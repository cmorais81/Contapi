"""
COBOL AI Engine v4.0 - Member Extractor
Extrator robusto para membros VMEMBER.
"""

import re
import logging
from typing import List
from dataclasses import dataclass

from parsers.interfaces.parser_interface import IMemberExtractor


@dataclass
class ExtractedMember:
    """Representa um membro extraído."""
    name: str
    content: str
    start_line: int
    end_line: int
    line_count: int
    size: int
    
    def to_dict(self) -> dict:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'start_line': self.start_line,
            'end_line': self.end_line,
            'line_count': self.line_count,
            'size': self.size
        }


class VMemberExtractor(IMemberExtractor):
    """
    Extrator de membros VMEMBER.
    
    Responsabilidades:
    - Extrair membros de arquivos empilhados
    - Suportar múltiplos formatos VMEMBER
    - Validar integridade dos membros
    - Fornecer metadados detalhados
    """
    
    def __init__(self):
        """Inicializa o extrator de membros."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões VMEMBER suportados
        self.vmember_patterns = [
            re.compile(r'^\s*VMEMBER\s+NAME\s+([A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'^\s*VMEMBER\s+([A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'^\s*//\s*VMEMBER\s+NAME\s+([A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'^\s*\*\s*VMEMBER\s+NAME\s+([A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'^\s*//\*\s*([A-Z0-9\-_]+)\s*\*', re.IGNORECASE),
        ]
        
        # Padrões de fim de membro (opcionais)
        self.end_patterns = [
            re.compile(r'^\s*VMEMBER\s+END', re.IGNORECASE),
            re.compile(r'^\s*//\s*END\s+VMEMBER', re.IGNORECASE),
            re.compile(r'^\s*\*\s*END\s+VMEMBER', re.IGNORECASE),
        ]
        
        self.logger.info("VMEMBER Extractor inicializado")
    
    def extract_members(self, content: str) -> List[ExtractedMember]:
        """
        Extrai membros do conteúdo empilhado.
        
        Args:
            content: Conteúdo empilhado
            
        Returns:
            List[ExtractedMember]: Lista de membros extraídos
        """
        if not content:
            return []
        
        lines = content.split('\n')
        members = []
        current_member = None
        current_content = []
        current_start_line = 0
        
        for line_num, line in enumerate(lines, 1):
            # Verificar se é início de novo membro
            member_name = self._extract_member_name(line)
            if member_name:
                # Salvar membro anterior se existir
                if current_member and current_content:
                    member = self._create_member(
                        current_member, 
                        current_content, 
                        current_start_line, 
                        line_num - 1
                    )
                    members.append(member)
                    self.logger.debug(f"Membro extraído: {current_member}")
                
                # Iniciar novo membro
                current_member = member_name
                current_content = []
                current_start_line = line_num
                continue
            
            # Verificar se é fim de membro
            if self._is_end_marker(line):
                if current_member and current_content:
                    member = self._create_member(
                        current_member, 
                        current_content, 
                        current_start_line, 
                        line_num - 1
                    )
                    members.append(member)
                    self.logger.debug(f"Membro extraído (com fim): {current_member}")
                
                current_member = None
                current_content = []
                continue
            
            # Adicionar linha ao membro atual
            if current_member is not None:
                current_content.append(line)
        
        # Salvar último membro se existir
        if current_member and current_content:
            member = self._create_member(
                current_member, 
                current_content, 
                current_start_line, 
                len(lines)
            )
            members.append(member)
            self.logger.debug(f"Último membro extraído: {current_member}")
        
        self.logger.info(f"Extração concluída: {len(members)} membros encontrados")
        return members
    
    def extract_member_by_name(self, content: str, member_name: str) -> ExtractedMember:
        """
        Extrai um membro específico pelo nome.
        
        Args:
            content: Conteúdo empilhado
            member_name: Nome do membro a extrair
            
        Returns:
            ExtractedMember: Membro extraído ou None se não encontrado
        """
        members = self.extract_members(content)
        
        for member in members:
            if member.name.upper() == member_name.upper():
                return member
        
        return None
    
    def get_member_names(self, content: str) -> List[str]:
        """
        Retorna lista de nomes de membros no conteúdo.
        
        Args:
            content: Conteúdo empilhado
            
        Returns:
            List[str]: Lista de nomes de membros
        """
        member_names = []
        lines = content.split('\n')
        
        for line in lines:
            member_name = self._extract_member_name(line)
            if member_name and member_name not in member_names:
                member_names.append(member_name)
        
        return member_names
    
    def validate_members(self, members: List[ExtractedMember]) -> dict:
        """
        Valida integridade dos membros extraídos.
        
        Args:
            members: Lista de membros a validar
            
        Returns:
            dict: Resultado da validação
        """
        validation_result = {
            'valid_members': 0,
            'invalid_members': 0,
            'empty_members': 0,
            'duplicate_names': [],
            'issues': []
        }
        
        member_names = []
        
        for member in members:
            # Verificar se membro está vazio
            if not member.content.strip():
                validation_result['empty_members'] += 1
                validation_result['issues'].append(f"Membro vazio: {member.name}")
                continue
            
            # Verificar nomes duplicados
            if member.name in member_names:
                validation_result['duplicate_names'].append(member.name)
                validation_result['issues'].append(f"Nome duplicado: {member.name}")
            else:
                member_names.append(member.name)
            
            # Verificar se conteúdo parece válido
            if self._is_valid_member_content(member.content):
                validation_result['valid_members'] += 1
            else:
                validation_result['invalid_members'] += 1
                validation_result['issues'].append(f"Conteúdo inválido: {member.name}")
        
        return validation_result
    
    def _extract_member_name(self, line: str) -> str:
        """
        Extrai nome do membro da linha.
        
        Args:
            line: Linha a analisar
            
        Returns:
            str: Nome do membro ou None se não encontrado
        """
        for pattern in self.vmember_patterns:
            match = pattern.match(line)
            if match:
                return match.group(1).strip()
        
        return None
    
    def _is_end_marker(self, line: str) -> bool:
        """
        Verifica se a linha é marcador de fim de membro.
        
        Args:
            line: Linha a verificar
            
        Returns:
            bool: True se for marcador de fim
        """
        return any(pattern.match(line) for pattern in self.end_patterns)
    
    def _create_member(self, name: str, content_lines: List[str], 
                      start_line: int, end_line: int) -> ExtractedMember:
        """
        Cria objeto ExtractedMember.
        
        Args:
            name: Nome do membro
            content_lines: Linhas do conteúdo
            start_line: Linha de início
            end_line: Linha de fim
            
        Returns:
            ExtractedMember: Membro criado
        """
        content = '\n'.join(content_lines)
        
        return ExtractedMember(
            name=name,
            content=content,
            start_line=start_line,
            end_line=end_line,
            line_count=len(content_lines),
            size=len(content)
        )
    
    def _is_valid_member_content(self, content: str) -> bool:
        """
        Verifica se o conteúdo do membro é válido.
        
        Args:
            content: Conteúdo a verificar
            
        Returns:
            bool: True se válido
        """
        if not content or not content.strip():
            return False
        
        # Verificar se tem pelo menos algumas características de COBOL
        content_upper = content.upper()
        
        # Indicadores básicos de COBOL/Copybook
        indicators = [
            'IDENTIFICATION', 'PROGRAM-ID', 'DATA DIVISION',
            'PROCEDURE DIVISION', 'WORKING-STORAGE', 'PIC',
            'PICTURE', 'COPY', '01 ', '05 ', '10 ', 'MOVE',
            'PERFORM', 'IF', 'ELSE', 'END-IF'
        ]
        
        # Se tem pelo menos 1 indicador, considerar válido
        return any(indicator in content_upper for indicator in indicators)
    
    def get_extraction_statistics(self, content: str, members: List[ExtractedMember]) -> dict:
        """
        Retorna estatísticas da extração.
        
        Args:
            content: Conteúdo original
            members: Membros extraídos
            
        Returns:
            dict: Estatísticas da extração
        """
        total_lines = len(content.split('\n'))
        total_size = len(content)
        
        extracted_lines = sum(member.line_count for member in members)
        extracted_size = sum(member.size for member in members)
        
        return {
            'total_members': len(members),
            'member_names': [member.name for member in members],
            'original_lines': total_lines,
            'original_size': total_size,
            'extracted_lines': extracted_lines,
            'extracted_size': extracted_size,
            'extraction_efficiency': round(extracted_lines / total_lines * 100, 1) if total_lines > 0 else 0,
            'average_member_size': round(extracted_size / len(members), 1) if members else 0,
            'largest_member': max(members, key=lambda m: m.size).name if members else None,
            'smallest_member': min(members, key=lambda m: m.size).name if members else None
        }
