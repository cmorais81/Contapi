"""
Infrastructure Layer - Repository Implementations.
Following Repository Pattern and implementing domain repository interfaces.

Author: Carlos Morais
"""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import UUID
import asyncio

from sqlalchemy import select, update, delete, and_, or_, func, text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload, joinedload

from ...domain.entities import DataObject, DataLineage, AccessPolicy, QualityMetric
from ...domain.repositories import (
    IDataObjectRepository, IDataLineageRepository, 
    IAccessPolicyRepository, IQualityMetricRepository
)
from ...domain.value_objects import (
    DataObjectId, DataObjectName, CatalogName, SchemaName,
    SecurityClassification, ObjectType, DataFormat
)
from ...application.dtos import SearchRequestDTO, PaginatedResponseDTO
from ...application.exceptions import EntityNotFoundError, DatabaseError
from .models import (
    DataObjectModel, DataLineageModel, AccessPolicyModel, 
    QualityMetricModel, DataObjectPropertyModel
)


class BaseRepository(ABC):
    """Base repository with common functionality."""
    
    def __init__(self, session: AsyncSession):
        self._session = session
    
    async def _execute_query(self, query):
        """Execute query with error handling."""
        try:
            result = await self._session.execute(query)
            return result
        except Exception as e:
            raise DatabaseError(f"Database query failed: {str(e)}")
    
    async def _commit(self):
        """Commit transaction with error handling."""
        try:
            await self._session.commit()
        except Exception as e:
            await self._session.rollback()
            raise DatabaseError(f"Database commit failed: {str(e)}")
    
    async def _rollback(self):
        """Rollback transaction."""
        try:
            await self._session.rollback()
        except Exception as e:
            raise DatabaseError(f"Database rollback failed: {str(e)}")


class DataObjectRepository(BaseRepository, IDataObjectRepository):
    """SQLAlchemy implementation of DataObject repository."""
    
    async def save(self, data_object: DataObject) -> DataObject:
        """Save data object to database."""
        try:
            # Convert entity to model
            model = self._entity_to_model(data_object)
            
            # Check if it's an update or insert
            existing = await self._session.get(DataObjectModel, data_object.id)
            if existing:
                # Update existing
                for key, value in model.__dict__.items():
                    if not key.startswith('_') and key != 'id':
                        setattr(existing, key, value)
                model = existing
            else:
                # Insert new
                self._session.add(model)
            
            await self._commit()
            
            # Convert back to entity
            return self._model_to_entity(model)
            
        except Exception as e:
            await self._rollback()
            raise DatabaseError(f"Failed to save data object: {str(e)}")
    
    async def get_by_id(self, object_id: DataObjectId) -> Optional[DataObject]:
        """Get data object by ID."""
        try:
            query = select(DataObjectModel).options(
                selectinload(DataObjectModel.properties)
            ).where(DataObjectModel.id == object_id.value)
            
            result = await self._execute_query(query)
            model = result.scalar_one_or_none()
            
            if model:
                return self._model_to_entity(model)
            return None
            
        except Exception as e:
            raise DatabaseError(f"Failed to get data object by ID: {str(e)}")
    
    async def get_by_name(
        self, 
        catalog_name: CatalogName, 
        schema_name: SchemaName, 
        object_name: DataObjectName
    ) -> Optional[DataObject]:
        """Get data object by full name."""
        try:
            query = select(DataObjectModel).options(
                selectinload(DataObjectModel.properties)
            ).where(
                and_(
                    DataObjectModel.catalog_name == catalog_name.value,
                    DataObjectModel.schema_name == schema_name.value,
                    DataObjectModel.object_name == object_name.value
                )
            )
            
            result = await self._execute_query(query)
            model = result.scalar_one_or_none()
            
            if model:
                return self._model_to_entity(model)
            return None
            
        except Exception as e:
            raise DatabaseError(f"Failed to get data object by name: {str(e)}")
    
    async def list_by_catalog(self, catalog_name: CatalogName) -> List[DataObject]:
        """List all data objects in a catalog."""
        try:
            query = select(DataObjectModel).options(
                selectinload(DataObjectModel.properties)
            ).where(
                DataObjectModel.catalog_name == catalog_name.value
            ).order_by(DataObjectModel.object_name)
            
            result = await self._execute_query(query)
            models = result.scalars().all()
            
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise DatabaseError(f"Failed to list data objects by catalog: {str(e)}")
    
    async def list_by_schema(
        self, 
        catalog_name: CatalogName, 
        schema_name: SchemaName
    ) -> List[DataObject]:
        """List all data objects in a schema."""
        try:
            query = select(DataObjectModel).options(
                selectinload(DataObjectModel.properties)
            ).where(
                and_(
                    DataObjectModel.catalog_name == catalog_name.value,
                    DataObjectModel.schema_name == schema_name.value
                )
            ).order_by(DataObjectModel.object_name)
            
            result = await self._execute_query(query)
            models = result.scalars().all()
            
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise DatabaseError(f"Failed to list data objects by schema: {str(e)}")
    
    async def list_by_type(self, object_type: ObjectType) -> List[DataObject]:
        """List all data objects of a specific type."""
        try:
            query = select(DataObjectModel).options(
                selectinload(DataObjectModel.properties)
            ).where(
                DataObjectModel.object_type == object_type.value
            ).order_by(DataObjectModel.object_name)
            
            result = await self._execute_query(query)
            models = result.scalars().all()
            
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise DatabaseError(f"Failed to list data objects by type: {str(e)}")
    
    async def list_by_owner(self, owner: str) -> List[DataObject]:
        """List all data objects owned by a user."""
        try:
            query = select(DataObjectModel).options(
                selectinload(DataObjectModel.properties)
            ).where(
                or_(
                    DataObjectModel.object_owner == owner,
                    DataObjectModel.business_owner == owner,
                    DataObjectModel.steward == owner
                )
            ).order_by(DataObjectModel.object_name)
            
            result = await self._execute_query(query)
            models = result.scalars().all()
            
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise DatabaseError(f"Failed to list data objects by owner: {str(e)}")
    
    async def list_by_tags(self, tags: List[str]) -> List[DataObject]:
        """List all data objects with specific tags."""
        try:
            # Build query to find objects with any of the specified tags
            tag_conditions = [DataObjectModel.tags.contains([tag]) for tag in tags]
            
            query = select(DataObjectModel).options(
                selectinload(DataObjectModel.properties)
            ).where(
                or_(*tag_conditions)
            ).order_by(DataObjectModel.object_name)
            
            result = await self._execute_query(query)
            models = result.scalars().all()
            
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise DatabaseError(f"Failed to list data objects by tags: {str(e)}")
    
    async def search(self, search_request: SearchRequestDTO) -> PaginatedResponseDTO:
        """Search data objects with filters and pagination."""
        try:
            # Build base query
            query = select(DataObjectModel).options(
                selectinload(DataObjectModel.properties)
            )
            
            # Apply filters
            conditions = []
            
            # Text search
            if search_request.query:
                search_term = f"%{search_request.query}%"
                conditions.append(
                    or_(
                        DataObjectModel.object_name.ilike(search_term),
                        DataObjectModel.description.ilike(search_term),
                        DataObjectModel.full_name.ilike(search_term)
                    )
                )
            
            # Apply additional filters
            if search_request.filters:
                for key, value in search_request.filters.items():
                    if hasattr(DataObjectModel, key):
                        if isinstance(value, list):
                            conditions.append(getattr(DataObjectModel, key).in_(value))
                        else:
                            conditions.append(getattr(DataObjectModel, key) == value)
            
            if conditions:
                query = query.where(and_(*conditions))
            
            # Count total results
            count_query = select(func.count()).select_from(query.subquery())
            total_result = await self._execute_query(count_query)
            total = total_result.scalar()
            
            # Apply sorting
            if search_request.sort_by:
                sort_column = getattr(DataObjectModel, search_request.sort_by, None)
                if sort_column:
                    if search_request.sort_order == "desc":
                        query = query.order_by(sort_column.desc())
                    else:
                        query = query.order_by(sort_column.asc())
            else:
                query = query.order_by(DataObjectModel.object_name)
            
            # Apply pagination
            offset = (search_request.page - 1) * search_request.limit
            query = query.offset(offset).limit(search_request.limit)
            
            # Execute query
            result = await self._execute_query(query)
            models = result.scalars().all()
            
            # Convert to entities
            entities = [self._model_to_entity(model) for model in models]
            
            # Calculate pagination info
            pages = (total + search_request.limit - 1) // search_request.limit
            
            return PaginatedResponseDTO(
                items=entities,
                total=total,
                page=search_request.page,
                size=len(entities),
                pages=pages,
                has_next=search_request.page < pages,
                has_prev=search_request.page > 1
            )
            
        except Exception as e:
            raise DatabaseError(f"Failed to search data objects: {str(e)}")
    
    async def delete(self, object_id: DataObjectId) -> bool:
        """Delete data object (soft delete)."""
        try:
            query = update(DataObjectModel).where(
                DataObjectModel.id == object_id.value
            ).values(
                is_active=False,
                updated_at=datetime.utcnow()
            )
            
            result = await self._execute_query(query)
            await self._commit()
            
            return result.rowcount > 0
            
        except Exception as e:
            await self._rollback()
            raise DatabaseError(f"Failed to delete data object: {str(e)}")
    
    async def hard_delete(self, object_id: DataObjectId) -> bool:
        """Permanently delete data object."""
        try:
            # Delete properties first (foreign key constraint)
            await self._execute_query(
                delete(DataObjectPropertyModel).where(
                    DataObjectPropertyModel.object_id == object_id.value
                )
            )
            
            # Delete object
            query = delete(DataObjectModel).where(
                DataObjectModel.id == object_id.value
            )
            
            result = await self._execute_query(query)
            await self._commit()
            
            return result.rowcount > 0
            
        except Exception as e:
            await self._rollback()
            raise DatabaseError(f"Failed to hard delete data object: {str(e)}")
    
    async def exists(self, object_id: DataObjectId) -> bool:
        """Check if data object exists."""
        try:
            query = select(func.count()).where(
                DataObjectModel.id == object_id.value
            )
            
            result = await self._execute_query(query)
            count = result.scalar()
            
            return count > 0
            
        except Exception as e:
            raise DatabaseError(f"Failed to check data object existence: {str(e)}")
    
    async def get_statistics(self) -> Dict[str, Any]:
        """Get repository statistics."""
        try:
            # Total objects
            total_query = select(func.count()).select_from(DataObjectModel)
            total_result = await self._execute_query(total_query)
            total = total_result.scalar()
            
            # Objects by type
            type_query = select(
                DataObjectModel.object_type,
                func.count().label('count')
            ).group_by(DataObjectModel.object_type)
            type_result = await self._execute_query(type_query)
            by_type = {row.object_type: row.count for row in type_result}
            
            # Objects by classification
            classification_query = select(
                DataObjectModel.security_classification,
                func.count().label('count')
            ).group_by(DataObjectModel.security_classification)
            classification_result = await self._execute_query(classification_query)
            by_classification = {row.security_classification: row.count for row in classification_result}
            
            # Active vs inactive
            active_query = select(func.count()).where(DataObjectModel.is_active == True)
            active_result = await self._execute_query(active_query)
            active = active_result.scalar()
            
            return {
                "total_objects": total,
                "active_objects": active,
                "inactive_objects": total - active,
                "objects_by_type": by_type,
                "objects_by_classification": by_classification
            }
            
        except Exception as e:
            raise DatabaseError(f"Failed to get repository statistics: {str(e)}")
    
    def _entity_to_model(self, entity: DataObject) -> DataObjectModel:
        """Convert entity to SQLAlchemy model."""
        model = DataObjectModel(
            id=entity.id,
            object_name=entity.object_name.value,
            object_type=entity.object_type.value,
            catalog_name=entity.catalog_name.value,
            schema_name=entity.schema_name.value,
            full_name=entity.full_name,
            object_owner=entity.object_owner,
            description=entity.description,
            location=entity.location,
            format=entity.format.value if entity.format else None,
            size_bytes=entity.size_bytes,
            row_count=entity.row_count,
            column_count=entity.column_count,
            is_active=entity.is_active,
            tags=list(entity.tags),
            security_classification=entity.security_classification.value,
            retention_policy=entity.retention_policy,
            business_owner=entity.business_owner,
            steward=entity.steward,
            created_at=entity.created_at,
            updated_at=entity.updated_at,
            version=entity.version,
            quality_score=entity.quality_score.value if entity.quality_score else None
        )
        
        # Add properties
        for prop in entity.properties:
            prop_model = DataObjectPropertyModel(
                object_id=entity.id,
                name=prop.name,
                data_type=prop.data_type,
                is_nullable=prop.is_nullable,
                is_primary_key=prop.is_primary_key,
                is_foreign_key=prop.is_foreign_key,
                description=prop.description,
                default_value=prop.default_value,
                constraints=prop.constraints,
                tags=list(prop.tags),
                security_classification=prop.security_classification.value if prop.security_classification else None
            )
            model.properties.append(prop_model)
        
        return model
    
    def _model_to_entity(self, model: DataObjectModel) -> DataObject:
        """Convert SQLAlchemy model to entity."""
        from ...domain.entities import DataObjectProperty
        
        # Convert properties
        properties = []
        for prop_model in model.properties:
            prop = DataObjectProperty(
                name=prop_model.name,
                data_type=prop_model.data_type,
                is_nullable=prop_model.is_nullable,
                is_primary_key=prop_model.is_primary_key,
                is_foreign_key=prop_model.is_foreign_key,
                description=prop_model.description,
                default_value=prop_model.default_value,
                constraints=prop_model.constraints or [],
                tags=set(prop_model.tags or []),
                security_classification=SecurityClassification(prop_model.security_classification) if prop_model.security_classification else None
            )
            properties.append(prop)
        
        # Create entity
        entity = DataObject(
            object_name=DataObjectName(model.object_name),
            object_type=ObjectType(model.object_type),
            catalog_name=CatalogName(model.catalog_name),
            schema_name=SchemaName(model.schema_name),
            object_owner=model.object_owner,
            entity_id=model.id,
            description=model.description,
            location=model.location,
            format=DataFormat(model.format) if model.format else None,
            size_bytes=model.size_bytes,
            row_count=model.row_count,
            tags=set(model.tags or []),
            security_classification=SecurityClassification(model.security_classification),
            retention_policy=model.retention_policy,
            business_owner=model.business_owner,
            steward=model.steward,
            properties=properties
        )
        
        # Set internal state
        entity._created_at = model.created_at
        entity._updated_at = model.updated_at
        entity._version = model.version
        entity._is_active = model.is_active
        
        if model.quality_score is not None:
            from ...domain.value_objects import QualityScore
            entity._quality_score = QualityScore(model.quality_score)
        
        return entity


class DataLineageRepository(BaseRepository, IDataLineageRepository):
    """SQLAlchemy implementation of DataLineage repository."""
    
    async def save(self, lineage: DataLineage) -> DataLineage:
        """Save data lineage to database."""
        try:
            model = self._entity_to_model(lineage)
            
            existing = await self._session.get(DataLineageModel, lineage.id)
            if existing:
                for key, value in model.__dict__.items():
                    if not key.startswith('_') and key != 'id':
                        setattr(existing, key, value)
                model = existing
            else:
                self._session.add(model)
            
            await self._commit()
            return self._model_to_entity(model)
            
        except Exception as e:
            await self._rollback()
            raise DatabaseError(f"Failed to save data lineage: {str(e)}")
    
    async def get_by_id(self, lineage_id: UUID) -> Optional[DataLineage]:
        """Get data lineage by ID."""
        try:
            model = await self._session.get(DataLineageModel, lineage_id)
            if model:
                return self._model_to_entity(model)
            return None
            
        except Exception as e:
            raise DatabaseError(f"Failed to get data lineage by ID: {str(e)}")
    
    async def get_upstream_lineage(self, object_id: DataObjectId) -> List[DataLineage]:
        """Get upstream lineage for an object."""
        try:
            query = select(DataLineageModel).where(
                DataLineageModel.target_object_id == object_id.value
            )
            
            result = await self._execute_query(query)
            models = result.scalars().all()
            
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise DatabaseError(f"Failed to get upstream lineage: {str(e)}")
    
    async def get_downstream_lineage(self, object_id: DataObjectId) -> List[DataLineage]:
        """Get downstream lineage for an object."""
        try:
            query = select(DataLineageModel).where(
                DataLineageModel.source_object_id == object_id.value
            )
            
            result = await self._execute_query(query)
            models = result.scalars().all()
            
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise DatabaseError(f"Failed to get downstream lineage: {str(e)}")
    
    async def delete(self, lineage_id: UUID) -> bool:
        """Delete data lineage."""
        try:
            query = delete(DataLineageModel).where(
                DataLineageModel.id == lineage_id
            )
            
            result = await self._execute_query(query)
            await self._commit()
            
            return result.rowcount > 0
            
        except Exception as e:
            await self._rollback()
            raise DatabaseError(f"Failed to delete data lineage: {str(e)}")
    
    def _entity_to_model(self, entity: DataLineage) -> DataLineageModel:
        """Convert entity to SQLAlchemy model."""
        return DataLineageModel(
            id=entity.id,
            source_object_id=entity.source_object_id.value,
            target_object_id=entity.target_object_id.value,
            lineage_type=entity.lineage_type,
            transformation_logic=entity.transformation_logic,
            job_id=entity.job_id,
            job_name=entity.job_name,
            confidence_score=entity.confidence_score.value,
            discovered_by=entity.discovered_by,
            is_active=entity.is_active,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )
    
    def _model_to_entity(self, model: DataLineageModel) -> DataLineage:
        """Convert SQLAlchemy model to entity."""
        from ...domain.value_objects import LineageConfidence
        
        entity = DataLineage(
            source_object_id=DataObjectId(model.source_object_id),
            target_object_id=DataObjectId(model.target_object_id),
            lineage_type=model.lineage_type,
            entity_id=model.id,
            transformation_logic=model.transformation_logic,
            job_id=model.job_id,
            job_name=model.job_name,
            confidence_score=LineageConfidence(model.confidence_score),
            discovered_by=model.discovered_by
        )
        
        # Set internal state
        entity._created_at = model.created_at
        entity._updated_at = model.updated_at
        entity._is_active = model.is_active
        
        return entity


# Similar implementations for AccessPolicyRepository and QualityMetricRepository
# would follow the same pattern...

class AccessPolicyRepository(BaseRepository, IAccessPolicyRepository):
    """SQLAlchemy implementation of AccessPolicy repository."""
    
    async def save(self, policy: AccessPolicy) -> AccessPolicy:
        """Save access policy to database."""
        # Implementation similar to DataObjectRepository
        pass
    
    async def get_by_id(self, policy_id: UUID) -> Optional[AccessPolicy]:
        """Get access policy by ID."""
        pass
    
    # ... other methods


class QualityMetricRepository(BaseRepository, IQualityMetricRepository):
    """SQLAlchemy implementation of QualityMetric repository."""
    
    async def save(self, metric: QualityMetric) -> QualityMetric:
        """Save quality metric to database."""
        # Implementation similar to DataObjectRepository
        pass
    
    async def get_by_id(self, metric_id: UUID) -> Optional[QualityMetric]:
        """Get quality metric by ID."""
        pass
    
    # ... other methods

