"""
FastAPI Endpoints for Data Objects.
Following RESTful principles and OpenAPI standards.

Author: Carlos Morais
"""

from typing import List, Optional, Dict, Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Query, Body, Path
from fastapi.responses import JSONResponse

from ....application.use_cases import (
    CreateDataObjectUseCase, GetDataObjectUseCase, UpdateDataObjectUseCase,
    DeleteDataObjectUseCase, SearchDataObjectsUseCase, ListDataObjectsUseCase
)
from ....application.dtos import (
    DataObjectCreateDTO, DataObjectUpdateDTO, DataObjectResponseDTO,
    SearchRequestDTO, PaginatedResponseDTO, ErrorResponseDTO
)
from ....application.exceptions import (
    EntityNotFoundError, ValidationError, DatabaseError, 
    PermissionError, BusinessRuleViolationError
)
from ...dependencies import get_create_data_object_use_case, get_get_data_object_use_case, ...


router = APIRouter(
    prefix="/data-objects",
    tags=["Data Objects"],
    responses={
        400: {"model": ErrorResponseDTO, "description": "Bad Request"},
        401: {"model": ErrorResponseDTO, "description": "Unauthorized"},
        403: {"model": ErrorResponseDTO, "description": "Forbidden"},
        404: {"model": ErrorResponseDTO, "description": "Not Found"},
        500: {"model": ErrorResponseDTO, "description": "Internal Server Error"}
    }
)


@router.post(
    "/",
    response_model=DataObjectResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new Data Object",
    description="Creates a new data object in the governance catalog. Requires admin privileges.",
    operation_id="create_data_object"
)
async def create_data_object(
    data_object_dto: DataObjectCreateDTO = Body(..., description="Data object creation payload"),
    use_case: CreateDataObjectUseCase = Depends(get_create_data_object_use_case)
) -> DataObjectResponseDTO:
    """
    Create a new Data Object.
    
    This endpoint allows creating a new data object with its properties, metadata, and ownership.
    It performs validation on the input data and ensures the object is unique.
    """
    try:
        created_object = await use_case.execute(data_object_dto)
        return created_object
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except BusinessRuleViolationError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))
    except Exception as e:
        # Log the exception
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="An unexpected error occurred")


@router.get(
    "/{object_id}",
    response_model=DataObjectResponseDTO,
    summary="Get a Data Object by ID",
    description="Retrieves a single data object by its unique ID.",
    operation_id="get_data_object_by_id"
)
async def get_data_object(
    object_id: UUID = Path(..., description="Unique ID of the data object"),
    use_case: GetDataObjectUseCase = Depends(get_get_data_object_use_case)
) -> DataObjectResponseDTO:
    """
    Get a Data Object by its ID.
    
    This endpoint retrieves detailed information about a specific data object,
    including its properties, metadata, and quality score.
    """
    try:
        data_object = await use_case.execute(object_id)
        if not data_object:
            raise EntityNotFoundError("Data object not found")
        return data_object
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        # Log the exception
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="An unexpected error occurred")


@router.put(
    "/{object_id}",
    response_model=DataObjectResponseDTO,
    summary="Update a Data Object",
    description="Updates an existing data object. Requires admin or owner privileges.",
    operation_id="update_data_object"
)
async def update_data_object(
    object_id: UUID = Path(..., description="Unique ID of the data object to update"),
    update_dto: DataObjectUpdateDTO = Body(..., description="Data object update payload"),
    use_case: UpdateDataObjectUseCase = Depends(get_update_data_object_use_case)
) -> DataObjectResponseDTO:
    """
    Update a Data Object.
    
    This endpoint allows updating metadata and properties of an existing data object.
    It performs validation and ensures the user has the necessary permissions.
    """
    try:
        updated_object = await use_case.execute(object_id, update_dto)
        return updated_object
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))
    except Exception as e:
        # Log the exception
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="An unexpected error occurred")


@router.delete(
    "/{object_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a Data Object",
    description="Deletes a data object (soft delete). Requires admin privileges.",
    operation_id="delete_data_object"
)
async def delete_data_object(
    object_id: UUID = Path(..., description="Unique ID of the data object to delete"),
    use_case: DeleteDataObjectUseCase = Depends(get_delete_data_object_use_case)
) -> None:
    """
    Delete a Data Object.
    
    This endpoint performs a soft delete on a data object, marking it as inactive.
    The object can be recovered later. For permanent deletion, use the hard delete endpoint.
    """
    try:
        await use_case.execute(object_id)
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(e))
    except Exception as e:
        # Log the exception
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="An unexpected error occurred")


@router.get(
    "/",
    response_model=PaginatedResponseDTO[DataObjectResponseDTO],
    summary="List Data Objects",
    description="Lists all data objects with pagination.",
    operation_id="list_data_objects"
)
async def list_data_objects(
    page: int = Query(1, ge=1, description="Page number"),
    limit: int = Query(20, ge=1, le=100, description="Page size"),
    sort_by: Optional[str] = Query(None, description="Field to sort by"),
    sort_order: str = Query("asc", description="Sort order (asc or desc)"),
    use_case: ListDataObjectsUseCase = Depends(get_list_data_objects_use_case)
) -> PaginatedResponseDTO[DataObjectResponseDTO]:
    """
    List Data Objects.
    
    This endpoint provides a paginated list of all data objects in the catalog.
    It supports sorting and filtering.
    """
    try:
        search_request = SearchRequestDTO(page=page, limit=limit, sort_by=sort_by, sort_order=sort_order)
        paginated_result = await use_case.execute(search_request)
        return paginated_result
    except Exception as e:
        # Log the exception
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="An unexpected error occurred")


@router.post(
    "/search",
    response_model=PaginatedResponseDTO[DataObjectResponseDTO],
    summary="Search Data Objects",
    description="Searches for data objects based on query and filters.",
    operation_id="search_data_objects"
)
async def search_data_objects(
    search_request: SearchRequestDTO = Body(..., description="Search request payload"),
    use_case: SearchDataObjectsUseCase = Depends(get_search_data_objects_use_case)
) -> PaginatedResponseDTO[DataObjectResponseDTO]:
    """
    Search Data Objects.
    
    This endpoint provides advanced search capabilities for data objects,
    including full-text search, filtering by metadata, and pagination.
    """
    try:
        paginated_result = await use_case.execute(search_request)
        return paginated_result
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        # Log the exception
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="An unexpected error occurred")


# Additional endpoints for properties, tags, etc.

@router.post(
    "/{object_id}/properties",
    response_model=DataObjectResponseDTO,
    summary="Add a property to a Data Object",
    description="Adds a new property/column to an existing data object.",
    operation_id="add_data_object_property"
)
async def add_data_object_property(
    object_id: UUID = Path(..., description="Unique ID of the data object"),
    property_dto: DataObjectPropertyDTO = Body(..., description="Property to add"),
    # use_case: AddPropertyUseCase = Depends(get_add_property_use_case)
) -> DataObjectResponseDTO:
    """
    Add a property to a Data Object.
    """
    # Implementation would call a dedicated use case
    pass


@router.delete(
    "/{object_id}/properties/{property_name}",
    response_model=DataObjectResponseDTO,
    summary="Remove a property from a Data Object",
    description="Removes a property/column from an existing data object.",
    operation_id="remove_data_object_property"
)
async def remove_data_object_property(
    object_id: UUID = Path(..., description="Unique ID of the data object"),
    property_name: str = Path(..., description="Name of the property to remove"),
    # use_case: RemovePropertyUseCase = Depends(get_remove_property_use_case)
) -> DataObjectResponseDTO:
    """
    Remove a property from a Data Object.
    """
    # Implementation would call a dedicated use case
    pass


@router.post(
    "/{object_id}/tags",
    response_model=DataObjectResponseDTO,
    summary="Add a tag to a Data Object",
    description="Adds a new tag to an existing data object.",
    operation_id="add_data_object_tag"
)
async def add_data_object_tag(
    object_id: UUID = Path(..., description="Unique ID of the data object"),
    tag: str = Body(..., description="Tag to add"),
    # use_case: AddTagUseCase = Depends(get_add_tag_use_case)
) -> DataObjectResponseDTO:
    """
    Add a tag to a Data Object.
    """
    # Implementation would call a dedicated use case
    pass


@router.delete(
    "/{object_id}/tags/{tag_name}",
    response_model=DataObjectResponseDTO,
    summary="Remove a tag from a Data Object",
    description="Removes a tag from an existing data object.",
    operation_id="remove_data_object_tag"
)
async def remove_data_object_tag(
    object_id: UUID = Path(..., description="Unique ID of the data object"),
    tag_name: str = Path(..., description="Name of the tag to remove"),
    # use_case: RemoveTagUseCase = Depends(get_remove_tag_use_case)
) -> DataObjectResponseDTO:
    """
    Remove a tag from a Data Object.
    """
    # Implementation would call a dedicated use case
    pass

