"""
Domain entities for Data Governance API.
Following Domain-Driven Design (DDD) principles and SOLID architecture.

Author: Carlos Morais
"""

from abc import ABC, abstractmethod
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Any, Set
from uuid import UUID, uuid4
from dataclasses import dataclass, field

from ..value_objects import (
    DataObjectId, DataObjectName, CatalogName, SchemaName,
    SecurityClassification, ObjectType, DataFormat,
    QualityScore, LineageConfidence, PolicyPriority
)


class BaseEntity(ABC):
    """Base entity following DDD principles."""
    
    def __init__(self, entity_id: Optional[UUID] = None):
        self._id = entity_id or uuid4()
        self._created_at = datetime.utcnow()
        self._updated_at = datetime.utcnow()
        self._version = 1
        self._domain_events: List[Any] = []
    
    @property
    def id(self) -> UUID:
        """Entity unique identifier."""
        return self._id
    
    @property
    def created_at(self) -> datetime:
        """Entity creation timestamp."""
        return self._created_at
    
    @property
    def updated_at(self) -> datetime:
        """Entity last update timestamp."""
        return self._updated_at
    
    @property
    def version(self) -> int:
        """Entity version for optimistic locking."""
        return self._version
    
    def mark_as_updated(self) -> None:
        """Mark entity as updated."""
        self._updated_at = datetime.utcnow()
        self._version += 1
    
    def add_domain_event(self, event: Any) -> None:
        """Add domain event to be published."""
        self._domain_events.append(event)
    
    def clear_domain_events(self) -> List[Any]:
        """Clear and return domain events."""
        events = self._domain_events.copy()
        self._domain_events.clear()
        return events
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, BaseEntity):
            return False
        return self._id == other._id
    
    def __hash__(self) -> int:
        return hash(self._id)


@dataclass
class DataObjectProperty:
    """Value object representing a data object property/column."""
    name: str
    data_type: str
    is_nullable: bool = True
    is_primary_key: bool = False
    is_foreign_key: bool = False
    description: Optional[str] = None
    default_value: Optional[str] = None
    constraints: List[str] = field(default_factory=list)
    tags: Set[str] = field(default_factory=set)
    security_classification: Optional[SecurityClassification] = None
    
    def __post_init__(self):
        """Validate property after initialization."""
        if not self.name or not self.name.strip():
            raise ValueError("Property name cannot be empty")
        if not self.data_type or not self.data_type.strip():
            raise ValueError("Property data type cannot be empty")
        
        # Normalize name
        self.name = self.name.strip().lower()
        self.data_type = self.data_type.strip().lower()
        
        # Convert tags to set if it's a list
        if isinstance(self.tags, list):
            self.tags = set(self.tags)
    
    def add_tag(self, tag: str) -> None:
        """Add a tag to the property."""
        if tag and tag.strip():
            self.tags.add(tag.strip().lower())
    
    def remove_tag(self, tag: str) -> None:
        """Remove a tag from the property."""
        self.tags.discard(tag.strip().lower())
    
    def has_tag(self, tag: str) -> bool:
        """Check if property has a specific tag."""
        return tag.strip().lower() in self.tags
    
    def is_sensitive(self) -> bool:
        """Check if property contains sensitive data."""
        sensitive_tags = {'pii', 'phi', 'sensitive', 'confidential', 'personal'}
        return bool(self.tags.intersection(sensitive_tags))


class DataObject(BaseEntity):
    """
    Data Object entity representing tables, views, volumes, etc.
    Core entity in the data governance domain.
    """
    
    def __init__(
        self,
        object_name: DataObjectName,
        object_type: ObjectType,
        catalog_name: CatalogName,
        schema_name: SchemaName,
        object_owner: str,
        entity_id: Optional[UUID] = None,
        description: Optional[str] = None,
        location: Optional[str] = None,
        format: Optional[DataFormat] = None,
        size_bytes: Optional[int] = None,
        row_count: Optional[int] = None,
        tags: Optional[Set[str]] = None,
        security_classification: SecurityClassification = SecurityClassification.INTERNAL,
        retention_policy: Optional[str] = None,
        business_owner: Optional[str] = None,
        steward: Optional[str] = None,
        properties: Optional[List[DataObjectProperty]] = None
    ):
        super().__init__(entity_id)
        
        # Validate required fields
        self._validate_required_fields(object_name, object_type, catalog_name, schema_name, object_owner)
        
        # Core attributes
        self._object_name = object_name
        self._object_type = object_type
        self._catalog_name = catalog_name
        self._schema_name = schema_name
        self._object_owner = object_owner
        
        # Optional attributes
        self._description = description
        self._location = location
        self._format = format
        self._size_bytes = size_bytes
        self._row_count = row_count
        self._tags = tags or set()
        self._security_classification = security_classification
        self._retention_policy = retention_policy
        self._business_owner = business_owner
        self._steward = steward
        self._properties = properties or []
        
        # Computed attributes
        self._is_active = True
        self._quality_score: Optional[QualityScore] = None
        
        # Add creation event
        from ..events import DataObjectCreatedEvent
        self.add_domain_event(DataObjectCreatedEvent(self))
    
    def _validate_required_fields(self, object_name, object_type, catalog_name, schema_name, object_owner):
        """Validate required fields."""
        if not object_name:
            raise ValueError("Object name is required")
        if not object_type:
            raise ValueError("Object type is required")
        if not catalog_name:
            raise ValueError("Catalog name is required")
        if not schema_name:
            raise ValueError("Schema name is required")
        if not object_owner or not object_owner.strip():
            raise ValueError("Object owner is required")
    
    # Properties (getters)
    @property
    def object_name(self) -> DataObjectName:
        return self._object_name
    
    @property
    def object_type(self) -> ObjectType:
        return self._object_type
    
    @property
    def catalog_name(self) -> CatalogName:
        return self._catalog_name
    
    @property
    def schema_name(self) -> SchemaName:
        return self._schema_name
    
    @property
    def full_name(self) -> str:
        """Get fully qualified name."""
        return f"{self._catalog_name.value}.{self._schema_name.value}.{self._object_name.value}"
    
    @property
    def object_owner(self) -> str:
        return self._object_owner
    
    @property
    def description(self) -> Optional[str]:
        return self._description
    
    @property
    def location(self) -> Optional[str]:
        return self._location
    
    @property
    def format(self) -> Optional[DataFormat]:
        return self._format
    
    @property
    def size_bytes(self) -> Optional[int]:
        return self._size_bytes
    
    @property
    def row_count(self) -> Optional[int]:
        return self._row_count
    
    @property
    def column_count(self) -> int:
        return len(self._properties)
    
    @property
    def tags(self) -> Set[str]:
        return self._tags.copy()
    
    @property
    def security_classification(self) -> SecurityClassification:
        return self._security_classification
    
    @property
    def retention_policy(self) -> Optional[str]:
        return self._retention_policy
    
    @property
    def business_owner(self) -> Optional[str]:
        return self._business_owner
    
    @property
    def steward(self) -> Optional[str]:
        return self._steward
    
    @property
    def properties(self) -> List[DataObjectProperty]:
        return self._properties.copy()
    
    @property
    def is_active(self) -> bool:
        return self._is_active
    
    @property
    def quality_score(self) -> Optional[QualityScore]:
        return self._quality_score
    
    # Business methods
    def update_description(self, description: str) -> None:
        """Update object description."""
        self._description = description
        self.mark_as_updated()
        
        from ..events import DataObjectUpdatedEvent
        self.add_domain_event(DataObjectUpdatedEvent(self, "description"))
    
    def update_location(self, location: str) -> None:
        """Update object location."""
        self._location = location
        self.mark_as_updated()
        
        from ..events import DataObjectUpdatedEvent
        self.add_domain_event(DataObjectUpdatedEvent(self, "location"))
    
    def update_size_metrics(self, size_bytes: Optional[int], row_count: Optional[int]) -> None:
        """Update size metrics."""
        self._size_bytes = size_bytes
        self._row_count = row_count
        self.mark_as_updated()
        
        from ..events import DataObjectUpdatedEvent
        self.add_domain_event(DataObjectUpdatedEvent(self, "size_metrics"))
    
    def add_tag(self, tag: str) -> None:
        """Add a tag to the object."""
        if tag and tag.strip():
            self._tags.add(tag.strip().lower())
            self.mark_as_updated()
            
            from ..events import DataObjectTaggedEvent
            self.add_domain_event(DataObjectTaggedEvent(self, tag))
    
    def remove_tag(self, tag: str) -> None:
        """Remove a tag from the object."""
        if tag.strip().lower() in self._tags:
            self._tags.remove(tag.strip().lower())
            self.mark_as_updated()
            
            from ..events import DataObjectUntaggedEvent
            self.add_domain_event(DataObjectUntaggedEvent(self, tag))
    
    def has_tag(self, tag: str) -> bool:
        """Check if object has a specific tag."""
        return tag.strip().lower() in self._tags
    
    def update_security_classification(self, classification: SecurityClassification) -> None:
        """Update security classification."""
        old_classification = self._security_classification
        self._security_classification = classification
        self.mark_as_updated()
        
        from ..events import DataObjectSecurityUpdatedEvent
        self.add_domain_event(DataObjectSecurityUpdatedEvent(self, old_classification, classification))
    
    def update_ownership(self, business_owner: Optional[str] = None, steward: Optional[str] = None) -> None:
        """Update ownership information."""
        if business_owner is not None:
            self._business_owner = business_owner
        if steward is not None:
            self._steward = steward
        self.mark_as_updated()
        
        from ..events import DataObjectOwnershipUpdatedEvent
        self.add_domain_event(DataObjectOwnershipUpdatedEvent(self))
    
    def add_property(self, property: DataObjectProperty) -> None:
        """Add a property/column to the object."""
        # Check if property already exists
        existing_names = {prop.name for prop in self._properties}
        if property.name in existing_names:
            raise ValueError(f"Property '{property.name}' already exists")
        
        self._properties.append(property)
        self.mark_as_updated()
        
        from ..events import DataObjectPropertyAddedEvent
        self.add_domain_event(DataObjectPropertyAddedEvent(self, property))
    
    def remove_property(self, property_name: str) -> None:
        """Remove a property/column from the object."""
        self._properties = [prop for prop in self._properties if prop.name != property_name.lower()]
        self.mark_as_updated()
        
        from ..events import DataObjectPropertyRemovedEvent
        self.add_domain_event(DataObjectPropertyRemovedEvent(self, property_name))
    
    def get_property(self, property_name: str) -> Optional[DataObjectProperty]:
        """Get a specific property by name."""
        for prop in self._properties:
            if prop.name == property_name.lower():
                return prop
        return None
    
    def get_sensitive_properties(self) -> List[DataObjectProperty]:
        """Get all properties that contain sensitive data."""
        return [prop for prop in self._properties if prop.is_sensitive()]
    
    def update_quality_score(self, score: QualityScore) -> None:
        """Update quality score."""
        self._quality_score = score
        self.mark_as_updated()
        
        from ..events import DataObjectQualityUpdatedEvent
        self.add_domain_event(DataObjectQualityUpdatedEvent(self, score))
    
    def deactivate(self) -> None:
        """Deactivate the object (soft delete)."""
        self._is_active = False
        self.mark_as_updated()
        
        from ..events import DataObjectDeactivatedEvent
        self.add_domain_event(DataObjectDeactivatedEvent(self))
    
    def activate(self) -> None:
        """Activate the object."""
        self._is_active = True
        self.mark_as_updated()
        
        from ..events import DataObjectActivatedEvent
        self.add_domain_event(DataObjectActivatedEvent(self))
    
    def is_table(self) -> bool:
        """Check if object is a table."""
        return self._object_type == ObjectType.TABLE
    
    def is_view(self) -> bool:
        """Check if object is a view."""
        return self._object_type in [ObjectType.VIEW, ObjectType.MATERIALIZED_VIEW]
    
    def is_volume(self) -> bool:
        """Check if object is a volume."""
        return self._object_type == ObjectType.VOLUME
    
    def has_sensitive_data(self) -> bool:
        """Check if object contains sensitive data."""
        # Check tags
        sensitive_tags = {'pii', 'phi', 'sensitive', 'confidential', 'personal'}
        if self._tags.intersection(sensitive_tags):
            return True
        
        # Check security classification
        if self._security_classification in [SecurityClassification.CONFIDENTIAL, SecurityClassification.RESTRICTED]:
            return True
        
        # Check properties
        return any(prop.is_sensitive() for prop in self._properties)
    
    def calculate_estimated_size_mb(self) -> Optional[float]:
        """Calculate estimated size in MB."""
        if self._size_bytes is None:
            return None
        return self._size_bytes / (1024 * 1024)
    
    def calculate_estimated_size_gb(self) -> Optional[float]:
        """Calculate estimated size in GB."""
        if self._size_bytes is None:
            return None
        return self._size_bytes / (1024 * 1024 * 1024)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert entity to dictionary representation."""
        return {
            "id": str(self._id),
            "object_name": self._object_name.value,
            "object_type": self._object_type.value,
            "catalog_name": self._catalog_name.value,
            "schema_name": self._schema_name.value,
            "full_name": self.full_name,
            "object_owner": self._object_owner,
            "description": self._description,
            "location": self._location,
            "format": self._format.value if self._format else None,
            "size_bytes": self._size_bytes,
            "row_count": self._row_count,
            "column_count": self.column_count,
            "tags": list(self._tags),
            "security_classification": self._security_classification.value,
            "retention_policy": self._retention_policy,
            "business_owner": self._business_owner,
            "steward": self._steward,
            "is_active": self._is_active,
            "quality_score": self._quality_score.value if self._quality_score else None,
            "created_at": self._created_at.isoformat(),
            "updated_at": self._updated_at.isoformat(),
            "version": self._version,
            "properties": [
                {
                    "name": prop.name,
                    "data_type": prop.data_type,
                    "is_nullable": prop.is_nullable,
                    "is_primary_key": prop.is_primary_key,
                    "is_foreign_key": prop.is_foreign_key,
                    "description": prop.description,
                    "default_value": prop.default_value,
                    "constraints": prop.constraints,
                    "tags": list(prop.tags),
                    "security_classification": prop.security_classification.value if prop.security_classification else None
                }
                for prop in self._properties
            ]
        }


class DataLineage(BaseEntity):
    """
    Data Lineage entity representing relationships between data objects.
    """
    
    def __init__(
        self,
        source_object_id: DataObjectId,
        target_object_id: DataObjectId,
        lineage_type: str,
        entity_id: Optional[UUID] = None,
        transformation_logic: Optional[str] = None,
        job_id: Optional[str] = None,
        job_name: Optional[str] = None,
        confidence_score: LineageConfidence = LineageConfidence(1.0),
        discovered_by: str = "manual"
    ):
        super().__init__(entity_id)
        
        # Validate
        if source_object_id == target_object_id:
            raise ValueError("Source and target objects cannot be the same")
        
        self._source_object_id = source_object_id
        self._target_object_id = target_object_id
        self._lineage_type = lineage_type
        self._transformation_logic = transformation_logic
        self._job_id = job_id
        self._job_name = job_name
        self._confidence_score = confidence_score
        self._discovered_by = discovered_by
        self._is_active = True
        
        # Add creation event
        from ..events import DataLineageCreatedEvent
        self.add_domain_event(DataLineageCreatedEvent(self))
    
    @property
    def source_object_id(self) -> DataObjectId:
        return self._source_object_id
    
    @property
    def target_object_id(self) -> DataObjectId:
        return self._target_object_id
    
    @property
    def lineage_type(self) -> str:
        return self._lineage_type
    
    @property
    def transformation_logic(self) -> Optional[str]:
        return self._transformation_logic
    
    @property
    def job_id(self) -> Optional[str]:
        return self._job_id
    
    @property
    def job_name(self) -> Optional[str]:
        return self._job_name
    
    @property
    def confidence_score(self) -> LineageConfidence:
        return self._confidence_score
    
    @property
    def discovered_by(self) -> str:
        return self._discovered_by
    
    @property
    def is_active(self) -> bool:
        return self._is_active
    
    def update_confidence_score(self, score: LineageConfidence) -> None:
        """Update confidence score."""
        self._confidence_score = score
        self.mark_as_updated()
    
    def update_transformation_logic(self, logic: str) -> None:
        """Update transformation logic."""
        self._transformation_logic = logic
        self.mark_as_updated()
    
    def deactivate(self) -> None:
        """Deactivate lineage relationship."""
        self._is_active = False
        self.mark_as_updated()
    
    def is_high_confidence(self) -> bool:
        """Check if lineage has high confidence."""
        return self._confidence_score.value >= 0.8
    
    def is_automatic_discovery(self) -> bool:
        """Check if lineage was discovered automatically."""
        return self._discovered_by != "manual"


class AccessPolicy(BaseEntity):
    """
    Access Policy entity for data governance and security.
    """
    
    def __init__(
        self,
        policy_name: str,
        policy_type: str,
        policy_scope: str,
        conditions: Dict[str, Any],
        actions: Dict[str, Any],
        entity_id: Optional[UUID] = None,
        priority: PolicyPriority = PolicyPriority(100),
        description: Optional[str] = None,
        compliance_frameworks: Optional[List[str]] = None,
        object_id: Optional[DataObjectId] = None,
        created_by: Optional[str] = None
    ):
        super().__init__(entity_id)
        
        # Validate
        if not policy_name or not policy_name.strip():
            raise ValueError("Policy name is required")
        if not policy_type or not policy_type.strip():
            raise ValueError("Policy type is required")
        if not conditions:
            raise ValueError("Policy conditions are required")
        if not actions:
            raise ValueError("Policy actions are required")
        
        self._policy_name = policy_name.strip()
        self._policy_type = policy_type.strip()
        self._policy_scope = policy_scope.strip()
        self._conditions = conditions
        self._actions = actions
        self._priority = priority
        self._description = description
        self._compliance_frameworks = compliance_frameworks or []
        self._object_id = object_id
        self._created_by = created_by
        self._is_active = True
        self._is_enforced = True
        
        # Add creation event
        from ..events import AccessPolicyCreatedEvent
        self.add_domain_event(AccessPolicyCreatedEvent(self))
    
    @property
    def policy_name(self) -> str:
        return self._policy_name
    
    @property
    def policy_type(self) -> str:
        return self._policy_type
    
    @property
    def policy_scope(self) -> str:
        return self._policy_scope
    
    @property
    def conditions(self) -> Dict[str, Any]:
        return self._conditions.copy()
    
    @property
    def actions(self) -> Dict[str, Any]:
        return self._actions.copy()
    
    @property
    def priority(self) -> PolicyPriority:
        return self._priority
    
    @property
    def description(self) -> Optional[str]:
        return self._description
    
    @property
    def compliance_frameworks(self) -> List[str]:
        return self._compliance_frameworks.copy()
    
    @property
    def object_id(self) -> Optional[DataObjectId]:
        return self._object_id
    
    @property
    def created_by(self) -> Optional[str]:
        return self._created_by
    
    @property
    def is_active(self) -> bool:
        return self._is_active
    
    @property
    def is_enforced(self) -> bool:
        return self._is_enforced
    
    def update_conditions(self, conditions: Dict[str, Any]) -> None:
        """Update policy conditions."""
        self._conditions = conditions
        self.mark_as_updated()
    
    def update_actions(self, actions: Dict[str, Any]) -> None:
        """Update policy actions."""
        self._actions = actions
        self.mark_as_updated()
    
    def update_priority(self, priority: PolicyPriority) -> None:
        """Update policy priority."""
        self._priority = priority
        self.mark_as_updated()
    
    def add_compliance_framework(self, framework: str) -> None:
        """Add compliance framework."""
        if framework not in self._compliance_frameworks:
            self._compliance_frameworks.append(framework)
            self.mark_as_updated()
    
    def remove_compliance_framework(self, framework: str) -> None:
        """Remove compliance framework."""
        if framework in self._compliance_frameworks:
            self._compliance_frameworks.remove(framework)
            self.mark_as_updated()
    
    def enable_enforcement(self) -> None:
        """Enable policy enforcement."""
        self._is_enforced = True
        self.mark_as_updated()
    
    def disable_enforcement(self) -> None:
        """Disable policy enforcement."""
        self._is_enforced = False
        self.mark_as_updated()
    
    def deactivate(self) -> None:
        """Deactivate policy."""
        self._is_active = False
        self._is_enforced = False
        self.mark_as_updated()
    
    def is_high_priority(self) -> bool:
        """Check if policy has high priority."""
        return self._priority.value <= 50
    
    def applies_to_object(self, object_id: DataObjectId) -> bool:
        """Check if policy applies to a specific object."""
        if self._object_id:
            return self._object_id == object_id
        # For global policies, check scope and conditions
        return self._policy_scope == "global"


class QualityMetric(BaseEntity):
    """
    Quality Metric entity for data quality monitoring.
    """
    
    def __init__(
        self,
        object_id: DataObjectId,
        dimension: str,
        metric_value: float,
        entity_id: Optional[UUID] = None,
        rule_name: Optional[str] = None,
        rule_definition: Optional[str] = None,
        threshold_value: Optional[float] = None,
        measurement_timestamp: Optional[datetime] = None
    ):
        super().__init__(entity_id)
        
        # Validate
        if not (0 <= metric_value <= 100):
            raise ValueError("Metric value must be between 0 and 100")
        if threshold_value is not None and not (0 <= threshold_value <= 100):
            raise ValueError("Threshold value must be between 0 and 100")
        
        self._object_id = object_id
        self._dimension = dimension
        self._metric_value = metric_value
        self._rule_name = rule_name
        self._rule_definition = rule_definition
        self._threshold_value = threshold_value
        self._measurement_timestamp = measurement_timestamp or datetime.utcnow()
        self._is_passing = self._calculate_is_passing()
        
        # Add creation event
        from ..events import QualityMetricCreatedEvent
        self.add_domain_event(QualityMetricCreatedEvent(self))
    
    def _calculate_is_passing(self) -> bool:
        """Calculate if metric is passing based on threshold."""
        if self._threshold_value is None:
            return True
        return self._metric_value >= self._threshold_value
    
    @property
    def object_id(self) -> DataObjectId:
        return self._object_id
    
    @property
    def dimension(self) -> str:
        return self._dimension
    
    @property
    def metric_value(self) -> float:
        return self._metric_value
    
    @property
    def rule_name(self) -> Optional[str]:
        return self._rule_name
    
    @property
    def rule_definition(self) -> Optional[str]:
        return self._rule_definition
    
    @property
    def threshold_value(self) -> Optional[float]:
        return self._threshold_value
    
    @property
    def measurement_timestamp(self) -> datetime:
        return self._measurement_timestamp
    
    @property
    def is_passing(self) -> bool:
        return self._is_passing
    
    def update_metric_value(self, value: float) -> None:
        """Update metric value."""
        if not (0 <= value <= 100):
            raise ValueError("Metric value must be between 0 and 100")
        
        self._metric_value = value
        self._measurement_timestamp = datetime.utcnow()
        self._is_passing = self._calculate_is_passing()
        self.mark_as_updated()
    
    def update_threshold(self, threshold: float) -> None:
        """Update threshold value."""
        if not (0 <= threshold <= 100):
            raise ValueError("Threshold value must be between 0 and 100")
        
        self._threshold_value = threshold
        self._is_passing = self._calculate_is_passing()
        self.mark_as_updated()
    
    def is_critical_failure(self) -> bool:
        """Check if metric represents a critical failure."""
        return not self._is_passing and self._metric_value < 50
    
    def get_quality_level(self) -> str:
        """Get quality level based on metric value."""
        if self._metric_value >= 90:
            return "excellent"
        elif self._metric_value >= 80:
            return "good"
        elif self._metric_value >= 70:
            return "fair"
        elif self._metric_value >= 50:
            return "poor"
        else:
            return "critical"

