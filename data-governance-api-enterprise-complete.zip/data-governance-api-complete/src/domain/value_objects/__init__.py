"""
Value Objects for Data Governance Domain.
Following Domain-Driven Design (DDD) principles.

Value objects are immutable and defined by their attributes rather than identity.

Author: Carlos Morais
"""

from abc import ABC
from dataclasses import dataclass
from enum import Enum
from typing import Any, Union
from uuid import UUID
import re


class BaseValueObject(ABC):
    """Base class for all value objects."""
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, self.__class__):
            return False
        return self.__dict__ == other.__dict__
    
    def __hash__(self) -> int:
        return hash(tuple(sorted(self.__dict__.items())))


@dataclass(frozen=True)
class DataObjectId(BaseValueObject):
    """Value object for Data Object ID."""
    value: UUID
    
    def __post_init__(self):
        if not isinstance(self.value, UUID):
            raise ValueError("DataObjectId must be a valid UUID")
    
    def __str__(self) -> str:
        return str(self.value)


@dataclass(frozen=True)
class DataObjectName(BaseValueObject):
    """Value object for Data Object Name."""
    value: str
    
    def __post_init__(self):
        if not self.value or not self.value.strip():
            raise ValueError("DataObjectName cannot be empty")
        
        # Validate name format (alphanumeric, underscores, hyphens)
        if not re.match(r'^[a-zA-Z0-9_-]+$', self.value.strip()):
            raise ValueError("DataObjectName must contain only alphanumeric characters, underscores, and hyphens")
        
        if len(self.value.strip()) > 255:
            raise ValueError("DataObjectName cannot exceed 255 characters")
        
        # Normalize to lowercase
        object.__setattr__(self, 'value', self.value.strip().lower())
    
    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class CatalogName(BaseValueObject):
    """Value object for Catalog Name."""
    value: str
    
    def __post_init__(self):
        if not self.value or not self.value.strip():
            raise ValueError("CatalogName cannot be empty")
        
        if not re.match(r'^[a-zA-Z0-9_-]+$', self.value.strip()):
            raise ValueError("CatalogName must contain only alphanumeric characters, underscores, and hyphens")
        
        if len(self.value.strip()) > 255:
            raise ValueError("CatalogName cannot exceed 255 characters")
        
        # Normalize to lowercase
        object.__setattr__(self, 'value', self.value.strip().lower())
    
    def __str__(self) -> str:
        return self.value


@dataclass(frozen=True)
class SchemaName(BaseValueObject):
    """Value object for Schema Name."""
    value: str
    
    def __post_init__(self):
        if not self.value or not self.value.strip():
            raise ValueError("SchemaName cannot be empty")
        
        if not re.match(r'^[a-zA-Z0-9_-]+$', self.value.strip()):
            raise ValueError("SchemaName must contain only alphanumeric characters, underscores, and hyphens")
        
        if len(self.value.strip()) > 255:
            raise ValueError("SchemaName cannot exceed 255 characters")
        
        # Normalize to lowercase
        object.__setattr__(self, 'value', self.value.strip().lower())
    
    def __str__(self) -> str:
        return self.value


class SecurityClassification(Enum):
    """Security classification levels."""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"
    
    def __str__(self) -> str:
        return self.value
    
    def get_level(self) -> int:
        """Get numeric level for comparison."""
        levels = {
            self.PUBLIC: 1,
            self.INTERNAL: 2,
            self.CONFIDENTIAL: 3,
            self.RESTRICTED: 4
        }
        return levels[self]
    
    def is_more_restrictive_than(self, other: 'SecurityClassification') -> bool:
        """Check if this classification is more restrictive than another."""
        return self.get_level() > other.get_level()
    
    def is_sensitive(self) -> bool:
        """Check if classification represents sensitive data."""
        return self in [self.CONFIDENTIAL, self.RESTRICTED]


class ObjectType(Enum):
    """Types of data objects."""
    TABLE = "table"
    VIEW = "view"
    MATERIALIZED_VIEW = "materialized_view"
    VOLUME = "volume"
    MODEL = "model"
    FUNCTION = "function"
    STREAMING_TABLE = "streaming_table"
    
    def __str__(self) -> str:
        return self.value
    
    def is_queryable(self) -> bool:
        """Check if object type is queryable."""
        return self in [self.TABLE, self.VIEW, self.MATERIALIZED_VIEW, self.STREAMING_TABLE]
    
    def supports_lineage(self) -> bool:
        """Check if object type supports lineage tracking."""
        return self in [self.TABLE, self.VIEW, self.MATERIALIZED_VIEW, self.STREAMING_TABLE, self.MODEL]


class DataFormat(Enum):
    """Data formats."""
    DELTA = "delta"
    PARQUET = "parquet"
    JSON = "json"
    CSV = "csv"
    AVRO = "avro"
    ORC = "orc"
    TEXT = "text"
    BINARY = "binary"
    
    def __str__(self) -> str:
        return self.value
    
    def is_columnar(self) -> bool:
        """Check if format is columnar."""
        return self in [self.DELTA, self.PARQUET, self.ORC]
    
    def supports_schema_evolution(self) -> bool:
        """Check if format supports schema evolution."""
        return self in [self.DELTA, self.PARQUET, self.AVRO]


@dataclass(frozen=True)
class QualityScore(BaseValueObject):
    """Value object for Quality Score."""
    value: float
    
    def __post_init__(self):
        if not isinstance(self.value, (int, float)):
            raise ValueError("QualityScore must be a number")
        
        if not (0 <= self.value <= 100):
            raise ValueError("QualityScore must be between 0 and 100")
        
        # Ensure it's a float
        object.__setattr__(self, 'value', float(self.value))
    
    def __str__(self) -> str:
        return f"{self.value:.2f}"
    
    def get_grade(self) -> str:
        """Get letter grade for quality score."""
        if self.value >= 90:
            return "A"
        elif self.value >= 80:
            return "B"
        elif self.value >= 70:
            return "C"
        elif self.value >= 60:
            return "D"
        else:
            return "F"
    
    def is_passing(self, threshold: float = 70.0) -> bool:
        """Check if score is passing based on threshold."""
        return self.value >= threshold
    
    def is_excellent(self) -> bool:
        """Check if score is excellent (>= 90)."""
        return self.value >= 90
    
    def is_poor(self) -> bool:
        """Check if score is poor (< 60)."""
        return self.value < 60


@dataclass(frozen=True)
class LineageConfidence(BaseValueObject):
    """Value object for Lineage Confidence Score."""
    value: float
    
    def __post_init__(self):
        if not isinstance(self.value, (int, float)):
            raise ValueError("LineageConfidence must be a number")
        
        if not (0 <= self.value <= 1):
            raise ValueError("LineageConfidence must be between 0 and 1")
        
        # Ensure it's a float
        object.__setattr__(self, 'value', float(self.value))
    
    def __str__(self) -> str:
        return f"{self.value:.3f}"
    
    def get_percentage(self) -> float:
        """Get confidence as percentage."""
        return self.value * 100
    
    def is_high_confidence(self) -> bool:
        """Check if confidence is high (>= 0.8)."""
        return self.value >= 0.8
    
    def is_medium_confidence(self) -> bool:
        """Check if confidence is medium (0.5 - 0.8)."""
        return 0.5 <= self.value < 0.8
    
    def is_low_confidence(self) -> bool:
        """Check if confidence is low (< 0.5)."""
        return self.value < 0.5
    
    def get_level(self) -> str:
        """Get confidence level as string."""
        if self.is_high_confidence():
            return "high"
        elif self.is_medium_confidence():
            return "medium"
        else:
            return "low"


@dataclass(frozen=True)
class PolicyPriority(BaseValueObject):
    """Value object for Policy Priority."""
    value: int
    
    def __post_init__(self):
        if not isinstance(self.value, int):
            raise ValueError("PolicyPriority must be an integer")
        
        if not (1 <= self.value <= 1000):
            raise ValueError("PolicyPriority must be between 1 and 1000")
    
    def __str__(self) -> str:
        return str(self.value)
    
    def is_critical(self) -> bool:
        """Check if priority is critical (1-10)."""
        return 1 <= self.value <= 10
    
    def is_high(self) -> bool:
        """Check if priority is high (11-50)."""
        return 11 <= self.value <= 50
    
    def is_medium(self) -> bool:
        """Check if priority is medium (51-100)."""
        return 51 <= self.value <= 100
    
    def is_low(self) -> bool:
        """Check if priority is low (101-1000)."""
        return 101 <= self.value <= 1000
    
    def get_level(self) -> str:
        """Get priority level as string."""
        if self.is_critical():
            return "critical"
        elif self.is_high():
            return "high"
        elif self.is_medium():
            return "medium"
        else:
            return "low"


class QualityDimension(Enum):
    """Data quality dimensions."""
    COMPLETENESS = "completeness"
    ACCURACY = "accuracy"
    CONSISTENCY = "consistency"
    TIMELINESS = "timeliness"
    VALIDITY = "validity"
    UNIQUENESS = "uniqueness"
    
    def __str__(self) -> str:
        return self.value
    
    def get_description(self) -> str:
        """Get description of the quality dimension."""
        descriptions = {
            self.COMPLETENESS: "Measures the proportion of non-null values",
            self.ACCURACY: "Measures how close values are to the true values",
            self.CONSISTENCY: "Measures uniformity of data across systems",
            self.TIMELINESS: "Measures how up-to-date the data is",
            self.VALIDITY: "Measures conformance to defined formats and rules",
            self.UNIQUENESS: "Measures the absence of duplicate records"
        }
        return descriptions[self]


class LineageType(Enum):
    """Types of data lineage relationships."""
    TABLE_TO_TABLE = "table_to_table"
    COLUMN_TO_COLUMN = "column_to_column"
    JOB_TO_TABLE = "job_to_table"
    MODEL_TO_TABLE = "model_to_table"
    VIEW_TO_TABLE = "view_to_table"
    FUNCTION_TO_TABLE = "function_to_table"
    
    def __str__(self) -> str:
        return self.value
    
    def is_column_level(self) -> bool:
        """Check if lineage is at column level."""
        return self == self.COLUMN_TO_COLUMN
    
    def is_table_level(self) -> bool:
        """Check if lineage is at table level."""
        return self in [self.TABLE_TO_TABLE, self.VIEW_TO_TABLE, self.JOB_TO_TABLE, self.MODEL_TO_TABLE]


class PolicyType(Enum):
    """Types of access policies."""
    ROW_FILTER = "row_filter"
    COLUMN_MASK = "column_mask"
    ACCESS_CONTROL = "access_control"
    DATA_MASKING = "data_masking"
    ENCRYPTION = "encryption"
    AUDIT = "audit"
    
    def __str__(self) -> str:
        return self.value
    
    def is_data_protection(self) -> bool:
        """Check if policy is for data protection."""
        return self in [self.COLUMN_MASK, self.DATA_MASKING, self.ENCRYPTION]
    
    def is_access_control(self) -> bool:
        """Check if policy is for access control."""
        return self in [self.ROW_FILTER, self.ACCESS_CONTROL]


@dataclass(frozen=True)
class EmailAddress(BaseValueObject):
    """Value object for Email Address."""
    value: str
    
    def __post_init__(self):
        if not self.value or not self.value.strip():
            raise ValueError("Email address cannot be empty")
        
        # Basic email validation
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_pattern, self.value.strip()):
            raise ValueError("Invalid email address format")
        
        # Normalize to lowercase
        object.__setattr__(self, 'value', self.value.strip().lower())
    
    def __str__(self) -> str:
        return self.value
    
    def get_domain(self) -> str:
        """Get email domain."""
        return self.value.split('@')[1]
    
    def get_username(self) -> str:
        """Get email username."""
        return self.value.split('@')[0]


@dataclass(frozen=True)
class DataSize(BaseValueObject):
    """Value object for Data Size in bytes."""
    bytes: int
    
    def __post_init__(self):
        if not isinstance(self.bytes, int):
            raise ValueError("Data size must be an integer")
        
        if self.bytes < 0:
            raise ValueError("Data size cannot be negative")
    
    def __str__(self) -> str:
        return self.to_human_readable()
    
    def to_kb(self) -> float:
        """Convert to kilobytes."""
        return self.bytes / 1024
    
    def to_mb(self) -> float:
        """Convert to megabytes."""
        return self.bytes / (1024 ** 2)
    
    def to_gb(self) -> float:
        """Convert to gigabytes."""
        return self.bytes / (1024 ** 3)
    
    def to_tb(self) -> float:
        """Convert to terabytes."""
        return self.bytes / (1024 ** 4)
    
    def to_human_readable(self) -> str:
        """Convert to human readable format."""
        if self.bytes < 1024:
            return f"{self.bytes} B"
        elif self.bytes < 1024 ** 2:
            return f"{self.to_kb():.2f} KB"
        elif self.bytes < 1024 ** 3:
            return f"{self.to_mb():.2f} MB"
        elif self.bytes < 1024 ** 4:
            return f"{self.to_gb():.2f} GB"
        else:
            return f"{self.to_tb():.2f} TB"
    
    def is_large(self, threshold_gb: float = 1.0) -> bool:
        """Check if data size is large based on threshold."""
        return self.to_gb() >= threshold_gb


@dataclass(frozen=True)
class RowCount(BaseValueObject):
    """Value object for Row Count."""
    value: int
    
    def __post_init__(self):
        if not isinstance(self.value, int):
            raise ValueError("Row count must be an integer")
        
        if self.value < 0:
            raise ValueError("Row count cannot be negative")
    
    def __str__(self) -> str:
        return self.to_human_readable()
    
    def to_human_readable(self) -> str:
        """Convert to human readable format."""
        if self.value < 1000:
            return str(self.value)
        elif self.value < 1000000:
            return f"{self.value / 1000:.1f}K"
        elif self.value < 1000000000:
            return f"{self.value / 1000000:.1f}M"
        else:
            return f"{self.value / 1000000000:.1f}B"
    
    def is_large_table(self, threshold: int = 1000000) -> bool:
        """Check if row count indicates a large table."""
        return self.value >= threshold
    
    def is_empty(self) -> bool:
        """Check if table is empty."""
        return self.value == 0


@dataclass(frozen=True)
class TagName(BaseValueObject):
    """Value object for Tag Name."""
    value: str
    
    def __post_init__(self):
        if not self.value or not self.value.strip():
            raise ValueError("Tag name cannot be empty")
        
        # Validate tag format (alphanumeric, underscores, hyphens)
        if not re.match(r'^[a-zA-Z0-9_-]+$', self.value.strip()):
            raise ValueError("Tag name must contain only alphanumeric characters, underscores, and hyphens")
        
        if len(self.value.strip()) > 50:
            raise ValueError("Tag name cannot exceed 50 characters")
        
        # Normalize to lowercase
        object.__setattr__(self, 'value', self.value.strip().lower())
    
    def __str__(self) -> str:
        return self.value
    
    def is_system_tag(self) -> bool:
        """Check if tag is a system tag."""
        system_prefixes = ['sys_', 'system_', 'auto_']
        return any(self.value.startswith(prefix) for prefix in system_prefixes)
    
    def is_sensitive_tag(self) -> bool:
        """Check if tag indicates sensitive data."""
        sensitive_tags = {'pii', 'phi', 'sensitive', 'confidential', 'personal', 'private'}
        return self.value in sensitive_tags


# Factory functions for common value objects
def create_data_object_id(value: Union[str, UUID]) -> DataObjectId:
    """Create DataObjectId from string or UUID."""
    if isinstance(value, str):
        return DataObjectId(UUID(value))
    return DataObjectId(value)


def create_quality_score(value: Union[int, float]) -> QualityScore:
    """Create QualityScore from numeric value."""
    return QualityScore(float(value))


def create_lineage_confidence(value: Union[int, float]) -> LineageConfidence:
    """Create LineageConfidence from numeric value."""
    return LineageConfidence(float(value))


def create_policy_priority(value: int) -> PolicyPriority:
    """Create PolicyPriority from integer value."""
    return PolicyPriority(value)


def create_data_size(bytes_value: int) -> DataSize:
    """Create DataSize from bytes value."""
    return DataSize(bytes_value)


def create_row_count(count: int) -> RowCount:
    """Create RowCount from integer value."""
    return RowCount(count)

