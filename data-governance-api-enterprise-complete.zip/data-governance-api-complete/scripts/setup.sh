#!/bin/bash

# Data Governance API - Setup and Deployment Script
# Author: Carlos Morais
# Version: 2.0.0

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="data-governance-api"
PYTHON_VERSION="3.9"
VENV_NAME="venv"

# Functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_requirements() {
    log_info "Checking system requirements..."
    
    # Check Python version
    if ! command -v python3 &> /dev/null; then
        log_error "Python 3 is not installed"
        exit 1
    fi
    
    PYTHON_VER=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
    if [[ $(echo "$PYTHON_VER >= $PYTHON_VERSION" | bc -l) -eq 0 ]]; then
        log_error "Python $PYTHON_VERSION or higher is required (found $PYTHON_VER)"
        exit 1
    fi
    
    # Check pip
    if ! command -v pip3 &> /dev/null; then
        log_error "pip3 is not installed"
        exit 1
    fi
    
    # Check PostgreSQL (optional)
    if command -v psql &> /dev/null; then
        log_success "PostgreSQL found"
    else
        log_warning "PostgreSQL not found - you'll need to install it separately"
    fi
    
    # Check Docker (optional)
    if command -v docker &> /dev/null; then
        log_success "Docker found"
    else
        log_warning "Docker not found - Docker deployment won't be available"
    fi
    
    log_success "System requirements check completed"
}

setup_environment() {
    log_info "Setting up Python virtual environment..."
    
    # Create virtual environment
    if [ ! -d "$VENV_NAME" ]; then
        python3 -m venv $VENV_NAME
        log_success "Virtual environment created"
    else
        log_info "Virtual environment already exists"
    fi
    
    # Activate virtual environment
    source $VENV_NAME/bin/activate
    
    # Upgrade pip
    pip install --upgrade pip
    
    # Install dependencies
    log_info "Installing Python dependencies..."
    pip install -r requirements.txt
    pip install -r requirements-dev.txt
    
    log_success "Python environment setup completed"
}

setup_database() {
    log_info "Setting up database..."
    
    # Check if .env file exists
    if [ ! -f ".env" ]; then
        if [ -f ".env.example" ]; then
            cp .env.example .env
            log_info "Created .env file from .env.example"
            log_warning "Please edit .env file with your database configuration"
        else
            log_error ".env.example file not found"
            exit 1
        fi
    fi
    
    # Source environment variables
    source .env
    
    # Run database migrations
    if command -v alembic &> /dev/null; then
        log_info "Running database migrations..."
        alembic upgrade head
        log_success "Database migrations completed"
    else
        log_warning "Alembic not found - skipping database migrations"
    fi
}

run_tests() {
    log_info "Running test suite..."
    
    # Activate virtual environment
    source $VENV_NAME/bin/activate
    
    # Run tests with coverage
    pytest --cov=src --cov-report=html --cov-report=term-missing
    
    # Check coverage threshold
    COVERAGE=$(pytest --cov=src --cov-report=term | grep TOTAL | awk '{print $4}' | sed 's/%//')
    if [[ $(echo "$COVERAGE >= 90" | bc -l) -eq 1 ]]; then
        log_success "Test coverage: $COVERAGE% (meets 90% threshold)"
    else
        log_warning "Test coverage: $COVERAGE% (below 90% threshold)"
    fi
    
    log_success "Test suite completed"
}

run_quality_checks() {
    log_info "Running code quality checks..."
    
    # Activate virtual environment
    source $VENV_NAME/bin/activate
    
    # Format code
    log_info "Formatting code with black..."
    black src tests --check --diff
    
    # Sort imports
    log_info "Checking import sorting with isort..."
    isort src tests --check-only --diff
    
    # Lint code
    log_info "Linting code with flake8..."
    flake8 src tests
    
    # Type checking
    log_info "Type checking with mypy..."
    mypy src
    
    # Security scanning
    log_info "Security scanning with bandit..."
    bandit -r src -f json -o bandit-report.json
    
    log_success "Code quality checks completed"
}

build_docker() {
    log_info "Building Docker image..."
    
    # Build production image
    docker build -f Dockerfile -t $PROJECT_NAME:latest .
    
    # Build development image
    docker build -f Dockerfile.dev -t $PROJECT_NAME:dev .
    
    log_success "Docker images built successfully"
}

deploy_local() {
    log_info "Deploying application locally..."
    
    # Activate virtual environment
    source $VENV_NAME/bin/activate
    
    # Start the application
    log_info "Starting Data Governance API..."
    uvicorn src.presentation.main:app --host 0.0.0.0 --port 8000 --reload
}

deploy_docker() {
    log_info "Deploying with Docker Compose..."
    
    # Check if docker-compose.yml exists
    if [ ! -f "docker-compose.yml" ]; then
        log_error "docker-compose.yml not found"
        exit 1
    fi
    
    # Start services
    docker-compose up --build -d
    
    # Wait for services to be ready
    log_info "Waiting for services to be ready..."
    sleep 10
    
    # Check health
    if curl -f http://localhost:8000/health > /dev/null 2>&1; then
        log_success "Application is running at http://localhost:8000"
        log_info "API Documentation: http://localhost:8000/docs"
        log_info "ReDoc Documentation: http://localhost:8000/redoc"
    else
        log_error "Application failed to start"
        docker-compose logs
        exit 1
    fi
}

deploy_production() {
    log_info "Deploying to production..."
    
    # Build production image
    build_docker
    
    # Tag for production
    docker tag $PROJECT_NAME:latest $PROJECT_NAME:prod-$(date +%Y%m%d-%H%M%S)
    
    # Deploy with production compose file
    if [ -f "docker-compose.prod.yml" ]; then
        docker-compose -f docker-compose.prod.yml up -d
        log_success "Production deployment completed"
    else
        log_error "docker-compose.prod.yml not found"
        exit 1
    fi
}

generate_docs() {
    log_info "Generating documentation..."
    
    # Activate virtual environment
    source $VENV_NAME/bin/activate
    
    # Generate API documentation
    python scripts/generate_openapi_spec.py
    
    # Generate code documentation
    if command -v sphinx-build &> /dev/null; then
        sphinx-build -b html docs docs/_build/html
        log_success "Documentation generated in docs/_build/html"
    else
        log_warning "Sphinx not found - skipping code documentation"
    fi
}

backup_database() {
    log_info "Creating database backup..."
    
    # Source environment variables
    source .env
    
    # Create backup directory
    mkdir -p backups
    
    # Create backup filename with timestamp
    BACKUP_FILE="backups/governance_backup_$(date +%Y%m%d_%H%M%S).sql"
    
    # Create backup
    pg_dump $DATABASE_URL > $BACKUP_FILE
    
    # Compress backup
    gzip $BACKUP_FILE
    
    log_success "Database backup created: $BACKUP_FILE.gz"
}

restore_database() {
    if [ -z "$1" ]; then
        log_error "Usage: $0 restore <backup_file>"
        exit 1
    fi
    
    BACKUP_FILE=$1
    
    if [ ! -f "$BACKUP_FILE" ]; then
        log_error "Backup file not found: $BACKUP_FILE"
        exit 1
    fi
    
    log_info "Restoring database from $BACKUP_FILE..."
    
    # Source environment variables
    source .env
    
    # Restore database
    if [[ $BACKUP_FILE == *.gz ]]; then
        gunzip -c $BACKUP_FILE | psql $DATABASE_URL
    else
        psql $DATABASE_URL < $BACKUP_FILE
    fi
    
    log_success "Database restored from $BACKUP_FILE"
}

show_help() {
    echo "Data Governance API - Setup and Deployment Script"
    echo ""
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  setup           - Complete setup (environment + database + tests)"
    echo "  env             - Setup Python environment only"
    echo "  db              - Setup database only"
    echo "  test            - Run test suite"
    echo "  quality         - Run code quality checks"
    echo "  docker          - Build Docker images"
    echo "  dev             - Start development server"
    echo "  deploy-docker   - Deploy with Docker Compose"
    echo "  deploy-prod     - Deploy to production"
    echo "  docs            - Generate documentation"
    echo "  backup          - Create database backup"
    echo "  restore <file>  - Restore database from backup"
    echo "  clean           - Clean up temporary files"
    echo "  help            - Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 setup                    # Complete setup"
    echo "  $0 dev                      # Start development server"
    echo "  $0 deploy-docker            # Deploy with Docker"
    echo "  $0 restore backup.sql.gz    # Restore database"
}

clean_up() {
    log_info "Cleaning up temporary files..."
    
    # Remove Python cache
    find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
    find . -type f -name "*.pyc" -delete 2>/dev/null || true
    
    # Remove test artifacts
    rm -rf .pytest_cache htmlcov .coverage
    
    # Remove build artifacts
    rm -rf build dist *.egg-info
    
    log_success "Cleanup completed"
}

# Main script logic
case "$1" in
    "setup")
        check_requirements
        setup_environment
        setup_database
        run_tests
        log_success "Setup completed successfully!"
        log_info "Run '$0 dev' to start the development server"
        ;;
    "env")
        check_requirements
        setup_environment
        ;;
    "db")
        setup_database
        ;;
    "test")
        run_tests
        ;;
    "quality")
        run_quality_checks
        ;;
    "docker")
        build_docker
        ;;
    "dev")
        deploy_local
        ;;
    "deploy-docker")
        deploy_docker
        ;;
    "deploy-prod")
        deploy_production
        ;;
    "docs")
        generate_docs
        ;;
    "backup")
        backup_database
        ;;
    "restore")
        restore_database "$2"
        ;;
    "clean")
        clean_up
        ;;
    "help"|"--help"|"-h"|"")
        show_help
        ;;
    *)
        log_error "Unknown command: $1"
        show_help
        exit 1
        ;;
esac

