"""
COBOL AI Engine v2.2.0 - Prompt Manager
Gerenciador de prompts customizáveis com documentação automática.
"""

import logging
import yaml
import os
from typing import Dict, Any, List, Optional
from datetime import datetime


class PromptManager:
    """
    Gerenciador de prompts customizáveis.
    
    Funcionalidades:
    - Carregamento de prompts de arquivo YAML
    - Customização de perguntas sem alterar código
    - Geração automática de prompts por fase
    - Documentação automática de prompts utilizados
    - Suporte a contexto específico por tipo de programa
    """
    
    def __init__(self, prompts_config_path: str = "config/prompts.yaml"):
        """
        Inicializa o gerenciador de prompts.
        
        Args:
            prompts_config_path: Caminho para arquivo de configuração de prompts
        """
        self.logger = logging.getLogger(__name__)
        self.prompts_config_path = prompts_config_path
        self.config = self._load_prompts_config()
        
        # Histórico de prompts utilizados (para documentação)
        self.prompt_history = []
        
        self.logger.info("Prompt Manager inicializado com configuração customizável")
    
    def _load_prompts_config(self) -> Dict[str, Any]:
        """Carrega configuração de prompts do arquivo YAML."""
        try:
            if os.path.exists(self.prompts_config_path):
                with open(self.prompts_config_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
                self.logger.info(f"Configuração de prompts carregada: {self.prompts_config_path}")
                return config
            else:
                self.logger.warning(f"Arquivo de prompts não encontrado: {self.prompts_config_path}")
                return self._get_default_config()
        except Exception as e:
            self.logger.error(f"Erro ao carregar configuração de prompts: {str(e)}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão de prompts."""
        return {
            "prompts": {
                "include_in_documentation": True,
                "base_prompt": "Analise o seguinte programa COBOL:\n\n{cobol_code}\n\n{analysis_questions}",
                "analysis_questions": {
                    "functional": {
                        "question": "O que este programa faz funcionalmente?",
                        "priority": 1,
                        "required": True
                    }
                }
            }
        }
    
    def generate_base_prompt(self, program_name: str, cobol_code: str, 
                           context: Optional[Dict[str, Any]] = None) -> str:
        """
        Gera prompt base customizável.
        
        Args:
            program_name: Nome do programa COBOL
            cobol_code: Código fonte do programa
            context: Contexto adicional
            
        Returns:
            Prompt base formatado
        """
        # Obter configuração de prompts
        prompts_config = self.config.get("prompts", {})
        
        # Gerar lista de perguntas
        analysis_questions = self._generate_analysis_questions(program_name)
        
        # Obter template base
        base_template = prompts_config.get("base_prompt", "")
        
        # Calcular estatísticas do código
        code_size = len(cobol_code)
        line_count = len(cobol_code.split('\n'))
        
        # Formatear prompt base
        base_prompt = base_template.format(
            cobol_code=cobol_code,
            analysis_questions=analysis_questions,
            program_name=program_name,
            code_size=code_size,
            line_count=line_count
        )
        
        # Aplicar contexto específico se disponível
        if context:
            base_prompt = self._apply_contextual_prompt(base_prompt, program_name, context)
        
        # Registrar prompt para documentação
        self._register_prompt_usage("base", base_prompt, {
            "program_name": program_name,
            "code_size": code_size,
            "line_count": line_count,
            "timestamp": datetime.now().isoformat()
        })
        
        return base_prompt
    
    def _generate_analysis_questions(self, program_name: str) -> str:
        """Gera lista de perguntas de análise baseada na configuração."""
        questions_config = self.config.get("prompts", {}).get("analysis_questions", {})
        user_questions = self.config.get("prompts", {}).get("customization", {}).get("user_questions", {})
        
        # Combinar perguntas padrão e customizadas
        all_questions = {**questions_config, **user_questions}
        
        # Ordenar por prioridade
        sorted_questions = sorted(
            all_questions.items(),
            key=lambda x: x[1].get("priority", 999)
        )
        
        # Gerar lista numerada
        questions_list = []
        for i, (key, config) in enumerate(sorted_questions, 1):
            question = config.get("question", "")
            if config.get("required", True) or self._should_include_question(key, program_name):
                questions_list.append(f"{i}. {question}")
        
        return "\n".join(questions_list)
    
    def _should_include_question(self, question_key: str, program_name: str) -> bool:
        """Determina se uma pergunta opcional deve ser incluída."""
        # Lógica para incluir perguntas baseada no tipo de programa
        if question_key == "relationships" and any(prefix in program_name for prefix in ["LHAN", "LHBR"]):
            return True
        if question_key == "code_examples":
            return True
        return False
    
    def _apply_contextual_prompt(self, base_prompt: str, program_name: str, 
                                context: Dict[str, Any]) -> str:
        """Aplica contexto específico ao prompt."""
        contextual_config = self.config.get("prompts", {}).get("contextual_prompts", {})
        
        # Determinar tipo de programa
        program_type = self._determine_program_type(program_name)
        context_config = contextual_config.get(program_type, contextual_config.get("default", {}))
        
        # Adicionar contexto específico
        if context_config:
            context_text = context_config.get("context", "")
            additional_questions = context_config.get("additional_questions", [])
            
            if context_text:
                base_prompt += f"\n\nContexto: Este é um {context_text}."
            
            if additional_questions:
                base_prompt += "\n\nPerguntas adicionais específicas:"
                for i, question in enumerate(additional_questions, 1):
                    base_prompt += f"\n{len(base_prompt.split('.'))}. {question}"
        
        return base_prompt
    
    def _determine_program_type(self, program_name: str) -> str:
        """Determina o tipo de programa baseado no nome."""
        if program_name.startswith("LHAN"):
            return "LHAN_programs"
        elif program_name.startswith("LHBR"):
            return "LHBR_programs"
        elif program_name.startswith("MZAN"):
            return "MZAN_programs"
        else:
            return "default"
    
    def generate_phase_prompt(self, base_prompt: str, phase_name: str, 
                            context: Optional[Dict[str, Any]] = None) -> str:
        """
        Gera prompt específico para uma fase.
        
        Args:
            base_prompt: Prompt base
            phase_name: Nome da fase
            context: Contexto adicional
            
        Returns:
            Prompt específico da fase
        """
        phase_config = self.config.get("prompts", {}).get("phase_prompts", {}).get(phase_name, {})
        
        if not phase_config:
            return base_prompt
        
        # Obter foco da fase
        focus = phase_config.get("focus", "")
        additional_context = phase_config.get("additional_context", "")
        
        # Substituir variáveis no foco
        if "{functional_question}" in focus:
            functional_question = self._get_functional_question()
            focus = focus.replace("{functional_question}", functional_question)
        
        # Construir prompt da fase
        phase_prompt = f"{base_prompt}\n\nFoque especificamente em: {focus}"
        
        if additional_context:
            phase_prompt += f"\n\n{additional_context}"
        
        # Registrar prompt da fase para documentação
        self._register_prompt_usage("phase", phase_prompt, {
            "phase_name": phase_name,
            "focus": focus,
            "timestamp": datetime.now().isoformat()
        })
        
        return phase_prompt
    
    def _get_functional_question(self) -> str:
        """Obtém a pergunta funcional configurada."""
        questions = self.config.get("prompts", {}).get("analysis_questions", {})
        functional_config = questions.get("functional", {})
        return functional_config.get("question", "O que este programa faz funcionalmente?")
    
    def _register_prompt_usage(self, prompt_type: str, prompt_text: str, 
                             metadata: Dict[str, Any]) -> None:
        """Registra uso de prompt para documentação."""
        if not self.config.get("prompts", {}).get("include_in_documentation", True):
            return
        
        prompt_record = {
            "type": prompt_type,
            "text": prompt_text,
            "metadata": metadata,
            "tokens_estimated": self._estimate_tokens(prompt_text),
            "timestamp": datetime.now().isoformat()
        }
        
        self.prompt_history.append(prompt_record)
    
    def _estimate_tokens(self, text: str) -> int:
        """Estima número de tokens no texto."""
        # Estimativa simples: ~1.3 tokens por palavra
        return int(len(text.split()) * 1.3)
    
    def get_prompt_documentation(self) -> str:
        """
        Gera documentação dos prompts utilizados.
        
        Returns:
            Documentação em formato Markdown
        """
        if not self.config.get("prompts", {}).get("include_in_documentation", True):
            return ""
        
        if not self.prompt_history:
            return ""
        
        doc_config = self.config.get("documentation", {})
        sections = doc_config.get("sections", {})
        
        documentation = []
        
        # Título da seção
        section_title = doc_config.get("placement", {}).get("section_title", "Transparência da Análise")
        subsection_title = doc_config.get("placement", {}).get("subsection_title", "Prompts Utilizados")
        
        documentation.append(f"## {section_title}")
        documentation.append(f"### {subsection_title}")
        documentation.append("")
        
        # Prompt original
        if sections.get("original_prompt", True):
            base_prompts = [p for p in self.prompt_history if p["type"] == "base"]
            if base_prompts:
                documentation.append("#### Prompt Principal")
                documentation.append("```")
                documentation.append(base_prompts[0]["text"])
                documentation.append("```")
                documentation.append("")
        
        # Prompts por fase
        if sections.get("phase_prompts", True):
            phase_prompts = [p for p in self.prompt_history if p["type"] == "phase"]
            if phase_prompts:
                documentation.append("#### Prompts por Fase")
                for i, prompt in enumerate(phase_prompts, 1):
                    phase_name = prompt["metadata"].get("phase_name", f"Fase {i}")
                    focus = prompt["metadata"].get("focus", "")
                    documentation.append(f"**{phase_name}** - Foco: {focus}")
                    documentation.append("```")
                    documentation.append(prompt["text"])
                    documentation.append("```")
                    documentation.append("")
        
        # Perguntas feitas
        if sections.get("questions_asked", True):
            documentation.append("#### Perguntas Realizadas")
            questions = self._extract_questions_from_prompts()
            for i, question in enumerate(questions, 1):
                documentation.append(f"{i}. {question}")
            documentation.append("")
        
        # Estatísticas dos prompts
        if sections.get("prompt_statistics", True):
            documentation.append("#### Estatísticas dos Prompts")
            total_tokens = sum(p["tokens_estimated"] for p in self.prompt_history)
            documentation.append(f"- **Total de prompts**: {len(self.prompt_history)}")
            documentation.append(f"- **Tokens estimados**: {total_tokens}")
            documentation.append(f"- **Configuração**: {self.prompts_config_path}")
            documentation.append("")
        
        # Customizações aplicadas
        if sections.get("customizations_applied", True):
            customizations = self._get_applied_customizations()
            if customizations:
                documentation.append("#### Customizações Aplicadas")
                for customization in customizations:
                    documentation.append(f"- {customization}")
                documentation.append("")
        
        return "\n".join(documentation)
    
    def _extract_questions_from_prompts(self) -> List[str]:
        """Extrai perguntas dos prompts utilizados."""
        questions = []
        questions_config = self.config.get("prompts", {}).get("analysis_questions", {})
        
        for key, config in questions_config.items():
            question = config.get("question", "")
            if question:
                questions.append(question)
        
        return questions
    
    def _get_applied_customizations(self) -> List[str]:
        """Obtém lista de customizações aplicadas."""
        customizations = []
        
        # Verificar perguntas customizadas
        user_questions = self.config.get("prompts", {}).get("customization", {}).get("user_questions", {})
        if user_questions:
            customizations.append(f"Perguntas customizadas: {len(user_questions)}")
        
        # Verificar substituições de texto
        replacements = self.config.get("prompts", {}).get("customization", {}).get("text_replacements", {})
        if replacements:
            customizations.append(f"Substituições de texto: {len(replacements)}")
        
        # Verificar configurações específicas de ambiente
        env_config = self.config.get("prompts", {}).get("customization", {}).get("environment_specific", {})
        if env_config:
            customizations.append(f"Configurações por ambiente: {list(env_config.keys())}")
        
        return customizations
    
    def clear_prompt_history(self) -> None:
        """Limpa histórico de prompts."""
        self.prompt_history = []
    
    def get_functional_question(self) -> str:
        """Retorna a pergunta funcional configurada."""
        return self._get_functional_question()
    
    def update_functional_question(self, new_question: str) -> None:
        """
        Atualiza a pergunta funcional dinamicamente.
        
        Args:
            new_question: Nova pergunta funcional
        """
        if "prompts" not in self.config:
            self.config["prompts"] = {}
        if "analysis_questions" not in self.config["prompts"]:
            self.config["prompts"]["analysis_questions"] = {}
        if "functional" not in self.config["prompts"]["analysis_questions"]:
            self.config["prompts"]["analysis_questions"]["functional"] = {}
        
        self.config["prompts"]["analysis_questions"]["functional"]["question"] = new_question
        
        self.logger.info(f"Pergunta funcional atualizada: {new_question}")
    
    def save_config(self) -> None:
        """Salva configuração atual no arquivo."""
        try:
            with open(self.prompts_config_path, 'w', encoding='utf-8') as f:
                yaml.dump(self.config, f, default_flow_style=False, allow_unicode=True)
            self.logger.info(f"Configuração de prompts salva: {self.prompts_config_path}")
        except Exception as e:
            self.logger.error(f"Erro ao salvar configuração de prompts: {str(e)}")

