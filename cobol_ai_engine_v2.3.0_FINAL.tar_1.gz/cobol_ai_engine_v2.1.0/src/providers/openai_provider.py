"""
COBOL AI Engine v2.1.0 - OpenAI Provider
Implementação completa com autenticação e controle de tokens.

Métodos de Autenticação Suportados:
1. API Key simples: OPENAI_API_KEY
2. API Key + Organization: OPENAI_API_KEY + OPENAI_ORG_ID
3. API Key + Project: OPENAI_API_KEY + OPENAI_PROJECT_ID
4. Azure OpenAI: AZURE_OPENAI_KEY + AZURE_OPENAI_ENDPOINT
"""

import logging
import time
import json
from typing import Dict, Any, Optional, List
from datetime import datetime

try:
    import openai
    from openai import OpenAI, AzureOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

from .base_provider import BaseAIProvider, AIRequest, AIResponse


class OpenAIProvider(BaseAIProvider):
    """
    Provedor OpenAI com autenticação completa e controle de tokens.
    
    Funcionalidades implementadas:
    - Múltiplos métodos de autenticação
    - Rate limiting inteligente
    - Controle de tokens por requisição
    - Faseamento automático para grandes análises
    - Suporte a Azure OpenAI
    - Tratamento robusto de erros
    """
    
    def __init__(self, name: str, config: Dict[str, Any]):
        """
        Inicializa o provedor OpenAI.
        
        Configurações suportadas:
        - api_key: Chave da API OpenAI
        - organization: ID da organização (opcional)
        - project: ID do projeto (opcional)
        - base_url: URL base customizada (opcional)
        - azure_endpoint: Endpoint Azure OpenAI (opcional)
        - azure_api_version: Versão da API Azure (opcional)
        - model: Modelo a ser usado (default: gpt-4)
        - max_tokens: Tokens máximos por requisição
        - rate_limit_delay: Delay entre requisições (segundos)
        """
        super().__init__(name, config)
        
        # Verificar dependências
        if not OPENAI_AVAILABLE:
            self.logger.error("Biblioteca 'openai' não encontrada. Execute: pip install openai>=1.3.0")
            self.enabled = False
            return
        
        # Configurações de autenticação
        self.api_key = config.get('api_key', '')
        self.organization = config.get('organization', '')
        self.project = config.get('project', '')
        self.base_url = config.get('base_url', '')
        
        # Configurações Azure OpenAI
        self.azure_endpoint = config.get('azure_endpoint', '')
        self.azure_api_version = config.get('azure_api_version', '2024-02-15-preview')
        self.is_azure = bool(self.azure_endpoint)
        
        # Configurações do modelo
        self.model = config.get('model', 'gpt-4' if not self.is_azure else 'gpt-4')
        self.rate_limit_delay = config.get('rate_limit_delay', 1.0)
        
        # Configurações de faseamento
        self.enable_phasing = config.get('enable_phasing', True)
        self.max_tokens_per_phase = config.get('max_tokens_per_phase', 4000)
        self.phase_overlap_tokens = config.get('phase_overlap_tokens', 200)
        
        # Cliente OpenAI
        self.client = None
        
        # Inicializar cliente
        self._initialize_client()
        
        self.logger.info(f"OpenAI Provider inicializado - Modelo: {self.model}, Azure: {self.is_azure}")
    
    def _initialize_client(self):
        """Inicializa cliente OpenAI com autenticação apropriada."""
        try:
            if self.is_azure:
                # Azure OpenAI
                if not self.api_key or not self.azure_endpoint:
                    self.logger.error("Azure OpenAI requer api_key e azure_endpoint")
                    self.enabled = False
                    return
                
                self.client = AzureOpenAI(
                    api_key=self.api_key,
                    azure_endpoint=self.azure_endpoint,
                    api_version=self.azure_api_version
                )
                self.logger.info("Cliente Azure OpenAI inicializado")
                
            else:
                # OpenAI padrão
                if not self.api_key:
                    self.logger.error("OpenAI requer api_key")
                    self.enabled = False
                    return
                
                client_kwargs = {
                    'api_key': self.api_key
                }
                
                if self.organization:
                    client_kwargs['organization'] = self.organization
                
                if self.project:
                    client_kwargs['project'] = self.project
                
                if self.base_url:
                    client_kwargs['base_url'] = self.base_url
                
                self.client = OpenAI(**client_kwargs)
                self.logger.info("Cliente OpenAI inicializado")
                
        except Exception as e:
            self.logger.error(f"Erro ao inicializar cliente OpenAI: {str(e)}")
            self.enabled = False
    
    def is_available(self) -> bool:
        """Verifica se OpenAI está disponível."""
        if not self.enabled or not OPENAI_AVAILABLE or not self.client:
            return False
        
        try:
            # Teste simples de conectividade
            models = self.client.models.list()
            return True
        except Exception as e:
            self.logger.debug(f"OpenAI não disponível: {str(e)}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando OpenAI com faseamento automático se necessário.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        if not self._validate_request(request):
            response = self._create_error_response("Requisição inválida")
            self._update_statistics(response)
            return response
        
        try:
            # Verificar se precisa de faseamento
            if self.enable_phasing and self._needs_phasing(request):
                return self._analyze_with_phasing(request)
            else:
                return self._analyze_single_request(request)
                
        except Exception as e:
            self.logger.error(f"Erro na análise OpenAI: {str(e)}")
            response = self._create_error_response(f"Erro OpenAI: {str(e)}")
            self._update_statistics(response)
            return response
    
    def _needs_phasing(self, request: AIRequest) -> bool:
        """
        Determina se a requisição precisa de faseamento.
        
        Args:
            request: Requisição a ser analisada
            
        Returns:
            True se precisa de faseamento
        """
        # Estimativa simples: ~4 caracteres por token
        estimated_tokens = len(request.prompt) // 4
        
        # Se estimativa + max_tokens excede limite, usar faseamento
        total_estimated = estimated_tokens + request.max_tokens
        
        return total_estimated > self.max_tokens_per_phase
    
    def _analyze_with_phasing(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise com faseamento automático.
        
        Args:
            request: Requisição original
            
        Returns:
            Resposta consolidada de todas as fases
        """
        self.logger.info("Iniciando análise OpenAI com faseamento automático")
        
        # Dividir prompt em fases
        phases = self._create_phases(request)
        
        all_responses = []
        total_tokens = 0
        
        for i, phase_request in enumerate(phases):
            self.logger.debug(f"Executando fase {i+1}/{len(phases)}")
            
            # Aplicar rate limiting
            if i > 0:
                time.sleep(self.rate_limit_delay)
            
            # Executar fase
            phase_response = self._analyze_single_request(phase_request)
            
            if phase_response.success:
                all_responses.append(phase_response.content)
                total_tokens += phase_response.tokens_used
            else:
                # Se uma fase falha, retornar erro
                return phase_response
        
        # Consolidar respostas
        consolidated_content = self._consolidate_phase_responses(all_responses)
        
        # Criar resposta final
        final_response = AIResponse(
            content=consolidated_content,
            tokens_used=total_tokens,
            provider_name=self.name,
            model_name=self.model,
            success=True
        )
        
        self._update_statistics(final_response)
        return final_response
    
    def _create_phases(self, request: AIRequest) -> List[AIRequest]:
        """
        Cria fases para análise dividida.
        
        Args:
            request: Requisição original
            
        Returns:
            Lista de requisições por fase
        """
        phases = []
        
        # Estratégia: dividir por aspectos da análise COBOL
        cobol_aspects = [
            {
                "name": "Informações Básicas",
                "prompt_suffix": "\n\nFoque apenas em: nome do programa, estrutura geral, divisões principais e propósito básico."
            },
            {
                "name": "Análise Funcional",
                "prompt_suffix": "\n\nFoque apenas em: O que este programa faz funcionalmente? Qual o processo de negócio implementado?"
            },
            {
                "name": "Análise Técnica",
                "prompt_suffix": "\n\nFoque apenas em: estruturas de dados, lógica de processamento, algoritmos utilizados."
            },
            {
                "name": "Regras de Negócio",
                "prompt_suffix": "\n\nFoque apenas em: regras de negócio codificadas, validações, cálculos específicos."
            }
        ]
        
        base_prompt = request.prompt
        
        for aspect in cobol_aspects:
            phase_prompt = base_prompt + aspect["prompt_suffix"]
            
            phase_request = AIRequest(
                prompt=phase_prompt,
                context=request.context.copy() if request.context else {},
                max_tokens=min(request.max_tokens // len(cobol_aspects), self.max_tokens_per_phase),
                temperature=request.temperature
            )
            
            # Adicionar contexto da fase
            if phase_request.context is None:
                phase_request.context = {}
            phase_request.context['phase_name'] = aspect["name"]
            
            phases.append(phase_request)
        
        return phases
    
    def _consolidate_phase_responses(self, responses: List[str]) -> str:
        """
        Consolida respostas de múltiplas fases.
        
        Args:
            responses: Lista de respostas das fases
            
        Returns:
            Conteúdo consolidado
        """
        consolidated = "# Análise COBOL Completa (OpenAI Faseado)\n\n"
        
        phase_names = ["Informações Básicas", "Análise Funcional", "Análise Técnica", "Regras de Negócio"]
        
        for i, (phase_name, response) in enumerate(zip(phase_names, responses)):
            consolidated += f"## {phase_name}\n\n"
            consolidated += response.strip() + "\n\n"
        
        consolidated += "---\n"
        consolidated += f"*Análise gerada com faseamento automático OpenAI - {len(responses)} fases*\n"
        
        return consolidated
    
    def _analyze_single_request(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise em requisição única.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        try:
            # Aplicar rate limiting
            time.sleep(self.rate_limit_delay)
            
            # Preparar mensagens
            messages = [
                {
                    "role": "system",
                    "content": "Você é um especialista em análise de programas COBOL com foco em sistemas bancários e mainframe."
                },
                {
                    "role": "user",
                    "content": request.prompt
                }
            ]
            
            # Fazer requisição
            start_time = time.time()
            
            completion = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                timeout=self.timeout
            )
            
            end_time = time.time()
            
            # Processar resposta
            if completion.choices and completion.choices[0].message:
                content = completion.choices[0].message.content
                
                # Extrair informações de uso
                usage = completion.usage
                total_tokens = usage.total_tokens if usage else 0
                input_tokens = usage.prompt_tokens if usage else 0
                output_tokens = usage.completion_tokens if usage else 0
                
                return AIResponse(
                    content=content,
                    tokens_used=total_tokens,
                    provider_name=self.name,
                    model_name=self.model,
                    success=True,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens
                )
            else:
                return self._create_error_response("Resposta OpenAI vazia")
                
        except openai.RateLimitError as e:
            self.logger.warning(f"Rate limit OpenAI atingido: {str(e)}")
            return self._create_error_response(f"Rate limit: {str(e)}")
        
        except openai.AuthenticationError as e:
            self.logger.error(f"Erro de autenticação OpenAI: {str(e)}")
            return self._create_error_response(f"Autenticação: {str(e)}")
        
        except openai.APIError as e:
            self.logger.error(f"Erro da API OpenAI: {str(e)}")
            return self._create_error_response(f"API Error: {str(e)}")
        
        except Exception as e:
            self.logger.error(f"Erro inesperado OpenAI: {str(e)}")
            return self._create_error_response(f"Erro: {str(e)}")
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações específicas do provedor OpenAI."""
        base_info = self.get_statistics()
        
        openai_info = {
            "model": self.model,
            "is_azure": self.is_azure,
            "azure_endpoint": self.azure_endpoint if self.is_azure else None,
            "organization": self.organization,
            "project": self.project,
            "base_url": self.base_url,
            "rate_limit_delay": self.rate_limit_delay,
            "enable_phasing": self.enable_phasing,
            "max_tokens_per_phase": self.max_tokens_per_phase,
            "client_initialized": bool(self.client)
        }
        
        base_info.update(openai_info)
        return base_info

