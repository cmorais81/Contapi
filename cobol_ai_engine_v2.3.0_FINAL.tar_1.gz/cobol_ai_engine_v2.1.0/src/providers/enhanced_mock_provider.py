"""
COBOL AI Engine v2.1.0 - Enhanced Mock Provider
Provider mock inteligente com análises específicas e trechos de código.

Funcionalidades:
- Sempre disponível (fallback garantido)
- Análise específica do código COBOL real
- Extração de trechos relevantes
- Respostas contextuais baseadas no conteúdo
- Faseamento automático para grandes análises
"""

import logging
import time
import random
import re
from typing import Dict, Any, Optional, List
from datetime import datetime

from .base_provider import BaseAIProvider, AIRequest, AIResponse


class EnhancedMockProvider(BaseAIProvider):
    """
    Provider mock inteligente com análises específicas do código COBOL.
    
    Funcionalidades implementadas:
    - Sempre disponível (100% uptime)
    - Análise específica do código real
    - Extração de trechos relevantes
    - Identificação de estruturas COBOL
    - Resposta detalhada para "O que faz funcionalmente?"
    """
    
    def __init__(self, name: str, config: Dict[str, Any]):
        """
        Inicializa o Enhanced Mock Provider.
        
        Args:
            name: Nome do provedor
            config: Configuração do provedor
        """
        super().__init__(name, config)
        
        # Configurações específicas do mock
        self.response_delay = config.get('response_delay', 0.1)
        self.enable_phasing = config.get('enable_phasing', True)
        self.max_tokens_per_phase = config.get('max_tokens_per_phase', 2000)
        self.simulate_realistic_tokens = config.get('simulate_realistic_tokens', True)
        
        # Padrões para análise de código COBOL
        self._setup_cobol_patterns()
        
        # Templates de resposta para diferentes tipos de análise
        self._setup_response_templates()
        
        # Sempre habilitado
        self.enabled = True
        
        self.logger.info("Enhanced Mock Provider inicializado - Análise específica de código")
    
    def _setup_cobol_patterns(self):
        """Configura padrões para análise de código COBOL."""
        
        self.cobol_patterns = {
            'program_id': re.compile(r'PROGRAM-ID\.\s*([A-Z0-9\-]+)', re.IGNORECASE),
            'divisions': re.compile(r'([A-Z]+)\s+DIVISION\.', re.IGNORECASE),
            'sections': re.compile(r'([A-Z0-9\-]+)\s+SECTION\.', re.IGNORECASE),
            'file_control': re.compile(r'SELECT\s+([A-Z0-9\-]+)\s+ASSIGN\s+TO\s+([^\.\n]+)', re.IGNORECASE),
            'working_storage': re.compile(r'(\d+)\s+([A-Z0-9\-]+).*?PIC\s+([X9\(\)V\-]+)', re.IGNORECASE),
            'procedure_calls': re.compile(r'PERFORM\s+([A-Z0-9\-]+)', re.IGNORECASE),
            'file_operations': re.compile(r'(OPEN|CLOSE|READ|WRITE)\s+([A-Z0-9\-]+)', re.IGNORECASE),
            'move_statements': re.compile(r'MOVE\s+([^\s]+)\s+TO\s+([A-Z0-9\-]+)', re.IGNORECASE),
            'if_conditions': re.compile(r'IF\s+([^THEN]+)\s+THEN', re.IGNORECASE),
            'copy_statements': re.compile(r'COPY\s+([A-Z0-9\-]+)', re.IGNORECASE)
        }
    
    def _setup_response_templates(self):
        """Configura templates de resposta contextuais."""
        
        self.response_templates = {
            'basic_info': {
                'keywords': ['informações básicas', 'estrutura geral', 'basic info', 'overview'],
                'template': """## Informações Básicas do Programa

### Identificação
- **Nome do Programa**: {program_name}
- **Linhas de Código**: {line_count}
- **Tamanho**: {size} caracteres

### Estrutura COBOL Identificada
{divisions_found}

### Arquivos Utilizados
{files_found}

### Copybooks Incluídos
{copybooks_found}

### Características Gerais
- Programa COBOL padrão seguindo estrutura mainframe
- Implementa processamento de dados corporativo
- Utiliza {file_count} arquivo(s) de dados
- Contém {section_count} seção(ões) de processamento"""
            },
            
            'functional_analysis': {
                'keywords': ['funcionalmente', 'funcional', 'o que faz', 'propósito', 'objetivo'],
                'template': """## O que este programa faz funcionalmente?

### Análise Funcional Detalhada do Programa {program_name}

#### Objetivo Principal
{functional_purpose}

#### Processo de Negócio Implementado

**1. Inicialização e Preparação**
{initialization_logic}

**2. Processamento Principal**
{main_processing}

**3. Validações e Controles**
{validation_logic}

**4. Finalização e Saídas**
{finalization_logic}

#### Regras de Negócio Identificadas
{business_rules}

#### Fluxo de Dados
{data_flow}

#### Impacto no Sistema Corporativo
Este programa é responsável por {system_impact}, sendo essencial para:
- Manutenção da integridade dos dados processados
- Execução de regras de negócio específicas
- Geração de informações para sistemas downstream
- Cumprimento de requisitos regulatórios e de auditoria"""
            },
            
            'technical_analysis': {
                'keywords': ['técnica', 'technical', 'estrutura', 'algoritmo', 'implementação'],
                'template': """## Análise Técnica Detalhada

### Estrutura do Programa {program_name}

#### Divisões COBOL Implementadas
{technical_divisions}

#### Seções de Processamento
{technical_sections}

#### Estruturas de Dados Principais
{data_structures}

#### Trechos de Código Relevantes

**Controle de Arquivos:**
```cobol
{file_control_code}
```

**Processamento Principal:**
```cobol
{main_procedure_code}
```

**Validações Implementadas:**
```cobol
{validation_code}
```

#### Algoritmos e Lógica de Processamento
{processing_algorithms}

#### Padrões de Design Utilizados
- Modularização através de seções PERFORM
- Estruturas de controle hierárquicas
- Tratamento estruturado de erros e exceções
- Organização lógica das operações de I/O

#### Considerações de Performance
{performance_considerations}"""
            },
            
            'business_rules': {
                'keywords': ['regras', 'negócio', 'business', 'validação', 'cálculo'],
                'template': """## Regras de Negócio e Validações

### Regras Implementadas no Programa {program_name}

#### Validações de Entrada
{input_validations}

#### Regras de Processamento
{processing_rules}

#### Controles de Qualidade
{quality_controls}

#### Cálculos e Transformações
{calculations}

#### Trechos de Código das Regras Principais
{business_rule_code}

#### Conformidade e Auditoria
{compliance_rules}"""
            }
        }
    
    def is_available(self) -> bool:
        """Enhanced Mock sempre está disponível."""
        return True
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise mock específica com base no código COBOL real.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        if not self._validate_request(request):
            response = self._create_error_response("Requisição inválida")
            self._update_statistics(response)
            return response
        
        try:
            # Verificar se precisa de faseamento
            if self.enable_phasing and self._needs_phasing(request):
                return self._analyze_with_phasing(request)
            else:
                return self._analyze_single_request(request)
                
        except Exception as e:
            self.logger.error(f"Erro na análise Enhanced Mock: {str(e)}")
            response = self._create_error_response(f"Erro Mock: {str(e)}")
            self._update_statistics(response)
            return response
    
    def _needs_phasing(self, request: AIRequest) -> bool:
        """Determina se a requisição precisa de faseamento."""
        # Para mock, usar faseamento se tokens solicitados > limite por fase
        return request.max_tokens > self.max_tokens_per_phase
    
    def _analyze_with_phasing(self, request: AIRequest) -> AIResponse:
        """Realiza análise com faseamento automático."""
        self.logger.info("Iniciando análise Enhanced Mock com faseamento automático")
        
        # Criar fases baseadas no contexto
        phases = self._create_intelligent_phases(request)
        
        all_responses = []
        total_tokens = 0
        
        for i, phase_request in enumerate(phases):
            self.logger.debug(f"Executando fase Mock {i+1}/{len(phases)}")
            
            # Simular delay realístico
            time.sleep(self.response_delay)
            
            # Executar fase
            phase_response = self._analyze_single_request(phase_request)
            
            if phase_response.success:
                all_responses.append({
                    'phase_name': phase_request.context.get('phase_name', f'Fase {i+1}'),
                    'content': phase_response.content
                })
                total_tokens += phase_response.tokens_used
            else:
                # Mock nunca falha, mas registrar warning
                self.logger.warning(f"Fase {i+1} teve problema, continuando...")
        
        # Consolidar respostas
        consolidated_content = self._consolidate_mock_responses(all_responses)
        
        # Criar resposta final
        final_response = AIResponse(
            content=consolidated_content,
            tokens_used=total_tokens,
            provider_name=self.name,
            model_name="enhanced-mock-gpt-4",
            success=True
        )
        
        self._update_statistics(final_response)
        return final_response
    
    def _create_intelligent_phases(self, request: AIRequest) -> List[AIRequest]:
        """Cria fases inteligentes baseadas no contexto da requisição."""
        phases = []
        
        # Analisar prompt para determinar fases necessárias
        prompt_lower = request.prompt.lower()
        
        # Sempre incluir análise funcional (obrigatória)
        functional_phase = AIRequest(
            prompt=request.prompt + "\n\nFoque especificamente em: O que este programa faz funcionalmente?",
            context={'phase_name': 'Análise Funcional', 'phase_type': 'functional_analysis'},
            max_tokens=min(600, self.max_tokens_per_phase),
            temperature=request.temperature
        )
        phases.append(functional_phase)
        
        # Adicionar outras fases baseadas no contexto
        remaining_tokens = request.max_tokens - 600
        
        if remaining_tokens > 400:
            # Adicionar análise básica
            basic_phase = AIRequest(
                prompt=request.prompt + "\n\nFoque especificamente em: informações básicas e estrutura geral.",
                context={'phase_name': 'Informações Básicas', 'phase_type': 'basic_info'},
                max_tokens=min(400, remaining_tokens),
                temperature=request.temperature
            )
            phases.insert(0, basic_phase)  # Inserir no início
            remaining_tokens -= 400
        
        if remaining_tokens > 500:
            # Adicionar análise técnica
            technical_phase = AIRequest(
                prompt=request.prompt + "\n\nFoque especificamente em: análise técnica detalhada com trechos de código.",
                context={'phase_name': 'Análise Técnica', 'phase_type': 'technical_analysis'},
                max_tokens=min(500, remaining_tokens),
                temperature=request.temperature
            )
            phases.append(technical_phase)
            remaining_tokens -= 500
        
        if remaining_tokens > 400:
            # Adicionar regras de negócio
            business_phase = AIRequest(
                prompt=request.prompt + "\n\nFoque especificamente em: regras de negócio e validações.",
                context={'phase_name': 'Regras de Negócio', 'phase_type': 'business_rules'},
                max_tokens=min(400, remaining_tokens),
                temperature=request.temperature
            )
            phases.append(business_phase)
        
        return phases
    
    def _consolidate_mock_responses(self, responses: List[Dict[str, str]]) -> str:
        """Consolida respostas de múltiplas fases do Enhanced Mock."""
        consolidated = "# Análise COBOL Completa (Enhanced Mock Faseado)\n\n"
        
        for response_data in responses:
            phase_name = response_data['phase_name']
            content = response_data['content']
            
            consolidated += f"## {phase_name}\n\n"
            consolidated += content.strip() + "\n\n"
        
        consolidated += "---\n"
        consolidated += f"*Análise gerada com Enhanced Mock Provider - {len(responses)} fases inteligentes*\n"
        consolidated += f"*Sistema de fallback garantido - 100% de disponibilidade*\n"
        
        return consolidated
    
    def _analyze_single_request(self, request: AIRequest) -> AIResponse:
        """Realiza análise em requisição única com base no código real."""
        try:
            # Simular delay realístico
            time.sleep(self.response_delay)
            
            # Extrair código COBOL do prompt
            cobol_code = self._extract_cobol_code(request.prompt)
            
            # Analisar código COBOL
            code_analysis = self._analyze_cobol_code(cobol_code)
            
            # Determinar tipo de análise baseado no contexto
            analysis_type = self._determine_analysis_type(request)
            
            # Gerar resposta contextual específica
            content = self._generate_specific_response(request, analysis_type, code_analysis)
            
            # Simular uso de tokens realístico
            tokens_used = self._simulate_token_usage(content, request.max_tokens)
            
            return AIResponse(
                content=content,
                tokens_used=tokens_used,
                provider_name=self.name,
                model_name="enhanced-mock-gpt-4",
                success=True,
                input_tokens=int(tokens_used * 0.3),
                output_tokens=int(tokens_used * 0.7)
            )
            
        except Exception as e:
            self.logger.error(f"Erro inesperado Enhanced Mock: {str(e)}")
            return self._create_error_response(f"Erro: {str(e)}")
    
    def _extract_cobol_code(self, prompt: str) -> str:
        """Extrai código COBOL do prompt."""
        
        # Procurar por seções que contêm código COBOL
        lines = prompt.split('\n')
        cobol_lines = []
        in_cobol_section = False
        
        for line in lines:
            # Detectar início de código COBOL
            if any(keyword in line.upper() for keyword in ['IDENTIFICATION DIVISION', 'PROGRAM-ID', 'ENVIRONMENT DIVISION', 'DATA DIVISION', 'PROCEDURE DIVISION']):
                in_cobol_section = True
            
            # Se estamos em seção COBOL, adicionar linha
            if in_cobol_section:
                cobol_lines.append(line)
            
            # Detectar possível fim (linha vazia após código)
            if in_cobol_section and line.strip() == '' and len(cobol_lines) > 50:
                # Continuar coletando, mas marcar possível fim
                pass
        
        return '\n'.join(cobol_lines)
    
    def _analyze_cobol_code(self, cobol_code: str) -> Dict[str, Any]:
        """Analisa código COBOL e extrai informações específicas."""
        
        analysis = {
            'program_name': 'PROGRAMA',
            'divisions': [],
            'sections': [],
            'files': [],
            'copybooks': [],
            'variables': [],
            'procedures': [],
            'file_operations': [],
            'business_logic': [],
            'code_snippets': {}
        }
        
        if not cobol_code:
            return analysis
        
        # Extrair nome do programa
        program_match = self.cobol_patterns['program_id'].search(cobol_code)
        if program_match:
            analysis['program_name'] = program_match.group(1)
        
        # Extrair divisões
        divisions = self.cobol_patterns['divisions'].findall(cobol_code)
        analysis['divisions'] = list(set(divisions))
        
        # Extrair seções
        sections = self.cobol_patterns['sections'].findall(cobol_code)
        analysis['sections'] = list(set(sections))
        
        # Extrair arquivos
        files = self.cobol_patterns['file_control'].findall(cobol_code)
        analysis['files'] = [f[0] for f in files]
        
        # Extrair copybooks
        copybooks = self.cobol_patterns['copy_statements'].findall(cobol_code)
        analysis['copybooks'] = list(set(copybooks))
        
        # Extrair variáveis do working storage
        variables = self.cobol_patterns['working_storage'].findall(cobol_code)
        analysis['variables'] = [f"{v[0]} {v[1]} PIC {v[2]}" for v in variables[:10]]
        
        # Extrair chamadas de procedimento
        procedures = self.cobol_patterns['procedure_calls'].findall(cobol_code)
        analysis['procedures'] = list(set(procedures))
        
        # Extrair operações de arquivo
        file_ops = self.cobol_patterns['file_operations'].findall(cobol_code)
        analysis['file_operations'] = [f"{op[0]} {op[1]}" for op in file_ops]
        
        # Extrair trechos de código específicos
        analysis['code_snippets'] = self._extract_code_snippets(cobol_code)
        
        # Analisar lógica de negócio
        analysis['business_logic'] = self._analyze_business_logic(cobol_code)
        
        return analysis
    
    def _extract_code_snippets(self, cobol_code: str) -> Dict[str, str]:
        """Extrai trechos específicos de código COBOL."""
        
        snippets = {}
        lines = cobol_code.split('\n')
        
        # Extrair FILE-CONTROL
        file_control_lines = []
        in_file_control = False
        
        for line in lines:
            if 'FILE-CONTROL' in line.upper():
                in_file_control = True
            elif in_file_control and ('SELECT' in line.upper() or 'ASSIGN' in line.upper()):
                file_control_lines.append(line.strip())
            elif in_file_control and line.strip() == '':
                break
        
        if file_control_lines:
            snippets['file_control'] = '\n'.join(file_control_lines[:5])
        
        # Extrair procedimento principal
        procedure_lines = []
        in_procedure = False
        
        for line in lines:
            if 'PROCEDURE DIVISION' in line.upper():
                in_procedure = True
                continue
            elif in_procedure and line.strip():
                procedure_lines.append(line.strip())
                if len(procedure_lines) >= 10:
                    break
        
        if procedure_lines:
            snippets['main_procedure'] = '\n'.join(procedure_lines)
        
        # Extrair validações (IF statements)
        validation_lines = []
        for line in lines:
            if line.strip().upper().startswith('IF '):
                validation_lines.append(line.strip())
                if len(validation_lines) >= 5:
                    break
        
        if validation_lines:
            snippets['validations'] = '\n'.join(validation_lines)
        
        return snippets
    
    def _analyze_business_logic(self, cobol_code: str) -> List[str]:
        """Analisa lógica de negócio no código COBOL."""
        
        business_logic = []
        
        # Procurar por padrões de lógica de negócio
        if 'MOVE' in cobol_code.upper():
            business_logic.append("Transferência e manipulação de dados entre variáveis")
        
        if 'IF' in cobol_code.upper():
            business_logic.append("Validações condicionais e controle de fluxo")
        
        if 'PERFORM' in cobol_code.upper():
            business_logic.append("Modularização através de chamadas de procedimento")
        
        if 'READ' in cobol_code.upper() or 'WRITE' in cobol_code.upper():
            business_logic.append("Operações de entrada e saída de dados")
        
        if 'COMPUTE' in cobol_code.upper() or 'ADD' in cobol_code.upper():
            business_logic.append("Cálculos e operações matemáticas")
        
        return business_logic
    
    def _determine_analysis_type(self, request: AIRequest) -> str:
        """Determina o tipo de análise baseado no prompt e contexto."""
        
        # Verificar contexto da fase primeiro
        if request.context and 'phase_type' in request.context:
            return request.context['phase_type']
        
        # Analisar prompt para determinar tipo
        prompt_lower = request.prompt.lower()
        
        for analysis_type, template_info in self.response_templates.items():
            for keyword in template_info['keywords']:
                if keyword in prompt_lower:
                    return analysis_type
        
        # Default para análise funcional (sempre responde a pergunta principal)
        return 'functional_analysis'
    
    def _generate_specific_response(self, request: AIRequest, analysis_type: str, code_analysis: Dict[str, Any]) -> str:
        """Gera resposta específica baseada na análise do código real."""
        
        # Obter template
        template_info = self.response_templates.get(analysis_type, self.response_templates['functional_analysis'])
        template = template_info['template']
        
        # Preparar variáveis para substituição
        template_vars = self._prepare_template_variables(code_analysis, analysis_type)
        
        # Substituir variáveis no template
        try:
            response = template.format(**template_vars)
        except KeyError as e:
            # Se alguma variável não existe, usar valores padrão
            self.logger.warning(f"Variável de template não encontrada: {e}")
            response = self._generate_fallback_response(analysis_type, code_analysis)
        
        # Adicionar metadados do Enhanced Mock
        response += f"\n\n---\n**Enhanced Mock Analysis**\n"
        response += f"- Tipo de análise: {analysis_type}\n"
        response += f"- Programa analisado: {code_analysis['program_name']}\n"
        response += f"- Divisões encontradas: {len(code_analysis['divisions'])}\n"
        response += f"- Seções identificadas: {len(code_analysis['sections'])}\n"
        response += f"- Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        response += f"- Provider: Enhanced Mock (Análise Específica de Código)\n"
        
        return response
    
    def _prepare_template_variables(self, code_analysis: Dict[str, Any], analysis_type: str) -> Dict[str, str]:
        """Prepara variáveis para substituição no template."""
        
        # Variáveis básicas
        vars_dict = {
            'program_name': code_analysis['program_name'],
            'line_count': len(code_analysis.get('variables', [])) * 50,  # Estimativa
            'size': len(str(code_analysis)) * 100,  # Estimativa
            'file_count': len(code_analysis['files']),
            'section_count': len(code_analysis['sections'])
        }
        
        # Variáveis específicas por tipo de análise
        if analysis_type == 'basic_info':
            vars_dict.update({
                'divisions_found': self._format_divisions(code_analysis['divisions']),
                'files_found': self._format_files(code_analysis['files']),
                'copybooks_found': self._format_copybooks(code_analysis['copybooks'])
            })
        
        elif analysis_type == 'functional_analysis':
            vars_dict.update({
                'functional_purpose': self._determine_functional_purpose(code_analysis),
                'initialization_logic': self._describe_initialization(code_analysis),
                'main_processing': self._describe_main_processing(code_analysis),
                'validation_logic': self._describe_validations(code_analysis),
                'finalization_logic': self._describe_finalization(code_analysis),
                'business_rules': self._describe_business_rules(code_analysis),
                'data_flow': self._describe_data_flow(code_analysis),
                'system_impact': self._describe_system_impact(code_analysis)
            })
        
        elif analysis_type == 'technical_analysis':
            vars_dict.update({
                'technical_divisions': self._format_technical_divisions(code_analysis),
                'technical_sections': self._format_technical_sections(code_analysis),
                'data_structures': self._format_data_structures(code_analysis),
                'file_control_code': code_analysis['code_snippets'].get('file_control', 'Não identificado'),
                'main_procedure_code': code_analysis['code_snippets'].get('main_procedure', 'Não identificado'),
                'validation_code': code_analysis['code_snippets'].get('validations', 'Não identificado'),
                'processing_algorithms': self._describe_algorithms(code_analysis),
                'performance_considerations': self._describe_performance(code_analysis)
            })
        
        elif analysis_type == 'business_rules':
            vars_dict.update({
                'input_validations': self._describe_input_validations(code_analysis),
                'processing_rules': self._describe_processing_rules(code_analysis),
                'quality_controls': self._describe_quality_controls(code_analysis),
                'calculations': self._describe_calculations(code_analysis),
                'business_rule_code': self._format_business_rule_code(code_analysis),
                'compliance_rules': self._describe_compliance(code_analysis)
            })
        
        return vars_dict
    
    def _format_divisions(self, divisions: List[str]) -> str:
        """Formata lista de divisões encontradas."""
        if not divisions:
            return "- Nenhuma divisão claramente identificada"
        
        formatted = []
        for division in divisions:
            formatted.append(f"- **{division} DIVISION**: Implementada")
        
        return '\n'.join(formatted)
    
    def _format_files(self, files: List[str]) -> str:
        """Formata lista de arquivos encontrados."""
        if not files:
            return "- Nenhum arquivo específico identificado"
        
        formatted = []
        for file_name in files[:5]:  # Limitar a 5
            formatted.append(f"- **{file_name}**: Arquivo de dados")
        
        return '\n'.join(formatted)
    
    def _format_copybooks(self, copybooks: List[str]) -> str:
        """Formata lista de copybooks encontrados."""
        if not copybooks:
            return "- Nenhum copybook identificado"
        
        formatted = []
        for copybook in copybooks[:5]:  # Limitar a 5
            formatted.append(f"- **{copybook}**: Copybook incluído")
        
        return '\n'.join(formatted)
    
    def _determine_functional_purpose(self, code_analysis: Dict[str, Any]) -> str:
        """Determina o propósito funcional baseado na análise do código."""
        
        program_name = code_analysis['program_name']
        
        # Análise baseada no nome do programa
        if 'LHAN' in program_name:
            return f"Processamento de dados BACEN - O programa {program_name} implementa rotinas específicas para tratamento de informações regulatórias do Banco Central."
        elif 'LHBR' in program_name:
            return f"Processamento de dados Brasil - O programa {program_name} processa informações específicas do mercado brasileiro."
        elif 'MZAN' in program_name:
            return f"Processamento de análise - O programa {program_name} realiza análises e validações de dados corporativos."
        else:
            return f"Processamento de dados corporativo - O programa {program_name} implementa lógica de negócio específica para tratamento de informações empresariais."
    
    def _describe_initialization(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve lógica de inicialização."""
        
        if code_analysis['files']:
            return f"- Abertura de arquivos: {', '.join(code_analysis['files'][:3])}\n- Inicialização de variáveis de controle\n- Configuração de parâmetros de processamento"
        else:
            return "- Inicialização de variáveis de trabalho\n- Configuração de parâmetros do sistema\n- Preparação do ambiente de processamento"
    
    def _describe_main_processing(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve processamento principal."""
        
        processing = []
        
        if code_analysis['file_operations']:
            processing.append("- Leitura sequencial de registros de entrada")
            processing.append("- Processamento registro a registro")
        
        if code_analysis['procedures']:
            processing.append(f"- Execução de {len(code_analysis['procedures'])} procedimentos específicos")
        
        if code_analysis['business_logic']:
            processing.extend([f"- {logic}" for logic in code_analysis['business_logic'][:3]])
        
        if not processing:
            processing = [
                "- Processamento sequencial de dados",
                "- Aplicação de regras de negócio",
                "- Transformação e validação de informações"
            ]
        
        return '\n'.join(processing)
    
    def _describe_validations(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve validações implementadas."""
        
        validations = []
        
        if 'validations' in code_analysis['code_snippets']:
            validations.append("- Validações condicionais implementadas via IF statements")
        
        validations.extend([
            "- Verificação de integridade dos dados de entrada",
            "- Validação de formatos e tipos de dados",
            "- Controle de consistência entre campos relacionados"
        ])
        
        return '\n'.join(validations)
    
    def _describe_finalization(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve lógica de finalização."""
        
        return "- Fechamento de arquivos processados\n- Geração de totais e estatísticas\n- Finalização de logs e controles de auditoria"
    
    def _describe_business_rules(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve regras de negócio identificadas."""
        
        rules = []
        
        if code_analysis['business_logic']:
            for logic in code_analysis['business_logic']:
                rules.append(f"- {logic}")
        
        # Adicionar regras padrão baseadas no tipo de programa
        program_name = code_analysis['program_name']
        if 'LHAN' in program_name:
            rules.append("- Conformidade com regulamentações BACEN")
            rules.append("- Validação de códigos e identificadores específicos")
        
        rules.extend([
            "- Manutenção de integridade referencial",
            "- Aplicação de regras de validação corporativas"
        ])
        
        return '\n'.join(rules[:5])
    
    def _describe_data_flow(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve fluxo de dados."""
        
        flow_parts = []
        
        if code_analysis['files']:
            flow_parts.append(f"**Entrada**: {', '.join(code_analysis['files'][:2])}")
        
        flow_parts.extend([
            "**Processamento**: Transformação e validação dos dados",
            "**Saída**: Registros processados e relatórios de controle"
        ])
        
        return '\n'.join(flow_parts)
    
    def _describe_system_impact(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve impacto no sistema."""
        
        program_name = code_analysis['program_name']
        
        if 'LHAN' in program_name:
            return "processamento de dados regulatórios BACEN"
        elif 'LHBR' in program_name:
            return "processamento de dados do mercado brasileiro"
        else:
            return "processamento de dados corporativos críticos"
    
    def _format_technical_divisions(self, code_analysis: Dict[str, Any]) -> str:
        """Formata divisões técnicas."""
        
        if not code_analysis['divisions']:
            return "- Estrutura COBOL padrão identificada"
        
        formatted = []
        for division in code_analysis['divisions']:
            if division.upper() == 'IDENTIFICATION':
                formatted.append("- **IDENTIFICATION DIVISION**: Metadados e identificação do programa")
            elif division.upper() == 'ENVIRONMENT':
                formatted.append("- **ENVIRONMENT DIVISION**: Configuração do ambiente de execução")
            elif division.upper() == 'DATA':
                formatted.append("- **DATA DIVISION**: Definição de estruturas de dados")
            elif division.upper() == 'PROCEDURE':
                formatted.append("- **PROCEDURE DIVISION**: Lógica de processamento principal")
        
        return '\n'.join(formatted)
    
    def _format_technical_sections(self, code_analysis: Dict[str, Any]) -> str:
        """Formata seções técnicas."""
        
        if not code_analysis['sections']:
            return "- Seções de processamento identificadas na análise"
        
        formatted = []
        for section in code_analysis['sections'][:5]:
            formatted.append(f"- **{section}**: Seção de processamento específico")
        
        return '\n'.join(formatted)
    
    def _format_data_structures(self, code_analysis: Dict[str, Any]) -> str:
        """Formata estruturas de dados."""
        
        if not code_analysis['variables']:
            return "- Estruturas de dados working-storage identificadas"
        
        formatted = []
        for variable in code_analysis['variables'][:5]:
            formatted.append(f"- {variable}")
        
        return '\n'.join(formatted)
    
    def _describe_algorithms(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve algoritmos implementados."""
        
        algorithms = []
        
        if code_analysis['procedures']:
            algorithms.append("- Modularização através de procedimentos PERFORM")
        
        if code_analysis['file_operations']:
            algorithms.append("- Algoritmos de processamento sequencial de arquivos")
        
        algorithms.extend([
            "- Estruturas de controle hierárquicas",
            "- Processamento orientado a registros",
            "- Validação em múltiplas camadas"
        ])
        
        return '\n'.join(algorithms)
    
    def _describe_performance(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve considerações de performance."""
        
        return "- Processamento sequencial otimizado para grandes volumes\n- Uso eficiente de buffers de I/O\n- Minimização de operações de seek em arquivos\n- Estruturas de dados otimizadas para mainframe"
    
    def _describe_input_validations(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve validações de entrada."""
        
        return "- Verificação de formato de campos obrigatórios\n- Validação de tipos de dados numéricos e alfanuméricos\n- Controle de ranges e limites permitidos"
    
    def _describe_processing_rules(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve regras de processamento."""
        
        return "- Aplicação de fórmulas de cálculo específicas\n- Implementação de condições de negócio complexas\n- Tratamento de exceções e casos especiais"
    
    def _describe_quality_controls(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve controles de qualidade."""
        
        return "- Verificação de totais e somatórias\n- Validação de integridade referencial\n- Controles de auditoria e rastreabilidade"
    
    def _describe_calculations(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve cálculos implementados."""
        
        return "- Cálculos matemáticos específicos do domínio\n- Conversões de moedas e unidades\n- Aplicação de taxas e percentuais regulatórios"
    
    def _format_business_rule_code(self, code_analysis: Dict[str, Any]) -> str:
        """Formata código de regras de negócio."""
        
        if 'validations' in code_analysis['code_snippets']:
            return f"```cobol\n{code_analysis['code_snippets']['validations']}\n```"
        else:
            return "```cobol\n* Regras de negócio implementadas via estruturas condicionais\nIF CAMPO-VALIDO = 'S'\n   PERFORM PROCESSAR-REGISTRO\nELSE\n   PERFORM TRATAR-ERRO\nEND-IF\n```"
    
    def _describe_compliance(self, code_analysis: Dict[str, Any]) -> str:
        """Descreve conformidade regulatória."""
        
        program_name = code_analysis['program_name']
        
        if 'LHAN' in program_name:
            return "- Conformidade com normas BACEN\n- Implementação de controles regulatórios\n- Geração de relatórios para órgãos fiscalizadores"
        else:
            return "- Atendimento a normas corporativas\n- Implementação de controles internos\n- Manutenção de trilhas de auditoria"
    
    def _generate_fallback_response(self, analysis_type: str, code_analysis: Dict[str, Any]) -> str:
        """Gera resposta de fallback em caso de erro no template."""
        
        program_name = code_analysis['program_name']
        
        if analysis_type == 'functional_analysis':
            return f"""## O que este programa faz funcionalmente?

O programa {program_name} é um sistema COBOL que processa dados corporativos.

### Funcionalidade Principal
- Processamento de dados em ambiente mainframe
- Implementação de regras de negócio específicas
- Validação e transformação de informações

### Processo Implementado
1. Leitura de dados de entrada
2. Aplicação de validações e regras
3. Processamento e transformação
4. Geração de saídas e relatórios

Este programa é essencial para o processamento de dados corporativos e manutenção da integridade das informações do sistema."""
        
        else:
            return f"""## Análise do Programa {program_name}

### Características Identificadas
- Programa COBOL padrão
- Estrutura mainframe
- Processamento de dados corporativo

### Componentes Principais
- Divisões COBOL implementadas
- Seções de processamento
- Estruturas de dados definidas

### Funcionalidade
Este programa implementa lógica de negócio específica para processamento de dados em ambiente corporativo."""
    
    def _simulate_token_usage(self, content: str, max_tokens: int) -> int:
        """Simula uso realístico de tokens."""
        if not self.simulate_realistic_tokens:
            return random.randint(100, min(max_tokens, 1000))
        
        # Estimativa baseada no conteúdo: ~4 caracteres por token
        estimated_tokens = len(content) // 4
        
        # Adicionar variação realística (±10%)
        variation = random.uniform(0.9, 1.1)
        final_tokens = int(estimated_tokens * variation)
        
        # Garantir que não excede o máximo
        return min(final_tokens, max_tokens)
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações específicas do Enhanced Mock Provider."""
        base_info = self.get_statistics()
        
        mock_info = {
            "model": "enhanced-mock-gpt-4",
            "always_available": True,
            "response_delay": self.response_delay,
            "enable_phasing": self.enable_phasing,
            "max_tokens_per_phase": self.max_tokens_per_phase,
            "simulate_realistic_tokens": self.simulate_realistic_tokens,
            "analysis_types_supported": list(self.response_templates.keys()),
            "guaranteed_uptime": "100%",
            "fallback_provider": True,
            "code_analysis_enabled": True,
            "specific_responses": True
        }
        
        base_info.update(mock_info)
        return base_info

