"""
COBOL AI Engine v2.1.0
Sistema completo de análise de programas COBOL com IA.
"""

__version__ = "2.1.0"
__author__ = "COBOL AI Engine Team"
__description__ = "Sistema avançado de análise de programas COBOL com múltiplos provedores de IA"

