"""
COBOL AI Engine v2.1.0 - COBOL Parser
Parser avançado para programas COBOL e copybooks.
"""

import logging
import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass


@dataclass
class CobolProgram:
    """Representa um programa COBOL parseado."""
    name: str
    content: str
    line_count: int
    size: int
    divisions: Dict[str, str]
    sections: List[str]
    variables: List[str]
    files: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'line_count': self.line_count,
            'size': self.size,
            'divisions': self.divisions,
            'sections': self.sections,
            'variables': self.variables,
            'files': self.files
        }


@dataclass
class CobolBook:
    """Representa um copybook COBOL."""
    name: str
    content: str
    line_count: int
    size: int
    structures: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'line_count': self.line_count,
            'size': self.size,
            'structures': self.structures
        }


class CobolParser:
    """
    Parser avançado para arquivos COBOL empilhados e copybooks.
    
    Funcionalidades:
    - Parse de arquivos empilhados (VMEMBER NAME)
    - Extração de programas e copybooks
    - Análise de estrutura COBOL
    - Identificação de divisões e seções
    - Extração de variáveis e arquivos
    """
    
    def __init__(self):
        """Inicializa o parser COBOL."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões regex para parsing
        self.vmember_pattern = re.compile(r'^\s*VMEMBER\s+NAME\s*=\s*([A-Z0-9]+)', re.IGNORECASE)
        self.division_pattern = re.compile(r'^\s*([A-Z]+)\s+DIVISION\.', re.IGNORECASE)
        self.section_pattern = re.compile(r'^\s*([A-Z0-9\-]+)\s+SECTION\.', re.IGNORECASE)
        self.variable_pattern = re.compile(r'^\s*\d+\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.file_pattern = re.compile(r'^\s*SELECT\s+([A-Z0-9\-]+)', re.IGNORECASE)
        
        self.logger.info("COBOL Parser inicializado")
    
    def parse_file(self, file_path: str) -> Tuple[List[CobolProgram], List[CobolBook]]:
        """
        Parse de arquivo COBOL empilhado.
        
        Args:
            file_path: Caminho para o arquivo
            
        Returns:
            Tupla com (programas, copybooks)
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            self.logger.info(f"Parseando arquivo: {file_path}")
            
            # Dividir por VMEMBER
            members = self._split_by_vmember(content)
            
            programs = []
            books = []
            
            for member_name, member_content in members.items():
                if self._is_program(member_content):
                    program = self._parse_program(member_name, member_content)
                    programs.append(program)
                    self.logger.debug(f"Programa parseado: {member_name}")
                else:
                    book = self._parse_book(member_name, member_content)
                    books.append(book)
                    self.logger.debug(f"Copybook parseado: {member_name}")
            
            self.logger.info(f"Parseados {len(programs)} programas e {len(books)} books de {file_path}")
            return programs, books
            
        except Exception as e:
            self.logger.error(f"Erro ao parsear arquivo {file_path}: {str(e)}")
            return [], []
    
    def _split_by_vmember(self, content: str) -> Dict[str, str]:
        """Divide conteúdo por VMEMBER NAME."""
        
        members = {}
        current_member = None
        current_content = []
        
        lines = content.split('\n')
        
        for line in lines:
            vmember_match = self.vmember_pattern.match(line)
            
            if vmember_match:
                # Salvar membro anterior se existir
                if current_member and current_content:
                    members[current_member] = '\n'.join(current_content)
                
                # Iniciar novo membro
                current_member = vmember_match.group(1)
                current_content = []
            else:
                # Adicionar linha ao membro atual
                if current_member:
                    current_content.append(line)
        
        # Salvar último membro
        if current_member and current_content:
            members[current_member] = '\n'.join(current_content)
        
        # Se não há VMEMBER, tratar arquivo inteiro como um membro
        if not members and content.strip():
            # Tentar extrair nome do primeiro programa
            first_lines = content.split('\n')[:20]
            program_name = 'PROGRAMA'
            
            for line in first_lines:
                if 'PROGRAM-ID' in line.upper():
                    parts = line.split()
                    if len(parts) >= 2:
                        program_name = parts[-1].rstrip('.')
                        break
            
            members[program_name] = content
        
        return members
    
    def _is_program(self, content: str) -> bool:
        """Determina se o conteúdo é um programa ou copybook."""
        
        content_upper = content.upper()
        
        # Indicadores de programa
        program_indicators = [
            'IDENTIFICATION DIVISION',
            'PROGRAM-ID',
            'ENVIRONMENT DIVISION',
            'DATA DIVISION',
            'PROCEDURE DIVISION'
        ]
        
        # Indicadores de copybook
        book_indicators = [
            'COPY',
            '01 ',
            '05 ',
            '10 ',
            'PIC ',
            'PICTURE '
        ]
        
        program_score = sum(1 for indicator in program_indicators if indicator in content_upper)
        book_score = sum(1 for indicator in book_indicators if indicator in content_upper)
        
        # Se tem divisões, é programa
        if program_score >= 2:
            return True
        
        # Se tem muitas estruturas de dados e poucas divisões, é copybook
        if book_score > program_score and program_score < 2:
            return False
        
        # Default: considerar programa se ambíguo
        return True
    
    def _parse_program(self, name: str, content: str) -> CobolProgram:
        """Parse de programa COBOL."""
        
        lines = content.split('\n')
        line_count = len([line for line in lines if line.strip()])
        size = len(content)
        
        # Extrair divisões
        divisions = self._extract_divisions(content)
        
        # Extrair seções
        sections = self._extract_sections(content)
        
        # Extrair variáveis
        variables = self._extract_variables(content)
        
        # Extrair arquivos
        files = self._extract_files(content)
        
        return CobolProgram(
            name=name,
            content=content,
            line_count=line_count,
            size=size,
            divisions=divisions,
            sections=sections,
            variables=variables,
            files=files
        )
    
    def _parse_book(self, name: str, content: str) -> CobolBook:
        """Parse de copybook COBOL."""
        
        lines = content.split('\n')
        line_count = len([line for line in lines if line.strip()])
        size = len(content)
        
        # Extrair estruturas de dados
        structures = self._extract_data_structures(content)
        
        return CobolBook(
            name=name,
            content=content,
            line_count=line_count,
            size=size,
            structures=structures
        )
    
    def _extract_divisions(self, content: str) -> Dict[str, str]:
        """Extrai divisões do programa COBOL."""
        
        divisions = {}
        current_division = None
        current_content = []
        
        lines = content.split('\n')
        
        for line in lines:
            division_match = self.division_pattern.match(line)
            
            if division_match:
                # Salvar divisão anterior
                if current_division and current_content:
                    divisions[current_division] = '\n'.join(current_content)
                
                # Iniciar nova divisão
                current_division = division_match.group(1).upper()
                current_content = [line]
            else:
                # Adicionar linha à divisão atual
                if current_division:
                    current_content.append(line)
        
        # Salvar última divisão
        if current_division and current_content:
            divisions[current_division] = '\n'.join(current_content)
        
        return divisions
    
    def _extract_sections(self, content: str) -> List[str]:
        """Extrai seções do programa COBOL."""
        
        sections = []
        
        for line in content.split('\n'):
            section_match = self.section_pattern.match(line)
            if section_match:
                section_name = section_match.group(1)
                if section_name not in sections:
                    sections.append(section_name)
        
        return sections
    
    def _extract_variables(self, content: str) -> List[str]:
        """Extrai variáveis do programa COBOL."""
        
        variables = []
        
        for line in content.split('\n'):
            variable_match = self.variable_pattern.match(line)
            if variable_match:
                variable_name = variable_match.group(1)
                if variable_name not in variables and len(variable_name) > 1:
                    variables.append(variable_name)
        
        return variables[:50]  # Limitar para evitar lista muito longa
    
    def _extract_files(self, content: str) -> List[str]:
        """Extrai arquivos do programa COBOL."""
        
        files = []
        
        for line in content.split('\n'):
            file_match = self.file_pattern.match(line)
            if file_match:
                file_name = file_match.group(1)
                if file_name not in files:
                    files.append(file_name)
        
        return files
    
    def _extract_data_structures(self, content: str) -> List[str]:
        """Extrai estruturas de dados do copybook."""
        
        structures = []
        
        # Padrão para estruturas de dados (01, 05, 10, etc.)
        structure_pattern = re.compile(r'^\s*(\d+)\s+([A-Z0-9\-]+)', re.IGNORECASE)
        
        for line in content.split('\n'):
            structure_match = structure_pattern.match(line)
            if structure_match:
                level = structure_match.group(1)
                name = structure_match.group(2)
                
                # Incluir apenas níveis principais (01, 05, 10)
                if level in ['01', '05', '10'] and name not in structures:
                    structures.append(f"{level} {name}")
        
        return structures[:30]  # Limitar para evitar lista muito longa
    
    def get_parser_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do parser."""
        
        return {
            "parser_version": "2.1.0",
            "supported_formats": ["VMEMBER", "Standard COBOL"],
            "supported_types": ["Programs", "Copybooks"],
            "features": [
                "Division extraction",
                "Section identification",
                "Variable detection",
                "File identification",
                "Data structure parsing"
            ]
        }

