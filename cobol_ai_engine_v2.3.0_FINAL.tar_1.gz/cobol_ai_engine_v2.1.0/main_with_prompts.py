#!/usr/bin/env python3
"""
COBOL AI Engine v2.2.0 - Script Principal com Prompts Customizáveis
Sistema completo de análise COBOL com documentação de prompts e perguntas customizáveis.
"""

import argparse
import logging
import os
import sys
from typing import List, Dict, Any

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager import PromptManager
from src.parsers.cobol_parser import CobolParser
from src.providers.provider_manager import ProviderManager
from src.generators.documentation_generator import DocumentationGenerator


def setup_logging(level: str = "INFO") -> None:
    """Configura logging do sistema."""
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('logs/cobol_ai_engine.log', mode='a')
        ]
    )
    
    # Criar diretório de logs se não existir
    os.makedirs('logs', exist_ok=True)


def main():
    """Função principal do COBOL AI Engine com prompts customizáveis."""
    
    parser = argparse.ArgumentParser(
        description="COBOL AI Engine v2.2.0 - Análise de programas COBOL com IA e prompts customizáveis"
    )
    
    # Argumentos principais
    parser.add_argument("--fontes", type=str, help="Arquivo com programas COBOL")
    parser.add_argument("--books", type=str, help="Arquivo com copybooks")
    parser.add_argument("--output", type=str, default="output", help="Diretório de saída")
    parser.add_argument("--config", type=str, default="config/config.yaml", help="Arquivo de configuração")
    parser.add_argument("--prompts", type=str, default="config/prompts.yaml", help="Arquivo de configuração de prompts")
    
    # Argumentos de controle
    parser.add_argument("--provider", type=str, help="Provedor específico a usar")
    parser.add_argument("--log-level", type=str, default="INFO", choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    
    # Comandos especiais
    parser.add_argument("--status", action="store_true", help="Mostrar status do sistema")
    parser.add_argument("--version", action="store_true", help="Mostrar versão")
    parser.add_argument("--list-questions", action="store_true", help="Listar perguntas configuradas")
    parser.add_argument("--update-question", type=str, help="Atualizar pergunta funcional")
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    try:
        # Mostrar versão
        if args.version:
            with open('VERSION', 'r') as f:
                version = f.read().strip()
            print(f"COBOL AI Engine v{version}")
            return
        
        # Carregar configurações
        config_manager = ConfigManager(args.config)
        config = config_manager.get_config()
        
        # Carregar gerenciador de prompts
        prompt_manager = PromptManager(args.prompts)
        
        # Listar perguntas configuradas
        if args.list_questions:
            print("=== PERGUNTAS CONFIGURADAS ===")
            questions_config = prompt_manager.config.get("prompts", {}).get("analysis_questions", {})
            for key, config in questions_config.items():
                question = config.get("question", "")
                priority = config.get("priority", "N/A")
                required = "Obrigatória" if config.get("required", False) else "Opcional"
                print(f"{priority}. {question} ({required})")
            
            # Mostrar pergunta funcional atual
            functional_question = prompt_manager.get_functional_question()
            print(f"\n=== PERGUNTA FUNCIONAL ATUAL ===")
            print(f'"{functional_question}"')
            return
        
        # Atualizar pergunta funcional
        if args.update_question:
            prompt_manager.update_functional_question(args.update_question)
            prompt_manager.save_config()
            print(f'Pergunta funcional atualizada para: "{args.update_question}"')
            return
        
        # Inicializar componentes
        provider_manager = ProviderManager(config)
        
        # Mostrar status
        if args.status:
            print("=== STATUS DO SISTEMA ===")
            print(f"COBOL AI Engine v2.2.0")
            print(f"Timestamp: {logger.handlers[0].formatter.formatTime(logging.LogRecord('', 0, '', 0, '', (), None))}")
            print()
            
            print("--- CONFIGURAÇÃO DE PROMPTS ---")
            print(f"Arquivo de prompts: {args.prompts}")
            print(f"Documentação de prompts: {'Habilitada' if prompt_manager.config.get('prompts', {}).get('include_in_documentation', False) else 'Desabilitada'}")
            
            functional_question = prompt_manager.get_functional_question()
            print(f'Pergunta funcional: "{functional_question}"')
            
            questions_count = len(prompt_manager.config.get("prompts", {}).get("analysis_questions", {}))
            print(f"Total de perguntas: {questions_count}")
            print()
            
            print("--- PROVEDORES ---")
            available_providers = provider_manager.get_available_providers()
            print(f"Total de provedores: {len(provider_manager.providers)}")
            print(f"Provedores disponíveis: {len(available_providers)}")
            print(f"Provedor primário: {provider_manager.primary_provider}")
            print(f"Primário disponível: {'Sim' if provider_manager.primary_provider in available_providers else 'Não'}")
            print()
            
            print("--- DETALHES DOS PROVEDORES ---")
            for name, provider in provider_manager.providers.items():
                status = "Sim" if provider.is_available() else "Não"
                usage = provider_manager.get_provider_statistics().get(name, {}).get('total_requests', 0)
                enabled = "✓" if provider_manager.config.get('ai', {}).get('providers', {}).get(name, {}).get('enabled', False) else "✗"
                print(f"{enabled} {name}")
                print(f"    Habilitado: {enabled}")
                print(f"    Disponível: {status}")
                print(f"    Uso: {usage} análises")
                print()
            
            return
        
        # Verificar argumentos obrigatórios
        if not args.fontes:
            print("Erro: --fontes é obrigatório")
            parser.print_help()
            return
        
        if not os.path.exists(args.fontes):
            print(f"Erro: Arquivo de fontes não encontrado: {args.fontes}")
            return
        
        # Inicializar parser e gerador
        cobol_parser = CobolParser()
        doc_generator = DocumentationGenerator(args.output)
        
        logger.info("=== INICIANDO PROCESSAMENTO ===")
        logger.info(f"Arquivo de fontes: {args.fontes}")
        logger.info(f"Arquivo de prompts: {args.prompts}")
        logger.info(f"Diretório de saída: {args.output}")
        
        # Processar arquivos
        programs = cobol_parser.parse_programs_file(args.fontes)
        books = []
        
        if args.books and os.path.exists(args.books):
            books = cobol_parser.parse_books_file(args.books)
            logger.info(f"Copybooks carregados: {len(books)}")
        
        if not programs:
            logger.error("Nenhum programa encontrado para processar")
            return
        
        logger.info(f"Programas encontrados: {len(programs)}")
        
        # Processar cada programa
        successful_analyses = 0
        total_tokens = 0
        
        for program in programs:
            logger.info(f"Processando programa: {program.name}")
            
            try:
                # Gerar prompt customizável
                base_prompt = prompt_manager.generate_base_prompt(
                    program.name, 
                    program.code,
                    {"books": books}
                )
                
                # Criar requisição
                from src.providers.base_provider import AIRequest
                request = AIRequest(
                    prompt=base_prompt,
                    context={
                        "program_name": program.name,
                        "program_type": "cobol",
                        "books": [book.name for book in books]
                    }
                )
                
                # Analisar com IA
                if args.provider:
                    response = provider_manager.analyze_with_specific_provider(request, args.provider)
                else:
                    response = provider_manager.analyze(request)
                
                if response.success:
                    # Adicionar referência ao prompt manager na resposta
                    response.prompt_manager = prompt_manager
                    
                    # Gerar documentação
                    doc_path = doc_generator.generate_program_documentation(program, response)
                    
                    if doc_path:
                        successful_analyses += 1
                        total_tokens += response.tokens_used
                        logger.info(f"Análise concluída: {program.name} ({response.tokens_used} tokens)")
                    else:
                        logger.error(f"Falha na geração de documentação: {program.name}")
                else:
                    logger.error(f"Falha na análise: {program.name} - {response.error_message}")
            
            except Exception as e:
                logger.error(f"Erro ao processar {program.name}: {str(e)}")
        
        # Gerar relatório consolidado
        consolidado_path = doc_generator.generate_consolidated_report(
            programs, books, {
                "successful_analyses": successful_analyses,
                "total_tokens": total_tokens,
                "provider_stats": provider_manager.get_provider_statistics(),
                "prompt_config": args.prompts,
                "functional_question": prompt_manager.get_functional_question()
            }
        )
        
        # Limpar histórico de prompts para próxima execução
        prompt_manager.clear_prompt_history()
        
        # Resultado final
        success_rate = (successful_analyses / len(programs)) * 100 if programs else 0
        
        print("=== PROCESSAMENTO CONCLUÍDO ===")
        print(f"Programas processados: {len(programs)}")
        if books:
            print(f"Copybooks processados: {len(books)}")
        print(f"Análises bem-sucedidas: {successful_analyses}/{len(programs)}")
        print(f"Taxa de sucesso: {success_rate:.1f}%")
        print(f"Total de tokens utilizados: {total_tokens}")
        print(f"Pergunta funcional: \"{prompt_manager.get_functional_question()}\"")
        print(f"Arquivos gerados em: {args.output}")
        
        if consolidado_path:
            print(f"Relatório consolidado: {os.path.basename(consolidado_path)}")
        
        logger.info("Processamento concluído com sucesso")
        
    except KeyboardInterrupt:
        logger.info("Processamento interrompido pelo usuário")
        print("\nProcessamento interrompido.")
    except Exception as e:
        logger.error(f"Erro fatal: {str(e)}")
        print(f"Erro: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()

