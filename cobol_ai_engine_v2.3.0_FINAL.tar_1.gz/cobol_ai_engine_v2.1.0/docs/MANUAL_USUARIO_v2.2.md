# Manual do Usuário - COBOL AI Engine v2.2.0

**Versão**: 2.2.0  
**Data**: 10 de Setembro de 2025  
**Status**: Produção - LuzIA Principal com Fallback Garantido

---

## Visão Geral

O COBOL AI Engine v2.2.0 é um sistema avançado de análise de programas COBOL que utiliza múltiplos provedores de Inteligência Artificial para gerar documentação técnica e funcional automaticamente.

### Principais Funcionalidades

- **LuzIA como Provedor Principal**: Integração completa com LuzIA para análises corporativas
- **Sistema de Fallback Inteligente**: Enhanced Mock e Basic garantem 100% de disponibilidade
- **Análise Específica de Código**: Extração e análise de estruturas COBOL reais
- **Faseamento Automático**: Controle inteligente de tokens para análises completas
- **Documentação Rica**: 4 tipos de análise por programa COBOL
- **Pergunta Central Garantida**: "O que este programa faz funcionalmente?" sempre respondida

---

## Instalação Rápida

### 1. Extração do Pacote
```bash
tar -xzf cobol_ai_engine_v2.2.0_FINAL.tar.gz
cd cobol_ai_engine_v2.1.0
```

### 2. Instalação de Dependências
```bash
pip install -r requirements.txt
```

### 3. Teste Imediato
```bash
# Teste básico (sempre funciona)
python main.py --fontes examples/fontes.txt

# Verificar status
python main.py --status
```

---

## Configuração de Provedores

### LuzIA (Provedor Principal)

#### Configuração de Credenciais
```bash
# Variáveis de ambiente obrigatórias
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# Variáveis opcionais para funcionalidades avançadas
export KNOWLEDGE_BASE_ID="sua_knowledge_base"
export GUARDRAIL_ID="seu_guardrail"
export GUARDRAIL_VERSION="versao_guardrail"
```

#### Verificação da Configuração
```bash
# Verificar se LuzIA está disponível
python main.py --status

# Testar conectividade
python main.py --test-providers
```

### Enhanced Mock (Fallback Inteligente)

O Enhanced Mock está sempre disponível e não requer configuração. Ele:
- Analisa código COBOL real
- Gera respostas específicas baseadas no conteúdo
- Responde sempre à pergunta "O que faz funcionalmente?"
- Inclui trechos de código na análise técnica

### Basic (Fallback Final)

O Basic Provider é o fallback final que nunca falha, garantindo 100% de disponibilidade do sistema.

---

## Uso Básico

### Comando Principal
```bash
python main.py [opções]
```

### Opções Principais

#### Análise de Arquivos
```bash
# Análise básica
python main.py --fontes arquivo_programas.txt

# Análise completa com copybooks
python main.py --fontes programas.txt --books copybooks.txt

# Especificar diretório de saída
python main.py --fontes dados.txt --output minha_analise
```

#### Controle de Provedores
```bash
# Forçar provedor específico
python main.py --provider luzia --fontes dados.txt
python main.py --provider enhanced_mock --fontes dados.txt

# Desabilitar fallback (não recomendado)
python main.py --no-fallback --fontes dados.txt
```

#### Controle de Tokens
```bash
# Limitar tokens por análise
python main.py --max-tokens 2000 --fontes dados.txt

# Desabilitar faseamento
python main.py --no-phasing --fontes dados.txt
```

#### Informações do Sistema
```bash
# Status detalhado
python main.py --status

# Versão do sistema
python main.py --version

# Teste de todos os provedores
python main.py --test-providers
```

---

## Exemplos Práticos

### Exemplo 1: Análise Básica
```bash
# Comando
python main.py --fontes examples/fontes.txt

# Resultado
=== PROCESSAMENTO CONCLUÍDO ===
Programas processados: 1
Taxa de sucesso: 100.0%
Total de tokens utilizados: 1301
Tempo de processamento: 0.80s
Arquivos gerados em: output
```

### Exemplo 2: Análise com LuzIA
```bash
# Configurar credenciais
export LUZIA_CLIENT_ID="seu_id"
export LUZIA_CLIENT_SECRET="seu_secret"

# Executar análise
python main.py --fontes dados_producao.txt --books copybooks.txt

# LuzIA será usado automaticamente como principal
```

### Exemplo 3: Análise com Configuração Específica
```bash
# Usar configuração personalizada
python main.py --config config/config_luzia_primary.yaml \
               --fontes programas_bacen.txt \
               --output analise_bacen \
               --max-tokens 4000
```

---

## Arquivos de Entrada

### Formato dos Arquivos

#### Arquivo de Programas (--fontes)
```
VMEMBER NAME=LHAN0542
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LHAN0542.
       ...código COBOL...

VMEMBER NAME=LHAN0705
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LHAN0705.
       ...código COBOL...
```

#### Arquivo de Copybooks (--books)
```
VMEMBER NAME=COPYBOOK1
       01 ESTRUTURA-DADOS.
          05 CAMPO1 PIC X(10).
          05 CAMPO2 PIC 9(5).
       ...definições...

VMEMBER NAME=COPYBOOK2
       ...outras definições...
```

### Preparação dos Arquivos

1. **Extrair do mainframe** usando ferramentas apropriadas
2. **Manter formato VMEMBER** para identificação correta
3. **Incluir código completo** para análise precisa
4. **Separar programas e copybooks** em arquivos distintos

---

## Arquivos de Saída

### Estrutura de Saída
```
output/
├── LHAN0542.md                    # Documentação do programa
├── LHAN0705.md                    # Documentação do programa
├── relatorio_consolidado.md       # Relatório geral
└── system_status_report.json      # Status do sistema
```

### Conteúdo da Documentação

#### Para cada programa (ex: LHAN0542.md):

1. **Informações Básicas**
   - Nome, linhas de código, tamanho
   - Estrutura COBOL identificada
   - Arquivos e copybooks utilizados

2. **Análise Funcional**
   - **Resposta à pergunta central**: "O que este programa faz funcionalmente?"
   - Objetivo principal e processo de negócio
   - Regras de negócio identificadas
   - Fluxo de dados e impacto no sistema

3. **Análise Técnica**
   - Divisões e seções COBOL
   - Estruturas de dados principais
   - **Trechos de código relevantes**
   - Algoritmos e padrões de design

4. **Regras de Negócio**
   - Validações de entrada
   - Regras de processamento
   - Controles de qualidade
   - Conformidade regulatória

5. **Metadados**
   - Provedor utilizado
   - Tokens consumidos
   - Timestamp da análise
   - Informações de rastreabilidade

---

## Configuração Avançada

### Arquivo de Configuração

#### config/config.yaml (Principal)
```yaml
ai:
  # LuzIA como provedor primário
  primary_provider: "luzia"
  
  # Fallback garantido
  fallback_providers: 
    - "enhanced_mock"
    - "basic"
  
  # Configurações globais
  enable_fallback: true
  global_timeout: 120
  global_max_tokens: 4000
  
  providers:
    luzia:
      enabled: true
      client_id: "${LUZIA_CLIENT_ID}"
      client_secret: "${LUZIA_CLIENT_SECRET}"
      model: "aws-claude-1-3-sonnet-exp"
      use_knowledge_base: true
      enable_phasing: true
      max_tokens_per_phase: 2000
    
    enhanced_mock:
      enabled: true
      cobol_analysis_enabled: true
      specific_responses: true
    
    basic:
      enabled: true
```

### Personalização por Ambiente

#### Desenvolvimento
```yaml
ai:
  primary_provider: "enhanced_mock"
  fallback_providers: ["basic"]
```

#### Homologação
```yaml
ai:
  primary_provider: "luzia"
  fallback_providers: ["enhanced_mock", "basic"]
  providers:
    luzia:
      timeout: 60
      max_tokens: 2000
```

#### Produção
```yaml
ai:
  primary_provider: "luzia"
  fallback_providers: ["enhanced_mock", "basic"]
  providers:
    luzia:
      timeout: 120
      max_tokens: 4000
      use_knowledge_base: true
      performance_config: "optimized"
```

---

## Monitoramento e Logs

### Logs do Sistema

#### Localização
```
logs/cobol_ai_engine.log
```

#### Configuração de Log Level
```bash
# Debug detalhado
python main.py --log-level DEBUG --fontes dados.txt

# Apenas erros
python main.py --log-level ERROR --fontes dados.txt
```

### Métricas de Performance

#### Status em Tempo Real
```bash
python main.py --status
```

#### Saída de Exemplo:
```
=== STATUS DO SISTEMA ===
COBOL AI Engine v2.2.0
Timestamp: 10/09/2025 06:21:17

--- PROVEDORES ---
Total de provedores: 3
Provedores disponíveis: 2
Provedor primário: luzia
Primário disponível: Não

--- DETALHES DOS PROVEDORES ---
✗ luzia
    Habilitado: ✓
    Disponível: Não
    Uso: 0 análises
✓ enhanced_mock
    Habilitado: ✓
    Disponível: Sim
    Uso: 5 análises
✓ basic
    Habilitado: ✓
    Disponível: Sim
    Uso: 0 análises

--- ESTATÍSTICAS ---
Total de requisições: 5
Requisições bem-sucedidas: 5
Taxa de sucesso: 100.0%
```

---

## Solução de Problemas

### Problemas Comuns

#### 1. LuzIA Indisponível
**Sintoma**: "Provedor luzia não disponível"
**Solução**:
```bash
# Verificar credenciais
echo $LUZIA_CLIENT_ID
echo $LUZIA_CLIENT_SECRET

# Testar conectividade
python main.py --test-providers

# Sistema usa fallback automaticamente
```

#### 2. Erro de Dependências
**Sintoma**: "ModuleNotFoundError"
**Solução**:
```bash
# Reinstalar dependências
pip install -r requirements.txt

# Verificar versão Python
python --version  # Deve ser 3.8+
```

#### 3. Arquivo de Entrada Inválido
**Sintoma**: "Nenhum programa COBOL encontrado"
**Solução**:
```bash
# Verificar formato do arquivo
head -20 arquivo_fontes.txt

# Deve conter VMEMBER NAME=
# Seguido do código COBOL
```

#### 4. Timeout de Análise
**Sintoma**: "Timeout na análise"
**Solução**:
```bash
# Reduzir tokens por análise
python main.py --max-tokens 2000 --fontes dados.txt

# Desabilitar faseamento se necessário
python main.py --no-phasing --fontes dados.txt
```

### Logs de Diagnóstico

#### Habilitar Debug
```bash
python main.py --log-level DEBUG --fontes dados.txt 2>&1 | tee debug.log
```

#### Verificar Logs
```bash
# Últimas 50 linhas
tail -50 logs/cobol_ai_engine.log

# Filtrar erros
grep ERROR logs/cobol_ai_engine.log
```

---

## Melhores Práticas

### Para Análise de Produção

1. **Configurar LuzIA**: Use LuzIA como principal para análises corporativas
2. **Manter Fallback**: Sempre mantenha Enhanced Mock habilitado
3. **Monitorar Logs**: Acompanhe logs para identificar problemas
4. **Testar Regularmente**: Execute `--test-providers` periodicamente

### Para Performance

1. **Usar Faseamento**: Mantenha `enable_phasing: true` para análises grandes
2. **Controlar Tokens**: Ajuste `max_tokens` conforme necessário
3. **Configurar Timeout**: Ajuste timeout baseado na latência da rede
4. **Batch Processing**: Processe múltiplos arquivos em lotes

### Para Qualidade

1. **Preparar Arquivos**: Garanta formato correto dos arquivos de entrada
2. **Incluir Copybooks**: Sempre forneça copybooks quando disponíveis
3. **Revisar Saídas**: Valide documentação gerada antes de usar
4. **Manter Atualizado**: Use sempre a versão mais recente

---

## Suporte e Recursos

### Documentação Adicional
- `docs/MANUAL_CONFIGURACAO_v2.2.md` - Configuração detalhada
- `docs/MANUAL_INSTALACAO_WINDOWS.md` - Instalação no Windows
- `README.md` - Visão geral técnica

### Exemplos Práticos
- `demo_luzia_example.py` - Demonstração completa
- `examples/` - Arquivos de teste
- `tests/` - Testes automatizados

### Arquivos de Configuração
- `config/config.yaml` - Configuração principal
- `config/config_luzia_primary.yaml` - Configuração completa LuzIA

---

## Changelog v2.2.0

### Novas Funcionalidades
- LuzIA configurado como provedor principal por padrão
- Sistema de fallback aprimorado com Enhanced Mock
- Análise específica de código COBOL melhorada
- Documentação atualizada com exemplos práticos
- Testes completos validados

### Melhorias
- Performance otimizada do sistema de fallback
- Logs mais detalhados para diagnóstico
- Configuração simplificada para LuzIA
- Documentação técnica aprimorada

### Correções
- Compatibilidade com urllib3 mais recente
- Tratamento robusto de erros de conectividade
- Validação aprimorada de arquivos de entrada

---

**COBOL AI Engine v2.2.0 - Sistema Completo e Validado para Produção**

