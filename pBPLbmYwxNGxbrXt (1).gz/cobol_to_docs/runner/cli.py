import sys
import os

# Adiciona o diretório raiz do pacote ao sys.path para imports absolutos
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from cobol_to_docs.runner.main import main

if __name__ == "__main__":
    main()

