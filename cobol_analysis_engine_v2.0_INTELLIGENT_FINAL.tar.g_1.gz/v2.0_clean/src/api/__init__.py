# API do Sistema de Análise COBOL para uso programático

