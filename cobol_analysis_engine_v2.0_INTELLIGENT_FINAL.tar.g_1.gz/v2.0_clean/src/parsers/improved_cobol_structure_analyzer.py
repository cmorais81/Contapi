import re
import logging
from typing import Dict, List, Any

class ImprovedCOBOLStructureAnalyzer:
    """Analisador de estrutura COBOL aprimorado para extrair hierarquia e fluxo de controle."""

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.section_pattern = re.compile(r'^([A-Z0-9\-]+)\s+SECTION\.', re.IGNORECASE)
        self.paragraph_pattern = re.compile(r'^([A-Z0-9\-]+)\.')
        self.perform_pattern = re.compile(r'PERFORM\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.goto_pattern = re.compile(r'GO\s+TO\s+([A-Z0-9\-]+)', re.IGNORECASE)

    def analyze(self, lines: List[str]) -> Dict[str, Any]:
        """Analisa a estrutura do programa COBOL a partir de uma lista de linhas."""
        structure = {
            "program_id": self._extract_program_id(lines),
            "divisions": [],
            "sections": {},
            "paragraphs": {},
            "control_flow": []
        }

        in_procedure_division = False
        current_section = None
        current_paragraph = None

        for i, line in enumerate(lines):
            if len(line) < 7 or line[6] == '*':
                continue

            content_area = line[7:].strip()
            if not content_area:
                continue

            if "PROCEDURE DIVISION" in line.upper():
                in_procedure_division = True
                structure["divisions"].append("PROCEDURE")
                current_section = "DEFAULT-SECTION"
                structure["sections"][current_section] = []
                continue

            if not in_procedure_division:
                if "IDENTIFICATION DIVISION" in line.upper(): structure["divisions"].append("IDENTIFICATION")
                if "ENVIRONMENT DIVISION" in line.upper(): structure["divisions"].append("ENVIRONMENT")
                if "DATA DIVISION" in line.upper(): structure["divisions"].append("DATA")
                continue

            # Estamos na PROCEDURE DIVISION
            section_match = self.section_pattern.match(content_area)
            if section_match:
                current_section = section_match.group(1)
                if current_section not in structure["sections"]:
                    structure["sections"][current_section] = []
                current_paragraph = None # Reseta o parágrafo ao encontrar nova seção
                continue

            # Parágrafos devem começar na Area A
            if not line[7].isspace():
                paragraph_match = self.paragraph_pattern.match(content_area)
                if paragraph_match:
                    paragraph_name = paragraph_match.group(1)
                    # Evitar confundir com sentenças que terminam com ponto
                    if " " not in paragraph_name and paragraph_name.upper() != "SECTION":
                        current_paragraph = paragraph_name
                        if current_paragraph not in structure["paragraphs"]:
                            structure["paragraphs"][current_paragraph] = {
                                "section": current_section,
                                "calls_to": [],
                                "line_start": i + 1
                            }
                            if current_section:
                                structure["sections"][current_section].append(current_paragraph)
                        # O resto da linha pode conter código
                        code_on_same_line = content_area[len(paragraph_name)+1:].strip()
                        if code_on_same_line:
                            self._find_calls(code_on_same_line, structure["paragraphs"][current_paragraph]["calls_to"])
                        continue

            if current_paragraph:
                self._find_calls(content_area, structure["paragraphs"][current_paragraph]["calls_to"])

        structure["divisions"] = sorted(list(set(structure["divisions"])))
        self._build_control_flow(structure)
        return structure

    def _find_calls(self, line: str, calls_list: List[str]):
        """Encontra chamadas PERFORM e GO TO em uma linha de código."""
        perform_match = self.perform_pattern.search(line)
        if perform_match:
            calls_list.append(perform_match.group(1))

        goto_match = self.goto_pattern.search(line)
        if goto_match:
            calls_list.append(goto_match.group(1))

    def _extract_program_id(self, lines: List[str]) -> str:
        """Extrai o PROGRAM-ID da IDENTIFICATION DIVISION."""
        for line in lines:
            if "PROGRAM-ID" in line.upper():
                match = re.search(r"PROGRAM-ID\.\s*(\w+)", line, re.IGNORECASE)
                if match:
                    return match.group(1)
        return "UNKNOWN"

    def _build_control_flow(self, structure: Dict[str, Any]):
        """Constrói um fluxo de controle simplificado."""
        if not structure["paragraphs"]:
            return

        # Tenta encontrar o primeiro parágrafo da primeira seção da procedure
        entry_point = None
        if "DEFAULT-SECTION" in structure["sections"] and structure["sections"]["DEFAULT-SECTION"]:
            entry_point = structure["sections"]["DEFAULT-SECTION"][0]
        elif structure["sections"]:
            first_section = next(iter(structure["sections"]))
            if structure["sections"][first_section]:
                entry_point = structure["sections"][first_section][0]

        if not entry_point:
            entry_point = next(iter(structure["paragraphs"])) # Fallback para o primeiro parágrafo encontrado

        visited = set()
        self._traverse_flow(entry_point, structure, visited)
        structure["control_flow"] = visited # A ordem não é garantida, mas mostra os parágrafos alcançáveis

    def _traverse_flow(self, paragraph: str, structure: Dict[str, Any], visited: set):
        """Percorre o fluxo de controle recursivamente."""
        if paragraph in visited or paragraph not in structure["paragraphs"]:
            return

        visited.add(paragraph)
        for called_paragraph in structure["paragraphs"][paragraph]["calls_to"]:
            self._traverse_flow(called_paragraph, structure, visited)

