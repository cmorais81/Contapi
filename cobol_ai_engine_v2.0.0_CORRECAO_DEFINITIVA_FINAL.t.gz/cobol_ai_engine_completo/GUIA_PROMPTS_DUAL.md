# Guia dos Sistemas de Prompts Dual

## Visão Geral

O sistema oferece **duas metodologias** diferentes de análise de programas COBOL. Você pode escolher qual usar alterando a configuração no arquivo `config/config.yaml`.

## Opções Disponíveis

### 1. Prompts Originais (`prompts_original.yaml`)
**Metodologia**: Análise técnica tradicional  
**Foco**: Documentação técnica completa e estruturada  
**Ideal para**: Análises detalhadas, documentação de sistemas, manutenção

#### Características:
- ✅ Análise funcional abrangente
- ✅ Arquitetura técnica detalhada  
- ✅ Mapeamento de regras de negócio
- ✅ Estruturas de dados completas
- ✅ Interfaces e integrações
- ✅ Considerações de performance
- ✅ Guia de manutenção
- ✅ Avaliação de qualidade de código

#### Formato de Saída:
- Documentação em Markdown estruturada
- Seções organizadas por prioridade
- Análise balanceada técnica/negócio
- Recomendações de melhoria

### 2. DOC-LEGADO PRO (`prompts_doc_legado_pro.yaml`)
**Metodologia**: Análise de sistemas legados com foco em modernização  
**Foco**: Extração de regras funcionais e especificações técnicas  
**Ideal para**: Modernização, migração, documentação de legado

#### Características:
- ✅ Documento Funcional (validação com negócio)
- ✅ Especificação Técnica (programadores/arquitetura)
- ✅ Artefatos visuais (fluxogramas/diagramas)
- ✅ Matrizes (CRUD, DMN)
- ✅ Rastreabilidade (arquivo/linha/objeto)
- ✅ Lacunas e suposições identificadas
- ✅ Próximos passos estruturados
- ✅ Trabalho evolutivo por rodadas

#### Formato de Saída:
- Resumo executivo
- Documento funcional versionado
- Especificação técnica versionada
- Diagramas em Mermaid/PlantUML
- Tabelas estruturadas
- Plano de ação

## Como Escolher

### Use **Prompts Originais** quando:
- Precisar de documentação técnica completa
- Foco em manutenção de sistemas existentes
- Análise detalhada de arquitetura
- Avaliação de qualidade de código
- Documentação para equipes técnicas

### Use **DOC-LEGADO PRO** quando:
- Estiver modernizando sistemas legados
- Precisar extrair regras de negócio
- Foco em migração/reescrita
- Documentação para stakeholders de negócio
- Trabalho colaborativo por etapas

## Como Alterar

### Método 1: Editar Configuração
Edite o arquivo `config/config.yaml`:

```yaml
ai:
  prompt:
    # Para usar prompts originais:
    prompts_file: "config/prompts_original.yaml"
    
    # Para usar DOC-LEGADO PRO:
    # prompts_file: "config/prompts_doc_legado_pro.yaml"
```

### Método 2: Linha de Comando (se implementado)
```bash
# Usar prompts originais
python3 main.py --prompts original --fontes programa.cbl

# Usar DOC-LEGADO PRO  
python3 main.py --prompts doc-legado-pro --fontes programa.cbl
```

## Arquivos de Configuração

```
config/
├── prompts_original.yaml      # Metodologia original (padrão)
├── prompts_doc_legado_pro.yaml # Metodologia DOC-LEGADO PRO
└── config.yaml                # Configuração principal
```

## Exemplo de Uso

### Cenário 1: Documentação de Sistema Existente
```yaml
# config/config.yaml
prompts_file: "config/prompts_original.yaml"
```

**Resultado**: Documentação técnica completa, análise de arquitetura, guia de manutenção

### Cenário 2: Modernização de Sistema Legado
```yaml
# config/config.yaml  
prompts_file: "config/prompts_doc_legado_pro.yaml"
```

**Resultado**: Extração de regras funcionais, especificações para reescrita, diagramas de fluxo

## Compatibilidade

Ambos os sistemas de prompts são **totalmente compatíveis** com:
- ✅ Provider LuzIA corrigido
- ✅ Sistema de fallback
- ✅ Análise multi-modelo
- ✅ Geração de relatórios
- ✅ Exportação HTML/PDF

## Recomendações

1. **Teste ambos** com o mesmo programa para comparar resultados
2. **Use prompts originais** como padrão para a maioria dos casos
3. **Use DOC-LEGADO PRO** para projetos específicos de modernização
4. **Documente** qual metodologia foi usada em cada análise

---

**Nota**: A escolha da metodologia não afeta o funcionamento do provider LuzIA corrigido. Ambas funcionam perfeitamente com o formato do `teste.py` implementado.
