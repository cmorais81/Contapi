# Relatório Comparativo - Análise Multi-Modelo

**Data:** 23/09/2025 às 07:54:24
**Sistema:** COBOL AI Engine v2.0.0

## Resumo Executivo

**Programas Analisados:** 1
**Modelos Utilizados:** 2 (aws_claude_3_5_sonnet, claude_3_5_sonnet)
**Total de Análises:** 2

## Estatísticas por Modelo

| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios |
|--------|----------|--------|-----------------|---------------|
| aws_claude_3_5_sonnet | 1 | 0 | 100.0% | 531 |
| claude_3_5_sonnet | 1 | 0 | 100.0% | 531 |

## Detalhes por Programa

### PROGRAMA

| Modelo | Status | Tokens | Qualidade | Diretório |
|--------|--------|--------|-----------|----------|
| aws_claude_3_5_sonnet | Sucesso | 531 | Baixa | model_aws_claude_3_5_sonnet |
| claude_3_5_sonnet | Sucesso | 531 | Baixa | model_claude_3_5_sonnet |

## Recomendações

**Modelo Recomendado:** claude_3_5_sonnet (melhor taxa de sucesso)

**Modelo Mais Detalhado:** claude_3_5_sonnet (maior média de tokens)

### Uso Recomendado por Cenário

- **Análise Rápida:** Use o modelo com melhor taxa de sucesso
- **Análise Detalhada:** Use o modelo com maior média de tokens
- **Análise Crítica:** Execute com múltiplos modelos e compare resultados
- **Produção:** Use o modelo mais estável baseado nas estatísticas

---
**Relatório gerado automaticamente pelo COBOL AI Engine v2.0.0**
