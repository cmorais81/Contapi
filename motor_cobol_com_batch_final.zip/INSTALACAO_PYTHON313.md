# Guia de Instalação - Python 3.13

## Visão Geral

Este guia fornece instruções detalhadas para instalar e configurar o Motor de Documentação COBOL com Python 3.13, incluindo todas as dependências e configurações necessárias.

---

## 🐍 Instalação do Python 3.13

### Windows

#### Opção 1: Download Oficial (Recomendado)
1. **Acesse**: https://www.python.org/downloads/
2. **Download**: Python 3.13.x (versão mais recente)
3. **Execute** o instalador
4. **Marque**: "Add Python to PATH"
5. **Marque**: "Install for all users"
6. **Clique**: "Install Now"

#### Opção 2: Microsoft Store
1. **Abra**: Microsoft Store
2. **Busque**: "Python 3.13"
3. **Instale**: Python 3.13

#### Opção 3: Chocolatey
```powershell
# Instalar Chocolatey (se não tiver)
Set-ExecutionPolicy Bypass -Scope Process -Force
iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))

# Instalar Python 3.13
choco install python --version=3.13.0
```

### macOS

#### Opção 1: Download Oficial
1. **Acesse**: https://www.python.org/downloads/
2. **Download**: Python 3.13.x para macOS
3. **Execute** o instalador .pkg
4. **Siga** as instruções do instalador

#### Opção 2: Homebrew (Recomendado)
```bash
# Instalar Homebrew (se não tiver)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Instalar Python 3.13
brew install python@3.13

# Criar link simbólico
brew link python@3.13
```

#### Opção 3: pyenv
```bash
# Instalar pyenv
brew install pyenv

# Instalar Python 3.13
pyenv install 3.13.0
pyenv global 3.13.0
```

### Linux (Ubuntu/Debian)

#### Opção 1: Repositório Oficial (Ubuntu 24.04+)
```bash
# Atualizar repositórios
sudo apt update

# Instalar Python 3.13
sudo apt install python3.13 python3.13-venv python3.13-pip

# Criar link simbólico (opcional)
sudo ln -sf /usr/bin/python3.13 /usr/bin/python3
```

#### Opção 2: PPA (Ubuntu/Debian)
```bash
# Adicionar PPA deadsnakes
sudo add-apt-repository ppa:deadsnakes/ppa
sudo apt update

# Instalar Python 3.13
sudo apt install python3.13 python3.13-venv python3.13-pip python3.13-dev
```

#### Opção 3: Compilar do Código Fonte
```bash
# Dependências para compilação
sudo apt install build-essential zlib1g-dev libncurses5-dev libgdbm-dev \
                 libnss3-dev libssl-dev libreadline-dev libffi-dev \
                 libsqlite3-dev wget libbz2-dev

# Download do código fonte
cd /tmp
wget https://www.python.org/ftp/python/3.13.0/Python-3.13.0.tgz
tar -xf Python-3.13.0.tgz
cd Python-3.13.0

# Configurar e compilar
./configure --enable-optimizations
make -j$(nproc)
sudo make altinstall

# Verificar instalação
python3.13 --version
```

### Linux (CentOS/RHEL/Fedora)

#### CentOS/RHEL 8+
```bash
# Habilitar EPEL
sudo dnf install epel-release

# Instalar Python 3.13
sudo dnf install python3.13 python3.13-pip python3.13-devel
```

#### Fedora
```bash
# Instalar Python 3.13
sudo dnf install python3.13 python3.13-pip python3.13-devel
```

---

## 🔧 Configuração do Ambiente

### Verificar Instalação

```bash
# Verificar versão do Python
python3.13 --version
# ou
python --version

# Verificar pip
python3.13 -m pip --version
```

### Criar Ambiente Virtual

```bash
# Criar ambiente virtual
python3.13 -m venv cobol_engine_env

# Ativar ambiente virtual
# Linux/macOS:
source cobol_engine_env/bin/activate

# Windows:
cobol_engine_env\Scripts\activate

# Verificar ambiente ativo
which python  # Linux/macOS
where python  # Windows
```

### Atualizar pip e setuptools

```bash
# Atualizar pip
python -m pip install --upgrade pip

# Instalar/atualizar setuptools e wheel
python -m pip install --upgrade setuptools wheel
```

---

## 📦 Instalação do Motor COBOL

### Opção 1: Instalação Direta

```bash
# Navegar para o diretório do projeto
cd cobol_documentation_engine

# Instalar dependências
pip install -r requirements.txt

# Instalar o motor em modo desenvolvimento
pip install -e .
```

### Opção 2: Instalação via setup.py

```bash
# Instalar usando setup.py
python setup.py install

# Ou em modo desenvolvimento
python setup.py develop
```

### Opção 3: Instalação via pip (local)

```bash
# Instalar do diretório local
pip install .

# Ou em modo editável
pip install -e .
```

---

## 🔍 Verificação da Instalação

### Teste Básico

```bash
# Testar importação dos módulos principais
python -c "
import sys
print(f'Python version: {sys.version}')

# Testar importações
try:
    import openai
    print('✓ OpenAI library imported successfully')
except ImportError as e:
    print(f'✗ OpenAI import failed: {e}')

try:
    import yaml
    print('✓ PyYAML imported successfully')
except ImportError as e:
    print(f'✗ PyYAML import failed: {e}')

try:
    import jinja2
    print('✓ Jinja2 imported successfully')
except ImportError as e:
    print(f'✗ Jinja2 import failed: {e}')

print('\\n✓ Basic dependencies check completed')
"
```

### Teste do Motor

```bash
# Testar CLI
python src/enhanced_cli.py --help

# Testar análise básica
python src/enhanced_cli.py analyze tests/sample_cobol/sample_program.cbl --format yaml

# Testar descoberta de plugins
python src/enhanced_cli.py plugins discover
```

### Teste de Integração com IA

```bash
# Configurar chave da API (temporariamente)
export OPENAI_API_KEY="sk-sua_chave_aqui"

# Testar conexão com OpenAI
python -c "
import os
from openai import OpenAI

try:
    client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
    response = client.chat.completions.create(
        model='gpt-3.5-turbo',
        messages=[{'role': 'user', 'content': 'Hello!'}],
        max_tokens=5
    )
    print('✓ OpenAI API connection successful')
    print(f'Response: {response.choices[0].message.content}')
except Exception as e:
    print(f'✗ OpenAI API connection failed: {e}')
"
```

---

## 🛠️ Configuração Avançada

### Configuração de Desenvolvimento

```bash
# Instalar dependências de desenvolvimento
pip install -e ".[dev]"

# Instalar ferramentas de qualidade de código
pip install black flake8 mypy pytest-cov

# Configurar pre-commit hooks (opcional)
pip install pre-commit
pre-commit install
```

### Configuração de Produção

```bash
# Instalar apenas dependências de produção
pip install --no-dev -r requirements.txt

# Configurar variáveis de ambiente
cp .env.example .env
# Editar .env com suas configurações

# Testar em modo produção
python src/enhanced_cli.py analyze programa.cbl --output ./results
```

### Configuração de Performance

```bash
# Instalar aceleradores opcionais
pip install uvloop  # Linux/macOS apenas
pip install orjson  # JSON mais rápido

# Configurar cache
export COBOL_ENGINE_CACHE_ENABLED=true
export COBOL_ENGINE_CACHE_TTL=3600
```

---

## 🐳 Instalação com Docker

### Dockerfile

```dockerfile
FROM python:3.13-slim

# Instalar dependências do sistema
RUN apt-get update && apt-get install -y \
    build-essential \
    git \
    && rm -rf /var/lib/apt/lists/*

# Configurar diretório de trabalho
WORKDIR /app

# Copiar arquivos de dependências
COPY requirements.txt pyproject.toml ./

# Instalar dependências Python
RUN pip install --no-cache-dir -r requirements.txt

# Copiar código fonte
COPY . .

# Instalar o motor
RUN pip install -e .

# Configurar usuário não-root
RUN useradd -m -u 1000 coboluser
USER coboluser

# Comando padrão
CMD ["python", "src/enhanced_cli.py", "--help"]
```

### Docker Compose

```yaml
version: '3.8'

services:
  cobol-engine:
    build: .
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - OPENAI_MODEL=gpt-4
    volumes:
      - ./input:/app/input
      - ./output:/app/output
    command: python src/enhanced_cli.py analyze /app/input/programa.cbl --output /app/output
```

### Comandos Docker

```bash
# Construir imagem
docker build -t cobol-engine .

# Executar container
docker run -it --rm \
  -e OPENAI_API_KEY="sua_chave_aqui" \
  -v $(pwd)/input:/app/input \
  -v $(pwd)/output:/app/output \
  cobol-engine python src/enhanced_cli.py analyze /app/input/programa.cbl --output /app/output

# Usar docker-compose
docker-compose up
```

---

## 🔧 Solução de Problemas

### Problemas Comuns

#### Erro: "python3.13: command not found"

```bash
# Verificar se Python está no PATH
echo $PATH

# Adicionar ao PATH (Linux/macOS)
export PATH="/usr/local/bin/python3.13:$PATH"

# Windows: Adicionar via Painel de Controle > Sistema > Variáveis de Ambiente
```

#### Erro: "pip: command not found"

```bash
# Instalar pip manualmente
python3.13 -m ensurepip --upgrade

# Ou baixar get-pip.py
curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
python3.13 get-pip.py
```

#### Erro: "Permission denied"

```bash
# Usar --user para instalação local
pip install --user -r requirements.txt

# Ou usar ambiente virtual (recomendado)
python3.13 -m venv venv
source venv/bin/activate  # Linux/macOS
pip install -r requirements.txt
```

#### Erro: "SSL Certificate verify failed"

```bash
# Atualizar certificados (macOS)
/Applications/Python\ 3.13/Install\ Certificates.command

# Linux: Atualizar ca-certificates
sudo apt update && sudo apt install ca-certificates

# Ou usar pip com --trusted-host (temporário)
pip install --trusted-host pypi.org --trusted-host pypi.python.org -r requirements.txt
```

### Problemas de Dependências

#### Conflitos de Versão

```bash
# Verificar dependências instaladas
pip list

# Verificar conflitos
pip check

# Resolver conflitos
pip install --upgrade --force-reinstall -r requirements.txt
```

#### Problemas de Compilação

```bash
# Instalar dependências de compilação (Ubuntu/Debian)
sudo apt install build-essential python3.13-dev

# CentOS/RHEL
sudo dnf groupinstall "Development Tools"
sudo dnf install python3.13-devel

# macOS
xcode-select --install
```

---

## 📊 Verificação Final

### Checklist de Instalação

```bash
# Script de verificação completa
python -c "
import sys
import subprocess
import importlib

print(f'Python version: {sys.version}')
print(f'Python executable: {sys.executable}')

# Verificar dependências principais
dependencies = [
    'openai', 'yaml', 'jinja2', 'click', 
    'colorama', 'rich', 'dotenv', 'requests'
]

for dep in dependencies:
    try:
        importlib.import_module(dep.replace('-', '_'))
        print(f'✓ {dep}')
    except ImportError:
        print(f'✗ {dep} - MISSING')

# Verificar comandos CLI
try:
    result = subprocess.run([sys.executable, 'src/enhanced_cli.py', '--help'], 
                          capture_output=True, text=True, timeout=10)
    if result.returncode == 0:
        print('✓ CLI working')
    else:
        print('✗ CLI failed')
except Exception as e:
    print(f'✗ CLI error: {e}')

print('\\n✓ Installation verification completed')
"
```

### Teste de Funcionalidade Completa

```bash
# Teste completo do sistema
echo "Testando funcionalidade completa..."

# 1. Análise básica
python src/enhanced_cli.py analyze tests/sample_cobol/sample_program.cbl --format json > /tmp/test_output.json
if [ $? -eq 0 ]; then
    echo "✓ Análise básica funcionando"
else
    echo "✗ Análise básica falhou"
fi

# 2. Plugins
python src/enhanced_cli.py plugins discover
if [ $? -eq 0 ]; then
    echo "✓ Sistema de plugins funcionando"
else
    echo "✗ Sistema de plugins falhou"
fi

# 3. Análise com plugins
python src/enhanced_cli.py analyze tests/sample_cobol/sample_program.cbl --plugins security_analyzer --format yaml > /tmp/test_plugins.yaml
if [ $? -eq 0 ]; then
    echo "✓ Análise com plugins funcionando"
else
    echo "✗ Análise com plugins falhou"
fi

echo "✓ Teste de funcionalidade completo"
```

---

## 🚀 Próximos Passos

### Configuração Inicial

1. **Configure variáveis de ambiente**:
   ```bash
   cp .env.example .env
   # Edite .env com suas configurações
   ```

2. **Configure integração com IA**:
   - Siga o guia `INTEGRACAO_IA.md`
   - Configure chave OpenAI
   - Teste conectividade

3. **Execute primeiro teste**:
   ```bash
   python src/enhanced_cli.py analyze tests/sample_cobol/sample_program.cbl
   ```

### Desenvolvimento

1. **Instale dependências de desenvolvimento**:
   ```bash
   pip install -e ".[dev]"
   ```

2. **Execute testes**:
   ```bash
   pytest tests/ -v
   ```

3. **Configure IDE** (VS Code, PyCharm, etc.)

### Produção

1. **Configure ambiente de produção**
2. **Configure monitoramento**
3. **Configure backup de configurações**
4. **Documente procedimentos específicos**

---

**Guia de Instalação Python 3.13 - Motor de Documentação COBOL**  
**Versão**: 1.0.0  
**Compatível com**: Python 3.11+, 3.12, 3.13

