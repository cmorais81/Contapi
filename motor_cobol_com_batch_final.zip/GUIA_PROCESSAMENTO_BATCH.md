# Guia de Processamento em Lote - Motor COBOL

## Visão Geral

O Motor de Documentação COBOL agora suporta **processamento em lote** para analisar múltiplos programas COBOL de uma só vez. Esta funcionalidade é ideal para:

- **Análise de portfolios** completos de sistemas legacy
- **Auditoria de segurança** em massa
- **Avaliação de modernização** de sistemas inteiros
- **Relatórios consolidados** de qualidade de código

---

## 🚀 Funcionalidades do Processamento em Lote

### **Entrada Suportada**
- **Arquivos ZIP** contendo programas COBOL
- **Diretórios** com arquivos COBOL (busca recursiva)
- **Múltiplos formatos**: .cbl, .cob, .cobol, .txt

### **Processamento**
- **Paralelo ou sequencial** (configurável)
- **Plugins personalizáveis** (segurança, performance, migração)
- **Documentação com IA** (opcional)
- **Tratamento robusto de erros**

### **Saída**
- **Análises individuais** (JSON por arquivo)
- **Relatório consolidado** (Markdown)
- **Estatísticas detalhadas** de processamento
- **Métricas de qualidade** do portfolio

---

## 📋 Comando Batch

### **Sintaxe Básica**
```bash
python src/enhanced_cli.py batch <entrada> --output <saída> [opções]
```

### **Parâmetros**

#### **Obrigatórios**
- `<entrada>`: Arquivo ZIP ou diretório com programas COBOL
- `--output <dir>`: Diretório onde salvar os resultados

#### **Opcionais**
- `--plugins <lista>`: Plugins específicos para executar
- `--enable-ai`: Habilitar documentação com IA
- `--parallel`: Processamento paralelo (padrão: true)
- `--max-workers <n>`: Número máximo de workers paralelos (padrão: 4)
- `--recursive`: Busca recursiva em diretórios (padrão: true)
- `--format <tipo>`: Formato de saída individual (json, yaml, markdown)

---

## 🎯 Exemplos Práticos

### **1. Análise Básica de ZIP**
```bash
# Análise simples de um portfolio
python src/enhanced_cli.py batch portfolio_cobol.zip \
  --output ./analise_portfolio
```

### **2. Análise Completa com Plugins**
```bash
# Análise com segurança e performance
python src/enhanced_cli.py batch sistema_financeiro.zip \
  --output ./auditoria_completa \
  --plugins security_analyzer performance_analyzer migration_analyzer
```

### **3. Análise de Diretório com IA**
```bash
# Análise de diretório com documentação IA
python src/enhanced_cli.py batch /caminho/para/cobol/ \
  --output ./docs_ia \
  --enable-ai \
  --recursive
```

### **4. Processamento Sequencial**
```bash
# Para sistemas com recursos limitados
python src/enhanced_cli.py batch portfolio.zip \
  --output ./resultados \
  --parallel false \
  --plugins security_analyzer
```

### **5. Análise Focada em Performance**
```bash
# Foco específico em otimização
python src/enhanced_cli.py batch sistema_batch.zip \
  --output ./otimizacao \
  --plugins performance_analyzer \
  --max-workers 8
```

---

## 📊 Resultados Gerados

### **Estrutura de Saída**
```
output_directory/
├── consolidated_report.md          # Relatório consolidado
├── programa1_analysis.json         # Análise individual
├── programa2_analysis.json         # Análise individual
├── programa3_analysis.json         # Análise individual
└── programa_N_analysis.json        # Análise individual
```

### **Relatório Consolidado**
O arquivo `consolidated_report.md` contém:

#### **📊 Estatísticas Gerais**
- Total de arquivos processados
- Sucessos vs. falhas
- Total de linhas de código
- Tempo de processamento
- Velocidade (arquivos/minuto)

#### **🔒 Análise de Segurança**
- Score médio de segurança (0-100)
- Melhor e pior scores
- Total de issues de segurança
- Distribuição por severidade

#### **⚡ Análise de Performance**
- Score médio de performance (0-100)
- Complexidade média
- Oportunidades de otimização
- Gargalos identificados

#### **📁 Lista de Arquivos**
- Status de processamento por arquivo
- Linhas de código por programa
- Program IDs identificados
- Indicadores de erro

#### **💡 Recomendações**
- Ações prioritárias baseadas nas análises
- Estratégias de melhoria
- Próximos passos sugeridos

### **Análises Individuais**
Cada arquivo `programa_analysis.json` contém:

```json
{
  "file_path": "/caminho/para/programa.cbl",
  "program_id": "NOME-PROGRAMA",
  "lines_of_code": 150,
  "processing_time": 0.25,
  "basic_analysis": {
    "program_info": {
      "variables_count": 25,
      "sections_count": 3,
      "paragraphs_count": 8
    }
  },
  "plugin_results": {
    "security_analyzer": {
      "security_score": 85,
      "issues": [...],
      "recommendations": [...]
    },
    "performance_analyzer": {
      "performance_score": 78,
      "complexity": "MEDIUM",
      "optimizations": [...]
    }
  },
  "ai_documentation": {
    "business_logic": "...",
    "data_structure": "..."
  }
}
```

---

## 🔧 Configuração Avançada

### **Otimização de Performance**

#### **Para Portfolios Grandes (100+ arquivos)**
```bash
python src/enhanced_cli.py batch portfolio_grande.zip \
  --output ./analise_massa \
  --parallel true \
  --max-workers 8 \
  --plugins security_analyzer  # Apenas plugins essenciais
```

#### **Para Análise Detalhada (< 50 arquivos)**
```bash
python src/enhanced_cli.py batch portfolio_pequeno.zip \
  --output ./analise_detalhada \
  --plugins security_analyzer performance_analyzer migration_analyzer \
  --enable-ai \
  --max-workers 4
```

### **Configuração de Memória**

#### **Sistemas com Pouca Memória**
```bash
# Processamento sequencial
python src/enhanced_cli.py batch portfolio.zip \
  --output ./resultados \
  --parallel false \
  --plugins security_analyzer
```

#### **Sistemas com Muita Memória**
```bash
# Máximo paralelismo
python src/enhanced_cli.py batch portfolio.zip \
  --output ./resultados \
  --parallel true \
  --max-workers 16 \
  --enable-ai
```

---

## 📈 Métricas e Benchmarks

### **Performance Típica**

#### **Programas Pequenos (< 500 linhas)**
- **Velocidade**: 100-200 arquivos/minuto
- **Memória**: ~50MB por worker
- **Plugins**: Todos suportados

#### **Programas Médios (500-2000 linhas)**
- **Velocidade**: 50-100 arquivos/minuto
- **Memória**: ~100MB por worker
- **Recomendação**: 4-8 workers

#### **Programas Grandes (> 2000 linhas)**
- **Velocidade**: 20-50 arquivos/minuto
- **Memória**: ~200MB por worker
- **Recomendação**: 2-4 workers

### **Exemplo Real - Portfolio de 50 Programas**
```
📊 Estatísticas de Processamento:
- Total de arquivos: 50
- Processados com sucesso: 48
- Falhas: 2
- Total de linhas de código: 125,000
- Tempo de processamento: 45.2s
- Velocidade: 66.4 arquivos/min

🔒 Análise de Segurança:
- Score médio: 78/100
- Issues críticos: 12
- Issues médios: 45
- Issues baixos: 123

⚡ Análise de Performance:
- Score médio: 65/100
- Complexidade alta: 8 programas
- Oportunidades de otimização: 156
```

---

## 🛠️ Solução de Problemas

### **Problemas Comuns**

#### **Erro: "Nenhum arquivo COBOL encontrado"**
```bash
# Verificar conteúdo do ZIP
unzip -l portfolio.zip

# Verificar extensões suportadas
# Suportadas: .cbl, .cob, .cobol, .txt
```

#### **Erro: "Arquivo ZIP inválido"**
```bash
# Verificar integridade do ZIP
unzip -t portfolio.zip

# Recriar ZIP se necessário
zip -r novo_portfolio.zip pasta_cobol/
```

#### **Performance Lenta**
```bash
# Reduzir workers
--max-workers 2

# Desabilitar IA
# Remover --enable-ai

# Usar menos plugins
--plugins security_analyzer
```

#### **Erro de Memória**
```bash
# Processamento sequencial
--parallel false

# Reduzir workers
--max-workers 1

# Processar em lotes menores
# Dividir ZIP em partes menores
```

### **Logs e Debug**

#### **Habilitar Logs Detalhados**
```bash
export COBOL_ENGINE_LOG_LEVEL=DEBUG
python src/enhanced_cli.py batch portfolio.zip --output ./debug_results
```

#### **Verificar Arquivos Problemáticos**
```bash
# Verificar relatório consolidado
cat ./resultados/consolidated_report.md

# Verificar análises individuais
ls -la ./resultados/*_analysis.json
```

---

## 🎯 Casos de Uso Específicos

### **1. Auditoria de Segurança Corporativa**
```bash
# Análise focada em segurança para compliance
python src/enhanced_cli.py batch sistema_bancario.zip \
  --output ./auditoria_seguranca \
  --plugins security_analyzer \
  --parallel true \
  --max-workers 6

# Resultado: Relatório de compliance para auditores
```

### **2. Planejamento de Modernização**
```bash
# Avaliação completa para migração
python src/enhanced_cli.py batch portfolio_legacy.zip \
  --output ./plano_modernizacao \
  --plugins migration_analyzer performance_analyzer \
  --enable-ai \
  --max-workers 4

# Resultado: Estratégia de modernização com estimativas
```

### **3. Otimização de Performance**
```bash
# Identificação de gargalos em sistema crítico
python src/enhanced_cli.py batch sistema_batch.zip \
  --output ./otimizacao_performance \
  --plugins performance_analyzer \
  --parallel true \
  --max-workers 8

# Resultado: Plano de otimização prioritizado
```

### **4. Transferência de Conhecimento**
```bash
# Documentação completa para nova equipe
python src/enhanced_cli.py batch sistema_completo.zip \
  --output ./base_conhecimento \
  --enable-ai \
  --plugins security_analyzer performance_analyzer migration_analyzer \
  --max-workers 4

# Resultado: Base de conhecimento completa
```

### **5. Análise Comparativa**
```bash
# Comparar versões antes/depois de mudanças
python src/enhanced_cli.py batch versao_antiga.zip \
  --output ./analise_v1

python src/enhanced_cli.py batch versao_nova.zip \
  --output ./analise_v2

# Comparar relatórios consolidados
diff ./analise_v1/consolidated_report.md ./analise_v2/consolidated_report.md
```

---

## 📋 Checklist de Processamento

### **✅ Preparação**
- [ ] Arquivo ZIP ou diretório preparado
- [ ] Extensões COBOL corretas (.cbl, .cob, .cobol, .txt)
- [ ] Espaço em disco suficiente para resultados
- [ ] Memória RAM adequada (4GB+ recomendado)
- [ ] API OpenAI configurada (se usar --enable-ai)

### **✅ Execução**
- [ ] Comando batch executado com parâmetros corretos
- [ ] Processamento concluído sem erros críticos
- [ ] Relatório consolidado gerado
- [ ] Análises individuais criadas
- [ ] Estatísticas de performance verificadas

### **✅ Validação**
- [ ] Número de arquivos processados confere
- [ ] Relatório consolidado revisado
- [ ] Issues críticos identificados
- [ ] Recomendações analisadas
- [ ] Próximos passos definidos

---

## 🚀 Próximos Passos

### **Após Processamento em Lote**

1. **Revisar Relatório Consolidado**
   - Identificar programas críticos
   - Priorizar issues de segurança
   - Planejar otimizações

2. **Análise Detalhada**
   - Examinar programas com scores baixos
   - Investigar falhas de processamento
   - Validar recomendações

3. **Plano de Ação**
   - Criar roadmap de melhorias
   - Definir prioridades
   - Estimar esforços

4. **Monitoramento Contínuo**
   - Reprocessar após mudanças
   - Acompanhar métricas de qualidade
   - Manter base de conhecimento atualizada

---

**Guia de Processamento em Lote - Motor de Documentação COBOL**  
**Versão**: 1.0.0  
**Compatível com**: Python 3.11+, portfolios de qualquer tamanho

