"""
Testes para o processador de lotes.
"""

import os
import sys
import tempfile
import zipfile
import shutil
import pytest
from pathlib import Path

# Adiciona src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from batch_processor import BatchProcessor


class TestBatchProcessor:
    """Testes para BatchProcessor."""
    
    def setup_method(self):
        """Setup para cada teste."""
        self.processor = BatchProcessor()
        self.temp_dir = tempfile.mkdtemp()
        
    def teardown_method(self):
        """Cleanup após cada teste."""
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
    
    def create_sample_cobol_file(self, filename: str, content: str = None) -> str:
        """Cria arquivo COBOL de exemplo."""
        if content is None:
            content = """
IDENTIFICATION DIVISION.
PROGRAM-ID. SAMPLE-PROGRAM.
AUTHOR. TEST.

DATA DIVISION.
WORKING-STORAGE SECTION.
01  WS-COUNTER    PIC 9(3) VALUE 0.

PROCEDURE DIVISION.
MAIN-PROCESS SECTION.
000-MAIN-ROUTINE.
    DISPLAY "Hello World"
    STOP RUN.
"""
        
        file_path = os.path.join(self.temp_dir, filename)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        return file_path
    
    def create_sample_zip(self, zip_name: str, files: list) -> str:
        """Cria arquivo ZIP com arquivos COBOL."""
        zip_path = os.path.join(self.temp_dir, zip_name)
        
        with zipfile.ZipFile(zip_path, 'w') as zip_file:
            for file_info in files:
                if isinstance(file_info, str):
                    # Nome do arquivo apenas
                    content = """
IDENTIFICATION DIVISION.
PROGRAM-ID. """ + file_info.replace('.cbl', '').upper() + """.

DATA DIVISION.
WORKING-STORAGE SECTION.
01  WS-VAR    PIC X(10).

PROCEDURE DIVISION.
MAIN-ROUTINE.
    DISPLAY "Test"
    STOP RUN.
"""
                    zip_file.writestr(file_info, content)
                else:
                    # Tupla (nome, conteúdo)
                    zip_file.writestr(file_info[0], file_info[1])
        
        return zip_path
    
    def test_find_cobol_files(self):
        """Testa busca de arquivos COBOL."""
        # Criar arquivos de teste
        self.create_sample_cobol_file("program1.cbl")
        self.create_sample_cobol_file("program2.cob")
        self.create_sample_cobol_file("program3.txt")
        
        # Criar arquivo não-COBOL
        with open(os.path.join(self.temp_dir, "readme.md"), 'w') as f:
            f.write("# Test")
        
        # Buscar arquivos COBOL
        cobol_files = self.processor._find_cobol_files(self.temp_dir, recursive=False)
        
        assert len(cobol_files) == 3
        assert any("program1.cbl" in f for f in cobol_files)
        assert any("program2.cob" in f for f in cobol_files)
        assert any("program3.txt" in f for f in cobol_files)
        assert not any("readme.md" in f for f in cobol_files)
    
    def test_extract_zip(self):
        """Testa extração de ZIP."""
        # Criar ZIP com arquivos COBOL
        zip_path = self.create_sample_zip("test.zip", [
            "program1.cbl",
            "program2.cob",
            "subdir/program3.cbl"
        ])
        
        # Extrair ZIP
        extract_dir = os.path.join(self.temp_dir, "extracted")
        os.makedirs(extract_dir)
        
        cobol_files = self.processor._extract_zip(zip_path, extract_dir)
        
        assert len(cobol_files) == 3
        assert all(os.path.exists(f) for f in cobol_files)
    
    def test_process_single_file(self):
        """Testa processamento de arquivo único."""
        # Criar arquivo COBOL
        cobol_content = """
IDENTIFICATION DIVISION.
PROGRAM-ID. TEST-PROGRAM.
AUTHOR. TESTER.

DATA DIVISION.
WORKING-STORAGE SECTION.
01  WS-NAME     PIC X(20) VALUE "TEST".
01  WS-COUNTER  PIC 9(3) VALUE 0.

PROCEDURE DIVISION.
MAIN-PROCESS SECTION.
000-MAIN-ROUTINE.
    DISPLAY "Processing: " WS-NAME
    ADD 1 TO WS-COUNTER
    STOP RUN.
"""
        
        file_path = self.create_sample_cobol_file("test.cbl", cobol_content)
        output_dir = os.path.join(self.temp_dir, "output")
        
        # Processar arquivo
        result = self.processor._process_single_file(
            file_path, output_dir, plugins=[], enable_ai=False
        )
        
        # Verificar resultado
        assert result['program_id'] == 'TEST-PROGRAM'
        assert result['lines_of_code'] > 0
        assert 'basic_analysis' in result
        assert result['basic_analysis']['program_info']['variables_count'] == 2
        
        # Verificar se arquivo de saída foi criado
        json_file = os.path.join(output_dir, "test_analysis.json")
        assert os.path.exists(json_file)
    
    def test_process_directory(self):
        """Testa processamento de diretório."""
        # Criar múltiplos arquivos COBOL
        files = []
        for i in range(3):
            file_path = self.create_sample_cobol_file(f"program{i+1}.cbl")
            files.append(file_path)
        
        output_dir = os.path.join(self.temp_dir, "output")
        
        # Processar diretório
        result = self.processor.process_directory(
            directory_path=self.temp_dir,
            output_dir=output_dir,
            plugins=[],
            enable_ai=False,
            parallel=False  # Sequencial para testes
        )
        
        # Verificar resultado
        assert result['stats']['total_files'] == 3
        assert result['stats']['processed_files'] == 3
        assert result['stats']['failed_files'] == 0
        assert len(result['results']) == 3
        
        # Verificar se relatório consolidado foi criado
        assert os.path.exists(result['consolidated_report'])
        
        # Verificar arquivos de saída individuais
        for i in range(3):
            json_file = os.path.join(output_dir, f"program{i+1}_analysis.json")
            assert os.path.exists(json_file)
    
    def test_process_zip_file(self):
        """Testa processamento de arquivo ZIP."""
        # Criar ZIP com múltiplos arquivos
        zip_path = self.create_sample_zip("portfolio.zip", [
            "payroll.cbl",
            "inventory.cbl", 
            "reports.cob"
        ])
        
        output_dir = os.path.join(self.temp_dir, "zip_output")
        
        # Processar ZIP
        result = self.processor.process_zip_file(
            zip_path=zip_path,
            output_dir=output_dir,
            plugins=[],
            enable_ai=False,
            parallel=False  # Sequencial para testes
        )
        
        # Verificar resultado
        assert result['stats']['total_files'] == 3
        assert result['stats']['processed_files'] == 3
        assert result['stats']['failed_files'] == 0
        
        # Verificar se relatório consolidado foi criado
        assert os.path.exists(result['consolidated_report'])
        
        # Verificar conteúdo do relatório
        with open(result['consolidated_report'], 'r', encoding='utf-8') as f:
            report_content = f.read()
            assert "Relatório Consolidado" in report_content
            assert "payroll.cbl" in report_content
            assert "inventory.cbl" in report_content
            assert "reports.cob" in report_content
    
    def test_process_with_plugins(self):
        """Testa processamento com plugins."""
        # Criar arquivo COBOL
        file_path = self.create_sample_cobol_file("test_with_plugins.cbl")
        output_dir = os.path.join(self.temp_dir, "plugin_output")
        
        # Processar com plugins (se disponíveis)
        result = self.processor.process_directory(
            directory_path=self.temp_dir,
            output_dir=output_dir,
            plugins=['security_analyzer'],  # Plugin pode não estar disponível em teste
            enable_ai=False,
            parallel=False
        )
        
        # Verificar que processamento foi bem-sucedido mesmo se plugin falhou
        assert result['stats']['processed_files'] >= 1
    
    def test_invalid_zip_file(self):
        """Testa tratamento de arquivo ZIP inválido."""
        # Criar arquivo que não é ZIP
        fake_zip = os.path.join(self.temp_dir, "fake.zip")
        with open(fake_zip, 'w') as f:
            f.write("This is not a ZIP file")
        
        output_dir = os.path.join(self.temp_dir, "error_output")
        
        # Tentar processar arquivo inválido
        with pytest.raises(ValueError, match="Arquivo ZIP inválido"):
            self.processor.process_zip_file(
                zip_path=fake_zip,
                output_dir=output_dir
            )
    
    def test_empty_directory(self):
        """Testa processamento de diretório vazio."""
        empty_dir = os.path.join(self.temp_dir, "empty")
        os.makedirs(empty_dir)
        
        output_dir = os.path.join(self.temp_dir, "empty_output")
        
        # Tentar processar diretório vazio
        with pytest.raises(ValueError, match="Nenhum arquivo COBOL encontrado"):
            self.processor.process_directory(
                directory_path=empty_dir,
                output_dir=output_dir
            )
    
    def test_processing_stats(self):
        """Testa coleta de estatísticas."""
        # Resetar estatísticas
        self.processor.reset_stats()
        stats = self.processor.get_processing_stats()
        
        assert stats['total_files'] == 0
        assert stats['processed_files'] == 0
        assert stats['failed_files'] == 0
        
        # Processar alguns arquivos
        for i in range(2):
            self.create_sample_cobol_file(f"stats_test{i+1}.cbl")
        
        output_dir = os.path.join(self.temp_dir, "stats_output")
        
        result = self.processor.process_directory(
            directory_path=self.temp_dir,
            output_dir=output_dir,
            parallel=False
        )
        
        # Verificar estatísticas
        stats = result['stats']
        assert stats['total_files'] == 2
        assert stats['processed_files'] == 2
        assert stats['processing_time'] > 0
        assert stats['files_per_minute'] > 0
    
    def test_parallel_processing(self):
        """Testa processamento paralelo."""
        # Criar múltiplos arquivos
        for i in range(4):
            self.create_sample_cobol_file(f"parallel{i+1}.cbl")
        
        output_dir = os.path.join(self.temp_dir, "parallel_output")
        
        # Processar em paralelo
        result = self.processor.process_directory(
            directory_path=self.temp_dir,
            output_dir=output_dir,
            parallel=True,
            max_workers=2
        )
        
        # Verificar que todos foram processados
        assert result['stats']['total_files'] == 4
        assert result['stats']['processed_files'] == 4
        assert result['stats']['failed_files'] == 0


if __name__ == '__main__':
    pytest.main([__file__])

