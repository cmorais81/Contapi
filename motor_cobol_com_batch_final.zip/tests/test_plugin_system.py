"""
Testes para o sistema de plugins.
"""

import unittest
import sys
import os
import tempfile
import json
from unittest.mock import Mock, patch

# Adiciona o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from cobol_parser import CobolParser
from plugin_system import (
    PluginManager, PluginType, PluginPriority, PluginMetadata,
    AnalyzerPlugin, FormatterPlugin, ExporterPlugin, PluginResult
)


class TestPluginSystem(unittest.TestCase):
    """Testes para o sistema de plugins."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.temp_dir = tempfile.mkdtemp()
        self.plugin_manager = PluginManager(self.temp_dir)
        
        # Programa COBOL para testes
        self.parser = CobolParser()
        self.sample_file = os.path.join(
            os.path.dirname(__file__), 
            'sample_cobol', 
            'sample_program.cbl'
        )
        self.program = self.parser.parse_file(self.sample_file)
    
    def tearDown(self):
        """Limpeza após testes."""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_plugin_manager_initialization(self):
        """Testa inicialização do gerenciador de plugins."""
        self.assertIsNotNone(self.plugin_manager)
        self.assertEqual(self.plugin_manager.plugins_dir, self.temp_dir)
        self.assertEqual(len(self.plugin_manager.plugins), 0)
        self.assertTrue(os.path.exists(self.temp_dir))
    
    def test_plugin_discovery(self):
        """Testa descoberta de plugins."""
        # Cria arquivo de plugin mock
        plugin_file = os.path.join(self.temp_dir, 'test_plugin.py')
        with open(plugin_file, 'w') as f:
            f.write('# Mock plugin file')
        
        # Cria diretório de plugin mock
        plugin_dir = os.path.join(self.temp_dir, 'test_plugin_dir')
        os.makedirs(plugin_dir)
        with open(os.path.join(plugin_dir, '__init__.py'), 'w') as f:
            f.write('# Mock plugin directory')
        
        discovered = self.plugin_manager.discover_plugins()
        
        self.assertIn('test_plugin', discovered)
        self.assertIn('test_plugin_dir', discovered)
    
    def test_plugin_metadata(self):
        """Testa criação de metadados de plugin."""
        metadata = PluginMetadata(
            name="test_plugin",
            version="1.0.0",
            description="Plugin de teste",
            author="Test Author",
            plugin_type=PluginType.ANALYZER,
            priority=PluginPriority.HIGH
        )
        
        self.assertEqual(metadata.name, "test_plugin")
        self.assertEqual(metadata.version, "1.0.0")
        self.assertEqual(metadata.plugin_type, PluginType.ANALYZER)
        self.assertEqual(metadata.priority, PluginPriority.HIGH)
        self.assertEqual(metadata.dependencies, [])
    
    def test_plugin_result(self):
        """Testa criação de resultado de plugin."""
        result = PluginResult(
            plugin_name="test_plugin",
            success=True,
            data={"test": "data"},
            execution_time=1.5
        )
        
        self.assertEqual(result.plugin_name, "test_plugin")
        self.assertTrue(result.success)
        self.assertEqual(result.data, {"test": "data"})
        self.assertEqual(result.execution_time, 1.5)
        self.assertIsNone(result.error)
    
    def test_analyzer_plugin_base(self):
        """Testa plugin base de análise."""
        class MockAnalyzerPlugin(AnalyzerPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="mock_analyzer",
                    version="1.0.0",
                    description="Mock analyzer",
                    author="Test",
                    plugin_type=PluginType.ANALYZER
                )
            
            def initialize(self, config):
                return True
            
            def analyze(self, program):
                return {"analysis": "mock result"}
        
        plugin = MockAnalyzerPlugin()
        result = plugin.execute(self.program, {})
        
        self.assertTrue(result.success)
        self.assertEqual(result.data, {"analysis": "mock result"})
        self.assertIsNone(result.error)
    
    def test_formatter_plugin_base(self):
        """Testa plugin base de formatação."""
        class MockFormatterPlugin(FormatterPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="mock_formatter",
                    version="1.0.0",
                    description="Mock formatter",
                    author="Test",
                    plugin_type=PluginType.FORMATTER
                )
            
            def initialize(self, config):
                return True
            
            def format(self, data, format_options):
                return f"Formatted: {data}"
        
        plugin = MockFormatterPlugin()
        context = {
            'data': 'test data',
            'format_options': {}
        }
        result = plugin.execute(self.program, context)
        
        self.assertTrue(result.success)
        self.assertEqual(result.data, "Formatted: test data")
    
    def test_exporter_plugin_base(self):
        """Testa plugin base de exportação."""
        class MockExporterPlugin(ExporterPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="mock_exporter",
                    version="1.0.0",
                    description="Mock exporter",
                    author="Test",
                    plugin_type=PluginType.EXPORTER
                )
            
            def initialize(self, config):
                return True
            
            def export(self, data, output_path, export_options):
                # Mock export - apenas retorna True
                return True
        
        plugin = MockExporterPlugin()
        context = {
            'data': 'test data',
            'output_path': '/tmp/test.txt',
            'export_options': {}
        }
        result = plugin.execute(self.program, context)
        
        self.assertTrue(result.success)
        self.assertTrue(result.data['exported'])
        self.assertEqual(result.data['path'], '/tmp/test.txt')
    
    def test_plugin_execution_order(self):
        """Testa ordem de execução de plugins."""
        # Cria plugins mock com diferentes prioridades
        class HighPriorityPlugin(AnalyzerPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="high_priority",
                    version="1.0.0",
                    description="High priority plugin",
                    author="Test",
                    plugin_type=PluginType.ANALYZER,
                    priority=PluginPriority.HIGH
                )
            
            def initialize(self, config):
                return True
            
            def analyze(self, program):
                return {"priority": "high"}
        
        class LowPriorityPlugin(AnalyzerPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="low_priority",
                    version="1.0.0",
                    description="Low priority plugin",
                    author="Test",
                    plugin_type=PluginType.ANALYZER,
                    priority=PluginPriority.LOW
                )
            
            def initialize(self, config):
                return True
            
            def analyze(self, program):
                return {"priority": "low"}
        
        # Registra plugins manualmente
        self.plugin_manager.plugins["high_priority"] = HighPriorityPlugin()
        self.plugin_manager.plugins["low_priority"] = LowPriorityPlugin()
        
        # Atualiza ordem de execução
        self.plugin_manager.execution_order[PluginType.ANALYZER] = ["high_priority", "low_priority"]
        self.plugin_manager.execution_order[PluginType.ANALYZER].sort(
            key=lambda x: self.plugin_manager.plugins[x].metadata.priority.value
        )
        
        # Executa plugins
        results = self.plugin_manager.execute_plugins(PluginType.ANALYZER, self.program)
        
        self.assertEqual(len(results), 2)
        # Plugin de alta prioridade deve executar primeiro
        self.assertEqual(results[0].plugin_name, "high_priority")
        self.assertEqual(results[1].plugin_name, "low_priority")
    
    def test_plugin_error_handling(self):
        """Testa tratamento de erros em plugins."""
        class ErrorPlugin(AnalyzerPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="error_plugin",
                    version="1.0.0",
                    description="Plugin que gera erro",
                    author="Test",
                    plugin_type=PluginType.ANALYZER
                )
            
            def initialize(self, config):
                return True
            
            def analyze(self, program):
                raise Exception("Erro simulado")
        
        plugin = ErrorPlugin()
        result = plugin.execute(self.program, {})
        
        self.assertFalse(result.success)
        self.assertIsNotNone(result.error)
        self.assertIn("Erro simulado", result.error)
    
    def test_plugin_config_validation(self):
        """Testa validação de configuração de plugins."""
        class ConfigValidationPlugin(AnalyzerPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="config_plugin",
                    version="1.0.0",
                    description="Plugin com validação de config",
                    author="Test",
                    plugin_type=PluginType.ANALYZER
                )
            
            def initialize(self, config):
                return True
            
            def validate_config(self, config):
                return config.get('required_field') is not None
            
            def analyze(self, program):
                return {"config": "validated"}
        
        plugin = ConfigValidationPlugin()
        
        # Configuração inválida
        self.assertFalse(plugin.validate_config({}))
        
        # Configuração válida
        self.assertTrue(plugin.validate_config({'required_field': 'value'}))
    
    def test_plugin_manager_stats(self):
        """Testa estatísticas do gerenciador de plugins."""
        # Adiciona plugins mock
        class TestPlugin1(AnalyzerPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="test1",
                    version="1.0.0",
                    description="Test plugin 1",
                    author="Test",
                    plugin_type=PluginType.ANALYZER,
                    priority=PluginPriority.HIGH
                )
            
            def initialize(self, config):
                return True
            
            def analyze(self, program):
                return {}
        
        class TestPlugin2(FormatterPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="test2",
                    version="1.0.0",
                    description="Test plugin 2",
                    author="Test",
                    plugin_type=PluginType.FORMATTER,
                    priority=PluginPriority.NORMAL
                )
            
            def initialize(self, config):
                return True
            
            def format(self, data, format_options):
                return str(data)
        
        self.plugin_manager.plugins["test1"] = TestPlugin1()
        self.plugin_manager.plugins["test2"] = TestPlugin2()
        
        stats = self.plugin_manager.get_execution_stats()
        
        self.assertEqual(stats['total_plugins'], 2)
        self.assertEqual(stats['plugins_by_type']['analyzer'], 1)
        self.assertEqual(stats['plugins_by_type']['formatter'], 1)
        self.assertEqual(stats['plugins_by_priority'][PluginPriority.HIGH.value], 1)
        self.assertEqual(stats['plugins_by_priority'][PluginPriority.NORMAL.value], 1)
    
    def test_plugin_list_filtering(self):
        """Testa listagem e filtragem de plugins."""
        # Adiciona plugins de diferentes tipos
        class AnalyzerPlugin1(AnalyzerPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="analyzer1",
                    version="1.0.0",
                    description="Analyzer 1",
                    author="Test",
                    plugin_type=PluginType.ANALYZER
                )
            
            def initialize(self, config):
                return True
            
            def analyze(self, program):
                return {}
        
        class FormatterPlugin1(FormatterPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="formatter1",
                    version="1.0.0",
                    description="Formatter 1",
                    author="Test",
                    plugin_type=PluginType.FORMATTER
                )
            
            def initialize(self, config):
                return True
            
            def format(self, data, format_options):
                return str(data)
        
        self.plugin_manager.plugins["analyzer1"] = AnalyzerPlugin1()
        self.plugin_manager.plugins["formatter1"] = FormatterPlugin1()
        
        # Lista todos os plugins
        all_plugins = self.plugin_manager.list_plugins()
        self.assertEqual(len(all_plugins), 2)
        self.assertIn("analyzer1", all_plugins)
        self.assertIn("formatter1", all_plugins)
        
        # Lista apenas analyzers
        analyzers = self.plugin_manager.list_plugins(PluginType.ANALYZER)
        self.assertEqual(len(analyzers), 1)
        self.assertIn("analyzer1", analyzers)
        
        # Lista apenas formatters
        formatters = self.plugin_manager.list_plugins(PluginType.FORMATTER)
        self.assertEqual(len(formatters), 1)
        self.assertIn("formatter1", formatters)
    
    def test_plugin_config_save_load(self):
        """Testa salvamento e carregamento de configuração de plugins."""
        config_file = os.path.join(self.temp_dir, 'plugins_config.json')
        
        # Configura plugins mock
        self.plugin_manager.plugin_configs = {
            'plugin1': {'setting1': 'value1'},
            'plugin2': {'setting2': 'value2'}
        }
        
        # Salva configuração
        success = self.plugin_manager.save_plugins_config(config_file)
        self.assertTrue(success)
        self.assertTrue(os.path.exists(config_file))
        
        # Verifica conteúdo do arquivo
        with open(config_file, 'r') as f:
            saved_config = json.load(f)
        
        self.assertIn('plugins', saved_config)
        self.assertEqual(saved_config['plugins']['plugin1']['setting1'], 'value1')
        self.assertEqual(saved_config['plugins']['plugin2']['setting2'], 'value2')
    
    def test_plugin_dependency_validation(self):
        """Testa validação de dependências entre plugins."""
        # Cria plugins com dependências
        class DependentPlugin(AnalyzerPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="dependent",
                    version="1.0.0",
                    description="Plugin com dependências",
                    author="Test",
                    plugin_type=PluginType.ANALYZER,
                    dependencies=["required_plugin", "missing_plugin"]
                )
            
            def initialize(self, config):
                return True
            
            def analyze(self, program):
                return {}
        
        class RequiredPlugin(AnalyzerPlugin):
            @property
            def metadata(self):
                return PluginMetadata(
                    name="required_plugin",
                    version="1.0.0",
                    description="Plugin requerido",
                    author="Test",
                    plugin_type=PluginType.ANALYZER
                )
            
            def initialize(self, config):
                return True
            
            def analyze(self, program):
                return {}
        
        # Registra plugins
        self.plugin_manager.plugins["dependent"] = DependentPlugin()
        self.plugin_manager.plugins["required_plugin"] = RequiredPlugin()
        
        # Valida dependências
        missing_deps = self.plugin_manager.validate_dependencies()
        
        self.assertIn("dependent", missing_deps)
        self.assertIn("missing_plugin", missing_deps["dependent"])
        self.assertNotIn("required_plugin", missing_deps["dependent"])


class TestRealPlugins(unittest.TestCase):
    """Testes com plugins reais do sistema."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.parser = CobolParser()
        self.sample_file = os.path.join(
            os.path.dirname(__file__), 
            'sample_cobol', 
            'sample_program.cbl'
        )
        self.program = self.parser.parse_file(self.sample_file)
        
        # Diretório de plugins reais
        self.plugins_dir = os.path.join(os.path.dirname(__file__), '..', 'plugins')
        self.plugin_manager = PluginManager(self.plugins_dir)
    
    def test_security_analyzer_plugin(self):
        """Testa plugin de análise de segurança."""
        # Carrega plugin de segurança
        success = self.plugin_manager.load_plugin('security_analyzer')
        
        if success:
            # Executa plugin
            results = self.plugin_manager.execute_plugins(PluginType.ANALYZER, self.program)
            
            # Verifica se há resultados
            security_results = [r for r in results if r.plugin_name == 'security_analyzer']
            self.assertEqual(len(security_results), 1)
            
            result = security_results[0]
            self.assertTrue(result.success)
            self.assertIn('issues', result.data)
            self.assertIn('security_score', result.data)
    
    def test_performance_analyzer_plugin(self):
        """Testa plugin de análise de performance."""
        # Carrega plugin de performance
        success = self.plugin_manager.load_plugin('performance_analyzer')
        
        if success:
            # Executa plugin
            results = self.plugin_manager.execute_plugins(PluginType.ANALYZER, self.program)
            
            # Verifica se há resultados
            perf_results = [r for r in results if r.plugin_name == 'performance_analyzer']
            self.assertEqual(len(perf_results), 1)
            
            result = perf_results[0]
            self.assertTrue(result.success)
            self.assertIn('issues', result.data)
            self.assertIn('performance_score', result.data)
    
    def test_migration_analyzer_plugin(self):
        """Testa plugin de análise de migração."""
        # Carrega plugin de migração
        success = self.plugin_manager.load_plugin('migration_analyzer')
        
        if success:
            # Executa plugin
            results = self.plugin_manager.execute_plugins(PluginType.ANALYZER, self.program)
            
            # Verifica se há resultados
            migration_results = [r for r in results if r.plugin_name == 'migration_analyzer']
            self.assertEqual(len(migration_results), 1)
            
            result = migration_results[0]
            self.assertTrue(result.success)
            self.assertIn('issues', result.data)
            self.assertIn('readiness_score', result.data)
            self.assertIn('modernization_strategy', result.data)
    
    def test_multiple_plugins_execution(self):
        """Testa execução de múltiplos plugins."""
        # Carrega múltiplos plugins
        plugins_loaded = []
        for plugin_name in ['security_analyzer', 'performance_analyzer', 'migration_analyzer']:
            if self.plugin_manager.load_plugin(plugin_name):
                plugins_loaded.append(plugin_name)
        
        if plugins_loaded:
            # Executa todos os plugins
            results = self.plugin_manager.execute_plugins(PluginType.ANALYZER, self.program)
            
            # Verifica se todos os plugins carregados executaram
            executed_plugins = [r.plugin_name for r in results]
            for plugin_name in plugins_loaded:
                self.assertIn(plugin_name, executed_plugins)
            
            # Verifica se todos tiveram sucesso
            for result in results:
                self.assertTrue(result.success, f"Plugin {result.plugin_name} falhou: {result.error}")


if __name__ == '__main__':
    unittest.main()

