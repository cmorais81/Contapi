"""
Testes para a integração com API do Copilot/OpenAI.
"""

import unittest
import sys
import os
from unittest.mock import Mock, patch

# Adiciona o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from copilot_integration import CopilotIntegration, AnalysisRequest, AnalysisResponse


class TestCopilotIntegration(unittest.TestCase):
    """Testes para a classe CopilotIntegration."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        # Mock da API key para testes
        with patch.dict(os.environ, {'OPENAI_API_KEY': 'test-key'}):
            self.integration = CopilotIntegration()
    
    def test_initialization(self):
        """Testa a inicialização da integração."""
        with patch.dict(os.environ, {'OPENAI_API_KEY': 'test-key'}):
            integration = CopilotIntegration()
            self.assertEqual(integration.model, 'gpt-4')
            self.assertEqual(integration.max_tokens, 4000)
            self.assertEqual(integration.temperature, 0.3)
    
    def test_initialization_without_api_key(self):
        """Testa inicialização sem API key."""
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(ValueError):
                CopilotIntegration()
    
    def test_prepare_prompt(self):
        """Testa a preparação de prompts."""
        request = AnalysisRequest(
            code_content="PROGRAM-ID. TEST.",
            program_summary={'program_id': 'TEST', 'total_variables': 5},
            analysis_type="full"
        )
        
        template = "Code: {code_content}\\nSummary: {program_summary}"
        prompt = self.integration._prepare_prompt(template, request)
        
        self.assertIn("PROGRAM-ID. TEST.", prompt)
        self.assertIn("Program ID: TEST", prompt)
    
    def test_format_program_summary(self):
        """Testa a formatação do resumo do programa."""
        summary = {
            'program_id': 'TEST-PROG',
            'author': 'Test Author',
            'total_variables': 10,
            'main_sections': ['MAIN-SECTION']
        }
        
        formatted = self.integration._format_program_summary(summary)
        
        self.assertIn("Program ID: TEST-PROG", formatted)
        self.assertIn("Author: Test Author", formatted)
        self.assertIn("Total Variables: 10", formatted)
        self.assertIn("Main Sections: MAIN-SECTION", formatted)
    
    def test_extract_response_sections(self):
        """Testa a extração de seções da resposta."""
        response = """
        PROPÓSITO DO PROGRAMA:
        Este programa calcula folha de pagamento.
        
        FUNCIONALIDADES PRINCIPAIS:
        - Calcula salários
        - Processa descontos
        
        COMPLEXIDADE:
        Média complexidade
        """
        
        sections = self.integration._extract_response_sections(response)
        
        self.assertIn('purpose', sections)
        self.assertIn('functionality', sections)
        # Verifica se pelo menos algumas seções foram extraídas
        self.assertGreater(len(sections), 0)
    
    @patch('copilot_integration.OpenAI')
    def test_call_openai_api_success(self, mock_openai):
        """Testa chamada bem-sucedida para API OpenAI."""
        # Mock da resposta da API
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Análise do programa COBOL"
        
        mock_client = Mock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_openai.return_value = mock_client
        
        with patch.dict(os.environ, {'OPENAI_API_KEY': 'test-key'}):
            integration = CopilotIntegration()
            integration.client = mock_client
            
            result = integration._call_openai_api("Test prompt")
            
            self.assertEqual(result, "Análise do programa COBOL")
            mock_client.chat.completions.create.assert_called_once()
    
    def test_process_api_response(self):
        """Testa o processamento da resposta da API."""
        response = """
        PROPÓSITO: Calcular folha de pagamento
        FUNCIONALIDADES: Processar salários e descontos
        """
        
        analysis_response = self.integration._process_api_response(response, "pt-br")
        
        self.assertIsInstance(analysis_response, AnalysisResponse)
        self.assertEqual(analysis_response.raw_response, response)
        self.assertIsInstance(analysis_response.variables_description, dict)
        self.assertIsInstance(analysis_response.execution_flow, list)


if __name__ == '__main__':
    unittest.main()

