"""
Testes para o analisador de código COBOL.
"""

import unittest
import sys
import os

# Adiciona o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from cobol_parser import CobolParser, CobolProgram


class TestCobolParser(unittest.TestCase):
    """Testes para a classe CobolParser."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.parser = CobolParser()
        self.sample_file = os.path.join(
            os.path.dirname(__file__), 
            'sample_cobol', 
            'sample_program.cbl'
        )
    
    def test_parse_file(self):
        """Testa o parsing de um arquivo COBOL."""
        program = self.parser.parse_file(self.sample_file)
        
        # Verifica informações básicas
        self.assertEqual(program.program_id, 'CALC-PAYROLL')
        self.assertEqual(program.author, 'SISTEMA DE FOLHA DE PAGAMENTO.')
        self.assertEqual(program.date_written, '15/12/2023.')
        
        # Verifica se variáveis foram extraídas
        self.assertGreater(len(program.variables), 0)
        
        # Verifica se seções foram extraídas
        self.assertGreater(len(program.sections), 0)
        
        # Verifica se parágrafos foram extraídos (dentro de seções ou standalone)
        total_paragraphs = len(program.paragraphs)
        for section in program.sections:
            total_paragraphs += len(section.paragraphs)
        self.assertGreater(total_paragraphs, 0)
    
    def test_variable_extraction(self):
        """Testa a extração de variáveis."""
        program = self.parser.parse_file(self.sample_file)
        
        # Procura por variáveis específicas
        variable_names = [var.name for var in program.variables]
        
        self.assertIn('WS-EMPLOYEE-RECORD', variable_names)
        self.assertIn('WS-EMP-ID', variable_names)
        self.assertIn('WS-EMP-NAME', variable_names)
        self.assertIn('WS-BASIC-SALARY', variable_names)
    
    def test_paragraph_extraction(self):
        """Testa a extração de parágrafos."""
        program = self.parser.parse_file(self.sample_file)
        
        # Os parágrafos estão dentro da seção MAIN-PROCESS
        all_paragraphs = []
        for section in program.sections:
            all_paragraphs.extend([para.name for para in section.paragraphs])
        
        # Adiciona parágrafos standalone se existirem
        all_paragraphs.extend([para.name for para in program.paragraphs])
        
        self.assertIn('100-INITIALIZE', all_paragraphs)
        self.assertIn('200-PROCESS-EMPLOYEE', all_paragraphs)
        self.assertIn('300-CALCULATE-PAY', all_paragraphs)
        self.assertIn('400-DISPLAY-RESULTS', all_paragraphs)
    
    def test_program_summary(self):
        """Testa a geração de resumo do programa."""
        program = self.parser.parse_file(self.sample_file)
        summary = self.parser.get_program_summary(program)
        
        self.assertEqual(summary['program_id'], 'CALC-PAYROLL')
        self.assertGreater(summary['total_variables'], 0)
        self.assertGreater(summary['total_paragraphs'], 0)
        self.assertIsInstance(summary['variables_by_level'], dict)
    
    def test_business_logic_extraction(self):
        """Testa a extração de lógica de negócio."""
        program = self.parser.parse_file(self.sample_file)
        business_logic = self.parser.extract_business_logic(program)
        
        self.assertGreater(len(business_logic), 0)
        self.assertIsInstance(business_logic, list)


if __name__ == '__main__':
    unittest.main()

