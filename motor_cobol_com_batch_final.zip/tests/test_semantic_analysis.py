"""
Testes para análise semântica avançada.
"""

import unittest
import sys
import os

# Adiciona o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from cobol_parser import CobolParser
from data_flow_analyzer import DataFlowAnalyzer, DataOperation
from complexity_analyzer import ComplexityAnalyzer, ComplexityLevel
from pattern_detector import PatternDetector, PatternType


class TestDataFlowAnalyzer(unittest.TestCase):
    """Testes para o analisador de fluxo de dados."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.parser = CobolParser()
        self.advanced_file = os.path.join(
            os.path.dirname(__file__), 
            'sample_cobol', 
            'advanced_structures.cbl'
        )
        self.program = self.parser.parse_file(self.advanced_file)
        self.analyzer = DataFlowAnalyzer(self.program)
    
    def test_data_flow_analysis(self):
        """Testa análise básica de fluxo de dados."""
        flow_graph = self.analyzer.analyze_data_flow()
        
        # Verifica se o grafo foi construído
        self.assertIsInstance(flow_graph, dict)
        self.assertGreater(len(self.analyzer.data_usages), 0)
        self.assertGreater(len(self.analyzer.data_flows), 0)
    
    def test_data_usage_extraction(self):
        """Testa extração de utilizações de dados."""
        self.analyzer._extract_data_usages()
        
        # Verifica se encontrou utilizações
        self.assertGreater(len(self.analyzer.data_usages), 0)
        
        # Verifica tipos de operações encontradas
        operation_types = {usage.operation for usage in self.analyzer.data_usages}
        self.assertIn(DataOperation.MOVE, operation_types)
        self.assertIn(DataOperation.READ, operation_types)
    
    def test_variable_categorization(self):
        """Testa categorização de variáveis."""
        self.analyzer.analyze_data_flow()
        
        # Verifica se variáveis foram categorizadas
        self.assertIsInstance(self.analyzer.input_variables, set)
        self.assertIsInstance(self.analyzer.output_variables, set)
        self.assertIsInstance(self.analyzer.intermediate_variables, set)
    
    def test_data_lineage(self):
        """Testa geração de linhagem de dados."""
        self.analyzer.analyze_data_flow()
        
        # Testa linhagem para uma variável específica
        if self.analyzer.data_flows:
            first_flow = self.analyzer.data_flows[0]
            lineage = self.analyzer.generate_data_lineage(first_flow.target_variable)
            
            self.assertIn('sources', lineage)
            self.assertIn('targets', lineage)
            self.assertIn('transformations', lineage)
    
    def test_critical_variables(self):
        """Testa identificação de variáveis críticas."""
        self.analyzer.analyze_data_flow()
        critical_vars = self.analyzer.get_critical_variables()
        
        self.assertIsInstance(critical_vars, dict)
        # Verifica se as variáveis estão ordenadas por criticidade
        if len(critical_vars) > 1:
            scores = list(critical_vars.values())
            self.assertEqual(scores, sorted(scores, reverse=True))
    
    def test_data_flow_summary(self):
        """Testa geração de resumo de fluxo de dados."""
        summary = self.analyzer.get_data_flow_summary()
        
        required_keys = [
            'total_variables_used', 'total_data_operations', 'total_data_flows',
            'input_variables', 'output_variables', 'intermediate_variables',
            'unused_variables', 'critical_variables', 'operations_by_type',
            'most_used_variables'
        ]
        
        for key in required_keys:
            self.assertIn(key, summary)


class TestComplexityAnalyzer(unittest.TestCase):
    """Testes para o analisador de complexidade."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.parser = CobolParser()
        self.advanced_file = os.path.join(
            os.path.dirname(__file__), 
            'sample_cobol', 
            'advanced_structures.cbl'
        )
        self.program = self.parser.parse_file(self.advanced_file)
        self.analyzer = ComplexityAnalyzer(self.program)
    
    def test_cyclomatic_complexity(self):
        """Testa cálculo de complexidade ciclomática."""
        complexity_metrics = self.analyzer.calculate_cyclomatic_complexity()
        
        # Verifica se métricas foram calculadas
        self.assertIn('PROGRAM_TOTAL', complexity_metrics)
        
        program_metric = complexity_metrics['PROGRAM_TOTAL']
        self.assertIsInstance(program_metric.value, int)
        self.assertGreater(program_metric.value, 0)
        self.assertIsInstance(program_metric.level, ComplexityLevel)
    
    def test_nesting_depth(self):
        """Testa cálculo de profundidade de aninhamento."""
        nesting_depths = self.analyzer.calculate_nesting_depth()
        
        self.assertIsInstance(nesting_depths, dict)
        # Verifica se encontrou pelo menos algum aninhamento
        if nesting_depths:
            for depth in nesting_depths.values():
                self.assertIsInstance(depth, int)
                self.assertGreater(depth, 0)
    
    def test_code_smells_detection(self):
        """Testa detecção de code smells."""
        code_smells = self.analyzer.identify_code_smells()
        
        self.assertIsInstance(code_smells, list)
        
        # Verifica estrutura dos code smells
        for smell in code_smells:
            self.assertIsNotNone(smell.type)
            self.assertIsNotNone(smell.description)
            self.assertIsNotNone(smell.location)
            self.assertIsInstance(smell.line_number, int)
            self.assertIn(smell.severity, ['LOW', 'MEDIUM', 'HIGH'])
    
    def test_complexity_report(self):
        """Testa geração de relatório de complexidade."""
        report = self.analyzer.generate_complexity_report()
        
        required_sections = [
            'general_stats', 'complexity_metrics', 'nesting_depths',
            'code_smells', 'quality_score', 'maintainability_index'
        ]
        
        for section in required_sections:
            self.assertIn(section, report)
        
        # Verifica estatísticas gerais
        stats = report['general_stats']
        self.assertGreater(stats['total_lines'], 0)
        self.assertGreaterEqual(stats['total_variables'], 0)
        self.assertGreaterEqual(stats['total_paragraphs'], 0)
        
        # Verifica pontuação de qualidade
        self.assertIsInstance(report['quality_score'], int)
        self.assertGreaterEqual(report['quality_score'], 0)
        self.assertLessEqual(report['quality_score'], 100)


class TestPatternDetector(unittest.TestCase):
    """Testes para o detector de padrões."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.parser = CobolParser()
        self.advanced_file = os.path.join(
            os.path.dirname(__file__), 
            'sample_cobol', 
            'advanced_structures.cbl'
        )
        self.program = self.parser.parse_file(self.advanced_file)
        self.detector = PatternDetector(self.program)
    
    def test_pattern_detection(self):
        """Testa detecção básica de padrões."""
        patterns = self.detector.detect_patterns()
        
        expected_categories = [
            'good_practices', 'anti_patterns', 'design_patterns',
            'performance_issues', 'maintainability_issues'
        ]
        
        for category in expected_categories:
            self.assertIn(category, patterns)
            self.assertIsInstance(patterns[category], list)
    
    def test_good_practices_detection(self):
        """Testa detecção de boas práticas."""
        patterns = self.detector.detect_patterns()
        good_practices = patterns['good_practices']
        
        # Verifica se encontrou pelo menos algumas boas práticas
        self.assertGreater(len(good_practices), 0)
        
        # Verifica estrutura dos padrões
        for pattern in good_practices:
            self.assertEqual(pattern.type, PatternType.GOOD_PRACTICE)
            self.assertIsNotNone(pattern.name)
            self.assertIsNotNone(pattern.description)
            self.assertIsInstance(pattern.confidence, float)
            self.assertGreaterEqual(pattern.confidence, 0.0)
            self.assertLessEqual(pattern.confidence, 1.0)
    
    def test_anti_patterns_detection(self):
        """Testa detecção de anti-padrões."""
        patterns = self.detector.detect_patterns()
        anti_patterns = patterns['anti_patterns']
        
        # Verifica estrutura dos anti-padrões
        for pattern in anti_patterns:
            self.assertEqual(pattern.type, PatternType.ANTI_PATTERN)
            self.assertIn(pattern.impact, ['LOW', 'MEDIUM', 'HIGH'])
            self.assertIsNotNone(pattern.suggestion)
    
    def test_pattern_report(self):
        """Testa geração de relatório de padrões."""
        report = self.detector.generate_pattern_report()
        
        # Verifica estrutura do relatório
        self.assertIn('summary', report)
        self.assertIn('patterns', report)
        self.assertIn('recommendations', report)
        
        # Verifica resumo
        summary = report['summary']
        required_summary_keys = [
            'total_patterns_detected', 'good_practices', 'anti_patterns',
            'design_patterns', 'performance_issues', 'maintainability_issues',
            'high_impact_patterns', 'quality_score'
        ]
        
        for key in required_summary_keys:
            self.assertIn(key, summary)
        
        # Verifica pontuação de qualidade
        self.assertIsInstance(summary['quality_score'], int)
        self.assertGreaterEqual(summary['quality_score'], 0)
        self.assertLessEqual(summary['quality_score'], 100)
        
        # Verifica recomendações
        self.assertIsInstance(report['recommendations'], list)
        self.assertGreater(len(report['recommendations']), 0)


class TestIntegratedSemanticAnalysis(unittest.TestCase):
    """Testes de integração para análise semântica."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.parser = CobolParser()
        self.advanced_file = os.path.join(
            os.path.dirname(__file__), 
            'sample_cobol', 
            'advanced_structures.cbl'
        )
        self.program = self.parser.parse_file(self.advanced_file)
    
    def test_complete_semantic_analysis(self):
        """Testa análise semântica completa."""
        # Análise de fluxo de dados
        data_analyzer = DataFlowAnalyzer(self.program)
        data_summary = data_analyzer.get_data_flow_summary()
        
        # Análise de complexidade
        complexity_analyzer = ComplexityAnalyzer(self.program)
        complexity_report = complexity_analyzer.generate_complexity_report()
        
        # Detecção de padrões
        pattern_detector = PatternDetector(self.program)
        pattern_report = pattern_detector.generate_pattern_report()
        
        # Verifica se todas as análises foram executadas
        self.assertIsNotNone(data_summary)
        self.assertIsNotNone(complexity_report)
        self.assertIsNotNone(pattern_report)
        
        # Verifica consistência entre análises
        self.assertGreater(data_summary['total_variables_used'], 0)
        self.assertGreater(complexity_report['general_stats']['total_variables'], 0)
        self.assertGreater(pattern_report['summary']['total_patterns_detected'], 0)
    
    def test_cross_analysis_correlation(self):
        """Testa correlação entre diferentes análises."""
        # Análise de complexidade
        complexity_analyzer = ComplexityAnalyzer(self.program)
        complexity_metrics = complexity_analyzer.calculate_cyclomatic_complexity()
        
        # Detecção de padrões
        pattern_detector = PatternDetector(self.program)
        patterns = pattern_detector.detect_patterns()
        
        # Verifica correlação: programas mais complexos tendem a ter mais problemas
        program_complexity = complexity_metrics.get('PROGRAM_TOTAL')
        if program_complexity and program_complexity.level in [ComplexityLevel.HIGH, ComplexityLevel.VERY_HIGH]:
            total_issues = (
                len(patterns['anti_patterns']) + 
                len(patterns['performance_issues']) + 
                len(patterns['maintainability_issues'])
            )
            # Programas complexos devem ter pelo menos alguns problemas detectados
            self.assertGreater(total_issues, 0)


if __name__ == '__main__':
    unittest.main()

