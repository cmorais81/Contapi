"""
Testes de integração para o motor de documentação COBOL.
"""

import unittest
import os
import sys
import tempfile
import shutil
from unittest.mock import patch, Mock

# Adiciona o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from cobol_parser import CobolParser
from copilot_integration import CopilotIntegration, AnalysisRequest, AnalysisResponse
from documentation_generator import DocumentationGenerator


class TestIntegration(unittest.TestCase):
    """Testes de integração do motor completo."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.test_dir = tempfile.mkdtemp()
        self.sample_files = [
            os.path.join(os.path.dirname(__file__), 'sample_cobol', 'sample_program.cbl'),
            os.path.join(os.path.dirname(__file__), 'sample_cobol', 'inventory_management.cbl')
        ]
        
        # Cria diretório de templates temporário
        self.template_dir = os.path.join(self.test_dir, 'templates')
        os.makedirs(self.template_dir)
        
        # Copia template para diretório temporário
        template_source = os.path.join(
            os.path.dirname(__file__), '..', 'templates', 
            'documentation_template.markdown.j2'
        )
        template_dest = os.path.join(self.template_dir, 'documentation_template.markdown.j2')
        shutil.copy2(template_source, template_dest)
    
    def tearDown(self):
        """Limpeza após os testes."""
        shutil.rmtree(self.test_dir)
    
    def test_full_pipeline_sample_program(self):
        """Testa o pipeline completo com o programa de exemplo."""
        sample_file = self.sample_files[0]
        
        # 1. Parsing
        parser = CobolParser()
        program = parser.parse_file(sample_file)
        summary = parser.get_program_summary(program)
        
        # Verifica se o parsing funcionou
        self.assertEqual(program.program_id, 'CALC-PAYROLL')
        self.assertGreater(len(program.variables), 0)
        
        # 2. Mock da análise da IA (para não depender da API real)
        mock_analysis = AnalysisResponse(
            program_purpose="Programa para calcular folha de pagamento",
            main_functionality="Calcula salários com horas extras e descontos",
            variables_description={
                "WS-EMP-ID": "Identificação do funcionário",
                "WS-BASIC-SALARY": "Salário base do funcionário"
            },
            business_logic_explanation="Aplica regras de negócio para cálculo salarial",
            input_output_description="Recebe dados do funcionário e exibe relatório",
            execution_flow=["Inicialização", "Entrada de dados", "Cálculos", "Exibição"],
            recommendations=["Validar entrada de dados", "Implementar tratamento de erros"],
            complexity_assessment="Baixa complexidade",
            raw_response="Análise completa do programa COBOL"
        )
        
        # 3. Geração de documentação
        doc_generator = DocumentationGenerator(template_dir=self.template_dir)
        output_path = os.path.join(self.test_dir, 'test_doc.md')
        
        doc_generator.generate_documentation(
            program=program,
            analysis=mock_analysis,
            output_path=output_path,
            output_format="markdown"
        )
        
        # Verifica se o arquivo foi criado
        self.assertTrue(os.path.exists(output_path))
        
        # Verifica conteúdo do arquivo
        with open(output_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        self.assertIn('CALC-PAYROLL', content)
        self.assertIn('Programa para calcular folha de pagamento', content)
        self.assertIn('WS-EMP-ID', content)
    
    def test_full_pipeline_inventory_program(self):
        """Testa o pipeline completo com o programa de inventário."""
        sample_file = self.sample_files[1]
        
        # 1. Parsing
        parser = CobolParser()
        program = parser.parse_file(sample_file)
        summary = parser.get_program_summary(program)
        
        # Verifica se o parsing funcionou
        self.assertEqual(program.program_id, 'INVENTORY-MGMT')
        self.assertGreater(len(program.variables), 0)
        self.assertGreater(summary['total_sections'], 0)
        
        # 2. Mock da análise da IA
        mock_analysis = AnalysisResponse(
            program_purpose="Sistema de gerenciamento de estoque",
            main_functionality="Gerencia produtos, estoque e relatórios",
            variables_description={
                "PROD-ID": "Identificação do produto",
                "PROD-QUANTITY": "Quantidade em estoque"
            },
            business_logic_explanation="Controla estoque com validações de mínimo",
            input_output_description="Interface de menu para operações de estoque",
            execution_flow=["Menu principal", "Operações", "Relatórios"],
            recommendations=["Implementar backup", "Validar dados de entrada"],
            complexity_assessment="Média complexidade",
            raw_response="Análise do sistema de estoque"
        )
        
        # 3. Geração de documentação
        doc_generator = DocumentationGenerator(template_dir=self.template_dir)
        output_path = os.path.join(self.test_dir, 'inventory_doc.md')
        
        doc_generator.generate_documentation(
            program=program,
            analysis=mock_analysis,
            output_path=output_path,
            output_format="markdown"
        )
        
        # Verifica se o arquivo foi criado
        self.assertTrue(os.path.exists(output_path))
        
        # Verifica conteúdo do arquivo
        with open(output_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        self.assertIn('INVENTORY-MGMT', content)
        self.assertIn('Sistema de gerenciamento de estoque', content)
        self.assertIn('PROD-ID', content)
    
    def test_parser_with_different_cobol_structures(self):
        """Testa o parser com diferentes estruturas COBOL."""
        parser = CobolParser()
        
        for sample_file in self.sample_files:
            with self.subTest(file=sample_file):
                program = parser.parse_file(sample_file)
                summary = parser.get_program_summary(program)
                
                # Verifica estruturas básicas
                self.assertIsNotNone(program.program_id)
                self.assertIsInstance(program.variables, list)
                self.assertIsInstance(program.sections, list)
                self.assertIsInstance(summary, dict)
                
                # Verifica se pelo menos algumas informações foram extraídas
                self.assertGreater(summary['total_variables'], 0)
    
    def test_documentation_generator_error_handling(self):
        """Testa o tratamento de erros do gerador de documentação."""
        doc_generator = DocumentationGenerator(template_dir=self.template_dir)
        
        # Testa formato inválido
        with self.assertRaises(ValueError):
            doc_generator.generate_documentation(
                program=Mock(),
                analysis=Mock(),
                output_path="/tmp/test.txt",
                output_format="invalid_format"
            )
        
        # Testa caminho inválido
        with self.assertRaises(Exception):
            doc_generator.generate_documentation(
                program=Mock(),
                analysis=Mock(),
                output_path="/invalid/path/test.md",
                output_format="markdown"
            )


if __name__ == '__main__':
    unittest.main()

