"""
Testes para integração aprimorada com Copilot.
"""

import unittest
import sys
import os
from unittest.mock import Mock, patch

# Adiciona o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from cobol_parser import CobolParser
from enhanced_copilot_integration import EnhancedCopilotIntegration, DocumentationRequest
from specialized_prompts import AnalysisType
from contextual_analyzer import ContextualAnalyzer, BusinessDomain


class TestEnhancedCopilotIntegration(unittest.TestCase):
    """Testes para integração aprimorada com Copilot."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.parser = CobolParser()
        self.advanced_file = os.path.join(
            os.path.dirname(__file__), 
            'sample_cobol', 
            'advanced_structures.cbl'
        )
        self.program = self.parser.parse_file(self.advanced_file)
        
        # Mock da integração para evitar chamadas reais à API
        with patch.dict(os.environ, {'OPENAI_API_KEY': 'test_key'}):
            self.integration = EnhancedCopilotIntegration()
    
    def test_initialization(self):
        """Testa inicialização da integração aprimorada."""
        self.assertIsNotNone(self.integration.specialized_prompts)
        self.assertIsNotNone(self.integration.contextual_analyzer)
        self.assertEqual(self.integration._analysis_cache, {})
    
    def test_technical_analyses_execution(self):
        """Testa execução das análises técnicas."""
        analyses = self.integration._perform_technical_analyses(self.program)
        
        # Verifica se todas as análises foram executadas
        self.assertIn('data_flow', analyses)
        self.assertIn('complexity', analyses)
        self.assertIn('patterns', analyses)
        
        # Verifica se não há erros nas análises
        for analysis_name, analysis_result in analyses.items():
            self.assertNotIn('error', analysis_result, 
                           f"Erro na análise {analysis_name}: {analysis_result.get('error', '')}")
    
    def test_cache_functionality(self):
        """Testa funcionalidade de cache."""
        # Primeira execução
        analyses1 = self.integration._perform_technical_analyses(self.program)
        
        # Segunda execução (deve usar cache)
        analyses2 = self.integration._perform_technical_analyses(self.program)
        
        # Verifica se os resultados são idênticos (cache funcionando)
        self.assertEqual(analyses1, analyses2)
        
        # Verifica estatísticas do cache
        cache_stats = self.integration.get_cache_stats()
        self.assertGreater(cache_stats['cached_analyses'], 0)
        self.assertGreater(cache_stats['cache_size_mb'], 0)
    
    def test_cache_clearing(self):
        """Testa limpeza do cache."""
        # Executa análise para popular cache
        self.integration._perform_technical_analyses(self.program)
        
        # Verifica que cache não está vazio
        self.assertGreater(len(self.integration._analysis_cache), 0)
        
        # Limpa cache
        self.integration.clear_cache()
        
        # Verifica que cache está vazio
        self.assertEqual(len(self.integration._analysis_cache), 0)
    
    @patch('openai.ChatCompletion.create')
    def test_analysis_documentation_generation(self, mock_openai):
        """Testa geração de documentação de análise."""
        # Mock da resposta da API
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Documentação de teste gerada"
        mock_openai.return_value = mock_response
        
        # Constrói contexto do programa
        program_context = self.integration.contextual_analyzer.build_context(self.program)
        technical_analyses = self.integration._perform_technical_analyses(self.program)
        
        # Testa geração de documentação
        doc = self.integration._generate_analysis_documentation(
            AnalysisType.BUSINESS_LOGIC,
            self.program,
            program_context,
            technical_analyses,
            "technical"
        )
        
        self.assertEqual(doc, "Documentação de teste gerada")
        self.assertTrue(mock_openai.called)
    
    @patch('openai.ChatCompletion.create')
    def test_comprehensive_documentation_generation(self, mock_openai):
        """Testa geração de documentação abrangente."""
        # Mock da resposta da API
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Documentação abrangente de teste"
        mock_openai.return_value = mock_response
        
        # Cria requisição de documentação
        request = DocumentationRequest(
            program=self.program,
            analysis_types=[AnalysisType.BUSINESS_LOGIC, AnalysisType.DATA_STRUCTURE],
            include_technical_details=True,
            target_audience="technical"
        )
        
        # Gera documentação
        documentation = self.integration.generate_comprehensive_documentation(request)
        
        # Verifica se documentação foi gerada para todos os tipos solicitados
        self.assertIn(AnalysisType.BUSINESS_LOGIC.value, documentation)
        self.assertIn(AnalysisType.DATA_STRUCTURE.value, documentation)
        self.assertIn('executive_summary', documentation)  # Deve gerar resumo executivo
    
    @patch('openai.ChatCompletion.create')
    def test_quick_analysis_generation(self, mock_openai):
        """Testa geração de análise rápida."""
        # Mock da resposta da API
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Análise rápida de teste"
        mock_openai.return_value = mock_response
        
        # Testa diferentes focos de análise
        focuses = ["business", "technical", "security", "performance"]
        
        for focus in focuses:
            analysis = self.integration.generate_quick_analysis(self.program, focus)
            self.assertEqual(analysis, "Análise rápida de teste")
    
    @patch('openai.ChatCompletion.create')
    def test_comparison_analysis(self, mock_openai):
        """Testa análise comparativa."""
        # Mock da resposta da API
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = "Análise comparativa de teste"
        mock_openai.return_value = mock_response
        
        # Cria segundo programa para comparação
        sample_file = os.path.join(
            os.path.dirname(__file__), 
            'sample_cobol', 
            'sample_program.cbl'
        )
        program2 = self.parser.parse_file(sample_file)
        
        # Testa análise comparativa
        comparison = self.integration.generate_comparison_analysis([self.program, program2])
        self.assertEqual(comparison, "Análise comparativa de teste")
        
        # Testa com apenas um programa (deve retornar erro)
        single_comparison = self.integration.generate_comparison_analysis([self.program])
        self.assertIn("pelo menos 2 programas", single_comparison)
    
    def test_format_analysis_summary(self):
        """Testa formatação de resumo de análises."""
        generated_docs = {
            'business_logic': 'Análise de lógica de negócio com muitas palavras para teste',
            'data_structure': 'Análise de estrutura de dados',
            'executive_summary': 'Resumo executivo'
        }
        
        summary = self.integration._format_analysis_summary(generated_docs)
        
        # Verifica se resumo executivo não é incluído
        self.assertNotIn('executive_summary', summary)
        
        # Verifica se outras análises são incluídas
        self.assertIn('Business Logic', summary)
        self.assertIn('Data Structure', summary)
        
        # Verifica se contagem de palavras está presente
        self.assertIn('palavras', summary)
    
    def test_format_detailed_analyses(self):
        """Testa formatação de análises detalhadas."""
        technical_analyses = {
            'data_flow': {
                'total_variables_used': 25,
                'total_data_operations': 50
            },
            'complexity': {
                'quality_score': 75,
                'code_smells': [{'type': 'test'}, {'type': 'test2'}]
            },
            'patterns': {
                'summary': {
                    'total_patterns_detected': 10
                }
            }
        }
        
        summary = self.integration._format_detailed_analyses(technical_analyses)
        
        # Verifica se informações estão presentes
        self.assertIn('25 variáveis', summary)
        self.assertIn('50 operações', summary)
        self.assertIn('Pontuação 75', summary)
        self.assertIn('2 problemas', summary)
        self.assertIn('10 padrões', summary)
    
    def test_error_handling_in_technical_analyses(self):
        """Testa tratamento de erros nas análises técnicas."""
        # Cria programa com conteúdo inválido para forçar erro
        invalid_program = Mock()
        invalid_program.program_id = "INVALID"
        invalid_program.raw_content = ""
        invalid_program.variables = []
        
        # Executa análises (deve capturar erros)
        analyses = self.integration._perform_technical_analyses(invalid_program)
        
        # Verifica se erros foram capturados adequadamente
        for analysis_name, analysis_result in analyses.items():
            if 'error' in analysis_result:
                self.assertIsInstance(analysis_result['error'], str)
    
    @patch('openai.ChatCompletion.create')
    def test_api_error_handling(self, mock_openai):
        """Testa tratamento de erros da API."""
        # Mock de erro da API
        mock_openai.side_effect = Exception("Erro de teste da API")
        
        # Constrói contexto do programa
        program_context = self.integration.contextual_analyzer.build_context(self.program)
        technical_analyses = self.integration._perform_technical_analyses(self.program)
        
        # Testa geração de documentação com erro
        doc = self.integration._generate_analysis_documentation(
            AnalysisType.BUSINESS_LOGIC,
            self.program,
            program_context,
            technical_analyses,
            "technical"
        )
        
        # Verifica se erro foi tratado adequadamente
        self.assertIn("Erro na geração de documentação", doc)
        self.assertIn("Erro de teste da API", doc)


class TestSpecializedPromptsIntegration(unittest.TestCase):
    """Testes para integração com prompts especializados."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.parser = CobolParser()
        self.advanced_file = os.path.join(
            os.path.dirname(__file__), 
            'sample_cobol', 
            'advanced_structures.cbl'
        )
        self.program = self.parser.parse_file(self.advanced_file)
        
        with patch.dict(os.environ, {'OPENAI_API_KEY': 'test_key'}):
            self.integration = EnhancedCopilotIntegration()
    
    def test_specialized_prompts_initialization(self):
        """Testa inicialização dos prompts especializados."""
        self.assertIsNotNone(self.integration.specialized_prompts)
        
        # Verifica se prompts especializados podem ser gerados
        from specialized_prompts import PromptContext
        
        context = PromptContext(
            analysis_type=AnalysisType.BUSINESS_LOGIC,
            program=self.program
        )
        
        prompt = self.integration.specialized_prompts.get_specialized_prompt(context)
        self.assertIsInstance(prompt, str)
        self.assertGreater(len(prompt), 100)  # Prompt deve ser substancial
    
    def test_contextual_analyzer_integration(self):
        """Testa integração com analisador contextual."""
        self.assertIsNotNone(self.integration.contextual_analyzer)
        
        # Verifica se contexto pode ser construído
        context = self.integration.contextual_analyzer.build_context(self.program)
        
        self.assertIsNotNone(context.business_domain)
        self.assertIsNotNone(context.complexity_category)
        self.assertIsInstance(context.critical_sections, list)
        self.assertIsInstance(context.insights, list)
    
    def test_prompt_context_building(self):
        """Testa construção de contexto para prompts."""
        # Executa análises técnicas
        technical_analyses = self.integration._perform_technical_analyses(self.program)
        program_context = self.integration.contextual_analyzer.build_context(self.program)
        
        # Simula construção de contexto de prompt
        from specialized_prompts import PromptContext
        
        prompt_context = PromptContext(
            analysis_type=AnalysisType.BUSINESS_LOGIC,
            program=self.program,
            complexity_metrics=technical_analyses.get('complexity'),
            data_flow_summary=technical_analyses.get('data_flow'),
            pattern_report=technical_analyses.get('patterns'),
            domain_indicators=[program_context.business_domain.value] if program_context.domain_confidence > 0.5 else [],
            critical_sections=program_context.critical_sections
        )
        
        # Verifica se contexto foi construído corretamente
        self.assertEqual(prompt_context.analysis_type, AnalysisType.BUSINESS_LOGIC)
        self.assertEqual(prompt_context.program, self.program)
        self.assertIsNotNone(prompt_context.complexity_metrics)
        self.assertIsNotNone(prompt_context.data_flow_summary)
        self.assertIsNotNone(prompt_context.pattern_report)


if __name__ == '__main__':
    unittest.main()

