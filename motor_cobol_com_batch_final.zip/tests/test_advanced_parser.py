"""
Testes para funcionalidades avançadas do parser COBOL.
"""

import unittest
import sys
import os

# Adiciona o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from cobol_parser import CobolParser
from copy_book_resolver import CopyBookResolver
from cobol_file import FileAnalyzer


class TestAdvancedParser(unittest.TestCase):
    """Testes para funcionalidades avançadas do parser."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.parser = CobolParser()
        self.advanced_file = os.path.join(
            os.path.dirname(__file__), 
            'sample_cobol', 
            'advanced_structures.cbl'
        )
    
    def test_advanced_variable_parsing(self):
        """Testa parsing de variáveis com estruturas avançadas."""
        program = self.parser.parse_file(self.advanced_file)
        
        # Verifica se variáveis foram extraídas
        self.assertGreater(len(program.variables), 0)
        
        # Procura por variáveis específicas
        variable_names = [var.name for var in program.variables]
        
        # Testa estruturas hierárquicas
        self.assertIn('WS-CUSTOMER-TABLE', variable_names)
        self.assertIn('WS-CUSTOMER-ENTRY', variable_names)
        self.assertIn('WS-CUST-ID', variable_names)
        
        # Testa REDEFINES
        redefines_vars = [var for var in program.variables if var.redefines]
        self.assertGreater(len(redefines_vars), 0)
        
        # Verifica se encontrou a variável que redefine
        numeric_area = next((var for var in program.variables if var.name == 'WS-NUMERIC-AREA'), None)
        self.assertIsNotNone(numeric_area)
        self.assertEqual(numeric_area.redefines, 'WS-REDEFINE-AREA')
    
    def test_occurs_clause_parsing(self):
        """Testa parsing de cláusulas OCCURS."""
        program = self.parser.parse_file(self.advanced_file)
        
        # Procura variável com OCCURS
        customer_entry = next((var for var in program.variables if var.name == 'WS-CUSTOMER-ENTRY'), None)
        self.assertIsNotNone(customer_entry)
        self.assertEqual(customer_entry.occurs, 100)
        self.assertEqual(customer_entry.occurs_depending, 'WS-CUSTOMER-COUNT')
    
    def test_condition_names_parsing(self):
        """Testa parsing de condition names (88 levels)."""
        program = self.parser.parse_file(self.advanced_file)
        
        # Procura variável com condition names
        file_status_var = next((var for var in program.variables if var.name == 'WS-FILE-STATUS'), None)
        self.assertIsNotNone(file_status_var)
        self.assertGreater(len(file_status_var.condition_names), 0)
        
        # Verifica se condition names foram capturados
        condition_names_text = ' '.join(file_status_var.condition_names)
        self.assertIn('FILE-OK', condition_names_text)
        self.assertIn('FILE-EOF', condition_names_text)
    
    def test_hierarchical_structure(self):
        """Testa construção de hierarquia de variáveis."""
        program = self.parser.parse_file(self.advanced_file)
        
        # Verifica relações pai-filho
        customer_table = next((var for var in program.variables if var.name == 'WS-CUSTOMER-TABLE'), None)
        self.assertIsNotNone(customer_table)
        self.assertGreater(len(customer_table.children), 0)
        
        # Verifica se filhos têm referência ao pai
        customer_count = next((var for var in program.variables if var.name == 'WS-CUSTOMER-COUNT'), None)
        self.assertIsNotNone(customer_count)
        self.assertEqual(customer_count.parent, 'WS-CUSTOMER-TABLE')


class TestCopyBookResolver(unittest.TestCase):
    """Testes para o resolver de COPY BOOKS."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.resolver = CopyBookResolver()
    
    def test_find_copy_references(self):
        """Testa identificação de referências COPY."""
        content = """
       WORKING-STORAGE SECTION.
       COPY CUSTOMER-RECORD.
       COPY COMMON-FIELDS OF LIBRARY1.
       COPY ERROR-CODES REPLACING ==:PREFIX:== BY ==WS-==.
       01  WS-WORK-AREA PIC X(100).
        """
        
        references = self.resolver.find_copy_references(content)
        
        self.assertEqual(len(references), 3)
        
        # Verifica primeira referência
        self.assertEqual(references[0].name, 'CUSTOMER-RECORD')
        self.assertIsNone(references[0].library_name)
        
        # Verifica segunda referência com biblioteca
        self.assertEqual(references[1].name, 'COMMON-FIELDS')
        self.assertEqual(references[1].library_name, 'LIBRARY1')
        
        # Verifica terceira referência com REPLACING
        self.assertEqual(references[2].name, 'ERROR-CODES')
        self.assertIn(':PREFIX:', references[2].replacing_clauses)
    
    def test_applying_replacing_clauses(self):
        """Testa aplicação de cláusulas REPLACING."""
        content = """
       01  :PREFIX:-RECORD.
           05  :PREFIX:-ID    PIC 9(5).
           05  :PREFIX:-NAME  PIC X(30).
        """
        
        replacing_clauses = {':PREFIX:': 'WS'}
        result = self.resolver.apply_replacing_clauses(content, replacing_clauses)
        
        self.assertIn('WS-RECORD', result)
        self.assertIn('WS-ID', result)
        self.assertIn('WS-NAME', result)
        self.assertNotIn(':PREFIX:', result)


class TestFileAnalyzer(unittest.TestCase):
    """Testes para o analisador de arquivos."""
    
    def setUp(self):
        """Configuração inicial dos testes."""
        self.analyzer = FileAnalyzer()
    
    def test_parse_select_statement(self):
        """Testa parsing de declarações SELECT."""
        line = "SELECT CUSTOMER-FILE ASSIGN TO 'CUSTOMER.DAT' ORGANIZATION IS INDEXED ACCESS MODE IS DYNAMIC RECORD KEY IS CUST-ID"
        
        cobol_file = self.analyzer.parse_select_statement(line, 1)
        
        self.assertIsNotNone(cobol_file)
        self.assertEqual(cobol_file.name, 'CUSTOMER-FILE')
        self.assertEqual(cobol_file.assign_to, 'CUSTOMER.DAT')
        self.assertEqual(cobol_file.organization.value, 'INDEXED')
        self.assertEqual(cobol_file.access_mode.value, 'DYNAMIC')
        self.assertEqual(cobol_file.record_key, 'CUST-ID')
    
    def test_find_file_operations(self):
        """Testa identificação de operações de arquivo."""
        content = """
       100-PROCESS-FILE.
           OPEN INPUT CUSTOMER-FILE
           READ CUSTOMER-FILE INTO WS-CUSTOMER-RECORD
           WRITE CUSTOMER-RECORD FROM WS-CUSTOMER-RECORD
           CLOSE CUSTOMER-FILE.
        """
        
        operations = self.analyzer.find_file_operations(content)
        
        self.assertEqual(len(operations), 4)
        
        # Verifica operação OPEN
        open_op = next((op for op in operations if op.operation_type == 'OPEN'), None)
        self.assertIsNotNone(open_op)
        self.assertEqual(open_op.file_name, 'CUSTOMER-FILE')
        self.assertEqual(open_op.mode, 'INPUT')
        
        # Verifica operação READ
        read_op = next((op for op in operations if op.operation_type == 'READ'), None)
        self.assertIsNotNone(read_op)
        self.assertEqual(read_op.into_variable, 'WS-CUSTOMER-RECORD')
    
    def test_analyze_file_usage_patterns(self):
        """Testa análise de padrões de uso de arquivos."""
        operations = [
            type('FileOperation', (), {
                'operation_type': 'OPEN',
                'file_name': 'TEST-FILE',
                'paragraph': 'OPEN-FILES'
            })(),
            type('FileOperation', (), {
                'operation_type': 'READ',
                'file_name': 'TEST-FILE',
                'paragraph': 'READ-RECORDS'
            })(),
            type('FileOperation', (), {
                'operation_type': 'CLOSE',
                'file_name': 'TEST-FILE',
                'paragraph': 'CLOSE-FILES'
            })()
        ]
        
        patterns = self.analyzer.analyze_file_usage_patterns(operations)
        
        self.assertIn('TEST-FILE', patterns)
        file_pattern = patterns['TEST-FILE']
        
        self.assertEqual(file_pattern['access_pattern'], 'read_only')
        self.assertEqual(file_pattern['usage_frequency'], 3)
        self.assertIn('READ-RECORDS', file_pattern['paragraphs_used'])


if __name__ == '__main__':
    unittest.main()

