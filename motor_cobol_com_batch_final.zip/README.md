# Motor de Documentação COBOL

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![OpenAI](https://img.shields.io/badge/AI-OpenAI%20GPT--4-green.svg)](https://openai.com/)

Motor avançado para análise, documentação e modernização de programas COBOL usando inteligência artificial e análise semântica.

## 🚀 Características Principais

- **Parser COBOL Avançado**: Suporte completo a COPY BOOKS, estruturas hierárquicas e FILE SECTION
- **Análise Semântica**: Mapeamento de fluxo de dados, complexidade ciclomática e detecção de padrões
- **Integração com IA**: OpenAI GPT-4, Azure OpenAI e GitHub Copilot para documentação inteligente
- **Sistema de Plugins**: Arquitetura extensível com plugins de segurança, performance e migração
- **Múltiplos Formatos**: Saída em JSON, YAML, Markdown, HTML e PDF
- **CLI Avançada**: Interface completa de linha de comando

## 📋 Requisitos

- **Python**: 3.11, 3.12 ou 3.13
- **Sistema Operacional**: Windows, macOS, Linux
- **Memória**: Mínimo 4GB RAM (recomendado 8GB)
- **API OpenAI**: Chave opcional para funcionalidades de IA

## ⚡ Instalação Rápida

### Python 3.13 (Recomendado)

```bash
# 1. Clone ou extraia o projeto
cd cobol_documentation_engine

# 2. Crie ambiente virtual
python3.13 -m venv venv
source venv/bin/activate  # Linux/macOS
# ou
venv\Scripts\activate     # Windows

# 3. Instale dependências
pip install -r requirements.txt

# 4. Configure API OpenAI (opcional)
cp .env.example .env
# Edite .env com sua chave OpenAI

# 5. Teste a instalação
python src/enhanced_cli.py --help
```

### Instalação Detalhada

Para instruções completas de instalação, consulte:
- **[Guia de Instalação Python 3.13](INSTALACAO_PYTHON313.md)**
- **[Guia de Integração com IA](INTEGRACAO_IA.md)**

## 🎯 Uso Rápido

### Análise Básica

```bash
# Análise simples
python src/enhanced_cli.py analyze programa.cbl

# Análise com plugins
python src/enhanced_cli.py analyze programa.cbl \
  --plugins security_analyzer performance_analyzer \
  --output ./resultados --format json
```

### Documentação com IA

```bash
# Documentação completa
python src/enhanced_cli.py document programa.cbl --output ./docs

# Análise rápida focada
python src/enhanced_cli.py quick programa.cbl --focus security
```

### Gerenciamento de Plugins

```bash
# Listar plugins disponíveis
python src/enhanced_cli.py plugins discover

# Carregar plugin específico
python src/enhanced_cli.py plugins load security_analyzer
```

## 📊 Exemplo de Resultado

### Entrada: Programa COBOL
```cobol
IDENTIFICATION DIVISION.
PROGRAM-ID. CALC-PAYROLL.
AUTHOR. SISTEMA DE FOLHA DE PAGAMENTO.

DATA DIVISION.
WORKING-STORAGE SECTION.
01  WS-EMPLOYEE-RECORD.
    05  WS-EMP-ID           PIC 9(6).
    05  WS-BASIC-SALARY     PIC 9(7)V99.
    05  WS-OVERTIME-HOURS   PIC 9(3).

PROCEDURE DIVISION.
MAIN-PROCESS SECTION.
000-MAIN-ROUTINE.
    PERFORM 100-CALCULATE-PAY
    PERFORM 200-DISPLAY-RESULTS.
```

### Saída: Análise Completa
```yaml
security_analysis:
  security_score: 92
  issues: 6
  compliance_status: "COMPLIANT"
  
performance_analysis:
  performance_score: 94
  complexity: "LOW"
  optimization_opportunities: 0
  
program_structure:
  variables: 14
  sections: 1
  lines_of_code: 77
  business_domain: "payroll"
```

## 🔌 Plugins Disponíveis

### Security Analyzer
- Detecção de vulnerabilidades
- Análise de compliance
- Pontuação de segurança (0-100)
- Recomendações específicas

### Performance Analyzer
- Análise de complexidade ciclomática
- Detecção de gargalos
- Oportunidades de otimização
- Métricas de qualidade

### Migration Analyzer
- Avaliação de prontidão para migração
- Estratégias de modernização
- Estimativa de esforço
- Roadmap de migração

## 🤖 Integração com IA

### OpenAI/ChatGPT
```bash
# Configurar chave da API
export OPENAI_API_KEY="sk-sua_chave_aqui"
export OPENAI_MODEL="gpt-4"

# Gerar documentação inteligente
python src/enhanced_cli.py document programa.cbl \
  --output ./docs --audience business
```

### Azure OpenAI
```bash
# Configurar Azure
export OPENAI_API_TYPE="azure"
export OPENAI_API_BASE="https://seu-recurso.openai.azure.com/"
export OPENAI_DEPLOYMENT_NAME="gpt-4"
```

Para configuração completa, consulte **[Guia de Integração com IA](INTEGRACAO_IA.md)**.

## 📚 Documentação

- **[Manual de Uso Completo](manual_de_uso_cobol_engine.md)** - Guia abrangente
- **[Documentação Técnica](documentacao_motor_cobol.md)** - Especificações detalhadas
- **[Guia de Instalação](INSTALACAO_PYTHON313.md)** - Instalação Python 3.13
- **[Integração com IA](INTEGRACAO_IA.md)** - Configuração OpenAI/Copilot

## 🧪 Testes

```bash
# Executar todos os testes
pytest tests/ -v

# Testes específicos
pytest tests/test_cobol_parser.py -v
pytest tests/test_plugin_system.py -v

# Cobertura de testes
pytest tests/ --cov=src --cov-report=html
```

## 🛠️ Desenvolvimento

### Configuração de Desenvolvimento

```bash
# Instalar dependências de desenvolvimento
pip install -e ".[dev]"

# Instalar ferramentas de qualidade
pip install black flake8 mypy

# Executar formatação
black src/ tests/

# Verificar qualidade do código
flake8 src/ tests/
mypy src/
```

### Criando Plugins Customizados

```python
from plugin_system import AnalyzerPlugin, PluginMetadata

class MeuPlugin(AnalyzerPlugin):
    @property
    def metadata(self):
        return PluginMetadata(
            name="meu_plugin",
            version="1.0.0",
            description="Meu plugin customizado"
        )
    
    def analyze(self, program):
        return {"resultado": "análise customizada"}
```

## 📈 Performance

### Benchmarks Típicos
- **Programas pequenos** (< 1.000 linhas): < 10 segundos
- **Programas médios** (1.000-10.000 linhas): 30-60 segundos
- **Programas grandes** (> 10.000 linhas): 2-5 minutos
- **Processamento em lote**: 100+ programas por hora

### Otimização
- Cache habilitado por padrão
- Processamento paralelo de plugins
- Rate limiting para APIs
- Análise incremental

## 🔧 Configuração

### Arquivo .env
```bash
# API OpenAI
OPENAI_API_KEY=sk-sua_chave_aqui
OPENAI_MODEL=gpt-4
OPENAI_MAX_TOKENS=4000

# Configurações do motor
COBOL_ENGINE_LOG_LEVEL=INFO
COBOL_ENGINE_CACHE_ENABLED=true
PLUGINS_ENABLED=security_analyzer,performance_analyzer
```

### Configuração Avançada
```yaml
# config/default_config.yaml
model: "gpt-4"
max_tokens: 4000
temperature: 0.3

analysis:
  enable_copy_books: true
  max_complexity_threshold: 10
  
output:
  default_format: "markdown"
  include_technical_details: true
```

## 🤝 Contribuição

1. **Fork** o repositório
2. **Crie** uma branch para sua feature (`git checkout -b feature/nova-funcionalidade`)
3. **Commit** suas mudanças (`git commit -am 'Adiciona nova funcionalidade'`)
4. **Push** para a branch (`git push origin feature/nova-funcionalidade`)
5. **Abra** um Pull Request

## 📄 Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🆘 Suporte

### Problemas Comuns
- **Erro de API**: Verifique chave OpenAI em `.env`
- **Plugin não carrega**: Verifique sintaxe e dependências
- **Erro de parsing**: Verifique formato do arquivo COBOL

### Recursos
- **Issues**: Reporte problemas no repositório
- **Discussões**: Participe das discussões da comunidade
- **Wiki**: Consulte a wiki para exemplos avançados

### Contato
- **Email**: dev@empresa.com
- **GitHub**: https://github.com/empresa/cobol-documentation-engine

---

## 🎯 Casos de Uso

### Auditoria de Segurança
```bash
python src/enhanced_cli.py analyze sistema_financeiro.cbl \
  --plugins security_analyzer \
  --output ./auditoria_seguranca
```

### Planejamento de Modernização
```bash
python src/enhanced_cli.py document sistema_legacy.cbl \
  --types migration business_logic \
  --audience mixed --output ./plano_modernizacao
```

### Otimização de Performance
```bash
python src/enhanced_cli.py analyze batch_processor.cbl \
  --plugins performance_analyzer \
  --output ./relatorio_performance
```

### Transferência de Conhecimento
```bash
python src/enhanced_cli.py document *.cbl \
  --output ./base_conhecimento \
  --audience technical --format markdown
```

---

**Motor de Documentação COBOL** - Transformando análise de código legacy com IA  
**Versão**: 1.0.0 | **Python**: 3.11+ | **Licença**: MIT

