"""
Plugin de análise de migração para programas COBOL.
"""

import re
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass
from enum import Enum

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from plugin_system import AnalyzerPlugin, PluginMetadata, PluginType, PluginPriority
from cobol_parser import CobolProgram


class MigrationComplexity(Enum):
    """Níveis de complexidade de migração."""
    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"
    VERY_COMPLEX = "very_complex"


class ModernizationStrategy(Enum):
    """Estratégias de modernização."""
    REWRITE = "rewrite"
    REFACTOR = "refactor"
    WRAP = "wrap"
    REPLACE = "replace"
    MAINTAIN = "maintain"


@dataclass
class MigrationIssue:
    """Representa um problema de migração identificado."""
    category: str
    description: str
    complexity: MigrationComplexity
    line_number: int
    code_snippet: str
    impact: str
    modernization_options: List[str]
    estimated_effort: str


class MigrationAnalyzerPlugin(AnalyzerPlugin):
    """Plugin para análise de migração de programas COBOL."""
    
    def __init__(self):
        self.config = {}
        self.legacy_patterns = {
            'mainframe_specific': {
                'patterns': [
                    r'(?i)(cics|ims|db2|vsam|qsam|isam)',
                    r'(?i)(jcl|job|step|dd\s+)',
                    r'(?i)(tso|ispf|sdsf)',
                    r'(?i)(mvs|zos|os/390)'
                ],
                'complexity': MigrationComplexity.COMPLEX,
                'category': 'Mainframe Dependencies'
            },
            'file_systems': {
                'patterns': [
                    r'(?i)(vsam|qsam|isam|ksds|esds|rrds)',
                    r'(?i)organization\s+is\s+(indexed|sequential|relative)',
                    r'(?i)access\s+mode\s+is\s+(sequential|random|dynamic)'
                ],
                'complexity': MigrationComplexity.MODERATE,
                'category': 'File System Dependencies'
            },
            'database_access': {
                'patterns': [
                    r'(?i)exec\s+sql',
                    r'(?i)exec\s+cics',
                    r'(?i)call\s+["\'].*sql',
                    r'(?i)(commit|rollback)\s*\.'
                ],
                'complexity': MigrationComplexity.MODERATE,
                'category': 'Database Access Patterns'
            },
            'screen_handling': {
                'patterns': [
                    r'(?i)(bms|map|mapset)',
                    r'(?i)(send\s+map|receive\s+map)',
                    r'(?i)(dfhcommarea|dfheiblk)',
                    r'(?i)screen\s+section'
                ],
                'complexity': MigrationComplexity.COMPLEX,
                'category': 'Screen/UI Handling'
            },
            'copybooks': {
                'patterns': [
                    r'(?i)copy\s+[a-zA-Z0-9\-]+',
                    r'(?i)include\s+[a-zA-Z0-9\-]+'
                ],
                'complexity': MigrationComplexity.MODERATE,
                'category': 'Copybook Dependencies'
            },
            'cobol_extensions': {
                'patterns': [
                    r'(?i)(comp-3|comp-4|comp-5)',
                    r'(?i)usage\s+is\s+(comp|binary|packed-decimal)',
                    r'(?i)(redefines|occurs\s+depending)',
                    r'(?i)(sort|merge)\s+'
                ],
                'complexity': MigrationComplexity.SIMPLE,
                'category': 'COBOL-Specific Features'
            },
            'system_calls': {
                'patterns': [
                    r'(?i)call\s+["\'].*system',
                    r'(?i)call\s+["\'].*(cmd|command)',
                    r'(?i)(system|environ)\s*\('
                ],
                'complexity': MigrationComplexity.COMPLEX,
                'category': 'System Integration'
            }
        }
    
    @property
    def metadata(self) -> PluginMetadata:
        """Retorna metadados do plugin."""
        return PluginMetadata(
            name="migration_analyzer",
            version="1.0.0",
            description="Analisa programas COBOL para planejamento de migração e modernização",
            author="COBOL Documentation Engine",
            plugin_type=PluginType.ANALYZER,
            priority=PluginPriority.NORMAL,
            dependencies=[],
            config_schema={
                "target_platform": {"type": "string", "default": "cloud", "enum": ["cloud", "java", "dotnet", "python"]},
                "migration_strategy": {"type": "string", "default": "refactor", "enum": ["rewrite", "refactor", "wrap", "replace"]},
                "complexity_threshold": {"type": "string", "default": "moderate"},
                "include_effort_estimation": {"type": "boolean", "default": True}
            }
        )
    
    def initialize(self, config: Dict[str, Any]) -> bool:
        """Inicializa o plugin com configuração."""
        try:
            self.config = config
            return True
        except Exception as e:
            print(f"Erro na inicialização do MigrationAnalyzer: {str(e)}")
            return False
    
    def analyze(self, program: CobolProgram) -> Dict[str, Any]:
        """Analisa programa COBOL para migração."""
        issues = []
        lines = program.raw_content.split('\n')
        
        # Analisa padrões legacy
        for pattern_name, pattern_info in self.legacy_patterns.items():
            pattern_issues = self._analyze_pattern(lines, pattern_name, pattern_info)
            issues.extend(pattern_issues)
        
        # Análise de complexidade geral
        complexity_analysis = self._analyze_migration_complexity(program, issues)
        
        # Estratégia de modernização recomendada
        modernization_strategy = self._recommend_modernization_strategy(complexity_analysis, issues)
        
        # Estimativa de esforço
        effort_estimation = self._estimate_migration_effort(complexity_analysis, issues)
        
        # Roadmap de migração
        migration_roadmap = self._generate_migration_roadmap(issues, complexity_analysis)
        
        # Análise de riscos
        risk_analysis = self._analyze_migration_risks(issues, complexity_analysis)
        
        return {
            'issues': [self._issue_to_dict(issue) for issue in issues],
            'complexity_analysis': complexity_analysis,
            'modernization_strategy': modernization_strategy,
            'effort_estimation': effort_estimation,
            'migration_roadmap': migration_roadmap,
            'risk_analysis': risk_analysis,
            'readiness_score': self._calculate_readiness_score(complexity_analysis, issues),
            'technology_mapping': self._generate_technology_mapping(issues)
        }
    
    def _analyze_pattern(self, lines: List[str], pattern_name: str, 
                        pattern_info: Dict[str, Any]) -> List[MigrationIssue]:
        """Analisa um padrão específico."""
        issues = []
        
        for line_num, line in enumerate(lines, 1):
            for pattern in pattern_info['patterns']:
                matches = re.finditer(pattern, line)
                for match in matches:
                    issue = MigrationIssue(
                        category=pattern_info['category'],
                        description=self._get_issue_description(pattern_name, match.group(0)),
                        complexity=pattern_info['complexity'],
                        line_number=line_num,
                        code_snippet=line.strip(),
                        impact=self._get_migration_impact(pattern_name),
                        modernization_options=self._get_modernization_options(pattern_name),
                        estimated_effort=self._estimate_pattern_effort(pattern_name, pattern_info['complexity'])
                    )
                    issues.append(issue)
        
        return issues
    
    def _get_issue_description(self, pattern_name: str, matched_text: str) -> str:
        """Gera descrição do problema de migração."""
        descriptions = {
            'mainframe_specific': f"Dependência específica de mainframe: '{matched_text}'",
            'file_systems': f"Sistema de arquivo legacy: '{matched_text}'",
            'database_access': f"Padrão de acesso a banco legacy: '{matched_text}'",
            'screen_handling': f"Manipulação de tela legacy: '{matched_text}'",
            'copybooks': f"Dependência de copybook: '{matched_text}'",
            'cobol_extensions': f"Extensão específica do COBOL: '{matched_text}'",
            'system_calls': f"Chamada de sistema: '{matched_text}'"
        }
        
        return descriptions.get(pattern_name, f"Padrão legacy detectado: '{matched_text}'")
    
    def _get_migration_impact(self, pattern_name: str) -> str:
        """Retorna impacto da migração para o padrão."""
        impacts = {
            'mainframe_specific': "Alto impacto - requer substituição completa da infraestrutura",
            'file_systems': "Médio impacto - requer migração para sistemas de arquivo modernos",
            'database_access': "Médio impacto - requer adaptação para APIs modernas de banco",
            'screen_handling': "Alto impacto - requer redesign completo da interface",
            'copybooks': "Baixo a médio impacto - requer conversão de estruturas de dados",
            'cobol_extensions': "Baixo impacto - pode ser convertido para equivalentes modernos",
            'system_calls': "Alto impacto - requer reimplementação específica da plataforma"
        }
        
        return impacts.get(pattern_name, "Impacto a ser avaliado")
    
    def _get_modernization_options(self, pattern_name: str) -> List[str]:
        """Retorna opções de modernização para o padrão."""
        options = {
            'mainframe_specific': [
                "Migração para cloud (AWS, Azure, GCP)",
                "Containerização com emuladores",
                "Reescrita em tecnologia moderna",
                "Uso de ferramentas de migração automatizada"
            ],
            'file_systems': [
                "Migração para bancos de dados relacionais",
                "Uso de sistemas de arquivo distribuídos",
                "APIs REST para acesso a dados",
                "Microserviços de dados"
            ],
            'database_access': [
                "Migração para ORMs modernos",
                "APIs REST/GraphQL",
                "Microserviços de dados",
                "Bancos NoSQL quando apropriado"
            ],
            'screen_handling': [
                "Desenvolvimento de interfaces web",
                "APIs REST para backend",
                "Frameworks modernos (React, Angular, Vue)",
                "Progressive Web Apps (PWA)"
            ],
            'copybooks': [
                "Conversão para schemas JSON/XML",
                "Classes/estruturas em linguagens modernas",
                "Definições de API (OpenAPI/Swagger)",
                "Modelos de dados ORM"
            ],
            'cobol_extensions': [
                "Tipos de dados equivalentes em linguagens modernas",
                "Bibliotecas de conversão",
                "Validação de dados moderna",
                "Serialização JSON/XML"
            ],
            'system_calls': [
                "APIs de sistema da plataforma alvo",
                "Bibliotecas multiplataforma",
                "Containerização",
                "Serviços gerenciados em cloud"
            ]
        }
        
        return options.get(pattern_name, ["Avaliar opções específicas"])
    
    def _estimate_pattern_effort(self, pattern_name: str, complexity: MigrationComplexity) -> str:
        """Estima esforço para migrar padrão específico."""
        base_efforts = {
            'mainframe_specific': "6-12 meses",
            'file_systems': "2-4 meses",
            'database_access': "1-3 meses",
            'screen_handling': "3-6 meses",
            'copybooks': "2-4 semanas",
            'cobol_extensions': "1-2 semanas",
            'system_calls': "2-6 semanas"
        }
        
        base_effort = base_efforts.get(pattern_name, "2-4 semanas")
        
        # Ajusta baseado na complexidade
        if complexity == MigrationComplexity.VERY_COMPLEX:
            return f"{base_effort} (complexidade muito alta)"
        elif complexity == MigrationComplexity.COMPLEX:
            return f"{base_effort} (complexidade alta)"
        elif complexity == MigrationComplexity.MODERATE:
            return f"{base_effort} (complexidade moderada)"
        else:
            return f"{base_effort} (complexidade baixa)"
    
    def _analyze_migration_complexity(self, program: CobolProgram, 
                                    issues: List[MigrationIssue]) -> Dict[str, Any]:
        """Analisa complexidade geral de migração."""
        analysis = {
            'overall_complexity': MigrationComplexity.SIMPLE,
            'complexity_factors': {},
            'lines_of_code': len(program.raw_content.split('\n')),
            'total_issues': len(issues),
            'critical_dependencies': 0,
            'modernization_readiness': 0
        }
        
        # Conta problemas por complexidade
        complexity_counts = {
            MigrationComplexity.SIMPLE: 0,
            MigrationComplexity.MODERATE: 0,
            MigrationComplexity.COMPLEX: 0,
            MigrationComplexity.VERY_COMPLEX: 0
        }
        
        for issue in issues:
            complexity_counts[issue.complexity] += 1
        
        analysis['complexity_factors'] = {
            'simple_issues': complexity_counts[MigrationComplexity.SIMPLE],
            'moderate_issues': complexity_counts[MigrationComplexity.MODERATE],
            'complex_issues': complexity_counts[MigrationComplexity.COMPLEX],
            'very_complex_issues': complexity_counts[MigrationComplexity.VERY_COMPLEX]
        }
        
        # Determina complexidade geral
        if complexity_counts[MigrationComplexity.VERY_COMPLEX] > 0:
            analysis['overall_complexity'] = MigrationComplexity.VERY_COMPLEX
        elif complexity_counts[MigrationComplexity.COMPLEX] > 2:
            analysis['overall_complexity'] = MigrationComplexity.COMPLEX
        elif complexity_counts[MigrationComplexity.MODERATE] > 5:
            analysis['overall_complexity'] = MigrationComplexity.MODERATE
        
        # Conta dependências críticas
        critical_categories = ['Mainframe Dependencies', 'Screen/UI Handling', 'System Integration']
        analysis['critical_dependencies'] = len([
            issue for issue in issues if issue.category in critical_categories
        ])
        
        # Calcula prontidão para modernização
        total_complexity_score = (
            complexity_counts[MigrationComplexity.SIMPLE] * 1 +
            complexity_counts[MigrationComplexity.MODERATE] * 3 +
            complexity_counts[MigrationComplexity.COMPLEX] * 7 +
            complexity_counts[MigrationComplexity.VERY_COMPLEX] * 15
        )
        
        # Normaliza baseado no tamanho do programa
        if analysis['lines_of_code'] > 0:
            complexity_density = total_complexity_score / analysis['lines_of_code'] * 100
            analysis['modernization_readiness'] = max(10, 100 - min(90, complexity_density))
        else:
            analysis['modernization_readiness'] = 50
        
        return analysis
    
    def _recommend_modernization_strategy(self, complexity_analysis: Dict[str, Any], 
                                        issues: List[MigrationIssue]) -> Dict[str, Any]:
        """Recomenda estratégia de modernização."""
        overall_complexity = complexity_analysis['overall_complexity']
        critical_deps = complexity_analysis['critical_dependencies']
        readiness = complexity_analysis['modernization_readiness']
        
        # Determina estratégia principal
        if overall_complexity == MigrationComplexity.VERY_COMPLEX or critical_deps > 5:
            primary_strategy = ModernizationStrategy.WRAP
            rationale = "Complexidade muito alta - recomenda-se wrapping inicial seguido de modernização gradual"
        elif overall_complexity == MigrationComplexity.COMPLEX or readiness < 30:
            primary_strategy = ModernizationStrategy.REFACTOR
            rationale = "Complexidade alta - refatoração gradual é mais segura"
        elif readiness > 70:
            primary_strategy = ModernizationStrategy.REWRITE
            rationale = "Boa prontidão para modernização - reescrita é viável"
        else:
            primary_strategy = ModernizationStrategy.REFACTOR
            rationale = "Complexidade moderada - refatoração é equilibrada"
        
        # Estratégias alternativas
        alternative_strategies = []
        if primary_strategy != ModernizationStrategy.WRAP:
            alternative_strategies.append(ModernizationStrategy.WRAP)
        if primary_strategy != ModernizationStrategy.REFACTOR:
            alternative_strategies.append(ModernizationStrategy.REFACTOR)
        if readiness > 50 and primary_strategy != ModernizationStrategy.REWRITE:
            alternative_strategies.append(ModernizationStrategy.REWRITE)
        
        return {
            'primary_strategy': primary_strategy.value,
            'rationale': rationale,
            'alternative_strategies': [s.value for s in alternative_strategies],
            'confidence_level': self._calculate_strategy_confidence(complexity_analysis),
            'prerequisites': self._get_strategy_prerequisites(primary_strategy),
            'success_factors': self._get_success_factors(primary_strategy)
        }
    
    def _estimate_migration_effort(self, complexity_analysis: Dict[str, Any], 
                                 issues: List[MigrationIssue]) -> Dict[str, Any]:
        """Estima esforço de migração."""
        base_effort_months = {
            MigrationComplexity.SIMPLE: 1,
            MigrationComplexity.MODERATE: 3,
            MigrationComplexity.COMPLEX: 6,
            MigrationComplexity.VERY_COMPLEX: 12
        }
        
        overall_complexity = complexity_analysis['overall_complexity']
        base_months = base_effort_months[overall_complexity]
        
        # Ajusta baseado no tamanho
        lines = complexity_analysis['lines_of_code']
        size_multiplier = 1 + (lines / 1000) * 0.1  # 10% a mais por 1000 linhas
        
        # Ajusta baseado em dependências críticas
        critical_deps = complexity_analysis['critical_dependencies']
        deps_multiplier = 1 + (critical_deps * 0.2)  # 20% a mais por dependência crítica
        
        total_months = base_months * size_multiplier * deps_multiplier
        
        # Estima recursos
        team_size = max(2, min(8, int(total_months / 2)))  # 2-8 pessoas
        
        return {
            'estimated_duration_months': round(total_months, 1),
            'estimated_team_size': team_size,
            'effort_breakdown': self._breakdown_effort_by_category(issues),
            'risk_buffer': '20-30%',
            'total_effort_person_months': round(total_months * team_size, 1),
            'confidence_range': f"±{int(total_months * 0.3)} meses"
        }
    
    def _generate_migration_roadmap(self, issues: List[MigrationIssue], 
                                  complexity_analysis: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Gera roadmap de migração."""
        phases = []
        
        # Fase 1: Preparação e Análise
        phases.append({
            'phase': 1,
            'name': 'Preparação e Análise Detalhada',
            'duration': '2-4 semanas',
            'activities': [
                'Análise completa de dependências',
                'Mapeamento de dados e interfaces',
                'Definição de arquitetura alvo',
                'Planejamento detalhado'
            ],
            'deliverables': [
                'Documento de arquitetura',
                'Plano de migração detalhado',
                'Análise de riscos',
                'Cronograma executivo'
            ]
        })
        
        # Fase 2: Infraestrutura e Fundação
        phases.append({
            'phase': 2,
            'name': 'Preparação de Infraestrutura',
            'duration': '3-6 semanas',
            'activities': [
                'Setup de ambiente de desenvolvimento',
                'Configuração de CI/CD',
                'Migração de dados de referência',
                'Desenvolvimento de ferramentas de migração'
            ],
            'deliverables': [
                'Ambiente de desenvolvimento',
                'Pipeline de CI/CD',
                'Ferramentas de migração',
                'Dados de teste migrados'
            ]
        })
        
        # Fases baseadas em categorias de problemas
        category_phases = self._generate_category_phases(issues)
        phases.extend(category_phases)
        
        # Fase final: Testes e Deploy
        phases.append({
            'phase': len(phases) + 1,
            'name': 'Testes Integrados e Deploy',
            'duration': '2-4 semanas',
            'activities': [
                'Testes de integração completos',
                'Testes de performance',
                'Testes de aceitação do usuário',
                'Deploy em produção'
            ],
            'deliverables': [
                'Sistema migrado em produção',
                'Documentação completa',
                'Treinamento de usuários',
                'Plano de suporte'
            ]
        })
        
        return phases
    
    def _generate_category_phases(self, issues: List[MigrationIssue]) -> List[Dict[str, Any]]:
        """Gera fases baseadas em categorias de problemas."""
        # Agrupa problemas por categoria
        by_category = {}
        for issue in issues:
            if issue.category not in by_category:
                by_category[issue.category] = []
            by_category[issue.category].append(issue)
        
        # Ordena categorias por prioridade
        category_priority = {
            'Mainframe Dependencies': 1,
            'File System Dependencies': 2,
            'Database Access Patterns': 3,
            'COBOL-Specific Features': 4,
            'Copybook Dependencies': 5,
            'Screen/UI Handling': 6,
            'System Integration': 7
        }
        
        sorted_categories = sorted(by_category.keys(), 
                                 key=lambda x: category_priority.get(x, 99))
        
        phases = []
        phase_num = 3  # Começa após preparação e infraestrutura
        
        for category in sorted_categories:
            category_issues = by_category[category]
            if len(category_issues) > 0:
                phase = {
                    'phase': phase_num,
                    'name': f'Migração: {category}',
                    'duration': self._estimate_category_duration(category, len(category_issues)),
                    'activities': self._get_category_activities(category),
                    'deliverables': self._get_category_deliverables(category),
                    'issues_count': len(category_issues),
                    'complexity': self._get_category_complexity(category_issues)
                }
                phases.append(phase)
                phase_num += 1
        
        return phases
    
    def _analyze_migration_risks(self, issues: List[MigrationIssue], 
                               complexity_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Analisa riscos de migração."""
        risks = {
            'high_risks': [],
            'medium_risks': [],
            'low_risks': [],
            'mitigation_strategies': {},
            'overall_risk_level': 'MEDIUM'
        }
        
        # Riscos baseados em complexidade
        overall_complexity = complexity_analysis['overall_complexity']
        if overall_complexity in [MigrationComplexity.COMPLEX, MigrationComplexity.VERY_COMPLEX]:
            risks['high_risks'].append({
                'risk': 'Alta complexidade técnica',
                'impact': 'Atrasos significativos e custos elevados',
                'probability': 'Alta',
                'mitigation': 'Planejamento detalhado e equipe experiente'
            })
        
        # Riscos baseados em categorias
        category_risks = {
            'Mainframe Dependencies': {
                'risk': 'Dependências de mainframe',
                'impact': 'Bloqueio completo da migração',
                'probability': 'Média',
                'mitigation': 'Estratégia de wrapping ou emulação'
            },
            'Screen/UI Handling': {
                'risk': 'Complexidade de interface',
                'impact': 'Rejeição pelos usuários',
                'probability': 'Média',
                'mitigation': 'Prototipagem e feedback contínuo'
            },
            'System Integration': {
                'risk': 'Integração com sistemas externos',
                'impact': 'Falhas de comunicação',
                'probability': 'Alta',
                'mitigation': 'Testes de integração extensivos'
            }
        }
        
        # Adiciona riscos baseados em problemas encontrados
        categories_found = set(issue.category for issue in issues)
        for category in categories_found:
            if category in category_risks:
                risk_info = category_risks[category]
                if len([i for i in issues if i.category == category]) > 3:
                    risks['high_risks'].append(risk_info)
                else:
                    risks['medium_risks'].append(risk_info)
        
        # Riscos gerais
        if complexity_analysis['lines_of_code'] > 5000:
            risks['medium_risks'].append({
                'risk': 'Tamanho grande do programa',
                'impact': 'Dificuldade de manutenção e testes',
                'probability': 'Média',
                'mitigation': 'Modularização e testes automatizados'
            })
        
        # Determina nível geral de risco
        if len(risks['high_risks']) > 2:
            risks['overall_risk_level'] = 'HIGH'
        elif len(risks['high_risks']) == 0 and len(risks['medium_risks']) < 3:
            risks['overall_risk_level'] = 'LOW'
        
        return risks
    
    def _calculate_readiness_score(self, complexity_analysis: Dict[str, Any], 
                                 issues: List[MigrationIssue]) -> int:
        """Calcula score de prontidão para migração (0-100)."""
        return int(complexity_analysis['modernization_readiness'])
    
    def _generate_technology_mapping(self, issues: List[MigrationIssue]) -> Dict[str, Any]:
        """Gera mapeamento de tecnologias legacy para modernas."""
        target_platform = self.config.get('target_platform', 'cloud')
        
        mappings = {
            'cloud': {
                'VSAM/QSAM': 'Cloud Storage (S3, Blob Storage)',
                'DB2': 'Cloud SQL (PostgreSQL, MySQL)',
                'CICS': 'Microserviços + API Gateway',
                'JCL': 'Workflow orchestration (Airflow, Step Functions)',
                'BMS Maps': 'Web UI (React, Angular)',
                'COBOL': 'Java/Python/C# microserviços'
            },
            'java': {
                'VSAM/QSAM': 'JPA/Hibernate + Database',
                'DB2': 'JDBC + PostgreSQL/Oracle',
                'CICS': 'Spring Boot microserviços',
                'JCL': 'Spring Batch',
                'BMS Maps': 'Spring MVC + Thymeleaf/React',
                'COBOL': 'Java classes'
            },
            'dotnet': {
                'VSAM/QSAM': 'Entity Framework + SQL Server',
                'DB2': 'ADO.NET + SQL Server',
                'CICS': 'ASP.NET Core Web API',
                'JCL': '.NET Core Worker Services',
                'BMS Maps': 'ASP.NET Core MVC + Blazor',
                'COBOL': 'C# classes'
            },
            'python': {
                'VSAM/QSAM': 'SQLAlchemy + PostgreSQL',
                'DB2': 'psycopg2 + PostgreSQL',
                'CICS': 'FastAPI/Django REST',
                'JCL': 'Celery + Redis',
                'BMS Maps': 'Django + React/Vue',
                'COBOL': 'Python modules'
            }
        }
        
        return {
            'target_platform': target_platform,
            'technology_mappings': mappings.get(target_platform, mappings['cloud']),
            'recommended_frameworks': self._get_recommended_frameworks(target_platform),
            'migration_tools': self._get_migration_tools(target_platform)
        }
    
    def _get_recommended_frameworks(self, platform: str) -> List[str]:
        """Retorna frameworks recomendados por plataforma."""
        frameworks = {
            'cloud': ['Serverless Framework', 'Terraform', 'Docker', 'Kubernetes'],
            'java': ['Spring Boot', 'Spring Cloud', 'Maven/Gradle', 'JUnit'],
            'dotnet': ['.NET Core', 'Entity Framework', 'NuGet', 'xUnit'],
            'python': ['FastAPI', 'Django', 'SQLAlchemy', 'pytest']
        }
        return frameworks.get(platform, [])
    
    def _get_migration_tools(self, platform: str) -> List[str]:
        """Retorna ferramentas de migração recomendadas."""
        tools = {
            'cloud': ['AWS Migration Hub', 'Azure Migrate', 'Google Cloud Migrate'],
            'java': ['COBOL-to-Java converters', 'Eclipse IDE', 'SonarQube'],
            'dotnet': ['Visual Studio', 'COBOL.NET', 'Azure DevOps'],
            'python': ['PyCharm', 'COBOL parsers', 'Black formatter']
        }
        return tools.get(platform, [])
    
    def _calculate_strategy_confidence(self, complexity_analysis: Dict[str, Any]) -> str:
        """Calcula confiança na estratégia recomendada."""
        readiness = complexity_analysis['modernization_readiness']
        if readiness > 70:
            return "Alta"
        elif readiness > 40:
            return "Média"
        else:
            return "Baixa"
    
    def _get_strategy_prerequisites(self, strategy: ModernizationStrategy) -> List[str]:
        """Retorna pré-requisitos para estratégia."""
        prerequisites = {
            ModernizationStrategy.REWRITE: [
                "Equipe experiente na tecnologia alvo",
                "Documentação completa dos requisitos",
                "Ambiente de testes robusto",
                "Aprovação para mudanças significativas"
            ],
            ModernizationStrategy.REFACTOR: [
                "Conhecimento profundo do código existente",
                "Ferramentas de refatoração",
                "Testes automatizados",
                "Processo de CI/CD"
            ],
            ModernizationStrategy.WRAP: [
                "Ferramentas de wrapping/integração",
                "APIs bem definidas",
                "Monitoramento robusto",
                "Plano de migração gradual"
            ]
        }
        return prerequisites.get(strategy, [])
    
    def _get_success_factors(self, strategy: ModernizationStrategy) -> List[str]:
        """Retorna fatores de sucesso para estratégia."""
        factors = {
            ModernizationStrategy.REWRITE: [
                "Planejamento detalhado",
                "Prototipagem iterativa",
                "Feedback contínuo dos usuários",
                "Gestão de mudanças efetiva"
            ],
            ModernizationStrategy.REFACTOR: [
                "Mudanças incrementais",
                "Testes contínuos",
                "Documentação atualizada",
                "Monitoramento de qualidade"
            ],
            ModernizationStrategy.WRAP: [
                "Interfaces bem definidas",
                "Monitoramento de performance",
                "Plano de evolução clara",
                "Gestão de dependências"
            ]
        }
        return factors.get(strategy, [])
    
    def _breakdown_effort_by_category(self, issues: List[MigrationIssue]) -> Dict[str, str]:
        """Quebra esforço por categoria."""
        by_category = {}
        for issue in issues:
            if issue.category not in by_category:
                by_category[issue.category] = 0
            by_category[issue.category] += 1
        
        # Converte para estimativas de tempo
        effort_breakdown = {}
        for category, count in by_category.items():
            if count > 5:
                effort_breakdown[category] = "2-4 meses"
            elif count > 2:
                effort_breakdown[category] = "3-6 semanas"
            else:
                effort_breakdown[category] = "1-2 semanas"
        
        return effort_breakdown
    
    def _estimate_category_duration(self, category: str, issue_count: int) -> str:
        """Estima duração para categoria."""
        base_durations = {
            'Mainframe Dependencies': '4-8 semanas',
            'File System Dependencies': '2-4 semanas',
            'Database Access Patterns': '2-3 semanas',
            'Screen/UI Handling': '3-6 semanas',
            'Copybook Dependencies': '1-2 semanas',
            'COBOL-Specific Features': '1-2 semanas',
            'System Integration': '2-4 semanas'
        }
        
        base = base_durations.get(category, '2-3 semanas')
        if issue_count > 5:
            return f"{base} (estendido devido ao volume)"
        return base
    
    def _get_category_activities(self, category: str) -> List[str]:
        """Retorna atividades para categoria."""
        activities = {
            'Mainframe Dependencies': [
                'Análise de dependências de mainframe',
                'Seleção de alternativas cloud/modernas',
                'Desenvolvimento de adaptadores',
                'Testes de compatibilidade'
            ],
            'File System Dependencies': [
                'Mapeamento de estruturas de arquivo',
                'Migração para banco de dados',
                'Desenvolvimento de APIs de acesso',
                'Testes de integridade de dados'
            ],
            'Database Access Patterns': [
                'Conversão de SQL embarcado',
                'Implementação de DAOs/Repositories',
                'Otimização de queries',
                'Testes de performance'
            ]
        }
        return activities.get(category, ['Análise', 'Desenvolvimento', 'Testes'])
    
    def _get_category_deliverables(self, category: str) -> List[str]:
        """Retorna entregáveis para categoria."""
        deliverables = {
            'Mainframe Dependencies': [
                'Adaptadores implementados',
                'Documentação de migração',
                'Testes de compatibilidade',
                'Plano de rollback'
            ],
            'File System Dependencies': [
                'APIs de dados implementadas',
                'Dados migrados',
                'Documentação de estruturas',
                'Testes de integridade'
            ]
        }
        return deliverables.get(category, ['Código migrado', 'Testes', 'Documentação'])
    
    def _get_category_complexity(self, issues: List[MigrationIssue]) -> str:
        """Retorna complexidade da categoria."""
        complexities = [issue.complexity for issue in issues]
        if MigrationComplexity.VERY_COMPLEX in complexities:
            return "Muito Alta"
        elif MigrationComplexity.COMPLEX in complexities:
            return "Alta"
        elif MigrationComplexity.MODERATE in complexities:
            return "Moderada"
        else:
            return "Baixa"
    
    def _issue_to_dict(self, issue: MigrationIssue) -> Dict[str, Any]:
        """Converte MigrationIssue para dicionário."""
        return {
            'category': issue.category,
            'description': issue.description,
            'complexity': issue.complexity.value,
            'line_number': issue.line_number,
            'code_snippet': issue.code_snippet,
            'impact': issue.impact,
            'modernization_options': issue.modernization_options,
            'estimated_effort': issue.estimated_effort
        }

