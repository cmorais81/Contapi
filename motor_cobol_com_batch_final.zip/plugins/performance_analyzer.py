"""
Plugin de análise de performance para programas COBOL.
"""

import re
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from plugin_system import AnalyzerPlugin, PluginMetadata, PluginType, PluginPriority
from cobol_parser import CobolProgram


@dataclass
class PerformanceIssue:
    """Representa um problema de performance identificado."""
    severity: str  # LOW, MEDIUM, HIGH
    category: str
    description: str
    line_number: int
    code_snippet: str
    impact: str
    recommendation: str
    estimated_improvement: str


class PerformanceAnalyzerPlugin(AnalyzerPlugin):
    """Plugin para análise de performance em programas COBOL."""
    
    def __init__(self):
        self.config = {}
        self.performance_patterns = {
            'nested_loops': {
                'pattern': r'(?i)perform\s+.*varying.*perform\s+.*varying',
                'severity': 'HIGH',
                'category': 'Algorithmic Complexity'
            },
            'inefficient_search': {
                'pattern': r'(?i)search\s+(?!all)',
                'severity': 'MEDIUM',
                'category': 'Search Operations'
            },
            'unnecessary_sorting': {
                'pattern': r'(?i)sort\s+.*using\s+.*giving',
                'severity': 'MEDIUM',
                'category': 'Sorting Operations'
            },
            'frequent_io': {
                'pattern': r'(?i)(read|write)\s+.*(?:in\s+loop|perform)',
                'severity': 'HIGH',
                'category': 'I/O Operations'
            },
            'string_concatenation': {
                'pattern': r'(?i)string\s+.*delimited.*into',
                'severity': 'LOW',
                'category': 'String Operations'
            },
            'large_arrays': {
                'pattern': r'(?i)occurs\s+([0-9]+)',
                'severity': 'MEDIUM',
                'category': 'Memory Usage'
            },
            'goto_usage': {
                'pattern': r'(?i)go\s+to\s+',
                'severity': 'LOW',
                'category': 'Control Flow'
            },
            'unoptimized_conditions': {
                'pattern': r'(?i)if\s+.*and\s+.*and\s+.*and',
                'severity': 'LOW',
                'category': 'Conditional Logic'
            }
        }
    
    @property
    def metadata(self) -> PluginMetadata:
        """Retorna metadados do plugin."""
        return PluginMetadata(
            name="performance_analyzer",
            version="1.0.0",
            description="Analisa programas COBOL em busca de problemas de performance",
            author="COBOL Documentation Engine",
            plugin_type=PluginType.ANALYZER,
            priority=PluginPriority.NORMAL,
            dependencies=[],
            config_schema={
                "enable_all_checks": {"type": "boolean", "default": True},
                "array_size_threshold": {"type": "integer", "default": 1000},
                "loop_depth_threshold": {"type": "integer", "default": 3},
                "io_frequency_threshold": {"type": "integer", "default": 10}
            }
        )
    
    def initialize(self, config: Dict[str, Any]) -> bool:
        """Inicializa o plugin com configuração."""
        try:
            self.config = config
            return True
        except Exception as e:
            print(f"Erro na inicialização do PerformanceAnalyzer: {str(e)}")
            return False
    
    def analyze(self, program: CobolProgram) -> Dict[str, Any]:
        """Analisa programa COBOL em busca de problemas de performance."""
        issues = []
        lines = program.raw_content.split('\n')
        
        # Análises específicas
        issues.extend(self._analyze_nested_loops(lines))
        issues.extend(self._analyze_io_operations(lines))
        issues.extend(self._analyze_array_sizes(lines))
        issues.extend(self._analyze_search_operations(lines))
        issues.extend(self._analyze_sorting_operations(lines))
        issues.extend(self._analyze_string_operations(lines))
        issues.extend(self._analyze_control_flow(lines))
        issues.extend(self._analyze_conditional_logic(lines))
        
        # Análise de complexidade geral
        complexity_analysis = self._analyze_complexity(lines)
        
        # Gera estatísticas
        stats = self._generate_statistics(issues, lines)
        
        # Gera recomendações
        recommendations = self._generate_recommendations(issues, complexity_analysis)
        
        # Calcula score de performance
        performance_score = self._calculate_performance_score(issues, complexity_analysis)
        
        return {
            'issues': [self._issue_to_dict(issue) for issue in issues],
            'complexity_analysis': complexity_analysis,
            'statistics': stats,
            'recommendations': recommendations,
            'performance_score': performance_score,
            'optimization_opportunities': self._identify_optimization_opportunities(issues)
        }
    
    def _analyze_nested_loops(self, lines: List[str]) -> List[PerformanceIssue]:
        """Analisa loops aninhados."""
        issues = []
        loop_depth = 0
        loop_stack = []
        
        for line_num, line in enumerate(lines, 1):
            line_upper = line.upper().strip()
            
            # Detecta início de loop
            if 'PERFORM' in line_upper and ('VARYING' in line_upper or 'UNTIL' in line_upper):
                loop_depth += 1
                loop_stack.append((line_num, line.strip()))
                
                # Verifica se excede threshold
                threshold = self.config.get('loop_depth_threshold', 3)
                if loop_depth > threshold:
                    issue = PerformanceIssue(
                        severity='HIGH',
                        category='Algorithmic Complexity',
                        description=f'Loop aninhado de profundidade {loop_depth} (threshold: {threshold})',
                        line_number=line_num,
                        code_snippet=line.strip(),
                        impact='Alto impacto na performance - complexidade O(n^' + str(loop_depth) + ')',
                        recommendation='Considere otimizar algoritmo ou reduzir aninhamento',
                        estimated_improvement='50-80% melhoria potencial'
                    )
                    issues.append(issue)
            
            # Detecta fim de loop
            elif 'END-PERFORM' in line_upper and loop_depth > 0:
                loop_depth -= 1
                if loop_stack:
                    loop_stack.pop()
        
        return issues
    
    def _analyze_io_operations(self, lines: List[str]) -> List[PerformanceIssue]:
        """Analisa operações de I/O."""
        issues = []
        io_operations = []
        
        for line_num, line in enumerate(lines, 1):
            line_upper = line.upper().strip()
            
            if any(op in line_upper for op in ['READ', 'WRITE', 'REWRITE', 'DELETE']):
                io_operations.append((line_num, line.strip()))
        
        # Verifica frequência de I/O
        threshold = self.config.get('io_frequency_threshold', 10)
        if len(io_operations) > threshold:
            # Analisa padrões de I/O ineficientes
            for line_num, code in io_operations:
                if self._is_io_in_loop(lines, line_num):
                    issue = PerformanceIssue(
                        severity='HIGH',
                        category='I/O Operations',
                        description='Operação de I/O dentro de loop',
                        line_number=line_num,
                        code_snippet=code,
                        impact='Alto impacto - I/O é operação custosa',
                        recommendation='Considere batch processing ou cache',
                        estimated_improvement='30-60% melhoria potencial'
                    )
                    issues.append(issue)
        
        return issues
    
    def _analyze_array_sizes(self, lines: List[str]) -> List[PerformanceIssue]:
        """Analisa tamanhos de arrays."""
        issues = []
        threshold = self.config.get('array_size_threshold', 1000)
        
        for line_num, line in enumerate(lines, 1):
            occurs_match = re.search(r'(?i)occurs\s+(\d+)', line)
            if occurs_match:
                size = int(occurs_match.group(1))
                if size > threshold:
                    issue = PerformanceIssue(
                        severity='MEDIUM',
                        category='Memory Usage',
                        description=f'Array grande detectado: {size} elementos (threshold: {threshold})',
                        line_number=line_num,
                        code_snippet=line.strip(),
                        impact='Impacto médio no uso de memória',
                        recommendation='Considere paginação ou estruturas mais eficientes',
                        estimated_improvement='20-40% redução no uso de memória'
                    )
                    issues.append(issue)
        
        return issues
    
    def _analyze_search_operations(self, lines: List[str]) -> List[PerformanceIssue]:
        """Analisa operações de busca."""
        issues = []
        
        for line_num, line in enumerate(lines, 1):
            line_upper = line.upper().strip()
            
            # Busca linear vs binária
            if 'SEARCH ' in line_upper and 'SEARCH ALL' not in line_upper:
                issue = PerformanceIssue(
                    severity='MEDIUM',
                    category='Search Operations',
                    description='Busca linear detectada - considere busca binária',
                    line_number=line_num,
                    code_snippet=line.strip(),
                    impact='Impacto médio - O(n) vs O(log n)',
                    recommendation='Use SEARCH ALL para busca binária se dados estão ordenados',
                    estimated_improvement='50-90% melhoria para grandes datasets'
                )
                issues.append(issue)
        
        return issues
    
    def _analyze_sorting_operations(self, lines: List[str]) -> List[PerformanceIssue]:
        """Analisa operações de ordenação."""
        issues = []
        sort_count = 0
        
        for line_num, line in enumerate(lines, 1):
            if 'SORT ' in line.upper():
                sort_count += 1
                
                # Verifica se é ordenação desnecessária
                if self._is_redundant_sort(lines, line_num):
                    issue = PerformanceIssue(
                        severity='MEDIUM',
                        category='Sorting Operations',
                        description='Possível ordenação redundante detectada',
                        line_number=line_num,
                        code_snippet=line.strip(),
                        impact='Impacto médio - operação custosa desnecessária',
                        recommendation='Verifique se dados já estão ordenados ou use índices',
                        estimated_improvement='100% eliminação se redundante'
                    )
                    issues.append(issue)
        
        # Muitas operações de sort
        if sort_count > 3:
            issue = PerformanceIssue(
                severity='LOW',
                category='Sorting Operations',
                description=f'Múltiplas operações de ordenação ({sort_count})',
                line_number=0,
                code_snippet='Múltiplas operações SORT',
                impact='Impacto cumulativo na performance',
                recommendation='Considere consolidar ordenações ou usar estruturas pré-ordenadas',
                estimated_improvement='20-40% melhoria potencial'
            )
            issues.append(issue)
        
        return issues
    
    def _analyze_string_operations(self, lines: List[str]) -> List[PerformanceIssue]:
        """Analisa operações de string."""
        issues = []
        string_ops = 0
        
        for line_num, line in enumerate(lines, 1):
            line_upper = line.upper().strip()
            
            if 'STRING ' in line_upper and 'DELIMITED' in line_upper:
                string_ops += 1
                
                # Verifica se está em loop
                if self._is_in_loop(lines, line_num):
                    issue = PerformanceIssue(
                        severity='LOW',
                        category='String Operations',
                        description='Concatenação de string em loop',
                        line_number=line_num,
                        code_snippet=line.strip(),
                        impact='Impacto baixo a médio dependendo da frequência',
                        recommendation='Considere buffer ou concatenação em batch',
                        estimated_improvement='10-30% melhoria potencial'
                    )
                    issues.append(issue)
        
        return issues
    
    def _analyze_control_flow(self, lines: List[str]) -> List[PerformanceIssue]:
        """Analisa fluxo de controle."""
        issues = []
        goto_count = 0
        
        for line_num, line in enumerate(lines, 1):
            if 'GO TO' in line.upper():
                goto_count += 1
                
                issue = PerformanceIssue(
                    severity='LOW',
                    category='Control Flow',
                    description='Uso de GO TO detectado',
                    line_number=line_num,
                    code_snippet=line.strip(),
                    impact='Impacto baixo na performance, alto na manutenibilidade',
                    recommendation='Considere usar PERFORM ou estruturas condicionais',
                    estimated_improvement='5-15% melhoria na legibilidade'
                )
                issues.append(issue)
        
        return issues
    
    def _analyze_conditional_logic(self, lines: List[str]) -> List[PerformanceIssue]:
        """Analisa lógica condicional."""
        issues = []
        
        for line_num, line in enumerate(lines, 1):
            line_upper = line.upper().strip()
            
            # Condições muito complexas
            and_count = line_upper.count(' AND ')
            or_count = line_upper.count(' OR ')
            
            if and_count + or_count > 3:
                issue = PerformanceIssue(
                    severity='LOW',
                    category='Conditional Logic',
                    description=f'Condição complexa com {and_count + or_count} operadores lógicos',
                    line_number=line_num,
                    code_snippet=line.strip(),
                    impact='Impacto baixo na performance, médio na legibilidade',
                    recommendation='Considere quebrar em múltiplas condições ou usar EVALUATE',
                    estimated_improvement='10-20% melhoria na legibilidade'
                )
                issues.append(issue)
        
        return issues
    
    def _analyze_complexity(self, lines: List[str]) -> Dict[str, Any]:
        """Analisa complexidade geral do programa."""
        analysis = {
            'total_lines': len(lines),
            'executable_lines': 0,
            'loop_count': 0,
            'condition_count': 0,
            'io_operations': 0,
            'complexity_score': 0
        }
        
        for line in lines:
            line_upper = line.upper().strip()
            
            # Conta linhas executáveis
            if line_upper and not line_upper.startswith('*') and '.' not in line_upper[:10]:
                analysis['executable_lines'] += 1
            
            # Conta estruturas
            if 'PERFORM' in line_upper:
                analysis['loop_count'] += 1
            
            if 'IF ' in line_upper or 'WHEN ' in line_upper:
                analysis['condition_count'] += 1
            
            if any(op in line_upper for op in ['READ', 'WRITE', 'REWRITE', 'DELETE']):
                analysis['io_operations'] += 1
        
        # Calcula score de complexidade
        analysis['complexity_score'] = (
            analysis['loop_count'] * 2 +
            analysis['condition_count'] * 1 +
            analysis['io_operations'] * 1.5
        )
        
        return analysis
    
    def _generate_statistics(self, issues: List[PerformanceIssue], lines: List[str]) -> Dict[str, Any]:
        """Gera estatísticas dos problemas de performance."""
        stats = {
            'total_issues': len(issues),
            'by_severity': {'LOW': 0, 'MEDIUM': 0, 'HIGH': 0},
            'by_category': {},
            'lines_analyzed': len(lines),
            'issue_density': len(issues) / len(lines) if lines else 0
        }
        
        for issue in issues:
            stats['by_severity'][issue.severity] += 1
            
            if issue.category not in stats['by_category']:
                stats['by_category'][issue.category] = 0
            stats['by_category'][issue.category] += 1
        
        return stats
    
    def _generate_recommendations(self, issues: List[PerformanceIssue], 
                                complexity_analysis: Dict[str, Any]) -> List[str]:
        """Gera recomendações de otimização."""
        recommendations = []
        
        # Recomendações baseadas em problemas
        high_issues = [i for i in issues if i.severity == 'HIGH']
        if high_issues:
            recommendations.append(f"PRIORIDADE ALTA: {len(high_issues)} problema(s) de alta severidade identificado(s)")
        
        # Recomendações baseadas em categorias
        categories = set(issue.category for issue in issues)
        
        if 'Algorithmic Complexity' in categories:
            recommendations.append("Otimize algoritmos com alta complexidade - considere estruturas de dados mais eficientes")
        
        if 'I/O Operations' in categories:
            recommendations.append("Otimize operações de I/O - considere buffering e batch processing")
        
        if 'Memory Usage' in categories:
            recommendations.append("Otimize uso de memória - considere paginação para grandes estruturas")
        
        # Recomendações baseadas em complexidade
        if complexity_analysis['complexity_score'] > 50:
            recommendations.append("Programa com alta complexidade - considere refatoração em módulos menores")
        
        if not recommendations:
            recommendations.append("Nenhum problema crítico de performance identificado")
        
        return recommendations
    
    def _calculate_performance_score(self, issues: List[PerformanceIssue], 
                                   complexity_analysis: Dict[str, Any]) -> int:
        """Calcula score de performance (0-100)."""
        # Peso por severidade
        severity_weights = {'LOW': 1, 'MEDIUM': 3, 'HIGH': 7}
        
        issue_penalty = sum(severity_weights.get(issue.severity, 1) for issue in issues)
        complexity_penalty = min(30, complexity_analysis['complexity_score'] / 2)
        
        total_penalty = issue_penalty + complexity_penalty
        score = max(10, 100 - min(90, total_penalty))
        
        return int(score)
    
    def _identify_optimization_opportunities(self, issues: List[PerformanceIssue]) -> List[Dict[str, Any]]:
        """Identifica oportunidades de otimização."""
        opportunities = []
        
        # Agrupa por categoria
        by_category = {}
        for issue in issues:
            if issue.category not in by_category:
                by_category[issue.category] = []
            by_category[issue.category].append(issue)
        
        # Gera oportunidades
        for category, category_issues in by_category.items():
            if len(category_issues) >= 2:  # Múltiplos problemas na mesma categoria
                opportunity = {
                    'category': category,
                    'issue_count': len(category_issues),
                    'potential_improvement': self._estimate_category_improvement(category),
                    'effort_level': self._estimate_effort_level(category),
                    'priority': self._calculate_priority(category_issues)
                }
                opportunities.append(opportunity)
        
        # Ordena por prioridade
        opportunities.sort(key=lambda x: x['priority'], reverse=True)
        
        return opportunities
    
    def _estimate_category_improvement(self, category: str) -> str:
        """Estima melhoria potencial por categoria."""
        improvements = {
            'Algorithmic Complexity': '50-80%',
            'I/O Operations': '30-60%',
            'Memory Usage': '20-40%',
            'Search Operations': '50-90%',
            'Sorting Operations': '20-100%',
            'String Operations': '10-30%',
            'Control Flow': '5-15%',
            'Conditional Logic': '10-20%'
        }
        return improvements.get(category, '10-30%')
    
    def _estimate_effort_level(self, category: str) -> str:
        """Estima nível de esforço por categoria."""
        efforts = {
            'Algorithmic Complexity': 'Alto',
            'I/O Operations': 'Médio',
            'Memory Usage': 'Médio',
            'Search Operations': 'Baixo',
            'Sorting Operations': 'Baixo',
            'String Operations': 'Baixo',
            'Control Flow': 'Médio',
            'Conditional Logic': 'Baixo'
        }
        return efforts.get(category, 'Médio')
    
    def _calculate_priority(self, issues: List[PerformanceIssue]) -> int:
        """Calcula prioridade baseada nos problemas."""
        severity_scores = {'LOW': 1, 'MEDIUM': 3, 'HIGH': 7}
        return sum(severity_scores.get(issue.severity, 1) for issue in issues)
    
    def _is_io_in_loop(self, lines: List[str], line_num: int) -> bool:
        """Verifica se operação de I/O está dentro de loop."""
        # Busca para trás por PERFORM
        for i in range(max(0, line_num - 10), line_num):
            if 'PERFORM' in lines[i].upper():
                return True
        return False
    
    def _is_in_loop(self, lines: List[str], line_num: int) -> bool:
        """Verifica se linha está dentro de loop."""
        return self._is_io_in_loop(lines, line_num)
    
    def _is_redundant_sort(self, lines: List[str], line_num: int) -> bool:
        """Verifica se ordenação pode ser redundante."""
        # Busca por SORT anterior nas últimas 20 linhas
        for i in range(max(0, line_num - 20), line_num):
            if 'SORT ' in lines[i].upper():
                return True
        return False
    
    def _issue_to_dict(self, issue: PerformanceIssue) -> Dict[str, Any]:
        """Converte PerformanceIssue para dicionário."""
        return {
            'severity': issue.severity,
            'category': issue.category,
            'description': issue.description,
            'line_number': issue.line_number,
            'code_snippet': issue.code_snippet,
            'impact': issue.impact,
            'recommendation': issue.recommendation,
            'estimated_improvement': issue.estimated_improvement
        }

