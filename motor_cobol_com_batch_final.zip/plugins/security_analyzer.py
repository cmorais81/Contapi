"""
Plugin de análise de segurança para programas COBOL.
"""

import re
from typing import Dict, List, Any
from dataclasses import dataclass

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from plugin_system import AnalyzerPlugin, PluginMetadata, PluginType, PluginPriority
from cobol_parser import CobolProgram


@dataclass
class SecurityIssue:
    """Representa um problema de segurança identificado."""
    severity: str  # LOW, MEDIUM, HIGH, CRITICAL
    category: str
    description: str
    line_number: int
    code_snippet: str
    recommendation: str


class SecurityAnalyzerPlugin(AnalyzerPlugin):
    """Plugin para análise de segurança em programas COBOL."""
    
    def __init__(self):
        self.config = {}
        self.security_patterns = {
            'password_exposure': {
                'patterns': [
                    r'(?i)(password|senha|pwd)\s*=\s*["\']([^"\']+)["\']',
                    r'(?i)display\s+.*(?:password|senha|pwd)',
                    r'(?i)move\s+["\']([^"\']*(?:password|senha|pwd)[^"\']*)["\']'
                ],
                'severity': 'HIGH',
                'category': 'Credential Exposure'
            },
            'hardcoded_credentials': {
                'patterns': [
                    r'(?i)user\s*=\s*["\']([^"\']+)["\']',
                    r'(?i)userid\s*=\s*["\']([^"\']+)["\']',
                    r'(?i)username\s*=\s*["\']([^"\']+)["\']'
                ],
                'severity': 'MEDIUM',
                'category': 'Hardcoded Credentials'
            },
            'sql_injection': {
                'patterns': [
                    r'(?i)exec\s+sql\s+.*\|\|',
                    r'(?i)exec\s+sql\s+.*concat',
                    r'(?i)string\s+.*delimited\s+.*into\s+.*sql'
                ],
                'severity': 'HIGH',
                'category': 'SQL Injection Risk'
            },
            'sensitive_data': {
                'patterns': [
                    r'(?i)(cpf|cnpj|ssn|social.security)',
                    r'(?i)(credit.card|card.number|cartao)',
                    r'(?i)(account.number|numero.conta)',
                    r'(?i)(bank.account|conta.bancaria)'
                ],
                'severity': 'MEDIUM',
                'category': 'Sensitive Data Handling'
            },
            'file_access': {
                'patterns': [
                    r'(?i)open\s+.*mode\s+.*output',
                    r'(?i)delete\s+file',
                    r'(?i)write\s+.*from\s+.*password'
                ],
                'severity': 'MEDIUM',
                'category': 'File Access Control'
            },
            'input_validation': {
                'patterns': [
                    r'(?i)accept\s+(?!.*(?:if|when|numeric|alphabetic))',
                    r'(?i)move\s+.*to\s+.*(?!.*(?:if|when|inspect))'
                ],
                'severity': 'LOW',
                'category': 'Input Validation'
            },
            'privilege_escalation': {
                'patterns': [
                    r'(?i)call\s+["\']([^"\']*(?:admin|root|system)[^"\']*)["\']',
                    r'(?i)exec\s+.*(?:grant|revoke|alter\s+user)'
                ],
                'severity': 'CRITICAL',
                'category': 'Privilege Escalation'
            }
        }
    
    @property
    def metadata(self) -> PluginMetadata:
        """Retorna metadados do plugin."""
        return PluginMetadata(
            name="security_analyzer",
            version="1.0.0",
            description="Analisa programas COBOL em busca de vulnerabilidades de segurança",
            author="COBOL Documentation Engine",
            plugin_type=PluginType.ANALYZER,
            priority=PluginPriority.HIGH,
            dependencies=[],
            config_schema={
                "enable_all_checks": {"type": "boolean", "default": True},
                "severity_threshold": {"type": "string", "default": "LOW", "enum": ["LOW", "MEDIUM", "HIGH", "CRITICAL"]},
                "custom_patterns": {"type": "object", "default": {}},
                "exclude_patterns": {"type": "array", "default": []}
            }
        )
    
    def initialize(self, config: Dict[str, Any]) -> bool:
        """Inicializa o plugin com configuração."""
        try:
            self.config = config
            
            # Adiciona padrões customizados se fornecidos
            custom_patterns = config.get('custom_patterns', {})
            if custom_patterns:
                self.security_patterns.update(custom_patterns)
            
            return True
        except Exception as e:
            print(f"Erro na inicialização do SecurityAnalyzer: {str(e)}")
            return False
    
    def validate_config(self, config: Dict[str, Any]) -> bool:
        """Valida configuração do plugin."""
        try:
            # Valida threshold de severidade
            severity_threshold = config.get('severity_threshold', 'LOW')
            if severity_threshold not in ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL']:
                return False
            
            # Valida padrões customizados
            custom_patterns = config.get('custom_patterns', {})
            if custom_patterns and not isinstance(custom_patterns, dict):
                return False
            
            return True
        except:
            return False
    
    def analyze(self, program: CobolProgram) -> Dict[str, Any]:
        """Analisa programa COBOL em busca de problemas de segurança."""
        issues = []
        lines = program.raw_content.split('\n')
        
        # Analisa cada linha do programa
        for line_num, line in enumerate(lines, 1):
            line_issues = self._analyze_line(line, line_num)
            issues.extend(line_issues)
        
        # Filtra por threshold de severidade
        severity_threshold = self.config.get('severity_threshold', 'LOW')
        filtered_issues = self._filter_by_severity(issues, severity_threshold)
        
        # Gera estatísticas
        stats = self._generate_statistics(filtered_issues)
        
        # Gera recomendações
        recommendations = self._generate_recommendations(filtered_issues)
        
        return {
            'issues': [self._issue_to_dict(issue) for issue in filtered_issues],
            'statistics': stats,
            'recommendations': recommendations,
            'security_score': self._calculate_security_score(filtered_issues, len(lines)),
            'compliance_status': self._assess_compliance(filtered_issues)
        }
    
    def _analyze_line(self, line: str, line_num: int) -> List[SecurityIssue]:
        """Analisa uma linha em busca de problemas de segurança."""
        issues = []
        
        for pattern_name, pattern_info in self.security_patterns.items():
            # Verifica se o padrão está habilitado
            if not self.config.get('enable_all_checks', True):
                continue
            
            # Verifica padrões de exclusão
            exclude_patterns = self.config.get('exclude_patterns', [])
            if any(exclude in line for exclude in exclude_patterns):
                continue
            
            for pattern in pattern_info['patterns']:
                matches = re.finditer(pattern, line)
                for match in matches:
                    issue = SecurityIssue(
                        severity=pattern_info['severity'],
                        category=pattern_info['category'],
                        description=self._get_issue_description(pattern_name, match),
                        line_number=line_num,
                        code_snippet=line.strip(),
                        recommendation=self._get_recommendation(pattern_name)
                    )
                    issues.append(issue)
        
        return issues
    
    def _get_issue_description(self, pattern_name: str, match) -> str:
        """Gera descrição do problema identificado."""
        descriptions = {
            'password_exposure': f"Possível exposição de senha: '{match.group(0)}'",
            'hardcoded_credentials': f"Credencial hardcoded detectada: '{match.group(0)}'",
            'sql_injection': f"Possível vulnerabilidade de SQL injection: '{match.group(0)}'",
            'sensitive_data': f"Manipulação de dados sensíveis: '{match.group(0)}'",
            'file_access': f"Operação de arquivo potencialmente insegura: '{match.group(0)}'",
            'input_validation': f"Entrada sem validação aparente: '{match.group(0)}'",
            'privilege_escalation': f"Possível escalação de privilégios: '{match.group(0)}'"
        }
        
        return descriptions.get(pattern_name, f"Problema de segurança detectado: '{match.group(0)}'")
    
    def _get_recommendation(self, pattern_name: str) -> str:
        """Gera recomendação para correção do problema."""
        recommendations = {
            'password_exposure': "Evite hardcoding de senhas. Use variáveis de ambiente ou sistemas de gerenciamento de credenciais.",
            'hardcoded_credentials': "Remova credenciais hardcoded. Use configuração externa ou sistemas de autenticação.",
            'sql_injection': "Use prepared statements ou valide/sanitize entradas antes de construir queries SQL.",
            'sensitive_data': "Implemente criptografia para dados sensíveis e controle de acesso adequado.",
            'file_access': "Implemente controles de acesso e validação de permissões para operações de arquivo.",
            'input_validation': "Adicione validação de entrada (NUMERIC, ALPHABETIC, etc.) antes de processar dados.",
            'privilege_escalation': "Revise chamadas para funções privilegiadas e implemente controle de acesso adequado."
        }
        
        return recommendations.get(pattern_name, "Revise o código e implemente controles de segurança adequados.")
    
    def _filter_by_severity(self, issues: List[SecurityIssue], threshold: str) -> List[SecurityIssue]:
        """Filtra problemas por severidade."""
        severity_levels = {'LOW': 1, 'MEDIUM': 2, 'HIGH': 3, 'CRITICAL': 4}
        threshold_level = severity_levels.get(threshold, 1)
        
        return [issue for issue in issues 
                if severity_levels.get(issue.severity, 1) >= threshold_level]
    
    def _generate_statistics(self, issues: List[SecurityIssue]) -> Dict[str, Any]:
        """Gera estatísticas dos problemas encontrados."""
        stats = {
            'total_issues': len(issues),
            'by_severity': {'LOW': 0, 'MEDIUM': 0, 'HIGH': 0, 'CRITICAL': 0},
            'by_category': {},
            'most_common_issues': []
        }
        
        # Conta por severidade
        for issue in issues:
            stats['by_severity'][issue.severity] += 1
        
        # Conta por categoria
        for issue in issues:
            if issue.category not in stats['by_category']:
                stats['by_category'][issue.category] = 0
            stats['by_category'][issue.category] += 1
        
        # Identifica problemas mais comuns
        category_counts = list(stats['by_category'].items())
        category_counts.sort(key=lambda x: x[1], reverse=True)
        stats['most_common_issues'] = category_counts[:5]
        
        return stats
    
    def _generate_recommendations(self, issues: List[SecurityIssue]) -> List[str]:
        """Gera recomendações gerais baseadas nos problemas encontrados."""
        recommendations = []
        
        # Recomendações baseadas em severidade
        critical_count = len([i for i in issues if i.severity == 'CRITICAL'])
        high_count = len([i for i in issues if i.severity == 'HIGH'])
        
        if critical_count > 0:
            recommendations.append(f"URGENTE: {critical_count} problema(s) crítico(s) identificado(s). Correção imediata necessária.")
        
        if high_count > 0:
            recommendations.append(f"ALTA PRIORIDADE: {high_count} problema(s) de alta severidade requerem atenção.")
        
        # Recomendações baseadas em categorias
        categories = set(issue.category for issue in issues)
        
        if 'Credential Exposure' in categories:
            recommendations.append("Implemente sistema de gerenciamento de credenciais seguro.")
        
        if 'SQL Injection Risk' in categories:
            recommendations.append("Revise todas as construções de SQL dinâmico e implemente prepared statements.")
        
        if 'Sensitive Data Handling' in categories:
            recommendations.append("Implemente criptografia e controles de acesso para dados sensíveis.")
        
        # Recomendações gerais
        if len(issues) > 10:
            recommendations.append("Considere implementar revisão de código automatizada para segurança.")
        
        if not recommendations:
            recommendations.append("Nenhum problema crítico identificado. Continue seguindo boas práticas de segurança.")
        
        return recommendations
    
    def _calculate_security_score(self, issues: List[SecurityIssue], total_lines: int) -> int:
        """Calcula pontuação de segurança (0-100)."""
        if total_lines == 0:
            return 100
        
        # Peso por severidade
        severity_weights = {'LOW': 1, 'MEDIUM': 3, 'HIGH': 7, 'CRITICAL': 15}
        
        total_weight = sum(severity_weights.get(issue.severity, 1) for issue in issues)
        
        # Normaliza baseado no tamanho do programa
        issue_density = total_weight / total_lines * 100
        
        # Calcula score (máximo de penalidade é 80 pontos)
        score = max(20, 100 - min(80, issue_density))
        
        return int(score)
    
    def _assess_compliance(self, issues: List[SecurityIssue]) -> Dict[str, Any]:
        """Avalia conformidade com padrões de segurança."""
        compliance = {
            'overall_status': 'COMPLIANT',
            'critical_violations': 0,
            'high_violations': 0,
            'recommendations_count': 0
        }
        
        critical_count = len([i for i in issues if i.severity == 'CRITICAL'])
        high_count = len([i for i in issues if i.severity == 'HIGH'])
        
        compliance['critical_violations'] = critical_count
        compliance['high_violations'] = high_count
        compliance['recommendations_count'] = len(issues)
        
        if critical_count > 0:
            compliance['overall_status'] = 'NON_COMPLIANT'
        elif high_count > 3:
            compliance['overall_status'] = 'PARTIALLY_COMPLIANT'
        
        return compliance
    
    def _issue_to_dict(self, issue: SecurityIssue) -> Dict[str, Any]:
        """Converte SecurityIssue para dicionário."""
        return {
            'severity': issue.severity,
            'category': issue.category,
            'description': issue.description,
            'line_number': issue.line_number,
            'code_snippet': issue.code_snippet,
            'recommendation': issue.recommendation
        }

