# Motor de Documentação COBOL - Análise de Requisitos

## Objetivo
Desenvolver um motor em Python que analise código COBOL e gere documentação explicativa automatizada usando a API do Copilot/OpenAI.

## Funcionalidades Principais

### 1. Análise de Código COBOL
- Leitura e parsing de arquivos COBOL (.cbl, .cob, .cobol)
- Identificação de estruturas principais:
  - IDENTIFICATION DIVISION
  - ENVIRONMENT DIVISION
  - DATA DIVISION
  - PROCEDURE DIVISION
- Extração de variáveis, parágrafos, seções e procedimentos
- Análise de fluxo de controle e lógica de negócio

### 2. Integração com API Copilot/OpenAI
- Configuração de autenticação com chave API
- Envio de código COBOL para análise
- Processamento de respostas da API
- Tratamento de erros e limitações de rate limit

### 3. Geração de Documentação
- Criação de documentação estruturada em formato Markdown
- Explicação do propósito do programa
- Descrição das principais funcionalidades
- Mapeamento de variáveis e suas utilizações
- Fluxograma de execução
- Exemplos de entrada e saída (quando aplicável)

### 4. Interface de Uso
- Interface de linha de comando (CLI)
- Processamento em lote de múltiplos arquivos
- Configurações personalizáveis
- Logs de execução e relatórios de erro

## Arquitetura do Sistema

### Componentes Principais
1. **CobolParser**: Responsável pela análise sintática do código COBOL
2. **CopilotIntegration**: Gerencia a comunicação com a API do Copilot
3. **DocumentationGenerator**: Gera a documentação final
4. **CLIInterface**: Interface de linha de comando
5. **ConfigManager**: Gerenciamento de configurações

### Fluxo de Dados
```
Arquivo COBOL → CobolParser → CopilotIntegration → DocumentationGenerator → Documentação MD/HTML
```

## Tecnologias e Dependências
- Python 3.8+
- OpenAI Python SDK
- Regex para parsing COBOL
- Click para CLI
- Jinja2 para templates de documentação
- PyYAML para configurações

## Estrutura de Arquivos
```
cobol_documentation_engine/
├── src/
│   ├── __init__.py
│   ├── cobol_parser.py
│   ├── copilot_integration.py
│   ├── documentation_generator.py
│   ├── cli_interface.py
│   └── config_manager.py
├── templates/
│   ├── documentation_template.md
│   └── html_template.html
├── tests/
│   ├── test_cobol_parser.py
│   ├── test_copilot_integration.py
│   └── sample_cobol/
├── config/
│   └── default_config.yaml
├── requirements.txt
├── setup.py
└── README.md
```

## Casos de Uso
1. Análise de programa COBOL legado para migração
2. Documentação de sistemas mainframe existentes
3. Onboarding de novos desenvolvedores em projetos COBOL
4. Auditoria e compliance de código COBOL

## Limitações e Considerações
- Dependência da qualidade das respostas da API do Copilot
- Limitações de rate limit da API
- Complexidade variável do código COBOL
- Necessidade de validação manual da documentação gerada

