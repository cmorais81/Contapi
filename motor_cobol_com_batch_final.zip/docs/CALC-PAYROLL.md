# Documentação do Programa COBOL: CALC-PAYROLL

**Autor:** SISTEMA DE FOLHA DE PAGAMENTO.
**Data de Criação:** 15/12/2023.

---

## 1. Propósito do Programa

**Problema que resolve:**
Automatiza o cálculo da remuneração mensal do funcionário, incluindo o pagamento de horas extras limitadas a um máximo, e o desconto de impostos com base em uma taxa fixa, facilitando o processamento da folha de pagamento.
---

## 2. Funcionalidades Principais

- Inicialização das variáveis de cálculo.

## 3. Lógica de Negócio

**
- Limitação das horas extras a 40 horas.
- Taxa fixa de imposto de 15%.
- Cálculo do pagamento de horas extras com base em taxa e horas trabalhadas.
- Apresentação dos valores em formato monetário com duas casas decimais.
---

## 4. Fluxo de Execução


O fluxo de execução não foi detalhado na análise.


## 5. Entrada e Saída de Dados

- Implementar testes automatizados para garantir a confiabilidade dos cálculos.
---
# Conclusão
O programa CALC-PAYROLL é um sistema simples e funcional para cálculo de folha de pagamento individual, adequado para ambientes básicos. Com pequenas melhorias, especialmente na inicialização de variáveis e validação de dados, pode se tornar mais robusto e confiável para uso em ambientes reais de processamento de folha de pagamento.
---
Se desejar, posso ajudar a elaborar versões melhoradas do código ou documentação adicional.

## 6. Descrição das Variáveis


As variáveis não foram detalhadas na análise.


### Estrutura de Dados Completa

<details>
<summary>Clique para expandir e ver todas as variáveis</summary>

```cobol
1 WS-EMPLOYEE-RECORD 5 WS-EMP-ID PIC 9(5 WS-EMP-NAME PIC X(5 WS-BASIC-SALARY PIC 9(5 WS-OVERTIME-HOURS PIC 9(5 WS-OVERTIME-RATE PIC 9(1 WS-CALCULATIONS 5 WS-OVERTIME-PAY PIC 9(5 WS-GROSS-PAY PIC 9(5 WS-TAX-DEDUCTION PIC 9(5 WS-NET-PAY PIC 9(1 WS-CONSTANTS 5 WS-TAX-RATE PIC 9V995 WS-MAX-OVERTIME PIC 9(
```

</details>

## 7. Avaliação e Recomendações

**Complexidade:** ** Baixa a média.
O programa é linear, com poucas decisões e cálculos simples. Não possui estruturas complexas como loops aninhados, manipulação de arquivos ou tratamento de erros.
- **Pontos de melhoria identificados:**
- A variável **WS-OVERTIME-RATE** não é inicializada nem solicitada ao usuário, o que pode causar resultados incorretos no cálculo do pagamento das horas extras.

**Recomendações:**

Nenhuma recomendação específica.


---

## Anexo: Código Fonte Completo

<details>
<summary>Clique para expandir e ver o código fonte</summary>

```cobol
       IDENTIFICATION DIVISION.
       PROGRAM-ID. CALC-PAYROLL.
       AUTHOR. SISTEMA DE FOLHA DE PAGAMENTO.
       DATE-WRITTEN. 15/12/2023.
       REMARKS. PROGRAMA PARA CALCULAR FOLHA DE PAGAMENTO.

       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. IBM-370.
       OBJECT-COMPUTER. IBM-370.

       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-EMPLOYEE-RECORD.
           05  WS-EMP-ID           PIC 9(6).
           05  WS-EMP-NAME         PIC X(30).
           05  WS-BASIC-SALARY     PIC 9(7)V99.
           05  WS-OVERTIME-HOURS   PIC 9(3).
           05  WS-OVERTIME-RATE    PIC 9(3)V99.
       
       01  WS-CALCULATIONS.
           05  WS-OVERTIME-PAY     PIC 9(7)V99.
           05  WS-GROSS-PAY        PIC 9(8)V99.
           05  WS-TAX-DEDUCTION    PIC 9(6)V99.
           05  WS-NET-PAY          PIC 9(8)V99.
       
       01  WS-CONSTANTS.
           05  WS-TAX-RATE         PIC 9V99 VALUE 0.15.
           05  WS-MAX-OVERTIME     PIC 9(3) VALUE 40.

       PROCEDURE DIVISION.
       MAIN-PROCESS SECTION.
       000-MAIN-ROUTINE.
           PERFORM 100-INITIALIZE
           PERFORM 200-PROCESS-EMPLOYEE
           PERFORM 300-CALCULATE-PAY
           PERFORM 400-DISPLAY-RESULTS
           PERFORM 999-END-PROGRAM.

       100-INITIALIZE.
           DISPLAY 'INICIANDO CALCULO DE FOLHA DE PAGAMENTO'
           MOVE ZEROS TO WS-CALCULATIONS.

       200-PROCESS-EMPLOYEE.
           DISPLAY 'DIGITE O ID DO FUNCIONARIO: '
           ACCEPT WS-EMP-ID
           DISPLAY 'DIGITE O NOME DO FUNCIONARIO: '
           ACCEPT WS-EMP-NAME
           DISPLAY 'DIGITE O SALARIO BASE: '
           ACCEPT WS-BASIC-SALARY
           DISPLAY 'DIGITE AS HORAS EXTRAS: '
           ACCEPT WS-OVERTIME-HOURS.

       300-CALCULATE-PAY.
           IF WS-OVERTIME-HOURS > WS-MAX-OVERTIME
               MOVE WS-MAX-OVERTIME TO WS-OVERTIME-HOURS
           END-IF
           
           COMPUTE WS-OVERTIME-PAY = WS-OVERTIME-HOURS * WS-OVERTIME-RATE
           COMPUTE WS-GROSS-PAY = WS-BASIC-SALARY + WS-OVERTIME-PAY
           COMPUTE WS-TAX-DEDUCTION = WS-GROSS-PAY * WS-TAX-RATE
           COMPUTE WS-NET-PAY = WS-GROSS-PAY - WS-TAX-DEDUCTION.

       400-DISPLAY-RESULTS.
           DISPLAY 'RELATORIO DE PAGAMENTO'
           DISPLAY 'FUNCIONARIO: ' WS-EMP-NAME
           DISPLAY 'SALARIO BASE: ' WS-BASIC-SALARY
           DISPLAY 'HORAS EXTRAS: ' WS-OVERTIME-HOURS
           DISPLAY 'PAGAMENTO HORAS EXTRAS: ' WS-OVERTIME-PAY
           DISPLAY 'SALARIO BRUTO: ' WS-GROSS-PAY
           DISPLAY 'DESCONTO IMPOSTO: ' WS-TAX-DEDUCTION
           DISPLAY 'SALARIO LIQUIDO: ' WS-NET-PAY.

       999-END-PROGRAM.
           DISPLAY 'PROGRAMA FINALIZADO'
           STOP RUN.


```

</details>

