# Documentação do Programa COBOL: ADVANCED-STRUCTURES

**Autor:** TESTE DE ESTRUTURAS AVANCADAS.
**Data de Criação:** 25/12/2023.

---

## 1. Propósito do Programa

### Problema que Resolve
O programa resolve o problema de gerenciamento e consulta de informações de clientes armazenadas em arquivo indexado, facilitando a busca rápida por ID e o cálculo do saldo total dos clientes carregados, além de fornecer um resumo do processamento realizado.
---

## 2. Funcionalidades Principais

### Operações Realizadas
- Inicialização do ambiente e variáveis de trabalho.
- Abertura do arquivo de clientes em modo de leitura e escrita (I-O).
- Leitura sequencial dos registros do arquivo `CUSTOMER.DAT` até o fim do arquivo ou até atingir o limite máximo de registros (100).
- Armazenamento dos registros lidos em uma tabela interna (`WS-CUSTOMER-TABLE`).
- Cálculo do saldo total dos clientes durante a leitura.

## 3. Lógica de Negócio

A documentação e melhorias sugeridas visam facilitar a manutenção, aumentar a robustez e preparar o programa para possíveis evoluções futuras.
---
Se desejar, posso auxiliar na geração de documentação técnica formalizada (ex: manual do usuário, manual de manutenção) ou na refatoração do código para atender padrões modernos.

## 4. Fluxo de Execução


O fluxo de execução não foi detalhado na análise.


## 5. Entrada e Saída de Dados

---
# Conclusão

## 6. Descrição das Variáveis


As variáveis não foram detalhadas na análise.


### Estrutura de Dados Completa

<details>
<summary>Clique para expandir e ver todas as variáveis</summary>

```cobol
1 CUSTOMER-RECORD 5 CUST-ID PIC 9(5 CUST-NAME PIC X(5 CUST-ADDRESS 10 STREET PIC X(10 CITY PIC X(10 STATE PIC XX.10 ZIP-CODE PIC 9(5 CUST-PHONE PIC X(5 CUST-BALANCE PIC S9(1 WS-FILE-STATUS PIC XX.1 WS-CUSTOMER-TABLE 5 WS-CUSTOMER-COUNT PIC 9(5 WS-CUSTOMER-ENTRY 10 WS-CUST-ID PIC 9(10 WS-CUST-NAME PIC X(10 WS-CUST-BALANCE PIC S9(1 WS-WORK-AREAS 5 WS-TOTAL-BALANCE PIC S9(9)V995 WS-RECORD-COUNT PIC 9(5 WS-SEARCH-KEY PIC 9(5 WS-FOUND-FLAG PIC X1 WS-DATE-FIELDS 5 WS-CURRENT-DATE 10 WS-YEAR PIC 9(10 WS-MONTH PIC 9(10 WS-DAY PIC 9(5 WS-FORMATTED-DATE PIC X(1 WS-REDEFINE-AREA PIC X(1 WS-NUMERIC-AREA 5 WS-NUM-PART PIC 9(5 WS-ALPHA-PART PIC X(1 WS-COUNTERS 5 WS-I PIC 9(5 WS-J PIC 9(5 WS-MAX-RECORDS PIC 9(
```

</details>

## 7. Avaliação e Recomendações

**Complexidade:** Média.
- O programa apresenta estruturas básicas de controle (PERFORM, IF, READ), manipulação de arquivos indexados e uso de tabelas internas com OCCURS DEPENDING ON.

**Recomendações:**

Nenhuma recomendação específica.


---

## Anexo: Código Fonte Completo

<details>
<summary>Clique para expandir e ver o código fonte</summary>

```cobol
       IDENTIFICATION DIVISION.
       PROGRAM-ID. ADVANCED-STRUCTURES.
       AUTHOR. TESTE DE ESTRUTURAS AVANCADAS.
       DATE-WRITTEN. 25/12/2023.

       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT CUSTOMER-FILE ASSIGN TO 'CUSTOMER.DAT'
           ORGANIZATION IS INDEXED
           ACCESS MODE IS DYNAMIC
           RECORD KEY IS CUST-ID
           ALTERNATE RECORD KEY IS CUST-NAME
           FILE STATUS IS WS-FILE-STATUS.

       DATA DIVISION.
       FILE SECTION.
       FD  CUSTOMER-FILE.
       01  CUSTOMER-RECORD.
           05  CUST-ID             PIC 9(6).
           05  CUST-NAME           PIC X(30).
           05  CUST-ADDRESS.
               10  STREET          PIC X(25).
               10  CITY            PIC X(20).
               10  STATE           PIC XX.
               10  ZIP-CODE        PIC 9(5).
           05  CUST-PHONE          PIC X(12).
           05  CUST-BALANCE        PIC S9(7)V99 COMP-3.

       WORKING-STORAGE SECTION.
       01  WS-FILE-STATUS          PIC XX.
           88  FILE-OK             VALUE '00'.
           88  FILE-EOF            VALUE '10'.
           88  FILE-NOT-FOUND      VALUE '23'.
           88  FILE-DUPLICATE      VALUE '22'.

       01  WS-CUSTOMER-TABLE.
           05  WS-CUSTOMER-COUNT   PIC 9(3) VALUE ZERO.
           05  WS-CUSTOMER-ENTRY   OCCURS 100 TIMES
                                   DEPENDING ON WS-CUSTOMER-COUNT
                                   INDEXED BY CUST-IDX.
               10  WS-CUST-ID      PIC 9(6).
               10  WS-CUST-NAME    PIC X(30).
               10  WS-CUST-BALANCE PIC S9(7)V99.

       01  WS-WORK-AREAS.
           05  WS-TOTAL-BALANCE    PIC S9(9)V99 VALUE ZERO.
           05  WS-RECORD-COUNT     PIC 9(5) VALUE ZERO.
           05  WS-SEARCH-KEY       PIC 9(6).
           05  WS-FOUND-FLAG       PIC X VALUE 'N'.
               88  CUSTOMER-FOUND  VALUE 'Y'.
               88  CUSTOMER-NOT-FOUND VALUE 'N'.

       01  WS-DATE-FIELDS.
           05  WS-CURRENT-DATE.
               10  WS-YEAR         PIC 9(4).
               10  WS-MONTH        PIC 9(2).
               10  WS-DAY          PIC 9(2).
           05  WS-FORMATTED-DATE   PIC X(10).

       01  WS-REDEFINE-AREA        PIC X(20) VALUE SPACES.
       01  WS-NUMERIC-AREA REDEFINES WS-REDEFINE-AREA.
           05  WS-NUM-PART         PIC 9(10).
           05  WS-ALPHA-PART       PIC X(10).

       01  WS-COUNTERS.
           05  WS-I                PIC 9(3) VALUE 1.
           05  WS-J                PIC 9(3) VALUE 1.
           05  WS-MAX-RECORDS      PIC 9(3) VALUE 100.

       PROCEDURE DIVISION.
       MAIN-PROCESS SECTION.
       000-MAIN-ROUTINE.
           PERFORM 100-INITIALIZE
           PERFORM 200-LOAD-CUSTOMER-TABLE
           PERFORM 300-PROCESS-CUSTOMERS
           PERFORM 400-DISPLAY-SUMMARY
           PERFORM 999-END-PROGRAM.

       100-INITIALIZE.
           DISPLAY 'INICIANDO PROCESSAMENTO DE CLIENTES'
           MOVE FUNCTION CURRENT-DATE TO WS-CURRENT-DATE
           MOVE ZERO TO WS-CUSTOMER-COUNT
           MOVE ZERO TO WS-TOTAL-BALANCE
           OPEN I-O CUSTOMER-FILE
           IF NOT FILE-OK
               DISPLAY 'ERRO AO ABRIR ARQUIVO: ' WS-FILE-STATUS
               PERFORM 999-END-PROGRAM
           END-IF.

       200-LOAD-CUSTOMER-TABLE.
           MOVE ZERO TO WS-RECORD-COUNT
           PERFORM UNTIL FILE-EOF OR WS-CUSTOMER-COUNT >= WS-MAX-RECORDS
               READ CUSTOMER-FILE NEXT RECORD
                   AT END
                       SET FILE-EOF TO TRUE
                   NOT AT END
                       ADD 1 TO WS-CUSTOMER-COUNT
                       ADD 1 TO WS-RECORD-COUNT
                       MOVE CUST-ID TO 
                           WS-CUST-ID(WS-CUSTOMER-COUNT)
                       MOVE CUST-NAME TO 
                           WS-CUST-NAME(WS-CUSTOMER-COUNT)
                       MOVE CUST-BALANCE TO 
                           WS-CUST-BALANCE(WS-CUSTOMER-COUNT)
                       ADD CUST-BALANCE TO WS-TOTAL-BALANCE
               END-READ
           END-PERFORM
           
           DISPLAY 'REGISTROS CARREGADOS: ' WS-RECORD-COUNT.

       300-PROCESS-CUSTOMERS.
           DISPLAY 'DIGITE ID DO CLIENTE PARA BUSCA: '
           ACCEPT WS-SEARCH-KEY
           
           SET CUSTOMER-NOT-FOUND TO TRUE
           PERFORM VARYING WS-I FROM 1 BY 1 
                   UNTIL WS-I > WS-CUSTOMER-COUNT 
                      OR CUSTOMER-FOUND
               IF WS-CUST-ID(WS-I) = WS-SEARCH-KEY
                   SET CUSTOMER-FOUND TO TRUE
                   DISPLAY 'CLIENTE ENCONTRADO:'
                   DISPLAY 'ID: ' WS-CUST-ID(WS-I)
                   DISPLAY 'NOME: ' WS-CUST-NAME(WS-I)
                   DISPLAY 'SALDO: ' WS-CUST-BALANCE(WS-I)
               END-IF
           END-PERFORM
           
           IF CUSTOMER-NOT-FOUND
               DISPLAY 'CLIENTE NAO ENCONTRADO'
           END-IF.

       400-DISPLAY-SUMMARY.
           DISPLAY 'RESUMO DO PROCESSAMENTO:'
           DISPLAY 'TOTAL DE CLIENTES: ' WS-CUSTOMER-COUNT
           DISPLAY 'SALDO TOTAL: ' WS-TOTAL-BALANCE
           
           COMPUTE WS-FORMATTED-DATE = 
               WS-DAY '/' WS-MONTH '/' WS-YEAR
           DISPLAY 'DATA DO PROCESSAMENTO: ' WS-FORMATTED-DATE.

       999-END-PROGRAM.
           CLOSE CUSTOMER-FILE
           DISPLAY 'PROGRAMA FINALIZADO'
           STOP RUN.


```

</details>

