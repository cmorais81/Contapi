# Documentação do Programa COBOL: INVENTORY-MGMT

**Autor:** SISTEMA DE ESTOQUE.
**Data de Criação:** 20/12/2023.

---

## 1. Propósito do Programa

### Problema que Resolve
Resolve o problema de controle manual do estoque, automatizando a consulta, listagem e monitoramento dos produtos, facilitando a identificação de produtos com estoque baixo e possibilitando futuras atualizações no estoque.
---

## 2. Funcionalidades Principais

---
Se desejar, posso auxiliar na implementação das melhorias ou na criação de documentação técnica complementar.

## 3. Lógica de Negócio

- Produto é identificado unicamente pelo `PROD-ID`.
- Estoque baixo é definido quando `PROD-QUANTITY` é menor ou igual a `PROD-MIN-STOCK`.
- O programa não permite opções inválidas no menu.
- A atualização de estoque está prevista, mas ainda não implementada.
---

## 4. Fluxo de Execução


O fluxo de execução não foi detalhado na análise.


## 5. Entrada e Saída de Dados

- Modularizar o código em seções e parágrafos mais granulares para facilitar manutenção.
- Migrar para uso de banco de dados ou arquivos indexados para maior eficiência.
- Criar interface gráfica ou web para melhorar usabilidade.
- Internacionalizar mensagens para suportar múltiplos idiomas.
---
# Conclusão

## 6. Descrição das Variáveis


As variáveis não foram detalhadas na análise.


### Estrutura de Dados Completa

<details>
<summary>Clique para expandir e ver todas as variáveis</summary>

```cobol
1 PRODUCT-RECORD 5 PROD-ID PIC 9(5 PROD-NAME PIC X(5 PROD-QUANTITY PIC 9(5 PROD-PRICE PIC 9(5 PROD-MIN-STOCK PIC 9(1 WS-PRODUCT-WORK 5 WS-PROD-ID PIC 9(5 WS-PROD-NAME PIC X(5 WS-QUANTITY-CHANGE PIC S9(5 WS-NEW-QUANTITY PIC 9(1 WS-COUNTERS 5 WS-TOTAL-PRODUCTS PIC 9(5 WS-LOW-STOCK-COUNT PIC 9(1 WS-FLAGS 5 WS-EOF-FLAG PIC X5 WS-FOUND-FLAG PIC X1 WS-MENU-OPTION PIC 9
```

</details>

## 7. Avaliação e Recomendações

**Complexidade:** ** Média.
- O programa possui estrutura clara e modularizada em parágrafos, com uso adequado de flags e variáveis de controle.
- Não há manipulação complexa de dados, mas o uso de arquivo sequencial e controle de fluxo exige atenção.

**Recomendações:**

Nenhuma recomendação específica.


---

## Anexo: Código Fonte Completo

<details>
<summary>Clique para expandir e ver o código fonte</summary>

```cobol
       IDENTIFICATION DIVISION.
       PROGRAM-ID. INVENTORY-MGMT.
       AUTHOR. SISTEMA DE ESTOQUE.
       DATE-WRITTEN. 20/12/2023.
       REMARKS. PROGRAMA PARA GERENCIAR ESTOQUE DE PRODUTOS.

       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT PRODUCT-FILE ASSIGN TO 'PRODUCTS.DAT'
           ORGANIZATION IS SEQUENTIAL
           ACCESS MODE IS SEQUENTIAL.

       DATA DIVISION.
       FILE SECTION.
       FD  PRODUCT-FILE.
       01  PRODUCT-RECORD.
           05  PROD-ID             PIC 9(5).
           05  PROD-NAME           PIC X(25).
           05  PROD-QUANTITY       PIC 9(5).
           05  PROD-PRICE          PIC 9(5)V99.
           05  PROD-MIN-STOCK      PIC 9(3).

       WORKING-STORAGE SECTION.
       01  WS-PRODUCT-WORK.
           05  WS-PROD-ID          PIC 9(5).
           05  WS-PROD-NAME        PIC X(25).
           05  WS-QUANTITY-CHANGE  PIC S9(4).
           05  WS-NEW-QUANTITY     PIC 9(5).
       
       01  WS-COUNTERS.
           05  WS-TOTAL-PRODUCTS   PIC 9(4) VALUE ZERO.
           05  WS-LOW-STOCK-COUNT  PIC 9(3) VALUE ZERO.
       
       01  WS-FLAGS.
           05  WS-EOF-FLAG         PIC X VALUE 'N'.
           05  WS-FOUND-FLAG       PIC X VALUE 'N'.
       
       01  WS-MENU-OPTION         PIC 9 VALUE ZERO.

       PROCEDURE DIVISION.
       MAIN-PROCESS SECTION.
       000-MAIN-ROUTINE.
           PERFORM 100-INITIALIZE
           PERFORM 200-MAIN-MENU UNTIL WS-MENU-OPTION = 9
           PERFORM 999-END-PROGRAM.

       100-INITIALIZE.
           DISPLAY 'SISTEMA DE GERENCIAMENTO DE ESTOQUE'
           DISPLAY '=================================='
           OPEN INPUT PRODUCT-FILE.

       200-MAIN-MENU.
           DISPLAY ' '
           DISPLAY 'MENU PRINCIPAL:'
           DISPLAY '1 - LISTAR PRODUTOS'
           DISPLAY '2 - BUSCAR PRODUTO'
           DISPLAY '3 - ATUALIZAR ESTOQUE'
           DISPLAY '4 - RELATORIO DE ESTOQUE BAIXO'
           DISPLAY '9 - SAIR'
           DISPLAY 'ESCOLHA UMA OPCAO: '
           ACCEPT WS-MENU-OPTION
           
           EVALUATE WS-MENU-OPTION
               WHEN 1
                   PERFORM 300-LIST-PRODUCTS
               WHEN 2
                   PERFORM 400-SEARCH-PRODUCT
               WHEN 3
                   PERFORM 500-UPDATE-STOCK
               WHEN 4
                   PERFORM 600-LOW-STOCK-REPORT
               WHEN 9
                   DISPLAY 'SAINDO DO SISTEMA...'
               WHEN OTHER
                   DISPLAY 'OPCAO INVALIDA!'
           END-EVALUATE.

       300-LIST-PRODUCTS.
           DISPLAY 'LISTA DE PRODUTOS:'
           DISPLAY '=================='
           MOVE 'N' TO WS-EOF-FLAG
           MOVE ZERO TO WS-TOTAL-PRODUCTS
           
           PERFORM UNTIL WS-EOF-FLAG = 'Y'
               READ PRODUCT-FILE
                   AT END
                       MOVE 'Y' TO WS-EOF-FLAG
                   NOT AT END
                       ADD 1 TO WS-TOTAL-PRODUCTS
                       DISPLAY PROD-ID ' - ' PROD-NAME 
                               ' QTD: ' PROD-QUANTITY
                               ' PRECO: ' PROD-PRICE
               END-READ
           END-PERFORM
           
           DISPLAY 'TOTAL DE PRODUTOS: ' WS-TOTAL-PRODUCTS.

       400-SEARCH-PRODUCT.
           DISPLAY 'DIGITE O ID DO PRODUTO: '
           ACCEPT WS-PROD-ID
           MOVE 'N' TO WS-EOF-FLAG
           MOVE 'N' TO WS-FOUND-FLAG
           
           PERFORM UNTIL WS-EOF-FLAG = 'Y' OR WS-FOUND-FLAG = 'Y'
               READ PRODUCT-FILE
                   AT END
                       MOVE 'Y' TO WS-EOF-FLAG
                   NOT AT END
                       IF PROD-ID = WS-PROD-ID
                           MOVE 'Y' TO WS-FOUND-FLAG
                           DISPLAY 'PRODUTO ENCONTRADO:'
                           DISPLAY 'ID: ' PROD-ID
                           DISPLAY 'NOME: ' PROD-NAME
                           DISPLAY 'QUANTIDADE: ' PROD-QUANTITY
                           DISPLAY 'PRECO: ' PROD-PRICE
                           DISPLAY 'ESTOQUE MINIMO: ' PROD-MIN-STOCK
                       END-IF
               END-READ
           END-PERFORM
           
           IF WS-FOUND-FLAG = 'N'
               DISPLAY 'PRODUTO NAO ENCONTRADO!'
           END-IF.

       500-UPDATE-STOCK.
           DISPLAY 'ATUALIZACAO DE ESTOQUE'
           DISPLAY 'DIGITE O ID DO PRODUTO: '
           ACCEPT WS-PROD-ID
           DISPLAY 'DIGITE A ALTERACAO (+/-): '
           ACCEPT WS-QUANTITY-CHANGE
           
           DISPLAY 'FUNCIONALIDADE EM DESENVOLVIMENTO'.

       600-LOW-STOCK-REPORT.
           DISPLAY 'RELATORIO DE ESTOQUE BAIXO:'
           DISPLAY '=========================='
           MOVE 'N' TO WS-EOF-FLAG
           MOVE ZERO TO WS-LOW-STOCK-COUNT
           
           PERFORM UNTIL WS-EOF-FLAG = 'Y'
               READ PRODUCT-FILE
                   AT END
                       MOVE 'Y' TO WS-EOF-FLAG
                   NOT AT END
                       IF PROD-QUANTITY <= PROD-MIN-STOCK
                           ADD 1 TO WS-LOW-STOCK-COUNT
                           DISPLAY PROD-ID ' - ' PROD-NAME 
                                   ' QTD ATUAL: ' PROD-QUANTITY
                                   ' MIN: ' PROD-MIN-STOCK
                       END-IF
               END-READ
           END-PERFORM
           
           DISPLAY 'PRODUTOS COM ESTOQUE BAIXO: ' WS-LOW-STOCK-COUNT.

       999-END-PROGRAM.
           CLOSE PRODUCT-FILE
           DISPLAY 'SISTEMA FINALIZADO'
           STOP RUN.


```

</details>

