"""
Analisador contextual inteligente para programas COBOL.
"""

import re
from typing import Dict, List, Set, Tuple, Any, Optional
from dataclasses import dataclass
from enum import Enum

from cobol_parser import CobolProgram, CobolVariable
from data_flow_analyzer import DataFlowAnalyzer
from complexity_analyzer import ComplexityAnalyzer
from pattern_detector import PatternDetector


class BusinessDomain(Enum):
    """Domínios de negócio identificáveis."""
    FINANCIAL = "Financeiro"
    PAYROLL = "Folha de Pagamento"
    INVENTORY = "Estoque/Inventário"
    CUSTOMER = "Gestão de Clientes"
    ACCOUNTING = "Contabilidade"
    INSURANCE = "Seguros"
    BANKING = "Bancário"
    RETAIL = "Varejo"
    MANUFACTURING = "Manufatura"
    HEALTHCARE = "Saúde"
    GOVERNMENT = "Governo"
    UTILITIES = "Utilidades"
    TELECOMMUNICATIONS = "Telecomunicações"
    UNKNOWN = "Não Identificado"


class ComplexityCategory(Enum):
    """Categorias de complexidade."""
    SIMPLE = "Simples"
    MODERATE = "Moderada"
    COMPLEX = "Complexa"
    VERY_COMPLEX = "Muito Complexa"


@dataclass
class DomainIndicator:
    """Indicador de domínio de negócio."""
    domain: BusinessDomain
    confidence: float  # 0.0 a 1.0
    evidence: List[str]
    keywords_found: List[str]


@dataclass
class ContextualInsight:
    """Insight contextual sobre o programa."""
    category: str
    description: str
    confidence: float
    evidence: List[str]
    recommendations: List[str] = None
    
    def __post_init__(self):
        if self.recommendations is None:
            self.recommendations = []


@dataclass
class ProgramContext:
    """Contexto completo do programa."""
    program: CobolProgram
    business_domain: BusinessDomain
    domain_confidence: float
    complexity_category: ComplexityCategory
    critical_sections: List[str]
    modernization_candidates: List[str]
    data_relationships: Dict[str, List[str]]
    integration_complexity: str
    security_concerns: List[str]
    performance_hotspots: List[str]
    insights: List[ContextualInsight]


class ContextualAnalyzer:
    """Analisador contextual inteligente para programas COBOL."""
    
    def __init__(self):
        # Dicionários de palavras-chave por domínio
        self.domain_keywords = {
            BusinessDomain.FINANCIAL: [
                'account', 'balance', 'transaction', 'payment', 'credit', 'debit',
                'interest', 'loan', 'deposit', 'withdrawal', 'amount', 'currency',
                'conta', 'saldo', 'transacao', 'pagamento', 'credito', 'debito',
                'juros', 'emprestimo', 'deposito', 'saque', 'valor', 'moeda'
            ],
            BusinessDomain.PAYROLL: [
                'salary', 'wage', 'employee', 'payroll', 'tax', 'deduction',
                'overtime', 'bonus', 'benefit', 'pension', 'social', 'inss',
                'salario', 'funcionario', 'folha', 'imposto', 'desconto',
                'hora-extra', 'bonus', 'beneficio', 'pensao', 'previdencia'
            ],
            BusinessDomain.INVENTORY: [
                'stock', 'inventory', 'product', 'item', 'quantity', 'warehouse',
                'supplier', 'order', 'purchase', 'delivery', 'shipment',
                'estoque', 'inventario', 'produto', 'item', 'quantidade', 'almoxarifado',
                'fornecedor', 'pedido', 'compra', 'entrega', 'remessa'
            ],
            BusinessDomain.CUSTOMER: [
                'customer', 'client', 'contact', 'address', 'phone', 'email',
                'registration', 'profile', 'preference', 'history', 'service',
                'cliente', 'contato', 'endereco', 'telefone', 'email',
                'cadastro', 'perfil', 'preferencia', 'historico', 'servico'
            ],
            BusinessDomain.ACCOUNTING: [
                'ledger', 'journal', 'asset', 'liability', 'equity', 'revenue',
                'expense', 'depreciation', 'amortization', 'fiscal', 'audit',
                'razao', 'diario', 'ativo', 'passivo', 'patrimonio', 'receita',
                'despesa', 'depreciacao', 'amortizacao', 'fiscal', 'auditoria'
            ],
            BusinessDomain.INSURANCE: [
                'policy', 'premium', 'claim', 'coverage', 'deductible', 'beneficiary',
                'underwriting', 'risk', 'actuarial', 'reserve', 'reinsurance',
                'apolice', 'premio', 'sinistro', 'cobertura', 'franquia', 'beneficiario',
                'subscricao', 'risco', 'atuarial', 'reserva', 'resseguro'
            ],
            BusinessDomain.BANKING: [
                'bank', 'branch', 'atm', 'card', 'check', 'transfer', 'swift',
                'routing', 'clearing', 'settlement', 'correspondent', 'fed',
                'banco', 'agencia', 'caixa', 'cartao', 'cheque', 'transferencia',
                'compensacao', 'liquidacao', 'correspondente', 'bacen'
            ]
        }
        
        # Padrões de complexidade
        self.complexity_patterns = {
            'high_complexity_keywords': [
                'REDEFINES', 'OCCURS DEPENDING', 'PERFORM THRU', 'GO TO',
                'EXEC SQL', 'EXEC CICS', 'CALL', 'SORT', 'MERGE'
            ],
            'integration_keywords': [
                'CALL', 'EXEC SQL', 'EXEC CICS', 'MQ', 'DB2', 'IMS',
                'VSAM', 'QSAM', 'COPY', 'INCLUDE'
            ],
            'performance_keywords': [
                'SEARCH ALL', 'SORT', 'MERGE', 'PERFORM VARYING',
                'OCCURS', 'INDEX', 'POINTER'
            ]
        }
    
    def build_context(self, program: CobolProgram) -> ProgramContext:
        """
        Constrói contexto completo do programa.
        
        Args:
            program: Programa COBOL analisado
            
        Returns:
            Contexto completo do programa
        """
        # Detecta domínio de negócio
        domain_analysis = self.detect_business_domain(program)
        
        # Avalia complexidade
        complexity_category = self.assess_complexity(program)
        
        # Identifica seções críticas
        critical_sections = self.identify_critical_code_sections(program)
        
        # Identifica candidatos à modernização
        modernization_candidates = self.identify_modernization_opportunities(program)
        
        # Mapeia relacionamentos de dados
        data_relationships = self.map_data_relationships(program)
        
        # Avalia complexidade de integração
        integration_complexity = self.assess_integration_complexity(program)
        
        # Identifica preocupações de segurança
        security_concerns = self.identify_security_concerns(program)
        
        # Identifica hotspots de performance
        performance_hotspots = self.identify_performance_hotspots(program)
        
        # Gera insights contextuais
        insights = self.generate_contextual_insights(program, domain_analysis, complexity_category)
        
        return ProgramContext(
            program=program,
            business_domain=domain_analysis.domain,
            domain_confidence=domain_analysis.confidence,
            complexity_category=complexity_category,
            critical_sections=critical_sections,
            modernization_candidates=modernization_candidates,
            data_relationships=data_relationships,
            integration_complexity=integration_complexity,
            security_concerns=security_concerns,
            performance_hotspots=performance_hotspots,
            insights=insights
        )
    
    def detect_business_domain(self, program: CobolProgram) -> DomainIndicator:
        """
        Detecta o domínio de negócio do programa.
        
        Args:
            program: Programa COBOL
            
        Returns:
            Indicador de domínio com confiança
        """
        content_lower = program.raw_content.lower()
        domain_scores = {}
        evidence_by_domain = {}
        keywords_found_by_domain = {}
        
        # Analisa cada domínio
        for domain, keywords in self.domain_keywords.items():
            score = 0
            evidence = []
            keywords_found = []
            
            for keyword in keywords:
                count = content_lower.count(keyword.lower())
                if count > 0:
                    score += count
                    keywords_found.append(keyword)
                    evidence.append(f"'{keyword}' encontrado {count} vez(es)")
            
            domain_scores[domain] = score
            evidence_by_domain[domain] = evidence
            keywords_found_by_domain[domain] = keywords_found
        
        # Encontra domínio com maior pontuação
        if not domain_scores or max(domain_scores.values()) == 0:
            return DomainIndicator(
                domain=BusinessDomain.UNKNOWN,
                confidence=0.0,
                evidence=["Nenhuma palavra-chave de domínio específico encontrada"],
                keywords_found=[]
            )
        
        best_domain = max(domain_scores.keys(), key=lambda d: domain_scores[d])
        max_score = domain_scores[best_domain]
        
        # Calcula confiança baseada na pontuação relativa
        total_score = sum(domain_scores.values())
        confidence = max_score / total_score if total_score > 0 else 0.0
        
        # Ajusta confiança baseada na quantidade de evidências
        evidence_count = len(evidence_by_domain[best_domain])
        if evidence_count >= 5:
            confidence = min(1.0, confidence * 1.2)
        elif evidence_count <= 2:
            confidence = confidence * 0.8
        
        return DomainIndicator(
            domain=best_domain,
            confidence=min(1.0, confidence),
            evidence=evidence_by_domain[best_domain],
            keywords_found=keywords_found_by_domain[best_domain]
        )
    
    def assess_complexity(self, program: CobolProgram) -> ComplexityCategory:
        """
        Avalia a categoria de complexidade do programa.
        
        Args:
            program: Programa COBOL
            
        Returns:
            Categoria de complexidade
        """
        complexity_score = 0
        content_upper = program.raw_content.upper()
        
        # Fatores de complexidade
        factors = {
            'lines_of_code': len(program.raw_content.split('\n')),
            'variables': len(program.variables),
            'paragraphs': len(program.paragraphs),
            'sections': len(program.sections)
        }
        
        # Pontuação baseada em tamanho
        if factors['lines_of_code'] > 1000:
            complexity_score += 3
        elif factors['lines_of_code'] > 500:
            complexity_score += 2
        elif factors['lines_of_code'] > 200:
            complexity_score += 1
        
        # Pontuação baseada em estruturas complexas
        for keyword in self.complexity_patterns['high_complexity_keywords']:
            count = content_upper.count(keyword)
            complexity_score += count * 0.5
        
        # Pontuação baseada em integrações
        for keyword in self.complexity_patterns['integration_keywords']:
            count = content_upper.count(keyword)
            complexity_score += count * 0.3
        
        # Categoriza complexidade
        if complexity_score >= 15:
            return ComplexityCategory.VERY_COMPLEX
        elif complexity_score >= 10:
            return ComplexityCategory.COMPLEX
        elif complexity_score >= 5:
            return ComplexityCategory.MODERATE
        else:
            return ComplexityCategory.SIMPLE
    
    def identify_critical_code_sections(self, program: CobolProgram) -> List[str]:
        """
        Identifica seções críticas do código.
        
        Args:
            program: Programa COBOL
            
        Returns:
            Lista de seções críticas
        """
        critical_sections = []
        lines = program.raw_content.split('\n')
        
        # Identifica seções com alta densidade de lógica de negócio
        current_paragraph = None
        business_logic_density = {}
        
        for line in lines:
            # Identifica parágrafo atual
            paragraph_match = re.match(r'^\s*([A-Z0-9][A-Z0-9-]*)\s*\.', line, re.IGNORECASE)
            if paragraph_match and not any(keyword in line.upper() for keyword in ['DIVISION', 'SECTION']):
                current_paragraph = paragraph_match.group(1)
                business_logic_density[current_paragraph] = 0
            
            # Conta lógica de negócio
            if current_paragraph and any(keyword in line.upper() for keyword in 
                ['IF', 'WHEN', 'COMPUTE', 'EVALUATE', 'PERFORM', 'CALL']):
                business_logic_density[current_paragraph] += 1
        
        # Identifica parágrafos com alta densidade
        for paragraph, density in business_logic_density.items():
            if density >= 5:  # Threshold para criticidade
                critical_sections.append(f"{paragraph} (densidade de lógica: {density})")
        
        # Identifica seções com operações críticas
        for line_num, line in enumerate(lines, 1):
            line_upper = line.upper().strip()
            if any(critical_op in line_upper for critical_op in 
                ['EXEC SQL COMMIT', 'EXEC SQL ROLLBACK', 'STOP RUN', 'GOBACK']):
                critical_sections.append(f"Linha {line_num}: {line.strip()}")
        
        return critical_sections[:10]  # Limita a 10 seções mais críticas
    
    def identify_modernization_opportunities(self, program: CobolProgram) -> List[str]:
        """
        Identifica oportunidades de modernização.
        
        Args:
            program: Programa COBOL
            
        Returns:
            Lista de oportunidades de modernização
        """
        opportunities = []
        content_upper = program.raw_content.upper()
        
        # Padrões que indicam oportunidades de modernização
        modernization_patterns = {
            'GO TO': 'Substituir por programação estruturada (PERFORM)',
            'PERFORM THRU': 'Refatorar para PERFORM simples ou inline',
            'REDEFINES': 'Considerar estruturas de dados mais claras',
            'EXEC SQL': 'Avaliar migração para ORM ou APIs REST',
            'EXEC CICS': 'Considerar arquitetura de microserviços',
            'SORT': 'Avaliar uso de ferramentas modernas de processamento',
            'CALL': 'Considerar APIs ou serviços web'
        }
        
        for pattern, suggestion in modernization_patterns.items():
            count = content_upper.count(pattern)
            if count > 0:
                opportunities.append(f"{pattern} ({count}x): {suggestion}")
        
        # Identifica estruturas de dados complexas
        complex_structures = 0
        for var in program.variables:
            if var.occurs or var.redefines or len(var.children) > 5:
                complex_structures += 1
        
        if complex_structures > 5:
            opportunities.append(f"Estruturas de dados complexas ({complex_structures}): Considerar normalização")
        
        # Identifica processamento batch pesado
        if 'READ' in content_upper and content_upper.count('READ') > 10:
            opportunities.append("Processamento batch intensivo: Considerar streaming ou processamento paralelo")
        
        return opportunities
    
    def map_data_relationships(self, program: CobolProgram) -> Dict[str, List[str]]:
        """
        Mapeia relacionamentos entre dados.
        
        Args:
            program: Programa COBOL
            
        Returns:
            Dicionário com relacionamentos de dados
        """
        relationships = {}
        
        # Analisa hierarquia de variáveis
        for var in program.variables:
            if var.parent:
                if var.parent not in relationships:
                    relationships[var.parent] = []
                relationships[var.parent].append(var.name)
        
        # Analisa redefinições
        for var in program.variables:
            if var.redefines:
                if var.redefines not in relationships:
                    relationships[var.redefines] = []
                relationships[var.redefines].append(f"{var.name} (REDEFINES)")
        
        # Analisa fluxo de dados através de MOVE statements
        lines = program.raw_content.split('\n')
        move_pattern = re.compile(r'MOVE\s+(.+?)\s+TO\s+(.+)', re.IGNORECASE)
        
        for line in lines:
            match = move_pattern.search(line)
            if match:
                source = match.group(1).strip()
                target = match.group(2).strip()
                
                if source not in relationships:
                    relationships[source] = []
                relationships[source].append(f"{target} (MOVE)")
        
        return relationships
    
    def assess_integration_complexity(self, program: CobolProgram) -> str:
        """
        Avalia complexidade de integração.
        
        Args:
            program: Programa COBOL
            
        Returns:
            Nível de complexidade de integração
        """
        content_upper = program.raw_content.upper()
        integration_score = 0
        
        # Pontuação por tipo de integração
        integration_weights = {
            'CALL': 2,
            'EXEC SQL': 3,
            'EXEC CICS': 4,
            'COPY': 1,
            'INCLUDE': 1,
            'MQ': 3,
            'DB2': 3,
            'IMS': 4,
            'VSAM': 2,
            'QSAM': 1
        }
        
        for keyword, weight in integration_weights.items():
            count = content_upper.count(keyword)
            integration_score += count * weight
        
        # Categoriza complexidade
        if integration_score >= 20:
            return "Muito Alta"
        elif integration_score >= 10:
            return "Alta"
        elif integration_score >= 5:
            return "Média"
        elif integration_score > 0:
            return "Baixa"
        else:
            return "Mínima"
    
    def identify_security_concerns(self, program: CobolProgram) -> List[str]:
        """
        Identifica preocupações de segurança.
        
        Args:
            program: Programa COBOL
            
        Returns:
            Lista de preocupações de segurança
        """
        concerns = []
        content_lower = program.raw_content.lower()
        
        # Padrões de segurança
        security_patterns = {
            'password': 'Possível manipulação de senhas em texto claro',
            'senha': 'Possível manipulação de senhas em texto claro',
            'pwd': 'Possível manipulação de senhas em texto claro',
            'accept': 'Entrada de dados sem validação aparente',
            'display': 'Possível exposição de dados sensíveis',
            'cpf': 'Manipulação de dados pessoais sensíveis',
            'cnpj': 'Manipulação de dados empresariais sensíveis',
            'card': 'Possível manipulação de dados de cartão',
            'account': 'Manipulação de dados de conta'
        }
        
        for pattern, concern in security_patterns.items():
            if pattern in content_lower:
                count = content_lower.count(pattern)
                concerns.append(f"{concern} ({count} ocorrência(s))")
        
        # Verifica falta de validação em ACCEPT
        lines = program.raw_content.split('\n')
        accept_without_validation = 0
        
        for i, line in enumerate(lines):
            if 'ACCEPT' in line.upper():
                # Verifica se há validação nas próximas 3 linhas
                has_validation = False
                for j in range(i+1, min(i+4, len(lines))):
                    if any(val_keyword in lines[j].upper() for val_keyword in 
                          ['IF', 'NUMERIC', 'ALPHABETIC', 'SPACE']):
                        has_validation = True
                        break
                
                if not has_validation:
                    accept_without_validation += 1
        
        if accept_without_validation > 0:
            concerns.append(f"ACCEPT sem validação aparente ({accept_without_validation} caso(s))")
        
        return concerns
    
    def identify_performance_hotspots(self, program: CobolProgram) -> List[str]:
        """
        Identifica hotspots de performance.
        
        Args:
            program: Programa COBOL
            
        Returns:
            Lista de hotspots de performance
        """
        hotspots = []
        lines = program.raw_content.split('\n')
        
        # Analisa loops aninhados
        loop_depth = 0
        max_loop_depth = 0
        
        for line in lines:
            line_upper = line.upper().strip()
            if 'PERFORM' in line_upper and ('UNTIL' in line_upper or 'VARYING' in line_upper):
                loop_depth += 1
                max_loop_depth = max(max_loop_depth, loop_depth)
            elif 'END-PERFORM' in line_upper:
                loop_depth = max(0, loop_depth - 1)
        
        if max_loop_depth > 2:
            hotspots.append(f"Loops aninhados profundos (profundidade: {max_loop_depth})")
        
        # Identifica operações custosas
        expensive_operations = {
            'SEARCH ALL': 'Busca binária - verificar se índices estão otimizados',
            'SORT': 'Operação de ordenação - considerar otimizações',
            'MERGE': 'Operação de merge - avaliar necessidade',
            'EXEC SQL': 'Operações de banco - verificar performance de queries'
        }
        
        for operation, description in expensive_operations.items():
            count = program.raw_content.upper().count(operation)
            if count > 0:
                hotspots.append(f"{operation} ({count}x): {description}")
        
        # Identifica acesso sequencial a grandes estruturas
        large_arrays = [var for var in program.variables if var.occurs and var.occurs > 100]
        if large_arrays:
            hotspots.append(f"Arrays grandes ({len(large_arrays)}): Verificar padrões de acesso")
        
        return hotspots
    
    def generate_contextual_insights(self, program: CobolProgram, 
                                   domain_analysis: DomainIndicator,
                                   complexity_category: ComplexityCategory) -> List[ContextualInsight]:
        """
        Gera insights contextuais sobre o programa.
        
        Args:
            program: Programa COBOL
            domain_analysis: Análise de domínio
            complexity_category: Categoria de complexidade
            
        Returns:
            Lista de insights contextuais
        """
        insights = []
        
        # Insight sobre domínio de negócio
        if domain_analysis.confidence > 0.7:
            insights.append(ContextualInsight(
                category="Domínio de Negócio",
                description=f"Programa claramente identificado como {domain_analysis.domain.value}",
                confidence=domain_analysis.confidence,
                evidence=domain_analysis.evidence[:3],
                recommendations=[
                    f"Aplicar padrões específicos do domínio {domain_analysis.domain.value}",
                    "Validar regras de negócio com especialistas do domínio"
                ]
            ))
        
        # Insight sobre complexidade
        if complexity_category in [ComplexityCategory.COMPLEX, ComplexityCategory.VERY_COMPLEX]:
            insights.append(ContextualInsight(
                category="Complexidade",
                description=f"Programa com complexidade {complexity_category.value.lower()}",
                confidence=0.9,
                evidence=[f"Categoria: {complexity_category.value}"],
                recommendations=[
                    "Considerar refatoração em módulos menores",
                    "Implementar testes unitários abrangentes",
                    "Documentar lógica complexa detalhadamente"
                ]
            ))
        
        # Insight sobre modernização
        content_upper = program.raw_content.upper()
        legacy_patterns = ['GO TO', 'PERFORM THRU', 'EXEC CICS']
        legacy_count = sum(content_upper.count(pattern) for pattern in legacy_patterns)
        
        if legacy_count > 5:
            insights.append(ContextualInsight(
                category="Modernização",
                description="Programa contém padrões legados significativos",
                confidence=0.8,
                evidence=[f"{legacy_count} padrões legados identificados"],
                recommendations=[
                    "Priorizar para modernização",
                    "Avaliar migração para arquitetura moderna",
                    "Implementar testes antes da refatoração"
                ]
            ))
        
        # Insight sobre manutenibilidade
        lines_count = len(program.raw_content.split('\n'))
        variables_count = len(program.variables)
        
        if lines_count > 1000 or variables_count > 100:
            insights.append(ContextualInsight(
                category="Manutenibilidade",
                description="Programa de grande porte requer atenção especial",
                confidence=0.9,
                evidence=[f"{lines_count} linhas, {variables_count} variáveis"],
                recommendations=[
                    "Implementar documentação detalhada",
                    "Estabelecer padrões de codificação",
                    "Considerar divisão em módulos menores"
                ]
            ))
        
        return insights
    
    def get_context_summary(self, context: ProgramContext) -> Dict[str, Any]:
        """
        Gera resumo do contexto do programa.
        
        Args:
            context: Contexto do programa
            
        Returns:
            Resumo estruturado do contexto
        """
        return {
            'program_info': {
                'name': context.program.program_id,
                'author': context.program.author,
                'lines_of_code': len(context.program.raw_content.split('\n')),
                'variables_count': len(context.program.variables)
            },
            'business_context': {
                'domain': context.business_domain.value,
                'domain_confidence': context.domain_confidence,
                'complexity_category': context.complexity_category.value
            },
            'technical_analysis': {
                'critical_sections_count': len(context.critical_sections),
                'modernization_opportunities': len(context.modernization_candidates),
                'integration_complexity': context.integration_complexity,
                'security_concerns_count': len(context.security_concerns),
                'performance_hotspots_count': len(context.performance_hotspots)
            },
            'insights_summary': {
                'total_insights': len(context.insights),
                'high_confidence_insights': len([i for i in context.insights if i.confidence > 0.8]),
                'categories': list(set(i.category for i in context.insights))
            },
            'recommendations': {
                'priority_actions': self._get_priority_recommendations(context),
                'modernization_readiness': self._assess_modernization_readiness(context),
                'maintenance_priority': self._assess_maintenance_priority(context)
            }
        }
    
    def _get_priority_recommendations(self, context: ProgramContext) -> List[str]:
        """Gera recomendações prioritárias."""
        recommendations = []
        
        if context.complexity_category in [ComplexityCategory.COMPLEX, ComplexityCategory.VERY_COMPLEX]:
            recommendations.append("Refatoração para reduzir complexidade")
        
        if len(context.security_concerns) > 3:
            recommendations.append("Revisão de segurança urgente")
        
        if len(context.performance_hotspots) > 2:
            recommendations.append("Otimização de performance")
        
        if context.domain_confidence > 0.8:
            recommendations.append("Validação de regras de negócio com especialistas")
        
        return recommendations
    
    def _assess_modernization_readiness(self, context: ProgramContext) -> str:
        """Avalia prontidão para modernização."""
        score = 0
        
        if context.complexity_category == ComplexityCategory.SIMPLE:
            score += 3
        elif context.complexity_category == ComplexityCategory.MODERATE:
            score += 2
        
        if len(context.modernization_candidates) < 5:
            score += 2
        
        if context.integration_complexity in ["Baixa", "Mínima"]:
            score += 2
        
        if len(context.security_concerns) < 3:
            score += 1
        
        if score >= 7:
            return "Alta"
        elif score >= 4:
            return "Média"
        else:
            return "Baixa"
    
    def _assess_maintenance_priority(self, context: ProgramContext) -> str:
        """Avalia prioridade de manutenção."""
        priority_score = 0
        
        if len(context.critical_sections) > 5:
            priority_score += 3
        
        if len(context.security_concerns) > 2:
            priority_score += 3
        
        if context.complexity_category == ComplexityCategory.VERY_COMPLEX:
            priority_score += 2
        
        if len(context.performance_hotspots) > 3:
            priority_score += 2
        
        if priority_score >= 6:
            return "Alta"
        elif priority_score >= 3:
            return "Média"
        else:
            return "Baixa"

