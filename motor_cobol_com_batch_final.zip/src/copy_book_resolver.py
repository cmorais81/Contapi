"""
Resolver para arquivos COPY BOOK em programas COBOL.
"""

import os
import re
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path


@dataclass
class CopyBookReference:
    """Representa uma referência a um COPY BOOK no código."""
    name: str
    line_number: int
    replacing_clauses: Dict[str, str] = None
    library_name: Optional[str] = None
    
    def __post_init__(self):
        if self.replacing_clauses is None:
            self.replacing_clauses = {}


@dataclass
class CopyBookContent:
    """Representa o conteúdo de um COPY BOOK."""
    name: str
    file_path: str
    content: str
    variables: List = None
    nested_copies: List[str] = None
    
    def __post_init__(self):
        if self.variables is None:
            self.variables = []
        if self.nested_copies is None:
            self.nested_copies = []


class CopyBookResolver:
    """Resolve e processa arquivos COPY BOOK."""
    
    def __init__(self, copy_paths: List[str] = None):
        """
        Inicializa o resolver de COPY BOOKS.
        
        Args:
            copy_paths: Lista de diretórios onde procurar COPY BOOKS
        """
        self.copy_paths = copy_paths or []
        self.resolved_copies = {}
        self.copy_cache = {}
        
        # Padrões regex para identificar COPY statements
        self.patterns = {
            'copy_statement': re.compile(
                r'^\s*COPY\s+([A-Z0-9-]+)(?:\s+OF\s+([A-Z0-9-]+))?'
                r'(?:\s+REPLACING\s+(.+?))?\.', 
                re.IGNORECASE | re.MULTILINE
            ),
            'replacing_clause': re.compile(
                r'==([^=]+)==\s+BY\s+==([^=]+)==', 
                re.IGNORECASE
            )
        }
    
    def find_copy_references(self, content: str) -> List[CopyBookReference]:
        """
        Encontra todas as referências COPY no código.
        
        Args:
            content: Conteúdo do programa COBOL
            
        Returns:
            Lista de referências COPY encontradas
        """
        references = []
        lines = content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            # Ignora comentários
            if len(line) > 6 and line[6] == '*':
                continue
                
            match = self.patterns['copy_statement'].search(line)
            if match:
                copy_name = match.group(1)
                library_name = match.group(2) if match.group(2) else None
                replacing_text = match.group(3) if match.group(3) else ""
                
                # Processa cláusulas REPLACING
                replacing_clauses = {}
                if replacing_text:
                    replacing_matches = self.patterns['replacing_clause'].findall(replacing_text)
                    for old_text, new_text in replacing_matches:
                        replacing_clauses[old_text.strip()] = new_text.strip()
                
                reference = CopyBookReference(
                    name=copy_name,
                    line_number=line_num,
                    replacing_clauses=replacing_clauses,
                    library_name=library_name
                )
                references.append(reference)
        
        return references
    
    def locate_copy_book(self, copy_name: str, library_name: Optional[str] = None) -> Optional[str]:
        """
        Localiza um arquivo COPY BOOK nos diretórios configurados.
        
        Args:
            copy_name: Nome do COPY BOOK
            library_name: Nome da biblioteca (opcional)
            
        Returns:
            Caminho completo do arquivo ou None se não encontrado
        """
        # Possíveis extensões para COPY BOOKS
        extensions = ['', '.cpy', '.copy', '.inc', '.cbl', '.cob']
        
        # Possíveis variações do nome
        name_variations = [
            copy_name,
            copy_name.upper(),
            copy_name.lower()
        ]
        
        for copy_path in self.copy_paths:
            for name_var in name_variations:
                for ext in extensions:
                    full_name = f"{name_var}{ext}"
                    file_path = os.path.join(copy_path, full_name)
                    
                    if os.path.isfile(file_path):
                        return file_path
                    
                    # Se há biblioteca especificada, procura em subdiretório
                    if library_name:
                        lib_path = os.path.join(copy_path, library_name.lower(), full_name)
                        if os.path.isfile(lib_path):
                            return lib_path
        
        return None
    
    def load_copy_book(self, copy_name: str, library_name: Optional[str] = None) -> Optional[CopyBookContent]:
        """
        Carrega o conteúdo de um COPY BOOK.
        
        Args:
            copy_name: Nome do COPY BOOK
            library_name: Nome da biblioteca (opcional)
            
        Returns:
            Conteúdo do COPY BOOK ou None se não encontrado
        """
        # Verifica cache primeiro
        cache_key = f"{copy_name}:{library_name or ''}"
        if cache_key in self.copy_cache:
            return self.copy_cache[cache_key]
        
        file_path = self.locate_copy_book(copy_name, library_name)
        if not file_path:
            return None
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            copy_book = CopyBookContent(
                name=copy_name,
                file_path=file_path,
                content=content
            )
            
            # Procura COPY statements aninhados
            nested_references = self.find_copy_references(content)
            copy_book.nested_copies = [ref.name for ref in nested_references]
            
            # Adiciona ao cache
            self.copy_cache[cache_key] = copy_book
            
            return copy_book
            
        except Exception as e:
            print(f"Erro ao carregar COPY BOOK {copy_name}: {e}")
            return None
    
    def apply_replacing_clauses(self, content: str, replacing_clauses: Dict[str, str]) -> str:
        """
        Aplica cláusulas REPLACING ao conteúdo do COPY BOOK.
        
        Args:
            content: Conteúdo original
            replacing_clauses: Dicionário de substituições
            
        Returns:
            Conteúdo com substituições aplicadas
        """
        modified_content = content
        
        for old_text, new_text in replacing_clauses.items():
            # Remove delimitadores == se presentes
            old_text = old_text.strip('=').strip()
            new_text = new_text.strip('=').strip()
            
            # Aplica substituição (case-insensitive)
            pattern = re.compile(re.escape(old_text), re.IGNORECASE)
            modified_content = pattern.sub(new_text, modified_content)
        
        return modified_content
    
    def resolve_copy_books(self, content: str) -> Tuple[str, Dict[str, CopyBookContent]]:
        """
        Resolve todos os COPY BOOKS em um programa e retorna o código expandido.
        
        Args:
            content: Conteúdo do programa COBOL
            
        Returns:
            Tupla com (código expandido, dicionário de COPY BOOKS resolvidos)
        """
        expanded_content = content
        resolved_copies = {}
        
        # Processa COPY statements de forma recursiva
        max_iterations = 10  # Evita loops infinitos
        iteration = 0
        
        while iteration < max_iterations:
            references = self.find_copy_references(expanded_content)
            if not references:
                break
            
            lines = expanded_content.split('\n')
            
            # Processa referências de trás para frente para manter números de linha
            for reference in reversed(references):
                copy_book = self.load_copy_book(reference.name, reference.library_name)
                
                if copy_book:
                    # Aplica cláusulas REPLACING se existirem
                    copy_content = copy_book.content
                    if reference.replacing_clauses:
                        copy_content = self.apply_replacing_clauses(
                            copy_content, 
                            reference.replacing_clauses
                        )
                    
                    # Substitui a linha COPY pelo conteúdo expandido
                    copy_lines = copy_content.split('\n')
                    
                    # Adiciona comentário indicando início do COPY
                    copy_lines.insert(0, f"      * BEGIN COPY {reference.name}")
                    copy_lines.append(f"      * END COPY {reference.name}")
                    
                    # Substitui na lista de linhas
                    lines[reference.line_number - 1:reference.line_number] = copy_lines
                    
                    # Armazena COPY BOOK resolvido
                    resolved_copies[reference.name] = copy_book
                else:
                    # COPY BOOK não encontrado - adiciona comentário de erro
                    error_comment = f"      * ERROR: COPY {reference.name} NOT FOUND"
                    lines[reference.line_number - 1] = error_comment
            
            expanded_content = '\n'.join(lines)
            iteration += 1
        
        return expanded_content, resolved_copies
    
    def get_copy_book_dependencies(self, copy_name: str) -> List[str]:
        """
        Retorna lista de dependências de um COPY BOOK (COPY BOOKS aninhados).
        
        Args:
            copy_name: Nome do COPY BOOK
            
        Returns:
            Lista de nomes de COPY BOOKS dependentes
        """
        copy_book = self.load_copy_book(copy_name)
        if not copy_book:
            return []
        
        dependencies = []
        visited = set()
        
        def collect_dependencies(cb_name: str):
            if cb_name in visited:
                return
            visited.add(cb_name)
            
            cb = self.load_copy_book(cb_name)
            if cb:
                for nested_copy in cb.nested_copies:
                    dependencies.append(nested_copy)
                    collect_dependencies(nested_copy)
        
        collect_dependencies(copy_name)
        return dependencies
    
    def generate_dependency_graph(self, program_content: str) -> Dict[str, List[str]]:
        """
        Gera grafo de dependências de COPY BOOKS para um programa.
        
        Args:
            program_content: Conteúdo do programa COBOL
            
        Returns:
            Dicionário com dependências de cada COPY BOOK
        """
        references = self.find_copy_references(program_content)
        dependency_graph = {}
        
        for reference in references:
            dependencies = self.get_copy_book_dependencies(reference.name)
            dependency_graph[reference.name] = dependencies
        
        return dependency_graph

