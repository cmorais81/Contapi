"""
Classes para análise de FILE SECTION em programas COBOL.
"""

from dataclasses import dataclass
from typing import List, Optional, Dict
from enum import Enum

from cobol_parser import CobolVariable


class FileOrganization(Enum):
    """Tipos de organização de arquivo COBOL."""
    SEQUENTIAL = "SEQUENTIAL"
    INDEXED = "INDEXED"
    RELATIVE = "RELATIVE"
    LINE_SEQUENTIAL = "LINE SEQUENTIAL"


class AccessMode(Enum):
    """Modos de acesso a arquivo COBOL."""
    SEQUENTIAL = "SEQUENTIAL"
    RANDOM = "RANDOM"
    DYNAMIC = "DYNAMIC"


class RecordFormat(Enum):
    """Formatos de registro COBOL."""
    FIXED = "FIXED"
    VARIABLE = "VARIABLE"


@dataclass
class CobolFile:
    """Representa um arquivo COBOL definido na FILE SECTION."""
    name: str
    select_name: str  # Nome usado no SELECT
    assign_to: str  # Valor da cláusula ASSIGN TO
    organization: Optional[FileOrganization] = None
    access_mode: Optional[AccessMode] = None
    record_format: Optional[RecordFormat] = None
    record_key: Optional[str] = None  # Para arquivos INDEXED
    alternate_keys: List[str] = None  # Chaves alternativas
    record_structure: List[CobolVariable] = None  # Estrutura do registro
    block_size: Optional[int] = None
    record_size: Optional[int] = None
    file_status: Optional[str] = None  # Variável de status do arquivo
    line_number: int = 0
    
    def __post_init__(self):
        if self.alternate_keys is None:
            self.alternate_keys = []
        if self.record_structure is None:
            self.record_structure = []


@dataclass
class FileOperation:
    """Representa uma operação de arquivo no programa."""
    operation_type: str  # OPEN, CLOSE, READ, WRITE, REWRITE, DELETE
    file_name: str
    mode: Optional[str] = None  # INPUT, OUTPUT, I-O, EXTEND
    into_variable: Optional[str] = None  # Para READ INTO
    from_variable: Optional[str] = None  # Para WRITE FROM
    key_variable: Optional[str] = None  # Para acesso por chave
    line_number: int = 0
    paragraph: Optional[str] = None  # Parágrafo onde ocorre a operação


class FileAnalyzer:
    """Analisador de estruturas de arquivo COBOL."""
    
    def __init__(self):
        self.files = {}
        self.file_operations = []
    
    def parse_select_statement(self, line: str, line_number: int) -> Optional[CobolFile]:
        """
        Analisa uma declaração SELECT e extrai informações do arquivo.
        
        Args:
            line: Linha contendo SELECT
            line_number: Número da linha
            
        Returns:
            Objeto CobolFile ou None se não for válido
        """
        import re
        
        # Padrão para SELECT statement
        select_pattern = re.compile(
            r'SELECT\s+([A-Z0-9-]+)\s+ASSIGN\s+TO\s+[\'"]?([^\'"\s]+)[\'"]?',
            re.IGNORECASE
        )
        
        match = select_pattern.search(line)
        if not match:
            return None
        
        file_name = match.group(1)
        assign_to = match.group(2).strip('\'"')
        
        cobol_file = CobolFile(
            name=file_name,
            select_name=file_name,
            assign_to=assign_to,
            line_number=line_number
        )
        
        # Extrai organização se presente na linha
        if 'ORGANIZATION' in line.upper():
            if 'SEQUENTIAL' in line.upper():
                cobol_file.organization = FileOrganization.SEQUENTIAL
            elif 'INDEXED' in line.upper():
                cobol_file.organization = FileOrganization.INDEXED
            elif 'RELATIVE' in line.upper():
                cobol_file.organization = FileOrganization.RELATIVE
        
        # Extrai modo de acesso se presente
        if 'ACCESS' in line.upper():
            if 'SEQUENTIAL' in line.upper():
                cobol_file.access_mode = AccessMode.SEQUENTIAL
            elif 'RANDOM' in line.upper():
                cobol_file.access_mode = AccessMode.RANDOM
            elif 'DYNAMIC' in line.upper():
                cobol_file.access_mode = AccessMode.DYNAMIC
        
        # Extrai chave de registro se presente
        record_key_pattern = re.compile(r'RECORD\s+KEY\s+IS\s+([A-Z0-9-]+)', re.IGNORECASE)
        key_match = record_key_pattern.search(line)
        if key_match:
            cobol_file.record_key = key_match.group(1)
        
        return cobol_file
    
    def parse_fd_statement(self, lines: List[str], start_index: int) -> tuple:
        """
        Analisa uma declaração FD (File Description) e suas variáveis associadas.
        
        Args:
            lines: Lista de linhas do programa
            start_index: Índice da linha FD
            
        Returns:
            Tupla (nome_arquivo, estrutura_registro, próximo_índice)
        """
        import re
        
        fd_line = lines[start_index]
        
        # Extrai nome do arquivo da linha FD
        fd_pattern = re.compile(r'FD\s+([A-Z0-9-]+)', re.IGNORECASE)
        match = fd_pattern.search(fd_line)
        
        if not match:
            return None, [], start_index + 1
        
        file_name = match.group(1)
        record_structure = []
        
        # Processa linhas seguintes até encontrar próxima FD ou mudança de seção
        current_index = start_index + 1
        
        while current_index < len(lines):
            line = lines[current_index].strip()
            
            # Para se encontrar nova FD ou seção
            if (line.startswith('FD ') or 
                'WORKING-STORAGE' in line.upper() or 
                'LINKAGE' in line.upper() or
                'PROCEDURE DIVISION' in line.upper()):
                break
            
            # Analisa definições de variáveis (01 level)
            if re.match(r'^\s*01\s+', line):
                # Aqui você integraria com o parser de variáveis existente
                # Por simplicidade, vamos extrair apenas o nome
                var_pattern = re.compile(r'01\s+([A-Z0-9-]+)', re.IGNORECASE)
                var_match = var_pattern.search(line)
                if var_match:
                    var_name = var_match.group(1)
                    # Criar estrutura básica da variável
                    # (integração completa seria feita com o parser principal)
                    record_structure.append(var_name)
            
            current_index += 1
        
        return file_name, record_structure, current_index
    
    def find_file_operations(self, content: str) -> List[FileOperation]:
        """
        Encontra todas as operações de arquivo no código.
        
        Args:
            content: Conteúdo do programa COBOL
            
        Returns:
            Lista de operações de arquivo encontradas
        """
        import re
        
        operations = []
        lines = content.split('\n')
        
        # Padrões para diferentes operações
        patterns = {
            'open': re.compile(r'OPEN\s+(INPUT|OUTPUT|I-O|EXTEND)\s+([A-Z0-9-]+)', re.IGNORECASE),
            'close': re.compile(r'CLOSE\s+([A-Z0-9-]+)', re.IGNORECASE),
            'read': re.compile(r'READ\s+([A-Z0-9-]+)(?:\s+INTO\s+([A-Z0-9-]+))?', re.IGNORECASE),
            'write': re.compile(r'WRITE\s+([A-Z0-9-]+)(?:\s+FROM\s+([A-Z0-9-]+))?', re.IGNORECASE),
            'rewrite': re.compile(r'REWRITE\s+([A-Z0-9-]+)(?:\s+FROM\s+([A-Z0-9-]+))?', re.IGNORECASE),
            'delete': re.compile(r'DELETE\s+([A-Z0-9-]+)', re.IGNORECASE)
        }
        
        current_paragraph = None
        
        for line_num, line in enumerate(lines, 1):
            # Identifica parágrafo atual
            paragraph_pattern = re.compile(r'^\s*([A-Z0-9][A-Z0-9-]*)\s*\.', re.IGNORECASE)
            para_match = paragraph_pattern.match(line)
            if para_match:
                current_paragraph = para_match.group(1)
                continue
            
            # Procura operações de arquivo
            for op_type, pattern in patterns.items():
                match = pattern.search(line)
                if match:
                    if op_type == 'open':
                        operation = FileOperation(
                            operation_type='OPEN',
                            file_name=match.group(2),
                            mode=match.group(1),
                            line_number=line_num,
                            paragraph=current_paragraph
                        )
                    elif op_type in ['read', 'write', 'rewrite']:
                        operation = FileOperation(
                            operation_type=op_type.upper(),
                            file_name=match.group(1),
                            into_variable=match.group(2) if op_type == 'read' else None,
                            from_variable=match.group(2) if op_type in ['write', 'rewrite'] else None,
                            line_number=line_num,
                            paragraph=current_paragraph
                        )
                    else:  # close, delete
                        operation = FileOperation(
                            operation_type=op_type.upper(),
                            file_name=match.group(1),
                            line_number=line_num,
                            paragraph=current_paragraph
                        )
                    
                    operations.append(operation)
        
        return operations
    
    def analyze_file_usage_patterns(self, operations: List[FileOperation]) -> Dict[str, Dict]:
        """
        Analisa padrões de uso de arquivos.
        
        Args:
            operations: Lista de operações de arquivo
            
        Returns:
            Dicionário com análise de padrões por arquivo
        """
        file_patterns = {}
        
        for operation in operations:
            file_name = operation.file_name
            
            if file_name not in file_patterns:
                file_patterns[file_name] = {
                    'operations': [],
                    'access_pattern': 'unknown',
                    'usage_frequency': 0,
                    'paragraphs_used': set()
                }
            
            file_patterns[file_name]['operations'].append(operation.operation_type)
            file_patterns[file_name]['usage_frequency'] += 1
            if operation.paragraph:
                file_patterns[file_name]['paragraphs_used'].add(operation.paragraph)
        
        # Determina padrão de acesso baseado nas operações
        for file_name, pattern_info in file_patterns.items():
            ops = pattern_info['operations']
            
            if 'READ' in ops and 'WRITE' not in ops:
                pattern_info['access_pattern'] = 'read_only'
            elif 'WRITE' in ops and 'READ' not in ops:
                pattern_info['access_pattern'] = 'write_only'
            elif 'READ' in ops and 'WRITE' in ops:
                pattern_info['access_pattern'] = 'read_write'
            elif 'REWRITE' in ops or 'DELETE' in ops:
                pattern_info['access_pattern'] = 'update'
            
            # Converte set para list para serialização
            pattern_info['paragraphs_used'] = list(pattern_info['paragraphs_used'])
        
        return file_patterns

