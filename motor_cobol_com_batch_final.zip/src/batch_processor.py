"""
Processador de lotes para análise de múltiplos programas COBOL.
Suporta processamento de arquivos ZIP, diretórios e listas de arquivos.
"""

import os
import sys
import zipfile
import tempfile
import shutil
import json
import yaml
from typing import List, Dict, Any, Optional, Tuple
from pathlib import Path
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging

# Adiciona src ao path
sys.path.insert(0, os.path.dirname(__file__))

from cobol_parser import CobolParser
from plugin_system import PluginManager, PluginType
from enhanced_copilot_integration import EnhancedCopilotIntegration, DocumentationRequest
from specialized_prompts import AnalysisType


class BatchProcessor:
    """Processador de lotes para múltiplos programas COBOL."""
    
    def __init__(self, config_path: Optional[str] = None):
        self.parser = CobolParser()
        self.plugin_manager = None
        self.copilot_integration = None
        self.logger = logging.getLogger(__name__)
        
        # Inicializa componentes
        self._initialize_components(config_path)
        
        # Estatísticas de processamento
        self.stats = {
            'total_files': 0,
            'processed_files': 0,
            'failed_files': 0,
            'total_lines': 0,
            'processing_time': 0,
            'files_per_minute': 0
        }
    
    def _initialize_components(self, config_path: Optional[str]):
        """Inicializa componentes do sistema."""
        try:
            # Plugin manager
            plugins_dir = os.path.join(os.path.dirname(__file__), '..', 'plugins')
            self.plugin_manager = PluginManager(plugins_dir)
            
            # Copilot integration
            if not config_path:
                config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'default_config.yaml')
            
            if os.path.exists(config_path):
                self.copilot_integration = EnhancedCopilotIntegration(config_path)
            
        except Exception as e:
            self.logger.warning(f"Erro na inicialização de componentes: {e}")
    
    def process_zip_file(self, zip_path: str, output_dir: str, 
                        plugins: List[str] = None, 
                        enable_ai: bool = False,
                        parallel: bool = True,
                        max_workers: int = 4) -> Dict[str, Any]:
        """
        Processa um arquivo ZIP contendo programas COBOL.
        
        Args:
            zip_path: Caminho para o arquivo ZIP
            output_dir: Diretório de saída
            plugins: Lista de plugins para executar
            enable_ai: Se deve usar IA para documentação
            parallel: Se deve processar em paralelo
            max_workers: Número máximo de workers paralelos
            
        Returns:
            Dicionário com resultados do processamento
        """
        self.logger.info(f"Iniciando processamento do ZIP: {zip_path}")
        start_time = time.time()
        
        # Criar diretório temporário
        with tempfile.TemporaryDirectory() as temp_dir:
            # Extrair ZIP
            cobol_files = self._extract_zip(zip_path, temp_dir)
            
            if not cobol_files:
                raise ValueError("Nenhum arquivo COBOL encontrado no ZIP")
            
            self.stats['total_files'] = len(cobol_files)
            self.logger.info(f"Encontrados {len(cobol_files)} arquivos COBOL")
            
            # Processar arquivos
            if parallel and len(cobol_files) > 1:
                results = self._process_files_parallel(
                    cobol_files, output_dir, plugins, enable_ai, max_workers
                )
            else:
                results = self._process_files_sequential(
                    cobol_files, output_dir, plugins, enable_ai
                )
            
            # Calcular estatísticas
            self.stats['processing_time'] = time.time() - start_time
            self.stats['files_per_minute'] = (
                self.stats['processed_files'] / (self.stats['processing_time'] / 60)
                if self.stats['processing_time'] > 0 else 0
            )
            
            # Gerar relatório consolidado
            consolidated_report = self._generate_consolidated_report(results, output_dir)
            
            return {
                'results': results,
                'stats': self.stats,
                'consolidated_report': consolidated_report,
                'output_directory': output_dir
            }
    
    def process_directory(self, directory_path: str, output_dir: str,
                         plugins: List[str] = None,
                         enable_ai: bool = False,
                         recursive: bool = True,
                         parallel: bool = True,
                         max_workers: int = 4) -> Dict[str, Any]:
        """
        Processa um diretório contendo programas COBOL.
        
        Args:
            directory_path: Caminho para o diretório
            output_dir: Diretório de saída
            plugins: Lista de plugins para executar
            enable_ai: Se deve usar IA para documentação
            recursive: Se deve buscar recursivamente
            parallel: Se deve processar em paralelo
            max_workers: Número máximo de workers paralelos
            
        Returns:
            Dicionário com resultados do processamento
        """
        self.logger.info(f"Iniciando processamento do diretório: {directory_path}")
        start_time = time.time()
        
        # Encontrar arquivos COBOL
        cobol_files = self._find_cobol_files(directory_path, recursive)
        
        if not cobol_files:
            raise ValueError("Nenhum arquivo COBOL encontrado no diretório")
        
        self.stats['total_files'] = len(cobol_files)
        self.logger.info(f"Encontrados {len(cobol_files)} arquivos COBOL")
        
        # Processar arquivos
        if parallel and len(cobol_files) > 1:
            results = self._process_files_parallel(
                cobol_files, output_dir, plugins, enable_ai, max_workers
            )
        else:
            results = self._process_files_sequential(
                cobol_files, output_dir, plugins, enable_ai
            )
        
        # Calcular estatísticas
        self.stats['processing_time'] = time.time() - start_time
        self.stats['files_per_minute'] = (
            self.stats['processed_files'] / (self.stats['processing_time'] / 60)
            if self.stats['processing_time'] > 0 else 0
        )
        
        # Gerar relatório consolidado
        consolidated_report = self._generate_consolidated_report(results, output_dir)
        
        return {
            'results': results,
            'stats': self.stats,
            'consolidated_report': consolidated_report,
            'output_directory': output_dir
        }
    
    def _extract_zip(self, zip_path: str, extract_dir: str) -> List[str]:
        """Extrai ZIP e retorna lista de arquivos COBOL."""
        cobol_files = []
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
                
                # Encontrar arquivos COBOL extraídos
                cobol_files = self._find_cobol_files(extract_dir, recursive=True)
                
        except zipfile.BadZipFile:
            raise ValueError(f"Arquivo ZIP inválido: {zip_path}")
        except Exception as e:
            raise RuntimeError(f"Erro ao extrair ZIP: {e}")
        
        return cobol_files
    
    def _find_cobol_files(self, directory: str, recursive: bool = True) -> List[str]:
        """Encontra arquivos COBOL em um diretório."""
        cobol_extensions = {'.cbl', '.cob', '.cobol', '.txt'}
        cobol_files = []
        
        if recursive:
            for root, dirs, files in os.walk(directory):
                for file in files:
                    if any(file.lower().endswith(ext) for ext in cobol_extensions):
                        cobol_files.append(os.path.join(root, file))
        else:
            for file in os.listdir(directory):
                file_path = os.path.join(directory, file)
                if os.path.isfile(file_path) and any(file.lower().endswith(ext) for ext in cobol_extensions):
                    cobol_files.append(file_path)
        
        return sorted(cobol_files)
    
    def _process_files_parallel(self, files: List[str], output_dir: str,
                               plugins: List[str], enable_ai: bool,
                               max_workers: int) -> Dict[str, Any]:
        """Processa arquivos em paralelo."""
        results = {}
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submeter tarefas
            future_to_file = {
                executor.submit(self._process_single_file, file_path, output_dir, plugins, enable_ai): file_path
                for file_path in files
            }
            
            # Coletar resultados
            for future in as_completed(future_to_file):
                file_path = future_to_file[future]
                try:
                    result = future.result()
                    results[file_path] = result
                    self.stats['processed_files'] += 1
                    self.logger.info(f"✓ Processado: {os.path.basename(file_path)}")
                except Exception as e:
                    self.stats['failed_files'] += 1
                    results[file_path] = {'error': str(e)}
                    self.logger.error(f"✗ Erro em {os.path.basename(file_path)}: {e}")
        
        return results
    
    def _process_files_sequential(self, files: List[str], output_dir: str,
                                 plugins: List[str], enable_ai: bool) -> Dict[str, Any]:
        """Processa arquivos sequencialmente."""
        results = {}
        
        for file_path in files:
            try:
                result = self._process_single_file(file_path, output_dir, plugins, enable_ai)
                results[file_path] = result
                self.stats['processed_files'] += 1
                self.logger.info(f"✓ Processado: {os.path.basename(file_path)}")
            except Exception as e:
                self.stats['failed_files'] += 1
                results[file_path] = {'error': str(e)}
                self.logger.error(f"✗ Erro em {os.path.basename(file_path)}: {e}")
        
        return results
    
    def _process_single_file(self, file_path: str, output_dir: str,
                           plugins: List[str], enable_ai: bool) -> Dict[str, Any]:
        """Processa um único arquivo COBOL."""
        start_time = time.time()
        
        # Parse do programa
        program = self.parser.parse_file(file_path)
        
        # Contar linhas
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            lines = len(f.readlines())
            self.stats['total_lines'] += lines
        
        result = {
            'file_path': file_path,
            'program_id': program.program_id,
            'lines_of_code': lines,
            'processing_time': 0,
            'basic_analysis': {},
            'plugin_results': {},
            'ai_documentation': None
        }
        
        # Análise básica
        result['basic_analysis'] = {
            'program_info': {
                'program_id': program.program_id,
                'author': program.author,
                'date_written': program.date_written,
                'variables_count': len(program.variables),
                'sections_count': len(program.sections),
                'paragraphs_count': len(program.paragraphs)
            }
        }
        
        # Executar plugins
        if plugins and self.plugin_manager:
            for plugin_name in plugins:
                try:
                    if self.plugin_manager.load_plugin(plugin_name):
                        plugin_results = self.plugin_manager.execute_plugins(
                            PluginType.ANALYZER, program
                        )
                        for plugin_result in plugin_results:
                            if plugin_result.plugin_name == plugin_name and plugin_result.success:
                                result['plugin_results'][plugin_name] = plugin_result.data
                except Exception as e:
                    self.logger.warning(f"Erro no plugin {plugin_name}: {e}")
        
        # Documentação com IA
        if enable_ai and self.copilot_integration:
            try:
                request = DocumentationRequest(
                    program=program,
                    analysis_types=[AnalysisType.BUSINESS_LOGIC, AnalysisType.DATA_STRUCTURE],
                    target_audience="technical"
                )
                ai_docs = self.copilot_integration.generate_comprehensive_documentation(request)
                result['ai_documentation'] = ai_docs
            except Exception as e:
                self.logger.warning(f"Erro na documentação IA: {e}")
        
        result['processing_time'] = time.time() - start_time
        
        # Salvar resultado individual
        self._save_individual_result(result, output_dir)
        
        return result
    
    def _save_individual_result(self, result: Dict[str, Any], output_dir: str):
        """Salva resultado individual de um arquivo."""
        os.makedirs(output_dir, exist_ok=True)
        
        file_name = os.path.basename(result['file_path'])
        base_name = os.path.splitext(file_name)[0]
        
        # Salvar em JSON
        json_path = os.path.join(output_dir, f"{base_name}_analysis.json")
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False, default=str)
        
        # Salvar em Markdown se houver documentação IA
        if result.get('ai_documentation'):
            md_path = os.path.join(output_dir, f"{base_name}_documentation.md")
            with open(md_path, 'w', encoding='utf-8') as f:
                for doc_type, content in result['ai_documentation'].items():
                    f.write(f"# {doc_type.replace('_', ' ').title()}\n\n")
                    f.write(content)
                    f.write("\n\n---\n\n")
    
    def _generate_consolidated_report(self, results: Dict[str, Any], output_dir: str) -> str:
        """Gera relatório consolidado de todos os arquivos processados."""
        report_path = os.path.join(output_dir, "consolidated_report.md")
        
        # Estatísticas consolidadas
        total_files = len(results)
        successful_files = sum(1 for r in results.values() if 'error' not in r)
        failed_files = total_files - successful_files
        total_lines = sum(r.get('lines_of_code', 0) for r in results.values() if 'error' not in r)
        
        # Análise de plugins consolidada
        plugin_stats = {}
        security_scores = []
        performance_scores = []
        
        for result in results.values():
            if 'error' in result:
                continue
                
            for plugin_name, plugin_data in result.get('plugin_results', {}).items():
                if plugin_name not in plugin_stats:
                    plugin_stats[plugin_name] = {'count': 0, 'issues': 0}
                
                plugin_stats[plugin_name]['count'] += 1
                
                if plugin_name == 'security_analyzer':
                    if 'security_score' in plugin_data:
                        security_scores.append(plugin_data['security_score'])
                    if 'issues' in plugin_data:
                        plugin_stats[plugin_name]['issues'] += len(plugin_data['issues'])
                
                elif plugin_name == 'performance_analyzer':
                    if 'performance_score' in plugin_data:
                        performance_scores.append(plugin_data['performance_score'])
                    if 'issues' in plugin_data:
                        plugin_stats[plugin_name]['issues'] += len(plugin_data['issues'])
        
        # Gerar relatório em Markdown
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Consolidado - Análise de Portfolio COBOL\n\n")
            
            # Estatísticas gerais
            f.write("## 📊 Estatísticas Gerais\n\n")
            f.write(f"- **Total de arquivos**: {total_files}\n")
            f.write(f"- **Processados com sucesso**: {successful_files}\n")
            f.write(f"- **Falhas**: {failed_files}\n")
            f.write(f"- **Total de linhas de código**: {total_lines:,}\n")
            f.write(f"- **Tempo de processamento**: {self.stats['processing_time']:.2f}s\n")
            f.write(f"- **Arquivos por minuto**: {self.stats['files_per_minute']:.1f}\n\n")
            
            # Análise de segurança
            if security_scores:
                avg_security = sum(security_scores) / len(security_scores)
                f.write("## 🔒 Análise de Segurança\n\n")
                f.write(f"- **Score médio de segurança**: {avg_security:.1f}/100\n")
                f.write(f"- **Melhor score**: {max(security_scores)}/100\n")
                f.write(f"- **Pior score**: {min(security_scores)}/100\n")
                f.write(f"- **Total de issues de segurança**: {plugin_stats.get('security_analyzer', {}).get('issues', 0)}\n\n")
            
            # Análise de performance
            if performance_scores:
                avg_performance = sum(performance_scores) / len(performance_scores)
                f.write("## ⚡ Análise de Performance\n\n")
                f.write(f"- **Score médio de performance**: {avg_performance:.1f}/100\n")
                f.write(f"- **Melhor score**: {max(performance_scores)}/100\n")
                f.write(f"- **Pior score**: {min(performance_scores)}/100\n")
                f.write(f"- **Total de issues de performance**: {plugin_stats.get('performance_analyzer', {}).get('issues', 0)}\n\n")
            
            # Lista de arquivos processados
            f.write("## 📁 Arquivos Processados\n\n")
            f.write("| Arquivo | Status | Linhas | Program ID |\n")
            f.write("|---------|--------|--------|------------|\n")
            
            for file_path, result in results.items():
                file_name = os.path.basename(file_path)
                if 'error' in result:
                    f.write(f"| {file_name} | ❌ Erro | - | - |\n")
                else:
                    status = "✅ Sucesso"
                    lines = result.get('lines_of_code', 0)
                    program_id = result.get('program_id', 'N/A')
                    f.write(f"| {file_name} | {status} | {lines} | {program_id} |\n")
            
            f.write("\n")
            
            # Recomendações
            f.write("## 💡 Recomendações\n\n")
            
            if security_scores and avg_security < 80:
                f.write("- **Segurança**: Portfolio apresenta vulnerabilidades. Revisar issues de segurança identificadas.\n")
            
            if performance_scores and avg_performance < 80:
                f.write("- **Performance**: Oportunidades de otimização identificadas. Revisar complexidade e gargalos.\n")
            
            if failed_files > 0:
                f.write(f"- **Qualidade**: {failed_files} arquivos falharam no processamento. Verificar sintaxe COBOL.\n")
            
            f.write("\n---\n\n")
            f.write(f"*Relatório gerado em {time.strftime('%Y-%m-%d %H:%M:%S')}*\n")
        
        return report_path
    
    def get_processing_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas de processamento."""
        return self.stats.copy()
    
    def reset_stats(self):
        """Reseta estatísticas de processamento."""
        self.stats = {
            'total_files': 0,
            'processed_files': 0,
            'failed_files': 0,
            'total_lines': 0,
            'processing_time': 0,
            'files_per_minute': 0
        }

