"""
Analisador de fluxo de dados para programas COBOL.
"""

import re
from typing import Dict, List, Set, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

from cobol_parser import CobolProgram, CobolVariable, CobolSection, CobolParagraph


class DataOperation(Enum):
    """Tipos de operações com dados."""
    READ = "READ"           # Leitura de dados
    WRITE = "WRITE"         # Escrita de dados
    MODIFY = "MODIFY"       # Modificação de dados
    COMPUTE = "COMPUTE"     # Cálculo/computação
    MOVE = "MOVE"           # Movimentação de dados
    ACCEPT = "ACCEPT"       # Entrada de dados
    DISPLAY = "DISPLAY"     # Saída de dados
    COMPARE = "COMPARE"     # Comparação de dados


@dataclass
class DataUsage:
    """Representa o uso de uma variável no programa."""
    variable_name: str
    operation: DataOperation
    line_number: int
    paragraph: Optional[str] = None
    section: Optional[str] = None
    context: Optional[str] = None  # Contexto da operação (ex: lado direito de MOVE)
    target_variable: Optional[str] = None  # Para operações que envolvem duas variáveis


@dataclass
class DataFlow:
    """Representa o fluxo de dados entre variáveis."""
    source_variable: str
    target_variable: str
    operation_type: str
    line_number: int
    paragraph: Optional[str] = None
    transformation: Optional[str] = None  # Tipo de transformação aplicada


class DataFlowAnalyzer:
    """Analisador de fluxo de dados em programas COBOL."""
    
    def __init__(self, program: CobolProgram):
        self.program = program
        self.data_usages: List[DataUsage] = []
        self.data_flows: List[DataFlow] = []
        self.variable_definitions: Dict[str, List[int]] = {}
        self.variable_usages: Dict[str, List[int]] = {}
        
        # Inicializa conjuntos de categorização
        self.input_variables: Set[str] = set()
        self.output_variables: Set[str] = set()
        self.intermediate_variables: Set[str] = set()
        self.unused_variables: Set[str] = set()
        
        # Padrões regex para identificar operações com dados
        self.patterns = {
            'move': re.compile(r'MOVE\s+(.+?)\s+TO\s+(.+)', re.IGNORECASE),
            'compute': re.compile(r'COMPUTE\s+([A-Z0-9-]+)\s*=\s*(.+)', re.IGNORECASE),
            'add': re.compile(r'ADD\s+([A-Z0-9-\(\)\s,]+)\s+TO\s+([A-Z0-9-]+)', re.IGNORECASE),
            'subtract': re.compile(r'SUBTRACT\s+([A-Z0-9-\(\)\s,]+)\s+FROM\s+([A-Z0-9-]+)', re.IGNORECASE),
            'multiply': re.compile(r'MULTIPLY\s+([A-Z0-9-]+)\s+BY\s+([A-Z0-9-]+)', re.IGNORECASE),
            'divide': re.compile(r'DIVIDE\s+([A-Z0-9-]+)\s+INTO\s+([A-Z0-9-]+)', re.IGNORECASE),
            'accept': re.compile(r'ACCEPT\s+([A-Z0-9-]+)', re.IGNORECASE),
            'display': re.compile(r'DISPLAY\s+([A-Z0-9-\'\"\s,]+)', re.IGNORECASE),
            'if_condition': re.compile(r'IF\s+([A-Z0-9-\(\)\s=<>]+)', re.IGNORECASE),
            'read_into': re.compile(r'READ\s+([A-Z0-9-]+)(?:\s+INTO\s+([A-Z0-9-]+))?', re.IGNORECASE),
            'write_from': re.compile(r'WRITE\s+([A-Z0-9-]+)(?:\s+FROM\s+([A-Z0-9-]+))?', re.IGNORECASE),
            'variable_reference': re.compile(r'\b([A-Z0-9][A-Z0-9-]*)\b', re.IGNORECASE)
        }
    
    def analyze_data_flow(self) -> Dict[str, List[str]]:
        """
        Analisa o fluxo de dados no programa.
        
        Returns:
            Dicionário com o grafo de fluxo de dados
        """
        self._extract_data_usages()
        self._build_data_flows()
        self._categorize_variables()
        
        return self._build_flow_graph()
    
    def _extract_data_usages(self):
        """Extrai todas as utilizações de dados do programa."""
        current_section = None
        current_paragraph = None
        
        lines = self.program.raw_content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            # Ignora comentários
            if len(line) > 6 and line[6] == '*':
                continue
            
            # Identifica seção atual
            section_match = re.match(r'^\s*([A-Z0-9][A-Z0-9-]*(?:\s+[A-Z0-9][A-Z0-9-]*)*)\s+SECTION\s*\.', line, re.IGNORECASE)
            if section_match:
                current_section = section_match.group(1)
                continue
            
            # Identifica parágrafo atual
            paragraph_match = re.match(r'^\s*([A-Z0-9][A-Z0-9-]*)\s*\.', line, re.IGNORECASE)
            if paragraph_match and not any(keyword in line.upper() for keyword in ['DIVISION', 'SECTION']):
                current_paragraph = paragraph_match.group(1)
                continue
            
            # Analisa operações de dados
            self._analyze_line_for_data_operations(line, line_num, current_section, current_paragraph)
    
    def _analyze_line_for_data_operations(self, line: str, line_num: int, section: str, paragraph: str):
        """Analisa uma linha em busca de operações com dados."""
        line_upper = line.upper().strip()
        
        # MOVE statement - trata casos de quebra de linha
        move_match = self.patterns['move'].search(line)
        if move_match:
            source = move_match.group(1).strip()
            target = move_match.group(2).strip()
            
            # Processa múltiplos targets separados por vírgula
            targets = [t.strip() for t in target.split(',') if t.strip()]
            
            for target in targets:
                self._add_data_usage(source, DataOperation.READ, line_num, paragraph, section, "source")
                self._add_data_usage(target, DataOperation.MOVE, line_num, paragraph, section, "target")
                self._add_data_flow(source, target, "MOVE", line_num, paragraph)
        
        # Verifica se é uma linha MOVE incompleta (quebrada)
        elif 'MOVE' in line_upper and 'TO' not in line_upper:
            # Procura a próxima linha para completar o MOVE
            # (implementação simplificada - em produção seria mais robusta)
            pass
        
        # COMPUTE statement
        compute_match = self.patterns['compute'].search(line)
        if compute_match:
            target = compute_match.group(1).strip()
            expression = compute_match.group(2).strip()
            
            self._add_data_usage(target, DataOperation.WRITE, line_num, paragraph, section, "computed")
            
            # Extrai variáveis da expressão
            variables_in_expr = self._extract_variables_from_expression(expression)
            for var in variables_in_expr:
                self._add_data_usage(var, DataOperation.READ, line_num, paragraph, section, "computation")
                self._add_data_flow(var, target, "COMPUTE", line_num, paragraph, "arithmetic")
        
        # ADD statement
        add_match = self.patterns['add'].search(line)
        if add_match:
            sources = [s.strip() for s in add_match.group(1).split(',')]
            target = add_match.group(2).strip()
            
            for source in sources:
                self._add_data_usage(source, DataOperation.READ, line_num, paragraph, section, "addend")
                self._add_data_flow(source, target, "ADD", line_num, paragraph, "addition")
            
            self._add_data_usage(target, DataOperation.MODIFY, line_num, paragraph, section, "sum")
        
        # SUBTRACT statement
        subtract_match = self.patterns['subtract'].search(line)
        if subtract_match:
            sources = [s.strip() for s in subtract_match.group(1).split(',')]
            target = subtract_match.group(2).strip()
            
            for source in sources:
                self._add_data_usage(source, DataOperation.READ, line_num, paragraph, section, "subtrahend")
                self._add_data_flow(source, target, "SUBTRACT", line_num, paragraph, "subtraction")
            
            self._add_data_usage(target, DataOperation.MODIFY, line_num, paragraph, section, "difference")
        
        # ACCEPT statement
        accept_match = self.patterns['accept'].search(line)
        if accept_match:
            variable = accept_match.group(1).strip()
            self._add_data_usage(variable, DataOperation.ACCEPT, line_num, paragraph, section, "input")
        
        # DISPLAY statement
        display_match = self.patterns['display'].search(line)
        if display_match:
            display_items = display_match.group(1)
            variables = self._extract_variables_from_display(display_items)
            for var in variables:
                self._add_data_usage(var, DataOperation.DISPLAY, line_num, paragraph, section, "output")
        
        # IF condition
        if_match = self.patterns['if_condition'].search(line)
        if if_match:
            condition = if_match.group(1)
            variables = self._extract_variables_from_condition(condition)
            for var in variables:
                self._add_data_usage(var, DataOperation.COMPARE, line_num, paragraph, section, "condition")
        
        # READ INTO
        read_match = self.patterns['read_into'].search(line)
        if read_match:
            file_name = read_match.group(1).strip()
            into_var = read_match.group(2)
            
            self._add_data_usage(file_name, DataOperation.READ, line_num, paragraph, section, "file_read")
            if into_var:
                into_var = into_var.strip()
                self._add_data_usage(into_var, DataOperation.WRITE, line_num, paragraph, section, "file_data")
                self._add_data_flow(file_name, into_var, "READ", line_num, paragraph, "file_to_variable")
        
        # WRITE FROM
        write_match = self.patterns['write_from'].search(line)
        if write_match:
            record_name = write_match.group(1).strip()
            from_var = write_match.group(2)
            
            self._add_data_usage(record_name, DataOperation.WRITE, line_num, paragraph, section, "file_write")
            if from_var:
                from_var = from_var.strip()
                self._add_data_usage(from_var, DataOperation.READ, line_num, paragraph, section, "source_data")
                self._add_data_flow(from_var, record_name, "WRITE", line_num, paragraph, "variable_to_file")
    
    def _add_data_usage(self, variable: str, operation: DataOperation, line_num: int, 
                       paragraph: str, section: str, context: str):
        """Adiciona uma utilização de dados à lista."""
        # Filtra literais e palavras reservadas
        if self._is_literal_or_reserved(variable):
            return
        
        usage = DataUsage(
            variable_name=variable,
            operation=operation,
            line_number=line_num,
            paragraph=paragraph,
            section=section,
            context=context
        )
        self.data_usages.append(usage)
        
        # Atualiza índices
        if variable not in self.variable_usages:
            self.variable_usages[variable] = []
        self.variable_usages[variable].append(line_num)
        
        if operation in [DataOperation.WRITE, DataOperation.MODIFY, DataOperation.ACCEPT]:
            if variable not in self.variable_definitions:
                self.variable_definitions[variable] = []
            self.variable_definitions[variable].append(line_num)
    
    def _add_data_flow(self, source: str, target: str, operation: str, line_num: int, 
                      paragraph: str, transformation: str = None):
        """Adiciona um fluxo de dados à lista."""
        if self._is_literal_or_reserved(source) or self._is_literal_or_reserved(target):
            return
        
        flow = DataFlow(
            source_variable=source,
            target_variable=target,
            operation_type=operation,
            line_number=line_num,
            paragraph=paragraph,
            transformation=transformation
        )
        self.data_flows.append(flow)
    
    def _is_literal_or_reserved(self, text: str) -> bool:
        """Verifica se o texto é um literal ou palavra reservada."""
        if not text or len(text.strip()) == 0:
            return True
        
        text = text.strip()
        
        # Literais numéricos
        if re.match(r'^-?\d+(\.\d+)?$', text):
            return True
        
        # Literais de string
        if (text.startswith('"') and text.endswith('"')) or (text.startswith("'") and text.endswith("'")):
            return True
        
        # Palavras reservadas comuns
        reserved_words = {
            'ZERO', 'ZEROS', 'ZEROES', 'SPACE', 'SPACES', 'HIGH-VALUE', 'HIGH-VALUES',
            'LOW-VALUE', 'LOW-VALUES', 'NULL', 'NULLS', 'TRUE', 'FALSE', 'ALL'
        }
        
        return text.upper() in reserved_words
    
    def _extract_variables_from_expression(self, expression: str) -> List[str]:
        """Extrai variáveis de uma expressão aritmética."""
        variables = []
        # Remove operadores e parênteses
        cleaned = re.sub(r'[+\-*/()=<>]', ' ', expression)
        tokens = cleaned.split()
        
        for token in tokens:
            token = token.strip()
            if token and not self._is_literal_or_reserved(token):
                variables.append(token)
        
        return variables
    
    def _extract_variables_from_display(self, display_items: str) -> List[str]:
        """Extrai variáveis de um statement DISPLAY."""
        variables = []
        # Remove literais entre aspas
        cleaned = re.sub(r'[\'"][^\'\"]*[\'"]', '', display_items)
        tokens = cleaned.split()
        
        for token in tokens:
            token = token.strip(',')
            if token and not self._is_literal_or_reserved(token):
                variables.append(token)
        
        return variables
    
    def _extract_variables_from_condition(self, condition: str) -> List[str]:
        """Extrai variáveis de uma condição IF."""
        variables = []
        # Remove operadores de comparação
        cleaned = re.sub(r'(=|<|>|<=|>=|<>|NOT|AND|OR)', ' ', condition)
        tokens = cleaned.split()
        
        for token in tokens:
            token = token.strip('()')
            if token and not self._is_literal_or_reserved(token):
                variables.append(token)
        
        return variables
    
    def _build_data_flows(self):
        """Constrói os fluxos de dados baseado nas utilizações."""
        # Os fluxos já são construídos durante a análise das linhas
        pass
    
    def _categorize_variables(self):
        """Categoriza variáveis por tipo de uso."""
        self.input_variables = set()
        self.output_variables = set()
        self.intermediate_variables = set()
        self.unused_variables = set()
        
        # Variáveis definidas no programa
        defined_vars = {var.name for var in self.program.variables}
        
        for usage in self.data_usages:
            var_name = usage.variable_name
            
            if usage.operation == DataOperation.ACCEPT:
                self.input_variables.add(var_name)
            elif usage.operation == DataOperation.DISPLAY:
                self.output_variables.add(var_name)
            elif usage.operation in [DataOperation.WRITE, DataOperation.MODIFY, DataOperation.COMPUTE]:
                self.intermediate_variables.add(var_name)
        
        # Identifica variáveis não utilizadas
        used_vars = {usage.variable_name for usage in self.data_usages}
        self.unused_variables = defined_vars - used_vars
    
    def _build_flow_graph(self) -> Dict[str, List[str]]:
        """Constrói o grafo de fluxo de dados."""
        flow_graph = {}
        
        for flow in self.data_flows:
            source = flow.source_variable
            target = flow.target_variable
            
            if source not in flow_graph:
                flow_graph[source] = []
            
            if target not in flow_graph[source]:
                flow_graph[source].append(target)
        
        return flow_graph
    
    def generate_data_lineage(self, variable: str) -> Dict[str, List[str]]:
        """
        Gera a linhagem de dados para uma variável específica.
        
        Args:
            variable: Nome da variável
            
        Returns:
            Dicionário com origem e destino dos dados
        """
        lineage = {
            'sources': [],
            'targets': [],
            'transformations': []
        }
        
        # Encontra fontes (variáveis que alimentam esta variável)
        for flow in self.data_flows:
            if flow.target_variable == variable:
                lineage['sources'].append({
                    'variable': flow.source_variable,
                    'operation': flow.operation_type,
                    'line': flow.line_number,
                    'transformation': flow.transformation
                })
        
        # Encontra destinos (variáveis alimentadas por esta variável)
        for flow in self.data_flows:
            if flow.source_variable == variable:
                lineage['targets'].append({
                    'variable': flow.target_variable,
                    'operation': flow.operation_type,
                    'line': flow.line_number,
                    'transformation': flow.transformation
                })
        
        return lineage
    
    def get_critical_variables(self) -> Dict[str, int]:
        """
        Identifica variáveis críticas baseado no número de dependências.
        
        Returns:
            Dicionário com variáveis e suas pontuações de criticidade
        """
        criticality_scores = {}
        
        for usage in self.data_usages:
            var_name = usage.variable_name
            if var_name not in criticality_scores:
                criticality_scores[var_name] = 0
            
            # Pontuação baseada no tipo de operação
            if usage.operation == DataOperation.ACCEPT:
                criticality_scores[var_name] += 3  # Entrada de dados é crítica
            elif usage.operation == DataOperation.DISPLAY:
                criticality_scores[var_name] += 2  # Saída é importante
            elif usage.operation in [DataOperation.COMPUTE, DataOperation.MODIFY]:
                criticality_scores[var_name] += 2  # Transformações são importantes
            else:
                criticality_scores[var_name] += 1  # Uso geral
        
        # Ordena por criticidade
        return dict(sorted(criticality_scores.items(), key=lambda x: x[1], reverse=True))
    
    def get_data_flow_summary(self) -> Dict[str, any]:
        """
        Gera um resumo da análise de fluxo de dados.
        
        Returns:
            Dicionário com resumo da análise
        """
        # Executa análise se ainda não foi executada
        if not self.data_usages:
            self.analyze_data_flow()
            
        return {
            'total_variables_used': len(self.variable_usages),
            'total_data_operations': len(self.data_usages),
            'total_data_flows': len(self.data_flows),
            'input_variables': list(self.input_variables),
            'output_variables': list(self.output_variables),
            'intermediate_variables': list(self.intermediate_variables),
            'unused_variables': list(self.unused_variables),
            'critical_variables': list(self.get_critical_variables().keys())[:10],
            'operations_by_type': self._count_operations_by_type(),
            'most_used_variables': self._get_most_used_variables(10)
        }
    
    def _count_operations_by_type(self) -> Dict[str, int]:
        """Conta operações por tipo."""
        counts = {}
        for usage in self.data_usages:
            op_type = usage.operation.value
            counts[op_type] = counts.get(op_type, 0) + 1
        return counts
    
    def _get_most_used_variables(self, limit: int) -> List[Dict[str, any]]:
        """Retorna as variáveis mais utilizadas."""
        usage_counts = {}
        for var_name, line_numbers in self.variable_usages.items():
            usage_counts[var_name] = len(line_numbers)
        
        sorted_vars = sorted(usage_counts.items(), key=lambda x: x[1], reverse=True)
        
        return [
            {'variable': var, 'usage_count': count}
            for var, count in sorted_vars[:limit]
        ]

