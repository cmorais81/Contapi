"""
Prompts especializados para diferentes tipos de análise COBOL.
"""

from typing import Dict, List, Any
from dataclasses import dataclass
from enum import Enum

from cobol_parser import CobolProgram, CobolVariable
from data_flow_analyzer import DataFlowAnalyzer
from complexity_analyzer import ComplexityAnalyzer
from pattern_detector import PatternDetector


class AnalysisType(Enum):
    """Tipos de análise especializada."""
    BUSINESS_LOGIC = "business_logic"
    DATA_STRUCTURE = "data_structure"
    PERFORMANCE = "performance"
    MIGRATION = "migration"
    SECURITY = "security"
    MAINTENANCE = "maintenance"
    INTEGRATION = "integration"


@dataclass
class PromptContext:
    """Contexto para geração de prompts especializados."""
    analysis_type: AnalysisType
    program: CobolProgram
    complexity_metrics: Dict[str, Any] = None
    data_flow_summary: Dict[str, Any] = None
    pattern_report: Dict[str, Any] = None
    domain_indicators: List[str] = None
    critical_sections: List[str] = None
    
    def __post_init__(self):
        if self.domain_indicators is None:
            self.domain_indicators = []
        if self.critical_sections is None:
            self.critical_sections = []


class SpecializedPrompts:
    """Gerador de prompts especializados para análise COBOL."""
    
    def __init__(self):
        self.base_instructions = {
            'tone': "Seja técnico mas acessível, explicando conceitos COBOL quando necessário.",
            'structure': "Organize a resposta em seções claras com títulos descritivos.",
            'language': "Responda em português brasileiro.",
            'format': "Use markdown para formatação, incluindo listas, tabelas e código quando apropriado."
        }
    
    def get_specialized_prompt(self, context: PromptContext) -> str:
        """
        Gera um prompt especializado baseado no tipo de análise.
        
        Args:
            context: Contexto da análise
            
        Returns:
            Prompt especializado formatado
        """
        if context.analysis_type == AnalysisType.BUSINESS_LOGIC:
            return self.get_business_logic_prompt(context)
        elif context.analysis_type == AnalysisType.DATA_STRUCTURE:
            return self.get_data_structure_prompt(context)
        elif context.analysis_type == AnalysisType.PERFORMANCE:
            return self.get_performance_analysis_prompt(context)
        elif context.analysis_type == AnalysisType.MIGRATION:
            return self.get_migration_assessment_prompt(context)
        elif context.analysis_type == AnalysisType.SECURITY:
            return self.get_security_analysis_prompt(context)
        elif context.analysis_type == AnalysisType.MAINTENANCE:
            return self.get_maintenance_analysis_prompt(context)
        elif context.analysis_type == AnalysisType.INTEGRATION:
            return self.get_integration_analysis_prompt(context)
        else:
            return self.get_general_analysis_prompt(context)
    
    def get_business_logic_prompt(self, context: PromptContext) -> str:
        """Gera prompt focado em regras de negócio."""
        business_rules = self._extract_business_rules(context.program)
        domain_context = self._build_domain_context(context.domain_indicators)
        
        prompt = f"""
# Análise de Regras de Negócio - Programa COBOL

Você é um analista de sistemas especializado em COBOL e regras de negócio. Analise o programa COBOL fornecido com foco nas regras de negócio implementadas.

## Contexto do Programa
- **Nome**: {context.program.program_id}
- **Autor**: {context.program.author or 'Não especificado'}
- **Domínio identificado**: {domain_context}

## Regras de Negócio Identificadas
{self._format_business_rules(business_rules)}

## Instruções de Análise

### 1. Identificação de Regras de Negócio
- Identifique e explique cada regra de negócio implementada no código
- Foque em validações, cálculos, condições e transformações de dados
- Explique o propósito comercial de cada regra

### 2. Fluxo de Processos de Negócio
- Descreva o fluxo principal de processamento
- Identifique pontos de decisão críticos
- Explique como os dados fluem através dos processos

### 3. Validações e Controles
- Liste todas as validações de dados implementadas
- Identifique controles de integridade e consistência
- Explique tratamentos de erro e exceções

### 4. Cálculos e Transformações
- Detalhe fórmulas e cálculos implementados
- Explique transformações de dados
- Identifique regras de arredondamento ou precisão

### 5. Impacto no Negócio
- Avalie a criticidade de cada regra para o negócio
- Identifique dependências entre regras
- Sugira melhorias ou otimizações

{self._get_base_instructions()}

## Código COBOL para Análise
```cobol
{context.program.raw_content}
```
"""
        return prompt.strip()
    
    def get_data_structure_prompt(self, context: PromptContext) -> str:
        """Gera prompt focado em estruturas de dados."""
        data_summary = context.data_flow_summary or {}
        variables_info = self._analyze_variable_structures(context.program.variables)
        
        prompt = f"""
# Análise de Estruturas de Dados - Programa COBOL

Você é um arquiteto de dados especializado em COBOL. Analise as estruturas de dados do programa fornecido.

## Contexto do Programa
- **Nome**: {context.program.program_id}
- **Total de variáveis**: {len(context.program.variables)}
- **Variáveis utilizadas**: {data_summary.get('total_variables_used', 'N/A')}

## Resumo das Estruturas
{self._format_variable_structures(variables_info)}

## Instruções de Análise

### 1. Arquitetura de Dados
- Analise a organização hierárquica das estruturas de dados
- Identifique padrões de design de dados
- Avalie a normalização e relacionamentos

### 2. Estruturas Complexas
- Detalhe arrays e tabelas (OCCURS)
- Explique redefinições (REDEFINES) e seu propósito
- Analise estruturas condicionais (88 levels)

### 3. Fluxo de Dados
- Mapeie como os dados fluem entre estruturas
- Identifique transformações e conversões
- Analise dependências entre variáveis

### 4. Eficiência e Otimização
- Avalie o uso eficiente de memória
- Identifique oportunidades de otimização
- Sugira melhorias na organização dos dados

### 5. Qualidade dos Dados
- Analise validações e controles de qualidade
- Identifique possíveis problemas de integridade
- Sugira melhorias na validação de dados

### 6. Documentação de Estruturas
- Crie diagramas conceituais das principais estruturas
- Documente relacionamentos e dependências
- Explique o propósito de cada estrutura principal

{self._get_base_instructions()}

## Código COBOL para Análise
```cobol
{context.program.raw_content}
```
"""
        return prompt.strip()
    
    def get_performance_analysis_prompt(self, context: PromptContext) -> str:
        """Gera prompt focado em análise de performance."""
        complexity_info = context.complexity_metrics or {}
        performance_indicators = self._identify_performance_indicators(context.program)
        
        prompt = f"""
# Análise de Performance - Programa COBOL

Você é um especialista em otimização de performance de sistemas COBOL. Analise o programa fornecido identificando gargalos e oportunidades de otimização.

## Contexto do Programa
- **Nome**: {context.program.program_id}
- **Complexidade**: {complexity_info.get('PROGRAM_TOTAL', {}).get('level', 'N/A')}
- **Linhas de código**: {complexity_info.get('general_stats', {}).get('total_lines', 'N/A')}

## Indicadores de Performance Identificados
{self._format_performance_indicators(performance_indicators)}

## Instruções de Análise

### 1. Análise de Algoritmos
- Identifique algoritmos ineficientes (O(n²), O(n³))
- Analise loops aninhados e sua complexidade
- Avalie estruturas de busca e ordenação

### 2. Operações de I/O
- Analise padrões de acesso a arquivos
- Identifique operações de I/O desnecessárias
- Avalie estratégias de buffering e caching

### 3. Uso de Memória
- Analise alocação e uso de memória
- Identifique estruturas de dados superdimensionadas
- Avalie reutilização de variáveis

### 4. Estruturas de Controle
- Analise eficiência de IFs vs EVALUATE
- Identifique condições redundantes
- Avalie ordem de condições para otimização

### 5. Operações Matemáticas
- Analise cálculos complexos e repetitivos
- Identifique oportunidades de pré-cálculo
- Avalie precisão vs performance

### 6. Recomendações de Otimização
- Sugira melhorias específicas de performance
- Priorize otimizações por impacto
- Estime ganhos potenciais de performance

### 7. Métricas e Monitoramento
- Sugira pontos de medição de performance
- Identifique KPIs relevantes
- Recomende ferramentas de profiling

{self._get_base_instructions()}

## Código COBOL para Análise
```cobol
{context.program.raw_content}
```
"""
        return prompt.strip()
    
    def get_migration_assessment_prompt(self, context: PromptContext) -> str:
        """Gera prompt para avaliação de migração."""
        migration_complexity = self._assess_migration_complexity(context.program)
        modern_equivalents = self._identify_modern_equivalents(context.program)
        
        prompt = f"""
# Avaliação de Migração - Programa COBOL

Você é um arquiteto de sistemas especializado em modernização de aplicações COBOL. Avalie a viabilidade e estratégia de migração do programa fornecido.

## Contexto do Programa
- **Nome**: {context.program.program_id}
- **Complexidade de migração**: {migration_complexity['level']}
- **Fatores de risco**: {len(migration_complexity['risk_factors'])}

## Análise de Migração
{self._format_migration_analysis(migration_complexity)}

## Equivalências Modernas Identificadas
{self._format_modern_equivalents(modern_equivalents)}

## Instruções de Análise

### 1. Avaliação de Viabilidade
- Analise a complexidade técnica da migração
- Identifique dependências críticas
- Avalie riscos e desafios principais

### 2. Estratégias de Migração
- **Reescrita completa**: Quando recomendada e esforço estimado
- **Migração incremental**: Fases e prioridades
- **Encapsulamento**: Quando manter COBOL faz sentido
- **Híbrida**: Combinação de estratégias

### 3. Tecnologias de Destino
- Linguagens modernas mais adequadas (Java, C#, Python)
- Frameworks e plataformas recomendadas
- Bancos de dados e arquiteturas de dados

### 4. Mapeamento de Funcionalidades
- Identifique funcionalidades que podem ser automatizadas
- Mapeie lógica de negócio para padrões modernos
- Identifique componentes reutilizáveis

### 5. Plano de Migração
- Defina fases de migração por prioridade
- Estime esforço e cronograma
- Identifique recursos necessários

### 6. Riscos e Mitigações
- Liste riscos técnicos e de negócio
- Sugira estratégias de mitigação
- Defina critérios de sucesso

### 7. ROI e Benefícios
- Avalie benefícios da modernização
- Estime custos vs benefícios
- Identifique quick wins

{self._get_base_instructions()}

## Código COBOL para Análise
```cobol
{context.program.raw_content}
```
"""
        return prompt.strip()
    
    def get_security_analysis_prompt(self, context: PromptContext) -> str:
        """Gera prompt focado em análise de segurança."""
        security_issues = self._identify_security_issues(context.program)
        
        prompt = f"""
# Análise de Segurança - Programa COBOL

Você é um especialista em segurança de aplicações mainframe e COBOL. Analise o programa fornecido identificando vulnerabilidades e riscos de segurança.

## Contexto do Programa
- **Nome**: {context.program.program_id}
- **Potenciais riscos identificados**: {len(security_issues)}

## Riscos de Segurança Identificados
{self._format_security_issues(security_issues)}

## Instruções de Análise

### 1. Vulnerabilidades de Código
- Identifique buffer overflows potenciais
- Analise validação inadequada de entrada
- Verifique tratamento inseguro de dados sensíveis

### 2. Controle de Acesso
- Analise verificações de autorização
- Identifique bypass de controles de segurança
- Avalie segregação de funções

### 3. Manipulação de Dados Sensíveis
- Identifique dados sensíveis (senhas, CPF, cartões)
- Analise criptografia e proteção de dados
- Verifique logs e auditoria

### 4. Operações de Arquivo
- Analise permissões de arquivo
- Identifique acessos não autorizados
- Verifique integridade de dados

### 5. Injeção e Manipulação
- Analise possibilidades de injeção SQL
- Identifique manipulação de parâmetros
- Verifique sanitização de dados

### 6. Auditoria e Logging
- Avalie trilhas de auditoria
- Identifique eventos não logados
- Analise retenção e proteção de logs

### 7. Recomendações de Segurança
- Sugira melhorias específicas
- Priorize correções por criticidade
- Recomende controles compensatórios

{self._get_base_instructions()}

## Código COBOL para Análise
```cobol
{context.program.raw_content}
```
"""
        return prompt.strip()
    
    def get_maintenance_analysis_prompt(self, context: PromptContext) -> str:
        """Gera prompt focado em análise de manutenibilidade."""
        maintenance_metrics = context.complexity_metrics or {}
        code_smells = maintenance_metrics.get('code_smells', [])
        
        prompt = f"""
# Análise de Manutenibilidade - Programa COBOL

Você é um especialista em qualidade de código e manutenção de sistemas COBOL. Analise o programa fornecido focando na facilidade de manutenção e evolução.

## Contexto do Programa
- **Nome**: {context.program.program_id}
- **Pontuação de qualidade**: {maintenance_metrics.get('quality_score', 'N/A')}
- **Problemas identificados**: {len(code_smells)}

## Problemas de Manutenibilidade
{self._format_code_smells(code_smells)}

## Instruções de Análise

### 1. Legibilidade do Código
- Avalie clareza de nomenclatura
- Analise estruturação e organização
- Verifique documentação e comentários

### 2. Complexidade e Modularidade
- Analise complexidade ciclomática
- Avalie tamanho de parágrafos e seções
- Identifique oportunidades de modularização

### 3. Padrões e Convenções
- Verifique consistência de padrões
- Identifique desvios de boas práticas
- Analise aderência a standards

### 4. Dependências e Acoplamento
- Analise acoplamento entre módulos
- Identifique dependências circulares
- Avalie coesão funcional

### 5. Testabilidade
- Avalie facilidade de teste
- Identifique pontos de teste críticos
- Sugira estratégias de teste

### 6. Documentação
- Analise qualidade da documentação
- Identifique gaps de documentação
- Sugira melhorias na documentação

### 7. Plano de Melhoria
- Priorize melhorias por impacto
- Sugira refatorações específicas
- Estime esforço de melhoria

{self._get_base_instructions()}

## Código COBOL para Análise
```cobol
{context.program.raw_content}
```
"""
        return prompt.strip()
    
    def get_integration_analysis_prompt(self, context: PromptContext) -> str:
        """Gera prompt focado em análise de integração."""
        integration_points = self._identify_integration_points(context.program)
        
        prompt = f"""
# Análise de Integração - Programa COBOL

Você é um arquiteto de integração especializado em sistemas mainframe. Analise o programa fornecido focando em pontos de integração e interfaces.

## Contexto do Programa
- **Nome**: {context.program.program_id}
- **Pontos de integração identificados**: {len(integration_points)}

## Pontos de Integração
{self._format_integration_points(integration_points)}

## Instruções de Análise

### 1. Interfaces de Dados
- Identifique arquivos de entrada e saída
- Analise formatos e estruturas de dados
- Avalie compatibilidade de interfaces

### 2. Chamadas de Sistema
- Identifique CALLs para outros programas
- Analise parâmetros e contratos
- Avalie dependências externas

### 3. Operações de Banco de Dados
- Analise acessos a DB2, IMS ou outros SGBDs
- Identifique transações e commits
- Avalie performance de queries

### 4. Comunicação entre Sistemas
- Identifique MQ, CICS, ou outras middleware
- Analise protocolos de comunicação
- Avalie tratamento de erros

### 5. Batch vs Online
- Identifique processamento batch
- Analise interações online (CICS)
- Avalie sincronização de dados

### 6. APIs e Web Services
- Identifique exposição de funcionalidades
- Analise potencial para APIs REST
- Avalie modernização de interfaces

### 7. Estratégia de Integração
- Sugira padrões de integração
- Recomende tecnologias modernas
- Defina arquitetura de integração

{self._get_base_instructions()}

## Código COBOL para Análise
```cobol
{context.program.raw_content}
```
"""
        return prompt.strip()
    
    def get_general_analysis_prompt(self, context: PromptContext) -> str:
        """Gera prompt para análise geral."""
        prompt = f"""
# Análise Geral - Programa COBOL

Você é um analista de sistemas COBOL experiente. Forneça uma análise abrangente do programa fornecido.

## Contexto do Programa
- **Nome**: {context.program.program_id}
- **Autor**: {context.program.author or 'Não especificado'}

## Instruções de Análise

### 1. Visão Geral
- Descreva o propósito e funcionalidade principal
- Identifique o domínio de negócio
- Explique o fluxo principal de processamento

### 2. Estrutura e Organização
- Analise a organização do código
- Avalie a estruturação em divisões e seções
- Identifique padrões arquiteturais

### 3. Qualidade do Código
- Avalie legibilidade e manutenibilidade
- Identifique boas práticas e problemas
- Sugira melhorias gerais

### 4. Recomendações
- Sugira melhorias prioritárias
- Identifique riscos e oportunidades
- Recomende próximos passos

{self._get_base_instructions()}

## Código COBOL para Análise
```cobol
{context.program.raw_content}
```
"""
        return prompt.strip()
    
    def _get_base_instructions(self) -> str:
        """Retorna instruções base para todos os prompts."""
        return f"""
## Instruções Gerais
- **Tom**: {self.base_instructions['tone']}
- **Estrutura**: {self.base_instructions['structure']}
- **Idioma**: {self.base_instructions['language']}
- **Formato**: {self.base_instructions['format']}

## Formato de Resposta
- Use títulos e subtítulos claros
- Inclua exemplos de código quando relevante
- Forneça recomendações práticas e acionáveis
- Priorize informações por importância
- Seja específico e evite generalidades
"""
    
    def _extract_business_rules(self, program: CobolProgram) -> List[str]:
        """Extrai regras de negócio do programa."""
        rules = []
        lines = program.raw_content.split('\n')
        
        for line in lines:
            line_upper = line.upper().strip()
            if any(keyword in line_upper for keyword in ['IF', 'WHEN', 'COMPUTE', 'EVALUATE']):
                rules.append(line.strip())
        
        return rules[:10]  # Limita a 10 regras principais
    
    def _build_domain_context(self, domain_indicators: List[str]) -> str:
        """Constrói contexto do domínio."""
        if not domain_indicators:
            return "Domínio não identificado automaticamente"
        return ", ".join(domain_indicators)
    
    def _format_business_rules(self, rules: List[str]) -> str:
        """Formata regras de negócio para o prompt."""
        if not rules:
            return "Nenhuma regra específica identificada automaticamente."
        
        formatted = "```cobol\n"
        for i, rule in enumerate(rules, 1):
            formatted += f"{i}. {rule}\n"
        formatted += "```"
        return formatted
    
    def _analyze_variable_structures(self, variables: List[CobolVariable]) -> Dict[str, Any]:
        """Analisa estruturas de variáveis."""
        return {
            'total_variables': len(variables),
            'level_01_structures': len([v for v in variables if v.level == 1]),
            'arrays': len([v for v in variables if v.occurs]),
            'redefines': len([v for v in variables if v.redefines]),
            'condition_names': len([v for v in variables if v.condition_names])
        }
    
    def _format_variable_structures(self, info: Dict[str, Any]) -> str:
        """Formata informações de estruturas de variáveis."""
        return f"""
- **Total de variáveis**: {info['total_variables']}
- **Estruturas nível 01**: {info['level_01_structures']}
- **Arrays (OCCURS)**: {info['arrays']}
- **Redefinições (REDEFINES)**: {info['redefines']}
- **Nomes de condição (88)**: {info['condition_names']}
"""
    
    def _identify_performance_indicators(self, program: CobolProgram) -> List[str]:
        """Identifica indicadores de performance."""
        indicators = []
        lines = program.raw_content.split('\n')
        
        for line in lines:
            line_upper = line.upper().strip()
            if 'PERFORM' in line_upper and 'UNTIL' in line_upper:
                indicators.append(f"Loop: {line.strip()}")
            elif 'SEARCH' in line_upper:
                indicators.append(f"Busca: {line.strip()}")
            elif 'READ' in line_upper:
                indicators.append(f"I/O: {line.strip()}")
        
        return indicators[:5]  # Limita a 5 indicadores
    
    def _format_performance_indicators(self, indicators: List[str]) -> str:
        """Formata indicadores de performance."""
        if not indicators:
            return "Nenhum indicador específico identificado automaticamente."
        
        formatted = ""
        for indicator in indicators:
            formatted += f"- {indicator}\n"
        return formatted
    
    def _assess_migration_complexity(self, program: CobolProgram) -> Dict[str, Any]:
        """Avalia complexidade de migração."""
        risk_factors = []
        lines = program.raw_content.split('\n')
        
        for line in lines:
            line_upper = line.upper().strip()
            if 'GO TO' in line_upper:
                risk_factors.append("Uso de GO TO")
            elif 'REDEFINES' in line_upper:
                risk_factors.append("Estruturas REDEFINES complexas")
            elif 'CALL' in line_upper:
                risk_factors.append("Dependências externas (CALL)")
        
        complexity_level = "Baixa"
        if len(risk_factors) > 10:
            complexity_level = "Alta"
        elif len(risk_factors) > 5:
            complexity_level = "Média"
        
        return {
            'level': complexity_level,
            'risk_factors': list(set(risk_factors))
        }
    
    def _format_migration_analysis(self, analysis: Dict[str, Any]) -> str:
        """Formata análise de migração."""
        formatted = f"**Nível de complexidade**: {analysis['level']}\n\n"
        if analysis['risk_factors']:
            formatted += "**Fatores de risco identificados**:\n"
            for factor in analysis['risk_factors']:
                formatted += f"- {factor}\n"
        return formatted
    
    def _identify_modern_equivalents(self, program: CobolProgram) -> Dict[str, str]:
        """Identifica equivalentes modernos."""
        equivalents = {}
        lines = program.raw_content.split('\n')
        
        for line in lines:
            line_upper = line.upper().strip()
            if 'PERFORM UNTIL' in line_upper:
                equivalents['Loops'] = "while/for loops em linguagens modernas"
            elif 'EVALUATE' in line_upper:
                equivalents['Decisões múltiplas'] = "switch/case statements"
            elif 'COPY' in line_upper:
                equivalents['Reutilização'] = "imports/includes/modules"
        
        return equivalents
    
    def _format_modern_equivalents(self, equivalents: Dict[str, str]) -> str:
        """Formata equivalentes modernos."""
        if not equivalents:
            return "Nenhum equivalente específico identificado automaticamente."
        
        formatted = ""
        for cobol_feature, modern_equiv in equivalents.items():
            formatted += f"- **{cobol_feature}**: {modern_equiv}\n"
        return formatted
    
    def _identify_security_issues(self, program: CobolProgram) -> List[str]:
        """Identifica possíveis problemas de segurança."""
        issues = []
        lines = program.raw_content.split('\n')
        
        for line in lines:
            line_upper = line.upper().strip()
            if any(keyword in line_upper for keyword in ['PASSWORD', 'SENHA', 'PWD']):
                issues.append("Possível manipulação de senhas")
            elif 'ACCEPT' in line_upper:
                issues.append("Entrada de dados sem validação aparente")
            elif 'DISPLAY' in line_upper and any(sensitive in line_upper for sensitive in ['CPF', 'CARD', 'ACCOUNT']):
                issues.append("Possível exposição de dados sensíveis")
        
        return list(set(issues))
    
    def _format_security_issues(self, issues: List[str]) -> str:
        """Formata problemas de segurança."""
        if not issues:
            return "Nenhum risco óbvio identificado automaticamente."
        
        formatted = ""
        for issue in issues:
            formatted += f"- ⚠️ {issue}\n"
        return formatted
    
    def _format_code_smells(self, code_smells: List[Dict]) -> str:
        """Formata code smells."""
        if not code_smells:
            return "Nenhum problema específico identificado automaticamente."
        
        formatted = ""
        for smell in code_smells[:5]:  # Limita a 5 problemas
            formatted += f"- **{smell.get('type', 'N/A')}**: {smell.get('description', 'N/A')}\n"
        return formatted
    
    def _identify_integration_points(self, program: CobolProgram) -> List[str]:
        """Identifica pontos de integração."""
        points = []
        lines = program.raw_content.split('\n')
        
        for line in lines:
            line_upper = line.upper().strip()
            if 'CALL' in line_upper:
                points.append(f"Chamada externa: {line.strip()}")
            elif 'READ' in line_upper or 'WRITE' in line_upper:
                points.append(f"Operação de arquivo: {line.strip()}")
            elif 'EXEC SQL' in line_upper:
                points.append(f"Acesso a banco: {line.strip()}")
        
        return points[:5]  # Limita a 5 pontos
    
    def _format_integration_points(self, points: List[str]) -> str:
        """Formata pontos de integração."""
        if not points:
            return "Nenhum ponto específico identificado automaticamente."
        
        formatted = ""
        for point in points:
            formatted += f"- {point}\n"
        return formatted

