"""
Analisador de complexidade para programas COBOL.
"""

import re
from typing import Dict, List, Tuple, Set
from dataclasses import dataclass
from enum import Enum

from cobol_parser import CobolProgram, CobolParagraph, CobolSection


class ComplexityLevel(Enum):
    """Níveis de complexidade."""
    LOW = "Baixa"
    MEDIUM = "Média"
    HIGH = "Alta"
    VERY_HIGH = "Muito Alta"


@dataclass
class ComplexityMetric:
    """Representa uma métrica de complexidade."""
    name: str
    value: int
    description: str
    level: ComplexityLevel
    recommendations: List[str] = None
    
    def __post_init__(self):
        if self.recommendations is None:
            self.recommendations = []


@dataclass
class CodeSmell:
    """Representa um problema de qualidade no código."""
    type: str
    description: str
    location: str
    line_number: int
    severity: str  # LOW, MEDIUM, HIGH
    suggestion: str


class ComplexityAnalyzer:
    """Analisador de complexidade de código COBOL."""
    
    def __init__(self, program: CobolProgram):
        self.program = program
        self.code_smells: List[CodeSmell] = []
        
        # Padrões regex para análise de complexidade
        self.patterns = {
            'if_statement': re.compile(r'^\s*IF\s+', re.IGNORECASE),
            'evaluate_statement': re.compile(r'^\s*EVALUATE\s+', re.IGNORECASE),
            'when_clause': re.compile(r'^\s*WHEN\s+', re.IGNORECASE),
            'perform_until': re.compile(r'PERFORM\s+.*\s+UNTIL\s+', re.IGNORECASE),
            'perform_varying': re.compile(r'PERFORM\s+.*\s+VARYING\s+', re.IGNORECASE),
            'perform_times': re.compile(r'PERFORM\s+.*\s+TIMES', re.IGNORECASE),
            'search_statement': re.compile(r'^\s*SEARCH\s+', re.IGNORECASE),
            'goto_statement': re.compile(r'^\s*GO\s+TO\s+', re.IGNORECASE),
            'nested_if': re.compile(r'^\s+IF\s+', re.IGNORECASE),
            'end_if': re.compile(r'^\s*END-IF', re.IGNORECASE),
            'call_statement': re.compile(r'^\s*CALL\s+', re.IGNORECASE),
            'exit_statement': re.compile(r'^\s*EXIT\s*\.', re.IGNORECASE),
            'stop_run': re.compile(r'^\s*STOP\s+RUN', re.IGNORECASE)
        }
    
    def calculate_cyclomatic_complexity(self) -> Dict[str, ComplexityMetric]:
        """
        Calcula a complexidade ciclomática do programa.
        
        Returns:
            Dicionário com métricas de complexidade por parágrafo/seção
        """
        complexity_metrics = {}
        
        # Complexidade geral do programa
        total_complexity = self._calculate_program_complexity()
        complexity_metrics['PROGRAM_TOTAL'] = ComplexityMetric(
            name="Complexidade Total do Programa",
            value=total_complexity,
            description=f"Complexidade ciclomática total: {total_complexity}",
            level=self._get_complexity_level(total_complexity),
            recommendations=self._get_complexity_recommendations(total_complexity)
        )
        
        # Complexidade por seção
        for section in self.program.sections:
            section_complexity = self._calculate_section_complexity(section)
            complexity_metrics[f"SECTION_{section.name}"] = ComplexityMetric(
                name=f"Seção {section.name}",
                value=section_complexity,
                description=f"Complexidade da seção {section.name}: {section_complexity}",
                level=self._get_complexity_level(section_complexity),
                recommendations=self._get_section_recommendations(section, section_complexity)
            )
        
        # Complexidade por parágrafo
        all_paragraphs = self.program.paragraphs.copy()
        for section in self.program.sections:
            all_paragraphs.extend(section.paragraphs)
        
        for paragraph in all_paragraphs:
            para_complexity = self._calculate_paragraph_complexity(paragraph)
            if para_complexity > 1:  # Só reporta parágrafos com complexidade > 1
                complexity_metrics[f"PARAGRAPH_{paragraph.name}"] = ComplexityMetric(
                    name=f"Parágrafo {paragraph.name}",
                    value=para_complexity,
                    description=f"Complexidade do parágrafo {paragraph.name}: {para_complexity}",
                    level=self._get_complexity_level(para_complexity),
                    recommendations=self._get_paragraph_recommendations(paragraph, para_complexity)
                )
        
        return complexity_metrics
    
    def _calculate_program_complexity(self) -> int:
        """Calcula a complexidade total do programa."""
        complexity = 1  # Complexidade base
        lines = self.program.raw_content.split('\n')
        
        for line in lines:
            complexity += self._count_decision_points(line)
        
        return complexity
    
    def _calculate_section_complexity(self, section: CobolSection) -> int:
        """Calcula a complexidade de uma seção."""
        complexity = 1  # Complexidade base
        
        for paragraph in section.paragraphs:
            for line in paragraph.content:
                complexity += self._count_decision_points(line)
        
        return complexity
    
    def _calculate_paragraph_complexity(self, paragraph: CobolParagraph) -> int:
        """Calcula a complexidade de um parágrafo."""
        complexity = 1  # Complexidade base
        
        for line in paragraph.content:
            complexity += self._count_decision_points(line)
        
        return complexity
    
    def _count_decision_points(self, line: str) -> int:
        """Conta pontos de decisão em uma linha."""
        points = 0
        line_upper = line.upper().strip()
        
        # IF statements
        if self.patterns['if_statement'].match(line):
            points += 1
            # Conta condições múltiplas (AND, OR)
            points += line_upper.count(' AND ')
            points += line_upper.count(' OR ')
        
        # EVALUATE/WHEN
        if self.patterns['evaluate_statement'].match(line):
            points += 1
        elif self.patterns['when_clause'].match(line):
            points += 1
        
        # PERFORM loops
        if (self.patterns['perform_until'].search(line) or 
            self.patterns['perform_varying'].search(line) or
            self.patterns['perform_times'].search(line)):
            points += 1
        
        # SEARCH statements
        if self.patterns['search_statement'].match(line):
            points += 1
        
        return points
    
    def calculate_nesting_depth(self) -> Dict[str, int]:
        """
        Calcula a profundidade de aninhamento por parágrafo.
        
        Returns:
            Dicionário com profundidade máxima por parágrafo
        """
        nesting_depths = {}
        
        all_paragraphs = self.program.paragraphs.copy()
        for section in self.program.sections:
            all_paragraphs.extend(section.paragraphs)
        
        for paragraph in all_paragraphs:
            max_depth = self._calculate_paragraph_nesting(paragraph)
            if max_depth > 1:
                nesting_depths[paragraph.name] = max_depth
        
        return nesting_depths
    
    def _calculate_paragraph_nesting(self, paragraph: CobolParagraph) -> int:
        """Calcula a profundidade de aninhamento de um parágrafo."""
        max_depth = 0
        current_depth = 0
        
        for line in paragraph.content:
            line_stripped = line.strip().upper()
            
            # Aumenta profundidade
            if (line_stripped.startswith('IF ') or 
                line_stripped.startswith('EVALUATE ') or
                line_stripped.startswith('PERFORM ') and 'UNTIL' in line_stripped):
                current_depth += 1
                max_depth = max(max_depth, current_depth)
            
            # Diminui profundidade
            elif (line_stripped.startswith('END-IF') or 
                  line_stripped.startswith('END-EVALUATE') or
                  line_stripped.startswith('END-PERFORM')):
                current_depth = max(0, current_depth - 1)
        
        return max_depth
    
    def identify_code_smells(self) -> List[CodeSmell]:
        """
        Identifica problemas de qualidade no código.
        
        Returns:
            Lista de code smells encontrados
        """
        self.code_smells = []
        
        self._detect_long_paragraphs()
        self._detect_excessive_gotos()
        self._detect_unused_variables()
        self._detect_magic_numbers()
        self._detect_deep_nesting()
        self._detect_duplicate_code()
        self._detect_large_data_structures()
        
        return self.code_smells
    
    def _detect_long_paragraphs(self):
        """Detecta parágrafos muito longos."""
        all_paragraphs = self.program.paragraphs.copy()
        for section in self.program.sections:
            all_paragraphs.extend(section.paragraphs)
        
        for paragraph in all_paragraphs:
            line_count = len(paragraph.content)
            if line_count > 50:
                self.code_smells.append(CodeSmell(
                    type="LONG_PARAGRAPH",
                    description=f"Parágrafo muito longo com {line_count} linhas",
                    location=paragraph.name,
                    line_number=paragraph.line_number,
                    severity="MEDIUM",
                    suggestion="Considere dividir em parágrafos menores e mais específicos"
                ))
    
    def _detect_excessive_gotos(self):
        """Detecta uso excessivo de GO TO."""
        goto_count = 0
        lines = self.program.raw_content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            if self.patterns['goto_statement'].search(line):
                goto_count += 1
                if goto_count > 5:  # Limite arbitrário
                    self.code_smells.append(CodeSmell(
                        type="EXCESSIVE_GOTO",
                        description="Uso excessivo de GO TO statements",
                        location=f"Linha {line_num}",
                        line_number=line_num,
                        severity="HIGH",
                        suggestion="Refatore usando PERFORM e estruturas de controle estruturadas"
                    ))
    
    def _detect_unused_variables(self):
        """Detecta variáveis não utilizadas."""
        # Extrai nomes de variáveis definidas
        defined_vars = {var.name for var in self.program.variables}
        
        # Extrai variáveis usadas no código
        used_vars = set()
        lines = self.program.raw_content.split('\n')
        
        for line in lines:
            # Procura referências a variáveis
            for var_name in defined_vars:
                if re.search(r'\b' + re.escape(var_name) + r'\b', line, re.IGNORECASE):
                    used_vars.add(var_name)
        
        # Identifica variáveis não utilizadas
        unused_vars = defined_vars - used_vars
        
        for var_name in unused_vars:
            var = next((v for v in self.program.variables if v.name == var_name), None)
            if var:
                self.code_smells.append(CodeSmell(
                    type="UNUSED_VARIABLE",
                    description=f"Variável '{var_name}' definida mas não utilizada",
                    location=f"Linha {var.line_number}",
                    line_number=var.line_number,
                    severity="LOW",
                    suggestion="Remova a variável se não for necessária"
                ))
    
    def _detect_magic_numbers(self):
        """Detecta números mágicos no código."""
        lines = self.program.raw_content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            # Procura números literais (exceto 0, 1, -1 que são comuns)
            magic_numbers = re.findall(r'\b(?!0\b|1\b|-1\b)\d{2,}\b', line)
            
            for number in magic_numbers:
                self.code_smells.append(CodeSmell(
                    type="MAGIC_NUMBER",
                    description=f"Número mágico '{number}' encontrado",
                    location=f"Linha {line_num}",
                    line_number=line_num,
                    severity="LOW",
                    suggestion="Considere usar uma constante nomeada"
                ))
    
    def _detect_deep_nesting(self):
        """Detecta aninhamento muito profundo."""
        nesting_depths = self.calculate_nesting_depth()
        
        for paragraph_name, depth in nesting_depths.items():
            if depth > 4:  # Limite de 4 níveis
                paragraph = self._find_paragraph_by_name(paragraph_name)
                if paragraph:
                    self.code_smells.append(CodeSmell(
                        type="DEEP_NESTING",
                        description=f"Aninhamento muito profundo ({depth} níveis)",
                        location=paragraph_name,
                        line_number=paragraph.line_number,
                        severity="HIGH",
                        suggestion="Refatore extraindo lógica para parágrafos separados"
                    ))
    
    def _detect_duplicate_code(self):
        """Detecta código duplicado."""
        all_paragraphs = self.program.paragraphs.copy()
        for section in self.program.sections:
            all_paragraphs.extend(section.paragraphs)
        
        # Compara parágrafos em busca de similaridade
        for i, para1 in enumerate(all_paragraphs):
            for para2 in all_paragraphs[i+1:]:
                similarity = self._calculate_similarity(para1.content, para2.content)
                if similarity > 0.8:  # 80% de similaridade
                    self.code_smells.append(CodeSmell(
                        type="DUPLICATE_CODE",
                        description=f"Código similar encontrado entre {para1.name} e {para2.name}",
                        location=f"{para1.name}, {para2.name}",
                        line_number=para1.line_number,
                        severity="MEDIUM",
                        suggestion="Considere extrair código comum para um parágrafo reutilizável"
                    ))
    
    def _detect_large_data_structures(self):
        """Detecta estruturas de dados muito grandes."""
        for var in self.program.variables:
            if var.level == 1:  # Estruturas de nível 1
                child_count = len(var.children)
                if child_count > 20:
                    self.code_smells.append(CodeSmell(
                        type="LARGE_DATA_STRUCTURE",
                        description=f"Estrutura de dados muito grande com {child_count} campos",
                        location=var.name,
                        line_number=var.line_number,
                        severity="MEDIUM",
                        suggestion="Considere dividir em estruturas menores e mais coesas"
                    ))
    
    def _calculate_similarity(self, content1: List[str], content2: List[str]) -> float:
        """Calcula similaridade entre dois blocos de código."""
        if not content1 or not content2:
            return 0.0
        
        # Normaliza o conteúdo (remove espaços e converte para maiúscula)
        normalized1 = [line.strip().upper() for line in content1 if line.strip()]
        normalized2 = [line.strip().upper() for line in content2 if line.strip()]
        
        if not normalized1 or not normalized2:
            return 0.0
        
        # Conta linhas idênticas
        common_lines = 0
        for line1 in normalized1:
            if line1 in normalized2:
                common_lines += 1
        
        # Calcula similaridade
        max_lines = max(len(normalized1), len(normalized2))
        return common_lines / max_lines if max_lines > 0 else 0.0
    
    def _find_paragraph_by_name(self, name: str) -> CobolParagraph:
        """Encontra um parágrafo pelo nome."""
        all_paragraphs = self.program.paragraphs.copy()
        for section in self.program.sections:
            all_paragraphs.extend(section.paragraphs)
        
        return next((p for p in all_paragraphs if p.name == name), None)
    
    def _get_complexity_level(self, complexity: int) -> ComplexityLevel:
        """Determina o nível de complexidade baseado no valor."""
        if complexity <= 5:
            return ComplexityLevel.LOW
        elif complexity <= 10:
            return ComplexityLevel.MEDIUM
        elif complexity <= 20:
            return ComplexityLevel.HIGH
        else:
            return ComplexityLevel.VERY_HIGH
    
    def _get_complexity_recommendations(self, complexity: int) -> List[str]:
        """Gera recomendações baseadas na complexidade."""
        recommendations = []
        
        if complexity > 20:
            recommendations.extend([
                "Considere dividir o programa em módulos menores",
                "Refatore lógica complexa em parágrafos separados",
                "Implemente testes unitários para validar funcionalidade"
            ])
        elif complexity > 10:
            recommendations.extend([
                "Revise a lógica de controle para simplificação",
                "Considere extrair funcionalidades em parágrafos específicos"
            ])
        elif complexity > 5:
            recommendations.append("Monitore a complexidade em futuras modificações")
        
        return recommendations
    
    def _get_section_recommendations(self, section: CobolSection, complexity: int) -> List[str]:
        """Gera recomendações específicas para uma seção."""
        recommendations = []
        
        if complexity > 15:
            recommendations.append(f"Seção {section.name} muito complexa - considere dividir")
        
        if len(section.paragraphs) > 10:
            recommendations.append("Muitos parágrafos - considere reorganizar")
        
        return recommendations
    
    def _get_paragraph_recommendations(self, paragraph: CobolParagraph, complexity: int) -> List[str]:
        """Gera recomendações específicas para um parágrafo."""
        recommendations = []
        
        if complexity > 10:
            recommendations.append("Parágrafo muito complexo - considere dividir")
        
        if len(paragraph.content) > 30:
            recommendations.append("Parágrafo muito longo - considere extrair lógica")
        
        return recommendations
    
    def generate_complexity_report(self) -> Dict[str, any]:
        """
        Gera um relatório completo de complexidade.
        
        Returns:
            Dicionário com relatório de complexidade
        """
        complexity_metrics = self.calculate_cyclomatic_complexity()
        nesting_depths = self.calculate_nesting_depth()
        code_smells = self.identify_code_smells()
        
        # Estatísticas gerais
        total_lines = len(self.program.raw_content.split('\n'))
        total_variables = len(self.program.variables)
        total_paragraphs = len(self.program.paragraphs)
        for section in self.program.sections:
            total_paragraphs += len(section.paragraphs)
        
        return {
            'general_stats': {
                'total_lines': total_lines,
                'total_variables': total_variables,
                'total_paragraphs': total_paragraphs,
                'total_sections': len(self.program.sections)
            },
            'complexity_metrics': {
                name: {
                    'value': metric.value,
                    'level': metric.level.value,
                    'description': metric.description,
                    'recommendations': metric.recommendations
                }
                for name, metric in complexity_metrics.items()
            },
            'nesting_depths': nesting_depths,
            'code_smells': [
                {
                    'type': smell.type,
                    'description': smell.description,
                    'location': smell.location,
                    'line_number': smell.line_number,
                    'severity': smell.severity,
                    'suggestion': smell.suggestion
                }
                for smell in code_smells
            ],
            'quality_score': self._calculate_quality_score(complexity_metrics, code_smells),
            'maintainability_index': self._calculate_maintainability_index(
                total_lines, complexity_metrics, code_smells
            )
        }
    
    def _calculate_quality_score(self, complexity_metrics: Dict, code_smells: List[CodeSmell]) -> int:
        """Calcula uma pontuação de qualidade (0-100)."""
        base_score = 100
        
        # Penaliza por complexidade alta
        program_complexity = complexity_metrics.get('PROGRAM_TOTAL')
        if program_complexity:
            if program_complexity.level == ComplexityLevel.VERY_HIGH:
                base_score -= 30
            elif program_complexity.level == ComplexityLevel.HIGH:
                base_score -= 20
            elif program_complexity.level == ComplexityLevel.MEDIUM:
                base_score -= 10
        
        # Penaliza por code smells
        for smell in code_smells:
            if smell.severity == "HIGH":
                base_score -= 5
            elif smell.severity == "MEDIUM":
                base_score -= 3
            else:
                base_score -= 1
        
        return max(0, base_score)
    
    def _calculate_maintainability_index(self, total_lines: int, complexity_metrics: Dict, 
                                       code_smells: List[CodeSmell]) -> float:
        """Calcula índice de manutenibilidade."""
        # Fórmula simplificada baseada em métricas conhecidas
        program_complexity = complexity_metrics.get('PROGRAM_TOTAL')
        complexity_value = program_complexity.value if program_complexity else 1
        
        # Índice baseado em linhas de código, complexidade e problemas
        halstead_volume = total_lines * 4.17  # Aproximação
        maintainability = (
            171 - 5.2 * (complexity_value ** 0.23) - 
            0.23 * (complexity_value) - 16.2 * (halstead_volume ** 0.5) +
            50 * (2.46 ** (-len(code_smells) / 10))
        )
        
        return max(0, min(100, maintainability))

