"""
Detector de padrões e anti-padrões em código COBOL.
"""

import re
from typing import Dict, List, Set, Tuple
from dataclasses import dataclass
from enum import Enum

from cobol_parser import CobolProgram, CobolVariable, CobolParagraph, CobolSection


class PatternType(Enum):
    """Tipos de padrões detectados."""
    GOOD_PRACTICE = "Boa Prática"
    ANTI_PATTERN = "Anti-padrão"
    DESIGN_PATTERN = "Padrão de Design"
    PERFORMANCE_ISSUE = "Problema de Performance"
    MAINTAINABILITY_ISSUE = "Problema de Manutenibilidade"


@dataclass
class DetectedPattern:
    """Representa um padrão detectado no código."""
    name: str
    type: PatternType
    description: str
    location: str
    line_number: int
    confidence: float  # 0.0 a 1.0
    impact: str  # LOW, MEDIUM, HIGH
    suggestion: str
    examples: List[str] = None
    
    def __post_init__(self):
        if self.examples is None:
            self.examples = []


class PatternDetector:
    """Detector de padrões e anti-padrões em código COBOL."""
    
    def __init__(self, program: CobolProgram):
        self.program = program
        self.detected_patterns: List[DetectedPattern] = []
        
        # Padrões regex para detecção
        self.patterns = {
            'error_handling': re.compile(r'(FILE\s+STATUS|INVALID\s+KEY|AT\s+END|NOT\s+AT\s+END)', re.IGNORECASE),
            'data_validation': re.compile(r'(IF.*NUMERIC|IF.*ALPHABETIC|IF.*SPACE)', re.IGNORECASE),
            'structured_programming': re.compile(r'(PERFORM.*UNTIL|PERFORM.*VARYING|EVALUATE)', re.IGNORECASE),
            'goto_usage': re.compile(r'GO\s+TO\s+', re.IGNORECASE),
            'exit_paragraph': re.compile(r'^\s*([A-Z0-9-]+)-EXIT\s*\.', re.IGNORECASE),
            'initialization': re.compile(r'(INITIALIZE|MOVE\s+ZERO|MOVE\s+SPACE)', re.IGNORECASE),
            'magic_numbers': re.compile(r'\b\d{3,}\b'),
            'hardcoded_values': re.compile(r'[\'"][^\'\"]{10,}[\'"]'),
            'copy_usage': re.compile(r'^\s*COPY\s+', re.IGNORECASE),
            'consistent_naming': re.compile(r'^[A-Z][A-Z0-9-]*$'),
            'file_operations': re.compile(r'(OPEN|CLOSE|READ|WRITE)', re.IGNORECASE),
            'perform_thru': re.compile(r'PERFORM\s+.*\s+THRU\s+', re.IGNORECASE),
            'inline_perform': re.compile(r'PERFORM\s+UNTIL.*END-PERFORM', re.IGNORECASE | re.DOTALL),
            'working_storage_organization': re.compile(r'^\s*01\s+WS-', re.IGNORECASE),
            'linkage_section': re.compile(r'LINKAGE\s+SECTION', re.IGNORECASE),
            'procedure_division_using': re.compile(r'PROCEDURE\s+DIVISION\s+USING', re.IGNORECASE)
        }
    
    def detect_patterns(self) -> Dict[str, List[DetectedPattern]]:
        """
        Detecta todos os padrões no programa.
        
        Returns:
            Dicionário categorizado com padrões detectados
        """
        self.detected_patterns = []
        
        # Detecta boas práticas
        self._detect_error_handling_patterns()
        self._detect_data_validation_patterns()
        self._detect_structured_programming_patterns()
        self._detect_modular_design_patterns()
        self._detect_naming_conventions()
        self._detect_initialization_patterns()
        
        # Detecta anti-padrões
        self._detect_goto_antipatterns()
        self._detect_magic_number_antipatterns()
        self._detect_hardcoded_value_antipatterns()
        self._detect_performance_antipatterns()
        self._detect_maintainability_antipatterns()
        
        # Categoriza os padrões
        return self._categorize_patterns()
    
    def _detect_error_handling_patterns(self):
        """Detecta padrões de tratamento de erro."""
        lines = self.program.raw_content.split('\n')
        error_handling_count = 0
        file_operations_count = 0
        
        for line_num, line in enumerate(lines, 1):
            if self.patterns['file_operations'].search(line):
                file_operations_count += 1
            
            if self.patterns['error_handling'].search(line):
                error_handling_count += 1
                
                # Detecta padrão específico de FILE STATUS
                if 'FILE STATUS' in line.upper():
                    self.detected_patterns.append(DetectedPattern(
                        name="Uso de FILE STATUS",
                        type=PatternType.GOOD_PRACTICE,
                        description="Implementação adequada de controle de status de arquivo",
                        location=f"Linha {line_num}",
                        line_number=line_num,
                        confidence=0.9,
                        impact="HIGH",
                        suggestion="Continue usando FILE STATUS para controle robusto de arquivos",
                        examples=[line.strip()]
                    ))
                
                # Detecta tratamento de AT END
                if 'AT END' in line.upper():
                    self.detected_patterns.append(DetectedPattern(
                        name="Tratamento de Fim de Arquivo",
                        type=PatternType.GOOD_PRACTICE,
                        description="Tratamento adequado de condição de fim de arquivo",
                        location=f"Linha {line_num}",
                        line_number=line_num,
                        confidence=0.8,
                        impact="MEDIUM",
                        suggestion="Boa prática de tratamento de exceções de arquivo",
                        examples=[line.strip()]
                    ))
        
        # Avalia cobertura geral de tratamento de erro
        if file_operations_count > 0:
            error_coverage = error_handling_count / file_operations_count
            if error_coverage > 0.8:
                self.detected_patterns.append(DetectedPattern(
                    name="Cobertura Adequada de Tratamento de Erro",
                    type=PatternType.GOOD_PRACTICE,
                    description=f"Boa cobertura de tratamento de erro ({error_coverage:.1%})",
                    location="Programa geral",
                    line_number=1,
                    confidence=0.9,
                    impact="HIGH",
                    suggestion="Mantenha a disciplina de tratamento de erros"
                ))
    
    def _detect_data_validation_patterns(self):
        """Detecta padrões de validação de dados."""
        lines = self.program.raw_content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            if self.patterns['data_validation'].search(line):
                validation_type = ""
                if 'NUMERIC' in line.upper():
                    validation_type = "numérica"
                elif 'ALPHABETIC' in line.upper():
                    validation_type = "alfabética"
                elif 'SPACE' in line.upper():
                    validation_type = "espaços"
                
                self.detected_patterns.append(DetectedPattern(
                    name=f"Validação de Dados ({validation_type})",
                    type=PatternType.GOOD_PRACTICE,
                    description=f"Implementação de validação {validation_type} de dados",
                    location=f"Linha {line_num}",
                    line_number=line_num,
                    confidence=0.8,
                    impact="MEDIUM",
                    suggestion="Continue validando dados de entrada para robustez",
                    examples=[line.strip()]
                ))
    
    def _detect_structured_programming_patterns(self):
        """Detecta padrões de programação estruturada."""
        lines = self.program.raw_content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            if self.patterns['structured_programming'].search(line):
                if 'PERFORM' in line.upper() and 'UNTIL' in line.upper():
                    self.detected_patterns.append(DetectedPattern(
                        name="Uso de PERFORM UNTIL",
                        type=PatternType.GOOD_PRACTICE,
                        description="Uso de estrutura de loop estruturada",
                        location=f"Linha {line_num}",
                        line_number=line_num,
                        confidence=0.9,
                        impact="MEDIUM",
                        suggestion="PERFORM UNTIL é preferível a GO TO para loops",
                        examples=[line.strip()]
                    ))
                
                elif 'EVALUATE' in line.upper():
                    self.detected_patterns.append(DetectedPattern(
                        name="Uso de EVALUATE",
                        type=PatternType.GOOD_PRACTICE,
                        description="Uso de estrutura de decisão múltipla estruturada",
                        location=f"Linha {line_num}",
                        line_number=line_num,
                        confidence=0.9,
                        impact="MEDIUM",
                        suggestion="EVALUATE é mais legível que múltiplos IFs aninhados",
                        examples=[line.strip()]
                    ))
    
    def _detect_modular_design_patterns(self):
        """Detecta padrões de design modular."""
        # Analisa uso de COPY BOOKS
        copy_usage_count = 0
        lines = self.program.raw_content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            if self.patterns['copy_usage'].search(line):
                copy_usage_count += 1
        
        if copy_usage_count > 0:
            self.detected_patterns.append(DetectedPattern(
                name="Uso de COPY BOOKS",
                type=PatternType.DESIGN_PATTERN,
                description=f"Uso de {copy_usage_count} COPY BOOKS para reutilização",
                location="Programa geral",
                line_number=1,
                confidence=0.9,
                impact="HIGH",
                suggestion="COPY BOOKS promovem reutilização e manutenibilidade",
            ))
        
        # Analisa organização de parágrafos
        paragraph_count = len(self.program.paragraphs)
        for section in self.program.sections:
            paragraph_count += len(section.paragraphs)
        
        if paragraph_count > 5:
            avg_lines_per_paragraph = len(lines) / paragraph_count
            if avg_lines_per_paragraph < 30:
                self.detected_patterns.append(DetectedPattern(
                    name="Modularização Adequada",
                    type=PatternType.DESIGN_PATTERN,
                    description=f"Boa modularização com {paragraph_count} parágrafos",
                    location="Programa geral",
                    line_number=1,
                    confidence=0.8,
                    impact="MEDIUM",
                    suggestion="Parágrafos pequenos facilitam manutenção e teste"
                ))
    
    def _detect_naming_conventions(self):
        """Detecta padrões de convenção de nomenclatura."""
        consistent_naming = 0
        total_variables = len(self.program.variables)
        
        # Analisa consistência de nomenclatura de variáveis
        for var in self.program.variables:
            if self.patterns['consistent_naming'].match(var.name):
                consistent_naming += 1
        
        if total_variables > 0:
            consistency_ratio = consistent_naming / total_variables
            if consistency_ratio > 0.9:
                self.detected_patterns.append(DetectedPattern(
                    name="Nomenclatura Consistente",
                    type=PatternType.GOOD_PRACTICE,
                    description=f"Alta consistência na nomenclatura ({consistency_ratio:.1%})",
                    location="Programa geral",
                    line_number=1,
                    confidence=0.9,
                    impact="MEDIUM",
                    suggestion="Mantenha padrões de nomenclatura consistentes"
                ))
        
        # Detecta uso de prefixos organizacionais
        ws_variables = sum(1 for var in self.program.variables if var.name.startswith('WS-'))
        if ws_variables > total_variables * 0.5:
            self.detected_patterns.append(DetectedPattern(
                name="Uso de Prefixos Organizacionais",
                type=PatternType.GOOD_PRACTICE,
                description="Uso consistente de prefixos WS- para Working Storage",
                location="Working Storage Section",
                line_number=1,
                confidence=0.8,
                impact="MEDIUM",
                suggestion="Prefixos ajudam na organização e identificação de variáveis"
            ))
    
    def _detect_initialization_patterns(self):
        """Detecta padrões de inicialização."""
        lines = self.program.raw_content.split('\n')
        initialization_count = 0
        
        for line_num, line in enumerate(lines, 1):
            if self.patterns['initialization'].search(line):
                initialization_count += 1
                
                if 'INITIALIZE' in line.upper():
                    self.detected_patterns.append(DetectedPattern(
                        name="Uso de INITIALIZE",
                        type=PatternType.GOOD_PRACTICE,
                        description="Uso de INITIALIZE para inicialização segura",
                        location=f"Linha {line_num}",
                        line_number=line_num,
                        confidence=0.9,
                        impact="MEDIUM",
                        suggestion="INITIALIZE é mais seguro que MOVE para estruturas complexas",
                        examples=[line.strip()]
                    ))
        
        if initialization_count > 3:
            self.detected_patterns.append(DetectedPattern(
                name="Inicialização Adequada de Variáveis",
                type=PatternType.GOOD_PRACTICE,
                description=f"Boa prática de inicialização ({initialization_count} ocorrências)",
                location="Programa geral",
                line_number=1,
                confidence=0.8,
                impact="MEDIUM",
                suggestion="Inicialização adequada previne erros de dados não definidos"
            ))
    
    def _detect_goto_antipatterns(self):
        """Detecta anti-padrões relacionados a GO TO."""
        lines = self.program.raw_content.split('\n')
        goto_count = 0
        
        for line_num, line in enumerate(lines, 1):
            if self.patterns['goto_usage'].search(line):
                goto_count += 1
                
                self.detected_patterns.append(DetectedPattern(
                    name="Uso de GO TO",
                    type=PatternType.ANTI_PATTERN,
                    description="Uso de GO TO pode prejudicar legibilidade",
                    location=f"Linha {line_num}",
                    line_number=line_num,
                    confidence=0.7,
                    impact="MEDIUM",
                    suggestion="Considere usar PERFORM para melhor estruturação",
                    examples=[line.strip()]
                ))
        
        if goto_count > 5:
            self.detected_patterns.append(DetectedPattern(
                name="Uso Excessivo de GO TO",
                type=PatternType.ANTI_PATTERN,
                description=f"Uso excessivo de GO TO ({goto_count} ocorrências)",
                location="Programa geral",
                line_number=1,
                confidence=0.9,
                impact="HIGH",
                suggestion="Refatore usando programação estruturada com PERFORM"
            ))
    
    def _detect_magic_number_antipatterns(self):
        """Detecta anti-padrões de números mágicos."""
        lines = self.program.raw_content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            magic_numbers = self.patterns['magic_numbers'].findall(line)
            for number in magic_numbers:
                # Ignora números comuns que não são considerados mágicos
                if number not in ['100', '999', '000']:
                    self.detected_patterns.append(DetectedPattern(
                        name="Número Mágico",
                        type=PatternType.ANTI_PATTERN,
                        description=f"Número mágico '{number}' sem contexto claro",
                        location=f"Linha {line_num}",
                        line_number=line_num,
                        confidence=0.6,
                        impact="LOW",
                        suggestion="Use constantes nomeadas para melhor legibilidade",
                        examples=[line.strip()]
                    ))
    
    def _detect_hardcoded_value_antipatterns(self):
        """Detecta anti-padrões de valores hardcoded."""
        lines = self.program.raw_content.split('\n')
        
        for line_num, line in enumerate(lines, 1):
            hardcoded_values = self.patterns['hardcoded_values'].findall(line)
            for value in hardcoded_values:
                self.detected_patterns.append(DetectedPattern(
                    name="Valor Hardcoded",
                    type=PatternType.MAINTAINABILITY_ISSUE,
                    description=f"Valor hardcoded longo: {value[:20]}...",
                    location=f"Linha {line_num}",
                    line_number=line_num,
                    confidence=0.8,
                    impact="MEDIUM",
                    suggestion="Considere usar variáveis ou COPY BOOKS para valores constantes",
                    examples=[line.strip()]
                ))
    
    def _detect_performance_antipatterns(self):
        """Detecta anti-padrões de performance."""
        lines = self.program.raw_content.split('\n')
        
        # Detecta PERFORM THRU que pode ser ineficiente
        for line_num, line in enumerate(lines, 1):
            if self.patterns['perform_thru'].search(line):
                self.detected_patterns.append(DetectedPattern(
                    name="PERFORM THRU",
                    type=PatternType.PERFORMANCE_ISSUE,
                    description="PERFORM THRU pode ser menos eficiente que PERFORM simples",
                    location=f"Linha {line_num}",
                    line_number=line_num,
                    confidence=0.6,
                    impact="LOW",
                    suggestion="Considere usar PERFORM simples quando possível",
                    examples=[line.strip()]
                ))
        
        # Detecta loops aninhados potencialmente ineficientes
        nested_perform_depth = 0
        max_nested_depth = 0
        
        for line in lines:
            if 'PERFORM' in line.upper() and ('UNTIL' in line.upper() or 'VARYING' in line.upper()):
                nested_perform_depth += 1
                max_nested_depth = max(max_nested_depth, nested_perform_depth)
            elif 'END-PERFORM' in line.upper():
                nested_perform_depth = max(0, nested_perform_depth - 1)
        
        if max_nested_depth > 2:
            self.detected_patterns.append(DetectedPattern(
                name="Loops Aninhados Profundos",
                type=PatternType.PERFORMANCE_ISSUE,
                description=f"Loops aninhados com profundidade {max_nested_depth}",
                location="Programa geral",
                line_number=1,
                confidence=0.8,
                impact="MEDIUM",
                suggestion="Considere otimizar algoritmos com muitos loops aninhados"
            ))
    
    def _detect_maintainability_antipatterns(self):
        """Detecta anti-padrões de manutenibilidade."""
        # Detecta parágrafos muito longos
        all_paragraphs = self.program.paragraphs.copy()
        for section in self.program.sections:
            all_paragraphs.extend(section.paragraphs)
        
        for paragraph in all_paragraphs:
            if len(paragraph.content) > 50:
                self.detected_patterns.append(DetectedPattern(
                    name="Parágrafo Muito Longo",
                    type=PatternType.MAINTAINABILITY_ISSUE,
                    description=f"Parágrafo {paragraph.name} com {len(paragraph.content)} linhas",
                    location=paragraph.name,
                    line_number=paragraph.line_number,
                    confidence=0.9,
                    impact="MEDIUM",
                    suggestion="Divida em parágrafos menores para melhor manutenibilidade"
                ))
        
        # Detecta falta de comentários
        lines = self.program.raw_content.split('\n')
        comment_lines = sum(1 for line in lines if len(line) > 6 and line[6] == '*')
        code_lines = len([line for line in lines if line.strip() and not (len(line) > 6 and line[6] == '*')])
        
        if code_lines > 0:
            comment_ratio = comment_lines / code_lines
            if comment_ratio < 0.1:  # Menos de 10% de comentários
                self.detected_patterns.append(DetectedPattern(
                    name="Documentação Insuficiente",
                    type=PatternType.MAINTAINABILITY_ISSUE,
                    description=f"Baixa proporção de comentários ({comment_ratio:.1%})",
                    location="Programa geral",
                    line_number=1,
                    confidence=0.8,
                    impact="MEDIUM",
                    suggestion="Adicione mais comentários para facilitar manutenção"
                ))
    
    def _categorize_patterns(self) -> Dict[str, List[DetectedPattern]]:
        """Categoriza os padrões detectados."""
        categorized = {
            'good_practices': [],
            'anti_patterns': [],
            'design_patterns': [],
            'performance_issues': [],
            'maintainability_issues': []
        }
        
        for pattern in self.detected_patterns:
            if pattern.type == PatternType.GOOD_PRACTICE:
                categorized['good_practices'].append(pattern)
            elif pattern.type == PatternType.ANTI_PATTERN:
                categorized['anti_patterns'].append(pattern)
            elif pattern.type == PatternType.DESIGN_PATTERN:
                categorized['design_patterns'].append(pattern)
            elif pattern.type == PatternType.PERFORMANCE_ISSUE:
                categorized['performance_issues'].append(pattern)
            elif pattern.type == PatternType.MAINTAINABILITY_ISSUE:
                categorized['maintainability_issues'].append(pattern)
        
        return categorized
    
    def generate_pattern_report(self) -> Dict[str, any]:
        """
        Gera um relatório completo de padrões.
        
        Returns:
            Dicionário com relatório de padrões
        """
        patterns = self.detect_patterns()
        
        # Calcula estatísticas
        total_patterns = sum(len(pattern_list) for pattern_list in patterns.values())
        high_impact_patterns = sum(
            1 for pattern_list in patterns.values() 
            for pattern in pattern_list 
            if pattern.impact == "HIGH"
        )
        
        # Calcula pontuação de qualidade
        good_practices_count = len(patterns['good_practices'])
        issues_count = (
            len(patterns['anti_patterns']) + 
            len(patterns['performance_issues']) + 
            len(patterns['maintainability_issues'])
        )
        
        quality_score = max(0, min(100, 50 + (good_practices_count * 10) - (issues_count * 5)))
        
        return {
            'summary': {
                'total_patterns_detected': total_patterns,
                'good_practices': len(patterns['good_practices']),
                'anti_patterns': len(patterns['anti_patterns']),
                'design_patterns': len(patterns['design_patterns']),
                'performance_issues': len(patterns['performance_issues']),
                'maintainability_issues': len(patterns['maintainability_issues']),
                'high_impact_patterns': high_impact_patterns,
                'quality_score': quality_score
            },
            'patterns': {
                category: [
                    {
                        'name': pattern.name,
                        'type': pattern.type.value,
                        'description': pattern.description,
                        'location': pattern.location,
                        'line_number': pattern.line_number,
                        'confidence': pattern.confidence,
                        'impact': pattern.impact,
                        'suggestion': pattern.suggestion,
                        'examples': pattern.examples
                    }
                    for pattern in pattern_list
                ]
                for category, pattern_list in patterns.items()
            },
            'recommendations': self._generate_recommendations(patterns, quality_score)
        }
    
    def _generate_recommendations(self, patterns: Dict[str, List[DetectedPattern]], 
                                quality_score: int) -> List[str]:
        """Gera recomendações baseadas nos padrões detectados."""
        recommendations = []
        
        if quality_score < 50:
            recommendations.append("Qualidade do código precisa de atenção significativa")
        elif quality_score < 70:
            recommendations.append("Qualidade do código pode ser melhorada")
        else:
            recommendations.append("Boa qualidade geral do código")
        
        # Recomendações específicas por categoria
        if len(patterns['anti_patterns']) > 5:
            recommendations.append("Refatore anti-padrões para melhorar manutenibilidade")
        
        if len(patterns['performance_issues']) > 3:
            recommendations.append("Revise questões de performance identificadas")
        
        if len(patterns['maintainability_issues']) > 3:
            recommendations.append("Melhore documentação e estruturação do código")
        
        if len(patterns['good_practices']) > 10:
            recommendations.append("Continue seguindo as boas práticas identificadas")
        
        return recommendations

