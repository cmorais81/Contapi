"""
Sistema de plugins extensível para o motor de documentação COBOL.
"""

import os
import importlib
import inspect
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Type, Callable
from dataclasses import dataclass
from enum import Enum
import json
import yaml

from cobol_parser import CobolProgram


class PluginType(Enum):
    """Tipos de plugins suportados."""
    ANALYZER = "analyzer"
    FORMATTER = "formatter"
    EXPORTER = "exporter"
    VALIDATOR = "validator"
    TRANSFORMER = "transformer"
    REPORTER = "reporter"


class PluginPriority(Enum):
    """Prioridades de execução de plugins."""
    HIGHEST = 1
    HIGH = 2
    NORMAL = 3
    LOW = 4
    LOWEST = 5


@dataclass
class PluginMetadata:
    """Metadados de um plugin."""
    name: str
    version: str
    description: str
    author: str
    plugin_type: PluginType
    priority: PluginPriority = PluginPriority.NORMAL
    dependencies: List[str] = None
    config_schema: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.dependencies is None:
            self.dependencies = []
        if self.config_schema is None:
            self.config_schema = {}


@dataclass
class PluginResult:
    """Resultado da execução de um plugin."""
    plugin_name: str
    success: bool
    data: Any = None
    error: str = None
    execution_time: float = 0.0
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class PluginInterface(ABC):
    """Interface base para todos os plugins."""
    
    @property
    @abstractmethod
    def metadata(self) -> PluginMetadata:
        """Retorna metadados do plugin."""
        pass
    
    @abstractmethod
    def initialize(self, config: Dict[str, Any]) -> bool:
        """
        Inicializa o plugin com configuração.
        
        Args:
            config: Configuração do plugin
            
        Returns:
            True se inicialização foi bem-sucedida
        """
        pass
    
    @abstractmethod
    def execute(self, program: CobolProgram, context: Dict[str, Any]) -> PluginResult:
        """
        Executa o plugin.
        
        Args:
            program: Programa COBOL
            context: Contexto de execução
            
        Returns:
            Resultado da execução
        """
        pass
    
    def validate_config(self, config: Dict[str, Any]) -> bool:
        """
        Valida configuração do plugin.
        
        Args:
            config: Configuração a ser validada
            
        Returns:
            True se configuração é válida
        """
        return True
    
    def cleanup(self):
        """Limpa recursos do plugin."""
        pass


class AnalyzerPlugin(PluginInterface):
    """Plugin base para análise de código."""
    
    @abstractmethod
    def analyze(self, program: CobolProgram) -> Dict[str, Any]:
        """
        Analisa programa COBOL.
        
        Args:
            program: Programa COBOL
            
        Returns:
            Resultado da análise
        """
        pass
    
    def execute(self, program: CobolProgram, context: Dict[str, Any]) -> PluginResult:
        """Implementação padrão de execute para analyzers."""
        try:
            import time
            start_time = time.time()
            
            result = self.analyze(program)
            
            execution_time = time.time() - start_time
            
            return PluginResult(
                plugin_name=self.metadata.name,
                success=True,
                data=result,
                execution_time=execution_time
            )
            
        except Exception as e:
            return PluginResult(
                plugin_name=self.metadata.name,
                success=False,
                error=str(e)
            )


class FormatterPlugin(PluginInterface):
    """Plugin base para formatação de saída."""
    
    @abstractmethod
    def format(self, data: Any, format_options: Dict[str, Any]) -> str:
        """
        Formata dados para saída.
        
        Args:
            data: Dados a serem formatados
            format_options: Opções de formatação
            
        Returns:
            Dados formatados
        """
        pass
    
    def execute(self, program: CobolProgram, context: Dict[str, Any]) -> PluginResult:
        """Implementação padrão de execute para formatters."""
        try:
            import time
            start_time = time.time()
            
            data = context.get('data')
            format_options = context.get('format_options', {})
            
            result = self.format(data, format_options)
            
            execution_time = time.time() - start_time
            
            return PluginResult(
                plugin_name=self.metadata.name,
                success=True,
                data=result,
                execution_time=execution_time
            )
            
        except Exception as e:
            return PluginResult(
                plugin_name=self.metadata.name,
                success=False,
                error=str(e)
            )


class ExporterPlugin(PluginInterface):
    """Plugin base para exportação de dados."""
    
    @abstractmethod
    def export(self, data: Any, output_path: str, export_options: Dict[str, Any]) -> bool:
        """
        Exporta dados para arquivo.
        
        Args:
            data: Dados a serem exportados
            output_path: Caminho de saída
            export_options: Opções de exportação
            
        Returns:
            True se exportação foi bem-sucedida
        """
        pass
    
    def execute(self, program: CobolProgram, context: Dict[str, Any]) -> PluginResult:
        """Implementação padrão de execute para exporters."""
        try:
            import time
            start_time = time.time()
            
            data = context.get('data')
            output_path = context.get('output_path')
            export_options = context.get('export_options', {})
            
            success = self.export(data, output_path, export_options)
            
            execution_time = time.time() - start_time
            
            return PluginResult(
                plugin_name=self.metadata.name,
                success=success,
                data={'exported': success, 'path': output_path},
                execution_time=execution_time
            )
            
        except Exception as e:
            return PluginResult(
                plugin_name=self.metadata.name,
                success=False,
                error=str(e)
            )


class PluginManager:
    """Gerenciador de plugins."""
    
    def __init__(self, plugins_dir: str = None):
        """
        Inicializa gerenciador de plugins.
        
        Args:
            plugins_dir: Diretório de plugins
        """
        self.plugins_dir = plugins_dir or os.path.join(os.path.dirname(__file__), '..', 'plugins')
        self.plugins: Dict[str, PluginInterface] = {}
        self.plugin_configs: Dict[str, Dict[str, Any]] = {}
        self.execution_order: Dict[PluginType, List[str]] = {}
        
        # Cria diretório de plugins se não existir
        os.makedirs(self.plugins_dir, exist_ok=True)
        
        # Inicializa ordem de execução
        for plugin_type in PluginType:
            self.execution_order[plugin_type] = []
    
    def discover_plugins(self) -> List[str]:
        """
        Descobre plugins disponíveis no diretório.
        
        Returns:
            Lista de nomes de plugins descobertos
        """
        discovered = []
        
        if not os.path.exists(self.plugins_dir):
            return discovered
        
        for item in os.listdir(self.plugins_dir):
            plugin_path = os.path.join(self.plugins_dir, item)
            
            # Verifica se é um arquivo Python
            if item.endswith('.py') and not item.startswith('__'):
                plugin_name = item[:-3]  # Remove .py
                discovered.append(plugin_name)
            
            # Verifica se é um diretório com __init__.py
            elif os.path.isdir(plugin_path) and os.path.exists(os.path.join(plugin_path, '__init__.py')):
                discovered.append(item)
        
        return discovered
    
    def load_plugin(self, plugin_name: str, config: Dict[str, Any] = None) -> bool:
        """
        Carrega um plugin.
        
        Args:
            plugin_name: Nome do plugin
            config: Configuração do plugin
            
        Returns:
            True se plugin foi carregado com sucesso
        """
        try:
            # Adiciona diretório de plugins ao path
            import sys
            if self.plugins_dir not in sys.path:
                sys.path.insert(0, self.plugins_dir)
            
            # Importa módulo do plugin
            module = importlib.import_module(plugin_name)
            
            # Procura classe que implementa PluginInterface
            plugin_class = None
            for name, obj in inspect.getmembers(module):
                if (inspect.isclass(obj) and 
                    issubclass(obj, PluginInterface) and 
                    obj != PluginInterface and
                    not inspect.isabstract(obj)):
                    plugin_class = obj
                    break
            
            if not plugin_class:
                raise ValueError(f"Nenhuma classe de plugin válida encontrada em {plugin_name}")
            
            # Instancia plugin
            plugin_instance = plugin_class()
            
            # Valida e aplica configuração
            if config is None:
                config = {}
            
            if not plugin_instance.validate_config(config):
                raise ValueError(f"Configuração inválida para plugin {plugin_name}")
            
            if not plugin_instance.initialize(config):
                raise ValueError(f"Falha na inicialização do plugin {plugin_name}")
            
            # Registra plugin
            self.plugins[plugin_name] = plugin_instance
            self.plugin_configs[plugin_name] = config
            
            # Adiciona à ordem de execução
            plugin_type = plugin_instance.metadata.plugin_type
            if plugin_name not in self.execution_order[plugin_type]:
                self.execution_order[plugin_type].append(plugin_name)
                # Ordena por prioridade
                self.execution_order[plugin_type].sort(
                    key=lambda x: self.plugins[x].metadata.priority.value
                )
            
            return True
            
        except Exception as e:
            print(f"Erro ao carregar plugin {plugin_name}: {str(e)}")
            return False
    
    def unload_plugin(self, plugin_name: str) -> bool:
        """
        Descarrega um plugin.
        
        Args:
            plugin_name: Nome do plugin
            
        Returns:
            True se plugin foi descarregado com sucesso
        """
        try:
            if plugin_name in self.plugins:
                plugin = self.plugins[plugin_name]
                plugin.cleanup()
                
                # Remove da ordem de execução
                plugin_type = plugin.metadata.plugin_type
                if plugin_name in self.execution_order[plugin_type]:
                    self.execution_order[plugin_type].remove(plugin_name)
                
                # Remove registros
                del self.plugins[plugin_name]
                if plugin_name in self.plugin_configs:
                    del self.plugin_configs[plugin_name]
                
                return True
            
            return False
            
        except Exception as e:
            print(f"Erro ao descarregar plugin {plugin_name}: {str(e)}")
            return False
    
    def execute_plugins(self, plugin_type: PluginType, program: CobolProgram, 
                       context: Dict[str, Any] = None) -> List[PluginResult]:
        """
        Executa plugins de um tipo específico.
        
        Args:
            plugin_type: Tipo de plugin
            program: Programa COBOL
            context: Contexto de execução
            
        Returns:
            Lista de resultados dos plugins
        """
        if context is None:
            context = {}
        
        results = []
        
        for plugin_name in self.execution_order[plugin_type]:
            if plugin_name in self.plugins:
                plugin = self.plugins[plugin_name]
                result = plugin.execute(program, context)
                results.append(result)
                
                # Adiciona resultado ao contexto para próximos plugins
                context[f'{plugin_name}_result'] = result
        
        return results
    
    def get_plugin_info(self, plugin_name: str) -> Optional[PluginMetadata]:
        """
        Retorna informações de um plugin.
        
        Args:
            plugin_name: Nome do plugin
            
        Returns:
            Metadados do plugin ou None se não encontrado
        """
        if plugin_name in self.plugins:
            return self.plugins[plugin_name].metadata
        return None
    
    def list_plugins(self, plugin_type: PluginType = None) -> List[str]:
        """
        Lista plugins carregados.
        
        Args:
            plugin_type: Tipo de plugin (opcional)
            
        Returns:
            Lista de nomes de plugins
        """
        if plugin_type is None:
            return list(self.plugins.keys())
        
        return [name for name, plugin in self.plugins.items() 
                if plugin.metadata.plugin_type == plugin_type]
    
    def load_plugins_from_config(self, config_path: str) -> int:
        """
        Carrega plugins a partir de arquivo de configuração.
        
        Args:
            config_path: Caminho para arquivo de configuração
            
        Returns:
            Número de plugins carregados com sucesso
        """
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                if config_path.endswith('.yaml') or config_path.endswith('.yml'):
                    config = yaml.safe_load(f)
                else:
                    config = json.load(f)
            
            loaded_count = 0
            plugins_config = config.get('plugins', {})
            
            for plugin_name, plugin_config in plugins_config.items():
                if self.load_plugin(plugin_name, plugin_config):
                    loaded_count += 1
            
            return loaded_count
            
        except Exception as e:
            print(f"Erro ao carregar configuração de plugins: {str(e)}")
            return 0
    
    def save_plugins_config(self, config_path: str) -> bool:
        """
        Salva configuração atual dos plugins.
        
        Args:
            config_path: Caminho para arquivo de configuração
            
        Returns:
            True se salvou com sucesso
        """
        try:
            config = {
                'plugins': self.plugin_configs
            }
            
            with open(config_path, 'w', encoding='utf-8') as f:
                if config_path.endswith('.yaml') or config_path.endswith('.yml'):
                    yaml.dump(config, f, default_flow_style=False)
                else:
                    json.dump(config, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Erro ao salvar configuração de plugins: {str(e)}")
            return False
    
    def validate_dependencies(self) -> Dict[str, List[str]]:
        """
        Valida dependências entre plugins.
        
        Returns:
            Dicionário com plugins e suas dependências não atendidas
        """
        missing_dependencies = {}
        
        for plugin_name, plugin in self.plugins.items():
            missing = []
            for dependency in plugin.metadata.dependencies:
                if dependency not in self.plugins:
                    missing.append(dependency)
            
            if missing:
                missing_dependencies[plugin_name] = missing
        
        return missing_dependencies
    
    def get_execution_stats(self) -> Dict[str, Any]:
        """
        Retorna estatísticas de execução dos plugins.
        
        Returns:
            Estatísticas de execução
        """
        stats = {
            'total_plugins': len(self.plugins),
            'plugins_by_type': {},
            'plugins_by_priority': {}
        }
        
        for plugin_name, plugin in self.plugins.items():
            plugin_type = plugin.metadata.plugin_type.value
            priority = plugin.metadata.priority.value
            
            if plugin_type not in stats['plugins_by_type']:
                stats['plugins_by_type'][plugin_type] = 0
            stats['plugins_by_type'][plugin_type] += 1
            
            if priority not in stats['plugins_by_priority']:
                stats['plugins_by_priority'][priority] = 0
            stats['plugins_by_priority'][priority] += 1
        
        return stats


class PluginRegistry:
    """Registro global de plugins disponíveis."""
    
    def __init__(self):
        self.available_plugins: Dict[str, Dict[str, Any]] = {}
    
    def register_plugin(self, plugin_info: Dict[str, Any]):
        """
        Registra informações de um plugin.
        
        Args:
            plugin_info: Informações do plugin
        """
        plugin_name = plugin_info.get('name')
        if plugin_name:
            self.available_plugins[plugin_name] = plugin_info
    
    def get_available_plugins(self) -> Dict[str, Dict[str, Any]]:
        """
        Retorna plugins disponíveis.
        
        Returns:
            Dicionário com plugins disponíveis
        """
        return self.available_plugins.copy()
    
    def search_plugins(self, plugin_type: PluginType = None, 
                      keyword: str = None) -> List[Dict[str, Any]]:
        """
        Busca plugins por critérios.
        
        Args:
            plugin_type: Tipo de plugin
            keyword: Palavra-chave para busca
            
        Returns:
            Lista de plugins que atendem aos critérios
        """
        results = []
        
        for plugin_name, plugin_info in self.available_plugins.items():
            # Filtra por tipo
            if plugin_type and plugin_info.get('type') != plugin_type.value:
                continue
            
            # Filtra por palavra-chave
            if keyword:
                keyword_lower = keyword.lower()
                if (keyword_lower not in plugin_name.lower() and
                    keyword_lower not in plugin_info.get('description', '').lower()):
                    continue
            
            results.append(plugin_info)
        
        return results


# Instância global do registro
plugin_registry = PluginRegistry()

