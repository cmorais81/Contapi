"""
Integração com API do Copilot/OpenAI para análise de código COBOL.
"""

import os
import time
import json
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import openai
from openai import OpenAI


@dataclass
class AnalysisRequest:
    """Representa uma solicitação de análise de código COBOL."""
    code_content: str
    program_summary: Dict
    analysis_type: str = "full"  # full, summary, variables, logic
    language: str = "pt-br"


@dataclass
class AnalysisResponse:
    """Representa a resposta da análise de código COBOL."""
    program_purpose: str
    main_functionality: str
    variables_description: Dict[str, str]
    business_logic_explanation: str
    input_output_description: str
    execution_flow: List[str]
    recommendations: List[str]
    complexity_assessment: str
    raw_response: str


class CopilotIntegration:
    """Classe para integração com API do Copilot/OpenAI."""
    
    def __init__(self, api_key: Optional[str] = None, model: str = "gpt-4", 
                 max_tokens: int = 4000, temperature: float = 0.3):
        """
        Inicializa a integração com OpenAI.
        
        Args:
            api_key: Chave da API OpenAI (se None, usa variável de ambiente)
            model: Modelo a ser usado
            max_tokens: Número máximo de tokens na resposta
            temperature: Temperatura para geração de texto
        """
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature
        
        if not self.api_key:
            raise ValueError("API key do OpenAI não encontrada. Configure OPENAI_API_KEY ou passe como parâmetro.")
        
        # Configura cliente OpenAI
        self.client = OpenAI(
            api_key=self.api_key,
            base_url=os.getenv('OPENAI_API_BASE', 'https://api.openai.com/v1')
        )
        
        # Templates de prompts
        self.prompts = {
            'full_analysis': self._get_full_analysis_prompt(),
            'summary_analysis': self._get_summary_analysis_prompt(),
            'variables_analysis': self._get_variables_analysis_prompt(),
            'logic_analysis': self._get_logic_analysis_prompt()
        }
    
    def analyze_cobol_program(self, request: AnalysisRequest) -> AnalysisResponse:
        """
        Analisa um programa COBOL usando a API do OpenAI.
        
        Args:
            request: Solicitação de análise
            
        Returns:
            AnalysisResponse: Resposta da análise
        """
        try:
            # Seleciona o prompt apropriado
            prompt_template = self.prompts.get(f'{request.analysis_type}_analysis', 
                                             self.prompts['full_analysis'])
            
            # Prepara o prompt com os dados do programa
            prompt = self._prepare_prompt(prompt_template, request)
            
            # Faz a chamada para a API
            response = self._call_openai_api(prompt)
            
            # Processa a resposta
            analysis_response = self._process_api_response(response, request.language)
            
            return analysis_response
            
        except Exception as e:
            raise Exception(f"Erro na análise do programa COBOL: {str(e)}")
    
    def _call_openai_api(self, prompt: str, max_retries: int = 3) -> str:
        """
        Faz chamada para a API OpenAI com retry automático.
        
        Args:
            prompt: Prompt para enviar
            max_retries: Número máximo de tentativas
            
        Returns:
            str: Resposta da API
        """
        for attempt in range(max_retries):
            try:
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {
                            "role": "system",
                            "content": "Você é um especialista em análise de código COBOL e documentação técnica. "
                                     "Forneça análises detalhadas, precisas e bem estruturadas."
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    max_tokens=self.max_tokens,
                    temperature=self.temperature
                )
                
                return response.choices[0].message.content
                
            except openai.RateLimitError:
                if attempt < max_retries - 1:
                    wait_time = 2 ** attempt  # Backoff exponencial
                    time.sleep(wait_time)
                    continue
                else:
                    raise Exception("Limite de rate da API excedido após múltiplas tentativas")
                    
            except openai.APIError as e:
                raise Exception(f"Erro na API OpenAI: {str(e)}")
                
            except Exception as e:
                raise Exception(f"Erro inesperado na chamada da API: {str(e)}")
    
    def _prepare_prompt(self, template: str, request: AnalysisRequest) -> str:
        """
        Prepara o prompt substituindo variáveis do template.
        
        Args:
            template: Template do prompt
            request: Dados da solicitação
            
        Returns:
            str: Prompt preparado
        """
        # Converte summary para string formatada
        summary_text = self._format_program_summary(request.program_summary)
        
        # Substitui variáveis no template
        prompt = template.format(
            code_content=request.code_content,
            program_summary=summary_text,
            language=request.language
        )
        
        return prompt
    
    def _format_program_summary(self, summary: Dict) -> str:
        """
        Formata o resumo do programa para inclusão no prompt.
        
        Args:
            summary: Dicionário com resumo do programa
            
        Returns:
            str: Resumo formatado
        """
        formatted = []
        formatted.append(f"Program ID: {summary.get('program_id', 'N/A')}")
        formatted.append(f"Author: {summary.get('author', 'N/A')}")
        formatted.append(f"Date Written: {summary.get('date_written', 'N/A')}")
        formatted.append(f"Total Variables: {summary.get('total_variables', 0)}")
        formatted.append(f"Total Sections: {summary.get('total_sections', 0)}")
        formatted.append(f"Total Paragraphs: {summary.get('total_paragraphs', 0)}")
        
        if summary.get('main_sections'):
            formatted.append(f"Main Sections: {', '.join(summary['main_sections'])}")
        
        if summary.get('main_paragraphs'):
            formatted.append(f"Main Paragraphs: {', '.join(summary['main_paragraphs'][:5])}")
        
        return "\\n".join(formatted)
    
    def _process_api_response(self, response: str, language: str) -> AnalysisResponse:
        """
        Processa a resposta da API e extrai informações estruturadas.
        
        Args:
            response: Resposta bruta da API
            language: Idioma da análise
            
        Returns:
            AnalysisResponse: Resposta estruturada
        """
        # Tenta extrair informações estruturadas da resposta
        try:
            # Procura por seções específicas na resposta
            sections = self._extract_response_sections(response)
            
            return AnalysisResponse(
                program_purpose=sections.get('purpose', 'Não identificado'),
                main_functionality=sections.get('functionality', 'Não identificado'),
                variables_description=sections.get('variables', {}),
                business_logic_explanation=sections.get('logic', 'Não identificado'),
                input_output_description=sections.get('input_output', 'Não identificado'),
                execution_flow=sections.get('flow', []),
                recommendations=sections.get('recommendations', []),
                complexity_assessment=sections.get('complexity', 'Não avaliado'),
                raw_response=response
            )
            
        except Exception as e:
            # Se falhar na extração estruturada, retorna resposta básica
            return AnalysisResponse(
                program_purpose="Análise disponível na resposta completa",
                main_functionality="Análise disponível na resposta completa",
                variables_description={},
                business_logic_explanation="Análise disponível na resposta completa",
                input_output_description="Análise disponível na resposta completa",
                execution_flow=[],
                recommendations=[],
                complexity_assessment="Não avaliado",
                raw_response=response
            )
    
    def _extract_response_sections(self, response: str) -> Dict[str, Any]:
        """
        Extrai seções específicas da resposta da API.
        
        Args:
            response: Resposta da API
            
        Returns:
            Dict: Seções extraídas
        """
        sections = {}
        
        # Padrões para identificar seções
        patterns = {
            'purpose': ['propósito', 'objetivo', 'finalidade', 'purpose'],
            'functionality': ['funcionalidade', 'função', 'functionality', 'funcionalidades'],
            'logic': ['lógica', 'logic', 'negócio', 'business'],
            'input_output': ['entrada', 'saída', 'input', 'output', 'i/o'],
            'complexity': ['complexidade', 'complexity'],
        }
        
        lines = response.split('\n')
        current_section = None
        current_content = []
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
                
            # Verifica se a linha indica uma nova seção
            line_lower = line.lower()
            section_found = False
            
            for section_key, keywords in patterns.items():
                if any(keyword in line_lower for keyword in keywords):
                    # Salva seção anterior se existir
                    if current_section and current_content:
                        sections[current_section] = '\n'.join(current_content)
                    
                    current_section = section_key
                    current_content = []
                    section_found = True
                    
                    # Se a linha tem conteúdo além do cabeçalho, adiciona
                    if ':' in line:
                        content_after_colon = line.split(':', 1)[1].strip()
                        if content_after_colon:
                            current_content.append(content_after_colon)
                    break
            
            # Se não é cabeçalho de seção, adiciona ao conteúdo atual
            if not section_found and current_section:
                current_content.append(line)
        
        # Adiciona a última seção
        if current_section and current_content:
            sections[current_section] = '\n'.join(current_content)
        
        return sections
    
    def _get_full_analysis_prompt(self) -> str:
        """Retorna o template de prompt para análise completa."""
        return """
Analise o seguinte programa COBOL e forneça uma documentação completa e detalhada em {language}.

RESUMO DO PROGRAMA:
{program_summary}

CÓDIGO COBOL:
{code_content}

Por favor, forneça uma análise estruturada incluindo:

1. PROPÓSITO DO PROGRAMA:
   - Qual é o objetivo principal deste programa?
   - Que problema ele resolve?

2. FUNCIONALIDADES PRINCIPAIS:
   - Quais são as principais operações realizadas?
   - Como o programa processa os dados?

3. DESCRIÇÃO DAS VARIÁVEIS:
   - Liste e explique as principais variáveis e suas funções
   - Identifique estruturas de dados importantes

4. LÓGICA DE NEGÓCIO:
   - Explique a lógica principal do programa
   - Identifique regras de negócio implementadas

5. ENTRADA E SAÍDA:
   - Que tipos de dados o programa recebe?
   - Que tipos de dados o programa produz?

6. FLUXO DE EXECUÇÃO:
   - Descreva o fluxo principal de execução
   - Identifique pontos de decisão importantes

7. AVALIAÇÃO DE COMPLEXIDADE:
   - Avalie a complexidade do código (baixa/média/alta)
   - Identifique possíveis pontos de melhoria

8. RECOMENDAÇÕES:
   - Sugestões para documentação adicional
   - Possíveis melhorias ou modernizações

Forneça uma análise clara, detalhada e bem estruturada.
"""
    
    def _get_summary_analysis_prompt(self) -> str:
        """Retorna o template de prompt para análise resumida."""
        return """
Analise o seguinte programa COBOL e forneça um resumo conciso em {language}.

RESUMO DO PROGRAMA:
{program_summary}

CÓDIGO COBOL:
{code_content}

Forneça um resumo incluindo:
1. Propósito principal do programa
2. Principais funcionalidades
3. Tipos de dados processados
4. Complexidade geral

Mantenha a resposta concisa mas informativa.
"""
    
    def _get_variables_analysis_prompt(self) -> str:
        """Retorna o template de prompt para análise de variáveis."""
        return """
Analise as variáveis do seguinte programa COBOL em {language}.

RESUMO DO PROGRAMA:
{program_summary}

CÓDIGO COBOL:
{code_content}

Foque especificamente em:
1. Identificação de todas as variáveis principais
2. Explicação da função de cada variável
3. Estruturas de dados e hierarquias
4. Tipos de dados utilizados
5. Valores iniciais e constantes

Forneça uma análise detalhada das variáveis e estruturas de dados.
"""
    
    def _get_logic_analysis_prompt(self) -> str:
        """Retorna o template de prompt para análise de lógica."""
        return """
Analise a lógica de negócio do seguinte programa COBOL em {language}.

RESUMO DO PROGRAMA:
{program_summary}

CÓDIGO COBOL:
{code_content}

Foque especificamente em:
1. Lógica principal de processamento
2. Regras de negócio implementadas
3. Condições e validações
4. Cálculos e transformações
5. Fluxo de controle e decisões

Forneça uma análise detalhada da lógica de negócio implementada.
"""

