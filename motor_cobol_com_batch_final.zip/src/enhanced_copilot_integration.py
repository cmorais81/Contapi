"""
Integração aprimorada com OpenAI/Copilot para geração de documentação COBOL.
"""

import os
import openai
import yaml
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

from cobol_parser import CobolProgram
from data_flow_analyzer import DataFlowAnalyzer
from complexity_analyzer import ComplexityAnalyzer
from pattern_detector import PatternDetector
from specialized_prompts import SpecializedPrompts, PromptContext, AnalysisType
from contextual_analyzer import ContextualAnalyzer


@dataclass
class DocumentationRequest:
    """Requisição de documentação."""
    program: CobolProgram
    analysis_types: List[AnalysisType]
    include_technical_details: bool = True
    include_business_analysis: bool = True
    target_audience: str = "technical"  # technical, business, mixed
    output_format: str = "markdown"  # markdown, html, pdf


class EnhancedCopilotIntegration:
    """Integração aprimorada com OpenAI/Copilot usando prompts especializados."""
    
    def __init__(self, config_path: str = None):
        """
        Inicializa a integração com OpenAI.
        
        Args:
            config_path: Caminho para arquivo de configuração
        """
        self.config = self._load_config(config_path)
        self.api_key = os.getenv('OPENAI_API_KEY')
        
        if not self.api_key:
            raise ValueError("OPENAI_API_KEY não encontrada nas variáveis de ambiente")
        
        # Configura cliente OpenAI
        openai.api_key = self.api_key
        if 'api_base' in self.config:
            openai.api_base = self.config['api_base']
        
        # Inicializa componentes
        self.specialized_prompts = SpecializedPrompts()
        self.contextual_analyzer = ContextualAnalyzer()
        
        # Cache para análises
        self._analysis_cache = {}
    
    def _load_config(self, config_path: str) -> Dict:
        """Carrega configuração."""
        if config_path is None:
            config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'default_config.yaml')
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            return {
                'model': 'gpt-4',
                'max_tokens': 4000,
                'temperature': 0.3
            }
    
    def generate_comprehensive_documentation(self, request: DocumentationRequest) -> Dict[str, str]:
        """
        Gera documentação abrangente usando múltiplos tipos de análise.
        
        Args:
            request: Requisição de documentação
            
        Returns:
            Dicionário com documentação por tipo de análise
        """
        documentation = {}
        
        # Constrói contexto do programa
        program_context = self.contextual_analyzer.build_context(request.program)
        
        # Executa análises técnicas se necessário
        technical_analyses = {}
        if request.include_technical_details:
            technical_analyses = self._perform_technical_analyses(request.program)
        
        # Gera documentação para cada tipo de análise solicitado
        for analysis_type in request.analysis_types:
            try:
                doc_section = self._generate_analysis_documentation(
                    analysis_type, 
                    request.program, 
                    program_context,
                    technical_analyses,
                    request.target_audience
                )
                documentation[analysis_type.value] = doc_section
            except Exception as e:
                documentation[analysis_type.value] = f"Erro ao gerar documentação: {str(e)}"
        
        # Gera resumo executivo se múltiplas análises
        if len(request.analysis_types) > 1:
            documentation['executive_summary'] = self._generate_executive_summary(
                request.program, program_context, technical_analyses, documentation
            )
        
        return documentation
    
    def _perform_technical_analyses(self, program: CobolProgram) -> Dict[str, Any]:
        """Executa análises técnicas do programa."""
        cache_key = f"{program.program_id}_{hash(program.raw_content)}"
        
        if cache_key in self._analysis_cache:
            return self._analysis_cache[cache_key]
        
        analyses = {}
        
        try:
            # Análise de fluxo de dados
            data_analyzer = DataFlowAnalyzer(program)
            analyses['data_flow'] = data_analyzer.get_data_flow_summary()
        except Exception as e:
            analyses['data_flow'] = {'error': str(e)}
        
        try:
            # Análise de complexidade
            complexity_analyzer = ComplexityAnalyzer(program)
            analyses['complexity'] = complexity_analyzer.generate_complexity_report()
        except Exception as e:
            analyses['complexity'] = {'error': str(e)}
        
        try:
            # Detecção de padrões
            pattern_detector = PatternDetector(program)
            analyses['patterns'] = pattern_detector.generate_pattern_report()
        except Exception as e:
            analyses['patterns'] = {'error': str(e)}
        
        self._analysis_cache[cache_key] = analyses
        return analyses
    
    def _generate_analysis_documentation(self, analysis_type: AnalysisType, 
                                       program: CobolProgram,
                                       program_context,
                                       technical_analyses: Dict[str, Any],
                                       target_audience: str) -> str:
        """Gera documentação para um tipo específico de análise."""
        
        # Prepara contexto do prompt
        prompt_context = PromptContext(
            analysis_type=analysis_type,
            program=program,
            complexity_metrics=technical_analyses.get('complexity'),
            data_flow_summary=technical_analyses.get('data_flow'),
            pattern_report=technical_analyses.get('patterns'),
            domain_indicators=[program_context.business_domain.value] if program_context.domain_confidence > 0.5 else [],
            critical_sections=program_context.critical_sections
        )
        
        # Gera prompt especializado
        specialized_prompt = self.specialized_prompts.get_specialized_prompt(prompt_context)
        
        # Ajusta prompt baseado na audiência
        if target_audience == "business":
            specialized_prompt += "\n\nFOCO: Priorize explicações de negócio, minimize detalhes técnicos."
        elif target_audience == "technical":
            specialized_prompt += "\n\nFOCO: Inclua detalhes técnicos profundos e recomendações específicas."
        
        # Chama API OpenAI
        try:
            response = openai.ChatCompletion.create(
                model=self.config.get('model', 'gpt-4'),
                messages=[
                    {
                        "role": "system",
                        "content": "Você é um especialista em análise de sistemas COBOL com décadas de experiência em mainframe e modernização de aplicações."
                    },
                    {
                        "role": "user",
                        "content": specialized_prompt
                    }
                ],
                max_tokens=self.config.get('max_tokens', 4000),
                temperature=self.config.get('temperature', 0.3)
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            return f"Erro na geração de documentação: {str(e)}"
    
    def _generate_executive_summary(self, program: CobolProgram, 
                                  program_context, 
                                  technical_analyses: Dict[str, Any],
                                  generated_docs: Dict[str, str]) -> str:
        """Gera resumo executivo consolidado."""
        
        context_summary = self.contextual_analyzer.get_context_summary(program_context)
        
        summary_prompt = f"""
# Resumo Executivo - Análise Completa do Programa COBOL

Você é um consultor sênior em modernização de sistemas. Crie um resumo executivo consolidado baseado nas análises realizadas.

## Contexto do Programa
- **Nome**: {program.program_id}
- **Domínio**: {context_summary['business_context']['domain']}
- **Complexidade**: {context_summary['business_context']['complexity_category']}
- **Linhas de código**: {context_summary['program_info']['lines_of_code']}

## Análises Realizadas
{self._format_analysis_summary(generated_docs)}

## Métricas Principais
- **Seções críticas**: {context_summary['technical_analysis']['critical_sections_count']}
- **Oportunidades de modernização**: {context_summary['technical_analysis']['modernization_opportunities']}
- **Complexidade de integração**: {context_summary['technical_analysis']['integration_complexity']}
- **Preocupações de segurança**: {context_summary['technical_analysis']['security_concerns_count']}

## Instruções para Resumo Executivo

### 1. Visão Geral (2-3 parágrafos)
- Descreva o propósito e importância do programa
- Contextualize no domínio de negócio identificado
- Destaque características principais

### 2. Principais Descobertas (lista com 5-7 pontos)
- Identifique os achados mais importantes de todas as análises
- Priorize por impacto no negócio
- Inclua tanto aspectos positivos quanto preocupações

### 3. Recomendações Estratégicas (lista com 3-5 ações)
- Sugira ações prioritárias baseadas nas análises
- Considere ROI e viabilidade
- Inclua cronograma sugerido (curto/médio/longo prazo)

### 4. Próximos Passos (lista com 3-4 ações imediatas)
- Defina ações concretas para os próximos 30-90 dias
- Identifique recursos necessários
- Estabeleça critérios de sucesso

## Formato
- Use linguagem executiva (não técnica)
- Seja conciso mas abrangente
- Foque em impacto de negócio
- Inclua métricas quando relevante
- Use markdown para formatação

## Análises Detalhadas Disponíveis
{self._format_detailed_analyses(technical_analyses)}
"""
        
        try:
            response = openai.ChatCompletion.create(
                model=self.config.get('model', 'gpt-4'),
                messages=[
                    {
                        "role": "system",
                        "content": "Você é um consultor executivo especializado em modernização de sistemas mainframe e transformação digital."
                    },
                    {
                        "role": "user",
                        "content": summary_prompt
                    }
                ],
                max_tokens=self.config.get('max_tokens', 4000),
                temperature=0.2  # Mais determinístico para resumos executivos
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            return f"Erro na geração do resumo executivo: {str(e)}"
    
    def _format_analysis_summary(self, generated_docs: Dict[str, str]) -> str:
        """Formata resumo das análises realizadas."""
        summary = ""
        for analysis_type, content in generated_docs.items():
            if analysis_type != 'executive_summary':
                word_count = len(content.split())
                summary += f"- **{analysis_type.replace('_', ' ').title()}**: {word_count} palavras de análise\n"
        return summary
    
    def _format_detailed_analyses(self, technical_analyses: Dict[str, Any]) -> str:
        """Formata resumo das análises técnicas detalhadas."""
        summary = ""
        
        if 'data_flow' in technical_analyses and 'error' not in technical_analyses['data_flow']:
            df = technical_analyses['data_flow']
            summary += f"- **Fluxo de Dados**: {df.get('total_variables_used', 0)} variáveis, {df.get('total_data_operations', 0)} operações\n"
        
        if 'complexity' in technical_analyses and 'error' not in technical_analyses['complexity']:
            comp = technical_analyses['complexity']
            summary += f"- **Complexidade**: Pontuação {comp.get('quality_score', 'N/A')}, {len(comp.get('code_smells', []))} problemas identificados\n"
        
        if 'patterns' in technical_analyses and 'error' not in technical_analyses['patterns']:
            pat = technical_analyses['patterns']
            summary += f"- **Padrões**: {pat.get('summary', {}).get('total_patterns_detected', 0)} padrões detectados\n"
        
        return summary
    
    def generate_quick_analysis(self, program: CobolProgram, focus: str = "general") -> str:
        """
        Gera análise rápida focada.
        
        Args:
            program: Programa COBOL
            focus: Foco da análise (general, business, technical, security, performance)
            
        Returns:
            Análise rápida em markdown
        """
        # Mapeia foco para tipo de análise
        focus_mapping = {
            "business": AnalysisType.BUSINESS_LOGIC,
            "technical": AnalysisType.MAINTENANCE,
            "security": AnalysisType.SECURITY,
            "performance": AnalysisType.PERFORMANCE,
            "migration": AnalysisType.MIGRATION,
            "integration": AnalysisType.INTEGRATION,
            "data": AnalysisType.DATA_STRUCTURE
        }
        
        analysis_type = focus_mapping.get(focus, AnalysisType.BUSINESS_LOGIC)
        
        request = DocumentationRequest(
            program=program,
            analysis_types=[analysis_type],
            include_technical_details=True,
            target_audience="mixed"
        )
        
        documentation = self.generate_comprehensive_documentation(request)
        return documentation.get(analysis_type.value, "Erro na geração da análise")
    
    def generate_comparison_analysis(self, programs: List[CobolProgram]) -> str:
        """
        Gera análise comparativa entre múltiplos programas.
        
        Args:
            programs: Lista de programas COBOL
            
        Returns:
            Análise comparativa em markdown
        """
        if len(programs) < 2:
            return "Análise comparativa requer pelo menos 2 programas"
        
        # Analisa cada programa
        program_analyses = []
        for program in programs:
            context = self.contextual_analyzer.build_context(program)
            technical = self._perform_technical_analyses(program)
            
            program_analyses.append({
                'program': program,
                'context': context,
                'technical': technical
            })
        
        # Gera prompt de comparação
        comparison_prompt = self._build_comparison_prompt(program_analyses)
        
        try:
            response = openai.ChatCompletion.create(
                model=self.config.get('model', 'gpt-4'),
                messages=[
                    {
                        "role": "system",
                        "content": "Você é um arquiteto de sistemas especializado em análise comparativa de aplicações COBOL."
                    },
                    {
                        "role": "user",
                        "content": comparison_prompt
                    }
                ],
                max_tokens=self.config.get('max_tokens', 4000),
                temperature=0.3
            )
            
            return response.choices[0].message.content.strip()
            
        except Exception as e:
            return f"Erro na geração da análise comparativa: {str(e)}"
    
    def _build_comparison_prompt(self, program_analyses: List[Dict]) -> str:
        """Constrói prompt para análise comparativa."""
        prompt = """
# Análise Comparativa de Programas COBOL

Você é um especialista em análise de sistemas COBOL. Compare os programas fornecidos e forneça insights sobre suas diferenças, semelhanças e recomendações.

## Programas Analisados

"""
        
        for i, analysis in enumerate(program_analyses, 1):
            program = analysis['program']
            context = analysis['context']
            
            newline = '\n'
            prompt += f"""
### Programa {i}: {program.program_id}
- **Domínio**: {context.business_domain.value}
- **Complexidade**: {context.complexity_category.value}
- **Linhas**: {len(program.raw_content.split(newline))}
- **Variáveis**: {len(program.variables)}
- **Seções críticas**: {len(context.critical_sections)}

```cobol
{program.raw_content[:500]}...
```
"""
        
        prompt += """

## Instruções de Análise Comparativa

### 1. Análise Estrutural
- Compare arquitetura e organização dos programas
- Identifique padrões comuns e diferenças
- Avalie qualidade estrutural relativa

### 2. Análise de Complexidade
- Compare métricas de complexidade
- Identifique qual programa é mais complexo e por quê
- Sugira estratégias de simplificação

### 3. Análise de Domínio
- Compare domínios de negócio identificados
- Identifique sobreposições funcionais
- Avalie oportunidades de consolidação

### 4. Análise de Modernização
- Compare prontidão para modernização
- Identifique qual programa deve ser priorizado
- Sugira estratégias específicas para cada um

### 5. Recomendações
- Sugira ordem de priorização para manutenção/modernização
- Identifique oportunidades de reutilização
- Recomende estratégias de evolução

Use markdown para formatação e seja específico nas recomendações.
"""
        
        return prompt
    
    def clear_cache(self):
        """Limpa cache de análises."""
        self._analysis_cache.clear()
    
    def get_cache_stats(self) -> Dict[str, int]:
        """Retorna estatísticas do cache."""
        return {
            'cached_analyses': len(self._analysis_cache),
            'cache_size_mb': sum(len(str(v)) for v in self._analysis_cache.values()) / (1024 * 1024)
        }

