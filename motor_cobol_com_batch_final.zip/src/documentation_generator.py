"""
Gerador de documentação para programas COBOL analisados.
"""

import os
from typing import Dict, Any
from jinja2 import Environment, FileSystemLoader

# Importa as estruturas de dados necessárias
from cobol_parser import CobolProgram
from copilot_integration import AnalysisResponse


class DocumentationGenerator:
    """Gera documentação em Markdown ou HTML a partir da análise do programa."""
    
    def __init__(self, template_dir: str):
        """
        Inicializa o gerador de documentação.
        
        Args:
            template_dir: Diretório onde os templates estão localizados.
        """
        self.env = Environment(loader=FileSystemLoader(template_dir))
    
    def generate_documentation(
        self, 
        program: CobolProgram, 
        analysis: AnalysisResponse, 
        output_path: str, 
        output_format: str = "markdown"
    ):
        """
        Gera a documentação final.
        
        Args:
            program: Objeto CobolProgram com dados do parser.
            analysis: Objeto AnalysisResponse com dados da API.
            output_path: Caminho para salvar o arquivo de documentação.
            output_format: Formato da documentação (markdown ou html).
        """
        if output_format not in ["markdown", "html"]:
            raise ValueError("Formato de saída inválido. Use 'markdown' ou 'html'.")
        
        template_name = f"documentation_template.{output_format}.j2"
        template = self.env.get_template(template_name)
        
        # Prepara o contexto para o template
        context = self._prepare_template_context(program, analysis)
        
        # Renderiza o template
        rendered_doc = template.render(context)
        
        # Salva o arquivo
        try:
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(rendered_doc)
        except Exception as e:
            raise Exception(f"Erro ao salvar documentação em {output_path}: {str(e)}")
    
    def _prepare_template_context(self, program: CobolProgram, analysis: AnalysisResponse) -> Dict[str, Any]:
        """
        Prepara o dicionário de contexto para o template Jinja2.
        
        Args:
            program: Objeto CobolProgram.
            analysis: Objeto AnalysisResponse.
            
        Returns:
            Dicionário de contexto.
        """
        return {
            "program_id": program.program_id,
            "author": program.author,
            "date_written": program.date_written,
            "program_purpose": analysis.program_purpose,
            "main_functionality": analysis.main_functionality,
            "variables_description": analysis.variables_description,
            "business_logic_explanation": analysis.business_logic_explanation,
            "input_output_description": analysis.input_output_description,
            "execution_flow": analysis.execution_flow,
            "complexity_assessment": analysis.complexity_assessment,
            "recommendations": analysis.recommendations,
            "variables": program.variables,
            "sections": program.sections,
            "paragraphs": program.paragraphs,
            "raw_code": program.raw_content
        }


