"""
Analisador de código COBOL para extração de estruturas e informações relevantes.
"""

import re
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum


class CobolDivision(Enum):
    """Enumeração das divisões COBOL."""
    IDENTIFICATION = "IDENTIFICATION"
    ENVIRONMENT = "ENVIRONMENT"
    DATA = "DATA"
    PROCEDURE = "PROCEDURE"


@dataclass
class CobolVariable:
    """Representa uma variável COBOL."""
    name: str
    level: int
    picture: Optional[str] = None
    value: Optional[str] = None
    usage: Optional[str] = None
    occurs: Optional[int] = None  # Para arrays (OCCURS clause)
    occurs_depending: Optional[str] = None  # OCCURS DEPENDING ON
    redefines: Optional[str] = None  # REDEFINES clause
    condition_names: List[str] = None  # 88 level condition names
    parent: Optional[str] = None  # Variável pai na hierarquia
    children: List[str] = None  # Variáveis filhas
    line_number: int = 0
    synchronized: bool = False  # SYNC clause
    justified: bool = False  # JUSTIFIED clause
    blank_when_zero: bool = False  # BLANK WHEN ZERO
    sign_clause: Optional[str] = None  # SIGN IS LEADING/TRAILING
    
    def __post_init__(self):
        if self.condition_names is None:
            self.condition_names = []
        if self.children is None:
            self.children = []


@dataclass
class CobolParagraph:
    """Representa um parágrafo COBOL."""
    name: str
    line_number: int
    content: List[str]


@dataclass
class CobolSection:
    """Representa uma seção COBOL."""
    name: str
    line_number: int
    paragraphs: List[CobolParagraph]


@dataclass
class CobolProgram:
    """Representa um programa COBOL completo."""
    program_id: Optional[str] = None
    author: Optional[str] = None
    date_written: Optional[str] = None
    date_compiled: Optional[str] = None
    remarks: Optional[str] = None
    variables: List[CobolVariable] = None
    sections: List[CobolSection] = None
    paragraphs: List[CobolParagraph] = None
    raw_content: str = ""
    
    def __post_init__(self):
        if self.variables is None:
            self.variables = []
        if self.sections is None:
            self.sections = []
        if self.paragraphs is None:
            self.paragraphs = []


class CobolParser:
    """Parser para análise de código COBOL."""
    
    def __init__(self):
        self.current_division = None
        self.current_section = None
        
        # Padrões regex para identificação de estruturas COBOL
        self.patterns = {
            'division': re.compile(r'^\s*(\w+)\s+DIVISION\s*\.', re.IGNORECASE),
            'section': re.compile(r'^\s*([A-Z0-9][A-Z0-9-]*(?:\s+[A-Z0-9][A-Z0-9-]*)*)\s+SECTION\s*\.', re.IGNORECASE),
            'paragraph': re.compile(r'^\s*([A-Z0-9][A-Z0-9-]*)\s*\.', re.IGNORECASE),
            'program_id': re.compile(r'^\s*PROGRAM-ID\s*\.\s*([A-Z0-9-]+)', re.IGNORECASE),
            'author': re.compile(r'^\s*AUTHOR\s*\.\s*(.+)', re.IGNORECASE),
            'date_written': re.compile(r'^\s*DATE-WRITTEN\s*\.\s*(.+)', re.IGNORECASE),
            'date_compiled': re.compile(r'^\s*DATE-COMPILED\s*\.\s*(.+)', re.IGNORECASE),
            'remarks': re.compile(r'^\s*REMARKS\s*\.\s*(.+)', re.IGNORECASE),
            'variable': re.compile(
                r'^\s*(\d{2})\s+([A-Z0-9-]+)'
                r'(?:\s+REDEFINES\s+([A-Z0-9-]+))?'
                r'(?:\s+PIC\s+([X9V\(\)S\+\-\.AZPB]+))?'
                r'(?:\s+OCCURS\s+(\d+)(?:\s+TIMES)?(?:\s+DEPENDING\s+ON\s+([A-Z0-9-]+))?)?'
                r'(?:\s+VALUE\s+([^\.]+))?'
                r'(?:\s+USAGE\s+([^\.]+))?'
                r'(?:\s+(SYNC|SYNCHRONIZED))?'
                r'(?:\s+(JUSTIFIED|JUST))?'
                r'(?:\s+BLANK\s+WHEN\s+ZERO)?'
                r'(?:\s+SIGN\s+IS\s+(LEADING|TRAILING))?'
                r'\s*\.?', 
                re.IGNORECASE
            ),
            'condition_name': re.compile(r'^\s*88\s+([A-Z0-9-]+)\s+VALUE\s+([^\.]+)\.', re.IGNORECASE),
            'working_storage': re.compile(r'^\s*WORKING-STORAGE\s+SECTION\s*\.', re.IGNORECASE),
            'linkage_section': re.compile(r'^\s*LINKAGE\s+SECTION\s*\.', re.IGNORECASE),
            'file_section': re.compile(r'^\s*FILE\s+SECTION\s*\.', re.IGNORECASE),
        }
    
    def parse_file(self, file_path: str, encoding: str = 'utf-8') -> CobolProgram:
        """
        Analisa um arquivo COBOL e retorna um objeto CobolProgram.
        
        Args:
            file_path: Caminho para o arquivo COBOL
            encoding: Codificação do arquivo
            
        Returns:
            CobolProgram: Objeto com as informações extraídas
        """
        try:
            with open(file_path, 'r', encoding=encoding) as file:
                content = file.read()
            return self.parse_content(content)
        except Exception as e:
            raise Exception(f"Erro ao ler arquivo {file_path}: {str(e)}")
    
    def parse_content(self, content: str) -> CobolProgram:
        """
        Analisa o conteúdo COBOL e extrai as estruturas.
        
        Args:
            content: Conteúdo do programa COBOL
            
        Returns:
            CobolProgram: Objeto com as informações extraídas
        """
        program = CobolProgram(raw_content=content)
        lines = content.split('\n')
        
        current_section = None
        current_paragraph = None
        in_data_division = False
        in_procedure_division = False
        
        for line_num, line in enumerate(lines, 1):
            # Remove comentários (linhas que começam com * na coluna 7)
            if len(line) > 6 and line[6] == '*':
                continue
                
            # Identifica divisões
            division_match = self.patterns['division'].match(line)
            if division_match:
                division_name = division_match.group(1).upper()
                self.current_division = division_name
                in_data_division = (division_name == 'DATA')
                in_procedure_division = (division_name == 'PROCEDURE')
                continue
            
            # Processa IDENTIFICATION DIVISION
            if self.current_division == 'IDENTIFICATION':
                self._parse_identification_division(line, program)
            
            # Processa DATA DIVISION
            elif in_data_division:
                self._parse_data_division(line, line_num, program)
            
            # Processa PROCEDURE DIVISION
            elif in_procedure_division:
                current_section, current_paragraph = self._parse_procedure_division(
                    line, line_num, program, current_section, current_paragraph
                )
        
        return program
    
    def _parse_identification_division(self, line: str, program: CobolProgram):
        """Analisa linhas da IDENTIFICATION DIVISION."""
        for pattern_name, pattern in [
            ('program_id', self.patterns['program_id']),
            ('author', self.patterns['author']),
            ('date_written', self.patterns['date_written']),
            ('date_compiled', self.patterns['date_compiled']),
            ('remarks', self.patterns['remarks'])
        ]:
            match = pattern.match(line)
            if match:
                setattr(program, pattern_name, match.group(1).strip())
                break
    
    def _parse_data_division(self, line: str, line_num: int, program: CobolProgram):
        """Analisa linhas da DATA DIVISION."""
        # Identifica seções da DATA DIVISION
        if (self.patterns['working_storage'].match(line) or 
            self.patterns['linkage_section'].match(line) or 
            self.patterns['file_section'].match(line)):
            return
        
        # Identifica condition names (88 level)
        condition_match = self.patterns['condition_name'].match(line)
        if condition_match:
            condition_name = condition_match.group(1)
            condition_value = condition_match.group(2).strip()
            
            # Adiciona condition name à última variável processada
            if program.variables:
                last_var = program.variables[-1]
                last_var.condition_names.append(f"{condition_name}: {condition_value}")
            return
        
        # Identifica variáveis
        var_match = self.patterns['variable'].match(line)
        if var_match:
            level = int(var_match.group(1))
            name = var_match.group(2)
            redefines = var_match.group(3) if var_match.group(3) else None
            picture = var_match.group(4) if var_match.group(4) else None
            occurs = int(var_match.group(5)) if var_match.group(5) else None
            occurs_depending = var_match.group(6) if var_match.group(6) else None
            value = var_match.group(7) if var_match.group(7) else None
            usage = var_match.group(8) if var_match.group(8) else None
            sync = bool(var_match.group(9)) if var_match.group(9) else False
            justified = bool(var_match.group(10)) if var_match.group(10) else False
            sign_clause = var_match.group(11) if var_match.group(11) else None
            
            # Determina variável pai baseada no nível
            parent = None
            if level > 1:
                # Procura a variável pai (nível menor mais próximo)
                for var in reversed(program.variables):
                    if var.level < level:
                        parent = var.name
                        var.children.append(name)
                        break
            
            variable = CobolVariable(
                name=name,
                level=level,
                picture=picture,
                value=value,
                usage=usage,
                occurs=occurs,
                occurs_depending=occurs_depending,
                redefines=redefines,
                parent=parent,
                line_number=line_num,
                synchronized=sync,
                justified=justified,
                sign_clause=sign_clause
            )
            program.variables.append(variable)
        
        # Verifica se é uma linha de continuação com DEPENDING ON
        elif 'DEPENDING ON' in line.upper() and program.variables:
            depending_match = re.search(r'DEPENDING\s+ON\s+([A-Z0-9-]+)', line, re.IGNORECASE)
            if depending_match:
                last_var = program.variables[-1]
                if last_var.occurs and not last_var.occurs_depending:
                    last_var.occurs_depending = depending_match.group(1)
    
    def _parse_procedure_division(self, line: str, line_num: int, program: CobolProgram, 
                                current_section: Optional[CobolSection], 
                                current_paragraph: Optional[CobolParagraph]) -> Tuple[Optional[CobolSection], Optional[CobolParagraph]]:
        """Analisa linhas da PROCEDURE DIVISION."""
        # Identifica seções
        section_match = self.patterns['section'].match(line)
        if section_match:
            section_name = section_match.group(1)
            current_section = CobolSection(
                name=section_name,
                line_number=line_num,
                paragraphs=[]
            )
            program.sections.append(current_section)
            current_paragraph = None
            return current_section, current_paragraph
        
        # Identifica parágrafos
        paragraph_match = self.patterns['paragraph'].match(line)
        if paragraph_match:
            paragraph_name = paragraph_match.group(1)
            current_paragraph = CobolParagraph(
                name=paragraph_name,
                line_number=line_num,
                content=[]
            )
            
            if current_section:
                current_section.paragraphs.append(current_paragraph)
            else:
                program.paragraphs.append(current_paragraph)
            
            return current_section, current_paragraph
        
        # Adiciona conteúdo ao parágrafo atual
        if current_paragraph and line.strip():
            current_paragraph.content.append(line.strip())
        
        return current_section, current_paragraph
    
    def get_program_summary(self, program: CobolProgram) -> Dict:
        """
        Gera um resumo das informações do programa COBOL.
        
        Args:
            program: Objeto CobolProgram
            
        Returns:
            Dict: Resumo das informações
        """
        # Conta total de parágrafos (standalone + dentro de seções)
        total_paragraphs = len(program.paragraphs)
        for section in program.sections:
            total_paragraphs += len(section.paragraphs)
        
        # Coleta nomes de parágrafos principais
        main_paragraphs = [paragraph.name for paragraph in program.paragraphs[:10]]
        for section in program.sections:
            main_paragraphs.extend([para.name for para in section.paragraphs[:10]])
        
        return {
            'program_id': program.program_id,
            'author': program.author,
            'date_written': program.date_written,
            'total_variables': len(program.variables),
            'total_sections': len(program.sections),
            'total_paragraphs': total_paragraphs,
            'variables_by_level': self._group_variables_by_level(program.variables),
            'main_sections': [section.name for section in program.sections],
            'main_paragraphs': main_paragraphs[:10]  # Primeiros 10
        }
    
    def _group_variables_by_level(self, variables: List[CobolVariable]) -> Dict[int, int]:
        """Agrupa variáveis por nível."""
        level_count = {}
        for var in variables:
            level_count[var.level] = level_count.get(var.level, 0) + 1
        return level_count
    
    def extract_business_logic(self, program: CobolProgram) -> List[str]:
        """
        Extrai trechos de lógica de negócio do programa.
        
        Args:
            program: Objeto CobolProgram
            
        Returns:
            List[str]: Lista de trechos de código relevantes
        """
        business_logic = []
        
        # Coleta conteúdo dos parágrafos principais
        for paragraph in program.paragraphs:
            if paragraph.content:
                business_logic.extend(paragraph.content)
        
        # Coleta conteúdo das seções
        for section in program.sections:
            for paragraph in section.paragraphs:
                if paragraph.content:
                    business_logic.extend(paragraph.content)
        
        return business_logic

