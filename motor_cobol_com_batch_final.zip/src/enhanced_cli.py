"""
Interface de linha de comando aprimorada com suporte a plugins.
"""

import os
import sys
import argparse
import json
import yaml
from typing import List, Dict, Any
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()
import time

# Adiciona src ao path
sys.path.insert(0, os.path.dirname(__file__))

from cobol_parser import CobolParser
from enhanced_copilot_integration import EnhancedCopilotIntegration, DocumentationRequest
from specialized_prompts import AnalysisType
from plugin_system import PluginManager, PluginType
from documentation_generator import DocumentationGenerator


class EnhancedCLI:
    """Interface de linha de comando aprimorada."""
    
    def __init__(self):
        self.parser = CobolParser()
        self.copilot_integration = None
        self.plugin_manager = None
        self.doc_generator = None
        
        # Inicializa componentes
        self._initialize_components()
    
    def _initialize_components(self):
        """Inicializa componentes do sistema."""
        try:
            # Integração com Copilot
            config_path = os.path.join(os.path.dirname(__file__), '..', 'config', 'default_config.yaml')
            self.copilot_integration = EnhancedCopilotIntegration(config_path)
            
            # Gerenciador de plugins
            plugins_dir = os.path.join(os.path.dirname(__file__), '..', 'plugins')
            self.plugin_manager = PluginManager(plugins_dir)
            
            # Gerador de documentação
            self.doc_generator = DocumentationGenerator(config_path)
            
        except Exception as e:
            print(f"Aviso: Erro na inicialização de componentes: {str(e)}")
            print("Algumas funcionalidades podem não estar disponíveis.")
    
    def create_parser(self) -> argparse.ArgumentParser:
        """Cria parser de argumentos."""
        parser = argparse.ArgumentParser(
            description='Motor de Documentação COBOL - Versão Aprimorada',
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Exemplos de uso:

  # Análise básica
  python enhanced_cli.py analyze programa.cbl

  # Análise com plugins específicos
  python enhanced_cli.py analyze programa.cbl --plugins security_analyzer performance_analyzer

  # Documentação completa
  python enhanced_cli.py document programa.cbl --output docs/ --format markdown

  # Análise comparativa
  python enhanced_cli.py compare prog1.cbl prog2.cbl prog3.cbl

  # Gerenciamento de plugins
  python enhanced_cli.py plugins list
  python enhanced_cli.py plugins load security_analyzer --config security_config.yaml

  # Análise rápida focada
  python enhanced_cli.py quick programa.cbl --focus business
            """
        )
        
        subparsers = parser.add_subparsers(dest='command', help='Comandos disponíveis')
        
        # Comando analyze
        analyze_parser = subparsers.add_parser('analyze', help='Analisa programa COBOL')
        analyze_parser.add_argument('file', help='Arquivo COBOL para analisar')
        analyze_parser.add_argument('--plugins', nargs='*', help='Plugins específicos para executar')
        analyze_parser.add_argument('--output', '-o', help='Diretório de saída')
        analyze_parser.add_argument('--format', choices=['json', 'yaml', 'markdown'], default='json', help='Formato de saída')
        analyze_parser.add_argument('--config', help='Arquivo de configuração de plugins')
        
        # Comando document
        doc_parser = subparsers.add_parser('document', help='Gera documentação completa')
        doc_parser.add_argument('file', help='Arquivo COBOL para documentar')
        doc_parser.add_argument('--output', '-o', required=True, help='Diretório de saída')
        doc_parser.add_argument('--types', nargs='*', 
                               choices=[t.value for t in AnalysisType],
                               help='Tipos de análise para incluir')
        doc_parser.add_argument('--audience', choices=['technical', 'business', 'mixed'], 
                               default='mixed', help='Audiência alvo')
        doc_parser.add_argument('--format', choices=['markdown', 'html', 'pdf'], 
                               default='markdown', help='Formato de saída')
        
        # Comando compare
        compare_parser = subparsers.add_parser('compare', help='Compara múltiplos programas')
        compare_parser.add_argument('files', nargs='+', help='Arquivos COBOL para comparar')
        compare_parser.add_argument('--output', '-o', help='Arquivo de saída')
        compare_parser.add_argument('--format', choices=['markdown', 'html'], default='markdown')
        
        # Comando quick
        quick_parser = subparsers.add_parser('quick', help='Análise rápida focada')
        quick_parser.add_argument('file', help='Arquivo COBOL para analisar')
        quick_parser.add_argument('--focus', 
                                 choices=['general', 'business', 'technical', 'security', 'performance', 'migration'],
                                 default='general', help='Foco da análise')
        quick_parser.add_argument('--output', '-o', help='Arquivo de saída')
        
        # Comando plugins
        plugins_parser = subparsers.add_parser('plugins', help='Gerencia plugins')
        plugins_subparsers = plugins_parser.add_subparsers(dest='plugin_action', help='Ações de plugin')
        
        # plugins list
        plugins_subparsers.add_parser('list', help='Lista plugins disponíveis')
        
        # plugins load
        load_parser = plugins_subparsers.add_parser('load', help='Carrega plugin')
        load_parser.add_argument('plugin_name', help='Nome do plugin')
        load_parser.add_argument('--config', help='Arquivo de configuração do plugin')
        
        # plugins unload
        unload_parser = plugins_subparsers.add_parser('unload', help='Descarrega plugin')
        unload_parser.add_argument('plugin_name', help='Nome do plugin')
        
        # plugins info
        info_parser = plugins_subparsers.add_parser('info', help='Informações do plugin')
        info_parser.add_argument('plugin_name', help='Nome do plugin')
        
        # plugins discover
        plugins_subparsers.add_parser('discover', help='Descobre plugins disponíveis')
        
        # Comando batch
        batch_parser = subparsers.add_parser('batch', help='Processa múltiplos arquivos (ZIP ou diretório)')
        batch_parser.add_argument('input', help='Arquivo ZIP ou diretório com programas COBOL')
        batch_parser.add_argument('--output', '-o', required=True, help='Diretório de saída')
        batch_parser.add_argument('--plugins', nargs='*', help='Plugins específicos para executar')
        batch_parser.add_argument('--enable-ai', action='store_true', help='Habilitar documentação com IA')
        batch_parser.add_argument('--parallel', action='store_true', default=True, help='Processamento paralelo')
        batch_parser.add_argument('--max-workers', type=int, default=4, help='Número máximo de workers paralelos')
        batch_parser.add_argument('--recursive', action='store_true', default=True, help='Busca recursiva em diretórios')
        batch_parser.add_argument('--format', choices=['json', 'yaml', 'markdown'], default='json', help='Formato de saída individual')

        return parser
    
    def run(self, args: List[str] = None):
        """Executa CLI."""
        parser = self.create_parser()
        parsed_args = parser.parse_args(args)
        
        if not parsed_args.command:
            parser.print_help()
            return
        
        try:
            if parsed_args.command == 'analyze':
                self.cmd_analyze(parsed_args)
            elif parsed_args.command == 'document':
                self.cmd_document(parsed_args)
            elif parsed_args.command == 'compare':
                self.cmd_compare(parsed_args)
            elif parsed_args.command == 'quick':
                self.cmd_quick(parsed_args)
            elif parsed_args.command == 'batch':
                self.cmd_batch(parsed_args)
            elif parsed_args.command == 'plugins':
                self.cmd_plugins(parsed_args)
            else:
                parser.print_help()
                
        except Exception as e:
            print(f"Erro: {str(e)}")
            sys.exit(1)
    
    def cmd_analyze(self, args):
        """Comando de análise."""
        print(f"Analisando arquivo: {args.file}")
        
        # Verifica se arquivo existe
        if not os.path.exists(args.file):
            raise FileNotFoundError(f"Arquivo não encontrado: {args.file}")
        
        # Parse do programa
        program = self.parser.parse_file(args.file)
        print(f"Programa parseado: {program.program_id}")
        
        # Carrega configuração de plugins se fornecida
        if args.config and self.plugin_manager:
            loaded_count = self.plugin_manager.load_plugins_from_config(args.config)
            print(f"Plugins carregados da configuração: {loaded_count}")
        
        # Carrega plugins específicos se fornecidos
        if args.plugins and self.plugin_manager:
            for plugin_name in args.plugins:
                success = self.plugin_manager.load_plugin(plugin_name)
                if success:
                    print(f"Plugin carregado: {plugin_name}")
                else:
                    print(f"Falha ao carregar plugin: {plugin_name}")
        
        # Executa análises
        results = {}
        
        # Análises com plugins
        if self.plugin_manager:
            plugin_results = self.plugin_manager.execute_plugins(PluginType.ANALYZER, program)
            for result in plugin_results:
                if result.success:
                    results[result.plugin_name] = result.data
                    print(f"✓ {result.plugin_name}: {result.execution_time:.2f}s")
                else:
                    print(f"✗ {result.plugin_name}: {result.error}")
        
        # Análise básica do parser
        basic_analysis = {
            'program_info': {
                'program_id': program.program_id,
                'author': program.author,
                'date_written': program.date_written,
                'lines_of_code': len(program.raw_content.split('\n')),
                'variables_count': len(program.variables),
                'sections_count': len(program.sections),
                'paragraphs_count': len(program.paragraphs)
            },
            'variables': [self._serialize_variable(var) for var in program.variables],
            'sections': [self._serialize_section(section) for section in program.sections],
            'paragraphs': [self._serialize_paragraph(paragraph) for paragraph in program.paragraphs]
        }
        results['basic_analysis'] = basic_analysis
        
        # Salva resultados
        self._save_results(results, args.output, args.format, f"{program.program_id}_analysis")
        
        print(f"Análise concluída. Resultados salvos em formato {args.format}")
    
    def cmd_document(self, args):
        """Comando de documentação."""
        if not self.copilot_integration:
            raise Exception("Integração com Copilot não disponível")
        
        print(f"Gerando documentação para: {args.file}")
        
        # Parse do programa
        program = self.parser.parse_file(args.file)
        
        # Determina tipos de análise
        if args.types:
            analysis_types = [AnalysisType(t) for t in args.types]
        else:
            # Tipos padrão
            analysis_types = [
                AnalysisType.BUSINESS_LOGIC,
                AnalysisType.DATA_STRUCTURE,
                AnalysisType.MAINTENANCE
            ]
        
        # Cria requisição de documentação
        request = DocumentationRequest(
            program=program,
            analysis_types=analysis_types,
            include_technical_details=True,
            target_audience=args.audience,
            output_format=args.format
        )
        
        # Gera documentação
        print("Gerando documentação com IA...")
        documentation = self.copilot_integration.generate_comprehensive_documentation(request)
        
        # Salva documentação
        os.makedirs(args.output, exist_ok=True)
        
        for doc_type, content in documentation.items():
            filename = f"{program.program_id}_{doc_type}.{args.format}"
            filepath = os.path.join(args.output, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            print(f"✓ {doc_type}: {filepath}")
        
        print(f"Documentação completa gerada em: {args.output}")
    
    def cmd_compare(self, args):
        """Comando de comparação."""
        if not self.copilot_integration:
            raise Exception("Integração com Copilot não disponível")
        
        print(f"Comparando {len(args.files)} programas...")
        
        # Parse dos programas
        programs = []
        for file_path in args.files:
            if not os.path.exists(file_path):
                print(f"Aviso: Arquivo não encontrado: {file_path}")
                continue
            
            program = self.parser.parse_file(file_path)
            programs.append(program)
            print(f"✓ Parseado: {program.program_id}")
        
        if len(programs) < 2:
            raise Exception("Pelo menos 2 programas válidos são necessários para comparação")
        
        # Gera análise comparativa
        print("Gerando análise comparativa...")
        comparison = self.copilot_integration.generate_comparison_analysis(programs)
        
        # Salva resultado
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(comparison)
            print(f"Análise comparativa salva em: {args.output}")
        else:
            print("\n" + "="*80)
            print("ANÁLISE COMPARATIVA")
            print("="*80)
            print(comparison)
    
    def cmd_quick(self, args):
        """Comando de análise rápida."""
        if not self.copilot_integration:
            raise Exception("Integração com Copilot não disponível")
        
        print(f"Análise rápida ({args.focus}): {args.file}")
        
        # Parse do programa
        program = self.parser.parse_file(args.file)
        
        # Gera análise rápida
        analysis = self.copilot_integration.generate_quick_analysis(program, args.focus)
        
        # Salva ou exibe resultado
        if args.output:
            with open(args.output, 'w', encoding='utf-8') as f:
                f.write(analysis)
            print(f"Análise salva em: {args.output}")
        else:
            print("\n" + "="*80)
            print(f"ANÁLISE RÁPIDA - {args.focus.upper()}")
            print("="*80)
            print(analysis)
    
    def cmd_batch(self, args):
        """Comando para processamento em lote."""
        from batch_processor import BatchProcessor
        
        console.print(f"[bold blue]🔄 Iniciando processamento em lote...[/bold blue]")
        console.print(f"📁 Entrada: {args.input}")
        console.print(f"📂 Saída: {args.output}")
        
        try:
            # Inicializar processador
            processor = BatchProcessor()
            
            # Determinar se é ZIP ou diretório
            if args.input.lower().endswith('.zip'):
                console.print("📦 Processando arquivo ZIP...")
                result = processor.process_zip_file(
                    zip_path=args.input,
                    output_dir=args.output,
                    plugins=args.plugins or [],
                    enable_ai=args.enable_ai,
                    parallel=args.parallel,
                    max_workers=args.max_workers
                )
            elif os.path.isdir(args.input):
                console.print("📁 Processando diretório...")
                result = processor.process_directory(
                    directory_path=args.input,
                    output_dir=args.output,
                    plugins=args.plugins or [],
                    enable_ai=args.enable_ai,
                    recursive=args.recursive,
                    parallel=args.parallel,
                    max_workers=args.max_workers
                )
            else:
                console.print("[red]❌ Entrada deve ser um arquivo ZIP ou diretório[/red]")
                return
            
            # Exibir estatísticas
            stats = result['stats']
            console.print("\n[bold green]✅ Processamento concluído![/bold green]")
            console.print(f"📊 Arquivos processados: {stats['processed_files']}/{stats['total_files']}")
            console.print(f"📈 Linhas de código: {stats['total_lines']:,}")
            console.print(f"⏱️  Tempo total: {stats['processing_time']:.2f}s")
            console.print(f"🚀 Velocidade: {stats['files_per_minute']:.1f} arquivos/min")
            
            if stats['failed_files'] > 0:
                console.print(f"[yellow]⚠️  Falhas: {stats['failed_files']} arquivos[/yellow]")
            
            console.print(f"\n📋 Relatório consolidado: {result['consolidated_report']}")
            console.print(f"📂 Resultados salvos em: {result['output_directory']}")
            
        except Exception as e:
            console.print(f"[red]❌ Erro no processamento: {e}[/red]")
            raise

    def cmd_plugins(self, args):
        """Comando de gerenciamento de plugins."""
        if not self.plugin_manager:
            raise Exception("Gerenciador de plugins não disponível")
        
        if args.plugin_action == 'list':
            self._list_plugins()
        elif args.plugin_action == 'load':
            self._load_plugin(args.plugin_name, args.config)
        elif args.plugin_action == 'unload':
            self._unload_plugin(args.plugin_name)
        elif args.plugin_action == 'info':
            self._plugin_info(args.plugin_name)
        elif args.plugin_action == 'discover':
            self._discover_plugins()
        else:
            print("Ação de plugin não especificada. Use: list, load, unload, info, discover")
    
    def _list_plugins(self):
        """Lista plugins carregados."""
        print("Plugins carregados:")
        
        if not self.plugin_manager.plugins:
            print("  Nenhum plugin carregado")
            return
        
        for plugin_name, plugin in self.plugin_manager.plugins.items():
            metadata = plugin.metadata
            print(f"  ✓ {plugin_name}")
            print(f"    Versão: {metadata.version}")
            print(f"    Tipo: {metadata.plugin_type.value}")
            print(f"    Prioridade: {metadata.priority.value}")
            print(f"    Descrição: {metadata.description}")
            print()
        
        # Estatísticas
        stats = self.plugin_manager.get_execution_stats()
        print(f"Total: {stats['total_plugins']} plugins")
        print(f"Por tipo: {stats['plugins_by_type']}")
    
    def _load_plugin(self, plugin_name: str, config_file: str = None):
        """Carrega plugin."""
        config = {}
        
        if config_file:
            if not os.path.exists(config_file):
                raise FileNotFoundError(f"Arquivo de configuração não encontrado: {config_file}")
            
            with open(config_file, 'r', encoding='utf-8') as f:
                if config_file.endswith('.yaml') or config_file.endswith('.yml'):
                    config = yaml.safe_load(f)
                else:
                    config = json.load(f)
        
        success = self.plugin_manager.load_plugin(plugin_name, config)
        
        if success:
            print(f"✓ Plugin '{plugin_name}' carregado com sucesso")
        else:
            print(f"✗ Falha ao carregar plugin '{plugin_name}'")
    
    def _unload_plugin(self, plugin_name: str):
        """Descarrega plugin."""
        success = self.plugin_manager.unload_plugin(plugin_name)
        
        if success:
            print(f"✓ Plugin '{plugin_name}' descarregado com sucesso")
        else:
            print(f"✗ Plugin '{plugin_name}' não estava carregado")
    
    def _plugin_info(self, plugin_name: str):
        """Exibe informações do plugin."""
        info = self.plugin_manager.get_plugin_info(plugin_name)
        
        if not info:
            print(f"Plugin '{plugin_name}' não encontrado")
            return
        
        print(f"Informações do plugin: {plugin_name}")
        print(f"  Nome: {info.name}")
        print(f"  Versão: {info.version}")
        print(f"  Descrição: {info.description}")
        print(f"  Autor: {info.author}")
        print(f"  Tipo: {info.plugin_type.value}")
        print(f"  Prioridade: {info.priority.value}")
        
        if info.dependencies:
            print(f"  Dependências: {', '.join(info.dependencies)}")
        
        if info.config_schema:
            print("  Schema de configuração:")
            for key, schema in info.config_schema.items():
                print(f"    {key}: {schema}")
    
    def _discover_plugins(self):
        """Descobre plugins disponíveis."""
        discovered = self.plugin_manager.discover_plugins()
        
        print("Plugins disponíveis para carregamento:")
        
        if not discovered:
            print("  Nenhum plugin encontrado")
            return
        
        for plugin_name in discovered:
            status = "carregado" if plugin_name in self.plugin_manager.plugins else "disponível"
            print(f"  • {plugin_name} ({status})")
    
    def _save_results(self, results: Dict[str, Any], output_dir: str, format_type: str, base_name: str):
        """Salva resultados da análise."""
        if not output_dir:
            # Exibe no console se não especificado diretório
            if format_type == 'json':
                print(json.dumps(results, indent=2, ensure_ascii=False))
            elif format_type == 'yaml':
                print(yaml.dump(results, default_flow_style=False, allow_unicode=True))
            else:
                # Formato markdown simples
                print(self._format_as_markdown(results))
            return
        
        # Cria diretório se não existe
        os.makedirs(output_dir, exist_ok=True)
        
        # Determina extensão
        extensions = {'json': '.json', 'yaml': '.yaml', 'markdown': '.md'}
        extension = extensions.get(format_type, '.json')
        
        # Salva arquivo
        filepath = os.path.join(output_dir, f"{base_name}{extension}")
        
        with open(filepath, 'w', encoding='utf-8') as f:
            if format_type == 'json':
                json.dump(results, f, indent=2, ensure_ascii=False)
            elif format_type == 'yaml':
                yaml.dump(results, f, default_flow_style=False, allow_unicode=True)
            else:
                f.write(self._format_as_markdown(results))
        
        print(f"Resultados salvos em: {filepath}")
    
    def _format_as_markdown(self, results: Dict[str, Any]) -> str:
        """Formata resultados como markdown."""
        markdown = "# Análise de Programa COBOL\n\n"
        
        for section_name, section_data in results.items():
            markdown += f"## {section_name.replace('_', ' ').title()}\n\n"
            
            if isinstance(section_data, dict):
                for key, value in section_data.items():
                    if isinstance(value, (list, dict)):
                        markdown += f"**{key}**: {len(value) if isinstance(value, list) else 'objeto complexo'}\n\n"
                    else:
                        markdown += f"**{key}**: {value}\n\n"
            else:
                markdown += f"{section_data}\n\n"
        
        return markdown


    def _serialize_variable(self, var) -> Dict[str, Any]:
        """Serializa variável COBOL para JSON."""
        return {
            'name': var.name,
            'level': var.level,
            'picture': var.picture,
            'value': var.value,
            'usage': var.usage,
            'occurs': var.occurs,
            'occurs_depending': var.occurs_depending,
            'redefines': var.redefines,
            'parent': var.parent,
            'children': [child for child in var.children] if var.children else [],
            'condition_names': var.condition_names,
            'line_number': var.line_number,
            'synchronized': var.synchronized,
            'justified': var.justified,
            'blank_when_zero': var.blank_when_zero,
            'sign_clause': var.sign_clause
        }
    
    def _serialize_section(self, section) -> Dict[str, Any]:
        """Serializa seção COBOL para JSON."""
        return {
            'name': section.name,
            'line_number': section.line_number,
            'paragraphs': [self._serialize_paragraph(p) for p in section.paragraphs]
        }
    
    def _serialize_paragraph(self, paragraph) -> Dict[str, Any]:
        """Serializa parágrafo COBOL para JSON."""
        return {
            'name': paragraph.name,
            'line_number': paragraph.line_number,
            'content': paragraph.content
        }


def main():
    """Função principal."""
    cli = EnhancedCLI()
    cli.run()


if __name__ == '__main__':
    main()

