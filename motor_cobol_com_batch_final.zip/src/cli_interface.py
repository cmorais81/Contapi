"""
Interface de linha de comando (CLI) para o motor de documentação COBOL.
"""

import click
import os
import yaml
from dotenv import load_dotenv

# Adiciona o diretório src ao path para importações
import sys
sys.path.insert(0, os.path.dirname(__file__))

from cobol_parser import CobolParser
from copilot_integration import CopilotIntegration, AnalysisRequest
from documentation_generator import DocumentationGenerator

# Carrega variáveis de ambiente
load_dotenv()


@click.group()
@click.option("--config", default="config/default_config.yaml", help="Caminho para o arquivo de configuração.")
@click.pass_context
def cli(ctx, config):
    """Motor de Documentação COBOL com IA."""
    ctx.ensure_object(dict)
    
    try:
        with open(config, "r") as f:
            ctx.obj["CONFIG"] = yaml.safe_load(f)
    except FileNotFoundError:
        click.echo(f"Erro: Arquivo de configuração [31m{config}[0m não encontrado.", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Erro ao carregar configuração: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("file_path", type=click.Path(exists=True))
@click.option("--output-dir", default="docs", help="Diretório para salvar a documentação.")
@click.option("--format", "output_format", type=click.Choice(["markdown", "html"]), default=None, help="Formato da documentação.")
@click.pass_context
def generate(ctx, file_path, output_dir, output_format):
    """Gera documentação para um único arquivo COBOL."""
    config = ctx.obj["CONFIG"]
    
    # Define o formato de saída (prioridade: CLI > config)
    final_output_format = output_format or config["documentation"]["output_format"]
    
    # Garante que o diretório de saída exista
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        # 1. Parsing do COBOL
        click.echo(f"[34mAnalisando arquivo COBOL:[0m {file_path}")
        parser = CobolParser()
        program = parser.parse_file(file_path, encoding=config["cobol"]["encoding"])
        summary = parser.get_program_summary(program)
        click.echo("[32mAnálise concluída com sucesso.[0m")
        
        # 2. Integração com Copilot/OpenAI
        click.echo("[34mEnviando para análise da IA...[0m")
        copilot = CopilotIntegration(
            api_key=os.getenv("OPENAI_API_KEY"),
            model=config["api"]["model"],
            max_tokens=config["api"]["max_tokens"],
            temperature=config["api"]["temperature"]
        )
        
        request = AnalysisRequest(
            code_content=program.raw_content,
            program_summary=summary,
            language=config["documentation"]["language"]
        )
        
        analysis = copilot.analyze_cobol_program(request)
        click.echo("[32mAnálise da IA recebida.[0m")
        
        # 3. Geração da Documentação
        click.echo(f"[34mGerando documentação em formato {final_output_format.upper()}...[0m")
        doc_generator = DocumentationGenerator(template_dir="templates")
        
        output_filename = f"{program.program_id or os.path.basename(file_path)}.md"
        output_path = os.path.join(output_dir, output_filename)
        
        doc_generator.generate_documentation(
            program=program,
            analysis=analysis,
            output_path=output_path,
            output_format=final_output_format
        )
        
        click.echo(f"[32mDocumentação gerada com sucesso em:[0m {output_path}")
        
    except Exception as e:
        click.echo(f"[31mErro durante a geração da documentação: {e}[0m", err=True)
        sys.exit(1)


if __name__ == "__main__":
    cli()


