# Guia de Integração com IA - OpenAI/ChatGPT/Copilot

## Visão Geral

O Motor de Documentação COBOL suporta integração com diferentes provedores de IA para gerar documentação inteligente e análises contextuais. Este guia explica como configurar e usar cada opção.

---

## 🤖 Opções de Integração

### 1. OpenAI ChatGPT (Recomendado)
- **Modelos**: GPT-4, GPT-4 Turbo, GPT-3.5 Turbo
- **Vantagens**: Melhor qualidade, modelos mais recentes
- **Custo**: Pay-per-use baseado em tokens

### 2. Azure OpenAI
- **Modelos**: Mesmos da OpenAI, mas hospedados na Azure
- **Vantagens**: Compliance empresarial, SLA garantido
- **Custo**: Baseado em instância + tokens

### 3. GitHub Copilot
- **Modelos**: Baseado em GPT, otimizado para código
- **Vantagens**: Integração com GitHub, foco em desenvolvimento
- **Custo**: Assinatura mensal

---

## 🔧 Configuração OpenAI/ChatGPT

### Passo 1: Obter Chave da API

1. **Acesse**: https://platform.openai.com/
2. **Faça login** ou crie uma conta
3. **Vá para**: API Keys (https://platform.openai.com/api-keys)
4. **Clique**: "Create new secret key"
5. **Copie** a chave gerada (começa com `sk-`)

### Passo 2: Configurar Variáveis de Ambiente

#### Opção A: Arquivo .env (Recomendado)
```bash
# Copie o arquivo de exemplo
cp .env.example .env

# Edite o arquivo .env
nano .env
```

Configure no arquivo `.env`:
```bash
# Configuração OpenAI
OPENAI_API_KEY=sk-sua_chave_aqui
OPENAI_API_BASE=https://api.openai.com/v1
OPENAI_MODEL=gpt-4
OPENAI_MAX_TOKENS=4000
OPENAI_TEMPERATURE=0.3
```

#### Opção B: Variáveis de Sistema
```bash
# Linux/macOS
export OPENAI_API_KEY="sk-sua_chave_aqui"
export OPENAI_MODEL="gpt-4"

# Windows
set OPENAI_API_KEY=sk-sua_chave_aqui
set OPENAI_MODEL=gpt-4
```

### Passo 3: Testar Configuração

```bash
# Teste básico
python -c "
import os
from openai import OpenAI

client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
response = client.chat.completions.create(
    model='gpt-3.5-turbo',
    messages=[{'role': 'user', 'content': 'Hello!'}],
    max_tokens=10
)
print('✓ Configuração OpenAI funcionando!')
print(f'Resposta: {response.choices[0].message.content}')
"
```

### Passo 4: Usar no Motor

```bash
# Documentação com IA
python src/enhanced_cli.py document programa.cbl --output ./docs

# Análise rápida com IA
python src/enhanced_cli.py quick programa.cbl --focus business
```

---

## 🔧 Configuração Azure OpenAI

### Passo 1: Criar Recurso Azure OpenAI

1. **Portal Azure**: https://portal.azure.com/
2. **Criar recurso**: Azure OpenAI Service
3. **Configurar**: Região, pricing tier, etc.
4. **Deploy modelo**: GPT-4 ou GPT-3.5-turbo

### Passo 2: Obter Credenciais

1. **Vá para**: Seu recurso Azure OpenAI
2. **Keys and Endpoint**: Copie a chave e endpoint
3. **Model deployments**: Note o nome do deployment

### Passo 3: Configurar Variáveis

```bash
# Configuração Azure OpenAI
OPENAI_API_TYPE=azure
OPENAI_API_KEY=sua_chave_azure_aqui
OPENAI_API_BASE=https://seu-recurso.openai.azure.com/
OPENAI_API_VERSION=2024-02-15-preview
OPENAI_DEPLOYMENT_NAME=gpt-4
```

### Passo 4: Testar Azure OpenAI

```bash
python -c "
import os
from openai import AzureOpenAI

client = AzureOpenAI(
    api_key=os.getenv('OPENAI_API_KEY'),
    api_version=os.getenv('OPENAI_API_VERSION'),
    azure_endpoint=os.getenv('OPENAI_API_BASE')
)

response = client.chat.completions.create(
    model=os.getenv('OPENAI_DEPLOYMENT_NAME'),
    messages=[{'role': 'user', 'content': 'Hello Azure!'}],
    max_tokens=10
)
print('✓ Configuração Azure OpenAI funcionando!')
"
```

---

## 🔧 Configuração GitHub Copilot

### Passo 1: Obter Token GitHub

1. **GitHub Settings**: https://github.com/settings/tokens
2. **Generate new token**: Personal access token
3. **Scopes**: Selecione `copilot` e `read:user`
4. **Copie** o token gerado

### Passo 2: Configurar Token

```bash
# Configuração GitHub Copilot
GITHUB_TOKEN=ghp_seu_token_aqui
COPILOT_API_BASE=https://api.github.com/copilot
```

### Passo 3: Implementação Customizada

O GitHub Copilot requer implementação específica. Crie um arquivo `copilot_integration.py`:

```python
import os
import requests
from typing import Dict, Any

class CopilotIntegration:
    def __init__(self):
        self.token = os.getenv('GITHUB_TOKEN')
        self.base_url = os.getenv('COPILOT_API_BASE', 'https://api.github.com/copilot')
        
    def generate_documentation(self, code: str, context: str) -> str:
        headers = {
            'Authorization': f'token {self.token}',
            'Accept': 'application/vnd.github.v3+json'
        }
        
        prompt = f"""
        Analise este código COBOL e gere documentação:
        
        Contexto: {context}
        
        Código:
        {code}
        
        Gere documentação técnica detalhada.
        """
        
        # Implementar chamada para API do Copilot
        # (API específica pode variar)
        
        return "Documentação gerada pelo Copilot"
```

---

## ⚙️ Configuração Avançada

### Modelos Recomendados por Uso

#### Para Documentação Técnica
```bash
OPENAI_MODEL=gpt-4
OPENAI_MAX_TOKENS=4000
OPENAI_TEMPERATURE=0.2
```

#### Para Análise de Negócio
```bash
OPENAI_MODEL=gpt-4
OPENAI_MAX_TOKENS=3000
OPENAI_TEMPERATURE=0.3
```

#### Para Análise de Código
```bash
OPENAI_MODEL=gpt-4-turbo
OPENAI_MAX_TOKENS=8000
OPENAI_TEMPERATURE=0.1
```

### Configuração de Rate Limiting

```python
# config/ai_config.yaml
ai_settings:
  rate_limiting:
    requests_per_minute: 60
    tokens_per_minute: 150000
    retry_attempts: 3
    retry_delay: 1
  
  fallback_models:
    - gpt-4
    - gpt-4-turbo
    - gpt-3.5-turbo
  
  cost_optimization:
    max_tokens_per_request: 4000
    use_caching: true
    cache_ttl: 3600
```

### Prompts Customizados

Edite `src/specialized_prompts.py` para personalizar prompts:

```python
class CustomPrompts:
    BUSINESS_ANALYSIS = """
    Você é um analista de negócios especializado em sistemas COBOL.
    Analise este programa e explique:
    1. Processo de negócio implementado
    2. Regras de negócio identificadas
    3. Impacto no negócio
    4. Oportunidades de melhoria
    
    Use linguagem acessível para stakeholders de negócio.
    """
    
    TECHNICAL_ANALYSIS = """
    Você é um arquiteto de software especializado em modernização.
    Analise este código COBOL e forneça:
    1. Análise técnica detalhada
    2. Padrões arquiteturais identificados
    3. Pontos de melhoria técnica
    4. Estratégias de refatoração
    
    Foque em aspectos técnicos e de arquitetura.
    """
```

---

## 💰 Gestão de Custos

### Estimativa de Custos OpenAI

#### GPT-4 (Recomendado)
- **Input**: $0.03 por 1K tokens
- **Output**: $0.06 por 1K tokens
- **Programa médio**: ~$0.50-2.00 por análise

#### GPT-3.5 Turbo (Econômico)
- **Input**: $0.0015 por 1K tokens  
- **Output**: $0.002 por 1K tokens
- **Programa médio**: ~$0.05-0.20 por análise

### Otimização de Custos

```python
# Configuração econômica
OPENAI_MODEL=gpt-3.5-turbo
OPENAI_MAX_TOKENS=2000
OPENAI_TEMPERATURE=0.3

# Cache para evitar reprocessamento
COBOL_ENGINE_CACHE_ENABLED=true
COBOL_ENGINE_CACHE_TTL=86400  # 24 horas
```

### Monitoramento de Uso

```bash
# Script para monitorar custos
python -c "
import openai
import os

client = openai.OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

# Verificar uso atual (se disponível na API)
print('Monitorando uso da API...')
# Implementar lógica de monitoramento
"
```

---

## 🔍 Solução de Problemas

### Erro: "API key not found"

```bash
# Verificar se a chave está configurada
echo $OPENAI_API_KEY

# Se vazio, configurar:
export OPENAI_API_KEY="sk-sua_chave_aqui"
```

### Erro: "Rate limit exceeded"

```bash
# Configurar rate limiting
OPENAI_RATE_LIMIT_REQUESTS=50
OPENAI_RATE_LIMIT_TOKENS=100000
```

### Erro: "Model not found"

```bash
# Verificar modelos disponíveis
python -c "
from openai import OpenAI
client = OpenAI()
models = client.models.list()
for model in models.data:
    if 'gpt' in model.id:
        print(model.id)
"
```

### Erro de Conectividade

```bash
# Testar conectividade
curl -H "Authorization: Bearer $OPENAI_API_KEY" \
     https://api.openai.com/v1/models
```

---

## 📊 Monitoramento e Logs

### Habilitar Logs Detalhados

```bash
# Configurar logging
COBOL_ENGINE_LOG_LEVEL=DEBUG
ENABLE_DETAILED_LOGGING=true

# Executar com logs
python src/enhanced_cli.py document programa.cbl --output ./docs 2>&1 | tee analysis.log
```

### Métricas de Performance

```python
# Adicionar ao código para monitoramento
import time
import logging

def monitor_ai_call(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        try:
            result = func(*args, **kwargs)
            duration = time.time() - start_time
            logging.info(f"AI call successful: {duration:.2f}s")
            return result
        except Exception as e:
            duration = time.time() - start_time
            logging.error(f"AI call failed after {duration:.2f}s: {e}")
            raise
    return wrapper
```

---

## 🚀 Exemplos Práticos

### Análise Completa com IA

```bash
# Configurar ambiente
export OPENAI_API_KEY="sk-sua_chave_aqui"
export OPENAI_MODEL="gpt-4"

# Análise completa
python src/enhanced_cli.py document programa.cbl \
  --output ./documentacao_ia \
  --types business_logic data_structure security performance \
  --audience mixed \
  --format markdown
```

### Análise Rápida Focada

```bash
# Análise de segurança
python src/enhanced_cli.py quick programa.cbl \
  --focus security \
  --output relatorio_seguranca.md

# Análise de migração
python src/enhanced_cli.py quick programa.cbl \
  --focus migration \
  --output estrategia_migracao.md
```

### Comparação com IA

```bash
# Comparar versões
python src/enhanced_cli.py compare \
  versao_antiga.cbl versao_nova.cbl \
  --output comparacao_ia.md \
  --format markdown
```

---

## 📋 Checklist de Configuração

### ✅ Configuração Básica
- [ ] Python 3.11+ instalado
- [ ] Dependências instaladas (`pip install -r requirements.txt`)
- [ ] Chave OpenAI obtida
- [ ] Variáveis de ambiente configuradas
- [ ] Teste de conectividade realizado

### ✅ Configuração Avançada
- [ ] Arquivo `.env` configurado
- [ ] Rate limiting configurado
- [ ] Cache habilitado
- [ ] Logs configurados
- [ ] Prompts customizados (se necessário)

### ✅ Testes
- [ ] Teste de API funcionando
- [ ] Análise simples executada
- [ ] Documentação gerada
- [ ] Plugins funcionando
- [ ] Formatos de saída testados

---

## 📞 Suporte

### Recursos Úteis
- **OpenAI Documentation**: https://platform.openai.com/docs
- **Azure OpenAI**: https://docs.microsoft.com/azure/cognitive-services/openai/
- **GitHub Copilot**: https://docs.github.com/copilot

### Problemas Comuns
- **Rate Limits**: Configurar delays entre chamadas
- **Token Limits**: Dividir análises grandes em partes menores
- **Custos**: Usar modelos mais econômicos para testes

### Contato
- **Issues**: Reporte problemas no repositório
- **Documentação**: Consulte este guia e o manual principal
- **Comunidade**: Participe das discussões no projeto

---

**Guia de Integração com IA - Motor de Documentação COBOL**  
**Versão**: 1.0.0  
**Compatível com**: Python 3.11+, OpenAI API v1.0+

