"""
Setup script para o Motor de Documentação COBOL.
"""

from setuptools import setup, find_packages
import os

# Lê o README para descrição longa
def read_readme():
    with open("README.md", "r", encoding="utf-8") as fh:
        return fh.read()

# Lê os requirements
def read_requirements():
    with open("requirements.txt", "r", encoding="utf-8") as fh:
        return [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="cobol-documentation-engine",
    version="1.0.0",
    author="Equipe de Desenvolvimento",
    author_email="dev@empresa.com",
    description="Motor avançado para análise e documentação de código COBOL",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/empresa/cobol-documentation-engine",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Information Technology",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Documentation",
        "Topic :: Software Development :: Quality Assurance",
        "Topic :: System :: Systems Administration",
    ],
    python_requires=">=3.11",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=8.3.3",
            "pytest-cov>=5.0.0",
            "black>=24.0.0",
            "flake8>=7.0.0",
            "mypy>=1.11.0",
        ],
        "docs": [
            "sphinx>=7.0.0",
            "sphinx-rtd-theme>=2.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "cobol-engine=enhanced_cli:main",
            "cobol-analyze=enhanced_cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "": ["*.yaml", "*.yml", "*.json", "*.j2", "*.md"],
    },
    zip_safe=False,
    keywords="cobol, documentation, analysis, legacy, modernization, security, performance",
    project_urls={
        "Bug Reports": "https://github.com/empresa/cobol-documentation-engine/issues",
        "Source": "https://github.com/empresa/cobol-documentation-engine",
        "Documentation": "https://cobol-engine.readthedocs.io/",
    },
)

