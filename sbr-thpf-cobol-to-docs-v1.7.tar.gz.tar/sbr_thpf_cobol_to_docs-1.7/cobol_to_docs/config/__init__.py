from pathlib import Path
import os

# Define o caminho para o diretório de prompts
prompts_dir = Path(os.path.dirname(os.path.abspath(__file__))) / "prompts"

