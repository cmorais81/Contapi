"""
Aplicação principal da API de Governança de Dados
"""

import os
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.responses import RedirectResponse

from app.endpoints import data_contracts, external_metadata
from app.utils.exceptions import setup_exception_handlers

# Configuração da aplicação
app = FastAPI(
    title="tbr-gdpcore-dtgovapi",
    description="API de Governança de Dados com suporte a Unity Catalog External Lineage",
    version="2.1.0",
    docs_url=None,
    redoc_url=None,
    openapi_url="/api/openapi.json"
)

# Configuração de CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configuração de tratamento de exceções
setup_exception_handlers(app)

# Rotas de documentação
@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    return get_swagger_ui_html(
        openapi_url=app.openapi_url,
        title=f"{app.title} - Swagger UI",
        oauth2_redirect_url=app.swagger_ui_oauth2_redirect_url,
        swagger_js_url="/static/swagger-ui-bundle.js",
        swagger_css_url="/static/swagger-ui.css",
    )

@app.get("/redoc", include_in_schema=False)
async def redoc_html():
    return get_redoc_html(
        openapi_url=app.openapi_url,
        title=f"{app.title} - ReDoc",
        redoc_js_url="/static/redoc.standalone.js",
    )

# Rota raiz
@app.get("/", include_in_schema=False)
async def root():
    return RedirectResponse(url="/docs")

# Rota de health check
@app.get("/health", tags=["Health"])
async def health_check():
    return {"status": "healthy", "version": app.version}

# Inclusão dos routers
app.include_router(data_contracts.router, prefix="/api/v1", tags=["Data Contracts"])
app.include_router(external_metadata.router, prefix="/api/v1", tags=["External Metadata"])

# Inicialização da aplicação
def start_application():
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)

if __name__ == "__main__":
    start_application()

