# tbr-gdpcore-dtgovapi

API de Governança de Dados com suporte a Unity Catalog External Lineage

## Visão Geral

O tbr-gdpcore-dtgovapi é uma API completa de governança de dados baseada em contratos, com funcionalidades avançadas de ML, integrações enterprise, monitoramento, privacidade e analytics. A API suporta integração com Unity Catalog External Lineage, permitindo rastreabilidade completa de dados entre diferentes plataformas.

## Funcionalidades Principais

- Contratos de dados com versionamento
- Layouts customizáveis por país/região
- Sistema de qualidade com ML
- Detecção de anomalias automática
- Linhagem de dados completa
- Privacidade e compliance (LGPD/GDPR)
- Integrações Unity Catalog e Axon
- Unity Catalog External Lineage
- Analytics e relatórios executivos
- Observabilidade enterprise

## Estrutura do Projeto

```
tbr-gdpcore-dtgovapi/
├── src/                    # Código fonte da aplicação
│   ├── app/                # Código da aplicação
│   │   ├── models/         # Modelos de dados
│   │   ├── schemas/        # Schemas Pydantic
│   │   ├── services/       # Serviços de negócio
│   │   ├── repositories/   # Repositórios de dados
│   │   ├── endpoints/      # Endpoints REST
│   │   ├── utils/          # Utilitários
│   │   ├── integrations/   # Integrações externas
│   │   └── ml/             # Modelos de Machine Learning
│   └── tests/              # Testes automatizados
│       ├── unit/           # Testes unitários
│       └── integration/    # Testes de integração
├── models/                 # Modelos DBML
├── database/               # Scripts de banco de dados
├── docs/                   # Documentação
└── deployment/             # Arquivos de deploy
    ├── aks/                # Deploy no Azure Kubernetes Service
    └── local/              # Deploy local em Windows
```

## Requisitos

- Python 3.9+
- PostgreSQL 13+
- Azure Kubernetes Service (para deploy em produção)

## Instalação Local (Windows sem Docker)

Consulte o guia detalhado em `docs/GUIA_INSTALACAO_LOCAL_WINDOWS.md`.

## Deploy no AKS

Consulte o guia detalhado em `docs/MANUAL_DEPLOY_AKS_ATUALIZADO.md`.

## Modelo de Dados

O modelo de dados completo está disponível em `models/modelo_completo_v2.1.dbml`. Consulte a documentação em `docs/RESUMO_ALTERACOES_MODELO_V2.1.md` para detalhes sobre as últimas atualizações.

## Licença

Proprietária - Todos os direitos reservados

