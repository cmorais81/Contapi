# Guia de Instalação Local - tbr-gdpcore-dtgovapi

Este guia fornece instruções detalhadas para instalar e executar a API de Governança de Dados (tbr-gdpcore-dtgovapi) em um ambiente Windows local sem Docker.

## Requisitos de Sistema

- Windows 10/11 (64-bit)
- Python 3.9+ (recomendado: Python 3.11)
- PostgreSQL 13+
- Git
- Visual Studio Code ou PyCharm (opcional, mas recomendado)

## 1. Preparação do Ambiente

### 1.1. Instalação do Python

1. Baixe o instalador do Python 3.11 do [site oficial](https://www.python.org/downloads/windows/)
2. Execute o instalador e marque a opção "Add Python to PATH"
3. Conclua a instalação

Verifique a instalação abrindo o Prompt de Comando e executando:

```cmd
python --version
```

### 1.2. Instalação do PostgreSQL

1. Baixe o instalador do PostgreSQL 13 do [site oficial](https://www.postgresql.org/download/windows/)
2. Execute o instalador e siga as instruções
3. Anote a senha do usuário postgres definida durante a instalação
4. Mantenha a porta padrão (5432)
5. Conclua a instalação

### 1.3. Instalação do Git

1. Baixe o instalador do Git do [site oficial](https://git-scm.com/download/win)
2. Execute o instalador com as opções padrão
3. Conclua a instalação

## 2. Configuração do Projeto

### 2.1. Clone do Repositório

Abra o Prompt de Comando e execute:

```cmd
cd C:\Projetos
git clone https://github.com/sua-empresa/tbr-gdpcore-dtgovapi.git
cd tbr-gdpcore-dtgovapi
```

### 2.2. Criação do Ambiente Virtual

```cmd
python -m venv venv
venv\Scripts\activate
```

### 2.3. Instalação das Dependências

```cmd
pip install -r requirements.txt
```

## 3. Configuração do Banco de Dados

### 3.1. Criação do Banco de Dados

Abra o SQL Shell (psql) instalado com o PostgreSQL:

```
Server [localhost]: (pressione Enter)
Database [postgres]: (pressione Enter)
Port [5432]: (pressione Enter)
Username [postgres]: (pressione Enter)
Password for user postgres: (digite sua senha)
```

Execute os comandos SQL:

```sql
CREATE DATABASE tbr_gdpcore_dtgovapi;
CREATE USER tbr_gdpcore_user WITH PASSWORD 'sua_senha_segura';
GRANT ALL PRIVILEGES ON DATABASE tbr_gdpcore_dtgovapi TO tbr_gdpcore_user;
\q
```

### 3.2. Execução do Script de Criação de Tabelas

```cmd
cd database
psql -U postgres -d tbr_gdpcore_dtgovapi -f create_tables.sql
cd ..
```

## 4. Configuração da Aplicação

### 4.1. Criação do Arquivo .env

Crie um arquivo `.env` na raiz do projeto com o seguinte conteúdo:

```
DATABASE_URL=postgresql://tbr_gdpcore_user:sua_senha_segura@localhost:5432/tbr_gdpcore_dtgovapi
SECRET_KEY=gerar_chave_secreta_aleatoria
DEBUG=True
ENVIRONMENT=development
```

Para gerar uma chave secreta aleatória, execute no Prompt de Comando:

```cmd
python -c "import secrets; print(secrets.token_hex(32))"
```

Copie o resultado e substitua `gerar_chave_secreta_aleatoria` no arquivo `.env`.

## 5. Execução da Aplicação

### 5.1. Iniciar o Servidor de Desenvolvimento

```cmd
cd src
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### 5.2. Acessar a API

Abra um navegador e acesse:

- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## 6. Execução dos Testes

### 6.1. Testes Unitários

```cmd
cd tests
pytest unit/
```

### 6.2. Testes de Integração

```cmd
cd tests
pytest integration/
```

## 7. Solução de Problemas Comuns

### 7.1. Erro de Conexão com o Banco de Dados

Se você encontrar erros de conexão com o banco de dados:

1. Verifique se o serviço PostgreSQL está em execução
2. Verifique as credenciais no arquivo `.env`
3. Verifique se o firewall não está bloqueando a porta 5432

### 7.2. Erro de Dependências

Se você encontrar erros relacionados a dependências:

```cmd
pip install --upgrade pip
pip install -r requirements.txt --force-reinstall
```

### 7.3. Erro de Permissão

Se você encontrar erros de permissão ao executar scripts:

1. Execute o Prompt de Comando como administrador
2. Verifique as permissões do usuário no PostgreSQL

## 8. Integração com Unity Catalog

Para configurar a integração com Unity Catalog:

1. Obtenha um token de acesso do Databricks
2. Configure as variáveis de ambiente:

```
DATABRICKS_HOST=seu_workspace_url
DATABRICKS_TOKEN=seu_token
UNITY_CATALOG_METASTORE_ID=seu_metastore_id
```

## 9. Próximos Passos

Após a instalação bem-sucedida:

1. Explore a documentação da API em http://localhost:8000/docs
2. Revise o modelo de dados em `models/modelo_completo_v2.1.dbml`
3. Consulte `docs/RESUMO_ALTERACOES_MODELO_V2.1.md` para entender as últimas atualizações

## Suporte

Para obter suporte, entre em contato com a equipe de desenvolvimento em support@sua-empresa.com

