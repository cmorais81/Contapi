"""
TBR GDP Core - Data Governance API
Contract Service

Service completo para gestão de contratos de dados com
versionamento, layouts por país e validações.
"""

from typing import List, Dict, Optional, Tuple
from datetime import datetime
import uuid
from sqlalchemy import and_, or_
from src.models import db, DataContract, ContractVersion, ContractLayout, ContractSchemaDefinition
from src.models.contracts import ContractStatus, DataClassification, CompatibilityMode


class ContractService:
    """Service para gestão de contratos de dados"""
    
    @staticmethod
    def create_contract(data: Dict, user_id: str, country_code: str = 'BR') -> DataContract:
        """Cria um novo contrato de dados"""
        
        # Validar dados obrigatórios
        if not data.get('name'):
            raise ValueError("Nome do contrato é obrigatório")
        
        if not data.get('schema_definition'):
            raise ValueError("Definição de schema é obrigatória")
        
        # Verificar se já existe contrato com mesmo nome
        existing = DataContract.query.filter_by(name=data['name']).first()
        if existing:
            raise ValueError(f"Contrato com nome '{data['name']}' já existe")
        
        # Criar contrato
        contract = DataContract(
            name=data['name'],
            description=data.get('description'),
            version=data.get('version', '1.0.0'),
            status=ContractStatus.DRAFT,
            schema_definition=data['schema_definition'],
            data_classification=DataClassification(data.get('data_classification', 'internal')),
            business_domain=data.get('business_domain'),
            tags=data.get('tags', []),
            metadata=data.get('metadata', {}),
            created_by=user_id,
            updated_by=user_id
        )
        
        contract.save()
        
        # Criar versão inicial
        ContractService.create_version(
            contract.id,
            data['schema_definition'],
            user_id,
            version_number=contract.version,
            is_initial=True
        )
        
        # Criar layout padrão para o país
        ContractService.create_layout_for_country(
            contract.id,
            country_code,
            user_id
        )
        
        # Criar definições de schema
        ContractService._create_schema_definitions(contract.id, data['schema_definition'])
        
        return contract
    
    @staticmethod
    def get_contracts(
        page: int = 1,
        per_page: int = 20,
        status: Optional[str] = None,
        business_domain: Optional[str] = None,
        search: Optional[str] = None,
        country_code: Optional[str] = None
    ) -> Tuple[List[DataContract], int]:
        """Lista contratos com filtros e paginação"""
        
        query = DataContract.query
        
        # Aplicar filtros
        if status:
            query = query.filter(DataContract.status == ContractStatus(status))
        
        if business_domain:
            query = query.filter(DataContract.business_domain == business_domain)
        
        if search:
            query = query.filter(
                or_(
                    DataContract.name.ilike(f'%{search}%'),
                    DataContract.description.ilike(f'%{search}%')
                )
            )
        
        # Filtrar por país se especificado
        if country_code:
            query = query.join(ContractLayout).filter(
                ContractLayout.country_code == country_code
            )
        
        # Ordenar por data de criação
        query = query.order_by(DataContract.created_at.desc())
        
        # Aplicar paginação
        total = query.count()
        contracts = query.offset((page - 1) * per_page).limit(per_page).all()
        
        return contracts, total
    
    @staticmethod
    def get_contract_by_id(contract_id: str, country_code: Optional[str] = None) -> Optional[DataContract]:
        """Obtém contrato por ID com layout específico do país"""
        
        contract = DataContract.query.get(contract_id)
        if not contract:
            return None
        
        # Se país especificado, carregar layout específico
        if country_code:
            layout = contract.get_layout_for_country(country_code)
            if layout:
                # Aplicar formatação específica do país
                contract._country_layout = layout
        
        return contract
    
    @staticmethod
    def update_contract(contract_id: str, data: Dict, user_id: str) -> DataContract:
        """Atualiza um contrato existente"""
        
        contract = DataContract.query.get(contract_id)
        if not contract:
            raise ValueError("Contrato não encontrado")
        
        # Verificar se pode ser editado
        if contract.status == ContractStatus.ARCHIVED:
            raise ValueError("Contrato arquivado não pode ser editado")
        
        # Atualizar campos
        if 'description' in data:
            contract.description = data['description']
        
        if 'business_domain' in data:
            contract.business_domain = data['business_domain']
        
        if 'tags' in data:
            contract.tags = data['tags']
        
        if 'metadata' in data:
            contract.metadata = data['metadata']
        
        # Se schema foi alterado, criar nova versão
        if 'schema_definition' in data:
            new_version = ContractService._increment_version(contract.version)
            
            ContractService.create_version(
                contract_id,
                data['schema_definition'],
                user_id,
                version_number=new_version
            )
            
            contract.version = new_version
            contract.schema_definition = data['schema_definition']
            
            # Atualizar definições de schema
            ContractService._update_schema_definitions(contract_id, data['schema_definition'])
        
        contract.updated_by = user_id
        contract.save()
        
        return contract
    
    @staticmethod
    def activate_contract(contract_id: str, user_id: str) -> DataContract:
        """Ativa um contrato"""
        
        contract = DataContract.query.get(contract_id)
        if not contract:
            raise ValueError("Contrato não encontrado")
        
        if contract.status != ContractStatus.DRAFT:
            raise ValueError("Apenas contratos em rascunho podem ser ativados")
        
        # Validar schema antes de ativar
        validation_result = ContractService.validate_contract_schema(contract_id)
        if not validation_result['is_valid']:
            raise ValueError(f"Schema inválido: {validation_result['errors']}")
        
        contract.status = ContractStatus.ACTIVE
        contract.updated_by = user_id
        contract.save()
        
        # Ativar versão atual
        active_version = contract.get_active_version()
        if active_version:
            active_version.activate()
        
        return contract
    
    @staticmethod
    def create_version(
        contract_id: str,
        schema_definition: Dict,
        user_id: str,
        version_number: Optional[str] = None,
        changelog: Optional[str] = None,
        compatibility_mode: str = 'backward',
        is_initial: bool = False
    ) -> ContractVersion:
        """Cria uma nova versão do contrato"""
        
        contract = DataContract.query.get(contract_id)
        if not contract:
            raise ValueError("Contrato não encontrado")
        
        if not version_number:
            version_number = ContractService._increment_version(contract.version)
        
        # Verificar compatibilidade se não for versão inicial
        if not is_initial:
            current_version = contract.get_active_version()
            if current_version:
                compatibility_check = ContractService._check_schema_compatibility(
                    current_version.schema_definition,
                    schema_definition,
                    compatibility_mode
                )
                
                if not compatibility_check['compatible']:
                    # Se não compatível, marcar mudanças breaking
                    breaking_changes = compatibility_check.get('breaking_changes', [])
                else:
                    breaking_changes = []
            else:
                breaking_changes = []
        else:
            breaking_changes = []
        
        # Criar nova versão
        version = ContractVersion(
            contract_id=contract_id,
            version_number=version_number,
            schema_definition=schema_definition,
            changelog=changelog,
            compatibility_mode=CompatibilityMode(compatibility_mode),
            breaking_changes=breaking_changes,
            created_by=user_id
        )
        
        version.save()
        
        # Se for a primeira versão ou marcada para ativar, ativar
        if is_initial:
            version.activate()
        
        return version
    
    @staticmethod
    def create_layout_for_country(
        contract_id: str,
        country_code: str,
        user_id: str,
        layout_config: Optional[Dict] = None
    ) -> ContractLayout:
        """Cria layout específico para um país"""
        
        contract = DataContract.query.get(contract_id)
        if not contract:
            raise ValueError("Contrato não encontrado")
        
        # Configurações padrão por país
        default_configs = {
            'BR': {
                'date_format': 'dd/MM/yyyy',
                'currency_symbol': 'R$',
                'phone_pattern': '(XX) XXXXX-XXXX',
                'compliance_requirements': ['LGPD'],
                'validation_rules': {
                    'cpf': r'^\d{3}\.\d{3}\.\d{3}-\d{2}$',
                    'phone': r'^\(\d{2}\)\s\d{4,5}-\d{4}$'
                }
            },
            'US': {
                'date_format': 'MM/dd/yyyy',
                'currency_symbol': '$',
                'phone_pattern': '(XXX) XXX-XXXX',
                'compliance_requirements': ['CCPA'],
                'validation_rules': {
                    'ssn': r'^\d{3}-\d{2}-\d{4}$',
                    'phone': r'^\(\d{3}\)\s\d{3}-\d{4}$'
                }
            },
            'EU': {
                'date_format': 'dd.MM.yyyy',
                'currency_symbol': '€',
                'phone_pattern': '+XX XX XXXX XXXX',
                'compliance_requirements': ['GDPR'],
                'validation_rules': {
                    'phone': r'^\+\d{2}\s\d{2}\s\d{4}\s\d{4}$'
                }
            }
        }
        
        config = layout_config or default_configs.get(country_code, default_configs['BR'])
        
        # Verificar se já existe layout para este país
        existing = ContractLayout.query.filter_by(
            contract_id=contract_id,
            country_code=country_code
        ).first()
        
        if existing:
            # Atualizar existente
            existing.layout_config = config
            existing.compliance_requirements = config.get('compliance_requirements', [])
            existing.validation_rules = config.get('validation_rules', {})
            existing.formatting_rules = {
                'date': {'type': 'date', 'format': config.get('date_format')},
                'currency': {'type': 'currency', 'symbol': config.get('currency_symbol')},
                'phone': {'type': 'phone', 'pattern': config.get('phone_pattern')}
            }
            existing.save()
            return existing
        
        # Criar novo layout
        layout = ContractLayout(
            contract_id=contract_id,
            country_code=country_code,
            layout_name=f"{contract.name}_{country_code}",
            layout_config=config,
            compliance_requirements=config.get('compliance_requirements', []),
            validation_rules=config.get('validation_rules', {}),
            formatting_rules={
                'date': {'type': 'date', 'format': config.get('date_format')},
                'currency': {'type': 'currency', 'symbol': config.get('currency_symbol')},
                'phone': {'type': 'phone', 'pattern': config.get('phone_pattern')}
            }
        )
        
        layout.save()
        return layout
    
    @staticmethod
    def validate_data_against_contract(
        contract_id: str,
        data: Dict,
        country_code: Optional[str] = None
    ) -> Dict:
        """Valida dados contra um contrato"""
        
        contract = DataContract.query.get(contract_id)
        if not contract:
            raise ValueError("Contrato não encontrado")
        
        result = {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'formatted_data': data.copy()
        }
        
        # Validar contra schema do contrato
        schema_valid, schema_errors = contract.validate_schema(data)
        if not schema_valid:
            result['is_valid'] = False
            result['errors'].append(f"Schema validation: {schema_errors}")
        
        # Aplicar formatação específica do país
        if country_code:
            layout = contract.get_layout_for_country(country_code)
            if layout:
                result['formatted_data'] = layout.apply_formatting(data)
                
                # Validar compliance
                compliance_valid, compliance_violations = layout.validate_compliance(data)
                if not compliance_valid:
                    result['warnings'].extend(compliance_violations)
        
        # Validar campos individuais
        for field_def in contract.schema_definitions:
            field_valid, field_errors = field_def.validate_field_value(
                data.get(field_def.field_name)
            )
            if not field_valid:
                result['is_valid'] = False
                result['errors'].extend(field_errors)
        
        return result
    
    @staticmethod
    def validate_contract_schema(contract_id: str) -> Dict:
        """Valida o schema de um contrato"""
        
        contract = DataContract.query.get(contract_id)
        if not contract:
            raise ValueError("Contrato não encontrado")
        
        result = {
            'is_valid': True,
            'errors': [],
            'warnings': []
        }
        
        # Verificar se schema está presente
        if not contract.schema_definition:
            result['is_valid'] = False
            result['errors'].append("Schema definition is missing")
            return result
        
        # Validar estrutura do schema JSON
        try:
            import jsonschema
            # Schema básico para validar a estrutura
            meta_schema = {
                "type": "object",
                "properties": {
                    "type": {"type": "string"},
                    "properties": {"type": "object"}
                },
                "required": ["type", "properties"]
            }
            jsonschema.validate(contract.schema_definition, meta_schema)
        except Exception as e:
            result['is_valid'] = False
            result['errors'].append(f"Invalid JSON schema structure: {str(e)}")
        
        # Verificar se há definições de campos
        if not contract.schema_definitions:
            result['warnings'].append("No field definitions found")
        
        # Verificar consistência entre schema e definições
        schema_fields = set(contract.schema_definition.get('properties', {}).keys())
        definition_fields = set(field.field_name for field in contract.schema_definitions)
        
        missing_definitions = schema_fields - definition_fields
        extra_definitions = definition_fields - schema_fields
        
        if missing_definitions:
            result['warnings'].append(f"Missing field definitions: {list(missing_definitions)}")
        
        if extra_definitions:
            result['warnings'].append(f"Extra field definitions: {list(extra_definitions)}")
        
        return result
    
    @staticmethod
    def get_contract_versions(contract_id: str) -> List[ContractVersion]:
        """Obtém todas as versões de um contrato"""
        
        return ContractVersion.query.filter_by(
            contract_id=contract_id
        ).order_by(ContractVersion.created_at.desc()).all()
    
    @staticmethod
    def get_contract_layouts(contract_id: str) -> List[ContractLayout]:
        """Obtém todos os layouts de um contrato"""
        
        return ContractLayout.query.filter_by(
            contract_id=contract_id
        ).order_by(ContractLayout.country_code).all()
    
    @staticmethod
    def _increment_version(current_version: str) -> str:
        """Incrementa número da versão"""
        try:
            parts = current_version.split('.')
            if len(parts) == 3:
                major, minor, patch = map(int, parts)
                return f"{major}.{minor}.{patch + 1}"
            else:
                return f"{current_version}.1"
        except:
            return "1.0.1"
    
    @staticmethod
    def _check_schema_compatibility(old_schema: Dict, new_schema: Dict, mode: str) -> Dict:
        """Verifica compatibilidade entre schemas"""
        
        result = {
            'compatible': True,
            'breaking_changes': []
        }
        
        old_props = old_schema.get('properties', {})
        new_props = new_schema.get('properties', {})
        
        if mode == 'backward':
            # Verificar se campos foram removidos
            removed_fields = set(old_props.keys()) - set(new_props.keys())
            if removed_fields:
                result['compatible'] = False
                result['breaking_changes'].extend([f"Removed field: {field}" for field in removed_fields])
            
            # Verificar se tipos mudaram
            for field in old_props:
                if field in new_props:
                    old_type = old_props[field].get('type')
                    new_type = new_props[field].get('type')
                    if old_type != new_type:
                        result['compatible'] = False
                        result['breaking_changes'].append(f"Type changed for field {field}: {old_type} -> {new_type}")
        
        return result
    
    @staticmethod
    def _create_schema_definitions(contract_id: str, schema_definition: Dict):
        """Cria definições de schema baseadas no JSON schema"""
        
        properties = schema_definition.get('properties', {})
        required_fields = schema_definition.get('required', [])
        
        for field_name, field_config in properties.items():
            definition = ContractSchemaDefinition(
                contract_id=contract_id,
                field_name=field_name,
                field_type=field_config.get('type', 'string'),
                field_description=field_config.get('description'),
                is_required=field_name in required_fields,
                default_value=field_config.get('default'),
                validation_pattern=field_config.get('pattern'),
                min_length=field_config.get('minLength'),
                max_length=field_config.get('maxLength'),
                min_value=field_config.get('minimum'),
                max_value=field_config.get('maximum'),
                enum_values=field_config.get('enum'),
                format_hint=field_config.get('format')
            )
            
            # Detectar PII automaticamente
            pii_fields = ['email', 'phone', 'cpf', 'ssn', 'name', 'address']
            if any(pii_field in field_name.lower() for pii_field in pii_fields):
                definition.is_pii = True
            
            definition.save()
    
    @staticmethod
    def _update_schema_definitions(contract_id: str, schema_definition: Dict):
        """Atualiza definições de schema"""
        
        # Remover definições antigas
        ContractSchemaDefinition.query.filter_by(contract_id=contract_id).delete()
        db.session.commit()
        
        # Criar novas definições
        ContractService._create_schema_definitions(contract_id, schema_definition)

