"""
TBR GDP Core - Data Governance API
External Lineage Service

Service completo para Unity Catalog External Lineage
"""

from typing import List, Dict, Optional, Tuple
from datetime import datetime
import uuid
import requests
from src.models import db, ExternalMetadata, ExternalColumnMapping, ExternalLineageRelationship, DataObject
from src.models.lineage import SystemType, EntityType


class ExternalLineageService:
    """Service para Unity Catalog External Lineage"""
    
    @staticmethod
    def create_external_metadata(data: Dict, user_id: str) -> ExternalMetadata:
        """Cria metadado externo"""
        
        # Validar dados obrigatórios
        if not data.get('name'):
            raise ValueError("Nome é obrigatório")
        
        if not data.get('system_type'):
            raise ValueError("Tipo de sistema é obrigatório")
        
        if not data.get('entity_type'):
            raise ValueError("Tipo de entidade é obrigatório")
        
        # Gerar ID externo único
        external_id = f"{data['system_type']}_{uuid.uuid4().hex[:8]}"
        
        # Criar metadado externo
        metadata = ExternalMetadata(
            external_metadata_id=external_id,
            name=data['name'],
            system_type=SystemType(data['system_type']),
            entity_type=EntityType(data['entity_type']),
            external_url=data.get('external_url'),
            description=data.get('description'),
            owner=data.get('owner'),
            created_by_external=data.get('created_by_external'),
            metadata_json=data.get('metadata', {})
        )
        
        metadata.save()
        
        # Criar mapeamentos de colunas se fornecidos
        if data.get('column_mappings'):
            for mapping in data['column_mappings']:
                ExternalLineageService.create_column_mapping(
                    metadata.id,
                    mapping,
                    user_id
                )
        
        # Criar relacionamentos de lineage se fornecidos
        if data.get('lineage_relationships'):
            for relationship in data['lineage_relationships']:
                ExternalLineageService.create_lineage_relationship(
                    metadata.id,
                    relationship,
                    user_id
                )
        
        return metadata
    
    @staticmethod
    def get_external_metadata(
        page: int = 1,
        per_page: int = 20,
        system_type: Optional[str] = None,
        entity_type: Optional[str] = None,
        search: Optional[str] = None
    ) -> Tuple[List[ExternalMetadata], int]:
        """Lista metadados externos com filtros"""
        
        query = ExternalMetadata.query
        
        # Aplicar filtros
        if system_type:
            query = query.filter(ExternalMetadata.system_type == SystemType(system_type))
        
        if entity_type:
            query = query.filter(ExternalMetadata.entity_type == EntityType(entity_type))
        
        if search:
            query = query.filter(
                ExternalMetadata.name.ilike(f'%{search}%')
            )
        
        # Ordenar por data de criação
        query = query.order_by(ExternalMetadata.created_at.desc())
        
        # Aplicar paginação
        total = query.count()
        metadata_list = query.offset((page - 1) * per_page).limit(per_page).all()
        
        return metadata_list, total
    
    @staticmethod
    def get_external_metadata_by_id(metadata_id: str) -> Optional[ExternalMetadata]:
        """Obtém metadado externo por ID"""
        return ExternalMetadata.query.get(metadata_id)
    
    @staticmethod
    def sync_to_unity_catalog(metadata_id: str) -> Dict:
        """Sincroniza metadado com Unity Catalog"""
        
        metadata = ExternalMetadata.query.get(metadata_id)
        if not metadata:
            raise ValueError("Metadado não encontrado")
        
        try:
            # Simular sincronização com Unity Catalog
            # Em ambiente real, faria chamada para API do Unity Catalog
            sync_result = metadata.sync_to_unity_catalog()
            
            # Registrar operação de sincronização
            ExternalLineageService._log_sync_operation(
                metadata_id,
                'sync_to_unity_catalog',
                'success',
                sync_result
            )
            
            return {
                'success': True,
                'unity_catalog_id': sync_result['unity_catalog_id'],
                'sync_timestamp': sync_result['sync_timestamp'],
                'message': 'Sincronização realizada com sucesso'
            }
            
        except Exception as e:
            # Registrar erro
            ExternalLineageService._log_sync_operation(
                metadata_id,
                'sync_to_unity_catalog',
                'error',
                {'error': str(e)}
            )
            
            raise ValueError(f"Erro na sincronização: {str(e)}")
    
    @staticmethod
    def create_column_mapping(
        metadata_id: str,
        mapping_data: Dict,
        user_id: str
    ) -> ExternalColumnMapping:
        """Cria mapeamento de coluna"""
        
        # Validar dados
        if not mapping_data.get('external_column_name'):
            raise ValueError("Nome da coluna externa é obrigatório")
        
        # Verificar se objeto interno existe
        internal_object = None
        if mapping_data.get('internal_object_id'):
            internal_object = DataObject.query.get(mapping_data['internal_object_id'])
            if not internal_object:
                raise ValueError("Objeto interno não encontrado")
        
        mapping = ExternalColumnMapping(
            external_metadata_id=metadata_id,
            external_column_name=mapping_data['external_column_name'],
            internal_object_id=mapping_data.get('internal_object_id'),
            internal_column_name=mapping_data.get('internal_column_name'),
            mapping_confidence=mapping_data.get('mapping_confidence', 1.0),
            mapping_type=mapping_data.get('mapping_type', 'direct'),
            transformation_notes=mapping_data.get('transformation_notes')
        )
        
        mapping.save()
        return mapping
    
    @staticmethod
    def create_lineage_relationship(
        metadata_id: str,
        relationship_data: Dict,
        user_id: str
    ) -> ExternalLineageRelationship:
        """Cria relacionamento de lineage"""
        
        # Validar dados
        if not relationship_data.get('internal_object_id'):
            raise ValueError("ID do objeto interno é obrigatório")
        
        if not relationship_data.get('relationship_type'):
            raise ValueError("Tipo de relacionamento é obrigatório")
        
        # Verificar se objeto interno existe
        internal_object = DataObject.query.get(relationship_data['internal_object_id'])
        if not internal_object:
            raise ValueError("Objeto interno não encontrado")
        
        relationship = ExternalLineageRelationship(
            external_metadata_id=metadata_id,
            internal_object_id=relationship_data['internal_object_id'],
            relationship_type=relationship_data['relationship_type'],
            relationship_strength=relationship_data.get('relationship_strength', 1.0),
            discovered_method=relationship_data.get('discovered_method', 'manual'),
            notes=relationship_data.get('notes')
        )
        
        relationship.save()
        return relationship
    
    @staticmethod
    def get_lineage_graph(object_id: str, depth: int = 3) -> Dict:
        """Obtém grafo de lineage incluindo metadados externos"""
        
        # Verificar se é objeto interno ou externo
        internal_object = DataObject.query.get(object_id)
        external_metadata = ExternalMetadata.query.get(object_id)
        
        if not internal_object and not external_metadata:
            raise ValueError("Objeto não encontrado")
        
        graph = {
            'object_id': object_id,
            'nodes': [],
            'edges': [],
            'metadata': {}
        }
        
        if internal_object:
            # Construir grafo a partir de objeto interno
            graph = ExternalLineageService._build_graph_from_internal(
                internal_object, depth, graph
            )
        else:
            # Construir grafo a partir de metadado externo
            graph = ExternalLineageService._build_graph_from_external(
                external_metadata, depth, graph
            )
        
        return graph
    
    @staticmethod
    def analyze_impact(object_id: str) -> Dict:
        """Analisa impacto de mudanças em um objeto"""
        
        # Obter grafo de lineage
        graph = ExternalLineageService.get_lineage_graph(object_id, depth=5)
        
        # Analisar impacto downstream
        downstream_objects = []
        for edge in graph['edges']:
            if edge['source'] == object_id:
                downstream_objects.append(edge['target'])
        
        # Categorizar impactos
        impact_analysis = {
            'total_affected_objects': len(downstream_objects),
            'affected_systems': set(),
            'critical_dependencies': [],
            'recommendations': []
        }
        
        for node in graph['nodes']:
            if node['id'] in downstream_objects:
                if node.get('system_type'):
                    impact_analysis['affected_systems'].add(node['system_type'])
                
                # Identificar dependências críticas
                if node.get('entity_type') in ['dashboard', 'report']:
                    impact_analysis['critical_dependencies'].append({
                        'object_id': node['id'],
                        'name': node['name'],
                        'type': node['entity_type'],
                        'system': node.get('system_type'),
                        'impact_level': 'high'
                    })
        
        # Gerar recomendações
        if impact_analysis['total_affected_objects'] > 10:
            impact_analysis['recommendations'].append(
                "Alto número de objetos afetados. Considere implementar mudanças gradualmente."
            )
        
        if 'dashboard' in [dep['type'] for dep in impact_analysis['critical_dependencies']]:
            impact_analysis['recommendations'].append(
                "Dashboards críticos serão afetados. Notifique usuários finais."
            )
        
        impact_analysis['affected_systems'] = list(impact_analysis['affected_systems'])
        
        return impact_analysis
    
    @staticmethod
    def discover_lineage_from_system(system_type: str, config: Dict) -> Dict:
        """Descobre lineage automaticamente de um sistema externo"""
        
        discovered_objects = []
        
        try:
            if system_type == 'tableau':
                discovered_objects = ExternalLineageService._discover_tableau_lineage(config)
            elif system_type == 'power_bi':
                discovered_objects = ExternalLineageService._discover_powerbi_lineage(config)
            elif system_type == 'salesforce':
                discovered_objects = ExternalLineageService._discover_salesforce_lineage(config)
            else:
                raise ValueError(f"Sistema {system_type} não suportado para descoberta automática")
            
            # Criar metadados descobertos
            created_metadata = []
            for obj_data in discovered_objects:
                metadata = ExternalLineageService.create_external_metadata(
                    obj_data,
                    config.get('user_id', 'system')
                )
                created_metadata.append(metadata)
            
            return {
                'success': True,
                'discovered_count': len(created_metadata),
                'created_metadata': [m.to_dict() for m in created_metadata]
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'discovered_count': 0
            }
    
    @staticmethod
    def _discover_tableau_lineage(config: Dict) -> List[Dict]:
        """Descobre lineage do Tableau"""
        
        # Simular descoberta do Tableau
        # Em ambiente real, usaria Tableau REST API
        
        discovered = [
            {
                'name': 'Sales Dashboard',
                'system_type': 'tableau',
                'entity_type': 'dashboard',
                'external_url': f"{config.get('server_url', 'https://tableau.company.com')}/dashboard/sales",
                'description': 'Dashboard de vendas principal',
                'owner': 'sales.team@company.com',
                'metadata': {
                    'workbook': 'Sales Analytics',
                    'project': 'Sales',
                    'last_refresh': datetime.utcnow().isoformat()
                }
            },
            {
                'name': 'Customer Report',
                'system_type': 'tableau',
                'entity_type': 'report',
                'external_url': f"{config.get('server_url', 'https://tableau.company.com')}/report/customers",
                'description': 'Relatório de clientes',
                'owner': 'marketing.team@company.com',
                'metadata': {
                    'workbook': 'Customer Analytics',
                    'project': 'Marketing'
                }
            }
        ]
        
        return discovered
    
    @staticmethod
    def _discover_powerbi_lineage(config: Dict) -> List[Dict]:
        """Descobre lineage do Power BI"""
        
        # Simular descoberta do Power BI
        discovered = [
            {
                'name': 'Financial Dashboard',
                'system_type': 'power_bi',
                'entity_type': 'dashboard',
                'external_url': f"{config.get('workspace_url', 'https://app.powerbi.com')}/dashboard/financial",
                'description': 'Dashboard financeiro',
                'owner': 'finance.team@company.com',
                'metadata': {
                    'workspace': 'Finance',
                    'dataset': 'Financial Data'
                }
            }
        ]
        
        return discovered
    
    @staticmethod
    def _discover_salesforce_lineage(config: Dict) -> List[Dict]:
        """Descobre lineage do Salesforce"""
        
        # Simular descoberta do Salesforce
        discovered = [
            {
                'name': 'Account Object',
                'system_type': 'salesforce',
                'entity_type': 'dataset',
                'external_url': f"{config.get('instance_url', 'https://company.salesforce.com')}/Account",
                'description': 'Objeto Account do Salesforce',
                'owner': 'salesforce.admin@company.com',
                'metadata': {
                    'object_type': 'standard',
                    'api_name': 'Account'
                }
            }
        ]
        
        return discovered
    
    @staticmethod
    def _build_graph_from_internal(internal_object: DataObject, depth: int, graph: Dict) -> Dict:
        """Constrói grafo a partir de objeto interno"""
        
        # Adicionar nó do objeto interno
        graph['nodes'].append({
            'id': str(internal_object.id),
            'name': internal_object.name,
            'type': 'internal',
            'object_type': internal_object.object_type.value,
            'data_source': internal_object.data_source
        })
        
        # Buscar relacionamentos externos
        external_relationships = ExternalLineageRelationship.query.filter_by(
            internal_object_id=internal_object.id
        ).all()
        
        for rel in external_relationships:
            # Adicionar nó do metadado externo
            ext_metadata = rel.external_metadata
            graph['nodes'].append({
                'id': str(ext_metadata.id),
                'name': ext_metadata.name,
                'type': 'external',
                'system_type': ext_metadata.system_type.value,
                'entity_type': ext_metadata.entity_type.value,
                'external_url': ext_metadata.external_url
            })
            
            # Adicionar aresta
            if rel.relationship_type == 'source':
                graph['edges'].append({
                    'source': str(ext_metadata.id),
                    'target': str(internal_object.id),
                    'type': 'external_to_internal',
                    'strength': rel.relationship_strength
                })
            else:
                graph['edges'].append({
                    'source': str(internal_object.id),
                    'target': str(ext_metadata.id),
                    'type': 'internal_to_external',
                    'strength': rel.relationship_strength
                })
        
        return graph
    
    @staticmethod
    def _build_graph_from_external(external_metadata: ExternalMetadata, depth: int, graph: Dict) -> Dict:
        """Constrói grafo a partir de metadado externo"""
        
        # Adicionar nó do metadado externo
        graph['nodes'].append({
            'id': str(external_metadata.id),
            'name': external_metadata.name,
            'type': 'external',
            'system_type': external_metadata.system_type.value,
            'entity_type': external_metadata.entity_type.value,
            'external_url': external_metadata.external_url
        })
        
        # Buscar relacionamentos internos
        for rel in external_metadata.lineage_relationships:
            internal_object = rel.internal_object
            
            # Adicionar nó do objeto interno
            graph['nodes'].append({
                'id': str(internal_object.id),
                'name': internal_object.name,
                'type': 'internal',
                'object_type': internal_object.object_type.value,
                'data_source': internal_object.data_source
            })
            
            # Adicionar aresta
            if rel.relationship_type == 'source':
                graph['edges'].append({
                    'source': str(internal_object.id),
                    'target': str(external_metadata.id),
                    'type': 'internal_to_external',
                    'strength': rel.relationship_strength
                })
            else:
                graph['edges'].append({
                    'source': str(external_metadata.id),
                    'target': str(internal_object.id),
                    'type': 'external_to_internal',
                    'strength': rel.relationship_strength
                })
        
        return graph
    
    @staticmethod
    def _log_sync_operation(metadata_id: str, operation: str, status: str, details: Dict):
        """Registra operação de sincronização"""
        
        from src.models.integrations import SyncOperation
        
        sync_op = SyncOperation(
            integration_id=metadata_id,
            operation_type=operation,
            status=status,
            started_at=datetime.utcnow(),
            completed_at=datetime.utcnow(),
            details=details
        )
        
        sync_op.save()

