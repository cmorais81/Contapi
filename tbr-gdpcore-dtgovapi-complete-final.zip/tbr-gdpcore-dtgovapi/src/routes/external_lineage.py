"""
TBR GDP Core - Data Governance API
Endpoints de Unity Catalog External Lineage

Implementação completa dos endpoints para external lineage
"""

from flask import Blueprint, request, jsonify, g
from flask_restx import Api, Resource, fields, Namespace
from src.services.external_lineage_service import ExternalLineageService
import logging

# Criar blueprint
external_lineage_bp = Blueprint('external_lineage', __name__)
api = Api(external_lineage_bp, doc=False)

# Namespace
ns = Namespace('external-lineage', description='Unity Catalog External Lineage')

# Modelos Swagger
external_metadata_model = api.model('ExternalMetadata', {
    'id': fields.String(description='ID interno'),
    'external_metadata_id': fields.String(description='ID externo único'),
    'name': fields.String(required=True, description='Nome do metadado'),
    'system_type': fields.String(required=True, enum=['tableau', 'power_bi', 'looker', 'qlik', 'salesforce', 'snowflake', 'databricks', 'custom']),
    'entity_type': fields.String(required=True, enum=['dashboard', 'report', 'dataset', 'workbook', 'flow', 'model']),
    'external_url': fields.String(description='URL externa'),
    'description': fields.String(description='Descrição'),
    'owner': fields.String(description='Proprietário'),
    'unity_catalog_external_id': fields.String(description='ID no Unity Catalog'),
    'sync_status': fields.String(description='Status de sincronização'),
    'last_sync_at': fields.DateTime(description='Última sincronização'),
    'created_at': fields.DateTime(description='Data de criação')
})

create_metadata_model = api.model('CreateExternalMetadata', {
    'name': fields.String(required=True, description='Nome do metadado'),
    'system_type': fields.String(required=True, enum=['tableau', 'power_bi', 'looker', 'qlik', 'salesforce', 'snowflake', 'databricks', 'custom']),
    'entity_type': fields.String(required=True, enum=['dashboard', 'report', 'dataset', 'workbook', 'flow', 'model']),
    'external_url': fields.String(description='URL externa'),
    'description': fields.String(description='Descrição'),
    'owner': fields.String(description='Proprietário'),
    'metadata': fields.Raw(description='Metadados adicionais'),
    'column_mappings': fields.List(fields.Raw, description='Mapeamentos de colunas'),
    'lineage_relationships': fields.List(fields.Raw, description='Relacionamentos de lineage')
})

column_mapping_model = api.model('ColumnMapping', {
    'external_column_name': fields.String(required=True, description='Nome da coluna externa'),
    'internal_object_id': fields.String(description='ID do objeto interno'),
    'internal_column_name': fields.String(description='Nome da coluna interna'),
    'mapping_confidence': fields.Float(description='Confiança do mapeamento'),
    'mapping_type': fields.String(description='Tipo de mapeamento'),
    'transformation_notes': fields.String(description='Notas de transformação')
})

lineage_relationship_model = api.model('LineageRelationship', {
    'internal_object_id': fields.String(required=True, description='ID do objeto interno'),
    'relationship_type': fields.String(required=True, description='Tipo de relacionamento'),
    'relationship_strength': fields.Float(description='Força do relacionamento'),
    'discovered_method': fields.String(description='Método de descoberta'),
    'notes': fields.String(description='Notas')
})

lineage_graph_model = api.model('LineageGraph', {
    'object_id': fields.String(description='ID do objeto'),
    'nodes': fields.List(fields.Raw, description='Nós do grafo'),
    'edges': fields.List(fields.Raw, description='Arestas do grafo'),
    'metadata': fields.Raw(description='Metadados do grafo')
})

sync_result_model = api.model('SyncResult', {
    'success': fields.Boolean(description='Se a sincronização foi bem-sucedida'),
    'unity_catalog_id': fields.String(description='ID no Unity Catalog'),
    'sync_timestamp': fields.String(description='Timestamp da sincronização'),
    'message': fields.String(description='Mensagem de resultado')
})

discovery_config_model = api.model('DiscoveryConfig', {
    'system_type': fields.String(required=True, enum=['tableau', 'power_bi', 'salesforce']),
    'server_url': fields.String(description='URL do servidor'),
    'username': fields.String(description='Nome de usuário'),
    'password': fields.String(description='Senha'),
    'api_token': fields.String(description='Token de API'),
    'workspace_url': fields.String(description='URL do workspace'),
    'instance_url': fields.String(description='URL da instância')
})


@ns.route('/metadata')
class ExternalMetadataList(Resource):
    @api.doc('list_external_metadata')
    @api.param('page', 'Número da página', type='integer', default=1)
    @api.param('per_page', 'Itens por página', type='integer', default=20)
    @api.param('system_type', 'Filtrar por tipo de sistema', enum=['tableau', 'power_bi', 'looker', 'qlik', 'salesforce', 'snowflake', 'databricks', 'custom'])
    @api.param('entity_type', 'Filtrar por tipo de entidade', enum=['dashboard', 'report', 'dataset', 'workbook', 'flow', 'model'])
    @api.param('search', 'Buscar por nome')
    def get(self):
        """Lista metadados externos com filtros"""
        try:
            page = request.args.get('page', 1, type=int)
            per_page = request.args.get('per_page', 20, type=int)
            system_type = request.args.get('system_type')
            entity_type = request.args.get('entity_type')
            search = request.args.get('search')
            
            metadata_list, total = ExternalLineageService.get_external_metadata(
                page=page,
                per_page=per_page,
                system_type=system_type,
                entity_type=entity_type,
                search=search
            )
            
            result = []
            for metadata in metadata_list:
                metadata_dict = metadata.to_dict()
                result.append(metadata_dict)
            
            return {
                'metadata': result,
                'pagination': {
                    'page': page,
                    'per_page': per_page,
                    'total': total,
                    'pages': (total + per_page - 1) // per_page
                }
            }
            
        except Exception as e:
            logging.error(f"Error listing external metadata: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")
    
    @api.doc('create_external_metadata')
    @api.expect(create_metadata_model)
    @api.marshal_with(external_metadata_model, code=201)
    def post(self):
        """Cria novo metadado externo"""
        try:
            data = request.get_json()
            
            if not data:
                api.abort(400, "Dados não fornecidos")
            
            metadata = ExternalLineageService.create_external_metadata(
                data=data,
                user_id=g.user_id
            )
            
            return metadata.to_dict(), 201
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error creating external metadata: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/metadata/<string:metadata_id>')
class ExternalMetadata(Resource):
    @api.doc('get_external_metadata')
    @api.marshal_with(external_metadata_model)
    def get(self, metadata_id):
        """Obtém metadado externo específico"""
        try:
            metadata = ExternalLineageService.get_external_metadata_by_id(metadata_id)
            
            if not metadata:
                api.abort(404, "Metadado não encontrado")
            
            return metadata.to_dict()
            
        except Exception as e:
            logging.error(f"Error getting external metadata {metadata_id}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/metadata/<string:metadata_id>/sync')
class ExternalMetadataSync(Resource):
    @api.doc('sync_to_unity_catalog')
    @api.marshal_with(sync_result_model)
    def post(self, metadata_id):
        """Sincroniza metadado com Unity Catalog"""
        try:
            result = ExternalLineageService.sync_to_unity_catalog(metadata_id)
            
            return result
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error syncing metadata {metadata_id}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/metadata/<string:metadata_id>/column-mappings')
class ColumnMappings(Resource):
    @api.doc('create_column_mapping')
    @api.expect(column_mapping_model)
    def post(self, metadata_id):
        """Cria mapeamento de coluna"""
        try:
            data = request.get_json()
            
            if not data:
                api.abort(400, "Dados não fornecidos")
            
            mapping = ExternalLineageService.create_column_mapping(
                metadata_id=metadata_id,
                mapping_data=data,
                user_id=g.user_id
            )
            
            return mapping.to_dict(), 201
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error creating column mapping: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/metadata/<string:metadata_id>/relationships')
class LineageRelationships(Resource):
    @api.doc('create_lineage_relationship')
    @api.expect(lineage_relationship_model)
    def post(self, metadata_id):
        """Cria relacionamento de lineage"""
        try:
            data = request.get_json()
            
            if not data:
                api.abort(400, "Dados não fornecidos")
            
            relationship = ExternalLineageService.create_lineage_relationship(
                metadata_id=metadata_id,
                relationship_data=data,
                user_id=g.user_id
            )
            
            return relationship.to_dict(), 201
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error creating lineage relationship: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/graph/<string:object_id>')
class LineageGraph(Resource):
    @api.doc('get_lineage_graph')
    @api.param('depth', 'Profundidade do grafo', type='integer', default=3)
    @api.marshal_with(lineage_graph_model)
    def get(self, object_id):
        """Obtém grafo de lineage para um objeto"""
        try:
            depth = request.args.get('depth', 3, type=int)
            
            graph = ExternalLineageService.get_lineage_graph(
                object_id=object_id,
                depth=depth
            )
            
            return graph
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error getting lineage graph for {object_id}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/impact-analysis/<string:object_id>')
class ImpactAnalysis(Resource):
    @api.doc('analyze_impact')
    def get(self, object_id):
        """Analisa impacto de mudanças em um objeto"""
        try:
            analysis = ExternalLineageService.analyze_impact(object_id)
            
            return analysis
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error analyzing impact for {object_id}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/discover')
class LineageDiscovery(Resource):
    @api.doc('discover_lineage')
    @api.expect(discovery_config_model)
    def post(self):
        """Descobre lineage automaticamente de sistemas externos"""
        try:
            data = request.get_json()
            
            if not data:
                api.abort(400, "Configuração não fornecida")
            
            if 'system_type' not in data:
                api.abort(400, "Tipo de sistema é obrigatório")
            
            # Adicionar user_id à configuração
            data['user_id'] = g.user_id
            
            result = ExternalLineageService.discover_lineage_from_system(
                system_type=data['system_type'],
                config=data
            )
            
            return result
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error discovering lineage: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


# Registrar namespace
api.add_namespace(ns)

