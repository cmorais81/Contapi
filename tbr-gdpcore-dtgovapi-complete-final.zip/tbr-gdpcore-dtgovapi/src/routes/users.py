"""
TBR GDP Core - Data Governance API
Endpoints de Usuários
"""

from flask import Blueprint, request, g
from flask_restx import Api, Resource, Namespace
import logging

users_bp = Blueprint('users', __name__)
api = Api(users_bp, doc=False)
ns = Namespace('users', description='Gestão de Usuários e Permissões')

@ns.route('/profile')
class UserProfile(Resource):
    @api.doc('get_user_profile')
    def get(self):
        """Obtém perfil do usuário atual"""
        try:
            return {
                'id': g.user_id,
                'username': 'user@company.com',
                'country_code': g.country_code,
                'tenant_id': g.tenant_id,
                'permissions': ['read_contracts', 'write_contracts'],
                'preferences': {
                    'language': 'pt-BR',
                    'timezone': 'America/Sao_Paulo'
                }
            }
        except Exception as e:
            api.abort(500, f"Erro interno: {str(e)}")

api.add_namespace(ns)

