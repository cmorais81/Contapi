"""
TBR GDP Core - Data Governance API
Endpoints de Contratos de Dados

Implementação completa dos endpoints para gestão de contratos
"""

from flask import Blueprint, request, jsonify, g
from flask_restx import Api, Resource, fields, Namespace
from src.services.contract_service import ContractService
from src.models.contracts import ContractStatus, DataClassification
import logging

# Criar blueprint
contracts_bp = Blueprint('contracts', __name__)
api = Api(contracts_bp, doc=False)  # Documentação será no main

# Namespace para organização
ns = Namespace('contracts', description='Gestão de Contratos de Dados')

# Modelos para documentação Swagger
contract_model = api.model('DataContract', {
    'id': fields.String(description='ID único do contrato'),
    'name': fields.String(required=True, description='Nome do contrato'),
    'description': fields.String(description='Descrição do contrato'),
    'version': fields.String(description='Versão atual'),
    'status': fields.String(enum=['draft', 'active', 'deprecated', 'archived']),
    'schema_definition': fields.Raw(required=True, description='Definição do schema JSON'),
    'data_classification': fields.String(enum=['public', 'internal', 'confidential', 'restricted']),
    'business_domain': fields.String(description='Domínio de negócio'),
    'tags': fields.List(fields.String, description='Tags do contrato'),
    'created_at': fields.DateTime(description='Data de criação'),
    'updated_at': fields.DateTime(description='Data de atualização')
})

contract_create_model = api.model('CreateContract', {
    'name': fields.String(required=True, description='Nome do contrato'),
    'description': fields.String(description='Descrição do contrato'),
    'schema_definition': fields.Raw(required=True, description='Definição do schema JSON'),
    'data_classification': fields.String(enum=['public', 'internal', 'confidential', 'restricted'], default='internal'),
    'business_domain': fields.String(description='Domínio de negócio'),
    'tags': fields.List(fields.String, description='Tags do contrato'),
    'metadata': fields.Raw(description='Metadados adicionais')
})

contract_update_model = api.model('UpdateContract', {
    'description': fields.String(description='Descrição do contrato'),
    'schema_definition': fields.Raw(description='Definição do schema JSON'),
    'business_domain': fields.String(description='Domínio de negócio'),
    'tags': fields.List(fields.String, description='Tags do contrato'),
    'metadata': fields.Raw(description='Metadados adicionais')
})

validation_model = api.model('ValidationRequest', {
    'data': fields.Raw(required=True, description='Dados para validação')
})

validation_result_model = api.model('ValidationResult', {
    'is_valid': fields.Boolean(description='Se os dados são válidos'),
    'errors': fields.List(fields.String, description='Lista de erros'),
    'warnings': fields.List(fields.String, description='Lista de avisos'),
    'formatted_data': fields.Raw(description='Dados formatados para o país')
})


@ns.route('/')
class ContractList(Resource):
    @api.doc('list_contracts')
    @api.param('page', 'Número da página', type='integer', default=1)
    @api.param('per_page', 'Itens por página', type='integer', default=20)
    @api.param('status', 'Filtrar por status', enum=['draft', 'active', 'deprecated', 'archived'])
    @api.param('business_domain', 'Filtrar por domínio de negócio')
    @api.param('search', 'Buscar por nome ou descrição')
    @api.marshal_list_with(contract_model)
    def get(self):
        """Lista contratos de dados com filtros e paginação"""
        try:
            # Extrair parâmetros
            page = request.args.get('page', 1, type=int)
            per_page = request.args.get('per_page', 20, type=int)
            status = request.args.get('status')
            business_domain = request.args.get('business_domain')
            search = request.args.get('search')
            
            # Buscar contratos
            contracts, total = ContractService.get_contracts(
                page=page,
                per_page=per_page,
                status=status,
                business_domain=business_domain,
                search=search,
                country_code=g.country_code
            )
            
            # Converter para dicionários
            result = []
            for contract in contracts:
                contract_dict = contract.to_dict()
                result.append(contract_dict)
            
            return {
                'contracts': result,
                'pagination': {
                    'page': page,
                    'per_page': per_page,
                    'total': total,
                    'pages': (total + per_page - 1) // per_page
                }
            }
            
        except Exception as e:
            logging.error(f"Error listing contracts: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")
    
    @api.doc('create_contract')
    @api.expect(contract_create_model)
    @api.marshal_with(contract_model, code=201)
    def post(self):
        """Cria um novo contrato de dados"""
        try:
            data = request.get_json()
            
            # Validar dados obrigatórios
            if not data:
                api.abort(400, "Dados não fornecidos")
            
            # Criar contrato
            contract = ContractService.create_contract(
                data=data,
                user_id=g.user_id,
                country_code=g.country_code
            )
            
            return contract.to_dict(), 201
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error creating contract: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/<string:contract_id>')
class Contract(Resource):
    @api.doc('get_contract')
    @api.marshal_with(contract_model)
    def get(self, contract_id):
        """Obtém um contrato específico"""
        try:
            contract = ContractService.get_contract_by_id(
                contract_id,
                country_code=g.country_code
            )
            
            if not contract:
                api.abort(404, "Contrato não encontrado")
            
            return contract.to_dict()
            
        except Exception as e:
            logging.error(f"Error getting contract {contract_id}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")
    
    @api.doc('update_contract')
    @api.expect(contract_update_model)
    @api.marshal_with(contract_model)
    def put(self, contract_id):
        """Atualiza um contrato existente"""
        try:
            data = request.get_json()
            
            if not data:
                api.abort(400, "Dados não fornecidos")
            
            contract = ContractService.update_contract(
                contract_id=contract_id,
                data=data,
                user_id=g.user_id
            )
            
            return contract.to_dict()
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error updating contract {contract_id}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")
    
    @api.doc('delete_contract')
    def delete(self, contract_id):
        """Remove um contrato"""
        try:
            contract = ContractService.get_contract_by_id(contract_id)
            
            if not contract:
                api.abort(404, "Contrato não encontrado")
            
            contract.delete()
            
            return {'message': 'Contrato removido com sucesso'}, 200
            
        except Exception as e:
            logging.error(f"Error deleting contract {contract_id}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/<string:contract_id>/activate')
class ContractActivation(Resource):
    @api.doc('activate_contract')
    @api.marshal_with(contract_model)
    def post(self, contract_id):
        """Ativa um contrato"""
        try:
            contract = ContractService.activate_contract(
                contract_id=contract_id,
                user_id=g.user_id
            )
            
            return contract.to_dict()
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error activating contract {contract_id}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/<string:contract_id>/validate')
class ContractValidation(Resource):
    @api.doc('validate_data')
    @api.expect(validation_model)
    @api.marshal_with(validation_result_model)
    def post(self, contract_id):
        """Valida dados contra um contrato"""
        try:
            request_data = request.get_json()
            
            if not request_data or 'data' not in request_data:
                api.abort(400, "Dados para validação não fornecidos")
            
            result = ContractService.validate_data_against_contract(
                contract_id=contract_id,
                data=request_data['data'],
                country_code=g.country_code
            )
            
            return result
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error validating data for contract {contract_id}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/<string:contract_id>/versions')
class ContractVersions(Resource):
    @api.doc('get_contract_versions')
    def get(self, contract_id):
        """Lista todas as versões de um contrato"""
        try:
            versions = ContractService.get_contract_versions(contract_id)
            
            result = []
            for version in versions:
                version_dict = version.to_dict()
                result.append(version_dict)
            
            return {'versions': result}
            
        except Exception as e:
            logging.error(f"Error getting versions for contract {contract_id}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/<string:contract_id>/layouts')
class ContractLayouts(Resource):
    @api.doc('get_contract_layouts')
    def get(self, contract_id):
        """Lista todos os layouts de um contrato"""
        try:
            layouts = ContractService.get_contract_layouts(contract_id)
            
            result = []
            for layout in layouts:
                layout_dict = layout.to_dict()
                result.append(layout_dict)
            
            return {'layouts': result}
            
        except Exception as e:
            logging.error(f"Error getting layouts for contract {contract_id}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


@ns.route('/<string:contract_id>/layouts/<string:country_code>')
class ContractCountryLayout(Resource):
    @api.doc('create_country_layout')
    def post(self, contract_id, country_code):
        """Cria layout específico para um país"""
        try:
            data = request.get_json() or {}
            
            layout = ContractService.create_layout_for_country(
                contract_id=contract_id,
                country_code=country_code,
                user_id=g.user_id,
                layout_config=data.get('layout_config')
            )
            
            return layout.to_dict(), 201
            
        except ValueError as e:
            api.abort(400, str(e))
        except Exception as e:
            logging.error(f"Error creating layout for contract {contract_id}, country {country_code}: {str(e)}")
            api.abort(500, f"Erro interno: {str(e)}")


# Registrar namespace
api.add_namespace(ns)

