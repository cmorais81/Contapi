"""
TBR GDP Core - Data Governance API
Configuração do Banco de Dados
"""

import os
from datetime import timedelta


class Config:
    """Configuração base da aplicação"""
    
    # Configurações básicas
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'tbr-gdp-core-secret-key-2025'
    
    # Banco de dados
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///src/database/app.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_size': 10,
        'pool_recycle': 3600,
        'pool_pre_ping': True
    }
    
    # Redis (cache)
    REDIS_URL = os.environ.get('REDIS_URL') or 'redis://localhost:6379/0'
    
    # JWT
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY') or 'jwt-secret-key'
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=24)
    
    # Unity Catalog
    UNITY_CATALOG_URL = os.environ.get('UNITY_CATALOG_URL') or 'https://databricks.company.com'
    UNITY_CATALOG_TOKEN = os.environ.get('UNITY_CATALOG_TOKEN') or 'dummy-token'
    
    # Configurações de aplicação
    ITEMS_PER_PAGE = 20
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    
    # Logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL') or 'INFO'
    
    # Multi-tenancy
    DEFAULT_COUNTRY_CODE = 'BR'
    DEFAULT_TENANT_ID = 'default'
    
    # Compliance
    COMPLIANCE_FRAMEWORKS = {
        'BR': ['LGPD'],
        'US': ['CCPA'],
        'EU': ['GDPR'],
        'GB': ['DPA'],
        'CA': ['PIPEDA']
    }


class DevelopmentConfig(Config):
    """Configuração para desenvolvimento"""
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///src/database/app.db'


class ProductionConfig(Config):
    """Configuração para produção"""
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'postgresql://user:pass@localhost/governance'


class TestingConfig(Config):
    """Configuração para testes"""
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'

