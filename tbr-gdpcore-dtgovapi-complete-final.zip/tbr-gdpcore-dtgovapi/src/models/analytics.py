"""
TBR GDP Core - Data Governance API
Modelos de Analytics
"""

from sqlalchemy import Column, String, DateTime, Text, Float, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from . import db, BaseModel


class GovernanceKPI(BaseModel):
    __tablename__ = 'governance_kpis'
    
    name = Column(String(255), nullable=False)
    value = Column(Float, nullable=False)
    target_value = Column(Float)
    measurement_date = Column(DateTime, nullable=False)
    category = Column(String(100))
    metadata = Column(JSONB)


class ReportDefinition(BaseModel):
    __tablename__ = 'report_definitions'
    
    name = Column(String(255), nullable=False)
    description = Column(Text)
    query_definition = Column(JSONB, nullable=False)
    parameters = Column(JSONB)
    schedule = Column(String(100))


class ReportExecution(BaseModel):
    __tablename__ = 'report_executions'
    
    report_id = Column(UUID(as_uuid=True), ForeignKey('report_definitions.id'))
    executed_by = Column(UUID(as_uuid=True), ForeignKey('users.id'))
    execution_time = Column(DateTime, nullable=False)
    status = Column(String(50), default='completed')
    results = Column(JSONB)
    
    # Relacionamentos
    report = relationship("ReportDefinition")
    executor = relationship("User")

