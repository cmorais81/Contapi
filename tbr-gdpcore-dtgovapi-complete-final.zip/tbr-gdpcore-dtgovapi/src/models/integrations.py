"""
TBR GDP Core - Data Governance API
Modelos de Integrações
"""

from sqlalchemy import Column, String, Boolean, DateTime, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from . import db, BaseModel


class IntegrationConfig(BaseModel):
    __tablename__ = 'integration_configs'
    
    name = Column(String(255), nullable=False)
    integration_type = Column(String(100), nullable=False)
    config = Column(JSONB, nullable=False)
    is_active = Column(Boolean, default=True)
    last_sync = Column(DateTime)


class SyncOperation(BaseModel):
    __tablename__ = 'sync_operations'
    
    integration_id = Column(UUID(as_uuid=True))
    operation_type = Column(String(100), nullable=False)
    status = Column(String(50), default='pending')
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    details = Column(JSONB)

