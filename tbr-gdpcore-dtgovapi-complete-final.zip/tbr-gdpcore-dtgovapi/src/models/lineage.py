"""
TBR GDP Core - Data Governance API
Modelos de Lineage de Dados e Unity Catalog External Lineage
"""

from sqlalchemy import Column, String, Boolean, DateTime, Text, Integer, ForeignKey, Enum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from . import db, BaseModel
import enum


class LineageType(enum.Enum):
    DIRECT = "direct"
    DERIVED = "derived"
    AGGREGATED = "aggregated"
    FILTERED = "filtered"
    JOINED = "joined"


class SystemType(enum.Enum):
    TABLEAU = "tableau"
    POWER_BI = "power_bi"
    LOOKER = "looker"
    QLIK = "qlik"
    SALESFORCE = "salesforce"
    SNOWFLAKE = "snowflake"
    DATABRICKS = "databricks"
    CUSTOM = "custom"


class EntityType(enum.Enum):
    DASHBOARD = "dashboard"
    REPORT = "report"
    DATASET = "dataset"
    WORKBOOK = "workbook"
    FLOW = "flow"
    MODEL = "model"


class DataLineage(BaseModel):
    __tablename__ = 'data_lineage'
    
    source_object_id = Column(UUID(as_uuid=True), ForeignKey('data_objects.id'), nullable=False)
    target_object_id = Column(UUID(as_uuid=True), ForeignKey('data_objects.id'), nullable=False)
    lineage_type = Column(Enum(LineageType), nullable=False)
    transformation_logic = Column(Text)
    column_mappings = Column(JSONB)
    confidence_score = Column(Float, default=1.0)
    is_active = Column(Boolean, default=True)
    
    # Relacionamentos
    source_object = relationship("DataObject", foreign_keys=[source_object_id], back_populates="source_lineages")
    target_object = relationship("DataObject", foreign_keys=[target_object_id], back_populates="target_lineages")


class ExternalMetadata(BaseModel):
    __tablename__ = 'external_metadata'
    
    external_metadata_id = Column(String(255), nullable=False, unique=True)
    name = Column(String(255), nullable=False)
    system_type = Column(Enum(SystemType), nullable=False)
    entity_type = Column(Enum(EntityType), nullable=False)
    external_url = Column(String(500))
    description = Column(Text)
    owner = Column(String(255))
    created_by_external = Column(String(255))
    external_created_at = Column(DateTime)
    external_updated_at = Column(DateTime)
    unity_catalog_external_id = Column(String(255))
    sync_status = Column(String(50), default='pending')
    last_sync_at = Column(DateTime)
    metadata_json = Column(JSONB)
    
    # Relacionamentos
    column_mappings = relationship("ExternalColumnMapping", back_populates="external_metadata", cascade="all, delete-orphan")
    lineage_relationships = relationship("ExternalLineageRelationship", back_populates="external_metadata", cascade="all, delete-orphan")
    
    def sync_to_unity_catalog(self):
        """Sincroniza metadados com Unity Catalog"""
        # Simular sincronização com Unity Catalog
        import uuid
        from datetime import datetime
        
        if not self.unity_catalog_external_id:
            self.unity_catalog_external_id = f"uc_external_{uuid.uuid4().hex[:8]}"
        
        self.sync_status = 'synced'
        self.last_sync_at = datetime.utcnow()
        self.save()
        
        return {
            'success': True,
            'unity_catalog_id': self.unity_catalog_external_id,
            'sync_timestamp': self.last_sync_at.isoformat()
        }


class ExternalColumnMapping(BaseModel):
    __tablename__ = 'external_column_mappings'
    
    external_metadata_id = Column(UUID(as_uuid=True), ForeignKey('external_metadata.id'), nullable=False)
    external_column_name = Column(String(255), nullable=False)
    internal_object_id = Column(UUID(as_uuid=True), ForeignKey('data_objects.id'))
    internal_column_name = Column(String(255))
    mapping_confidence = Column(Float, default=1.0)
    mapping_type = Column(String(50), default='direct')
    transformation_notes = Column(Text)
    
    # Relacionamentos
    external_metadata = relationship("ExternalMetadata", back_populates="column_mappings")
    internal_object = relationship("DataObject")


class ExternalLineageRelationship(BaseModel):
    __tablename__ = 'external_lineage_relationships'
    
    external_metadata_id = Column(UUID(as_uuid=True), ForeignKey('external_metadata.id'), nullable=False)
    internal_object_id = Column(UUID(as_uuid=True), ForeignKey('data_objects.id'), nullable=False)
    relationship_type = Column(String(50), nullable=False)  # 'source', 'target', 'reference'
    relationship_strength = Column(Float, default=1.0)
    discovered_method = Column(String(100))  # 'manual', 'api_scan', 'metadata_analysis'
    notes = Column(Text)
    
    # Relacionamentos
    external_metadata = relationship("ExternalMetadata", back_populates="lineage_relationships")
    internal_object = relationship("DataObject")

