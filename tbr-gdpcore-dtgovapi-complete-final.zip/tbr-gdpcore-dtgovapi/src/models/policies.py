"""
TBR GDP Core - Data Governance API
Modelos de Políticas de Dados
"""

from sqlalchemy import Column, String, Boolean, DateTime, Text, Enum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from . import db, BaseModel
import enum


class PolicyType(enum.Enum):
    ACCESS_CONTROL = "access_control"
    DATA_RETENTION = "data_retention"
    DATA_CLASSIFICATION = "data_classification"
    PRIVACY = "privacy"


class DataPolicy(BaseModel):
    __tablename__ = 'data_policies'
    
    name = Column(String(255), nullable=False)
    description = Column(Text)
    policy_type = Column(Enum(PolicyType), nullable=False)
    rules = Column(JSONB, nullable=False)
    is_active = Column(Boolean, default=True)
    applies_to = Column(ARRAY(String))  # Lista de objetos/domínios
    compliance_frameworks = Column(ARRAY(String))  # LGPD, GDPR, etc.

