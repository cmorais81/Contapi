"""
TBR GDP Core - Data Governance API
Modelos de Qualidade de Dados
"""

from sqlalchemy import Column, String, Boolean, DateTime, Text, Integer, Float, ForeignKey, Enum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from . import db, BaseModel
import enum


class QualityDimension(enum.Enum):
    COMPLETENESS = "completeness"
    ACCURACY = "accuracy"
    CONSISTENCY = "consistency"
    VALIDITY = "validity"
    UNIQUENESS = "uniqueness"
    TIMELINESS = "timeliness"


class RuleType(enum.Enum):
    NOT_NULL = "not_null"
    UNIQUE = "unique"
    RANGE = "range"
    PATTERN = "pattern"
    CUSTOM_SQL = "custom_sql"


class ExecutionStatus(enum.Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


class QualityRule(BaseModel):
    __tablename__ = 'quality_rules'
    
    name = Column(String(255), nullable=False)
    description = Column(Text)
    rule_type = Column(Enum(RuleType), nullable=False)
    dimension = Column(Enum(QualityDimension), nullable=False)
    contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts.id'))
    data_object_id = Column(UUID(as_uuid=True), ForeignKey('data_objects.id'))
    target_column = Column(String(100))
    rule_definition = Column(JSONB, nullable=False)
    threshold = Column(Float, default=100.0)
    is_active = Column(Boolean, default=True)
    severity = Column(String(20), default='medium')
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="quality_rules")
    data_object = relationship("DataObject", back_populates="quality_rules")
    executions = relationship("QualityExecution", back_populates="rule", cascade="all, delete-orphan")
    
    def execute(self):
        """Executa a regra de qualidade"""
        execution = QualityExecution(
            rule_id=self.id,
            status=ExecutionStatus.RUNNING
        )
        execution.save()
        
        try:
            # Simular execução da regra
            import random
            score = random.uniform(70, 100)
            passed = score >= self.threshold
            
            result = QualityResult(
                execution_id=execution.id,
                score=score,
                passed=passed,
                details={'simulated': True}
            )
            result.save()
            
            execution.status = ExecutionStatus.COMPLETED
            execution.save()
            
            return execution
        except Exception as e:
            execution.status = ExecutionStatus.FAILED
            execution.error_message = str(e)
            execution.save()
            raise


class QualityExecution(BaseModel):
    __tablename__ = 'quality_executions'
    
    rule_id = Column(UUID(as_uuid=True), ForeignKey('quality_rules.id'), nullable=False)
    status = Column(Enum(ExecutionStatus), default=ExecutionStatus.PENDING)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    error_message = Column(Text)
    
    # Relacionamentos
    rule = relationship("QualityRule", back_populates="executions")
    results = relationship("QualityResult", back_populates="execution", cascade="all, delete-orphan")


class QualityResult(BaseModel):
    __tablename__ = 'quality_results'
    
    execution_id = Column(UUID(as_uuid=True), ForeignKey('quality_executions.id'), nullable=False)
    score = Column(Float, nullable=False)
    passed = Column(Boolean, nullable=False)
    records_tested = Column(Integer)
    records_passed = Column(Integer)
    records_failed = Column(Integer)
    details = Column(JSONB)
    
    # Relacionamentos
    execution = relationship("QualityExecution", back_populates="results")

