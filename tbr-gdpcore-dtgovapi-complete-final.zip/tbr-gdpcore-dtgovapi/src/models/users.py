"""
TBR GDP Core - Data Governance API
Modelos de Usuários e Permissões
"""

from sqlalchemy import Column, String, Boolean, DateTime, Text, ForeignKey, Table
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from . import db, BaseModel
from werkzeug.security import generate_password_hash, check_password_hash


# Tabelas de associação
user_groups = Table('user_groups',
    Column('user_id', UUID(as_uuid=True), ForeignKey('users.id'), primary_key=True),
    Column('group_id', UUID(as_uuid=True), ForeignKey('groups.id'), primary_key=True)
)

group_permissions = Table('group_permissions',
    Column('group_id', UUID(as_uuid=True), ForeignKey('groups.id'), primary_key=True),
    Column('permission_id', UUID(as_uuid=True), ForeignKey('permissions.id'), primary_key=True)
)

user_permissions = Table('user_permissions',
    Column('user_id', UUID(as_uuid=True), ForeignKey('users.id'), primary_key=True),
    Column('permission_id', UUID(as_uuid=True), ForeignKey('permissions.id'), primary_key=True)
)


class User(BaseModel):
    __tablename__ = 'users'
    
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    first_name = Column(String(100))
    last_name = Column(String(100))
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    last_login = Column(DateTime)
    country_code = Column(String(2), default='BR')
    tenant_id = Column(String(100), default='default')
    preferences = Column(JSONB)
    
    # Relacionamentos
    groups = relationship("Group", secondary=user_groups, back_populates="users")
    permissions = relationship("Permission", secondary=user_permissions, back_populates="users")
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def has_permission(self, permission_name):
        # Verificar permissões diretas
        for perm in self.permissions:
            if perm.name == permission_name:
                return True
        
        # Verificar permissões via grupos
        for group in self.groups:
            for perm in group.permissions:
                if perm.name == permission_name:
                    return True
        
        return self.is_admin  # Admins têm todas as permissões


class Group(BaseModel):
    __tablename__ = 'groups'
    
    name = Column(String(100), unique=True, nullable=False)
    description = Column(Text)
    is_active = Column(Boolean, default=True)
    
    # Relacionamentos
    users = relationship("User", secondary=user_groups, back_populates="groups")
    permissions = relationship("Permission", secondary=group_permissions, back_populates="groups")


class Permission(BaseModel):
    __tablename__ = 'permissions'
    
    name = Column(String(100), unique=True, nullable=False)
    description = Column(Text)
    resource = Column(String(100))
    action = Column(String(50))
    
    # Relacionamentos
    users = relationship("User", secondary=user_permissions, back_populates="permissions")
    groups = relationship("Group", secondary=group_permissions, back_populates="permissions")


# Aliases para compatibilidade
UserGroup = user_groups
GroupPermissionAssignment = group_permissions
UserPermissionAssignment = user_permissions

