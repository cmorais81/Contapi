"""
TBR GDP Core - Data Governance API
Modelos de Detecção de Anomalias
"""

from sqlalchemy import Column, String, Boolean, DateTime, Text, Integer, Float, ForeignKey, Enum
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from . import db, BaseModel
import enum


class AnomalyType(enum.Enum):
    VOLUME_ANOMALY = "volume_anomaly"
    PATTERN_ANOMALY = "pattern_anomaly"
    QUALITY_ANOMALY = "quality_anomaly"
    SCHEMA_ANOMALY = "schema_anomaly"


class DetectionMethod(enum.Enum):
    ISOLATION_FOREST = "isolation_forest"
    LSTM_AUTOENCODER = "lstm_autoencoder"
    Z_SCORE = "z_score"
    ENSEMBLE = "ensemble"


class AnomalyStatus(enum.Enum):
    OPEN = "open"
    INVESTIGATING = "investigating"
    RESOLVED = "resolved"
    FALSE_POSITIVE = "false_positive"


class AnomalyDetection(BaseModel):
    __tablename__ = 'anomaly_detections'
    
    data_object_id = Column(UUID(as_uuid=True), ForeignKey('data_objects.id'), nullable=False)
    anomaly_type = Column(Enum(AnomalyType), nullable=False)
    detection_method = Column(Enum(DetectionMethod), nullable=False)
    anomaly_score = Column(Float, nullable=False)
    threshold = Column(Float, default=0.8)
    status = Column(Enum(AnomalyStatus), default=AnomalyStatus.OPEN)
    severity = Column(String(20), default='medium')
    description = Column(Text)
    detected_at = Column(DateTime, nullable=False)
    resolved_at = Column(DateTime)
    resolved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'))
    resolution_notes = Column(Text)
    metadata = Column(JSONB)
    
    # Relacionamentos
    data_object = relationship("DataObject", back_populates="anomaly_detections")
    resolver = relationship("User")
    
    def resolve(self, user_id, notes=None):
        """Resolve a anomalia"""
        from datetime import datetime
        self.status = AnomalyStatus.RESOLVED
        self.resolved_at = datetime.utcnow()
        self.resolved_by = user_id
        if notes:
            self.resolution_notes = notes
        self.save()
        return self

