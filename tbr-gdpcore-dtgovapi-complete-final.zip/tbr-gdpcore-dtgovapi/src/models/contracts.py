"""
TBR GDP Core - Data Governance API
Modelos de Contratos de Dados

Implementação completa dos modelos para contratos de dados
com versionamento e layouts por país.
"""

from sqlalchemy import Column, String, Boolean, DateTime, Text, Integer, ForeignKey, Enum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from . import db, BaseModel
import enum


class ContractStatus(enum.Enum):
    """Status do contrato"""
    DRAFT = "draft"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"


class DataClassification(enum.Enum):
    """Classificação de dados"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"


class CompatibilityMode(enum.Enum):
    """Modo de compatibilidade entre versões"""
    BACKWARD = "backward"
    FORWARD = "forward"
    FULL = "full"
    NONE = "none"


class DataContract(BaseModel):
    """Modelo para contratos de dados"""
    __tablename__ = 'data_contracts'
    
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text)
    version = Column(String(50), nullable=False, default='1.0.0')
    status = Column(Enum(ContractStatus), nullable=False, default=ContractStatus.DRAFT, index=True)
    schema_definition = Column(JSONB)
    data_classification = Column(Enum(DataClassification), default=DataClassification.INTERNAL)
    owner_id = Column(UUID(as_uuid=True), ForeignKey('users.id'))
    steward_id = Column(UUID(as_uuid=True), ForeignKey('users.id'))
    business_domain = Column(String(100), index=True)
    tags = Column(ARRAY(String))
    metadata = Column(JSONB)
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'))
    updated_by = Column(UUID(as_uuid=True), ForeignKey('users.id'))
    
    # Relacionamentos
    owner = relationship("User", foreign_keys=[owner_id], backref="owned_contracts")
    steward = relationship("User", foreign_keys=[steward_id], backref="stewarded_contracts")
    creator = relationship("User", foreign_keys=[created_by])
    updater = relationship("User", foreign_keys=[updated_by])
    
    versions = relationship("ContractVersion", back_populates="contract", cascade="all, delete-orphan")
    layouts = relationship("ContractLayout", back_populates="contract", cascade="all, delete-orphan")
    schema_definitions = relationship("ContractSchemaDefinition", back_populates="contract", cascade="all, delete-orphan")
    data_objects = relationship("DataObject", back_populates="contract")
    quality_rules = relationship("QualityRule", back_populates="contract")
    
    def __repr__(self):
        return f'<DataContract {self.name} v{self.version}>'
    
    def get_active_version(self):
        """Retorna a versão ativa do contrato"""
        return ContractVersion.query.filter_by(
            contract_id=self.id,
            is_active=True
        ).first()
    
    def get_layout_for_country(self, country_code):
        """Retorna o layout para um país específico"""
        return ContractLayout.query.filter_by(
            contract_id=self.id,
            country_code=country_code,
            is_active=True
        ).first()
    
    def validate_schema(self, data):
        """Valida dados contra o schema do contrato"""
        import jsonschema
        try:
            if self.schema_definition:
                jsonschema.validate(data, self.schema_definition)
                return True, None
        except jsonschema.ValidationError as e:
            return False, str(e)
        return True, None
    
    def get_compliance_requirements(self, country_code=None):
        """Retorna requisitos de compliance"""
        requirements = []
        
        if country_code:
            layout = self.get_layout_for_country(country_code)
            if layout and layout.compliance_requirements:
                requirements.extend(layout.compliance_requirements)
        
        # Adicionar requisitos baseados na classificação
        if self.data_classification == DataClassification.CONFIDENTIAL:
            requirements.extend(['encryption', 'access_control'])
        elif self.data_classification == DataClassification.RESTRICTED:
            requirements.extend(['encryption', 'access_control', 'audit_trail', 'approval_workflow'])
            
        return list(set(requirements))


class ContractVersion(BaseModel):
    """Modelo para versionamento de contratos"""
    __tablename__ = 'contract_versions'
    
    contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts.id'), nullable=False)
    version_number = Column(String(50), nullable=False)
    schema_definition = Column(JSONB, nullable=False)
    changelog = Column(Text)
    compatibility_mode = Column(Enum(CompatibilityMode), default=CompatibilityMode.BACKWARD)
    is_active = Column(Boolean, default=False)
    activation_date = Column(DateTime)
    deprecation_date = Column(DateTime)
    migration_guide = Column(Text)
    breaking_changes = Column(ARRAY(String))
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'))
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="versions")
    creator = relationship("User")
    
    def __repr__(self):
        return f'<ContractVersion {self.version_number}>'
    
    def activate(self):
        """Ativa esta versão e desativa outras"""
        # Desativar outras versões
        ContractVersion.query.filter_by(
            contract_id=self.contract_id,
            is_active=True
        ).update({'is_active': False})
        
        # Ativar esta versão
        self.is_active = True
        self.activation_date = datetime.utcnow()
        db.session.commit()
    
    def check_compatibility(self, other_version):
        """Verifica compatibilidade com outra versão"""
        import jsonschema
        
        if not other_version:
            return False, "Versão não encontrada"
        
        try:
            # Verificação básica de compatibilidade de schema
            if self.compatibility_mode == CompatibilityMode.BACKWARD:
                # Verificar se dados da versão anterior são válidos na nova
                return True, "Compatibilidade backward verificada"
            elif self.compatibility_mode == CompatibilityMode.FORWARD:
                # Verificar se dados da nova versão são válidos na anterior
                return True, "Compatibilidade forward verificada"
            elif self.compatibility_mode == CompatibilityMode.FULL:
                return True, "Compatibilidade total"
            else:
                return False, "Sem garantia de compatibilidade"
        except Exception as e:
            return False, f"Erro na verificação: {str(e)}"


class ContractLayout(BaseModel):
    """Modelo para layouts de contratos por país"""
    __tablename__ = 'contract_layouts'
    
    contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts.id'), nullable=False)
    country_code = Column(String(2), nullable=False, index=True)
    region_code = Column(String(10))
    layout_name = Column(String(100), nullable=False)
    layout_config = Column(JSONB, nullable=False)
    field_mappings = Column(JSONB)
    validation_rules = Column(JSONB)
    formatting_rules = Column(JSONB)
    compliance_requirements = Column(ARRAY(String))
    is_active = Column(Boolean, default=True)
    priority = Column(Integer, default=0)
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="layouts")
    
    def __repr__(self):
        return f'<ContractLayout {self.layout_name} ({self.country_code})>'
    
    def apply_formatting(self, data):
        """Aplica regras de formatação aos dados"""
        if not self.formatting_rules:
            return data
        
        formatted_data = data.copy()
        
        for field, rules in self.formatting_rules.items():
            if field in formatted_data:
                value = formatted_data[field]
                
                # Aplicar formatação de data
                if rules.get('type') == 'date' and rules.get('format'):
                    try:
                        from datetime import datetime
                        if isinstance(value, str):
                            # Converter para datetime e reformatar
                            dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
                            formatted_data[field] = dt.strftime(rules['format'])
                    except:
                        pass
                
                # Aplicar formatação de moeda
                elif rules.get('type') == 'currency':
                    try:
                        currency_symbol = rules.get('symbol', '$')
                        if isinstance(value, (int, float)):
                            formatted_data[field] = f"{currency_symbol}{value:,.2f}"
                    except:
                        pass
                
                # Aplicar formatação de telefone
                elif rules.get('type') == 'phone' and rules.get('pattern'):
                    try:
                        import re
                        # Remover caracteres não numéricos
                        clean_phone = re.sub(r'\D', '', str(value))
                        # Aplicar padrão
                        pattern = rules['pattern']
                        if len(clean_phone) >= 10:
                            formatted_data[field] = pattern.replace('X', '{}').format(*clean_phone)
                    except:
                        pass
        
        return formatted_data
    
    def validate_compliance(self, data):
        """Valida compliance com regulamentações locais"""
        violations = []
        
        if not self.compliance_requirements:
            return True, violations
        
        # Verificar LGPD (Brasil)
        if 'LGPD' in self.compliance_requirements:
            # Verificar se dados pessoais têm consentimento
            if self._contains_personal_data(data):
                if not data.get('consent_given'):
                    violations.append("LGPD: Consentimento necessário para dados pessoais")
        
        # Verificar GDPR (Europa)
        if 'GDPR' in self.compliance_requirements:
            if self._contains_personal_data(data):
                if not data.get('lawful_basis'):
                    violations.append("GDPR: Base legal necessária para processamento")
        
        # Verificar CCPA (Califórnia)
        if 'CCPA' in self.compliance_requirements:
            if self._contains_personal_data(data):
                if not data.get('privacy_notice_given'):
                    violations.append("CCPA: Aviso de privacidade necessário")
        
        return len(violations) == 0, violations
    
    def _contains_personal_data(self, data):
        """Verifica se os dados contêm informações pessoais"""
        personal_fields = ['email', 'phone', 'cpf', 'ssn', 'name', 'address']
        return any(field in data for field in personal_fields)


class ContractSchemaDefinition(BaseModel):
    """Modelo para definições de schema de contratos"""
    __tablename__ = 'contract_schema_definitions'
    
    contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts.id'), nullable=False)
    field_name = Column(String(100), nullable=False)
    field_type = Column(String(50), nullable=False)
    field_description = Column(Text)
    is_required = Column(Boolean, default=False)
    is_pii = Column(Boolean, default=False)
    default_value = Column(String(255))
    validation_pattern = Column(String(500))
    min_length = Column(Integer)
    max_length = Column(Integer)
    min_value = Column(Float)
    max_value = Column(Float)
    enum_values = Column(ARRAY(String))
    format_hint = Column(String(100))
    business_rules = Column(Text)
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="schema_definitions")
    
    def __repr__(self):
        return f'<ContractSchemaDefinition {self.field_name}>'
    
    def validate_field_value(self, value):
        """Valida um valor contra as regras do campo"""
        errors = []
        
        # Verificar se é obrigatório
        if self.is_required and (value is None or value == ''):
            errors.append(f"Campo {self.field_name} é obrigatório")
            return False, errors
        
        if value is None:
            return True, errors
        
        # Verificar tipo
        if self.field_type == 'string' and not isinstance(value, str):
            errors.append(f"Campo {self.field_name} deve ser string")
        elif self.field_type == 'integer' and not isinstance(value, int):
            errors.append(f"Campo {self.field_name} deve ser inteiro")
        elif self.field_type == 'number' and not isinstance(value, (int, float)):
            errors.append(f"Campo {self.field_name} deve ser número")
        elif self.field_type == 'boolean' and not isinstance(value, bool):
            errors.append(f"Campo {self.field_name} deve ser booleano")
        
        # Verificar comprimento
        if isinstance(value, str):
            if self.min_length and len(value) < self.min_length:
                errors.append(f"Campo {self.field_name} deve ter pelo menos {self.min_length} caracteres")
            if self.max_length and len(value) > self.max_length:
                errors.append(f"Campo {self.field_name} deve ter no máximo {self.max_length} caracteres")
        
        # Verificar valores numéricos
        if isinstance(value, (int, float)):
            if self.min_value is not None and value < self.min_value:
                errors.append(f"Campo {self.field_name} deve ser pelo menos {self.min_value}")
            if self.max_value is not None and value > self.max_value:
                errors.append(f"Campo {self.field_name} deve ser no máximo {self.max_value}")
        
        # Verificar enum
        if self.enum_values and value not in self.enum_values:
            errors.append(f"Campo {self.field_name} deve ser um dos valores: {', '.join(self.enum_values)}")
        
        # Verificar padrão regex
        if self.validation_pattern and isinstance(value, str):
            import re
            if not re.match(self.validation_pattern, value):
                errors.append(f"Campo {self.field_name} não atende ao padrão exigido")
        
        return len(errors) == 0, errors

