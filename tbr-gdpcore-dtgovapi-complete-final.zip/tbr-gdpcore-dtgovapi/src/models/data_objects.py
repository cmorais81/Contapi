"""
TBR GDP Core - Data Governance API
Modelos de Objetos de Dados

Implementação completa dos modelos para catálogo de objetos de dados
e suas propriedades com profiling automático.
"""

from sqlalchemy import Column, String, Boolean, DateTime, Text, Integer, BigInteger, Float, ForeignKey, Enum
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import relationship
from . import db, BaseModel
import enum


class ObjectType(enum.Enum):
    """Tipo do objeto de dados"""
    TABLE = "table"
    VIEW = "view"
    FILE = "file"
    API = "api"
    STREAM = "stream"


class DataObject(BaseModel):
    """Modelo para objetos de dados"""
    __tablename__ = 'data_objects'
    
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text)
    object_type = Column(Enum(ObjectType), nullable=False, index=True)
    data_source = Column(String(100), index=True)
    schema_name = Column(String(100))
    table_name = Column(String(100))
    full_path = Column(String(500), index=True)
    contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts.id'))
    business_domain = Column(String(100), index=True)
    data_classification = Column(String(50), default='internal')
    contains_pii = Column(Boolean, default=False, index=True)
    record_count = Column(BigInteger)
    data_size_bytes = Column(BigInteger)
    last_updated = Column(DateTime)
    update_frequency = Column(String(50))
    retention_period = Column(String(50))
    tags = Column(ARRAY(String))
    metadata = Column(JSONB)
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="data_objects")
    properties = relationship("DataObjectProperty", back_populates="data_object", cascade="all, delete-orphan")
    quality_rules = relationship("QualityRule", back_populates="data_object")
    source_lineages = relationship("DataLineage", foreign_keys="DataLineage.source_object_id", back_populates="source_object")
    target_lineages = relationship("DataLineage", foreign_keys="DataLineage.target_object_id", back_populates="target_object")
    anomaly_detections = relationship("AnomalyDetection", back_populates="data_object")
    
    def __repr__(self):
        return f'<DataObject {self.name}>'
    
    def get_quality_score(self):
        """Calcula score de qualidade baseado nas propriedades"""
        if not self.properties:
            return None
        
        total_score = 0
        count = 0
        
        for prop in self.properties:
            if prop.quality_score is not None:
                total_score += prop.quality_score
                count += 1
        
        return total_score / count if count > 0 else None
    
    def get_pii_fields(self):
        """Retorna lista de campos que contêm PII"""
        return [prop.property_name for prop in self.properties if prop.is_pii]
    
    def get_data_profile(self):
        """Retorna perfil completo dos dados"""
        profile = {
            'object_info': {
                'name': self.name,
                'type': self.object_type.value,
                'record_count': self.record_count,
                'data_size_bytes': self.data_size_bytes,
                'last_updated': self.last_updated.isoformat() if self.last_updated else None
            },
            'quality_score': self.get_quality_score(),
            'pii_fields': self.get_pii_fields(),
            'properties': []
        }
        
        for prop in self.properties:
            prop_profile = {
                'name': prop.property_name,
                'type': prop.property_type,
                'nullable': prop.is_nullable,
                'pii': prop.is_pii,
                'distinct_count': prop.distinct_count,
                'null_count': prop.null_count,
                'quality_score': prop.quality_score
            }
            
            if prop.sample_values:
                prop_profile['sample_values'] = prop.sample_values[:5]  # Primeiros 5 valores
            
            profile['properties'].append(prop_profile)
        
        return profile
    
    def update_statistics(self):
        """Atualiza estatísticas do objeto"""
        from datetime import datetime
        
        # Simular atualização de estatísticas
        # Em um ambiente real, isso conectaria ao sistema de dados
        self.last_updated = datetime.utcnow()
        
        # Atualizar contagem de registros baseado nas propriedades
        if self.properties:
            max_count = max([prop.distinct_count or 0 for prop in self.properties])
            if max_count > 0:
                self.record_count = max_count
        
        # Calcular se contém PII
        self.contains_pii = any(prop.is_pii for prop in self.properties)
        
        db.session.commit()
    
    def get_lineage_upstream(self, depth=3):
        """Retorna objetos upstream na linhagem"""
        upstream = []
        current_depth = 0
        
        def _get_upstream(obj_id, current_depth):
            if current_depth >= depth:
                return
            
            lineages = DataLineage.query.filter_by(target_object_id=obj_id).all()
            for lineage in lineages:
                upstream.append({
                    'object': lineage.source_object,
                    'lineage_type': lineage.lineage_type.value,
                    'depth': current_depth + 1
                })
                _get_upstream(lineage.source_object_id, current_depth + 1)
        
        _get_upstream(self.id, current_depth)
        return upstream
    
    def get_lineage_downstream(self, depth=3):
        """Retorna objetos downstream na linhagem"""
        downstream = []
        current_depth = 0
        
        def _get_downstream(obj_id, current_depth):
            if current_depth >= depth:
                return
            
            lineages = DataLineage.query.filter_by(source_object_id=obj_id).all()
            for lineage in lineages:
                downstream.append({
                    'object': lineage.target_object,
                    'lineage_type': lineage.lineage_type.value,
                    'depth': current_depth + 1
                })
                _get_downstream(lineage.target_object_id, current_depth + 1)
        
        _get_downstream(self.id, current_depth)
        return downstream


class DataObjectProperty(BaseModel):
    """Modelo para propriedades/colunas dos objetos de dados"""
    __tablename__ = 'data_object_properties'
    
    data_object_id = Column(UUID(as_uuid=True), ForeignKey('data_objects.id'), nullable=False)
    property_name = Column(String(100), nullable=False, index=True)
    property_type = Column(String(50), nullable=False)
    property_description = Column(Text)
    is_nullable = Column(Boolean, default=True)
    is_primary_key = Column(Boolean, default=False)
    is_foreign_key = Column(Boolean, default=False)
    is_indexed = Column(Boolean, default=False)
    is_pii = Column(Boolean, default=False, index=True)
    data_classification = Column(String(50))
    sample_values = Column(ARRAY(String))
    distinct_count = Column(BigInteger)
    null_count = Column(BigInteger)
    min_value = Column(String(255))
    max_value = Column(String(255))
    avg_length = Column(Float)
    pattern_analysis = Column(JSONB)
    quality_score = Column(Float)
    
    # Relacionamentos
    data_object = relationship("DataObject", back_populates="properties")
    
    def __repr__(self):
        return f'<DataObjectProperty {self.property_name}>'
    
    def calculate_quality_score(self):
        """Calcula score de qualidade da propriedade"""
        score = 100.0
        
        # Penalizar por valores nulos se não deveria ser nullable
        if not self.is_nullable and self.null_count and self.data_object.record_count:
            null_percentage = (self.null_count / self.data_object.record_count) * 100
            score -= null_percentage
        
        # Penalizar por baixa cardinalidade em campos que deveriam ser únicos
        if self.is_primary_key and self.distinct_count and self.data_object.record_count:
            if self.distinct_count < self.data_object.record_count:
                uniqueness_percentage = (self.distinct_count / self.data_object.record_count) * 100
                score = min(score, uniqueness_percentage)
        
        # Bonus por ter descrição
        if self.property_description:
            score = min(100.0, score + 5.0)
        
        # Bonus por ter classificação de dados
        if self.data_classification:
            score = min(100.0, score + 2.0)
        
        self.quality_score = max(0.0, score)
        return self.quality_score
    
    def analyze_patterns(self):
        """Analisa padrões nos dados da propriedade"""
        if not self.sample_values:
            return None
        
        patterns = {
            'data_types': {},
            'formats': {},
            'lengths': [],
            'common_patterns': []
        }
        
        import re
        
        for value in self.sample_values:
            if value is None:
                continue
            
            value_str = str(value)
            
            # Analisar tipos de dados
            if value_str.isdigit():
                patterns['data_types']['numeric'] = patterns['data_types'].get('numeric', 0) + 1
            elif re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', value_str):
                patterns['data_types']['email'] = patterns['data_types'].get('email', 0) + 1
                patterns['formats']['email'] = True
            elif re.match(r'^\d{4}-\d{2}-\d{2}', value_str):
                patterns['data_types']['date'] = patterns['data_types'].get('date', 0) + 1
                patterns['formats']['iso_date'] = True
            elif re.match(r'^\+?[\d\s\-\(\)]+$', value_str):
                patterns['data_types']['phone'] = patterns['data_types'].get('phone', 0) + 1
                patterns['formats']['phone'] = True
            else:
                patterns['data_types']['text'] = patterns['data_types'].get('text', 0) + 1
            
            # Analisar comprimentos
            patterns['lengths'].append(len(value_str))
        
        # Calcular estatísticas de comprimento
        if patterns['lengths']:
            patterns['avg_length'] = sum(patterns['lengths']) / len(patterns['lengths'])
            patterns['min_length'] = min(patterns['lengths'])
            patterns['max_length'] = max(patterns['lengths'])
        
        # Identificar padrões comuns
        if patterns['data_types'].get('email', 0) > 0:
            patterns['common_patterns'].append('email_format')
        if patterns['data_types'].get('phone', 0) > 0:
            patterns['common_patterns'].append('phone_format')
        if patterns['data_types'].get('date', 0) > 0:
            patterns['common_patterns'].append('date_format')
        
        self.pattern_analysis = patterns
        return patterns
    
    def detect_pii(self):
        """Detecta automaticamente se o campo contém PII"""
        pii_indicators = [
            'email', 'mail', 'e-mail',
            'phone', 'telefone', 'celular',
            'cpf', 'cnpj', 'ssn',
            'name', 'nome', 'firstname', 'lastname',
            'address', 'endereco', 'rua',
            'birth', 'nascimento', 'birthday',
            'password', 'senha', 'pwd'
        ]
        
        field_name_lower = self.property_name.lower()
        
        # Verificar nome do campo
        for indicator in pii_indicators:
            if indicator in field_name_lower:
                self.is_pii = True
                return True
        
        # Verificar padrões nos dados
        if self.pattern_analysis:
            if 'email_format' in self.pattern_analysis.get('common_patterns', []):
                self.is_pii = True
                return True
            if 'phone_format' in self.pattern_analysis.get('common_patterns', []):
                self.is_pii = True
                return True
        
        return False
    
    def get_data_quality_issues(self):
        """Identifica problemas de qualidade nos dados"""
        issues = []
        
        # Verificar valores nulos em campos obrigatórios
        if not self.is_nullable and self.null_count and self.null_count > 0:
            issues.append({
                'type': 'null_values_in_required_field',
                'severity': 'high',
                'description': f'Campo obrigatório {self.property_name} tem {self.null_count} valores nulos'
            })
        
        # Verificar unicidade em chaves primárias
        if self.is_primary_key and self.distinct_count and self.data_object.record_count:
            if self.distinct_count < self.data_object.record_count:
                duplicates = self.data_object.record_count - self.distinct_count
                issues.append({
                    'type': 'duplicate_primary_key',
                    'severity': 'critical',
                    'description': f'Chave primária {self.property_name} tem {duplicates} valores duplicados'
                })
        
        # Verificar cardinalidade muito baixa
        if self.distinct_count and self.data_object.record_count:
            cardinality_ratio = self.distinct_count / self.data_object.record_count
            if cardinality_ratio < 0.01 and not self.property_name.lower() in ['status', 'type', 'category']:
                issues.append({
                    'type': 'low_cardinality',
                    'severity': 'medium',
                    'description': f'Campo {self.property_name} tem cardinalidade muito baixa ({cardinality_ratio:.2%})'
                })
        
        # Verificar PII não classificado
        if self.is_pii and not self.data_classification:
            issues.append({
                'type': 'unclassified_pii',
                'severity': 'high',
                'description': f'Campo PII {self.property_name} não tem classificação de dados'
            })
        
        return issues

