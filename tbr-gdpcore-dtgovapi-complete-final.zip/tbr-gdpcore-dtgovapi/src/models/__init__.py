"""
TBR GDP Core - Data Governance API
Modelos de Dados SQLAlchemy

Implementação completa dos modelos baseados no modelo DBML
"""

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import uuid
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy import Column, String, Boolean, DateTime, Text, Integer, Float, ForeignKey, Table
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

# Inicializar SQLAlchemy
db = SQLAlchemy()

# Base para todos os modelos
class BaseModel(db.Model):
    """Modelo base com campos comuns"""
    __abstract__ = True
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """Converte modelo para dicionário"""
        result = {}
        for column in self.__table__.columns:
            value = getattr(self, column.name)
            if isinstance(value, datetime):
                result[column.name] = value.isoformat()
            elif isinstance(value, uuid.UUID):
                result[column.name] = str(value)
            else:
                result[column.name] = value
        return result
    
    def save(self):
        """Salva o modelo no banco"""
        db.session.add(self)
        db.session.commit()
        return self
    
    def delete(self):
        """Remove o modelo do banco"""
        db.session.delete(self)
        db.session.commit()
        return True

# Importar todos os modelos
from .contracts import DataContract, ContractVersion, ContractLayout, ContractSchemaDefinition
from .data_objects import DataObject, DataObjectProperty
from .quality import QualityRule, QualityExecution, QualityResult
from .lineage import DataLineage, ExternalMetadata, ExternalColumnMapping, ExternalLineageRelationship
from .anomalies import AnomalyDetection
from .policies import DataPolicy
from .users import User, Group, Permission, UserGroup, GroupPermissionAssignment, UserPermissionAssignment
from .audit import AuditLog
from .analytics import GovernanceKPI, ReportDefinition, ReportExecution
from .integrations import IntegrationConfig, SyncOperation

# Lista de todos os modelos para facilitar importação
__all__ = [
    'db', 'BaseModel',
    'DataContract', 'ContractVersion', 'ContractLayout', 'ContractSchemaDefinition',
    'DataObject', 'DataObjectProperty',
    'QualityRule', 'QualityExecution', 'QualityResult',
    'DataLineage', 'ExternalMetadata', 'ExternalColumnMapping', 'ExternalLineageRelationship',
    'AnomalyDetection',
    'DataPolicy',
    'User', 'Group', 'Permission', 'UserGroup', 'GroupPermissionAssignment', 'UserPermissionAssignment',
    'AuditLog',
    'GovernanceKPI', 'ReportDefinition', 'ReportExecution',
    'IntegrationConfig', 'SyncOperation'
]

