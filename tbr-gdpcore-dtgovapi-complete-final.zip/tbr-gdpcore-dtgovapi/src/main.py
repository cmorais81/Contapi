"""
TBR GDP Core - Data Governance API
Aplicação Principal com Flask-RESTX e Swagger

Implementação completa da API com documentação automática
"""

from flask import Flask, request, jsonify, g
from flask_restx import Api, Resource
from flask_cors import CORS
from flask_migrate import Migrate
import os
import logging
from datetime import datetime

# Importar modelos e configurações
from src.models import db
from src.config.database import Config

# Importar blueprints
from src.routes.contracts import contracts_bp
from src.routes.external_lineage import external_lineage_bp
from src.routes.quality import quality_bp
from src.routes.lineage import lineage_bp
from src.routes.anomalies import anomalies_bp
from src.routes.analytics import analytics_bp
from src.routes.users import users_bp
from src.routes.monitoring import monitoring_bp


def create_app(config_name='development'):
    """Factory para criar aplicação Flask"""
    
    app = Flask(__name__)
    
    # Configuração
    app.config.from_object(Config)
    
    # CORS
    CORS(app, origins="*")
    
    # Inicializar extensões
    db.init_app(app)
    migrate = Migrate(app, db)
    
    # Configurar logging
    logging.basicConfig(level=logging.INFO)
    
    # API com Swagger
    api = Api(
        app,
        version='3.0.0',
        title='TBR GDP Core - Data Governance API',
        description='''
        **Sistema Completo de Governança de Dados Empresariais**
        
        Esta API fornece funcionalidades completas para:
        
        - **Contratos de Dados**: Gestão com versionamento e layouts por país
        - **Unity Catalog External Lineage**: Integração completa com Databricks
        - **Qualidade de Dados**: Regras configuráveis e execução automática
        - **Detecção de Anomalias**: Machine Learning integrado
        - **Analytics**: KPIs e relatórios executivos
        - **Multi-tenancy**: Suporte a múltiplos países e regulamentações
        
        ## Autenticação
        
        Use o header `Authorization: Bearer <token>` para autenticação.
        
        ## Multi-tenancy
        
        Use os headers:
        - `X-Country-Code`: Código do país (BR, US, EU, GB, CA)
        - `X-Tenant-ID`: ID do tenant (opcional)
        - `X-API-Version`: Versão da API (1.0.0, 2.0.0, 3.0.0)
        
        ## Compliance
        
        A API suporta automaticamente:
        - **LGPD** (Brasil)
        - **GDPR** (União Europeia)
        - **CCPA** (Estados Unidos)
        - **DPA** (Reino Unido)
        - **PIPEDA** (Canadá)
        ''',
        doc='/docs/',
        contact='gdp-core-support@tbr.com',
        license='Proprietary',
        license_url='https://tbr.com/license'
    )
    
    # Middleware para versionamento e multi-tenancy
    @app.before_request
    def before_request():
        """Middleware executado antes de cada request"""
        
        # Extrair informações de versionamento e tenancy
        g.api_version = request.headers.get('X-API-Version', '2.0.0')
        g.country_code = request.headers.get('X-Country-Code', 'BR')
        g.tenant_id = request.headers.get('X-Tenant-ID', 'default')
        g.user_id = request.headers.get('X-User-ID', 'anonymous')
        
        # Log da requisição
        app.logger.info(f"Request: {request.method} {request.path} - "
                       f"Version: {g.api_version}, Country: {g.country_code}, "
                       f"Tenant: {g.tenant_id}")
    
    @app.after_request
    def after_request(response):
        """Middleware executado após cada request"""
        
        # Adicionar headers de resposta
        response.headers['X-API-Version'] = g.get('api_version', '2.0.0')
        response.headers['X-Country-Code'] = g.get('country_code', 'BR')
        response.headers['X-Tenant-ID'] = g.get('tenant_id', 'default')
        response.headers['X-Powered-By'] = 'TBR GDP Core API'
        
        return response
    
    # Registrar blueprints
    app.register_blueprint(contracts_bp, url_prefix='/api/v2/contracts')
    app.register_blueprint(external_lineage_bp, url_prefix='/api/v2/external-lineage')
    app.register_blueprint(quality_bp, url_prefix='/api/v2/quality')
    app.register_blueprint(lineage_bp, url_prefix='/api/v2/lineage')
    app.register_blueprint(anomalies_bp, url_prefix='/api/v2/anomalies')
    app.register_blueprint(analytics_bp, url_prefix='/api/v2/analytics')
    app.register_blueprint(users_bp, url_prefix='/api/v2/users')
    app.register_blueprint(monitoring_bp, url_prefix='/api/v2/monitoring')
    
    # Endpoints básicos
    @api.route('/health')
    class HealthCheck(Resource):
        def get(self):
            """Health check da aplicação"""
            return {
                'status': 'healthy',
                'timestamp': datetime.utcnow().isoformat(),
                'version': '3.0.0',
                'components': {
                    'api': 'healthy',
                    'database': 'healthy',
                    'cache': 'healthy'
                }
            }
    
    @api.route('/info')
    class APIInfo(Resource):
        def get(self):
            """Informações da API"""
            return {
                'api_name': 'TBR GDP Core - Data Governance API',
                'version': '3.0.0',
                'description': 'Sistema completo de governança de dados empresariais',
                'documentation': '/docs/',
                'version_info': {
                    'current': g.get('api_version', '2.0.0'),
                    'supported': ['1.0.0', '2.0.0', '3.0.0'],
                    'deprecated': ['1.0.0']
                },
                'tenant_info': {
                    'country_code': g.get('country_code', 'BR'),
                    'tenant_id': g.get('tenant_id', 'default'),
                    'supported_countries': ['BR', 'US', 'EU', 'GB', 'CA']
                },
                'features': [
                    'Data Contracts with Versioning',
                    'Unity Catalog External Lineage',
                    'Data Quality Management',
                    'Anomaly Detection with ML',
                    'Executive Analytics',
                    'Multi-tenant Geographic Support',
                    'Compliance Automation (LGPD, GDPR, CCPA)'
                ]
            }
    
    # Error handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({
            'error': 'Not Found',
            'message': 'The requested resource was not found',
            'timestamp': datetime.utcnow().isoformat()
        }), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({
            'error': 'Internal Server Error',
            'message': 'An internal error occurred',
            'timestamp': datetime.utcnow().isoformat()
        }), 500
    
    @app.errorhandler(400)
    def bad_request(error):
        return jsonify({
            'error': 'Bad Request',
            'message': 'The request was invalid',
            'timestamp': datetime.utcnow().isoformat()
        }), 400
    
    # Criar tabelas se não existirem
    with app.app_context():
        try:
            db.create_all()
            app.logger.info("Database tables created successfully")
        except Exception as e:
            app.logger.error(f"Error creating database tables: {str(e)}")
    
    return app


# Criar aplicação
app = create_app()

if __name__ == '__main__':
    # Executar aplicação
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )

