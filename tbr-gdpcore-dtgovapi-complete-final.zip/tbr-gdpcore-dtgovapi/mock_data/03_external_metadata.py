#!/usr/bin/env python3
"""
TBR GDP Core API - Mock Data: External Metadata
Cria metadados externos para Unity Catalog External Lineage
"""

import os
import sys
import requests
import json
from datetime import datetime, timedelta

# Configurações
API_BASE_URL = os.environ.get('API_BASE_URL', 'http://localhost:5000')

# Metadados externos de exemplo
EXTERNAL_METADATA = [
    # Tableau
    {
        "name": "Sales Performance Dashboard",
        "system_type": "tableau",
        "entity_type": "dashboard",
        "external_url": "https://tableau.company.com/dashboard/sales-performance",
        "description": "Dashboard principal de performance de vendas",
        "owner": "sales.team@company.com",
        "metadata": {
            "workbook": "Sales Analytics",
            "project": "Executive Dashboards",
            "last_refresh": "2025-01-07T08:00:00Z",
            "refresh_frequency": "daily",
            "data_sources": ["sales_db", "customer_db"],
            "filters": ["region", "date_range", "product_category"]
        },
        "column_mappings": [
            {
                "external_column_name": "Customer Name",
                "internal_column_name": "name",
                "mapping_confidence": 0.95,
                "mapping_type": "direct"
            },
            {
                "external_column_name": "Total Sales",
                "internal_column_name": "total_amount",
                "mapping_confidence": 0.98,
                "mapping_type": "direct"
            }
        ]
    },
    {
        "name": "Customer Segmentation Report",
        "system_type": "tableau",
        "entity_type": "report",
        "external_url": "https://tableau.company.com/report/customer-segmentation",
        "description": "Relatório de segmentação de clientes",
        "owner": "marketing.team@company.com",
        "metadata": {
            "workbook": "Customer Analytics",
            "project": "Marketing Reports",
            "parameters": ["segment_type", "date_range"],
            "calculated_fields": ["customer_lifetime_value", "churn_probability"]
        }
    },
    
    # Power BI
    {
        "name": "Financial KPIs Dashboard",
        "system_type": "power_bi",
        "entity_type": "dashboard",
        "external_url": "https://app.powerbi.com/dashboard/financial-kpis",
        "description": "Dashboard de KPIs financeiros",
        "owner": "finance.team@company.com",
        "metadata": {
            "workspace": "Finance",
            "dataset": "Financial Data",
            "last_refresh": "2025-01-07T06:00:00Z",
            "refresh_schedule": "hourly",
            "measures": ["revenue", "profit_margin", "cash_flow"]
        }
    },
    {
        "name": "Monthly Revenue Report",
        "system_type": "power_bi",
        "entity_type": "report",
        "external_url": "https://app.powerbi.com/report/monthly-revenue",
        "description": "Relatório mensal de receita",
        "owner": "finance.analyst@company.com",
        "metadata": {
            "workspace": "Finance",
            "dataset": "Sales Data",
            "pages": ["Overview", "By Region", "By Product", "Trends"]
        }
    },
    
    # Salesforce
    {
        "name": "Account Object",
        "system_type": "salesforce",
        "entity_type": "dataset",
        "external_url": "https://company.salesforce.com/Account",
        "description": "Objeto Account do Salesforce",
        "owner": "salesforce.admin@company.com",
        "metadata": {
            "object_type": "standard",
            "api_name": "Account",
            "record_count": 15000,
            "fields_count": 45,
            "custom_fields": ["Industry_Segment__c", "Customer_Tier__c"]
        },
        "column_mappings": [
            {
                "external_column_name": "Name",
                "internal_column_name": "name",
                "mapping_confidence": 1.0,
                "mapping_type": "direct"
            },
            {
                "external_column_name": "BillingEmail",
                "internal_column_name": "email",
                "mapping_confidence": 0.9,
                "mapping_type": "direct"
            }
        ]
    },
    {
        "name": "Opportunity Object",
        "system_type": "salesforce",
        "entity_type": "dataset",
        "external_url": "https://company.salesforce.com/Opportunity",
        "description": "Objeto Opportunity do Salesforce",
        "owner": "sales.ops@company.com",
        "metadata": {
            "object_type": "standard",
            "api_name": "Opportunity",
            "record_count": 8500,
            "stage_values": ["Prospecting", "Qualification", "Proposal", "Closed Won", "Closed Lost"]
        }
    },
    
    # Looker
    {
        "name": "Customer 360 Dashboard",
        "system_type": "looker",
        "entity_type": "dashboard",
        "external_url": "https://company.looker.com/dashboard/customer-360",
        "description": "Visão 360 do cliente",
        "owner": "customer.success@company.com",
        "metadata": {
            "model": "customer_analytics",
            "explores": ["customers", "transactions", "support_tickets"],
            "filters": ["customer_segment", "acquisition_channel"]
        }
    },
    
    # Qlik
    {
        "name": "Supply Chain Analytics",
        "system_type": "qlik",
        "entity_type": "dashboard",
        "external_url": "https://qlik.company.com/app/supply-chain",
        "description": "Analytics da cadeia de suprimentos",
        "owner": "supply.chain@company.com",
        "metadata": {
            "app_id": "supply-chain-001",
            "sheets": ["Overview", "Inventory", "Suppliers", "Logistics"],
            "data_connections": ["erp_system", "warehouse_db"]
        }
    },
    
    # Snowflake
    {
        "name": "Customer Data Warehouse",
        "system_type": "snowflake",
        "entity_type": "dataset",
        "external_url": "https://company.snowflakecomputing.com/customer_dw",
        "description": "Data warehouse de dados de clientes",
        "owner": "data.engineering@company.com",
        "metadata": {
            "database": "CUSTOMER_DW",
            "schema": "PROD",
            "table_type": "BASE TABLE",
            "row_count": 2500000,
            "clustering_keys": ["customer_id", "created_date"]
        }
    },
    
    # Databricks
    {
        "name": "ML Feature Store",
        "system_type": "databricks",
        "entity_type": "dataset",
        "external_url": "https://company.databricks.com/feature-store",
        "description": "Feature store para modelos de ML",
        "owner": "ml.engineering@company.com",
        "metadata": {
            "catalog": "feature_store",
            "schema": "customer_features",
            "table_format": "delta",
            "features_count": 150,
            "model_versions": ["v1.0", "v1.1", "v2.0"]
        }
    }
]

def create_external_metadata_via_api(metadata_data):
    """Cria metadado externo via API"""
    try:
        headers = {
            'Content-Type': 'application/json',
            'X-Country-Code': 'BR',
            'X-API-Version': '2.0.0',
            'X-User-ID': 'admin.br'
        }
        
        response = requests.post(
            f"{API_BASE_URL}/api/v2/external-lineage/metadata",
            json=metadata_data,
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 201:
            return response.json()
        else:
            print(f"   ❌ Erro ao criar metadado: {response.status_code} - {response.text}")
            return None
            
    except Exception as e:
        print(f"   ❌ Erro na requisição: {e}")
        return None

def sync_metadata_to_unity_catalog(metadata_id):
    """Sincroniza metadado com Unity Catalog"""
    try:
        headers = {
            'Content-Type': 'application/json',
            'X-Country-Code': 'BR',
            'X-API-Version': '2.0.0',
            'X-User-ID': 'admin.br'
        }
        
        response = requests.post(
            f"{API_BASE_URL}/api/v2/external-lineage/metadata/{metadata_id}/sync",
            headers=headers,
            timeout=15
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            print(f"   ⚠️ Erro na sincronização: {response.status_code}")
            return None
            
    except Exception as e:
        print(f"   ⚠️ Erro na sincronização: {e}")
        return None

def get_lineage_graph(metadata_id):
    """Obtém grafo de lineage"""
    try:
        headers = {
            'X-Country-Code': 'BR',
            'X-API-Version': '2.0.0'
        }
        
        response = requests.get(
            f"{API_BASE_URL}/api/v2/external-lineage/graph/{metadata_id}",
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            return None
            
    except Exception as e:
        print(f"   ⚠️ Erro ao obter lineage: {e}")
        return None

def create_mock_data():
    """Cria dados de mock para metadados externos"""
    
    print("🔗 Criando metadados externos para Unity Catalog...")
    
    created_metadata = []
    systems_count = {}
    
    for metadata_data in EXTERNAL_METADATA:
        print(f"\n📊 Criando: {metadata_data['name']}")
        print(f"   🏢 Sistema: {metadata_data['system_type']}")
        print(f"   📋 Tipo: {metadata_data['entity_type']}")
        
        # Criar metadado externo
        created = create_external_metadata_via_api(metadata_data)
        
        if created:
            metadata_id = created.get('id')
            print(f"   ✅ Metadado criado: ID {metadata_id}")
            
            # Contar por sistema
            system = metadata_data['system_type']
            systems_count[system] = systems_count.get(system, 0) + 1
            
            # Sincronizar com Unity Catalog
            print(f"   🔄 Sincronizando com Unity Catalog...")
            sync_result = sync_metadata_to_unity_catalog(metadata_id)
            
            if sync_result and sync_result.get('success'):
                print(f"   ✅ Sincronizado: {sync_result.get('unity_catalog_id', 'N/A')}")
            else:
                print(f"   ⚠️ Sincronização simulada (modo desenvolvimento)")
            
            # Obter lineage
            lineage = get_lineage_graph(metadata_id)
            if lineage:
                nodes_count = len(lineage.get('nodes', []))
                edges_count = len(lineage.get('edges', []))
                print(f"   📈 Lineage: {nodes_count} nós, {edges_count} conexões")
            
            created_metadata.append({
                'metadata': created,
                'system_type': system,
                'entity_type': metadata_data['entity_type'],
                'sync_result': sync_result
            })
        else:
            print(f"   ❌ Falha ao criar metadado")
    
    # Estatísticas
    print(f"\n📊 Resumo:")
    print(f"   🔗 {len(created_metadata)} metadados externos criados")
    print(f"   🏢 Sistemas integrados:")
    for system, count in systems_count.items():
        print(f"      • {system}: {count} objetos")
    
    # Tipos de entidade
    entity_types = {}
    for item in created_metadata:
        entity_type = item['entity_type']
        entity_types[entity_type] = entity_types.get(entity_type, 0) + 1
    
    print(f"   📋 Tipos de entidade:")
    for entity_type, count in entity_types.items():
        print(f"      • {entity_type}: {count} objetos")
    
    # Salvar dados para referência
    mock_data = {
        'external_metadata': EXTERNAL_METADATA,
        'created_metadata': created_metadata,
        'systems_count': systems_count,
        'entity_types': entity_types,
        'created_at': datetime.now().isoformat()
    }
    
    # Criar diretório se não existir
    os.makedirs('mock_data/sample_data', exist_ok=True)
    
    with open('mock_data/sample_data/external_metadata.json', 'w', encoding='utf-8') as f:
        json.dump(mock_data, f, indent=2, ensure_ascii=False)
    
    print(f"   💾 Dados salvos em: mock_data/sample_data/external_metadata.json")
    
    return len(created_metadata) > 0

def main():
    """Função principal"""
    try:
        success = create_mock_data()
        if success:
            print("\n✅ Mock data de metadados externos criado com sucesso!")
        else:
            print("\n❌ Erro ao criar mock data de metadados externos")
            sys.exit(1)
            
    except Exception as e:
        print(f"\n❌ Erro inesperado: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

