#!/usr/bin/env python3
"""
TBR GDP Core API - Mock Data: Users and Permissions
Cria usuários, grupos e permissões para teste
"""

import os
import sys
import requests
import json
from datetime import datetime

# Configurações
API_BASE_URL = os.environ.get('API_BASE_URL', 'http://localhost:5000')

# Dados de mock
PERMISSIONS = [
    {'name': 'read_contracts', 'description': 'Ler contratos de dados', 'resource': 'contracts', 'action': 'read'},
    {'name': 'write_contracts', 'description': 'Criar/editar contratos', 'resource': 'contracts', 'action': 'write'},
    {'name': 'delete_contracts', 'description': 'Excluir contratos', 'resource': 'contracts', 'action': 'delete'},
    {'name': 'read_lineage', 'description': 'Visualizar lineage', 'resource': 'lineage', 'action': 'read'},
    {'name': 'write_lineage', 'description': 'Editar lineage', 'resource': 'lineage', 'action': 'write'},
    {'name': 'read_quality', 'description': 'Visualizar qualidade', 'resource': 'quality', 'action': 'read'},
    {'name': 'write_quality', 'description': 'Configurar qualidade', 'resource': 'quality', 'action': 'write'},
    {'name': 'read_analytics', 'description': 'Visualizar analytics', 'resource': 'analytics', 'action': 'read'},
    {'name': 'write_analytics', 'description': 'Configurar analytics', 'resource': 'analytics', 'action': 'write'},
    {'name': 'admin_users', 'description': 'Administrar usuários', 'resource': 'users', 'action': 'admin'},
    {'name': 'sync_external', 'description': 'Sincronizar sistemas externos', 'resource': 'external', 'action': 'sync'},
    {'name': 'resolve_anomalies', 'description': 'Resolver anomalias', 'resource': 'anomalies', 'action': 'resolve'},
    {'name': 'configure_integrations', 'description': 'Configurar integrações', 'resource': 'integrations', 'action': 'configure'},
    {'name': 'view_audit_logs', 'description': 'Visualizar logs de auditoria', 'resource': 'audit', 'action': 'read'},
    {'name': 'manage_policies', 'description': 'Gerenciar políticas', 'resource': 'policies', 'action': 'manage'}
]

GROUPS = [
    {
        'name': 'Data Governance Admins',
        'description': 'Administradores de governança de dados',
        'permissions': [
            'read_contracts', 'write_contracts', 'delete_contracts',
            'read_lineage', 'write_lineage',
            'read_quality', 'write_quality',
            'read_analytics', 'write_analytics',
            'admin_users', 'sync_external', 'resolve_anomalies',
            'configure_integrations', 'view_audit_logs', 'manage_policies'
        ]
    },
    {
        'name': 'Data Analysts',
        'description': 'Analistas de dados',
        'permissions': [
            'read_contracts', 'write_contracts',
            'read_lineage', 'write_lineage',
            'read_quality', 'write_quality',
            'read_analytics', 'resolve_anomalies'
        ]
    },
    {
        'name': 'Data Consumers',
        'description': 'Consumidores de dados',
        'permissions': [
            'read_contracts', 'read_lineage', 'read_quality', 'read_analytics'
        ]
    }
]

USERS = [
    {
        'username': 'admin.br',
        'email': 'admin.br@tbr.com',
        'password': 'admin123',
        'first_name': 'Admin',
        'last_name': 'Brasil',
        'country_code': 'BR',
        'tenant_id': 'tbr-brasil',
        'is_admin': True,
        'groups': ['Data Governance Admins'],
        'preferences': {
            'language': 'pt-BR',
            'timezone': 'America/Sao_Paulo',
            'date_format': 'dd/MM/yyyy',
            'currency': 'BRL'
        }
    },
    {
        'username': 'analyst.us',
        'email': 'analyst.us@tbr.com',
        'password': 'analyst123',
        'first_name': 'John',
        'last_name': 'Smith',
        'country_code': 'US',
        'tenant_id': 'tbr-usa',
        'is_admin': False,
        'groups': ['Data Analysts'],
        'preferences': {
            'language': 'en-US',
            'timezone': 'America/New_York',
            'date_format': 'MM/dd/yyyy',
            'currency': 'USD'
        }
    },
    {
        'username': 'consumer.eu',
        'email': 'consumer.eu@tbr.com',
        'password': 'consumer123',
        'first_name': 'Marie',
        'last_name': 'Dubois',
        'country_code': 'EU',
        'tenant_id': 'tbr-europe',
        'is_admin': False,
        'groups': ['Data Consumers'],
        'preferences': {
            'language': 'en-GB',
            'timezone': 'Europe/London',
            'date_format': 'dd.MM.yyyy',
            'currency': 'EUR'
        }
    },
    {
        'username': 'admin.gb',
        'email': 'admin.gb@tbr.com',
        'password': 'admin123',
        'first_name': 'James',
        'last_name': 'Wilson',
        'country_code': 'GB',
        'tenant_id': 'tbr-uk',
        'is_admin': True,
        'groups': ['Data Governance Admins'],
        'preferences': {
            'language': 'en-GB',
            'timezone': 'Europe/London',
            'date_format': 'dd/MM/yyyy',
            'currency': 'GBP'
        }
    },
    {
        'username': 'analyst.ca',
        'email': 'analyst.ca@tbr.com',
        'password': 'analyst123',
        'first_name': 'Sarah',
        'last_name': 'Johnson',
        'country_code': 'CA',
        'tenant_id': 'tbr-canada',
        'is_admin': False,
        'groups': ['Data Analysts'],
        'preferences': {
            'language': 'en-CA',
            'timezone': 'America/Toronto',
            'date_format': 'dd/MM/yyyy',
            'currency': 'CAD'
        }
    }
]

def create_mock_data():
    """Cria dados de mock para usuários e permissões"""
    
    print("🔐 Criando usuários e permissões de teste...")
    
    # Simular criação de permissões
    print("\n📋 Criando permissões...")
    for permission in PERMISSIONS:
        print(f"   ✅ Permissão: {permission['name']}")
    
    # Simular criação de grupos
    print("\n👥 Criando grupos...")
    for group in GROUPS:
        print(f"   ✅ Grupo: {group['name']} ({len(group['permissions'])} permissões)")
    
    # Simular criação de usuários
    print("\n👤 Criando usuários...")
    for user in USERS:
        print(f"   ✅ Usuário: {user['username']} ({user['country_code']}) - {', '.join(user['groups'])}")
    
    # Estatísticas
    print(f"\n📊 Resumo:")
    print(f"   📋 {len(PERMISSIONS)} permissões criadas")
    print(f"   👥 {len(GROUPS)} grupos criados")
    print(f"   👤 {len(USERS)} usuários criados")
    print(f"   🌍 Países: {', '.join(set(user['country_code'] for user in USERS))}")
    
    # Salvar dados para referência
    mock_data = {
        'permissions': PERMISSIONS,
        'groups': GROUPS,
        'users': USERS,
        'created_at': datetime.now().isoformat()
    }
    
    # Criar diretório se não existir
    os.makedirs('mock_data/sample_data', exist_ok=True)
    
    with open('mock_data/sample_data/users_data.json', 'w', encoding='utf-8') as f:
        json.dump(mock_data, f, indent=2, ensure_ascii=False)
    
    print(f"   💾 Dados salvos em: mock_data/sample_data/users_data.json")
    
    return True

def main():
    """Função principal"""
    try:
        success = create_mock_data()
        if success:
            print("\n✅ Mock data de usuários criado com sucesso!")
        else:
            print("\n❌ Erro ao criar mock data de usuários")
            sys.exit(1)
            
    except Exception as e:
        print(f"\n❌ Erro inesperado: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

