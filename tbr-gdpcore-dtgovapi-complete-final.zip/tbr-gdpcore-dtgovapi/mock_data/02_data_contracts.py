#!/usr/bin/env python3
"""
TBR GDP Core API - Mock Data: Data Contracts
Cria contratos de dados com versionamento e layouts por país
"""

import os
import sys
import requests
import json
from datetime import datetime, timedelta

# Configurações
API_BASE_URL = os.environ.get('API_BASE_URL', 'http://localhost:5000')

# Schemas de exemplo
CUSTOMER_SCHEMA = {
    "type": "object",
    "properties": {
        "customer_id": {
            "type": "string",
            "description": "Identificador único do cliente",
            "pattern": "^CUST[0-9]{6}$"
        },
        "name": {
            "type": "string",
            "description": "Nome completo do cliente",
            "minLength": 2,
            "maxLength": 100
        },
        "email": {
            "type": "string",
            "description": "Email do cliente",
            "format": "email"
        },
        "phone": {
            "type": "string",
            "description": "Telefone do cliente"
        },
        "birth_date": {
            "type": "string",
            "description": "Data de nascimento",
            "format": "date"
        },
        "document_number": {
            "type": "string",
            "description": "Número do documento (CPF, SSN, etc.)"
        },
        "address": {
            "type": "object",
            "properties": {
                "street": {"type": "string"},
                "city": {"type": "string"},
                "state": {"type": "string"},
                "postal_code": {"type": "string"},
                "country": {"type": "string"}
            },
            "required": ["street", "city", "country"]
        },
        "created_at": {
            "type": "string",
            "description": "Data de criação do registro",
            "format": "date-time"
        },
        "updated_at": {
            "type": "string",
            "description": "Data de última atualização",
            "format": "date-time"
        }
    },
    "required": ["customer_id", "name", "email", "created_at"]
}

SALES_SCHEMA = {
    "type": "object",
    "properties": {
        "sale_id": {
            "type": "string",
            "description": "Identificador único da venda",
            "pattern": "^SALE[0-9]{8}$"
        },
        "customer_id": {
            "type": "string",
            "description": "ID do cliente",
            "pattern": "^CUST[0-9]{6}$"
        },
        "product_id": {
            "type": "string",
            "description": "ID do produto"
        },
        "quantity": {
            "type": "integer",
            "description": "Quantidade vendida",
            "minimum": 1
        },
        "unit_price": {
            "type": "number",
            "description": "Preço unitário",
            "minimum": 0
        },
        "total_amount": {
            "type": "number",
            "description": "Valor total da venda",
            "minimum": 0
        },
        "currency": {
            "type": "string",
            "description": "Moeda da transação",
            "enum": ["BRL", "USD", "EUR", "GBP", "CAD"]
        },
        "sale_date": {
            "type": "string",
            "description": "Data da venda",
            "format": "date"
        },
        "payment_method": {
            "type": "string",
            "description": "Método de pagamento",
            "enum": ["credit_card", "debit_card", "cash", "bank_transfer", "pix"]
        },
        "status": {
            "type": "string",
            "description": "Status da venda",
            "enum": ["pending", "confirmed", "shipped", "delivered", "cancelled"]
        }
    },
    "required": ["sale_id", "customer_id", "product_id", "quantity", "unit_price", "total_amount", "currency", "sale_date"]
}

PRODUCT_SCHEMA = {
    "type": "object",
    "properties": {
        "product_id": {
            "type": "string",
            "description": "Identificador único do produto",
            "pattern": "^PROD[0-9]{6}$"
        },
        "name": {
            "type": "string",
            "description": "Nome do produto",
            "minLength": 1,
            "maxLength": 200
        },
        "description": {
            "type": "string",
            "description": "Descrição detalhada do produto"
        },
        "category": {
            "type": "string",
            "description": "Categoria do produto"
        },
        "brand": {
            "type": "string",
            "description": "Marca do produto"
        },
        "price": {
            "type": "number",
            "description": "Preço do produto",
            "minimum": 0
        },
        "currency": {
            "type": "string",
            "description": "Moeda do preço",
            "enum": ["BRL", "USD", "EUR", "GBP", "CAD"]
        },
        "weight": {
            "type": "number",
            "description": "Peso em kg",
            "minimum": 0
        },
        "dimensions": {
            "type": "object",
            "properties": {
                "length": {"type": "number", "minimum": 0},
                "width": {"type": "number", "minimum": 0},
                "height": {"type": "number", "minimum": 0}
            }
        },
        "is_active": {
            "type": "boolean",
            "description": "Se o produto está ativo"
        }
    },
    "required": ["product_id", "name", "category", "price", "currency"]
}

# Contratos de dados
CONTRACTS = [
    {
        "name": "Customer Data Contract",
        "description": "Contrato para dados de clientes com compliance LGPD/GDPR",
        "version": "1.0.0",
        "schema_definition": CUSTOMER_SCHEMA,
        "data_classification": "confidential",
        "business_domain": "Customer Management",
        "tags": ["customer", "pii", "lgpd", "gdpr"],
        "metadata": {
            "owner": "Customer Success Team",
            "steward": "data.steward@tbr.com",
            "retention_period": "7 years",
            "compliance_frameworks": ["LGPD", "GDPR", "CCPA"]
        }
    },
    {
        "name": "Sales Transaction Contract",
        "description": "Contrato para transações de vendas",
        "version": "1.0.0",
        "schema_definition": SALES_SCHEMA,
        "data_classification": "internal",
        "business_domain": "Sales",
        "tags": ["sales", "transaction", "revenue"],
        "metadata": {
            "owner": "Sales Team",
            "steward": "sales.analyst@tbr.com",
            "retention_period": "10 years",
            "compliance_frameworks": ["SOX", "IFRS"]
        }
    },
    {
        "name": "Product Catalog Contract",
        "description": "Contrato para catálogo de produtos",
        "version": "1.0.0",
        "schema_definition": PRODUCT_SCHEMA,
        "data_classification": "public",
        "business_domain": "Product Management",
        "tags": ["product", "catalog", "inventory"],
        "metadata": {
            "owner": "Product Team",
            "steward": "product.manager@tbr.com",
            "retention_period": "5 years",
            "compliance_frameworks": []
        }
    }
]

# Dados de exemplo para validação
SAMPLE_DATA = {
    "Customer Data Contract": {
        "valid_example": {
            "customer_id": "CUST123456",
            "name": "João Silva",
            "email": "joao.silva@email.com",
            "phone": "(11) 99999-9999",
            "birth_date": "1985-03-15",
            "document_number": "123.456.789-00",
            "address": {
                "street": "Rua das Flores, 123",
                "city": "São Paulo",
                "state": "SP",
                "postal_code": "01234-567",
                "country": "Brasil"
            },
            "created_at": "2025-01-07T10:00:00Z",
            "updated_at": "2025-01-07T10:00:00Z"
        },
        "invalid_example": {
            "customer_id": "INVALID",
            "name": "",
            "email": "invalid-email",
            "created_at": "invalid-date"
        }
    },
    "Sales Transaction Contract": {
        "valid_example": {
            "sale_id": "SALE12345678",
            "customer_id": "CUST123456",
            "product_id": "PROD123456",
            "quantity": 2,
            "unit_price": 99.99,
            "total_amount": 199.98,
            "currency": "BRL",
            "sale_date": "2025-01-07",
            "payment_method": "credit_card",
            "status": "confirmed"
        }
    },
    "Product Catalog Contract": {
        "valid_example": {
            "product_id": "PROD123456",
            "name": "Smartphone XYZ",
            "description": "Smartphone com 128GB de armazenamento",
            "category": "Electronics",
            "brand": "TechBrand",
            "price": 899.99,
            "currency": "BRL",
            "weight": 0.18,
            "dimensions": {
                "length": 15.0,
                "width": 7.5,
                "height": 0.8
            },
            "is_active": True
        }
    }
}

def create_contract_via_api(contract_data, country_code='BR'):
    """Cria contrato via API"""
    try:
        headers = {
            'Content-Type': 'application/json',
            'X-Country-Code': country_code,
            'X-API-Version': '2.0.0',
            'X-User-ID': f'admin.{country_code.lower()}'
        }
        
        response = requests.post(
            f"{API_BASE_URL}/api/v2/contracts/",
            json=contract_data,
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 201:
            return response.json()
        else:
            print(f"   ❌ Erro ao criar contrato: {response.status_code} - {response.text}")
            return None
            
    except Exception as e:
        print(f"   ❌ Erro na requisição: {e}")
        return None

def validate_contract_data(contract_id, sample_data, country_code='BR'):
    """Valida dados contra contrato"""
    try:
        headers = {
            'Content-Type': 'application/json',
            'X-Country-Code': country_code,
            'X-API-Version': '2.0.0'
        }
        
        response = requests.post(
            f"{API_BASE_URL}/api/v2/contracts/{contract_id}/validate",
            json={'data': sample_data},
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200:
            result = response.json()
            return result.get('is_valid', False)
        else:
            return False
            
    except Exception as e:
        print(f"   ⚠️ Erro na validação: {e}")
        return False

def create_mock_data():
    """Cria dados de mock para contratos"""
    
    print("📋 Criando contratos de dados...")
    
    created_contracts = []
    countries = ['BR', 'US', 'EU', 'GB', 'CA']
    
    for contract_data in CONTRACTS:
        print(f"\n📄 Criando contrato: {contract_data['name']}")
        
        # Criar contrato para cada país
        for country in countries:
            print(f"   🌍 País: {country}")
            
            # Ajustar dados específicos do país
            contract_copy = contract_data.copy()
            contract_copy['name'] = f"{contract_data['name']} ({country})"
            
            # Criar contrato
            created_contract = create_contract_via_api(contract_copy, country)
            
            if created_contract:
                print(f"   ✅ Contrato criado: ID {created_contract.get('id', 'N/A')}")
                created_contracts.append({
                    'contract': created_contract,
                    'country': country,
                    'original_name': contract_data['name']
                })
                
                # Validar dados de exemplo
                if contract_data['name'] in SAMPLE_DATA:
                    sample = SAMPLE_DATA[contract_data['name']].get('valid_example')
                    if sample:
                        is_valid = validate_contract_data(
                            created_contract.get('id'),
                            sample,
                            country
                        )
                        status = "✅" if is_valid else "❌"
                        print(f"   {status} Validação de dados: {'Passou' if is_valid else 'Falhou'}")
            else:
                print(f"   ❌ Falha ao criar contrato para {country}")
    
    # Estatísticas
    print(f"\n📊 Resumo:")
    print(f"   📋 {len(created_contracts)} contratos criados")
    print(f"   🌍 {len(countries)} países configurados")
    print(f"   📝 {len(CONTRACTS)} tipos de contrato")
    
    # Salvar dados para referência
    mock_data = {
        'contracts': CONTRACTS,
        'sample_data': SAMPLE_DATA,
        'created_contracts': created_contracts,
        'created_at': datetime.now().isoformat()
    }
    
    # Criar diretório se não existir
    os.makedirs('mock_data/sample_data', exist_ok=True)
    
    with open('mock_data/sample_data/contracts_data.json', 'w', encoding='utf-8') as f:
        json.dump(mock_data, f, indent=2, ensure_ascii=False)
    
    print(f"   💾 Dados salvos em: mock_data/sample_data/contracts_data.json")
    
    return len(created_contracts) > 0

def main():
    """Função principal"""
    try:
        success = create_mock_data()
        if success:
            print("\n✅ Mock data de contratos criado com sucesso!")
        else:
            print("\n❌ Erro ao criar mock data de contratos")
            sys.exit(1)
            
    except Exception as e:
        print(f"\n❌ Erro inesperado: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

