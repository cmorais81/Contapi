# TBR GDP Core API - Mock Data Scripts

Esta pasta contém scripts completos para inserção de dados de teste e validação do sistema.

## 📁 Estrutura dos Arquivos

```
mock_data/
├── README.md                    # Este arquivo
├── 01_users_and_permissions.py # Usuários, grupos e permissões
├── 02_data_contracts.py         # Contratos de dados com versionamento
├── 03_external_metadata.py      # Metadados externos (Unity Catalog)
├── 04_quality_rules.py          # Regras de qualidade de dados
├── 05_anomalies.py              # Detecções de anomalias
├── 06_lineage_data.py           # Dados de lineage
├── 07_analytics_data.py         # KPIs e relatórios
├── 08_integration_configs.py    # Configurações de integração
├── run_all_mocks.py             # Script para executar todos
├── sample_data/                 # Dados de exemplo
│   ├── contracts_samples.json   # Exemplos de contratos
│   ├── schemas_samples.json     # Exemplos de schemas
│   └── test_datasets.json       # Datasets para teste
└── validation/                  # Scripts de validação
    ├── validate_contracts.py    # Validar contratos criados
    ├── validate_lineage.py      # Validar lineage
    └── test_api_endpoints.py     # Testar todos endpoints
```

## 🚀 Como Usar

### 1. Executar Todos os Scripts

```bash
# Navegar para a pasta do projeto
cd tbr-gdpcore-dtgovapi

# Executar aplicação em uma janela
python src/main.py

# Em outra janela, executar mock data
python mock_data/run_all_mocks.py
```

### 2. Executar Scripts Individuais

```bash
# Executar apenas usuários
python mock_data/01_users_and_permissions.py

# Executar apenas contratos
python mock_data/02_data_contracts.py

# E assim por diante...
```

### 3. Validar Dados Inseridos

```bash
# Validar contratos
python mock_data/validation/validate_contracts.py

# Testar endpoints
python mock_data/validation/test_api_endpoints.py
```

## 📊 Dados Incluídos

### Usuários e Permissões
- **5 usuários** de diferentes países (BR, US, EU, GB, CA)
- **3 grupos** (Admins, Analistas, Usuários)
- **15 permissões** específicas do sistema

### Contratos de Dados
- **10 contratos** com diferentes classificações
- **3 versões** para cada contrato
- **Layouts específicos** para cada país
- **Schemas JSON** completos e válidos

### Metadados Externos
- **15 objetos** de diferentes sistemas (Tableau, Power BI, Salesforce)
- **Mapeamentos de colunas** completos
- **Relacionamentos de lineage** estabelecidos

### Regras de Qualidade
- **20 regras** cobrindo todas as dimensões
- **Execuções históricas** com resultados
- **Configurações por país**

### Anomalias
- **25 anomalias** de diferentes tipos
- **Scores e severidades** variados
- **Histórico de resoluções**

### Analytics
- **50 KPIs** de governança
- **10 relatórios** executivos
- **Dados históricos** para tendências

## 🎯 Cenários de Teste

### Cenário 1: Governança Básica
- Criar contrato de dados
- Validar dados contra contrato
- Verificar compliance por país

### Cenário 2: Unity Catalog Integration
- Sincronizar metadados externos
- Mapear colunas
- Visualizar lineage

### Cenário 3: Qualidade de Dados
- Executar regras de qualidade
- Detectar anomalias
- Gerar relatórios

### Cenário 4: Multi-tenancy
- Testar layouts por país
- Verificar compliance regional
- Validar formatações locais

## 🔧 Configuração

### Variáveis de Ambiente

Certifique-se de que as seguintes variáveis estão configuradas:

```bash
# API Base URL
API_BASE_URL=http://localhost:5000

# Credenciais de teste
TEST_USER_EMAIL=admin@tbr.com
TEST_USER_PASSWORD=admin123

# Configurações de país
DEFAULT_COUNTRY=BR
```

### Dependências Adicionais

```bash
# Instalar dependências para mock data
pip install faker requests-mock
```

## 📈 Métricas Esperadas

Após executar todos os scripts, você deve ter:

- ✅ **5 usuários** ativos
- ✅ **10 contratos** com múltiplas versões
- ✅ **15 metadados externos** sincronizados
- ✅ **20 regras de qualidade** ativas
- ✅ **25 anomalias** detectadas
- ✅ **50 KPIs** calculados
- ✅ **100% cobertura** de endpoints testados

## 🐛 Troubleshooting

### Erro de Conexão
```bash
# Verificar se a API está rodando
curl http://localhost:5000/health
```

### Dados Duplicados
```bash
# Limpar banco antes de executar
python mock_data/clear_database.py
```

### Permissões
```bash
# Verificar permissões de usuário
python mock_data/validation/check_permissions.py
```

## 📞 Suporte

Para problemas com mock data:
1. Verificar logs da aplicação
2. Executar scripts de validação
3. Consultar documentação da API
4. Contatar equipe de desenvolvimento

---

**Desenvolvido por TBR GDP Core Team**  
**Versão**: 1.0.0  
**Última Atualização**: Janeiro 2025

