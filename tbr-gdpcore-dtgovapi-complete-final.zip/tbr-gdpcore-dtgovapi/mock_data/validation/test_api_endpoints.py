#!/usr/bin/env python3
"""
TBR GDP Core API - Validation: Test API Endpoints
Testa todos os endpoints da API
"""

import os
import sys
import requests
import json
from datetime import datetime

API_BASE_URL = os.environ.get('API_BASE_URL', 'http://localhost:5000')

ENDPOINTS_TO_TEST = [
    # Health e Info
    {'method': 'GET', 'url': '/health', 'description': 'Health Check'},
    {'method': 'GET', 'url': '/info', 'description': 'API Info'},
    
    # Contratos
    {'method': 'GET', 'url': '/api/v2/contracts/', 'description': 'Listar Contratos', 'headers': {'X-Country-Code': 'BR'}},
    
    # External Lineage
    {'method': 'GET', 'url': '/api/v2/external-lineage/metadata', 'description': 'Metadados Externos', 'headers': {'X-Country-Code': 'BR'}},
    
    # Quality
    {'method': 'GET', 'url': '/api/v2/quality/dashboard', 'description': 'Dashboard de Qualidade', 'headers': {'X-Country-Code': 'BR'}},
    {'method': 'GET', 'url': '/api/v2/quality/rules', 'description': 'Regras de Qualidade', 'headers': {'X-Country-Code': 'BR'}},
    
    # Lineage
    {'method': 'GET', 'url': '/api/v2/lineage/graph/customer_table', 'description': 'Grafo de Lineage', 'headers': {'X-Country-Code': 'BR'}},
    
    # Anomalias
    {'method': 'GET', 'url': '/api/v2/anomalies/dashboard', 'description': 'Dashboard de Anomalias', 'headers': {'X-Country-Code': 'BR'}},
    
    # Analytics
    {'method': 'GET', 'url': '/api/v2/analytics/executive-dashboard', 'description': 'Dashboard Executivo', 'headers': {'X-Country-Code': 'BR'}},
    {'method': 'GET', 'url': '/api/v2/analytics/reports', 'description': 'Relatórios', 'headers': {'X-Country-Code': 'BR'}},
    
    # Usuários
    {'method': 'GET', 'url': '/api/v2/users/profile', 'description': 'Perfil do Usuário', 'headers': {'X-Country-Code': 'BR', 'X-User-ID': 'admin.br'}},
    
    # Monitoramento
    {'method': 'GET', 'url': '/api/v2/monitoring/health', 'description': 'Health Detalhado', 'headers': {'X-Country-Code': 'BR'}},
    {'method': 'GET', 'url': '/api/v2/monitoring/metrics', 'description': 'Métricas', 'headers': {'X-Country-Code': 'BR'}},
]

def test_endpoint(endpoint):
    """Testa um endpoint específico"""
    try:
        url = f"{API_BASE_URL}{endpoint['url']}"
        headers = endpoint.get('headers', {})
        
        if endpoint['method'] == 'GET':
            response = requests.get(url, headers=headers, timeout=10)
        elif endpoint['method'] == 'POST':
            response = requests.post(url, headers=headers, json=endpoint.get('data', {}), timeout=10)
        else:
            return False, f"Método {endpoint['method']} não suportado"
        
        if response.status_code in [200, 201]:
            try:
                data = response.json()
                return True, f"Status: {response.status_code}, Response: {type(data).__name__}"
            except:
                return True, f"Status: {response.status_code}, Response: text"
        else:
            return False, f"Status: {response.status_code}, Error: {response.text[:100]}"
            
    except requests.exceptions.RequestException as e:
        return False, f"Erro de conexão: {str(e)}"
    except Exception as e:
        return False, f"Erro inesperado: {str(e)}"

def test_all_endpoints():
    """Testa todos os endpoints"""
    print("🧪 Testando todos os endpoints da API...")
    print("=" * 60)
    
    results = []
    success_count = 0
    
    for i, endpoint in enumerate(ENDPOINTS_TO_TEST, 1):
        print(f"\n[{i:2d}/{len(ENDPOINTS_TO_TEST)}] {endpoint['description']}")
        print(f"        {endpoint['method']} {endpoint['url']}")
        
        success, message = test_endpoint(endpoint)
        
        if success:
            print(f"        ✅ {message}")
            success_count += 1
        else:
            print(f"        ❌ {message}")
        
        results.append({
            'endpoint': endpoint,
            'success': success,
            'message': message,
            'tested_at': datetime.now().isoformat()
        })
    
    # Resumo
    print("\n" + "=" * 60)
    print(f"📊 Resumo dos Testes:")
    print(f"   ✅ Sucessos: {success_count}/{len(ENDPOINTS_TO_TEST)}")
    print(f"   ❌ Falhas: {len(ENDPOINTS_TO_TEST) - success_count}/{len(ENDPOINTS_TO_TEST)}")
    print(f"   📈 Taxa de Sucesso: {(success_count/len(ENDPOINTS_TO_TEST)*100):.1f}%")
    
    # Salvar resultados
    test_results = {
        'total_tests': len(ENDPOINTS_TO_TEST),
        'successful_tests': success_count,
        'failed_tests': len(ENDPOINTS_TO_TEST) - success_count,
        'success_rate': success_count/len(ENDPOINTS_TO_TEST)*100,
        'results': results,
        'tested_at': datetime.now().isoformat()
    }
    
    os.makedirs('mock_data/validation', exist_ok=True)
    with open('mock_data/validation/endpoint_test_results.json', 'w', encoding='utf-8') as f:
        json.dump(test_results, f, indent=2, ensure_ascii=False)
    
    print(f"   💾 Resultados salvos em: mock_data/validation/endpoint_test_results.json")
    
    return success_count == len(ENDPOINTS_TO_TEST)

def main():
    """Função principal"""
    try:
        # Verificar se API está rodando
        try:
            response = requests.get(f"{API_BASE_URL}/health", timeout=5)
            if response.status_code != 200:
                print("❌ API não está saudável")
                sys.exit(1)
        except:
            print("❌ API não está rodando. Execute 'python src/main.py' primeiro.")
            sys.exit(1)
        
        success = test_all_endpoints()
        
        if success:
            print("\n🎉 Todos os endpoints testados com sucesso!")
        else:
            print("\n⚠️ Alguns endpoints falharam nos testes")
            print("   Verifique os logs acima para detalhes")
            
    except Exception as e:
        print(f"\n❌ Erro inesperado: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

