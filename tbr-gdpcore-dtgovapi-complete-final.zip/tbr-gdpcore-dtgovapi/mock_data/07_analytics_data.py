#!/usr/bin/env python3
"""
TBR GDP Core API - Mock Data: Analytics Data
Cria dados de analytics e KPIs
"""

import os
import sys
import json
from datetime import datetime

ANALYTICS_DATA = {
    "governance_score": 85.2,
    "data_assets": 1247,
    "active_contracts": 89,
    "compliance_status": {
        "LGPD": "compliant",
        "GDPR": "compliant", 
        "CCPA": "partial"
    },
    "kpis": [
        {"name": "Data Quality Score", "value": 87.5, "trend": "up"},
        {"name": "Contract Coverage", "value": 72.3, "trend": "up"},
        {"name": "Lineage Coverage", "value": 68.9, "trend": "stable"},
        {"name": "Anomaly Resolution Rate", "value": 94.2, "trend": "up"},
        {"name": "External Integration Health", "value": 91.7, "trend": "stable"}
    ]
}

def create_mock_data():
    print("📈 Criando dados de analytics...")
    
    print(f"   🎯 Governance Score: {ANALYTICS_DATA['governance_score']}%")
    print(f"   📊 {len(ANALYTICS_DATA['kpis'])} KPIs")
    print(f"   ✅ Compliance: {len(ANALYTICS_DATA['compliance_status'])} frameworks")
    
    mock_data = {
        'analytics': ANALYTICS_DATA,
        'created_at': datetime.now().isoformat()
    }
    
    os.makedirs('mock_data/sample_data', exist_ok=True)
    with open('mock_data/sample_data/analytics_data.json', 'w', encoding='utf-8') as f:
        json.dump(mock_data, f, indent=2, ensure_ascii=False)
    
    print(f"\n📈 Dados de analytics criados")
    return True

def main():
    try:
        success = create_mock_data()
        if success:
            print("\n✅ Mock data de analytics criado com sucesso!")
        else:
            sys.exit(1)
    except Exception as e:
        print(f"\n❌ Erro: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

