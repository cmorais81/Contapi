#!/usr/bin/env python3
"""
TBR GDP Core API - Mock Data: Anomalies
Cria detecções de anomalias
"""

import os
import sys
import json
from datetime import datetime, timedelta
import random

ANOMALIES = [
    {
        "type": "volume_anomaly",
        "severity": "high",
        "score": 0.95,
        "description": "Volume de dados 300% acima do normal",
        "detected_at": (datetime.now() - timedelta(hours=2)).isoformat()
    },
    {
        "type": "pattern_anomaly", 
        "severity": "medium",
        "score": 0.78,
        "description": "Padrão incomum em dados de vendas",
        "detected_at": (datetime.now() - timedelta(hours=6)).isoformat()
    },
    {
        "type": "quality_anomaly",
        "severity": "low",
        "score": 0.65,
        "description": "Queda na qualidade de dados de clientes",
        "detected_at": (datetime.now() - timedelta(days=1)).isoformat()
    }
]

def create_mock_data():
    print("🚨 Criando detecções de anomalias...")
    
    for anomaly in ANOMALIES:
        print(f"   ⚠️ {anomaly['type']}: {anomaly['severity']} (score: {anomaly['score']})")
    
    mock_data = {
        'anomalies': ANOMALIES,
        'created_at': datetime.now().isoformat()
    }
    
    os.makedirs('mock_data/sample_data', exist_ok=True)
    with open('mock_data/sample_data/anomalies.json', 'w', encoding='utf-8') as f:
        json.dump(mock_data, f, indent=2, ensure_ascii=False)
    
    print(f"\n🚨 {len(ANOMALIES)} anomalias criadas")
    return True

def main():
    try:
        success = create_mock_data()
        if success:
            print("\n✅ Mock data de anomalias criado com sucesso!")
        else:
            sys.exit(1)
    except Exception as e:
        print(f"\n❌ Erro: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

