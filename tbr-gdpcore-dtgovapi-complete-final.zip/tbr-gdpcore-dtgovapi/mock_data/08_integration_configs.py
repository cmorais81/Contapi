#!/usr/bin/env python3
"""
TBR GDP Core API - Mock Data: Integration Configs
Cria configurações de integração
"""

import os
import sys
import json
from datetime import datetime

INTEGRATION_CONFIGS = [
    {
        "name": "Tableau Integration",
        "integration_type": "tableau",
        "config": {
            "server_url": "https://tableau.company.com",
            "username": "api_user",
            "site_id": "default"
        },
        "is_active": True,
        "last_sync": datetime.now().isoformat()
    },
    {
        "name": "Power BI Integration", 
        "integration_type": "power_bi",
        "config": {
            "workspace_url": "https://app.powerbi.com",
            "tenant_id": "company-tenant",
            "client_id": "powerbi-client"
        },
        "is_active": True,
        "last_sync": datetime.now().isoformat()
    },
    {
        "name": "Unity Catalog Sync",
        "integration_type": "databricks",
        "config": {
            "workspace_url": "https://company.databricks.com",
            "catalog_name": "main",
            "schema_name": "governance"
        },
        "is_active": True,
        "last_sync": datetime.now().isoformat()
    }
]

def create_mock_data():
    print("🔧 Criando configurações de integração...")
    
    for config in INTEGRATION_CONFIGS:
        status = "✅" if config['is_active'] else "❌"
        print(f"   {status} {config['name']} ({config['integration_type']})")
    
    mock_data = {
        'integration_configs': INTEGRATION_CONFIGS,
        'created_at': datetime.now().isoformat()
    }
    
    os.makedirs('mock_data/sample_data', exist_ok=True)
    with open('mock_data/sample_data/integration_configs.json', 'w', encoding='utf-8') as f:
        json.dump(mock_data, f, indent=2, ensure_ascii=False)
    
    print(f"\n🔧 {len(INTEGRATION_CONFIGS)} configurações criadas")
    return True

def main():
    try:
        success = create_mock_data()
        if success:
            print("\n✅ Mock data de integrações criado com sucesso!")
        else:
            sys.exit(1)
    except Exception as e:
        print(f"\n❌ Erro: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

