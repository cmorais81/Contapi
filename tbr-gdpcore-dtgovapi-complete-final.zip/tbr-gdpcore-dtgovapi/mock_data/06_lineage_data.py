#!/usr/bin/env python3
"""
TBR GDP Core API - Mock Data: Lineage Data
Cria dados de lineage
"""

import os
import sys
import json
from datetime import datetime

LINEAGE_DATA = {
    "nodes": [
        {"id": "customer_table", "name": "Customer Table", "type": "table"},
        {"id": "sales_table", "name": "Sales Table", "type": "table"},
        {"id": "sales_dashboard", "name": "Sales Dashboard", "type": "dashboard"},
        {"id": "customer_report", "name": "Customer Report", "type": "report"}
    ],
    "edges": [
        {"source": "customer_table", "target": "sales_dashboard", "type": "feeds"},
        {"source": "sales_table", "target": "sales_dashboard", "type": "feeds"},
        {"source": "customer_table", "target": "customer_report", "type": "feeds"}
    ]
}

def create_mock_data():
    print("🔗 Criando dados de lineage...")
    
    print(f"   📊 {len(LINEAGE_DATA['nodes'])} nós")
    print(f"   🔗 {len(LINEAGE_DATA['edges'])} conexões")
    
    mock_data = {
        'lineage': LINEAGE_DATA,
        'created_at': datetime.now().isoformat()
    }
    
    os.makedirs('mock_data/sample_data', exist_ok=True)
    with open('mock_data/sample_data/lineage_data.json', 'w', encoding='utf-8') as f:
        json.dump(mock_data, f, indent=2, ensure_ascii=False)
    
    print(f"\n🔗 Dados de lineage criados")
    return True

def main():
    try:
        success = create_mock_data()
        if success:
            print("\n✅ Mock data de lineage criado com sucesso!")
        else:
            sys.exit(1)
    except Exception as e:
        print(f"\n❌ Erro: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

