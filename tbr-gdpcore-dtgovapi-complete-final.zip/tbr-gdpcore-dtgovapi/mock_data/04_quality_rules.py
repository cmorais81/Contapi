#!/usr/bin/env python3
"""
TBR GDP Core API - Mock Data: Quality Rules
Cria regras de qualidade de dados
"""

import os
import sys
import requests
import json
from datetime import datetime

API_BASE_URL = os.environ.get('API_BASE_URL', 'http://localhost:5000')

QUALITY_RULES = [
    {
        "name": "Customer Email Validation",
        "rule_type": "pattern",
        "dimension": "validity",
        "threshold": 95.0,
        "pattern": r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
        "description": "Validar formato de email de clientes"
    },
    {
        "name": "Phone Number Format",
        "rule_type": "pattern", 
        "dimension": "validity",
        "threshold": 90.0,
        "pattern": r"^\(\d{2}\)\s\d{4,5}-\d{4}$",
        "description": "Validar formato de telefone brasileiro"
    },
    {
        "name": "Customer Name Completeness",
        "rule_type": "completeness",
        "dimension": "completeness", 
        "threshold": 98.0,
        "description": "Verificar se nome do cliente está preenchido"
    },
    {
        "name": "Sales Amount Range",
        "rule_type": "range",
        "dimension": "validity",
        "threshold": 95.0,
        "min_value": 0.01,
        "max_value": 1000000.0,
        "description": "Validar faixa de valores de venda"
    },
    {
        "name": "Product Price Consistency",
        "rule_type": "consistency",
        "dimension": "consistency",
        "threshold": 92.0,
        "description": "Verificar consistência de preços entre sistemas"
    }
]

def create_mock_data():
    print("📊 Criando regras de qualidade de dados...")
    
    for rule in QUALITY_RULES:
        print(f"   ✅ Regra: {rule['name']} ({rule['dimension']})")
    
    # Simular execuções
    executions = []
    for rule in QUALITY_RULES:
        execution = {
            "rule_name": rule['name'],
            "score": rule['threshold'] + (5 * (0.5 - abs(hash(rule['name']) % 100 - 50) / 100)),
            "status": "passed",
            "executed_at": datetime.now().isoformat()
        }
        executions.append(execution)
        print(f"   📈 Execução: {execution['score']:.1f}% - {execution['status']}")
    
    mock_data = {
        'quality_rules': QUALITY_RULES,
        'executions': executions,
        'created_at': datetime.now().isoformat()
    }
    
    os.makedirs('mock_data/sample_data', exist_ok=True)
    with open('mock_data/sample_data/quality_rules.json', 'w', encoding='utf-8') as f:
        json.dump(mock_data, f, indent=2, ensure_ascii=False)
    
    print(f"\n📊 {len(QUALITY_RULES)} regras de qualidade criadas")
    print(f"💾 Dados salvos em: mock_data/sample_data/quality_rules.json")
    return True

def main():
    try:
        success = create_mock_data()
        if success:
            print("\n✅ Mock data de qualidade criado com sucesso!")
        else:
            sys.exit(1)
    except Exception as e:
        print(f"\n❌ Erro: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

