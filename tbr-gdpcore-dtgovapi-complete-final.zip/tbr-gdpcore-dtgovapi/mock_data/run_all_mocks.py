#!/usr/bin/env python3
"""
TBR GDP Core API - Mock Data Runner
Script principal para executar todos os scripts de mock data
"""

import os
import sys
import time
import requests
import subprocess
from datetime import datetime

# Adicionar src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

# Configurações
API_BASE_URL = os.environ.get('API_BASE_URL', 'http://localhost:5000')
MOCK_DATA_DIR = os.path.dirname(__file__)

# Scripts na ordem de execução
MOCK_SCRIPTS = [
    '01_users_and_permissions.py',
    '02_data_contracts.py', 
    '03_external_metadata.py',
    '04_quality_rules.py',
    '05_anomalies.py',
    '06_lineage_data.py',
    '07_analytics_data.py',
    '08_integration_configs.py'
]

def check_api_health():
    """Verifica se a API está rodando"""
    try:
        response = requests.get(f"{API_BASE_URL}/health", timeout=5)
        if response.status_code == 200:
            print("✅ API está rodando e saudável")
            return True
        else:
            print(f"❌ API retornou status {response.status_code}")
            return False
    except requests.exceptions.RequestException as e:
        print(f"❌ Erro ao conectar com a API: {e}")
        return False

def run_script(script_name):
    """Executa um script de mock data"""
    script_path = os.path.join(MOCK_DATA_DIR, script_name)
    
    if not os.path.exists(script_path):
        print(f"❌ Script não encontrado: {script_name}")
        return False
    
    print(f"🔄 Executando {script_name}...")
    
    try:
        result = subprocess.run(
            [sys.executable, script_path],
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode == 0:
            print(f"✅ {script_name} executado com sucesso")
            if result.stdout:
                print(f"   Output: {result.stdout.strip()}")
            return True
        else:
            print(f"❌ Erro ao executar {script_name}")
            if result.stderr:
                print(f"   Erro: {result.stderr.strip()}")
            return False
            
    except subprocess.TimeoutExpired:
        print(f"❌ Timeout ao executar {script_name}")
        return False
    except Exception as e:
        print(f"❌ Erro inesperado ao executar {script_name}: {e}")
        return False

def get_api_stats():
    """Obtém estatísticas da API após inserção dos dados"""
    try:
        # Verificar contratos
        contracts_response = requests.get(f"{API_BASE_URL}/api/v2/contracts/")
        contracts_count = 0
        if contracts_response.status_code == 200:
            contracts_data = contracts_response.json()
            contracts_count = contracts_data.get('pagination', {}).get('total', 0)
        
        # Verificar metadados externos
        metadata_response = requests.get(f"{API_BASE_URL}/api/v2/external-lineage/metadata")
        metadata_count = 0
        if metadata_response.status_code == 200:
            metadata_data = metadata_response.json()
            metadata_count = metadata_data.get('pagination', {}).get('total', 0)
        
        # Verificar usuários
        users_response = requests.get(f"{API_BASE_URL}/api/v2/users/profile")
        users_status = "✅" if users_response.status_code == 200 else "❌"
        
        return {
            'contracts': contracts_count,
            'external_metadata': metadata_count,
            'users_status': users_status
        }
        
    except Exception as e:
        print(f"⚠️ Erro ao obter estatísticas: {e}")
        return None

def main():
    """Função principal"""
    print("🚀 TBR GDP Core API - Mock Data Runner")
    print("=" * 50)
    print(f"📅 Iniciado em: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"🌐 API URL: {API_BASE_URL}")
    print()
    
    # Verificar se a API está rodando
    print("🔍 Verificando status da API...")
    if not check_api_health():
        print("\n❌ A API não está rodando. Por favor:")
        print("1. Navegue para o diretório do projeto")
        print("2. Execute: python src/main.py")
        print("3. Aguarde a API inicializar")
        print("4. Execute este script novamente")
        sys.exit(1)
    
    print()
    
    # Executar scripts de mock data
    print("📊 Executando scripts de mock data...")
    print("-" * 30)
    
    success_count = 0
    total_scripts = len(MOCK_SCRIPTS)
    
    for i, script in enumerate(MOCK_SCRIPTS, 1):
        print(f"\n[{i}/{total_scripts}] {script}")
        if run_script(script):
            success_count += 1
        
        # Pequena pausa entre scripts
        time.sleep(1)
    
    print()
    print("=" * 50)
    
    # Resumo da execução
    if success_count == total_scripts:
        print("🎉 Todos os scripts executados com sucesso!")
    else:
        print(f"⚠️ {success_count}/{total_scripts} scripts executados com sucesso")
    
    # Obter estatísticas finais
    print("\n📈 Estatísticas finais:")
    stats = get_api_stats()
    if stats:
        print(f"   📋 Contratos criados: {stats['contracts']}")
        print(f"   🔗 Metadados externos: {stats['external_metadata']}")
        print(f"   👤 Sistema de usuários: {stats['users_status']}")
    
    print("\n🔗 Links úteis:")
    print(f"   📚 Swagger UI: {API_BASE_URL}/docs/")
    print(f"   ❤️ Health Check: {API_BASE_URL}/health")
    print(f"   ℹ️ API Info: {API_BASE_URL}/info")
    
    print("\n✨ Próximos passos:")
    print("1. Acesse o Swagger UI para explorar os endpoints")
    print("2. Execute os scripts de validação em mock_data/validation/")
    print("3. Teste os cenários de uso documentados")
    
    print(f"\n📅 Finalizado em: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    main()

