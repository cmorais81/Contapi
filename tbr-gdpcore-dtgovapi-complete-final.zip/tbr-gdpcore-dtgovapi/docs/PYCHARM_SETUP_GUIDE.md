# TBR GDP Core API - Guia de Configuração do PyCharm

Este guia fornece instruções detalhadas para configurar o PyCharm Professional para desenvolvimento local do projeto TBR GDP Core - Data Governance API.

## 📋 Pré-requisitos

### Software Necessário
- **PyCharm Professional** (versão 2023.1 ou superior)
- **Python 3.11+** instalado no sistema
- **Git** para controle de versão
- **PostgreSQL** (opcional, pode usar SQLite para desenvolvimento)
- **Redis** (opcional para cache)

### Verificar Instalações
```bash
# Verificar Python
python --version
# Deve retornar: Python 3.11.x

# Verificar Git
git --version

# Verificar pip
pip --version
```

## 🚀 Configuração Inicial do Projeto

### 1. Clonar/Extrair o Projeto

```bash
# Se usando Git
git clone <repository-url> tbr-gdpcore-dtgovapi
cd tbr-gdpcore-dtgovapi

# Ou extrair o ZIP fornecido
# Extrair tbr-gdpcore-dtgovapi-complete.zip
# cd tbr-gdpcore-dtgovapi
```

### 2. Abrir Projeto no PyCharm

1. **Abrir PyCharm Professional**
2. **File → Open**
3. **Selecionar a pasta `tbr-gdpcore-dtgovapi`**
4. **Clicar em "OK"**

## 🐍 Configuração do Ambiente Virtual

### 1. Criar Ambiente Virtual no PyCharm

1. **File → Settings** (Ctrl+Alt+S)
2. **Project → Python Interpreter**
3. **Clicar no ⚙️ → Add...**
4. **Selecionar "Virtualenv Environment"**
5. **Escolher "New environment"**
6. **Base interpreter**: Selecionar Python 3.11
7. **Location**: `./venv` (dentro do projeto)
8. **Clicar "OK"**

### 2. Ativar Ambiente Virtual

O PyCharm ativará automaticamente. Para verificar:
- **Terminal do PyCharm** deve mostrar `(venv)` no prompt
- **Status bar** inferior deve mostrar o interpretador correto

### 3. Instalar Dependências

No **Terminal do PyCharm**:

```bash
# Atualizar pip
python -m pip install --upgrade pip

# Instalar dependências do projeto
pip install -r requirements.txt

# Verificar instalação
pip list
```

## 🗄️ Configuração do Banco de Dados

### Opção 1: SQLite (Recomendado para Desenvolvimento)

**Configuração automática** - não requer instalação adicional.

### Opção 2: PostgreSQL (Produção-like)

#### Instalar PostgreSQL

**Windows:**
```bash
# Baixar e instalar PostgreSQL do site oficial
# https://www.postgresql.org/download/windows/
```

**macOS:**
```bash
brew install postgresql
brew services start postgresql
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

#### Criar Banco de Dados

```bash
# Conectar ao PostgreSQL
sudo -u postgres psql

# Criar banco e usuário
CREATE DATABASE tbr_gdp_core;
CREATE USER gdp_user WITH PASSWORD 'gdp_password';
GRANT ALL PRIVILEGES ON DATABASE tbr_gdp_core TO gdp_user;
\q
```

## ⚙️ Configuração de Variáveis de Ambiente

### 1. Criar Arquivo .env

No **root do projeto**, criar arquivo `.env`:

```bash
# Configurações do Banco de Dados
# Para SQLite (desenvolvimento)
DATABASE_URL=sqlite:///src/database/app.db

# Para PostgreSQL (produção-like)
# DATABASE_URL=postgresql://gdp_user:gdp_password@localhost:5432/tbr_gdp_core

# Configurações de Segurança
SECRET_KEY=tbr-gdp-core-secret-key-development-2025
JWT_SECRET_KEY=jwt-secret-key-development

# Redis (opcional)
REDIS_URL=redis://localhost:6379/0

# Unity Catalog (desenvolvimento)
UNITY_CATALOG_URL=https://demo.databricks.com
UNITY_CATALOG_TOKEN=demo-token

# Configurações de Log
LOG_LEVEL=DEBUG

# Configurações de Aplicação
FLASK_ENV=development
FLASK_DEBUG=True
```

### 2. Configurar Variáveis no PyCharm

1. **Run → Edit Configurations...**
2. **Clicar no "+" → Python**
3. **Name**: `TBR GDP Core API`
4. **Script path**: `src/main.py`
5. **Environment variables**: Clicar no 📁
6. **Adicionar variáveis do arquivo .env**

Ou usar plugin **EnvFile**:
1. **File → Settings → Plugins**
2. **Buscar e instalar "EnvFile"**
3. **Restart PyCharm**
4. **Run Configuration → EnvFile tab**
5. **Enable EnvFile** ✅
6. **Add .env file**

## 🏃‍♂️ Configuração de Execução

### 1. Configurar Run Configuration

1. **Run → Edit Configurations...**
2. **Clicar no "+" → Python**
3. **Configurar:**
   - **Name**: `TBR GDP Core API`
   - **Script path**: `src/main.py`
   - **Parameters**: (deixar vazio)
   - **Python interpreter**: Selecionar o venv criado
   - **Working directory**: Root do projeto
   - **Environment variables**: Configurar conforme seção anterior

### 2. Configurar Flask Run Configuration

1. **Run → Edit Configurations...**
2. **Clicar no "+" → Flask Server**
3. **Configurar:**
   - **Name**: `Flask Development Server`
   - **Target type**: Script path
   - **Target**: `src/main.py`
   - **Application**: `app`
   - **Host**: `0.0.0.0`
   - **Port**: `5000`
   - **Environment variables**: Mesmo do anterior

## 🗃️ Configuração do Banco de Dados no PyCharm

### 1. Conectar ao Banco (Database Tool)

1. **View → Tool Windows → Database**
2. **Clicar no "+" → Data Source → SQLite/PostgreSQL**
3. **Configurar conexão:**

**Para SQLite:**
- **File**: `src/database/app.db`

**Para PostgreSQL:**
- **Host**: `localhost`
- **Port**: `5432`
- **Database**: `tbr_gdp_core`
- **User**: `gdp_user`
- **Password**: `gdp_password`

4. **Test Connection**
5. **Apply → OK**

### 2. Executar Migrações

No **Terminal do PyCharm**:

```bash
# Navegar para o diretório src
cd src

# Inicializar migrações (primeira vez)
flask db init

# Criar migração
flask db migrate -m "Initial migration"

# Aplicar migração
flask db upgrade
```

## 🐛 Configuração de Debug

### 1. Configurar Breakpoints

- **Clicar na margem esquerda** do editor para adicionar breakpoints
- **Breakpoints condicionais**: Clique direito no breakpoint

### 2. Debug Configuration

1. **Usar a configuração criada anteriormente**
2. **Clicar no ícone de Debug** (🐛) em vez de Run
3. **Ou usar Shift+F9**

### 3. Debug Avançado

**Configurar Debug Templates:**
1. **File → Settings → Build, Execution, Deployment → Python Debugger**
2. **Configurar:**
   - **Attach to subprocess**: ✅
   - **Collect run-time types**: ✅
   - **Gevent compatible**: ✅ (se usando gevent)

## 🧪 Configuração de Testes

### 1. Configurar Test Runner

1. **File → Settings → Tools → Python Integrated Tools**
2. **Default test runner**: `pytest`
3. **Apply → OK**

### 2. Criar Test Configuration

1. **Run → Edit Configurations...**
2. **Clicar no "+" → Python tests → pytest**
3. **Configurar:**
   - **Name**: `All Tests`
   - **Target**: `Custom`
   - **Target**: `tests/`
   - **Python interpreter**: Venv do projeto
   - **Working directory**: Root do projeto

### 3. Executar Testes

```bash
# No terminal do PyCharm
pytest tests/ -v

# Com coverage
pytest tests/ --cov=src --cov-report=html
```

## 📊 Configuração do Swagger/OpenAPI

### 1. Acessar Documentação

Após executar a aplicação:
- **Swagger UI**: http://localhost:5000/docs/
- **OpenAPI JSON**: http://localhost:5000/swagger.json

### 2. Configurar HTTP Client

1. **Tools → HTTP Client → Test RESTful Web Service**
2. **Ou criar arquivo `.http` no projeto:**

```http
### Health Check
GET http://localhost:5000/health

### API Info
GET http://localhost:5000/info

### List Contracts
GET http://localhost:5000/api/v2/contracts/
X-Country-Code: BR
X-API-Version: 2.0.0

### Create Contract
POST http://localhost:5000/api/v2/contracts/
Content-Type: application/json
X-Country-Code: BR
X-API-Version: 2.0.0

{
  "name": "Customer Contract",
  "description": "Contract for customer data",
  "schema_definition": {
    "type": "object",
    "properties": {
      "name": {"type": "string"},
      "email": {"type": "string", "format": "email"}
    },
    "required": ["name", "email"]
  }
}
```

## 🔧 Configurações Adicionais do PyCharm

### 1. Code Style

1. **File → Settings → Editor → Code Style → Python**
2. **Configurar:**
   - **Line length**: 100
   - **Use tabs**: ❌
   - **Tab size**: 4
   - **Indent**: 4

### 2. Inspections

1. **File → Settings → Editor → Inspections**
2. **Habilitar:**
   - **Python → PEP 8 coding style violation**
   - **Python → Type checker**
   - **Python → Unresolved references**

### 3. Plugins Recomendados

**Instalar via File → Settings → Plugins:**

- **EnvFile** - Gerenciar variáveis de ambiente
- **Database Navigator** - Melhor suporte a banco de dados
- **Rainbow Brackets** - Colorir brackets
- **GitToolBox** - Melhor integração Git
- **Requirements** - Gerenciar requirements.txt
- **Swagger** - Suporte a OpenAPI/Swagger

### 4. Live Templates

**Criar templates para código comum:**

1. **File → Settings → Editor → Live Templates**
2. **Criar grupo "Flask API"**
3. **Adicionar templates:**

**Endpoint básico:**
```python
@ns.route('/$ROUTE$')
class $CLASS$(Resource):
    @api.doc('$DOC$')
    def get(self):
        """$DESC$"""
        try:
            return {'message': 'success'}
        except Exception as e:
            api.abort(500, f"Erro interno: {str(e)}")
```

## 🚀 Executar a Aplicação

### 1. Primeira Execução

```bash
# No terminal do PyCharm
cd src
python main.py
```

### 2. Verificar Funcionamento

**Abrir no navegador:**
- **Health Check**: http://localhost:5000/health
- **API Info**: http://localhost:5000/info
- **Swagger Docs**: http://localhost:5000/docs/

### 3. Logs de Desenvolvimento

**Configurar logging no PyCharm:**
1. **Run → Edit Configurations**
2. **Logs tab**
3. **Adicionar log files se necessário**

## 🔍 Troubleshooting

### Problemas Comuns

#### 1. Erro de Import
```bash
# Adicionar src ao PYTHONPATH
export PYTHONPATH="${PYTHONPATH}:${PWD}/src"
```

#### 2. Banco de Dados não Encontrado
```bash
# Criar diretório do banco
mkdir -p src/database
```

#### 3. Dependências não Instaladas
```bash
# Reinstalar requirements
pip install -r requirements.txt --force-reinstall
```

#### 4. Porta em Uso
```bash
# Verificar processos na porta 5000
lsof -i :5000
# Matar processo se necessário
kill -9 <PID>
```

### Debug de Problemas

1. **Verificar logs no console do PyCharm**
2. **Usar Debug mode para step-through**
3. **Verificar variáveis de ambiente**
4. **Testar conexão com banco de dados**

## 📝 Comandos Úteis

### Terminal do PyCharm

```bash
# Ativar ambiente virtual (se não automático)
source venv/bin/activate  # Linux/Mac
venv\Scripts\activate     # Windows

# Instalar nova dependência
pip install <package>
pip freeze > requirements.txt

# Executar aplicação
python src/main.py

# Executar testes
pytest tests/ -v

# Verificar código
flake8 src/
black src/

# Migrações de banco
flask db migrate -m "Description"
flask db upgrade

# Shell interativo
flask shell
```

## 🎯 Próximos Passos

1. **Configurar Git** no PyCharm (VCS → Enable Version Control)
2. **Configurar Docker** para containerização
3. **Configurar CI/CD** pipelines
4. **Configurar monitoring** local
5. **Configurar testes de integração**

## 📞 Suporte

Se encontrar problemas:

1. **Verificar logs** no console do PyCharm
2. **Consultar documentação** do Flask e SQLAlchemy
3. **Verificar issues** no repositório do projeto
4. **Contatar equipe** de desenvolvimento

---

**Desenvolvido por TBR GDP Core Team**  
**Versão do Guia**: 1.0.0  
**Última Atualização**: Janeiro 2025

