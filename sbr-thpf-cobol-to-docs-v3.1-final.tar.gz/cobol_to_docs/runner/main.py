'''
COBOL to Docs v1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
'''

import argparse
import logging
import os
import sys
import json
import time
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adiciona o diretório raiz do projeto ao sys.path para permitir imports absolutos
# ao executar o script diretamente (não como um pacote instalado).
if __name__ == "__main__" or "cobol_to_docs" not in sys.modules:
    current_dir = Path(__file__).resolve().parent
    project_root = current_dir.parent.parent
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))

from cobol_to_docs.src.core.config import ConfigManager
from cobol_to_docs.src.core.prompt_manager_dual import DualPromptManager
from cobol_to_docs.src.providers.enhanced_provider_manager import EnhancedProviderManager
from cobol_to_docs.src.parsers.cobol_parser import COBOLParser, CobolProgram, CobolBook
from cobol_to_docs.src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from cobol_to_docs.src.generators.documentation_generator import DocumentationGenerator
from cobol_to_docs.src.utils.cost_calculator import CostCalculator
from cobol_to_docs.src.rag.rag_integration import RAGIntegration

def resolve_file_path(file_path: str) -> str:
    if os.path.isabs(file_path):
        return file_path
    return os.path.abspath(file_path)

def setup_logging(log_level: str = "INFO") -> None:
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(log_dir, f"cobol_to_docs_{timestamp_str}.log")
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(sys.stdout)
        ]
    )

def _parse_program_from_file(parser: COBOLParser, file_path: str) -> Optional[CobolProgram]:
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        # O parse_program do COBOLParser precisa de all_copybook_contents para resolver COPYs
        # Mas neste ponto, ainda não temos o mapa final de copybooks.
        # Vamos usar o parse_program sem a resolução de copybooks, que será feita no analyzer.
        return parser.parse_program(content, file_path=file_path)
    except Exception as e:
        logging.getLogger(__name__).error(f"Erro ao parsear programa {file_path}: {e}")
        return None

def _parse_book_from_file(parser: COBOLParser, file_path: str) -> Optional[CobolBook]:
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        # O COBOLParser não tem um método parse_book público, mas tem o _parse_book
        # Para evitar usar um método privado, vou simular o parse de book aqui.
        # O book name é o nome do arquivo.
        book_name = Path(file_path).stem
        return CobolBook(
            name=book_name,
            content=content,
            line_count=len(content.splitlines()),
            size=len(content),
            structures=[], # Não é necessário parsear estruturas aqui
            file_path=file_path
        )
    except Exception as e:
        logging.getLogger(__name__).error(f"Erro ao parsear copybook {file_path}: {e}")
        return None

def analyze_program_with_model(program: CobolProgram, books: List[CobolBook], model: str, output_dir: str, config_manager: ConfigManager, is_multi_model: bool, prompt_set: str, cost_calculator: CostCalculator, rag_integration=None, args=None, jcl_content: Optional[str] = None, all_copybook_contents: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    logger = logging.getLogger    if is_multi_model:
        model_name_sanitized = model.replace("/", "_").replace("-", "_")
        model_output_dir = os.path.join(output_dir, f"model_{model_name_sanitized}")
        os.makedirs(model_output_dir, exist_ok=True)
        logger.info(f"Criando diretório de saída específico do modelo: {model_output_dir}")
    else:
        model_output_dir = output_dir
        provider_manager = EnhancedProviderManager(config_manager.get_config())
        
        # O PromptManager agora usa o caminho do arquivo de prompts customizado
        prompt_manager = DualPromptManager(
            config_manager.config, 
            prompt_set, 
            custom_prompts_file=args.prompts_file_path # Usar o novo argumento
        )
        doc_generator = DocumentationGenerator(model_output_dir)
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager, rag_integration)
        
        start_time = time.time()
        analysis_result = analyzer.analyze_program(program, model, books=books, jcl_content=jcl_content, all_copybook_contents=all_copybook_contents)
        analysis_time = time.time() - start_time
        
        if not analysis_result.success:
            error_msg = f"ERRO na análise de {program.name} com modelo {model}: {analysis_result.error_message}"
            logger.error(error_msg)
            return {
                "success": False,
                "program_name": program.name,
                "model": model,
                "error": analysis_result.error_message,
                "tokens_used": 0,
                "analysis_time": analysis_time,
                "output_dir": model_output_dir
            }
        
        cost_info = cost_calculator.tokens_analytics(
            response={"usage": {'prompt_tokens': analysis_result.prompt_tokens, 'completion_tokens': analysis_result.completion_tokens, 'total_tokens': analysis_result.tokens_used}},
            model=analysis_result.model_used
        )

        doc_generator.generate_program_documentation(program, analysis_result.ai_response)
        
        logger.info(f"Análise de {program.name} com {model} bem-sucedida.")
        
        return {
            "success": True,
            "program_name": program.name,
            "model": analysis_result.model_used,
            "tokens_used": analysis_result.tokens_used,
            "analysis_time": analysis_time,
            "output_dir": model_output_dir
        }

    except Exception as e:
        logger.error(f"Erro fatal ao analisar {program.name} com {model}: {e}", exc_info=True)
        return {
            "success": False,
            "program_name": program.name,
            "model": model,
            "error": str(e),
            "tokens_used": 0,
            "analysis_time": 0,
            "output_dir": model_output_dir
        }

def process_vmember_file(file_path: str, output_dir: str) -> List[str]:
    logger = logging.getLogger(__name__)
    extracted_files = []
    temp_dir_path = Path(output_dir) / "temp_extracted_members"
    temp_dir_path.mkdir(exist_ok=True, parents=True)

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            file_contents = f.read().splitlines()
    except Exception as e:
        logger.error(f"Erro ao ler o arquivo V-MEMBER {file_path}: {e}")
        return []

    current_program_code = []
    current_program_name = None

    for line in file_contents:
        if "VMEMBER NAME" in line:
            if current_program_name and current_program_code:
                temp_file_path = temp_dir_path / f"{current_program_name}.cbl"
                with open(temp_file_path, 'w', encoding='utf-8') as out_f:
                    out_f.write('\n'.join(current_program_code))
                extracted_files.append(str(temp_file_path))
            
            current_program_name = line.split("VMEMBER NAME")[-1].strip()
            current_program_code = []
        elif line.startswith("V") and current_program_name:
             current_program_code.append(line[1:])

    if current_program_name and current_program_code:
        temp_file_path = temp_dir_path / f"{current_program_name}.cbl"
        with open(temp_file_path, 'w', encoding='utf-8') as out_f:
            out_f.write('\n'.join(current_program_code))
        extracted_files.append(str(temp_file_path))
    
    logger.info(f"{len(extracted_files)} membros extraídos de {file_path}")
    return extracted_files

def main():
    parser = argparse.ArgumentParser(description="COBOL to Docs - Análise e Documentação de Programas COBOL com IA.")
    parser.add_argument("--fontes", required=True, type=str, help="Caminho para um arquivo de texto contendo uma lista de caminhos para programas COBOL ou um arquivo V-MEMBER.")
    parser.add_argument("--books", type=str, help="Caminho para um arquivo de texto contendo uma lista de caminhos para copybooks, ou diretórios separados por vírgula.")
    parser.add_argument("--output", type=str, default="output", help="Diretório para salvar os resultados.")
    parser.add_argument("--models", type=str, default="basic-fallback", help="Modelos de IA a serem usados, separados por vírgula ou como uma lista JSON.")
    parser.add_argument("--prompt-set", type=str, default="default", help="Conjunto de prompts a ser utilizado.")
    parser.add_argument("--prompts-file", type=str, help="Caminho para o arquivo de prompts (prompts.yaml).")
    parser.add_argument("--log-level", type=str, default="INFO", help="Nível de log.")
    parser.add_argument("--config-file", type=str, help="Caminho para o arquivo de configuração (config.yaml).")
    parser.add_argument("--jcl-path", type=str, help="Caminho para um arquivo JCL associado.")
    parser.add_argument("--pdf", action="store_true", help="Gera o relatório final em formato PDF.")
    parser.add_argument("--rag-enabled", action="store_true", help="Ativa a integração com RAG.")
    parser.add_argument("--status", action="store_true", help="Exibe o status dos provedores e modelos de IA configurados.")

    args = parser.parse_args()
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)

    main_dir = Path(__file__).resolve().parent
    cobol_to_docs_dir = main_dir.parent
    
    # 1. ConfigManager: Prioriza --config-file, depois o default
    default_config_file = cobol_to_docs_dir / "config" / "config.yaml"
    config_file = resolve_file_path(args.config_file) if args.config_file else default_config_file
    config_manager = ConfigManager(config_path=config_file)
    
    # 2. PromptManager: Prioriza --prompts-file, depois o default
    default_prompts_file = cobol_to_docs_dir / "config" / "prompts.yaml"
    
    # Adicionar o caminho do prompts_file ao args para ser usado em analyze_program_with_model
    # O ConfigManager agora não precisa carregar prompts, pois o DualPromptManager fará isso.
    args.prompts_file_path = resolve_file_path(args.prompts_file) if args.prompts_file else default_prompts_file

    if args.status:
        # display_status(config_manager) # A função display_status precisa ser implementada ou corrigida
        logger.info("Funcionalidade de status a ser implementada.")
        sys.exit(0)

    output_dir = args.output
    os.makedirs(output_dir, exist_ok=True)

    provider_manager = EnhancedProviderManager(config_manager.get_config())
    available_models = list(provider_manager.model_configurations.keys())

    models_to_use = []
    if args.models:
        models_to_use = [model.strip() for model in args.models.split(',')]
    else:
        models_to_use = [config_manager.get_ai_config().get("default", "gpt-4o")]

    # Pre-processamento de V-MEMBERs
    fontes_path = resolve_file_path(args.fontes)
    program_paths = process_vmember_file(fontes_path, output_dir)

    copybook_paths = []
    if args.books:
        books_path = resolve_file_path(args.books)
        copybook_paths = process_vmember_file(books_path, output_dir)

    cobol_parser = COBOLParser()
    parsed_programs = [_parse_program_from_file(cobol_parser, p) for p in program_paths]
    parsed_books = [_parse_book_from_file(cobol_parser, c) for c in copybook_paths]

    if not parsed_programs:
        logger.error("Nenhum programa COBOL válido encontrado para análise.")
        sys.exit(1)

    jcl_content = None
    if args.jcl_path:
        try:
            with open(resolve_file_path(args.jcl_path), "r", encoding="utf-8") as f:
                jcl_content = f.read()
        except FileNotFoundError:
            logger.warning(f"Arquivo JCL não encontrado: {args.jcl_path}")

    cost_calculator = CostCalculator(config_manager.get_ai_config().get("api_costs"))
    rag_integration = RAGIntegration(config_manager.get_config()) if args.rag_enabled else None

    all_results = []
    all_copybook_contents = {b.name.upper(): b.content for b in parsed_books}

    for program in parsed_programs:
        if program is None: continue
        for model in models_to_use:
            result = analyze_program_with_model(
                program, parsed_books, model, output_dir, config_manager, 
                len(models_to_use) > 1, args.prompt_set, cost_calculator, rag_integration, 
                args, jcl_content=jcl_content, all_copybook_contents=all_copybook_contents
            )
            all_results.append(result)

    if args.pdf:
        # A geração de PDF consolidado precisa ser implementada
        logger.info("A geração de PDF consolidado será implementada em uma versão futura.")

    logger.info("Processamento concluído.")

if __name__ == "__main__":
    main()

