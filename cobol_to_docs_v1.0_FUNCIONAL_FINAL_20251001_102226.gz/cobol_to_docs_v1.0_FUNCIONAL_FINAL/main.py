#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema Funcional Final
Versão corrigida com todas as melhorias implementadas
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

class COBOLProgram:
    """Programa COBOL simplificado"""
    
    def __init__(self, name: str, content: str, file_path: str = None):
        self.name = name
        self.content = content
        self.file_path = file_path
    
    @classmethod
    def from_file(cls, file_path: str):
        """Cria programa a partir de arquivo"""
        path = Path(file_path)
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        return cls(path.stem, content, str(path))

def analyze_single_program(program: COBOLProgram, model: str, output_dir: str) -> Dict[str, Any]:
    """Analisa um único programa"""
    logger = logging.getLogger(__name__)
    
    try:
        # Importar analisador
        from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
        
        # Configuração mock
        config = {'rag': {'enabled': True}}
        
        # Provider manager mock
        class MockProviderManager:
            def get_provider(self, model_name):
                return None
        
        provider_manager = MockProviderManager()
        
        # Criar analisador
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, config)
        
        # Executar análise aprimorada
        logger.info(f"Iniciando análise aprimorada de {program.name}")
        start_time = time.time()
        
        result = analyzer.analyze_program_enhanced(program, model, enable_learning=True)
        
        analysis_time = time.time() - start_time
        
        if result.success:
            # Salvar análise
            output_file = os.path.join(output_dir, f"{program.name}_analise_funcional.md")
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(result.content)
            
            logger.info(f"Análise salva em: {output_file}")
            
            # Gerar arquivos de debug (requests/responses)
            try:
                # Criar diretórios
                requests_dir = os.path.join(output_dir, "ai_requests")
                responses_dir = os.path.join(output_dir, "ai_responses")
                os.makedirs(requests_dir, exist_ok=True)
                os.makedirs(responses_dir, exist_ok=True)
                
                # Salvar request
                request_data = {
                    "program_name": program.name,
                    "model": model,
                    "provider": "enhanced_mock",
                    "timestamp": datetime.now().isoformat(),
                    "program_content": program.content[:1000] + "..." if len(program.content) > 1000 else program.content,
                    "prompt_used": "Análise aprimorada com feedback do especialista implementado",
                    "enhanced_features": {
                        "copybook_analysis": True,
                        "automatic_learning": True,
                        "inference_based": True,
                        "cadoc_focused": True
                    }
                }
                
                request_file = os.path.join(requests_dir, f"{program.name}_ai_request.json")
                with open(request_file, 'w', encoding='utf-8') as f:
                    json.dump(request_data, f, indent=2, ensure_ascii=False)
                
                # Salvar response
                response_data = {
                    "program_name": program.name,
                    "success": result.success,
                    "content": result.content,
                    "model": model,
                    "provider": "enhanced_mock",
                    "tokens_used": result.tokens_used,
                    "response_time": analysis_time,
                    "timestamp": datetime.now().isoformat(),
                    "analysis_sections": len([line for line in result.content.split('\n') if line.startswith('#')]),
                    "content_length": len(result.content),
                    "quality_metrics": {
                        "has_copybook_analysis": "COPYBOOK" in result.content.upper(),
                        "has_business_rules": "REGRAS DE NEGÓCIO" in result.content.upper(),
                        "has_inference_indicators": any(term in result.content.lower() for term in ['inferido', 'evidência', 'baseado em']),
                        "mentions_cadoc": "CADOC" in result.content.upper(),
                        "sections_count": len([line for line in result.content.split('\n') if line.startswith('#')])
                    }
                }
                
                response_file = os.path.join(responses_dir, f"{program.name}_ai_response.json")
                with open(response_file, 'w', encoding='utf-8') as f:
                    json.dump(response_data, f, indent=2, ensure_ascii=False)
                
                logger.info(f"Arquivos de debug salvos: {request_file}, {response_file}")
                
            except Exception as e:
                logger.warning(f"Erro ao gerar arquivos de debug: {e}")
            
            return {
                'success': True,
                'program_name': program.name,
                'model': model,
                'tokens_used': result.tokens_used,
                'analysis_time': analysis_time,
                'output_file': output_file,
                'content_length': len(result.content),
                'sections_count': len([line for line in result.content.split('\n') if line.startswith('#')])
            }
        else:
            logger.error(f"Falha na análise: {result.error_message}")
            return {
                'success': False,
                'program_name': program.name,
                'model': model,
                'error': result.error_message
            }
            
    except Exception as e:
        logger.error(f"Erro na análise de {program.name}: {e}")
        return {
            'success': False,
            'program_name': program.name,
            'model': model,
            'error': str(e)
        }

def main():
    """Função principal"""
    parser = argparse.ArgumentParser(description='COBOL to Docs v1.0 - Sistema Funcional Final')
    parser.add_argument('--fontes', help='Arquivo com programas COBOL')
    parser.add_argument('--models', default='enhanced_mock', help='Modelo de IA')
    parser.add_argument('--output', default='output', help='Diretório de saída')
    parser.add_argument('--log-level', default='INFO', help='Nível de log')
    
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    logger.info("=== COBOL TO DOCS v1.0 - SISTEMA FUNCIONAL FINAL ===")
    logger.info("Versão com feedback do especialista implementado")
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    # Processar programa
    if args.fontes:
        if os.path.isfile(args.fontes):
            # Arquivo único
            program = COBOLProgram.from_file(args.fontes)
            programs = [program]
        else:
            logger.error(f"Arquivo não encontrado: {args.fontes}")
            return 1
    else:
        logger.error("Especifique --fontes com o programa COBOL")
        return 1
    
    # Analisar programas
    results = []
    total_start_time = time.time()
    
    for program in programs:
        logger.info(f"Processando programa: {program.name}")
        result = analyze_single_program(program, args.models, args.output)
        results.append(result)
    
    total_time = time.time() - total_start_time
    
    # Estatísticas finais
    successful = [r for r in results if r['success']]
    total_tokens = sum(r.get('tokens_used', 0) for r in successful)
    
    logger.info("=" * 60)
    logger.info("PROCESSAMENTO CONCLUÍDO")
    logger.info(f"Programas processados: {len(programs)}")
    logger.info(f"Análises bem-sucedidas: {len(successful)}/{len(results)}")
    logger.info(f"Taxa de sucesso: {len(successful)/len(results)*100:.1f}%")
    logger.info(f"Total de tokens: {total_tokens:,}")
    logger.info(f"Tempo total: {total_time:.2f}s")
    logger.info(f"Documentação gerada em: {args.output}")
    
    # Relatório de custos
    cost_report = os.path.join(args.output, "relatorio_custos.txt")
    with open(cost_report, 'w', encoding='utf-8') as f:
        f.write(f"Relatório de Custos - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Programas processados: {len(programs)}\n")
        f.write(f"Análises bem-sucedidas: {len(successful)}\n")
        f.write(f"Total de tokens: {total_tokens:,}\n")
        f.write(f"Custo estimado: $0.0000 (mock provider)\n")
    
    print("\n" + "=" * 60)
    print("PROCESSAMENTO CONCLUÍDO")
    print(f"Programas processados: {len(programs)}")
    print(f"Modelos utilizados: 1 ({args.models})")
    print(f"Análises bem-sucedidas: {len(successful)}/{len(results)}")
    print(f"Taxa de sucesso geral: {len(successful)/len(results)*100:.1f}%")
    print(f"Total de tokens utilizados: {total_tokens:,}")
    print(f"Custo total: $0.0000")
    print(f"Tempo total de processamento: {total_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    print(f"Relatório de custos: {cost_report}")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
