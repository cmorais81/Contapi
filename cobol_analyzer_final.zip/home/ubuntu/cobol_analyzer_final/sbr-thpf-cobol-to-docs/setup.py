#!/usr/bin/env python3

from setuptools import setup, find_packages
from setuptools.command.install import install
import os
import shutil
from pathlib import Path

class CustomInstallCommand(install):
    """Comando de instalação customizado que copia todos os arquivos necessários"""
    
    def run(self):
        # Executar instalação padrão
        install.run(self)
        
        # Copiar arquivos necessários para o site-packages
        try:
            # Encontrar o diretório de instalação
            install_dir = Path(self.install_lib)
            
            # Copiar diretórios de configuração e dados para o pacote instalado
            for dir_name in ["config", "examples", "data"]:
                source_dir = Path(f"cobol_to_docs/{dir_name}")
                dest_dir = install_dir / "cobol_to_docs" / dir_name
                if source_dir.exists():
                    if dest_dir.exists():
                        shutil.rmtree(dest_dir)
                    shutil.copytree(source_dir, dest_dir)
                    print(f"Copiado diretório {dir_name} para {dest_dir}")
            
        except Exception as e:
            print(f"Aviso: Erro ao copiar arquivos: {e}")

# Ler o README
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except:
    long_description = "COBOL Analyzer - Ferramenta de análise de código COBOL com IA"

# Encontrar todos os pacotes recursivamente
def find_all_packages():
    """Encontra todos os pacotes Python no projeto"""
    packages = []
    
    # Pacotes do src
    src_packages = find_packages(where="cobol_to_docs/src")
    for pkg in src_packages:
        packages.append(f"cobol_to_docs.{pkg}")
    
    # Pacote runner
    packages.append("cobol_to_docs.runner")
    
    return packages

setup(
    name="cobol-to-docs",
    version="3.1.0",
    author="COBOL Analyzer Team",
    description="Ferramenta de análise de código COBOL com tecnologia de IA",
    long_description=long_description,
    long_description_content_type="text/markdown",
    
    # Usar comando de instalação customizado
    cmdclass={
        'install': CustomInstallCommand,
    },
    
    # Incluir todos os pacotes Python
    packages=find_all_packages(),
    package_dir={
        "cobol_to_docs": "cobol_to_docs/src",
        "cobol_to_docs.runner": "cobol_to_docs/runner"
    },
    
    # Entry points para comandos globais
    entry_points={
        "console_scripts": [
            "cobol-to-docs=cobol_to_docs.runner.cobol_to_docs:main",
            "cobol-analyzer=cobol_to_docs.runner.cli:main",
        ],
    },
    
    # Incluir todos os arquivos necessários
    package_data={
        "cobol_to_docs": [
            "config/*",
            "data/*", 
            "data/rag_sessions/*",
            "examples/*",
            "runner/*"
        ],
    },
    
    include_package_data=True,
    
    # Dependências essenciais
    install_requires=[
        "pyyaml>=6.0",
        "requests>=2.28.0",
        "numpy>=1.21.0",
        "scikit-learn>=1.0.0",
        "jinja2>=3.0.0",
        "markdown>=3.3.0",
        "sentence-transformers>=2.2.0",
        "openai>=1.0.0",
        "weasyprint>=54.0",
        "reportlab>=3.6.0",
        "pandas>=1.3.0",
        "openpyxl>=3.0.0",
        "colorama>=0.4.4",
        "tqdm>=4.62.0",
        "python-dotenv>=0.19.0",
    ],
    
    # Dependências opcionais para desenvolvimento
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black>=21.0",
            "flake8>=3.8",
            "mypy>=0.800",
            "pre-commit>=2.15.0",
        ],
        "jupyter": [
            "jupyter>=1.0.0",
            "ipykernel>=6.0.0",
            "notebook>=6.4.0",
        ],
    },
    
    # Metadados básicos
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    zip_safe=False,
)
