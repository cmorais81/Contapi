# Manual do Usuário - COBOL Analyzer v3.1.0

## Índice

1. [Introdução](#introdução)
2. [Instalação](#instalação)
3. [Configuração Inicial](#configuração-inicial)
4. [Uso Básico](#uso-básico)
5. [Funcionalidades Avançadas](#funcionalidades-avançadas)
6. [Sistema RAG](#sistema-rag)
7. [Provedores de IA](#provedores-de-ia)
8. [Análise de Resultados](#análise-de-resultados)
9. [Solução de Problemas](#solução-de-problemas)
10. [Referência Técnica](#referência-técnica)

## Introdução

O COBOL Analyzer é uma ferramenta profissional desenvolvida para análise automatizada de código COBOL utilizando tecnologias de Inteligência Artificial. A ferramenta oferece análise detalhada de programas COBOL legados, identificação de regras de negócio, mapeamento de estruturas de dados e geração automática de documentação técnica.

### Principais Benefícios

A ferramenta permite modernização eficiente de sistemas legados através da análise automatizada que identifica padrões, dependências e regras de negócio complexas. O sistema RAG (Retrieval-Augmented Generation) enriquece as análises com conhecimento especializado em COBOL, enquanto múltiplos provedores de IA garantem flexibilidade e qualidade nas análises.

### Arquitetura da Solução

O COBOL Analyzer utiliza arquitetura modular com componentes especializados para parsing de código, análise semântica, integração com IA e geração de documentação. O sistema RAG incorpora base de conhecimento especializada que é continuamente enriquecida durante as análises.

## Instalação

### Requisitos do Sistema

**Requisitos Mínimos:**
- Python 3.8 ou superior
- 4GB de RAM
- 2GB de espaço em disco
- Conexão com internet para provedores de IA

**Requisitos Recomendados:**
- Python 3.11 ou superior
- 8GB de RAM
- 5GB de espaço em disco
- Conexão estável com internet

### Processo de Instalação

#### Método 1: Instalação via pip

```bash
# Extrair o pacote
tar -xzf SBR_THPF_COBOL_TO_DOCS_v3.1.0_FINAL.tar.gz
cd sbr-thpf-cobol-to-docs/

# Instalar dependências
pip install -r requirements.txt

# Instalar o pacote
pip install .
```

#### Método 2: Instalação via Pipenv (Recomendado)

```bash
# Extrair o pacote
tar -xzf SBR_THPF_COBOL_TO_DOCS_v3.1.0_FINAL.tar.gz
cd sbr-thpf-cobol-to-docs/

# Criar ambiente virtual e instalar
pipenv install
pipenv shell
```

### Verificação da Instalação

```bash
# Verificar se a instalação foi bem-sucedida
python -c "import cobol_to_docs; print('Instalação bem-sucedida')"

# Executar testes unitários
python -m pytest cobol_to_docs/tests/ -v
```

## Configuração Inicial

### Inicialização de Projeto

Para usar o COBOL Analyzer em qualquer pasta, execute o comando de inicialização que copia todos os arquivos necessários:

```bash
# Criar pasta do projeto
mkdir meu_projeto_cobol
cd meu_projeto_cobol

# Inicializar projeto
python /caminho/para/cobol_to_docs/runner/cobol_to_docs_simple.py --init
```

### Estrutura Criada

O comando de inicialização cria a seguinte estrutura:

```
meu_projeto_cobol/
├── config/              # Configurações e prompts
├── data/                # Base de conhecimento RAG
├── examples/            # Exemplos e tutoriais
├── logs/                # Logs da aplicação
├── output/              # Documentação gerada
├── temp/                # Arquivos temporários
└── fontes_exemplo.txt   # Template para lista de programas
```

### Configuração de Provedores de IA

#### Luzia (Santander - Recomendado para Produção)

```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

Edite o arquivo `config/config.yaml` para configurar parâmetros específicos do Luzia.

#### GitHub Copilot

```bash
export GITHUB_TOKEN="seu_github_token"
```

#### OpenAI

```bash
export OPENAI_API_KEY="sua_api_key"
```

#### AWS Bedrock

```bash
export AWS_ACCESS_KEY_ID="sua_access_key"
export AWS_SECRET_ACCESS_KEY="sua_secret_key"
export AWS_REGION="us-east-1"
```

### Configuração Avançada

Edite o arquivo `config/config.yaml` para ajustar:

- Configurações específicas de provedores
- Parâmetros de análise (profundidade, foco)
- Configurações de saída (formatos, estrutura)
- Configurações do sistema RAG
- Configurações de logging

## Uso Básico

### Verificação do Status do Sistema

Antes de iniciar análises, verifique se o sistema está configurado corretamente:

```bash
python /caminho/para/cobol_to_docs/runner/main.py --status
```

Este comando verifica a disponibilidade dos provedores de IA, carregamento da configuração e status do sistema RAG.

### Preparação dos Arquivos de Entrada

#### Lista de Programas COBOL

Crie um arquivo texto listando os programas COBOL a serem analisados:

```
# arquivo: meus_programas.txt
programa1.cbl
programa2.cbl
programa3.cbl
```

#### Lista de Copybooks (Opcional)

Crie um arquivo texto listando os copybooks relacionados:

```
# arquivo: meus_copybooks.txt
copybook1.cpy
copybook2.cpy
copybook3.cpy
```

### Análise Básica

#### Análise Simples

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes meus_programas.txt \
  --models enhanced_mock
```

#### Análise com Copybooks

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes meus_programas.txt \
  --books meus_copybooks.txt \
  --models luzia
```

#### Análise de Programa Individual

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programa_especifico.cbl \
  --models enhanced_mock
```

### Usando Exemplos Incluídos

O sistema inclui exemplos prontos para teste:

```bash
# Análise usando exemplos incluídos
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes examples/fontes.txt \
  --models enhanced_mock
```

## Funcionalidades Avançadas

### Tipos de Análise Especializada

#### Análise Consolidada Sistêmica

Realiza análise integrada de múltiplos programas com visão arquitetural:

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --consolidado \
  --models luzia
```

#### Análise Especializada

Análise detalhada com foco em padrões avançados e otimizações:

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --analise-especialista \
  --models luzia
```

#### Análise para Modernização

Gera recomendações específicas para modernização e migração:

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --modernizacao \
  --models luzia
```

#### Análise Detalhada da PROCEDURE DIVISION

Foco específico na lógica de processamento:

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --procedure-detalhada \
  --models luzia
```

### Opções de Saída

#### Geração de PDF

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --pdf \
  --models luzia
```

#### Relatório Único Consolidado

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --relatorio-unico \
  --models luzia
```

#### Diretório de Saída Personalizado

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --output minha_saida \
  --models luzia
```

### Configurações Avançadas

#### Conjunto de Prompts Personalizado

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --prompt-set especialista \
  --models luzia
```

#### Remoção de Comentários

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --no-comments \
  --models luzia
```

#### Nível de Logging Detalhado

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --log-level DEBUG \
  --models luzia
```

## Sistema RAG

### Funcionamento do Sistema RAG

O sistema RAG (Retrieval-Augmented Generation) enriquece automaticamente as análises com conhecimento especializado em COBOL. Durante cada análise, o sistema busca informações relevantes na base de conhecimento e incorpora esse contexto na análise da IA.

### Base de Conhecimento

A base de conhecimento inclui:

- Padrões comuns de programação COBOL
- Regras de negócio bancárias e financeiras
- Melhores práticas de desenvolvimento
- Estruturas de dados típicas
- Padrões de modernização

### Configuração do RAG

O sistema RAG é configurado automaticamente, mas pode ser personalizado através do arquivo `config/config.yaml`:

```yaml
rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base.json"
  embeddings_cache: "data/cobol_embeddings.pkl"
  max_context_items: 10
  similarity_threshold: 0.7
```

### Monitoramento do RAG

O sistema gera logs detalhados das operações RAG:

- `logs/rag_session_report_*.txt` - Relatório resumido da sessão
- `logs/rag_detailed_log_*.json` - Log detalhado em formato JSON
- `logs/rag_operations_*.log` - Log de operações específicas

## Provedores de IA

### Enhanced Mock (Desenvolvimento e Testes)

Provider simulado que não requer credenciais, ideal para desenvolvimento e testes:

```bash
--models enhanced_mock
```

**Características:**
- Não requer configuração de credenciais
- Gera análises simuladas realistas
- Ideal para validação de fluxos
- Tempo de resposta consistente

### Luzia (Produção - Recomendado)

Provider oficial do Santander usando modelo aws-claude-3-5-sonnet:

```bash
--models luzia
```

**Características:**
- Análises de alta qualidade
- Integração nativa com ambiente Santander
- Suporte a análises complexas
- Otimizado para código COBOL bancário

### GitHub Copilot

Provider usando modelo gpt-4o:

```bash
--models github_copilot
```

**Características:**
- Análises rápidas e precisas
- Boa compreensão de padrões de código
- Integração com ecossistema GitHub
- Suporte a múltiplas linguagens

### OpenAI

Provider usando modelos GPT-4:

```bash
--models openai
```

**Características:**
- Análises detalhadas e contextuais
- Capacidade de raciocínio avançada
- Suporte a análises especializadas
- Flexibilidade de configuração

### AWS Bedrock

Provider usando modelos Claude e Titan:

```bash
--models bedrock
```

**Características:**
- Integração com infraestrutura AWS
- Múltiplos modelos disponíveis
- Controle de custos granular
- Escalabilidade empresarial

### Seleção de Múltiplos Provedores

É possível usar múltiplos provedores em uma única análise:

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --models '["luzia", "github_copilot"]'
```

## Análise de Resultados

### Estrutura dos Arquivos de Saída

#### Documentação Principal

Cada programa analisado gera um arquivo de análise funcional:

```
output/
├── PROGRAMA1_analise_funcional.md
├── PROGRAMA2_analise_funcional.md
└── PROGRAMA3_analise_funcional.md
```

#### Arquivos de Suporte

```
output/
├── ai_requests/          # Requisições enviadas para IA
├── ai_responses/         # Respostas recebidas da IA
└── relatorio_custos.txt  # Relatório de custos e tokens
```

#### Logs do Sistema

```
logs/
├── cobol_to_docs_*.log              # Logs principais
├── rag_session_report_*.txt         # Relatórios RAG
├── rag_detailed_log_*.json          # Logs RAG detalhados
└── rag_operations_*.log             # Operações RAG
```

### Estrutura da Análise Funcional

Cada arquivo de análise contém:

#### Cabeçalho
- Nome do programa
- Data e hora da análise
- Modelo de IA utilizado
- Provedor usado

#### Resumo Executivo
- Propósito do programa
- Tipo de processamento
- Complexidade estimada
- Principais funcionalidades

#### Análise Estrutural
- Divisões COBOL identificadas
- Seções principais
- Estruturas de dados
- Arquivos utilizados

#### Regras de Negócio
- Regras identificadas automaticamente
- Validações implementadas
- Cálculos realizados
- Condições de processamento

#### Fluxo de Processamento
- Sequência de operações
- Pontos de decisão
- Loops e iterações
- Tratamento de erros

#### Recomendações
- Sugestões de modernização
- Pontos de atenção
- Possíveis melhorias
- Considerações de migração

### Interpretação dos Relatórios

#### Relatório de Custos

O arquivo `relatorio_custos.txt` contém:

```
Modelo: luzia | Tokens: 15,234 | Custo: $0.0456
Modelo: github_copilot | Tokens: 12,890 | Custo: $0.0387
Total de tokens: 28,124
Custo total: $0.0843
```

#### Relatório RAG

Os relatórios RAG mostram:

- Número de operações realizadas
- Itens de conhecimento utilizados
- Contexto adicionado às análises
- Performance do sistema

### Validação dos Resultados

#### Verificação de Qualidade

Para validar a qualidade das análises:

1. Compare análises de múltiplos provedores
2. Verifique a consistência das regras de negócio identificadas
3. Valide o mapeamento de estruturas de dados
4. Confirme a precisão do fluxo de processamento

#### Métricas de Sucesso

- Taxa de sucesso das análises (deve ser próxima a 100%)
- Tempo médio de processamento por programa
- Quantidade de tokens utilizados
- Qualidade das recomendações geradas

## Solução de Problemas

### Problemas Comuns de Instalação

#### Erro de Dependências

```
ERROR: Could not find a version that satisfies the requirement
```

**Solução:**
```bash
# Atualizar pip
pip install --upgrade pip

# Instalar dependências individualmente
pip install pyyaml requests numpy scikit-learn
```

#### Erro de Permissões

```
Permission denied: '/usr/local/lib/python3.11/dist-packages/'
```

**Solução:**
```bash
# Usar ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows

pip install .
```

### Problemas de Configuração

#### Erro de Credenciais

```
Erro: Failed to resolve 'login.azure.paas.santanderbr.pre.corp'
```

**Solução:**
1. Verificar se as credenciais estão configuradas corretamente
2. Usar enhanced_mock para testes sem credenciais
3. Verificar conectividade de rede

#### Erro de Configuração de Modelo

```
Erro: Modelo gpt-4 não está configurado no sistema
```

**Solução:**
1. Verificar se a API key está configurada
2. Confirmar se o modelo está disponível
3. Usar modelo alternativo disponível

### Problemas de Execução

#### Erro de Importação

```
ModuleNotFoundError: No module named 'cobol_to_docs'
```

**Solução:**
```bash
# Reinstalar o pacote
pip uninstall cobol-to-docs
pip install . --force-reinstall
```

#### Erro de Arquivo Não Encontrado

```
FileNotFoundError: [Errno 2] No such file or directory: 'programa.cbl'
```

**Solução:**
1. Verificar se os caminhos dos arquivos estão corretos
2. Usar caminhos absolutos quando necessário
3. Verificar permissões de leitura dos arquivos

#### Erro de Memória

```
MemoryError: Unable to allocate array
```

**Solução:**
1. Processar arquivos menores por vez
2. Aumentar memória disponível
3. Usar processamento em lotes

### Problemas do Sistema RAG

#### Base de Conhecimento Não Carregada

```
WARNING: Knowledge base not found
```

**Solução:**
1. Verificar se o comando --init foi executado
2. Confirmar se os arquivos data/ estão presentes
3. Verificar permissões de leitura

#### Cache de Embeddings Corrompido

```
ERROR: Failed to load embeddings cache
```

**Solução:**
```bash
# Remover cache corrompido
rm data/cobol_embeddings.pkl

# O sistema recriará automaticamente
```

### Diagnóstico Avançado

#### Logs Detalhados

Para diagnóstico detalhado, use:

```bash
python /caminho/para/cobol_to_docs/runner/main.py \
  --fontes programas.txt \
  --models enhanced_mock \
  --log-level DEBUG
```

#### Teste de Componentes

```bash
# Testar parsers
python -m pytest cobol_to_docs/tests/test_cobol_parser.py -v

# Testar provedores
python -m pytest cobol_to_docs/tests/test_providers.py -v

# Testar configuração
python -m pytest cobol_to_docs/tests/test_config.py -v
```

## Referência Técnica

### Argumentos da Linha de Comando

#### Argumentos Principais

- `--fontes ARQUIVO` - Arquivo com lista de programas COBOL
- `--books ARQUIVO` - Arquivo com lista de copybooks
- `--models MODELO` - Modelo(s) de IA a usar
- `--output DIRETORIO` - Diretório de saída (padrão: output)

#### Opções de Análise

- `--consolidado` - Análise consolidada sistêmica
- `--relatorio-unico` - Relatório único consolidado
- `--analise-especialista` - Análise especializada
- `--procedure-detalhada` - Análise detalhada da PROCEDURE DIVISION
- `--modernizacao` - Análise para modernização

#### Opções de Configuração

- `--prompt-set CONJUNTO` - Conjunto de prompts a usar
- `--no-comments` - Remover comentários do código
- `--pdf` - Gerar relatórios HTML/PDF
- `--log-level NIVEL` - Nível de logging (DEBUG, INFO, WARNING, ERROR)

#### Comandos Utilitários

- `--init` - Inicializar projeto
- `--status` - Verificar status do sistema

### Estrutura de Arquivos de Configuração

#### config.yaml

```yaml
# Configuração principal
providers:
  luzia:
    enabled: true
    model: "aws-claude-3-5-sonnet"
  
  openai:
    enabled: true
    model: "gpt-4"

rag:
  enabled: true
  max_context_items: 10

output:
  format: "markdown"
  include_metadata: true
```

#### Arquivos de Prompts

Os arquivos de prompts estão organizados por especialidade:

- `prompts_enhanced.yaml` - Prompts gerais melhorados
- `prompts_especialista.yaml` - Prompts de especialista
- `prompts_cadoc_deep_analysis.yaml` - Análise profunda
- `prompts_deep_business_rules.yaml` - Regras de negócio
- `prompts_doc_legado_pro.yaml` - Documentação de legado
- `prompts_melhorado_rag.yaml` - Prompts otimizados para RAG

### Códigos de Saída

- `0` - Execução bem-sucedida
- `1` - Erro geral
- `2` - Erro de configuração
- `3` - Erro de arquivo não encontrado
- `4` - Erro de credenciais
- `5` - Erro de rede/conectividade

### Variáveis de Ambiente

#### Provedores de IA

```bash
# Luzia
LUZIA_CLIENT_ID
LUZIA_CLIENT_SECRET

# GitHub Copilot
GITHUB_TOKEN

# OpenAI
OPENAI_API_KEY

# AWS Bedrock
AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY
AWS_REGION
```

#### Configurações do Sistema

```bash
# Diretório de configuração personalizado
COBOL_ANALYZER_CONFIG_DIR

# Nível de logging padrão
COBOL_ANALYZER_LOG_LEVEL

# Diretório de cache
COBOL_ANALYZER_CACHE_DIR
```

### Limites e Restrições

#### Limites de Arquivo

- Tamanho máximo por programa COBOL: 10MB
- Número máximo de programas por análise: 100
- Número máximo de copybooks: 50

#### Limites de Token

- Tokens máximos por requisição: 32,000
- Tokens máximos por sessão: 1,000,000

#### Limites de Tempo

- Timeout por requisição: 300 segundos
- Timeout total por análise: 3600 segundos

### Suporte e Manutenção

#### Atualizações

Para verificar atualizações:

```bash
# Verificar versão atual
python -c "import cobol_to_docs; print(cobol_to_docs.__version__)"
```

#### Backup de Configurações

Recomenda-se fazer backup regular dos arquivos:

- `config/config.yaml`
- `config/prompts_*.yaml`
- `data/cobol_knowledge_base.json`

#### Monitoramento

Para monitoramento em produção, monitore:

- Logs de erro em `logs/cobol_to_docs_*.log`
- Taxa de sucesso das análises
- Tempo médio de processamento
- Uso de tokens e custos

---

**COBOL Analyzer v3.1.0**  
Manual do Usuário Completo  
Desenvolvido pela equipe COBOL Analyzer - Outubro 2025
