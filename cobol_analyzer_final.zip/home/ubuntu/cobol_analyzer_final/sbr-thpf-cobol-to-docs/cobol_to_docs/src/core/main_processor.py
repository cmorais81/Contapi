"""
COBOL AI Engine v3.0.0 - Main Processor
Processador principal para análise de arquivos COBOL
"""

import logging
import os
import time
from typing import List, Dict, Any

from .config import ConfigManager
from .prompt_manager_dual import DualPromptManager
from ..providers.enhanced_provider_manager import EnhancedProviderManager
from ..parsers.cobol_parser_original import COBOLParser
from ..analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from ..generators.documentation_generator import DocumentationGenerator
from ..utils.cost_calculator import CostCalculator

def process_cobol_files(args, config_manager: ConfigManager, cost_calculator: CostCalculator, rag_integration) -> None:
    """Processa arquivos COBOL com funcionalidade completa restaurada."""
    logger = logging.getLogger(__name__)
    
    models = parse_models_argument(args.models)
    logger.info(f"Modelos a serem utilizados: {models}")

    parser = COBOLParser()
    
    logger.info("=== MODO ANÁLISE PADRÃO =====")
    process_standard_analysis(args, config_manager, cost_calculator, parser, models, rag_integration)

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    import json
    if not models_str:
        return []
    models_str = models_str.strip()
    if models_str.startswith("["):
        try:
            return json.loads(models_str)
        except json.JSONDecodeError:
            return []
    return [models_str]

def process_standard_analysis(args, config_manager, cost_calculator, parser, models, rag_integration):
    """Processa análise padrão de programas COBOL."""
    logger = logging.getLogger(__name__)
    start_time = time.time()
    
    os.makedirs(args.output, exist_ok=True)
    
    programs, _ = parser.parse_file(args.fontes)
    logger.info(f"Total de programas para análise: {len(programs)}")

    books = []
    if args.books:
        _, books = parser.parse_file(args.books)
        logger.info(f"Total de copybooks carregados: {len(books)}")

    all_results = []
    successful_analyses = 0
    total_tokens = 0

    provider_manager = EnhancedProviderManager(config_manager.config)

    for program in programs:
        for model in models:
            logger.info(f"Analisando {program.name} com o modelo {model}")
            result = analyze_program_with_model(
                program, books, model, args.output, config_manager, 
                len(models) > 1, args.prompt_set, cost_calculator, 
                rag_integration, args, provider_manager
            )
            all_results.append(result)
            if result['success']:
                successful_analyses += 1
                total_tokens += result['tokens_used']

    generate_comparative_report(programs, all_results, args.output)
    
    total_time = time.time() - start_time
    total_analyses = len(programs) * len(models)
    success_rate = (successful_analyses / total_analyses) * 100 if total_analyses > 0 else 0

    logger.info(f"Análises bem-sucedidas: {successful_analyses}/{total_analyses} ({success_rate:.1f}%)")
    logger.info(f"Tempo total: {total_time:.2f}s")

def analyze_program_with_model(program, books, model, output_dir, config_manager, 
                             is_multi_model, prompt_set, cost_calculator, 
                             rag_integration, args, provider_manager):
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)

    provider_name = config_manager.get_provider_for_model(model) or "unknown"
    model_output_dir = os.path.join(output_dir, provider_name, model.replace('/', '_'))
    os.makedirs(model_output_dir, exist_ok=True)

    try:
        prompt_manager = DualPromptManager(config_manager.config, prompt_set)
        doc_generator = DocumentationGenerator()
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager, rag_integration)
        
        analysis_result = analyzer.analyze_program(program, model)
        
        if not analysis_result.success:
            logger.error(f"Falha na análise de {program.name} com {model}: {analysis_result.error_message}")
            return {'success': False, 'model': model, 'error': analysis_result.error_message, 'tokens_used': 0}

        doc_generator.generate_program_documentation(program, analysis_result, model_output_dir)
        
        logger.info(f"Análise de {program.name} com {model} concluída. Tokens: {analysis_result.tokens_used}")
        return {'success': True, 'model': model, 'tokens_used': analysis_result.tokens_used, 'response': analysis_result}
        
    except Exception as e:
        logger.critical(f"Erro fatal ao analisar {program.name} com {model}: {e}", exc_info=True)
        return {'success': False, 'model': model, 'error': str(e), 'tokens_used': 0}

def generate_comparative_report(programs, all_results, output_dir):
    """Gera relatório comparativo entre modelos."""
    logger = logging.getLogger(__name__)
    report_path = os.path.join(output_dir, "relatorio_comparativo.md")
    try:
        with open(report_path, "w", encoding="utf-8") as f:
            f.write("# Relatório Comparativo de Análise\n")
            # Simplificado para focar na correção do bug
            for result in all_results:
                f.write(f"- Modelo: {result['model']}, Sucesso: {result['success']}\n")
        logger.info(f"Relatório comparativo salvo em: {report_path}")
    except Exception as e:
        logger.error(f"Não foi possível gerar o relatório: {e}")

