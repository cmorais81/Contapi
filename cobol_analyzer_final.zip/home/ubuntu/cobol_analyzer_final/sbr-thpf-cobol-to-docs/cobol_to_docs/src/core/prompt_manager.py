"""
COBOL AI Engine v2.6.0 - Prompt Manager
Gerenciador de prompts customizáveis com todos os métodos implementados.
"""

import os
import yaml
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime


class PromptManager:
    """
    Gerenciador de prompts customizáveis para análise COBOL.
    Implementa TODOS os métodos necessários.
    """
    
    def __init__(self, config_file: str = "config/prompts.yaml"):
        """Inicializa o gerenciador de prompts."""
        self.logger = logging.getLogger(__name__)
        self.config_file = config_file
        self.config = {}
        self.load_config()
        self.logger.info(f"Configuração de prompts carregada: {config_file}")
        self.logger.info("Prompt Manager inicializado com configuração customizável")
    
    def load_config(self) -> None:
        """Carrega configuração de prompts do arquivo YAML."""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    self.config = yaml.safe_load(f) or {}
            else:
                self.config = self._get_default_config()
                self.save_config()
        except Exception as e:
            self.logger.error(f"Erro ao carregar configuração de prompts: {e}")
            self.config = self._get_default_config()
    
    def save_config(self) -> None:
        """Salva configuração atual no arquivo YAML."""
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, 'w', encoding='utf-8') as f:
                yaml.dump(self.config, f, default_flow_style=False, 
                         allow_unicode=True, indent=2)
        except Exception as e:
            self.logger.error(f"Erro ao salvar configuração de prompts: {e}")
    
    def get_analysis_questions(self) -> Dict[str, Dict[str, Any]]:
        """
        Retorna todas as perguntas de análise configuradas.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        prompts_config = self.config.get('prompts', {})
        return prompts_config.get('analysis_questions', {})
    
    def get_functional_question(self) -> str:
        """Retorna a pergunta funcional atual."""
        questions = self.get_analysis_questions()
        functional = questions.get('functional', {})
        return functional.get('question', "O que este programa faz funcionalmente?")
    
    def update_functional_question(self, new_question: str) -> bool:
        """Atualiza a pergunta funcional."""
        try:
            if 'analysis_questions' not in self.config:
                self.config['analysis_questions'] = {}
            
            if 'functional' not in self.config['analysis_questions']:
                self.config['analysis_questions']['functional'] = {}
            
            self.config['analysis_questions']['functional']['question'] = new_question
            self.save_config()
            
            self.logger.info(f"Pergunta funcional atualizada: {new_question}")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao atualizar pergunta funcional: {e}")
            return False
    
    def generate_base_prompt(self, program_name: str, program_code: str, 
                           context: Dict[str, Any] = None) -> str:
        """Gera prompt base para análise COBOL com pré-análise integrada."""
        if context is None:
            context = {}
        
        # Obter configurações
        system_prompt = self.get_system_prompt()
        required_questions = self.get_required_questions()
        
        # Construir prompt
        prompt_parts = [system_prompt]
        
        # NOVA FUNCIONALIDADE: Incluir pré-análise se disponível
        pre_analysis = context.get('pre_analysis', {})
        if pre_analysis:
            prompt_parts.append(f"\n=== PRÉ-ANÁLISE DETALHADA DO CÓDIGO ===")
            
            # Estrutura do programa
            if 'structure' in pre_analysis:
                structure = pre_analysis['structure']
                prompt_parts.append(f"\nESTRUTURA DO PROGRAMA:")
                prompt_parts.append(f"- Divisões: {', '.join(structure.get('divisions', []))}")
                prompt_parts.append(f"- Seções: {len(structure.get('sections', []))}")
                prompt_parts.append(f"- Parágrafos: {len(structure.get('paragraphs', []))}")
            
            # Comentários categorizados
            if 'comments' in pre_analysis:
                comments = pre_analysis['comments']
                prompt_parts.append(f"\nCOMENTÁRIOS ANALISADOS ({len(comments)} encontrados):")
                for comment in comments[:10]:  # Limitar a 10 comentários mais relevantes
                    prompt_parts.append(f"- {comment.get('text', '')[:100]}...")
            
            # Regras de negócio identificadas
            if 'business_rules' in pre_analysis:
                rules = pre_analysis['business_rules']
                prompt_parts.append(f"\nREGRAS DE NEGÓCIO IDENTIFICADAS ({len(rules)} encontradas):")
                for rule in rules:
                    prompt_parts.append(f"- {rule.get('description', '')}")
                    if rule.get('type'):
                        prompt_parts.append(f"  Tipo: {rule['type']}")
            
            # Referências regulatórias
            if 'regulatory_references' in pre_analysis:
                refs = pre_analysis['regulatory_references']
                if refs:
                    prompt_parts.append(f"\nREFERÊNCIAS REGULATÓRIAS ENCONTRADAS:")
                    for ref in refs:
                        prompt_parts.append(f"- {ref}")
            
            # Arquivos e recursos
            if 'files' in pre_analysis:
                files = pre_analysis['files']
                if files.get('input_files') or files.get('output_files'):
                    prompt_parts.append(f"\nARQUIVOS MAPEADOS:")
                    if files.get('input_files'):
                        prompt_parts.append(f"- Entrada: {', '.join(files['input_files'])}")
                    if files.get('output_files'):
                        prompt_parts.append(f"- Saída: {', '.join(files['output_files'])}")
            
            # Métricas de qualidade
            if 'metrics' in pre_analysis:
                metrics = pre_analysis['metrics']
                prompt_parts.append(f"\nMÉTRICAS DE QUALIDADE:")
                prompt_parts.append(f"- Complexidade: {metrics.get('complexity', 'N/A')}")
                prompt_parts.append(f"- Linhas de código: {metrics.get('lines_of_code', 'N/A')}")
                prompt_parts.append(f"- Percentual de comentários: {metrics.get('comment_percentage', 'N/A')}%")
            
            prompt_parts.append(f"\n=== FIM DA PRÉ-ANÁLISE ===\n")
        
        prompt_parts.append(f"Analise o seguinte programa COBOL:")
        prompt_parts.append(f"Nome do programa: {program_name}")
        prompt_parts.append(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Adicionar informações de contexto
        if context.get('books'):
            prompt_parts.append(f"Copybooks relacionados: {len(context.get('books', []))}")
        
        prompt_parts.append(f"\nCódigo do programa:\n{program_code}")
        
        # Adicionar perguntas específicas
        prompt_parts.append(f"\nPor favor, responda às seguintes perguntas específicas:")
        
        for i, (key, question_data) in enumerate(required_questions.items(), 1):
            question = question_data.get('question', '')
            description = question_data.get('description', '')
            prompt_parts.append(f"\n{i}. {question}")
            if description:
                prompt_parts.append(f"   ({description})")
        
        # Adicionar perguntas opcionais se houver espaço
        optional_questions = self.get_optional_questions()
        if optional_questions:
            prompt_parts.append(f"\nPerguntas adicionais (se possível):")
            for i, (key, question_data) in enumerate(optional_questions.items(), len(required_questions) + 1):
                question = question_data.get('question', '')
                prompt_parts.append(f"\n{i}. {question}")
        
        prompt_parts.append(f"\nForneça uma análise completa e detalhada em português brasileiro.")
        
        return '\n'.join(prompt_parts)
    
    def generate_phase_prompt(self, base_prompt: str, phase: str, 
                            question_data: Dict[str, Any]) -> str:
        """Gera prompt específico para uma fase."""
        phase_template = self.config.get('phase_templates', {}).get(
            phase, self._get_default_phase_template()
        )
        
        # Substituições específicas da fase
        substitutions = {
            'base_prompt': base_prompt,
            'question': question_data.get('question', ''),
            'focus': question_data.get('focus', ''),
            'context': question_data.get('context', ''),
            'phase': phase
        }
        
        prompt = phase_template
        for key, value in substitutions.items():
            prompt = prompt.replace(f'{{{key}}}', str(value))
        
        return prompt
    
    def get_questions_by_priority(self) -> List[tuple]:
        """Retorna perguntas ordenadas por prioridade."""
        questions = self.get_analysis_questions()
        
        # Ordenar por prioridade
        sorted_questions = sorted(
            questions.items(),
            key=lambda x: x[1].get('priority', 999)
        )
        
        return sorted_questions
    
    def get_required_questions(self) -> Dict[str, Dict[str, Any]]:
        """Retorna apenas perguntas obrigatórias."""
        questions = self.get_analysis_questions()
        return {
            key: value for key, value in questions.items()
            if value.get('required', False)
        }
    
    def get_optional_questions(self) -> Dict[str, Dict[str, Any]]:
        """Retorna apenas perguntas opcionais."""
        questions = self.get_analysis_questions()
        return {
            key: value for key, value in questions.items()
            if not value.get('required', False)
        }
    
    def add_custom_question(self, key: str, question: str, 
                          priority: int = 10, required: bool = False,
                          context: str = "") -> bool:
        """Adiciona uma pergunta customizada."""
        try:
            if 'analysis_questions' not in self.config:
                self.config['analysis_questions'] = {}
            
            self.config['analysis_questions'][key] = {
                'question': question,
                'priority': priority,
                'required': required,
                'context': context,
                'added_at': datetime.now().isoformat()
            }
            
            self.save_config()
            self.logger.info(f"Pergunta customizada adicionada: {key}")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao adicionar pergunta customizada: {e}")
            return False
    
    def remove_question(self, key: str) -> bool:
        """Remove uma pergunta."""
        try:
            questions = self.config.get('analysis_questions', {})
            if key in questions:
                del questions[key]
                self.save_config()
                self.logger.info(f"Pergunta removida: {key}")
                return True
            return False
        except Exception as e:
            self.logger.error(f"Erro ao remover pergunta: {e}")
            return False
    
    def get_context_templates(self) -> Dict[str, str]:
        """Retorna templates de contexto por tipo de programa."""
        return self.config.get('context_templates', {})
    
    def detect_program_type(self, program_name: str, program_code: str) -> str:
        """Detecta tipo de programa baseado em padrões."""
        patterns = self.config.get('program_patterns', {})
        
        for program_type, pattern_data in patterns.items():
            name_patterns = pattern_data.get('name_patterns', [])
            code_patterns = pattern_data.get('code_patterns', [])
            
            # Verificar padrões no nome
            for pattern in name_patterns:
                if pattern.lower() in program_name.lower():
                    return program_type
            
            # Verificar padrões no código
            for pattern in code_patterns:
                if pattern.upper() in program_code.upper():
                    return program_type
        
        return 'default'
    
    def get_program_context(self, program_name: str, program_code: str) -> str:
        """Retorna contexto específico para o tipo de programa."""
        program_type = self.detect_program_type(program_name, program_code)
        templates = self.get_context_templates()
        return templates.get(program_type, templates.get('default', ''))
    
    def _format_context(self, context: Dict[str, Any]) -> str:
        """Formata informações de contexto."""
        if not context:
            return "Nenhum contexto adicional fornecido."
        
        formatted = []
        
        if 'books' in context:
            books = context['books']
            if books:
                formatted.append(f"Copybooks relacionados: {len(books)} encontrados")
                if len(books) <= 5:
                    formatted.append(f"Nomes: {', '.join(books)}")
        
        if 'related_programs' in context:
            related = context['related_programs']
            if related:
                formatted.append(f"Programas relacionados: {len(related)}")
        
        return "; ".join(formatted) if formatted else "Contexto básico de análise."
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão com prompts aprimorados para documentação completa."""
        return {
            'version': '2.0.0',
            'analysis_questions': {
                'functional': {
                    'question': 'Forneça uma análise funcional completa e detalhada deste programa COBOL, incluindo: 1) Propósito principal e objetivo de negócio, 2) Fluxo de processamento passo-a-passo, 3) Entradas e saídas esperadas, 4) Condições de execução e critérios de parada, 5) Impacto no processo de negócio geral.',
                    'priority': 1,
                    'required': True,
                    'focus': 'Análise funcional abrangente com contexto de negócio',
                    'context': 'Documentação funcional completa para stakeholders técnicos e de negócio'
                },
                'technical_architecture': {
                    'question': 'Descreva detalhadamente a arquitetura técnica do programa, incluindo: 1) Estrutura das divisões COBOL (IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE), 2) Organização de seções e parágrafos, 3) Definição e uso de arquivos (FD, SELECT), 4) Estruturas de dados (WORKING-STORAGE, LINKAGE), 5) Fluxo de controle e chamadas de programa, 6) Tratamento de erros e exceções.',
                    'priority': 2,
                    'required': True,
                    'focus': 'Arquitetura técnica detalhada com mapeamento de componentes',
                    'context': 'Documentação técnica para desenvolvedores e arquitetos'
                },
                'business_rules': {
                    'question': 'Identifique e documente todas as regras de negócio implementadas, incluindo: 1) Validações de dados e critérios de aceitação, 2) Cálculos e fórmulas utilizadas, 3) Condições de processamento e decisões lógicas, 4) Regras de transformação de dados, 5) Políticas de negócio codificadas, 6) Exceções e tratamentos especiais.',
                    'priority': 3,
                    'required': True,
                    'focus': 'Mapeamento completo de regras de negócio e lógica empresarial',
                    'context': 'Documentação de regras para analistas de negócio e compliance'
                },
                'data_structures': {
                    'question': 'Analise e documente todas as estruturas de dados, incluindo: 1) Layouts de registros e campos, 2) Tipos de dados e formatos (PIC clauses), 3) Relacionamentos entre estruturas, 4) Copybooks utilizados e suas funções, 5) Mapeamento de dados de entrada e saída, 6) Transformações e conversões de dados.',
                    'priority': 4,
                    'required': True,
                    'focus': 'Documentação completa de estruturas e fluxos de dados',
                    'context': 'Referência técnica para integração e manutenção de dados'
                },
                'integration_interfaces': {
                    'question': 'Documente todas as interfaces e integrações, incluindo: 1) Arquivos de entrada e saída (formatos, layouts, frequência), 2) Chamadas para outros programas (CALL statements), 3) Acesso a bancos de dados (SQL embedded, DB2, etc.), 4) Interfaces com sistemas externos, 5) Dependências de JCL e jobs, 6) Parâmetros de execução e configuração.',
                    'priority': 5,
                    'required': True,
                    'focus': 'Mapeamento completo de integrações e dependências',
                    'context': 'Documentação de interfaces para integração de sistemas'
                },
                'performance_considerations': {
                    'question': 'Analise aspectos de performance e otimização, incluindo: 1) Pontos críticos de performance no código, 2) Uso de recursos (CPU, memória, I/O), 3) Algoritmos e estruturas de dados utilizadas, 4) Oportunidades de otimização identificadas, 5) Gargalos potenciais e limitações, 6) Recomendações para melhorias.',
                    'priority': 6,
                    'required': False,
                    'focus': 'Análise de performance e otimização',
                    'context': 'Documentação técnica para otimização e tuning'
                },
                'maintenance_guide': {
                    'question': 'Forneça um guia de manutenção detalhado, incluindo: 1) Pontos de atenção para modificações, 2) Impactos de mudanças em diferentes seções, 3) Procedimentos de teste recomendados, 4) Documentação de bugs conhecidos ou limitações, 5) Histórico de modificações importantes, 6) Recomendações para futuras melhorias.',
                    'priority': 7,
                    'required': False,
                    'focus': 'Guia prático para manutenção e evolução',
                    'context': 'Manual de manutenção para equipes de desenvolvimento'
                },
                'code_quality': {
                    'question': 'Avalie a qualidade do código, incluindo: 1) Aderência a padrões de codificação COBOL, 2) Legibilidade e organização do código, 3) Uso de boas práticas de programação, 4) Identificação de code smells ou anti-patterns, 5) Sugestões de refatoração, 6) Avaliação de manutenibilidade.',
                    'priority': 8,
                    'required': False,
                    'focus': 'Avaliação de qualidade e manutenibilidade do código',
                    'context': 'Análise de qualidade para revisão técnica'
                }
            },
            'base_template': {
                'template': '''Você é um especialista em análise de sistemas COBOL com mais de 20 anos de experiência em documentação de sistemas legados. Sua tarefa é analisar o programa COBOL fornecido e gerar uma documentação técnica completa, detalhada e profissional.

PROGRAMA PARA ANÁLISE:
Nome: {program_name}
Data da análise: {timestamp}
Contexto: {context_info}

CÓDIGO COBOL:
{program_code}

INSTRUÇÕES PARA ANÁLISE:
1. Forneça uma documentação técnica completa e profissional
2. Use linguagem clara e precisa, adequada para diferentes audiências (técnica e negócio)
3. Inclua exemplos específicos do código quando relevante
4. Organize a informação de forma estruturada e lógica
5. Destaque aspectos críticos e pontos de atenção
6. Forneça insights baseados em boas práticas de desenvolvimento COBOL
7. Mantenha foco na utilidade prática da documentação

FORMATO DE RESPOSTA:
- Use Markdown para formatação
- Organize em seções claras e bem estruturadas
- Inclua tabelas quando apropriado para dados estruturados
- Use listas numeradas ou com marcadores para informações sequenciais
- Destaque informações importantes com formatação adequada

Gere uma análise abrangente que sirva como documentação técnica definitiva deste programa.'''
            },
            'phase_templates': {
                'default': '''Baseado no seguinte programa COBOL:

{base_prompt}

Foque especificamente em: {question}

{context}'''
            },
            'context_templates': {
                'data_processing': 'Programa de processamento de dados corporativo',
                'report_programs': 'Programa de geração de relatórios',
                'batch_programs': 'Programa de processamento em lote',
                'online_programs': 'Programa de transação online',
                'interface_programs': 'Programa de interface/API',
                'utility_programs': 'Programa utilitário/ferramenta',
                'default': 'Programa COBOL genérico'
            },
            'program_patterns': {
                'data_processing': {
                    'name_patterns': ['proc', 'process', 'data'],
                    'code_patterns': ['SELECT', 'FD', 'SORT']
                },
                'report_programs': {
                    'name_patterns': ['rel', 'rpt', 'rep', 'report'],
                    'code_patterns': ['WRITE', 'DISPLAY', 'REPORT']
                },
                'batch_programs': {
                    'name_patterns': ['batch', 'bth', 'job'],
                    'code_patterns': ['JCL', 'STEP', 'SYSIN']
                },
                'online_programs': {
                    'name_patterns': ['onl', 'txn', 'scr', 'cics'],
                    'code_patterns': ['CICS', 'COMMAREA', 'DFHCOMMAREA']
                },
                'interface_programs': {
                    'name_patterns': ['int', 'ifc', 'api', 'web'],
                    'code_patterns': ['CALL', 'LINKAGE', 'COPY']
                },
                'utility_programs': {
                    'name_patterns': ['utl', 'util', 'tool'],
                    'code_patterns': ['UTILITY', 'TOOL', 'CONVERT']
                }
            }
        }
    
    def _get_default_base_template(self) -> str:
        """Retorna template base padrão."""
        return '''Analise o seguinte programa COBOL:

Nome do programa: {program_name}
Timestamp da análise: {timestamp}
Contexto: {context_info}

Código COBOL:
{program_code}

Por favor, forneça uma análise completa e detalhada.'''
    
    def _get_default_phase_template(self) -> str:
        """Retorna template de fase padrão."""
        return '''Baseado no seguinte programa COBOL:

{base_prompt}

Foque especificamente em: {question}

{context}'''
    
    def get_system_prompt(self) -> str:
        """Retorna o prompt do sistema configurado."""
        prompts_config = self.config.get('prompts', {})
        return prompts_config.get('system_prompt', self._get_default_system_prompt())
    
    def _get_default_system_prompt(self) -> str:
        """Retorna prompt do sistema padrão."""
        return """Você é um especialista em análise de código COBOL com mais de 20 anos de experiência em sistemas bancários e financeiros.

Sua especialidade inclui:
- Análise detalhada de programas COBOL legados
- Documentação técnica e funcional completa
- Identificação de regras de negócio e compliance regulatório
- Mapeamento de fluxos de dados e processos
- Avaliação de qualidade e manutenibilidade de código

Responda sempre em português brasileiro de forma clara, técnica e estruturada.
Forneça análises completas e detalhadas, evitando respostas superficiais.
Identifique e documente todas as regras de negócio, validações e aspectos regulatórios encontrados no código."""

