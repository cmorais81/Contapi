"""
COBOL AI Engine v3.0.0 - Dual Prompt Manager
Gerenciador de prompts que utiliza a configuração centralizada do ConfigManager.
"""

import logging
from typing import Dict, List, Any, Optional

class DualPromptManager:
    """
    Gerenciador de prompts que busca as configurações do ConfigManager,
    suportando prompts específicos por modelo.
    """
    
    def __init__(self, config: Dict[str, Any], prompt_set: str = None, **kwargs):
        """
        Inicializa o gerenciador de prompts.
        
        Args:
            config: Dicionário de configuração vindo do ConfigManager.
            prompt_set: Conjunto de prompts a usar (para compatibilidade, mas a lógica principal usa a config).
        """
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.prompt_set = prompt_set or self.config.get("ai", {}).get("default_prompt_set", "original")
        
        # A configuração de prompts é extraída diretamente da configuração principal
        self.prompts_config = self.config.get("prompts", {})
        
        self.logger.info(f"Dual Prompt Manager inicializado com o conjunto de prompts: {self.prompt_set}")

    def get_system_prompt(self, model_name: Optional[str] = None) -> str:
        """
        Retorna o prompt de sistema para o modelo especificado, com fallback para o padrão.
        """
        # 1. Tenta buscar um prompt de sistema específico para o modelo
        if model_name:
            model_specific_prompts = self.prompts_config.get("model_specific", {})
            if model_name in model_specific_prompts and "system_prompt" in model_specific_prompts[model_name]:
                self.logger.info(f"Usando system prompt específico para o modelo: {model_name}")
                return model_specific_prompts[model_name]["system_prompt"]

        # 2. Fallback para o prompt de sistema do conjunto ativo
        active_set_config = self.prompts_config.get(self.prompt_set, {})
        if "system_prompt" in active_set_config:
            self.logger.info(f"Usando system prompt do conjunto \'{self.prompt_set}\'.")
            return active_set_config["system_prompt"]

        # 3. Fallback para o prompt de sistema global
        global_system_prompt = self.prompts_config.get("global_system_prompt", "Você é um assistente de IA.")
        self.logger.warning("Nenhum system prompt específico encontrado, usando o global.")
        return global_system_prompt

    def get_prompt(self, model_name: Optional[str] = None) -> str:
        """
        Retorna o prompt principal para o modelo especificado, com fallback para o padrão.
        """
        # 1. Tenta buscar um prompt principal específico para o modelo
        if model_name:
            model_specific_prompts = self.prompts_config.get("model_specific", {})
            if model_name in model_specific_prompts and "main_prompt" in model_specific_prompts[model_name]:
                self.logger.info(f"Usando prompt principal específico para o modelo: {model_name}")
                return model_specific_prompts[model_name]["main_prompt"]

        # 2. Fallback para o prompt principal do conjunto ativo
        active_set_config = self.prompts_config.get(self.prompt_set, {})
        if "main_prompt" in active_set_config:
            self.logger.info(f"Usando prompt principal do conjunto \'{self.prompt_set}\'.")
            return active_set_config["main_prompt"]

        # 3. Fallback para um prompt principal global ou string vazia
        global_main_prompt = self.prompts_config.get("global_main_prompt", "")
        self.logger.warning("Nenhum prompt principal específico encontrado, usando o global ou padrão.")
        return global_main_prompt

    def generate_base_prompt(self, program_name: str, program_code: str, model_name: Optional[str] = None, context: Optional[Dict[str, Any]] = None) -> str:
        """
        Gera o prompt completo para a análise, combinando o prompt principal com o código.
        """
        main_prompt_template = self.get_prompt(model_name)
        
        # Substituir placeholders no template
        prompt = main_prompt_template.format(
            program_name=program_name,
            program_code=program_code,
            context=context or {}
        )
        
        return prompt


