"""
COBOL AI Engine v1.7.0 - Exceções Customizadas
Módulo com exceções específicas para melhor tratamento de erros.
"""

from typing import Optional, Dict, Any


class COBOLAIEngineException(Exception):
    """Exceção base para todas as exceções do COBOL AI Engine."""
    
    def __init__(self, message: str, error_code: str = None, details: Dict[str, Any] = None):
        """
        Inicializa a exceção base.
        
        Args:
            message: Mensagem de erro
            error_code: Código de erro único
            details: Detalhes adicionais sobre o erro
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code or "UNKNOWN_ERROR"
        self.details = details or {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte a exceção para dicionário."""
        return {
            "error_type": self.__class__.__name__,
            "error_code": self.error_code,
            "message": self.message,
            "details": self.details
        }


class ConfigurationError(COBOLAIEngineException):
    """Erro de configuração do sistema."""
    
    def __init__(self, message: str, config_file: str = None, missing_key: str = None):
        super().__init__(
            message=message,
            error_code="CONFIG_ERROR",
            details={
                "config_file": config_file,
                "missing_key": missing_key
            }
        )


class ProviderError(COBOLAIEngineException):
    """Erro relacionado aos provedores de IA."""
    
    def __init__(self, message: str, provider_name: str = None, provider_error: str = None):
        super().__init__(
            message=message,
            error_code="PROVIDER_ERROR",
            details={
                "provider_name": provider_name,
                "provider_error": provider_error
            }
        )


class ProviderNotAvailableError(ProviderError):
    """Provedor de IA não está disponível."""
    
    def __init__(self, provider_name: str, reason: str = None):
        message = f"Provedor '{provider_name}' não está disponível"
        if reason:
            message += f": {reason}"
        
        super().__init__(
            message=message,
            provider_name=provider_name,
            provider_error=reason
        )
        self.error_code = "PROVIDER_NOT_AVAILABLE"


class ProviderAuthenticationError(ProviderError):
    """Erro de autenticação com provedor de IA."""
    
    def __init__(self, provider_name: str, auth_error: str = None):
        message = f"Falha na autenticação com o provedor '{provider_name}'"
        if auth_error:
            message += f": {auth_error}"
        
        super().__init__(
            message=message,
            provider_name=provider_name,
            provider_error=auth_error
        )
        self.error_code = "PROVIDER_AUTH_ERROR"


class ProviderTimeoutError(ProviderError):
    """Timeout na comunicação com provedor de IA."""
    
    def __init__(self, provider_name: str, timeout_seconds: int = None):
        message = f"Timeout na comunicação com o provedor '{provider_name}'"
        if timeout_seconds:
            message += f" após {timeout_seconds} segundos"
        
        super().__init__(
            message=message,
            provider_name=provider_name,
            provider_error=f"Timeout: {timeout_seconds}s"
        )
        self.error_code = "PROVIDER_TIMEOUT"


class ProviderQuotaExceededError(ProviderError):
    """Cota do provedor de IA foi excedida."""
    
    def __init__(self, provider_name: str, quota_type: str = None):
        message = f"Cota excedida para o provedor '{provider_name}'"
        if quota_type:
            message += f" ({quota_type})"
        
        super().__init__(
            message=message,
            provider_name=provider_name,
            provider_error=f"Quota exceeded: {quota_type}"
        )
        self.error_code = "PROVIDER_QUOTA_EXCEEDED"


class FileProcessingError(COBOLAIEngineException):
    """Erro no processamento de arquivos."""
    
    def __init__(self, message: str, file_path: str = None, file_type: str = None):
        super().__init__(
            message=message,
            error_code="FILE_PROCESSING_ERROR",
            details={
                "file_path": file_path,
                "file_type": file_type
            }
        )


class FileNotFoundError(FileProcessingError):
    """Arquivo não encontrado."""
    
    def __init__(self, file_path: str):
        super().__init__(
            message=f"Arquivo não encontrado: {file_path}",
            file_path=file_path
        )
        self.error_code = "FILE_NOT_FOUND"


class InvalidFileFormatError(FileProcessingError):
    """Formato de arquivo inválido."""
    
    def __init__(self, file_path: str, expected_format: str = None):
        message = f"Formato de arquivo inválido: {file_path}"
        if expected_format:
            message += f" (esperado: {expected_format})"
        
        super().__init__(
            message=message,
            file_path=file_path,
            file_type=expected_format
        )
        self.error_code = "INVALID_FILE_FORMAT"


class COBOLParsingError(COBOLAIEngineException):
    """Erro no parsing de código COBOL."""
    
    def __init__(self, message: str, program_name: str = None, line_number: int = None):
        super().__init__(
            message=message,
            error_code="COBOL_PARSING_ERROR",
            details={
                "program_name": program_name,
                "line_number": line_number
            }
        )


class DocumentationGenerationError(COBOLAIEngineException):
    """Erro na geração de documentação."""
    
    def __init__(self, message: str, output_format: str = None, program_name: str = None):
        super().__init__(
            message=message,
            error_code="DOCUMENTATION_ERROR",
            details={
                "output_format": output_format,
                "program_name": program_name
            }
        )


class PDFConversionError(DocumentationGenerationError):
    """Erro na conversão para PDF."""
    
    def __init__(self, message: str, input_file: str = None, converter: str = None):
        super().__init__(
            message=message,
            output_format="PDF"
        )
        self.error_code = "PDF_CONVERSION_ERROR"
        self.details.update({
            "input_file": input_file,
            "converter": converter
        })


class ValidationError(COBOLAIEngineException):
    """Erro de validação de dados."""
    
    def __init__(self, message: str, field_name: str = None, field_value: Any = None):
        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            details={
                "field_name": field_name,
                "field_value": str(field_value) if field_value is not None else None
            }
        )


class TokenLimitExceededError(COBOLAIEngineException):
    """Limite de tokens excedido."""
    
    def __init__(self, message: str, current_tokens: int = None, max_tokens: int = None):
        super().__init__(
            message=message,
            error_code="TOKEN_LIMIT_EXCEEDED",
            details={
                "current_tokens": current_tokens,
                "max_tokens": max_tokens
            }
        )


# Utilitários para tratamento de exceções

def format_error_message(exception: COBOLAIEngineException) -> str:
    """
    Formata uma exceção customizada em uma mensagem amigável.
    
    Args:
        exception: Exceção customizada
        
    Returns:
        Mensagem formatada
    """
    message = f"[{exception.error_code}] {exception.message}"
    
    if exception.details:
        details = []
        for key, value in exception.details.items():
            if value is not None:
                details.append(f"{key}: {value}")
        
        if details:
            message += f" ({', '.join(details)})"
    
    return message


def get_user_friendly_message(exception: Exception) -> str:
    """
    Converte qualquer exceção em uma mensagem amigável ao usuário.
    
    Args:
        exception: Exceção a ser convertida
        
    Returns:
        Mensagem amigável
    """
    if isinstance(exception, COBOLAIEngineException):
        return format_error_message(exception)
    
    # Mapeamento de exceções comuns para mensagens amigáveis
    error_mappings = {
        "FileNotFoundError": "Arquivo não encontrado. Verifique se o caminho está correto.",
        "PermissionError": "Permissão negada. Verifique as permissões do arquivo ou diretório.",
        "ConnectionError": "Erro de conexão. Verifique sua conexão com a internet.",
        "TimeoutError": "Operação expirou. Tente novamente ou aumente o timeout.",
        "ValueError": "Valor inválido fornecido. Verifique os parâmetros de entrada.",
        "KeyError": "Chave não encontrada na configuração. Verifique o arquivo de configuração.",
        "ImportError": "Dependência não encontrada. Execute 'pip install -r requirements.txt'.",
    }
    
    exception_name = exception.__class__.__name__
    user_message = error_mappings.get(exception_name, str(exception))
    
    return f"[{exception_name}] {user_message}"


def suggest_solution(exception: COBOLAIEngineException) -> Optional[str]:
    """
    Sugere uma solução para a exceção.
    
    Args:
        exception: Exceção customizada
        
    Returns:
        Sugestão de solução ou None
    """
    solutions = {
        "CONFIG_ERROR": "Verifique o arquivo de configuração e certifique-se de que todas as chaves necessárias estão presentes.",
        "PROVIDER_NOT_AVAILABLE": "Verifique as credenciais do provedor ou tente usar um provedor alternativo.",
        "PROVIDER_AUTH_ERROR": "Verifique suas credenciais de API e certifique-se de que estão corretas.",
        "PROVIDER_TIMEOUT": "Aumente o valor de timeout na configuração ou verifique sua conexão.",
        "PROVIDER_QUOTA_EXCEEDED": "Aguarde a renovação da cota ou use um provedor alternativo.",
        "FILE_NOT_FOUND": "Verifique se o arquivo existe e se o caminho está correto.",
        "INVALID_FILE_FORMAT": "Certifique-se de que o arquivo está no formato correto.",
        "COBOL_PARSING_ERROR": "Verifique se o código COBOL está sintaticamente correto.",
        "PDF_CONVERSION_ERROR": "Verifique se o WeasyPrint está instalado corretamente.",
        "TOKEN_LIMIT_EXCEEDED": "Reduza o tamanho do arquivo de entrada ou aumente o limite de tokens."
    }
    
    return solutions.get(exception.error_code)

