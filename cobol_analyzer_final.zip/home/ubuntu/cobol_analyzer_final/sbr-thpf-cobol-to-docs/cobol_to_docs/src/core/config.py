"""
COBOL AI Engine v3.0.0 - Configuration Manager
Gerenciador de configuração para o COBOL AI Engine
"""

import os
import yaml
import logging
from typing import Dict, Any, Optional, List

class ConfigManager:
    """Gerencia as configurações do aplicativo."""

    def __init__(self, config_path: str = 'config.yaml', prompts_path: str = 'prompts.yaml'):
        self.logger = logging.getLogger(__name__)
        self.config = self._load_config(config_path)
        self.prompts = self._load_config(prompts_path) or {}
        self.logger.info(f"Configuração carregada de: {config_path}")
        if not self.prompts:
            self.logger.warning(f"Arquivo de prompts não encontrado: {prompts_path}")

    def _load_config(self, file_path: str) -> Optional[Dict[str, Any]]:
        """Carrega um arquivo de configuração YAML."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            return None
        except Exception as e:
            self.logger.error(f"Erro ao carregar {file_path}: {e}")
            return None

    def get(self, key: str, default: Any = None) -> Any:
        """Recupera um valor de configuração usando notação de ponto."""
        keys = key.split('.')
        value = self.config
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        return value

    def get_provider_for_model(self, model_name: str) -> Optional[str]:
        """Encontra o provedor para um determinado nome de modelo."""
        providers = self.get('providers', {})
        for provider, details in providers.items():
            if 'models' in details and isinstance(details['models'], dict):
                for model_key, model_info in details['models'].items():
                    if isinstance(model_info, dict) and model_info.get('name') == model_name:
                        return provider
        return None

