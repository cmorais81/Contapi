"""
Templates para geração de documentação
"""
