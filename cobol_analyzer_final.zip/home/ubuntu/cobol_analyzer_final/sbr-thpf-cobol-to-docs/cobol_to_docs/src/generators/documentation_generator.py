"""
COBOL AI Engine v3.0.0 - Documentation Generator
Gerador de documentação aprimorado com suporte a múltiplos formatos e templates.
"""

import os
import logging
from typing import Dict, Any

class DocumentationGenerator:
    """Gera documentação para programas COBOL analisados."""

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def generate_program_documentation(self, program, analysis_result, output_dir):
        """Gera a documentação para um único programa."""
        os.makedirs(output_dir, exist_ok=True)
        
        # Salvar a resposta completa da IA
        self._save_ia_response(program.name, analysis_result, output_dir)
        
        # Salvar os prompts utilizados
        self._save_prompts(program.name, analysis_result, output_dir)

    def _save_ia_response(self, program_name, analysis_result, output_dir):
        """Salva a resposta completa da IA em um arquivo de texto."""
        response_dir = os.path.join(output_dir, "responses")
        os.makedirs(response_dir, exist_ok=True)
        file_path = os.path.join(response_dir, f"{program_name}_response.txt")
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(analysis_result.content)
            self.logger.info(f"Resposta da IA para {program_name} salva em: {file_path}")
        except Exception as e:
            self.logger.error(f"Erro ao salvar resposta da IA para {program_name}: {e}")

    def _save_prompts(self, program_name, analysis_result, output_dir):
        """Salva os prompts utilizados em arquivos de texto."""
        prompts_dir = os.path.join(output_dir, "requests")
        os.makedirs(prompts_dir, exist_ok=True)
        
        prompts_used = analysis_result.metadata.get('prompts_used', {})
        
        for key, prompt_content in prompts_used.items():
            file_path = os.path.join(prompts_dir, f"{program_name}_{key}.txt")
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(str(prompt_content))
                self.logger.info(f"Prompt '{key}' para {program_name} salvo em: {file_path}")
            except Exception as e:
                self.logger.error(f"Erro ao salvar prompt '{key}' para {program_name}: {e}")
