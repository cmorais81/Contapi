#!/usr/bin/env python3
"""
COBOL RAG System - Sistema de Recuperação e Geração Aumentada para COBOL
Implementa técnicas avançadas de RAG para enriquecer análises de código COBOL
"""

import os
import json
import logging
import hashlib
import pickle
import time
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import numpy as np
from dataclasses import dataclass
import re
from .auto_learning_enhancement import AutoLearningEnhancement
from .rag_logger import RAGTransparentLogger

@dataclass
class CobolKnowledgeItem:
    """Item de conhecimento COBOL para a base de dados RAG"""
    id: str
    title: str
    content: str
    category: str  # 'pattern', 'best_practice', 'banking_rule', 'technical_doc'
    keywords: List[str]
    cobol_constructs: List[str]  # PERFORM, IF, EVALUATE, etc.
    domain: str  # 'banking', 'insurance', 'general'
    complexity_level: str  # 'basic', 'intermediate', 'advanced'
    embedding: Optional[np.ndarray] = None
    created_at: datetime = None

class CobolRAGSystem:
    """
    Sistema RAG avançado para análise de código COBOL.
    Implementa recuperação semântica e enriquecimento de contexto.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o sistema RAG COBOL.
        
        Args:
            config: Configuração do sistema
        """
        self.logger = logging.getLogger(__name__)
        self.config = config
        
        # Inicializar sistema de logging transparente
        log_dir = config.get('rag', {}).get('log_dir', 'logs')
        enable_console_rag_logs = config.get('rag', {}).get('enable_console_logs', True)
        self.rag_logger = RAGTransparentLogger(log_dir, enable_console_rag_logs)
        
        # Configurações RAG
        self.knowledge_base_path = config.get('rag', {}).get('knowledge_base_path', 'data/cobol_knowledge_base_consolidated.json')
        self.embeddings_path = config.get('rag', {}).get('embeddings_path', 'data/cobol_embeddings.pkl')
        self.max_context_items = config.get('rag', {}).get('max_context_items', 5)
        self.similarity_threshold = config.get('rag', {}).get('similarity_threshold', 0.7)
        
        # Base de conhecimento
        self.knowledge_base: List[CobolKnowledgeItem] = []
        self.embeddings_cache: Dict[str, np.ndarray] = {}
        
        # Configuração de auto-learning
        self.auto_learn_enabled = config.get('rag', {}).get('auto_learn', True)
        
        # Inicializar sistema
        self._initialize_knowledge_base()
        self._load_embeddings_cache()
        
        # Inicializar auto-learning
        self.auto_learning = AutoLearningEnhancement(self)
        
        # Inicializar sistema de aprendizado inteligente
        from .intelligent_learning_system import IntelligentLearningSystem
        self.learning_system = IntelligentLearningSystem(self.knowledge_base_path)
        
        self.logger.info("COBOL RAG System inicializado com auto-learning e sistema inteligente")
    
    def _initialize_knowledge_base(self):
        """Inicializa a base de conhecimento COBOL com padrões e melhores práticas."""
        
        # Carregar base existente se disponível
        if os.path.exists(self.knowledge_base_path):
            try:
                with open(self.knowledge_base_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for item_data in data:
                        item = CobolKnowledgeItem(**item_data)
                        self.knowledge_base.append(item)
                self.logger.info(f"Base de conhecimento carregada: {len(self.knowledge_base)} itens")
                return
            except Exception as e:
                self.logger.warning(f"Erro ao carregar base existente: {e}")
        
        # Criar base inicial se não existir
        self._create_initial_knowledge_base()
        self._save_knowledge_base()
    
    def _create_initial_knowledge_base(self):
        """Cria base de conhecimento inicial com padrões COBOL essenciais."""
        
        initial_knowledge = [
            # Padrões de Estrutura
            {
                "title": "Padrão de Inicialização de Programa COBOL",
                "content": """
                Padrão padrão para inicialização de programas COBOL:
                1. PERFORM INICIALIZAR - Configuração inicial, abertura de arquivos
                2. PERFORM PROCESSAR - Loop principal de processamento
                3. PERFORM FINALIZAR - Fechamento de arquivos, relatórios finais
                
                Exemplo:
                MAIN-PROCEDURE.
                    PERFORM INICIALIZAR
                    PERFORM PROCESSAR
                    PERFORM FINALIZAR
                    STOP RUN.
                """,
                "category": "pattern",
                "keywords": ["inicialização", "main-procedure", "perform", "estrutura"],
                "cobol_constructs": ["PERFORM", "STOP RUN"],
                "domain": "general",
                "complexity_level": "basic"
            },
            
            # Padrões de Loop
            {
                "title": "Padrão de Loop com Controle de Arquivo",
                "content": """
                Padrão para processamento sequencial de arquivos:
                
                PROCESSAR.
                    READ ARQUIVO-ENTRADA
                    PERFORM UNTIL WS-EOF = 'S'
                        PERFORM PROCESSAR-REGISTRO
                        READ ARQUIVO-ENTRADA
                    END-PERFORM.
                
                Sempre verificar status do arquivo após READ e tratar fim de arquivo adequadamente.
                """,
                "category": "pattern",
                "keywords": ["loop", "arquivo", "read", "until", "eof"],
                "cobol_constructs": ["READ", "PERFORM UNTIL", "END-PERFORM"],
                "domain": "general",
                "complexity_level": "intermediate"
            },
            
            # Regras Bancárias
            {
                "title": "Validação de Conta Bancária",
                "content": """
                Padrão para validação de contas bancárias:
                1. Verificar se conta não está em branco
                2. Validar dígito verificador
                3. Verificar se conta existe na base
                4. Validar status da conta (ativa/inativa)
                
                Códigos de retorno padrão:
                '00' - Conta válida
                '01' - Conta inválida
                '02' - Conta inexistente
                '03' - Conta inativa
                """,
                "category": "banking_rule",
                "keywords": ["conta", "validação", "bancário", "dígito verificador"],
                "cobol_constructs": ["IF", "EVALUATE"],
                "domain": "banking",
                "complexity_level": "intermediate"
            },
            
            # Melhores Práticas
            {
                "title": "Tratamento de Erro em Operações de Arquivo",
                "content": """
                Sempre verificar FILE-STATUS após operações de arquivo:
                
                OPEN INPUT ARQUIVO-ENTRADA
                IF FILE-STATUS NOT = '00'
                    DISPLAY 'ERRO NA ABERTURA: ' FILE-STATUS
                    PERFORM ERRO-FATAL
                END-IF
                
                Códigos importantes:
                '00' - Sucesso
                '10' - Fim de arquivo
                '23' - Arquivo não encontrado
                '30' - Erro permanente
                """,
                "category": "best_practice",
                "keywords": ["file-status", "erro", "arquivo", "tratamento"],
                "cobol_constructs": ["OPEN", "FILE-STATUS", "IF"],
                "domain": "general",
                "complexity_level": "basic"
            },
            
            # Padrões de Cálculo
            {
                "title": "Cálculo de Juros Compostos",
                "content": """
                Padrão para cálculo de juros compostos em sistemas bancários:
                
                COMPUTE WS-VALOR-FINAL = WS-CAPITAL * 
                    ((1 + WS-TAXA-JUROS) ** WS-PERIODO)
                
                Validações necessárias:
                - Taxa de juros > 0
                - Período > 0
                - Capital > 0
                - Verificar overflow em cálculos
                """,
                "category": "banking_rule",
                "keywords": ["juros", "cálculo", "financeiro", "compute"],
                "cobol_constructs": ["COMPUTE", "**"],
                "domain": "banking",
                "complexity_level": "advanced"
            }
        ]
        
        # Converter para objetos CobolKnowledgeItem
        for i, item in enumerate(initial_knowledge):
            knowledge_item = CobolKnowledgeItem(
                id=f"kb_{i:04d}",
                title=item["title"],
                content=item["content"],
                category=item["category"],
                keywords=item["keywords"],
                cobol_constructs=item["cobol_constructs"],
                domain=item["domain"],
                complexity_level=item["complexity_level"],
                created_at=datetime.now()
            )
            self.knowledge_base.append(knowledge_item)
        
        self.logger.info(f"Base de conhecimento inicial criada com {len(self.knowledge_base)} itens")
    
    def _save_knowledge_base(self):
        """Salva a base de conhecimento em arquivo JSON."""
        try:
            os.makedirs(os.path.dirname(self.knowledge_base_path), exist_ok=True)
            
            # Converter para formato serializável
            data = []
            for item in self.knowledge_base:
                # Tratar created_at que pode ser string ou datetime
                created_at_str = None
                if item.created_at:
                    if hasattr(item.created_at, 'isoformat'):
                        created_at_str = item.created_at.isoformat()
                    else:
                        created_at_str = str(item.created_at)
                
                item_dict = {
                    'id': item.id,
                    'title': item.title,
                    'content': item.content,
                    'category': item.category,
                    'keywords': item.keywords,
                    'cobol_constructs': item.cobol_constructs,
                    'domain': item.domain,
                    'complexity_level': item.complexity_level,
                    'created_at': created_at_str
                }
                data.append(item_dict)
            
            with open(self.knowledge_base_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Base de conhecimento salva: {len(data)} itens")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar base de conhecimento: {e}")
    
    def _load_embeddings_cache(self):
        """Carrega cache de embeddings se disponível."""
        if os.path.exists(self.embeddings_path):
            try:
                with open(self.embeddings_path, 'rb') as f:
                    self.embeddings_cache = pickle.load(f)
                self.logger.info(f"Cache de embeddings carregado: {len(self.embeddings_cache)} itens")
            except Exception as e:
                self.logger.warning(f"Erro ao carregar cache de embeddings: {e}")
                self.embeddings_cache = {}
    
    def _save_embeddings_cache(self):
        """Salva cache de embeddings."""
        try:
            os.makedirs(os.path.dirname(self.embeddings_path), exist_ok=True)
            with open(self.embeddings_path, 'wb') as f:
                pickle.dump(self.embeddings_cache, f)
            self.logger.info(f"Cache de embeddings salvo: {len(self.embeddings_cache)} itens")
        except Exception as e:
            self.logger.error(f"Erro ao salvar cache de embeddings: {e}")
    
    def _create_simple_embedding(self, text: str) -> np.ndarray:
        """
        Cria embedding simples baseado em TF-IDF e características COBOL.
        Em produção, usar modelos como sentence-transformers.
        """
        # Normalizar texto
        text = text.lower()
        
        # Palavras-chave COBOL importantes
        cobol_keywords = [
            'perform', 'if', 'else', 'evaluate', 'when', 'read', 'write', 'open', 'close',
            'compute', 'move', 'add', 'subtract', 'multiply', 'divide', 'display',
            'working-storage', 'procedure', 'division', 'section', 'paragraph',
            'file-status', 'pic', 'value', 'occurs', 'redefines', 'copy', 'call'
        ]
        
        # Termos bancários importantes
        banking_terms = [
            'conta', 'cliente', 'saldo', 'juros', 'taxa', 'transação', 'débito', 'crédito',
            'validação', 'autorização', 'limite', 'bloqueio', 'movimentação'
        ]
        
        # Criar vetor de características
        features = []
        
        # Características COBOL (presença de palavras-chave)
        for keyword in cobol_keywords:
            features.append(1.0 if keyword in text else 0.0)
        
        # Características bancárias
        for term in banking_terms:
            features.append(1.0 if term in text else 0.0)
        
        # Características estruturais
        features.append(len(re.findall(r'\bperform\b', text)))  # Número de PERFORMs
        features.append(len(re.findall(r'\bif\b', text)))       # Número de IFs
        features.append(len(re.findall(r'\bread\b', text)))     # Número de READs
        features.append(len(text.split()))                      # Número de palavras
        
        return np.array(features, dtype=np.float32)
    
    def _calculate_similarity(self, embedding1: np.ndarray, embedding2: np.ndarray) -> float:
        """Calcula similaridade cosseno entre dois embeddings."""
        try:
            # Normalizar vetores
            norm1 = np.linalg.norm(embedding1)
            norm2 = np.linalg.norm(embedding2)
            
            if norm1 == 0 or norm2 == 0:
                return 0.0
            
            # Similaridade cosseno
            similarity = np.dot(embedding1, embedding2) / (norm1 * norm2)
            return float(similarity)
            
        except Exception as e:
            self.logger.warning(f"Erro ao calcular similaridade: {e}")
            return 0.0
    
    def retrieve_relevant_knowledge(self, query: str, cobol_code: str = "", 
                                  max_items: int = None, program_name: str = "unknown") -> List[Tuple[CobolKnowledgeItem, float]]:
        """
        Recupera conhecimento relevante da base usando busca semântica.
        
        Args:
            query: Consulta/contexto para busca
            cobol_code: Código COBOL para análise adicional
            max_items: Número máximo de itens a retornar
            program_name: Nome do programa para logging
            
        Returns:
            Lista de tuplas (item_conhecimento, score_similaridade)
        """
        start_time = time.time()
        
        if not self.knowledge_base:
            self.rag_logger.log_error("retrieve_relevant_knowledge", program_name, 
                                    "Base de conhecimento vazia")
            return []
        
        max_items = max_items or self.max_context_items
        
        # Combinar query e código para busca
        search_text = f"{query} {cobol_code}"
        
        # Gerar embedding da consulta
        query_hash = hashlib.md5(search_text.encode()).hexdigest()
        
        if query_hash not in self.embeddings_cache:
            query_embedding = self._create_simple_embedding(search_text)
            self.embeddings_cache[query_hash] = query_embedding
        else:
            query_embedding = self.embeddings_cache[query_hash]
        
        # Calcular similaridades
        similarities = []
        
        for item in self.knowledge_base:
            # Gerar embedding do item se não existir
            item_hash = hashlib.md5(f"{item.title} {item.content}".encode()).hexdigest()
            
            if item_hash not in self.embeddings_cache:
                item_embedding = self._create_simple_embedding(f"{item.title} {item.content}")
                self.embeddings_cache[item_hash] = item_embedding
            else:
                item_embedding = self.embeddings_cache[item_hash]
            
            # Calcular similaridade
            similarity = self._calculate_similarity(query_embedding, item_embedding)
            
            if similarity >= self.similarity_threshold:
                similarities.append((item, similarity))
        
        # Ordenar por similaridade e retornar top items
        similarities.sort(key=lambda x: x[1], reverse=True)
        
        # Salvar cache atualizado
        self._save_embeddings_cache()
        
        # Preparar resultado final
        result = similarities[:max_items]
        
        # Calcular tempo de execução
        execution_time_ms = (time.time() - start_time) * 1000
        
        # Extrair dados para logging
        knowledge_items = [item for item, _ in result]
        similarity_scores = [score for _, score in result]
        
        # Log da operação
        self.rag_logger.log_knowledge_retrieval(
            program_name=program_name,
            query=query,
            knowledge_items=knowledge_items,
            similarity_scores=similarity_scores,
            execution_time_ms=execution_time_ms
        )
        
        return result
    
    def enhance_analysis_context(self, program_name: str, cobol_code: str, 
                               analysis_type: str = "general") -> Dict[str, Any]:
        """
        Enriquece o contexto de análise com conhecimento relevante da base RAG.
        
        Args:
            program_name: Nome do programa COBOL
            cobol_code: Código COBOL a ser analisado
            analysis_type: Tipo de análise ('general', 'banking', 'modernization')
            
        Returns:
            Contexto enriquecido com conhecimento relevante
        """
        # Extrair características do código
        code_features = self._extract_code_features(cobol_code)
        
        # Criar query baseada nas características
        query_parts = [
            f"Análise de programa COBOL {program_name}",
            f"Tipo de análise: {analysis_type}"
        ]
        
        # Adicionar características específicas
        if code_features['has_file_operations']:
            query_parts.append("operações de arquivo")
        if code_features['has_calculations']:
            query_parts.append("cálculos matemáticos")
        if code_features['banking_indicators']:
            query_parts.append("sistema bancário")
        
        query = " ".join(query_parts)
        
        # Recuperar conhecimento relevante
        relevant_knowledge = self.retrieve_relevant_knowledge(query, cobol_code, program_name=program_name)
        
        # Construir contexto enriquecido
        enhanced_context = {
            'program_name': program_name,
            'analysis_type': analysis_type,
            'code_features': code_features,
            'relevant_patterns': [],
            'best_practices': [],
            'banking_rules': [],
            'technical_guidance': [],
            'total_knowledge_items': len(relevant_knowledge)
        }
        
        # Categorizar conhecimento recuperado
        for item, score in relevant_knowledge:
            knowledge_entry = {
                'title': item.title,
                'content': item.content,
                'similarity_score': score,
                'complexity_level': item.complexity_level,
                'domain': item.domain
            }
            
            if item.category == 'pattern':
                enhanced_context['relevant_patterns'].append(knowledge_entry)
            elif item.category == 'best_practice':
                enhanced_context['best_practices'].append(knowledge_entry)
            elif item.category == 'banking_rule':
                enhanced_context['banking_rules'].append(knowledge_entry)
            elif item.category == 'technical_doc':
                enhanced_context['technical_guidance'].append(knowledge_entry)
        
        self.logger.info(f"Contexto enriquecido para {program_name}: {len(relevant_knowledge)} itens de conhecimento")
        
        # Log do enriquecimento de contexto
        base_context_size = len(f"{program_name} {analysis_type}")
        enhanced_context_str = json.dumps(enhanced_context, ensure_ascii=False)
        enhanced_context_size = len(enhanced_context_str)
        
        self.rag_logger.log_context_enhancement(
            program_name=program_name,
            base_context_size=base_context_size,
            enhanced_context_size=enhanced_context_size,
            knowledge_items_used=len(relevant_knowledge)
        )
        
        return enhanced_context
    
    def _extract_code_features(self, cobol_code: str) -> Dict[str, Any]:
        """Extrai características do código COBOL para melhorar a busca RAG."""
        code = cobol_code.lower()
        
        features = {
            'has_file_operations': bool(re.search(r'\b(open|close|read|write|rewrite)\b', code)),
            'has_calculations': bool(re.search(r'\b(compute|add|subtract|multiply|divide)\b', code)),
            'has_loops': bool(re.search(r'\bperform\s+.*\s+until\b', code)),
            'has_conditionals': bool(re.search(r'\b(if|evaluate|when)\b', code)),
            'banking_indicators': bool(re.search(r'\b(conta|cliente|saldo|juros|taxa)\b', code)),
            'copybooks': re.findall(r'\bcopy\s+(\w+)', code),
            'paragraphs': re.findall(r'^(\w+(?:-\w+)*)\s*\.$', code, re.MULTILINE),
            'file_status_checks': bool(re.search(r'\bfile-status\b', code)),
            'error_handling': bool(re.search(r'\b(error|erro|exception)\b', code))
        }
        
        return features
    
    def generate_rag_enhanced_prompt(self, base_prompt: str, enhanced_context: Dict[str, Any]) -> str:
        """
        Gera prompt enriquecido com conhecimento RAG.
        
        Args:
            base_prompt: Prompt base original
            enhanced_context: Contexto enriquecido pelo RAG
            
        Returns:
            Prompt enriquecido com conhecimento relevante
        """
        program_name = enhanced_context.get('program_name', 'unknown')
        rag_sections = []
        
        # Adicionar padrões relevantes
        if enhanced_context['relevant_patterns']:
            rag_sections.append("## PADRÕES COBOL RELEVANTES IDENTIFICADOS:")
            for pattern in enhanced_context['relevant_patterns'][:3]:  # Top 3
                rag_sections.append(f"### {pattern['title']}")
                rag_sections.append(pattern['content'])
                rag_sections.append(f"*Similaridade: {pattern['similarity_score']:.2f}*")
                rag_sections.append("")
        
        # Adicionar melhores práticas
        if enhanced_context['best_practices']:
            rag_sections.append("## MELHORES PRÁTICAS APLICÁVEIS:")
            for practice in enhanced_context['best_practices'][:2]:  # Top 2
                rag_sections.append(f"### {practice['title']}")
                rag_sections.append(practice['content'])
                rag_sections.append("")
        
        # Adicionar regras bancárias se aplicável
        if enhanced_context['banking_rules']:
            rag_sections.append("## REGRAS BANCÁRIAS RELEVANTES:")
            for rule in enhanced_context['banking_rules'][:2]:  # Top 2
                rag_sections.append(f"### {rule['title']}")
                rag_sections.append(rule['content'])
                rag_sections.append("")
        
        # Construir prompt final
        if rag_sections:
            rag_content = "\n".join(rag_sections)
            
            # Substituir placeholder {rag_context} se existir
            if "{rag_context}" in base_prompt:
                enhanced_prompt = base_prompt.replace("{rag_context}", rag_content)
            else:
                # Se não há placeholder, adicionar no final
                enhanced_prompt = f"""
{base_prompt}

## CONHECIMENTO CONTEXTUAL RELEVANTE (RAG):

{rag_content}

**INSTRUÇÕES IMPORTANTES:**
- Use o conhecimento contextual acima para enriquecer sua análise
- Identifique padrões conhecidos no código analisado
- Aplique as melhores práticas mencionadas em suas recomendações
- Referencie regras bancárias quando aplicável
- Seja específico sobre como o conhecimento contextual se aplica ao código

---
"""
            
            # Log do enriquecimento de prompt
            rag_sections_added = []
            if enhanced_context['relevant_patterns']:
                rag_sections_added.append("Padrões COBOL")
            if enhanced_context['best_practices']:
                rag_sections_added.append("Melhores Práticas")
            if enhanced_context['banking_rules']:
                rag_sections_added.append("Regras Bancárias")
            
            self.rag_logger.log_prompt_enhancement(
                program_name=program_name,
                base_prompt_size=len(base_prompt),
                enhanced_prompt_size=len(enhanced_prompt),
                rag_sections_added=rag_sections_added
            )
            
            return enhanced_prompt
        
        return base_prompt
    
    def add_knowledge_item(self, title: str, content: str, category: str,
                          keywords: List[str], cobol_constructs: List[str],
                          domain: str = "general", complexity_level: str = "intermediate") -> str:
        """
        Adiciona novo item de conhecimento à base RAG.
        
        Returns:
            ID do item adicionado
        """
        item_id = f"kb_{len(self.knowledge_base):04d}"
        
        new_item = CobolKnowledgeItem(
            id=item_id,
            title=title,
            content=content,
            category=category,
            keywords=keywords,
            cobol_constructs=cobol_constructs,
            domain=domain,
            complexity_level=complexity_level,
            created_at=datetime.now()
        )
        
        self.knowledge_base.append(new_item)
        self._save_knowledge_base()
        
        self.logger.info(f"Novo item de conhecimento adicionado: {item_id}")
        return item_id
    
    def get_knowledge_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas da base de conhecimento."""
        if not self.knowledge_base:
            return {}
        
        categories = {}
        domains = {}
        complexity_levels = {}
        
        for item in self.knowledge_base:
            categories[item.category] = categories.get(item.category, 0) + 1
            domains[item.domain] = domains.get(item.domain, 0) + 1
            complexity_levels[item.complexity_level] = complexity_levels.get(item.complexity_level, 0) + 1
        
        return {
            'total_items': len(self.knowledge_base),
            'categories': categories,
            'domains': domains,
            'complexity_levels': complexity_levels,
            'embeddings_cached': len(self.embeddings_cache)
        }

    def learn_from_analysis(self, analysis_result: str, program_name: str, 
                           cobol_code: str) -> bool:
        """
        Aprende automaticamente com a análise e enriquece a base RAG.
        
        Args:
            analysis_result: Resultado da análise do programa
            program_name: Nome do programa analisado
            cobol_code: Código COBOL do programa
            
        Returns:
            bool: True se novo conhecimento foi adicionado
        """
        
        if not self.auto_learn_enabled:
            return False
        
        try:
            # Extrai conhecimento da análise
            extracted_knowledge = self.learning_system.extract_knowledge_from_analysis(
                analysis_result, program_name, cobol_code
            )
            
            # Adiciona conhecimento à base
            knowledge_added = self.learning_system.add_learned_knowledge_to_base(
                extracted_knowledge
            )
            
            if knowledge_added:
                # Recarrega base de conhecimento
                self._initialize_knowledge_base()
                # Limpa cache de embeddings para forçar recriação
                self.embeddings_cache.clear()
                
                self.logger.info(f"Base RAG enriquecida com conhecimento do programa {program_name}")
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Erro no aprendizado automático: {e}")
            return False
    
    def get_learning_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do sistema de aprendizado"""
        
        base_stats = self.get_knowledge_base_stats()
        learning_stats = self.learning_system.get_learning_statistics()
        
        return {
            **base_stats,
            **learning_stats,
            "auto_learning_enabled": self.auto_learn_enabled
        }

    def finalize_rag_session(self) -> str:
        """
        Finaliza a sessão RAG e gera relatório completo.
        
        Returns:
            Caminho do arquivo de relatório gerado
        """
        try:
            report_path = self.rag_logger.close_session()
            self.logger.info(f"Sessão RAG finalizada. Relatório disponível em: {report_path}")
            return report_path
        except Exception as e:
            self.logger.error(f"Erro ao finalizar sessão RAG: {e}")
            return ""
    
    def get_rag_session_summary(self) -> Dict[str, Any]:
        """
        Retorna resumo da sessão RAG atual.
        
        Returns:
            Dicionário com estatísticas da sessão
        """
        try:
            summary = self.rag_logger.generate_session_summary()
            return {
                'session_id': summary.session_id,
                'total_operations': summary.total_operations,
                'knowledge_items_used': summary.total_knowledge_items_used,
                'programs_analyzed': summary.programs_analyzed,
                'categories_distribution': summary.categories_distribution,
                'domains_distribution': summary.domains_distribution,
                'average_similarity_score': summary.average_similarity_score,
                'total_execution_time_ms': summary.total_execution_time_ms
            }
        except Exception as e:
            self.logger.error(f"Erro ao gerar resumo da sessão RAG: {e}")
            return {}
