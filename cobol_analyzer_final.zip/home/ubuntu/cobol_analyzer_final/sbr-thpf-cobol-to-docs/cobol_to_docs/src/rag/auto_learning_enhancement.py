"""
Implementação de auto-learning para enriquecimento automático da base de conhecimento RAG.
"""

import re
import json
from datetime import datetime
from typing import Dict, Any, List
import logging

class AutoLearningEnhancement:
    """Sistema de aprendizado automático para base de conhecimento RAG."""
    
    def __init__(self, rag_system):
        self.rag_system = rag_system
        self.logger = logging.getLogger(__name__)
    
    def add_program_analysis_to_knowledge_base(self, program_name: str, analysis_result: str, 
                                             cobol_code: str, model_used: str = "unknown") -> bool:
        """
        Adiciona análise bem-sucedida à base de conhecimento automaticamente.
        
        Args:
            program_name: Nome do programa COBOL analisado
            analysis_result: Resultado da análise gerada pela IA
            cobol_code: Código COBOL original
            model_used: Modelo de IA utilizado
            
        Returns:
            True se adicionado com sucesso, False caso contrário
        """
        try:
            # Extrair insights valiosos da análise
            insights = self._extract_insights_from_analysis(analysis_result, cobol_code)
            
            if not insights:
                self.logger.info(f"Nenhum insight valioso encontrado na análise de {program_name}")
                return False
            
            # Adicionar cada insight como item de conhecimento
            items_added = 0
            for insight in insights:
                if self._is_valuable_insight(insight):
                    item_id = self._add_insight_to_knowledge_base(insight, program_name, model_used)
                    if item_id:
                        items_added += 1
            
            if items_added > 0:
                self.logger.info(f"Auto-learning: {items_added} novos itens adicionados da análise de {program_name}")
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Erro no auto-learning para {program_name}: {str(e)}")
            return False
    
    def _extract_insights_from_analysis(self, analysis_result: str, cobol_code: str) -> List[Dict[str, Any]]:
        """Extrai insights valiosos da análise gerada pela IA."""
        insights = []
        
        # 1. Extrair padrões identificados
        patterns = self._extract_patterns(analysis_result, cobol_code)
        insights.extend(patterns)
        
        # 2. Extrair regras de negócio
        business_rules = self._extract_business_rules(analysis_result, cobol_code)
        insights.extend(business_rules)
        
        # 3. Extrair técnicas de otimização
        optimizations = self._extract_optimizations(analysis_result, cobol_code)
        insights.extend(optimizations)
        
        # 4. Extrair tratamentos de erro
        error_handling = self._extract_error_handling(analysis_result, cobol_code)
        insights.extend(error_handling)
        
        return insights
    
    def _extract_patterns(self, analysis: str, code: str) -> List[Dict[str, Any]]:
        """Extrai padrões de código identificados na análise."""
        patterns = []
        
        # Buscar menções a padrões na análise
        pattern_indicators = [
            r"padrão\s+(\w+(?:\s+\w+)*)",
            r"estrutura\s+(\w+(?:\s+\w+)*)",
            r"organização\s+(\w+(?:\s+\w+)*)",
            r"metodologia\s+(\w+(?:\s+\w+)*)"
        ]
        
        for indicator in pattern_indicators:
            matches = re.finditer(indicator, analysis.lower())
            for match in matches:
                pattern_name = match.group(1).title()
                
                # Extrair contexto ao redor da menção
                start = max(0, match.start() - 200)
                end = min(len(analysis), match.end() + 200)
                context = analysis[start:end]
                
                # Identificar constructs COBOL relacionados
                cobol_constructs = self._identify_cobol_constructs(code)
                
                pattern = {
                    'type': 'pattern',
                    'title': f"Padrão {pattern_name} Identificado",
                    'content': context,
                    'cobol_constructs': cobol_constructs,
                    'source': 'auto_learning',
                    'confidence': self._calculate_confidence(context, code)
                }
                
                patterns.append(pattern)
        
        return patterns
    
    def _extract_business_rules(self, analysis: str, code: str) -> List[Dict[str, Any]]:
        """Extrai regras de negócio identificadas na análise."""
        rules = []
        
        # Indicadores de regras de negócio
        business_indicators = [
            r"regra\s+de\s+negócio",
            r"validação\s+(\w+(?:\s+\w+)*)",
            r"cálculo\s+(\w+(?:\s+\w+)*)",
            r"processamento\s+(\w+(?:\s+\w+)*)",
            r"controle\s+(\w+(?:\s+\w+)*)"
        ]
        
        # Buscar indicadores bancários específicos
        banking_terms = ["conta", "cliente", "saldo", "juros", "taxa", "cpf", "cnpj", "agência"]
        
        for term in banking_terms:
            if term in analysis.lower() and term in code.lower():
                # Extrair contexto da regra
                pattern = rf"\b{term}\b.*?[.!?]"
                matches = re.finditer(pattern, analysis.lower())
                
                for match in matches:
                    rule_context = match.group(0)
                    
                    rule = {
                        'type': 'banking_rule',
                        'title': f"Regra de {term.title()} Identificada",
                        'content': rule_context,
                        'domain': 'banking',
                        'source': 'auto_learning',
                        'confidence': self._calculate_confidence(rule_context, code)
                    }
                    
                    rules.append(rule)
        
        return rules
    
    def _extract_optimizations(self, analysis: str, code: str) -> List[Dict[str, Any]]:
        """Extrai técnicas de otimização mencionadas na análise."""
        optimizations = []
        
        optimization_keywords = [
            "otimização", "performance", "eficiência", "melhoria",
            "índice", "commit", "batch", "array", "cursor"
        ]
        
        for keyword in optimization_keywords:
            if keyword in analysis.lower():
                # Buscar contexto da otimização
                pattern = rf"\b{keyword}\b.*?[.!?]"
                matches = re.finditer(pattern, analysis.lower())
                
                for match in matches:
                    opt_context = match.group(0)
                    
                    optimization = {
                        'type': 'best_practice',
                        'title': f"Otimização de {keyword.title()} Identificada",
                        'content': opt_context,
                        'category': 'performance',
                        'source': 'auto_learning',
                        'confidence': self._calculate_confidence(opt_context, code)
                    }
                    
                    optimizations.append(optimization)
        
        return optimizations
    
    def _extract_error_handling(self, analysis: str, code: str) -> List[Dict[str, Any]]:
        """Extrai padrões de tratamento de erro identificados."""
        error_patterns = []
        
        # Buscar menções a tratamento de erro
        error_keywords = ["erro", "exception", "file-status", "sqlcode", "tratamento"]
        
        for keyword in error_keywords:
            if keyword in analysis.lower() and keyword in code.lower():
                # Extrair contexto do tratamento
                pattern = rf"\b{keyword}\b.*?[.!?]"
                matches = re.finditer(pattern, analysis.lower())
                
                for match in matches:
                    error_context = match.group(0)
                    
                    error_pattern = {
                        'type': 'best_practice',
                        'title': f"Tratamento de {keyword.title()} Identificado",
                        'content': error_context,
                        'category': 'error_handling',
                        'source': 'auto_learning',
                        'confidence': self._calculate_confidence(error_context, code)
                    }
                    
                    error_patterns.append(error_pattern)
        
        return error_patterns
    
    def _identify_cobol_constructs(self, code: str) -> List[str]:
        """Identifica constructs COBOL presentes no código."""
        constructs = []
        
        cobol_keywords = [
            "PERFORM", "IF", "EVALUATE", "READ", "WRITE", "OPEN", "CLOSE",
            "COMPUTE", "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "MOVE",
            "STRING", "UNSTRING", "INSPECT", "CALL", "EXEC SQL"
        ]
        
        code_upper = code.upper()
        for keyword in cobol_keywords:
            if keyword in code_upper:
                constructs.append(keyword)
        
        return constructs
    
    def _calculate_confidence(self, context: str, code: str) -> float:
        """Calcula nível de confiança do insight baseado no contexto."""
        confidence = 0.5  # Base
        
        # Aumentar confiança baseado em fatores
        if len(context) > 100:  # Contexto detalhado
            confidence += 0.1
        
        if any(term in context.lower() for term in ["exemplo", "implementação", "código"]):
            confidence += 0.1
        
        if any(term in code.lower() for term in ["perform", "if", "read", "write"]):
            confidence += 0.1
        
        # Reduzir confiança se muito genérico
        if len(context) < 50:
            confidence -= 0.2
        
        return min(1.0, max(0.1, confidence))
    
    def _is_valuable_insight(self, insight: Dict[str, Any]) -> bool:
        """Determina se um insight é valioso o suficiente para ser adicionado."""
        # Critérios de valor
        min_confidence = 0.6
        min_content_length = 50
        
        if insight.get('confidence', 0) < min_confidence:
            return False
        
        if len(insight.get('content', '')) < min_content_length:
            return False
        
        # Evitar duplicatas óbvias
        if self._is_duplicate_insight(insight):
            return False
        
        return True
    
    def _is_duplicate_insight(self, insight: Dict[str, Any]) -> bool:
        """Verifica se o insight já existe na base de conhecimento."""
        title = insight.get('title', '').lower()
        
        for existing_item in self.rag_system.knowledge_base:
            if existing_item.title.lower() == title:
                return True
        
        return False
    
    def _add_insight_to_knowledge_base(self, insight: Dict[str, Any], 
                                     program_name: str, model_used: str) -> str:
        """Adiciona insight à base de conhecimento."""
        try:
            # Gerar ID único
            item_id = f"auto_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{len(self.rag_system.knowledge_base)}"
            
            # Preparar dados
            title = insight.get('title', f"Insight de {program_name}")
            content = f"""
            Insight extraído automaticamente da análise do programa {program_name}:
            
            {insight.get('content', '')}
            
            Fonte: Análise automática usando {model_used}
            Confiança: {insight.get('confidence', 0.5):.2f}
            Data: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            """
            
            category = insight.get('type', 'pattern')
            domain = insight.get('domain', 'general')
            
            # Extrair keywords do conteúdo
            keywords = self._extract_keywords(content)
            
            # Adicionar à base
            return self.rag_system.add_knowledge_item(
                title=title,
                content=content,
                category=category,
                keywords=keywords,
                cobol_constructs=insight.get('cobol_constructs', []),
                domain=domain,
                complexity_level='intermediate'
            )
            
        except Exception as e:
            self.logger.error(f"Erro ao adicionar insight à base: {str(e)}")
            return None
    
    def _extract_keywords(self, content: str) -> List[str]:
        """Extrai keywords relevantes do conteúdo."""
        # Palavras comuns a ignorar
        stop_words = {'de', 'da', 'do', 'para', 'com', 'em', 'na', 'no', 'a', 'o', 'e', 'ou'}
        
        # Extrair palavras significativas
        words = re.findall(r'\b\w{4,}\b', content.lower())
        keywords = [word for word in words if word not in stop_words]
        
        # Retornar top 10 mais frequentes
        from collections import Counter
        word_counts = Counter(keywords)
        return [word for word, count in word_counts.most_common(10)]
    
    def get_auto_learning_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas do auto-learning."""
        auto_items = [item for item in self.rag_system.knowledge_base 
                     if 'auto_learning' in getattr(item, 'content', '')]
        
        return {
            'total_auto_items': len(auto_items),
            'total_items': len(self.rag_system.knowledge_base),
            'auto_learning_percentage': len(auto_items) / len(self.rag_system.knowledge_base) * 100 if self.rag_system.knowledge_base else 0,
            'last_auto_addition': max([item.created_at for item in auto_items]) if auto_items else None
        }
