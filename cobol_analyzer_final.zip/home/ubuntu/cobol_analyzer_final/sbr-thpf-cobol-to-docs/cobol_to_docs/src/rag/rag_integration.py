#!/usr/bin/env python3
"""
RAG Integration - Integração do Sistema RAG com COBOL to Docs
Fornece interface simplificada para usar RAG em análises COBOL
"""

import logging
import os
from typing import Dict, Any, Optional
from .cobol_rag_system import CobolRAGSystem

class RAGIntegration:
    """
    Classe de integração que conecta o sistema RAG com o COBOL to Docs.
    Fornece interface simplificada para enriquecimento de análises.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa a integração RAG.
        
        Args:
            config: Configuração do sistema
        """
        self.logger = logging.getLogger(__name__)
        self.config = config
        
        # Verificar se RAG está habilitado
        self.rag_enabled = config.get('rag', {}).get('enabled', True)
        
        if self.rag_enabled:
            try:
                self.rag_system = CobolRAGSystem(config)
                self.logger.info("RAG Integration inicializada com sucesso")
            except Exception as e:
                self.logger.error(f"Erro ao inicializar RAG: {e}")
                self.rag_enabled = False
                self.rag_system = None
        else:
            self.rag_system = None
            self.logger.info("RAG desabilitado na configuração")
    
    def is_enabled(self) -> bool:
        """Verifica se o RAG está habilitado e funcionando."""
        return self.rag_enabled and self.rag_system is not None
    
    def enhance_analysis_prompt(self, program_name: str, cobol_code: str, 
                              base_prompt: str, analysis_type: str = "general") -> str:
        """
        Enriquece um prompt de análise com conhecimento RAG.
        
        Args:
            program_name: Nome do programa COBOL
            cobol_code: Código COBOL
            base_prompt: Prompt base original
            analysis_type: Tipo de análise
            
        Returns:
            Prompt enriquecido ou prompt original se RAG desabilitado
        """
        if not self.is_enabled():
            return base_prompt
        
        try:
            # Obter contexto enriquecido
            enhanced_context = self.rag_system.enhance_analysis_context(
                program_name, cobol_code, analysis_type
            )
            
            # Gerar prompt enriquecido
            enhanced_prompt = self.rag_system.generate_rag_enhanced_prompt(
                base_prompt, enhanced_context
            )
            
            self.logger.info(f"Prompt enriquecido para {program_name} com {enhanced_context['total_knowledge_items']} itens RAG")
            return enhanced_prompt
            
        except Exception as e:
            self.logger.error(f"Erro ao enriquecer prompt com RAG: {e}")
            return base_prompt
    
    def enhance_consolidated_analysis(self, programs_data: Dict[str, str], 
                                    base_prompt: str) -> str:
        """
        Enriquece análise consolidada com conhecimento RAG sistêmico.
        
        Args:
            programs_data: Dicionário {nome_programa: código_cobol}
            base_prompt: Prompt base da análise consolidada
            
        Returns:
            Prompt enriquecido para análise consolidada
        """
        if not self.is_enabled():
            return base_prompt
        
        try:
            # Combinar todos os códigos para análise sistêmica
            all_code = "\n\n".join(programs_data.values())
            program_names = list(programs_data.keys())
            
            # Criar contexto sistêmico
            system_query = f"Análise sistêmica consolidada de {len(programs_data)} programas COBOL: {', '.join(program_names)}"
            
            # Obter conhecimento relevante para análise sistêmica
            relevant_knowledge = self.rag_system.retrieve_relevant_knowledge(
                system_query, all_code, max_items=8  # Mais itens para análise consolidada
            )
            
            # Construir contexto sistêmico
            system_context = {
                'analysis_type': 'consolidated_system',
                'program_count': len(programs_data),
                'program_names': program_names,
                'relevant_patterns': [],
                'best_practices': [],
                'banking_rules': [],
                'system_integration_guidance': [],
                'total_knowledge_items': len(relevant_knowledge)
            }
            
            # Categorizar conhecimento para análise sistêmica
            for item, score in relevant_knowledge:
                knowledge_entry = {
                    'title': item.title,
                    'content': item.content,
                    'similarity_score': score,
                    'complexity_level': item.complexity_level,
                    'domain': item.domain
                }
                
                if item.category == 'pattern':
                    system_context['relevant_patterns'].append(knowledge_entry)
                elif item.category == 'best_practice':
                    system_context['best_practices'].append(knowledge_entry)
                elif item.category == 'banking_rule':
                    system_context['banking_rules'].append(knowledge_entry)
                else:
                    system_context['system_integration_guidance'].append(knowledge_entry)
            
            # Gerar prompt sistêmico enriquecido
            enhanced_prompt = self._generate_system_rag_prompt(base_prompt, system_context)
            
            self.logger.info(f"Análise consolidada enriquecida com {len(relevant_knowledge)} itens RAG sistêmicos")
            return enhanced_prompt
            
        except Exception as e:
            self.logger.error(f"Erro ao enriquecer análise consolidada com RAG: {e}")
            return base_prompt
    
    def _generate_system_rag_prompt(self, base_prompt: str, system_context: Dict[str, Any]) -> str:
        """Gera prompt enriquecido para análise sistêmica consolidada."""
        
        rag_sections = []
        
        # Seção de introdução RAG
        rag_sections.append("## CONHECIMENTO SISTÊMICO CONTEXTUAL (RAG):")
        rag_sections.append(f"*Análise enriquecida com {system_context['total_knowledge_items']} itens de conhecimento relevantes*")
        rag_sections.append("")
        
        # Padrões sistêmicos
        if system_context['relevant_patterns']:
            rag_sections.append("### PADRÕES ARQUITETURAIS IDENTIFICADOS:")
            for pattern in system_context['relevant_patterns'][:3]:
                rag_sections.append(f"**{pattern['title']}** (Similaridade: {pattern['similarity_score']:.2f})")
                rag_sections.append(pattern['content'])
                rag_sections.append("")
        
        # Melhores práticas sistêmicas
        if system_context['best_practices']:
            rag_sections.append("### MELHORES PRÁTICAS PARA SISTEMAS INTEGRADOS:")
            for practice in system_context['best_practices'][:3]:
                rag_sections.append(f"**{practice['title']}**")
                rag_sections.append(practice['content'])
                rag_sections.append("")
        
        # Regras de negócio sistêmicas
        if system_context['banking_rules']:
            rag_sections.append("### REGRAS DE NEGÓCIO SISTÊMICAS:")
            for rule in system_context['banking_rules'][:2]:
                rag_sections.append(f"**{rule['title']}**")
                rag_sections.append(rule['content'])
                rag_sections.append("")
        
        # Orientações de integração
        if system_context['system_integration_guidance']:
            rag_sections.append("### ORIENTAÇÕES DE INTEGRAÇÃO SISTÊMICA:")
            for guidance in system_context['system_integration_guidance'][:2]:
                rag_sections.append(f"**{guidance['title']}**")
                rag_sections.append(guidance['content'])
                rag_sections.append("")
        
        # Instruções específicas para análise sistêmica
        rag_sections.append("### INSTRUÇÕES PARA ANÁLISE SISTÊMICA ENRIQUECIDA:")
        rag_sections.append("- Identifique como os padrões conhecidos se manifestam no sistema completo")
        rag_sections.append("- Analise interdependências entre programas usando conhecimento contextual")
        rag_sections.append("- Aplique melhores práticas sistêmicas em suas recomendações")
        rag_sections.append("- Considere regras de negócio que afetam múltiplos componentes")
        rag_sections.append("- Proponha melhorias arquiteturais baseadas no conhecimento recuperado")
        rag_sections.append("")
        
        # Construir prompt final
        rag_content = "\n".join(rag_sections)
        enhanced_prompt = f"""
{base_prompt}

{rag_content}

---

**ANÁLISE PRINCIPAL (use o conhecimento contextual acima):**
"""
        
        return enhanced_prompt
    
    def add_program_analysis_to_knowledge_base(self, program_name: str, 
                                             analysis_result: str, 
                                             cobol_code: str) -> Optional[str]:
        """
        Adiciona resultado de análise à base de conhecimento para futuras consultas.
        
        Args:
            program_name: Nome do programa analisado
            analysis_result: Resultado da análise
            cobol_code: Código COBOL original
            
        Returns:
            ID do item adicionado ou None se falhou
        """
        if not self.is_enabled():
            return None
        
        try:
            # Extrair características do código para keywords
            code_features = self.rag_system._extract_code_features(cobol_code)
            
            # Gerar keywords baseadas nas características
            keywords = [program_name.lower()]
            if code_features['has_file_operations']:
                keywords.extend(['arquivo', 'file-operations'])
            if code_features['has_calculations']:
                keywords.extend(['cálculo', 'matemática'])
            if code_features['banking_indicators']:
                keywords.extend(['bancário', 'financeiro'])
            
            # Identificar constructs COBOL
            cobol_constructs = []
            if code_features['has_loops']:
                cobol_constructs.append('PERFORM UNTIL')
            if code_features['has_conditionals']:
                cobol_constructs.extend(['IF', 'EVALUATE'])
            if code_features['has_file_operations']:
                cobol_constructs.extend(['READ', 'WRITE', 'OPEN', 'CLOSE'])
            
            # Determinar domínio
            domain = 'banking' if code_features['banking_indicators'] else 'general'
            
            # Adicionar à base de conhecimento
            item_id = self.rag_system.add_knowledge_item(
                title=f"Análise do Programa {program_name}",
                content=f"Programa: {program_name}\n\nAnálise:\n{analysis_result}",
                category="technical_doc",
                keywords=keywords,
                cobol_constructs=cobol_constructs,
                domain=domain,
                complexity_level="intermediate"
            )
            
            self.logger.info(f"Análise de {program_name} adicionada à base de conhecimento: {item_id}")
            return item_id
            
        except Exception as e:
            self.logger.error(f"Erro ao adicionar análise à base de conhecimento: {e}")
            return None
    
    def get_rag_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do sistema RAG."""
        if not self.is_enabled():
            return {'rag_enabled': False}
        
        try:
            stats = self.rag_system.get_knowledge_stats()
            stats['rag_enabled'] = True
            return stats
        except Exception as e:
            self.logger.error(f"Erro ao obter estatísticas RAG: {e}")
            return {'rag_enabled': True, 'error': str(e)}
    
    def search_knowledge_base(self, query: str, max_results: int = 5) -> Dict[str, Any]:
        """
        Busca na base de conhecimento RAG.
        
        Args:
            query: Consulta de busca
            max_results: Número máximo de resultados
            
        Returns:
            Resultados da busca
        """
        if not self.is_enabled():
            return {'results': [], 'rag_enabled': False}
        
        try:
            relevant_items = self.rag_system.retrieve_relevant_knowledge(
                query, "", max_results
            )
            
            results = []
            for item, score in relevant_items:
                results.append({
                    'title': item.title,
                    'content': item.content[:500] + "..." if len(item.content) > 500 else item.content,
                    'category': item.category,
                    'domain': item.domain,
                    'complexity_level': item.complexity_level,
                    'similarity_score': score,
                    'keywords': item.keywords
                })
            
            return {
                'results': results,
                'total_found': len(results),
                'query': query,
                'rag_enabled': True
            }
            
        except Exception as e:
            self.logger.error(f"Erro na busca RAG: {e}")
            return {'results': [], 'error': str(e), 'rag_enabled': True}

    
    def finalize_session(self) -> Optional[str]:
        """
        Finaliza a sessão RAG e gera relatório completo.
        
        Returns:
            Caminho do arquivo de relatório gerado ou None se RAG desabilitado
        """
        if not self.is_enabled():
            return None
        
        try:
            return self.rag_system.finalize_rag_session()
        except Exception as e:
            self.logger.error(f"Erro ao finalizar sessão RAG: {e}")
            return None
    
    def get_session_summary(self) -> Optional[Dict[str, Any]]:
        """
        Retorna resumo da sessão RAG atual.
        
        Returns:
            Dicionário com estatísticas da sessão ou None se RAG desabilitado
        """
        if not self.is_enabled():
            return None
        
        try:
            return self.rag_system.get_rag_session_summary()
        except Exception as e:
            self.logger.error(f"Erro ao obter resumo da sessão RAG: {e}")
            return None
    
    def get_session_stats(self) -> Dict[str, Any]:
        """
        Retorna estatísticas da sessão RAG atual.
        
        Returns:
            Dicionário com estatísticas da sessão
        """
        if not self.is_enabled():
            return {
                'operations': 0,
                'programs': 0,
                'knowledge_items': 0,
                'rag_enabled': False
            }
        
        try:
            summary = self.rag_system.get_rag_session_summary()
            if summary:
                return {
                    'operations': summary.get('total_operations', 0),
                    'programs': summary.get('programs_analyzed', 0),
                    'knowledge_items': summary.get('knowledge_items_used', 0),
                    'rag_enabled': True
                }
            else:
                return {
                    'operations': 0,
                    'programs': 0,
                    'knowledge_items': 0,
                    'rag_enabled': True
                }
        except Exception as e:
            self.logger.error(f"Erro ao obter estatísticas da sessão RAG: {e}")
            return {
                'operations': 0,
                'programs': 0,
                'knowledge_items': 0,
                'rag_enabled': True,
                'error': str(e)
            }
