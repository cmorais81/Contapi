"""
Módulo de prompts para análise COBOL
Contém prompts especializados para diferentes tipos de análise
"""

from .professional_cobol_prompts import ProfessionalCOBOLPrompts
from .expert_level_prompts import ExpertLevelPrompts
from .ultra_detailed_cobol_prompts import UltraDetailedCOBOLPrompts

__all__ = [
    'ProfessionalCOBOLPrompts',
    'ExpertLevelPrompts', 
    'UltraDetailedCOBOLPrompts'
]
