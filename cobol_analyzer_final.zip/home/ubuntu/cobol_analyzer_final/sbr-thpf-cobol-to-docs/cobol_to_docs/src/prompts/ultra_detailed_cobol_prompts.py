#!/usr/bin/env python3
"""
Prompts Ultra-Detalhados para Análise COBOL
Prompts especializados para capturar detalhes técnicos específicos
"""

class UltraDetailedCOBOLPrompts:
    """
    Prompts ultra-detalhados para análise técnica profunda de código COBOL
    """
    
    @staticmethod
    def get_deep_functional_analysis_prompt(program_name: str, program_content: str, copybooks: str = "") -> str:
        """
        Prompt para análise funcional ultra-detalhada
        """
        return f"""Você é um especialista sênior em COBOL com 25+ anos de experiência em sistemas bancários e financeiros.
Analise o programa COBOL {program_name} com nível de detalhamento EXTREMO, identificando TODOS os aspectos técnicos e funcionais.

PROGRAMA: {program_name}

COPYBOOKS RELACIONADOS:
{copybooks if copybooks else "Nenhum copybook fornecido"}

CÓDIGO COBOL:
{program_content}

ANÁLISE ULTRA-DETALHADA REQUERIDA:

## 1. FUNCIONALIDADES PRINCIPAIS (DETALHE MÁXIMO)

Para CADA funcionalidade identificada, forneça:
- **Nome da Funcionalidade**: [nome específico]
- **Tipo de Operação**: [Validação/Processamento/Cálculo/Integração/Controle]
- **Descrição Técnica**: [descrição detalhada do que faz]
- **Localização no Código**: [linhas específicas]
- **Parâmetros de Entrada**: [dados recebidos]
- **Parâmetros de Saída**: [dados gerados]
- **Regras de Negócio Aplicadas**: [regras específicas]
- **Validações Realizadas**: [tipos de validação]
- **Tratamento de Erro**: [como trata erros]
- **Dependências**: [outros módulos/arquivos]

IDENTIFIQUE ESPECIFICAMENTE:
- Validações físicas e lógicas de arquivos
- Processamento de arquivos de entrada e saída
- Validações específicas por tipo de informação
- Verificação de dados (CPF/CNPJ, valores numéricos, percentuais)
- Tratamento de informações CADOC
- Operações de abertura/fechamento de arquivos
- Validações de header, trailer e registros de detalhe
- Gravação de registros válidos e com erro

## 2. SEQUÊNCIA DE EXECUÇÃO DETALHADA

Mapeie TODA a sequência de execução:
1. **Inicialização**:
   - Rotinas de inicialização (ex: R100-INICIO)
   - Abertura de arquivos
   - Obtenção de data corrente
   - Verificação de data base do sistema

2. **Processamento Principal**:
   - Rotinas de processamento (ex: R200-PROCESSAMENTO)
   - Leitura de arquivo de entrada
   - Validações específicas (ex: R210-VALIDA-HEADER, R220-VALIDA-TRAILER)
   - Validação de registros de detalhe (ex: R230-VALIDA-DETALHE)
   - Gravação de registros válidos e com erro

3. **Finalização**:
   - Rotinas de finalização (ex: R900-FIM)
   - Fechamento de arquivos
   - Exibição de estatísticas de processamento

Para CADA rotina, identifique:
- **Nome da Rotina**: [nome exato]
- **Função Específica**: [o que faz]
- **Parâmetros**: [dados manipulados]
- **Validações**: [verificações realizadas]
- **Saídas**: [resultados gerados]

## 3. REGRAS DE NEGÓCIO IDENTIFICADAS (ULTRA-ESPECÍFICAS)

Para CADA regra de negócio, forneça:
- **ID da Regra**: RN-XXX
- **Nome da Regra**: [nome específico]
- **Tipo**: [Validação de Dados/Cálculo/Controle/Integração]
- **Descrição Detalhada**: [explicação completa]
- **Localização**: [linha(s) específica(s)]
- **Código COBOL**: [trecho exato]
- **Valores/Constantes**: [valores específicos utilizados]
- **Condições**: [quando se aplica]
- **Ações**: [o que acontece quando ativada]
- **Tratamento de Exceção**: [como trata casos especiais]
- **Impacto no Negócio**: [consequências]
- **Criticidade**: [CRÍTICA/ALTA/MÉDIA/BAIXA]

IDENTIFIQUE ESPECIFICAMENTE:
- Validação de datas (formato, consistência)
- Validação de CPF/CNPJ (algoritmo, formato)
- Validação de valores numéricos (faixas, formatos)
- Validação de percentuais (limites, precisão)
- Códigos de modalidade/submodalidade
- Regras específicas do CADOC
- Validações de tipos de informação (01, 02, 03, etc.)

## 4. TIPOS DE INFORMAÇÃO E VALIDAÇÕES

Para CADA tipo de informação identificado:
- **Código do Tipo**: [ex: 01, 02, 03, 04, 06, 07, 10, 11, 12, 14, 15, 17, 18, 19]
- **Descrição**: [o que representa]
- **Validações Específicas**: [regras aplicadas]
- **Campos Obrigatórios**: [campos necessários]
- **Campos Opcionais**: [campos facultativos]
- **Formatos Aceitos**: [padrões de dados]
- **Regras de Consistência**: [verificações cruzadas]
- **Tratamento de Erro**: [como trata inconsistências]

## 5. ARQUIVOS DE ENTRADA E SAÍDA (DETALHAMENTO COMPLETO)

Para CADA arquivo:
- **Nome do Arquivo**: [nome exato]
- **Tipo**: [Entrada/Saída/Trabalho]
- **Formato**: [Sequencial/VSAM/etc.]
- **Estrutura de Registro**: [layout detalhado]
- **Tamanho do Registro**: [bytes]
- **Campos Principais**: [campos importantes]
- **Validações Aplicadas**: [verificações realizadas]
- **Tratamento de Erro**: [como trata problemas]
- **Estatísticas Geradas**: [contadores, totais]

IDENTIFIQUE ESPECIFICAMENTE:
- Arquivo de entrada principal (ex: E1DQ0705)
- Arquivos de saída (ex: S1DQ0705 para válidos, S2DQ0705 para erros)
- Estrutura de header, trailer e registros de detalhe
- Campos de controle e validação

## 6. VALIDAÇÕES ESPECÍFICAS (MÁXIMO DETALHE)

Para CADA validação identificada:
- **Nome da Validação**: [nome específico]
- **Tipo**: [Formato/Consistência/Negócio/Técnica]
- **Campo(s) Validado(s)**: [campos específicos]
- **Regra de Validação**: [lógica aplicada]
- **Valores Aceitos**: [faixas, listas, padrões]
- **Mensagem de Erro**: [texto específico]
- **Ação em Caso de Erro**: [o que acontece]
- **Código de Erro**: [se aplicável]

IDENTIFIQUE ESPECIFICAMENTE:
- Validação de CPF (dígitos verificadores, formato)
- Validação de CNPJ (algoritmo, estrutura)
- Validação de datas (formato AAAAMMDD, consistência)
- Validação de valores monetários (formato, precisão)
- Validação de percentuais (faixas válidas)
- Validação de códigos (modalidade, submodalidade)

## 7. TRATAMENTO DE INFORMAÇÕES CADOC

Identifique TODAS as referências ao CADOC:
- **Tipos de Documento**: [quais tipos são tratados]
- **Validações Específicas**: [regras do CADOC]
- **Campos Obrigatórios**: [dados necessários]
- **Formatos Aceitos**: [padrões específicos]
- **Regras de Consistência**: [verificações cruzadas]
- **Integração**: [como interage com outros sistemas]

## 8. ESTATÍSTICAS E CONTROLES

Para CADA estatística gerada:
- **Nome da Estatística**: [nome específico]
- **Tipo**: [Contador/Total/Percentual/Controle]
- **Cálculo**: [como é calculada]
- **Finalidade**: [para que serve]
- **Exibição**: [onde é mostrada]
- **Armazenamento**: [onde é gravada]

## 9. ROTINAS DE ERRO E EXCEÇÃO

Para CADA tratamento de erro:
- **Tipo de Erro**: [categoria do erro]
- **Condição de Ativação**: [quando ocorre]
- **Ação Executada**: [o que faz]
- **Mensagem**: [texto específico]
- **Log/Registro**: [onde é registrado]
- **Recuperação**: [como se recupera]

## 10. INTEGRAÇÕES E DEPENDÊNCIAS

Para CADA integração:
- **Sistema/Módulo**: [nome do sistema]
- **Tipo de Integração**: [Arquivo/DB/API/Chamada]
- **Dados Trocados**: [informações específicas]
- **Protocolo**: [como se comunica]
- **Tratamento de Erro**: [como trata falhas]
- **Dependências**: [o que precisa para funcionar]

FORMATO DE RESPOSTA OBRIGATÓRIO:

# ANÁLISE FUNCIONAL ULTRA-DETALHADA - {program_name}

## 1. FUNCIONALIDADES PRINCIPAIS

### Funcionalidade 1: [Nome]
- **Tipo**: [tipo específico]
- **Descrição**: [descrição detalhada]
- **Localização**: Linhas X-Y
- **Entrada**: [dados de entrada]
- **Saída**: [dados de saída]
- **Validações**: [validações aplicadas]
- **Tratamento de Erro**: [como trata erros]

[Continue para todas as funcionalidades...]

## 2. SEQUÊNCIA DE EXECUÇÃO DETALHADA

### Fase 1: Inicialização (R100-INICIO)
- **Abertura de arquivos**: [arquivos específicos]
- **Obtenção de data**: [como obtém]
- **Verificações iniciais**: [o que verifica]

### Fase 2: Processamento Principal (R200-PROCESSAMENTO)
- **Leitura de entrada**: [como lê]
- **Validações**: [quais validações]
- **Processamento**: [como processa]

[Continue para todas as fases...]

## 3. REGRAS DE NEGÓCIO IDENTIFICADAS

### RN-001: Validação de CPF
- **Tipo**: Validação de Dados
- **Descrição**: [descrição específica]
- **Localização**: Linha X
- **Código**: `[código COBOL exato]`
- **Algoritmo**: [algoritmo de validação]
- **Tratamento de Erro**: [como trata]
- **Criticidade**: ALTA

[Continue para todas as regras...]

## 4. TIPOS DE INFORMAÇÃO E VALIDAÇÕES

### Tipo 01: [Descrição]
- **Campos Obrigatórios**: [lista específica]
- **Validações**: [validações aplicadas]
- **Formato**: [formato esperado]

[Continue para todos os tipos...]

## 5. ARQUIVOS DE ENTRADA E SAÍDA

### Arquivo E1DQ0705 (Entrada)
- **Tipo**: Arquivo sequencial de entrada
- **Estrutura**: [estrutura detalhada]
- **Validações**: [validações aplicadas]

### Arquivo S1DQ0705 (Saída - Válidos)
- **Tipo**: Arquivo sequencial de saída
- **Conteúdo**: Registros válidos processados
- **Estrutura**: [estrutura detalhada]

[Continue para todos os arquivos...]

## 6. VALIDAÇÕES ESPECÍFICAS

### Validação de CPF (R305-VALIDA-CPF)
- **Algoritmo**: [algoritmo específico]
- **Verificações**: [o que verifica]
- **Tratamento**: [como trata erros]

[Continue para todas as validações...]

SEJA EXTREMAMENTE ESPECÍFICO E TÉCNICO. Use terminologia COBOL precisa e forneça exemplos de código quando relevante."""

    @staticmethod
    def get_business_rules_deep_extraction_prompt(program_name: str, program_content: str) -> str:
        """
        Prompt para extração ultra-detalhada de regras de negócio
        """
        return f"""Como especialista sênior em COBOL e sistemas bancários, extraia TODAS as regras de negócio do programa {program_name} com MÁXIMO DETALHAMENTO.

CÓDIGO:
{program_content}

INSTRUÇÕES ULTRA-ESPECÍFICAS:

## CATEGORIAS DE REGRAS A IDENTIFICAR:

### 1. VALIDAÇÕES DE DADOS
- Validação de CPF/CNPJ (algoritmos específicos)
- Validação de datas (formatos, consistência)
- Validação de valores numéricos (faixas, precisão)
- Validação de percentuais (limites, casas decimais)
- Validação de códigos (modalidade, submodalidade)
- Validação de campos obrigatórios/opcionais

### 2. REGRAS DE PROCESSAMENTO
- Sequência de execução obrigatória
- Condições de parada/continuação
- Regras de agrupamento/classificação
- Regras de totalização/sumarização
- Regras de geração de arquivos de saída

### 3. REGRAS DE NEGÓCIO ESPECÍFICAS
- Regras do CADOC (Cadastro de Documentos)
- Regras de compliance bancário
- Regras de auditoria e rastreabilidade
- Regras de controle de qualidade
- Regras de integridade referencial

### 4. REGRAS DE TRATAMENTO DE ERRO
- Condições de erro específicas
- Ações corretivas automáticas
- Regras de log e auditoria
- Regras de recuperação de falhas

## FORMATO DE RESPOSTA OBRIGATÓRIO:

Para CADA regra identificada:

### RN-XXX: [Nome Específico da Regra]
- **Categoria**: [Validação/Processamento/Negócio/Erro]
- **Subcategoria**: [tipo específico]
- **Localização**: Linha(s) X[-Y]
- **Descrição Técnica**: [descrição detalhada]
- **Código COBOL**: 
```cobol
[trecho específico do código]
```
- **Condições de Ativação**: [quando se aplica]
- **Parâmetros**: [valores/variáveis utilizados]
- **Algoritmo**: [lógica específica]
- **Valores Aceitos**: [faixas, listas, padrões]
- **Tratamento de Exceção**: [como trata casos especiais]
- **Mensagem de Erro**: [se aplicável]
- **Ação em Caso de Falha**: [o que acontece]
- **Dependências**: [outras regras relacionadas]
- **Impacto no Negócio**: [consequências]
- **Criticidade**: [CRÍTICA/ALTA/MÉDIA/BAIXA]
- **Observações**: [detalhes adicionais]

## EXEMPLOS ESPECÍFICOS A PROCURAR:

### Validação de CPF:
- Verificação de dígitos verificadores
- Validação de formato (XXX.XXX.XXX-XX)
- Verificação de CPFs inválidos conhecidos
- Tratamento de CPFs zerados ou sequenciais

### Validação de CNPJ:
- Algoritmo de validação específico
- Verificação de formato (XX.XXX.XXX/XXXX-XX)
- Validação de dígitos verificadores
- Tratamento de CNPJs especiais

### Validação de Datas:
- Formato AAAAMMDD
- Verificação de anos bissextos
- Validação de meses (01-12)
- Validação de dias por mês
- Consistência entre datas

### Validação de Valores:
- Faixas de valores aceitos
- Precisão decimal
- Formato de apresentação
- Validação de sinais (+/-)

### Tipos de Informação CADOC:
- Tipo 01: [especificar validações]
- Tipo 02: [especificar validações]
- Tipo 03: [especificar validações]
- [etc. para todos os tipos encontrados]

SEJA EXTREMAMENTE DETALHADO E TÉCNICO. Identifique TODAS as regras, mesmo as mais sutis."""

    @staticmethod
    def get_file_processing_analysis_prompt(program_name: str, program_content: str) -> str:
        """
        Prompt para análise detalhada de processamento de arquivos
        """
        return f"""Analise DETALHADAMENTE o processamento de arquivos no programa COBOL {program_name}.

CÓDIGO:
{program_content}

ANÁLISE ULTRA-DETALHADA DE ARQUIVOS:

## 1. IDENTIFICAÇÃO DE ARQUIVOS

Para CADA arquivo identificado:
- **Nome Lógico**: [nome no programa]
- **Nome Físico**: [nome real do arquivo]
- **Tipo**: [Entrada/Saída/Trabalho/Índice]
- **Organização**: [Sequencial/VSAM/Relativa/Indexada]
- **Modo de Acesso**: [Sequential/Random/Dynamic]
- **Status**: [Input/Output/I-O/Extend]

## 2. ESTRUTURA DE REGISTROS

Para CADA tipo de registro:
- **Nome do Registro**: [nome específico]
- **Tamanho**: [bytes]
- **Tipo**: [Header/Trailer/Detalhe/Controle]
- **Layout Detalhado**: [estrutura campo por campo]
- **Campos de Controle**: [campos de identificação]
- **Campos de Dados**: [campos de informação]

## 3. OPERAÇÕES DE ARQUIVO

Para CADA operação:
- **Tipo de Operação**: [OPEN/READ/WRITE/CLOSE/REWRITE/DELETE]
- **Arquivo Envolvido**: [nome do arquivo]
- **Localização**: [linha no código]
- **Condições**: [quando é executada]
- **Tratamento de Status**: [verificação de file-status]
- **Tratamento de Erro**: [ações em caso de erro]

## 4. VALIDAÇÕES DE ARQUIVO

Para CADA validação:
- **Tipo de Validação**: [Header/Trailer/Detalhe/Estrutura]
- **Campo(s) Validado(s)**: [campos específicos]
- **Regra de Validação**: [lógica aplicada]
- **Ação em Caso de Erro**: [o que acontece]
- **Mensagem de Erro**: [texto específico]

## 5. PROCESSAMENTO SEQUENCIAL

Detalhe a sequência de processamento:
- **Inicialização**: [abertura de arquivos]
- **Loop Principal**: [leitura e processamento]
- **Validações**: [verificações realizadas]
- **Gravação**: [escrita de resultados]
- **Finalização**: [fechamento e estatísticas]

## 6. CONTROLES E ESTATÍSTICAS

Para CADA controle:
- **Nome do Controle**: [nome específico]
- **Tipo**: [Contador/Total/Percentual]
- **Cálculo**: [como é calculado]
- **Finalidade**: [para que serve]
- **Exibição**: [onde é mostrado]

FORMATO DE RESPOSTA:

# ANÁLISE DE PROCESSAMENTO DE ARQUIVOS - {program_name}

## ARQUIVOS IDENTIFICADOS

### E1DQ0705 - Arquivo de Entrada
- **Tipo**: Arquivo sequencial de entrada
- **Organização**: Sequential
- **Registro**: [tamanho e estrutura]
- **Validações**: [validações aplicadas]

### S1DQ0705 - Arquivo de Saída (Válidos)
- **Tipo**: Arquivo sequencial de saída
- **Conteúdo**: Registros processados com sucesso
- **Estrutura**: [layout detalhado]

[Continue para todos os arquivos...]

## OPERAÇÕES DETALHADAS

### Abertura de Arquivos (R100-INICIO)
- **Sequência**: [ordem de abertura]
- **Verificações**: [validações realizadas]
- **Tratamento de Erro**: [ações em caso de falha]

### Processamento Principal (R200-PROCESSAMENTO)
- **Leitura**: [como lê os registros]
- **Validação**: [verificações realizadas]
- **Processamento**: [transformações aplicadas]
- **Gravação**: [como grava os resultados]

[Continue para todas as operações...]

SEJA EXTREMAMENTE ESPECÍFICO sobre estruturas de dados e operações de arquivo."""

    @staticmethod
    def get_validation_rules_analysis_prompt(program_name: str, program_content: str) -> str:
        """
        Prompt para análise ultra-detalhada de validações
        """
        return f"""Analise TODAS as validações implementadas no programa COBOL {program_name} com MÁXIMO DETALHAMENTO.

CÓDIGO:
{program_content}

ANÁLISE ULTRA-ESPECÍFICA DE VALIDAÇÕES:

## CATEGORIAS DE VALIDAÇÃO A IDENTIFICAR:

### 1. VALIDAÇÕES DE FORMATO
- Formato de CPF (XXX.XXX.XXX-XX ou XXXXXXXXXXX)
- Formato de CNPJ (XX.XXX.XXX/XXXX-XX ou XXXXXXXXXXXXXX)
- Formato de datas (AAAAMMDD, DD/MM/AAAA, etc.)
- Formato de valores monetários
- Formato de percentuais
- Formato de códigos específicos

### 2. VALIDAÇÕES DE CONSISTÊNCIA
- Dígitos verificadores de CPF
- Dígitos verificadores de CNPJ
- Consistência de datas (anos bissextos, dias por mês)
- Consistência entre campos relacionados
- Validação de faixas de valores
- Validação de listas de valores aceitos

### 3. VALIDAÇÕES DE NEGÓCIO
- Regras específicas do CADOC
- Validações por tipo de informação
- Regras de obrigatoriedade condicional
- Validações de integridade referencial
- Regras de compliance bancário

### 4. VALIDAÇÕES TÉCNICAS
- Verificação de campos obrigatórios
- Validação de tipos de dados
- Verificação de tamanhos de campo
- Validação de caracteres permitidos
- Verificação de encoding

## FORMATO DE RESPOSTA OBRIGATÓRIO:

Para CADA validação identificada:

### VAL-XXX: [Nome Específico da Validação]
- **Categoria**: [Formato/Consistência/Negócio/Técnica]
- **Subcategoria**: [tipo específico]
- **Campo(s) Validado(s)**: [campos específicos]
- **Localização**: Linha(s) X[-Y]
- **Descrição**: [o que valida]
- **Algoritmo**: [lógica de validação]
- **Código COBOL**:
```cobol
[trecho específico do código]
```
- **Condições de Aplicação**: [quando se aplica]
- **Valores Aceitos**: [faixas, listas, padrões]
- **Valores Rejeitados**: [o que não aceita]
- **Mensagem de Erro**: [texto específico]
- **Código de Erro**: [se aplicável]
- **Ação em Caso de Erro**: [o que acontece]
- **Tratamento de Exceção**: [casos especiais]
- **Dependências**: [outras validações relacionadas]
- **Criticidade**: [CRÍTICA/ALTA/MÉDIA/BAIXA]
- **Observações**: [detalhes adicionais]

## EXEMPLOS ESPECÍFICOS:

### Validação de CPF (R305-VALIDA-CPF)
- **Algoritmo Completo**: [passo a passo]
- **Verificação de Dígitos**: [como calcula]
- **CPFs Inválidos**: [lista de CPFs rejeitados]
- **Tratamento de Zeros**: [como trata 000.000.000-00]

### Validação de CNPJ (R310-VALIDA-CNPJ)
- **Algoritmo Específico**: [método de validação]
- **Pesos Utilizados**: [sequência de pesos]
- **Cálculo de Dígitos**: [fórmula aplicada]
- **Casos Especiais**: [CNPJs especiais]

### Validação de Data (R300-VALIDA-DATA)
- **Formato Aceito**: [AAAAMMDD]
- **Verificação de Ano**: [faixa válida]
- **Verificação de Mês**: [01-12]
- **Verificação de Dia**: [por mês]
- **Anos Bissextos**: [como trata]

### Validação por Tipo de Informação
- **Tipo 01**: [validações específicas]
- **Tipo 02**: [validações específicas]
- **Tipo 03**: [validações específicas]
- [etc. para todos os tipos]

IDENTIFIQUE TODAS as validações, incluindo as mais sutis e implícitas."""

    @staticmethod
    def get_cadoc_specific_analysis_prompt(program_name: str, program_content: str) -> str:
        """
        Prompt específico para análise de funcionalidades CADOC
        """
        return f"""Analise ESPECIFICAMENTE as funcionalidades relacionadas ao CADOC (Cadastro de Documentos) no programa {program_name}.

CÓDIGO:
{program_content}

ANÁLISE ESPECÍFICA DO CADOC:

## 1. IDENTIFICAÇÃO DE FUNCIONALIDADES CADOC

Identifique TODAS as referências ao CADOC:
- Comentários mencionando CADOC
- Variáveis relacionadas ao CADOC
- Rotinas específicas do CADOC
- Validações do CADOC
- Tipos de documento CADOC

## 2. TIPOS DE DOCUMENTO CADOC

Para CADA tipo identificado:
- **Código do Tipo**: [ex: 01, 02, 03, etc.]
- **Descrição**: [o que representa]
- **Campos Obrigatórios**: [lista específica]
- **Campos Opcionais**: [lista específica]
- **Validações Específicas**: [regras aplicadas]
- **Formato de Dados**: [estrutura esperada]
- **Regras de Consistência**: [verificações cruzadas]

## 3. VALIDAÇÕES ESPECÍFICAS DO CADOC

Para CADA validação CADOC:
- **Nome da Validação**: [nome específico]
- **Tipo de Documento**: [qual tipo se aplica]
- **Campo(s) Validado(s)**: [campos específicos]
- **Regra de Validação**: [lógica aplicada]
- **Valores Aceitos**: [padrões válidos]
- **Tratamento de Erro**: [ações em caso de falha]

## 4. PROCESSAMENTO DE DOCUMENTOS CADOC

Detalhe o fluxo de processamento:
- **Recepção**: [como recebe os documentos]
- **Validação**: [verificações realizadas]
- **Classificação**: [como classifica por tipo]
- **Processamento**: [transformações aplicadas]
- **Armazenamento**: [como armazena]
- **Auditoria**: [controles aplicados]

## 5. INTEGRAÇÃO COM OUTROS SISTEMAS

Identifique integrações:
- **Sistemas Fonte**: [de onde vêm os dados]
- **Sistemas Destino**: [para onde vão os dados]
- **Formatos de Troca**: [estruturas de dados]
- **Protocolos**: [como se comunica]
- **Controles**: [verificações de integridade]

FORMATO DE RESPOSTA:

# ANÁLISE ESPECÍFICA CADOC - {program_name}

## FUNCIONALIDADES CADOC IDENTIFICADAS

### Tratamento de Informações CADOC
- **Descrição**: [funcionalidade específica]
- **Localização**: [linhas no código]
- **Tipos Suportados**: [lista de tipos]
- **Validações**: [verificações realizadas]

## TIPOS DE DOCUMENTO SUPORTADOS

### Tipo 01: [Descrição]
- **Campos Obrigatórios**: [lista]
- **Validações**: [regras específicas]
- **Formato**: [estrutura de dados]

[Continue para todos os tipos...]

## VALIDAÇÕES ESPECÍFICAS

### Validação de Tipo de Informação
- **Algoritmo**: [como valida]
- **Valores Aceitos**: [lista de tipos válidos]
- **Tratamento de Erro**: [ações em caso de tipo inválido]

[Continue para todas as validações...]

SEJA EXTREMAMENTE ESPECÍFICO sobre aspectos do CADOC."""

    @staticmethod
    def get_error_handling_analysis_prompt(program_name: str, program_content: str) -> str:
        """
        Prompt para análise detalhada de tratamento de erros
        """
        return f"""Analise DETALHADAMENTE todo o tratamento de erros e exceções no programa {program_name}.

CÓDIGO:
{program_content}

ANÁLISE COMPLETA DE TRATAMENTO DE ERROS:

## 1. TIPOS DE ERRO IDENTIFICADOS

Para CADA tipo de erro:
- **Categoria**: [Validação/Arquivo/Sistema/Negócio]
- **Subcategoria**: [tipo específico]
- **Descrição**: [o que representa]
- **Condições de Ocorrência**: [quando acontece]
- **Severidade**: [CRÍTICO/ALTO/MÉDIO/BAIXO]

## 2. MECANISMOS DE DETECÇÃO

Para CADA mecanismo:
- **Tipo de Verificação**: [File-Status/Condição/Validação]
- **Localização**: [onde é verificado]
- **Código de Verificação**: [como detecta]
- **Ação Imediata**: [o que faz ao detectar]

## 3. TRATAMENTO ESPECÍFICO

Para CADA tratamento:
- **Tipo de Erro**: [categoria específica]
- **Ação Corretiva**: [o que faz para corrigir]
- **Mensagem de Erro**: [texto específico]
- **Log/Registro**: [onde registra]
- **Recuperação**: [como se recupera]
- **Continuidade**: [continua ou para]

## 4. CÓDIGOS DE ERRO

Para CADA código:
- **Código**: [número/texto do erro]
- **Descrição**: [o que significa]
- **Origem**: [onde é gerado]
- **Tratamento**: [como é tratado]
- **Documentação**: [onde está documentado]

FORMATO DE RESPOSTA:

# ANÁLISE DE TRATAMENTO DE ERROS - {program_name}

## CATEGORIAS DE ERRO

### Erros de Validação
- **Tipos**: [lista de tipos]
- **Tratamento**: [como são tratados]
- **Recuperação**: [possibilidades de recuperação]

### Erros de Arquivo
- **File Status**: [códigos verificados]
- **Ações**: [o que faz para cada status]
- **Recuperação**: [como se recupera]

[Continue para todas as categorias...]

## MECANISMOS ESPECÍFICOS

### Verificação de File Status
- **Códigos Verificados**: [lista de códigos]
- **Ações por Código**: [o que faz para cada um]
- **Localização**: [onde verifica]

[Continue para todos os mecanismos...]

SEJA EXTREMAMENTE DETALHADO sobre tratamento de erros."""
