"""
COBOL AI Engine v3.0.0 - Enhanced Provider Manager
Gerenciador aprimorado de provedores com suporte a múltiplos modelos e configurações específicas.
"""

import logging
from typing import Dict, List, Any

from .base_provider import BaseProvider, AIRequest, AIResponse
from .luzia_provider import LuziaProvider
from .enhanced_mock_provider import EnhancedMockProvider
from .basic_provider import BasicProvider
from .databricks_provider import DatabricksProvider
from .bedrock_provider import BedrockProvider
from .openai_provider import OpenAIProvider
from .github_copilot_provider import GitHubCopilotProvider

class EnhancedProviderManager:
    """Gerenciador aprimorado de provedores de IA, responsável por carregar e despachar para o provedor correto."""

    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o EnhancedProviderManager.

        Args:
            config: O dicionário de configuração completo da aplicação.
        """
        self.logger = logging.getLogger(__name__)
        self.logger.info("Initializing EnhancedProviderManager...")
        self.config = config
        self.providers: Dict[str, BaseProvider] = {}
        self.model_configurations: Dict[str, Dict[str, Any]] = {}
        
        self._initialize_providers()
        
        self.logger.info(f"EnhancedProviderManager initialized. Loaded models: {list(self.model_configurations.keys())}")

    def _initialize_providers(self) -> None:
        """
        Carrega e inicializa todos os provedores que estão habilitados no arquivo de configuração.
        """
        self.logger.info("Starting provider initialization...")
        providers_config = self.config.get("providers", {})
        if not providers_config:
            self.logger.warning("No 'providers' section found in config. No providers will be loaded.")
            return

        available_provider_classes = {
            "luzia": LuziaProvider,
            "enhanced_mock": EnhancedMockProvider,
            "basic": BasicProvider,
            "databricks": DatabricksProvider,
            "bedrock": BedrockProvider,
            "openai": OpenAIProvider,
            "github_copilot": GitHubCopilotProvider
        }

        for provider_name, provider_config in providers_config.items():
            if provider_config.get("enabled", False):
                self.logger.info(f"Found enabled provider in config: '{provider_name}'")
                if provider_name in available_provider_classes:
                    try:
                        ProviderClass = available_provider_classes[provider_name]
                        provider_instance = ProviderClass(provider_config)
                        self.providers[provider_name] = provider_instance
                        self.logger.info(f"Successfully instantiated provider: '{provider_name}'")
                        self._load_models_for_provider(provider_name, provider_config)
                    except Exception as e:
                        self.logger.error(f"Failed to initialize provider '{provider_name}': {e}", exc_info=True)
                else:
                    self.logger.warning(f"Provider '{provider_name}' is enabled in config but no matching class was found.")
            else:
                self.logger.debug(f"Skipping disabled provider: '{provider_name}'")

    def _load_models_for_provider(self, provider_name: str, provider_config: Dict[str, Any]):
        """
        Carrega as configurações de modelo para um provedor específico.
        """
        models = provider_config.get("models", {})
        self.logger.info(f"Loading models for provider '{provider_name}': {list(models.keys())}")
        for model_key, model_config in models.items():
            model_name = model_config.get("name", model_key)
            
            if model_name in self.model_configurations:
                 self.logger.warning(f"Model name '{model_name}' is not unique and is being overwritten by provider '{provider_name}'.")

            self.model_configurations[model_name] = {
                "provider": provider_name,
                **model_config
            }
            self.logger.info(f"Loaded model '{model_name}' (from provider '{provider_name}').")

    def analyze_with_model(self, model_name: str, request: AIRequest) -> AIResponse:
        """
        Realiza uma análise usando um modelo específico, despachando para o provedor correto.
        """
        self.logger.info(f"Attempting analysis with model: '{model_name}'")
        
        available_keys = list(self.model_configurations.keys())
        self.logger.debug(f"Available model keys for lookup: {available_keys}")
        
        if model_name not in self.model_configurations:
            self.logger.error(f"Model '{model_name}' not found in configurations. Cannot proceed with analysis.")
            return AIResponse(success=False, content="", tokens_used=0, model=model_name, provider="none", error_message=f"Model '{model_name}' is not configured.")

        model_conf = self.model_configurations[model_name]
        provider_name = model_conf.get("provider")

        if provider_name not in self.providers:
            self.logger.error(f"Provider '{provider_name}' (for model '{model_name}') is not available/initialized.")
            return AIResponse(success=False, content="", tokens_used=0, model=model_name, provider=provider_name or "unknown", error_message=f"Provider '{provider_name}' for model '{model_name}' is not available.")

        self.logger.info(f"Dispatching request for model '{model_name}' to provider '{provider_name}'.")
        provider = self.providers[provider_name]
        return provider.analyze(request)

