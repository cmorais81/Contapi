"""
COBOL AI Engine v2.6.0 - Provider Manager
Gerenciador completo de provedores de IA com TODOS os métodos implementados.
"""

import logging
import time
from typing import Dict, List, Any, Optional
from .base_provider import BaseProvider, AIRequest, AIResponse
from .luzia_provider import LuziaProvider
from .enhanced_mock_provider import EnhancedMockProvider
from .basic_provider import BasicProvider
from .databricks_provider import DatabricksProvider
from .bedrock_provider import BedrockProvider
from .openai_provider import OpenAIProvider


class ProviderManager:
    """
    Gerenciador de provedores de IA.
    TODOS OS MÉTODOS IMPLEMENTADOS - corrige erros das imagens.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o gerenciador de provedores."""
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.providers: Dict[str, BaseProvider] = {}
        self.statistics: Dict[str, Dict[str, Any]] = {}
        
        # Configuração de provedores
        ai_config = config.get('ai', {})
        self.primary_provider = ai_config.get('primary_provider', 'enhanced_mock')
        self.fallback_providers = ai_config.get('fallback_providers', ['basic'])
        
        # Inicializar provedores
        self._initialize_providers(ai_config)
        
        self.logger.info(f"Provider Manager inicializado - Primário: {self.primary_provider}")
    
    def _initialize_providers(self, ai_config: Dict[str, Any]) -> None:
        """Inicializa todos os provedores disponíveis."""
        providers_config = ai_config.get('providers', {})
        
        # Provedores disponíveis
        available_providers = {
            'luzia': LuziaProvider,
            'enhanced_mock': EnhancedMockProvider,
            'basic': BasicProvider,
            'databricks': DatabricksProvider,
            'bedrock': BedrockProvider,
            'openai': OpenAIProvider
        }
        
        for provider_name, provider_class in available_providers.items():
            try:
                provider_config = providers_config.get(provider_name, {})
                
                # Sempre inicializar enhanced_mock e basic como fallback
                if provider_config.get('enabled', False) or provider_name in ['enhanced_mock', 'basic']:
                    # CORRIGIDO: Passar configuração corretamente
                    provider = provider_class(provider_config)
                    self.providers[provider_name] = provider
                    
                    # Inicializar estatísticas
                    self.statistics[provider_name] = {
                        'total_requests': 0,
                        'successful_requests': 0,
                        'failed_requests': 0,
                        'total_tokens': 0,
                        'average_response_time': 0.0,
                        'last_request_time': None,
                        'consecutive_failures': 0
                    }
                    
                    self.logger.info(f"Provedor {provider_name} inicializado com sucesso")
                    
            except Exception as e:
                self.logger.error(f"Erro ao inicializar provedor {provider_name}: {str(e)}")
    
    def get_available_providers(self) -> List[str]:
        """
        Retorna lista de provedores disponíveis.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        available = []
        for name, provider in self.providers.items():
            try:
                if provider.is_available():
                    available.append(name)
            except Exception as e:
                self.logger.error(f"Erro ao verificar disponibilidade do {name}: {e}")
        
        return available
    
    def get_provider_statistics(self, provider_name: str) -> Dict[str, Any]:
        """
        Retorna estatísticas de um provedor específico.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        if provider_name not in self.providers:
            return {}
        
        stats = self.statistics.get(provider_name, {})
        
        # Adicionar estatísticas do próprio provider
        try:
            provider_stats = self.providers[provider_name].get_statistics()
            stats.update(provider_stats)
        except Exception as e:
            self.logger.error(f"Erro ao obter estatísticas do {provider_name}: {e}")
        
        return stats
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando o sistema de fallback.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        # Tentar provedor primário primeiro
        if self.primary_provider in self.providers:
            response = self._try_provider(self.primary_provider, request)
            if response.success:
                return response
        
        # Tentar provedores de fallback
        for fallback_provider in self.fallback_providers:
            if fallback_provider in self.providers:
                response = self._try_provider(fallback_provider, request)
                if response.success:
                    return response
        
        # Se todos falharam, retornar erro
        return AIResponse(
            success=False,
            content="",
            tokens_used=0,
            model="none",
            provider="none",
            error_message="Todos os provedores falharam"
        )
    
    def analyze_with_specific_provider(self, provider_name: str, request: AIRequest) -> AIResponse:
        """
        Analisa usando um provedor específico.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        if provider_name not in self.providers:
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model="none",
                provider=provider_name,
                error_message=f"Provedor {provider_name} não encontrado"
            )
        
        return self._try_provider(provider_name, request)
    
    def get_provider_status(self, provider_name: str) -> Dict[str, Any]:
        """
        Retorna status detalhado de um provedor.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        if provider_name not in self.providers:
            return {
                'available': False,
                'error': f'Provedor {provider_name} não encontrado'
            }
        
        try:
            provider = self.providers[provider_name]
            stats = self.get_provider_statistics(provider_name)
            
            return {
                'available': provider.is_available(),
                'enabled': getattr(provider, 'enabled', True),
                'model': getattr(provider, 'model', 'unknown'),
                'statistics': stats,
                'last_health_check': time.time()
            }
        except Exception as e:
            return {
                'available': False,
                'error': str(e)
            }
    
    def get_system_status(self) -> Dict[str, Any]:
        """
        Retorna status completo do sistema.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        available_providers = self.get_available_providers()
        
        provider_details = {}
        for provider_name in self.providers.keys():
            provider_details[provider_name] = self.get_provider_status(provider_name)
        
        return {
            'total_providers': len(self.providers),
            'available_providers': len(available_providers),
            'primary_provider': self.primary_provider,
            'primary_available': self.primary_provider in available_providers,
            'fallback_providers': self.fallback_providers,
            'provider_details': provider_details,
            'timestamp': time.time()
        }
    
    def health_check(self) -> Dict[str, bool]:
        """
        Executa verificação de saúde em todos os provedores.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        health_status = {}
        
        for provider_name, provider in self.providers.items():
            try:
                # Teste simples de disponibilidade
                health_status[provider_name] = provider.is_available()
                
                # Reset contador de falhas consecutivas se estiver saudável
                if health_status[provider_name]:
                    self.statistics[provider_name]['consecutive_failures'] = 0
                    
            except Exception as e:
                self.logger.error(f"Health check falhou para {provider_name}: {e}")
                health_status[provider_name] = False
                self.statistics[provider_name]['consecutive_failures'] += 1
        
        return health_status
    
    def reset_statistics(self, provider_name: Optional[str] = None) -> bool:
        """
        Reseta estatísticas de um ou todos os provedores.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        try:
            if provider_name:
                if provider_name in self.statistics:
                    self.statistics[provider_name] = {
                        'total_requests': 0,
                        'successful_requests': 0,
                        'failed_requests': 0,
                        'total_tokens': 0,
                        'average_response_time': 0.0,
                        'last_request_time': None,
                        'consecutive_failures': 0
                    }
                    self.logger.info(f"Estatísticas resetadas para {provider_name}")
                    return True
                return False
            else:
                # Reset todas as estatísticas
                for name in self.statistics.keys():
                    self.statistics[name] = {
                        'total_requests': 0,
                        'successful_requests': 0,
                        'failed_requests': 0,
                        'total_tokens': 0,
                        'average_response_time': 0.0,
                        'last_request_time': None,
                        'consecutive_failures': 0
                    }
                self.logger.info("Todas as estatísticas foram resetadas")
                return True
                
        except Exception as e:
            self.logger.error(f"Erro ao resetar estatísticas: {e}")
            return False
    
    def set_primary_provider(self, provider_name: str) -> bool:
        """
        Define o provedor primário.
        MÉTODO IMPLEMENTADO - funcionalidade adicional.
        """
        if provider_name in self.providers:
            self.primary_provider = provider_name
            self.logger.info(f"Provedor primário alterado para: {provider_name}")
            return True
        return False
    
    def add_fallback_provider(self, provider_name: str) -> bool:
        """
        Adiciona um provedor à lista de fallback.
        MÉTODO IMPLEMENTADO - funcionalidade adicional.
        """
        if provider_name in self.providers and provider_name not in self.fallback_providers:
            self.fallback_providers.append(provider_name)
            self.logger.info(f"Provedor {provider_name} adicionado ao fallback")
            return True
        return False
    
    def remove_fallback_provider(self, provider_name: str) -> bool:
        """
        Remove um provedor da lista de fallback.
        MÉTODO IMPLEMENTADO - funcionalidade adicional.
        """
        if provider_name in self.fallback_providers:
            self.fallback_providers.remove(provider_name)
            self.logger.info(f"Provedor {provider_name} removido do fallback")
            return True
        return False
    
    def _try_provider(self, provider_name: str, request: AIRequest) -> AIResponse:
        """Tenta usar um provedor específico."""
        start_time = time.time()
        
        try:
            provider = self.providers[provider_name]
            
            # Verificar se está disponível
            if not provider.is_available():
                raise Exception(f"Provedor {provider_name} não está disponível")
            
            # Executar análise
            response = provider.analyze(request)
            
            # Atualizar estatísticas
            response_time = time.time() - start_time
            self._update_provider_statistics(provider_name, response, response_time, True)
            
            return response
            
        except Exception as e:
            # Atualizar estatísticas de erro
            response_time = time.time() - start_time
            self._update_provider_statistics(provider_name, None, response_time, False)
            
            self.logger.error(f"Erro no provedor {provider_name}: {str(e)}")
            
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model="unknown",
                provider=provider_name,
                error_message=str(e)
            )
    
    def _update_provider_statistics(self, provider_name: str, response: Optional[AIResponse], 
                                  response_time: float, success: bool) -> None:
        """Atualiza estatísticas do provedor."""
        if provider_name not in self.statistics:
            return
        
        stats = self.statistics[provider_name]
        
        stats['total_requests'] += 1
        stats['last_request_time'] = time.time()
        
        if success:
            stats['successful_requests'] += 1
            stats['consecutive_failures'] = 0
            if response:
                stats['total_tokens'] += response.tokens_used
        else:
            stats['failed_requests'] += 1
            stats['consecutive_failures'] += 1
        
        # Atualizar tempo médio de resposta
        total_requests = stats['total_requests']
        current_avg = stats['average_response_time']
        stats['average_response_time'] = ((current_avg * (total_requests - 1)) + response_time) / total_requests

