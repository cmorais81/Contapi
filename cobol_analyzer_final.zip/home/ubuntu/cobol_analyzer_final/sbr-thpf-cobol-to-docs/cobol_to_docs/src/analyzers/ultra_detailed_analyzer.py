#!/usr/bin/env python3
"""
Analisador Ultra-Detalhado de COBOL
Análise técnica profunda com máximo detalhamento
"""

import logging
import re
from typing import Dict, List, Any, Optional
from datetime import datetime

from ..prompts.ultra_detailed_cobol_prompts import UltraDetailedCOBOLPrompts
from ..providers.enhanced_provider_manager import EnhancedProviderManager
from ..utils.enhanced_cost_calculator import EnhancedCostCalculator

class UltraDetailedAnalyzer:
    """
    Analisador que gera análises ultra-detalhadas de código COBOL
    com foco em aspectos técnicos específicos
    """
    
    def __init__(self, provider_config: Dict[str, Any]):
        self.logger = logging.getLogger(__name__)
        self.provider_manager = EnhancedProviderManager(provider_config)
        self.cost_calculator = EnhancedCostCalculator()
        self.prompts = UltraDetailedCOBOLPrompts()
        
    def analyze_program_ultra_detailed(self, 
                                     program: Any, 
                                     model: str = "luzia",
                                     copybooks: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Realiza análise ultra-detalhada usando prompts especializados
        """
        self.logger.info(f"Iniciando análise ultra-detalhada do programa {program.name}")
        
        try:
            # Preparar copybooks relacionados
            copybook_content = ""
            if copybooks:
                copybook_content = "\n".join([f"COPYBOOK {name}:\n{content}" 
                                            for name, content in copybooks.items()])
            
            # Análise funcional ultra-detalhada
            functional_analysis = self._execute_functional_analysis(
                program, model, copybook_content
            )
            
            # Análise específica de regras de negócio
            business_rules_analysis = self._execute_business_rules_analysis(
                program, model
            )
            
            # Análise de processamento de arquivos
            file_processing_analysis = self._execute_file_processing_analysis(
                program, model
            )
            
            # Análise de validações
            validation_analysis = self._execute_validation_analysis(
                program, model
            )
            
            # Análise específica do CADOC
            cadoc_analysis = self._execute_cadoc_analysis(
                program, model
            )
            
            # Análise de tratamento de erros
            error_handling_analysis = self._execute_error_handling_analysis(
                program, model
            )
            
            # Consolidar resultados
            consolidated_analysis = {
                'program_info': self._extract_detailed_program_info(program),
                'functional_analysis': functional_analysis,
                'business_rules_analysis': business_rules_analysis,
                'file_processing_analysis': file_processing_analysis,
                'validation_analysis': validation_analysis,
                'cadoc_analysis': cadoc_analysis,
                'error_handling_analysis': error_handling_analysis,
                'cost_summary': self._get_analysis_costs(),
                'analysis_metadata': {
                    'timestamp': datetime.now().isoformat(),
                    'model_used': model,
                    'analysis_version': '3.0-ultra-detailed',
                    'analyzer': 'UltraDetailedAnalyzer',
                    'total_analyses': 6
                }
            }
            
            self.logger.info(f"Análise ultra-detalhada concluída para {program.name}")
            return consolidated_analysis
            
        except Exception as e:
            self.logger.error(f"Erro na análise ultra-detalhada de {program.name}: {e}", exc_info=True)
            return self._generate_error_analysis(program, str(e))
    
    def _execute_functional_analysis(self, program: Any, model: str, copybooks: str) -> Dict[str, Any]:
        """Executa análise funcional ultra-detalhada"""
        prompt = self.prompts.get_deep_functional_analysis_prompt(
            program.name, program.content, copybooks
        )
        
        return self._execute_analysis_with_prompt(prompt, model, "functional_analysis")
    
    def _execute_business_rules_analysis(self, program: Any, model: str) -> Dict[str, Any]:
        """Executa análise ultra-detalhada de regras de negócio"""
        prompt = self.prompts.get_business_rules_deep_extraction_prompt(
            program.name, program.content
        )
        
        return self._execute_analysis_with_prompt(prompt, model, "business_rules_analysis")
    
    def _execute_file_processing_analysis(self, program: Any, model: str) -> Dict[str, Any]:
        """Executa análise detalhada de processamento de arquivos"""
        prompt = self.prompts.get_file_processing_analysis_prompt(
            program.name, program.content
        )
        
        return self._execute_analysis_with_prompt(prompt, model, "file_processing_analysis")
    
    def _execute_validation_analysis(self, program: Any, model: str) -> Dict[str, Any]:
        """Executa análise detalhada de validações"""
        prompt = self.prompts.get_validation_rules_analysis_prompt(
            program.name, program.content
        )
        
        return self._execute_analysis_with_prompt(prompt, model, "validation_analysis")
    
    def _execute_cadoc_analysis(self, program: Any, model: str) -> Dict[str, Any]:
        """Executa análise específica do CADOC"""
        prompt = self.prompts.get_cadoc_specific_analysis_prompt(
            program.name, program.content
        )
        
        return self._execute_analysis_with_prompt(prompt, model, "cadoc_analysis")
    
    def _execute_error_handling_analysis(self, program: Any, model: str) -> Dict[str, Any]:
        """Executa análise de tratamento de erros"""
        prompt = self.prompts.get_error_handling_analysis_prompt(
            program.name, program.content
        )
        
        return self._execute_analysis_with_prompt(prompt, model, "error_handling_analysis")
    
    def _execute_analysis_with_prompt(self, prompt: str, model: str, analysis_type: str) -> Dict[str, Any]:
        """Executa análise com prompt específico"""
        try:
            # Criar request para análise
            request = type('AIRequest', (), {
                'prompt': prompt,
                'model': model,
                'max_tokens': 12000,  # Aumentado para análises detalhadas
                'temperature': 0.05   # Reduzido para máxima precisão
            })()
            
            response = self.provider_manager.analyze(request)
            
            if hasattr(response, 'success') and response.success:
                # Calcular custos
                cost_info = self.cost_calculator.tokens_analytics(
                    getattr(response, 'metadata', {}), model
                )
                
                # Processar resposta específica
                processed_data = self._process_analysis_response(
                    getattr(response, 'content', ''), analysis_type
                )
                
                return {
                    'success': True,
                    'analysis_content': getattr(response, 'content', ''),
                    'processed_data': processed_data,
                    'tokens_used': cost_info.get('total_tokens', 0),
                    'cost_usd': cost_info.get('cost', 0.0),
                    'cost_brl': cost_info.get('cost_brl', 0.0),
                    'processing_time': getattr(response, 'processing_time', 0),
                    'analysis_type': analysis_type
                }
            else:
                return {
                    'success': False,
                    'error': getattr(response, 'error', 'Erro desconhecido'),
                    'tokens_used': 0,
                    'cost_usd': 0.0,
                    'cost_brl': 0.0,
                    'analysis_type': analysis_type
                }
                
        except Exception as e:
            self.logger.error(f"Erro na análise {analysis_type}: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e),
                'tokens_used': 0,
                'cost_usd': 0.0,
                'cost_brl': 0.0,
                'analysis_type': analysis_type
            }
    
    def _process_analysis_response(self, content: str, analysis_type: str) -> Dict[str, Any]:
        """Processa resposta da análise para extrair dados estruturados"""
        processed_data = {
            'summary': self._extract_summary(content),
            'items_count': self._count_items(content, analysis_type),
            'key_findings': self._extract_key_findings(content, analysis_type)
        }
        
        # Processamento específico por tipo de análise
        if analysis_type == "functional_analysis":
            processed_data.update(self._process_functional_response(content))
        elif analysis_type == "business_rules_analysis":
            processed_data.update(self._process_business_rules_response(content))
        elif analysis_type == "file_processing_analysis":
            processed_data.update(self._process_file_processing_response(content))
        elif analysis_type == "validation_analysis":
            processed_data.update(self._process_validation_response(content))
        elif analysis_type == "cadoc_analysis":
            processed_data.update(self._process_cadoc_response(content))
        elif analysis_type == "error_handling_analysis":
            processed_data.update(self._process_error_handling_response(content))
        
        return processed_data
    
    def _process_functional_response(self, content: str) -> Dict[str, Any]:
        """Processa resposta de análise funcional"""
        return {
            'functionalities_count': len(re.findall(r'### Funcionalidade \d+:', content)),
            'execution_phases': len(re.findall(r'### Fase \d+:', content)),
            'main_operations': self._extract_operations(content)
        }
    
    def _process_business_rules_response(self, content: str) -> Dict[str, Any]:
        """Processa resposta de análise de regras de negócio"""
        rules = re.findall(r'### RN-\d+:', content)
        return {
            'business_rules_count': len(rules),
            'critical_rules': len(re.findall(r'CRÍTICA', content)),
            'high_priority_rules': len(re.findall(r'ALTA', content)),
            'validation_rules': len(re.findall(r'Validação', content))
        }
    
    def _process_file_processing_response(self, content: str) -> Dict[str, Any]:
        """Processa resposta de análise de processamento de arquivos"""
        return {
            'input_files': len(re.findall(r'Entrada', content)),
            'output_files': len(re.findall(r'Saída', content)),
            'file_operations': len(re.findall(r'OPEN|READ|WRITE|CLOSE', content)),
            'validations': len(re.findall(r'Validação', content))
        }
    
    def _process_validation_response(self, content: str) -> Dict[str, Any]:
        """Processa resposta de análise de validações"""
        return {
            'total_validations': len(re.findall(r'### VAL-\d+:', content)),
            'format_validations': len(re.findall(r'Formato', content)),
            'business_validations': len(re.findall(r'Negócio', content)),
            'cpf_validations': len(re.findall(r'CPF', content)),
            'cnpj_validations': len(re.findall(r'CNPJ', content))
        }
    
    def _process_cadoc_response(self, content: str) -> Dict[str, Any]:
        """Processa resposta de análise CADOC"""
        return {
            'cadoc_references': len(re.findall(r'CADOC', content)),
            'document_types': len(re.findall(r'Tipo \d+:', content)),
            'cadoc_validations': len(re.findall(r'Validação.*CADOC', content))
        }
    
    def _process_error_handling_response(self, content: str) -> Dict[str, Any]:
        """Processa resposta de análise de tratamento de erros"""
        return {
            'error_types': len(re.findall(r'### Erro', content)),
            'error_codes': len(re.findall(r'Código.*:', content)),
            'recovery_mechanisms': len(re.findall(r'Recuperação', content)),
            'file_status_checks': len(re.findall(r'File.*Status', content))
        }
    
    def _extract_summary(self, content: str) -> str:
        """Extrai resumo da análise"""
        lines = content.split('\n')
        summary_lines = []
        
        for line in lines[:10]:  # Primeiras 10 linhas
            if line.strip() and not line.startswith('#'):
                summary_lines.append(line.strip())
        
        return ' '.join(summary_lines)[:500]  # Máximo 500 caracteres
    
    def _count_items(self, content: str, analysis_type: str) -> int:
        """Conta itens identificados na análise"""
        if analysis_type == "functional_analysis":
            return len(re.findall(r'### Funcionalidade', content))
        elif analysis_type == "business_rules_analysis":
            return len(re.findall(r'### RN-', content))
        elif analysis_type == "validation_analysis":
            return len(re.findall(r'### VAL-', content))
        else:
            return len(re.findall(r'###', content))
    
    def _extract_key_findings(self, content: str, analysis_type: str) -> List[str]:
        """Extrai principais descobertas da análise"""
        findings = []
        
        # Buscar por padrões específicos
        critical_items = re.findall(r'CRÍTICA?[^.]*\.', content)
        high_items = re.findall(r'ALTA?[^.]*\.', content)
        
        findings.extend(critical_items[:3])  # Máximo 3 itens críticos
        findings.extend(high_items[:2])      # Máximo 2 itens de alta prioridade
        
        return findings
    
    def _extract_operations(self, content: str) -> List[str]:
        """Extrai operações principais identificadas"""
        operations = []
        
        # Buscar por operações COBOL
        cobol_ops = re.findall(r'(OPEN|READ|WRITE|CLOSE|COMPUTE|IF|PERFORM|CALL)[^.]*\.', content)
        operations.extend(cobol_ops[:5])  # Máximo 5 operações
        
        return operations
    
    def _extract_detailed_program_info(self, program: Any) -> Dict[str, Any]:
        """Extrai informações detalhadas do programa"""
        lines = program.content.split('\n')
        
        # Análise estatística do código
        total_lines = len(lines)
        code_lines = len([line for line in lines if line.strip() and not line.strip().startswith('*')])
        comment_lines = len([line for line in lines if line.strip().startswith('*')])
        blank_lines = len([line for line in lines if not line.strip()])
        
        # Contagem de elementos COBOL
        if_statements = len(re.findall(r'\bIF\b', program.content, re.IGNORECASE))
        perform_statements = len(re.findall(r'\bPERFORM\b', program.content, re.IGNORECASE))
        compute_statements = len(re.findall(r'\bCOMPUTE\b', program.content, re.IGNORECASE))
        call_statements = len(re.findall(r'\bCALL\b', program.content, re.IGNORECASE))
        
        return {
            'program_id': self._extract_program_id(lines),
            'author': self._extract_author(lines),
            'date_written': self._extract_date_written(lines),
            'purpose': self._extract_purpose(lines),
            'statistics': {
                'total_lines': total_lines,
                'code_lines': code_lines,
                'comment_lines': comment_lines,
                'blank_lines': blank_lines,
                'comment_ratio': comment_lines / total_lines if total_lines > 0 else 0,
                'code_density': code_lines / total_lines if total_lines > 0 else 0
            },
            'cobol_elements': {
                'if_statements': if_statements,
                'perform_statements': perform_statements,
                'compute_statements': compute_statements,
                'call_statements': call_statements
            },
            'complexity_indicators': {
                'cyclomatic_complexity': if_statements + perform_statements + 1,
                'nesting_level': self._calculate_nesting_level(program.content),
                'maintainability_index': self._calculate_maintainability_index(
                    total_lines, if_statements, comment_ratio=comment_lines/total_lines
                )
            },
            'size_metrics': {
                'size_bytes': len(program.content),
                'size_kb': len(program.content) / 1024,
                'estimated_tokens': len(program.content) // 4
            }
        }
    
    def _calculate_nesting_level(self, content: str) -> int:
        """Calcula nível máximo de aninhamento"""
        max_level = 0
        current_level = 0
        
        for line in content.split('\n'):
            line = line.strip().upper()
            if 'IF ' in line:
                current_level += 1
                max_level = max(max_level, current_level)
            elif 'END-IF' in line:
                current_level = max(0, current_level - 1)
        
        return max_level
    
    def _calculate_maintainability_index(self, lines: int, complexity: int, comment_ratio: float) -> float:
        """Calcula índice de manutenibilidade"""
        # Fórmula simplificada baseada em métricas de software
        if lines == 0:
            return 0
        
        volume = lines * 4.7  # Estimativa de volume
        maintainability = 171 - 5.2 * (volume ** 0.23) - 0.23 * complexity - 16.2 * (1 - comment_ratio)
        
        return max(0, min(100, maintainability))
    
    def _get_analysis_costs(self) -> Dict[str, Any]:
        """Obtém custos da análise atual"""
        return self.cost_calculator.get_session_summary()
    
    def _generate_error_analysis(self, program: Any, error: str) -> Dict[str, Any]:
        """Gera análise de erro quando falha"""
        return {
            'program_info': self._extract_detailed_program_info(program),
            'functional_analysis': {'success': False, 'error': error},
            'business_rules_analysis': {'success': False, 'error': error},
            'file_processing_analysis': {'success': False, 'error': error},
            'validation_analysis': {'success': False, 'error': error},
            'cadoc_analysis': {'success': False, 'error': error},
            'error_handling_analysis': {'success': False, 'error': error},
            'cost_summary': {'total_cost_brl': 0.0},
            'analysis_metadata': {
                'timestamp': datetime.now().isoformat(),
                'error': error,
                'status': 'FAILED'
            }
        }
    
    # Métodos auxiliares para extração de informações
    def _extract_program_id(self, lines: List[str]) -> str:
        """Extrai ID do programa"""
        for line in lines:
            if 'PROGRAM-ID' in line.upper():
                parts = line.split('.')
                if len(parts) > 0:
                    return parts[0].split()[-1]
        return "Unknown"
    
    def _extract_author(self, lines: List[str]) -> str:
        """Extrai autor do programa"""
        for line in lines:
            if 'AUTHOR' in line.upper():
                return line.split('AUTHOR')[-1].strip().rstrip('.')
        return "Unknown"
    
    def _extract_date_written(self, lines: List[str]) -> str:
        """Extrai data de criação"""
        for line in lines:
            if 'DATE-WRITTEN' in line.upper():
                return line.split('DATE-WRITTEN')[-1].strip().rstrip('.')
        return "Unknown"
    
    def _extract_purpose(self, lines: List[str]) -> str:
        """Extrai propósito do programa"""
        for line in lines:
            if 'REMARKS' in line.upper() or 'PURPOSE' in line.upper():
                return line.split(':')[-1].strip().rstrip('.')
        return "Not specified"
