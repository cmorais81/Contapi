"""
COBOL AI Engine v2.0.0 - Lineage Mapper
Mapeador de linhagem e sequência de execução para programas COBOL.
"""

import logging
import re
from typing import Dict, List, Set, Any, Optional, Tuple
from datetime import datetime
from dataclasses import dataclass
from collections import defaultdict, deque

try:
    from ..parsers.cobol_parser import CobolProgram, CobolBook
    from .completeness_analyzer import DependencyInfo
except ImportError:
    from parsers.cobol_parser import CobolProgram, CobolBook
    from completeness_analyzer import DependencyInfo


@dataclass
class ExecutionNode:
    """Nó de execução no grafo de linhagem."""
    program_name: str
    node_type: str  # 'PROGRAM', 'COPYBOOK', 'FILE', 'JCL'
    dependencies: List[str]
    dependents: List[str]
    execution_order: Optional[int] = None
    execution_level: Optional[int] = None
    is_entry_point: bool = False
    is_terminal: bool = False


@dataclass
class ExecutionSequence:
    """Sequência de execução identificada."""
    sequence_id: str
    entry_point: str
    execution_path: List[str]
    total_programs: int
    sequence_type: str  # 'LINEAR', 'PARALLEL', 'CONDITIONAL', 'LOOP'
    description: str


class LineageMapper:
    """
    Mapeador de linhagem e sequência de execução para programas COBOL.
    
    Funcionalidades:
    - Análise de dependências entre programas
    - Identificação de sequências de execução
    - Mapeamento de linhagem de dados
    - Detecção de pontos de entrada e saída
    - Análise de fluxo de execução
    """
    
    def __init__(self):
        """Inicializa o mapeador de linhagem."""
        self.logger = logging.getLogger(__name__)
        self.execution_nodes: Dict[str, ExecutionNode] = {}
        self.execution_sequences: List[ExecutionSequence] = []
        self.dependency_graph: Dict[str, List[str]] = defaultdict(list)
        self.reverse_dependency_graph: Dict[str, List[str]] = defaultdict(list)
        self.file_lineage: Dict[str, List[str]] = defaultdict(list)
        self.data_lineage: Dict[str, List[str]] = defaultdict(list)
        
        self.logger.info("Lineage Mapper inicializado")
    
    def build_dependency_graph(self, dependencies: List[DependencyInfo]) -> None:
        """
        Constrói grafo de dependências a partir das informações coletadas.
        
        Args:
            dependencies: Lista de dependências identificadas
        """
        self.logger.info(f"Construindo grafo de dependências com {len(dependencies)} dependências")
        
        # Limpar grafos existentes
        self.dependency_graph.clear()
        self.reverse_dependency_graph.clear()
        self.execution_nodes.clear()
        
        # Coletar todos os programas únicos
        all_programs = set()
        for dep in dependencies:
            all_programs.add(dep.source_program)
            all_programs.add(dep.target_program)
        
        # Inicializar nós de execução
        for program in all_programs:
            self.execution_nodes[program] = ExecutionNode(
                program_name=program,
                node_type=self._determine_node_type(program),
                dependencies=[],
                dependents=[]
            )
        
        # Construir grafos de dependência
        for dep in dependencies:
            source = dep.source_program
            target = dep.target_program
            
            # Grafo direto (quem depende de quem)
            if target not in self.dependency_graph[source]:
                self.dependency_graph[source].append(target)
                self.execution_nodes[source].dependencies.append(target)
            
            # Grafo reverso (quem é dependido por quem)
            if source not in self.reverse_dependency_graph[target]:
                self.reverse_dependency_graph[target].append(source)
                self.execution_nodes[target].dependents.append(source)
            
            # Mapear linhagem de arquivos
            if dep.dependency_type == 'FILE':
                self.file_lineage[source].append(target)
            
            # Mapear linhagem de dados (COPY)
            if dep.dependency_type == 'COPY':
                self.data_lineage[source].append(target)
        
        # Identificar pontos de entrada e saída
        self._identify_entry_and_exit_points()
        
        self.logger.info(f"Grafo construído: {len(all_programs)} programas, {len(dependencies)} dependências")
    
    def _determine_node_type(self, program_name: str) -> str:
        """Determina o tipo do nó baseado no nome do programa."""
        name_upper = program_name.upper()
        
        # Padrões comuns para diferentes tipos
        if any(pattern in name_upper for pattern in ['COPY', 'BOOK', 'INC']):
            return 'COPYBOOK'
        elif any(pattern in name_upper for pattern in ['FILE', 'DATA', 'DAT']):
            return 'FILE'
        elif any(pattern in name_upper for pattern in ['JCL', 'JOB', 'PROC']):
            return 'JCL'
        else:
            return 'PROGRAM'
    
    def _identify_entry_and_exit_points(self) -> None:
        """Identifica pontos de entrada e saída no grafo."""
        for program_name, node in self.execution_nodes.items():
            # Ponto de entrada: não tem dependentes (ninguém chama)
            if not node.dependents and node.node_type == 'PROGRAM':
                node.is_entry_point = True
                self.logger.debug(f"Ponto de entrada identificado: {program_name}")
            
            # Ponto terminal: não tem dependências (não chama ninguém)
            if not node.dependencies and node.node_type == 'PROGRAM':
                node.is_terminal = True
                self.logger.debug(f"Ponto terminal identificado: {program_name}")
    
    def analyze_execution_sequences(self) -> List[ExecutionSequence]:
        """
        Analisa e identifica sequências de execução.
        
        Returns:
            Lista de sequências de execução identificadas
        """
        self.logger.info("Analisando sequências de execução")
        
        self.execution_sequences.clear()
        
        # Encontrar todos os pontos de entrada
        entry_points = [name for name, node in self.execution_nodes.items() 
                       if node.is_entry_point]
        
        if not entry_points:
            # Se não há pontos de entrada claros, usar programas com menos dependentes
            entry_points = self._find_likely_entry_points()
        
        # Analisar sequência a partir de cada ponto de entrada
        for entry_point in entry_points:
            sequences = self._trace_execution_paths(entry_point)
            self.execution_sequences.extend(sequences)
        
        # Calcular ordem de execução
        self._calculate_execution_order()
        
        self.logger.info(f"Identificadas {len(self.execution_sequences)} sequências de execução")
        return self.execution_sequences
    
    def _find_likely_entry_points(self) -> List[str]:
        """Encontra prováveis pontos de entrada quando não há pontos óbvios."""
        # Programas com poucos ou nenhum dependente são prováveis pontos de entrada
        candidates = []
        
        for name, node in self.execution_nodes.items():
            if node.node_type == 'PROGRAM':
                dependent_count = len(node.dependents)
                candidates.append((name, dependent_count))
        
        # Ordenar por número de dependentes (menos dependentes = mais provável entrada)
        candidates.sort(key=lambda x: x[1])
        
        # Retornar até 3 candidatos mais prováveis
        return [name for name, _ in candidates[:3]]
    
    def _trace_execution_paths(self, entry_point: str) -> List[ExecutionSequence]:
        """
        Traça caminhos de execução a partir de um ponto de entrada.
        
        Args:
            entry_point: Nome do programa ponto de entrada
            
        Returns:
            Lista de sequências identificadas
        """
        sequences = []
        visited = set()
        
        def dfs_trace(current: str, path: List[str], sequence_id: str) -> None:
            if current in visited:
                # Detectou loop - criar sequência de loop
                loop_start = path.index(current) if current in path else len(path)
                loop_path = path[loop_start:] + [current]
                
                sequences.append(ExecutionSequence(
                    sequence_id=f"{sequence_id}_LOOP_{len(sequences)}",
                    entry_point=entry_point,
                    execution_path=loop_path,
                    total_programs=len(set(loop_path)),
                    sequence_type='LOOP',
                    description=f"Loop detectado: {' -> '.join(loop_path)}"
                ))
                return
            
            visited.add(current)
            current_path = path + [current]
            
            node = self.execution_nodes.get(current)
            if not node or not node.dependencies:
                # Fim do caminho - criar sequência linear
                sequences.append(ExecutionSequence(
                    sequence_id=f"{sequence_id}_LINEAR_{len(sequences)}",
                    entry_point=entry_point,
                    execution_path=current_path,
                    total_programs=len(current_path),
                    sequence_type='LINEAR',
                    description=f"Sequência linear: {' -> '.join(current_path)}"
                ))
                return
            
            # Verificar se há múltiplas dependências (execução paralela/condicional)
            if len(node.dependencies) > 1:
                # Execução paralela ou condicional
                for dep in node.dependencies:
                    dfs_trace(dep, current_path, sequence_id)
                
                sequences.append(ExecutionSequence(
                    sequence_id=f"{sequence_id}_PARALLEL_{len(sequences)}",
                    entry_point=entry_point,
                    execution_path=current_path + node.dependencies,
                    total_programs=len(current_path) + len(node.dependencies),
                    sequence_type='PARALLEL',
                    description=f"Execução paralela de {current}: {', '.join(node.dependencies)}"
                ))
            else:
                # Continuar sequência linear
                dfs_trace(node.dependencies[0], current_path, sequence_id)
        
        # Iniciar rastreamento
        sequence_id = f"SEQ_{entry_point}"
        dfs_trace(entry_point, [], sequence_id)
        
        return sequences
    
    def _calculate_execution_order(self) -> None:
        """Calcula ordem de execução usando ordenação topológica."""
        # Implementar ordenação topológica (Kahn's algorithm)
        in_degree = defaultdict(int)
        
        # Calcular grau de entrada para cada nó
        for source, targets in self.dependency_graph.items():
            for target in targets:
                in_degree[target] += 1
        
        # Inicializar fila com nós sem dependências
        queue = deque()
        for name, node in self.execution_nodes.items():
            if in_degree[name] == 0 and node.node_type == 'PROGRAM':
                queue.append(name)
                node.execution_order = 0
                node.execution_level = 0
        
        order = 0
        level = 0
        
        while queue:
            level_size = len(queue)
            
            for _ in range(level_size):
                current = queue.popleft()
                current_node = self.execution_nodes[current]
                current_node.execution_order = order
                current_node.execution_level = level
                order += 1
                
                # Processar dependências
                for dependency in self.dependency_graph[current]:
                    in_degree[dependency] -= 1
                    if in_degree[dependency] == 0:
                        queue.append(dependency)
            
            level += 1
    
    def get_execution_flow_report(self) -> Dict[str, Any]:
        """
        Gera relatório completo do fluxo de execução.
        
        Returns:
            Dicionário com relatório detalhado
        """
        entry_points = [name for name, node in self.execution_nodes.items() 
                       if node.is_entry_point]
        terminal_points = [name for name, node in self.execution_nodes.items() 
                          if node.is_terminal]
        
        # Estatísticas por tipo de nó
        node_type_stats = defaultdict(int)
        for node in self.execution_nodes.values():
            node_type_stats[node.node_type] += 1
        
        # Análise de complexidade
        max_dependencies = max(len(node.dependencies) for node in self.execution_nodes.values())
        avg_dependencies = sum(len(node.dependencies) for node in self.execution_nodes.values()) / len(self.execution_nodes)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'summary': {
                'total_programs': len(self.execution_nodes),
                'total_sequences': len(self.execution_sequences),
                'entry_points': len(entry_points),
                'terminal_points': len(terminal_points),
                'total_dependencies': sum(len(deps) for deps in self.dependency_graph.values()),
                'max_dependencies_per_program': max_dependencies,
                'avg_dependencies_per_program': round(avg_dependencies, 2)
            },
            'entry_points': entry_points,
            'terminal_points': terminal_points,
            'node_type_distribution': dict(node_type_stats),
            'execution_sequences': [
                {
                    'sequence_id': seq.sequence_id,
                    'entry_point': seq.entry_point,
                    'execution_path': seq.execution_path,
                    'total_programs': seq.total_programs,
                    'sequence_type': seq.sequence_type,
                    'description': seq.description
                }
                for seq in self.execution_sequences
            ],
            'execution_nodes': {
                name: {
                    'node_type': node.node_type,
                    'dependencies': node.dependencies,
                    'dependents': node.dependents,
                    'execution_order': node.execution_order,
                    'execution_level': node.execution_level,
                    'is_entry_point': node.is_entry_point,
                    'is_terminal': node.is_terminal
                }
                for name, node in self.execution_nodes.items()
            },
            'file_lineage': dict(self.file_lineage),
            'data_lineage': dict(self.data_lineage)
        }
    
    def get_program_execution_order(self) -> List[Tuple[str, int, int]]:
        """
        Retorna ordem de execução dos programas.
        
        Returns:
            Lista de tuplas (programa, ordem, nível)
        """
        programs_with_order = []
        
        for name, node in self.execution_nodes.items():
            if node.node_type == 'PROGRAM' and node.execution_order is not None:
                programs_with_order.append((name, node.execution_order, node.execution_level))
        
        # Ordenar por ordem de execução
        programs_with_order.sort(key=lambda x: x[1])
        
        return programs_with_order
    
    def get_critical_path(self) -> List[str]:
        """
        Identifica o caminho crítico (sequência mais longa) de execução.
        
        Returns:
            Lista de programas no caminho crítico
        """
        if not self.execution_sequences:
            return []
        
        # Encontrar sequência mais longa
        longest_sequence = max(self.execution_sequences, key=lambda x: x.total_programs)
        
        return longest_sequence.execution_path
    
    def get_parallel_execution_opportunities(self) -> List[Dict[str, Any]]:
        """
        Identifica oportunidades de execução paralela.
        
        Returns:
            Lista de oportunidades de paralelização
        """
        opportunities = []
        
        # Agrupar programas por nível de execução
        level_groups = defaultdict(list)
        for name, node in self.execution_nodes.items():
            if node.node_type == 'PROGRAM' and node.execution_level is not None:
                level_groups[node.execution_level].append(name)
        
        # Identificar níveis com múltiplos programas (podem ser executados em paralelo)
        for level, programs in level_groups.items():
            if len(programs) > 1:
                opportunities.append({
                    'execution_level': level,
                    'parallel_programs': programs,
                    'parallelization_factor': len(programs),
                    'description': f"Nível {level}: {len(programs)} programas podem ser executados em paralelo"
                })
        
        return opportunities
    
    def validate_execution_completeness(self, expected_programs: List[str]) -> Dict[str, Any]:
        """
        Valida se todos os programas esperados estão no fluxo de execução.
        
        Args:
            expected_programs: Lista de programas esperados
            
        Returns:
            Relatório de validação
        """
        mapped_programs = set(self.execution_nodes.keys())
        expected_set = set(expected_programs)
        
        missing_from_flow = expected_set - mapped_programs
        extra_in_flow = mapped_programs - expected_set
        
        # Verificar se todos os programas têm ordem de execução
        programs_without_order = [
            name for name, node in self.execution_nodes.items()
            if node.node_type == 'PROGRAM' and node.execution_order is None
        ]
        
        return {
            'validation_timestamp': datetime.now().isoformat(),
            'expected_programs': len(expected_programs),
            'mapped_programs': len(mapped_programs),
            'missing_from_flow': list(missing_from_flow),
            'extra_in_flow': list(extra_in_flow),
            'programs_without_order': programs_without_order,
            'completeness_percentage': ((len(expected_set & mapped_programs) / len(expected_set)) * 100) if expected_set else 100,
            'validation_passed': len(missing_from_flow) == 0 and len(programs_without_order) == 0
        }

