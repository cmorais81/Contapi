"""
Expert Level COBOL Analyzer v3.0 - CORRIGIDO
Analisador de nível especialista baseado nos exemplos do especialista sênior.
"""

import logging
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

from ..prompts.expert_level_prompts import ExpertLevelPrompts
from ..providers.enhanced_provider_manager import EnhancedProviderManager
from ..providers.base_provider import AIRequest, AIResponse
from ..rag.rag_integration_enhanced import EnhancedRAGIntegration
from ..parsers.cobol_program import CobolProgram


@dataclass
class ExpertAnalysisResult:
    """Resultado da análise de nível especialista."""
    program_name: str
    detailed_analysis: str
    business_rules: str
    file_processing: str
    validations: str
    cadoc_analysis: str
    error_handling: str
    success: bool = True
    tokens_used: int = 0
    analysis_time: float = 0.0
    model_used: str = ""
    error_message: str = ""


class ExpertLevelAnalyzer:
    """Analisador COBOL de nível especialista."""
    
    def __init__(self, provider_manager: EnhancedProviderManager, rag_system: EnhancedRAGIntegration = None):
        """
        Inicializa o analisador especialista.
        
        Args:
            provider_manager: Gerenciador de providers de IA
            rag_system: Sistema RAG para enriquecimento contextual
        """
        self.logger = logging.getLogger(__name__)
        self.provider_manager = provider_manager
        self.rag_system = rag_system
        self.prompts = ExpertLevelPrompts()
        
        # Configurações de análise
        self.analysis_config = {
            'temperature': 0.05,  # Máxima precisão técnica
            'max_tokens': 12000,  # Análises detalhadas
            'timeout': 180.0      # Tempo suficiente para análises profundas
        }
    
    def analyze_program_expert_level(
        self, 
        program: CobolProgram, 
        model_name: str = 'luzia'
    ) -> ExpertAnalysisResult:
        """
        Realiza análise completa de nível especialista de um programa COBOL.
        
        Args:
            program: Programa COBOL a ser analisado
            model_name: Modelo de IA a ser usado
            
        Returns:
            ExpertAnalysisResult: Resultado da análise especialista
        """
        start_time = time.time()
        
        try:
            self.logger.info(f"Iniciando análise de nível especialista para {program.name}")
            
            # Análise principal consolidada (em vez de 6 separadas)
            analysis_result = self._perform_consolidated_expert_analysis(program, model_name)
            
            # Calcular métricas
            total_time = time.time() - start_time
            
            # Adicionar conhecimento ao RAG
            if self.rag_system and analysis_result.success:
                self._add_analysis_to_rag(program, analysis_result.content)
            
            self.logger.info(f"Análise especialista concluída para {program.name} - {analysis_result.tokens_used} tokens em {total_time:.2f}s")
            
            return ExpertAnalysisResult(
                program_name=program.name,
                detailed_analysis=analysis_result.content,
                business_rules="Incluído na análise principal",
                file_processing="Incluído na análise principal",
                validations="Incluído na análise principal",
                cadoc_analysis="Incluído na análise principal",
                error_handling="Incluído na análise principal",
                success=analysis_result.success,
                tokens_used=analysis_result.tokens_used,
                analysis_time=total_time,
                model_used=analysis_result.model,
                error_message=analysis_result.error_message if not analysis_result.success else ""
            )
            
        except Exception as e:
            error_msg = f"Erro na análise especialista de {program.name}: {str(e)}"
            self.logger.error(error_msg)
            
            return ExpertAnalysisResult(
                program_name=program.name,
                detailed_analysis="",
                business_rules="",
                file_processing="",
                validations="",
                cadoc_analysis="",
                error_handling="",
                success=False,
                error_message=error_msg,
                analysis_time=time.time() - start_time
            )
    
    def _perform_consolidated_expert_analysis(self, program: CobolProgram, model_name: str) -> AIResponse:
        """Realiza análise consolidada de nível especialista."""
        self.logger.info(f"Executando análise consolidada especialista para {program.name}")
        
        # Obter contexto RAG
        rag_context = ""
        if self.rag_system:
            try:
                search_result = self.rag_system.search_knowledge_base(
                    f"análise COBOL programa {program.name} bancário",
                    max_results=5
                )
                if search_result.get('success') and search_result.get('results'):
                    rag_items = []
                    for result in search_result['results']:
                        rag_items.append(f"**{result.get('category', 'Conhecimento')}**: {result.get('content', '')[:300]}...")
                    rag_context = "\n".join(rag_items)
                    self.logger.info(f"Contexto RAG obtido: {len(rag_items)} itens")
            except Exception as e:
                self.logger.warning(f"Erro ao obter contexto RAG: {e}")
                rag_context = ""
        
        # Criar prompt especializado consolidado
        prompt = self.prompts.get_consolidated_expert_prompt().format(
            rag_context=rag_context if rag_context else "Nenhum conhecimento prévio disponível."
        )
        
        # Criar request
        request = AIRequest(
            prompt=prompt,
            program_name=program.name,
            program_code=program.content,
            context={'analysis_type': 'consolidated_expert'},
            temperature=self.analysis_config['temperature'],
            max_tokens=self.analysis_config['max_tokens']
        )
        
        # Executar análise
        try:
            response, model_used = self.provider_manager.analyze_with_model(request, model_name)
        except Exception as e:
            self.logger.error(f"Erro na chamada do provider: {str(e)}")
            # Retornar resposta de erro
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=model_name,
                provider=model_name,
                error_message=str(e)
            )
        
        if response.success:
            self.logger.info(f"Análise consolidada concluída - {response.tokens_used} tokens")
        else:
            self.logger.error(f"Falha na análise consolidada: {response.error_message}")
        
        return response
    
    def _add_analysis_to_rag(self, program: CobolProgram, analysis_content: str):
        """Adiciona resultados da análise à base RAG."""
        try:
            if not self.rag_system:
                return
            
            # Adicionar conhecimento da análise à base RAG
            self.rag_system.add_analysis_knowledge(
                program.name,
                analysis_content[:1000],  # Primeiros 1000 caracteres
                'expert_analysis',
                {'domain': 'cobol_banking', 'analysis_type': 'expert_level'}
            )
            
            self.logger.info(f"Conhecimento de {program.name} adicionado à base RAG")
            
        except Exception as e:
            self.logger.error(f"Erro ao adicionar conhecimento ao RAG: {str(e)}")
    
    def estimate_analysis_cost(self, program: CobolProgram, model_name: str = 'luzia') -> Dict[str, Any]:
        """Estima o custo da análise especialista."""
        try:
            # Estimar tokens
            base_tokens = len(program.content.split()) * 1.5  # Código do programa
            estimated_tokens = base_tokens + 5000  # Análise consolidada
            
            # Obter estimativa de custo do provider
            sample_request = AIRequest(
                prompt="Sample prompt for cost estimation",
                program_name=program.name,
                program_code=program.content[:1000],  # Amostra do código
                max_tokens=estimated_tokens
            )
            
            cost_estimate = self.provider_manager.estimate_costs(sample_request, model_name)
            
            return {
                'program_name': program.name,
                'model': model_name,
                'estimated_tokens': estimated_tokens,
                'cost_estimate': cost_estimate,
                'analysis_type': 'consolidated_expert',
                'estimated_time_minutes': estimated_tokens / 1000 * 0.3
            }
            
        except Exception as e:
            return {
                'error': f'Erro ao estimar custos: {str(e)}',
                'program_name': program.name
            }
