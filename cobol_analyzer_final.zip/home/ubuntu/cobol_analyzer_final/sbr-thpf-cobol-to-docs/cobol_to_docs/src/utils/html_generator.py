"""
HTML Generator Melhorado - COBOL AI Engine v2.0.0
Gerador de HTML com CSS profissional otimizado para conversão PDF
"""

import os
import re
import logging
from datetime import datetime
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class HTMLReportGenerator:
    """Gerador de relatórios HTML com formatação profissional para PDF."""
    
    def __init__(self):
        """Inicializa o gerador."""
        self.css_styles = self._get_professional_css()
    
    def _get_professional_css(self) -> str:
        """Retorna CSS profissional otimizado para PDF."""
        return """
        <style>
        /* ===== RESET E CONFIGURAÇÕES BÁSICAS ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        html {
            font-size: 12pt;
            line-height: 1.4;
        }
        
        body {
            font-family: 'Segoe UI', 'Arial', 'Helvetica', sans-serif;
            color: #2c3e50;
            background: white;
            max-width: 210mm;
            margin: 0 auto;
            padding: 20mm 15mm;
            counter-reset: page-counter;
        }
        
        /* ===== CONFIGURAÇÕES PARA IMPRESSÃO/PDF ===== */
        @media print {
            html {
                font-size: 10pt;
            }
            
            body {
                margin: 0;
                padding: 15mm 12mm;
                max-width: none;
            }
            
            .page-break {
                page-break-before: always;
            }
            
            .page-break-avoid {
                page-break-inside: avoid;
            }
            
            .no-print {
                display: none !important;
            }
            
            h1, h2, h3, h4 {
                page-break-after: avoid;
                page-break-inside: avoid;
            }
            
            pre, .code-block {
                page-break-inside: avoid;
                break-inside: avoid;
            }
            
            table {
                page-break-inside: avoid;
            }
            
            .section {
                page-break-inside: avoid;
            }
            
            /* Cabeçalho e rodapé para PDF */
            @page {
                margin: 20mm 15mm 25mm 15mm;
                
                @top-center {
                    content: "COBOL AI Engine - Análise de Sistema";
                    font-size: 9pt;
                    color: #7f8c8d;
                    border-bottom: 1px solid #ecf0f1;
                    padding-bottom: 5mm;
                }
                
                @bottom-right {
                    content: "Página " counter(page);
                    font-size: 9pt;
                    color: #7f8c8d;
                }
                
                @bottom-left {
                    content: "Gerado em " attr(data-date);
                    font-size: 9pt;
                    color: #7f8c8d;
                }
            }
        }
        
        /* ===== TIPOGRAFIA PROFISSIONAL ===== */
        h1 {
            color: #1a365d;
            font-size: 2.2em;
            font-weight: 700;
            margin-bottom: 0.8em;
            margin-top: 0.5em;
            padding: 0.5em 0;
            border-bottom: 4px solid #3182ce;
            text-align: center;
            background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%);
            border-radius: 8px;
            padding: 1em;
        }
        
        h2 {
            color: #2d3748;
            font-size: 1.6em;
            font-weight: 600;
            margin-top: 2em;
            margin-bottom: 1em;
            padding: 0.5em 0 0.3em 0;
            border-bottom: 2px solid #e2e8f0;
            border-left: 4px solid #4299e1;
            padding-left: 1em;
            background: #f7fafc;
            border-radius: 4px;
        }
        
        h3 {
            color: #2d3748;
            font-size: 1.3em;
            font-weight: 600;
            margin-top: 1.5em;
            margin-bottom: 0.8em;
            padding: 0.3em 0;
            border-bottom: 1px solid #cbd5e0;
        }
        
        h4 {
            color: #4a5568;
            font-size: 1.1em;
            font-weight: 600;
            margin-top: 1.2em;
            margin-bottom: 0.6em;
        }
        
        h5, h6 {
            color: #4a5568;
            font-size: 1em;
            font-weight: 600;
            margin-top: 1em;
            margin-bottom: 0.5em;
        }
        
        /* ===== PARÁGRAFOS E TEXTO ===== */
        p {
            margin-bottom: 1em;
            text-align: justify;
            hyphens: auto;
        }
        
        .lead {
            font-size: 1.1em;
            font-weight: 400;
            color: #4a5568;
            margin-bottom: 1.5em;
        }
        
        /* ===== LISTAS ===== */
        ul, ol {
            margin: 1em 0;
            padding-left: 2em;
        }
        
        li {
            margin-bottom: 0.5em;
            line-height: 1.5;
        }
        
        ul li {
            list-style-type: disc;
        }
        
        ol li {
            list-style-type: decimal;
        }
        
        /* ===== CÓDIGO E PRÉ-FORMATADO ===== */
        code {
            background: #f1f5f9;
            color: #1e293b;
            padding: 0.2em 0.4em;
            border-radius: 3px;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 0.9em;
            border: 1px solid #e2e8f0;
        }
        
        pre {
            background: #1a202c;
            color: #e2e8f0;
            padding: 1.5em;
            border-radius: 8px;
            overflow-x: auto;
            margin: 1.5em 0;
            font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
            font-size: 0.85em;
            line-height: 1.4;
            border: 1px solid #2d3748;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        pre code {
            background: none;
            color: inherit;
            padding: 0;
            border: none;
            border-radius: 0;
        }
        
        /* ===== TABELAS PROFISSIONAIS ===== */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 1.5em 0;
            background: white;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        
        th {
            background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
            color: white;
            font-weight: 600;
            padding: 1em 0.8em;
            text-align: left;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        td {
            padding: 0.8em;
            border-bottom: 1px solid #e2e8f0;
            vertical-align: top;
        }
        
        tr:nth-child(even) {
            background: #f7fafc;
        }
        
        tr:hover {
            background: #edf2f7;
        }
        
        /* ===== BLOCKQUOTES ===== */
        blockquote {
            background: #f7fafc;
            border-left: 4px solid #4299e1;
            padding: 1em 1.5em;
            margin: 1.5em 0;
            font-style: italic;
            color: #4a5568;
            border-radius: 0 8px 8px 0;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        
        blockquote p:last-child {
            margin-bottom: 0;
        }
        
        /* ===== SEÇÕES ESPECIAIS ===== */
        .section {
            margin: 2em 0;
            padding: 1.5em;
            border-radius: 8px;
            background: #f7fafc;
            border: 1px solid #e2e8f0;
        }
        
        .highlight {
            background: #fef5e7;
            border: 1px solid #f6ad55;
            border-radius: 6px;
            padding: 1em;
            margin: 1em 0;
        }
        
        .warning {
            background: #fed7d7;
            border: 1px solid #fc8181;
            border-radius: 6px;
            padding: 1em;
            margin: 1em 0;
        }
        
        .info {
            background: #e6fffa;
            border: 1px solid #4fd1c7;
            border-radius: 6px;
            padding: 1em;
            margin: 1em 0;
        }
        
        .success {
            background: #f0fff4;
            border: 1px solid #68d391;
            border-radius: 6px;
            padding: 1em;
            margin: 1em 0;
        }
        
        /* ===== METADADOS E INFORMAÇÕES ===== */
        .metadata {
            background: #edf2f7;
            border: 1px solid #cbd5e0;
            border-radius: 8px;
            padding: 1.5em;
            margin: 2em 0;
            font-size: 0.9em;
        }
        
        .metadata h4 {
            color: #2d3748;
            margin-top: 0;
            margin-bottom: 1em;
            border-bottom: 1px solid #cbd5e0;
            padding-bottom: 0.5em;
        }
        
        .metadata table {
            margin: 0;
            box-shadow: none;
        }
        
        .metadata th {
            background: #cbd5e0;
            color: #2d3748;
        }
        
        /* ===== LINKS ===== */
        a {
            color: #3182ce;
            text-decoration: none;
            border-bottom: 1px dotted #3182ce;
        }
        
        a:hover {
            color: #2c5282;
            border-bottom: 1px solid #2c5282;
        }
        
        /* ===== UTILITÁRIOS ===== */
        .text-center {
            text-align: center;
        }
        
        .text-right {
            text-align: right;
        }
        
        .text-small {
            font-size: 0.85em;
            color: #718096;
        }
        
        .text-muted {
            color: #718096;
        }
        
        .mb-large {
            margin-bottom: 2em;
        }
        
        .mt-large {
            margin-top: 2em;
        }
        
        /* ===== CABEÇALHO DO DOCUMENTO ===== */
        .document-header {
            text-align: center;
            margin-bottom: 3em;
            padding: 2em;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }
        
        .document-header h1 {
            color: white;
            border: none;
            background: none;
            margin: 0;
            padding: 0;
        }
        
        .document-header .subtitle {
            font-size: 1.1em;
            opacity: 0.9;
            margin-top: 0.5em;
        }
        
        .document-header .date {
            font-size: 0.9em;
            opacity: 0.8;
            margin-top: 1em;
        }
        
        /* ===== RODAPÉ ===== */
        .document-footer {
            margin-top: 4em;
            padding-top: 2em;
            border-top: 2px solid #e2e8f0;
            text-align: center;
            color: #718096;
            font-size: 0.9em;
        }
        
        /* ===== RESPONSIVIDADE ===== */
        @media screen and (max-width: 768px) {
            body {
                padding: 1em;
            }
            
            h1 {
                font-size: 1.8em;
            }
            
            h2 {
                font-size: 1.4em;
            }
            
            table {
                font-size: 0.8em;
            }
            
            pre {
                font-size: 0.75em;
                padding: 1em;
            }
        }
        
        /* ===== MELHORIAS PARA COBOL ===== */
        .cobol-code {
            background: #0d1117;
            color: #c9d1d9;
            border: 1px solid #30363d;
        }
        
        .cobol-division {
            color: #ff7b72;
            font-weight: bold;
        }
        
        .cobol-section {
            color: #79c0ff;
            font-weight: bold;
        }
        
        .cobol-keyword {
            color: #ff7b72;
        }
        
        .cobol-comment {
            color: #8b949e;
            font-style: italic;
        }
        
        .analysis-summary {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            border: 1px solid #0ea5e9;
            border-radius: 12px;
            padding: 2em;
            margin: 2em 0;
        }
        
        .analysis-summary h3 {
            color: #0c4a6e;
            margin-top: 0;
        }
        </style>
        """
    
    def _convert_markdown_to_html(self, markdown_content: str) -> str:
        """Converte Markdown para HTML com formatação melhorada."""
        html = markdown_content
        
        # Converter cabeçalhos
        html = re.sub(r'^# (.+)$', r'<h1>\1</h1>', html, flags=re.MULTILINE)
        html = re.sub(r'^## (.+)$', r'<h2>\1</h2>', html, flags=re.MULTILINE)
        html = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html, flags=re.MULTILINE)
        html = re.sub(r'^#### (.+)$', r'<h4>\1</h4>', html, flags=re.MULTILINE)
        html = re.sub(r'^##### (.+)$', r'<h5>\1</h5>', html, flags=re.MULTILINE)
        
        # Converter texto em negrito e itálico
        html = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html)
        html = re.sub(r'\*(.+?)\*', r'<em>\1</em>', html)
        
        # Converter código inline
        html = re.sub(r'`([^`]+)`', r'<code>\1</code>', html)
        
        # Converter blocos de código
        html = re.sub(r'```(\w+)?\n(.*?)\n```', 
                     lambda m: f'<pre class="cobol-code" data-language="{m.group(1) or ""}"><code>{self._highlight_cobol(m.group(2))}</code></pre>', 
                     html, flags=re.DOTALL)
        
        # Converter listas
        html = re.sub(r'^- (.+)$', r'<li>\1</li>', html, flags=re.MULTILINE)
        html = re.sub(r'^(\d+)\. (.+)$', r'<li>\2</li>', html, flags=re.MULTILINE)
        
        # Agrupar itens de lista
        html = re.sub(r'(<li>.*?</li>)', r'<ul>\1</ul>', html, flags=re.DOTALL)
        html = re.sub(r'</ul>\s*<ul>', '', html)
        
        # Converter links
        html = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'<a href="\2">\1</a>', html)
        
        # Converter parágrafos
        paragraphs = html.split('\n\n')
        html_paragraphs = []
        
        for para in paragraphs:
            para = para.strip()
            if para and not para.startswith('<'):
                para = f'<p>{para}</p>'
            html_paragraphs.append(para)
        
        html = '\n\n'.join(html_paragraphs)
        
        # Converter tabelas
        html = self._convert_tables(html)
        
        # Converter blockquotes
        html = re.sub(r'^> (.+)$', r'<blockquote><p>\1</p></blockquote>', html, flags=re.MULTILINE)
        
        return html
    
    def _highlight_cobol(self, code: str) -> str:
        """Aplica syntax highlighting básico para COBOL."""
        # Destacar divisões
        code = re.sub(r'\b(IDENTIFICATION|ENVIRONMENT|DATA|PROCEDURE)\s+DIVISION\b', 
                     r'<span class="cobol-division">\1 DIVISION</span>', code)
        
        # Destacar seções
        code = re.sub(r'\b(WORKING-STORAGE|FILE|LINKAGE)\s+SECTION\b', 
                     r'<span class="cobol-section">\1 SECTION</span>', code)
        
        # Destacar palavras-chave
        keywords = ['PROGRAM-ID', 'AUTHOR', 'PIC', 'VALUE', 'DISPLAY', 'MOVE', 'COMPUTE', 
                   'PERFORM', 'IF', 'ELSE', 'END-IF', 'STOP', 'RUN', 'ACCEPT', 'ADD', 
                   'SUBTRACT', 'MULTIPLY', 'DIVIDE', 'CALL', 'COPY', 'INCLUDE']
        
        for keyword in keywords:
            code = re.sub(rf'\b{keyword}\b', f'<span class="cobol-keyword">{keyword}</span>', code)
        
        # Destacar comentários
        code = re.sub(r'(\*.*$)', r'<span class="cobol-comment">\1</span>', code, flags=re.MULTILINE)
        
        return code
    
    def _convert_tables(self, html: str) -> str:
        """Converte tabelas Markdown para HTML."""
        lines = html.split('\n')
        in_table = False
        table_html = []
        result_lines = []
        
        for line in lines:
            if '|' in line and not in_table:
                # Início de tabela
                in_table = True
                table_html = ['<table>']
                headers = [cell.strip() for cell in line.split('|')[1:-1]]
                table_html.append('<thead><tr>')
                for header in headers:
                    table_html.append(f'<th>{header}</th>')
                table_html.append('</tr></thead><tbody>')
            elif '|' in line and in_table:
                if '---' in line:
                    # Linha separadora, ignorar
                    continue
                # Linha de dados
                cells = [cell.strip() for cell in line.split('|')[1:-1]]
                table_html.append('<tr>')
                for cell in cells:
                    table_html.append(f'<td>{cell}</td>')
                table_html.append('</tr>')
            elif in_table and '|' not in line:
                # Fim da tabela
                table_html.append('</tbody></table>')
                result_lines.append('\n'.join(table_html))
                table_html = []
                in_table = False
                result_lines.append(line)
            else:
                result_lines.append(line)
        
        # Se ainda estiver em uma tabela no final
        if in_table:
            table_html.append('</tbody></table>')
            result_lines.append('\n'.join(table_html))
        
        return '\n'.join(result_lines)
    
    def generate_html_report(self, markdown_file: str, output_dir: str) -> str:
        """Gera relatório HTML a partir de arquivo Markdown."""
        try:
            # Ler arquivo Markdown
            with open(markdown_file, 'r', encoding='utf-8') as f:
                markdown_content = f.read()
            
            # Converter para HTML
            html_content = self._convert_markdown_to_html(markdown_content)
            
            # Extrair título do documento
            title_match = re.search(r'^# (.+)$', markdown_content, re.MULTILINE)
            title = title_match.group(1) if title_match else "Análise COBOL"
            
            # Gerar HTML completo
            full_html = self._generate_complete_html(html_content, title)
            
            # Salvar arquivo HTML
            base_name = os.path.splitext(os.path.basename(markdown_file))[0]
            html_file = os.path.join(output_dir, f"{base_name}.html")
            
            with open(html_file, 'w', encoding='utf-8') as f:
                f.write(full_html)
            
            logger.info(f"Relatório HTML gerado: {html_file}")
            return html_file
            
        except Exception as e:
            logger.error(f"Erro ao gerar HTML para {markdown_file}: {e}")
            return None
    
    def _generate_complete_html(self, content: str, title: str) -> str:
        """Gera HTML completo com cabeçalho e estrutura."""
        current_date = datetime.now().strftime("%d/%m/%Y às %H:%M:%S")
        
        return f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - COBOL AI Engine</title>
    {self.css_styles}
</head>
<body data-date="{current_date}">
    <div class="document-header">
        <h1>{title}</h1>
        <div class="subtitle">Análise Automatizada de Sistema COBOL</div>
        <div class="date">Gerado em {current_date}</div>
    </div>
    
    <div class="document-content">
        {content}
    </div>
    
    <div class="document-footer">
        <p>Relatório gerado pelo <strong>COBOL AI Engine v2.0.0</strong></p>
        <p class="text-small">Sistema de Análise Automatizada de Programas COBOL</p>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {{
            const elements = document.querySelectorAll('h1, h2, h3, pre, table, .section');
            elements.forEach(el => el.classList.add('page-break-avoid'));
            
            const h2Elements = document.querySelectorAll('h2');
            h2Elements.forEach((el, index) => {{
                if (index > 0) el.classList.add('page-break');
            }});
        }});
    </script>
</body>
</html>"""
    
    def generate_html_reports(self, output_dir: str) -> List[str]:
        """Gera relatórios HTML para todos os arquivos Markdown no diretório."""
        html_files = []
        
        try:
            # Procurar arquivos Markdown
            for root, dirs, files in os.walk(output_dir):
                for file in files:
                    if file.endswith('.md'):
                        markdown_file = os.path.join(root, file)
                        html_file = self.generate_html_report(markdown_file, root)
                        if html_file:
                            html_files.append(html_file)
            
            logger.info(f"Gerados {len(html_files)} relatórios HTML")
            return html_files
            
        except Exception as e:
            logger.error(f"Erro ao gerar relatórios HTML: {e}")
            return []
