"""
COBOL to Docs v1.1 - COBOL Preprocessor
Utilitários para preprocessamento de código COBOL.
"""

import re
import logging
from typing import List, Tuple


class COBOLPreprocessor:
    """
    Preprocessador de código COBOL para diferentes tipos de análise.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def has_comments(self, cobol_code: str) -> bool:
        """
        Verifica se o código COBOL tem comentários significativos.
        
        Args:
            cobol_code: Código COBOL
            
        Returns:
            True se tem comentários, False caso contrário
        """
        lines = cobol_code.split('\n')
        comment_count = 0
        
        for line in lines:
            # Verificar se é linha de comentário (formato V      * ou similar)
            if len(line) >= 8 and line[7] == '*':
                # Ignorar linhas de separação (só asteriscos ou traços)
                content = line[8:].strip()
                if content and not all(c in '*-=+' for c in content):
                    comment_count += 1
            # Verificar formato alternativo (coluna 7 = *)
            elif len(line) >= 7 and line[6] == '*':
                # Ignorar linhas de separação (só asteriscos ou traços)
                content = line[7:].strip()
                if content and not all(c in '*-=+' for c in content):
                    comment_count += 1
        
        # Considera que tem comentários se há mais de 5 linhas de comentário real
        return comment_count > 5
    
    def remove_comments(self, cobol_code: str) -> Tuple[str, int]:
        """
        Remove todos os comentários do código COBOL.
        
        Args:
            cobol_code: Código COBOL original
            
        Returns:
            Tuple com (código_sem_comentários, quantidade_linhas_removidas)
        """
        lines = cobol_code.split('\n')
        clean_lines = []
        removed_count = 0
        
        for line in lines:
            # Verificar se é linha de comentário (formato V      * ou similar)
            if len(line) >= 8 and line[7] == '*':
                removed_count += 1
                continue
            # Verificar formato alternativo (coluna 7 = *)
            elif len(line) >= 7 and line[6] == '*':
                removed_count += 1
                continue
            
            # Verificar se é linha em branco
            if line.strip() == '':
                continue
                
            # Verificar comentários inline (após código)
            # Manter apenas a parte do código
            if len(line) > 72:
                line = line[:72]  # COBOL padrão até coluna 72
            
            clean_lines.append(line)
        
        self.logger.info(f"Removidos {removed_count} comentários do código COBOL")
        return '\n'.join(clean_lines), removed_count
    
    def extract_procedure_division(self, cobol_code: str) -> str:
        """
        Extrai apenas a PROCEDURE DIVISION do código COBOL.
        
        Args:
            cobol_code: Código COBOL completo
            
        Returns:
            String contendo apenas a PROCEDURE DIVISION
        """
        lines = cobol_code.split('\n')
        procedure_lines = []
        in_procedure = False
        
        for line in lines:
            # Detectar início da PROCEDURE DIVISION
            if 'PROCEDURE DIVISION' in line.upper():
                in_procedure = True
                procedure_lines.append(line)
                continue
            
            # Se estamos na PROCEDURE DIVISION, adicionar linha
            if in_procedure:
                procedure_lines.append(line)
        
        result = '\n'.join(procedure_lines)
        self.logger.info(f"Extraída PROCEDURE DIVISION com {len(procedure_lines)} linhas")
        return result
    
    def detect_copybooks(self, cobol_code: str) -> List[str]:
        """
        Detecta todos os copybooks referenciados no código.
        
        Args:
            cobol_code: Código COBOL
            
        Returns:
            Lista de nomes de copybooks encontrados
        """
        copybooks = []
        
        # Padrões para detectar copybooks
        patterns = [
            r'COPY\s+([A-Z0-9\-_]+)',
            r'\+\+INCLUDE\s+([A-Z0-9\-_]+)',
            r'COPY\s+"([^"]+)"',
            r'COPY\s+\'([^\']+)\''
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, cobol_code, re.IGNORECASE)
            copybooks.extend(matches)
        
        # Remover duplicatas e ordenar
        unique_copybooks = sorted(list(set(copybooks)))
        
        self.logger.info(f"Detectados {len(unique_copybooks)} copybooks: {unique_copybooks}")
        return unique_copybooks
    
    def extract_paragraphs(self, cobol_code: str) -> List[dict]:
        """
        Extrai todos os parágrafos da PROCEDURE DIVISION.
        
        Args:
            cobol_code: Código COBOL
            
        Returns:
            Lista de dicionários com informações dos parágrafos
        """
        procedure_code = self.extract_procedure_division(cobol_code)
        lines = procedure_code.split('\n')
        paragraphs = []
        
        for i, line in enumerate(lines, 1):
            # Detectar parágrafos (linha que termina com .)
            line_stripped = line.strip()
            if (line_stripped.endswith('.') and 
                not line_stripped.startswith('*') and
                len(line_stripped) > 1 and
                not any(keyword in line_stripped.upper() for keyword in 
                       ['IF ', 'ELSE', 'END-IF', 'MOVE ', 'ADD ', 'SUBTRACT ', 'MULTIPLY ', 'DIVIDE '])):
                
                paragraph_name = line_stripped[:-1].strip()
                if paragraph_name and not ' ' in paragraph_name:
                    paragraphs.append({
                        'name': paragraph_name,
                        'line': i,
                        'original_line': line
                    })
        
        self.logger.info(f"Extraídos {len(paragraphs)} parágrafos da PROCEDURE DIVISION")
        return paragraphs
    
    def analyze_complexity(self, cobol_code: str) -> dict:
        """
        Analisa a complexidade do código COBOL.
        
        Args:
            cobol_code: Código COBOL
            
        Returns:
            Dicionário com métricas de complexidade
        """
        lines = cobol_code.split('\n')
        
        metrics = {
            'total_lines': len(lines),
            'code_lines': 0,
            'comment_lines': 0,
            'blank_lines': 0,
            'if_statements': 0,
            'perform_statements': 0,
            'goto_statements': 0,
            'call_statements': 0,
            'paragraphs': 0,
            'copybooks': len(self.detect_copybooks(cobol_code))
        }
        
        for line in lines:
            line_stripped = line.strip()
            
            if not line_stripped:
                metrics['blank_lines'] += 1
            elif len(line) >= 7 and line[6] == '*':
                metrics['comment_lines'] += 1
            else:
                metrics['code_lines'] += 1
                
                # Contar estruturas de controle
                line_upper = line_stripped.upper()
                if 'IF ' in line_upper:
                    metrics['if_statements'] += 1
                if 'PERFORM ' in line_upper:
                    metrics['perform_statements'] += 1
                if 'GO TO ' in line_upper or 'GOTO ' in line_upper:
                    metrics['goto_statements'] += 1
                if 'CALL ' in line_upper:
                    metrics['call_statements'] += 1
        
        metrics['paragraphs'] = len(self.extract_paragraphs(cobol_code))
        
        # Calcular complexidade ciclomática aproximada
        metrics['cyclomatic_complexity'] = (
            metrics['if_statements'] + 
            metrics['perform_statements'] + 
            metrics['goto_statements'] + 1
        )
        
        self.logger.info(f"Análise de complexidade concluída: {metrics['cyclomatic_complexity']} pontos")
        return metrics
    
    def create_no_comments_version(self, program_name: str, cobol_code: str) -> str:
        """
        Cria uma versão do programa sem comentários para teste.
        
        Args:
            program_name: Nome do programa
            cobol_code: Código COBOL original
            
        Returns:
            Código COBOL sem comentários
        """
        clean_code, removed_count = self.remove_comments(cobol_code)
        
        header = f"""*{'='*60}
* PROGRAMA: {program_name} (VERSÃO SEM COMENTÁRIOS)
* COMENTÁRIOS REMOVIDOS: {removed_count} linhas
* GERADO PARA TESTE DE CAPACIDADE DE ANÁLISE PURA DA IA
*{'='*60}

"""
        
        return header + clean_code
