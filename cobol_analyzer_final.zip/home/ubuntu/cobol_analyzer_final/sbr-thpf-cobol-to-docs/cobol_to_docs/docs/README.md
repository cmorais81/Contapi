# COBOL Analyzer v3.1.0

Sistema profissional de análise e documentação automatizada de programas COBOL utilizando Inteligência Artificial.

## Visão Geral

O COBOL Analyzer automatiza a análise de código COBOL legado, gerando documentação técnica detalhada através de múltiplos provedores de IA, incluindo sistema RAG inteligente para aprendizado contínuo.

## Instalação

### Pré-requisitos
- Python 3.8 ou superior
- pip (gerenciador de pacotes Python)

### Instalação via pip
```bash
# Extrair o pacote
tar -xzf COBOL_ANALYZER_v3.1.0_FINAL.tar.gz
cd cobol_analyzer_final/

# Instalar
pip install .
```

### Verificar Instalação
```bash
cobol-to-docs --help
```

## Configuração Inicial

### Inicialização Automática
Execute o comando de inicialização para configurar o ambiente local:

```bash
cobol-to-docs --init
```

Este comando cria automaticamente:
- **config/**: Arquivos de configuração e prompts especializados
- **data/**: Base de conhecimento RAG e dados de treinamento
- **logs/**: Diretório para logs de execução
- **examples/**: Exemplos de programas COBOL

### Configuração de Provedores

#### Luzia (Padrão - Santander)
```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

#### GitHub Copilot
```bash
export GITHUB_TOKEN="seu_github_token"
```

#### OpenAI
```bash
export OPENAI_API_KEY="sua_api_key"
```

## Uso Básico

### Análise de Programas
```bash
# Criar arquivo com lista de programas
echo "programa1.cbl" > fontes.txt
echo "programa2.cbl" >> fontes.txt

# Executar análise
cobol-to-docs --fontes fontes.txt --models luzia
```

### Análise com Copybooks
```bash
# Incluir copybooks na análise
echo "copybook1.cpy" > books.txt
cobol-to-docs --fontes fontes.txt --books books.txt --models luzia
```

### Análise Consolidada
```bash
# Análise sistêmica de todo o conjunto
cobol-to-docs --fontes fontes.txt --consolidado --models luzia
```

## Modelos de IA Disponíveis

### Luzia (Recomendado)
- **aws-claude-3-5-sonnet**: Modelo principal para análises complexas
- **aws-claude-3-5-haiku**: Modelo rápido para análises simples
- **amazon-nova-pro-v1**: Modelo avançado para análises especializadas

### GitHub Copilot
- **gpt-4o**: Modelo GPT-4 Omni via GitHub Copilot
- **gpt-4o-mini**: Versão otimizada para análises rápidas

### Enhanced Mock (Desenvolvimento)
- **enhanced-mock-gpt-4**: Simulador para testes e desenvolvimento

## Tipos de Análise

### Análise Padrão
```bash
cobol-to-docs --fontes fontes.txt --models luzia
```

### Análise Especialista
```bash
cobol-to-docs --fontes fontes.txt --analise-especialista --models luzia
```

### Análise de Modernização
```bash
cobol-to-docs --fontes fontes.txt --modernizacao --models luzia
```

### Análise Detalhada de Procedures
```bash
cobol-to-docs --fontes fontes.txt --procedure-detalhada --models luzia
```

## Sistema RAG

O sistema RAG enriquece automaticamente as análises com:
- **Base de Conhecimento**: Padrões COBOL, melhores práticas, regras bancárias
- **Auto-Learning**: Aprendizado contínuo a partir das análises realizadas
- **Contexto Inteligente**: Enriquecimento automático dos prompts
- **Relatórios Detalhados**: Rastreamento do uso da base de conhecimento

## Estrutura de Saída

```
output/
├── PROGRAMA_analise_funcional.md      # Documentação funcional
├── PROGRAMA_ai_response.json          # Resposta completa da IA
├── PROGRAMA_ai_request.json           # Request enviado para IA
├── relatorio_custos.txt               # Relatório de custos
└── logs/
    └── rag_session_report_*.txt       # Relatórios do sistema RAG
```

## Monitoramento

### Verificar Status dos Provedores
```bash
cobol-to-docs --status
```

### Logs Detalhados
```bash
cobol-to-docs --fontes fontes.txt --log-level DEBUG --models luzia
```

## Exemplos Práticos

### Análise de Sistema Bancário
```bash
# Configurar ambiente
cobol-to-docs --init

# Preparar lista de programas
find /caminho/cobol -name "*.cbl" > programas_bancarios.txt

# Executar análise consolidada
cobol-to-docs --fontes programas_bancarios.txt \
              --consolidado \
              --analise-especialista \
              --modernizacao \
              --models luzia
```

## Solução de Problemas

### Comando não encontrado
```bash
# Verificar instalação
pip list | grep cobol-to-docs

# Reinstalar se necessário
pip uninstall cobol-to-docs -y
pip install .
```

### Provider não disponível
```bash
# Verificar status
cobol-to-docs --status

# Configurar credenciais
export LUZIA_CLIENT_ID="seu_id"
export LUZIA_CLIENT_SECRET="seu_secret"
```

### Erro de configuração
```bash
# Reinicializar ambiente
rm -rf config/ data/ logs/ examples/
cobol-to-docs --init
```

## Documentação Adicional

- **docs/MANUAL_USUARIO.md**: Manual detalhado do usuário
- **docs/MANUAL_TECNICO.md**: Documentação técnica
- **docs/GUIA_CONFIGURACAO.md**: Guia de configuração avançada

## Versão

**COBOL Analyzer v3.1.0**  
Data de lançamento: Outubro 2025  
Compatibilidade: Python 3.8+
