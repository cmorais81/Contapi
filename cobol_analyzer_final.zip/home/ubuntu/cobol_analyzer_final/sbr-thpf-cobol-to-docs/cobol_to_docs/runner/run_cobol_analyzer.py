#!/usr/bin/env python3
"""
Script wrapper para executar o COBOL Analyzer com imports corretos
"""

import sys
import os

# Configurar paths
script_dir = os.path.dirname(os.path.abspath(__file__))
cobol_to_docs_dir = os.path.dirname(script_dir)
project_root = os.path.dirname(cobol_to_docs_dir)
src_dir = os.path.join(cobol_to_docs_dir, 'src')

# Adicionar ao path
sys.path.insert(0, project_root)
sys.path.insert(0, cobol_to_docs_dir)
sys.path.insert(0, src_dir)

# Importar e executar main
if __name__ == "__main__":
    try:
        # Importar módulos necessários
        from core.config import ConfigManager
        from core.prompt_manager_dual import DualPromptManager
        from providers.enhanced_provider_manager import EnhancedProviderManager
        from parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
        from analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
        from analyzers.consolidated_analyzer import ConsolidatedAnalyzer
        from generators.documentation_generator import DocumentationGenerator
        from utils.cost_calculator import CostCalculator
        from utils.html_generator import HTMLReportGenerator
        from rag.cobol_rag_system import CobolRAGSystem
        from core.main_processor import MainProcessor
        
        print("✓ Todos os módulos importados com sucesso")
        
        # Importar e executar main
        import main
        main.main()
        
    except ImportError as e:
        print(f"Erro de importação: {e}")
        print("Certifique-se de que está executando do diretório correto")
        sys.exit(1)
    except Exception as e:
        print(f"Erro na execução: {e}")
        sys.exit(1)
