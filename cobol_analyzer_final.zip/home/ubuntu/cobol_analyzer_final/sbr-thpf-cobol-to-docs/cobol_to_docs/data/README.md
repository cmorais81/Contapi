# Diretório de Dados - COBOL Analyzer

Este diretório contém os dados do sistema RAG (Retrieval-Augmented Generation) e outros arquivos de dados da aplicação.

## Estrutura

```
data/
├── README.md                           # Este arquivo
├── rag_knowledge_base.json            # Base de conhecimento RAG
├── cobol_embeddings.pkl               # Cache de embeddings
├── rag_sessions/                      # Relatórios de sessões RAG
│   ├── rag_session_report_*.md        # Relatórios individuais
│   └── ...
└── backups/                           # Backups automáticos (se habilitado)
    ├── rag_knowledge_base_*.json      # Backups da base
    └── ...
```

## Arquivos Principais

### rag_knowledge_base.json
Base de conhecimento principal do sistema RAG contendo:
- Padrões COBOL conhecidos
- Regras de negócio bancárias
- Melhores práticas de desenvolvimento
- Conhecimento acumulado de análises anteriores

### cobol_embeddings.pkl
Cache de embeddings vetoriais para acelerar buscas semânticas na base de conhecimento.

### rag_sessions/
Diretório contendo relatórios detalhados de cada sessão de uso do sistema RAG, incluindo:
- Programas analisados
- Conhecimento utilizado
- Novos itens adicionados
- Estatísticas de uso

## Configuração

O local deste diretório pode ser configurado no arquivo `config.yaml`:

```yaml
rag:
  data_directory: "data"
  knowledge_base_path: "data/rag_knowledge_base.json"
  session_reports_path: "data/rag_sessions"
```

## Backup

Se habilitado na configuração, backups automáticos da base de conhecimento são criados periodicamente no subdiretório `backups/`.

## Manutenção

- **Limpeza**: Relatórios de sessão antigos podem ser removidos periodicamente
- **Backup**: Recomenda-se backup regular da base de conhecimento
- **Monitoramento**: Verificar crescimento da base e performance das buscas

## Segurança

- Este diretório contém dados sensíveis da aplicação
- Não compartilhar a base de conhecimento sem autorização
- Manter backups seguros da base de dados
