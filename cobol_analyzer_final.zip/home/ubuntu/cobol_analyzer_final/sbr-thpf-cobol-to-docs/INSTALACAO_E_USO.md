# Guia de Instalação e Uso - COBOL Analyzer v3.1.0

## Visão Geral

O COBOL Analyzer é uma ferramenta profissional para análise automatizada de código COBOL utilizando Inteligência Artificial. Esta versão inclui sistema RAG avançado, múltiplos provedores de IA e geração automática de documentação.

## Instalação

### Pré-requisitos

- Python 3.8 ou superior
- pip (gerenciador de pacotes Python)
- 2GB de espaço em disco
- Conexão com internet (para provedores de IA)

### Instalação via pip

```bash
# Extrair o pacote
tar -xzf SBR_THPF_COBOL_TO_DOCS_v3.1.0_FINAL.tar.gz
cd sbr-thpf-cobol-to-docs/

# Instalar dependências e o pacote
pip install -r requirements.txt
pip install .
```

### Instalação via Pipenv (Recomendado)

```bash
# Extrair o pacote
tar -xzf SBR_THPF_COBOL_TO_DOCS_v3.1.0_FINAL.tar.gz
cd sbr-thpf-cobol-to-docs/

# Instalar com Pipenv
pipenv install
pipenv shell
```

## Inicialização de Projeto

### Comando de Inicialização

Para usar o COBOL Analyzer em qualquer pasta, execute:

```bash
# Criar e entrar em sua pasta de projeto
mkdir meu_projeto_cobol
cd meu_projeto_cobol

# Inicializar projeto (copia todos os arquivos necessários)
python /caminho/para/cobol_to_docs/runner/cobol_to_docs_simple.py --init
```

### Arquivos Copiados Automaticamente

O comando `--init` copia automaticamente:

#### Diretório config/
- `config.yaml` - Configuração principal
- `config_enhanced.yaml` - Configuração avançada
- `prompts_cadoc_deep_analysis.yaml` - Prompts especializados
- `prompts_deep_business_rules.yaml` - Regras de negócio
- `prompts_enhanced.yaml` - Prompts melhorados
- `prompts_especialista.yaml` - Prompts de especialista
- Outros arquivos de prompts especializados

#### Diretório data/
- `cobol_knowledge_base.json` - Base de conhecimento principal
- `cobol_embeddings.pkl` - Embeddings pré-calculados
- `knowledge_base` - Arquivo de conhecimento expandido
- Arquivos de backup e versões expandidas
- Diretório `rag_sessions/` para sessões RAG

#### Diretório examples/
- `fontes.txt` - Lista de programas exemplo (65KB)
- `programa_exemplo.cbl` - Programa COBOL exemplo
- `SISTEMA_LH.cbl` - Sistema completo exemplo
- `copybook_*.cpy` - Copybooks exemplo
- `COBOL_to_Docs_Tutorial.ipynb` - Tutorial Jupyter
- `INICIO_RAPIDO.md` - Guia de início rápido
- Outros exemplos e documentação

#### Diretórios de Trabalho
- `logs/` - Logs da aplicação
- `output/` - Documentação gerada
- `temp/` - Arquivos temporários

#### Arquivo de Template
- `fontes_exemplo.txt` - Template para lista de programas

## Configuração

### Configuração de Provedores de IA

#### Luzia (Santander - Recomendado)
```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

#### GitHub Copilot
```bash
export GITHUB_TOKEN="seu_github_token"
```

#### OpenAI
```bash
export OPENAI_API_KEY="sua_api_key"
```

#### AWS Bedrock
```bash
export AWS_ACCESS_KEY_ID="sua_access_key"
export AWS_SECRET_ACCESS_KEY="sua_secret_key"
export AWS_REGION="us-east-1"
```

### Edição de Configuração

Edite o arquivo `config/config.yaml` para ajustar:
- Configurações de provedores
- Parâmetros de análise
- Configurações de saída
- Configurações do sistema RAG

## Uso Básico

### Verificar Status do Sistema

```bash
python /caminho/para/cobol_to_docs/runner/main.py --status
```

### Análise de Programas COBOL

#### Análise Básica
```bash
# Criar arquivo com lista de programas
echo "programa1.cbl" > meus_programas.txt
echo "programa2.cbl" >> meus_programas.txt

# Executar análise
python /caminho/para/cobol_to_docs/runner/main.py --fontes meus_programas.txt --models enhanced_mock
```

#### Análise com Copybooks
```bash
# Criar arquivo com lista de copybooks
echo "copybook1.cpy" > meus_copybooks.txt

# Executar análise
python /caminho/para/cobol_to_docs/runner/main.py --fontes meus_programas.txt --books meus_copybooks.txt --models luzia
```

#### Análise com Exemplos Incluídos
```bash
# Usar exemplos copiados pelo --init
python /caminho/para/cobol_to_docs/runner/main.py --fontes examples/fontes.txt --models enhanced_mock
```

### Modelos Disponíveis

#### Enhanced Mock (Desenvolvimento)
```bash
--models enhanced_mock
```
- Não requer credenciais
- Ideal para testes e desenvolvimento
- Gera análises simuladas realistas

#### Luzia (Produção - Recomendado)
```bash
--models luzia
```
- Modelo aws-claude-3-5-sonnet
- Análises de alta qualidade
- Requer credenciais Santander

#### GitHub Copilot
```bash
--models github_copilot
```
- Modelo gpt-4o
- Análises rápidas e precisas
- Requer token GitHub

#### OpenAI
```bash
--models openai
```
- Modelos GPT-4
- Análises detalhadas
- Requer API key OpenAI

## Funcionalidades Avançadas

### Análise Consolidada
```bash
python /caminho/para/cobol_to_docs/runner/main.py --fontes programas.txt --consolidado --models luzia
```

### Análise Especializada
```bash
python /caminho/para/cobol_to_docs/runner/main.py --fontes programas.txt --analise-especialista --models luzia
```

### Análise para Modernização
```bash
python /caminho/para/cobol_to_docs/runner/main.py --fontes programas.txt --modernizacao --models luzia
```

### Geração de PDF
```bash
python /caminho/para/cobol_to_docs/runner/main.py --fontes programas.txt --pdf --models luzia
```

## Arquivos de Saída

### Documentação Gerada

#### Diretório output/
- `PROGRAMA_analise_funcional.md` - Análise funcional de cada programa
- `ai_requests/` - Requisições enviadas para IA
- `ai_responses/` - Respostas recebidas da IA
- `relatorio_custos.txt` - Relatório de custos e tokens

#### Diretório logs/
- `cobol_to_docs_*.log` - Logs principais da aplicação
- `rag_session_report_*.txt` - Relatórios de sessões RAG
- `rag_detailed_log_*.json` - Logs detalhados do sistema RAG
- `rag_operations_*.log` - Operações do sistema RAG

### Estrutura da Análise Funcional

Cada arquivo de análise contém:
- Resumo executivo do programa
- Análise da estrutura COBOL
- Identificação de regras de negócio
- Mapeamento de arquivos e dados
- Fluxo de processamento
- Recomendações de modernização
- Metadados da análise (data, modelo, tokens)

## Sistema RAG

### Funcionalidades

O sistema RAG (Retrieval-Augmented Generation) enriquece as análises com:
- Base de conhecimento COBOL especializada
- Padrões e melhores práticas
- Regras de negócio bancárias
- Contexto histórico e técnico

### Configuração

O sistema RAG é configurado automaticamente com:
- 48 itens na base de conhecimento
- 142 embeddings pré-calculados
- Sistema de aprendizado automático
- Cache inteligente de contexto

## Solução de Problemas

### Problemas Comuns

#### Erro de Credenciais
```
Erro: Failed to resolve 'login.azure.paas.santanderbr.pre.corp'
```
**Solução**: Configure as credenciais do provedor ou use `enhanced_mock` para testes.

#### Erro de Configuração
```
Erro: Modelo gpt-4 não está configurado no sistema
```
**Solução**: Configure a API key do provedor ou use um modelo disponível.

#### Erro de Importação
```
ModuleNotFoundError: No module named 'cobol_to_docs'
```
**Solução**: Reinstale o pacote com `pip install .` no diretório do projeto.

### Logs de Diagnóstico

Para diagnóstico detalhado:
```bash
python /caminho/para/cobol_to_docs/runner/main.py --log-level DEBUG --fontes programas.txt --models enhanced_mock
```

## Desenvolvimento e Testes

### Executar Testes Unitários
```bash
cd sbr-thpf-cobol-to-docs/
python -m pytest cobol_to_docs/tests/ -v
```

### Estrutura de Desenvolvimento
```
sbr-thpf-cobol-to-docs/
├── cobol_to_docs/           # Aplicação principal
│   ├── src/                 # Código fonte
│   ├── tests/               # Testes unitários
│   ├── config/              # Configurações
│   ├── data/                # Base de conhecimento
│   └── examples/            # Exemplos
├── requirements.txt         # Dependências
├── setup.py                 # Configuração de instalação
└── README.md               # Documentação principal
```

## Suporte e Documentação

### Documentação Adicional
- `README.md` - Documentação principal
- `CHANGELOG.md` - Histórico de mudanças
- `examples/INICIO_RAPIDO.md` - Guia de início rápido
- `examples/COBOL_to_Docs_Tutorial.ipynb` - Tutorial interativo

### Arquivos de Exemplo
- `examples/fontes.txt` - Lista de programas exemplo
- `examples/programa_exemplo.cbl` - Programa COBOL exemplo
- `examples/copybook_*.cpy` - Copybooks exemplo

## Licença

Este projeto está licenciado sob a licença MIT. Veja o arquivo `LICENSE` para detalhes.

---

**COBOL Analyzer v3.1.0**  
**Desenvolvido pela equipe COBOL Analyzer**  
**Data**: Outubro 2025
