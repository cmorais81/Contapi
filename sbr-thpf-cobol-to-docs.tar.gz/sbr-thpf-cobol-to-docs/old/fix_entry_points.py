#!/usr/bin/env python3
"""
Script para corrigir os entry points após instalação via pip
"""

import os
import sys
import site
from pathlib import Path

def fix_entry_points():
    """Corrige os entry points cobol-to-docs e cobol-analyzer"""
    
    # Encontrar o diretório bin do ambiente virtual ou sistema
    bin_dirs = []
    
    # Ambiente virtual
    if hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix):
        bin_dirs.append(Path(sys.prefix) / "bin")
    
    # Sistema
    try:
        for site_dir in site.getsitepackages():
            bin_dir = Path(site_dir).parent / "bin"
            if bin_dir.exists():
                bin_dirs.append(bin_dir)
    except:
        pass
    
    # Diretório local do usuário
    try:
        user_site = site.getusersitepackages()
        if user_site:
            user_bin = Path(user_site).parent / "bin"
            if user_bin.exists():
                bin_dirs.append(user_bin)
    except:
        pass
    
    # Conteúdo do script corrigido
    script_content = '''#!/usr/bin/env python3
"""
COBOL to Docs - Entry Point Corrigido
"""

import sys
import os
import subprocess
from pathlib import Path

def find_cobol_to_docs():
    """Encontra o script cobol_to_docs.py"""
    # Procurar no mesmo diretório
    script_dir = Path(__file__).parent
    cobol_script = script_dir / "cobol_to_docs.py"
    if cobol_script.exists():
        return str(cobol_script)
    
    # Procurar nos site-packages
    try:
        import site
        for site_dir in site.getsitepackages() + [site.getusersitepackages()]:
            if site_dir:
                candidates = [
                    Path(site_dir) / "cobol_to_docs.py",
                    Path(site_dir).parent / "bin" / "cobol_to_docs.py"
                ]
                for candidate in candidates:
                    if candidate.exists():
                        return str(candidate)
    except:
        pass
    
    return None

def main():
    """Função principal"""
    cobol_script = find_cobol_to_docs()
    if cobol_script:
        try:
            cmd = [sys.executable, cobol_script] + sys.argv[1:]
            return subprocess.call(cmd)
        except Exception as e:
            print(f"Erro ao executar cobol_to_docs.py: {e}")
    
    print("Erro: Não foi possível encontrar cobol_to_docs.py")
    print("Execute diretamente: cobol_to_docs.py --help")
    return 1

if __name__ == '__main__':
    sys.exit(main())
'''
    
    # Corrigir os entry points
    fixed_count = 0
    for bin_dir in bin_dirs:
        for script_name in ["cobol-to-docs", "cobol-analyzer"]:
            script_path = bin_dir / script_name
            if script_path.exists():
                try:
                    with open(script_path, 'w') as f:
                        f.write(script_content)
                    os.chmod(script_path, 0o755)
                    print(f"✓ Corrigido: {script_path}")
                    fixed_count += 1
                except Exception as e:
                    print(f"✗ Erro ao corrigir {script_path}: {e}")
    
    if fixed_count > 0:
        print(f"\n {fixed_count} entry points corrigidos com sucesso!")
        print("Agora você pode usar:")
        print("  cobol-to-docs --help")
        print("  cobol-analyzer --help")
    else:
        print(" Nenhum entry point encontrado para corrigir.")
        print("Use diretamente: cobol_to_docs.py --help")

if __name__ == '__main__':
    fix_entry_points()
