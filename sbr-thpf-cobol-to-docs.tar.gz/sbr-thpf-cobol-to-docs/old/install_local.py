#!/usr/bin/env python3
"""
Script de instalação local para COBOL Analyzer
Garante que a instalação funcione corretamente em qualquer máquina
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def print_step(step, message):
    """Imprime passo da instalação"""
    print(f"\n{'='*50}")
    print(f"PASSO {step}: {message}")
    print('='*50)

def run_command(cmd, description):
    """Executa comando e verifica resultado"""
    print(f" {description}")
    print(f"💻 Executando: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        print(f" Sucesso: {description}")
        if result.stdout:
            print(f" Output: {result.stdout.strip()}")
        return True
    except subprocess.CalledProcessError as e:
        print(f" Erro: {description}")
        print(f" Stderr: {e.stderr}")
        return False
    except Exception as e:
        print(f" Erro inesperado: {e}")
        return False

def check_python_version():
    """Verifica versão do Python"""
    version = sys.version_info
    print(f"🐍 Python {version.major}.{version.minor}.{version.micro}")
    
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print(" Python 3.8+ é necessário")
        return False
    
    print(" Versão do Python compatível")
    return True

def backup_existing_installation():
    """Faz backup de instalação existente"""
    script_path = shutil.which('cobol-to-docs')
    if script_path:
        backup_path = f"{script_path}.backup"
        try:
            shutil.copy2(script_path, backup_path)
            print(f"💾 Backup criado: {backup_path}")
        except Exception as e:
            print(f"  Aviso: Não foi possível criar backup: {e}")

def create_entry_point_script():
    """Cria script de entry point robusto"""
    
    # Encontrar diretório de instalação
    try:
        import site
        site_packages = site.getsitepackages()[0]
    except:
        site_packages = "/usr/local/lib/python3.11/site-packages"
    
    script_content = f'''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
COBOL Analyzer Entry Point - Versão Robusta
Gerado automaticamente pelo install_local.py
"""

import sys
import os
import subprocess
from pathlib import Path

def find_main_enhanced():
    """Encontra main_enhanced.py em locais possíveis"""
    
    # Locais possíveis para main_enhanced.py
    possible_locations = [
        # Diretório atual
        Path.cwd() / "main_enhanced.py",
        
        # Diretório do script
        Path(__file__).parent / "main_enhanced.py",
        
        # Site-packages
        Path("{site_packages}") / "main_enhanced.py",
        
        # Diretório de desenvolvimento
        Path("/home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py"),
        
        # Diretório relativo ao usuário
        Path.home() / "cobol_analyzer_EXCELENCIA" / "main_enhanced.py",
        
        # Busca no PATH
        Path("/usr/local/bin/main_enhanced.py"),
        Path("/usr/bin/main_enhanced.py"),
    ]
    
    for location in possible_locations:
        if location.exists():
            return location
    
    return None

def find_main_original():
    """Encontra main.py original"""
    
    possible_locations = [
        Path.cwd() / "main.py",
        Path(__file__).parent / "main.py",
        Path("{site_packages}") / "main.py",
        Path("/home/ubuntu/cobol_analyzer_EXCELENCIA/main.py"),
    ]
    
    for location in possible_locations:
        if location.exists():
            return location
    
    return None

def main():
    """Função principal do entry point"""
    
    # Verificar se é comando --init
    if '--init' in sys.argv:
        print(" Detectado comando --init")
        
        # Encontrar main_enhanced.py
        main_enhanced = find_main_enhanced()
        
        if main_enhanced:
            print(f"📍 Usando: {{main_enhanced}}")
            # Substituir --init por --init-local para compatibilidade
            args = [arg if arg != '--init' else '--init-local' for arg in sys.argv[1:]]
            cmd = [sys.executable, str(main_enhanced)] + args
            result = subprocess.run(cmd, check=False)
            sys.exit(result.returncode)
        else:
            print(" Erro: main_enhanced.py não encontrado")
            print(" Locais verificados:")
            for loc in [Path.cwd() / "main_enhanced.py", Path("{site_packages}") / "main_enhanced.py"]:
                print(f"   - {loc} ({'' if loc.exists() else ''})")
            print(" Tente executar diretamente:")
            print("   python main_enhanced.py --init-local")
            sys.exit(1)
    
    # Para outros comandos, tentar importar main
    try:
        # Tentar importar main do site-packages
        sys.path.insert(0, "{site_packages}")
        from main import main as main_func
        main_func()
    except ImportError:
        # Fallback para execução direta
        main_py = find_main_original()
        
        if main_py:
            cmd = [sys.executable, str(main_py)] + sys.argv[1:]
            result = subprocess.run(cmd, check=False)
            sys.exit(result.returncode)
        else:
            print(" Erro: Não foi possível encontrar main.py")
            print(" Verifique se o COBOL Analyzer está instalado corretamente")
            print(" Tente reinstalar com: python install_local.py")
            sys.exit(1)

if __name__ == "__main__":
    main()
'''
    
    return script_content

def install_entry_point():
    """Instala entry point personalizado"""
    
    # Encontrar diretório bin
    bin_dirs = ["/usr/local/bin", "/usr/bin", os.path.expanduser("~/.local/bin")]
    
    bin_dir = None
    for bd in bin_dirs:
        if os.path.exists(bd) and os.access(bd, os.W_OK):
            bin_dir = bd
            break
    
    if not bin_dir:
        print(" Não foi possível encontrar diretório bin com permissão de escrita")
        return False
    
    script_path = os.path.join(bin_dir, "cobol-to-docs")
    script_content = create_entry_point_script()
    
    try:
        with open(script_path, 'w') as f:
            f.write(script_content)
        
        os.chmod(script_path, 0o755)
        print(f" Entry point criado: {script_path}")
        return True
        
    except Exception as e:
        print(f" Erro ao criar entry point: {e}")
        return False

def test_installation():
    """Testa a instalação"""
    
    print("\n TESTANDO INSTALAÇÃO")
    print("-" * 30)
    
    # Teste 1: Comando disponível
    if shutil.which('cobol-to-docs'):
        print(" Comando cobol-to-docs encontrado")
    else:
        print(" Comando cobol-to-docs não encontrado")
        return False
    
    # Teste 2: Help
    if run_command(['cobol-to-docs', '--help'], "Teste --help"):
        print(" Comando --help funcionando")
    else:
        print(" Comando --help falhou")
        return False
    
    # Teste 3: Init em diretório temporário
    test_dir = Path("/tmp/test_cobol_install")
    test_dir.mkdir(exist_ok=True)
    
    original_cwd = os.getcwd()
    try:
        os.chdir(str(test_dir))
        
        if run_command(['cobol-to-docs', '--init'], "Teste --init"):
            print(" Comando --init funcionando")
            
            # Verificar se diretórios foram criados
            expected_dirs = ['config', 'data', 'logs', 'examples']
            all_created = all((test_dir / d).exists() for d in expected_dirs)
            
            if all_created:
                print(" Diretórios criados corretamente")
                return True
            else:
                print(" Nem todos os diretórios foram criados")
                return False
        else:
            print(" Comando --init falhou")
            return False
            
    finally:
        os.chdir(original_cwd)
        # Limpar diretório de teste
        try:
            shutil.rmtree(str(test_dir))
        except:
            pass

def main():
    """Função principal de instalação"""
    
    print(" COBOL ANALYZER - INSTALAÇÃO LOCAL")
    print("=" * 50)
    print("Este script instala o COBOL Analyzer de forma robusta")
    print("garantindo que funcione corretamente na sua máquina.")
    print("=" * 50)
    
    # Passo 1: Verificar Python
    print_step(1, "Verificando Python")
    if not check_python_version():
        sys.exit(1)
    
    # Passo 2: Backup
    print_step(2, "Backup de instalação existente")
    backup_existing_installation()
    
    # Passo 3: Desinstalar versão anterior
    print_step(3, "Removendo instalação anterior")
    run_command([sys.executable, '-m', 'pip', 'uninstall', 'cobol-to-docs', '-y'], 
                "Desinstalar versão anterior")
    
    # Passo 4: Instalar com setup corrigido
    print_step(4, "Instalando COBOL Analyzer")
    if not run_command([sys.executable, 'setup_corrigido.py', 'install'], 
                      "Instalar pacote"):
        print(" Falha na instalação via setup.py")
        print(" Tentando instalação alternativa...")
        
        if not run_command([sys.executable, '-m', 'pip', 'install', '.'], 
                          "Instalar via pip"):
            print(" Falha na instalação via pip")
            sys.exit(1)
    
    # Passo 5: Criar entry point robusto
    print_step(5, "Configurando entry point")
    if not install_entry_point():
        print("  Entry point não pôde ser criado automaticamente")
        print(" Você pode executar diretamente: python main_enhanced.py --init-local")
    
    # Passo 6: Testar instalação
    print_step(6, "Testando instalação")
    if test_installation():
        print("\n INSTALAÇÃO CONCLUÍDA COM SUCESSO!")
        print(" Agora você pode usar: cobol-to-docs --init")
    else:
        print("\n INSTALAÇÃO FALHOU")
        print(" Tente executar manualmente:")
        print("   python main_enhanced.py --init-local")
        sys.exit(1)

if __name__ == "__main__":
    main()
