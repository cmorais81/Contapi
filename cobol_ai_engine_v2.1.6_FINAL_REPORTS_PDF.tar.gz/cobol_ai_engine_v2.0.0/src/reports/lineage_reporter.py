"""
COBOL AI Engine v2.0.0 - Lineage Reporter
Gerador de relatórios de linhagem e fluxo de execução.
"""

import logging
import os
from typing import Dict, List, Any, Optional
from datetime import datetime

from ..analyzers.completeness_analyzer import CompletenessAnalyzer
from ..analyzers.lineage_mapper import LineageMapper, ExecutionSequence


class LineageReporter:
    """
    Gerador de relatórios de linhagem e fluxo de execução.
    
    Funcionalidades:
    - Relatório de completude de processamento
    - Relatório de dependências entre programas
    - Relatório de sequência de execução
    - Relatório de linhagem de dados
    - Visualização de fluxo de execução
    """
    
    def __init__(self, output_dir: str = "output"):
        """
        Inicializa o gerador de relatórios.
        
        Args:
            output_dir: Diretório de saída para relatórios
        """
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        
        # Criar diretório de relatórios
        self.reports_dir = os.path.join(output_dir, "reports")
        os.makedirs(self.reports_dir, exist_ok=True)
        
        self.logger.info(f"Lineage Reporter inicializado - Output: {self.reports_dir}")
    
    def generate_completeness_report(self, completeness_analyzer: CompletenessAnalyzer) -> str:
        """
        Gera relatório de completude de processamento.
        
        Args:
            completeness_analyzer: Analisador de completude
            
        Returns:
            Caminho do arquivo de relatório gerado
        """
        try:
            report_data = completeness_analyzer.get_completeness_report()
            
            content = self._generate_completeness_content(report_data)
            
            filename = "RELATORIO_COMPLETUDE.md"
            filepath = os.path.join(self.reports_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.logger.info(f"Relatório de completude gerado: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório de completude: {e}")
            return ""
    
    def generate_lineage_report(self, lineage_mapper: LineageMapper) -> str:
        """
        Gera relatório de linhagem e fluxo de execução.
        
        Args:
            lineage_mapper: Mapeador de linhagem
            
        Returns:
            Caminho do arquivo de relatório gerado
        """
        try:
            flow_data = lineage_mapper.get_execution_flow_report()
            
            content = self._generate_lineage_content(flow_data, lineage_mapper)
            
            filename = "RELATORIO_LINHAGEM_EXECUCAO.md"
            filepath = os.path.join(self.reports_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.logger.info(f"Relatório de linhagem gerado: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório de linhagem: {e}")
            return ""
    
    def generate_consolidated_report(self, completeness_analyzer: CompletenessAnalyzer,
                                   lineage_mapper: LineageMapper,
                                   expected_programs: List[str]) -> str:
        """
        Gera relatório consolidado com completude e linhagem.
        
        Args:
            completeness_analyzer: Analisador de completude
            lineage_mapper: Mapeador de linhagem
            expected_programs: Lista de programas esperados
            
        Returns:
            Caminho do arquivo de relatório gerado
        """
        try:
            completeness_data = completeness_analyzer.get_completeness_report()
            flow_data = lineage_mapper.get_execution_flow_report()
            validation_data = lineage_mapper.validate_execution_completeness(expected_programs)
            
            content = self._generate_consolidated_content(
                completeness_data, flow_data, validation_data, expected_programs
            )
            
            filename = "RELATORIO_CONSOLIDADO_LINHAGEM.md"
            filepath = os.path.join(self.reports_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.logger.info(f"Relatório consolidado gerado: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório consolidado: {e}")
            return ""
    
    def _generate_completeness_content(self, report_data: Dict[str, Any]) -> str:
        """Gera conteúdo do relatório de completude."""
        summary = report_data['summary']
        missing = report_data['missing_programs']
        dependencies = report_data['dependencies']
        
        content = f"""# Relatório de Completude de Processamento

**Data de Geração:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Versão do Sistema:** COBOL AI Engine v2.0.0

---

## Resumo Executivo

Este relatório apresenta a análise de completude do processamento de programas COBOL, 
garantindo que todos os programas listados no arquivo de entrada foram processados corretamente.

### Estatísticas Gerais

| Métrica | Valor |
|---------|-------|
| **Total de Programas** | {summary['total_programs']} |
| **Programas Encontrados** | {summary['found']} |
| **Programas Parseados** | {summary['parsed']} |
| **Programas Analisados** | {summary['analyzed']} |
| **Programas Documentados** | {summary['documented']} |
| **Programas com Erro** | {summary['errors']} |
| **Percentual de Completude** | {summary['completeness_percentage']:.1f}% |

---

## Status de Processamento

###  Programas Processados com Sucesso
{self._format_program_list([name for name, details in report_data['program_details'].items() 
                           if details['documented'] and not details['error']])}

### ⚠ Programas Não Encontrados
{self._format_program_list(missing['not_found'])}

### ⚠ Programas Não Parseados
{self._format_program_list(missing['not_parsed'])}

### ⚠ Programas Não Analisados
{self._format_program_list(missing['not_analyzed'])}

### ⚠ Programas Não Documentados
{self._format_program_list(missing['not_documented'])}

###  Programas com Erro
{self._format_program_list_with_errors(report_data['program_details'], missing['with_errors'])}

---

## Análise de Dependências

### Estatísticas de Dependências

| Tipo de Dependência | Quantidade |
|---------------------|------------|
{self._format_dependency_stats(dependencies['by_type'])}
| **Total** | **{dependencies['total_dependencies']}** |

### Detalhamento de Dependências

{self._format_dependency_details(dependencies['dependency_list'])}

---

## Detalhes dos Programas

{self._format_program_details(report_data['program_details'])}

---

## Recomendações

### Ações Imediatas Necessárias

{self._generate_completeness_recommendations(missing, summary)}

### Próximos Passos

1. **Resolver Problemas Identificados:** Corrigir programas com erro ou não processados
2. **Validar Dependências:** Verificar se todas as dependências estão corretas
3. **Completar Processamento:** Garantir que todos os programas sejam documentados
4. **Monitoramento Contínuo:** Implementar verificações regulares de completude

---

**Relatório gerado automaticamente pelo COBOL AI Engine v2.0.0**  
**Para questões técnicas, consulte a equipe de desenvolvimento**
"""
        
        return content
    
    def _generate_lineage_content(self, flow_data: Dict[str, Any], 
                                lineage_mapper: LineageMapper) -> str:
        """Gera conteúdo do relatório de linhagem."""
        summary = flow_data['summary']
        sequences = flow_data['execution_sequences']
        
        # Obter informações adicionais
        execution_order = lineage_mapper.get_program_execution_order()
        critical_path = lineage_mapper.get_critical_path()
        parallel_opportunities = lineage_mapper.get_parallel_execution_opportunities()
        
        content = f"""# Relatório de Linhagem e Fluxo de Execução

**Data de Geração:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Versão do Sistema:** COBOL AI Engine v2.0.0

---

## Resumo Executivo

Este relatório apresenta a análise completa de linhagem e fluxo de execução dos programas COBOL, 
incluindo sequências de execução, dependências e oportunidades de otimização.

### Estatísticas do Fluxo de Execução

| Métrica | Valor |
|---------|-------|
| **Total de Programas** | {summary['total_programs']} |
| **Sequências Identificadas** | {summary['total_sequences']} |
| **Pontos de Entrada** | {summary['entry_points']} |
| **Pontos Terminais** | {summary['terminal_points']} |
| **Total de Dependências** | {summary['total_dependencies']} |
| **Máx. Dependências por Programa** | {summary['max_dependencies_per_program']} |
| **Média de Dependências** | {summary['avg_dependencies_per_program']} |

---

## Pontos de Entrada e Saída

###  Pontos de Entrada (Programas Iniciais)
{self._format_program_list(flow_data['entry_points'])}

### 🏁 Pontos Terminais (Programas Finais)
{self._format_program_list(flow_data['terminal_points'])}

---

## Ordem de Execução dos Programas

### Sequência Recomendada de Execução

{self._format_execution_order(execution_order)}

---

## Sequências de Execução Identificadas

{self._format_execution_sequences(sequences)}

---

## Caminho Crítico

### Sequência Mais Longa de Execução

{self._format_critical_path(critical_path)}

---

## Oportunidades de Execução Paralela

{self._format_parallel_opportunities(parallel_opportunities)}

---

## Linhagem de Dados

### Linhagem de Arquivos
{self._format_file_lineage(flow_data['file_lineage'])}

### Linhagem de Copybooks
{self._format_data_lineage(flow_data['data_lineage'])}

---

## Distribuição por Tipo de Componente

{self._format_node_type_distribution(flow_data['node_type_distribution'])}

---

## Análise Detalhada dos Nós

{self._format_execution_nodes(flow_data['execution_nodes'])}

---

## Recomendações de Otimização

{self._generate_lineage_recommendations(flow_data, parallel_opportunities)}

---

**Relatório gerado automaticamente pelo COBOL AI Engine v2.0.0**  
**Para questões técnicas, consulte a equipe de desenvolvimento**
"""
        
        return content
    
    def _generate_consolidated_content(self, completeness_data: Dict[str, Any],
                                     flow_data: Dict[str, Any],
                                     validation_data: Dict[str, Any],
                                     expected_programs: List[str]) -> str:
        """Gera conteúdo do relatório consolidado."""
        content = f"""# Relatório Consolidado - Completude e Linhagem

**Data de Geração:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Versão do Sistema:** COBOL AI Engine v2.0.0

---

## Resumo Executivo

Este relatório consolidado apresenta uma visão completa do processamento e análise de linhagem 
dos programas COBOL, garantindo que todos os programas foram processados e suas sequências 
de execução foram mapeadas corretamente.

### Programas Esperados vs Processados

| Métrica | Valor |
|---------|-------|
| **Programas Esperados** | {len(expected_programs)} |
| **Programas Mapeados** | {validation_data['mapped_programs']} |
| **Completude de Processamento** | {completeness_data['summary']['completeness_percentage']:.1f}% |
| **Completude de Mapeamento** | {validation_data['completeness_percentage']:.1f}% |
| **Validação Aprovada** | {' Sim' if validation_data['validation_passed'] else ' Não'} |

---

## Lista de Programas Esperados

{self._format_expected_programs_status(expected_programs, completeness_data, flow_data)}

---

## Validação de Completude

###  Programas Corretamente Mapeados
{self._format_program_list([p for p in expected_programs 
                           if p in flow_data['execution_nodes']])}

### ⚠ Programas Ausentes do Fluxo
{self._format_program_list(validation_data['missing_from_flow'])}

### ⚠ Programas Extras no Fluxo
{self._format_program_list(validation_data['extra_in_flow'])}

### ⚠ Programas Sem Ordem de Execução
{self._format_program_list(validation_data['programs_without_order'])}

---

## Resumo de Sequências de Execução

{self._format_sequence_summary(flow_data['execution_sequences'])}

---

## Matriz de Dependências

{self._format_dependency_matrix(expected_programs, flow_data['execution_nodes'])}

---

## Análise de Impacto

{self._generate_impact_analysis(expected_programs, completeness_data, flow_data)}

---

## Plano de Ação

{self._generate_action_plan(validation_data, completeness_data)}

---

**Relatório gerado automaticamente pelo COBOL AI Engine v2.0.0**  
**Para questões técnicas, consulte a equipe de desenvolvimento**
"""
        
        return content
    
    # Métodos auxiliares de formatação
    
    def _format_program_list(self, programs: List[str]) -> str:
        """Formata lista de programas."""
        if not programs:
            return "*Nenhum programa nesta categoria*\n"
        
        return "\n".join(f"- **{program}**" for program in programs) + "\n"
    
    def _format_program_list_with_errors(self, program_details: Dict[str, Any], 
                                       error_programs: List[str]) -> str:
        """Formata lista de programas com erros."""
        if not error_programs:
            return "*Nenhum programa com erro*\n"
        
        result = []
        for program in error_programs:
            details = program_details.get(program, {})
            error = details.get('error', 'Erro não especificado')
            result.append(f"- **{program}**: {error}")
        
        return "\n".join(result) + "\n"
    
    def _format_dependency_stats(self, by_type: Dict[str, int]) -> str:
        """Formata estatísticas de dependências."""
        if not by_type:
            return "| Nenhuma dependência | 0 |\n"
        
        return "\n".join(f"| {dep_type} | {count} |" for dep_type, count in by_type.items())
    
    def _format_dependency_details(self, dependencies: List[Dict[str, Any]]) -> str:
        """Formata detalhes das dependências."""
        if not dependencies:
            return "*Nenhuma dependência identificada*\n"
        
        result = ["| Programa Origem | Programa Destino | Tipo | Linha | Contexto |",
                 "|-----------------|------------------|------|-------|----------|"]
        
        for dep in dependencies[:20]:  # Limitar a 20 para não sobrecarregar
            result.append(f"| {dep['source']} | {dep['target']} | {dep['type']} | "
                         f"{dep['line'] or 'N/A'} | {(dep['context'] or '')[:50]}... |")
        
        if len(dependencies) > 20:
            result.append(f"| ... | ... | ... | ... | *+{len(dependencies) - 20} dependências* |")
        
        return "\n".join(result) + "\n"
    
    def _format_program_details(self, program_details: Dict[str, Any]) -> str:
        """Formata detalhes dos programas."""
        result = ["| Programa | Encontrado | Parseado | Analisado | Documentado | Tamanho | Linhas |",
                 "|----------|------------|----------|-----------|-------------|---------|--------|"]
        
        for name, details in program_details.items():
            found = "" if details['found'] else ""
            parsed = "" if details['parsed'] else ""
            analyzed = "" if details['analyzed'] else ""
            documented = "" if details['documented'] else ""
            size = f"{details['size']:,}" if details['size'] else "N/A"
            lines = str(details['line_count']) if details['line_count'] else "N/A"
            
            result.append(f"| {name} | {found} | {parsed} | {analyzed} | {documented} | {size} | {lines} |")
        
        return "\n".join(result) + "\n"
    
    def _format_execution_order(self, execution_order: List[tuple]) -> str:
        """Formata ordem de execução."""
        if not execution_order:
            return "*Nenhuma ordem de execução identificada*\n"
        
        result = ["| Ordem | Nível | Programa |",
                 "|-------|-------|----------|"]
        
        for program, order, level in execution_order:
            result.append(f"| {order + 1} | {level} | **{program}** |")
        
        return "\n".join(result) + "\n"
    
    def _format_execution_sequences(self, sequences: List[Dict[str, Any]]) -> str:
        """Formata sequências de execução."""
        if not sequences:
            return "*Nenhuma sequência identificada*\n"
        
        result = []
        for i, seq in enumerate(sequences, 1):
            result.append(f"### Sequência {i}: {seq['sequence_id']}")
            result.append(f"**Tipo:** {seq['sequence_type']}")
            result.append(f"**Ponto de Entrada:** {seq['entry_point']}")
            result.append(f"**Total de Programas:** {seq['total_programs']}")
            result.append(f"**Caminho:** {' → '.join(seq['execution_path'])}")
            result.append(f"**Descrição:** {seq['description']}")
            result.append("")
        
        return "\n".join(result)
    
    def _format_critical_path(self, critical_path: List[str]) -> str:
        """Formata caminho crítico."""
        if not critical_path:
            return "*Nenhum caminho crítico identificado*\n"
        
        return f"**Caminho:** {' → '.join(critical_path)}\n\n" \
               f"**Total de Programas:** {len(critical_path)}\n\n" \
               f"Este é o caminho mais longo de execução identificado no sistema.\n"
    
    def _format_parallel_opportunities(self, opportunities: List[Dict[str, Any]]) -> str:
        """Formata oportunidades de paralelização."""
        if not opportunities:
            return "*Nenhuma oportunidade de paralelização identificada*\n"
        
        result = []
        for opp in opportunities:
            result.append(f"### Nível {opp['execution_level']}")
            result.append(f"**Programas Paralelos:** {', '.join(opp['parallel_programs'])}")
            result.append(f"**Fator de Paralelização:** {opp['parallelization_factor']}x")
            result.append(f"**Descrição:** {opp['description']}")
            result.append("")
        
        return "\n".join(result)
    
    def _format_file_lineage(self, file_lineage: Dict[str, List[str]]) -> str:
        """Formata linhagem de arquivos."""
        if not file_lineage:
            return "*Nenhuma linhagem de arquivo identificada*\n"
        
        result = []
        for program, files in file_lineage.items():
            result.append(f"- **{program}** → {', '.join(files)}")
        
        return "\n".join(result) + "\n"
    
    def _format_data_lineage(self, data_lineage: Dict[str, List[str]]) -> str:
        """Formata linhagem de dados."""
        if not data_lineage:
            return "*Nenhuma linhagem de copybook identificada*\n"
        
        result = []
        for program, copybooks in data_lineage.items():
            result.append(f"- **{program}** → {', '.join(copybooks)}")
        
        return "\n".join(result) + "\n"
    
    def _format_node_type_distribution(self, distribution: Dict[str, int]) -> str:
        """Formata distribuição por tipo de nó."""
        if not distribution:
            return "*Nenhuma distribuição identificada*\n"
        
        result = ["| Tipo de Componente | Quantidade |",
                 "|-------------------|------------|"]
        
        for node_type, count in distribution.items():
            result.append(f"| {node_type} | {count} |")
        
        return "\n".join(result) + "\n"
    
    def _format_execution_nodes(self, nodes: Dict[str, Any]) -> str:
        """Formata nós de execução."""
        result = ["| Programa | Tipo | Dependências | Dependentes | Ordem | Nível |",
                 "|----------|------|--------------|-------------|-------|-------|"]
        
        for name, node in nodes.items():
            deps = len(node['dependencies'])
            dependents = len(node['dependents'])
            order = node['execution_order'] if node['execution_order'] is not None else "N/A"
            level = node['execution_level'] if node['execution_level'] is not None else "N/A"
            
            result.append(f"| {name} | {node['node_type']} | {deps} | {dependents} | {order} | {level} |")
        
        return "\n".join(result) + "\n"
    
    def _generate_completeness_recommendations(self, missing: Dict[str, List[str]], 
                                             summary: Dict[str, Any]) -> str:
        """Gera recomendações de completude."""
        recommendations = []
        
        if missing['not_found']:
            recommendations.append(" **Verificar Arquivos Não Encontrados:** Confirmar se os caminhos dos arquivos estão corretos")
        
        if missing['not_parsed']:
            recommendations.append(" **Corrigir Problemas de Parsing:** Verificar sintaxe dos programas não parseados")
        
        if missing['not_analyzed']:
            recommendations.append("🤖 **Completar Análise:** Executar análise dos programas pendentes")
        
        if missing['not_documented']:
            recommendations.append("📝 **Gerar Documentação:** Completar documentação dos programas analisados")
        
        if missing['with_errors']:
            recommendations.append(" **Resolver Erros:** Corrigir problemas identificados nos programas com erro")
        
        if summary['completeness_percentage'] < 100:
            recommendations.append(f" **Melhorar Completude:** Atual {summary['completeness_percentage']:.1f}% - Meta: 100%")
        
        if not recommendations:
            recommendations.append(" **Processamento Completo:** Todos os programas foram processados com sucesso")
        
        return "\n".join(recommendations) + "\n"
    
    def _generate_lineage_recommendations(self, flow_data: Dict[str, Any], 
                                        parallel_opportunities: List[Dict[str, Any]]) -> str:
        """Gera recomendações de linhagem."""
        recommendations = []
        
        if parallel_opportunities:
            total_parallelization = sum(opp['parallelization_factor'] for opp in parallel_opportunities)
            recommendations.append(f" **Otimização de Performance:** {len(parallel_opportunities)} oportunidades de paralelização identificadas (fator total: {total_parallelization}x)")
        
        if flow_data['summary']['entry_points'] == 0:
            recommendations.append(" **Identificar Pontos de Entrada:** Nenhum ponto de entrada claro identificado - revisar dependências")
        
        if flow_data['summary']['terminal_points'] == 0:
            recommendations.append("🏁 **Identificar Pontos Terminais:** Nenhum ponto terminal identificado - possível loop ou dependência circular")
        
        avg_deps = flow_data['summary']['avg_dependencies_per_program']
        if avg_deps > 5:
            recommendations.append(f"🔗 **Reduzir Acoplamento:** Média de {avg_deps:.1f} dependências por programa - considerar refatoração")
        
        if flow_data['summary']['total_sequences'] > flow_data['summary']['total_programs']:
            recommendations.append(" **Simplificar Fluxo:** Múltiplas sequências detectadas - considerar consolidação")
        
        if not recommendations:
            recommendations.append(" **Fluxo Otimizado:** Linhagem bem estruturada sem problemas identificados")
        
        return "\n".join(recommendations) + "\n"
    
    def _format_expected_programs_status(self, expected_programs: List[str],
                                       completeness_data: Dict[str, Any],
                                       flow_data: Dict[str, Any]) -> str:
        """Formata status dos programas esperados."""
        result = ["| Programa | Processado | Mapeado | Ordem | Nível | Status |",
                 "|----------|------------|---------|-------|-------|--------|"]
        
        for program in expected_programs:
            # Status de processamento
            prog_details = completeness_data['program_details'].get(program, {})
            processed = "" if prog_details.get('documented', False) else ""
            
            # Status de mapeamento
            node = flow_data['execution_nodes'].get(program, {})
            mapped = "" if node else ""
            
            order = node.get('execution_order', 'N/A') if node else 'N/A'
            level = node.get('execution_level', 'N/A') if node else 'N/A'
            
            # Status geral
            if processed == "" and mapped == "":
                status = " Completo"
            elif processed == "":
                status = "⚠ Processado"
            elif mapped == "":
                status = "⚠ Mapeado"
            else:
                status = " Pendente"
            
            result.append(f"| {program} | {processed} | {mapped} | {order} | {level} | {status} |")
        
        return "\n".join(result) + "\n"
    
    def _format_sequence_summary(self, sequences: List[Dict[str, Any]]) -> str:
        """Formata resumo das sequências."""
        if not sequences:
            return "*Nenhuma sequência identificada*\n"
        
        # Agrupar por tipo
        by_type = {}
        for seq in sequences:
            seq_type = seq['sequence_type']
            if seq_type not in by_type:
                by_type[seq_type] = []
            by_type[seq_type].append(seq)
        
        result = ["| Tipo de Sequência | Quantidade | Programas Envolvidos |",
                 "|-------------------|------------|---------------------|"]
        
        for seq_type, seqs in by_type.items():
            count = len(seqs)
            total_programs = sum(seq['total_programs'] for seq in seqs)
            result.append(f"| {seq_type} | {count} | {total_programs} |")
        
        return "\n".join(result) + "\n"
    
    def _format_dependency_matrix(self, expected_programs: List[str],
                                execution_nodes: Dict[str, Any]) -> str:
        """Formata matriz de dependências."""
        result = ["### Matriz de Dependências Entre Programas\n"]
        
        # Criar matriz
        matrix_header = ["| Programa |"] + [f" {p[:8]} |" for p in expected_programs]
        result.append("".join(matrix_header))
        
        separator = ["|----------|"] + [" :---: |" for _ in expected_programs]
        result.append("".join(separator))
        
        for source_prog in expected_programs:
            row = [f"| **{source_prog}** |"]
            source_node = execution_nodes.get(source_prog, {})
            dependencies = source_node.get('dependencies', [])
            
            for target_prog in expected_programs:
                if target_prog in dependencies:
                    row.append("  |")
                else:
                    row.append(" - |")
            
            result.append("".join(row))
        
        return "\n".join(result) + "\n"
    
    def _generate_impact_analysis(self, expected_programs: List[str],
                                completeness_data: Dict[str, Any],
                                flow_data: Dict[str, Any]) -> str:
        """Gera análise de impacto."""
        analysis = []
        
        # Programas críticos (com muitos dependentes)
        critical_programs = []
        for program in expected_programs:
            node = flow_data['execution_nodes'].get(program, {})
            dependents = len(node.get('dependents', []))
            if dependents >= 2:
                critical_programs.append((program, dependents))
        
        if critical_programs:
            critical_programs.sort(key=lambda x: x[1], reverse=True)
            analysis.append("### Programas Críticos (Alto Impacto)")
            for program, dependents in critical_programs[:5]:
                analysis.append(f"- **{program}**: {dependents} programas dependem dele")
            analysis.append("")
        
        # Programas isolados
        isolated_programs = []
        for program in expected_programs:
            node = flow_data['execution_nodes'].get(program, {})
            deps = len(node.get('dependencies', []))
            dependents = len(node.get('dependents', []))
            if deps == 0 and dependents == 0:
                isolated_programs.append(program)
        
        if isolated_programs:
            analysis.append("### Programas Isolados (Sem Dependências)")
            for program in isolated_programs:
                analysis.append(f"- **{program}**: Execução independente")
            analysis.append("")
        
        return "\n".join(analysis)
    
    def _generate_action_plan(self, validation_data: Dict[str, Any],
                            completeness_data: Dict[str, Any]) -> str:
        """Gera plano de ação."""
        actions = []
        
        if not validation_data['validation_passed']:
            actions.append("### 🚨 Ações Críticas")
            
            if validation_data['missing_from_flow']:
                actions.append("1. **Mapear Programas Ausentes:** Incluir no fluxo de execução")
            
            if validation_data['programs_without_order']:
                actions.append("2. **Definir Ordem de Execução:** Estabelecer sequência para programas pendentes")
            
            actions.append("")
        
        completeness_pct = completeness_data['summary']['completeness_percentage']
        if completeness_pct < 100:
            actions.append("###  Ações de Completude")
            actions.append(f"1. **Completar Processamento:** {100 - completeness_pct:.1f}% restante")
            actions.append("2. **Validar Resultados:** Verificar qualidade da documentação gerada")
            actions.append("")
        
        actions.append("###  Ações de Melhoria")
        actions.append("1. **Otimizar Execução:** Implementar paralelização identificada")
        actions.append("2. **Monitorar Dependências:** Acompanhar mudanças no fluxo")
        actions.append("3. **Documentar Processo:** Manter documentação atualizada")
        
        return "\n".join(actions) + "\n"

