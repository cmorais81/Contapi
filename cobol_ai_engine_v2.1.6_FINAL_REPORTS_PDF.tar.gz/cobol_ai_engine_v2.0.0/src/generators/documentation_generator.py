"""
COBOL AI Engine v1.3.0 - Documentation Generator
Gerador completo de documentação com suporte a faseamento e múltiplos formatos.
"""

import logging
import os
from typing import Dict, Any, List, Optional
from datetime import datetime

from ..parsers.cobol_parser import CobolProgram, CobolBook
from ..providers.base_provider import AIResponse


class DocumentationGenerator:
    """
    Gerador de documentação completo para programas COBOL.
    
    Funcionalidades:
    - Geração de documentação individual por programa
    - Relatório consolidado
    - Suporte a metadados de faseamento
    - Múltiplos formatos de saída
    - Estatísticas detalhadas
    """
    
    def __init__(self, output_dir: str = "output"):
        """
        Inicializa o gerador de documentação.
        
        Args:
            output_dir: Diretório de saída
        """
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        
        # Criar diretório de saída
        os.makedirs(output_dir, exist_ok=True)
        
        # Estatísticas
        self.files_generated = 0
        self.total_programs = 0
        self.total_books = 0
        
        self.logger.info(f"Documentation Generator inicializado - Output: {output_dir}")
    
    def generate_program_documentation(self, program: CobolProgram, 
                                     ai_response: AIResponse,
                                     phase_info: Optional[Dict[str, Any]] = None) -> str:
        """
        Gera documentação completa para um programa COBOL.
        
        Args:
            program: Programa COBOL analisado
            ai_response: Resposta da análise de IA
            phase_info: Informações de faseamento (opcional)
            
        Returns:
            Caminho do arquivo gerado
        """
        try:
            # Gerar conteúdo
            content = self._generate_program_content(program, ai_response, phase_info)
            
            # Salvar arquivo
            filename = f"{program.name}.md"
            filepath = os.path.join(self.output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.files_generated += 1
            self.total_programs += 1
            
            self.logger.info(f"Documentação gerada: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação para {program.name}: {e}")
            return ""
    
    def _generate_program_content(self, program: CobolProgram, 
                                ai_response: AIResponse,
                                phase_info: Optional[Dict[str, Any]] = None) -> str:
        """Gera conteúdo da documentação do programa."""
        
        # Obter documentação de prompts se disponível
        prompt_documentation = ""
        if hasattr(ai_response, 'prompt_manager') and ai_response.prompt_manager:
            prompt_documentation = ai_response.prompt_manager.get_prompt_documentation()
        
        # Obter prompts utilizados
        prompts_used = getattr(ai_response, 'prompts_used', {})
        
        content = f"""# Documentação Técnica e Funcional Completa: {program.name}

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Versão do Sistema**: COBOL AI Engine v1.3.0

## Resumo Executivo

**Nome do Programa:** {program.name}
**Tamanho do Código:** {program.size} caracteres ({program.line_count} linhas)
**Tipo de Componente:** {'Programa Principal' if 'PROGRAM-ID' in program.content else 'Copybook/Módulo'}
**Complexidade:** {'Alta' if program.line_count > 500 else 'Média' if program.line_count > 100 else 'Baixa'}

### Descrição Geral
Este documento apresenta uma análise técnica e funcional completa do componente COBOL {program.name}. 
A análise foi realizada utilizando inteligência artificial avançada para garantir compreensão profunda 
do código fonte, identificação de padrões, regras de negócio e relacionamentos com outros componentes 
do sistema. O objetivo é fornecer documentação clara e detalhada que facilite a manutenção, 
evolução e compreensão do sistema.

## Análise Detalhada Realizada pela IA

{ai_response.content}

{prompt_documentation}

## Informações Técnicas Detalhadas

### Características do Código Fonte
- **Total de Linhas:** {program.line_count} linhas
- **Tamanho em Caracteres:** {program.size} caracteres
- **Densidade de Código:** {len([line for line in program.content.split(chr(10)) if line.strip() and not line.strip().startswith('*')])} linhas efetivas
- **Linhas de Comentário:** {len([line for line in program.content.split(chr(10)) if line.strip().startswith('*')])} linhas
- **Percentual de Documentação:** {(len([line for line in program.content.split(chr(10)) if line.strip().startswith('*')]) / max(program.line_count, 1) * 100):.1f}%

### Estrutura Hierárquica do Programa

#### Divisões Identificadas"""
        
        # Adicionar divisões com mais detalhes
        if program.divisions:
            for division_name, division_content in program.divisions.items():
                lines_count = len(division_content.split(chr(10)))
                content += f"""
**{division_name} DIVISION**
- Linhas de código: {lines_count}
- Percentual do programa: {(lines_count / max(program.line_count, 1) * 100):.1f}%
- Função: {self._get_division_description(division_name)}
"""
        else:
            content += "\nEstrutura COBOL padrão detectada - análise detalhada realizada pela IA acima.\n"
        
        # Adicionar seções com mais detalhes
        content += "\n#### Seções Identificadas\n"
        if program.sections:
            content += f"Total de seções encontradas: {len(program.sections)}\n\n"
            for i, section in enumerate(program.sections[:15], 1):  # Limitar a 15
                content += f"{i}. **{section}**\n"
                content += f"   - Tipo: {self._get_section_type(section)}\n"
                content += f"   - Propósito: {self._get_section_purpose(section)}\n\n"
            if len(program.sections) > 15:
                content += f"... e mais {len(program.sections) - 15} seções adicionais\n"
        else:
            content += "Estrutura de seções analisada pela IA - detalhes na análise funcional acima.\n"
        
        # Adicionar variáveis com mais detalhes
        content += "\n#### Principais Variáveis e Estruturas de Dados\n"
        if program.variables:
            content += f"Total de variáveis identificadas: {len(program.variables)}\n\n"
            for i, variable in enumerate(program.variables[:20], 1):  # Limitar a 20
                content += f"{i}. **{variable}**\n"
                content += f"   - Categoria: {self._get_variable_category(variable)}\n"
                content += f"   - Uso estimado: {self._get_variable_usage(variable)}\n\n"
            if len(program.variables) > 20:
                content += f"... e mais {len(program.variables) - 20} variáveis adicionais\n"
        else:
            content += "Estruturas de dados analisadas pela IA - detalhes na análise técnica acima.\n"
        
        # Adicionar arquivos com mais detalhes
        content += "\n#### Arquivos e Recursos Utilizados\n"
        if program.files:
            content += f"Total de arquivos identificados: {len(program.files)}\n\n"
            for i, file_name in enumerate(program.files, 1):
                content += f"{i}. **{file_name}**\n"
                content += f"   - Tipo: {self._get_file_type(file_name)}\n"
                content += f"   - Função: {self._get_file_purpose(file_name)}\n\n"
        else:
            content += "Recursos e dependências analisados pela IA - detalhes na análise de relacionamentos acima.\n"
        
        # Adicionar informações de faseamento se disponível
        phase_content = ""
        if phase_info:
            phase_content = f"""
## Informações de Processamento Multi-Fase

**Número de Fases:** {phase_info.get('total_phases', 1)}
**Fase Atual:** {phase_info.get('current_phase', 1)}
**Tokens por Fase:** {phase_info.get('tokens_per_phase', 'N/A')}
**Estratégia de Divisão:** {phase_info.get('split_strategy', 'Automática baseada em tokens')}

### Detalhes do Faseamento
{phase_info.get('phase_details', 'Processamento realizado em fase única devido ao tamanho do programa.')}
"""
        
        # Adicionar seção de prompts utilizados
        prompts_section = ""
        if prompts_used and isinstance(prompts_used, dict):
            prompts_section = f"""
## Transparência e Auditoria

### Prompts Utilizados na Análise

#### Prompt Principal
```
{prompts_used.get('original_prompt', 'Prompt padrão de análise COBOL utilizado')}
```

#### Contexto do Sistema
```
{prompts_used.get('system_prompt', 'Contexto de análise técnica de programas COBOL')}
```

#### Informações do Programa
```
{prompts_used.get('context', f'Programa: {program.name}, Tamanho: {program.size} caracteres')}
```

#### Perguntas Específicas Realizadas
{chr(10).join([f'- {question}' for question in prompts_used.get('questions', ['Análise funcional', 'Estrutura técnica', 'Regras de negócio'])]) if prompts_used.get('questions') else '- Análise funcional completa realizada'}
"""
        
        # Adicionar metadados detalhados da análise
        metadata_section = self._generate_metadata_section(ai_response)
        
        content += f"""
{phase_content}

{prompts_section}

{metadata_section}

## Metadados Completos da Análise

### Informações do Processamento de IA
- **Provedor Utilizado:** {ai_response.provider}
- **Modelo de IA:** {ai_response.model}
- **Total de Tokens Processados:** {ai_response.tokens_used}
- **Timestamp da Análise:** {ai_response.timestamp}
- **Status do Processamento:** {getattr(ai_response, 'status', 'Concluído com sucesso')}
- **Tempo de Processamento:** {getattr(ai_response, 'processing_time', 'N/A')} segundos
- **Qualidade da Análise:** {'Excelente' if ai_response.tokens_used > 1000 else 'Boa' if ai_response.tokens_used > 500 else 'Básica'}

### Estatísticas de Análise
- **Profundidade da Análise:** {'Completa' if len(ai_response.content) > 2000 else 'Detalhada' if len(ai_response.content) > 1000 else 'Resumida'}
- **Cobertura do Código:** {'Total' if program.line_count < 1000 else 'Extensiva' if program.line_count < 2000 else 'Segmentada'}
- **Nível de Detalhamento:** {'Alto' if len(ai_response.content.split('.')) > 20 else 'Médio' if len(ai_response.content.split('.')) > 10 else 'Básico'}

### Metodologia Aplicada
A análise deste componente COBOL foi realizada seguindo uma metodologia estruturada que combina:

1. **Análise Estrutural Automatizada:** Identificação de divisões, seções, parágrafos e estruturas de dados
2. **Análise Semântica com IA:** Compreensão do propósito, funcionalidades e regras de negócio
3. **Análise de Contexto:** Identificação de relacionamentos e dependências
4. **Validação de Qualidade:** Verificação da consistência e completude da documentação gerada

### Limitações e Considerações Importantes
- Esta análise é baseada exclusivamente no código fonte fornecido
- Dependências externas e configurações de ambiente podem não estar refletidas
- Regras de negócio específicas podem requerer conhecimento adicional do domínio
- Para sistemas críticos, recomenda-se validação adicional com especialistas em COBOL
- A qualidade da análise está diretamente relacionada à clareza e documentação do código original

### Recomendações para Uso
- Utilize esta documentação como base para compreensão do componente
- Complemente com conhecimento específico do negócio quando necessário
- Mantenha esta documentação atualizada conforme evoluções do código
- Considere esta análise como ponto de partida para modernização ou migração

---
**Documentação gerada automaticamente pelo COBOL AI Engine v1.3.0**
**Sistema de Análise Inteligente de Programas COBOL**
**Data de Geração:** {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
**Qualidade:** Análise Detalhada e Transparente
"""
        
        return content
    
    def _get_division_description(self, division_name: str) -> str:
        """Retorna descrição da divisão COBOL."""
        descriptions = {
            "IDENTIFICATION": "Identificação do programa e metadados",
            "ENVIRONMENT": "Configuração do ambiente e recursos",
            "DATA": "Definição de estruturas de dados e variáveis",
            "PROCEDURE": "Lógica principal e procedimentos do programa"
        }
        return descriptions.get(division_name.upper(), "Divisão específica do programa")
    
    def _get_section_type(self, section_name: str) -> str:
        """Identifica o tipo da seção."""
        section_upper = section_name.upper()
        if "INPUT-OUTPUT" in section_upper:
            return "Configuração de E/S"
        elif "FILE-CONTROL" in section_upper:
            return "Controle de Arquivos"
        elif "WORKING-STORAGE" in section_upper:
            return "Área de Trabalho"
        elif "LINKAGE" in section_upper:
            return "Interface Externa"
        else:
            return "Seção Procedimental"
    
    def _get_section_purpose(self, section_name: str) -> str:
        """Retorna o propósito da seção."""
        section_upper = section_name.upper()
        if "INPUT-OUTPUT" in section_upper:
            return "Define configurações de entrada e saída"
        elif "FILE-CONTROL" in section_upper:
            return "Especifica arquivos utilizados pelo programa"
        elif "WORKING-STORAGE" in section_upper:
            return "Declara variáveis de trabalho e constantes"
        elif "LINKAGE" in section_upper:
            return "Define interface com programas externos"
        else:
            return "Contém lógica de processamento"
    
    def _get_variable_category(self, variable_name: str) -> str:
        """Categoriza a variável baseada no nome."""
        var_upper = variable_name.upper()
        if var_upper.startswith('WS-'):
            return "Variável de Working Storage"
        elif var_upper.startswith('LS-'):
            return "Variável de Linkage Section"
        elif var_upper.startswith('FD-'):
            return "Descrição de Arquivo"
        elif any(prefix in var_upper for prefix in ['CNT-', 'CONT-', 'COUNT']):
            return "Contador"
        elif any(prefix in var_upper for prefix in ['SW-', 'FLAG-', 'IND-']):
            return "Indicador/Flag"
        else:
            return "Variável de Dados"
    
    def _get_variable_usage(self, variable_name: str) -> str:
        """Estima o uso da variável."""
        var_upper = variable_name.upper()
        if any(word in var_upper for word in ['ERRO', 'ERROR']):
            return "Tratamento de erros"
        elif any(word in var_upper for word in ['TOTAL', 'SUM', 'SOMA']):
            return "Acumulação/Totalização"
        elif any(word in var_upper for word in ['DATA', 'DATE']):
            return "Manipulação de datas"
        elif any(word in var_upper for word in ['NOME', 'NAME']):
            return "Armazenamento de nomes"
        else:
            return "Processamento geral"
    
    def _get_file_type(self, file_name: str) -> str:
        """Identifica o tipo do arquivo."""
        file_upper = file_name.upper()
        if any(ext in file_upper for ext in ['.DAT', '.DATA']):
            return "Arquivo de Dados"
        elif any(ext in file_upper for ext in ['.TXT', '.TEXT']):
            return "Arquivo Texto"
        elif any(ext in file_upper for ext in ['.IDX', '.INDEX']):
            return "Arquivo Indexado"
        elif any(word in file_upper for word in ['ENTRADA', 'INPUT']):
            return "Arquivo de Entrada"
        elif any(word in file_upper for word in ['SAIDA', 'OUTPUT']):
            return "Arquivo de Saída"
        else:
            return "Arquivo de Sistema"
    
    def _get_file_purpose(self, file_name: str) -> str:
        """Determina o propósito do arquivo."""
        file_upper = file_name.upper()
        if any(word in file_upper for word in ['LOG', 'AUDIT']):
            return "Registro de auditoria"
        elif any(word in file_upper for word in ['ERRO', 'ERROR']):
            return "Registro de erros"
        elif any(word in file_upper for word in ['RELAT', 'REPORT']):
            return "Geração de relatórios"
        elif any(word in file_upper for word in ['TEMP', 'TMP']):
            return "Arquivo temporário"
        else:
            return "Processamento de dados"

    def generate_book_documentation(self, book: CobolBook, 
                                  ai_response: AIResponse) -> str:
        """
        Gera documentação para um copybook COBOL.
        
        Args:
            book: Copybook COBOL analisado
            ai_response: Resposta da análise de IA
            
        Returns:
            Caminho do arquivo gerado
        """
        try:
            # Gerar conteúdo
            content = self._generate_book_content(book, ai_response)
            
            # Salvar arquivo
            filename = f"{book.name}_COPYBOOK.md"
            filepath = os.path.join(self.output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.files_generated += 1
            self.total_books += 1
            
            self.logger.info(f"Documentação de copybook gerada: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação para copybook {book.name}: {e}")
            return ""
    
    def _generate_book_content(self, book: CobolBook, ai_response: AIResponse) -> str:
        """Gera conteúdo da documentação do copybook."""
        
        # Obter prompts utilizados
        prompts_used = getattr(ai_response, 'prompts_used', {})
        
        content = f"""# Documentação de Copybook: {book.name}

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Versão do Sistema**: COBOL AI Engine v1.3.0

## Resumo Executivo

**Nome do Copybook:** {book.name}
**Tamanho do Código:** {book.size} caracteres ({book.line_count} linhas)
**Tipo de Componente:** Copybook/Biblioteca de Definições
**Complexidade:** {'Alta' if book.line_count > 200 else 'Média' if book.line_count > 50 else 'Baixa'}

### Descrição Geral
Este documento apresenta uma análise técnica completa do copybook COBOL {book.name}. 
Copybooks são componentes fundamentais em sistemas COBOL, contendo definições de dados, 
estruturas e constantes reutilizáveis por múltiplos programas. Esta análise identifica 
as estruturas definidas, seu propósito e como podem ser utilizadas em programas COBOL.

## Análise Detalhada do Copybook

{ai_response.content}

## Informações Técnicas Detalhadas

### Características do Copybook
- **Total de Linhas:** {book.line_count} linhas
- **Tamanho em Caracteres:** {book.size} caracteres
- **Densidade de Código:** {len([line for line in book.content.split(chr(10)) if line.strip() and not line.strip().startswith('*')])} linhas efetivas
- **Linhas de Comentário:** {len([line for line in book.content.split(chr(10)) if line.strip().startswith('*')])} linhas
- **Percentual de Documentação:** {(len([line for line in book.content.split(chr(10)) if line.strip().startswith('*')]) / max(book.line_count, 1) * 100):.1f}%

### Estruturas Definidas

#### Principais Definições de Dados"""
        
        # Adicionar variáveis do copybook
        if book.variables:
            content += f"\nTotal de definições encontradas: {len(book.variables)}\n\n"
            for i, variable in enumerate(book.variables[:25], 1):  # Limitar a 25
                content += f"{i}. **{variable}**\n"
                content += f"   - Categoria: {self._get_variable_category(variable)}\n"
                content += f"   - Uso típico: {self._get_variable_usage(variable)}\n\n"
            if len(book.variables) > 25:
                content += f"... e mais {len(book.variables) - 25} definições adicionais\n"
        else:
            content += "\nDefinições de dados analisadas pela IA - detalhes na análise técnica acima.\n"
        
        # Adicionar seção de prompts utilizados
        prompts_section = ""
        if prompts_used and isinstance(prompts_used, dict):
            prompts_section = f"""
## Transparência e Auditoria

### Prompts Utilizados na Análise

#### Prompt Principal
```
{prompts_used.get('original_prompt', 'Prompt padrão de análise de copybook COBOL utilizado')}
```

#### Contexto do Sistema
```
{prompts_used.get('system_prompt', 'Contexto de análise técnica de copybooks COBOL')}
```

#### Informações do Copybook
```
{prompts_used.get('context', f'Copybook: {book.name}, Tamanho: {book.size} caracteres')}
```
"""
        
        content += f"""
{prompts_section}

## Metadados da Análise

### Informações do Processamento de IA
- **Provedor Utilizado:** {ai_response.provider}
- **Modelo de IA:** {ai_response.model}
- **Total de Tokens Processados:** {ai_response.tokens_used}
- **Timestamp da Análise:** {ai_response.timestamp}
- **Status do Processamento:** {getattr(ai_response, 'status', 'Concluído com sucesso')}
- **Qualidade da Análise:** {'Excelente' if ai_response.tokens_used > 500 else 'Boa' if ai_response.tokens_used > 200 else 'Básica'}

### Uso Recomendado
- **Inclusão em Programas:** COPY {book.name}
- **Propósito Principal:** {self._get_copybook_purpose(book.name)}
- **Compatibilidade:** COBOL padrão
- **Dependências:** {self._get_copybook_dependencies(book.content)}

### Considerações de Manutenção
- Alterações neste copybook afetam todos os programas que o utilizam
- Recomenda-se versionamento adequado para controle de mudanças
- Testes de regressão são essenciais após modificações
- Documentação deve ser mantida atualizada com as definições

---
**Documentação gerada automaticamente pelo COBOL AI Engine v1.3.0**
**Sistema de Análise Inteligente de Programas COBOL**
**Data de Geração:** {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
**Tipo:** Análise de Copybook Detalhada
"""
        
        return content
    
    def _get_copybook_purpose(self, book_name: str) -> str:
        """Determina o propósito do copybook baseado no nome."""
        name_upper = book_name.upper()
        if any(word in name_upper for word in ['ERRO', 'ERROR']):
            return "Definições para tratamento de erros"
        elif any(word in name_upper for word in ['DATA', 'DATE']):
            return "Estruturas para manipulação de datas"
        elif any(word in name_upper for word in ['COMM', 'COMMON']):
            return "Definições comuns compartilhadas"
        elif any(word in name_upper for word in ['FILE', 'ARQUIVO']):
            return "Estruturas de arquivos"
        else:
            return "Definições de dados específicas do sistema"
    
    def _get_copybook_dependencies(self, content: str) -> str:
        """Identifica dependências do copybook."""
        if 'COPY ' in content.upper():
            return "Possui dependências de outros copybooks"
        elif any(word in content.upper() for word in ['CALL ', 'INVOKE ']):
            return "Pode ter dependências de programas externos"
        else:
            return "Sem dependências externas identificadas"

    def generate_consolidated_report(self, programs: List[CobolProgram], 
                                   books: List[CobolBook],
                                   analysis_results: Dict[str, Any],
                                   ai_responses: List[AIResponse] = None) -> str:
        """
        Gera relatório consolidado da análise com informações detalhadas de prompts.
        
        Args:
            programs: Lista de programas analisados
            books: Lista de copybooks analisados
            analysis_results: Resultados da análise
            ai_responses: Lista de respostas da IA com informações de prompts
            
        Returns:
            Caminho do arquivo gerado
        """
        try:
            content = self._generate_consolidated_content(programs, books, analysis_results, ai_responses)
            
            # Salvar arquivo
            filename = "relatorio_consolidado.md"
            filepath = os.path.join(self.output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.logger.info(f"Relatório consolidado gerado: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório consolidado: {e}")
            return ""
    
    def _generate_consolidated_content(self, programs: List[CobolProgram], 
                                     books: List[CobolBook],
                                     analysis_results: Dict[str, Any],
                                     ai_responses: List[AIResponse] = None) -> str:
        """Gera conteúdo do relatório consolidado com informações de prompts."""
        
        total_programs = len(programs)
        total_books = len(books)
        total_lines = sum(getattr(p, 'line_count', 0) for p in programs) + sum(getattr(b, 'line_count', 0) for b in books)
        total_size = sum(getattr(p, 'size', 0) for p in programs) + sum(getattr(b, 'size', 0) for b in books)
        
        # Estatísticas de análise
        successful_analyses = analysis_results.get('successful_analyses', 0)
        failed_analyses = analysis_results.get('failed_analyses', 0)
        total_tokens = analysis_results.get('total_tokens', 0)
        processing_time = analysis_results.get('processing_time', 0)
        
        # Informações de prompts
        prompt_info = self._extract_prompt_information(ai_responses) if ai_responses else {}
        
        content = f"""# Relatório Consolidado de Análise COBOL

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Versão do Sistema**: COBOL AI Engine v2.1.5

## Resumo Executivo da Análise

### Componentes Analisados
- **Total de Programas COBOL:** {total_programs}
- **Total de Copybooks:** {total_books}
- **Total de Componentes:** {total_programs + total_books}
- **Linhas de Código Total:** {total_lines:,} linhas
- **Tamanho Total:** {total_size:,} caracteres

### Resultados da Análise
- **Análises Bem-sucedidas:** {successful_analyses}/{total_programs + total_books}
- **Taxa de Sucesso:** {(successful_analyses / max(total_programs + total_books, 1) * 100):.1f}%
- **Análises com Falha:** {failed_analyses}
- **Total de Tokens Utilizados:** {total_tokens:,}
- **Tempo Total de Processamento:** {processing_time:.2f} segundos
- **Eficiência:** {(total_tokens / max(processing_time, 0.1)):.0f} tokens/segundo

## Detalhamento por Componente

### Programas COBOL Analisados"""
        
        if programs:
            for i, program in enumerate(programs, 1):
                complexity = 'Alta' if getattr(program, 'line_count', 0) > 500 else 'Média' if getattr(program, 'line_count', 0) > 100 else 'Baixa'
                content += f"""
{i}. **{program.name}**
   - Linhas de código: {getattr(program, 'line_count', 0)}
   - Tamanho: {getattr(program, 'size', 0)} caracteres
   - Complexidade: {complexity}
   - Status: {'Analisado com sucesso' if program.name in analysis_results.get('successful_programs', []) else 'Análise pendente'}
"""
        else:
            content += "\nNenhum programa COBOL foi analisado nesta execução.\n"
        
        content += "\n### Copybooks Analisados"
        
        if books:
            for i, book in enumerate(books, 1):
                complexity = 'Alta' if getattr(book, 'line_count', 0) > 200 else 'Média' if getattr(book, 'line_count', 0) > 50 else 'Baixa'
                content += f"""
{i}. **{book.name}**
   - Linhas de código: {getattr(book, 'line_count', 0)}
   - Tamanho: {getattr(book, 'size', 0)} caracteres
   - Complexidade: {complexity}
   - Status: {'Analisado com sucesso' if book.name in analysis_results.get('successful_books', []) else 'Análise pendente'}
"""
        else:
            content += "\nNenhum copybook foi analisado nesta execução.\n"
        
        # Estatísticas detalhadas
        content += f"""
## Estatísticas Detalhadas

### Distribuição por Complexidade

#### Programas COBOL
- **Alta Complexidade (>500 linhas):** {len([p for p in programs if getattr(p, 'line_count', 0) > 500])} programas
- **Média Complexidade (100-500 linhas):** {len([p for p in programs if 100 <= getattr(p, 'line_count', 0) <= 500])} programas
- **Baixa Complexidade (<100 linhas):** {len([p for p in programs if getattr(p, 'line_count', 0) < 100])} programas

#### Copybooks
- **Alta Complexidade (>200 linhas):** {len([b for b in books if getattr(b, 'line_count', 0) > 200])} copybooks
- **Média Complexidade (50-200 linhas):** {len([b for b in books if 50 <= getattr(b, 'line_count', 0) <= 200])} copybooks
- **Baixa Complexidade (<50 linhas):** {len([b for b in books if getattr(b, 'line_count', 0) < 50])} copybooks

### Métricas de Qualidade
- **Densidade Média de Documentação:** {self._calculate_documentation_density(programs + books):.1f}%
- **Tamanho Médio de Programa:** {(sum(getattr(p, 'line_count', 0) for p in programs) / max(len(programs), 1)):.0f} linhas
- **Tamanho Médio de Copybook:** {(sum(getattr(b, 'line_count', 0) for b in books) / max(len(books), 1)):.0f} linhas

### Eficiência do Processamento
- **Tokens por Componente:** {(total_tokens / max(total_programs + total_books, 1)):.0f} tokens/componente
- **Tempo por Componente:** {(processing_time / max(total_programs + total_books, 1)):.2f} segundos/componente
- **Throughput:** {((total_programs + total_books) / max(processing_time / 3600, 0.001)):.1f} componentes/hora

## Recomendações e Próximos Passos

### Componentes Prioritários para Revisão
{self._get_priority_recommendations(programs, books)}

### Oportunidades de Melhoria
- Componentes com baixa documentação podem se beneficiar de comentários adicionais
- Programas de alta complexidade podem ser candidatos a refatoração
- Copybooks extensos podem ser divididos em módulos menores

### Considerações para Manutenção
- Estabelecer padrões de documentação baseados na análise realizada
- Implementar revisões periódicas dos componentes identificados como críticos
- Considerar modernização gradual dos componentes mais complexos

---
**Relatório gerado automaticamente pelo COBOL AI Engine v1.3.0**
**Sistema de Análise Inteligente de Programas COBOL**
**Data de Geração:** {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
**Escopo:** Análise Consolidada Completa
"""
        
        # Adicionar seção de informações de prompts
        if prompt_info:
            content += f"""

## Informações Detalhadas dos Prompts Utilizados

### Configuração de Prompts
- **System Prompt Utilizado:** {prompt_info.get('system_prompt_source', 'Configuração padrão')}
- **Tamanho do System Prompt:** {prompt_info.get('system_prompt_length', 0)} caracteres
- **Provedor Principal:** {prompt_info.get('primary_provider', 'N/A')}
- **Modelos Utilizados:** {', '.join(prompt_info.get('models_used', []))}

### Estatísticas de Prompts
- **Total de Prompts Enviados:** {prompt_info.get('total_prompts', 0)}
- **Tamanho Médio dos Prompts:** {prompt_info.get('average_prompt_size', 0)} caracteres
- **Maior Prompt:** {prompt_info.get('max_prompt_size', 0)} caracteres
- **Menor Prompt:** {prompt_info.get('min_prompt_size', 0)} caracteres

### System Prompt Utilizado
```
{prompt_info.get('system_prompt_content', 'System prompt não disponível')}
```

### Exemplo de Prompt de Análise
```
{prompt_info.get('sample_user_prompt', 'Prompt de exemplo não disponível')}
```

### Provedores e Modelos por Análise
{self._generate_provider_details_table(prompt_info.get('provider_details', []))}
"""
        
        return content
    
    def _calculate_documentation_density(self, components) -> float:
        """Calcula a densidade média de documentação."""
        if not components:
            return 0.0
        
        total_lines = 0
        total_comment_lines = 0
        
        for component in components:
            content = getattr(component, 'content', '')
            lines = content.split(chr(10))
            total_lines += len(lines)
            total_comment_lines += len([line for line in lines if line.strip().startswith('*')])
        
        return (total_comment_lines / max(total_lines, 1)) * 100
    
    def _get_priority_recommendations(self, programs, books) -> str:
        """Gera recomendações de prioridade."""
        high_complexity_programs = [p for p in programs if getattr(p, 'line_count', 0) > 500]
        low_doc_components = []  # Seria calculado baseado na densidade de documentação
        
        recommendations = []
        
        if high_complexity_programs:
            recommendations.append(f"- **Programas de Alta Complexidade:** {', '.join([p.name for p in high_complexity_programs[:5]])}")
        
        if len(programs) > 10:
            recommendations.append("- **Volume Elevado:** Considerar análise em lotes para otimização")
        
        if not recommendations:
            recommendations.append("- **Sistema Bem Estruturado:** Componentes dentro de padrões aceitáveis")
        
        return chr(10).join(recommendations)
    
    def _extract_prompt_information(self, ai_responses: List[AIResponse]) -> Dict[str, Any]:
        """
        Extrai informações detalhadas dos prompts utilizados.
        
        Args:
            ai_responses: Lista de respostas da IA
            
        Returns:
            Dicionário com informações dos prompts
        """
        if not ai_responses:
            return {}
        
        # Carregar system prompt atual
        try:
            from ..core.config import ConfigManager
            config_manager = ConfigManager("config/config_unified.yaml")
            system_prompt = config_manager.get_system_prompt()
        except:
            system_prompt = "System prompt não disponível"
        
        # Extrair informações dos prompts
        prompt_sizes = []
        providers_used = set()
        models_used = set()
        provider_details = []
        sample_user_prompt = ""
        
        for response in ai_responses:
            if hasattr(response, 'prompts_used') and response.prompts_used:
                user_prompt = response.prompts_used.get('original_prompt', '')
                if user_prompt and len(user_prompt) > len(sample_user_prompt):
                    sample_user_prompt = user_prompt
                
                if user_prompt:
                    prompt_sizes.append(len(user_prompt))
            
            providers_used.add(response.provider)
            models_used.add(response.model)
            
            provider_details.append({
                'provider': response.provider,
                'model': response.model,
                'tokens_used': response.tokens_used,
                'timestamp': response.timestamp.strftime('%H:%M:%S') if response.timestamp else 'N/A'
            })
        
        return {
            'system_prompt_source': 'config/prompts.yaml',
            'system_prompt_length': len(system_prompt),
            'system_prompt_content': system_prompt,
            'primary_provider': list(providers_used)[0] if providers_used else 'N/A',
            'models_used': list(models_used),
            'total_prompts': len(ai_responses),
            'average_prompt_size': int(sum(prompt_sizes) / len(prompt_sizes)) if prompt_sizes else 0,
            'max_prompt_size': max(prompt_sizes) if prompt_sizes else 0,
            'min_prompt_size': min(prompt_sizes) if prompt_sizes else 0,
            'sample_user_prompt': sample_user_prompt[:500] + '...' if len(sample_user_prompt) > 500 else sample_user_prompt,
            'provider_details': provider_details
        }
    
    def _generate_provider_details_table(self, provider_details: List[Dict]) -> str:
        """
        Gera tabela com detalhes dos provedores utilizados.
        
        Args:
            provider_details: Lista com detalhes dos provedores
            
        Returns:
            Tabela formatada em markdown
        """
        if not provider_details:
            return "Nenhum detalhe de provedor disponível."
        
        table = """
| Análise | Provedor | Modelo | Tokens | Horário |
|---------|----------|--------|--------|---------|
"""
        
        for i, detail in enumerate(provider_details, 1):
            table += f"| {i} | {detail['provider']} | {detail['model']} | {detail['tokens_used']} | {detail['timestamp']} |\n"
        
        return table
    
    def generate_functional_report(self, programs: List[CobolProgram], 
                                 books: List[CobolBook],
                                 analysis_results: Dict[str, Any],
                                 ai_responses: List[AIResponse] = None) -> str:
        """
        Gera relatório funcional centralizado com todas as informações funcionais.
        
        Args:
            programs: Lista de programas analisados
            books: Lista de copybooks analisados
            analysis_results: Resultados da análise
            ai_responses: Lista de respostas da IA
            
        Returns:
            Caminho do arquivo gerado
        """
        try:
            content = self._generate_functional_content(programs, books, analysis_results, ai_responses)
            
            # Salvar arquivo
            filename = "relatorio_funcional_centralizado.md"
            filepath = os.path.join(self.output_dir, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.logger.info(f"Relatório funcional centralizado gerado: {filename}")
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório funcional centralizado: {e}")
            return ""
    
    def _generate_functional_content(self, programs: List[CobolProgram], 
                                   books: List[CobolBook],
                                   analysis_results: Dict[str, Any],
                                   ai_responses: List[AIResponse] = None) -> str:
        """Gera conteúdo do relatório funcional centralizado."""
        
        content = f"""# Relatório Funcional Centralizado - Análise COBOL

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Versão do Sistema**: COBOL AI Engine v2.1.5
**Escopo**: Consolidação Funcional Completa

## Sumário Executivo

Este relatório consolida todas as informações funcionais extraídas dos programas COBOL analisados, organizando-as por domínio funcional e fornecendo uma visão unificada das regras de negócio, processos e funcionalidades implementadas no sistema.

### Componentes Analisados
- **Programas COBOL**: {len(programs)}
- **Copybooks**: {len(books)}
- **Total de Componentes**: {len(programs) + len(books)}

## Mapeamento Funcional por Programa

"""
        
        # Adicionar análise funcional de cada programa
        for i, program in enumerate(programs, 1):
            content += self._generate_program_functional_analysis(program, i, ai_responses)
        
        # Adicionar análise funcional de copybooks
        if books:
            content += "\n## Mapeamento Funcional por Copybook\n\n"
            for i, book in enumerate(books, 1):
                content += self._generate_book_functional_analysis(book, i, ai_responses)
        
        # Adicionar consolidação funcional
        content += self._generate_functional_consolidation(programs, books, ai_responses)
        
        # Adicionar mapeamento de dependências funcionais
        content += self._generate_functional_dependencies_map(programs, books)
        
        # Adicionar recomendações funcionais
        content += self._generate_functional_recommendations(programs, books)
        
        content += f"""

---
**Relatório Funcional Centralizado gerado pelo COBOL AI Engine v2.1.5**
**Data de Geração:** {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
**Escopo:** Análise Funcional Completa e Consolidada
"""
        
        return content
    
    def _find_analysis_for_program(self, program_name: str, ai_responses: List[AIResponse] = None) -> str:
        """Encontra a análise correspondente a um programa."""
        if not ai_responses:
            return ""
        
        for response in ai_responses:
            if hasattr(response, 'program_name') and response.program_name == program_name:
                return response.content
            # Fallback: verificar se o nome do programa está no conteúdo
            if program_name in response.content:
                return response.content
        
        return ""
    
    def _generate_program_functional_analysis(self, program: CobolProgram, index: int, ai_responses: List[AIResponse] = None) -> str:
        """Gera análise funcional detalhada de um programa."""
        
        # Buscar análise correspondente
        program_analysis = self._find_analysis_for_program(program.name, ai_responses)
        
        content = f"""### {index}. {program.name}

**Características Técnicas:**
- **Linhas de Código:** {getattr(program, 'line_count', 0)}
- **Tamanho:** {getattr(program, 'size', 0)} caracteres
- **Complexidade:** {self._calculate_complexity_level(program)}

**Análise Funcional:**
"""
        
        if program_analysis:
            # Extrair informações funcionais da análise
            functional_info = self._extract_functional_information(program_analysis)
            
            content += f"""
**Objetivo Principal:**
{functional_info.get('main_purpose', 'Não identificado na análise')}

**Regras de Negócio Identificadas:**
{self._format_business_rules(functional_info.get('business_rules', []))}

**Processos Implementados:**
{self._format_processes(functional_info.get('processes', []))}

**Estruturas de Dados:**
{self._format_data_structures(functional_info.get('data_structures', []))}

**Dependências Funcionais:**
{self._format_functional_dependencies(functional_info.get('dependencies', []))}

**Pontos Críticos:**
{self._format_critical_points(functional_info.get('critical_points', []))}
"""
        else:
            content += """
**Status:** Análise funcional não disponível para este programa.
**Recomendação:** Executar análise detalhada para obter informações funcionais.
"""
        
        content += "\n---\n\n"
        return content
    
    def _generate_book_functional_analysis(self, book: CobolBook, index: int, ai_responses: List[AIResponse] = None) -> str:
        """Gera análise funcional detalhada de um copybook."""
        
        # Buscar análise correspondente
        book_analysis = self._find_analysis_for_program(book.name, ai_responses)
        
        content = f"""### {index}. {book.name}

**Características Técnicas:**
- **Linhas de Código:** {getattr(book, 'line_count', 0)}
- **Tamanho:** {getattr(book, 'size', 0)} caracteres
- **Tipo:** Copybook/Estrutura de Dados

**Análise Funcional:**
"""
        
        if book_analysis:
            functional_info = self._extract_functional_information(book_analysis)
            
            content += f"""
**Propósito:**
{functional_info.get('main_purpose', 'Não identificado na análise')}

**Estruturas Definidas:**
{self._format_data_structures(functional_info.get('data_structures', []))}

**Campos e Layouts:**
{self._format_field_layouts(functional_info.get('field_layouts', []))}

**Programas que Utilizam:**
{self._format_usage_programs(functional_info.get('usage_programs', []))}
"""
        else:
            content += """
**Status:** Análise funcional não disponível para este copybook.
**Recomendação:** Executar análise detalhada para obter informações funcionais.
"""
        
        content += "\n---\n\n"
        return content
    
    def _calculate_complexity_level(self, program: CobolProgram) -> str:
        """Calcula nível de complexidade do programa."""
        line_count = getattr(program, 'line_count', 0)
        if line_count > 1000:
            return "Muito Alta"
        elif line_count > 500:
            return "Alta"
        elif line_count > 200:
            return "Média"
        elif line_count > 50:
            return "Baixa"
        else:
            return "Muito Baixa"
    
    def _extract_functional_information(self, analysis_content: str) -> Dict[str, Any]:
        """Extrai informações funcionais da análise."""
        # Implementação simplificada - em produção seria mais sofisticada
        info = {
            'main_purpose': 'Análise em processamento',
            'business_rules': ['Regras de negócio sendo identificadas'],
            'processes': ['Processos sendo mapeados'],
            'data_structures': ['Estruturas sendo analisadas'],
            'dependencies': ['Dependências sendo identificadas'],
            'critical_points': ['Pontos críticos sendo avaliados']
        }
        
        # Tentar extrair informações básicas do conteúdo
        if 'objetivo' in analysis_content.lower():
            lines = analysis_content.split('\n')
            for line in lines:
                if 'objetivo' in line.lower():
                    info['main_purpose'] = line.strip()
                    break
        
        return info
    
    def _format_business_rules(self, rules: List[str]) -> str:
        """Formata lista de regras de negócio."""
        if not rules:
            return "Nenhuma regra de negócio específica identificada."
        
        formatted = ""
        for i, rule in enumerate(rules, 1):
            formatted += f"{i}. {rule}\n"
        return formatted
    
    def _format_processes(self, processes: List[str]) -> str:
        """Formata lista de processos."""
        if not processes:
            return "Nenhum processo específico identificado."
        
        formatted = ""
        for i, process in enumerate(processes, 1):
            formatted += f"{i}. {process}\n"
        return formatted
    
    def _format_data_structures(self, structures: List[str]) -> str:
        """Formata lista de estruturas de dados."""
        if not structures:
            return "Nenhuma estrutura de dados específica identificada."
        
        formatted = ""
        for i, structure in enumerate(structures, 1):
            formatted += f"{i}. {structure}\n"
        return formatted
    
    def _format_functional_dependencies(self, dependencies: List[str]) -> str:
        """Formata lista de dependências funcionais."""
        if not dependencies:
            return "Nenhuma dependência funcional específica identificada."
        
        formatted = ""
        for i, dependency in enumerate(dependencies, 1):
            formatted += f"{i}. {dependency}\n"
        return formatted
    
    def _format_critical_points(self, points: List[str]) -> str:
        """Formata lista de pontos críticos."""
        if not points:
            return "Nenhum ponto crítico específico identificado."
        
        formatted = ""
        for i, point in enumerate(points, 1):
            formatted += f"{i}. {point}\n"
        return formatted
    
    def _format_field_layouts(self, layouts: List[str]) -> str:
        """Formata layouts de campos."""
        if not layouts:
            return "Layout de campos sendo analisado."
        
        formatted = ""
        for layout in layouts:
            formatted += f"- {layout}\n"
        return formatted
    
    def _format_usage_programs(self, programs: List[str]) -> str:
        """Formata lista de programas que utilizam o copybook."""
        if not programs:
            return "Programas utilizadores sendo identificados."
        
        return ", ".join(programs)
    
    def _identify_functional_domains(self, programs: List[CobolProgram]) -> Dict[str, List[CobolProgram]]:
        """Identifica domínios funcionais baseado nos nomes dos programas."""
        domains = {}
        
        for program in programs:
            # Lógica simplificada baseada em prefixos comuns
            name = program.name.upper()
            
            if name.startswith(('LHAN', 'LH')):
                domain = "Linhagem e Histórico"
            elif name.startswith(('CONT', 'CT')):
                domain = "Contabilidade"
            elif name.startswith(('REL', 'RL')):
                domain = "Relatórios"
            elif name.startswith(('PROC', 'PR')):
                domain = "Processamento"
            elif name.startswith(('VAL', 'VL')):
                domain = "Validação"
            else:
                domain = "Geral"
            
            if domain not in domains:
                domains[domain] = []
            domains[domain].append(program)
        
        return domains
    
    def _get_domain_description(self, domain: str, programs: List[CobolProgram]) -> str:
        """Retorna descrição do domínio funcional."""
        descriptions = {
            "Linhagem e Histórico": "Programas responsáveis por rastreamento e histórico de dados",
            "Contabilidade": "Programas de processamento contábil e financeiro",
            "Relatórios": "Programas de geração de relatórios e extratos",
            "Processamento": "Programas de processamento de dados e transações",
            "Validação": "Programas de validação e verificação de dados",
            "Geral": "Programas de propósito geral ou não categorizados"
        }
        
        return descriptions.get(domain, "Domínio funcional específico")
    
    def _consolidate_business_rules(self, ai_responses: List[AIResponse] = None) -> List[Dict[str, str]]:
        """Consolida regras de negócio de todas as análises."""
        if not ai_responses:
            return []
        
        # Implementação simplificada
        rules = []
        for i, response in enumerate(ai_responses, 1):
            rules.append({
                'title': f'Regra de Negócio {i}',
                'source': getattr(response, 'program_name', f'Programa {i}'),
                'description': 'Regra extraída da análise do programa',
                'impact': 'Impacto sendo avaliado'
            })
        
        return rules[:10]  # Limitar a 10 regras para exemplo
    
    def _identify_data_flows(self, programs: List[CobolProgram], books: List[CobolBook], ai_responses: List[AIResponse] = None) -> List[Dict[str, str]]:
        """Identifica fluxos de dados entre componentes."""
        flows = []
        
        # Implementação simplificada
        for i, program in enumerate(programs, 1):
            flows.append({
                'name': f'Fluxo {i}',
                'source': program.name,
                'destination': 'Sistema de destino',
                'data_description': 'Dados processados pelo programa',
                'processing': 'Processamento específico do programa'
            })
        
        return flows[:5]  # Limitar a 5 fluxos para exemplo
    
    def _identify_copybooks_used(self, program: CobolProgram, books: List[CobolBook]) -> List[str]:
        """Identifica copybooks utilizados pelo programa."""
        # Implementação simplificada - em produção analisaria o código
        return [book.name for book in books[:2]]  # Exemplo
    
    def _identify_related_programs(self, program: CobolProgram, programs: List[CobolProgram]) -> List[str]:
        """Identifica programas relacionados."""
        # Implementação simplificada
        related = []
        for other_program in programs:
            if other_program.name != program.name and other_program.name[:2] == program.name[:2]:
                related.append(other_program.name)
        
        return related[:3]  # Limitar a 3 relacionados
    
    def _identify_files_used(self, program: CobolProgram) -> List[str]:
        """Identifica arquivos utilizados pelo programa."""
        # Implementação simplificada
        return [f"ARQUIVO_{program.name[:4]}", f"DATASET_{program.name[:4]}"]
    
    def _analyze_functional_impact(self, program: CobolProgram, programs: List[CobolProgram], books: List[CobolBook]) -> Dict[str, str]:
        """Analisa impacto funcional do programa."""
        line_count = getattr(program, 'line_count', 0)
        
        if line_count > 500:
            criticality = "Alta"
            recommendations = "Monitoramento contínuo e testes rigorosos"
        elif line_count > 200:
            criticality = "Média"
            recommendations = "Testes regulares e documentação atualizada"
        else:
            criticality = "Baixa"
            recommendations = "Manutenção padrão"
        
        return {
            'impacted_programs': f"{len([p for p in programs if p.name[:2] == program.name[:2]])} programa(s)",
            'dependent_copybooks': f"{len(books)} copybook(s)",
            'criticality_level': criticality,
            'recommendations': recommendations
        }
    
    def _generate_metadata_section(self, ai_response: AIResponse) -> str:
        """
        Gera seção detalhada de metadata do LuzIA.
        
        Args:
            ai_response: Resposta da IA com metadata
            
        Returns:
            Seção formatada com metadata
        """
        metadata_section = ""
        
        # Verificar se há metadata específica do LuzIA
        if hasattr(ai_response, 'raw_response') and ai_response.raw_response:
            try:
                import json
                if isinstance(ai_response.raw_response, dict):
                    raw_data = ai_response.raw_response
                elif isinstance(ai_response.raw_response, str):
                    raw_data = json.loads(ai_response.raw_response)
                else:
                    raw_data = {}
                
                # Extrair metadata do LuzIA
                if 'output' in raw_data and 'metadata' in raw_data['output']:
                    metadata = raw_data['output']['metadata']
                    
                    metadata_section = f"""
## Informações Detalhadas do Processamento LuzIA

### Rastreabilidade da Análise
- **Trace ID:** {metadata.get('trace_id', 'N/A')}
- **Timestamp de Processamento:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
- **Identificador Único:** {metadata.get('trace_id', 'N/A')[:8]}...

### Estatísticas de Tokens Detalhadas"""
                    
                    if 'usage' in metadata and metadata['usage']:
                        usage = metadata['usage'][0] if isinstance(metadata['usage'], list) else metadata['usage']
                        
                        metadata_section += f"""
- **Modelo Utilizado:** {usage.get('model', 'N/A')}
- **Tokens de Entrada (Prompt):** {usage.get('prompt_tokens', 0):,}
- **Tokens de Saída (Resposta):** {usage.get('completion_tokens', 0):,}
- **Total de Tokens Processados:** {usage.get('total_tokens', 0):,}
- **Eficiência de Processamento:** {(usage.get('completion_tokens', 0) / max(usage.get('prompt_tokens', 1), 1) * 100):.1f}%
- **Custo Estimado de Tokens:** {usage.get('total_tokens', 0) * 0.000001:.6f} USD (estimativa)

### Qualidade da Análise
- **Densidade de Resposta:** {len(ai_response.content) / max(usage.get('completion_tokens', 1), 1):.2f} chars/token
- **Profundidade Técnica:** {'Alta' if usage.get('completion_tokens', 0) > 800 else 'Média' if usage.get('completion_tokens', 0) > 400 else 'Básica'}
- **Cobertura de Análise:** {'Completa' if usage.get('prompt_tokens', 0) > 40000 else 'Detalhada' if usage.get('prompt_tokens', 0) > 20000 else 'Resumida'}
- **Razão Entrada/Saída:** {(usage.get('prompt_tokens', 0) / max(usage.get('completion_tokens', 1), 1)):.1f}:1

### Informações Técnicas do Processamento
- **Capacidade do Modelo:** {usage.get('model', 'N/A')}
- **Contexto Utilizado:** {usage.get('prompt_tokens', 0):,} tokens de contexto
- **Resposta Gerada:** {usage.get('completion_tokens', 0):,} tokens de análise
- **Eficiência do Processamento:** {((usage.get('completion_tokens', 0) / max(usage.get('total_tokens', 1), 1)) * 100):.1f}% de tokens úteis"""
                    
                    metadata_section += f"""

### Auditoria e Conformidade
- **Provedor de IA:** LuzIA (Santander)
- **Ambiente:** {'Produção' if 'prd-api' in str(raw_data) else 'Desenvolvimento'}
- **Conformidade LGPD:** Dados processados em ambiente corporativo seguro
- **Rastreabilidade:** Trace ID {metadata.get('trace_id', 'N/A')} para auditoria completa
- **Retenção de Logs:** Conforme política corporativa de retenção de dados

### Metadata Técnica Completa
```json
{json.dumps(metadata, indent=2, ensure_ascii=False)}
```"""
                    
            except Exception as e:
                self.logger.debug(f"Erro ao processar metadata: {e}")
                metadata_section = f"""
## Informações do Processamento

### Análise Realizada
- **Provedor:** {ai_response.provider}
- **Modelo:** {ai_response.model}
- **Tokens Processados:** {ai_response.tokens_used}
- **Status:** Análise concluída com sucesso"""
        
        return metadata_section

    def get_statistics(self) -> Dict[str, Any]:
        """
        Retorna estatísticas do gerador.
        
        Returns:
            Dicionário com estatísticas
        """
        return {
            'files_generated': self.files_generated,
            'total_programs': self.total_programs,
            'total_books': self.total_books,
            'output_directory': self.output_dir
        }


    def _generate_functional_consolidation(self, programs: List[CobolProgram], books: List[CobolBook], ai_responses: List[AIResponse] = None) -> str:
        """Gera consolidação funcional do sistema."""
        
        content = """
## Consolidação Funcional do Sistema

### Domínios Funcionais Identificados

"""
        
        # Identificar domínios funcionais baseado nos nomes dos programas
        domains = self._identify_functional_domains(programs)
        
        for domain, programs_in_domain in domains.items():
            content += f"""
#### {domain}
**Programas:** {', '.join([p.name for p in programs_in_domain])}
**Quantidade:** {len(programs_in_domain)} programa(s)
**Descrição:** {self._get_domain_description(domain, programs_in_domain)}

"""
        
        content += """
### Regras de Negócio Consolidadas

"""
        
        # Consolidar regras de negócio de todas as análises
        all_business_rules = self._consolidate_business_rules(ai_responses)
        
        for i, rule in enumerate(all_business_rules, 1):
            content += f"""
{i}. **{rule.get('title', f'Regra {i}')}**
   - **Origem:** {rule.get('source', 'N/A')}
   - **Descrição:** {rule.get('description', 'Não disponível')}
   - **Impacto:** {rule.get('impact', 'A definir')}

"""
        
        content += """
### Fluxos de Dados Identificados

"""
        
        # Mapear fluxos de dados
        data_flows = self._identify_data_flows(programs, books, ai_responses)
        
        for flow in data_flows:
            content += f"""
**{flow.get('name', 'Fluxo não nomeado')}**
- **Origem:** {flow.get('source', 'N/A')}
- **Destino:** {flow.get('destination', 'N/A')}
- **Dados:** {flow.get('data_description', 'Não especificado')}
- **Processamento:** {flow.get('processing', 'Não detalhado')}

"""
        
        return content
    
    def _generate_functional_dependencies_map(self, programs: List[CobolProgram], books: List[CobolBook]) -> str:
        """Gera mapeamento de dependências funcionais."""
        
        content = """
## Mapeamento de Dependências Funcionais

### Matriz de Dependências

| Programa | Copybooks Utilizados | Programas Relacionados | Arquivos/Datasets |
|----------|---------------------|------------------------|-------------------|
"""
        
        for program in programs:
            copybooks_used = self._identify_copybooks_used(program, books)
            related_programs = self._identify_related_programs(program, programs)
            files_used = self._identify_files_used(program)
            
            content += f"| {program.name} | {', '.join(copybooks_used)} | {', '.join(related_programs)} | {', '.join(files_used)} |\n"
        
        content += """

### Análise de Impacto

"""
        
        # Análise de impacto para cada programa
        for program in programs:
            impact_analysis = self._analyze_functional_impact(program, programs, books)
            content += f"""
**{program.name}:**
- **Programas Impactados:** {impact_analysis.get('impacted_programs', 'Nenhum')}
- **Copybooks Dependentes:** {impact_analysis.get('dependent_copybooks', 'Nenhum')}
- **Nível de Criticidade:** {impact_analysis.get('criticality_level', 'Baixo')}
- **Recomendações:** {impact_analysis.get('recommendations', 'Nenhuma recomendação específica')}

"""
        
        return content
    
    def _generate_functional_recommendations(self, programs: List[CobolProgram], books: List[CobolBook]) -> str:
        """Gera recomendações funcionais."""
        
        content = """
## Recomendações Funcionais

### Modernização e Melhoria

"""
        
        # Analisar programas para recomendações
        high_complexity_programs = [p for p in programs if getattr(p, 'line_count', 0) > 500]
        
        if high_complexity_programs:
            content += """
**Programas de Alta Complexidade:**
"""
            for program in high_complexity_programs[:5]:  # Top 5
                content += f"""
- **{program.name}**: {getattr(program, 'line_count', 0)} linhas
  - Recomendação: Considerar refatoração em módulos menores
  - Prioridade: Alta
  - Benefício: Melhoria na manutenibilidade

"""
        
        content += """
### Oportunidades de Otimização

**Consolidação de Funcionalidades:**
- Identificar funcionalidades duplicadas entre programas
- Criar bibliotecas compartilhadas para lógicas comuns
- Padronizar estruturas de dados similares

**Melhoria de Performance:**
- Revisar algoritmos em programas críticos
- Otimizar acesso a arquivos e datasets
- Implementar cache para dados frequentemente acessados

**Documentação e Governança:**
- Documentar regras de negócio identificadas
- Criar mapeamento de dependências atualizado
- Estabelecer padrões de codificação

### Próximos Passos Recomendados

1. **Análise Detalhada**: Executar análise aprofundada nos programas críticos
2. **Mapeamento Completo**: Documentar todas as dependências funcionais
3. **Plano de Modernização**: Criar roadmap de modernização baseado na criticidade
4. **Testes de Regressão**: Implementar testes para validar mudanças
5. **Monitoramento**: Estabelecer métricas de qualidade e performance

"""
        
        return content

