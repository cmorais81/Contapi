# API de Governança de Dados V1.3 - Guia Windows

**Desenvolvido por:** Carlos Morais (carlos.morais@f1rst.com.br)  
**Organização:** F1rst  
**Versão:** 1.3.0  
**Compatibilidade:** Python 3.13+ / Windows 10+

## Instalação Rápida no Windows

### Pré-requisitos
- **Python 3.13+** (recomendado) ou Python 3.9+
- **Windows 10** ou superior
- **Git** (opcional, para clonagem)

### Método 1: Instalação Automática (Recomendado)

1. **Extrair o pacote**
   ```
   Extraia PACOTE_FINAL_GOVERNANCA_V1_3.zip
   Navegue até: 01_CODIGO_FONTE\
   ```

2. **Executar setup automático**
   ```
   Duplo clique em: setup_windows.py
   ```
   
   Ou via linha de comando:
   ```cmd
   cd 01_CODIGO_FONTE
   python setup_windows.py
   ```

3. **Executar a API**
   ```
   Duplo clique em: run_windows.bat
   ```
   
   Ou:
   ```cmd
   python run_windows.py
   ```

### Método 2: Instalação Manual

1. **Verificar Python**
   ```cmd
   python --version
   ```
   Deve mostrar Python 3.9+ (recomendado 3.13+)

2. **Instalar dependências**
   ```cmd
   cd 01_CODIGO_FONTE
   pip install -r requirements.txt
   ```

3. **Configurar ambiente**
   ```cmd
   set PYTHONPATH=%CD%\src;%PYTHONPATH%
   ```

4. **Executar API**
   ```cmd
   python src\main.py
   ```

## Resolução de Problemas Comuns

### Erro: "ModuleNotFoundError"

**Problema:** Imports não funcionam no Windows
**Solução:**
```cmd
# Configurar PYTHONPATH
set PYTHONPATH=%CD%\src;%PYTHONPATH%

# Ou usar o script de execução
python run_windows.py
```

### Erro: "No module named 'fastapi'"

**Problema:** Dependências não instaladas
**Solução:**
```cmd
pip install --upgrade pip
pip install -r requirements.txt
```

### Erro: "Permission denied"

**Problema:** Permissões do Windows
**Solução:**
```cmd
# Executar como administrador
# Ou instalar dependências para usuário
pip install --user -r requirements.txt
```

### Erro: "Python not found"

**Problema:** Python não está no PATH
**Solução:**
1. Reinstalar Python marcando "Add to PATH"
2. Ou adicionar manualmente ao PATH do Windows

### Erro de Encoding

**Problema:** Caracteres especiais no Windows
**Solução:**
```cmd
# Configurar encoding UTF-8
set PYTHONIOENCODING=utf-8
chcp 65001
```

## Estrutura de Arquivos Windows

```
01_CODIGO_FONTE/
├── src/                          # Código fonte da API
│   ├── main.py                   # Arquivo principal (corrigido para Windows)
│   ├── api/                      # Controllers e routers
│   ├── application/              # Lógica de aplicação
│   ├── database/                 # Modelos e repositórios
│   └── domain/                   # Entidades de domínio
├── tests/                        # Testes automatizados
├── requirements.txt              # Dependências (Python 3.13 compatível)
├── setup_windows.py              # Setup automático para Windows
├── run_windows.py                # Execução para Windows
├── run_windows.bat               # Script batch para Windows
├── start_api.py                  # Execução rápida
├── README_WINDOWS.md             # Este arquivo
└── .env.example                  # Configurações de exemplo
```

## Scripts Disponíveis

### setup_windows.py
- **Função:** Configuração completa do ambiente
- **Uso:** `python setup_windows.py`
- **Recursos:**
  - Verifica versão do Python
  - Instala dependências automaticamente
  - Configura PYTHONPATH
  - Cria arquivo .env
  - Testa imports

### run_windows.py
- **Função:** Execução da API com configuração automática
- **Uso:** `python run_windows.py`
- **Recursos:**
  - Configura PYTHONPATH automaticamente
  - Verifica dependências
  - Executa API com tratamento de erros
  - Compatível com Python 3.13

### run_windows.bat
- **Função:** Script batch para execução simples
- **Uso:** Duplo clique ou `run_windows.bat`
- **Recursos:**
  - Verifica Python e pip
  - Instala dependências se necessário
  - Configura ambiente
  - Executa API

### start_api.py
- **Função:** Execução rápida sem verificações
- **Uso:** `python start_api.py`
- **Recursos:**
  - Execução direta da API
  - Mínimo de configuração
  - Para desenvolvimento rápido

## Configuração de Ambiente

### Arquivo .env
Crie um arquivo `.env` na pasta `01_CODIGO_FONTE`:

```env
# Configuração da API de Governança V1.3
DATABASE_URL=postgresql://governance_user:governance_pass@localhost:5432/governance_db
REDIS_URL=redis://localhost:6379/0
SECRET_KEY=your-secret-key-change-in-production
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30
ENVIRONMENT=development

# Azure (opcional)
AZURE_CLIENT_ID=
AZURE_CLIENT_SECRET=
AZURE_TENANT_ID=

# Databricks (opcional)
DATABRICKS_WORKSPACE_URL=
DATABRICKS_TOKEN=

# Monitoramento
LOG_LEVEL=INFO
```

### Variáveis de Ambiente Windows
```cmd
# Configurar PYTHONPATH permanentemente
setx PYTHONPATH "%CD%\src"

# Configurar encoding
setx PYTHONIOENCODING "utf-8"
```

## Execução da API

### Opção 1: Script Automático
```cmd
# Duplo clique em run_windows.bat
# Ou execute:
run_windows.bat
```

### Opção 2: Python Direto
```cmd
python run_windows.py
```

### Opção 3: Execução Manual
```cmd
set PYTHONPATH=%CD%\src;%PYTHONPATH%
python src\main.py
```

## Acessando a API

Após executar, a API estará disponível em:

- **API Principal:** http://localhost:8000
- **Documentação Interativa:** http://localhost:8000/docs
- **Documentação ReDoc:** http://localhost:8000/redoc
- **Health Check:** http://localhost:8000/health

## Testes

### Executar Testes
```cmd
# Instalar dependências de teste
pip install pytest pytest-asyncio pytest-cov

# Executar testes
python -m pytest tests/ -v

# Executar com cobertura
python -m pytest tests/ --cov=src --cov-report=html
```

### Teste de Conectividade
```cmd
# Testar se a API está funcionando
curl http://localhost:8000/health

# Ou no PowerShell
Invoke-RestMethod -Uri http://localhost:8000/health
```

## Desenvolvimento

### Estrutura de Imports Corrigida
O arquivo `main.py` foi corrigido para Windows com:
- Imports absolutos usando `src.`
- Configuração automática de PYTHONPATH
- Tratamento robusto de erros de import
- Compatibilidade com Python 3.13

### Exemplo de Import Correto
```python
# Antes (problemático no Windows)
from api.controllers import contracts

# Depois (compatível com Windows)
from src.api.controllers import contracts
```

## Monitoramento e Logs

### Logs da Aplicação
```cmd
# Logs são exibidos no console
# Para salvar em arquivo:
python run_windows.py > api.log 2>&1
```

### Verificar Status
```cmd
# Health check
curl http://localhost:8000/health

# Métricas
curl http://localhost:8000/api/v1/metrics
```

## Suporte

### Problemas Conhecidos
1. **Antivírus:** Pode bloquear execução - adicionar exceção
2. **Firewall:** Pode bloquear porta 8000 - liberar acesso
3. **Encoding:** Usar UTF-8 sempre
4. **Paths:** Usar barras invertidas no Windows

### Contato para Suporte
- **Email:** carlos.morais@f1rst.com.br
- **Organização:** F1rst
- **Documentação:** Consulte os outros arquivos do pacote

### Logs de Debug
Para debug detalhado:
```cmd
set LOG_LEVEL=DEBUG
python run_windows.py
```

## Próximos Passos

1. **Configurar banco de dados** (PostgreSQL recomendado)
2. **Configurar Redis** para cache
3. **Configurar integrações** Azure/Databricks
4. **Executar testes** completos
5. **Deploy em produção**

---

**Desenvolvido com excelência por Carlos Morais - F1rst**

**Transforme seus dados em ativos estratégicos com a API de Governança V1.3**

