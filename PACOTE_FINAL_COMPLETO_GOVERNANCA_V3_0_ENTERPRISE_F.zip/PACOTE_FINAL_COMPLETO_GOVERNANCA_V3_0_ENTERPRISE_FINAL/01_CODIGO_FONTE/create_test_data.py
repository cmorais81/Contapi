#!/usr/bin/env python3
"""
Script para carregar dados de teste na aplicação de governança
"""
import os
import sys
import json
import psycopg2
from datetime import datetime, timedelta
import uuid

# Configuração do banco
DB_CONFIG = {
    'host': 'localhost',
    'port': 5432,
    'database': 'governanca_dados',
    'user': 'postgres',
    'password': 'postgres'
}

def get_db_connection():
    """Conecta ao banco de dados"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        return conn
    except Exception as e:
        print(f"Erro ao conectar ao banco: {e}")
        return None

def create_test_data():
    """Cria dados de teste para demonstração"""
    conn = get_db_connection()
    if not conn:
        return False
    
    try:
        cursor = conn.cursor()
        
        # 1. Criar usuários de teste
        print("Criando usuários de teste...")
        users_data = [
            ('admin@santander.com.br', 'Admin Sistema', True, False),
            ('ana.silva@santander.com.br', 'Ana Silva', True, False),
            ('pedro.santos@santander.com.br', 'Pedro Santos', True, False),
            ('maria.costa@santander.com.br', 'Maria Costa', True, False),
            ('carlos.morais@f1rst.com.br', 'Carlos Morais', True, False)
        ]
        
        for email, full_name, is_active, is_superuser in users_data:
            user_id = str(uuid.uuid4())
            password_hash = '$2b$12$dummy.hash.for.testing.only'  # Hash dummy para testes
            cursor.execute("""
                INSERT INTO users (id, email, password_hash, full_name, is_active, is_superuser, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW(), NOW())
                ON CONFLICT (email) DO NOTHING
            """, (user_id, email, password_hash, full_name, is_active, is_superuser))
        
        # 2. Criar entidades de teste
        print("Criando entidades de teste...")
        entities_data = [
            ('customers', 'table', 'Tabela de clientes pessoa física', 'catalog.schema.customers', 'ACTIVE'),
            ('transactions', 'table', 'Transações financeiras', 'catalog.schema.transactions', 'ACTIVE'),
            ('products', 'table', 'Produtos bancários', 'catalog.schema.products', 'ACTIVE'),
            ('accounts', 'table', 'Contas bancárias', 'catalog.schema.accounts', 'ACTIVE'),
            ('customer_360', 'view', 'Visão 360 do cliente', 'catalog.schema.customer_360', 'ACTIVE')
        ]
        
        entity_ids = {}
        for name, entity_type, description, full_path, status in entities_data:
            entity_id = str(uuid.uuid4())
            entity_ids[name] = entity_id
            cursor.execute("""
                INSERT INTO entities (id, name, entity_type, description, full_path, status, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW(), NOW())
                ON CONFLICT (full_path) DO NOTHING
            """, (entity_id, name, entity_type, description, full_path, status))
        
        # 3. Criar contratos de dados
        print("Criando contratos de dados...")
        contracts_data = [
            ('Contrato Cliente PF', 'Contrato para dados de clientes pessoa física', 'APPROVED', 'customers'),
            ('Contrato Transações', 'Contrato para dados de transações', 'APPROVED', 'transactions'),
            ('Contrato Produtos', 'Contrato para dados de produtos bancários', 'DRAFT', 'products')
        ]
        
        for name, description, status, entity_name in contracts_data:
            contract_id = str(uuid.uuid4())
            cursor.execute("""
                INSERT INTO data_contracts (id, name, description, status, entity_id, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, NOW(), NOW())
                ON CONFLICT DO NOTHING
            """, (contract_id, name, description, status, entity_ids.get(entity_name)))
        
        # 4. Criar regras de qualidade
        print("Criando regras de qualidade...")
        quality_rules = [
            ('CPF Válido', 'Validação de CPF brasileiro', 'customers', 'cpf_column', 'ACTIVE'),
            ('Email Válido', 'Validação de formato de email', 'customers', 'email_column', 'ACTIVE'),
            ('Valor Positivo', 'Transações devem ter valor positivo', 'transactions', 'amount_column', 'ACTIVE'),
            ('Completude Obrigatória', 'Campos obrigatórios não podem ser nulos', 'products', 'name_column', 'ACTIVE')
        ]
        
        for name, description, entity_name, column_name, status in quality_rules:
            rule_id = str(uuid.uuid4())
            cursor.execute("""
                INSERT INTO quality_rules (id, name, description, entity_id, column_name, status, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, %s, NOW(), NOW())
                ON CONFLICT DO NOTHING
            """, (rule_id, name, description, entity_ids.get(entity_name), column_name, status))
        
        # 5. Criar políticas de governança
        print("Criando políticas de governança...")
        policies_data = [
            ('Política LGPD', 'Política de proteção de dados pessoais', 'data_protection', 'ACTIVE'),
            ('Política BACEN', 'Política de dados regulatórios BACEN', 'regulatory', 'ACTIVE'),
            ('Política Interna', 'Política interna de qualidade de dados', 'data_quality', 'ACTIVE')
        ]
        
        for name, description, policy_type, status in policies_data:
            policy_id = str(uuid.uuid4())
            cursor.execute("""
                INSERT INTO governance_policies (id, name, description, policy_type, status, created_at, updated_at)
                VALUES (%s, %s, %s, %s, %s, NOW(), NOW())
                ON CONFLICT DO NOTHING
            """, (policy_id, name, description, policy_type, status))
        
        # 6. Criar lineage de dados
        print("Criando lineage de dados...")
        lineage_data = [
            ('customers', 'customer_360', 'direct', 'ETL Process'),
            ('transactions', 'customer_360', 'direct', 'Aggregation'),
            ('accounts', 'customer_360', 'direct', 'Join Operation')
        ]
        
        for source_name, target_name, lineage_type, transformation in lineage_data:
            lineage_id = str(uuid.uuid4())
            source_id = entity_ids.get(source_name)
            target_id = entity_ids.get(target_name)
            if source_id and target_id:
                cursor.execute("""
                    INSERT INTO data_lineage (id, source_entity_id, target_entity_id, lineage_type, transformation_logic, created_at, updated_at)
                    VALUES (%s, %s, %s, %s, %s, NOW(), NOW())
                    ON CONFLICT DO NOTHING
                """, (lineage_id, source_id, target_id, lineage_type, transformation))
        
        # Commit das transações
        conn.commit()
        print("✓ Dados de teste criados com sucesso!")
        
        # Verificar dados criados
        cursor.execute("SELECT COUNT(*) FROM users")
        users_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM entities")
        entities_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM data_contracts")
        contracts_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM quality_rules")
        rules_count = cursor.fetchone()[0]
        
        print(f"✓ Usuários: {users_count}")
        print(f"✓ Entidades: {entities_count}")
        print(f"✓ Contratos: {contracts_count}")
        print(f"✓ Regras de Qualidade: {rules_count}")
        
        return True
        
    except Exception as e:
        print(f"Erro ao criar dados de teste: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()
        conn.close()

if __name__ == "__main__":
    print("=== Carregando Dados de Teste ===")
    success = create_test_data()
    if success:
        print("=== Dados de teste carregados com sucesso! ===")
        sys.exit(0)
    else:
        print("=== Erro ao carregar dados de teste ===")
        sys.exit(1)

