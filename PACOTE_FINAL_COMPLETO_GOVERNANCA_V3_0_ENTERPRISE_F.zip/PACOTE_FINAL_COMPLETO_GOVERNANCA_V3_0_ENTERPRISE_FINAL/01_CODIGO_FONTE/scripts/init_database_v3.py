#!/usr/bin/env python3
"""
Script de Inicialização do Banco de Dados V3.0
API de Governança de Dados
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
Organização: F1rst
"""

import asyncio
import sys
import os
from pathlib import Path
from datetime import datetime
import logging

# Adicionar src ao path
current_dir = Path(__file__).parent
src_dir = current_dir.parent / "src"
sys.path.insert(0, str(src_dir))

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

try:
    from src.database.connection import engine
    from src.database.models.base import Base
    
    # Importar todos os modelos para garantir que sejam registrados
    from src.database.models import *
    
    logger.info("✅ Imports realizados com sucesso")
    
except ImportError as e:
    logger.error(f"❌ Erro ao importar módulos: {e}")
    sys.exit(1)


async def create_tables():
    """Cria todas as tabelas no banco de dados"""
    try:
        logger.info("🔄 Iniciando criação das tabelas...")
        
        # Criar todas as tabelas
        Base.metadata.create_all(bind=engine)
        
        logger.info("✅ Tabelas criadas com sucesso!")
        
        # Listar tabelas criadas
        tables = list(Base.metadata.tables.keys())
        logger.info(f"📊 Total de tabelas criadas: {len(tables)}")
        
        # Agrupar tabelas por categoria
        table_categories = {
            "Autenticação": [t for t in tables if any(x in t.lower() for x in ['user', 'role', 'session', 'api_key'])],
            "Contratos": [t for t in tables if any(x in t.lower() for x in ['contract', 'export'])],
            "Qualidade": [t for t in tables if any(x in t.lower() for x in ['quality', 'rule', 'metric'])],
            "Entidades": [t for t in tables if any(x in t.lower() for x in ['entity', 'catalog'])],
            "Governança": [t for t in tables if any(x in t.lower() for x in ['policy', 'governance', 'steward'])],
            "Sistema": [t for t in tables if any(x in t.lower() for x in ['system', 'audit', 'log', 'performance'])],
            "Workflows": [t for t in tables if any(x in t.lower() for x in ['workflow', 'notification', 'alert'])],
            "Outros": []
        }
        
        # Classificar tabelas não categorizadas
        categorized = set()
        for category, category_tables in table_categories.items():
            if category != "Outros":
                categorized.update(category_tables)
        
        table_categories["Outros"] = [t for t in tables if t not in categorized]
        
        # Exibir tabelas por categoria
        for category, category_tables in table_categories.items():
            if category_tables:
                logger.info(f"\n📋 {category}:")
                for table in sorted(category_tables):
                    logger.info(f"  - {table}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Erro ao criar tabelas: {e}")
        return False


async def create_initial_data():
    """Cria dados iniciais necessários"""
    try:
        logger.info("🔄 Criando dados iniciais...")
        
        from sqlalchemy.orm import sessionmaker
        from src.database.models.auth import User, Role
        from src.database.models.contract_export import ContractExportTemplate
        
        Session = sessionmaker(bind=engine)
        session = Session()
        
        try:
            # Criar roles padrão
            roles_data = [
                {"name": "admin", "description": "Administrador do sistema"},
                {"name": "data_steward", "description": "Steward de dados"},
                {"name": "data_analyst", "description": "Analista de dados"},
                {"name": "data_engineer", "description": "Engenheiro de dados"},
                {"name": "business_user", "description": "Usuário de negócio"}
            ]
            
            for role_data in roles_data:
                existing_role = session.query(Role).filter_by(name=role_data["name"]).first()
                if not existing_role:
                    role = Role(**role_data)
                    session.add(role)
                    logger.info(f"  ✅ Role criada: {role_data['name']}")
            
            # Criar usuário admin padrão
            admin_user = session.query(User).filter_by(username="admin").first()
            if not admin_user:
                admin_user = User(
                    username="admin",
                    email="admin@f1rst.com.br",
                    full_name="Administrador",
                    is_active=True,
                    is_superuser=True
                )
                admin_user.set_password("admin123")  # Senha padrão - DEVE SER ALTERADA
                session.add(admin_user)
                logger.info("  ✅ Usuário admin criado (senha: admin123)")
            
            # Criar templates de export padrão
            templates_data = [
                {
                    "name": "json_standard",
                    "description": "Template padrão para export JSON",
                    "export_type": "json",
                    "export_format": "json",
                    "template_content": """
{
  "contract": {
    "id": "{{ contract.id }}",
    "name": "{{ contract.name }}",
    "version": "{{ contract.version }}",
    "description": "{{ contract.description }}",
    "schema": {{ contract.schema_definition | tojson }},
    "sla": {{ contract.sla_definition | tojson }},
    "quality": {{ contract.quality_requirements | tojson }},
    "metadata": {
      "domain": "{{ contract.domain }}",
      "classification": "{{ contract.data_classification }}",
      "created_at": "{{ contract.created_at }}",
      "updated_at": "{{ contract.updated_at }}"
    }
  }
}
                    """.strip(),
                    "is_active": True,
                    "is_default": True,
                    "created_by": "system"
                },
                {
                    "name": "yaml_standard",
                    "description": "Template padrão para export YAML",
                    "export_type": "yaml",
                    "export_format": "yaml",
                    "template_content": """
contract:
  id: {{ contract.id }}
  name: {{ contract.name }}
  version: {{ contract.version }}
  description: {{ contract.description }}
  schema: {{ contract.schema_definition | toyaml }}
  sla: {{ contract.sla_definition | toyaml }}
  quality: {{ contract.quality_requirements | toyaml }}
  metadata:
    domain: {{ contract.domain }}
    classification: {{ contract.data_classification }}
    created_at: {{ contract.created_at }}
    updated_at: {{ contract.updated_at }}
                    """.strip(),
                    "is_active": True,
                    "is_default": False,
                    "created_by": "system"
                },
                {
                    "name": "sql_ddl",
                    "description": "Template para geração de DDL SQL",
                    "export_type": "sql",
                    "export_format": "sql",
                    "template_content": """
-- Contract: {{ contract.name }} v{{ contract.version }}
-- Description: {{ contract.description }}
-- Generated at: {{ now() }}

{% if contract.schema_definition %}
-- Schema Definition
{% for table_name, table_def in contract.schema_definition.items() %}
CREATE TABLE {{ table_name }} (
{% for column in table_def.columns %}
  {{ column.name }} {{ column.type }}{% if not loop.last %},{% endif %}
{% endfor %}
);
{% endfor %}
{% endif %}

-- Quality Rules
{% if contract.quality_requirements %}
{% for rule in contract.quality_requirements %}
-- Rule: {{ rule.name }}
-- Description: {{ rule.description }}
{% endfor %}
{% endif %}
                    """.strip(),
                    "is_active": True,
                    "is_default": False,
                    "created_by": "system"
                }
            ]
            
            for template_data in templates_data:
                existing_template = session.query(ContractExportTemplate).filter_by(
                    name=template_data["name"]
                ).first()
                if not existing_template:
                    template = ContractExportTemplate(**template_data)
                    session.add(template)
                    logger.info(f"  ✅ Template criado: {template_data['name']}")
            
            # Commit todas as mudanças
            session.commit()
            logger.info("✅ Dados iniciais criados com sucesso!")
            
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()
            
        return True
        
    except Exception as e:
        logger.error(f"❌ Erro ao criar dados iniciais: {e}")
        return False


async def verify_installation():
    """Verifica se a instalação foi bem-sucedida"""
    try:
        logger.info("🔄 Verificando instalação...")
        
        from sqlalchemy.orm import sessionmaker
        from src.database.models.auth import User, Role
        from src.database.models.contract_export import ContractExportTemplate
        
        Session = sessionmaker(bind=engine)
        session = Session()
        
        try:
            # Verificar tabelas
            tables_count = len(Base.metadata.tables)
            logger.info(f"  📊 Tabelas: {tables_count}")
            
            # Verificar roles
            roles_count = session.query(Role).count()
            logger.info(f"  👥 Roles: {roles_count}")
            
            # Verificar usuários
            users_count = session.query(User).count()
            logger.info(f"  👤 Usuários: {users_count}")
            
            # Verificar templates
            templates_count = session.query(ContractExportTemplate).count()
            logger.info(f"  📄 Templates: {templates_count}")
            
            # Verificar usuário admin
            admin_user = session.query(User).filter_by(username="admin").first()
            if admin_user:
                logger.info(f"  ✅ Usuário admin: {admin_user.email}")
            else:
                logger.warning("  ⚠️ Usuário admin não encontrado")
            
            logger.info("✅ Verificação concluída com sucesso!")
            return True
            
        finally:
            session.close()
            
    except Exception as e:
        logger.error(f"❌ Erro na verificação: {e}")
        return False


async def main():
    """Função principal"""
    logger.info("🚀 Iniciando inicialização do banco de dados V3.0")
    logger.info("=" * 60)
    
    try:
        # Verificar conexão com banco
        logger.info("🔄 Testando conexão com banco de dados...")
        
        # Tentar conectar
        connection = engine.connect()
        connection.close()
        logger.info("✅ Conexão com banco estabelecida")
        
        # Criar tabelas
        success = await create_tables()
        if not success:
            logger.error("❌ Falha na criação das tabelas")
            sys.exit(1)
        
        # Criar dados iniciais
        success = await create_initial_data()
        if not success:
            logger.error("❌ Falha na criação dos dados iniciais")
            sys.exit(1)
        
        # Verificar instalação
        success = await verify_installation()
        if not success:
            logger.error("❌ Falha na verificação da instalação")
            sys.exit(1)
        
        logger.info("=" * 60)
        logger.info("🎉 Inicialização concluída com sucesso!")
        logger.info("")
        logger.info("📋 Próximos passos:")
        logger.info("  1. Alterar senha do usuário admin")
        logger.info("  2. Configurar variáveis de ambiente")
        logger.info("  3. Executar aplicação: uvicorn src.main:app --reload")
        logger.info("  4. Acessar documentação: http://localhost:8000/docs")
        logger.info("")
        logger.info("⚠️  IMPORTANTE: Altere a senha padrão do admin!")
        logger.info("   Usuário: admin")
        logger.info("   Senha: admin123")
        logger.info("")
        
    except Exception as e:
        logger.error(f"❌ Erro fatal durante inicialização: {e}")
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())

