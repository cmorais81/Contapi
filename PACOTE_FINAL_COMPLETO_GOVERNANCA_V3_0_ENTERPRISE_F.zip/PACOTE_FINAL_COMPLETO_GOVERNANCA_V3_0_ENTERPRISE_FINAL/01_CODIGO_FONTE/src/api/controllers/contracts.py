"""
Controller de Contratos de Dados - V1.9 com Banco de Dados
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
import logging

from src.database.connection import get_database_session
from src.database.models.contracts import DataContract, ContractVersion, ContractApproval
from src.database.repositories.base import BaseRepository

logger = logging.getLogger(__name__)

# Criar router
router = APIRouter()

def get_contract_repository(db: Session = Depends(get_database_session)) -> BaseRepository[DataContract]:
    """Dependency para obter repository de contratos"""
    return BaseRepository(DataContract, db)

@router.get("/contracts", summary="Listar contratos")
async def list_contracts(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    repository: BaseRepository[DataContract] = Depends(get_contract_repository)
):
    """
    Lista todos os contratos de dados disponíveis.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros se fornecidos
        filters = {}
        if status:
            filters['status'] = status
        
        # Buscar contratos com filtros e paginação
        contracts = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='created_at',
            sort_order='desc'
        )
        
        # Contar total para paginação
        total = repository.count(filters)
        
        logger.info(f"Listando {len(contracts)} contratos de {total} total")
        
        return {
            "contracts": [contract.to_dict() for contract in contracts],
            "total": total,
            "limit": limit,
            "offset": offset,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar contratos: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/contracts/{contract_id}", summary="Obter contrato")
async def get_contract(
    contract_id: UUID,
    repository: BaseRepository[DataContract] = Depends(get_contract_repository)
):
    """
    Obtém um contrato específico por ID.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        contract = repository.get_by_id(contract_id)
        
        if not contract:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        
        logger.info(f"Contrato encontrado: {contract_id}")
        
        return {
            "contract": contract.to_dict(),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter contrato {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/contracts", summary="Criar contrato")
async def create_contract(
    contract_data: Dict[str, Any],
    repository: BaseRepository[DataContract] = Depends(get_contract_repository)
):
    """
    Cria um novo contrato de dados.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        if 'name' not in contract_data:
            raise HTTPException(status_code=400, detail="Nome do contrato é obrigatório")
        
        # Verificar se já existe contrato com mesmo nome
        existing = repository.find_one_by(name=contract_data['name'])
        if existing:
            raise HTTPException(status_code=409, detail="Contrato com este nome já existe")
        
        # Criar contrato
        contract = repository.create(**contract_data)
        
        logger.info(f"Contrato criado: {contract.id}")
        
        return {
            "contract": contract.to_dict(),
            "message": "Contrato criado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar contrato: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/contracts/{contract_id}", summary="Atualizar contrato")
async def update_contract(
    contract_id: UUID,
    contract_data: Dict[str, Any],
    repository: BaseRepository[DataContract] = Depends(get_contract_repository)
):
    """
    Atualiza um contrato existente.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        contract = repository.update(contract_id, **contract_data)
        
        if not contract:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        
        logger.info(f"Contrato atualizado: {contract_id}")
        
        return {
            "contract": contract.to_dict(),
            "message": "Contrato atualizado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao atualizar contrato {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.delete("/contracts/{contract_id}", summary="Remover contrato")
async def delete_contract(
    contract_id: UUID,
    repository: BaseRepository[DataContract] = Depends(get_contract_repository)
):
    """
    Remove um contrato.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        deleted = repository.delete(contract_id)
        
        if not deleted:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        
        logger.info(f"Contrato removido: {contract_id}")
        
        return {
            "message": "Contrato removido com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao remover contrato {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/contracts/{contract_id}/versions", summary="Listar versões do contrato")
async def list_contract_versions(
    contract_id: UUID,
    db: Session = Depends(get_database_session)
):
    """
    Lista todas as versões de um contrato.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        version_repository = BaseRepository(ContractVersion, db)
        versions = version_repository.find_by(contract_id=contract_id)
        
        return {
            "versions": [version.to_dict() for version in versions],
            "total": len(versions),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar versões do contrato {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/contracts/{contract_id}", summary="Atualizar contrato")
async def update_contract(contract_id: str, update_data: Dict[str, Any]):
    """
    Atualiza um contrato existente.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        if contract_id not in contracts_db:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        
        contract = contracts_db[contract_id]
        
        # Atualizar campos permitidos
        updatable_fields = ['name', 'description', 'schema', 'sla', 'quality_rules', 'tags']
        for field in updatable_fields:
            if field in update_data:
                contract[field] = update_data[field]
        
        contract['updated_at'] = datetime.utcnow().isoformat()
        
        logger.info(f"Contrato atualizado: {contract_id}")
        
        return {
            "message": "Contrato atualizado com sucesso",
            "contract": contract,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao atualizar contrato {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.delete("/contracts/{contract_id}", summary="Remover contrato")
async def delete_contract(contract_id: str):
    """
    Remove um contrato.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        if contract_id not in contracts_db:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        
        del contracts_db[contract_id]
        logger.info(f"Contrato removido: {contract_id}")
        
        return {
            "message": "Contrato removido com sucesso",
            "contract_id": contract_id,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao remover contrato {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/contracts/{contract_id}/validate", summary="Validar contrato")
async def validate_contract(contract_id: str):
    """
    Valida um contrato de dados.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        if contract_id not in contracts_db:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        
        contract = contracts_db[contract_id]
        
        validation_result = {
            'valid': True,
            'errors': [],
            'warnings': [],
            'contract_id': contract_id,
            'validated_at': datetime.utcnow().isoformat(),
            'author': 'Carlos Morais',
            'email': 'carlos.morais@f1rst.com.br'
        }
        
        # Validações básicas
        if not contract.get('name'):
            validation_result['valid'] = False
            validation_result['errors'].append("Nome do contrato é obrigatório")
        
        if not contract.get('schema'):
            validation_result['warnings'].append("Schema não definido")
        
        logger.info(f"Validação de contrato {contract_id}: {'válido' if validation_result['valid'] else 'inválido'}")
        
        return validation_result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao validar contrato {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/contracts/{contract_id}/metrics", summary="Métricas do contrato")
async def get_contract_metrics(contract_id: str):
    """
    Obtém métricas de um contrato.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        if contract_id not in contracts_db:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        
        # Métricas simuladas
        metrics = {
            'contract_id': contract_id,
            'usage_count': 150,
            'last_accessed': datetime.utcnow().isoformat(),
            'quality_score': 0.95,
            'compliance_score': 0.98,
            'performance_metrics': {
                'avg_response_time': '145ms',
                'success_rate': 0.999,
                'error_rate': 0.001
            },
            'data_volume': {
                'daily_records': 50000,
                'monthly_records': 1500000,
                'storage_size_gb': 2.5
            },
            'author': 'Carlos Morais',
            'email': 'carlos.morais@f1rst.com.br'
        }
        
        logger.info(f"Métricas obtidas para contrato: {contract_id}")
        return metrics
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter métricas do contrato {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

