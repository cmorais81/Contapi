"""
Controller de Integrações Externas - V2.1 com Banco de Dados
API de Governança de Dados V2.1
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from fastapi import APIRouter, HTTPException, Depends, Query, BackgroundTasks
from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
import logging

from src.database.connection import get_database_session
from src.database.models.integrations import ExternalIntegration, IntegrationMapping, SyncJob
from src.database.repositories.base import BaseRepository

logger = logging.getLogger(__name__)

# Criar router
router = APIRouter()

def get_integration_repository(db: Session = Depends(get_database_session)) -> BaseRepository[ExternalIntegration]:
    """Dependency para obter repository de integrações"""
    return BaseRepository(ExternalIntegration, db)

def get_mapping_repository(db: Session = Depends(get_database_session)) -> BaseRepository[IntegrationMapping]:
    """Dependency para obter repository de mapeamentos"""
    return BaseRepository(IntegrationMapping, db)

def get_sync_job_repository(db: Session = Depends(get_database_session)) -> BaseRepository[SyncJob]:
    """Dependency para obter repository de jobs de sincronização"""
    return BaseRepository(SyncJob, db)

# ========================================
# INTEGRAÇÕES EXTERNAS
# ========================================

@router.get("/integrations", summary="Listar integrações externas")
async def list_integrations(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    integration_type: Optional[str] = Query(None, description="Filtrar por tipo"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    is_enabled: Optional[bool] = Query(None, description="Filtrar por habilitado"),
    repository: BaseRepository[ExternalIntegration] = Depends(get_integration_repository)
):
    """
    Lista todas as integrações externas configuradas.
    
    Suporta integrações com:
    - Unity Catalog (Databricks)
    - Informatica Axon
    - DataHub
    - Data Contract Manager
    - Conectores customizados
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if integration_type:
            filters['integration_type'] = integration_type
        if status:
            filters['status'] = status
        if is_enabled is not None:
            filters['is_enabled'] = is_enabled
        
        # Buscar integrações
        integrations = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='created_at',
            sort_order='desc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(integrations)} integrações de {total} total")
        
        return {
            "integrations": [integration.to_dict() for integration in integrations],
            "total": total,
            "limit": limit,
            "offset": offset,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar integrações: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/integrations", summary="Criar integração externa")
async def create_integration(
    integration_data: Dict[str, Any],
    repository: BaseRepository[ExternalIntegration] = Depends(get_integration_repository)
):
    """
    Cria uma nova integração externa.
    
    Tipos suportados:
    - unity_catalog: Databricks Unity Catalog
    - informatica_axon: Informatica Axon Data Governance
    - datahub: LinkedIn DataHub
    - data_contract_manager: Data Contract Manager
    - custom: Conectores customizados
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['name', 'integration_type']
        for field in required_fields:
            if field not in integration_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Verificar se já existe integração com mesmo nome
        existing = repository.find_one_by(name=integration_data['name'])
        if existing:
            raise HTTPException(status_code=409, detail="Integração com este nome já existe")
        
        # Criar integração
        integration = repository.create(**integration_data)
        
        logger.info(f"Integração criada: {integration.id} - {integration.name}")
        
        return {
            "integration": integration.to_dict(),
            "message": "Integração criada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar integração: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/integrations/{integration_id}", summary="Obter integração específica")
async def get_integration(
    integration_id: UUID,
    repository: BaseRepository[ExternalIntegration] = Depends(get_integration_repository)
):
    """
    Obtém uma integração específica por ID.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        integration = repository.get_by_id(integration_id)
        
        if not integration:
            raise HTTPException(status_code=404, detail="Integração não encontrada")
        
        logger.info(f"Integração encontrada: {integration_id}")
        
        return {
            "integration": integration.to_dict(),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter integração {integration_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/integrations/{integration_id}", summary="Atualizar integração")
async def update_integration(
    integration_id: UUID,
    integration_data: Dict[str, Any],
    repository: BaseRepository[ExternalIntegration] = Depends(get_integration_repository)
):
    """
    Atualiza uma integração existente.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        integration = repository.update(integration_id, **integration_data)
        
        if not integration:
            raise HTTPException(status_code=404, detail="Integração não encontrada")
        
        logger.info(f"Integração atualizada: {integration_id}")
        
        return {
            "integration": integration.to_dict(),
            "message": "Integração atualizada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao atualizar integração {integration_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# MAPEAMENTOS DE CAMPOS
# ========================================

@router.get("/integrations/{integration_id}/mappings", summary="Listar mapeamentos de campos")
async def list_integration_mappings(
    integration_id: UUID,
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    is_active: Optional[bool] = Query(None, description="Filtrar por ativo"),
    repository: BaseRepository[IntegrationMapping] = Depends(get_mapping_repository)
):
    """
    Lista mapeamentos de campos para uma integração.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {'integration_id': integration_id}
        if is_active is not None:
            filters['is_active'] = is_active
        
        # Buscar mapeamentos
        mappings = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='priority',
            sort_order='desc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(mappings)} mapeamentos para integração {integration_id}")
        
        return {
            "mappings": [mapping.to_dict() for mapping in mappings],
            "total": total,
            "limit": limit,
            "offset": offset,
            "integration_id": str(integration_id),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar mapeamentos: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/integrations/{integration_id}/mappings", summary="Criar mapeamento de campo")
async def create_integration_mapping(
    integration_id: UUID,
    mapping_data: Dict[str, Any],
    repository: BaseRepository[IntegrationMapping] = Depends(get_mapping_repository)
):
    """
    Cria um novo mapeamento de campo para uma integração.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['source_field', 'target_field']
        for field in required_fields:
            if field not in mapping_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Adicionar integration_id
        mapping_data['integration_id'] = integration_id
        
        # Criar mapeamento
        mapping = repository.create(**mapping_data)
        
        logger.info(f"Mapeamento criado: {mapping.id} para integração {integration_id}")
        
        return {
            "mapping": mapping.to_dict(),
            "message": "Mapeamento criado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar mapeamento: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# JOBS DE SINCRONIZAÇÃO
# ========================================

@router.get("/integrations/{integration_id}/sync-jobs", summary="Listar jobs de sincronização")
async def list_sync_jobs(
    integration_id: UUID,
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    repository: BaseRepository[SyncJob] = Depends(get_sync_job_repository)
):
    """
    Lista jobs de sincronização para uma integração.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {'integration_id': integration_id}
        if status:
            filters['status'] = status
        
        # Buscar jobs
        jobs = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='started_at',
            sort_order='desc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(jobs)} jobs para integração {integration_id}")
        
        return {
            "sync_jobs": [job.to_dict() for job in jobs],
            "total": total,
            "limit": limit,
            "offset": offset,
            "integration_id": str(integration_id),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar jobs de sincronização: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/integrations/{integration_id}/sync-jobs", summary="Criar job de sincronização")
async def create_sync_job(
    integration_id: UUID,
    job_data: Dict[str, Any],
    background_tasks: BackgroundTasks,
    repository: BaseRepository[SyncJob] = Depends(get_sync_job_repository)
):
    """
    Cria e executa um job de sincronização.
    
    Tipos de job suportados:
    - full_sync: Sincronização completa
    - incremental: Sincronização incremental
    - metadata_only: Apenas metadados
    - test_connection: Teste de conexão
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['job_name', 'job_type']
        for field in required_fields:
            if field not in job_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Adicionar integration_id
        job_data['integration_id'] = integration_id
        
        # Criar job
        job = repository.create(**job_data)
        
        # Agendar execução em background
        background_tasks.add_task(execute_sync_job, job.id)
        
        logger.info(f"Job de sincronização criado: {job.id} para integração {integration_id}")
        
        return {
            "sync_job": job.to_dict(),
            "message": "Job de sincronização criado e agendado",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar job de sincronização: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/sync-jobs/{job_id}", summary="Obter status do job")
async def get_sync_job_status(
    job_id: UUID,
    repository: BaseRepository[SyncJob] = Depends(get_sync_job_repository)
):
    """
    Obtém o status e detalhes de um job de sincronização.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        job = repository.get_by_id(job_id)
        
        if not job:
            raise HTTPException(status_code=404, detail="Job não encontrado")
        
        logger.info(f"Status do job consultado: {job_id}")
        
        return {
            "sync_job": job.to_dict(),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter status do job {job_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# FUNÇÕES AUXILIARES
# ========================================

async def execute_sync_job(job_id: UUID):
    """
    Executa um job de sincronização em background.
    
    Esta função será expandida para implementar a lógica real
    de sincronização com cada tipo de integração.
    """
    try:
        logger.info(f"Iniciando execução do job {job_id}")
        
        # TODO: Implementar lógica real de sincronização
        # - Unity Catalog: Usar Databricks SDK
        # - Informatica Axon: Usar REST API
        # - DataHub: Usar GraphQL API
        # - Custom: Usar configuração específica
        
        logger.info(f"Job {job_id} executado com sucesso")
        
    except Exception as e:
        logger.error(f"Erro na execução do job {job_id}: {e}")
        # TODO: Atualizar status do job para FAILED

