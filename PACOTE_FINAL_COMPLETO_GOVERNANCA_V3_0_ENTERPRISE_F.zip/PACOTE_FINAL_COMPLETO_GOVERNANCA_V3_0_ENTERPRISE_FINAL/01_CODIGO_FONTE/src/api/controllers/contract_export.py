"""
Controller de Contract Export
API de Governança de Dados V3.0
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
Organização: F1rst
"""

from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession

from src.database.connection import get_async_session
from src.application.services.contract_export_service import ContractExportService
from src.application.dtos.contract_export import (
    ContractExportRequest, ContractExportBatchRequest, ContractExportResponse,
    ContractExportListResponse, ExportStatus, ExportStatisticsResponse,
    ContractExportPreviewResponse, ExportType, ExportFormat
)
from src.api.controllers.auth import get_current_active_user

router = APIRouter(prefix="/api/v1/contract-export", tags=["Contract Export"])


@router.post("/", response_model=ContractExportResponse)
async def create_export(
    request: ContractExportRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Cria um novo export de contrato
    
    - **contract_id**: ID do contrato a ser exportado
    - **export_type**: Tipo de export (git, json, yaml, ci_cd)
    - **export_format**: Formato do export (json, yaml, sql)
    - **git_repository**: Repositório Git (opcional)
    - **git_branch**: Branch do Git (opcional)
    - **trigger_pipeline**: Se deve disparar pipeline CI/CD
    """
    try:
        service = ContractExportService(db)
        export = await service.create_export(request, current_user.get("username", "unknown"))
        
        return export
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.post("/batch", response_model=List[ContractExportResponse])
async def create_batch_export(
    request: ContractExportBatchRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Cria exports em lote para múltiplos contratos
    
    - **contract_ids**: Lista de IDs dos contratos
    - **export_type**: Tipo de export
    - **export_format**: Formato do export
    - **parallel_processing**: Se deve processar em paralelo
    - **max_concurrent_exports**: Máximo de exports simultâneos
    """
    try:
        if len(request.contract_ids) > 100:
            raise HTTPException(status_code=400, detail="Máximo de 100 contratos por lote")
        
        service = ContractExportService(db)
        exports = await service.create_batch_export(request, current_user.get("username", "unknown"))
        
        return exports
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.get("/{export_id}", response_model=ContractExportResponse)
async def get_export(
    export_id: int,
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Obtém detalhes de um export específico
    
    - **export_id**: ID do export
    """
    try:
        service = ContractExportService(db)
        export = await service.get_export(export_id)
        
        if not export:
            raise HTTPException(status_code=404, detail="Export não encontrado")
        
        return export
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.get("/", response_model=ContractExportListResponse)
async def list_exports(
    contract_id: Optional[int] = Query(None, description="Filtrar por ID do contrato"),
    status: Optional[ExportStatus] = Query(None, description="Filtrar por status"),
    export_type: Optional[ExportType] = Query(None, description="Filtrar por tipo"),
    page: int = Query(1, ge=1, description="Página"),
    size: int = Query(20, ge=1, le=100, description="Tamanho da página"),
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Lista exports com filtros e paginação
    
    - **contract_id**: Filtrar por contrato específico
    - **status**: Filtrar por status (pending, success, failed)
    - **export_type**: Filtrar por tipo (git, json, yaml, ci_cd)
    - **page**: Número da página
    - **size**: Itens por página
    """
    try:
        service = ContractExportService(db)
        exports, total = await service.list_exports(contract_id, status, page, size)
        
        pages = (total + size - 1) // size  # Ceiling division
        
        return ContractExportListResponse(
            exports=exports,
            total=total,
            page=page,
            size=size,
            pages=pages
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.post("/{export_id}/retry", response_model=ContractExportResponse)
async def retry_export(
    export_id: int,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Tenta novamente um export que falhou
    
    - **export_id**: ID do export a ser tentado novamente
    """
    try:
        service = ContractExportService(db)
        export = await service.retry_export(export_id)
        
        return export
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.post("/{export_id}/cancel", response_model=ContractExportResponse)
async def cancel_export(
    export_id: int,
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Cancela um export em andamento
    
    - **export_id**: ID do export a ser cancelado
    """
    try:
        service = ContractExportService(db)
        export = await service.cancel_export(export_id)
        
        return export
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.get("/statistics/summary", response_model=ExportStatisticsResponse)
async def get_export_statistics(
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Obtém estatísticas gerais de exports
    
    Retorna:
    - Total de exports
    - Exports bem-sucedidos
    - Exports falharam
    - Exports pendentes
    - Taxa de sucesso
    - Estatísticas por tipo e formato
    """
    try:
        service = ContractExportService(db)
        statistics = await service.get_export_statistics()
        
        return statistics
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.get("/contract/{contract_id}/exports", response_model=List[ContractExportResponse])
async def get_contract_exports(
    contract_id: int,
    limit: int = Query(10, ge=1, le=50, description="Limite de resultados"),
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Obtém histórico de exports de um contrato específico
    
    - **contract_id**: ID do contrato
    - **limit**: Limite de resultados (máximo 50)
    """
    try:
        service = ContractExportService(db)
        exports, _ = await service.list_exports(contract_id=contract_id, page=1, size=limit)
        
        return exports
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.post("/contract/{contract_id}/export", response_model=ContractExportResponse)
async def export_contract(
    contract_id: int,
    export_type: ExportType = Query(..., description="Tipo de export"),
    export_format: ExportFormat = Query(..., description="Formato do export"),
    git_repository: Optional[str] = Query(None, description="Repositório Git"),
    git_branch: Optional[str] = Query("main", description="Branch Git"),
    trigger_pipeline: bool = Query(False, description="Disparar pipeline CI/CD"),
    background_tasks: BackgroundTasks = BackgroundTasks(),
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Endpoint simplificado para exportar um contrato específico
    
    - **contract_id**: ID do contrato
    - **export_type**: Tipo de export
    - **export_format**: Formato do export
    - **git_repository**: Repositório Git (obrigatório para tipo 'git')
    - **git_branch**: Branch do Git
    - **trigger_pipeline**: Se deve disparar pipeline CI/CD
    """
    try:
        # Validar parâmetros
        if export_type == ExportType.GIT and not git_repository:
            raise HTTPException(status_code=400, detail="Repositório Git é obrigatório para export tipo 'git'")
        
        # Criar request
        request = ContractExportRequest(
            contract_id=contract_id,
            export_type=export_type,
            export_format=export_format,
            git_repository=git_repository,
            git_branch=git_branch,
            trigger_pipeline=trigger_pipeline
        )
        
        service = ContractExportService(db)
        export = await service.create_export(request, current_user.get("username", "unknown"))
        
        return export
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.get("/contract/{contract_id}/preview", response_model=ContractExportPreviewResponse)
async def preview_contract_export(
    contract_id: int,
    export_format: ExportFormat = Query(..., description="Formato do export"),
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Gera preview do que será exportado para um contrato
    
    - **contract_id**: ID do contrato
    - **export_format**: Formato do preview
    """
    try:
        service = ContractExportService(db)
        
        # Obter contrato
        contract = await service._get_contract(contract_id)
        if not contract:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        
        # Gerar preview
        content = await service._generate_export_content(contract, export_format.value)
        
        return ContractExportPreviewResponse(
            contract_id=contract_id,
            export_format=export_format,
            preview_content=content,
            estimated_size_bytes=len(content.encode('utf-8')),
            validation_results=[],
            warnings=[],
            generated_at=datetime.utcnow()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


# Endpoints de aprovação de contratos
@router.post("/contracts/{contract_id}/submit", response_model=dict)
async def submit_contract_for_approval(
    contract_id: int,
    approval_type: str = Query("technical", description="Tipo de aprovação"),
    comments: Optional[str] = Query(None, description="Comentários"),
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Submete contrato para aprovação
    
    - **contract_id**: ID do contrato
    - **approval_type**: Tipo de aprovação (technical, business, compliance)
    - **comments**: Comentários adicionais
    """
    try:
        # TODO: Implementar lógica de submissão para aprovação
        # Por enquanto, retorna sucesso
        
        return {
            "message": "Contrato submetido para aprovação com sucesso",
            "contract_id": contract_id,
            "approval_type": approval_type,
            "status": "pending_approval",
            "submitted_by": current_user.get("username"),
            "submitted_at": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.post("/contracts/{contract_id}/approve", response_model=dict)
async def approve_contract(
    contract_id: int,
    approval_type: str = Query("technical", description="Tipo de aprovação"),
    comments: Optional[str] = Query(None, description="Comentários da aprovação"),
    conditions: Optional[str] = Query(None, description="Condições da aprovação"),
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Aprova um contrato
    
    - **contract_id**: ID do contrato
    - **approval_type**: Tipo de aprovação
    - **comments**: Comentários da aprovação
    - **conditions**: Condições da aprovação
    """
    try:
        # TODO: Implementar lógica de aprovação
        # Por enquanto, retorna sucesso
        
        return {
            "message": "Contrato aprovado com sucesso",
            "contract_id": contract_id,
            "approval_type": approval_type,
            "status": "approved",
            "approved_by": current_user.get("username"),
            "approved_at": datetime.utcnow().isoformat(),
            "comments": comments,
            "conditions": conditions
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.post("/contracts/{contract_id}/reject", response_model=dict)
async def reject_contract(
    contract_id: int,
    approval_type: str = Query("technical", description="Tipo de aprovação"),
    reason: str = Query(..., description="Motivo da rejeição"),
    comments: Optional[str] = Query(None, description="Comentários adicionais"),
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Rejeita um contrato
    
    - **contract_id**: ID do contrato
    - **approval_type**: Tipo de aprovação
    - **reason**: Motivo da rejeição
    - **comments**: Comentários adicionais
    """
    try:
        # TODO: Implementar lógica de rejeição
        # Por enquanto, retorna sucesso
        
        return {
            "message": "Contrato rejeitado",
            "contract_id": contract_id,
            "approval_type": approval_type,
            "status": "rejected",
            "rejected_by": current_user.get("username"),
            "rejected_at": datetime.utcnow().isoformat(),
            "reason": reason,
            "comments": comments
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")


@router.get("/contracts/pending-approval", response_model=List[dict])
async def get_pending_approvals(
    approval_type: Optional[str] = Query(None, description="Filtrar por tipo de aprovação"),
    page: int = Query(1, ge=1, description="Página"),
    size: int = Query(20, ge=1, le=100, description="Tamanho da página"),
    db: AsyncSession = Depends(get_async_session),
    current_user: dict = Depends(get_current_active_user)
):
    """
    Lista contratos pendentes de aprovação
    
    - **approval_type**: Filtrar por tipo de aprovação
    - **page**: Número da página
    - **size**: Itens por página
    """
    try:
        # TODO: Implementar lógica para buscar aprovações pendentes
        # Por enquanto, retorna lista vazia
        
        return []
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro interno: {str(e)}")

