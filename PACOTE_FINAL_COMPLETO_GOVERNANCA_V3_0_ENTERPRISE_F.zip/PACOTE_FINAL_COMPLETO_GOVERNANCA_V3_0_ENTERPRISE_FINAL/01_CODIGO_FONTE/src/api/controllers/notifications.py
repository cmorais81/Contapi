"""
Controller para Notificações
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from src.application.dtos.notifications import (
    NotificationCreateDTO,
    NotificationResponseDTO,
    NotificationTemplateDTO,
    NotificationPreferenceDTO,
    NotificationRuleDTO,
    NotificationDeliveryDTO,
    NotificationStatsDTO,
    BulkNotificationDTO,
    BulkNotificationResultDTO,
    NotificationDigestDTO,
    NotificationType,
    NotificationChannel,
    NotificationPriority,
    NotificationStatus,
)
from src.application.dtos import PaginatedResponse, PaginationParams
from src.application.services.notification_service import NotificationService
from src.domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from src.api.dependencies import get_current_active_user, get_notification_service, validate_pagination

router = APIRouter(prefix="/api/v1/notifications", tags=["Notifications"])


# Notifications Management
@router.post(
    "/",
    response_model=NotificationResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar notificação",
    description="Cria e envia uma nova notificação"
)
async def create_notification(
    notification: NotificationCreateDTO,
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> NotificationResponseDTO:
    """Cria nova notificação"""
    try:
        return await service.create_notification(notification, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/",
    response_model=PaginatedResponse[NotificationResponseDTO],
    summary="Listar notificações",
    description="Lista notificações com filtros"
)
async def list_notifications(
    pagination: PaginationParams = Depends(validate_pagination),
    notification_type: Optional[NotificationType] = Query(None, description="Filtro por tipo"),
    status: Optional[NotificationStatus] = Query(None, description="Filtro por status"),
    priority: Optional[NotificationPriority] = Query(None, description="Filtro por prioridade"),
    recipient: Optional[str] = Query(None, description="Filtro por destinatário"),
    unread_only: bool = Query(False, description="Apenas não lidas"),
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[NotificationResponseDTO]:
    """Lista notificações"""
    filters = {
        "notification_type": notification_type,
        "status": status,
        "priority": priority,
        "recipient": recipient,
        "unread_only": unread_only
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_notifications(pagination, filters)


@router.get(
    "/{notification_id}",
    response_model=NotificationResponseDTO,
    summary="Buscar notificação",
    description="Retorna detalhes de uma notificação específica"
)
async def get_notification(
    notification_id: UUID,
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> NotificationResponseDTO:
    """Busca notificação específica"""
    try:
        return await service.get_notification(notification_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/{notification_id}/mark-read",
    response_model=dict,
    summary="Marcar como lida",
    description="Marca uma notificação como lida"
)
async def mark_notification_read(
    notification_id: UUID,
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Marca notificação como lida"""
    try:
        await service.mark_notification_read(notification_id, current_user["id"])
        return {"message": "Notification marked as read"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/bulk",
    response_model=BulkNotificationResultDTO,
    summary="Notificação em lote",
    description="Cria múltiplas notificações em uma operação"
)
async def create_bulk_notifications(
    bulk_notification: BulkNotificationDTO,
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> BulkNotificationResultDTO:
    """Cria notificações em lote"""
    try:
        return await service.create_bulk_notifications(bulk_notification, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/my-notifications",
    response_model=PaginatedResponse[NotificationResponseDTO],
    summary="Minhas notificações",
    description="Lista notificações do usuário atual"
)
async def get_my_notifications(
    pagination: PaginationParams = Depends(validate_pagination),
    unread_only: bool = Query(False, description="Apenas não lidas"),
    priority: Optional[NotificationPriority] = Query(None, description="Filtro por prioridade"),
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[NotificationResponseDTO]:
    """Lista notificações do usuário"""
    filters = {
        "recipient": current_user["email"],
        "unread_only": unread_only,
        "priority": priority
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_notifications(pagination, filters)


# Templates
@router.post(
    "/templates",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Criar template",
    description="Cria um template de notificação reutilizável"
)
async def create_notification_template(
    template: NotificationTemplateDTO,
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cria template de notificação"""
    try:
        template_id = await service.create_notification_template(template, current_user["id"])
        return {"message": "Notification template created successfully", "id": template_id}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/templates",
    response_model=List[dict],
    summary="Listar templates",
    description="Lista templates de notificação disponíveis"
)
async def list_notification_templates(
    notification_type: Optional[NotificationType] = Query(None, description="Filtro por tipo"),
    is_active: bool = Query(True, description="Filtro por ativo"),
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista templates de notificação"""
    filters = {
        "notification_type": notification_type,
        "is_active": is_active
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_notification_templates(filters)


# Preferences
@router.post(
    "/preferences",
    response_model=dict,
    summary="Configurar preferências",
    description="Configura preferências de notificação do usuário"
)
async def set_notification_preferences(
    preferences: List[NotificationPreferenceDTO],
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Configura preferências de notificação"""
    try:
        # Set user_id for all preferences
        for pref in preferences:
            pref.user_id = current_user["id"]
        
        await service.set_notification_preferences(preferences)
        return {"message": "Notification preferences updated successfully"}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/preferences",
    response_model=List[NotificationPreferenceDTO],
    summary="Obter preferências",
    description="Retorna preferências de notificação do usuário"
)
async def get_notification_preferences(
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[NotificationPreferenceDTO]:
    """Obtém preferências de notificação"""
    return await service.get_notification_preferences(current_user["id"])


# Rules
@router.post(
    "/rules",
    response_model=dict,
    status_code=status.HTTP_201_CREATED,
    summary="Criar regra de notificação",
    description="Cria uma regra automática de notificação"
)
async def create_notification_rule(
    rule: NotificationRuleDTO,
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Cria regra de notificação"""
    try:
        rule_id = await service.create_notification_rule(rule, current_user["id"])
        return {"message": "Notification rule created successfully", "id": rule_id}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/rules",
    response_model=List[dict],
    summary="Listar regras",
    description="Lista regras de notificação ativas"
)
async def list_notification_rules(
    event_type: Optional[str] = Query(None, description="Filtro por tipo de evento"),
    is_active: bool = Query(True, description="Filtro por ativo"),
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[dict]:
    """Lista regras de notificação"""
    filters = {
        "event_type": event_type,
        "is_active": is_active
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_notification_rules(filters)


# Statistics and Analytics
@router.get(
    "/stats",
    response_model=NotificationStatsDTO,
    summary="Estatísticas de notificação",
    description="Retorna estatísticas de entrega e engajamento"
)
async def get_notification_stats(
    period_days: int = Query(30, ge=1, le=365, description="Período em dias"),
    notification_type: Optional[NotificationType] = Query(None, description="Filtro por tipo"),
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> NotificationStatsDTO:
    """Obtém estatísticas de notificação"""
    filters = {
        "period_days": period_days,
        "notification_type": notification_type
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.get_notification_stats(filters)


# Delivery Status
@router.get(
    "/{notification_id}/delivery",
    response_model=List[NotificationDeliveryDTO],
    summary="Status de entrega",
    description="Retorna status de entrega por canal"
)
async def get_notification_delivery_status(
    notification_id: UUID,
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[NotificationDeliveryDTO]:
    """Obtém status de entrega"""
    try:
        return await service.get_notification_delivery_status(notification_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


# Digest
@router.get(
    "/digest",
    response_model=NotificationDigestDTO,
    summary="Digest de notificações",
    description="Gera digest personalizado de notificações"
)
async def generate_notification_digest(
    digest_type: str = Query("daily", description="Tipo de digest (daily, weekly)"),
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> NotificationDigestDTO:
    """Gera digest de notificações"""
    try:
        return await service.generate_notification_digest(current_user["id"], digest_type)
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


# Bulk Actions
@router.post(
    "/mark-all-read",
    response_model=dict,
    summary="Marcar todas como lidas",
    description="Marca todas as notificações do usuário como lidas"
)
async def mark_all_notifications_read(
    notification_type: Optional[NotificationType] = Query(None, description="Filtro por tipo"),
    service: NotificationService = Depends(get_notification_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Marca todas as notificações como lidas"""
    try:
        count = await service.mark_all_notifications_read(
            current_user["id"], 
            notification_type
        )
        return {"message": f"{count} notifications marked as read"}
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

