from typing import Optional, List, Dict, Any
"""
Controller de Sistema e Performance
Desenvolvido por Carlos Morais
"""

from datetime import datetime, timedelta
from typing import List, Dict, Any
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text
from pydantic import BaseModel
import psutil
import asyncio

from src.database.connection import get_async_session
from src.database.models import QueryPerformanceLog, LoadBalancerMetrics
from src.api.controllers.auth import get_current_active_user

router = APIRouter(prefix="/api/v1/system", tags=["System & Performance"])

# Modelos Pydantic
class SystemMetrics(BaseModel):
    cpu_usage: float
    memory_usage: float
    disk_usage: float
    network_io: Dict[str, int]
    uptime: float
    timestamp: datetime

class DatabaseMetrics(BaseModel):
    active_connections: int
    idle_connections: int
    total_connections: int
    pool_size: int
    pool_utilization: float
    avg_query_time: float
    slow_queries_count: int
    status: str

class PerformanceMetrics(BaseModel):
    requests_per_second: float
    avg_response_time: float
    error_rate: float
    cache_hit_rate: float
    database_metrics: DatabaseMetrics
    system_metrics: SystemMetrics

class QueryPerformanceResponse(BaseModel):
    id: int
    query_hash: str
    query_text: str
    execution_time: float
    rows_affected: int
    endpoint: Optional[str]
    user_id: Optional[int]
    created_at: datetime

    class Config:
        from_attributes = True

class LoadBalancerStatus(BaseModel):
    instance_id: str
    status: str
    health_score: float
    active_connections: int
    requests_handled: int
    last_health_check: datetime
    uptime: float

@router.get("/performance", response_model=PerformanceMetrics)
async def get_performance_metrics(
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter métricas de performance do sistema
    """
    # Métricas do sistema
    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')
    network = psutil.net_io_counters()
    boot_time = psutil.boot_time()
    uptime = datetime.now().timestamp() - boot_time
    
    system_metrics = SystemMetrics(
        cpu_usage=cpu_percent,
        memory_usage=memory.percent,
        disk_usage=(disk.used / disk.total) * 100,
        network_io={
            "bytes_sent": network.bytes_sent,
            "bytes_recv": network.bytes_recv,
            "packets_sent": network.packets_sent,
            "packets_recv": network.packets_recv
        },
        uptime=uptime,
        timestamp=datetime.utcnow()
    )
    
    # Métricas do banco de dados
    try:
        # Verificar conexões ativas (PostgreSQL)
        result = await db.execute(text("SELECT count(*) FROM pg_stat_activity WHERE state = 'active'"))
        active_connections = result.scalar() or 0
        
        result = await db.execute(text("SELECT count(*) FROM pg_stat_activity WHERE state = 'idle'"))
        idle_connections = result.scalar() or 0
        
        total_connections = active_connections + idle_connections
        
        # Pool size (exemplo)
        pool_size = 20
        pool_utilization = (total_connections / pool_size) * 100 if pool_size > 0 else 0
        
        # Tempo médio de query (últimas 100 queries)
        perf_query = select(QueryPerformanceLog).order_by(QueryPerformanceLog.created_at.desc()).limit(100)
        result = await db.execute(perf_query)
        recent_queries = result.scalars().all()
        
        if recent_queries:
            avg_query_time = sum(q.execution_time for q in recent_queries) / len(recent_queries)
            slow_queries_count = len([q for q in recent_queries if q.execution_time > 1.0])
        else:
            avg_query_time = 0.0
            slow_queries_count = 0
        
        # Status do banco
        if pool_utilization > 90:
            db_status = "critical"
        elif pool_utilization > 70:
            db_status = "warning"
        else:
            db_status = "healthy"
        
        database_metrics = DatabaseMetrics(
            active_connections=active_connections,
            idle_connections=idle_connections,
            total_connections=total_connections,
            pool_size=pool_size,
            pool_utilization=pool_utilization,
            avg_query_time=avg_query_time,
            slow_queries_count=slow_queries_count,
            status=db_status
        )
        
    except Exception as e:
        # Fallback para SQLite ou erro de conexão
        database_metrics = DatabaseMetrics(
            active_connections=1,
            idle_connections=0,
            total_connections=1,
            pool_size=1,
            pool_utilization=100.0,
            avg_query_time=0.1,
            slow_queries_count=0,
            status="healthy"
        )
    
    # Métricas de performance da aplicação (exemplo)
    return PerformanceMetrics(
        requests_per_second=45.2,  # Seria calculado baseado em métricas reais
        avg_response_time=0.15,
        error_rate=0.02,
        cache_hit_rate=0.85,
        database_metrics=database_metrics,
        system_metrics=system_metrics
    )

@router.get("/pool-status", response_model=DatabaseMetrics)
async def get_pool_status(
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter status detalhado do pool de conexões
    """
    try:
        # Informações do pool de conexões
        result = await db.execute(text("SELECT count(*) FROM pg_stat_activity"))
        total_connections = result.scalar() or 0
        
        result = await db.execute(text("SELECT count(*) FROM pg_stat_activity WHERE state = 'active'"))
        active_connections = result.scalar() or 0
        
        idle_connections = total_connections - active_connections
        
        # Configurações do pool
        pool_size = 20  # Seria obtido da configuração real
        pool_utilization = (total_connections / pool_size) * 100 if pool_size > 0 else 0
        
        # Queries recentes para calcular tempo médio
        perf_query = select(QueryPerformanceLog).order_by(QueryPerformanceLog.created_at.desc()).limit(50)
        result = await db.execute(perf_query)
        recent_queries = result.scalars().all()
        
        if recent_queries:
            avg_query_time = sum(q.execution_time for q in recent_queries) / len(recent_queries)
            slow_queries_count = len([q for q in recent_queries if q.execution_time > 1.0])
        else:
            avg_query_time = 0.0
            slow_queries_count = 0
        
        # Determinar status
        if pool_utilization > 90:
            status = "critical"
        elif pool_utilization > 70:
            status = "warning"
        else:
            status = "healthy"
        
        return DatabaseMetrics(
            active_connections=active_connections,
            idle_connections=idle_connections,
            total_connections=total_connections,
            pool_size=pool_size,
            pool_utilization=pool_utilization,
            avg_query_time=avg_query_time,
            slow_queries_count=slow_queries_count,
            status=status
        )
        
    except Exception:
        # Fallback para SQLite
        return DatabaseMetrics(
            active_connections=1,
            idle_connections=0,
            total_connections=1,
            pool_size=1,
            pool_utilization=100.0,
            avg_query_time=0.05,
            slow_queries_count=0,
            status="healthy"
        )

@router.get("/load-balancer", response_model=List[LoadBalancerStatus])
async def get_load_balancer_status(
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter status do load balancer
    """
    # Buscar métricas do load balancer
    query = select(LoadBalancerMetrics).order_by(LoadBalancerMetric.timestamp.desc()).limit(10)
    result = await db.execute(query)
    metrics = result.scalars().all()
    
    # Agrupar por instância
    instances = {}
    for metric in metrics:
        instance_id = metric.instance_id
        if instance_id not in instances:
            instances[instance_id] = {
                "instance_id": instance_id,
                "status": metric.status,
                "health_score": metric.health_score,
                "active_connections": metric.active_connections,
                "requests_handled": metric.requests_handled,
                "last_health_check": metric.timestamp,
                "uptime": (datetime.utcnow() - metric.timestamp).total_seconds()
            }
    
    # Se não há métricas, retornar instância padrão
    if not instances:
        instances["default"] = {
            "instance_id": "default",
            "status": "healthy",
            "health_score": 100.0,
            "active_connections": 5,
            "requests_handled": 1234,
            "last_health_check": datetime.utcnow(),
            "uptime": 3600.0
        }
    
    return [LoadBalancerStatus(**instance) for instance in instances.values()]

@router.get("/slow-queries", response_model=List[QueryPerformanceResponse])
async def get_slow_queries(
    limit: int = 50,
    threshold: float = 1.0,
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Obter queries lentas
    """
    query = select(QueryPerformanceLog).where(
        QueryPerformanceLog.execution_time > threshold
    ).order_by(QueryPerformanceLog.execution_time.desc()).limit(limit)
    
    result = await db.execute(query)
    slow_queries = result.scalars().all()
    
    return slow_queries

@router.get("/health-check")
async def detailed_health_check(
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Health check detalhado do sistema
    """
    checks = {}
    overall_status = "healthy"
    
    # Verificar banco de dados
    try:
        await db.execute(text("SELECT 1"))
        checks["database"] = {"status": "healthy", "message": "Database connection OK"}
    except Exception as e:
        checks["database"] = {"status": "unhealthy", "message": f"Database error: {str(e)}"}
        overall_status = "unhealthy"
    
    # Verificar sistema
    try:
        cpu_usage = psutil.cpu_percent()
        memory_usage = psutil.virtual_memory().percent
        
        if cpu_usage > 90 or memory_usage > 90:
            checks["system"] = {"status": "warning", "message": f"High resource usage: CPU {cpu_usage}%, Memory {memory_usage}%"}
            if overall_status == "healthy":
                overall_status = "warning"
        else:
            checks["system"] = {"status": "healthy", "message": f"System OK: CPU {cpu_usage}%, Memory {memory_usage}%"}
    except Exception as e:
        checks["system"] = {"status": "warning", "message": f"System check error: {str(e)}"}
        if overall_status == "healthy":
            overall_status = "warning"
    
    # Verificar cache (Redis)
    try:
        # Aqui você verificaria a conexão com Redis
        checks["cache"] = {"status": "healthy", "message": "Cache connection OK"}
    except Exception as e:
        checks["cache"] = {"status": "warning", "message": f"Cache warning: {str(e)}"}
        if overall_status == "healthy":
            overall_status = "warning"
    
    return {
        "status": overall_status,
        "timestamp": datetime.utcnow(),
        "checks": checks,
        "version": "2.1.0"
    }

@router.post("/optimize-database")
async def optimize_database(
    db: AsyncSession = Depends(get_async_session),
    current_user = Depends(get_current_active_user)
):
    """
    Executar otimizações no banco de dados
    """
    # TODO: Verificar se usuário é admin
    
    optimizations = []
    
    try:
        # VACUUM (PostgreSQL)
        await db.execute(text("VACUUM ANALYZE"))
        optimizations.append("VACUUM ANALYZE executed")
        
        # Reindex (PostgreSQL)
        await db.execute(text("REINDEX DATABASE governance_db"))
        optimizations.append("Database reindexed")
        
    except Exception as e:
        optimizations.append(f"Optimization error: {str(e)}")
    
    return {
        "message": "Database optimization completed",
        "optimizations": optimizations,
        "timestamp": datetime.utcnow()
    }

