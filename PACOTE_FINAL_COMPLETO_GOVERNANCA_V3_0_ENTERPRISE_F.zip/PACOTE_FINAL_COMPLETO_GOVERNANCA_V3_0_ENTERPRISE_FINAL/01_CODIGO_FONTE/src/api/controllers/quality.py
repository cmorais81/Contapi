"""
Controller de Qualidade de Dados - V1.9 com Banco de Dados
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from fastapi import APIRouter, HTTPException, Depends, Query
from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session
import logging

from src.database.connection import get_database_session
from src.database.models.quality import QualityRule, QualityMetric, DataQualityIssue
from src.database.repositories.base import BaseRepository

logger = logging.getLogger(__name__)

# Criar router
router = APIRouter()

def get_quality_rule_repository(db: Session = Depends(get_database_session)) -> BaseRepository[QualityRule]:
    """Dependency para obter repository de regras de qualidade"""
    return BaseRepository(QualityRule, db)

def get_quality_metric_repository(db: Session = Depends(get_database_session)) -> BaseRepository[QualityMetric]:
    """Dependency para obter repository de métricas de qualidade"""
    return BaseRepository(QualityMetric, db)

def get_quality_issue_repository(db: Session = Depends(get_database_session)) -> BaseRepository[DataQualityIssue]:
    """Dependency para obter repository de problemas de qualidade"""
    return BaseRepository(DataQualityIssue, db)

# ========================================
# REGRAS DE QUALIDADE
# ========================================

@router.get("/quality/rules", summary="Listar regras de qualidade")
async def list_quality_rules(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    rule_type: Optional[str] = Query(None, description="Filtrar por tipo de regra"),
    is_active: Optional[bool] = Query(None, description="Filtrar por status ativo"),
    repository: BaseRepository[QualityRule] = Depends(get_quality_rule_repository)
):
    """
    Lista todas as regras de qualidade de dados.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if rule_type:
            filters['rule_type'] = rule_type
        if is_active is not None:
            filters['is_active'] = is_active
        
        # Buscar regras
        rules = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='created_at',
            sort_order='desc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(rules)} regras de qualidade de {total} total")
        
        return {
            "rules": [rule.to_dict() for rule in rules],
            "total": total,
            "limit": limit,
            "offset": offset,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar regras de qualidade: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/quality/rules", summary="Criar regra de qualidade")
async def create_quality_rule(
    rule_data: Dict[str, Any],
    repository: BaseRepository[QualityRule] = Depends(get_quality_rule_repository)
):
    """
    Cria uma nova regra de qualidade de dados.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['name', 'rule_type', 'rule_definition']
        for field in required_fields:
            if field not in rule_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Verificar se já existe regra com mesmo nome
        existing = repository.find_one_by(name=rule_data['name'])
        if existing:
            raise HTTPException(status_code=409, detail="Regra com este nome já existe")
        
        # Criar regra
        rule = repository.create(**rule_data)
        
        logger.info(f"Regra de qualidade criada: {rule.id}")
        
        return {
            "rule": rule.to_dict(),
            "message": "Regra de qualidade criada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar regra de qualidade: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/quality/rules/{rule_id}", summary="Obter regra de qualidade")
async def get_quality_rule(
    rule_id: UUID,
    repository: BaseRepository[QualityRule] = Depends(get_quality_rule_repository)
):
    """
    Obtém uma regra de qualidade específica por ID.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        rule = repository.get_by_id(rule_id)
        
        if not rule:
            raise HTTPException(status_code=404, detail="Regra de qualidade não encontrada")
        
        logger.info(f"Regra de qualidade encontrada: {rule_id}")
        
        return {
            "rule": rule.to_dict(),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter regra de qualidade {rule_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# MÉTRICAS DE QUALIDADE
# ========================================

@router.get("/quality/metrics", summary="Listar métricas de qualidade")
async def list_quality_metrics(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    rule_id: Optional[UUID] = Query(None, description="Filtrar por regra"),
    entity_id: Optional[UUID] = Query(None, description="Filtrar por entidade"),
    repository: BaseRepository[QualityMetric] = Depends(get_quality_metric_repository)
):
    """
    Lista métricas de qualidade coletadas.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if rule_id:
            filters['rule_id'] = rule_id
        if entity_id:
            filters['entity_id'] = entity_id
        
        # Buscar métricas
        metrics = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='execution_date',
            sort_order='desc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(metrics)} métricas de qualidade de {total} total")
        
        return {
            "metrics": [metric.to_dict() for metric in metrics],
            "total": total,
            "limit": limit,
            "offset": offset,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar métricas de qualidade: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/quality/metrics", summary="Registrar métrica de qualidade")
async def create_quality_metric(
    metric_data: Dict[str, Any],
    repository: BaseRepository[QualityMetric] = Depends(get_quality_metric_repository)
):
    """
    Registra uma nova métrica de qualidade.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['rule_id', 'entity_id', 'execution_date', 'metric_value', 'passed']
        for field in required_fields:
            if field not in metric_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Criar métrica
        metric = repository.create(**metric_data)
        
        logger.info(f"Métrica de qualidade registrada: {metric.id}")
        
        return {
            "metric": metric.to_dict(),
            "message": "Métrica de qualidade registrada com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao registrar métrica de qualidade: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# ========================================
# PROBLEMAS DE QUALIDADE
# ========================================

@router.get("/quality/issues", summary="Listar problemas de qualidade")
async def list_quality_issues(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    severity: Optional[str] = Query(None, description="Filtrar por severidade"),
    repository: BaseRepository[DataQualityIssue] = Depends(get_quality_issue_repository)
):
    """
    Lista problemas de qualidade identificados.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Aplicar filtros
        filters = {}
        if status:
            filters['status'] = status
        if severity:
            filters['severity'] = severity
        
        # Buscar problemas
        issues = repository.search(
            filters=filters,
            limit=limit,
            offset=offset,
            sort_by='detection_date',
            sort_order='desc'
        )
        
        total = repository.count(filters)
        
        logger.info(f"Listando {len(issues)} problemas de qualidade de {total} total")
        
        return {
            "issues": [issue.to_dict() for issue in issues],
            "total": total,
            "limit": limit,
            "offset": offset,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar problemas de qualidade: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/quality/issues", summary="Registrar problema de qualidade")
async def create_quality_issue(
    issue_data: Dict[str, Any],
    repository: BaseRepository[DataQualityIssue] = Depends(get_quality_issue_repository)
):
    """
    Registra um novo problema de qualidade.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        # Validar dados obrigatórios
        required_fields = ['rule_id', 'entity_id', 'title', 'severity', 'detection_date']
        for field in required_fields:
            if field not in issue_data:
                raise HTTPException(status_code=400, detail=f"Campo {field} é obrigatório")
        
        # Criar problema
        issue = repository.create(**issue_data)
        
        logger.info(f"Problema de qualidade registrado: {issue.id}")
        
        return {
            "issue": issue.to_dict(),
            "message": "Problema de qualidade registrado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao registrar problema de qualidade: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/quality/issues/{issue_id}", summary="Atualizar problema de qualidade")
async def update_quality_issue(
    issue_id: UUID,
    issue_data: Dict[str, Any],
    repository: BaseRepository[DataQualityIssue] = Depends(get_quality_issue_repository)
):
    """
    Atualiza um problema de qualidade existente.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        issue = repository.update(issue_id, **issue_data)
        
        if not issue:
            raise HTTPException(status_code=404, detail="Problema de qualidade não encontrado")
        
        logger.info(f"Problema de qualidade atualizado: {issue_id}")
        
        return {
            "issue": issue.to_dict(),
            "message": "Problema de qualidade atualizado com sucesso",
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao atualizar problema de qualidade {issue_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

