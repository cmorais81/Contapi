"""
Sistema de Validação de Entrada - 100% Cobertura
Objetivo: Validar todas as entradas da API de forma robusta
"""

import re
import html
import json
import uuid
from typing import Any, Dict, List, Optional, Union, Tuple
from datetime import datetime, date
from decimal import Decimal, InvalidOperation
from email_validator import validate_email, EmailNotValidError
from pydantic import BaseModel, validator, ValidationError
import bleach
from urllib.parse import urlparse


class SecurityValidator:
    """Validador de segurança para prevenir ataques"""
    
    # Padrões de ataques conhecidos
    SQL_INJECTION_PATTERNS = [
        r"(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|SCRIPT)\b)",
        r"(--|#|/\*|\*/)",
        r"(\b(OR|AND)\s+\d+\s*=\s*\d+)",
        r"(\b(OR|AND)\s+['\"]?\w+['\"]?\s*=\s*['\"]?\w+['\"]?)",
        r"(;\s*(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION))",
    ]
    
    XSS_PATTERNS = [
        r"<script[^>]*>.*?</script>",
        r"javascript:",
        r"on\w+\s*=",
        r"<iframe[^>]*>.*?</iframe>",
        r"<object[^>]*>.*?</object>",
        r"<embed[^>]*>.*?</embed>",
        r"<link[^>]*>",
        r"<meta[^>]*>",
    ]
    
    PATH_TRAVERSAL_PATTERNS = [
        r"\.\./",
        r"\.\.\\",
        r"%2e%2e%2f",
        r"%2e%2e%5c",
        r"..%2f",
        r"..%5c",
    ]
    
    COMMAND_INJECTION_PATTERNS = [
        r"[;&|`$(){}[\]<>]",
        r"\b(cat|ls|pwd|whoami|id|uname|ps|netstat|ifconfig|ping|wget|curl|nc|telnet|ssh|ftp)\b",
        r"(\||&&|\|\|)",
    ]
    
    LDAP_INJECTION_PATTERNS = [
        r"[()&|!*]",
        r"\*\)",
        r"\(\|",
        r"\(&",
        r"\(!"
    ]
    
    @classmethod
    def detect_sql_injection(cls, value: str) -> List[str]:
        """Detecta tentativas de SQL injection"""
        threats = []
        value_lower = value.lower()
        
        for pattern in cls.SQL_INJECTION_PATTERNS:
            if re.search(pattern, value_lower, re.IGNORECASE):
                threats.append("sql_injection")
                break
        
        return threats
    
    @classmethod
    def detect_xss(cls, value: str) -> List[str]:
        """Detecta tentativas de XSS"""
        threats = []
        value_lower = value.lower()
        
        for pattern in cls.XSS_PATTERNS:
            if re.search(pattern, value_lower, re.IGNORECASE):
                threats.append("xss")
                break
        
        return threats
    
    @classmethod
    def detect_path_traversal(cls, value: str) -> List[str]:
        """Detecta tentativas de path traversal"""
        threats = []
        
        for pattern in cls.PATH_TRAVERSAL_PATTERNS:
            if re.search(pattern, value, re.IGNORECASE):
                threats.append("path_traversal")
                break
        
        return threats
    
    @classmethod
    def detect_command_injection(cls, value: str) -> List[str]:
        """Detecta tentativas de command injection"""
        threats = []
        
        for pattern in cls.COMMAND_INJECTION_PATTERNS:
            if re.search(pattern, value, re.IGNORECASE):
                threats.append("command_injection")
                break
        
        return threats
    
    @classmethod
    def detect_ldap_injection(cls, value: str) -> List[str]:
        """Detecta tentativas de LDAP injection"""
        threats = []
        
        for pattern in cls.LDAP_INJECTION_PATTERNS:
            if re.search(pattern, value):
                threats.append("ldap_injection")
                break
        
        return threats
    
    @classmethod
    def detect_all_threats(cls, value: str) -> List[str]:
        """Detecta todas as ameaças conhecidas"""
        if not isinstance(value, str):
            return []
        
        threats = []
        threats.extend(cls.detect_sql_injection(value))
        threats.extend(cls.detect_xss(value))
        threats.extend(cls.detect_path_traversal(value))
        threats.extend(cls.detect_command_injection(value))
        threats.extend(cls.detect_ldap_injection(value))
        
        return list(set(threats))  # Remove duplicatas


class InputSanitizer:
    """Sanitizador de entrada para limpar dados maliciosos"""
    
    @staticmethod
    def sanitize_html(value: str) -> str:
        """Sanitiza HTML removendo tags perigosas"""
        if not isinstance(value, str):
            return value
        
        # Tags permitidas (muito restritivas)
        allowed_tags = ['b', 'i', 'u', 'em', 'strong', 'p', 'br']
        allowed_attributes = {}
        
        return bleach.clean(
            value,
            tags=allowed_tags,
            attributes=allowed_attributes,
            strip=True
        )
    
    @staticmethod
    def sanitize_sql(value: str) -> str:
        """Sanitiza entrada para prevenir SQL injection"""
        if not isinstance(value, str):
            return value
        
        # Escape de aspas simples
        value = value.replace("'", "''")
        
        # Remove comentários SQL
        value = re.sub(r"--.*$", "", value, flags=re.MULTILINE)
        value = re.sub(r"/\*.*?\*/", "", value, flags=re.DOTALL)
        
        return value
    
    @staticmethod
    def sanitize_filename(value: str) -> str:
        """Sanitiza nome de arquivo"""
        if not isinstance(value, str):
            return value
        
        # Remove caracteres perigosos
        value = re.sub(r'[<>:"/\\|?*]', '', value)
        
        # Remove path traversal
        value = value.replace('..', '')
        
        # Limita tamanho
        value = value[:255]
        
        return value.strip()
    
    @staticmethod
    def sanitize_json(value: str) -> str:
        """Sanitiza JSON removendo conteúdo perigoso"""
        if not isinstance(value, str):
            return value
        
        try:
            # Parse e re-serialize para validar estrutura
            parsed = json.loads(value)
            return json.dumps(parsed)
        except (json.JSONDecodeError, TypeError):
            return "{}"
    
    @staticmethod
    def escape_special_chars(value: str) -> str:
        """Escapa caracteres especiais"""
        if not isinstance(value, str):
            return value
        
        # HTML escape
        value = html.escape(value)
        
        # Escape adicional para caracteres perigosos
        dangerous_chars = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#x27;',
            '/': '&#x2F;'
        }
        
        for char, escape in dangerous_chars.items():
            value = value.replace(char, escape)
        
        return value


class DataTypeValidator:
    """Validador de tipos de dados"""
    
    @staticmethod
    def validate_uuid(value: str) -> Tuple[bool, Optional[str]]:
        """Valida UUID"""
        try:
            uuid.UUID(value)
            return True, None
        except (ValueError, TypeError):
            return False, "Invalid UUID format"
    
    @staticmethod
    def validate_email(value: str) -> Tuple[bool, Optional[str]]:
        """Valida email"""
        try:
            validate_email(value)
            return True, None
        except EmailNotValidError as e:
            return False, str(e)
    
    @staticmethod
    def validate_url(value: str) -> Tuple[bool, Optional[str]]:
        """Valida URL"""
        try:
            result = urlparse(value)
            if not all([result.scheme, result.netloc]):
                return False, "Invalid URL format"
            
            # Verificar esquemas permitidos
            allowed_schemes = ['http', 'https', 'ftp', 'ftps']
            if result.scheme.lower() not in allowed_schemes:
                return False, f"URL scheme not allowed: {result.scheme}"
            
            return True, None
        except Exception:
            return False, "Invalid URL format"
    
    @staticmethod
    def validate_json(value: str) -> Tuple[bool, Optional[str]]:
        """Valida JSON"""
        try:
            json.loads(value)
            return True, None
        except json.JSONDecodeError as e:
            return False, f"Invalid JSON: {str(e)}"
    
    @staticmethod
    def validate_datetime(value: str) -> Tuple[bool, Optional[str]]:
        """Valida datetime ISO format"""
        try:
            datetime.fromisoformat(value.replace('Z', '+00:00'))
            return True, None
        except ValueError:
            return False, "Invalid datetime format (expected ISO format)"
    
    @staticmethod
    def validate_date(value: str) -> Tuple[bool, Optional[str]]:
        """Valida date ISO format"""
        try:
            date.fromisoformat(value)
            return True, None
        except ValueError:
            return False, "Invalid date format (expected YYYY-MM-DD)"
    
    @staticmethod
    def validate_decimal(value: str, max_digits: int = 10, decimal_places: int = 2) -> Tuple[bool, Optional[str]]:
        """Valida decimal"""
        try:
            decimal_value = Decimal(value)
            
            # Verificar número de dígitos
            sign, digits, exponent = decimal_value.as_tuple()
            if len(digits) > max_digits:
                return False, f"Too many digits (max: {max_digits})"
            
            # Verificar casas decimais
            if exponent < -decimal_places:
                return False, f"Too many decimal places (max: {decimal_places})"
            
            return True, None
        except (InvalidOperation, ValueError):
            return False, "Invalid decimal format"
    
    @staticmethod
    def validate_integer(value: str, min_value: int = None, max_value: int = None) -> Tuple[bool, Optional[str]]:
        """Valida integer"""
        try:
            int_value = int(value)
            
            if min_value is not None and int_value < min_value:
                return False, f"Value too small (min: {min_value})"
            
            if max_value is not None and int_value > max_value:
                return False, f"Value too large (max: {max_value})"
            
            return True, None
        except (ValueError, TypeError):
            return False, "Invalid integer format"


class BusinessRuleValidator:
    """Validador de regras de negócio"""
    
    @staticmethod
    def validate_contract_version(version: str) -> Tuple[bool, Optional[str]]:
        """Valida versão de contrato (semantic versioning)"""
        pattern = r'^(\d+)\.(\d+)\.(\d+)$'
        if not re.match(pattern, version):
            return False, "Version must follow semantic versioning (X.Y.Z)"
        
        parts = version.split('.')
        try:
            major, minor, patch = map(int, parts)
            if major < 0 or minor < 0 or patch < 0:
                return False, "Version numbers cannot be negative"
            return True, None
        except ValueError:
            return False, "Invalid version format"
    
    @staticmethod
    def validate_entity_name(name: str) -> Tuple[bool, Optional[str]]:
        """Valida nome de entidade"""
        if not name:
            return False, "Entity name cannot be empty"
        
        if len(name) > 255:
            return False, "Entity name too long (max: 255 characters)"
        
        # Padrão: letras, números, underscore, hífen
        pattern = r'^[a-zA-Z][a-zA-Z0-9_-]*$'
        if not re.match(pattern, name):
            return False, "Entity name must start with letter and contain only letters, numbers, underscore, and hyphen"
        
        return True, None
    
    @staticmethod
    def validate_quality_score(score: float) -> Tuple[bool, Optional[str]]:
        """Valida score de qualidade"""
        if not isinstance(score, (int, float)):
            return False, "Quality score must be a number"
        
        if score < 0 or score > 100:
            return False, "Quality score must be between 0 and 100"
        
        return True, None
    
    @staticmethod
    def validate_priority(priority: str) -> Tuple[bool, Optional[str]]:
        """Valida prioridade"""
        valid_priorities = ['low', 'medium', 'high', 'critical']
        if priority.lower() not in valid_priorities:
            return False, f"Priority must be one of: {', '.join(valid_priorities)}"
        
        return True, None
    
    @staticmethod
    def validate_status(status: str, valid_statuses: List[str]) -> Tuple[bool, Optional[str]]:
        """Valida status contra lista de valores válidos"""
        if status not in valid_statuses:
            return False, f"Status must be one of: {', '.join(valid_statuses)}"
        
        return True, None


class ComprehensiveValidator:
    """Validador abrangente que combina todas as validações"""
    
    def __init__(self):
        self.security_validator = SecurityValidator()
        self.sanitizer = InputSanitizer()
        self.type_validator = DataTypeValidator()
        self.business_validator = BusinessRuleValidator()
    
    def validate_and_sanitize(
        self, 
        value: Any, 
        field_name: str,
        data_type: str = "string",
        required: bool = True,
        sanitize: bool = True,
        **validation_kwargs
    ) -> Dict[str, Any]:
        """Valida e sanitiza um valor de forma abrangente"""
        
        result = {
            "original_value": value,
            "sanitized_value": value,
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "threats_detected": [],
            "field_name": field_name
        }
        
        # Verificar se é obrigatório
        if required and (value is None or value == ""):
            result["is_valid"] = False
            result["errors"].append(f"{field_name} is required")
            return result
        
        # Se valor é None ou vazio e não é obrigatório, retornar válido
        if not required and (value is None or value == ""):
            return result
        
        # Converter para string para validações
        str_value = str(value) if value is not None else ""
        
        # 1. Detectar ameaças de segurança
        threats = self.security_validator.detect_all_threats(str_value)
        if threats:
            result["threats_detected"] = threats
            result["warnings"].append(f"Security threats detected: {', '.join(threats)}")
        
        # 2. Sanitizar se solicitado
        if sanitize and isinstance(value, str):
            if data_type == "html":
                result["sanitized_value"] = self.sanitizer.sanitize_html(value)
            elif data_type == "sql":
                result["sanitized_value"] = self.sanitizer.sanitize_sql(value)
            elif data_type == "filename":
                result["sanitized_value"] = self.sanitizer.sanitize_filename(value)
            elif data_type == "json":
                result["sanitized_value"] = self.sanitizer.sanitize_json(value)
            else:
                result["sanitized_value"] = self.sanitizer.escape_special_chars(value)
        
        # 3. Validar tipo de dados
        sanitized_str = str(result["sanitized_value"]) if result["sanitized_value"] is not None else ""
        
        if data_type == "uuid":
            is_valid, error = self.type_validator.validate_uuid(sanitized_str)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        elif data_type == "email":
            is_valid, error = self.type_validator.validate_email(sanitized_str)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        elif data_type == "url":
            is_valid, error = self.type_validator.validate_url(sanitized_str)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        elif data_type == "json":
            is_valid, error = self.type_validator.validate_json(sanitized_str)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        elif data_type == "datetime":
            is_valid, error = self.type_validator.validate_datetime(sanitized_str)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        elif data_type == "date":
            is_valid, error = self.type_validator.validate_date(sanitized_str)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        elif data_type == "decimal":
            max_digits = validation_kwargs.get("max_digits", 10)
            decimal_places = validation_kwargs.get("decimal_places", 2)
            is_valid, error = self.type_validator.validate_decimal(sanitized_str, max_digits, decimal_places)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        elif data_type == "integer":
            min_value = validation_kwargs.get("min_value")
            max_value = validation_kwargs.get("max_value")
            is_valid, error = self.type_validator.validate_integer(sanitized_str, min_value, max_value)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        # 4. Validar regras de negócio específicas
        business_rule = validation_kwargs.get("business_rule")
        if business_rule == "contract_version":
            is_valid, error = self.business_validator.validate_contract_version(sanitized_str)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        elif business_rule == "entity_name":
            is_valid, error = self.business_validator.validate_entity_name(sanitized_str)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        elif business_rule == "quality_score":
            try:
                score = float(result["sanitized_value"])
                is_valid, error = self.business_validator.validate_quality_score(score)
                if not is_valid:
                    result["is_valid"] = False
                    result["errors"].append(error)
            except (ValueError, TypeError):
                result["is_valid"] = False
                result["errors"].append("Quality score must be a valid number")
        
        elif business_rule == "priority":
            is_valid, error = self.business_validator.validate_priority(sanitized_str)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        elif business_rule == "status":
            valid_statuses = validation_kwargs.get("valid_statuses", [])
            is_valid, error = self.business_validator.validate_status(sanitized_str, valid_statuses)
            if not is_valid:
                result["is_valid"] = False
                result["errors"].append(error)
        
        # 5. Validações de tamanho
        max_length = validation_kwargs.get("max_length")
        if max_length and len(sanitized_str) > max_length:
            result["is_valid"] = False
            result["errors"].append(f"{field_name} exceeds maximum length of {max_length}")
        
        min_length = validation_kwargs.get("min_length")
        if min_length and len(sanitized_str) < min_length:
            result["is_valid"] = False
            result["errors"].append(f"{field_name} is below minimum length of {min_length}")
        
        return result
    
    def validate_request_data(self, data: Dict[str, Any], validation_schema: Dict[str, Dict]) -> Dict[str, Any]:
        """Valida dados de request completos usando schema de validação"""
        
        results = {
            "is_valid": True,
            "field_results": {},
            "global_errors": [],
            "threats_summary": [],
            "sanitized_data": {}
        }
        
        # Validar cada campo
        for field_name, field_config in validation_schema.items():
            field_value = data.get(field_name)
            
            validation_result = self.validate_and_sanitize(
                value=field_value,
                field_name=field_name,
                **field_config
            )
            
            results["field_results"][field_name] = validation_result
            results["sanitized_data"][field_name] = validation_result["sanitized_value"]
            
            if not validation_result["is_valid"]:
                results["is_valid"] = False
            
            if validation_result["threats_detected"]:
                results["threats_summary"].extend(validation_result["threats_detected"])
        
        # Remover duplicatas de ameaças
        results["threats_summary"] = list(set(results["threats_summary"]))
        
        # Validações globais (relacionamentos entre campos, etc.)
        # Pode ser expandido conforme necessário
        
        return results


# Schemas de validação pré-definidos
VALIDATION_SCHEMAS = {
    "data_contract": {
        "name": {
            "data_type": "string",
            "required": True,
            "max_length": 255,
            "min_length": 1,
            "business_rule": "entity_name"
        },
        "description": {
            "data_type": "string",
            "required": False,
            "max_length": 1000,
            "sanitize": True
        },
        "version": {
            "data_type": "string",
            "required": True,
            "business_rule": "contract_version"
        },
        "owner_email": {
            "data_type": "email",
            "required": True
        },
        "schema_definition": {
            "data_type": "json",
            "required": True
        }
    },
    "entity": {
        "name": {
            "data_type": "string",
            "required": True,
            "max_length": 255,
            "business_rule": "entity_name"
        },
        "description": {
            "data_type": "string",
            "required": False,
            "max_length": 1000,
            "sanitize": True
        },
        "unity_catalog_path": {
            "data_type": "string",
            "required": True,
            "max_length": 500
        }
    },
    "quality_rule": {
        "name": {
            "data_type": "string",
            "required": True,
            "max_length": 255,
            "business_rule": "entity_name"
        },
        "expression": {
            "data_type": "sql",
            "required": True,
            "max_length": 2000,
            "sanitize": True
        },
        "severity": {
            "data_type": "string",
            "required": True,
            "business_rule": "priority"
        }
    }
}

