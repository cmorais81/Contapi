"""
Retry Policies para resiliência
"""

import asyncio
import random
import time
from typing import Any, Callable, List, Optional, Type, TypeVar, Union

from src.domain.exceptions import IntegrationError

T = TypeVar('T')


class RetryPolicy:
    """Política de retry base"""
    
    def __init__(
        self,
        max_attempts: int = 3,
        delay: float = 1.0,
        backoff_factor: float = 2.0,
        max_delay: float = 60.0,
        jitter: bool = True,
        exceptions: Optional[List[Type[Exception]]] = None
    ):
        self.max_attempts = max_attempts
        self.delay = delay
        self.backoff_factor = backoff_factor
        self.max_delay = max_delay
        self.jitter = jitter
        self.exceptions = exceptions or [Exception]
    
    def should_retry(self, exception: Exception, attempt: int) -> bool:
        """Verifica se deve tentar novamente"""
        if attempt >= self.max_attempts:
            return False
        
        return any(isinstance(exception, exc_type) for exc_type in self.exceptions)
    
    def get_delay(self, attempt: int) -> float:
        """Calcula delay para próxima tentativa"""
        delay = self.delay * (self.backoff_factor ** (attempt - 1))
        delay = min(delay, self.max_delay)
        
        if self.jitter:
            # Adicionar jitter para evitar thundering herd
            delay = delay * (0.5 + random.random() * 0.5)
        
        return delay


class ExponentialBackoffRetry(RetryPolicy):
    """Retry com backoff exponencial"""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)


class LinearBackoffRetry(RetryPolicy):
    """Retry com backoff linear"""
    
    def __init__(self, **kwargs):
        kwargs.setdefault('backoff_factor', 1.0)
        super().__init__(**kwargs)


class FixedDelayRetry(RetryPolicy):
    """Retry com delay fixo"""
    
    def __init__(self, **kwargs):
        kwargs.setdefault('backoff_factor', 1.0)
        super().__init__(**kwargs)
    
    def get_delay(self, attempt: int) -> float:
        """Delay fixo"""
        return self.delay


async def retry_async(
    func: Callable[..., T],
    policy: RetryPolicy,
    *args,
    **kwargs
) -> T:
    """Executa função assíncrona com retry"""
    
    last_exception = None
    
    for attempt in range(1, policy.max_attempts + 1):
        try:
            return await func(*args, **kwargs)
        
        except Exception as e:
            last_exception = e
            
            if not policy.should_retry(e, attempt):
                break
            
            if attempt < policy.max_attempts:
                delay = policy.get_delay(attempt)
                await asyncio.sleep(delay)
    
    # Se chegou aqui, todas as tentativas falharam
    raise IntegrationError(
        f"Failed after {policy.max_attempts} attempts",
        details={"last_exception": str(last_exception)}
    ) from last_exception


def retry_sync(
    func: Callable[..., T],
    policy: RetryPolicy,
    *args,
    **kwargs
) -> T:
    """Executa função síncrona com retry"""
    
    last_exception = None
    
    for attempt in range(1, policy.max_attempts + 1):
        try:
            return func(*args, **kwargs)
        
        except Exception as e:
            last_exception = e
            
            if not policy.should_retry(e, attempt):
                break
            
            if attempt < policy.max_attempts:
                delay = policy.get_delay(attempt)
                time.sleep(delay)
    
    # Se chegou aqui, todas as tentativas falharam
    raise IntegrationError(
        f"Failed after {policy.max_attempts} attempts",
        details={"last_exception": str(last_exception)}
    ) from last_exception


def retry(
    policy: Optional[RetryPolicy] = None,
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff_factor: float = 2.0,
    exceptions: Optional[List[Type[Exception]]] = None
):
    """Decorator para retry"""
    
    if policy is None:
        policy = ExponentialBackoffRetry(
            max_attempts=max_attempts,
            delay=delay,
            backoff_factor=backoff_factor,
            exceptions=exceptions
        )
    
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        
        async def async_wrapper(*args, **kwargs) -> T:
            return await retry_async(func, policy, *args, **kwargs)
        
        def sync_wrapper(*args, **kwargs) -> T:
            return retry_sync(func, policy, *args, **kwargs)
        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator


# Políticas pré-configuradas
DEFAULT_RETRY = ExponentialBackoffRetry(
    max_attempts=3,
    delay=1.0,
    backoff_factor=2.0,
    exceptions=[ConnectionError, TimeoutError, IntegrationError]
)

AGGRESSIVE_RETRY = ExponentialBackoffRetry(
    max_attempts=5,
    delay=0.5,
    backoff_factor=1.5,
    max_delay=30.0,
    exceptions=[ConnectionError, TimeoutError, IntegrationError]
)

CONSERVATIVE_RETRY = ExponentialBackoffRetry(
    max_attempts=2,
    delay=2.0,
    backoff_factor=3.0,
    max_delay=60.0,
    exceptions=[ConnectionError, TimeoutError]
)

NETWORK_RETRY = ExponentialBackoffRetry(
    max_attempts=4,
    delay=1.0,
    backoff_factor=2.0,
    max_delay=30.0,
    exceptions=[
        ConnectionError,
        TimeoutError,
        OSError,  # Network errors
        IntegrationError
    ]
)

