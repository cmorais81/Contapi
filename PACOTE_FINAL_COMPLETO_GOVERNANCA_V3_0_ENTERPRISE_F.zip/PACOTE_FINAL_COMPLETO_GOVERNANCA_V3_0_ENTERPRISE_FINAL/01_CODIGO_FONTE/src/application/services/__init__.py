"""
Módulo de Serviços da Aplicação
API de Governança de Dados V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

# Importações seguras dos serviços disponíveis
try:
    from .contract_service import ContractService
except ImportError:
    pass

try:
    from .data_contract_service import DataContractService
except ImportError:
    pass

try:
    from .domain_service import DomainService
except ImportError:
    pass

try:
    from .lineage_service import LineageService
except ImportError:
    pass

try:
    from .tag_service import TagService
except ImportError:
    pass

try:
    from .analytics_service import AnalyticsService
except ImportError:
    pass

try:
    from .discovery_service import DiscoveryService
except ImportError:
    pass

try:
    from .workflow_service import WorkflowService
except ImportError:
    pass

try:
    from .notification_service import NotificationService
except ImportError:
    pass

try:
    from .security_service import SecurityService
except ImportError:
    pass

try:
    from .performance_service import PerformanceService
except ImportError:
    pass

__all__ = [
    'ContractService',
    'DataContractService',
    'DomainService',
    'LineageService',
    'TagService',
    'AnalyticsService',
    'DiscoveryService',
    'WorkflowService',
    'NotificationService',
    'SecurityService',
    'PerformanceService'
]

