"""
Contract Export Service
API de Governança de Dados V3.0
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
Organização: F1rst
"""

import json
import yaml
import asyncio
import subprocess
import tempfile
import shutil
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Tuple
from pathlib import Path
from jinja2 import Template, Environment, FileSystemLoader
import logging

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_, desc, func
from sqlalchemy.orm import selectinload

from src.database.models.contract_export import ContractExport, ContractExportLog, ContractExportTemplate
from src.database.models.contracts import DataContract
from src.application.dtos.contract_export import (
    ContractExportRequest, ContractExportBatchRequest, ExportType, ExportFormat, 
    ExportStatus, ContractExportResponse, ExportStatisticsResponse
)

logger = logging.getLogger(__name__)


class GitService:
    """Serviço para operações Git"""
    
    def __init__(self, repository_url: str, username: Optional[str] = None, token: Optional[str] = None):
        self.repository_url = repository_url
        self.username = username
        self.token = token
        self.temp_dir = None
    
    async def clone_repository(self, branch: str = "main") -> str:
        """Clona repositório para diretório temporário"""
        try:
            self.temp_dir = tempfile.mkdtemp(prefix="contract_export_")
            
            # Construir comando git clone
            if self.username and self.token:
                # Usar autenticação por token
                auth_url = self.repository_url.replace("https://", f"https://{self.username}:{self.token}@")
                cmd = ["git", "clone", "-b", branch, auth_url, self.temp_dir]
            else:
                cmd = ["git", "clone", "-b", branch, self.repository_url, self.temp_dir]
            
            # Executar comando
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            if process.returncode != 0:
                raise Exception(f"Erro ao clonar repositório: {stderr.decode()}")
            
            logger.info(f"Repositório clonado com sucesso em {self.temp_dir}")
            return self.temp_dir
            
        except Exception as e:
            if self.temp_dir and Path(self.temp_dir).exists():
                shutil.rmtree(self.temp_dir)
            raise e
    
    async def write_file(self, file_path: str, content: str) -> str:
        """Escreve arquivo no repositório"""
        if not self.temp_dir:
            raise Exception("Repositório não foi clonado")
        
        full_path = Path(self.temp_dir) / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        logger.info(f"Arquivo escrito: {full_path}")
        return str(full_path)
    
    async def commit_and_push(self, commit_message: str, author_name: str, author_email: str) -> str:
        """Faz commit e push das mudanças"""
        if not self.temp_dir:
            raise Exception("Repositório não foi clonado")
        
        try:
            # Configurar git
            await self._run_git_command(["config", "user.name", author_name])
            await self._run_git_command(["config", "user.email", author_email])
            
            # Adicionar arquivos
            await self._run_git_command(["add", "."])
            
            # Verificar se há mudanças
            result = await self._run_git_command(["status", "--porcelain"])
            if not result.strip():
                logger.info("Nenhuma mudança para commit")
                return ""
            
            # Fazer commit
            await self._run_git_command(["commit", "-m", commit_message])
            
            # Fazer push
            await self._run_git_command(["push"])
            
            # Obter hash do commit
            commit_hash = await self._run_git_command(["rev-parse", "HEAD"])
            
            logger.info(f"Commit realizado com sucesso: {commit_hash.strip()}")
            return commit_hash.strip()
            
        except Exception as e:
            logger.error(f"Erro ao fazer commit/push: {e}")
            raise e
    
    async def _run_git_command(self, args: List[str]) -> str:
        """Executa comando git no diretório do repositório"""
        cmd = ["git"] + args
        
        process = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=self.temp_dir,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        
        if process.returncode != 0:
            raise Exception(f"Comando git falhou: {stderr.decode()}")
        
        return stdout.decode()
    
    def cleanup(self):
        """Limpa diretório temporário"""
        if self.temp_dir and Path(self.temp_dir).exists():
            shutil.rmtree(self.temp_dir)
            logger.info(f"Diretório temporário removido: {self.temp_dir}")


class ContractExportService:
    """Serviço para export de contratos"""
    
    def __init__(self, db_session: AsyncSession):
        self.db = db_session
        self.jinja_env = Environment(
            loader=FileSystemLoader('templates'),
            autoescape=True
        )
    
    async def create_export(self, request: ContractExportRequest, created_by: str) -> ContractExportResponse:
        """Cria um novo export de contrato"""
        try:
            # Verificar se contrato existe
            contract = await self._get_contract(request.contract_id)
            if not contract:
                raise ValueError(f"Contrato {request.contract_id} não encontrado")
            
            # Criar registro de export
            export = ContractExport(
                contract_id=request.contract_id,
                export_type=request.export_type.value,
                export_format=request.export_format.value,
                export_version=contract.version,
                export_status=ExportStatus.PENDING.value,
                git_repository=request.git_repository,
                git_branch=request.git_branch,
                git_commit_message=request.git_commit_message,
                export_metadata=request.export_metadata,
                created_by=created_by
            )
            
            self.db.add(export)
            await self.db.commit()
            await self.db.refresh(export)
            
            # Log inicial
            await self._add_log(export.id, "INFO", "Export criado com sucesso", {"request": request.dict()})
            
            # Processar export em background
            asyncio.create_task(self._process_export(export.id))
            
            return ContractExportResponse.from_orm(export)
            
        except Exception as e:
            logger.error(f"Erro ao criar export: {e}")
            raise e
    
    async def create_batch_export(self, request: ContractExportBatchRequest, created_by: str) -> List[ContractExportResponse]:
        """Cria exports em lote"""
        exports = []
        
        try:
            for contract_id in request.contract_ids:
                export_request = ContractExportRequest(
                    contract_id=contract_id,
                    export_type=request.export_type,
                    export_format=request.export_format,
                    git_repository=request.git_repository,
                    git_branch=request.git_branch,
                    git_commit_message=request.git_commit_message
                )
                
                export = await self.create_export(export_request, created_by)
                exports.append(export)
            
            return exports
            
        except Exception as e:
            logger.error(f"Erro ao criar exports em lote: {e}")
            raise e
    
    async def get_export(self, export_id: int) -> Optional[ContractExportResponse]:
        """Obtém export por ID"""
        try:
            query = select(ContractExport).where(ContractExport.id == export_id)
            result = await self.db.execute(query)
            export = result.scalar_one_or_none()
            
            if export:
                return ContractExportResponse.from_orm(export)
            return None
            
        except Exception as e:
            logger.error(f"Erro ao obter export {export_id}: {e}")
            raise e
    
    async def list_exports(self, contract_id: Optional[int] = None, status: Optional[ExportStatus] = None, 
                          page: int = 1, size: int = 20) -> Tuple[List[ContractExportResponse], int]:
        """Lista exports com filtros"""
        try:
            query = select(ContractExport)
            
            # Aplicar filtros
            if contract_id:
                query = query.where(ContractExport.contract_id == contract_id)
            if status:
                query = query.where(ContractExport.export_status == status.value)
            
            # Contar total
            count_query = select(func.count(ContractExport.id))
            if contract_id:
                count_query = count_query.where(ContractExport.contract_id == contract_id)
            if status:
                count_query = count_query.where(ContractExport.export_status == status.value)
            
            total_result = await self.db.execute(count_query)
            total = total_result.scalar()
            
            # Aplicar paginação
            query = query.order_by(desc(ContractExport.created_at))
            query = query.offset((page - 1) * size).limit(size)
            
            result = await self.db.execute(query)
            exports = result.scalars().all()
            
            export_responses = [ContractExportResponse.from_orm(export) for export in exports]
            
            return export_responses, total
            
        except Exception as e:
            logger.error(f"Erro ao listar exports: {e}")
            raise e
    
    async def retry_export(self, export_id: int) -> ContractExportResponse:
        """Tenta novamente um export que falhou"""
        try:
            export = await self._get_export_model(export_id)
            if not export:
                raise ValueError(f"Export {export_id} não encontrado")
            
            if not export.can_retry():
                raise ValueError(f"Export {export_id} não pode ser tentado novamente")
            
            # Resetar status
            export.export_status = ExportStatus.PENDING.value
            export.error_message = None
            export.updated_at = datetime.utcnow()
            
            await self.db.commit()
            
            # Log
            await self._add_log(export.id, "INFO", "Retry iniciado", {"retry_count": export.retry_count})
            
            # Processar novamente
            asyncio.create_task(self._process_export(export.id))
            
            return ContractExportResponse.from_orm(export)
            
        except Exception as e:
            logger.error(f"Erro ao tentar novamente export {export_id}: {e}")
            raise e
    
    async def cancel_export(self, export_id: int) -> ContractExportResponse:
        """Cancela um export"""
        try:
            export = await self._get_export_model(export_id)
            if not export:
                raise ValueError(f"Export {export_id} não encontrado")
            
            if export.export_status not in [ExportStatus.PENDING.value, "in_progress"]:
                raise ValueError(f"Export {export_id} não pode ser cancelado")
            
            export.export_status = ExportStatus.CANCELLED.value
            export.updated_at = datetime.utcnow()
            
            await self.db.commit()
            
            await self._add_log(export.id, "INFO", "Export cancelado")
            
            return ContractExportResponse.from_orm(export)
            
        except Exception as e:
            logger.error(f"Erro ao cancelar export {export_id}: {e}")
            raise e
    
    async def get_export_statistics(self) -> ExportStatisticsResponse:
        """Obtém estatísticas de exports"""
        try:
            # Total de exports
            total_query = select(func.count(ContractExport.id))
            total_result = await self.db.execute(total_query)
            total_exports = total_result.scalar()
            
            # Por status
            success_query = select(func.count(ContractExport.id)).where(
                ContractExport.export_status == ExportStatus.SUCCESS.value
            )
            success_result = await self.db.execute(success_query)
            successful_exports = success_result.scalar()
            
            failed_query = select(func.count(ContractExport.id)).where(
                ContractExport.export_status == ExportStatus.FAILED.value
            )
            failed_result = await self.db.execute(failed_query)
            failed_exports = failed_result.scalar()
            
            pending_query = select(func.count(ContractExport.id)).where(
                ContractExport.export_status == ExportStatus.PENDING.value
            )
            pending_result = await self.db.execute(pending_query)
            pending_exports = pending_result.scalar()
            
            # Calcular taxa de sucesso
            success_rate = (successful_exports / total_exports * 100) if total_exports > 0 else 0
            
            return ExportStatisticsResponse(
                total_exports=total_exports,
                successful_exports=successful_exports,
                failed_exports=failed_exports,
                pending_exports=pending_exports,
                success_rate_percentage=round(success_rate, 2)
            )
            
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas: {e}")
            raise e
    
    async def _process_export(self, export_id: int):
        """Processa export em background"""
        export = None
        git_service = None
        
        try:
            # Obter export
            export = await self._get_export_model(export_id)
            if not export:
                return
            
            # Atualizar status
            export.export_status = "in_progress"
            await self.db.commit()
            
            await self._add_log(export.id, "INFO", "Iniciando processamento do export")
            
            # Obter contrato
            contract = await self._get_contract(export.contract_id)
            if not contract:
                raise Exception("Contrato não encontrado")
            
            # Gerar conteúdo do export
            content = await self._generate_export_content(contract, export.export_format)
            
            # Processar baseado no tipo
            if export.export_type == ExportType.GIT.value:
                # Export para Git
                if not export.git_repository:
                    raise Exception("Repositório Git não especificado")
                
                git_service = GitService(export.git_repository)
                
                # Clonar repositório
                await git_service.clone_repository(export.git_branch or "main")
                
                # Determinar caminho do arquivo
                file_path = self._get_export_file_path(contract, export.export_format)
                
                # Escrever arquivo
                await git_service.write_file(file_path, content)
                
                # Commit e push
                commit_hash = await git_service.commit_and_push(
                    export.git_commit_message or f"Export contract {contract.name} v{contract.version}",
                    export.created_by,
                    f"{export.created_by}@f1rst.com.br"
                )
                
                # Atualizar export
                export.export_commit_hash = commit_hash
                export.export_path = file_path
                export.export_url = f"{export.git_repository}/blob/{export.git_branch}/{file_path}"
                
            else:
                # Export local (JSON, YAML, etc.)
                file_path = f"exports/contract_{contract.id}_{export.export_version}.{export.export_format}"
                export.export_path = file_path
            
            # Marcar como sucesso
            export.mark_as_success(export.export_commit_hash)
            await self.db.commit()
            
            await self._add_log(export.id, "INFO", "Export concluído com sucesso", {
                "file_path": export.export_path,
                "commit_hash": export.export_commit_hash
            })
            
        except Exception as e:
            logger.error(f"Erro ao processar export {export_id}: {e}")
            
            if export:
                export.mark_as_failed(str(e))
                await self.db.commit()
                
                await self._add_log(export.id, "ERROR", f"Export falhou: {str(e)}")
        
        finally:
            if git_service:
                git_service.cleanup()
    
    async def _generate_export_content(self, contract: DataContract, export_format: str) -> str:
        """Gera conteúdo do export baseado no formato"""
        try:
            # Preparar dados do contrato
            contract_data = {
                "id": contract.id,
                "name": contract.name,
                "description": contract.description,
                "version": contract.version,
                "status": contract.status.value if contract.status else None,
                "schema_definition": contract.schema_definition,
                "sla_definition": contract.sla_definition,
                "quality_requirements": contract.quality_requirements,
                "data_classification": contract.data_classification,
                "domain": contract.domain,
                "tags": contract.tags,
                "effective_date": contract.effective_date.isoformat() if contract.effective_date else None,
                "expiration_date": contract.expiration_date.isoformat() if contract.expiration_date else None,
                "created_at": contract.created_at.isoformat() if contract.created_at else None,
                "updated_at": contract.updated_at.isoformat() if contract.updated_at else None
            }
            
            # Gerar conteúdo baseado no formato
            if export_format == ExportFormat.JSON.value:
                return json.dumps(contract_data, indent=2, ensure_ascii=False)
            
            elif export_format == ExportFormat.YAML.value:
                return yaml.dump(contract_data, default_flow_style=False, allow_unicode=True)
            
            elif export_format == ExportFormat.SQL.value:
                return self._generate_sql_content(contract_data)
            
            else:
                raise ValueError(f"Formato de export não suportado: {export_format}")
                
        except Exception as e:
            logger.error(f"Erro ao gerar conteúdo do export: {e}")
            raise e
    
    def _generate_sql_content(self, contract_data: Dict[str, Any]) -> str:
        """Gera conteúdo SQL para o contrato"""
        sql_lines = [
            "-- Contract Export SQL",
            f"-- Generated at: {datetime.utcnow().isoformat()}",
            "",
            f"-- Contract: {contract_data['name']} v{contract_data['version']}",
            f"-- Description: {contract_data['description']}",
            "",
            "-- Schema Definition",
        ]
        
        if contract_data.get('schema_definition'):
            sql_lines.append("/*")
            sql_lines.append(json.dumps(contract_data['schema_definition'], indent=2))
            sql_lines.append("*/")
        
        return "\n".join(sql_lines)
    
    def _get_export_file_path(self, contract: DataContract, export_format: str) -> str:
        """Determina caminho do arquivo no repositório"""
        domain = contract.domain or "default"
        filename = f"{contract.name}_v{contract.version}.{export_format}"
        return f"contracts/{domain}/{filename}"
    
    async def _get_contract(self, contract_id: int) -> Optional[DataContract]:
        """Obtém contrato por ID"""
        query = select(DataContract).where(DataContract.id == contract_id)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def _get_export_model(self, export_id: int) -> Optional[ContractExport]:
        """Obtém modelo de export por ID"""
        query = select(ContractExport).where(ContractExport.id == export_id)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()
    
    async def _add_log(self, export_id: int, level: str, message: str, details: Optional[Dict[str, Any]] = None):
        """Adiciona log ao export"""
        try:
            log = ContractExportLog(
                export_id=export_id,
                log_level=level,
                log_message=message,
                log_details=details
            )
            
            self.db.add(log)
            await self.db.commit()
            
        except Exception as e:
            logger.error(f"Erro ao adicionar log: {e}")

