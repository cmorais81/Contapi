from typing import TypeVar
"""
DTOs para Notificações
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Union
from uuid import UUID

from pydantic import BaseModel, Field


class NotificationType(str, Enum):
    """Tipo de notificação"""
    WORKFLOW_APPROVAL = "workflow_approval"
    QUALITY_ALERT = "quality_alert"
    POLICY_VIOLATION = "policy_violation"
    DATA_ACCESS_REQUEST = "data_access_request"
    CONTRACT_EXPIRATION = "contract_expiration"
    STEWARD_ASSIGNMENT = "steward_assignment"
    SYSTEM_MAINTENANCE = "system_maintenance"
    COMPLIANCE_REMINDER = "compliance_reminder"
    CUSTOM = "custom"


class NotificationChannel(str, Enum):
    """Canal de notificação"""
    EMAIL = "email"
    SLACK = "slack"
    TEAMS = "teams"
    WEBHOOK = "webhook"
    IN_APP = "in_app"
    SMS = "sms"
    PUSH = "push"


class NotificationPriority(str, Enum):
    """Prioridade da notificação"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


class NotificationStatus(str, Enum):
    """Status da notificação"""
    PENDING = "pending"
    SENT = "sent"
    DELIVERED = "delivered"
    READ = "read"
    FAILED = "failed"
    CANCELLED = "cancelled"


class NotificationCreateDTO(BaseModel):
    """DTO para criação de notificação"""
    type: NotificationType
    title: str = Field(..., min_length=1, max_length=255)
    message: str = Field(..., min_length=1, max_length=2000)
    priority: NotificationPriority = NotificationPriority.MEDIUM
    channels: List[NotificationChannel] = Field(min_items=1)
    recipients: List[str] = Field(min_items=1)  # emails, user_ids, etc.
    context_data: Dict = Field(default_factory=dict)
    scheduled_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None
    action_url: Optional[str] = None
    action_text: Optional[str] = None
    template_id: Optional[UUID] = None
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_json_schema_extra = {
            "example": {
                "type": "workflow_approval",
                "title": "Data Access Request Pending Approval",
                "message": "A new data access request requires your approval",
                "priority": "high",
                "channels": ["email", "in_app"],
                "recipients": ["john.steward@company.com", "data-team@company.com"],
                "context_data": {
                    "workflow_id": "123e4567-e89b-12d3-a456-426614174000",
                    "requester": "jane.analyst@company.com",
                    "entity_name": "Customer Database"
                },
                "scheduled_at": "2025-01-15T09:00:00Z",
                "action_url": "/workflows/123e4567-e89b-12d3-a456-426614174000",
                "action_text": "Review Request",
                "metadata": {"department": "data_governance"}
            }
        }


class NotificationResponseDTO(BaseModel):
    """DTO para resposta de notificação"""
    id: UUID
    type: NotificationType
    title: str
    message: str
    priority: NotificationPriority
    status: NotificationStatus
    channels: List[NotificationChannel]
    recipients: List[str]
    context_data: Dict
    scheduled_at: Optional[datetime]
    sent_at: Optional[datetime]
    delivered_at: Optional[datetime]
    read_at: Optional[datetime]
    expires_at: Optional[datetime]
    action_url: Optional[str]
    action_text: Optional[str]
    template_id: Optional[UUID]
    created_by: UUID
    created_at: datetime
    updated_at: datetime
    metadata: Dict

    class Config:
        from_attributes = True


class NotificationTemplateDTO(BaseModel):
    """DTO para template de notificação"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str
    type: NotificationType
    title_template: str = Field(..., min_length=1, max_length=255)
    message_template: str = Field(..., min_length=1, max_length=2000)
    default_priority: NotificationPriority = NotificationPriority.MEDIUM
    default_channels: List[NotificationChannel] = Field(min_items=1)
    variables: List[str] = Field(default_factory=list)
    is_active: bool = Field(default=True)
    is_system_template: bool = Field(default=False)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_json_schema_extra = {
            "example": {
                "name": "Workflow Approval Template",
                "description": "Template for workflow approval notifications",
                "type": "workflow_approval",
                "title_template": "{{workflow_type}} Pending Approval",
                "message_template": "A {{workflow_type}} from {{requester}} requires your approval. Entity: {{entity_name}}",
                "default_priority": "high",
                "default_channels": ["email", "in_app"],
                "variables": ["workflow_type", "requester", "entity_name"],
                "is_active": True,
                "is_system_template": True,
                "metadata": {"category": "workflow"}
            }
        }


class NotificationPreferenceDTO(BaseModel):
    """DTO para preferências de notificação"""
    user_id: UUID
    notification_type: NotificationType
    enabled_channels: List[NotificationChannel] = Field(default_factory=list)
    minimum_priority: NotificationPriority = NotificationPriority.LOW
    quiet_hours_start: Optional[str] = Field(None, pattern=r'^([01]?[0-9]|2[0-3]):[0-5][0-9]$')
    quiet_hours_end: Optional[str] = Field(None, pattern=r'^([01]?[0-9]|2[0-3]):[0-5][0-9]$')
    timezone: str = Field(default="UTC")
    frequency_limit: Optional[int] = Field(None, ge=1)  # max notifications per hour
    digest_enabled: bool = Field(default=False)
    digest_frequency: str = Field(default="daily")  # hourly, daily, weekly

    class Config:
        json_json_schema_extra = {
            "example": {
                "user_id": "123e4567-e89b-12d3-a456-426614174000",
                "notification_type": "workflow_approval",
                "enabled_channels": ["email", "slack"],
                "minimum_priority": "medium",
                "quiet_hours_start": "22:00",
                "quiet_hours_end": "08:00",
                "timezone": "America/Sao_Paulo",
                "frequency_limit": 10,
                "digest_enabled": True,
                "digest_frequency": "daily"
            }
        }


class NotificationRuleDTO(BaseModel):
    """DTO para regra de notificação"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str
    event_type: str  # workflow_created, quality_threshold_exceeded, etc.
    conditions: Dict = Field(default_factory=dict)
    notification_template_id: UUID
    target_roles: List[str] = Field(default_factory=list)
    target_users: List[UUID] = Field(default_factory=list)
    is_active: bool = Field(default=True)
    priority_override: Optional[NotificationPriority] = None
    channel_override: Optional[List[NotificationChannel]] = None
    delay_minutes: int = Field(default=0, ge=0)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_json_schema_extra = {
            "example": {
                "name": "Quality Alert Rule",
                "description": "Notify stewards when data quality drops below threshold",
                "event_type": "quality_threshold_exceeded",
                "conditions": {
                    "metric": "data_quality_score",
                    "operator": "<",
                    "threshold": 80,
                    "entity_types": ["table", "view"]
                },
                "notification_template_id": "456e7890-e89b-12d3-a456-426614174000",
                "target_roles": ["data_steward", "data_owner"],
                "target_users": [],
                "is_active": True,
                "priority_override": "high",
                "delay_minutes": 15,
                "metadata": {"escalation_enabled": True}
            }
        }


class NotificationDeliveryDTO(BaseModel):
    """DTO para entrega de notificação"""
    notification_id: UUID
    channel: NotificationChannel
    recipient: str
    status: NotificationStatus
    attempt_count: int = Field(default=0, ge=0)
    last_attempt_at: Optional[datetime] = None
    delivered_at: Optional[datetime] = None
    error_message: Optional[str] = None
    response_data: Dict = Field(default_factory=dict)

    class Config:
        from_attributes = True


class NotificationStatsDTO(BaseModel):
    """DTO para estatísticas de notificação"""
    total_notifications: int
    sent_notifications: int
    delivered_notifications: int
    read_notifications: int
    failed_notifications: int
    delivery_rate: float = Field(ge=0, le=1)
    read_rate: float = Field(ge=0, le=1)
    avg_delivery_time_seconds: float
    notifications_by_type: Dict[str, int] = Field(default_factory=dict)
    notifications_by_channel: Dict[str, int] = Field(default_factory=dict)
    notifications_by_priority: Dict[str, int] = Field(default_factory=dict)
    period_start: datetime
    period_end: datetime

    class Config:
        json_json_schema_extra = {
            "example": {
                "total_notifications": 1500,
                "sent_notifications": 1450,
                "delivered_notifications": 1380,
                "read_notifications": 950,
                "failed_notifications": 50,
                "delivery_rate": 0.95,
                "read_rate": 0.69,
                "avg_delivery_time_seconds": 2.5,
                "notifications_by_type": {
                    "workflow_approval": 600,
                    "quality_alert": 400,
                    "policy_violation": 200
                },
                "notifications_by_channel": {
                    "email": 800,
                    "in_app": 500,
                    "slack": 200
                },
                "notifications_by_priority": {
                    "high": 300,
                    "medium": 800,
                    "low": 400
                },
                "period_start": "2025-01-01T00:00:00Z",
                "period_end": "2025-01-14T23:59:59Z"
            }
        }


class BulkNotificationDTO(BaseModel):
    """DTO para notificação em lote"""
    notifications: List[NotificationCreateDTO] = Field(min_items=1, max_items=100)
    batch_name: Optional[str] = None
    send_immediately: bool = Field(default=True)

    class Config:
        json_json_schema_extra = {
            "example": {
                "notifications": [
                    {
                        "type": "system_maintenance",
                        "title": "Scheduled Maintenance",
                        "message": "System will be down for maintenance",
                        "priority": "high",
                        "channels": ["email"],
                        "recipients": ["all_users"]
                    }
                ],
                "batch_name": "Maintenance Notification Batch",
                "send_immediately": False
            }
        }


class BulkNotificationResultDTO(BaseModel):
    """DTO para resultado de notificação em lote"""
    batch_id: UUID
    total_notifications: int
    queued_notifications: int
    failed_notifications: int
    errors: List[Dict] = Field(default_factory=list)
    processing_time_ms: int

    class Config:
        json_json_schema_extra = {
            "example": {
                "batch_id": "123e4567-e89b-12d3-a456-426614174000",
                "total_notifications": 50,
                "queued_notifications": 48,
                "failed_notifications": 2,
                "errors": [
                    {"index": 5, "error": "Invalid recipient email"},
                    {"index": 12, "error": "Template not found"}
                ],
                "processing_time_ms": 1200
            }
        }


class NotificationDigestDTO(BaseModel):
    """DTO para digest de notificações"""
    user_id: UUID
    digest_type: str  # daily, weekly
    period_start: datetime
    period_end: datetime
    total_notifications: int
    unread_notifications: int
    notifications_by_type: Dict[str, int]
    high_priority_count: int
    digest_content: List[Dict] = Field(default_factory=list)
    generated_at: datetime

    class Config:
        json_json_schema_extra = {
            "example": {
                "user_id": "123e4567-e89b-12d3-a456-426614174000",
                "digest_type": "daily",
                "period_start": "2025-01-14T00:00:00Z",
                "period_end": "2025-01-14T23:59:59Z",
                "total_notifications": 15,
                "unread_notifications": 8,
                "notifications_by_type": {
                    "workflow_approval": 5,
                    "quality_alert": 3,
                    "policy_violation": 2
                },
                "high_priority_count": 3,
                "digest_content": [
                    {
                        "type": "workflow_approval",
                        "count": 5,
                        "latest_title": "Data Access Request Pending"
                    }
                ],
                "generated_at": "2025-01-15T08:00:00Z"
            }
        }

