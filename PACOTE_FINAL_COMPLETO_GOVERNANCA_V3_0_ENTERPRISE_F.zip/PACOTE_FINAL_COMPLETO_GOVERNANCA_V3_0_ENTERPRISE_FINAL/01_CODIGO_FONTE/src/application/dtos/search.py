"""
DTOs para Busca e Pesquisa
API de Governança de Dados V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field, ConfigDict


class SearchParams(BaseModel):
    """Parâmetros de busca genéricos"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "query": "customer data",
                "filters": {"type": "table", "schema": "sales"},
                "sort_by": "name",
                "sort_order": "asc",
                "include_metadata": True
            }
        }
    )
    
    query: Optional[str] = Field(None, description="Termo de busca")
    filters: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Filtros de busca")
    sort_by: Optional[str] = Field(default="name", description="Campo para ordenação")
    sort_order: Optional[str] = Field(default="asc", description="Ordem de classificação (asc/desc)")
    include_metadata: bool = Field(default=False, description="Incluir metadados na resposta")
    include_tags: bool = Field(default=True, description="Incluir tags na resposta")


class SearchFilters(BaseModel):
    """Filtros específicos para busca"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "entity_type": "table",
                "schema_name": "sales",
                "database_name": "production",
                "tags": ["pii", "customer"],
                "owner": "data_team",
                "created_after": "2025-01-01",
                "updated_after": "2025-07-01"
            }
        }
    )
    
    entity_type: Optional[str] = Field(None, description="Tipo de entidade")
    schema_name: Optional[str] = Field(None, description="Nome do schema")
    database_name: Optional[str] = Field(None, description="Nome do banco")
    tags: Optional[List[str]] = Field(None, description="Tags para filtrar")
    owner: Optional[str] = Field(None, description="Proprietário")
    steward: Optional[str] = Field(None, description="Steward")
    created_after: Optional[str] = Field(None, description="Criado após (YYYY-MM-DD)")
    created_before: Optional[str] = Field(None, description="Criado antes (YYYY-MM-DD)")
    updated_after: Optional[str] = Field(None, description="Atualizado após (YYYY-MM-DD)")
    updated_before: Optional[str] = Field(None, description="Atualizado antes (YYYY-MM-DD)")
    has_quality_rules: Optional[bool] = Field(None, description="Possui regras de qualidade")
    has_contracts: Optional[bool] = Field(None, description="Possui contratos")


class SearchResult(BaseModel):
    """Resultado individual de busca"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "type": "entity",
                "name": "customer_data",
                "description": "Dados de clientes",
                "score": 0.95,
                "highlights": ["customer", "data"],
                "metadata": {"schema": "sales", "type": "table"}
            }
        }
    )
    
    id: UUID = Field(..., description="ID do item")
    type: str = Field(..., description="Tipo do item (entity, contract, rule, etc.)")
    name: str = Field(..., description="Nome do item")
    description: Optional[str] = Field(None, description="Descrição do item")
    score: float = Field(..., description="Score de relevância (0-1)")
    highlights: List[str] = Field(default_factory=list, description="Termos destacados")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadados do item")
    tags: List[str] = Field(default_factory=list, description="Tags do item")


class SearchResponse(BaseModel):
    """Resposta de busca com resultados paginados"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "query": "customer data",
                "total_results": 150,
                "page": 1,
                "page_size": 20,
                "total_pages": 8,
                "results": [],
                "facets": {"type": {"table": 80, "view": 45, "procedure": 25}},
                "suggestions": ["customer_profile", "customer_orders"]
            }
        }
    )
    
    query: str = Field(..., description="Termo de busca utilizado")
    total_results: int = Field(..., description="Total de resultados encontrados")
    page: int = Field(..., description="Página atual")
    page_size: int = Field(..., description="Tamanho da página")
    total_pages: int = Field(..., description="Total de páginas")
    results: List[SearchResult] = Field(..., description="Resultados da busca")
    facets: Optional[Dict[str, Dict[str, int]]] = Field(None, description="Facetas para filtros")
    suggestions: Optional[List[str]] = Field(None, description="Sugestões de busca")
    execution_time_ms: Optional[float] = Field(None, description="Tempo de execução em ms")


class AdvancedSearchParams(BaseModel):
    """Parâmetros para busca avançada"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "query": "customer AND (email OR phone)",
                "search_type": "advanced",
                "boost_fields": {"name": 2.0, "description": 1.5},
                "min_score": 0.5,
                "explain": False
            }
        }
    )
    
    query: str = Field(..., description="Query de busca (suporta operadores AND, OR, NOT)")
    search_type: str = Field(default="simple", description="Tipo de busca (simple, advanced, fuzzy)")
    boost_fields: Optional[Dict[str, float]] = Field(None, description="Campos com boost de relevância")
    min_score: Optional[float] = Field(default=0.0, description="Score mínimo para resultados")
    fuzzy_distance: Optional[int] = Field(default=2, description="Distância para busca fuzzy")
    explain: bool = Field(default=False, description="Incluir explicação do score")
    highlight_fields: Optional[List[str]] = Field(None, description="Campos para destacar")


class AutocompleteParams(BaseModel):
    """Parâmetros para autocompletar"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "prefix": "cust",
                "field": "name",
                "limit": 10,
                "context": {"type": "entity"}
            }
        }
    )
    
    prefix: str = Field(..., description="Prefixo para autocompletar")
    field: str = Field(default="name", description="Campo para buscar")
    limit: int = Field(default=10, description="Limite de sugestões")
    context: Optional[Dict[str, Any]] = Field(None, description="Contexto para filtrar sugestões")


class AutocompleteResponse(BaseModel):
    """Resposta de autocompletar"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "prefix": "cust",
                "suggestions": [
                    {"text": "customer_data", "score": 0.95},
                    {"text": "customer_profile", "score": 0.90},
                    {"text": "customer_orders", "score": 0.85}
                ]
            }
        }
    )
    
    prefix: str = Field(..., description="Prefixo utilizado")
    suggestions: List[Dict[str, Any]] = Field(..., description="Lista de sugestões")


# Aliases para compatibilidade
SearchRequest = SearchParams
SearchFiltersRequest = SearchFilters
AdvancedSearchRequest = AdvancedSearchParams
AutocompleteRequest = AutocompleteParams

