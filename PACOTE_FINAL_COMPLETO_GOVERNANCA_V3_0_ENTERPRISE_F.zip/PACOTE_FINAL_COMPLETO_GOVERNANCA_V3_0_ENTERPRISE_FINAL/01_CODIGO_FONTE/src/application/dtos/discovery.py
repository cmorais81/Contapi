from typing import TypeVar
"""
DTOs para Descoberta e Catálogo
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Union
from uuid import UUID

from pydantic import BaseModel, Field


class SearchScope(str, Enum):
    """Escopo de busca"""
    ALL = "all"
    ENTITIES = "entities"
    ATTRIBUTES = "attributes"
    DOMAINS = "domains"
    CONTRACTS = "contracts"
    DOCUMENTATION = "documentation"


class SearchResultType(str, Enum):
    """Tipo de resultado de busca"""
    ENTITY = "entity"
    ATTRIBUTE = "attribute"
    DOMAIN = "domain"
    CONTRACT = "contract"
    DOCUMENTATION = "documentation"
    TAG = "tag"
    POLICY = "policy"


class RelevanceScore(str, Enum):
    """Score de relevância"""
    EXACT_MATCH = "exact_match"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class CatalogSearchDTO(BaseModel):
    """DTO para busca no catálogo"""
    query: str = Field(..., min_length=1, max_length=500)
    scope: SearchScope = SearchScope.ALL
    filters: Dict = Field(default_factory=dict)
    include_deprecated: bool = Field(default=False)
    include_draft: bool = Field(default=False)
    sort_by: str = Field(default="relevance")  # relevance, name, created_date, usage
    sort_order: str = Field(default="desc")  # asc, desc
    highlight: bool = Field(default=True)
    facets: List[str] = Field(default_factory=list)
    max_results: int = Field(default=50, ge=1, le=500)

    class Config:
        json_json_schema_extra = {
            "example": {
                "query": "customer data",
                "scope": "entities",
                "filters": {
                    "domain": "customer",
                    "classification": "confidential",
                    "has_steward": True
                },
                "include_deprecated": False,
                "sort_by": "relevance",
                "highlight": True,
                "facets": ["domain", "classification", "steward"],
                "max_results": 20
            }
        }


class SearchResultDTO(BaseModel):
    """DTO para resultado de busca"""
    id: UUID
    type: SearchResultType
    title: str
    description: Optional[str]
    relevance_score: float = Field(ge=0, le=1)
    relevance_level: RelevanceScore
    highlights: List[str] = Field(default_factory=list)
    metadata: Dict = Field(default_factory=dict)
    path: Optional[str] = None  # breadcrumb path
    tags: List[str] = Field(default_factory=list)
    last_updated: datetime
    usage_count: int = Field(default=0)
    quality_score: Optional[float] = None

    class Config:
        json_json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "type": "entity",
                "title": "Customer Data Table",
                "description": "Main table containing customer information",
                "relevance_score": 0.95,
                "relevance_level": "high",
                "highlights": [
                    "Customer <em>data</em> table with personal information",
                    "Contains <em>customer</em> demographics and preferences"
                ],
                "metadata": {
                    "domain": "Customer",
                    "steward": "john.doe@company.com",
                    "classification": "confidential"
                },
                "path": "Customer Domain > Core Tables > Customer Data",
                "tags": ["PII", "Core", "Active"],
                "last_updated": "2025-01-14T10:00:00Z",
                "usage_count": 1250,
                "quality_score": 87.5
            }
        }


class SearchFacetDTO(BaseModel):
    """DTO para faceta de busca"""
    name: str
    display_name: str
    values: List[Dict[str, Union[str, int]]]  # value, count
    total_count: int

    class Config:
        json_json_schema_extra = {
            "example": {
                "name": "domain",
                "display_name": "Domain",
                "values": [
                    {"value": "Customer", "count": 45},
                    {"value": "Product", "count": 32},
                    {"value": "Finance", "count": 28}
                ],
                "total_count": 105
            }
        }


class SearchResponseDTO(BaseModel):
    """DTO para resposta de busca"""
    query: str
    total_results: int
    execution_time_ms: int
    results: List[SearchResultDTO]
    facets: List[SearchFacetDTO] = Field(default_factory=list)
    suggestions: List[str] = Field(default_factory=list)
    related_searches: List[str] = Field(default_factory=list)

    class Config:
        json_json_schema_extra = {
            "example": {
                "query": "customer data",
                "total_results": 25,
                "execution_time_ms": 150,
                "results": [],
                "facets": [],
                "suggestions": ["customer information", "customer demographics"],
                "related_searches": ["customer table", "user data", "client information"]
            }
        }


class RecommendationDTO(BaseModel):
    """DTO para recomendação"""
    id: UUID
    type: str  # similar_entities, related_data, popular_in_domain
    title: str
    description: str
    target_id: UUID
    target_type: str
    confidence_score: float = Field(ge=0, le=1)
    reason: str
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "type": "similar_entities",
                "title": "Customer Demographics Table",
                "description": "Similar table with customer demographic information",
                "target_id": "456e7890-e89b-12d3-a456-426614174000",
                "target_type": "entity",
                "confidence_score": 0.85,
                "reason": "Similar schema and usage patterns",
                "metadata": {"similarity_factors": ["schema", "usage", "domain"]}
            }
        }


class CatalogStatsDTO(BaseModel):
    """DTO para estatísticas do catálogo"""
    total_entities: int
    total_attributes: int
    total_domains: int
    total_contracts: int
    documented_entities: int
    entities_with_stewards: int
    entities_with_quality_rules: int
    avg_quality_score: float
    documentation_coverage: float = Field(ge=0, le=100)
    stewardship_coverage: float = Field(ge=0, le=100)
    compliance_coverage: float = Field(ge=0, le=100)
    most_popular_domains: List[Dict] = Field(default_factory=list)
    recent_additions: List[Dict] = Field(default_factory=list)
    last_updated: datetime

    class Config:
        json_json_schema_extra = {
            "example": {
                "total_entities": 1250,
                "total_attributes": 8500,
                "total_domains": 25,
                "total_contracts": 180,
                "documented_entities": 950,
                "entities_with_stewards": 800,
                "entities_with_quality_rules": 600,
                "avg_quality_score": 82.5,
                "documentation_coverage": 76.0,
                "stewardship_coverage": 64.0,
                "compliance_coverage": 88.0,
                "most_popular_domains": [
                    {"name": "Customer", "entity_count": 250, "usage_count": 5000}
                ],
                "recent_additions": [
                    {"name": "New Product Table", "added_date": "2025-01-14"}
                ],
                "last_updated": "2025-01-14T10:00:00Z"
            }
        }


class DataDiscoveryRequestDTO(BaseModel):
    """DTO para solicitação de descoberta"""
    source_type: str  # database, file_system, api, cloud_storage
    connection_details: Dict
    discovery_scope: str = Field(default="full")  # full, incremental, sample
    include_data_profiling: bool = Field(default=True)
    include_schema_analysis: bool = Field(default=True)
    include_relationship_detection: bool = Field(default=True)
    sample_size: Optional[int] = Field(None, ge=100, le=1000000)
    filters: Dict = Field(default_factory=dict)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_json_schema_extra = {
            "example": {
                "source_type": "database",
                "connection_details": {
                    "host": "db.company.com",
                    "database": "production",
                    "schema": "sales"
                },
                "discovery_scope": "incremental",
                "include_data_profiling": True,
                "include_schema_analysis": True,
                "include_relationship_detection": True,
                "sample_size": 10000,
                "filters": {"table_pattern": "customer_*"},
                "metadata": {"environment": "production"}
            }
        }


class DiscoveryResultDTO(BaseModel):
    """DTO para resultado de descoberta"""
    discovery_id: UUID
    source_type: str
    status: str  # running, completed, failed, cancelled
    progress_percentage: float = Field(ge=0, le=100)
    discovered_entities: int
    discovered_attributes: int
    discovered_relationships: int
    quality_issues_found: int
    start_time: datetime
    end_time: Optional[datetime] = None
    execution_time_ms: Optional[int] = None
    summary: Dict = Field(default_factory=dict)
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)

    class Config:
        json_json_schema_extra = {
            "example": {
                "discovery_id": "123e4567-e89b-12d3-a456-426614174000",
                "source_type": "database",
                "status": "completed",
                "progress_percentage": 100.0,
                "discovered_entities": 45,
                "discovered_attributes": 320,
                "discovered_relationships": 28,
                "quality_issues_found": 12,
                "start_time": "2025-01-14T09:00:00Z",
                "end_time": "2025-01-14T09:15:00Z",
                "execution_time_ms": 900000,
                "summary": {
                    "tables_analyzed": 45,
                    "data_types_detected": 15,
                    "pii_columns_found": 8
                },
                "errors": [],
                "warnings": ["Some tables had no data for profiling"]
            }
        }


class PopularContentDTO(BaseModel):
    """DTO para conteúdo popular"""
    id: UUID
    type: str
    name: str
    description: Optional[str]
    usage_count: int
    unique_users: int
    trend: str  # increasing, decreasing, stable
    domain: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    last_accessed: datetime

    class Config:
        json_json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "type": "entity",
                "name": "Customer Master Table",
                "description": "Primary customer data repository",
                "usage_count": 2500,
                "unique_users": 85,
                "trend": "increasing",
                "domain": "Customer",
                "tags": ["Core", "Master Data"],
                "last_accessed": "2025-01-14T09:30:00Z"
            }
        }


class SimilarContentDTO(BaseModel):
    """DTO para conteúdo similar"""
    id: UUID
    name: str
    type: str
    similarity_score: float = Field(ge=0, le=1)
    similarity_factors: List[str]
    description: Optional[str] = None
    domain: Optional[str] = None

    class Config:
        json_json_schema_extra = {
            "example": {
                "id": "456e7890-e89b-12d3-a456-426614174000",
                "name": "Customer Demographics",
                "type": "entity",
                "similarity_score": 0.85,
                "similarity_factors": ["schema_structure", "data_patterns", "usage_context"],
                "description": "Customer demographic and preference data",
                "domain": "Customer"
            }
        }


class BrowseNodeDTO(BaseModel):
    """DTO para nó de navegação"""
    id: UUID
    name: str
    type: str  # domain, folder, entity, attribute
    path: str
    children_count: int
    has_children: bool
    metadata: Dict = Field(default_factory=dict)
    icon: Optional[str] = None

    class Config:
        json_json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "name": "Customer Domain",
                "type": "domain",
                "path": "/Customer Domain",
                "children_count": 15,
                "has_children": True,
                "metadata": {
                    "entity_count": 15,
                    "steward": "john.doe@company.com"
                },
                "icon": "domain"
            }
        }


class BrowseResponseDTO(BaseModel):
    """DTO para resposta de navegação"""
    current_path: str
    parent_node: Optional[BrowseNodeDTO] = None
    children: List[BrowseNodeDTO]
    breadcrumbs: List[Dict[str, str]] = Field(default_factory=list)
    total_children: int
    filters_applied: Dict = Field(default_factory=dict)

    class Config:
        json_json_schema_extra = {
            "example": {
                "current_path": "/Customer Domain",
                "parent_node": None,
                "children": [],
                "breadcrumbs": [
                    {"name": "Root", "path": "/"},
                    {"name": "Customer Domain", "path": "/Customer Domain"}
                ],
                "total_children": 15,
                "filters_applied": {}
            }
        }

