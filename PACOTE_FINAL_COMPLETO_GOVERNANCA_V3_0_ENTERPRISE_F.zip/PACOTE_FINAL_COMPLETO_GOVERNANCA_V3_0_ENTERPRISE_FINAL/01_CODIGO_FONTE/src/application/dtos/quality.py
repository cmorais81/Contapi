"""
DTOs para Qualidade de Dados
API de Governança de Dados V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field, ConfigDict


class QualityRuleCreateDTO(BaseModel):
    """DTO para criação de regra de qualidade"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "name": "email_format_validation",
                "description": "Validação de formato de email",
                "rule_type": "format",
                "entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "column_name": "email",
                "rule_expression": "REGEXP_LIKE(email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$')",
                "severity": "high",
                "threshold": 95.0
            }
        }
    )
    
    name: str = Field(..., description="Nome da regra")
    description: Optional[str] = Field(None, description="Descrição da regra")
    rule_type: str = Field(..., description="Tipo da regra (format, range, null, etc.)")
    entity_id: UUID = Field(..., description="ID da entidade")
    column_name: Optional[str] = Field(None, description="Nome da coluna")
    rule_expression: str = Field(..., description="Expressão da regra")
    severity: str = Field(..., description="Severidade (low, medium, high, critical)")
    threshold: Optional[float] = Field(None, description="Limite de qualidade (%)")
    is_active: bool = Field(default=True, description="Regra ativa")


class QualityRuleUpdateDTO(BaseModel):
    """DTO para atualização de regra de qualidade"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "description": "Validação de formato de email atualizada",
                "threshold": 98.0,
                "is_active": True
            }
        }
    )
    
    description: Optional[str] = Field(None, description="Descrição da regra")
    rule_expression: Optional[str] = Field(None, description="Expressão da regra")
    severity: Optional[str] = Field(None, description="Severidade")
    threshold: Optional[float] = Field(None, description="Limite de qualidade (%)")
    is_active: Optional[bool] = Field(None, description="Regra ativa")


class QualityRuleResponseDTO(BaseModel):
    """DTO para resposta de regra de qualidade"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "name": "email_format_validation",
                "description": "Validação de formato de email",
                "rule_type": "format",
                "entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "column_name": "email",
                "rule_expression": "REGEXP_LIKE(email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$')",
                "severity": "high",
                "threshold": 95.0,
                "is_active": True,
                "created_at": "2025-07-17T23:36:17Z",
                "updated_at": "2025-07-17T23:36:17Z"
            }
        }
    )
    
    id: UUID = Field(..., description="ID único da regra")
    name: str = Field(..., description="Nome da regra")
    description: Optional[str] = Field(None, description="Descrição da regra")
    rule_type: str = Field(..., description="Tipo da regra")
    entity_id: UUID = Field(..., description="ID da entidade")
    column_name: Optional[str] = Field(None, description="Nome da coluna")
    rule_expression: str = Field(..., description="Expressão da regra")
    severity: str = Field(..., description="Severidade")
    threshold: Optional[float] = Field(None, description="Limite de qualidade (%)")
    is_active: bool = Field(..., description="Regra ativa")
    created_at: datetime = Field(..., description="Data de criação")
    updated_at: datetime = Field(..., description="Data de atualização")


class QualityMetricCreateDTO(BaseModel):
    """DTO para criação de métrica de qualidade"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "rule_id": "123e4567-e89b-12d3-a456-426614174000",
                "metric_value": 97.5,
                "total_records": 10000,
                "valid_records": 9750,
                "invalid_records": 250
            }
        }
    )
    
    rule_id: UUID = Field(..., description="ID da regra")
    metric_value: float = Field(..., description="Valor da métrica (%)")
    total_records: int = Field(..., description="Total de registros")
    valid_records: int = Field(..., description="Registros válidos")
    invalid_records: int = Field(..., description="Registros inválidos")
    execution_time: Optional[float] = Field(None, description="Tempo de execução (ms)")


class QualityMetricResponseDTO(BaseModel):
    """DTO para resposta de métrica de qualidade"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "rule_id": "123e4567-e89b-12d3-a456-426614174000",
                "metric_value": 97.5,
                "total_records": 10000,
                "valid_records": 9750,
                "invalid_records": 250,
                "execution_time": 1250.5,
                "measured_at": "2025-07-17T23:36:17Z"
            }
        }
    )
    
    id: UUID = Field(..., description="ID único da métrica")
    rule_id: UUID = Field(..., description="ID da regra")
    metric_value: float = Field(..., description="Valor da métrica (%)")
    total_records: int = Field(..., description="Total de registros")
    valid_records: int = Field(..., description="Registros válidos")
    invalid_records: int = Field(..., description="Registros inválidos")
    execution_time: Optional[float] = Field(None, description="Tempo de execução (ms)")
    measured_at: datetime = Field(..., description="Data da medição")


class QualityReportDTO(BaseModel):
    """DTO para relatório de qualidade"""
    model_config = ConfigDict(
        json_json_schema_extra={
            "example": {
                "entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "overall_score": 94.2,
                "total_rules": 15,
                "passed_rules": 12,
                "failed_rules": 3,
                "critical_issues": 1,
                "high_issues": 2,
                "medium_issues": 5,
                "low_issues": 8
            }
        }
    )
    
    entity_id: UUID = Field(..., description="ID da entidade")
    overall_score: float = Field(..., description="Score geral de qualidade (%)")
    total_rules: int = Field(..., description="Total de regras")
    passed_rules: int = Field(..., description="Regras aprovadas")
    failed_rules: int = Field(..., description="Regras falharam")
    critical_issues: int = Field(..., description="Problemas críticos")
    high_issues: int = Field(..., description="Problemas altos")
    medium_issues: int = Field(..., description="Problemas médios")
    low_issues: int = Field(..., description="Problemas baixos")
    generated_at: datetime = Field(default_factory=datetime.utcnow, description="Data do relatório")


# Aliases para compatibilidade
QualityRuleCreateRequest = QualityRuleCreateDTO
QualityRuleUpdateRequest = QualityRuleUpdateDTO
QualityRuleResponse = QualityRuleResponseDTO
QualityMetricCreateRequest = QualityMetricCreateDTO
QualityMetricResponse = QualityMetricResponseDTO
QualityReport = QualityReportDTO

