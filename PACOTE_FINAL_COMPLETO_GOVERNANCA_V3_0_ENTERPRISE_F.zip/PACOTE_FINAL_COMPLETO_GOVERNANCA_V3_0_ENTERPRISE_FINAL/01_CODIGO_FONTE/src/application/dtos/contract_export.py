"""
DTOs para Contract Export
API de Governança de Dados V3.0
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
Organização: F1rst
"""

from datetime import datetime
from typing import Optional, Dict, Any, List
from pydantic import BaseModel, Field, validator
from enum import Enum


class ExportType(str, Enum):
    """Tipos de export disponíveis"""
    GIT = "git"
    JSON = "json"
    YAML = "yaml"
    CI_CD = "ci_cd"
    BACKUP = "backup"


class ExportFormat(str, Enum):
    """Formatos de export disponíveis"""
    JSON = "json"
    YAML = "yaml"
    SQL = "sql"
    CSV = "csv"
    PARQUET = "parquet"


class ExportStatus(str, Enum):
    """Status do export"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"


class PipelineStatus(str, Enum):
    """Status do pipeline CI/CD"""
    QUEUED = "queued"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    SKIPPED = "skipped"


# Request DTOs
class ContractExportRequest(BaseModel):
    """Request para criar um export de contrato"""
    contract_id: int = Field(..., description="ID do contrato a ser exportado")
    export_type: ExportType = Field(..., description="Tipo de export")
    export_format: ExportFormat = Field(..., description="Formato do export")
    
    # Configurações Git (opcional)
    git_repository: Optional[str] = Field(None, description="Nome do repositório Git")
    git_branch: Optional[str] = Field("main", description="Branch do Git")
    git_commit_message: Optional[str] = Field(None, description="Mensagem do commit")
    
    # Configurações CI/CD (opcional)
    trigger_pipeline: bool = Field(False, description="Se deve disparar pipeline CI/CD")
    pipeline_config: Optional[Dict[str, Any]] = Field(None, description="Configurações do pipeline")
    
    # Metadados adicionais
    export_metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados adicionais")
    
    @validator('git_commit_message')
    def validate_commit_message(cls, v, values):
        if values.get('export_type') == ExportType.GIT and not v:
            return f"Export contract {values.get('contract_id')} - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        return v


class ContractExportBatchRequest(BaseModel):
    """Request para export em lote de contratos"""
    contract_ids: List[int] = Field(..., description="IDs dos contratos a serem exportados")
    export_type: ExportType = Field(..., description="Tipo de export")
    export_format: ExportFormat = Field(..., description="Formato do export")
    
    # Configurações Git (opcional)
    git_repository: Optional[str] = Field(None, description="Nome do repositório Git")
    git_branch: Optional[str] = Field("main", description="Branch do Git")
    git_commit_message: Optional[str] = Field(None, description="Mensagem do commit")
    
    # Configurações de processamento
    parallel_processing: bool = Field(True, description="Processamento paralelo")
    max_concurrent_exports: int = Field(5, description="Máximo de exports simultâneos")
    
    @validator('contract_ids')
    def validate_contract_ids(cls, v):
        if not v:
            raise ValueError("Lista de contract_ids não pode estar vazia")
        if len(v) > 100:
            raise ValueError("Máximo de 100 contratos por lote")
        return v


class GitConfigRequest(BaseModel):
    """Configurações específicas para Git"""
    repository_url: str = Field(..., description="URL do repositório")
    branch: str = Field("main", description="Branch")
    username: Optional[str] = Field(None, description="Usuário Git")
    token: Optional[str] = Field(None, description="Token de acesso")
    ssh_key: Optional[str] = Field(None, description="Chave SSH")
    
    # Estrutura do repositório
    base_path: str = Field("contracts", description="Caminho base no repositório")
    folder_structure: str = Field("domain/{domain}/contracts", description="Estrutura de pastas")
    
    @validator('repository_url')
    def validate_repository_url(cls, v):
        if not v.startswith(('https://', 'git@', 'ssh://')):
            raise ValueError("URL do repositório deve começar com https://, git@ ou ssh://")
        return v


# Response DTOs
class ContractExportResponse(BaseModel):
    """Response de um export de contrato"""
    id: int = Field(..., description="ID do export")
    contract_id: int = Field(..., description="ID do contrato")
    export_type: ExportType = Field(..., description="Tipo de export")
    export_format: ExportFormat = Field(..., description="Formato do export")
    export_version: str = Field(..., description="Versão do export")
    export_status: ExportStatus = Field(..., description="Status do export")
    
    # Informações do resultado
    export_path: Optional[str] = Field(None, description="Caminho do arquivo exportado")
    export_url: Optional[str] = Field(None, description="URL do export")
    export_commit_hash: Optional[str] = Field(None, description="Hash do commit Git")
    
    # Informações Git
    git_repository: Optional[str] = Field(None, description="Repositório Git")
    git_branch: Optional[str] = Field(None, description="Branch Git")
    git_commit_message: Optional[str] = Field(None, description="Mensagem do commit")
    git_author: Optional[str] = Field(None, description="Autor do commit")
    
    # Informações CI/CD
    pipeline_id: Optional[str] = Field(None, description="ID do pipeline")
    pipeline_status: Optional[PipelineStatus] = Field(None, description="Status do pipeline")
    pipeline_url: Optional[str] = Field(None, description="URL do pipeline")
    
    # Metadados
    error_message: Optional[str] = Field(None, description="Mensagem de erro")
    retry_count: int = Field(0, description="Número de tentativas")
    
    # Auditoria
    created_by: str = Field(..., description="Criado por")
    created_at: datetime = Field(..., description="Data de criação")
    updated_at: Optional[datetime] = Field(None, description="Data de atualização")
    exported_at: Optional[datetime] = Field(None, description="Data de export bem-sucedido")
    
    class Config:
        from_attributes = True


class ContractExportListResponse(BaseModel):
    """Response para lista de exports"""
    exports: List[ContractExportResponse] = Field(..., description="Lista de exports")
    total: int = Field(..., description="Total de exports")
    page: int = Field(..., description="Página atual")
    size: int = Field(..., description="Tamanho da página")
    pages: int = Field(..., description="Total de páginas")


class ContractExportLogResponse(BaseModel):
    """Response de log de export"""
    id: int = Field(..., description="ID do log")
    export_id: int = Field(..., description="ID do export")
    log_level: str = Field(..., description="Nível do log")
    log_message: str = Field(..., description="Mensagem do log")
    log_details: Optional[Dict[str, Any]] = Field(None, description="Detalhes do log")
    operation: Optional[str] = Field(None, description="Operação")
    step: Optional[str] = Field(None, description="Passo")
    duration_ms: Optional[int] = Field(None, description="Duração em milissegundos")
    created_at: datetime = Field(..., description="Data de criação")
    
    class Config:
        from_attributes = True


class ContractExportTemplateResponse(BaseModel):
    """Response de template de export"""
    id: int = Field(..., description="ID do template")
    name: str = Field(..., description="Nome do template")
    description: Optional[str] = Field(None, description="Descrição")
    export_type: ExportType = Field(..., description="Tipo de export")
    export_format: ExportFormat = Field(..., description="Formato do export")
    template_content: str = Field(..., description="Conteúdo do template")
    default_settings: Optional[Dict[str, Any]] = Field(None, description="Configurações padrão")
    validation_rules: Optional[Dict[str, Any]] = Field(None, description="Regras de validação")
    is_active: bool = Field(..., description="Se está ativo")
    is_default: bool = Field(..., description="Se é padrão")
    created_by: str = Field(..., description="Criado por")
    created_at: datetime = Field(..., description="Data de criação")
    updated_at: Optional[datetime] = Field(None, description="Data de atualização")
    
    class Config:
        from_attributes = True


# Status DTOs
class ExportStatusResponse(BaseModel):
    """Response de status de export"""
    export_id: int = Field(..., description="ID do export")
    status: ExportStatus = Field(..., description="Status atual")
    progress_percentage: int = Field(0, description="Percentual de progresso")
    current_step: Optional[str] = Field(None, description="Passo atual")
    estimated_completion: Optional[datetime] = Field(None, description="Estimativa de conclusão")
    
    # Estatísticas
    total_steps: int = Field(0, description="Total de passos")
    completed_steps: int = Field(0, description="Passos concluídos")
    failed_steps: int = Field(0, description="Passos falharam")
    
    # Informações de erro
    last_error: Optional[str] = Field(None, description="Último erro")
    can_retry: bool = Field(True, description="Se pode tentar novamente")


class PipelineStatusResponse(BaseModel):
    """Response de status do pipeline"""
    pipeline_id: str = Field(..., description="ID do pipeline")
    status: PipelineStatus = Field(..., description="Status do pipeline")
    pipeline_url: Optional[str] = Field(None, description="URL do pipeline")
    
    # Informações de execução
    started_at: Optional[datetime] = Field(None, description="Início da execução")
    finished_at: Optional[datetime] = Field(None, description="Fim da execução")
    duration_seconds: Optional[int] = Field(None, description="Duração em segundos")
    
    # Resultados
    success_count: int = Field(0, description="Número de sucessos")
    failure_count: int = Field(0, description="Número de falhas")
    
    # Logs
    logs_url: Optional[str] = Field(None, description="URL dos logs")
    artifacts_url: Optional[str] = Field(None, description="URL dos artefatos")


# Utility DTOs
class ExportStatisticsResponse(BaseModel):
    """Estatísticas de exports"""
    total_exports: int = Field(0, description="Total de exports")
    successful_exports: int = Field(0, description="Exports bem-sucedidos")
    failed_exports: int = Field(0, description="Exports falharam")
    pending_exports: int = Field(0, description="Exports pendentes")
    
    # Por tipo
    exports_by_type: Dict[str, int] = Field(default_factory=dict, description="Exports por tipo")
    exports_by_format: Dict[str, int] = Field(default_factory=dict, description="Exports por formato")
    
    # Temporais
    exports_last_24h: int = Field(0, description="Exports nas últimas 24h")
    exports_last_week: int = Field(0, description="Exports na última semana")
    exports_last_month: int = Field(0, description="Exports no último mês")
    
    # Performance
    average_export_time_seconds: float = Field(0.0, description="Tempo médio de export")
    success_rate_percentage: float = Field(0.0, description="Taxa de sucesso")


class ContractExportPreviewResponse(BaseModel):
    """Preview do que será exportado"""
    contract_id: int = Field(..., description="ID do contrato")
    export_format: ExportFormat = Field(..., description="Formato do export")
    preview_content: str = Field(..., description="Conteúdo do preview")
    estimated_size_bytes: int = Field(0, description="Tamanho estimado em bytes")
    validation_results: List[str] = Field(default_factory=list, description="Resultados da validação")
    warnings: List[str] = Field(default_factory=list, description="Avisos")
    
    # Metadados do preview
    generated_at: datetime = Field(..., description="Data de geração do preview")
    template_used: Optional[str] = Field(None, description="Template utilizado")

