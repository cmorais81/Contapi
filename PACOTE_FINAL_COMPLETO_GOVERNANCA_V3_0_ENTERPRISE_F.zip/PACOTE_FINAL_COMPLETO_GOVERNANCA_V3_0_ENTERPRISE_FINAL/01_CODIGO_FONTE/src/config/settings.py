"""
Sistema de Configuração Enterprise
API de Governança de Dados V3.0
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
Organização: F1rst
"""

import os
import yaml
from typing import List, Optional, Dict, Any
from pydantic_settings import BaseSettings
from pydantic import Field
from functools import lru_cache


class Settings(BaseSettings):
    """Configurações da aplicação com detecção automática de ambiente"""
    
    # Informações da Aplicação
    app_name: str = Field(default="API de Governança de Dados", description="Nome da aplicação")
    app_version: str = Field(default="3.0.0", description="Versão da aplicação")
    app_description: str = Field(default="API Enterprise para Governança de Dados V3.0", description="Descrição da aplicação")
    app_author: str = Field(default="Carlos Morais", description="Autor da aplicação")
    app_email: str = Field(default="carlos.morais@f1rst.com.br", description="Email do autor")
    app_organization: str = Field(default="F1rst", description="Organização")
    
    # Configuração de Ambiente
    environment: str = Field(default="development", description="Ambiente de execução")
    
    # Configuração da API
    api_host: str = Field(default="0.0.0.0", description="Host da API")
    api_port: int = Field(default=8000, description="Porta da API")
    api_debug: bool = Field(default=True, description="Modo debug")
    api_reload: bool = Field(default=True, description="Auto reload")
    api_workers: int = Field(default=1, description="Número de workers")
    
    # Configuração do Banco de Dados
    database_url: str = Field(default="postgresql://governance_user:governance_pass@localhost:5432/governance_db", description="URL do banco de dados")
    database_pool_size: int = Field(default=5, description="Tamanho do pool de conexões")
    database_max_overflow: int = Field(default=10, description="Máximo overflow do pool")
    database_echo: bool = Field(default=True, description="Echo SQL queries")
    
    # Configuração do Redis
    redis_url: str = Field(default="redis://localhost:6379/0", description="URL do Redis")
    redis_max_connections: int = Field(default=10, description="Máximo de conexões Redis")
    
    # Configuração de Segurança
    secret_key: str = Field(default="your-secret-key-change-in-production", description="Chave secreta")
    jwt_algorithm: str = Field(default="HS256", description="Algoritmo JWT")
    jwt_expire_minutes: int = Field(default=30, description="Expiração JWT em minutos")
    cors_origins: List[str] = Field(default=["*"], description="Origens CORS permitidas")
    cors_credentials: bool = Field(default=True, description="Credenciais CORS")
    cors_methods: List[str] = Field(default=["*"], description="Métodos CORS permitidos")
    cors_headers: List[str] = Field(default=["*"], description="Headers CORS permitidos")
    
    # Configuração de Logging
    log_level: str = Field(default="INFO", description="Nível de log")
    log_format: str = Field(default="%(asctime)s - %(name)s - %(levelname)s - %(message)s", description="Formato do log")
    log_file: Optional[str] = Field(default=None, description="Arquivo de log")
    
    # Configuração de Monitoramento
    monitoring_enabled: bool = Field(default=True, description="Monitoramento habilitado")
    health_check_interval: int = Field(default=30, description="Intervalo de health check")
    metrics_enabled: bool = Field(default=True, description="Métricas habilitadas")
    profiling_enabled: bool = Field(default=False, description="Profiling habilitado")
    
    # Configuração de Rate Limiting
    rate_limit_enabled: bool = Field(default=True, description="Rate limiting habilitado")
    rate_limit_requests: int = Field(default=100, description="Requests por minuto")
    rate_limit_window: int = Field(default=60, description="Janela de rate limiting")
    rate_limit_burst: int = Field(default=150, description="Burst limit")
    
    # Configuração de Cache
    cache_enabled: bool = Field(default=True, description="Cache habilitado")
    cache_ttl: int = Field(default=300, description="TTL do cache")
    cache_max_size: int = Field(default=1000, description="Tamanho máximo do cache")
    
    # Configuração de Backup
    backup_enabled: bool = Field(default=False, description="Backup habilitado")
    backup_interval: int = Field(default=3600, description="Intervalo de backup")
    backup_retention_days: int = Field(default=30, description="Retenção de backup em dias")
    
    # Configuração de Notificações
    notification_enabled: bool = Field(default=True, description="Notificações habilitadas")
    email_enabled: bool = Field(default=False, description="Email habilitado")
    email_smtp_host: Optional[str] = Field(default=None, description="Host SMTP")
    email_smtp_port: int = Field(default=587, description="Porta SMTP")
    email_username: Optional[str] = Field(default=None, description="Usuário email")
    email_password: Optional[str] = Field(default=None, description="Senha email")
    
    # Configuração Azure (opcional)
    azure_enabled: bool = Field(default=False, description="Azure habilitado")
    azure_client_id: Optional[str] = Field(default=None, description="Azure Client ID")
    azure_client_secret: Optional[str] = Field(default=None, description="Azure Client Secret")
    azure_tenant_id: Optional[str] = Field(default=None, description="Azure Tenant ID")
    
    # Configuração Databricks (opcional)
    databricks_enabled: bool = Field(default=False, description="Databricks habilitado")
    databricks_workspace_url: Optional[str] = Field(default=None, description="Databricks Workspace URL")
    databricks_token: Optional[str] = Field(default=None, description="Databricks Token")
    
    # Configuração Informatica Axon (opcional)
    informatica_axon_enabled: bool = Field(default=False, description="Informatica Axon habilitado")
    informatica_axon_url: Optional[str] = Field(default=None, description="Informatica Axon URL")
    informatica_axon_token: Optional[str] = Field(default=None, description="Informatica Axon Token")
    
    # Configuração Unity Catalog (opcional)
    unity_catalog_enabled: bool = Field(default=False, description="Unity Catalog habilitado")
    unity_catalog_url: Optional[str] = Field(default=None, description="Unity Catalog URL")
    unity_catalog_token: Optional[str] = Field(default=None, description="Unity Catalog Token")
    
    # Configuração de Performance
    max_request_size: int = Field(default=16777216, description="Tamanho máximo da requisição (16MB)")
    request_timeout: int = Field(default=30, description="Timeout da requisição")
    keep_alive_timeout: int = Field(default=2, description="Keep alive timeout")
    graceful_timeout: int = Field(default=30, description="Graceful timeout")
    max_workers: int = Field(default=4, description="Máximo de workers")
    worker_timeout: int = Field(default=30, description="Timeout do worker")
    
    # Configuração de Qualidade
    data_validation: bool = Field(default=True, description="Validação de dados")
    schema_validation: bool = Field(default=True, description="Validação de schema")
    business_rules_validation: bool = Field(default=True, description="Validação de regras de negócio")
    audit_logging: bool = Field(default=True, description="Log de auditoria")
    
    # Configuração de Compliance
    lgpd_enabled: bool = Field(default=True, description="LGPD habilitado")
    gdpr_enabled: bool = Field(default=True, description="GDPR habilitado")
    data_retention_days: int = Field(default=2555, description="Retenção de dados em dias (7 anos)")
    anonymization_enabled: bool = Field(default=True, description="Anonimização habilitada")
    
    # Configuração de Desenvolvimento
    dev_mode: bool = Field(default=True, description="Modo desenvolvimento")
    auto_reload: bool = Field(default=True, description="Auto reload")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False
        extra = "ignore"  # Ignora campos extras para compatibilidade
        
    def load_yaml_config(self, config_path: str = "config.yml") -> Dict[str, Any]:
        """Carrega configurações do arquivo YAML"""
        try:
            if os.path.exists(config_path):
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = yaml.safe_load(f)
                    
                # Aplica configurações do ambiente específico
                env_config = config.get('environments', {}).get(self.environment, {})
                global_config = config.get('global', {})
                
                # Mescla configurações
                merged_config = {**global_config, **env_config}
                return merged_config
        except Exception as e:
            print(f"Erro ao carregar config.yml: {e}")
        return {}
    
    def get_database_config(self) -> Dict[str, Any]:
        """Retorna configurações do banco de dados"""
        return {
            "url": self.database_url,
            "pool_size": self.database_pool_size,
            "max_overflow": self.database_max_overflow,
            "echo": self.database_echo and self.environment == "development"
        }
    
    def get_redis_config(self) -> Dict[str, Any]:
        """Retorna configurações do Redis"""
        return {
            "url": self.redis_url,
            "max_connections": self.redis_max_connections
        }
    
    def get_cors_config(self) -> Dict[str, Any]:
        """Retorna configurações CORS"""
        return {
            "allow_origins": self.cors_origins,
            "allow_credentials": self.cors_credentials,
            "allow_methods": self.cors_methods,
            "allow_headers": self.cors_headers
        }
    
    def get_logging_config(self) -> Dict[str, Any]:
        """Retorna configurações de logging"""
        return {
            "level": self.log_level,
            "format": self.log_format,
            "file": self.log_file
        }
    
    def is_production(self) -> bool:
        """Verifica se está em produção"""
        return self.environment.lower() == "production"
    
    def is_development(self) -> bool:
        """Verifica se está em desenvolvimento"""
        return self.environment.lower() == "development"
    
    def is_testing(self) -> bool:
        """Verifica se está em teste"""
        return self.environment.lower() == "testing"
    
    def get_integrations_status(self) -> Dict[str, bool]:
        """Retorna status das integrações"""
        return {
            "azure": self.azure_enabled,
            "databricks": self.databricks_enabled,
            "informatica_axon": self.informatica_axon_enabled,
            "unity_catalog": self.unity_catalog_enabled
        }
    
    def get_features_status(self) -> Dict[str, bool]:
        """Retorna status das funcionalidades"""
        return {
            "monitoring": self.monitoring_enabled,
            "rate_limiting": self.rate_limit_enabled,
            "caching": self.cache_enabled,
            "backup": self.backup_enabled,
            "notifications": self.notification_enabled,
            "data_validation": self.data_validation,
            "audit_logging": self.audit_logging,
            "lgpd": self.lgpd_enabled,
            "gdpr": self.gdpr_enabled
        }


@lru_cache()
def get_settings() -> Settings:
    """
    Retorna instância singleton das configurações
    Detecta automaticamente o ambiente e carrega configurações apropriadas
    """
    # Detecta ambiente automaticamente
    environment = os.getenv("ENVIRONMENT", "development").lower()
    
    # Cria instância das configurações
    settings = Settings(environment=environment)
    
    # Carrega configurações do YAML se disponível
    yaml_config = settings.load_yaml_config()
    
    # Aplica configurações específicas do ambiente
    if environment == "production":
        settings.api_debug = False
        settings.api_reload = False
        settings.database_echo = False
        settings.log_level = "INFO"
        settings.profiling_enabled = False
        settings.dev_mode = False
        settings.auto_reload = False
        
    elif environment == "testing":
        settings.api_debug = True
        settings.api_reload = False
        settings.database_echo = False
        settings.log_level = "WARNING"
        settings.monitoring_enabled = False
        settings.metrics_enabled = False
        settings.profiling_enabled = False
        
    elif environment == "development":
        settings.api_debug = True
        settings.api_reload = True
        settings.database_echo = True
        settings.log_level = "DEBUG"
        settings.profiling_enabled = True
        settings.dev_mode = True
        settings.auto_reload = True
    
    return settings


def get_environment_info() -> Dict[str, Any]:
    """Retorna informações do ambiente atual"""
    settings = get_settings()
    
    return {
        "environment": settings.environment,
        "app_name": settings.app_name,
        "app_version": settings.app_version,
        "author": settings.app_author,
        "organization": settings.app_organization,
        "is_production": settings.is_production(),
        "is_development": settings.is_development(),
        "is_testing": settings.is_testing(),
        "features": settings.get_features_status(),
        "integrations": settings.get_integrations_status(),
        "api_config": {
            "host": settings.api_host,
            "port": settings.api_port,
            "debug": settings.api_debug,
            "workers": settings.api_workers
        }
    }

