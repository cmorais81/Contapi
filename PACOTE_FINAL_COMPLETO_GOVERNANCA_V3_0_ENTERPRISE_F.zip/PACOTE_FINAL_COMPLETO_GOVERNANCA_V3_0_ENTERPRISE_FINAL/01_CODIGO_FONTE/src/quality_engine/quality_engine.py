"""
Engine Principal de Qualidade de Dados
API de Governança de Dados V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime
import logging
from uuid import UUID

from .rule_executor import RuleExecutor
from .metric_calculator import MetricCalculator
from .quality_validator import QualityValidator

logger = logging.getLogger(__name__)

class QualityEngine:
    """
    Engine principal de qualidade de dados
    
    Coordena a execução de regras de qualidade, cálculo de métricas
    e validação de dados em tempo real.
    """
    
    def __init__(self, config: Dict[str, Any] = None):
        """
        Inicializa a engine de qualidade
        
        Args:
            config: Configuração da engine
        """
        self.config = config or {}
        self.rule_executor = RuleExecutor(config)
        self.metric_calculator = MetricCalculator(config)
        self.quality_validator = QualityValidator(config)
        
        # Configurações padrão
        self.max_concurrent_rules = self.config.get('max_concurrent_rules', 10)
        self.timeout_seconds = self.config.get('timeout_seconds', 300)
        self.enable_caching = self.config.get('enable_caching', True)
        
        logger.info("Engine de qualidade inicializada")
    
    async def execute_quality_assessment(
        self, 
        entity_id: UUID, 
        rules: List[Dict[str, Any]] = None,
        calculate_metrics: bool = True,
        validate_data: bool = True
    ) -> Dict[str, Any]:
        """
        Executa avaliação completa de qualidade para uma entidade
        
        Args:
            entity_id: ID da entidade
            rules: Regras específicas a executar (opcional)
            calculate_metrics: Se deve calcular métricas
            validate_data: Se deve validar dados
            
        Returns:
            Dict: Resultado da avaliação de qualidade
        """
        try:
            start_time = datetime.now()
            
            logger.info(f"Iniciando avaliação de qualidade para entidade: {entity_id}")
            
            # Resultado consolidado
            assessment_result = {
                'entity_id': str(entity_id),
                'assessment_id': f"qa_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                'start_time': start_time.isoformat(),
                'status': 'running',
                'rules_executed': 0,
                'rules_passed': 0,
                'rules_failed': 0,
                'overall_score': 0.0,
                'metrics': {},
                'validation_results': {},
                'issues': [],
                'recommendations': []
            }
            
            # Executar tarefas em paralelo
            tasks = []
            
            # 1. Executar regras de qualidade
            if rules or True:  # Sempre executar regras padrão se não especificadas
                tasks.append(self._execute_rules_task(entity_id, rules))
            
            # 2. Calcular métricas
            if calculate_metrics:
                tasks.append(self._calculate_metrics_task(entity_id))
            
            # 3. Validar dados
            if validate_data:
                tasks.append(self._validate_data_task(entity_id))
            
            # Executar tarefas com timeout
            results = await asyncio.wait_for(
                asyncio.gather(*tasks, return_exceptions=True),
                timeout=self.timeout_seconds
            )
            
            # Processar resultados
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    logger.error(f"Erro na tarefa {i}: {result}")
                    assessment_result['issues'].append({
                        'type': 'execution_error',
                        'task': i,
                        'error': str(result)
                    })
                else:
                    # Consolidar resultados baseado no tipo de tarefa
                    if i == 0:  # Regras
                        self._consolidate_rules_results(assessment_result, result)
                    elif i == 1:  # Métricas
                        assessment_result['metrics'] = result
                    elif i == 2:  # Validação
                        assessment_result['validation_results'] = result
            
            # Calcular score geral
            assessment_result['overall_score'] = self._calculate_overall_score(assessment_result)
            
            # Gerar recomendações
            assessment_result['recommendations'] = self._generate_recommendations(assessment_result)
            
            # Finalizar
            end_time = datetime.now()
            assessment_result.update({
                'end_time': end_time.isoformat(),
                'duration_seconds': (end_time - start_time).total_seconds(),
                'status': 'completed'
            })
            
            logger.info(f"Avaliação de qualidade concluída: score {assessment_result['overall_score']:.2f}")
            
            return assessment_result
            
        except asyncio.TimeoutError:
            logger.error(f"Timeout na avaliação de qualidade para {entity_id}")
            assessment_result.update({
                'status': 'timeout',
                'end_time': datetime.now().isoformat(),
                'error': 'Avaliação excedeu tempo limite'
            })
            return assessment_result
            
        except Exception as e:
            logger.error(f"Erro na avaliação de qualidade: {e}")
            assessment_result.update({
                'status': 'error',
                'end_time': datetime.now().isoformat(),
                'error': str(e)
            })
            return assessment_result
    
    async def _execute_rules_task(self, entity_id: UUID, rules: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Executa regras de qualidade"""
        return await self.rule_executor.execute_rules(entity_id, rules)
    
    async def _calculate_metrics_task(self, entity_id: UUID) -> Dict[str, Any]:
        """Calcula métricas de qualidade"""
        return await self.metric_calculator.calculate_metrics(entity_id)
    
    async def _validate_data_task(self, entity_id: UUID) -> Dict[str, Any]:
        """Valida dados da entidade"""
        return await self.quality_validator.validate_entity(entity_id)
    
    def _consolidate_rules_results(self, assessment_result: Dict, rules_result: Dict):
        """Consolida resultados das regras"""
        assessment_result['rules_executed'] = rules_result.get('total_rules', 0)
        assessment_result['rules_passed'] = rules_result.get('passed_rules', 0)
        assessment_result['rules_failed'] = rules_result.get('failed_rules', 0)
        
        # Adicionar issues das regras
        for rule_result in rules_result.get('rule_results', []):
            if rule_result.get('status') == 'failed':
                assessment_result['issues'].append({
                    'type': 'rule_violation',
                    'rule_id': rule_result.get('rule_id'),
                    'rule_name': rule_result.get('rule_name'),
                    'severity': rule_result.get('severity', 'medium'),
                    'message': rule_result.get('error_message'),
                    'details': rule_result.get('details')
                })
    
    def _calculate_overall_score(self, assessment_result: Dict) -> float:
        """Calcula score geral de qualidade"""
        scores = []
        weights = []
        
        # Score das regras (peso 40%)
        if assessment_result['rules_executed'] > 0:
            rules_score = (assessment_result['rules_passed'] / assessment_result['rules_executed']) * 100
            scores.append(rules_score)
            weights.append(0.4)
        
        # Score das métricas (peso 35%)
        metrics = assessment_result.get('metrics', {})
        if metrics:
            metric_scores = []
            for metric_name, metric_data in metrics.items():
                if isinstance(metric_data, dict) and 'score' in metric_data:
                    metric_scores.append(metric_data['score'])
            
            if metric_scores:
                avg_metric_score = sum(metric_scores) / len(metric_scores)
                scores.append(avg_metric_score)
                weights.append(0.35)
        
        # Score da validação (peso 25%)
        validation = assessment_result.get('validation_results', {})
        if validation and 'overall_validity' in validation:
            validation_score = validation['overall_validity'] * 100
            scores.append(validation_score)
            weights.append(0.25)
        
        # Calcular média ponderada
        if scores:
            weighted_sum = sum(score * weight for score, weight in zip(scores, weights))
            total_weight = sum(weights)
            return weighted_sum / total_weight
        
        return 0.0
    
    def _generate_recommendations(self, assessment_result: Dict) -> List[Dict[str, Any]]:
        """Gera recomendações baseadas nos resultados"""
        recommendations = []
        
        # Recomendações baseadas no score geral
        overall_score = assessment_result['overall_score']
        
        if overall_score < 50:
            recommendations.append({
                'type': 'critical',
                'priority': 'high',
                'title': 'Qualidade crítica detectada',
                'description': 'A qualidade dos dados está abaixo do aceitável. Ação imediata necessária.',
                'actions': [
                    'Revisar regras de qualidade falhadas',
                    'Implementar validações na origem',
                    'Estabelecer processo de limpeza de dados'
                ]
            })
        elif overall_score < 70:
            recommendations.append({
                'type': 'warning',
                'priority': 'medium',
                'title': 'Qualidade precisa melhorar',
                'description': 'A qualidade dos dados pode ser aprimorada.',
                'actions': [
                    'Revisar regras com falhas',
                    'Implementar monitoramento contínuo',
                    'Treinar equipe em qualidade de dados'
                ]
            })
        
        # Recomendações baseadas em issues específicos
        issues_by_type = {}
        for issue in assessment_result.get('issues', []):
            issue_type = issue.get('type', 'unknown')
            if issue_type not in issues_by_type:
                issues_by_type[issue_type] = []
            issues_by_type[issue_type].append(issue)
        
        # Recomendações para violações de regras
        if 'rule_violation' in issues_by_type:
            rule_violations = issues_by_type['rule_violation']
            high_severity = [v for v in rule_violations if v.get('severity') == 'high']
            
            if high_severity:
                recommendations.append({
                    'type': 'rule_violation',
                    'priority': 'high',
                    'title': f'{len(high_severity)} violações de alta severidade',
                    'description': 'Regras críticas de qualidade foram violadas.',
                    'actions': [
                        'Corrigir dados que violam regras críticas',
                        'Revisar processo de entrada de dados',
                        'Implementar validações preventivas'
                    ]
                })
        
        # Recomendações baseadas em métricas
        metrics = assessment_result.get('metrics', {})
        if 'completeness' in metrics:
            completeness = metrics['completeness'].get('score', 100)
            if completeness < 80:
                recommendations.append({
                    'type': 'completeness',
                    'priority': 'medium',
                    'title': 'Completude baixa detectada',
                    'description': f'Completude dos dados: {completeness:.1f}%',
                    'actions': [
                        'Identificar campos com muitos valores nulos',
                        'Implementar validações obrigatórias',
                        'Revisar processo de coleta de dados'
                    ]
                })
        
        return recommendations
    
    async def execute_continuous_monitoring(self, entities: List[UUID]) -> Dict[str, Any]:
        """
        Executa monitoramento contínuo de qualidade
        
        Args:
            entities: Lista de entidades para monitorar
            
        Returns:
            Dict: Resultado do monitoramento
        """
        try:
            logger.info(f"Iniciando monitoramento contínuo para {len(entities)} entidades")
            
            monitoring_result = {
                'monitoring_id': f"mon_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                'start_time': datetime.now().isoformat(),
                'entities_monitored': len(entities),
                'entities_processed': 0,
                'entities_with_issues': 0,
                'critical_issues': 0,
                'summary': {},
                'entity_results': []
            }
            
            # Processar entidades em lotes para evitar sobrecarga
            batch_size = self.config.get('monitoring_batch_size', 5)
            
            for i in range(0, len(entities), batch_size):
                batch = entities[i:i + batch_size]
                
                # Executar avaliações em paralelo para o lote
                batch_tasks = [
                    self.execute_quality_assessment(
                        entity_id=entity_id,
                        calculate_metrics=True,
                        validate_data=False  # Monitoramento mais leve
                    )
                    for entity_id in batch
                ]
                
                batch_results = await asyncio.gather(*batch_tasks, return_exceptions=True)
                
                # Processar resultados do lote
                for entity_id, result in zip(batch, batch_results):
                    monitoring_result['entities_processed'] += 1
                    
                    if isinstance(result, Exception):
                        logger.error(f"Erro no monitoramento de {entity_id}: {result}")
                        continue
                    
                    # Analisar resultado
                    entity_summary = {
                        'entity_id': str(entity_id),
                        'overall_score': result.get('overall_score', 0),
                        'issues_count': len(result.get('issues', [])),
                        'critical_issues': len([
                            issue for issue in result.get('issues', [])
                            if issue.get('severity') == 'high'
                        ])
                    }
                    
                    monitoring_result['entity_results'].append(entity_summary)
                    
                    # Contar entidades com problemas
                    if entity_summary['issues_count'] > 0:
                        monitoring_result['entities_with_issues'] += 1
                    
                    monitoring_result['critical_issues'] += entity_summary['critical_issues']
            
            # Calcular resumo
            if monitoring_result['entities_processed'] > 0:
                avg_score = sum(
                    r['overall_score'] for r in monitoring_result['entity_results']
                ) / monitoring_result['entities_processed']
                
                monitoring_result['summary'] = {
                    'average_quality_score': avg_score,
                    'entities_with_issues_percentage': (
                        monitoring_result['entities_with_issues'] / 
                        monitoring_result['entities_processed']
                    ) * 100,
                    'critical_issues_total': monitoring_result['critical_issues']
                }
            
            monitoring_result.update({
                'end_time': datetime.now().isoformat(),
                'status': 'completed'
            })
            
            logger.info(f"Monitoramento concluído: {monitoring_result['entities_processed']} entidades processadas")
            
            return monitoring_result
            
        except Exception as e:
            logger.error(f"Erro no monitoramento contínuo: {e}")
            return {
                'status': 'error',
                'error': str(e),
                'end_time': datetime.now().isoformat()
            }
    
    def get_engine_status(self) -> Dict[str, Any]:
        """Retorna status da engine"""
        return {
            'engine_name': 'QualityEngine',
            'version': '2.3.0',
            'status': 'active',
            'config': {
                'max_concurrent_rules': self.max_concurrent_rules,
                'timeout_seconds': self.timeout_seconds,
                'enable_caching': self.enable_caching
            },
            'components': {
                'rule_executor': self.rule_executor.get_status(),
                'metric_calculator': self.metric_calculator.get_status(),
                'quality_validator': self.quality_validator.get_status()
            },
            'author': 'Carlos Morais (carlos.morais@f1rst.com.br)'
        }

