"""
Entidade Domain para o módulo de domínios
API de Governança de Dados V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class Domain(BaseModel):
    """Entidade de domínio de dados"""
    
    id: UUID = Field(default_factory=uuid4, description="ID único do domínio")
    name: str = Field(..., description="Nome do domínio")
    description: Optional[str] = Field(None, description="Descrição do domínio")
    parent_id: Optional[UUID] = Field(None, description="ID do domínio pai")
    owner_id: Optional[UUID] = Field(None, description="ID do proprietário")
    steward_id: Optional[UUID] = Field(None, description="ID do steward")
    domain_type: str = Field(default="business", description="Tipo do domínio")
    status: str = Field(default="active", description="Status do domínio")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadados do domínio")
    tags: List[str] = Field(default_factory=list, description="Tags do domínio")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Data de criação")
    updated_at: datetime = Field(default_factory=datetime.utcnow, description="Data de atualização")
    
    class Config:
        json_json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "name": "Customer Domain",
                "description": "Domínio de dados de clientes",
                "parent_id": None,
                "owner_id": "456e7890-e89b-12d3-a456-426614174000",
                "steward_id": "789e0123-e89b-12d3-a456-426614174000",
                "domain_type": "business",
                "status": "active",
                "metadata": {"priority": "high"},
                "tags": ["customer", "core"],
                "created_at": "2025-07-17T23:36:17Z",
                "updated_at": "2025-07-17T23:36:17Z"
            }
        }
    
    def __str__(self) -> str:
        return f"Domain(id={self.id}, name='{self.name}')"
    
    def __repr__(self) -> str:
        return self.__str__()
    
    def is_active(self) -> bool:
        """Verifica se o domínio está ativo"""
        return self.status == "active"
    
    def has_parent(self) -> bool:
        """Verifica se o domínio tem um pai"""
        return self.parent_id is not None
    
    def add_tag(self, tag: str) -> None:
        """Adiciona uma tag ao domínio"""
        if tag not in self.tags:
            self.tags.append(tag)
            self.updated_at = datetime.utcnow()
    
    def remove_tag(self, tag: str) -> None:
        """Remove uma tag do domínio"""
        if tag in self.tags:
            self.tags.remove(tag)
            self.updated_at = datetime.utcnow()
    
    def update_metadata(self, key: str, value: Any) -> None:
        """Atualiza um metadado do domínio"""
        self.metadata[key] = value
        self.updated_at = datetime.utcnow()
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte a entidade para dicionário"""
        return {
            "id": str(self.id),
            "name": self.name,
            "description": self.description,
            "parent_id": str(self.parent_id) if self.parent_id else None,
            "owner_id": str(self.owner_id) if self.owner_id else None,
            "steward_id": str(self.steward_id) if self.steward_id else None,
            "domain_type": self.domain_type,
            "status": self.status,
            "metadata": self.metadata,
            "tags": self.tags,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }

