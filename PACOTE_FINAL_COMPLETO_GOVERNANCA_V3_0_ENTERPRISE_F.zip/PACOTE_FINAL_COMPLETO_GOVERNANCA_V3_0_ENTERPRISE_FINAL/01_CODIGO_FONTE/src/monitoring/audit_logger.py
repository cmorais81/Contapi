"""
Sistema de Audit Logs Detalhados
Desenvolvido por Carlos Morais
"""

import json
import uuid
import asyncio
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union
from enum import Enum
from contextlib import asynccontextmanager
from functools import wraps
from dataclasses import dataclass, asdict

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete, and_, or_
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from src.database.models import AuditLog, AuditLogRetentionPolicy, AuditLogArchive
from src.database.connection import get_async_session
from config.settings import get_settings


class EventType(str, Enum):
    """Tipos de eventos de auditoria"""
    CREATE = "CREATE"
    READ = "READ"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    LOGIN = "LOGIN"
    LOGOUT = "LOGOUT"
    LOGIN_FAILED = "LOGIN_FAILED"
    ACCESS_DENIED = "ACCESS_DENIED"
    EXPORT = "EXPORT"
    IMPORT = "IMPORT"
    APPROVE = "APPROVE"
    REJECT = "REJECT"
    ARCHIVE = "ARCHIVE"
    RESTORE = "RESTORE"
    BULK_OPERATION = "BULK_OPERATION"
    API_CALL = "API_CALL"
    SYSTEM_EVENT = "SYSTEM_EVENT"


class Severity(str, Enum):
    """Níveis de severidade"""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARN = "WARN"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


@dataclass
class AuditContext:
    """Contexto de auditoria"""
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    correlation_id: Optional[str] = None
    request_id: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


class AuditLogger:
    """Sistema de audit logs detalhados"""
    
    def __init__(self):
        self.settings = get_settings()
        self._context_storage = {}
        
    async def log_event(
        self,
        event_type: EventType,
        resource_type: str,
        resource_id: Optional[str] = None,
        user_id: Optional[str] = None,
        changes: Optional[Dict[str, Any]] = None,
        additional_metadata: Optional[Dict[str, Any]] = None,
        severity: Severity = Severity.INFO,
        tags: Optional[List[str]] = None,
        correlation_id: Optional[str] = None,
        session: Optional[AsyncSession] = None
    ) -> str:
        """
        Registra um evento de auditoria
        
        Args:
            event_type: Tipo do evento
            resource_type: Tipo do recurso afetado
            resource_id: ID do recurso
            user_id: ID do usuário
            changes: Mudanças realizadas (before/after)
            additional_metadata: Metadados extras
            severity: Nível de severidade
            tags: Tags para categorização
            correlation_id: ID de correlação
            session: Sessão do banco de dados
            
        Returns:
            ID do log de auditoria criado
        """
        
        # Obter contexto atual
        context = self._get_current_context()
        
        # Preparar dados do log
        log_data = {
            "id": str(uuid.uuid4()),
            "event_type": event_type.value,
            "resource_type": resource_type,
            "resource_id": resource_id,
            "user_id": user_id or context.user_id,
            "session_id": context.session_id,
            "ip_address": context.ip_address,
            "user_agent": context.user_agent,
            "correlation_id": correlation_id or context.correlation_id or str(uuid.uuid4()),
            "changes": changes,
            "additional_metadata": additional_metadata,
            "severity": severity.value,
            "tags": tags or [],
            "created_at": datetime.utcnow()
        }
        
        # Salvar no banco
        if session:
            await self._save_audit_log(session, log_data)
        else:
            async with get_async_session() as db_session:
                await self._save_audit_log(db_session, log_data)
        
        return log_data["id"]
    
    async def log_api_request(
        self,
        request: Request,
        response: Response,
        user_id: Optional[str] = None,
        response_time_ms: Optional[int] = None,
        session: Optional[AsyncSession] = None
    ):
        """Registra uma requisição da API"""
        
        # Sanitizar body da requisição
        request_body = None
        if hasattr(request, '_body'):
            try:
                body_str = request._body.decode('utf-8')
                request_body = json.loads(body_str) if body_str else None
                # Remover campos sensíveis
                if request_body:
                    request_body = self._sanitize_request_body(request_body)
            except:
                request_body = {"error": "Could not parse request body"}
        
        additional_metadata = {
            "request_method": request.method,
            "request_path": str(request.url.path),
            "request_query": str(request.url.query) if request.url.query else None,
            "request_body": request_body,
            "response_status": response.status_code,
            "response_time_ms": response_time_ms,
            "content_length": response.headers.get("content-length"),
            "content_type": response.headers.get("content-type")
        }
        
        # Determinar severidade baseada no status
        if response.status_code >= 500:
            severity = Severity.ERROR
        elif response.status_code >= 400:
            severity = Severity.WARN
        else:
            severity = Severity.INFO
        
        await self.log_event(
            event_type=EventType.API_CALL,
            resource_type="api_endpoint",
            resource_id=f"{request.method}:{request.url.path}",
            user_id=user_id,
            additional_metadata=additional_metadata,
            severity=severity,
            tags=["api", "request"],
            session=session
        )
    
    async def log_data_change(
        self,
        event_type: EventType,
        resource_type: str,
        resource_id: str,
        before_data: Optional[Dict[str, Any]] = None,
        after_data: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None,
        session: Optional[AsyncSession] = None
    ):
        """Registra mudanças em dados"""
        
        changes = {}
        if before_data is not None:
            changes["before"] = before_data
        if after_data is not None:
            changes["after"] = after_data
            
        # Calcular campos alterados
        if before_data and after_data:
            changed_fields = []
            for key in set(before_data.keys()) | set(after_data.keys()):
                if before_data.get(key) != after_data.get(key):
                    changed_fields.append(key)
            changes["changed_fields"] = changed_fields
        
        await self.log_event(
            event_type=event_type,
            resource_type=resource_type,
            resource_id=resource_id,
            user_id=user_id,
            changes=changes,
            tags=["data_change"],
            session=session
        )
    
    async def search_audit_logs(
        self,
        event_types: Optional[List[EventType]] = None,
        resource_types: Optional[List[str]] = None,
        resource_id: Optional[str] = None,
        user_id: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        severity: Optional[Severity] = None,
        tags: Optional[List[str]] = None,
        correlation_id: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
        session: Optional[AsyncSession] = None
    ) -> List[Dict[str, Any]]:
        """Busca logs de auditoria com filtros"""
        
        async def _search(db_session: AsyncSession):
            query = select(AuditLog)
            
            # Aplicar filtros
            conditions = []
            
            if event_types:
                conditions.append(AuditLog.event_type.in_([et.value for et in event_types]))
            
            if resource_types:
                conditions.append(AuditLog.resource_type.in_(resource_types))
            
            if resource_id:
                conditions.append(AuditLog.resource_id == resource_id)
            
            if user_id:
                conditions.append(AuditLog.user_id == user_id)
            
            if start_date:
                conditions.append(AuditLog.created_at >= start_date)
            
            if end_date:
                conditions.append(AuditLog.created_at <= end_date)
            
            if severity:
                conditions.append(AuditLog.severity == severity.value)
            
            if correlation_id:
                conditions.append(AuditLog.correlation_id == correlation_id)
            
            if tags:
                for tag in tags:
                    conditions.append(AuditLog.tags.contains([tag]))
            
            if conditions:
                query = query.where(and_(*conditions))
            
            # Ordenar por data (mais recente primeiro)
            query = query.order_by(AuditLog.created_at.desc())
            
            # Aplicar paginação
            query = query.offset(offset).limit(limit)
            
            result = await db_session.execute(query)
            logs = result.scalars().all()
            
            return [self._audit_log_to_dict(log) for log in logs]
        
        if session:
            return await _search(session)
        else:
            async with get_async_session() as db_session:
                return await _search(db_session)
    
    async def cleanup_old_logs(self, session: Optional[AsyncSession] = None):
        """Remove logs antigos baseado nas políticas de retenção"""
        
        async def _cleanup(db_session: AsyncSession):
            # Buscar políticas de retenção
            policies_result = await db_session.execute(
                select(AuditLogRetentionPolicy).where(
                    AuditLogRetentionPolicy.is_active == True
                )
            )
            policies = policies_result.scalars().all()
            
            for policy in policies:
                cutoff_date = datetime.utcnow() - timedelta(days=policy.retention_days)
                
                # Construir condições de limpeza
                conditions = [AuditLog.created_at < cutoff_date]
                
                if policy.resource_type:
                    conditions.append(AuditLog.resource_type == policy.resource_type)
                
                if policy.event_type:
                    conditions.append(AuditLog.event_type == policy.event_type)
                
                # Deletar logs antigos
                delete_query = delete(AuditLog).where(and_(*conditions))
                result = await db_session.execute(delete_query)
                
                if result.rowcount > 0:
                    await self.log_event(
                        event_type=EventType.SYSTEM_EVENT,
                        resource_type="audit_log",
                        additional_metadata={
                            "action": "cleanup",
                            "policy_id": str(policy.id),
                            "deleted_count": result.rowcount,
                            "cutoff_date": cutoff_date.isoformat()
                        },
                        severity=Severity.INFO,
                        tags=["cleanup", "maintenance"],
                        session=db_session
                    )
            
            await db_session.commit()
        
        if session:
            await _cleanup(session)
        else:
            async with get_async_session() as db_session:
                await _cleanup(db_session)
    
    def set_context(self, context: AuditContext):
        """Define o contexto de auditoria para a thread atual"""
        task_id = id(asyncio.current_task())
        self._context_storage[task_id] = context
    
    def _get_current_context(self) -> AuditContext:
        """Obtém o contexto atual"""
        task_id = id(asyncio.current_task())
        return self._context_storage.get(task_id, AuditContext())
    
    def _sanitize_request_body(self, body: Dict[str, Any]) -> Dict[str, Any]:
        """Remove campos sensíveis do body da requisição"""
        sensitive_fields = {
            'password', 'token', 'secret', 'key', 'authorization',
            'credit_card', 'ssn', 'social_security', 'api_key'
        }
        
        def sanitize_dict(d):
            if isinstance(d, dict):
                return {
                    k: "***REDACTED***" if any(sf in k.lower() for sf in sensitive_fields)
                    else sanitize_dict(v)
                    for k, v in d.items()
                }
            elif isinstance(d, list):
                return [sanitize_dict(item) for item in d]
            else:
                return d
        
        return sanitize_dict(body)
    
    async def _save_audit_log(self, session: AsyncSession, log_data: Dict[str, Any]):
        """Salva o log de auditoria no banco"""
        audit_log = AuditLog(**log_data)
        session.add(audit_log)
        await session.commit()
    
    def _audit_log_to_dict(self, log: AuditLog) -> Dict[str, Any]:
        """Converte AuditLog para dicionário"""
        return {
            "id": str(log.id),
            "event_type": log.event_type,
            "resource_type": log.resource_type,
            "resource_id": log.resource_id,
            "user_id": log.user_id,
            "session_id": log.session_id,
            "ip_address": str(log.ip_address) if log.ip_address else None,
            "user_agent": log.user_agent,
            "correlation_id": log.correlation_id,
            "changes": log.changes,
            "additional_metadata": log.additional_metadata,
            "severity": log.severity,
            "tags": log.tags,
            "created_at": log.created_at.isoformat() if log.created_at else None
        }


# Instância global do audit logger
audit_logger = AuditLogger()


def audit_event(
    event_type: EventType,
    resource_type: str,
    severity: Severity = Severity.INFO,
    tags: Optional[List[str]] = None
):
    """Decorator para auditoria automática de funções"""
    
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            start_time = datetime.utcnow()
            correlation_id = str(uuid.uuid4())
            
            try:
                # Executar função
                result = await func(*args, **kwargs)
                
                # Log de sucesso
                execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000
                
                await audit_logger.log_event(
                    event_type=event_type,
                    resource_type=resource_type,
                    additional_metadata={
                        "function_name": func.__name__,
                        "execution_time_ms": int(execution_time),
                        "success": True
                    },
                    severity=severity,
                    tags=(tags or []) + ["function_call"],
                    correlation_id=correlation_id
                )
                
                return result
                
            except Exception as e:
                # Log de erro
                execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000
                
                await audit_logger.log_event(
                    event_type=EventType.SYSTEM_EVENT,
                    resource_type=resource_type,
                    additional_metadata={
                        "function_name": func.__name__,
                        "execution_time_ms": int(execution_time),
                        "success": False,
                        "error": str(e),
                        "error_type": type(e).__name__
                    },
                    severity=Severity.ERROR,
                    tags=(tags or []) + ["function_call", "error"],
                    correlation_id=correlation_id
                )
                
                raise
        
        return wrapper
    return decorator


class AuditMiddleware(BaseHTTPMiddleware):
    """Middleware para auditoria automática de requisições"""
    
    async def dispatch(self, request: Request, call_next):
        start_time = datetime.utcnow()
        
        # Extrair informações da requisição
        user_id = getattr(request.state, 'user_id', None)
        session_id = request.headers.get('X-Session-ID') or str(uuid.uuid4())
        ip_address = request.client.host if request.client else None
        user_agent = request.headers.get('User-Agent')
        correlation_id = request.headers.get('X-Correlation-ID') or str(uuid.uuid4())
        
        # Definir contexto de auditoria
        context = AuditContext(
            user_id=user_id,
            session_id=session_id,
            ip_address=ip_address,
            user_agent=user_agent,
            correlation_id=correlation_id
        )
        audit_logger.set_context(context)
        
        # Processar requisição
        response = await call_next(request)
        
        # Calcular tempo de resposta
        end_time = datetime.utcnow()
        response_time_ms = int((end_time - start_time).total_seconds() * 1000)
        
        # Log da requisição (apenas para endpoints importantes)
        if self._should_audit_request(request):
            try:
                await audit_logger.log_api_request(
                    request=request,
                    response=response,
                    user_id=user_id,
                    response_time_ms=response_time_ms
                )
            except Exception as e:
                # Não falhar a requisição por erro de auditoria
                print(f"Audit logging error: {e}")
        
        # Adicionar headers de correlação
        response.headers["X-Correlation-ID"] = correlation_id
        response.headers["X-Response-Time"] = str(response_time_ms)
        
        return response
    
    def _should_audit_request(self, request: Request) -> bool:
        """Determina se a requisição deve ser auditada"""
        path = request.url.path
        
        # Não auditar health checks e métricas
        skip_paths = ['/health', '/metrics', '/docs', '/openapi.json']
        if any(path.startswith(skip_path) for skip_path in skip_paths):
            return False
        
        # Auditar todas as outras requisições da API
        return path.startswith('/api/')

