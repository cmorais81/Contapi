"""
Repositório de Contratos de Dados
API de Governança de Dados V1.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, asc, func
from ..models.contracts import DataContract, ContractVersion, ContractApproval
from .base import BaseRepository

class ContractRepository(BaseRepository[DataContract]):
    """Repositório para operações com contratos de dados"""
    
    def __init__(self, session: Session):
        super().__init__(DataContract, session)
    
    def find_by_name(self, name: str) -> Optional[DataContract]:
        """Busca contrato por nome"""
        return self.session.query(DataContract).filter(
            DataContract.name == name
        ).first()
    
    def find_by_status(self, status: str) -> List[DataContract]:
        """Busca contratos por status"""
        return self.session.query(DataContract).filter(
            DataContract.status == status
        ).all()
    
    def find_active_contracts(self) -> List[DataContract]:
        """Busca contratos ativos"""
        return self.find_by_status('active')
    
    def find_by_owner(self, owner_id: str) -> List[DataContract]:
        """Busca contratos por proprietário"""
        return self.session.query(DataContract).filter(
            DataContract.owner_id == owner_id
        ).all()
    
    def search_contracts(self, search_term: str) -> List[DataContract]:
        """Busca contratos por termo de pesquisa"""
        return self.session.query(DataContract).filter(
            or_(
                DataContract.name.ilike(f'%{search_term}%'),
                DataContract.description.ilike(f'%{search_term}%')
            )
        ).all()
    
    def get_contract_versions(self, contract_id: str) -> List[ContractVersion]:
        """Obtém todas as versões de um contrato"""
        return self.session.query(ContractVersion).filter(
            ContractVersion.contract_id == contract_id
        ).order_by(desc(ContractVersion.version_number)).all()
    
    def get_latest_version(self, contract_id: str) -> Optional[ContractVersion]:
        """Obtém a versão mais recente de um contrato"""
        return self.session.query(ContractVersion).filter(
            ContractVersion.contract_id == contract_id
        ).order_by(desc(ContractVersion.version_number)).first()
    
    def get_pending_approvals(self, contract_id: str) -> List[ContractApproval]:
        """Obtém aprovações pendentes de um contrato"""
        return self.session.query(ContractApproval).filter(
            and_(
                ContractApproval.contract_id == contract_id,
                ContractApproval.status == 'pending'
            )
        ).all()

class ContractVersionRepository(BaseRepository[ContractVersion]):
    """Repositório para operações com versões de contratos"""
    
    def __init__(self, session: Session):
        super().__init__(ContractVersion, session)
    
    def find_by_contract_and_version(self, contract_id: str, version: str) -> Optional[ContractVersion]:
        """Busca versão específica de um contrato"""
        return self.session.query(ContractVersion).filter(
            and_(
                ContractVersion.contract_id == contract_id,
                ContractVersion.version_number == version
            )
        ).first()
    
    def get_active_versions(self, contract_id: str) -> List[ContractVersion]:
        """Obtém versões ativas de um contrato"""
        return self.session.query(ContractVersion).filter(
            and_(
                ContractVersion.contract_id == contract_id,
                ContractVersion.status == 'active'
            )
        ).all()

class ContractApprovalRepository(BaseRepository[ContractApproval]):
    """Repositório para operações com aprovações de contratos"""
    
    def __init__(self, session: Session):
        super().__init__(ContractApproval, session)
    
    def find_by_approver(self, approver_id: str) -> List[ContractApproval]:
        """Busca aprovações por aprovador"""
        return self.session.query(ContractApproval).filter(
            ContractApproval.approver_id == approver_id
        ).all()
    
    def find_pending_for_user(self, approver_id: str) -> List[ContractApproval]:
        """Busca aprovações pendentes para um usuário"""
        return self.session.query(ContractApproval).filter(
            and_(
                ContractApproval.approver_id == approver_id,
                ContractApproval.status == 'pending'
            )
        ).all()
    
    def approve_contract(self, approval_id: str, approver_id: str, comments: str = None) -> bool:
        """Aprova um contrato"""
        approval = self.get_by_id(approval_id)
        if approval and approval.approver_id == approver_id:
            approval.status = 'approved'
            approval.comments = comments
            approval.approved_at = self.session.query(func.now()).scalar()
            self.session.commit()
            return True
        return False
    
    def reject_contract(self, approval_id: str, approver_id: str, comments: str) -> bool:
        """Rejeita um contrato"""
        approval = self.get_by_id(approval_id)
        if approval and approval.approver_id == approver_id:
            approval.status = 'rejected'
            approval.comments = comments
            approval.approved_at = self.session.query(func.now()).scalar()
            self.session.commit()
            return True
        return False

