"""
Classe Base para Modelos SQLAlchemy
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import uuid
from datetime import datetime
from sqlalchemy import Column, DateTime, String, text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declarative_base, declared_attr
from sqlalchemy.sql import func

class BaseModel:
    """Classe base com campos comuns para todos os modelos"""
    
    @declared_attr
    def __tablename__(cls):
        """Gera nome da tabela automaticamente em snake_case"""
        import re
        name = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', cls.__name__)
        return re.sub('([a-z0-9])([A-Z])', r'\1_\2', name).lower()
    
    # Campos obrigatórios em todas as tabelas (padrão DBML)
    id = Column(
        UUID(as_uuid=True), 
        primary_key=True, 
        default=uuid.uuid4,
        server_default=text("gen_random_uuid()"),
        comment="Identificador único UUID"
    )
    
    created_at = Column(
        DateTime(timezone=True),
        nullable=False,
        default=datetime.utcnow,
        server_default=func.now(),
        comment="Data de criação do registro"
    )
    
    updated_at = Column(
        DateTime(timezone=True),
        nullable=False,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        server_default=func.now(),
        comment="Data da última atualização"
    )
    
    def to_dict(self):
        """Converte modelo para dicionário"""
        return {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }
    
    def update_from_dict(self, data: dict):
        """Atualiza modelo a partir de dicionário"""
        for key, value in data.items():
            if hasattr(self, key) and key not in ['id', 'created_at']:
                setattr(self, key, value)
        self.updated_at = datetime.utcnow()
    
    def __repr__(self):
        return f"<{self.__class__.__name__}(id={self.id})>"

# Base declarativa do SQLAlchemy
Base = declarative_base(cls=BaseModel)

# Metadados para migrations
Base.metadata.info = {
    'version': '1.9.0',
    'author': 'Carlos Morais',
    'email': 'carlos.morais@f1rst.com.br',
    'description': 'API de Governança de Dados - Modelo Completo'
}

