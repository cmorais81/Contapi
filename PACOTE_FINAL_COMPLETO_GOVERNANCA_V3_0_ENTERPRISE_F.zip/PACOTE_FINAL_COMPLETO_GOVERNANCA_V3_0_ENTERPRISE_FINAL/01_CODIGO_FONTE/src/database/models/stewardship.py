"""
Modelos de Data Stewardship
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum, Float
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class StewardRole(Enum):
    DATA_OWNER = "data_owner"
    DATA_STEWARD = "data_steward"
    DATA_CUSTODIAN = "data_custodian"
    BUSINESS_ANALYST = "business_analyst"
    TECHNICAL_LEAD = "technical_lead"
    COMPLIANCE_OFFICER = "compliance_officer"

class AssignmentStatus(Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"
    EXPIRED = "expired"

class ActivityType(Enum):
    DATA_PROFILING = "data_profiling"
    QUALITY_REVIEW = "quality_review"
    METADATA_UPDATE = "metadata_update"
    POLICY_ENFORCEMENT = "policy_enforcement"
    ISSUE_RESOLUTION = "issue_resolution"
    DOCUMENTATION = "documentation"
    TRAINING = "training"
    AUDIT = "audit"

class ActivityStatus(Enum):
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    OVERDUE = "overdue"

class DataSteward(Base):
    """Data stewards responsáveis pela governança"""
    __tablename__ = 'data_stewards'
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Usuário associado')
    steward_role = Column(SQLEnum(StewardRole), nullable=False, comment='Papel do steward')
    
    # Informações profissionais
    department = Column(String(255), comment='Departamento')
    business_unit = Column(String(255), comment='Unidade de negócio')
    expertise_areas = Column(JSONB, comment='Áreas de expertise')
    
    # Certificações e qualificações
    certifications = Column(JSONB, comment='Certificações relevantes')
    training_completed = Column(JSONB, comment='Treinamentos completados')
    skill_level = Column(String(50), comment='Nível de habilidade (junior, senior, expert)')
    
    # Configurações
    is_active = Column(Boolean, default=True, comment='Steward ativo')
    availability_hours = Column(Integer, comment='Horas disponíveis por semana')
    preferred_contact_method = Column(String(50), comment='Método preferido de contato')
    
    # Métricas de performance
    total_assignments = Column(Integer, default=0, comment='Total de atribuições')
    completed_activities = Column(Integer, default=0, comment='Atividades completadas')
    average_resolution_time = Column(Float, comment='Tempo médio de resolução em horas')
    quality_score = Column(Float, comment='Score de qualidade do trabalho (0-100)')
    
    # Relacionamentos
    user = relationship("User")
    assignments = relationship("StewardAssignment", back_populates="steward", cascade="all, delete-orphan")
    activities = relationship("StewardActivity", back_populates="steward", cascade="all, delete-orphan")

class StewardAssignment(Base):
    """Atribuições de stewardship para entidades"""
    __tablename__ = 'steward_assignments'
    __table_args__ = {'extend_existing': True}
    
    steward_id = Column(UUID(as_uuid=True), ForeignKey('data_stewards.id'), nullable=False)
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False)
    
    # Detalhes da atribuição
    assignment_type = Column(String(100), comment='Tipo de atribuição (primary, backup, reviewer)')
    responsibilities = Column(JSONB, comment='Responsabilidades específicas')
    scope_description = Column(Text, comment='Descrição do escopo')
    
    # Status e datas
    status = Column(SQLEnum(AssignmentStatus), default=AssignmentStatus.ACTIVE, comment='Status da atribuição')
    assigned_date = Column(DateTime(timezone=True), nullable=False, comment='Data de atribuição')
    effective_date = Column(DateTime(timezone=True), comment='Data de início efetivo')
    end_date = Column(DateTime(timezone=True), comment='Data de término')
    
    # Configurações
    priority_level = Column(String(50), comment='Nível de prioridade')
    escalation_contact = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Contato para escalação')
    
    # Metadados
    assigned_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que fez a atribuição')
    business_justification = Column(Text, comment='Justificativa de negócio')
    
    # Relacionamentos
    steward = relationship("DataSteward", back_populates="assignments")
    entity = relationship("Entity")
    assigner = relationship("User", foreign_keys=[assigned_by])
    escalation_user = relationship("User", foreign_keys=[escalation_contact])

class StewardActivity(Base):
    """Atividades realizadas pelos stewards"""
    __tablename__ = 'steward_activities'
    __table_args__ = {'extend_existing': True}
    
    steward_id = Column(UUID(as_uuid=True), ForeignKey('data_stewards.id'), nullable=False)
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade relacionada')
    
    # Detalhes da atividade
    activity_type = Column(SQLEnum(ActivityType), nullable=False, comment='Tipo de atividade')
    title = Column(String(255), nullable=False, comment='Título da atividade')
    description = Column(Text, comment='Descrição detalhada')
    
    # Status e cronograma
    status = Column(SQLEnum(ActivityStatus), default=ActivityStatus.PLANNED, comment='Status da atividade')
    planned_start = Column(DateTime(timezone=True), comment='Início planejado')
    planned_end = Column(DateTime(timezone=True), comment='Fim planejado')
    actual_start = Column(DateTime(timezone=True), comment='Início real')
    actual_end = Column(DateTime(timezone=True), comment='Fim real')
    
    # Esforço e recursos
    estimated_hours = Column(Float, comment='Horas estimadas')
    actual_hours = Column(Float, comment='Horas reais')
    resources_needed = Column(JSONB, comment='Recursos necessários')
    
    # Resultados
    deliverables = Column(JSONB, comment='Entregáveis da atividade')
    outcomes = Column(Text, comment='Resultados alcançados')
    lessons_learned = Column(Text, comment='Lições aprendidas')
    
    # Qualidade e impacto
    quality_impact = Column(Float, comment='Impacto na qualidade dos dados')
    business_value = Column(Text, comment='Valor de negócio gerado')
    
    # Colaboração
    collaborators = Column(JSONB, comment='Colaboradores envolvidos')
    stakeholders_notified = Column(JSONB, comment='Stakeholders notificados')
    
    # Relacionamentos
    steward = relationship("DataSteward", back_populates="activities")
    entity = relationship("Entity")

