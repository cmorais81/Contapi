"""
Modelos de Políticas de Governança
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum, Float
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class PolicyType(Enum):
    ACCESS_CONTROL = "access_control"
    DATA_CLASSIFICATION = "data_classification"
    RETENTION = "retention"
    QUALITY = "quality"
    PRIVACY = "privacy"
    COMPLIANCE = "compliance"
    MASKING = "masking"
    CUSTOM = "custom"

class PolicyStatus(Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    DEPRECATED = "deprecated"

class ViolationSeverity(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class ViolationStatus(Enum):
    OPEN = "open"
    INVESTIGATING = "investigating"
    RESOLVED = "resolved"
    FALSE_POSITIVE = "false_positive"
    ACCEPTED_RISK = "accepted_risk"

class ComplianceStatus(Enum):
    COMPLIANT = "compliant"
    NON_COMPLIANT = "non_compliant"
    PARTIALLY_COMPLIANT = "partially_compliant"
    NOT_ASSESSED = "not_assessed"

class GovernancePolicy(Base):
    """Políticas de governança de dados"""
    __tablename__ = 'governance_policies'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da política')
    description = Column(Text, comment='Descrição detalhada da política')
    policy_type = Column(SQLEnum(PolicyType), nullable=False, comment='Tipo da política')
    status = Column(SQLEnum(PolicyStatus), default=PolicyStatus.DRAFT, comment='Status da política')
    
    # Definição da política
    policy_definition = Column(JSONB, nullable=False, comment='Definição da política em JSON')
    enforcement_rules = Column(JSONB, comment='Regras de aplicação da política')
    exceptions = Column(JSONB, comment='Exceções à política')
    
    # Escopo de aplicação
    scope_entities = Column(JSONB, comment='Entidades no escopo da política')
    scope_attributes = Column(JSONB, comment='Atributos específicos no escopo')
    scope_conditions = Column(JSONB, comment='Condições para aplicação')
    
    # Configurações de enforcement
    is_enforced = Column(Boolean, default=False, comment='Política sendo aplicada')
    enforcement_mode = Column(String(50), default='monitor', comment='Modo de aplicação (monitor, enforce, block)')
    auto_remediation = Column(Boolean, default=False, comment='Remediação automática habilitada')
    
    # Metadados
    owner_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Proprietário da política')
    business_justification = Column(Text, comment='Justificativa de negócio')
    regulatory_basis = Column(JSONB, comment='Base regulatória (LGPD, GDPR, etc.)')
    
    # Datas importantes
    effective_date = Column(DateTime(timezone=True), comment='Data de vigência')
    review_date = Column(DateTime(timezone=True), comment='Data de revisão')
    expiration_date = Column(DateTime(timezone=True), comment='Data de expiração')
    
    # Relacionamentos
    owner = relationship("User", foreign_keys=[owner_id])
    violations = relationship("PolicyViolation", back_populates="policy", cascade="all, delete-orphan")

class PolicyViolation(Base):
    """Violações de políticas detectadas"""
    __tablename__ = 'policy_violations'
    __table_args__ = {'extend_existing': True}
    
    policy_id = Column(UUID(as_uuid=True), ForeignKey('governance_policies.id'), nullable=False)
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade onde ocorreu a violação')
    
    # Detalhes da violação
    violation_type = Column(String(100), nullable=False, comment='Tipo de violação')
    severity = Column(SQLEnum(ViolationSeverity), nullable=False, comment='Severidade da violação')
    status = Column(SQLEnum(ViolationStatus), default=ViolationStatus.OPEN, comment='Status da violação')
    
    # Contexto da violação
    violation_details = Column(JSONB, comment='Detalhes específicos da violação')
    affected_records = Column(Integer, comment='Número de registros afetados')
    detection_method = Column(String(100), comment='Método de detecção')
    
    # Datas
    detected_at = Column(DateTime(timezone=True), nullable=False, comment='Data de detecção')
    first_occurrence = Column(DateTime(timezone=True), comment='Primeira ocorrência conhecida')
    last_occurrence = Column(DateTime(timezone=True), comment='Última ocorrência')
    
    # Resolução
    assigned_to = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Responsável pela resolução')
    resolution_notes = Column(Text, comment='Notas sobre a resolução')
    resolved_at = Column(DateTime(timezone=True), comment='Data de resolução')
    
    # Impacto
    business_impact = Column(Text, comment='Impacto no negócio')
    risk_level = Column(String(50), comment='Nível de risco')
    
    # Relacionamentos
    policy = relationship("GovernancePolicy", back_populates="violations")
    entity = relationship("Entity")
    assignee = relationship("User", foreign_keys=[assigned_to])

class ComplianceReport(Base):
    """Relatórios de compliance regulatório"""
    __tablename__ = 'compliance_reports'
    __table_args__ = {'extend_existing': True}
    
    report_name = Column(String(255), nullable=False, comment='Nome do relatório')
    regulation = Column(String(100), nullable=False, comment='Regulamentação (LGPD, GDPR, SOX, etc.)')
    report_period_start = Column(DateTime(timezone=True), nullable=False, comment='Início do período')
    report_period_end = Column(DateTime(timezone=True), nullable=False, comment='Fim do período')
    
    # Status geral de compliance
    overall_status = Column(SQLEnum(ComplianceStatus), nullable=False, comment='Status geral de compliance')
    compliance_score = Column(Float, comment='Score de compliance (0-100)')
    
    # Métricas de compliance
    total_policies = Column(Integer, comment='Total de políticas avaliadas')
    compliant_policies = Column(Integer, comment='Políticas em compliance')
    violations_count = Column(Integer, comment='Número de violações')
    critical_violations = Column(Integer, comment='Violações críticas')
    
    # Detalhes do relatório
    findings = Column(JSONB, comment='Achados detalhados do relatório')
    recommendations = Column(JSONB, comment='Recomendações de melhoria')
    action_items = Column(JSONB, comment='Itens de ação necessários')
    
    # Evidências
    evidence_files = Column(JSONB, comment='Arquivos de evidência')
    audit_trail = Column(JSONB, comment='Trilha de auditoria')
    
    # Metadados
    generated_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Usuário que gerou o relatório')
    reviewed_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que revisou')
    approved_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que aprovou')
    
    # Status do relatório
    is_final = Column(Boolean, default=False, comment='Relatório finalizado')
    submitted_to_regulator = Column(Boolean, default=False, comment='Submetido ao regulador')
    submission_date = Column(DateTime(timezone=True), comment='Data de submissão')
    
    # Relacionamentos
    generator = relationship("User", foreign_keys=[generated_by])
    reviewer = relationship("User", foreign_keys=[reviewed_by])
    approver = relationship("User", foreign_keys=[approved_by])

