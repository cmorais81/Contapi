"""
Modelos de Notificações
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class NotificationType(Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    SUCCESS = "success"
    ALERT = "alert"

class NotificationStatus(Enum):
    PENDING = "pending"
    SENT = "sent"
    DELIVERED = "delivered"
    FAILED = "failed"
    READ = "read"

class NotificationChannel(Enum):
    EMAIL = "email"
    SMS = "sms"
    SLACK = "slack"
    TEAMS = "teams"
    WEBHOOK = "webhook"
    IN_APP = "in_app"

class AlertSeverity(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class AlertStatus(Enum):
    ACTIVE = "active"
    ACKNOWLEDGED = "acknowledged"
    RESOLVED = "resolved"
    SUPPRESSED = "suppressed"

class Notification(Base):
    """Notificações do sistema"""
    __tablename__ = 'notifications'
    __table_args__ = {'extend_existing': True}
    
    recipient_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Destinatário')
    
    # Conteúdo da notificação
    title = Column(String(255), nullable=False, comment='Título da notificação')
    message = Column(Text, nullable=False, comment='Mensagem da notificação')
    notification_type = Column(SQLEnum(NotificationType), nullable=False, comment='Tipo da notificação')
    
    # Status e entrega
    status = Column(SQLEnum(NotificationStatus), default=NotificationStatus.PENDING, comment='Status da notificação')
    channel = Column(SQLEnum(NotificationChannel), nullable=False, comment='Canal de entrega')
    
    # Metadados
    source_entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), comment='Entidade relacionada')
    source_type = Column(String(100), comment='Tipo da fonte (quality_rule, policy, workflow)')
    source_id = Column(UUID(as_uuid=True), comment='ID da fonte específica')
    
    # Configurações
    priority = Column(String(50), default='normal', comment='Prioridade da notificação')
    expires_at = Column(DateTime(timezone=True), comment='Data de expiração')
    
    # Dados adicionais
    notification_metadata = Column(JSONB, comment='Metadados adicionais')
    action_url = Column(String(500), comment='URL para ação relacionada')
    
    # Controle de entrega
    sent_at = Column(DateTime(timezone=True), comment='Data de envio')
    delivered_at = Column(DateTime(timezone=True), comment='Data de entrega')
    read_at = Column(DateTime(timezone=True), comment='Data de leitura')
    
    # Relacionamentos
    recipient = relationship("User", foreign_keys=[recipient_id])
    source_entity = relationship("Entity")

class NotificationPreference(Base):
    """Preferências de notificação dos usuários"""
    __tablename__ = 'notification_preferences'
    __table_args__ = {'extend_existing': True}
    
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Usuário')
    
    # Configurações por tipo
    info_enabled = Column(Boolean, default=True, comment='Notificações informativas')
    warning_enabled = Column(Boolean, default=True, comment='Notificações de aviso')
    error_enabled = Column(Boolean, default=True, comment='Notificações de erro')
    success_enabled = Column(Boolean, default=True, comment='Notificações de sucesso')
    alert_enabled = Column(Boolean, default=True, comment='Alertas')
    
    # Configurações por canal
    email_enabled = Column(Boolean, default=True, comment='Notificações por email')
    sms_enabled = Column(Boolean, default=False, comment='Notificações por SMS')
    slack_enabled = Column(Boolean, default=False, comment='Notificações no Slack')
    teams_enabled = Column(Boolean, default=False, comment='Notificações no Teams')
    in_app_enabled = Column(Boolean, default=True, comment='Notificações in-app')
    
    # Configurações de frequência
    digest_frequency = Column(String(50), default='daily', comment='Frequência do digest (immediate, hourly, daily, weekly)')
    quiet_hours_start = Column(String(5), comment='Início do período silencioso (HH:MM)')
    quiet_hours_end = Column(String(5), comment='Fim do período silencioso (HH:MM)')
    
    # Configurações específicas
    quality_alerts = Column(Boolean, default=True, comment='Alertas de qualidade')
    policy_violations = Column(Boolean, default=True, comment='Violações de política')
    workflow_updates = Column(Boolean, default=True, comment='Atualizações de workflow')
    
    # Contatos alternativos
    alternative_email = Column(String(255), comment='Email alternativo')
    phone_number = Column(String(20), comment='Número de telefone')
    slack_user_id = Column(String(100), comment='ID do usuário no Slack')
    teams_user_id = Column(String(100), comment='ID do usuário no Teams')
    
    # Relacionamentos
    user = relationship("User")

class AlertRule(Base):
    """Regras para geração de alertas"""
    __tablename__ = 'alert_rules'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome da regra de alerta')
    description = Column(Text, comment='Descrição da regra')
    
    # Configuração da regra
    rule_definition = Column(JSONB, nullable=False, comment='Definição da regra em JSON')
    trigger_conditions = Column(JSONB, comment='Condições para disparo')
    
    # Configurações do alerta
    severity = Column(SQLEnum(AlertSeverity), nullable=False, comment='Severidade do alerta')
    alert_template = Column(JSONB, comment='Template da mensagem de alerta')
    
    # Escopo
    entity_filters = Column(JSONB, comment='Filtros de entidades')
    attribute_filters = Column(JSONB, comment='Filtros de atributos')
    
    # Configurações de disparo
    is_active = Column(Boolean, default=True, comment='Regra ativa')
    cooldown_minutes = Column(Integer, default=60, comment='Período de cooldown em minutos')
    max_alerts_per_hour = Column(Integer, comment='Máximo de alertas por hora')
    
    # Destinatários
    recipients = Column(JSONB, comment='Lista de destinatários')
    escalation_rules = Column(JSONB, comment='Regras de escalação')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Criador da regra')
    last_triggered = Column(DateTime(timezone=True), comment='Último disparo')
    trigger_count = Column(Integer, default=0, comment='Número de disparos')
    
    # Relacionamentos
    creator = relationship("User", foreign_keys=[created_by])

