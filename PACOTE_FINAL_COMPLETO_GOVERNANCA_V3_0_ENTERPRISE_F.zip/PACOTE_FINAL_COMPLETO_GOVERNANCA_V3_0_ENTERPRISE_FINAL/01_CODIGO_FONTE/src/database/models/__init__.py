"""
Modelos SQLAlchemy - API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

# Modelos de Autenticação e Segurança
from .auth import User, UserSession, Role, UserRole, ApiKey

# Modelos de Auditoria e Logs
from .audit import AuditLog, AuditRule, AuditLogArchive, AuditLogRetentionPolicy, ComplianceReport, DataAccessLog

# Modelos de Rate Limiting
from .rate_limiting import RateLimitPolicy, RateLimitViolation, RateLimitCounter, RateLimitWhitelist, RateLimitUserOverride

# Modelos de Sistema e Performance
from .system import QueryPerformanceLog, SystemMetrics, LoadBalancerMetrics, SystemHealth

# Modelos de Contratos de Dados
from .contracts import DataContract, ContractVersion, ContractApproval

# Modelos de Contract Export
from .contract_export import ContractExport, ContractExportLog, ContractExportTemplate

# Modelos de Domínios
from .domains import Domain

# Modelos de Entidades e Catálogo
from .entities import Entity, EntityAttribute, EntityRelationship, EntityTag, EntityUsageStats, CatalogEntry

# Modelos de Qualidade de Dados
from .quality import QualityRule, QualityMetric, QualityIssue, QualityReport, QualityThreshold, QualityProfile

# Modelos de Lineage
from .lineage import DataLineage, LineageAttribute, ImpactAnalysis

# Modelos de Políticas
from .policies import GovernancePolicy, PolicyViolation, ComplianceReport

# Modelos de Stewardship
from .stewardship import DataSteward, StewardAssignment, StewardActivity

# Modelos de Tags
from .tags import Tag, TagHierarchy, TagCategory
from .entities import EntityTag

# Modelos de Workflows
from .workflows import WorkflowDefinition, WorkflowInstance, WorkflowStep

# Modelos de Notificações
from .notifications import Notification, NotificationPreference, AlertRule

__all__ = [
    # Autenticação
    'User', 'UserSession', 'Role', 'UserRole', 'ApiKey',
    
    # Auditoria
    'AuditLog', 'AuditRule', 'AuditLogArchive', 'AuditLogRetentionPolicy', 'ComplianceReport', 'DataAccessLog',
    
    # Rate Limiting
    'RateLimitPolicy', 'RateLimitViolation', 'RateLimitCounter', 'RateLimitWhitelist', 'RateLimitUserOverride',
    
    # Sistema
    'QueryPerformanceLog', 'SystemMetrics', 'LoadBalancerMetrics', 'SystemHealth', 'SystemConfiguration', 'SystemAlert',
    
    # Contratos
    'DataContract', 'ContractVersion', 'ContractApproval',
    
    # Contract Export
    'ContractExport', 'ContractExportLog', 'ContractExportTemplate',
    
    # Domínios
    'Domain',
    
    # Entidades
    'Entity', 'EntityAttribute', 'EntityRelationship', 'EntityTag', 'EntityUsageStats', 'CatalogEntry',
    
    # Qualidade
    'QualityRule', 'QualityMetric', 'QualityIssue', 'QualityReport', 'QualityThreshold', 'QualityProfile',
    
    # Lineage
    'DataLineage', 'LineageAttribute', 'ImpactAnalysis',
    
    # Políticas
    'GovernancePolicy', 'PolicyViolation', 'ComplianceReport',
    
    # Stewardship
    'DataSteward', 'StewardAssignment', 'StewardActivity',
    
    # Tags
    'Tag', 'TagHierarchy', 'TagCategory', 'EntityTag',
    
    # Workflows
    'WorkflowDefinition', 'WorkflowInstance', 'WorkflowStep',
    
    # Notificações
    'Notification', 'NotificationPreference', 'AlertRule'
]

