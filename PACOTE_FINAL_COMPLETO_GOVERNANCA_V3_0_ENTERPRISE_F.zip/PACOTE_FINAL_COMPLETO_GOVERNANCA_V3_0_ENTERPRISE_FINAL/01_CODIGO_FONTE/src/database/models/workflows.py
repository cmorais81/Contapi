"""
Modelos de Workflows
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum, Float
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class WorkflowStatus(Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    DEPRECATED = "deprecated"

class InstanceStatus(Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"

class StepStatus(Enum):
    WAITING = "waiting"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    CANCELLED = "cancelled"

class StepType(Enum):
    MANUAL = "manual"
    AUTOMATED = "automated"
    APPROVAL = "approval"
    NOTIFICATION = "notification"
    VALIDATION = "validation"
    TRANSFORMATION = "transformation"

class WorkflowDefinition(Base):
    """Definições de workflows de governança"""
    __tablename__ = 'workflow_definitions'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome do workflow')
    description = Column(Text, comment='Descrição do workflow')
    version = Column(String(50), nullable=False, comment='Versão do workflow')
    status = Column(SQLEnum(WorkflowStatus), default=WorkflowStatus.DRAFT, comment='Status do workflow')
    
    # Configuração do workflow
    workflow_definition = Column(JSONB, nullable=False, comment='Definição completa do workflow')
    trigger_conditions = Column(JSONB, comment='Condições para disparo automático')
    input_schema = Column(JSONB, comment='Schema dos dados de entrada')
    output_schema = Column(JSONB, comment='Schema dos dados de saída')
    
    # Configurações de execução
    max_concurrent_instances = Column(Integer, default=1, comment='Máximo de instâncias simultâneas')
    timeout_minutes = Column(Integer, comment='Timeout em minutos')
    retry_policy = Column(JSONB, comment='Política de retry')
    
    # Metadados
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False, comment='Criador do workflow')
    category = Column(String(100), comment='Categoria do workflow')
    tags = Column(JSONB, comment='Tags associadas')
    
    # Configurações de notificação
    notification_settings = Column(JSONB, comment='Configurações de notificação')
    escalation_rules = Column(JSONB, comment='Regras de escalação')
    
    # Relacionamentos
    creator = relationship("User", foreign_keys=[created_by])
    instances = relationship("WorkflowInstance", back_populates="definition", cascade="all, delete-orphan")

class WorkflowInstance(Base):
    """Instâncias de execução de workflows"""
    __tablename__ = 'workflow_instances'
    __table_args__ = {'extend_existing': True}
    
    definition_id = Column(UUID(as_uuid=True), ForeignKey('workflow_definitions.id'), nullable=False)
    
    # Status e execução
    status = Column(SQLEnum(InstanceStatus), default=InstanceStatus.PENDING, comment='Status da instância')
    started_at = Column(DateTime(timezone=True), comment='Data de início')
    completed_at = Column(DateTime(timezone=True), comment='Data de conclusão')
    
    # Dados de entrada e saída
    input_data = Column(JSONB, comment='Dados de entrada')
    output_data = Column(JSONB, comment='Dados de saída')
    context_data = Column(JSONB, comment='Dados de contexto')
    
    # Execução
    current_step_id = Column(UUID(as_uuid=True), ForeignKey('workflow_steps.id'), comment='Step atual')
    progress_percentage = Column(Float, default=0, comment='Percentual de progresso')
    
    # Metadados
    triggered_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que disparou')
    trigger_event = Column(String(255), comment='Evento que disparou')
    priority = Column(String(50), default='normal', comment='Prioridade de execução')
    
    # Erro e debugging
    error_message = Column(Text, comment='Mensagem de erro se houver')
    execution_log = Column(JSONB, comment='Log de execução')
    
    # Relacionamentos
    definition = relationship("WorkflowDefinition", back_populates="instances")
    current_step = relationship("WorkflowStep", foreign_keys=[current_step_id])
    steps = relationship("WorkflowStep", foreign_keys="WorkflowStep.instance_id", back_populates="instance", cascade="all, delete-orphan")
    trigger_user = relationship("User", foreign_keys=[triggered_by])

class WorkflowStep(Base):
    """Steps individuais de workflows"""
    __tablename__ = 'workflow_steps'
    __table_args__ = {'extend_existing': True}
    
    instance_id = Column(UUID(as_uuid=True), ForeignKey('workflow_instances.id'), nullable=False)
    
    # Identificação do step
    step_name = Column(String(255), nullable=False, comment='Nome do step')
    step_type = Column(SQLEnum(StepType), nullable=False, comment='Tipo do step')
    step_order = Column(Integer, nullable=False, comment='Ordem de execução')
    
    # Status e execução
    status = Column(SQLEnum(StepStatus), default=StepStatus.WAITING, comment='Status do step')
    started_at = Column(DateTime(timezone=True), comment='Data de início')
    completed_at = Column(DateTime(timezone=True), comment='Data de conclusão')
    
    # Configuração do step
    step_configuration = Column(JSONB, comment='Configuração específica do step')
    input_data = Column(JSONB, comment='Dados de entrada do step')
    output_data = Column(JSONB, comment='Dados de saída do step')
    
    # Execução
    assigned_to = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário responsável')
    due_date = Column(DateTime(timezone=True), comment='Data limite')
    estimated_duration = Column(Integer, comment='Duração estimada em minutos')
    actual_duration = Column(Integer, comment='Duração real em minutos')
    
    # Dependências
    depends_on_steps = Column(JSONB, comment='Steps dos quais depende')
    blocking_steps = Column(JSONB, comment='Steps que bloqueia')
    
    # Resultado
    result_data = Column(JSONB, comment='Dados do resultado')
    error_details = Column(Text, comment='Detalhes do erro se houver')
    retry_count = Column(Integer, default=0, comment='Número de tentativas')
    
    # Relacionamentos
    instance = relationship("WorkflowInstance", foreign_keys=[instance_id], back_populates="steps")
    assignee = relationship("User", foreign_keys=[assigned_to])

