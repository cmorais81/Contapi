"""
Modelo de Analytics e Busca
API de Governança de Dados V2.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, DateTime, ForeignKey, JSON, Integer, Float
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid

from src.database.base import BaseModel

class SearchAnalytic(BaseModel):
    """
    Modelo para Analytics de Busca
    
    Registra e analisa padrões de busca, popularidade de entidades
    e comportamento dos usuários no catálogo de dados.
    """
    __tablename__ = 'search_analytics'
    __table_args__ = {'extend_existing': True}
    
    # Identificação
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    session_id = Column(String(255), index=True, comment="ID da sessão de busca")
    user_id = Column(String(255), index=True, comment="ID do usuário")
    
    # Busca
    search_query = Column(Text, nullable=False, comment="Termo de busca")
    search_type = Column(String(50), nullable=False, index=True,
                        comment="Tipo: entity, attribute, glossary, lineage, quality")
    search_filters = Column(JSON, comment="Filtros aplicados na busca")
    
    # Contexto
    search_context = Column(String(100), comment="Contexto da busca")
    user_role = Column(String(100), comment="Papel do usuário")
    department = Column(String(100), comment="Departamento do usuário")
    
    # Resultados
    results_count = Column(Integer, comment="Número de resultados")
    results_returned = Column(JSON, comment="IDs dos resultados retornados")
    clicked_results = Column(JSON, comment="Resultados clicados pelo usuário")
    
    # Métricas de qualidade
    search_success = Column(Boolean, comment="Busca foi bem-sucedida")
    user_satisfaction = Column(Integer, comment="Satisfação do usuário (1-5)")
    result_relevance = Column(Float, comment="Relevância média dos resultados")
    
    # Timing
    search_duration_ms = Column(Integer, comment="Duração da busca em ms")
    time_to_first_click = Column(Integer, comment="Tempo até primeiro clique (ms)")
    session_duration = Column(Integer, comment="Duração da sessão (ms)")
    
    # Localização e dispositivo
    ip_address = Column(String(45), comment="Endereço IP")
    user_agent = Column(Text, comment="User agent do navegador")
    device_type = Column(String(50), comment="Tipo de dispositivo")
    browser = Column(String(100), comment="Navegador utilizado")
    
    # Refinamentos
    refinements_applied = Column(JSON, comment="Refinamentos aplicados")
    filters_used = Column(JSON, comment="Filtros utilizados")
    sort_criteria = Column(String(100), comment="Critério de ordenação")
    
    # Comportamento
    page_views = Column(Integer, default=1, comment="Páginas visualizadas")
    bounce_rate = Column(Boolean, comment="Usuário saiu sem interagir")
    conversion = Column(Boolean, comment="Usuário encontrou o que procurava")
    
    # Entidades relacionadas
    entity_id = Column(UUID(as_uuid=True), comment="Entidade principal acessada")
    related_entities = Column(JSON, comment="Entidades relacionadas visualizadas")
    
    # Feedback
    feedback_rating = Column(Integer, comment="Avaliação do usuário (1-5)")
    feedback_comment = Column(Text, comment="Comentário do usuário")
    reported_issues = Column(JSON, comment="Problemas reportados")
    
    # Categorização automática
    intent_category = Column(String(100), comment="Categoria de intenção detectada")
    search_complexity = Column(String(50), comment="Complexidade: simple, medium, complex")
    business_value = Column(String(50), comment="Valor de negócio: low, medium, high")
    
    # Métricas de performance
    cache_hit = Column(Boolean, comment="Resultado veio do cache")
    database_queries = Column(Integer, comment="Número de queries no banco")
    external_api_calls = Column(Integer, comment="Chamadas para APIs externas")
    
    # Auditoria automática (herdada de BaseModel)
    # created_at, updated_at, created_by, updated_by
    
    def __repr__(self):
        return f"<SearchAnalytic(id={self.id}, query='{self.search_query}', type='{self.search_type}')>"
    
    def to_dict(self):
        """Converte o modelo para dicionário"""
        return {
            'id': str(self.id),
            'session_id': self.session_id,
            'user_id': self.user_id,
            'search_query': self.search_query,
            'search_type': self.search_type,
            'search_filters': self.search_filters,
            'search_context': self.search_context,
            'user_role': self.user_role,
            'department': self.department,
            'results_count': self.results_count,
            'results_returned': self.results_returned,
            'clicked_results': self.clicked_results,
            'search_success': self.search_success,
            'user_satisfaction': self.user_satisfaction,
            'result_relevance': self.result_relevance,
            'search_duration_ms': self.search_duration_ms,
            'time_to_first_click': self.time_to_first_click,
            'session_duration': self.session_duration,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'device_type': self.device_type,
            'browser': self.browser,
            'refinements_applied': self.refinements_applied,
            'filters_used': self.filters_used,
            'sort_criteria': self.sort_criteria,
            'page_views': self.page_views,
            'bounce_rate': self.bounce_rate,
            'conversion': self.conversion,
            'entity_id': str(self.entity_id) if self.entity_id else None,
            'related_entities': self.related_entities,
            'feedback_rating': self.feedback_rating,
            'feedback_comment': self.feedback_comment,
            'reported_issues': self.reported_issues,
            'intent_category': self.intent_category,
            'search_complexity': self.search_complexity,
            'business_value': self.business_value,
            'cache_hit': self.cache_hit,
            'database_queries': self.database_queries,
            'external_api_calls': self.external_api_calls,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }
    
    @classmethod
    def get_search_types(cls):
        """Retorna tipos de busca disponíveis"""
        return [
            'entity',
            'attribute', 
            'glossary',
            'lineage',
            'quality',
            'contract',
            'policy',
            'steward',
            'domain',
            'tag'
        ]
    
    @classmethod
    def get_intent_categories(cls):
        """Retorna categorias de intenção"""
        return [
            'data_discovery',
            'data_understanding',
            'compliance_check',
            'quality_assessment',
            'lineage_analysis',
            'impact_analysis',
            'data_profiling',
            'business_context',
            'technical_details',
            'troubleshooting'
        ]
    
    @classmethod
    def get_complexity_levels(cls):
        """Retorna níveis de complexidade"""
        return [
            'simple',    # Busca simples por termo
            'medium',    # Busca com filtros
            'complex'    # Busca avançada com múltiplos critérios
        ]
    
    def mark_successful(self, satisfaction_rating: int = None):
        """Marca busca como bem-sucedida"""
        self.search_success = True
        self.conversion = True
        if satisfaction_rating:
            self.user_satisfaction = satisfaction_rating
    
    def mark_failed(self, reason: str = None):
        """Marca busca como falhada"""
        self.search_success = False
        self.conversion = False
        if reason:
            if not self.reported_issues:
                self.reported_issues = []
            self.reported_issues.append({
                'type': 'search_failure',
                'reason': reason,
                'timestamp': datetime.now().isoformat()
            })
    
    def add_click(self, result_id: str, position: int):
        """Adiciona clique em resultado"""
        if not self.clicked_results:
            self.clicked_results = []
        
        self.clicked_results.append({
            'result_id': result_id,
            'position': position,
            'timestamp': datetime.now().isoformat()
        })
    
    def calculate_relevance_score(self):
        """Calcula score de relevância baseado em cliques"""
        if not self.clicked_results or not self.results_count:
            return 0.0
        
        # Score baseado na posição dos cliques
        total_score = 0
        for click in self.clicked_results:
            position = click.get('position', 1)
            # Quanto menor a posição, maior o score
            score = 1.0 / position
            total_score += score
        
        # Normalizar pelo número de resultados
        self.result_relevance = total_score / self.results_count
        return self.result_relevance
    
    def detect_intent(self):
        """Detecta intenção baseada na query"""
        query_lower = self.search_query.lower()
        
        # Palavras-chave para diferentes intenções
        intent_keywords = {
            'data_discovery': ['find', 'search', 'discover', 'locate', 'where'],
            'data_understanding': ['what', 'definition', 'meaning', 'explain'],
            'compliance_check': ['compliance', 'gdpr', 'lgpd', 'regulation'],
            'quality_assessment': ['quality', 'validation', 'error', 'issue'],
            'lineage_analysis': ['lineage', 'source', 'origin', 'flow'],
            'impact_analysis': ['impact', 'downstream', 'affected', 'dependency'],
            'data_profiling': ['profile', 'statistics', 'distribution', 'summary'],
            'business_context': ['business', 'owner', 'purpose', 'usage'],
            'technical_details': ['schema', 'type', 'format', 'structure'],
            'troubleshooting': ['problem', 'issue', 'error', 'fix', 'debug']
        }
        
        # Detectar intenção baseada em palavras-chave
        for intent, keywords in intent_keywords.items():
            if any(keyword in query_lower for keyword in keywords):
                self.intent_category = intent
                return intent
        
        # Intenção padrão
        self.intent_category = 'data_discovery'
        return 'data_discovery'
    
    def calculate_complexity(self):
        """Calcula complexidade da busca"""
        complexity_score = 0
        
        # Fatores de complexidade
        if len(self.search_query.split()) > 3:
            complexity_score += 1
        
        if self.search_filters and len(self.search_filters) > 0:
            complexity_score += 1
        
        if self.refinements_applied and len(self.refinements_applied) > 0:
            complexity_score += 1
        
        if self.sort_criteria and self.sort_criteria != 'relevance':
            complexity_score += 1
        
        # Determinar nível
        if complexity_score == 0:
            self.search_complexity = 'simple'
        elif complexity_score <= 2:
            self.search_complexity = 'medium'
        else:
            self.search_complexity = 'complex'
        
        return self.search_complexity

