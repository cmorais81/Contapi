"""
Modelos de Contratos de Dados
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, DateTime, ForeignKey, Enum as SQLEnum
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class ContractStatus(Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"

class ApprovalStatus(Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    CANCELLED = "cancelled"

class DataContract(Base):
    """Contratos de dados com definições de SLA e qualidade"""
    __tablename__ = 'data_contracts'
    __table_args__ = {'extend_existing': True}
    
    name = Column(String(255), nullable=False, comment='Nome do contrato de dados')
    description = Column(Text, comment='Descrição detalhada do contrato')
    version = Column(String(50), nullable=False, comment='Versão do contrato')
    status = Column(SQLEnum(ContractStatus), default=ContractStatus.DRAFT, comment='Status do contrato')
    
    # Definições do contrato
    schema_definition = Column(JSONB, comment='Definição do schema em formato JSON')
    sla_definition = Column(JSONB, comment='Definições de SLA em formato JSON')
    quality_requirements = Column(JSONB, comment='Requisitos de qualidade')
    data_classification = Column(String(100), comment='Classificação dos dados (público, interno, confidencial)')
    
    # Metadados
    owner_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Proprietário do contrato')
    domain = Column(String(255), comment='Domínio de dados')
    tags = Column(JSONB, comment='Tags associadas ao contrato')
    
    # Configurações
    is_template = Column(Boolean, default=False, comment='Indica se é um template')
    parent_contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts.id'), comment='Contrato pai se derivado')
    
    # Datas importantes
    effective_date = Column(DateTime(timezone=True), comment='Data de vigência')
    expiration_date = Column(DateTime(timezone=True), comment='Data de expiração')
    
    # Relacionamentos
    owner = relationship("User", foreign_keys=[owner_id])
    parent_contract = relationship("DataContract", remote_side="DataContract.id")
    versions = relationship("ContractVersion", back_populates="contract", cascade="all, delete-orphan")
    approvals = relationship("ContractApproval", back_populates="contract", cascade="all, delete-orphan")
    exports = relationship("ContractExport", back_populates="contract", cascade="all, delete-orphan")

class ContractVersion(Base):
    """Histórico de versões dos contratos de dados"""
    __tablename__ = 'contract_versions'
    __table_args__ = {'extend_existing': True}
    
    contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts.id'), nullable=False)
    version_number = Column(String(50), nullable=False, comment='Número da versão')
    changes_summary = Column(Text, comment='Resumo das mudanças')
    schema_diff = Column(JSONB, comment='Diferenças no schema')
    sla_diff = Column(JSONB, comment='Diferenças no SLA')
    
    # Metadados da versão
    created_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    is_current = Column(Boolean, default=False, comment='Indica se é a versão atual')
    migration_notes = Column(Text, comment='Notas sobre migração')
    rollback_plan = Column(Text, comment='Plano de rollback')
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="versions")
    creator = relationship("User", foreign_keys=[created_by])

class ContractApproval(Base):
    """Processo de aprovação de contratos"""
    __tablename__ = 'contract_approvals'
    __table_args__ = {'extend_existing': True}
    
    contract_id = Column(UUID(as_uuid=True), ForeignKey('data_contracts.id'), nullable=False)
    approver_id = Column(UUID(as_uuid=True), ForeignKey('users.id'), nullable=False)
    status = Column(SQLEnum(ApprovalStatus), default=ApprovalStatus.PENDING, comment='Status da aprovação')
    
    # Detalhes da aprovação
    approval_type = Column(String(100), comment='Tipo de aprovação (técnica, negócio, compliance)')
    comments = Column(Text, comment='Comentários do aprovador')
    conditions = Column(JSONB, comment='Condições para aprovação')
    
    # Datas
    requested_at = Column(DateTime(timezone=True), nullable=False, comment='Data da solicitação')
    responded_at = Column(DateTime(timezone=True), comment='Data da resposta')
    expires_at = Column(DateTime(timezone=True), comment='Data limite para aprovação')
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="approvals")
    approver = relationship("User", foreign_keys=[approver_id])

