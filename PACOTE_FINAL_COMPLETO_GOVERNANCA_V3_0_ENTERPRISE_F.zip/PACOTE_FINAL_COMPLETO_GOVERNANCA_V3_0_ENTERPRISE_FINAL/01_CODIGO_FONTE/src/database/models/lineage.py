"""
Modelos de Lineage de Dados
API de Governança de Dados V1.9
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from sqlalchemy import Column, String, Text, Boolean, Integer, DateTime, ForeignKey, Enum as SQLEnum, Float
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
from enum import Enum
from ..base import Base

class LineageType(Enum):
    DIRECT = "direct"
    DERIVED = "derived"
    AGGREGATED = "aggregated"
    TRANSFORMED = "transformed"
    FILTERED = "filtered"
    JOINED = "joined"

class LineageDirection(Enum):
    UPSTREAM = "upstream"
    DOWNSTREAM = "downstream"
    BIDIRECTIONAL = "bidirectional"

class ImpactLevel(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class DataLineage(Base):
    """Relacionamentos de lineage entre entidades de dados"""
    __tablename__ = 'data_lineage'
    __table_args__ = {'extend_existing': True}
    
    source_entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False, comment='Entidade de origem')
    target_entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False, comment='Entidade de destino')
    
    # Tipo e direção do lineage
    lineage_type = Column(SQLEnum(LineageType), nullable=False, comment='Tipo de relacionamento de lineage')
    direction = Column(SQLEnum(LineageDirection), default=LineageDirection.DOWNSTREAM, comment='Direção do lineage')
    
    # Detalhes do relacionamento
    transformation_logic = Column(Text, comment='Lógica de transformação aplicada')
    sql_query = Column(Text, comment='Query SQL que estabelece o relacionamento')
    job_name = Column(String(255), comment='Nome do job/processo que cria o relacionamento')
    
    # Metadados técnicos
    confidence_score = Column(Float, comment='Confiança na detecção do lineage (0-100)')
    is_automatic = Column(Boolean, default=False, comment='Detectado automaticamente')
    last_verified = Column(DateTime(timezone=True), comment='Última verificação do lineage')
    
    # Contexto de execução
    execution_context = Column(JSONB, comment='Contexto de execução (spark job, pipeline, etc.)')
    frequency = Column(String(100), comment='Frequência de execução')
    
    # Status e qualidade
    is_active = Column(Boolean, default=True, comment='Lineage ativo')
    quality_score = Column(Float, comment='Score de qualidade do lineage')
    
    # Relacionamentos
    source_entity = relationship("Entity", foreign_keys=[source_entity_id])
    target_entity = relationship("Entity", foreign_keys=[target_entity_id])
    attributes = relationship("LineageAttribute", back_populates="lineage", cascade="all, delete-orphan")

class LineageAttribute(Base):
    """Lineage específico de atributos/colunas"""
    __tablename__ = 'lineage_attributes'
    __table_args__ = {'extend_existing': True}
    
    lineage_id = Column(UUID(as_uuid=True), ForeignKey('data_lineage.id'), nullable=False)
    source_attribute = Column(String(255), nullable=False, comment='Nome do atributo de origem')
    target_attribute = Column(String(255), nullable=False, comment='Nome do atributo de destino')
    
    # Transformação específica
    transformation_rule = Column(Text, comment='Regra de transformação específica')
    transformation_function = Column(String(255), comment='Função aplicada (SUM, AVG, CONCAT, etc.)')
    
    # Qualidade da transformação
    data_quality_impact = Column(Float, comment='Impacto na qualidade dos dados')
    completeness_ratio = Column(Float, comment='Razão de completude na transformação')
    
    # Metadados
    is_key_field = Column(Boolean, default=False, comment='Campo chave na transformação')
    business_logic = Column(Text, comment='Lógica de negócio aplicada')
    
    # Relacionamentos
    lineage = relationship("DataLineage", back_populates="attributes")

class ImpactAnalysis(Base):
    """Análise de impacto de mudanças em dados"""
    __tablename__ = 'impact_analysis'
    __table_args__ = {'extend_existing': True}
    
    entity_id = Column(UUID(as_uuid=True), ForeignKey('entities.id'), nullable=False, comment='Entidade analisada')
    analysis_type = Column(String(100), nullable=False, comment='Tipo de análise (schema_change, data_quality, etc.)')
    
    # Configuração da análise
    change_description = Column(Text, comment='Descrição da mudança proposta')
    impact_scope = Column(String(100), comment='Escopo do impacto (table, database, system)')
    
    # Resultados da análise
    affected_entities = Column(JSONB, comment='Entidades afetadas pela mudança')
    impact_level = Column(SQLEnum(ImpactLevel), comment='Nível de impacto')
    estimated_effort = Column(Integer, comment='Esforço estimado em horas')
    
    # Entidades downstream afetadas
    downstream_count = Column(Integer, default=0, comment='Número de entidades downstream afetadas')
    critical_dependencies = Column(JSONB, comment='Dependências críticas identificadas')
    
    # Recomendações
    recommendations = Column(JSONB, comment='Recomendações para mitigar impacto')
    migration_strategy = Column(Text, comment='Estratégia de migração sugerida')
    rollback_plan = Column(Text, comment='Plano de rollback')
    
    # Metadados da análise
    analyzed_by = Column(UUID(as_uuid=True), ForeignKey('users.id'), comment='Usuário que executou a análise')
    analysis_date = Column(DateTime(timezone=True), nullable=False, comment='Data da análise')
    is_approved = Column(Boolean, default=False, comment='Análise aprovada')
    
    # Relacionamentos
    entity = relationship("Entity")
    analyzer = relationship("User", foreign_keys=[analyzed_by])

