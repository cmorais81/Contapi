"""
Modelo de Contract Export
API de Governança de Dados V3.0
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
Organização: F1rst
"""

from datetime import datetime
from typing import Optional, Dict, Any
from sqlalchemy import Column, Integer, String, DateTime, Text, Boolean, ForeignKey, JSON
from sqlalchemy.orm import relationship
from .base import Base


class ContractExport(Base):
    """
    Modelo para gerenciar exports de contratos
    Rastreia todas as exportações de contratos para Git/CI-CD
    """
    __tablename__ = "contract_exports"
    
    # Identificação
    id = Column(Integer, primary_key=True, index=True)
    contract_id = Column(Integer, ForeignKey("contracts.id"), nullable=False, index=True)
    export_type = Column(String(50), nullable=False, index=True)  # git, json, yaml, ci_cd
    
    # Informações do Export
    export_format = Column(String(20), nullable=False)  # json, yaml, sql
    export_version = Column(String(20), nullable=False)  # v1.0.0, v1.1.0
    export_status = Column(String(20), nullable=False, default="pending")  # pending, success, failed
    
    # Dados do Export
    export_data = Column(JSON, nullable=True)  # Dados exportados
    export_path = Column(String(500), nullable=True)  # Caminho no repositório
    export_url = Column(String(500), nullable=True)  # URL do repositório
    export_commit_hash = Column(String(100), nullable=True)  # Hash do commit
    
    # Git Information
    git_repository = Column(String(200), nullable=True)  # Nome do repositório
    git_branch = Column(String(100), nullable=True, default="main")  # Branch
    git_commit_message = Column(Text, nullable=True)  # Mensagem do commit
    git_author = Column(String(100), nullable=True)  # Autor do commit
    
    # CI/CD Information
    pipeline_id = Column(String(100), nullable=True)  # ID do pipeline
    pipeline_status = Column(String(20), nullable=True)  # Status do pipeline
    pipeline_url = Column(String(500), nullable=True)  # URL do pipeline
    
    # Metadados
    export_metadata = Column(JSON, nullable=True)  # Metadados adicionais
    error_message = Column(Text, nullable=True)  # Mensagem de erro se falhou
    retry_count = Column(Integer, default=0)  # Número de tentativas
    
    # Auditoria
    created_by = Column(String(100), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    exported_at = Column(DateTime, nullable=True)  # Quando foi exportado com sucesso
    
    # Relacionamentos
    contract = relationship("Contract", back_populates="exports")
    
    def __repr__(self):
        return f"<ContractExport(id={self.id}, contract_id={self.contract_id}, type={self.export_type}, status={self.export_status})>"
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            "id": self.id,
            "contract_id": self.contract_id,
            "export_type": self.export_type,
            "export_format": self.export_format,
            "export_version": self.export_version,
            "export_status": self.export_status,
            "export_path": self.export_path,
            "export_url": self.export_url,
            "export_commit_hash": self.export_commit_hash,
            "git_repository": self.git_repository,
            "git_branch": self.git_branch,
            "git_commit_message": self.git_commit_message,
            "git_author": self.git_author,
            "pipeline_id": self.pipeline_id,
            "pipeline_status": self.pipeline_status,
            "pipeline_url": self.pipeline_url,
            "error_message": self.error_message,
            "retry_count": self.retry_count,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "exported_at": self.exported_at.isoformat() if self.exported_at else None
        }
    
    @property
    def is_successful(self) -> bool:
        """Verifica se o export foi bem-sucedido"""
        return self.export_status == "success"
    
    @property
    def is_pending(self) -> bool:
        """Verifica se o export está pendente"""
        return self.export_status == "pending"
    
    @property
    def is_failed(self) -> bool:
        """Verifica se o export falhou"""
        return self.export_status == "failed"
    
    def mark_as_success(self, commit_hash: Optional[str] = None, pipeline_id: Optional[str] = None):
        """Marca export como bem-sucedido"""
        self.export_status = "success"
        self.exported_at = datetime.utcnow()
        if commit_hash:
            self.export_commit_hash = commit_hash
        if pipeline_id:
            self.pipeline_id = pipeline_id
    
    def mark_as_failed(self, error_message: str):
        """Marca export como falhou"""
        self.export_status = "failed"
        self.error_message = error_message
        self.retry_count += 1
    
    def can_retry(self, max_retries: int = 3) -> bool:
        """Verifica se pode tentar novamente"""
        return self.retry_count < max_retries


class ContractExportLog(Base):
    """
    Log detalhado de exports de contratos
    Mantém histórico completo de todas as operações
    """
    __tablename__ = "contract_export_logs"
    
    # Identificação
    id = Column(Integer, primary_key=True, index=True)
    export_id = Column(Integer, ForeignKey("contract_exports.id"), nullable=False, index=True)
    
    # Informações do Log
    log_level = Column(String(20), nullable=False)  # INFO, WARNING, ERROR
    log_message = Column(Text, nullable=False)
    log_details = Column(JSON, nullable=True)  # Detalhes adicionais
    
    # Contexto
    operation = Column(String(50), nullable=True)  # git_clone, git_commit, git_push, pipeline_trigger
    step = Column(String(100), nullable=True)  # Passo específico
    duration_ms = Column(Integer, nullable=True)  # Duração em milissegundos
    
    # Auditoria
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Relacionamentos
    export = relationship("ContractExport", backref="logs")
    
    def __repr__(self):
        return f"<ContractExportLog(id={self.id}, export_id={self.export_id}, level={self.log_level})>"
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            "id": self.id,
            "export_id": self.export_id,
            "log_level": self.log_level,
            "log_message": self.log_message,
            "log_details": self.log_details,
            "operation": self.operation,
            "step": self.step,
            "duration_ms": self.duration_ms,
            "created_at": self.created_at.isoformat() if self.created_at else None
        }


class ContractExportTemplate(Base):
    """
    Templates para export de contratos
    Define formatos e estruturas padrão para diferentes tipos de export
    """
    __tablename__ = "contract_export_templates"
    
    # Identificação
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, unique=True, index=True)
    description = Column(Text, nullable=True)
    
    # Configuração do Template
    export_type = Column(String(50), nullable=False)  # git, json, yaml, ci_cd
    export_format = Column(String(20), nullable=False)  # json, yaml, sql
    template_content = Column(Text, nullable=False)  # Template Jinja2
    
    # Configurações
    default_settings = Column(JSON, nullable=True)  # Configurações padrão
    validation_rules = Column(JSON, nullable=True)  # Regras de validação
    
    # Status
    is_active = Column(Boolean, default=True, nullable=False)
    is_default = Column(Boolean, default=False, nullable=False)
    
    # Auditoria
    created_by = Column(String(100), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f"<ContractExportTemplate(id={self.id}, name={self.name}, type={self.export_type})>"
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "export_type": self.export_type,
            "export_format": self.export_format,
            "template_content": self.template_content,
            "default_settings": self.default_settings,
            "validation_rules": self.validation_rules,
            "is_active": self.is_active,
            "is_default": self.is_default,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }

