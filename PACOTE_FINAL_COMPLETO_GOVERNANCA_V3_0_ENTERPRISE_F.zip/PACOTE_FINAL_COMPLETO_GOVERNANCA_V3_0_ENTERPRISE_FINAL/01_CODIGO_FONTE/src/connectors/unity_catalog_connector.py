"""
Conector Unity Catalog (Databricks)
API de Governança de Dados V2.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import aiohttp
import asyncio
from typing import Dict, List, Any, Optional
from datetime import datetime
import logging

from .base_connector import BaseConnector, ConnectorStatus, SyncResult

logger = logging.getLogger(__name__)

class UnityCatalogConnector(BaseConnector):
    """Conector para Unity Catalog do Databricks"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.workspace_url = config.get('workspace_url')
        self.access_token = self.auth_config.get('access_token')
        self.session = None
        
    async def connect(self) -> bool:
        """Estabelece conexão com Unity Catalog"""
        try:
            self.status = ConnectorStatus.AUTHENTICATING
            
            # Criar sessão HTTP
            self.session = aiohttp.ClientSession(
                headers={
                    'Authorization': f'Bearer {self.access_token}',
                    'Content-Type': 'application/json'
                },
                timeout=aiohttp.ClientTimeout(total=30)
            )
            
            # Testar conexão
            test_result = await self.test_connection()
            
            if test_result.get('success'):
                self.status = ConnectorStatus.CONNECTED
                self.log_success("Conectado ao Unity Catalog com sucesso")
                return True
            else:
                self.status = ConnectorStatus.ERROR
                self.log_error("Falha na autenticação com Unity Catalog", test_result)
                return False
                
        except Exception as e:
            self.status = ConnectorStatus.ERROR
            self.log_error(f"Erro ao conectar com Unity Catalog: {str(e)}")
            return False
    
    async def disconnect(self) -> bool:
        """Desconecta do Unity Catalog"""
        try:
            if self.session:
                await self.session.close()
                self.session = None
            
            self.status = ConnectorStatus.DISCONNECTED
            self.log_success("Desconectado do Unity Catalog")
            return True
            
        except Exception as e:
            self.log_error(f"Erro ao desconectar: {str(e)}")
            return False
    
    async def test_connection(self) -> Dict[str, Any]:
        """Testa conexão com Unity Catalog"""
        try:
            if not self.session:
                await self.connect()
            
            # Testar com endpoint de catálogos
            url = f"{self.workspace_url}/api/2.1/unity-catalog/catalogs"
            
            async with self.session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        "success": True,
                        "status_code": response.status,
                        "catalogs_count": len(data.get('catalogs', [])),
                        "message": "Conexão com Unity Catalog bem-sucedida"
                    }
                else:
                    error_text = await response.text()
                    return {
                        "success": False,
                        "status_code": response.status,
                        "error": error_text,
                        "message": "Falha na conexão com Unity Catalog"
                    }
                    
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "message": "Erro ao testar conexão com Unity Catalog"
            }
    
    async def sync_entities(self, entity_filters: Optional[Dict] = None) -> SyncResult:
        """Sincroniza entidades do Unity Catalog"""
        result = SyncResult()
        start_time = datetime.now()
        
        try:
            self.status = ConnectorStatus.SYNCING
            
            if not self.session:
                await self.connect()
            
            # Sincronizar catálogos
            catalogs = await self._get_catalogs()
            result.entities_processed += len(catalogs)
            
            for catalog in catalogs:
                try:
                    # Sincronizar schemas do catálogo
                    schemas = await self._get_schemas(catalog['name'])
                    result.entities_processed += len(schemas)
                    
                    for schema in schemas:
                        try:
                            # Sincronizar tabelas do schema
                            tables = await self._get_tables(catalog['name'], schema['name'])
                            result.entities_processed += len(tables)
                            
                            for table in tables:
                                try:
                                    # Processar tabela
                                    await self._process_table_entity(catalog, schema, table)
                                    result.entities_created += 1
                                    
                                except Exception as e:
                                    result.entities_failed += 1
                                    result.errors.append(f"Erro ao processar tabela {table.get('name')}: {str(e)}")
                                    
                        except Exception as e:
                            result.errors.append(f"Erro ao sincronizar tabelas do schema {schema.get('name')}: {str(e)}")
                            
                except Exception as e:
                    result.errors.append(f"Erro ao sincronizar schemas do catálogo {catalog.get('name')}: {str(e)}")
            
            # Calcular tempo de execução
            end_time = datetime.now()
            result.execution_time_seconds = (end_time - start_time).total_seconds()
            
            # Determinar sucesso
            result.success = result.entities_failed == 0
            
            self.status = ConnectorStatus.CONNECTED
            self.last_sync_time = end_time
            
            self.log_success(f"Sincronização concluída: {result.entities_created} entidades criadas")
            
        except Exception as e:
            result.success = False
            result.errors.append(f"Erro geral na sincronização: {str(e)}")
            self.log_error("Erro na sincronização", {"error": str(e)})
            
        return result
    
    async def sync_metadata(self, entity_id: str) -> Dict[str, Any]:
        """Sincroniza metadados de uma entidade específica"""
        try:
            # Assumindo que entity_id é no formato catalog.schema.table
            parts = entity_id.split('.')
            if len(parts) != 3:
                raise ValueError("entity_id deve estar no formato catalog.schema.table")
            
            catalog_name, schema_name, table_name = parts
            
            # Obter metadados da tabela
            table_metadata = await self._get_table_metadata(catalog_name, schema_name, table_name)
            
            # Obter colunas da tabela
            columns = await self._get_table_columns(catalog_name, schema_name, table_name)
            
            return {
                "entity_id": entity_id,
                "metadata": table_metadata,
                "columns": columns,
                "sync_timestamp": datetime.now().isoformat(),
                "source": "unity_catalog"
            }
            
        except Exception as e:
            self.log_error(f"Erro ao sincronizar metadados de {entity_id}: {str(e)}")
            raise
    
    async def get_entity_lineage(self, entity_id: str) -> Dict[str, Any]:
        """Obtém lineage de uma entidade do Unity Catalog"""
        try:
            parts = entity_id.split('.')
            if len(parts) != 3:
                raise ValueError("entity_id deve estar no formato catalog.schema.table")
            
            catalog_name, schema_name, table_name = parts
            
            # Unity Catalog API para lineage
            url = f"{self.workspace_url}/api/2.1/unity-catalog/lineage"
            params = {
                "table_name": f"{catalog_name}.{schema_name}.{table_name}",
                "include_entity_lineage": "true"
            }
            
            async with self.session.get(url, params=params) as response:
                if response.status == 200:
                    lineage_data = await response.json()
                    return {
                        "entity_id": entity_id,
                        "upstream_tables": lineage_data.get('upstream_tables', []),
                        "downstream_tables": lineage_data.get('downstream_tables', []),
                        "lineage_timestamp": datetime.now().isoformat(),
                        "source": "unity_catalog"
                    }
                else:
                    error_text = await response.text()
                    raise Exception(f"Erro ao obter lineage: {error_text}")
                    
        except Exception as e:
            self.log_error(f"Erro ao obter lineage de {entity_id}: {str(e)}")
            raise
    
    async def get_data_quality_metrics(self, entity_id: str) -> Dict[str, Any]:
        """Obtém métricas de qualidade de dados"""
        try:
            parts = entity_id.split('.')
            if len(parts) != 3:
                raise ValueError("entity_id deve estar no formato catalog.schema.table")
            
            catalog_name, schema_name, table_name = parts
            
            # Executar queries de qualidade básicas
            quality_metrics = await self._calculate_quality_metrics(catalog_name, schema_name, table_name)
            
            return {
                "entity_id": entity_id,
                "metrics": quality_metrics,
                "calculated_at": datetime.now().isoformat(),
                "source": "unity_catalog"
            }
            
        except Exception as e:
            self.log_error(f"Erro ao obter métricas de qualidade de {entity_id}: {str(e)}")
            raise
    
    # Métodos auxiliares privados
    
    async def _get_catalogs(self) -> List[Dict]:
        """Obtém lista de catálogos"""
        url = f"{self.workspace_url}/api/2.1/unity-catalog/catalogs"
        
        async with self.session.get(url) as response:
            if response.status == 200:
                data = await response.json()
                return data.get('catalogs', [])
            else:
                raise Exception(f"Erro ao obter catálogos: {response.status}")
    
    async def _get_schemas(self, catalog_name: str) -> List[Dict]:
        """Obtém schemas de um catálogo"""
        url = f"{self.workspace_url}/api/2.1/unity-catalog/schemas"
        params = {"catalog_name": catalog_name}
        
        async with self.session.get(url, params=params) as response:
            if response.status == 200:
                data = await response.json()
                return data.get('schemas', [])
            else:
                raise Exception(f"Erro ao obter schemas: {response.status}")
    
    async def _get_tables(self, catalog_name: str, schema_name: str) -> List[Dict]:
        """Obtém tabelas de um schema"""
        url = f"{self.workspace_url}/api/2.1/unity-catalog/tables"
        params = {
            "catalog_name": catalog_name,
            "schema_name": schema_name
        }
        
        async with self.session.get(url, params=params) as response:
            if response.status == 200:
                data = await response.json()
                return data.get('tables', [])
            else:
                raise Exception(f"Erro ao obter tabelas: {response.status}")
    
    async def _get_table_metadata(self, catalog_name: str, schema_name: str, table_name: str) -> Dict:
        """Obtém metadados detalhados de uma tabela"""
        url = f"{self.workspace_url}/api/2.1/unity-catalog/tables/{catalog_name}.{schema_name}.{table_name}"
        
        async with self.session.get(url) as response:
            if response.status == 200:
                return await response.json()
            else:
                raise Exception(f"Erro ao obter metadados da tabela: {response.status}")
    
    async def _get_table_columns(self, catalog_name: str, schema_name: str, table_name: str) -> List[Dict]:
        """Obtém colunas de uma tabela"""
        table_metadata = await self._get_table_metadata(catalog_name, schema_name, table_name)
        return table_metadata.get('columns', [])
    
    async def _process_table_entity(self, catalog: Dict, schema: Dict, table: Dict):
        """Processa uma entidade tabela para sincronização"""
        # TODO: Implementar criação/atualização da entidade no banco local
        # Por enquanto, apenas log
        entity_name = f"{catalog['name']}.{schema['name']}.{table['name']}"
        logger.info(f"Processando entidade: {entity_name}")
    
    async def _calculate_quality_metrics(self, catalog_name: str, schema_name: str, table_name: str) -> Dict:
        """Calcula métricas de qualidade básicas"""
        # TODO: Implementar cálculos reais de qualidade
        # Por enquanto, retornar métricas mock
        return {
            "row_count": 1000,
            "null_percentage": 5.2,
            "duplicate_percentage": 0.1,
            "completeness_score": 94.8,
            "validity_score": 98.5,
            "consistency_score": 96.3,
            "overall_quality_score": 96.5
        }

