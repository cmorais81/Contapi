"""
Classe Base para Conectores
API de Governança de Dados V2.2
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from datetime import datetime
import logging
import json

logger = logging.getLogger(__name__)

class ConnectorStatus:
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    ERROR = "error"
    AUTHENTICATING = "authenticating"
    SYNCING = "syncing"

class SyncResult:
    def __init__(self):
        self.success = False
        self.entities_processed = 0
        self.entities_created = 0
        self.entities_updated = 0
        self.entities_failed = 0
        self.errors = []
        self.warnings = []
        self.execution_time_seconds = 0
        self.metadata = {}

class BaseConnector(ABC):
    """Classe base para todos os conectores"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o conector com configuração
        
        Args:
            config: Configuração do conector contendo:
                - name: Nome do conector
                - endpoint_url: URL do endpoint
                - authentication_config: Configuração de autenticação
                - sync_config: Configuração de sincronização
        """
        self.config = config
        self.name = config.get('name', 'Unknown Connector')
        self.endpoint_url = config.get('endpoint_url')
        self.auth_config = config.get('authentication_config', {})
        self.sync_config = config.get('sync_config', {})
        
        self.status = ConnectorStatus.DISCONNECTED
        self.last_sync_time = None
        self.last_error = None
        
        logger.info(f"Inicializando conector: {self.name}")
    
    @abstractmethod
    async def connect(self) -> bool:
        """
        Estabelece conexão com o sistema externo
        
        Returns:
            bool: True se conectado com sucesso
        """
        pass
    
    @abstractmethod
    async def disconnect(self) -> bool:
        """
        Desconecta do sistema externo
        
        Returns:
            bool: True se desconectado com sucesso
        """
        pass
    
    @abstractmethod
    async def test_connection(self) -> Dict[str, Any]:
        """
        Testa a conexão com o sistema externo
        
        Returns:
            Dict contendo resultado do teste
        """
        pass
    
    @abstractmethod
    async def sync_entities(self, entity_filters: Optional[Dict] = None) -> SyncResult:
        """
        Sincroniza entidades do sistema externo
        
        Args:
            entity_filters: Filtros para sincronização
            
        Returns:
            SyncResult: Resultado da sincronização
        """
        pass
    
    @abstractmethod
    async def sync_metadata(self, entity_id: str) -> Dict[str, Any]:
        """
        Sincroniza metadados de uma entidade específica
        
        Args:
            entity_id: ID da entidade
            
        Returns:
            Dict: Metadados sincronizados
        """
        pass
    
    @abstractmethod
    async def get_entity_lineage(self, entity_id: str) -> Dict[str, Any]:
        """
        Obtém lineage de uma entidade
        
        Args:
            entity_id: ID da entidade
            
        Returns:
            Dict: Informações de lineage
        """
        pass
    
    @abstractmethod
    async def get_data_quality_metrics(self, entity_id: str) -> Dict[str, Any]:
        """
        Obtém métricas de qualidade de dados
        
        Args:
            entity_id: ID da entidade
            
        Returns:
            Dict: Métricas de qualidade
        """
        pass
    
    # Métodos comuns implementados na classe base
    
    def get_status(self) -> Dict[str, Any]:
        """Retorna status atual do conector"""
        return {
            "name": self.name,
            "status": self.status,
            "endpoint_url": self.endpoint_url,
            "last_sync_time": self.last_sync_time.isoformat() if self.last_sync_time else None,
            "last_error": self.last_error,
            "config_summary": {
                "auth_type": self.auth_config.get('type', 'unknown'),
                "sync_frequency": self.sync_config.get('frequency', 'manual')
            }
        }
    
    def log_error(self, error: str, details: Optional[Dict] = None):
        """Log de erro do conector"""
        self.last_error = {
            "message": error,
            "timestamp": datetime.now().isoformat(),
            "details": details or {}
        }
        logger.error(f"Erro no conector {self.name}: {error}")
        if details:
            logger.error(f"Detalhes: {json.dumps(details, indent=2)}")
    
    def log_success(self, message: str, details: Optional[Dict] = None):
        """Log de sucesso do conector"""
        logger.info(f"Sucesso no conector {self.name}: {message}")
        if details:
            logger.info(f"Detalhes: {json.dumps(details, indent=2)}")
    
    def validate_config(self) -> List[str]:
        """
        Valida configuração do conector
        
        Returns:
            List[str]: Lista de erros de validação
        """
        errors = []
        
        if not self.endpoint_url:
            errors.append("endpoint_url é obrigatório")
        
        if not self.auth_config:
            errors.append("authentication_config é obrigatório")
        
        return errors
    
    def get_sync_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas de sincronização"""
        # TODO: Implementar coleta de estatísticas reais
        return {
            "total_syncs": 0,
            "successful_syncs": 0,
            "failed_syncs": 0,
            "last_sync_duration": 0,
            "average_sync_duration": 0,
            "entities_synced_today": 0,
            "entities_synced_total": 0
        }
    
    async def health_check(self) -> Dict[str, Any]:
        """
        Verifica saúde do conector
        
        Returns:
            Dict: Status de saúde
        """
        try:
            # Testar conexão
            connection_test = await self.test_connection()
            
            # Validar configuração
            config_errors = self.validate_config()
            
            # Determinar status geral
            is_healthy = (
                connection_test.get('success', False) and 
                len(config_errors) == 0
            )
            
            return {
                "healthy": is_healthy,
                "connector_name": self.name,
                "status": self.status,
                "connection_test": connection_test,
                "config_errors": config_errors,
                "last_sync": self.last_sync_time.isoformat() if self.last_sync_time else None,
                "last_error": self.last_error,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.log_error(f"Erro no health check: {str(e)}")
            return {
                "healthy": False,
                "connector_name": self.name,
                "status": ConnectorStatus.ERROR,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def get_supported_operations(self) -> List[str]:
        """Retorna operações suportadas pelo conector"""
        return [
            "connect",
            "disconnect", 
            "test_connection",
            "sync_entities",
            "sync_metadata",
            "get_entity_lineage",
            "get_data_quality_metrics",
            "health_check"
        ]
    
    def get_connector_info(self) -> Dict[str, Any]:
        """Retorna informações do conector"""
        return {
            "name": self.name,
            "type": self.__class__.__name__,
            "version": "2.2.0",
            "author": "Carlos Morais (carlos.morais@f1rst.com.br)",
            "supported_operations": self.get_supported_operations(),
            "endpoint_url": self.endpoint_url,
            "status": self.status,
            "last_sync": self.last_sync_time.isoformat() if self.last_sync_time else None
        }

