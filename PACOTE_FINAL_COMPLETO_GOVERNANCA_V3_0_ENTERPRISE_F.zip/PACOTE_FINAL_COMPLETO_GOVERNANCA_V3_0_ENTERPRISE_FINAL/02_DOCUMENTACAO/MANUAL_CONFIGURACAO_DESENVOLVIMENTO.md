# 🛠️ MANUAL DE CONFIGURAÇÃO - AMBIENTE DE DESENVOLVIMENTO

## 📋 VISÃO GERAL

Este manual orienta como configurar a aplicação de Contratos de Dados em ambiente de desenvolvimento local, conectando ao PostgreSQL para testes e desenvolvimento.

---

## 🔧 PRÉ-REQUISITOS

### **Software Necessário:**
- Python 3.11+
- PostgreSQL 14+
- Git
- Editor de código (VS Code recomendado)

### **Conhecimentos Básicos:**
- Linha de comando
- Conceitos básicos de banco de dados
- Python e FastAPI

---

## 📦 PASSO 1: INSTALAÇÃO DO POSTGRESQL

### **Windows:**
```bash
# Opção 1: Chocolatey
choco install postgresql

# Opção 2: Download direto
# Baixar de: https://www.postgresql.org/download/windows/
```

### **macOS:**
```bash
# Opção 1: Homebrew
brew install postgresql
brew services start postgresql

# Opção 2: Postgres.app
# Baixar de: https://postgresapp.com/
```

### **Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### **Verificar Instalação:**
```bash
psql --version
# Deve retornar: psql (PostgreSQL) 14.x
```

---

## 🗄️ PASSO 2: CONFIGURAÇÃO DO BANCO DE DADOS

### **Acessar PostgreSQL:**
```bash
# Linux/macOS
sudo -u postgres psql

# Windows (como administrador)
psql -U postgres
```

### **Criar Banco e Usuário:**
```sql
-- Criar usuário para desenvolvimento
CREATE USER dev_user WITH PASSWORD 'dev_password123';

-- Criar banco de dados
CREATE DATABASE governance_dev OWNER dev_user;

-- Conceder privilégios
GRANT ALL PRIVILEGES ON DATABASE governance_dev TO dev_user;

-- Sair do psql
\q
```

### **Testar Conexão:**
```bash
psql -h localhost -U dev_user -d governance_dev
# Senha: dev_password123
```

---

## 📁 PASSO 3: CONFIGURAÇÃO DA APLICAÇÃO

### **Clonar/Acessar o Projeto:**
```bash
# Se ainda não tem o código
cd /caminho/para/seus/projetos

# Acessar diretório da aplicação
cd PACOTE_FINAL_COMPLETO_GOVERNANCA_V2_4_CONFIG_ENTERPRISE/01_CODIGO_FONTE
```

### **Criar Ambiente Virtual:**
```bash
# Criar ambiente virtual
python -m venv venv

# Ativar ambiente virtual
# Windows
venv\Scripts\activate

# Linux/macOS
source venv/bin/activate
```

### **Instalar Dependências:**
```bash
pip install -r requirements.txt
```

---

## ⚙️ PASSO 4: CONFIGURAÇÃO DE VARIÁVEIS DE AMBIENTE

### **Criar Arquivo .env:**
```bash
# Criar arquivo .env na raiz do projeto
touch .env  # Linux/macOS
# ou criar manualmente no Windows
```

### **Configurar .env para Desenvolvimento:**
```env
# ===========================================
# CONFIGURAÇÃO DE DESENVOLVIMENTO
# ===========================================

# Ambiente
ENVIRONMENT=development
DEBUG=true
LOG_LEVEL=DEBUG

# ===========================================
# BANCO DE DADOS
# ===========================================
DATABASE_URL=postgresql://dev_user:dev_password123@localhost:5432/governance_dev
DB_HOST=localhost
DB_PORT=5432
DB_NAME=governance_dev
DB_USER=dev_user
DB_PASSWORD=dev_password123
DB_POOL_SIZE=5
DB_MAX_OVERFLOW=10

# ===========================================
# REDIS (OPCIONAL PARA DEV)
# ===========================================
REDIS_URL=redis://localhost:6379/0
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0

# ===========================================
# SEGURANÇA
# ===========================================
SECRET_KEY=dev-secret-key-change-in-production-123456789
JWT_SECRET_KEY=jwt-dev-secret-key-change-in-production-987654321
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=1440

# ===========================================
# API CONFIGURAÇÃO
# ===========================================
API_HOST=0.0.0.0
API_PORT=8000
API_RELOAD=true
API_WORKERS=1

# ===========================================
# RATE LIMITING
# ===========================================
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=60

# ===========================================
# LOGGING
# ===========================================
LOG_FORMAT=detailed
LOG_FILE=logs/app.log
LOG_ROTATION=1 day
LOG_RETENTION=7 days

# ===========================================
# FEATURES FLAGS
# ===========================================
ENABLE_SWAGGER=true
ENABLE_METRICS=true
ENABLE_HEALTH_CHECK=true
ENABLE_CORS=true

# ===========================================
# DESENVOLVIMENTO
# ===========================================
DEV_MODE=true
MOCK_EXTERNAL_APIS=true
SKIP_AUTH_IN_DEV=false
```

---

## 🗃️ PASSO 5: INICIALIZAÇÃO DO BANCO DE DADOS

### **Criar Script de Inicialização:**
```bash
# Criar arquivo init_db.py na raiz
touch init_db.py
```

### **Conteúdo do init_db.py:**
```python
#!/usr/bin/env python3
"""
Script para inicializar o banco de dados em desenvolvimento
"""
import asyncio
import sys
from pathlib import Path

# Adicionar src ao path
sys.path.append(str(Path(__file__).parent / "src"))

from src.database.connection import get_database_connection
from src.database.models import *  # Importar todos os modelos

async def init_database():
    """Inicializa o banco de dados com as tabelas"""
    try:
        print("🔄 Conectando ao banco de dados...")
        
        # Importar engine do SQLAlchemy
        from src.database.connection import engine
        from src.database.models.base import Base
        
        print("📋 Criando tabelas...")
        
        # Criar todas as tabelas
        Base.metadata.create_all(bind=engine)
        
        print("✅ Banco de dados inicializado com sucesso!")
        print("📊 Tabelas criadas:")
        
        # Listar tabelas criadas
        for table_name in Base.metadata.tables.keys():
            print(f"  - {table_name}")
            
    except Exception as e:
        print(f"❌ Erro ao inicializar banco: {e}")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(init_database())
```

### **Executar Inicialização:**
```bash
python init_db.py
```

---

## 🚀 PASSO 6: EXECUTAR A APLICAÇÃO

### **Método 1: Usando uvicorn diretamente**
```bash
# Ativar ambiente virtual (se não estiver ativo)
source venv/bin/activate  # Linux/macOS
# ou
venv\Scripts\activate     # Windows

# Executar aplicação
uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload
```

### **Método 2: Usando script Python**
```bash
python -m uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload
```

### **Método 3: Script personalizado (dev.py)**
```python
#!/usr/bin/env python3
"""
Script para executar aplicação em desenvolvimento
"""
import uvicorn
import os
from pathlib import Path

if __name__ == "__main__":
    # Configurar ambiente
    os.environ.setdefault("ENVIRONMENT", "development")
    
    # Executar aplicação
    uvicorn.run(
        "src.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="debug",
        access_log=True
    )
```

```bash
# Executar script personalizado
python dev.py
```

---

## 🌐 PASSO 7: VERIFICAR FUNCIONAMENTO

### **Acessar Aplicação:**
- **API Docs (Swagger):** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc
- **Health Check:** http://localhost:8000/health

### **Testar Endpoints Básicos:**
```bash
# Health check
curl http://localhost:8000/health

# Listar contratos
curl http://localhost:8000/api/v1/contracts

# Verificar métricas
curl http://localhost:8000/metrics
```

### **Verificar Logs:**
```bash
# Ver logs em tempo real
tail -f logs/app.log

# Ver logs no console (se configurado)
# Os logs aparecerão no terminal onde executou a aplicação
```

---

## 🧪 PASSO 8: DADOS DE TESTE

### **Criar Script de Dados de Teste:**
```python
#!/usr/bin/env python3
"""
Script para inserir dados de teste
"""
import asyncio
import sys
from pathlib import Path
from datetime import datetime

sys.path.append(str(Path(__file__).parent / "src"))

from src.database.connection import get_session
from src.database.models.contracts import Contract
from src.database.models.entities import Entity

async def create_test_data():
    """Cria dados de teste"""
    try:
        print("🔄 Criando dados de teste...")
        
        session = get_session()
        
        # Criar entidade de teste
        test_entity = Entity(
            name="customer_data",
            description="Dados de clientes para teste",
            entity_type="table",
            schema_name="public",
            created_by="dev_user"
        )
        session.add(test_entity)
        session.commit()
        
        # Criar contrato de teste
        test_contract = Contract(
            name="customer_data_contract",
            version="1.0.0",
            description="Contrato de dados de clientes",
            entity_id=test_entity.id,
            schema_definition={
                "type": "object",
                "properties": {
                    "customer_id": {"type": "integer"},
                    "name": {"type": "string"},
                    "email": {"type": "string"}
                }
            },
            status="draft",
            created_by="dev_user"
        )
        session.add(test_contract)
        session.commit()
        
        print("✅ Dados de teste criados com sucesso!")
        print(f"📊 Entity ID: {test_entity.id}")
        print(f"📋 Contract ID: {test_contract.id}")
        
    except Exception as e:
        print(f"❌ Erro ao criar dados de teste: {e}")
        session.rollback()
    finally:
        session.close()

if __name__ == "__main__":
    asyncio.run(create_test_data())
```

### **Executar Criação de Dados:**
```bash
python create_test_data.py
```

---

## 🔧 PASSO 9: FERRAMENTAS DE DESENVOLVIMENTO

### **Instalar Ferramentas Adicionais:**
```bash
# Ferramentas de desenvolvimento
pip install pytest pytest-asyncio httpx

# Cliente PostgreSQL (opcional)
pip install pgcli

# Formatação de código
pip install black isort flake8
```

### **Usar pgcli (Cliente PostgreSQL Melhorado):**
```bash
# Conectar com pgcli
pgcli postgresql://dev_user:dev_password123@localhost:5432/governance_dev

# Comandos úteis no pgcli
\dt          # Listar tabelas
\d contracts # Descrever tabela contracts
SELECT * FROM contracts LIMIT 5;
```

### **Configurar VS Code (Opcional):**
```json
// .vscode/settings.json
{
    "python.defaultInterpreterPath": "./venv/bin/python",
    "python.linting.enabled": true,
    "python.linting.flake8Enabled": true,
    "python.formatting.provider": "black",
    "python.sortImports.args": ["--profile", "black"]
}
```

---

## 🧪 PASSO 10: EXECUTAR TESTES

### **Testes Básicos:**
```bash
# Executar todos os testes
pytest

# Executar testes com verbose
pytest -v

# Executar testes específicos
pytest tests/test_contracts.py

# Executar com coverage
pytest --cov=src tests/
```

### **Testes Manuais via Swagger:**
1. Acessar http://localhost:8000/docs
2. Expandir endpoint `/api/v1/contracts`
3. Clicar em "Try it out"
4. Executar requisição
5. Verificar resposta

---

## 🔍 TROUBLESHOOTING

### **Problemas Comuns:**

**1. Erro de Conexão com PostgreSQL:**
```bash
# Verificar se PostgreSQL está rodando
sudo systemctl status postgresql  # Linux
brew services list | grep postgres  # macOS

# Verificar porta
sudo netstat -tlnp | grep 5432
```

**2. Erro de Permissão no Banco:**
```sql
-- Reconectar como postgres e ajustar permissões
sudo -u postgres psql
GRANT ALL PRIVILEGES ON DATABASE governance_dev TO dev_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO dev_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO dev_user;
```

**3. Erro de Importação Python:**
```bash
# Verificar se está no ambiente virtual
which python
# Deve apontar para venv/bin/python

# Reinstalar dependências
pip install -r requirements.txt --force-reinstall
```

**4. Porta 8000 em Uso:**
```bash
# Verificar processo usando porta 8000
sudo netstat -tlnp | grep 8000
# ou
lsof -i :8000

# Matar processo se necessário
kill -9 <PID>

# Ou usar porta diferente
uvicorn src.main:app --port 8001
```

**5. Tabelas não Criadas:**
```bash
# Verificar se modelos estão sendo importados
python -c "from src.database.models import *; print('OK')"

# Recriar banco se necessário
python init_db.py
```

---

## 📚 COMANDOS ÚTEIS

### **Desenvolvimento Diário:**
```bash
# Ativar ambiente
source venv/bin/activate

# Executar aplicação
uvicorn src.main:app --reload

# Em outro terminal - verificar saúde
curl http://localhost:8000/health

# Ver logs
tail -f logs/app.log
```

### **Banco de Dados:**
```bash
# Conectar ao banco
psql -h localhost -U dev_user -d governance_dev

# Backup do banco
pg_dump -h localhost -U dev_user governance_dev > backup.sql

# Restaurar backup
psql -h localhost -U dev_user governance_dev < backup.sql
```

### **Testes e Qualidade:**
```bash
# Executar testes
pytest -v

# Verificar formatação
black --check src/

# Verificar imports
isort --check-only src/

# Verificar linting
flake8 src/
```

---

## 🎯 PRÓXIMOS PASSOS

### **Após Configuração Básica:**
1. **Explorar Swagger UI** - Testar todos os endpoints
2. **Criar Contratos de Teste** - Usar a API para criar dados
3. **Testar Fluxo de Aprovação** - Simular processo completo
4. **Configurar IDE** - Debugger e ferramentas
5. **Estudar Código** - Entender arquitetura

### **Para Desenvolvimento Avançado:**
1. **Configurar Redis** - Para cache e sessões
2. **Configurar Docker** - Ambiente containerizado
3. **Configurar Testes Automatizados** - CI/CD local
4. **Configurar Monitoramento** - Métricas e logs
5. **Configurar Debugger** - Para desenvolvimento

---

## ✅ CHECKLIST DE VERIFICAÇÃO

- [ ] PostgreSQL instalado e rodando
- [ ] Banco `governance_dev` criado
- [ ] Usuário `dev_user` configurado
- [ ] Ambiente virtual Python ativo
- [ ] Dependências instaladas
- [ ] Arquivo `.env` configurado
- [ ] Tabelas criadas no banco
- [ ] Aplicação executando em http://localhost:8000
- [ ] Swagger UI acessível
- [ ] Health check retornando OK
- [ ] Dados de teste criados
- [ ] Testes básicos passando

**STATUS:** ✅ **AMBIENTE DE DESENVOLVIMENTO PRONTO!**

