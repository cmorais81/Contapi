"""
Modelo para representar um copybook COBOL.
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field


@dataclass
class CobolBook:
    """Representa um copybook COBOL."""
    
    name: str = ""
    content: str = ""
    line_count: int = 0
    structures: List[str] = field(default_factory=list)
    fields: List[str] = field(default_factory=list)
    constants: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """Inicialização pós-criação."""
        if not self.line_count and self.content:
            self.line_count = len(self.content.split('\n'))
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'line_count': self.line_count,
            'structures': self.structures,
            'fields': self.fields,
            'constants': self.constants,
            'metadata': self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CobolBook':
        """Cria instância a partir de dicionário."""
        return cls(
            name=data.get('name', ''),
            content=data.get('content', ''),
            line_count=data.get('line_count', 0),
            structures=data.get('structures', []),
            fields=data.get('fields', []),
            constants=data.get('constants', []),
            metadata=data.get('metadata', {})
        )
