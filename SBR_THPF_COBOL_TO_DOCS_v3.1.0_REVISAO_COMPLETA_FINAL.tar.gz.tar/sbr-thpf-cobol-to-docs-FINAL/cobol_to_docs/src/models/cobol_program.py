"""
Modelo para representar um programa COBOL.
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field


@dataclass
class CobolProgram:
    """Representa um programa COBOL."""
    
    name: str = ""
    program_id: str = ""
    content: str = ""
    line_count: int = 0
    size: int = 0
    files: List[str] = field(default_factory=list)
    divisions: List[str] = field(default_factory=list)
    sections: List[str] = field(default_factory=list)
    variables: List[str] = field(default_factory=list)
    procedures: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """Inicialização pós-criação."""
        if not self.program_id and self.name:
            self.program_id = self.name
        
        if not self.line_count and self.content:
            self.line_count = len(self.content.split('\n'))
        
        if not self.size and self.content:
            self.size = len(self.content)
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'program_id': self.program_id,
            'line_count': self.line_count,
            'files': self.files,
            'divisions': self.divisions,
            'sections': self.sections,
            'variables': self.variables,
            'procedures': self.procedures,
            'metadata': self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CobolProgram':
        """Cria instância a partir de dicionário."""
        return cls(
            name=data.get('name', ''),
            program_id=data.get('program_id', ''),
            content=data.get('content', ''),
            line_count=data.get('line_count', 0),
            files=data.get('files', []),
            divisions=data.get('divisions', []),
            sections=data.get('sections', []),
            variables=data.get('variables', []),
            procedures=data.get('procedures', []),
            metadata=data.get('metadata', {})
        )
