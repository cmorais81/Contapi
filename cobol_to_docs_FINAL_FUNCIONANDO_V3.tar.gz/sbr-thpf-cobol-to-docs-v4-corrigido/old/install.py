#!/usr/bin/env python3
"""
COBOL to Docs v1.3 - Script de Instalação Automatizada
Autor: Carlos Morais

Este script automatiza a instalação e configuração do COBOL to Docs v1.3
"""

import os
import sys
import subprocess
import platform
from pathlib import Path

def print_header():
    """Exibe cabeçalho do instalador"""
    print("=" * 60)
    print("COBOL to Docs v1.3 - Instalação Automatizada")
    print("=" * 60)
    print()

def check_python_version():
    """Verifica se a versão do Python é compatível"""
    print(" Verificando versão do Python...")
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print(" Python 3.8+ é necessário. Versão atual:", f"{version.major}.{version.minor}")
        return False
    print(f" Python {version.major}.{version.minor}.{version.micro} - OK")
    return True

def check_pip():
    """Verifica se pip está disponível"""
    print(" Verificando pip...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "--version"], 
                      check=True, capture_output=True)
        print(" pip - OK")
        return True
    except subprocess.CalledProcessError:
        print(" pip não encontrado")
        return False

def install_requirements():
    """Instala dependências do requirements.txt"""
    print(" Instalando dependências...")
    requirements_file = Path(__file__).parent / "requirements.txt"
    
    if not requirements_file.exists():
        print(" Arquivo requirements.txt não encontrado")
        return False
    
    try:
        cmd = [sys.executable, "-m", "pip", "install", "-r", str(requirements_file)]
        subprocess.run(cmd, check=True)
        print(" Dependências instaladas com sucesso")
        return True
    except subprocess.CalledProcessError as e:
        print(f" Erro ao instalar dependências: {e}")
        return False

def create_directories():
    """Cria diretórios necessários"""
    print(" Criando diretórios necessários...")
    directories = ["logs", "output", "temp"]
    
    for directory in directories:
        dir_path = Path(__file__).parent / directory
        dir_path.mkdir(exist_ok=True)
        print(f" Diretório {directory} criado/verificado")

def check_optional_dependencies():
    """Verifica dependências opcionais"""
    print(" Verificando dependências opcionais...")
    
    optional_deps = {
        "weasyprint": "Geração de PDF",
        "jupyter": "Suporte a notebooks",
        "sentence_transformers": "Sistema RAG"
    }
    
    for dep, description in optional_deps.items():
        try:
            __import__(dep)
            print(f" {dep} ({description}) - OK")
        except ImportError:
            print(f"  {dep} ({description}) - Não instalado")

def create_sample_env():
    """Cria arquivo .env de exemplo"""
    print("⚙  Criando arquivo de configuração de exemplo...")
    
    env_file = Path(__file__).parent / ".env.example"
    env_content = """# COBOL to Docs v1.3 - Configurações de Ambiente
# Copie este arquivo para .env e configure suas credenciais

# LuzIA Configuration
LUZIA_CLIENT_ID=your_client_id_here
LUZIA_CLIENT_SECRET=your_client_secret_here

# OpenAI Configuration (opcional)
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_ORGANIZATION=your_organization_here

# Databricks Configuration (opcional)
DATABRICKS_API_KEY=your_databricks_api_key_here
DATABRICKS_WORKSPACE_URL=your_workspace_url_here

# AWS Bedrock Configuration (opcional)
AWS_ACCESS_KEY_ID=your_access_key_here
AWS_SECRET_ACCESS_KEY=your_secret_key_here
AWS_REGION=us-east-1
"""
    
    with open(env_file, 'w', encoding='utf-8') as f:
        f.write(env_content)
    
    print(f" Arquivo {env_file.name} criado")
    print("   Configure suas credenciais copiando para .env")

def run_test():
    """Executa teste básico do sistema"""
    print(" Executando teste básico...")
    
    try:
        # Importa módulos principais
        sys.path.insert(0, str(Path(__file__).parent))
        from src.core.config import Config
        from src.rag.cobol_rag_system import COBOLRAGSystem
        
        # Testa carregamento de configuração
        config = Config()
        print(" Configuração carregada")
        
        # Testa sistema RAG
        rag = COBOLRAGSystem(config)
        print(" Sistema RAG inicializado")
        
        print(" Teste básico concluído com sucesso")
        return True
        
    except Exception as e:
        print(f" Erro no teste básico: {e}")
        return False

def print_usage_instructions():
    """Exibe instruções de uso"""
    print("\n" + "=" * 60)
    print("INSTALAÇÃO CONCLUÍDA!")
    print("=" * 60)
    print()
    print(" PRÓXIMOS PASSOS:")
    print()
    print("1. Configure suas credenciais:")
    print("   cp .env.example .env")
    print("   # Edite o arquivo .env com suas credenciais")
    print()
    print("2. Execute análises COBOL:")
    print("   python main.py --fontes examples/fontes.txt --books examples/books.txt")
    print()
    print("3. Para ajuda detalhada:")
    print("   python main.py --help")
    print()
    print(" DOCUMENTAÇÃO:")
    print("   - README.md: Guia completo")
    print("   - docs/: Documentação técnica")
    print("   - examples/: Exemplos de uso")
    print()
    print(" COBOL to Docs v1.3 está pronto para uso!")

def main():
    """Função principal do instalador"""
    print_header()
    
    # Verificações básicas
    if not check_python_version():
        sys.exit(1)
    
    if not check_pip():
        sys.exit(1)
    
    # Instalação
    if not install_requirements():
        sys.exit(1)
    
    # Configuração
    create_directories()
    create_sample_env()
    check_optional_dependencies()
    
    # Teste
    if not run_test():
        print("  Instalação concluída com avisos. Verifique as dependências.")
    
    # Instruções finais
    print_usage_instructions()

if __name__ == "__main__":
    main()
