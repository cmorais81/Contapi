#!/usr/bin/env python3
"""
Teste de funcionamento do COBOL to Docs corrigido
"""

import os
import sys
import logging

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'cobol_to_docs', 'src'))

from core.config import ConfigManager
from parsers.cobol_parser import COBOLParser
from providers.luzia_provider import LuziaProvider
from providers.base_provider import AIRequest

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def teste_parser():
    """Testa se o parser detecta todos os 5 programas"""
    logger.info("=== Teste do Parser COBOL ===")
    
    try:
        fontes_path = os.path.join(os.path.dirname(__file__), 'fontes.txt')
        if not os.path.exists(fontes_path):
            logger.error(f"❌ Arquivo {fontes_path} não encontrado")
            return False
            
        parser = COBOLParser()
        programs, books = parser.parse_file(fontes_path)
        
        logger.info(f"✅ Programas detectados: {len(programs)}")
        
        expected_programs = ['LHAN0542', 'LHAN0705', 'LHAN0706', 'LHBR0700', 'MZAN6056']
        found_programs = [p.name for p in programs]
        
        for prog in expected_programs:
            if prog in found_programs:
                logger.info(f"✅ {prog} - Detectado")
            else:
                logger.error(f"❌ {prog} - NÃO detectado")
                
        if len(programs) == 5 and all(prog in found_programs for prog in expected_programs):
            logger.info("✅ Parser funcionando corretamente!")
            return True
        else:
            logger.error("❌ Parser com problemas")
            return False
            
    except Exception as e:
        logger.error(f"❌ Erro no teste do parser: {e}")
        return False

def teste_luzia_connection():
    """Testa a conexão com o provedor Luzia"""
    logger.info("\n=== Teste de Conexão com Luzia ===")
    
    try:
        # Carregar configuração
        config_path = os.path.join(os.path.dirname(__file__), 'cobol_to_docs', 'config', 'config.yaml')
        config_manager = ConfigManager(config_path)
        config = config_manager.get_config()
        
        # Verificar se as variáveis de ambiente estão definidas
        client_id = os.getenv('LUZIA_CLIENT_ID')
        client_secret = os.getenv('LUZIA_CLIENT_SECRET')
        
        if not client_id or not client_secret:
            logger.error("❌ Variáveis LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET não estão definidas")
            logger.info("Configure as variáveis de ambiente:")
            logger.info("export LUZIA_CLIENT_ID=\'seu_client_id\' ")
            logger.info("export LUZIA_CLIENT_SECRET=\'seu_client_secret\' ")
            return False
        
        logger.info(f"✅ Variáveis de ambiente configuradas")
        logger.info(f"Client ID: {client_id[:10]}...")
        
        # Inicializar provedor Luzia
        luzia_config = config['providers']['luzia']
        luzia_provider = LuziaProvider(luzia_config)
        
        logger.info(f"✅ Provedor Luzia inicializado")
        logger.info(f"Auth URL: {luzia_provider.auth_url}")
        logger.info(f"API URL: {luzia_provider.base_url}")
        
        # Testar disponibilidade
        logger.info("🔄 Testando disponibilidade do Luzia...")
        is_available = luzia_provider.is_available()
        
        if is_available:
            logger.info("✅ Luzia está disponível!")
            
            # Teste simples de análise
            logger.info("🔄 Testando análise simples...")
            test_request = AIRequest(
                prompt="Analise este programa COBOL simples: IDENTIFICATION DIVISION. PROGRAM-ID. TESTE.",
                max_tokens=100,
                temperature=0.1,
                model="aws-claude-3-5-haiku",
                program_name="TESTE"
            )
            
            response = luzia_provider.analyze(test_request)
            
            if response.success:
                logger.info("✅ Teste de análise bem-sucedido!")
                logger.info(f"Resposta: {response.content[:100]}...")
                return True
            else:
                logger.error(f"❌ Falha na análise: {response.error_message}")
                return False
        else:
            logger.error("❌ Luzia não está disponível")
            return False
            
    except Exception as e:
        logger.error(f"❌ Erro no teste: {str(e)}")
        return False

if __name__ == "__main__":
    print("🚀 Testando COBOL to Docs Corrigido")
    print("=" * 50)
    
    parser_ok = teste_parser()
    luzia_ok = teste_luzia_connection()
    
    print("\n" + "=" * 50)
    print("📊 RESUMO DOS TESTES")
    print("=" * 50)
    
    if parser_ok:
        print("✅ Parser COBOL: FUNCIONANDO")
    else:
        print("❌ Parser COBOL: COM PROBLEMAS")
        
    if luzia_ok:
        print("✅ Conexão Luzia: OK")
    else:
        print("❌ Conexão Luzia: COM PROBLEMAS")
        
    if parser_ok and luzia_ok:
        print("\n🎉 SISTEMA PRONTO PARA USO!")
        print("\nPara usar:")
        print("1. Configure as variáveis de ambiente LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET.")
        print("2. Execute a análise: python3 cobol_to_docs/runner/main.py fontes.txt --provider luzia --model aws-claude-3-5-haiku")
        sys.exit(0)
    else:
        print("\n❌ SISTEMA COM PROBLEMAS - Verifique os erros acima")
        sys.exit(1)

