"""
COBOL AI Engine v4.0 - Parser Interface
Interface base para parsers COBOL seguindo princípios SOLID.
"""

from abc import ABC, abstractmethod
from typing import List, Tuple, Dict, Any, Optional
from dataclasses import dataclass, field
from enum import Enum


class ContentType(Enum):
    """Tipos de conteúdo suportados."""
    STACKED_FILE = "stacked"      # Arquivo empilhado com VMEMBER
    SINGLE_FILE = "single"        # Arquivo COBOL único
    LIST_FILE = "list"           # Lista de caminhos de arquivo
    UNKNOWN = "unknown"          # Tipo desconhecido


class MemberType(Enum):
    """Tipos de membros COBOL."""
    PROGRAM = "program"
    COPYBOOK = "copybook"
    UNKNOWN = "unknown"
    EMPTY = "empty"


@dataclass
class ParseStatistics:
    """Estatísticas de parsing."""
    files_parsed: int = 0
    members_found: int = 0
    programs_parsed: int = 0
    copybooks_parsed: int = 0
    empty_members: int = 0
    errors: int = 0
    total_size_bytes: int = 0
    processing_time_ms: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'files_parsed': self.files_parsed,
            'members_found': self.members_found,
            'programs_parsed': self.programs_parsed,
            'copybooks_parsed': self.copybooks_parsed,
            'empty_members': self.empty_members,
            'errors': self.errors,
            'total_size_bytes': self.total_size_bytes,
            'processing_time_ms': self.processing_time_ms
        }


@dataclass
class ParseResult:
    """Resultado de operação de parsing."""
    programs: List['CobolProgram'] = field(default_factory=list)
    copybooks: List['CobolCopybook'] = field(default_factory=list)
    source: Optional[str] = None
    success: bool = True
    error_message: Optional[str] = None
    statistics: ParseStatistics = field(default_factory=ParseStatistics)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def create_error_result(cls, error_message: str, source: str = None) -> 'ParseResult':
        """Cria resultado de erro."""
        return cls(
            success=False,
            error_message=error_message,
            source=source,
            programs=[],
            copybooks=[],
            statistics=ParseStatistics(errors=1)
        )
    
    def add_program(self, program: 'CobolProgram') -> None:
        """Adiciona programa ao resultado."""
        self.programs.append(program)
        self.statistics.programs_parsed += 1
    
    def add_copybook(self, copybook: 'CobolCopybook') -> None:
        """Adiciona copybook ao resultado."""
        self.copybooks.append(copybook)
        self.statistics.copybooks_parsed += 1
    
    def get_total_members(self) -> int:
        """Retorna total de membros parseados."""
        return len(self.programs) + len(self.copybooks)
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'programs': [prog.to_dict() for prog in self.programs],
            'copybooks': [book.to_dict() for book in self.copybooks],
            'source': self.source,
            'success': self.success,
            'error_message': self.error_message,
            'statistics': self.statistics.to_dict(),
            'metadata': self.metadata,
            'total_members': self.get_total_members()
        }


class ICobolParser(ABC):
    """
    Interface base para parsers COBOL.
    
    Define o contrato que todos os parsers COBOL devem seguir,
    garantindo consistência e permitindo substituição (LSP).
    """
    
    @abstractmethod
    def parse_file(self, file_path: str) -> ParseResult:
        """
        Parse um arquivo COBOL.
        
        Args:
            file_path: Caminho para o arquivo a ser parseado
            
        Returns:
            ParseResult: Resultado do parsing com programas e copybooks
            
        Raises:
            FileNotFoundError: Se o arquivo não for encontrado
            PermissionError: Se não houver permissão para ler o arquivo
        """
        pass
    
    @abstractmethod
    def parse_content(self, content: str, source_name: str = None) -> ParseResult:
        """
        Parse conteúdo COBOL diretamente.
        
        Args:
            content: Conteúdo COBOL a ser parseado
            source_name: Nome da fonte (opcional)
            
        Returns:
            ParseResult: Resultado do parsing
        """
        pass
    
    @abstractmethod
    def get_statistics(self) -> ParseStatistics:
        """
        Retorna estatísticas do parser.
        
        Returns:
            ParseStatistics: Estatísticas de processamento
        """
        pass
    
    @abstractmethod
    def reset_statistics(self) -> None:
        """Reseta as estatísticas do parser."""
        pass
    
    @abstractmethod
    def get_supported_formats(self) -> List[str]:
        """
        Retorna formatos suportados pelo parser.
        
        Returns:
            List[str]: Lista de formatos suportados
        """
        pass
    
    @abstractmethod
    def validate_content(self, content: str) -> bool:
        """
        Valida se o conteúdo é COBOL válido.
        
        Args:
            content: Conteúdo a validar
            
        Returns:
            bool: True se válido, False caso contrário
        """
        pass


class IContentDetector(ABC):
    """Interface para detectores de tipo de conteúdo."""
    
    @abstractmethod
    def detect_content_type(self, content: str) -> ContentType:
        """
        Detecta o tipo do conteúdo.
        
        Args:
            content: Conteúdo a analisar
            
        Returns:
            ContentType: Tipo detectado
        """
        pass
    
    @abstractmethod
    def is_stacked_file(self, content: str) -> bool:
        """
        Verifica se é arquivo empilhado.
        
        Args:
            content: Conteúdo a verificar
            
        Returns:
            bool: True se for arquivo empilhado
        """
        pass
    
    @abstractmethod
    def get_confidence_score(self, content: str, content_type: ContentType) -> float:
        """
        Retorna pontuação de confiança para o tipo detectado.
        
        Args:
            content: Conteúdo analisado
            content_type: Tipo a verificar
            
        Returns:
            float: Pontuação de 0.0 a 1.0
        """
        pass


class IContentCleaner(ABC):
    """Interface para limpadores de conteúdo."""
    
    @abstractmethod
    def clean_content(self, lines: List[str]) -> List[str]:
        """
        Limpa o conteúdo removendo comentários e linhas vazias.
        
        Args:
            lines: Linhas originais
            
        Returns:
            List[str]: Linhas limpas
        """
        pass
    
    @abstractmethod
    def remove_comments(self, lines: List[str]) -> List[str]:
        """
        Remove comentários do código.
        
        Args:
            lines: Linhas com comentários
            
        Returns:
            List[str]: Linhas sem comentários
        """
        pass
    
    @abstractmethod
    def normalize_whitespace(self, lines: List[str]) -> List[str]:
        """
        Normaliza espaços em branco.
        
        Args:
            lines: Linhas originais
            
        Returns:
            List[str]: Linhas normalizadas
        """
        pass


class IMemberExtractor(ABC):
    """Interface para extratores de membros."""
    
    @abstractmethod
    def extract_members(self, content: str) -> List['ParsedMember']:
        """
        Extrai membros de arquivo empilhado.
        
        Args:
            content: Conteúdo do arquivo empilhado
            
        Returns:
            List[ParsedMember]: Lista de membros extraídos
        """
        pass
    
    @abstractmethod
    def extract_vmember_name(self, line: str) -> Optional[str]:
        """
        Extrai nome do VMEMBER de uma linha.
        
        Args:
            line: Linha a analisar
            
        Returns:
            Optional[str]: Nome do membro ou None
        """
        pass
    
    @abstractmethod
    def get_supported_patterns(self) -> List[str]:
        """
        Retorna padrões VMEMBER suportados.
        
        Returns:
            List[str]: Lista de padrões regex
        """
        pass


class ITypeClassifier(ABC):
    """Interface para classificadores de tipo."""
    
    @abstractmethod
    def classify_member(self, content: str) -> MemberType:
        """
        Classifica o tipo do membro.
        
        Args:
            content: Conteúdo do membro
            
        Returns:
            MemberType: Tipo classificado
        """
        pass
    
    @abstractmethod
    def calculate_program_score(self, content: str) -> float:
        """
        Calcula pontuação de programa.
        
        Args:
            content: Conteúdo a analisar
            
        Returns:
            float: Pontuação de 0.0 a 1.0
        """
        pass
    
    @abstractmethod
    def calculate_copybook_score(self, content: str) -> float:
        """
        Calcula pontuação de copybook.
        
        Args:
            content: Conteúdo a analisar
            
        Returns:
            float: Pontuação de 0.0 a 1.0
        """
        pass
    
    @abstractmethod
    def get_classification_criteria(self) -> Dict[str, List[str]]:
        """
        Retorna critérios de classificação.
        
        Returns:
            Dict[str, List[str]]: Critérios por tipo
        """
        pass


class IParserValidator(ABC):
    """Interface para validadores de parser."""
    
    @abstractmethod
    def validate_structure(self, content: str) -> bool:
        """
        Valida estrutura COBOL.
        
        Args:
            content: Conteúdo a validar
            
        Returns:
            bool: True se estrutura válida
        """
        pass
    
    @abstractmethod
    def validate_syntax(self, content: str) -> List[str]:
        """
        Valida sintaxe COBOL.
        
        Args:
            content: Conteúdo a validar
            
        Returns:
            List[str]: Lista de erros encontrados
        """
        pass
    
    @abstractmethod
    def get_validation_rules(self) -> Dict[str, Any]:
        """
        Retorna regras de validação.
        
        Returns:
            Dict[str, Any]: Regras configuradas
        """
        pass
