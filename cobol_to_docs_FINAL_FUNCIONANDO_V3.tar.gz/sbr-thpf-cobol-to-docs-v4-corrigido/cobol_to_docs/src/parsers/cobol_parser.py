"""
COBOL AI Engine v2.1.0 - COBOL Parser
Parser avançado para programas COBOL e copybooks.
"""

import logging
import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass


@dataclass
class CobolProgram:
    """Representa um programa COBOL parseado."""
    name: str
    content: str
    line_count: int
    size: int
    divisions: Dict[str, str]
    sections: List[str]
    variables: List[str]
    files: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'line_count': self.line_count,
            'size': self.size,
            'divisions': self.divisions,
            'sections': self.sections,
            'variables': self.variables,
            'files': self.files
        }


@dataclass
class CobolBook:
    """Representa um copybook COBOL."""
    name: str
    content: str
    line_count: int
    size: int
    structures: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'line_count': self.line_count,
            'size': self.size,
            'structures': self.structures
        }


class COBOLParser:
    """
    Parser avançado para programas COBOL e copybooks.
    
    Funcionalidades:
    - Parse de arquivos empilhados (VMEMBER NAME)
    - Extração de programas e copybooks
    - Análise de estrutura COBOL
    - Identificação de divisões e seções
    - Extração de variáveis e arquivos
    """
    
    def __init__(self):
        """Inicializa o parser COBOL."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões regex para parsing
        self.vmember_pattern = re.compile(r'^\s*VMEMBER\s+NAME\s+([A-Z0-9]+)', re.IGNORECASE)
        self.division_pattern = re.compile(r'^\s*([A-Z]+)\s+DIVISION\.', re.IGNORECASE)
        self.section_pattern = re.compile(r'^\s*([A-Z0-9\-]+)\s+SECTION\.', re.IGNORECASE)
        self.variable_pattern = re.compile(r'^\s*\d+\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.file_pattern = re.compile(r'^\s*SELECT\s+([A-Z0-9\-]+)', re.IGNORECASE)
        
        self.logger.info("COBOL Parser inicializado")
    
    def parse_program(self, content: str, file_path: str = None) -> CobolProgram:
        """
        Parse de um programa COBOL individual.
        
        Args:
            content: Conteúdo do programa COBOL
            file_path: Caminho do arquivo (opcional)
            
        Returns:
            CobolProgram: Programa parseado
        """
        # Extrair nome do programa
        program_name = "UNKNOWN"
        if file_path:
            import os
            program_name = os.path.splitext(os.path.basename(file_path))[0]
        
        # Buscar PROGRAM-ID no conteúdo
        program_id_match = re.search(r'PROGRAM-ID\.\s+([A-Z0-9\-]+)', content, re.IGNORECASE)
        if program_id_match:
            program_name = program_id_match.group(1)
        
        # Parse do programa
        return self._parse_program(program_name, content)
    
    def parse_file(self, file_path: str) -> Tuple[List[CobolProgram], List[CobolBook]]:
        """
        Parse de arquivo COBOL empilhado.
        
        Args:
            file_path: Caminho para o arquivo
            
        Returns:
            Tuple[List[CobolProgram], List[CobolBook]]: Programas e copybooks encontrados
        """
        programs = []
        books = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            self.logger.info(f"Parseando arquivo: {file_path}")
            
            # Verificar se é arquivo empilhado (com VMEMBER)
            if 'VMEMBER NAME' in content.upper():
                members = self._split_by_vmember(content)
                
                for member_name, member_content in members.items():
                    if self._is_program(member_content):
                        program = self._parse_program(member_name, member_content)
                        programs.append(program)
                        self.logger.info(f"Programa parseado: {member_name}")
                    else:
                        book = self._parse_book(member_name, member_content)
                        books.append(book)
                        self.logger.info(f"Copybook parseado: {member_name}")
            else:
                # Arquivo único
                import os
                file_name = os.path.splitext(os.path.basename(file_path))[0]
                
                if self._is_program(content):
                    program = self._parse_program(file_name, content)
                    programs.append(program)
                    self.logger.info(f"Programa parseado: {file_name}")
                else:
                    book = self._parse_book(file_name, content)
                    books.append(book)
                    self.logger.info(f"Copybook parseado: {file_name}")
                    
        except Exception as e:
            self.logger.error(f"Erro ao parsear arquivo {file_path}: {str(e)}")
            
        return programs, books
    
    def _split_by_vmember(self, content: str) -> Dict[str, str]:
        """
        Divide o conteúdo por VMEMBER NAME.
        
        Args:
            content: Conteúdo do arquivo
            
        Returns:
            Dict[str, str]: Dicionário com nome do membro e seu conteúdo
        """
        members = {}
        lines = content.split('\n')
        current_member = None
        current_content = []
        
        for line in lines:
            vmember_match = self.vmember_pattern.match(line)
            if vmember_match:
                # Salvar membro anterior se existir
                if current_member and current_content:
                    members[current_member] = '\n'.join(current_content)
                
                # Iniciar novo membro
                current_member = vmember_match.group(1)
                current_content = []
            elif current_member:
                current_content.append(line)
        
        # Salvar último membro
        if current_member and current_content:
            members[current_member] = '\n'.join(current_content)
        
        return members
    
    def _is_program(self, content: str) -> bool:
        """
        Verifica se o conteúdo é um programa COBOL.
        
        Args:
            content: Conteúdo a verificar
            
        Returns:
            bool: True se for programa, False se for copybook
        """
        # Indicadores de programa
        program_indicators = [
            'IDENTIFICATION DIVISION',
            'ID DIVISION',
            'PROGRAM-ID',
            'PROCEDURE DIVISION'
        ]
        
        content_upper = content.upper()
        
        # Verificar se tem pelo menos 2 indicadores de programa
        indicators_found = sum(1 for indicator in program_indicators if indicator in content_upper)
        
        return indicators_found >= 1
    
    def _parse_program(self, name: str, content: str) -> CobolProgram:
        """
        Parse de um programa COBOL.
        
        Args:
            name: Nome do programa
            content: Conteúdo do programa
            
        Returns:
            CobolProgram: Programa parseado
        """
        return CobolProgram(
            name=name,
            content=content,
            line_count=len(content.split('\n')),
            size=len(content),
            divisions=self._extract_divisions(content),
            sections=self._extract_sections(content),
            variables=self._extract_variables(content),
            files=self._extract_files(content)
        )
    
    def _parse_book(self, name: str, content: str) -> CobolBook:
        """
        Parse de um copybook COBOL.
        
        Args:
            name: Nome do copybook
            content: Conteúdo do copybook
            
        Returns:
            CobolBook: Copybook parseado
        """
        return CobolBook(
            name=name,
            content=content,
            line_count=len(content.split('\n')),
            size=len(content),
            structures=self._extract_data_structures(content)
        )
    
    def _extract_divisions(self, content: str) -> Dict[str, str]:
        """Extrai as divisões do programa COBOL."""
        divisions = {}
        lines = content.split('\n')
        current_division = None
        current_content = []
        
        for line in lines:
            division_match = self.division_pattern.match(line)
            if division_match:
                # Salvar divisão anterior
                if current_division and current_content:
                    divisions[current_division] = '\n'.join(current_content)
                
                # Nova divisão
                current_division = division_match.group(1).upper()
                current_content = [line]
            elif current_division:
                current_content.append(line)
        
        # Salvar última divisão
        if current_division and current_content:
            divisions[current_division] = '\n'.join(current_content)
        
        return divisions
    
    def _extract_sections(self, content: str) -> List[str]:
        """Extrai as seções do programa COBOL."""
        sections = []
        lines = content.split('\n')
        
        for line in lines:
            section_match = self.section_pattern.match(line)
            if section_match:
                sections.append(section_match.group(1))
        
        return sections
    
    def _extract_variables(self, content: str) -> List[str]:
        """Extrai as variáveis do programa COBOL."""
        variables = []
        lines = content.split('\n')
        
        for line in lines:
            variable_match = self.variable_pattern.match(line)
            if variable_match:
                variables.append(variable_match.group(1))
        
        return variables
    
    def _extract_files(self, content: str) -> List[str]:
        """Extrai os arquivos do programa COBOL."""
        files = []
        lines = content.split('\n')
        
        for line in lines:
            file_match = self.file_pattern.match(line)
            if file_match:
                files.append(file_match.group(1))
        
        return files
    
    def _extract_data_structures(self, content: str) -> List[str]:
        """Extrai estruturas de dados do copybook."""
        structures = []
        lines = content.split('\n')
        
        # Padrão para estruturas de dados (01 level)
        structure_pattern = re.compile(r'^\s*01\s+([A-Z0-9\-]+)', re.IGNORECASE)
        
        for line in lines:
            structure_match = structure_pattern.match(line)
            if structure_match:
                structures.append(structure_match.group(1))
        
        return structures
    
    def get_parser_statistics(self) -> Dict[str, Any]:
        """
        Retorna estatísticas do parser.
        
        Returns:
            Dict[str, Any]: Estatísticas do parser
        """
        return {
            'parser_version': '2.1.0',
            'supported_formats': ['COBOL', 'Copybook', 'VMEMBER'],
            'features': [
                'Program parsing',
                'Copybook parsing',
                'Division extraction',
                'Section extraction',
                'Variable extraction',
                'File extraction'
            ]
        }
