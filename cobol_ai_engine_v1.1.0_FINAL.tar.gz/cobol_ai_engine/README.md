# COBOL AI Engine v1.1

Motor Python 3.13 para análise e documentação automatizada de programas COBOL usando múltiplas APIs de Inteligência Artificial.

## 🆕 Novidades da Versão 1.1

### 🧠 Análise Avançada de Lógica e Regras de Negócio
- **Extração de Procedimentos**: Identifica PERFORM statements e parágrafos COBOL
- **Análise de Condições**: Mapeia IF, EVALUATE, WHEN statements
- **Identificação de Cálculos**: Extrai COMPUTE, ADD, SUBTRACT, MULTIPLY, DIVIDE
- **Regras de Negócio**: Documenta regras específicas implementadas

### 📝 Transparência Total com Prompts
- **Prompts Incluídos**: Cada análise documenta o prompt completo usado
- **Rastreabilidade**: Auditoria total do processo de IA
- **Templates Especializados**: 4 tipos de prompts por análise
- **Metadados Completos**: Provedor, modelo, tokens documentados

## Características Principais

- **Parsing Avançado**: Processa arquivos COBOL empilhados e copybooks
- **Múltiplas IAs**: Integração com OpenAI, AWS Bedrock e GitHub Copilot
- **Análise de Relacionamentos**: Identifica sequência e dependências entre programas
- **Documentação Automática**: Gera documentação técnica e funcional em Markdown
- **Arquitetura SOLID**: Código seguindo princípios de design limpo
- **Configuração Flexível**: Sistema parametrizável via YAML/JSON

## Arquitetura

O projeto segue Clean Architecture com separação clara de responsabilidades:

```
src/
├── domain/                 # Regras de negócio e entidades
│   ├── entities/          # Entidades do domínio
│   └── interfaces/        # Contratos e abstrações
├── infrastructure/        # Implementações concretas
│   ├── parsers/          # Parsers COBOL
│   ├── ai_providers/     # Provedores de IA
│   └── config/           # Gerenciamento de configuração
└── application/           # Casos de uso e serviços
    └── services/         # Orquestração e lógica de aplicação
```

## Instalação

### Pré-requisitos

- Python 3.11+
- pip3

### Dependências

```bash
pip3 install PyYAML boto3 requests
```

### Configuração

1. Copie o arquivo de configuração exemplo:
```bash
cp config/config.yaml config/my_config.yaml
```

2. Configure suas chaves de API:
```yaml
ai:
  providers:
    openai:
      api_key: "${OPENAI_API_KEY}"
    bedrock:
      aws_access_key_id: "${AWS_ACCESS_KEY_ID}"
      aws_secret_access_key: "${AWS_SECRET_ACCESS_KEY}"
```

3. Configure variáveis de ambiente:
```bash
export OPENAI_API_KEY="sua_chave_openai"
export AWS_ACCESS_KEY_ID="sua_chave_aws"
export AWS_SECRET_ACCESS_KEY="sua_chave_secreta_aws"
```

## Uso

### Uso Básico

```python
from src.application.services.cobol_engine import CobolEngine

# Inicializa o motor
engine = CobolEngine(config_path='config/my_config.yaml')

# Processa arquivos COBOL
results = engine.process_cobol_files(
    fontes_path='path/to/fontes.txt',
    books_path='path/to/books.txt',
    output_dir='output/'
)

print(f"Processados {results['programs_count']} programas")
print(f"Sequência: {' -> '.join(results['sequence'])}")
```

### Exemplo de Linha de Comando

```python
# test_complete_system.py
python test_complete_system.py
```

## Funcionalidades

### Parser COBOL

- Extrai programas individuais de arquivos empilhados
- Identifica comentários e código válido (colunas 1-72)
- Processa copybooks e estruturas de dados
- Valida formato COBOL padrão

### Análise de Relacionamentos

- Identifica chamadas entre programas (CALL statements)
- Mapeia uso de copybooks (COPY statements)
- Determina sequência de execução
- Classifica programas (principal, auxiliar, utilitário)

### Integração com IA

- **OpenAI**: GPT-4, GPT-3.5-turbo
- **AWS Bedrock**: Claude, Titan
- **GitHub Copilot**: (estrutura preparada)
- Sistema de fallback automático
- Estimativa de custos por provedor

### Geração de Documentação

- Documentação técnica detalhada
- Documentação funcional de negócio
- Análise de complexidade
- Relacionamentos e dependências
- Formato Markdown limpo (sem ícones)

## Estrutura dos Arquivos de Entrada

### Arquivo de Fontes (fontes.txt)

```
VMEMBER NAME  PROGRAMA1
 ----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
V       IDENTIFICATION DIVISION.
V       PROGRAM-ID. PROGRAMA1.
...
VMEMBER NAME  PROGRAMA2
V       IDENTIFICATION DIVISION.
V       PROGRAM-ID. PROGRAMA2.
...
```

### Arquivo de Books (books.txt)

```
VMEMBER NAME  COPYBOOK1
V      * COPYBOOK DE ESTRUTURAS
V       01 ESTRUTURA-DADOS.
V          05 CAMPO1 PIC X(10).
...
```

## Configuração Avançada

### Configuração de Parsing

```yaml
parsing:
  extract_comments: true
  validate_cobol_format: true
  max_line_length: 72
  comment_indicator: "*"
```

### Configuração de Documentação

```yaml
documentation:
  include_version_history: true
  include_complexity_metrics: true
  include_sequence_analysis: true
  language: "pt-br"
  template_style: "technical"
```

## Exemplos de Saída

### Documentação Individual

```markdown
# Documentação do Programa: LHAN0542

## Resumo
Programa responsável por particionar arquivo BACEN DOC3040...

## Detalhes Técnicos
### Complexidade
- Total de linhas: 1278
- Linhas de código: 956
- Programas chamados: 3

## Relacionamentos
### Programas Chamados
- WDRAM0082
- CT-DRAM0018

### Copybooks Utilizados
- MZTCM530
```

### Relatório Completo

```markdown
# Relatório Completo de Análise COBOL

## Resumo Geral
- **Total de Programas:** 5
- **Total de Books:** 11

### Sequência de Execução
LHAN0542 -> LHAN0705 -> LHAN0706 -> LHBR0700 -> MZAN6056
```

## Testes

Execute os testes individuais:

```bash
# Teste do parser
python test_parser.py

# Teste de configuração
python test_config.py

# Teste dos provedores de IA
python test_ai_providers.py

# Teste do gerador de documentação
python test_documentation_generator.py

# Teste completo do sistema
python test_complete_system.py
```

## Arquitetura Técnica

### Princípios SOLID Aplicados

- **SRP**: Cada classe tem uma única responsabilidade
- **OCP**: Extensível para novos provedores de IA
- **LSP**: Interfaces bem definidas e substituíveis
- **ISP**: Interfaces específicas e coesas
- **DIP**: Dependência de abstrações, não implementações

### Padrões de Design

- **Strategy**: Provedores de IA intercambiáveis
- **Factory**: Criação de provedores de IA
- **Template Method**: Geração de documentação
- **Observer**: Sistema de logging

## Limitações Conhecidas

- Suporte limitado para COBOL não-padrão
- Análise de IA depende da disponibilidade dos provedores
- Parsing otimizado para formato mainframe padrão

## Próximos Passos

- Implementação completa do provedor GitHub Copilot
- Suporte para mais formatos de arquivo COBOL
- Interface web para uso interativo
- Análise de performance de código
- Geração de diagramas de fluxo

## Contribuição

O projeto segue princípios de Clean Code e SOLID. Para contribuir:

1. Mantenha a separação de responsabilidades
2. Implemente testes para novas funcionalidades
3. Siga os padrões de nomenclatura existentes
4. Documente interfaces públicas

## Licença

Este projeto foi desenvolvido como prova de conceito para análise automatizada de código COBOL.

