"""
Teste dos provedores de IA.
"""

import sys
import os
sys.path.append('/home/ubuntu/cobol_ai_engine')

from src.infrastructure.ai_providers.ai_provider_factory import AIProviderFactory, AIOrchestrator
from src.infrastructure.config.configuration_manager import ConfigurationManager
from src.domain.interfaces.ai_provider import AIRequest, AnalysisType
from src.domain.interfaces.configuration import AIProviderType
import logging

# Configura logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_ai_providers():
    """Testa os provedores de IA."""
    
    logger.info("=== Testando Provedores de IA ===")
    
    # Carrega configuração
    config_manager = ConfigurationManager(logger)
    
    try:
        config_manager.load_from_file('/home/ubuntu/cobol_ai_engine/config/config.yaml')
        logger.info("✓ Configuração carregada")
    except Exception as e:
        logger.warning(f"Erro carregando arquivo: {e}")
        config_manager.load_from_environment()
        logger.info("✓ Configuração carregada de variáveis de ambiente")
    
    # Cria factory
    factory = AIProviderFactory(logger)
    logger.info(f"Provedores suportados: {factory.get_supported_providers()}")
    
    # Cria orquestrador
    orchestrator = AIOrchestrator(logger)
    
    # Tenta criar e adicionar provedores disponíveis
    for provider_type in [AIProviderType.OPENAI, AIProviderType.BEDROCK]:
        try:
            ai_config = config_manager.get_ai_configuration(provider_type)
            provider = factory.create_provider(provider_type.value, ai_config)
            
            # Testa disponibilidade
            if provider.is_available():
                logger.info(f"✓ Provedor {provider_type.value} disponível")
                orchestrator.add_provider(provider, priority=1 if provider_type == AIProviderType.OPENAI else 0)
            else:
                logger.warning(f"✗ Provedor {provider_type.value} não disponível")
                
        except Exception as e:
            logger.warning(f"✗ Erro com provedor {provider_type.value}: {e}")
    
    # Mostra estatísticas do orquestrador
    stats = orchestrator.get_provider_statistics()
    logger.info(f"Estatísticas do orquestrador: {stats}")
    
    # Testa análise com código COBOL de exemplo
    if stats['available_providers'] > 0:
        logger.info("\n=== Testando Análise de Código COBOL ===")
        
        sample_cobol = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. HELLO-WORLD.
       AUTHOR. TESTE.
       
       ENVIRONMENT DIVISION.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-MESSAGE PIC X(20) VALUE 'HELLO WORLD'.
       
       PROCEDURE DIVISION.
       MAIN-PARA.
           DISPLAY WS-MESSAGE.
           STOP RUN.
        """
        
        # Cria solicitação de análise
        request = AIRequest(
            analysis_type=AnalysisType.PROGRAM_SUMMARY,
            content=sample_cobol,
            context={
                'program_name': 'HELLO-WORLD',
                'file_type': 'COBOL',
                'purpose': 'Programa de exemplo'
            },
            max_tokens=1000,
            temperature=0.3
        )
        
        try:
            response = orchestrator.process_request(request)
            
            if response.success:
                logger.info(f"✓ Análise bem-sucedida com {response.provider}")
                logger.info(f"Modelo usado: {response.model}")
                logger.info(f"Tokens usados: {response.tokens_used}")
                logger.info("Resposta da análise:")
                logger.info("-" * 50)
                logger.info(response.content[:500] + "..." if len(response.content) > 500 else response.content)
                logger.info("-" * 50)
            else:
                logger.error(f"✗ Falha na análise: {response.error_message}")
                
        except Exception as e:
            logger.error(f"✗ Erro durante análise: {e}")
    
    else:
        logger.warning("Nenhum provedor disponível para teste de análise")

if __name__ == "__main__":
    test_ai_providers()

