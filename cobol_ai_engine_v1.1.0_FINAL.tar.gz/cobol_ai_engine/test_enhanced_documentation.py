#!/usr/bin/env python3
"""
Teste específico para verificar a documentação melhorada com lógica e regras de negócio.
"""

import sys
import os
import logging

# Adicionar o diretório src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.infrastructure.ai_providers.mock_ai_provider import MockAIProvider
from src.domain.entities.ai_configuration import OpenAIConfiguration

def main():
    """Testa a documentação melhorada com análise de lógica e regras."""
    
    # Configurar logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    print("=== TESTE DE DOCUMENTAÇÃO MELHORADA ===")
    print()
    
    # Criar configuração mock
    config = OpenAIConfiguration(
        api_key="mock_key",
        model_name="mock-gpt-4",
        max_tokens=4000,
        temperature=0.3
    )
    
    # Criar provedor Mock AI
    provider = MockAIProvider(config, logger)
    
    # Código COBOL de exemplo com mais estruturas
    sample_cobol = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LHAN0542.
       
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT ARQUIVO-ENTRADA ASSIGN TO 'ENTRADA.DAT'.
           SELECT ARQUIVO-SAIDA ASSIGN TO 'SAIDA.DAT'.
       
       DATA DIVISION.
       FILE SECTION.
       FD ARQUIVO-ENTRADA.
       01 REG-ENTRADA.
          05 CAMPO-CHAVE      PIC X(10).
          05 CAMPO-VALOR      PIC 9(15)V99.
          05 CAMPO-DATA       PIC 9(8).
       
       WORKING-STORAGE SECTION.
       01 WS-CONTADOR         PIC 9(8) VALUE ZERO.
       01 WS-TOTAL-VALOR      PIC 9(15)V99 VALUE ZERO.
       01 WS-FLAG-EOF         PIC X VALUE 'N'.
       01 WS-LIMITE-ARQUIVO   PIC 9(8) VALUE 10000.
       
       PROCEDURE DIVISION.
       MAIN-PROCESS.
           PERFORM INICIALIZAR
           PERFORM PROCESSAR-ARQUIVO UNTIL WS-FLAG-EOF = 'S'
           PERFORM FINALIZAR
           STOP RUN.
       
       INICIALIZAR.
           OPEN INPUT ARQUIVO-ENTRADA
           OPEN OUTPUT ARQUIVO-SAIDA
           MOVE ZERO TO WS-CONTADOR.
       
       PROCESSAR-ARQUIVO.
           READ ARQUIVO-ENTRADA
               AT END MOVE 'S' TO WS-FLAG-EOF
               NOT AT END PERFORM VALIDAR-REGISTRO
           END-READ.
       
       VALIDAR-REGISTRO.
           IF CAMPO-CHAVE NOT = SPACES
              IF CAMPO-VALOR > ZERO
                 IF CAMPO-DATA NUMERIC
                    PERFORM PROCESSAR-REGISTRO-VALIDO
                 ELSE
                    PERFORM TRATAR-ERRO-DATA
                 END-IF
              ELSE
                 PERFORM TRATAR-ERRO-VALOR
              END-IF
           ELSE
              PERFORM TRATAR-ERRO-CHAVE
           END-IF.
       
       PROCESSAR-REGISTRO-VALIDO.
           ADD 1 TO WS-CONTADOR
           ADD CAMPO-VALOR TO WS-TOTAL-VALOR
           WRITE REG-SAIDA FROM REG-ENTRADA
           IF WS-CONTADOR >= WS-LIMITE-ARQUIVO
              PERFORM TROCAR-ARQUIVO-SAIDA
           END-IF.
       
       TRATAR-ERRO-CHAVE.
           DISPLAY 'ERRO: Chave em branco - Registro: ' WS-CONTADOR.
       
       TRATAR-ERRO-VALOR.
           DISPLAY 'ERRO: Valor inválido - Registro: ' WS-CONTADOR.
       
       TRATAR-ERRO-DATA.
           DISPLAY 'ERRO: Data inválida - Registro: ' WS-CONTADOR.
       
       TROCAR-ARQUIVO-SAIDA.
           CLOSE ARQUIVO-SAIDA
           PERFORM ABRIR-NOVO-ARQUIVO
           MOVE ZERO TO WS-CONTADOR.
       
       FINALIZAR.
           CLOSE ARQUIVO-ENTRADA
           CLOSE ARQUIVO-SAIDA
           DISPLAY 'Total processado: ' WS-TOTAL-VALOR.
    """
    
    print("📝 Testando análise técnica melhorada...")
    
    # Testar documentação técnica
    from src.domain.entities.ai_request import AIRequest
    
    request = AIRequest(
        program_name="LHAN0542",
        code_content=sample_cobol,
        analysis_type="technical_documentation"
    )
    
    response = provider.analyze_cobol_program(request)
    
    if response.success:
        print("✅ Análise técnica bem-sucedida!")
        print(f"📊 Tokens utilizados: {response.tokens_used}")
        print()
        print("=== DOCUMENTAÇÃO TÉCNICA MELHORADA ===")
        print(response.content)
        print()
        print("=" * 80)
    else:
        print(f"❌ Erro na análise técnica: {response.error_message}")
        return
    
    print()
    print("📋 Testando análise funcional melhorada...")
    
    # Testar documentação funcional
    request.analysis_type = "functional_documentation"
    response = provider.analyze_cobol_program(request)
    
    if response.success:
        print("✅ Análise funcional bem-sucedida!")
        print(f"📊 Tokens utilizados: {response.tokens_used}")
        print()
        print("=== DOCUMENTAÇÃO FUNCIONAL MELHORADA ===")
        print(response.content)
        print()
        print("=" * 80)
    else:
        print(f"❌ Erro na análise funcional: {response.error_message}")
        return
    
    print()
    print("🔗 Testando análise de relacionamentos...")
    
    # Testar análise de relacionamentos
    request.analysis_type = "relationship_analysis"
    response = provider.analyze_cobol_program(request)
    
    if response.success:
        print("✅ Análise de relacionamentos bem-sucedida!")
        print(f"📊 Tokens utilizados: {response.tokens_used}")
        print()
        print("=== ANÁLISE DE RELACIONAMENTOS ===")
        print(response.content)
        print()
        print("=" * 80)
    else:
        print(f"❌ Erro na análise de relacionamentos: {response.error_message}")
        return
    
    print()
    print("🎉 TESTE CONCLUÍDO COM SUCESSO!")
    print()
    print("✅ Funcionalidades testadas:")
    print("   - Extração de procedimentos COBOL")
    print("   - Identificação de condições e validações")
    print("   - Análise de cálculos e transformações")
    print("   - Mapeamento de regras de negócio específicas")
    print("   - Documentação de fluxo lógico")
    print("   - Análise de pontos de decisão críticos")
    print("   - Identificação de padrões de codificação")
    print()
    print("🚀 O sistema agora gera documentação muito mais rica e detalhada!")

if __name__ == "__main__":
    main()

