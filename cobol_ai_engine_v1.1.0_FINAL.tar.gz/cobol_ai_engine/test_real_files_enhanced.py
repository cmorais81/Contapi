#!/usr/bin/env python3
"""
Teste específico para análise detalhada dos arquivos reais fontes.txt e books.txt
com a nova funcionalidade de lógica e regras de negócio.
"""

import sys
import os
import logging

# Adicionar o diretório src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.application.services.cobol_engine import CobolEngine
from src.infrastructure.config.configuration_manager import ConfigurationManager

def main():
    """Testa análise completa com arquivos reais e análise melhorada."""
    
    # Configurar logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    print("=== TESTE COM ARQUIVOS REAIS - ANÁLISE MELHORADA ===")
    print()
    
    # Caminhos dos arquivos reais
    fontes_path = "/home/ubuntu/upload/fontes.txt"
    books_path = "/home/ubuntu/upload/BOOKS.txt"
    output_dir = "/home/ubuntu/cobol_ai_engine/teste_real_melhorado"
    
    # Verificar se arquivos existem
    if not os.path.exists(fontes_path):
        print(f"❌ Arquivo não encontrado: {fontes_path}")
        return
    
    if not os.path.exists(books_path):
        print(f"❌ Arquivo não encontrado: {books_path}")
        return
    
    print("✅ Arquivos de entrada encontrados")
    print(f"📁 Fontes: {fontes_path}")
    print(f"📁 Books: {books_path}")
    print(f"📁 Saída: {output_dir}")
    print()
    
    # Criar diretório de saída
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        # Configurar para usar Mock AI
        config_manager = ConfigurationManager()
        
        # Carregar configuração padrão
        config_file = "config/config.yaml"
        if os.path.exists(config_file):
            config_manager.load_from_file(config_file)
        
        print("🤖 Configurado para usar Mock AI com análise melhorada")
        print()
        
        # Criar engine
        engine = CobolEngine(config_manager, logger)
        
        print("🚀 Iniciando processamento completo...")
        print()
        
        # Processar arquivos
        result = engine.process_cobol_files(
            fontes_file=fontes_path,
            books_file=books_path,
            output_dir=output_dir
        )
        
        print("✅ Processamento concluído!")
        print()
        
        # Mostrar estatísticas
        print("📊 === ESTATÍSTICAS DO PROCESSAMENTO ===")
        print(f"✓ Programas processados: {result.get('programs_processed', 0)}")
        print(f"✓ Books processados: {result.get('books_processed', 0)}")
        print(f"✓ Sequência identificada: {result.get('execution_sequence', 'N/A')}")
        print(f"✓ Relacionamentos mapeados: {len(result.get('relationships', {}))}")
        print(f"✓ Análises de IA: {result.get('ai_analyses_success', 0)}/{result.get('ai_analyses_total', 0)}")
        print(f"✓ Taxa de sucesso IA: {result.get('ai_success_rate', 0):.1f}%")
        print(f"✓ Tokens utilizados: {result.get('total_tokens', 0)}")
        print()
        
        # Listar arquivos gerados
        print("📄 === ARQUIVOS GERADOS ===")
        if os.path.exists(output_dir):
            files = [f for f in os.listdir(output_dir) if f.endswith('.md')]
            files.sort()
            
            for file in files:
                file_path = os.path.join(output_dir, file)
                size = os.path.getsize(file_path)
                print(f"   📄 {file} ({size} bytes)")
        
        print()
        
        # Mostrar amostra de análise melhorada
        print("🔍 === AMOSTRA DE ANÁLISE MELHORADA ===")
        
        # Ler um arquivo de exemplo para mostrar a análise
        sample_file = os.path.join(output_dir, "LHAN0705.md")
        if os.path.exists(sample_file):
            print(f"📖 Mostrando análise do programa LHAN0705:")
            print()
            
            with open(sample_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Mostrar apenas as primeiras linhas para demonstração
            lines = content.split('\n')
            for i, line in enumerate(lines[:30]):  # Primeiras 30 linhas
                print(f"   {line}")
            
            if len(lines) > 30:
                print(f"   ... (mais {len(lines) - 30} linhas)")
        
        print()
        print("🎯 === ANÁLISE DE RELACIONAMENTOS ===")
        
        relationships = result.get('relationships', {})
        if relationships:
            for program, calls in relationships.items():
                if calls:
                    print(f"   {program} → {', '.join(calls)}")
        else:
            print("   Nenhum relacionamento identificado")
        
        print()
        print("🎉 === TESTE CONCLUÍDO COM SUCESSO! ===")
        print()
        print("✅ Funcionalidades demonstradas:")
        print("   - Parser COBOL com arquivos reais")
        print("   - Análise de lógica e regras de negócio")
        print("   - Identificação de procedimentos e condições")
        print("   - Mapeamento de cálculos e transformações")
        print("   - Documentação técnica e funcional rica")
        print("   - Análise de relacionamentos entre programas")
        print("   - Sequência de execução automática")
        print()
        print(f"📁 Documentação completa disponível em: {output_dir}")
        
    except Exception as e:
        logger.error(f"Erro durante processamento: {e}")
        print(f"❌ Erro: {e}")
        return

if __name__ == "__main__":
    main()

