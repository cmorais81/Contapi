"""
Teste básico do parser COBOL com os arquivos de exemplo.
"""

import sys
import os
sys.path.append('/home/ubuntu/cobol_ai_engine')

from src.infrastructure.parsers.cobol_file_parser import CobolFileParser
from src.infrastructure.parsers.books_parser import BooksParser
from src.infrastructure.parsers.program_analyzer import ProgramAnalyzer
from src.domain.entities.cobol_program import CobolProgram
import logging

# Configura logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_parser():
    """Testa o parser com os arquivos de exemplo."""
    
    # Testa parser de programas
    logger.info("=== Testando Parser de Programas ===")
    program_parser = CobolFileParser(logger)
    
    with open('/home/ubuntu/upload/fontes.txt', 'r', encoding='utf-8', errors='ignore') as f:
        fontes_content = f.read()
    
    programs_dict = program_parser.extract_programs(fontes_content)
    logger.info(f"Programas extraídos: {list(programs_dict.keys())}")
    
    # Testa parser de books
    logger.info("\n=== Testando Parser de Books ===")
    books_parser = BooksParser(logger)
    books = books_parser.parse_books('/home/ubuntu/upload/BOOKS.txt')
    
    logger.info(f"Books extraídos: {[book.name for book in books]}")
    
    # Cria objetos CobolProgram para análise
    programs = []
    for name, content in programs_dict.items():
        program = CobolProgram(name=name)
        program.source_lines = content.split('\n')
        programs.append(program)
    
    # Testa analisador de relacionamentos
    logger.info("\n=== Testando Analisador de Relacionamentos ===")
    analyzer = ProgramAnalyzer(logger)
    
    # Analisa relacionamentos
    relationships = analyzer.analyze_relationships(programs, books)
    logger.info(f"Relacionamentos de CALL: {relationships['call_relationships']}")
    logger.info(f"Relacionamentos de COPY: {relationships['copy_relationships']}")
    
    # Identifica sequência
    sequence = analyzer.identify_program_sequence(programs)
    logger.info(f"Sequência identificada: {' -> '.join(sequence)}")
    
    # Mostra estatísticas
    logger.info(f"\n=== Estatísticas ===")
    logger.info(f"Total de programas: {len(programs)}")
    logger.info(f"Total de books: {len(books)}")
    logger.info(f"Fluxo de dados: {relationships['data_flow']}")
    logger.info(f"Papéis dos programas: {relationships['program_roles']}")

if __name__ == "__main__":
    test_parser()

