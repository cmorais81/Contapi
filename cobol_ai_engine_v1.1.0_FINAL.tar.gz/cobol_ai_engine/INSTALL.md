# Guia de Instalação - COBOL AI Engine v1.0

## 📋 Requisitos do Sistema

### Requisitos Mínimos
- **Sistema Operacional**: Linux, macOS ou Windows
- **Python**: 3.11 ou superior
- **RAM**: 512MB disponível
- **Espaço em Disco**: 100MB para instalação
- **Conexão Internet**: Para APIs de IA (opcional)

### Requisitos Recomendados
- **RAM**: 2GB ou mais
- **CPU**: 2 cores ou mais
- **Espaço em Disco**: 1GB para dados e saídas
- **Python**: 3.11+ com pip atualizado

## 🚀 Instalação Rápida

### Passo 1: Verificar Python

```bash
# Verificar versão do Python
python3 --version

# Deve retornar Python 3.11.0 ou superior
# Se não tiver Python 3.11+, instale primeiro
```

### Passo 2: Baixar e Extrair

```bash
# Extrair o pacote
tar -xzf cobol_ai_engine_v1.0.tar.gz

# Entrar no diretório
cd cobol_ai_engine
```

### Passo 3: Instalar Dependências

```bash
# Instalar dependências Python
pip3 install -r requirements.txt

# Ou usando pip (se python3 for o padrão)
pip install -r requirements.txt
```

### Passo 4: Verificar Instalação

```bash
# Testar instalação
python3 main.py --version

# Deve retornar: COBOL AI Engine 1.0.0
```

### Passo 5: Executar Exemplo

```bash
# Executar exemplo básico
cd examples/
./exemplo_basico.sh
```

## 🐧 Instalação no Linux

### Ubuntu/Debian

```bash
# Atualizar sistema
sudo apt update

# Instalar Python 3.11+ se necessário
sudo apt install python3.11 python3.11-pip python3.11-venv

# Criar ambiente virtual (recomendado)
python3.11 -m venv cobol_ai_env
source cobol_ai_env/bin/activate

# Extrair e instalar
tar -xzf cobol_ai_engine_v1.0.tar.gz
cd cobol_ai_engine
pip install -r requirements.txt

# Testar
python3 main.py --version
```

### CentOS/RHEL/Fedora

```bash
# Instalar Python 3.11+ (Fedora)
sudo dnf install python3.11 python3.11-pip

# Ou CentOS/RHEL (pode precisar de repositórios adicionais)
sudo yum install python3.11 python3.11-pip

# Criar ambiente virtual
python3.11 -m venv cobol_ai_env
source cobol_ai_env/bin/activate

# Instalar
tar -xzf cobol_ai_engine_v1.0.tar.gz
cd cobol_ai_engine
pip install -r requirements.txt
```

### Arch Linux

```bash
# Instalar Python
sudo pacman -S python python-pip

# Instalar
tar -xzf cobol_ai_engine_v1.0.tar.gz
cd cobol_ai_engine
pip install -r requirements.txt
```

## 🍎 Instalação no macOS

### Usando Homebrew (Recomendado)

```bash
# Instalar Homebrew se não tiver
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Instalar Python 3.11+
brew install python@3.11

# Extrair e instalar
tar -xzf cobol_ai_engine_v1.0.tar.gz
cd cobol_ai_engine
pip3 install -r requirements.txt

# Testar
python3 main.py --version
```

### Usando Python.org

```bash
# 1. Baixar Python 3.11+ de python.org
# 2. Instalar o pacote .pkg
# 3. Abrir Terminal

# Extrair e instalar
tar -xzf cobol_ai_engine_v1.0.tar.gz
cd cobol_ai_engine
pip3 install -r requirements.txt
```

## 🪟 Instalação no Windows

### Usando Python.org (Recomendado)

1. **Baixar Python**:
   - Acesse [python.org](https://python.org)
   - Baixe Python 3.11+ para Windows
   - **Importante**: Marque "Add Python to PATH" durante instalação

2. **Extrair Pacote**:
   ```cmd
   # Extrair cobol_ai_engine_v1.0.tar.gz usando 7-Zip ou WinRAR
   # Ou usar PowerShell:
   tar -xzf cobol_ai_engine_v1.0.tar.gz
   ```

3. **Instalar Dependências**:
   ```cmd
   cd cobol_ai_engine
   pip install -r requirements.txt
   ```

4. **Testar**:
   ```cmd
   python main.py --version
   ```

### Usando Anaconda

```cmd
# Instalar Anaconda de anaconda.com
# Abrir Anaconda Prompt

# Criar ambiente
conda create -n cobol_ai python=3.11
conda activate cobol_ai

# Extrair e instalar
tar -xzf cobol_ai_engine_v1.0.tar.gz
cd cobol_ai_engine
pip install -r requirements.txt
```

### Usando WSL (Windows Subsystem for Linux)

```bash
# Instalar WSL se não tiver
wsl --install

# Dentro do WSL, seguir instruções do Linux
sudo apt update
sudo apt install python3.11 python3.11-pip
# ... resto igual ao Ubuntu
```

## 🐳 Instalação com Docker

### Dockerfile Incluído

```bash
# Construir imagem
docker build -t cobol-ai-engine .

# Executar container
docker run -it \
  -v $(pwd)/dados:/app/dados \
  -v $(pwd)/saida:/app/saida \
  -e OPENAI_API_KEY="sua_chave" \
  cobol-ai-engine \
  --fontes dados/fontes.txt \
  --books dados/books.txt \
  --output saida/
```

### Docker Compose

```yaml
# docker-compose.yml
version: '3.8'
services:
  cobol-ai-engine:
    build: .
    volumes:
      - ./dados:/app/dados
      - ./saida:/app/saida
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
    command: >
      --fontes dados/fontes.txt
      --books dados/books.txt
      --output saida/
```

```bash
# Executar com Docker Compose
docker-compose up
```

## 🔧 Configuração de APIs de IA

### OpenAI

1. **Criar Conta**:
   - Acesse [platform.openai.com](https://platform.openai.com)
   - Crie uma conta ou faça login

2. **Gerar API Key**:
   - Vá para "API Keys"
   - Clique "Create new secret key"
   - Copie a chave (começa com "sk-")

3. **Configurar Variável de Ambiente**:
   ```bash
   # Linux/macOS
   export OPENAI_API_KEY="sk-sua_chave_aqui"
   
   # Windows (PowerShell)
   $env:OPENAI_API_KEY="sk-sua_chave_aqui"
   
   # Windows (CMD)
   set OPENAI_API_KEY=sk-sua_chave_aqui
   ```

4. **Testar**:
   ```bash
   python3 main.py \
     --fontes examples/dados/fontes.txt \
     --books examples/dados/books.txt \
     --output teste_openai/
   ```

### AWS Bedrock

1. **Configurar AWS CLI**:
   ```bash
   # Instalar AWS CLI
   pip install awscli
   
   # Configurar credenciais
   aws configure
   ```

2. **Ou Usar Variáveis de Ambiente**:
   ```bash
   export AWS_ACCESS_KEY_ID="sua_chave_aws"
   export AWS_SECRET_ACCESS_KEY="sua_chave_secreta"
   export AWS_DEFAULT_REGION="us-east-1"
   ```

3. **Configurar Arquivo**:
   ```yaml
   # config/bedrock.yaml
   ai:
     primary_provider: "bedrock"
     providers:
       bedrock:
         aws_region: "us-east-1"
         model_name: "anthropic.claude-3-sonnet-20240229-v1:0"
   ```

4. **Testar**:
   ```bash
   python3 main.py \
     --config config/bedrock.yaml \
     --fontes examples/dados/fontes.txt \
     --books examples/dados/books.txt \
     --output teste_bedrock/
   ```

## 🔍 Verificação da Instalação

### Teste Completo

```bash
# 1. Verificar versão
python3 main.py --version

# 2. Testar parsing básico
python3 main.py \
  --fontes examples/dados/fontes.txt \
  --books examples/dados/books.txt \
  --output teste_instalacao/ \
  --log-level INFO

# 3. Verificar saída
ls -la teste_instalacao/
cat teste_instalacao/relatorio_completo.md
```

### Diagnóstico de Problemas

```bash
# Verificar Python
python3 --version
which python3

# Verificar dependências
pip3 list | grep -E "(PyYAML|boto3|requests)"

# Verificar estrutura
find . -name "*.py" | head -10

# Testar imports
python3 -c "
import sys
sys.path.append('.')
from src.application.services.cobol_engine import CobolEngine
print('✅ Imports funcionando')
"
```

## 🚨 Solução de Problemas Comuns

### Erro: "Python não encontrado"

```bash
# Linux/macOS
sudo apt install python3.11  # Ubuntu
brew install python@3.11     # macOS

# Windows
# Reinstalar Python de python.org com "Add to PATH"
```

### Erro: "pip não encontrado"

```bash
# Linux
sudo apt install python3.11-pip

# macOS
python3 -m ensurepip --upgrade

# Windows
python -m ensurepip --upgrade
```

### Erro: "Dependência não instalada"

```bash
# Atualizar pip
pip3 install --upgrade pip

# Instalar dependências uma por uma
pip3 install PyYAML
pip3 install boto3
pip3 install requests

# Ou forçar reinstalação
pip3 install -r requirements.txt --force-reinstall
```

### Erro: "Permissão negada"

```bash
# Linux/macOS
chmod +x main.py
chmod +x examples/*.sh

# Ou usar python explicitamente
python3 main.py --version
```

### Erro: "Módulo não encontrado"

```bash
# Verificar PYTHONPATH
export PYTHONPATH="${PYTHONPATH}:$(pwd)"

# Ou executar do diretório correto
cd cobol_ai_engine
python3 main.py --version
```

## 🔄 Atualização

### Atualizar para Nova Versão

```bash
# Backup da configuração atual
cp -r config/ config_backup/

# Extrair nova versão
tar -xzf cobol_ai_engine_v1.1.0.tar.gz

# Mover configurações personalizadas
cp config_backup/minha_config.yaml cobol_ai_engine/config/

# Atualizar dependências
cd cobol_ai_engine
pip3 install -r requirements.txt --upgrade

# Testar nova versão
python3 main.py --version
```

## 🗑️ Desinstalação

### Remover Completamente

```bash
# Remover diretório
rm -rf cobol_ai_engine/

# Remover dependências (se não usadas por outros projetos)
pip3 uninstall PyYAML boto3 requests

# Remover ambiente virtual (se usado)
rm -rf cobol_ai_env/

# Remover variáveis de ambiente
unset OPENAI_API_KEY
unset AWS_ACCESS_KEY_ID
unset AWS_SECRET_ACCESS_KEY
```

---

## 📞 Suporte

Se encontrar problemas durante a instalação:

1. **Verificar Requisitos**: Confirme que tem Python 3.11+
2. **Consultar Logs**: Use `--log-level DEBUG` para mais detalhes
3. **Testar Exemplos**: Execute os scripts em `examples/`
4. **Verificar Documentação**: Consulte `README.md` e `MANUAL_USUARIO.md`

---

*Guia de Instalação - COBOL AI Engine v1.0*
*Última atualização: Setembro 2025*

