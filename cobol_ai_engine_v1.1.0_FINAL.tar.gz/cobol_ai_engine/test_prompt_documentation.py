#!/usr/bin/env python3
"""
Teste específico para verificar se os prompts estão sendo incluídos na documentação.
"""

import sys
import os
import logging

# Adicionar o diretório src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.infrastructure.ai_providers.mock_ai_provider import MockAIProvider
from src.domain.entities.ai_configuration import OpenAIConfiguration
from src.domain.entities.ai_request import AIRequest
from src.application.services.documentation_generator import MarkdownDocumentationGenerator
from src.infrastructure.parsers.cobol_file_parser import CobolFileParser

def main():
    """Testa se os prompts estão sendo incluídos na documentação."""
    
    # Configurar logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    print("=== TESTE DE INCLUSÃO DE PROMPTS NA DOCUMENTAÇÃO ===")
    print()
    
    # Criar configuração mock
    config = OpenAIConfiguration(
        api_key="mock_key",
        model_name="mock-gpt-4",
        max_tokens=4000,
        temperature=0.3
    )
    
    # Criar provedor Mock AI
    provider = MockAIProvider(config, logger)
    
    # Código COBOL de exemplo
    sample_cobol = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LHAN0542.
       
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT ARQUIVO-ENTRADA ASSIGN TO 'ENTRADA.DAT'.
       
       DATA DIVISION.
       FILE SECTION.
       FD ARQUIVO-ENTRADA.
       01 REG-ENTRADA.
          05 CAMPO-CHAVE      PIC X(10).
          05 CAMPO-VALOR      PIC 9(15)V99.
       
       PROCEDURE DIVISION.
       MAIN-PROCESS.
           PERFORM INICIALIZAR
           PERFORM PROCESSAR-ARQUIVO
           STOP RUN.
       
       INICIALIZAR.
           OPEN INPUT ARQUIVO-ENTRADA.
       
       PROCESSAR-ARQUIVO.
           READ ARQUIVO-ENTRADA
               AT END DISPLAY 'FIM'
           END-READ.
    """
    
    print("🔍 Testando análise com captura de prompt...")
    
    # Criar requisição
    request = AIRequest(
        program_name="LHAN0542",
        code_content=sample_cobol,
        analysis_type="program_summary"
    )
    
    # Executar análise
    response = provider.analyze_cobol_program(request)
    
    if response.success:
        print("✅ Análise bem-sucedida!")
        print(f"📊 Tokens utilizados: {response.tokens_used}")
        print()
        
        # Verificar se prompt foi capturado
        if 'prompt_used' in response.metadata:
            print("✅ Prompt capturado com sucesso!")
            print()
            print("=== PROMPT UTILIZADO ===")
            print(response.metadata['prompt_used'][:500] + "..." if len(response.metadata['prompt_used']) > 500 else response.metadata['prompt_used'])
            print()
            print("=" * 80)
        else:
            print("❌ Prompt não foi capturado!")
            return
        
        print()
        print("📝 Testando geração de documentação com prompt...")
        
        # Simular estrutura de análise para documentação
        analysis_data = {
            'summary': response.content,
            'ai_analysis': {
                'content': response.content,
                'provider': response.provider,
                'model': response.model,
                'tokens_used': response.tokens_used,
                'metadata': response.metadata
            },
            'technical_details': {},
            'functional_details': {},
            'relationships': {}
        }
        
        # Criar programa mock
        class MockProgram:
            def __init__(self, name):
                self.name = name
                self.lines = sample_cobol.split('\n')
                self.total_lines = len(self.lines)
        
        program = MockProgram("LHAN0542")
        
        # Gerar documentação
        from src.application.services.documentation_generator import MarkdownFormatter
        formatter = MarkdownFormatter()
        doc_generator = MarkdownDocumentationGenerator(formatter)
        documentation = doc_generator.generate_documentation(program, analysis_data)
        
        print("✅ Documentação gerada!")
        print()
        
        # Verificar se prompt está na documentação
        if 'Prompt Utilizado na Análise' in documentation:
            print("✅ PROMPT INCLUÍDO NA DOCUMENTAÇÃO!")
            print()
            print("=== AMOSTRA DA DOCUMENTAÇÃO ===")
            
            # Mostrar parte da documentação que contém o prompt
            lines = documentation.split('\n')
            prompt_section_start = -1
            
            for i, line in enumerate(lines):
                if 'Prompt Utilizado na Análise' in line:
                    prompt_section_start = i
                    break
            
            if prompt_section_start >= 0:
                # Mostrar 10 linhas antes e 20 linhas depois da seção do prompt
                start = max(0, prompt_section_start - 10)
                end = min(len(lines), prompt_section_start + 30)
                
                for i in range(start, end):
                    print(f"{i+1:3d}: {lines[i]}")
            
            print()
            print("=" * 80)
        else:
            print("❌ Prompt NÃO foi incluído na documentação!")
            print()
            print("=== DOCUMENTAÇÃO GERADA (AMOSTRA) ===")
            print(documentation[:1000] + "..." if len(documentation) > 1000 else documentation)
            return
        
        print()
        print("🎉 TESTE CONCLUÍDO COM SUCESSO!")
        print()
        print("✅ Funcionalidades verificadas:")
        print("   - Captura do prompt usado na análise")
        print("   - Inclusão do prompt nos metadados da resposta")
        print("   - Geração de documentação com prompt incluído")
        print("   - Formatação adequada do prompt na documentação")
        print()
        print("🚀 O sistema agora documenta completamente o processo de análise!")
        
    else:
        print(f"❌ Erro na análise: {response.error_message}")

if __name__ == "__main__":
    main()

