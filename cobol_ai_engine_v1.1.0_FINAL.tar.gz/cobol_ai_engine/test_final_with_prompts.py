#!/usr/bin/env python3
"""
Teste final para demonstrar documentação com prompts incluídos.
"""

import sys
import os
import logging

# Adicionar o diretório src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.infrastructure.ai_providers.mock_ai_provider import MockAIProvider
from src.domain.entities.ai_configuration import OpenAIConfiguration
from src.domain.entities.ai_request import AIRequest
from src.application.services.documentation_generator import MarkdownDocumentationGenerator, MarkdownFormatter
from src.infrastructure.parsers.cobol_file_parser import CobolFileParser

def main():
    """Demonstra documentação completa com prompts incluídos."""
    
    # Configurar logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    print("=== DEMONSTRAÇÃO FINAL: DOCUMENTAÇÃO COM PROMPTS ===")
    print()
    
    # Carregar arquivo real
    fontes_path = "/home/ubuntu/upload/fontes.txt"
    
    if not os.path.exists(fontes_path):
        print(f"❌ Arquivo não encontrado: {fontes_path}")
        return
    
    print("✅ Carregando programas COBOL reais...")
    
    # Parser COBOL
    parser = CobolFileParser(logger)
    programs = parser.extract_programs(fontes_path)
    
    if not programs:
        print("❌ Nenhum programa encontrado!")
        return
    
    print(f"✅ {len(programs)} programas carregados")
    
    # Pegar primeiro programa para demonstração
    program = programs[0]
    print(f"📄 Analisando programa: {program.name}")
    print()
    
    # Configurar Mock AI
    config = OpenAIConfiguration(
        api_key="mock_key",
        model_name="mock-gpt-4",
        max_tokens=4000,
        temperature=0.3
    )
    
    provider = MockAIProvider(config, logger)
    
    # Executar múltiplas análises
    analyses = {}
    
    analysis_types = [
        ("program_summary", "Resumo do Programa"),
        ("technical_documentation", "Documentação Técnica"),
        ("functional_documentation", "Documentação Funcional"),
        ("relationship_analysis", "Análise de Relacionamentos")
    ]
    
    print("🤖 Executando análises com IA...")
    
    for analysis_type, description in analysis_types:
        print(f"   - {description}...")
        
        request = AIRequest(
            program_name=program.name,
            code_content='\n'.join(program.lines[:100]),  # Primeiras 100 linhas
            analysis_type=analysis_type
        )
        
        response = provider.analyze_cobol_program(request)
        
        if response.success:
            analyses[analysis_type] = {
                'content': response.content,
                'provider': response.provider,
                'model': response.model,
                'tokens_used': response.tokens_used,
                'metadata': response.metadata
            }
            print(f"     ✅ Concluída ({response.tokens_used} tokens)")
        else:
            print(f"     ❌ Erro: {response.error_message}")
    
    print()
    print("📝 Gerando documentação completa...")
    
    # Preparar dados para documentação
    analysis_data = {
        'summary': analyses.get('program_summary', {}).get('content', 'Nenhum resumo disponível.'),
        'ai_analysis': analyses.get('program_summary', {}),
        'technical_details': {
            'ai_analysis': analyses.get('technical_documentation', {}),
            'content': analyses.get('technical_documentation', {}).get('content', 'Nenhum detalhe técnico disponível.')
        },
        'functional_details': {
            'ai_analysis': analyses.get('functional_documentation', {}),
            'content': analyses.get('functional_documentation', {}).get('content', 'Nenhum detalhe funcional disponível.')
        },
        'relationships': {
            'ai_analysis': analyses.get('relationship_analysis', {}),
            'content': analyses.get('relationship_analysis', {}).get('content', 'Nenhum relacionamento identificado.')
        }
    }
    
    # Gerar documentação
    formatter = MarkdownFormatter()
    doc_generator = MarkdownDocumentationGenerator(formatter)
    documentation = doc_generator.generate_documentation(program, analysis_data)
    
    # Salvar documentação
    output_file = f"documentacao_com_prompts_{program.name}.md"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(documentation)
    
    print(f"✅ Documentação salva: {output_file}")
    print()
    
    # Verificar se prompts foram incluídos
    prompt_count = documentation.count("Prompt Utilizado na Análise")
    
    if prompt_count > 0:
        print(f"🎉 SUCESSO! {prompt_count} prompts incluídos na documentação!")
        print()
        
        # Mostrar estatísticas
        print("📊 === ESTATÍSTICAS DA DOCUMENTAÇÃO ===")
        print(f"   📄 Programa: {program.name}")
        print(f"   📏 Linhas de código: {len(program.lines)}")
        print(f"   🤖 Análises realizadas: {len(analyses)}")
        print(f"   📝 Prompts documentados: {prompt_count}")
        print(f"   📄 Tamanho da documentação: {len(documentation)} caracteres")
        
        total_tokens = sum(a.get('tokens_used', 0) for a in analyses.values())
        print(f"   🎯 Total de tokens: {total_tokens}")
        print()
        
        # Mostrar amostra da documentação
        print("📖 === AMOSTRA DA DOCUMENTAÇÃO ===")
        lines = documentation.split('\n')
        
        # Encontrar primeira seção de prompt
        for i, line in enumerate(lines):
            if "Prompt Utilizado na Análise" in line:
                print(f"Linha {i+1}: {line}")
                # Mostrar algumas linhas do prompt
                for j in range(i+1, min(i+10, len(lines))):
                    if lines[j].strip():
                        print(f"Linha {j+1}: {lines[j]}")
                break
        
        print()
        print("🎯 === FUNCIONALIDADES DEMONSTRADAS ===")
        print("   ✅ Parser COBOL com arquivos reais")
        print("   ✅ Múltiplas análises de IA por programa")
        print("   ✅ Captura completa de prompts utilizados")
        print("   ✅ Inclusão de prompts na documentação")
        print("   ✅ Metadados detalhados de cada análise")
        print("   ✅ Documentação técnica e funcional rica")
        print("   ✅ Rastreabilidade completa do processo")
        print()
        print(f"📁 Documentação completa disponível em: {output_file}")
        
    else:
        print("❌ Prompts não foram incluídos na documentação!")
        print()
        print("=== AMOSTRA DA DOCUMENTAÇÃO GERADA ===")
        print(documentation[:1500] + "..." if len(documentation) > 1500 else documentation)

if __name__ == "__main__":
    main()

