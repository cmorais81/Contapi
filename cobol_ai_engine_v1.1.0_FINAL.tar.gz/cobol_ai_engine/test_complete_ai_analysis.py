"""
Teste completo com análise de IA para todos os programas COBOL.
"""

import sys
import os
sys.path.append('/home/ubuntu/cobol_ai_engine')

from src.application.services.cobol_engine import CobolEngine
from src.infrastructure.ai_providers.mock_ai_provider import MockAIProvider
from src.domain.entities.ai_configuration import OpenAIConfiguration
from src.domain.interfaces.ai_provider import AIRequest, AnalysisType
import logging

# Configura logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_complete_ai_analysis():
    """Executa análise completa com IA para todos os programas."""
    
    logger.info("=== Análise Completa com IA - Todos os Programas ===")
    
    try:
        # Cria engine personalizado com Mock AI
        engine = CobolEngine(logger=logger)
        
        # Configura Mock AI diretamente
        mock_config = OpenAIConfiguration(
            api_key="mock_key",
            model_name="mock-gpt-4",
            max_tokens=4000,
            temperature=0.3
        )
        
        mock_provider = MockAIProvider(mock_config, logger)
        engine._ai_orchestrator.add_provider(mock_provider, priority=10)
        
        logger.info("Mock AI Provider configurado com sucesso")
        
        # Processa os arquivos com análise de IA
        results = engine.process_cobol_files(
            fontes_path='/home/ubuntu/upload/fontes.txt',
            books_path='/home/ubuntu/upload/BOOKS.txt',
            output_dir='/home/ubuntu/cobol_ai_engine/ai_complete_analysis'
        )
        
        # Mostra resultados detalhados
        logger.info("=== Resultados da Análise Completa ===")
        logger.info(f"✓ Programas analisados: {results['programs_count']}")
        logger.info(f"✓ Books processados: {results['books_count']}")
        logger.info(f"✓ Sequência identificada: {' → '.join(results['sequence'])}")
        
        # Mostra relacionamentos detalhados
        logger.info("\n=== Relacionamentos Identificados ===")
        for program, calls in results['relationships'].items():
            if calls:
                logger.info(f"{program} → {', '.join(calls)}")
        
        # Mostra estatísticas de IA
        ai_summary = results['ai_analysis_summary']
        logger.info(f"\n=== Estatísticas de IA ===")
        logger.info(f"✓ Análises bem-sucedidas: {ai_summary['successful_analyses']}/{ai_summary['total_programs']}")
        logger.info(f"✓ Taxa de sucesso: {ai_summary['success_rate']:.1f}%")
        logger.info(f"✓ Tokens totais: {ai_summary['total_tokens_used']}")
        
        if ai_summary['providers_used']:
            providers = ', '.join([f"{k}({v})" for k, v in ai_summary['providers_used'].items()])
            logger.info(f"✓ Provedores utilizados: {providers}")
        
        # Lista arquivos gerados
        logger.info(f"\n=== Documentação Gerada ({len(results['documentation_files'])} arquivos) ===")
        for file_path in results['documentation_files']:
            logger.info(f"📄 {file_path}")
        
        logger.info("\n✅ Análise completa executada com sucesso!")
        
        return results
        
    except Exception as e:
        logger.error(f"❌ Erro na análise completa: {e}")
        raise

def analyze_individual_programs():
    """Analisa cada programa individualmente com IA."""
    
    logger.info("\n=== Análise Individual com IA ===")
    
    # Cria provedor Mock AI
    mock_config = OpenAIConfiguration(
        api_key="mock_key",
        model_name="mock-gpt-4",
        max_tokens=4000,
        temperature=0.3
    )
    
    mock_provider = MockAIProvider(mock_config, logger)
    
    # Lista de programas para análise detalhada
    programs_to_analyze = ['LHAN0542', 'LHAN0705', 'LHAN0706', 'LHBR0700', 'MZAN6056']
    
    analysis_results = {}
    
    for program_name in programs_to_analyze:
        logger.info(f"\n--- Analisando {program_name} ---")
        
        # Simula conteúdo do programa (primeiras linhas)
        sample_content = f"""
V       IDENTIFICATION DIVISION.
V       PROGRAM-ID. {program_name}.
V       AUTHOR. SISTEMA-BACEN.
V       ENVIRONMENT DIVISION.
V       DATA DIVISION.
V       PROCEDURE DIVISION.
V       MAIN-PARA.
V           PERFORM INICIALIZA
V           PERFORM PROCESSA
V           PERFORM FINALIZA
V           STOP RUN.
        """
        
        # Análise de resumo
        summary_request = AIRequest(
            analysis_type=AnalysisType.PROGRAM_SUMMARY,
            content=sample_content,
            context={
                'program_name': program_name,
                'file_type': 'COBOL',
                'purpose': 'Processamento BACEN DOC3040'
            },
            max_tokens=1500
        )
        
        summary_response = mock_provider.analyze_cobol_program(summary_request)
        
        if summary_response.success:
            analysis_results[program_name] = {
                'summary': summary_response.content,
                'tokens_used': summary_response.tokens_used,
                'provider': summary_response.provider
            }
            
            logger.info(f"✓ {program_name}: Análise concluída ({summary_response.tokens_used} tokens)")
        else:
            logger.error(f"✗ {program_name}: Falha na análise - {summary_response.error_message}")
    
    return analysis_results

if __name__ == "__main__":
    # Executa análise completa
    complete_results = test_complete_ai_analysis()
    
    # Executa análise individual detalhada
    individual_results = analyze_individual_programs()
    
    # Salva resultados consolidados
    logger.info("\n=== Salvando Resultados Consolidados ===")
    
    consolidated_report = f"""# Análise Completa com IA - Programas COBOL BACEN

## Resumo Executivo

- **Total de Programas**: {complete_results['programs_count']}
- **Total de Books**: {complete_results['books_count']}
- **Sequência de Execução**: {' → '.join(complete_results['sequence'])}

## Análises Individuais

"""
    
    for program_name, analysis in individual_results.items():
        consolidated_report += f"""### {program_name}

**Provedor**: {analysis['provider']} | **Tokens**: {analysis['tokens_used']}

{analysis['summary']}

---

"""
    
    # Salva relatório consolidado
    with open('/home/ubuntu/cobol_ai_engine/ai_complete_analysis/RELATORIO_CONSOLIDADO_IA.md', 'w', encoding='utf-8') as f:
        f.write(consolidated_report)
    
    logger.info("📄 Relatório consolidado salvo: RELATORIO_CONSOLIDADO_IA.md")
    logger.info("\n🎉 Análise completa com IA finalizada!")

