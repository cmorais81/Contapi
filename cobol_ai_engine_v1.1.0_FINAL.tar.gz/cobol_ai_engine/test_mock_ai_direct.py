"""
Teste direto do Mock AI Provider para demonstrar capacidades de IA.
"""

import sys
import os
sys.path.append('/home/ubuntu/cobol_ai_engine')

from src.infrastructure.ai_providers.mock_ai_provider import MockAIProvider
from src.domain.entities.ai_configuration import OpenAIConfiguration
from src.domain.interfaces.ai_provider import AIRequest, AnalysisType
import logging

# Configura logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_mock_ai_capabilities():
    """Testa as capacidades do Mock AI Provider."""
    
    logger.info("=== Demonstração das Capacidades de IA ===")
    
    # Cria configuração mock
    config = OpenAIConfiguration(
        api_key="mock_key",
        model_name="mock-gpt-4",
        max_tokens=4000,
        temperature=0.3
    )
    
    # Cria provedor mock
    mock_provider = MockAIProvider(config, logger)
    
    # Código COBOL de exemplo (primeiras linhas do LHAN0542)
    sample_cobol = """
V       IDENTIFICATION DIVISION.
V       PROGRAM-ID. LHAN0542.
V       AUTHOR. EDIVALDO-DEDIC/GPTI.
V      ******************** OBJETIVO DO PROGRAMA ***********************
V      * PROGRAMA RESPONSAVEL POR PARTICIONAR ARQUIVO BACEN DOC3040    *
V      * EM MULTIPLOS ARQUIVOS MENORES PARA PROCESSAMENTO OTIMIZADO    *
V      ******************************************************************
V       ENVIRONMENT DIVISION.
V       INPUT-OUTPUT SECTION.
V       FILE-CONTROL.
V           SELECT ARQUIVO-ENTRADA ASSIGN TO ENTRADA.
V           SELECT ARQUIVO-SAIDA   ASSIGN TO SAIDA.
V       DATA DIVISION.
V       FILE SECTION.
V       FD  ARQUIVO-ENTRADA.
V       01  REG-ENTRADA            PIC X(500).
V       FD  ARQUIVO-SAIDA.
V       01  REG-SAIDA              PIC X(500).
V       WORKING-STORAGE SECTION.
V       01  WS-CONTADORES.
V           05 WS-CONT-LIDOS       PIC 9(09) VALUE ZEROS.
V           05 WS-CONT-GRAVADOS    PIC 9(09) VALUE ZEROS.
V       PROCEDURE DIVISION.
V       MAIN-PARA.
V           PERFORM INICIALIZA-PROGRAMA
V           PERFORM PROCESSA-ARQUIVO
V           PERFORM FINALIZA-PROGRAMA
V           STOP RUN.
    """
    
    # Testa diferentes tipos de análise
    test_cases = [
        (AnalysisType.PROGRAM_SUMMARY, "Resumo do Programa"),
        (AnalysisType.TECHNICAL_DOCUMENTATION, "Documentação Técnica"),
        (AnalysisType.FUNCTIONAL_DOCUMENTATION, "Documentação Funcional"),
        (AnalysisType.RELATIONSHIP_ANALYSIS, "Análise de Relacionamentos")
    ]
    
    for analysis_type, title in test_cases:
        logger.info(f"\n=== {title} ===")
        
        # Cria solicitação
        request = AIRequest(
            analysis_type=analysis_type,
            content=sample_cobol,
            context={
                'program_name': 'LHAN0542',
                'author': 'EDIVALDO-DEDIC/GPTI',
                'file_type': 'COBOL',
                'purpose': 'Particionamento de arquivo BACEN DOC3040'
            },
            max_tokens=2000,
            temperature=0.3
        )
        
        # Processa com IA
        response = mock_provider.analyze_cobol_program(request)
        
        if response.success:
            logger.info(f"✓ Análise bem-sucedida")
            logger.info(f"Provedor: {response.provider}")
            logger.info(f"Modelo: {response.model}")
            logger.info(f"Tokens usados: {response.tokens_used}")
            logger.info("\n" + "="*60)
            logger.info(response.content)
            logger.info("="*60)
        else:
            logger.error(f"✗ Falha na análise: {response.error_message}")
        
        logger.info("\n" + "-"*80 + "\n")

if __name__ == "__main__":
    test_mock_ai_capabilities()

