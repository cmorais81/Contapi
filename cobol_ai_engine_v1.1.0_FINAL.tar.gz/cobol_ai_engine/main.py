#!/usr/bin/env python3
"""
COBOL AI Engine - Script Principal
Motor para análise e documentação automatizada de programas COBOL.
"""

import sys
import os
import argparse
import logging
from pathlib import Path

# Adiciona o diretório src ao path
sys.path.append(str(Path(__file__).parent))

from src.application.services.cobol_engine import CobolEngine
from src.domain.entities.exceptions import CobolEngineError


def setup_logging(log_level: str = "INFO", log_file: str = None):
    """Configura o sistema de logging."""
    
    level = getattr(logging, log_level.upper(), logging.INFO)
    
    # Formato do log
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Handler para console
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    
    # Configura logger raiz
    logger = logging.getLogger()
    logger.setLevel(level)
    logger.addHandler(console_handler)
    
    # Handler para arquivo se especificado
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger


def main():
    """Função principal."""
    
    parser = argparse.ArgumentParser(
        description="COBOL AI Engine - Análise e documentação automatizada de programas COBOL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:

  # Uso básico
  python main.py --fontes fontes.txt --books books.txt --output docs/

  # Com configuração personalizada
  python main.py --fontes fontes.txt --books books.txt --output docs/ --config config/my_config.yaml

  # Com logging detalhado
  python main.py --fontes fontes.txt --books books.txt --output docs/ --log-level DEBUG --log-file engine.log

Configuração:
  Configure suas chaves de API via variáveis de ambiente:
  
  export OPENAI_API_KEY="sua_chave_openai"
  export AWS_ACCESS_KEY_ID="sua_chave_aws"
  export AWS_SECRET_ACCESS_KEY="sua_chave_secreta_aws"
        """
    )
    
    # Argumentos obrigatórios
    parser.add_argument('--version', action='version', version='COBOL AI Engine 1.1.0')
    parser.add_argument(
        '--fontes', '-f', 
        required=True, 
        help='Caminho para arquivo de fontes COBOL (ex: fontes.txt)'
    )
    
    parser.add_argument(
        '--books', '-b',
        required=True,
        help='Caminho para arquivo de books/copybooks (ex: books.txt)'
    )
    
    parser.add_argument(
        '--output', '-o',
        required=True,
        help='Diretório de saída para documentação (ex: docs/)'
    )
    
    # Argumentos opcionais
    parser.add_argument(
        '--config', '-c',
        help='Arquivo de configuração personalizado (ex: config/custom.yaml)'
    )
    
    parser.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
        default='INFO',
        help='Nível de logging (padrão: INFO)'
    )
    
    parser.add_argument(
        '--log-file',
        help='Arquivo para salvar logs (ex: logs/processamento.log)'
    )
    
    args = parser.parse_args()
    
    # Configura logging
    logger = setup_logging(args.log_level, args.log_file)
    
    try:
        # Valida arquivos de entrada
        if not os.path.exists(args.fontes):
            logger.error(f"Arquivo de fontes não encontrado: {args.fontes}")
            sys.exit(1)
        
        if not os.path.exists(args.books):
            logger.error(f"Arquivo de books não encontrado: {args.books}")
            sys.exit(1)
        
        # Valida configuração se fornecida
        if args.config and not os.path.exists(args.config):
            logger.error(f"Arquivo de configuração não encontrado: {args.config}")
            sys.exit(1)
        
        # Cria diretório de saída se não existir
        os.makedirs(args.output, exist_ok=True)
        
        logger.info("=== COBOL AI Engine - Iniciando Processamento ===")
        logger.info(f"Arquivo de fontes: {args.fontes}")
        logger.info(f"Arquivo de books: {args.books}")
        logger.info(f"Diretório de saída: {args.output}")
        logger.info(f"Configuração: {args.config or 'Variáveis de ambiente'}")
        
        # Inicializa o motor
        engine = CobolEngine(
            config_path=args.config,
            logger=logger
        )
        
        # Processa os arquivos
        results = engine.process_cobol_files(
            fontes_path=args.fontes,
            books_path=args.books,
            output_dir=args.output
        )
        
        # Exibe resultados
        logger.info("=== Resultados do Processamento ===")
        logger.info(f"✓ Programas processados: {results['programs_count']}")
        logger.info(f"✓ Books processados: {results['books_count']}")
        
        if results['sequence']:
            logger.info(f"✓ Sequência identificada: {' → '.join(results['sequence'])}")
        
        logger.info(f"✓ Arquivos de documentação gerados: {len(results['documentation_files'])}")
        
        # Mostra estatísticas de IA se disponíveis
        ai_summary = results['ai_analysis_summary']
        if ai_summary['total_programs'] > 0:
            logger.info(f"✓ Análises de IA: {ai_summary['successful_analyses']}/{ai_summary['total_programs']} ({ai_summary['success_rate']:.1f}%)")
            
            if ai_summary['total_tokens_used'] > 0:
                logger.info(f"✓ Tokens utilizados: {ai_summary['total_tokens_used']}")
            
            if ai_summary['providers_used']:
                providers = ', '.join([f"{k}({v})" for k, v in ai_summary['providers_used'].items()])
                logger.info(f"✓ Provedores utilizados: {providers}")
        
        # Lista arquivos gerados
        logger.info("\n=== Arquivos Gerados ===")
        for file_path in results['documentation_files']:
            logger.info(f"📄 {file_path}")
        
        logger.info("\n✅ Processamento concluído com sucesso!")
        
    except CobolEngineError as e:
        logger.error(f"❌ Erro do COBOL Engine: {e}")
        sys.exit(1)
        
    except KeyboardInterrupt:
        logger.info("\n⏹️  Processamento interrompido pelo usuário")
        sys.exit(0)
        
    except Exception as e:
        logger.error(f"❌ Erro inesperado: {e}")
        logger.debug("Detalhes do erro:", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()

