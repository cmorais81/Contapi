"""
Implementação do gerador de documentação Markdown.
Segue o padrão Template Method e princípios SOLID.
"""

import logging
from typing import Dict, Any, List, Optional
from ...domain.interfaces.documentation_generator import IDocumentationGenerator, IDocumentationFormatter
from ...domain.entities.cobol_program import CobolProgram
from ...domain.entities.cobol_book import CobolBook
from ...domain.entities.exceptions import DocumentationGenerationError


class MarkdownFormatter(IDocumentationFormatter):
    """Formatador para Markdown."""
    
    def format_title(self, text: str, level: int = 1) -> str:
        return f"{'#' * level} {text}\n"
    
    def format_table(self, headers: List[str], rows: List[List[str]]) -> str:
        header_line = "| " + " | ".join(headers) + " |"
        separator_line = "| " + " | ".join(["---"] * len(headers)) + " |"
        row_lines = ["| " + " | ".join(row) + " |" for row in rows]
        return "\n".join([header_line, separator_line] + row_lines) + "\n"
    
    def format_code_block(self, code: str, language: str = "cobol") -> str:
        return f"```{language}\n{code}\n```\n"
    
    def format_list(self, items: List[str], ordered: bool = False) -> str:
        if ordered:
            return "\n".join([f"{i+1}. {item}" for i, item in enumerate(items)]) + "\n"
        else:
            return "\n".join([f"- {item}" for item in items]) + "\n"


class BaseDocumentationGenerator(IDocumentationGenerator):
    """Classe base para geradores de documentação (Template Method)."""
    
    def __init__(self, formatter: IDocumentationFormatter, logger: Optional[logging.Logger] = None):
        self._formatter = formatter
        self._logger = logger or logging.getLogger(__name__)
    
    def generate_documentation(self, program: CobolProgram, analysis_results: Dict[str, Any]) -> str:
        """Gera documentação para um programa (método template)."""
        try:
            self._logger.info(f"Gerando documentação para o programa: {program.name}")
            
            parts = []
            parts.append(self._generate_header(program, analysis_results))
            parts.append(self._generate_summary(program, analysis_results))
            parts.append(self._generate_technical_details(program, analysis_results))
            parts.append(self._generate_functional_details(program, analysis_results))
            parts.append(self._generate_relationships(program, analysis_results))
            parts.append(self._generate_footer(program, analysis_results))
            
            return "\n".join(parts)
            
        except Exception as e:
            raise DocumentationGenerationError(f"Erro gerando documentação para {program.name}: {str(e)}")

    def generate_full_report(self, programs: List[CobolProgram], books: List[CobolBook], analysis_results: Dict[str, Any]) -> str:
        """Gera relatório completo para múltiplos programas."""
        report_parts = [self._formatter.format_title("Relatório Completo de Análise COBOL")]
        
        # Adiciona resumo geral
        report_parts.append(self._generate_overall_summary(programs, books, analysis_results))
        
        # Adiciona documentação de cada programa
        for program in programs:
            program_analysis = analysis_results.get(program.name, {})
            report_parts.append(self.generate_documentation(program, program_analysis))
            report_parts.append("\n---\n") # Separador
        
        return "\n".join(report_parts)

    def save_documentation(self, content: str, file_path: str) -> None:
        """Salva documentação em arquivo."""
        try:
            with open(file_path, 'w', encoding='utf-8') as file:
                file.write(content)
            self._logger.info(f"Documentação salva em: {file_path}")
        except Exception as e:
            raise DocumentationGenerationError(f"Erro ao salvar documentação: {str(e)}")

    # Métodos para serem implementados/sobrescritos por subclasses
    def _generate_header(self, program: CobolProgram, analysis: Dict[str, Any]) -> str:
        return self._formatter.format_title(f"Documentação do Programa: {program.name}")

    def _generate_summary(self, program: CobolProgram, analysis: Dict[str, Any]) -> str:
        raise NotImplementedError

    def _generate_technical_details(self, program: CobolProgram, analysis: Dict[str, Any]) -> str:
        raise NotImplementedError

    def _generate_functional_details(self, program: CobolProgram, analysis: Dict[str, Any]) -> str:
        raise NotImplementedError

    def _generate_relationships(self, program: CobolProgram, analysis: Dict[str, Any]) -> str:
        raise NotImplementedError

    def _generate_footer(self, program: CobolProgram, analysis: Dict[str, Any]) -> str:
        return "\n*Documentação gerada automaticamente.*"
    
    def _generate_overall_summary(self, programs: List[CobolProgram], books: List[CobolBook], analysis: Dict[str, Any]) -> str:
        return ""

class MarkdownDocumentationGenerator(BaseDocumentationGenerator):
    """Gerador de documentação em formato Markdown."""

    def _generate_summary(self, program: CobolProgram, analysis: Dict[str, Any]) -> str:
        """Gera resumo melhorado incluindo análise de IA com prompt."""
        content = [self._formatter.format_title("Resumo", 2)]
        
        # Resumo básico
        summary_content = analysis.get('summary', 'Nenhum resumo disponível.')
        content.append(summary_content)
        
        # Análise de IA se disponível
        if 'ai_analysis' in analysis:
            ai_section = self._generate_ai_section(program, analysis['ai_analysis'])
            if ai_section and ai_section != "Nenhuma análise de IA disponível.":
                content.append("\n## Análise com Inteligência Artificial")
                content.append(ai_section)
        
        return "\n".join(content)

    def _generate_technical_details(self, program: CobolProgram, analysis: Dict[str, Any]) -> str:
        tech_details = analysis.get('technical_details', {})
        content = [self._formatter.format_title("Detalhes Técnicos", 2)]
        
        if tech_details:
            for section, text in tech_details.items():
                content.append(self._formatter.format_title(section.replace('_', ' ').title(), 3))
                content.append(text)
        else:
            content.append("Nenhum detalhe técnico disponível.")

        return "\n".join(content)

    def _generate_functional_details(self, program: CobolProgram, analysis: Dict[str, Any]) -> str:
        func_details = analysis.get('functional_details', {})
        content = [self._formatter.format_title("Detalhes Funcionais", 2)]
        
        if func_details:
            for section, text in func_details.items():
                content.append(self._formatter.format_title(section.replace('_', ' ').title(), 3))
                content.append(text)
        else:
            content.append("Nenhum detalhe funcional disponível.")

        return "\n".join(content)

    def _generate_relationships(self, program: CobolProgram, analysis: Dict[str, Any]) -> str:
        relationships = analysis.get('relationships', {})
        content = [self._formatter.format_title("Relacionamentos", 2)]
        
        if relationships:
            called = relationships.get('called_programs', [])
            copied = relationships.get('used_copybooks', [])
            
            content.append(self._formatter.format_title("Programas Chamados", 3))
            content.append(self._formatter.format_list(called) if called else "Nenhum.")
            
            content.append(self._formatter.format_title("Copybooks Utilizados", 3))
            content.append(self._formatter.format_list(copied) if copied else "Nenhum.")
        else:
            content.append("Nenhum relacionamento identificado.")

        return "\n".join(content)
    
    def _generate_overall_summary(self, programs: List[CobolProgram], books: List[CobolBook], analysis: Dict[str, Any]) -> str:
        summary = [self._formatter.format_title("Resumo Geral", 2)]
        summary.append(f"- **Total de Programas:** {len(programs)}")
        summary.append(f"- **Total de Books:** {len(books)}")
        
        # Adiciona sequência de programas
        sequence = analysis.get('sequence', [])
        if sequence:
            summary.append(self._formatter.format_title("Sequência de Execução", 3))
            summary.append(" -> ".join(sequence))
        
        return "\n".join(summary)



    def _generate_ai_section(self, program: CobolProgram, ai_analysis: Dict[str, Any]) -> str:
        """
        Gera seção com análise de IA incluindo prompt usado.
        
        Args:
            program: Programa COBOL
            ai_analysis: Resultado da análise de IA
            
        Returns:
            Seção formatada em Markdown
        """
        if not ai_analysis:
            return "Nenhuma análise de IA disponível."
        
        sections = []
        
        # Adicionar análise de IA se disponível
        if 'content' in ai_analysis:
            sections.append(ai_analysis['content'])
        
        # Adicionar informações de metadados
        if 'metadata' in ai_analysis:
            metadata = ai_analysis['metadata']
            
            # Seção de metadados da análise
            sections.append("\n## Metadados da Análise")
            
            if 'provider' in ai_analysis:
                sections.append(f"- **Provedor de IA**: {ai_analysis['provider']}")
            
            if 'model' in ai_analysis:
                sections.append(f"- **Modelo**: {ai_analysis['model']}")
            
            if 'tokens_used' in ai_analysis:
                sections.append(f"- **Tokens utilizados**: {ai_analysis['tokens_used']}")
            
            if 'analysis_type' in metadata:
                sections.append(f"- **Tipo de análise**: {metadata['analysis_type']}")
            
            # Adicionar prompt usado se disponível
            if 'prompt_used' in metadata:
                sections.append("\n## Prompt Utilizado na Análise")
                sections.append("```")
                sections.append(metadata['prompt_used'])
                sections.append("```")
        
        return "\n".join(sections)
    
    def _generate_enhanced_summary(self, program: CobolProgram, analysis: Dict[str, Any]) -> str:
        """Gera resumo melhorado incluindo análise de IA com prompt."""
        content = [self._formatter.format_title("Resumo", 2)]
        
        # Resumo básico
        summary_content = analysis.get('summary', 'Nenhum resumo disponível.')
        content.append(summary_content)
        
        # Análise de IA se disponível
        if 'ai_analysis' in analysis:
            ai_section = self._generate_ai_section(program, analysis['ai_analysis'])
            if ai_section and ai_section != "Nenhuma análise de IA disponível.":
                content.append("\n## Análise com Inteligência Artificial")
                content.append(ai_section)
        
        return "\n".join(content)

