"""
Motor principal do COBOL AI Engine.
Orquestra todos os componentes seguindo princípios SOLID.
"""

import logging
import os
from typing import Dict, Any, List, Optional
from ...domain.entities.cobol_program import CobolProgram
from ...domain.entities.cobol_book import CobolBook
from ...domain.interfaces.ai_provider import AIRequest, AnalysisType
from ...infrastructure.parsers.cobol_file_parser import CobolFileParser
from ...infrastructure.parsers.books_parser import BooksParser
from ...infrastructure.parsers.program_analyzer import ProgramAnalyzer
from ...infrastructure.config.configuration_manager import ConfigurationManager
from ...infrastructure.ai_providers.ai_provider_factory import AIProviderFactory, AIOrchestrator
from .documentation_generator import MarkdownDocumentationGenerator, MarkdownFormatter
from ...domain.entities.exceptions import CobolEngineError


class CobolEngine:
    """Motor principal para análise e documentação de programas COBOL."""
    
    def __init__(self, config_path: Optional[str] = None, logger: Optional[logging.Logger] = None):
        """
        Inicializa o motor COBOL.
        
        Args:
            config_path: Caminho para arquivo de configuração
            logger: Logger para registrar operações
        """
        self._logger = logger or logging.getLogger(__name__)
        
        # Inicializa componentes
        self._config_manager = ConfigurationManager(self._logger)
        self._cobol_parser = CobolFileParser(self._logger)
        self._books_parser = BooksParser(self._logger)
        self._program_analyzer = ProgramAnalyzer(self._logger)
        self._ai_factory = AIProviderFactory(self._logger)
        self._ai_orchestrator = AIOrchestrator(self._logger)
        self._doc_generator = MarkdownDocumentationGenerator(MarkdownFormatter(), self._logger)
        
        # Carrega configuração
        if config_path and os.path.exists(config_path):
            self._config_manager.load_from_file(config_path)
        else:
            self._config_manager.load_from_environment()
        
        # Inicializa provedores de IA
        self._initialize_ai_providers()
        
        self._logger.info("COBOL Engine inicializado com sucesso")
    
    def process_cobol_files(self, fontes_path: str, books_path: str, output_dir: str) -> Dict[str, Any]:
        """
        Processa arquivos COBOL e gera documentação.
        
        Args:
            fontes_path: Caminho para arquivo de fontes
            books_path: Caminho para arquivo de books
            output_dir: Diretório de saída
            
        Returns:
            Resultados do processamento
        """
        try:
            self._logger.info(f"Iniciando processamento: fontes={fontes_path}, books={books_path}")
            
            # 1. Parse dos arquivos
            programs = self._parse_programs(fontes_path)
            books = self._parse_books(books_path)
            
            # 2. Análise de relacionamentos
            analysis_results = self._analyze_relationships(programs, books)
            
            # 3. Análise com IA
            ai_analysis = self._analyze_with_ai(programs, analysis_results)
            
            # 4. Geração de documentação
            documentation_results = self._generate_documentation(programs, books, ai_analysis, output_dir)
            
            # 5. Compilação dos resultados
            results = {
                'programs_count': len(programs),
                'books_count': len(books),
                'sequence': analysis_results.get('sequence', []),
                'relationships': analysis_results.get('call_relationships', {}),
                'documentation_files': documentation_results,
                'ai_analysis_summary': self._summarize_ai_analysis(ai_analysis)
            }
            
            self._logger.info("Processamento concluído com sucesso")
            return results
            
        except Exception as e:
            self._logger.error(f"Erro durante processamento: {str(e)}")
            raise CobolEngineError(f"Erro no processamento: {str(e)}")
    
    def _parse_programs(self, fontes_path: str) -> List[CobolProgram]:
        """Parse dos programas COBOL."""
        self._logger.info("Parseando programas COBOL...")
        
        with open(fontes_path, 'r', encoding='utf-8', errors='ignore') as file:
            content = file.read()
        
        programs_dict = self._cobol_parser.extract_programs(content)
        programs = []
        
        for name, program_content in programs_dict.items():
            program = CobolProgram(name=name)
            program.source_lines = program_content.split('\n')
            
            # Extrai informações básicas do programa
            self._extract_program_info(program)
            
            programs.append(program)
        
        self._logger.info(f"Parseados {len(programs)} programas")
        return programs
    
    def _parse_books(self, books_path: str) -> List[CobolBook]:
        """Parse dos books/copybooks."""
        self._logger.info("Parseando books/copybooks...")
        
        books = self._books_parser.parse_books(books_path)
        
        self._logger.info(f"Parseados {len(books)} books")
        return books
    
    def _analyze_relationships(self, programs: List[CobolProgram], books: List[CobolBook]) -> Dict[str, Any]:
        """Análise de relacionamentos entre programas."""
        self._logger.info("Analisando relacionamentos...")
        
        analysis = self._program_analyzer.analyze_relationships(programs, books)
        sequence = self._program_analyzer.identify_program_sequence(programs)
        
        analysis['sequence'] = sequence
        
        self._logger.info("Análise de relacionamentos concluída")
        return analysis
    
    def _analyze_with_ai(self, programs: List[CobolProgram], analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """Análise dos programas usando IA."""
        self._logger.info("Iniciando análise com IA...")
        
        ai_results = {}
        
        for program in programs:
            try:
                # Prepara contexto para IA
                context = {
                    'program_name': program.name,
                    'author': program.author or 'Não informado',
                    'complexity_metrics': program.get_complexity_metrics(),
                    'relationships': analysis_results.get('call_relationships', {}).get(program.name, [])
                }
                
                # Análise de resumo
                summary_request = AIRequest(
                    analysis_type=AnalysisType.PROGRAM_SUMMARY,
                    content='\n'.join(program.source_lines[:100]),  # Primeiras 100 linhas
                    context=context,
                    max_tokens=1000
                )
                
                summary_response = self._ai_orchestrator.process_request(summary_request)
                
                if summary_response.success:
                    ai_results[program.name] = {
                        'summary': summary_response.content,
                        'provider_used': summary_response.provider,
                        'tokens_used': summary_response.tokens_used
                    }
                else:
                    ai_results[program.name] = {
                        'summary': 'Análise não disponível',
                        'error': summary_response.error_message
                    }
                
            except Exception as e:
                self._logger.warning(f"Erro na análise IA do programa {program.name}: {str(e)}")
                ai_results[program.name] = {
                    'summary': 'Erro na análise',
                    'error': str(e)
                }
        
        self._logger.info("Análise com IA concluída")
        return ai_results
    
    def _generate_documentation(self, programs: List[CobolProgram], books: List[CobolBook], 
                              ai_analysis: Dict[str, Any], output_dir: str) -> List[str]:
        """Gera documentação para os programas."""
        self._logger.info("Gerando documentação...")
        
        os.makedirs(output_dir, exist_ok=True)
        generated_files = []
        
        # Gera documentação individual para cada programa
        for program in programs:
            program_analysis = ai_analysis.get(program.name, {})
            
            # Prepara dados para documentação
            analysis_data = {
                'summary': program_analysis.get('summary', 'Resumo não disponível'),
                'technical_details': {
                    'complexidade': str(program.get_complexity_metrics()),
                    'linhas_codigo': str(len(program.source_lines))
                },
                'functional_details': {
                    'objetivo': program.objective or 'Não informado',
                    'autor': program.author or 'Não informado'
                },
                'relationships': {
                    'called_programs': list(program.called_programs),
                    'used_copybooks': list(program.used_copybooks)
                }
            }
            
            # Gera documentação
            documentation = self._doc_generator.generate_documentation(program, analysis_data)
            
            # Salva arquivo
            file_path = os.path.join(output_dir, f"{program.name}.md")
            self._doc_generator.save_documentation(documentation, file_path)
            generated_files.append(file_path)
        
        # Gera relatório completo
        complete_analysis = {
            'sequence': self._program_analyzer.identify_program_sequence(programs)
        }
        
        full_report = self._doc_generator.generate_full_report(programs, books, complete_analysis)
        report_path = os.path.join(output_dir, "relatorio_completo.md")
        self._doc_generator.save_documentation(full_report, report_path)
        generated_files.append(report_path)
        
        self._logger.info(f"Documentação gerada: {len(generated_files)} arquivos")
        return generated_files
    
    def _initialize_ai_providers(self):
        """Inicializa provedores de IA configurados."""
        try:
            # Verifica se deve usar mock_ai
            primary_config_name = self._config_manager._config.get('ai', {}).get('primary_provider', 'openai')
            
            if primary_config_name == 'mock_ai':
                # Cria configuração mock
                from ...domain.entities.ai_configuration import AIConfiguration
                mock_config = AIConfiguration(
                    api_key="mock_key",
                    model_name="mock-gpt-4",
                    max_tokens=4000,
                    temperature=0.3
                )
                
                mock_provider = self._ai_factory.create_provider("mock_ai", mock_config)
                self._ai_orchestrator.add_provider(mock_provider, priority=10)
                self._logger.info("Provedor Mock AI configurado como primário")
                return
            
            # Configuração normal para outros provedores
            primary_provider = self._config_manager.get_primary_provider()
            fallback_providers = self._config_manager.get_fallback_providers()
            
            # Adiciona provedor primário
            try:
                primary_config = self._config_manager.get_ai_configuration(primary_provider)
                primary_ai = self._ai_factory.create_provider(primary_provider.value, primary_config)
                self._ai_orchestrator.add_provider(primary_ai, priority=10)
                self._logger.info(f"Provedor primário {primary_provider.value} configurado")
            except Exception as e:
                self._logger.warning(f"Erro configurando provedor primário: {e}")
            
            # Adiciona provedores de fallback
            for i, provider_type in enumerate(fallback_providers):
                try:
                    config = self._config_manager.get_ai_configuration(provider_type)
                    provider = self._ai_factory.create_provider(provider_type.value, config)
                    self._ai_orchestrator.add_provider(provider, priority=5-i)
                    self._logger.info(f"Provedor de fallback {provider_type.value} configurado")
                except Exception as e:
                    self._logger.warning(f"Erro configurando provedor {provider_type.value}: {e}")
                    
        except Exception as e:
            self._logger.warning(f"Erro inicializando provedores de IA: {e}")
    
    def _extract_program_info(self, program: CobolProgram):
        """Extrai informações básicas do programa."""
        for line in program.source_lines[:50]:  # Procura nas primeiras 50 linhas
            line_upper = line.upper().strip()
            
            if 'PROGRAM-ID' in line_upper:
                # Já temos o nome do programa
                pass
            elif 'AUTHOR' in line_upper:
                parts = line_upper.split('AUTHOR')
                if len(parts) > 1:
                    program.author = parts[1].strip(' .').replace('.', '')
            elif 'OBJETIVO' in line_upper or 'PURPOSE' in line_upper:
                program.objective = line.strip()
    
    def _summarize_ai_analysis(self, ai_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Cria resumo da análise de IA."""
        total_programs = len(ai_analysis)
        successful_analyses = sum(1 for result in ai_analysis.values() if 'error' not in result)
        total_tokens = sum(result.get('tokens_used', 0) for result in ai_analysis.values())
        
        providers_used = {}
        for result in ai_analysis.values():
            provider = result.get('provider_used')
            if provider:
                providers_used[provider] = providers_used.get(provider, 0) + 1
        
        return {
            'total_programs': total_programs,
            'successful_analyses': successful_analyses,
            'success_rate': (successful_analyses / total_programs * 100) if total_programs > 0 else 0,
            'total_tokens_used': total_tokens,
            'providers_used': providers_used
        }

