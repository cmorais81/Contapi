"""
Exceções customizadas para o domínio COBOL.
Segue boas práticas de tratamento de erros.
"""


class CobolEngineError(Exception):
    """Exceção base para erros do motor COBOL."""
    pass


class CobolParseError(CobolEngineError):
    """Erro durante o parsing de arquivos COBOL."""
    
    def __init__(self, message: str, file_path: str = None, line_number: int = None):
        self.file_path = file_path
        self.line_number = line_number
        
        error_msg = f"Erro de parsing: {message}"
        if file_path:
            error_msg += f" (arquivo: {file_path})"
        if line_number:
            error_msg += f" (linha: {line_number})"
            
        super().__init__(error_msg)


class CobolValidationError(CobolEngineError):
    """Erro de validação de dados COBOL."""
    pass


class CobolAnalysisError(CobolEngineError):
    """Erro durante análise de programas COBOL."""
    pass


class AIProviderError(CobolEngineError):
    """Erro relacionado aos provedores de IA."""
    
    def __init__(self, message: str, provider: str = None, error_code: str = None):
        self.provider = provider
        self.error_code = error_code
        
        error_msg = f"Erro do provedor de IA: {message}"
        if provider:
            error_msg += f" (provedor: {provider})"
        if error_code:
            error_msg += f" (código: {error_code})"
            
        super().__init__(error_msg)


class ConfigurationError(CobolEngineError):
    """Erro de configuração do sistema."""
    pass


class DocumentationGenerationError(CobolEngineError):
    """Erro durante geração de documentação."""
    pass

