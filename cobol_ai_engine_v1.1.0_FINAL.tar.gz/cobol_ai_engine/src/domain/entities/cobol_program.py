"""
Entidade que representa um programa COBOL.
Segue o princípio Single Responsibility (SRP) do SOLID.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Set
from datetime import datetime


@dataclass
class CobolProgram:
    """Representa um programa COBOL com suas características e metadados."""
    
    name: str
    author: Optional[str] = None
    date_written: Optional[str] = None
    date_compiled: Optional[str] = None
    objective: Optional[str] = None
    version_history: List[Dict[str, str]] = field(default_factory=list)
    source_lines: List[str] = field(default_factory=list)
    divisions: Dict[str, List[str]] = field(default_factory=dict)
    called_programs: Set[str] = field(default_factory=set)
    used_copybooks: Set[str] = field(default_factory=set)
    file_descriptors: List[str] = field(default_factory=list)
    working_storage: List[str] = field(default_factory=list)
    procedure_division: List[str] = field(default_factory=list)
    comments: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Validações pós-inicialização."""
        if not self.name:
            raise ValueError("Nome do programa é obrigatório")
    
    def add_called_program(self, program_name: str) -> None:
        """Adiciona um programa chamado por este programa."""
        if program_name:
            self.called_programs.add(program_name.strip())
    
    def add_used_copybook(self, copybook_name: str) -> None:
        """Adiciona um copybook usado por este programa."""
        if copybook_name:
            self.used_copybooks.add(copybook_name.strip())
    
    def add_version_entry(self, version: str, date: str, author: str, reason: str) -> None:
        """Adiciona entrada no histórico de versões."""
        self.version_history.append({
            'version': version,
            'date': date,
            'author': author,
            'reason': reason
        })
    
    def get_complexity_metrics(self) -> Dict[str, int]:
        """Retorna métricas de complexidade do programa."""
        return {
            'total_lines': len(self.source_lines),
            'comment_lines': len(self.comments),
            'procedure_lines': len(self.procedure_division),
            'called_programs_count': len(self.called_programs),
            'used_copybooks_count': len(self.used_copybooks),
            'file_descriptors_count': len(self.file_descriptors)
        }
    
    def has_relationship_with(self, other_program: 'CobolProgram') -> bool:
        """Verifica se este programa tem relacionamento com outro."""
        return (other_program.name in self.called_programs or 
                self.name in other_program.called_programs or
                bool(self.used_copybooks.intersection(other_program.used_copybooks)))
    
    def get_summary(self) -> Dict[str, str]:
        """Retorna resumo do programa para documentação."""
        return {
            'name': self.name,
            'author': self.author or 'Não informado',
            'objective': self.objective or 'Não informado',
            'complexity': str(self.get_complexity_metrics()),
            'dependencies': f"Chama: {', '.join(self.called_programs) if self.called_programs else 'Nenhum'}, "
                          f"Usa: {', '.join(self.used_copybooks) if self.used_copybooks else 'Nenhum'}"
        }

