"""
Entidade para requisições de IA.
"""

from dataclasses import dataclass
from typing import Optional

@dataclass
class AIRequest:
    """Requisição para análise de IA."""
    
    program_name: str
    code_content: str
    analysis_type: str
    context: Optional[str] = None
    
    def __post_init__(self):
        """Validação pós-inicialização."""
        if not self.program_name:
            raise ValueError("program_name é obrigatório")
        if not self.code_content:
            raise ValueError("code_content é obrigatório")
        if not self.analysis_type:
            raise ValueError("analysis_type é obrigatório")

