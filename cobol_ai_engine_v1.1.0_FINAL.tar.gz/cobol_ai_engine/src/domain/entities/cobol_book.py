"""
Entidade que representa um book/copybook COBOL.
Segue o princípio Single Responsibility (SRP) do SOLID.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Set
from enum import Enum


class BookType(Enum):
    """Tipos de books/copybooks."""
    COPYBOOK = "copybook"
    TABLE = "table"
    STRUCTURE = "structure"
    CONSTANTS = "constants"
    UNKNOWN = "unknown"


@dataclass
class CobolBook:
    """Representa um book/copybook COBOL com suas características."""
    
    name: str
    book_type: BookType = BookType.UNKNOWN
    description: Optional[str] = None
    source_lines: List[str] = field(default_factory=list)
    data_structures: List[str] = field(default_factory=list)
    constants: Dict[str, str] = field(default_factory=dict)
    tables: List[str] = field(default_factory=list)
    used_by_programs: Set[str] = field(default_factory=set)
    comments: List[str] = field(default_factory=list)
    version_info: Optional[str] = None
    
    def __post_init__(self):
        """Validações pós-inicialização."""
        if not self.name:
            raise ValueError("Nome do book é obrigatório")
    
    def add_using_program(self, program_name: str) -> None:
        """Adiciona um programa que usa este book."""
        if program_name:
            self.used_by_programs.add(program_name.strip())
    
    def add_data_structure(self, structure: str) -> None:
        """Adiciona uma estrutura de dados definida no book."""
        if structure:
            self.data_structures.append(structure.strip())
    
    def add_constant(self, name: str, value: str) -> None:
        """Adiciona uma constante definida no book."""
        if name and value:
            self.constants[name.strip()] = value.strip()
    
    def add_table(self, table_definition: str) -> None:
        """Adiciona uma tabela definida no book."""
        if table_definition:
            self.tables.append(table_definition.strip())
    
    def infer_book_type(self) -> BookType:
        """Infere o tipo do book baseado no conteúdo."""
        name_lower = self.name.lower()
        
        if 'cp' in name_lower or 'copy' in name_lower:
            return BookType.COPYBOOK
        elif 'tab' in name_lower or len(self.tables) > 0:
            return BookType.TABLE
        elif len(self.constants) > 0:
            return BookType.CONSTANTS
        elif len(self.data_structures) > 0:
            return BookType.STRUCTURE
        else:
            return BookType.UNKNOWN
    
    def get_usage_count(self) -> int:
        """Retorna quantos programas usam este book."""
        return len(self.used_by_programs)
    
    def is_shared_resource(self) -> bool:
        """Verifica se é um recurso compartilhado (usado por múltiplos programas)."""
        return self.get_usage_count() > 1
    
    def get_summary(self) -> Dict[str, str]:
        """Retorna resumo do book para documentação."""
        return {
            'name': self.name,
            'type': self.book_type.value,
            'description': self.description or 'Não informado',
            'usage_count': str(self.get_usage_count()),
            'used_by': ', '.join(self.used_by_programs) if self.used_by_programs else 'Nenhum programa',
            'structures_count': str(len(self.data_structures)),
            'constants_count': str(len(self.constants)),
            'tables_count': str(len(self.tables))
        }

