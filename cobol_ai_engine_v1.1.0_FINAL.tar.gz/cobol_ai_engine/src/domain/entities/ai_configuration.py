"""
Entidades para configurações de IA.
Segue o princípio Single Responsibility (SRP).
"""

from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from ..interfaces.configuration import IAIConfiguration, AIProviderType


@dataclass
class OpenAIConfiguration(IAIConfiguration):
    """Configuração para OpenAI."""
    
    api_key: str
    model_name: str = "gpt-4"
    api_endpoint: Optional[str] = None
    max_tokens: int = 4000
    temperature: float = 0.3
    organization: Optional[str] = None
    additional_parameters: Dict[str, Any] = field(default_factory=dict)
    
    def get_provider_type(self) -> AIProviderType:
        return AIProviderType.OPENAI
    
    def get_api_key(self) -> Optional[str]:
        return self.api_key
    
    def get_api_endpoint(self) -> Optional[str]:
        return self.api_endpoint or "https://api.openai.com/v1"
    
    def get_model_name(self) -> str:
        return self.model_name
    
    def get_max_tokens(self) -> int:
        return self.max_tokens
    
    def get_temperature(self) -> float:
        return self.temperature
    
    def get_additional_parameters(self) -> Dict[str, Any]:
        params = self.additional_parameters.copy()
        if self.organization:
            params['organization'] = self.organization
        return params


@dataclass
class CopilotConfiguration(IAIConfiguration):
    """Configuração para GitHub Copilot."""
    
    api_key: str
    model_name: str = "gpt-4"
    api_endpoint: Optional[str] = None
    max_tokens: int = 4000
    temperature: float = 0.3
    additional_parameters: Dict[str, Any] = field(default_factory=dict)
    
    def get_provider_type(self) -> AIProviderType:
        return AIProviderType.COPILOT
    
    def get_api_key(self) -> Optional[str]:
        return self.api_key
    
    def get_api_endpoint(self) -> Optional[str]:
        return self.api_endpoint or "https://api.githubcopilot.com/v1"
    
    def get_model_name(self) -> str:
        return self.model_name
    
    def get_max_tokens(self) -> int:
        return self.max_tokens
    
    def get_temperature(self) -> float:
        return self.temperature
    
    def get_additional_parameters(self) -> Dict[str, Any]:
        return self.additional_parameters.copy()


@dataclass
class BedrockConfiguration(IAIConfiguration):
    """Configuração para AWS Bedrock."""
    
    aws_access_key_id: str
    aws_secret_access_key: str
    aws_region: str = "us-east-1"
    model_name: str = "anthropic.claude-3-sonnet-20240229-v1:0"
    max_tokens: int = 4000
    temperature: float = 0.3
    additional_parameters: Dict[str, Any] = field(default_factory=dict)
    
    def get_provider_type(self) -> AIProviderType:
        return AIProviderType.BEDROCK
    
    def get_api_key(self) -> Optional[str]:
        return self.aws_access_key_id
    
    def get_api_endpoint(self) -> Optional[str]:
        return f"https://bedrock-runtime.{self.aws_region}.amazonaws.com"
    
    def get_model_name(self) -> str:
        return self.model_name
    
    def get_max_tokens(self) -> int:
        return self.max_tokens
    
    def get_temperature(self) -> float:
        return self.temperature
    
    def get_additional_parameters(self) -> Dict[str, Any]:
        params = self.additional_parameters.copy()
        params.update({
            'aws_secret_access_key': self.aws_secret_access_key,
            'aws_region': self.aws_region
        })
        return params


@dataclass
class ParsingConfiguration:
    """Configuração para parsing COBOL."""
    
    extract_comments: bool = True
    extract_version_history: bool = True
    validate_cobol_format: bool = True
    clean_sequence_numbers: bool = True
    max_line_length: int = 72
    comment_indicator: str = "*"
    debug_indicator: str = "D"
    continuation_indicator: str = "-"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'extract_comments': self.extract_comments,
            'extract_version_history': self.extract_version_history,
            'validate_cobol_format': self.validate_cobol_format,
            'clean_sequence_numbers': self.clean_sequence_numbers,
            'max_line_length': self.max_line_length,
            'comment_indicator': self.comment_indicator,
            'debug_indicator': self.debug_indicator,
            'continuation_indicator': self.continuation_indicator
        }


@dataclass
class DocumentationConfiguration:
    """Configuração para geração de documentação."""
    
    include_version_history: bool = True
    include_complexity_metrics: bool = True
    include_relationship_diagram: bool = True
    include_sequence_analysis: bool = True
    include_code_samples: bool = False
    max_code_sample_lines: int = 20
    output_format: str = "markdown"
    language: str = "pt-br"
    template_style: str = "technical"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'include_version_history': self.include_version_history,
            'include_complexity_metrics': self.include_complexity_metrics,
            'include_relationship_diagram': self.include_relationship_diagram,
            'include_sequence_analysis': self.include_sequence_analysis,
            'include_code_samples': self.include_code_samples,
            'max_code_sample_lines': self.max_code_sample_lines,
            'output_format': self.output_format,
            'language': self.language,
            'template_style': self.template_style
        }

