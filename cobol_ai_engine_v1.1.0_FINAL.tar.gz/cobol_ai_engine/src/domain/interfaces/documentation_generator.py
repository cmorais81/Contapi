"""
Interfaces para o gerador de documentação.
Segue o padrão Template Method e princípios SOLID.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from ..entities.cobol_program import CobolProgram
from ..entities.cobol_book import CobolBook


class IDocumentationGenerator(ABC):
    """Interface base para geradores de documentação."""
    
    @abstractmethod
    def generate_documentation(self, program: CobolProgram, analysis_results: Dict[str, Any]) -> str:
        """
        Gera documentação para um programa COBOL.
        
        Args:
            program: Programa COBOL a ser documentado
            analysis_results: Resultados da análise de IA
            
        Returns:
            Documentação gerada
        """
        pass
    
    @abstractmethod
    def generate_full_report(self, programs: List[CobolProgram], books: List[CobolBook], analysis_results: Dict[str, Any]) -> str:
        """
        Gera relatório completo para múltiplos programas.
        
        Args:
            programs: Lista de programas COBOL
            books: Lista de books/copybooks
            analysis_results: Resultados da análise de IA
            
        Returns:
            Relatório completo gerado
        """
        pass
    
    @abstractmethod
    def save_documentation(self, content: str, file_path: str) -> None:
        """
        Salva documentação em arquivo.
        
        Args:
            content: Conteúdo da documentação
            file_path: Caminho para salvar o arquivo
        """
        pass


class ITemplateEngine(ABC):
    """Interface para motores de template."""
    
    @abstractmethod
    def render(self, template_name: str, context: Dict[str, Any]) -> str:
        """
        Renderiza um template com o contexto fornecido.
        
        Args:
            template_name: Nome do template
            context: Contexto para renderização
            
        Returns:
            Conteúdo renderizado
        """
        pass
    
    @abstractmethod
    def load_template(self, template_content: str) -> Any:
        """
        Carrega um template a partir de uma string.
        
        Args:
            template_content: Conteúdo do template
            
        Returns:
            Template carregado
        """
        pass


class IDocumentationFormatter(ABC):
    """Interface para formatadores de documentação."""
    
    @abstractmethod
    def format_title(self, text: str, level: int = 1) -> str:
        """
        Formata um título.
        
        Args:
            text: Texto do título
            level: Nível do título (1-6)
            
        Returns:
            Título formatado
        """
        pass
    
    @abstractmethod
    def format_table(self, headers: List[str], rows: List[List[str]]) -> str:
        """
        Formata uma tabela.
        
        Args:
            headers: Cabeçalhos da tabela
            rows: Linhas da tabela
            
        Returns:
            Tabela formatada
        """
        pass
    
    @abstractmethod
    def format_code_block(self, code: str, language: str = "cobol") -> str:
        """
        Formata um bloco de código.
        
        Args:
            code: Código a ser formatado
            language: Linguagem do código
            
        Returns:
            Bloco de código formatado
        """
        pass
    
    @abstractmethod
    def format_list(self, items: List[str], ordered: bool = False) -> str:
        """
        Formata uma lista.
        
        Args:
            items: Itens da lista
            ordered: Se a lista é ordenada
            
        Returns:
            Lista formatada
        """
        pass

