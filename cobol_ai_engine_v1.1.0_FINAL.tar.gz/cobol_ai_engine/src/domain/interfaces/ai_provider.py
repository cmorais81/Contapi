"""
Interfaces para provedores de IA.
Segue os princípios Strategy Pattern e Interface Segregation (ISP).
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from enum import Enum
from dataclasses import dataclass


class AnalysisType(Enum):
    """Tipos de análise que podem ser solicitadas à IA."""
    PROGRAM_SUMMARY = "program_summary"
    TECHNICAL_DOCUMENTATION = "technical_documentation"
    FUNCTIONAL_DOCUMENTATION = "functional_documentation"
    RELATIONSHIP_ANALYSIS = "relationship_analysis"
    COMPLEXITY_ANALYSIS = "complexity_analysis"
    SEQUENCE_ANALYSIS = "sequence_analysis"


@dataclass
class AIRequest:
    """Representa uma solicitação para IA."""
    analysis_type: AnalysisType
    content: str
    context: Dict[str, Any]
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    additional_parameters: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.additional_parameters is None:
            self.additional_parameters = {}


@dataclass
class AIResponse:
    """Representa uma resposta da IA."""
    content: str
    provider: str
    model: str
    tokens_used: int
    success: bool
    error_message: Optional[str] = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class IAIProvider(ABC):
    """Interface base para provedores de IA."""
    
    @abstractmethod
    def analyze_cobol_program(self, request: AIRequest) -> AIResponse:
        """
        Analisa um programa COBOL usando IA.
        
        Args:
            request: Solicitação de análise
            
        Returns:
            Resposta da análise
            
        Raises:
            AIProviderError: Erro durante análise
        """
        pass
    
    @abstractmethod
    def generate_documentation(self, request: AIRequest) -> AIResponse:
        """
        Gera documentação usando IA.
        
        Args:
            request: Solicitação de geração
            
        Returns:
            Documentação gerada
        """
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        
        Returns:
            True se disponível, False caso contrário
        """
        pass
    
    @abstractmethod
    def get_provider_name(self) -> str:
        """Retorna nome do provedor."""
        pass
    
    @abstractmethod
    def get_supported_models(self) -> List[str]:
        """Retorna lista de modelos suportados."""
        pass
    
    @abstractmethod
    def estimate_cost(self, request: AIRequest) -> float:
        """
        Estima custo da solicitação.
        
        Args:
            request: Solicitação a ser estimada
            
        Returns:
            Custo estimado em USD
        """
        pass


class IAIProviderFactory(ABC):
    """Interface para factory de provedores de IA."""
    
    @abstractmethod
    def create_provider(self, provider_type: str, configuration: Dict[str, Any]) -> IAIProvider:
        """
        Cria um provedor de IA.
        
        Args:
            provider_type: Tipo do provedor
            configuration: Configuração do provedor
            
        Returns:
            Instância do provedor
        """
        pass
    
    @abstractmethod
    def get_supported_providers(self) -> List[str]:
        """Retorna lista de provedores suportados."""
        pass


class IAIOrchestrator(ABC):
    """Interface para orquestrador de múltiplas IAs."""
    
    @abstractmethod
    def process_request(self, request: AIRequest) -> AIResponse:
        """
        Processa solicitação usando provedor primário e fallbacks.
        
        Args:
            request: Solicitação a ser processada
            
        Returns:
            Resposta da IA
        """
        pass
    
    @abstractmethod
    def add_provider(self, provider: IAIProvider, priority: int = 0) -> None:
        """
        Adiciona provedor ao orquestrador.
        
        Args:
            provider: Provedor a ser adicionado
            priority: Prioridade (maior = mais prioritário)
        """
        pass
    
    @abstractmethod
    def remove_provider(self, provider_name: str) -> None:
        """
        Remove provedor do orquestrador.
        
        Args:
            provider_name: Nome do provedor a ser removido
        """
        pass
    
    @abstractmethod
    def get_available_providers(self) -> List[str]:
        """Retorna lista de provedores disponíveis."""
        pass


class IPromptTemplate(ABC):
    """Interface para templates de prompts."""
    
    @abstractmethod
    def generate_prompt(self, analysis_type: AnalysisType, context: Dict[str, Any]) -> str:
        """
        Gera prompt para análise.
        
        Args:
            analysis_type: Tipo de análise
            context: Contexto da análise
            
        Returns:
            Prompt formatado
        """
        pass
    
    @abstractmethod
    def get_supported_analysis_types(self) -> List[AnalysisType]:
        """Retorna tipos de análise suportados."""
        pass

