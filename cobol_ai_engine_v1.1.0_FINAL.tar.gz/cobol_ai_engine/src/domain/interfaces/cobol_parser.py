"""
Interface para parsers de arquivos COBOL.
Segue o princípio Interface Segregation (ISP) do SOLID.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from ..entities.cobol_program import CobolProgram
from ..entities.cobol_book import CobolBook


class ICobolParser(ABC):
    """Interface base para parsers de arquivos COBOL."""
    
    @abstractmethod
    def parse(self, file_path: str) -> List[CobolProgram]:
        """
        Parseia um arquivo COBOL e retorna lista de programas.
        
        Args:
            file_path: Caminho para o arquivo COBOL
            
        Returns:
            Lista de programas COBOL parseados
            
        Raises:
            CobolParseError: Erro durante o parsing
        """
        pass


class ICobolFileParser(ABC):
    """Interface para parser de arquivos empilhados COBOL."""
    
    @abstractmethod
    def extract_programs(self, file_content: str) -> Dict[str, str]:
        """
        Extrai programas individuais de arquivo empilhado.
        
        Args:
            file_content: Conteúdo do arquivo empilhado
            
        Returns:
            Dicionário com nome do programa como chave e código como valor
        """
        pass


class ICobolLineExtractor(ABC):
    """Interface para extração de linhas válidas COBOL."""
    
    @abstractmethod
    def extract_cobol_lines(self, raw_lines: List[str]) -> List[str]:
        """
        Extrai linhas válidas COBOL (colunas 1-72).
        
        Args:
            raw_lines: Linhas brutas do arquivo
            
        Returns:
            Lista de linhas COBOL válidas
        """
        pass


class ICommentIdentifier(ABC):
    """Interface para identificação de comentários."""
    
    @abstractmethod
    def is_comment(self, line: str) -> bool:
        """
        Verifica se uma linha é comentário (coluna 7 com *).
        
        Args:
            line: Linha a ser verificada
            
        Returns:
            True se for comentário, False caso contrário
        """
        pass


class IBooksParser(ABC):
    """Interface para parser de books/copybooks."""
    
    @abstractmethod
    def parse_books(self, file_path: str) -> List[CobolBook]:
        """
        Parseia arquivo de books/copybooks.
        
        Args:
            file_path: Caminho para o arquivo de books
            
        Returns:
            Lista de books parseados
        """
        pass


class IProgramAnalyzer(ABC):
    """Interface para análise de relacionamentos entre programas."""
    
    @abstractmethod
    def analyze_relationships(self, programs: List[CobolProgram], books: List[CobolBook]) -> Dict[str, Any]:
        """
        Analisa relacionamentos e dependências entre programas.
        
        Args:
            programs: Lista de programas COBOL
            books: Lista de books/copybooks
            
        Returns:
            Dicionário com análise de relacionamentos
        """
        pass
    
    @abstractmethod
    def identify_program_sequence(self, programs: List[CobolProgram]) -> List[str]:
        """
        Identifica sequência/linhagem entre programas.
        
        Args:
            programs: Lista de programas COBOL
            
        Returns:
            Lista ordenada de nomes de programas na sequência de execução
        """
        pass

