"""
Interfaces para sistema de configuração parametrizável.
Segue os princípios Open/Closed (OCP) e Dependency Inversion (DIP).
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from enum import Enum


class AIProviderType(Enum):
    """Tipos de provedores de IA suportados."""
    OPENAI = "openai"
    COPILOT = "copilot"
    BEDROCK = "bedrock"


class ConfigurationSource(Enum):
    """Fontes de configuração suportadas."""
    YAML = "yaml"
    JSON = "json"
    ENV = "environment"


class IConfigurationProvider(ABC):
    """Interface para provedores de configuração."""
    
    @abstractmethod
    def load_configuration(self, source: str) -> Dict[str, Any]:
        """
        Carrega configuração de uma fonte.
        
        Args:
            source: Caminho ou identificador da fonte de configuração
            
        Returns:
            Dicionário com configurações carregadas
            
        Raises:
            ConfigurationError: Erro ao carregar configuração
        """
        pass
    
    @abstractmethod
    def validate_configuration(self, config: Dict[str, Any]) -> bool:
        """
        Valida configuração carregada.
        
        Args:
            config: Configuração a ser validada
            
        Returns:
            True se válida, False caso contrário
        """
        pass
    
    @abstractmethod
    def get_supported_sources(self) -> List[ConfigurationSource]:
        """
        Retorna lista de fontes de configuração suportadas.
        
        Returns:
            Lista de fontes suportadas
        """
        pass


class IAIConfiguration(ABC):
    """Interface para configurações de IA."""
    
    @abstractmethod
    def get_provider_type(self) -> AIProviderType:
        """Retorna tipo do provedor de IA."""
        pass
    
    @abstractmethod
    def get_api_key(self) -> Optional[str]:
        """Retorna chave da API."""
        pass
    
    @abstractmethod
    def get_api_endpoint(self) -> Optional[str]:
        """Retorna endpoint da API."""
        pass
    
    @abstractmethod
    def get_model_name(self) -> str:
        """Retorna nome do modelo a ser usado."""
        pass
    
    @abstractmethod
    def get_max_tokens(self) -> int:
        """Retorna número máximo de tokens."""
        pass
    
    @abstractmethod
    def get_temperature(self) -> float:
        """Retorna temperatura para geração."""
        pass
    
    @abstractmethod
    def get_additional_parameters(self) -> Dict[str, Any]:
        """Retorna parâmetros adicionais específicos do provedor."""
        pass


class IConfigurationManager(ABC):
    """Interface para gerenciador de configurações."""
    
    @abstractmethod
    def load_from_file(self, file_path: str) -> None:
        """
        Carrega configuração de arquivo.
        
        Args:
            file_path: Caminho para arquivo de configuração
        """
        pass
    
    @abstractmethod
    def get_ai_configuration(self, provider_type: AIProviderType) -> IAIConfiguration:
        """
        Retorna configuração para um provedor de IA.
        
        Args:
            provider_type: Tipo do provedor de IA
            
        Returns:
            Configuração do provedor
        """
        pass
    
    @abstractmethod
    def get_primary_provider(self) -> AIProviderType:
        """Retorna provedor primário configurado."""
        pass
    
    @abstractmethod
    def get_fallback_providers(self) -> List[AIProviderType]:
        """Retorna lista de provedores de fallback."""
        pass
    
    @abstractmethod
    def get_parsing_configuration(self) -> Dict[str, Any]:
        """Retorna configurações de parsing COBOL."""
        pass
    
    @abstractmethod
    def get_documentation_configuration(self) -> Dict[str, Any]:
        """Retorna configurações de geração de documentação."""
        pass
    
    @abstractmethod
    def is_valid(self) -> bool:
        """Verifica se configuração atual é válida."""
        pass

