"""
Gerenciador de configurações seguindo padrão Strategy.
Segue os princípios SOLID, especialmente OCP e DIP.
"""

import os
import yaml
import json
import logging
from typing import Dict, Any, Optional, List
from ...domain.interfaces.configuration import (
    IConfigurationManager, IAIConfiguration, AIProviderType, ConfigurationSource
)
from ...domain.entities.ai_configuration import (
    OpenAIConfiguration, CopilotConfiguration, BedrockConfiguration,
    ParsingConfiguration, DocumentationConfiguration
)
from ...domain.entities.exceptions import ConfigurationError


class ConfigurationManager(IConfigurationManager):
    """Gerenciador central de configurações."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Inicializa o gerenciador de configurações.
        
        Args:
            logger: Logger para registrar operações
        """
        self._logger = logger or logging.getLogger(__name__)
        self._config: Dict[str, Any] = {}
        self._ai_configurations: Dict[AIProviderType, IAIConfiguration] = {}
        self._parsing_config: Optional[ParsingConfiguration] = None
        self._documentation_config: Optional[DocumentationConfiguration] = None
        
    def load_from_file(self, file_path: str) -> None:
        """
        Carrega configuração de arquivo.
        
        Args:
            file_path: Caminho para arquivo de configuração
            
        Raises:
            ConfigurationError: Erro ao carregar configuração
        """
        try:
            self._logger.info(f"Carregando configuração de: {file_path}")
            
            if not os.path.exists(file_path):
                raise ConfigurationError(f"Arquivo de configuração não encontrado: {file_path}")
            
            # Determina tipo do arquivo pela extensão
            _, ext = os.path.splitext(file_path)
            
            with open(file_path, 'r', encoding='utf-8') as file:
                if ext.lower() in ['.yaml', '.yml']:
                    self._config = yaml.safe_load(file)
                elif ext.lower() == '.json':
                    self._config = json.load(file)
                else:
                    raise ConfigurationError(f"Formato de arquivo não suportado: {ext}")
            
            # Valida e processa configuração
            self._validate_configuration()
            self._process_configuration()
            
            self._logger.info("Configuração carregada com sucesso")
            
        except Exception as e:
            if isinstance(e, ConfigurationError):
                raise
            raise ConfigurationError(f"Erro carregando configuração: {str(e)}")
    
    def get_ai_configuration(self, provider_type: AIProviderType) -> IAIConfiguration:
        """
        Retorna configuração para um provedor de IA.
        
        Args:
            provider_type: Tipo do provedor de IA
            
        Returns:
            Configuração do provedor
            
        Raises:
            ConfigurationError: Provedor não configurado
        """
        if provider_type not in self._ai_configurations:
            raise ConfigurationError(f"Provedor {provider_type.value} não configurado")
        
        return self._ai_configurations[provider_type]
    
    def get_primary_provider(self) -> AIProviderType:
        """Retorna o provedor primário de IA."""
        primary = self._config.get('ai', {}).get('primary_provider', 'openai')
        
        # Tratamento especial para mock_ai
        if primary == 'mock_ai':
            return AIProviderType.OPENAI  # Usa OpenAI como tipo base
        
        try:
            return AIProviderType(primary)
        except ValueError:
            self._logger.warning(f"Provedor primário inválido: {primary}, usando OpenAI")
            return AIProviderType.OPENAI
    
    def get_fallback_providers(self) -> List[AIProviderType]:
        """Retorna lista de provedores de fallback."""
        fallbacks = self._config.get('ai', {}).get('fallback_providers', [])
        valid_fallbacks = []
        
        for provider in fallbacks:
            try:
                valid_fallbacks.append(AIProviderType(provider))
            except ValueError:
                self._logger.warning(f"Provedor de fallback inválido: {provider}")
        
        return valid_fallbacks
    
    def get_parsing_configuration(self) -> Dict[str, Any]:
        """Retorna configurações de parsing COBOL."""
        if self._parsing_config:
            return self._parsing_config.to_dict()
        
        # Configuração padrão
        return ParsingConfiguration().to_dict()
    
    def get_documentation_configuration(self) -> Dict[str, Any]:
        """Retorna configurações de geração de documentação."""
        if self._documentation_config:
            return self._documentation_config.to_dict()
        
        # Configuração padrão
        return DocumentationConfiguration().to_dict()
    
    def is_valid(self) -> bool:
        """Verifica se configuração atual é válida."""
        try:
            # Verifica se tem pelo menos um provedor de IA configurado
            if not self._ai_configurations:
                return False
            
            # Verifica se provedor primário está configurado
            primary = self.get_primary_provider()
            if primary not in self._ai_configurations:
                return False
            
            # Verifica configurações básicas
            for provider_type, config in self._ai_configurations.items():
                if not config.get_api_key():
                    self._logger.warning(f"API key não configurada para {provider_type.value}")
                    return False
            
            return True
            
        except Exception as e:
            self._logger.error(f"Erro validando configuração: {str(e)}")
            return False
    
    def _validate_configuration(self) -> None:
        """Valida estrutura da configuração."""
        if not isinstance(self._config, dict):
            raise ConfigurationError("Configuração deve ser um objeto JSON/YAML")
        
        # Verifica seção de IA
        if 'ai' not in self._config:
            raise ConfigurationError("Seção 'ai' é obrigatória na configuração")
        
        ai_config = self._config['ai']
        if not isinstance(ai_config, dict):
            raise ConfigurationError("Seção 'ai' deve ser um objeto")
        
        # Verifica se tem pelo menos um provedor configurado
        providers = ai_config.get('providers', {})
        if not providers:
            raise ConfigurationError("Pelo menos um provedor de IA deve ser configurado")
    
    def _process_configuration(self) -> None:
        """Processa configuração carregada."""
        ai_config = self._config.get('ai', {})
        providers = ai_config.get('providers', {})
        
        # Processa configurações de provedores de IA
        for provider_name, provider_config in providers.items():
            try:
                provider_type = AIProviderType(provider_name)
                ai_configuration = self._create_ai_configuration(provider_type, provider_config)
                self._ai_configurations[provider_type] = ai_configuration
                
                self._logger.debug(f"Provedor {provider_name} configurado com sucesso")
                
            except ValueError:
                self._logger.warning(f"Provedor desconhecido ignorado: {provider_name}")
            except Exception as e:
                self._logger.error(f"Erro configurando provedor {provider_name}: {str(e)}")
        
        # Processa configuração de parsing
        parsing_config = self._config.get('parsing', {})
        if parsing_config:
            self._parsing_config = ParsingConfiguration(**parsing_config)
        
        # Processa configuração de documentação
        doc_config = self._config.get('documentation', {})
        if doc_config:
            self._documentation_config = DocumentationConfiguration(**doc_config)
    
    def _create_ai_configuration(self, provider_type: AIProviderType, config: Dict[str, Any]) -> IAIConfiguration:
        """Cria configuração específica do provedor."""
        # Substitui variáveis de ambiente
        processed_config = self._substitute_env_variables(config)
        
        if provider_type == AIProviderType.OPENAI:
            return OpenAIConfiguration(**processed_config)
        elif provider_type == AIProviderType.COPILOT:
            return CopilotConfiguration(**processed_config)
        elif provider_type == AIProviderType.BEDROCK:
            return BedrockConfiguration(**processed_config)
        else:
            raise ConfigurationError(f"Provedor não suportado: {provider_type.value}")
    
    def _substitute_env_variables(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Substitui variáveis de ambiente na configuração."""
        processed = {}
        
        for key, value in config.items():
            if isinstance(value, str) and value.startswith('${') and value.endswith('}'):
                # Extrai nome da variável de ambiente
                env_var = value[2:-1]
                env_value = os.getenv(env_var)
                
                if env_value is None:
                    raise ConfigurationError(f"Variável de ambiente não encontrada: {env_var}")
                
                processed[key] = env_value
            else:
                processed[key] = value
        
        return processed
    
    def load_from_environment(self) -> None:
        """Carrega configuração de variáveis de ambiente."""
        self._logger.info("Carregando configuração de variáveis de ambiente")
        
        # Configuração básica do OpenAI
        openai_key = os.getenv('OPENAI_API_KEY')
        if openai_key:
            openai_config = OpenAIConfiguration(
                api_key=openai_key,
                api_endpoint=os.getenv('OPENAI_API_BASE'),
                model_name=os.getenv('OPENAI_MODEL', 'gpt-4')
            )
            self._ai_configurations[AIProviderType.OPENAI] = openai_config
            self._logger.debug("OpenAI configurado via variáveis de ambiente")
        
        # Configuração básica do Bedrock
        aws_key = os.getenv('AWS_ACCESS_KEY_ID')
        aws_secret = os.getenv('AWS_SECRET_ACCESS_KEY')
        if aws_key and aws_secret:
            bedrock_config = BedrockConfiguration(
                aws_access_key_id=aws_key,
                aws_secret_access_key=aws_secret,
                aws_region=os.getenv('AWS_REGION', 'us-east-1')
            )
            self._ai_configurations[AIProviderType.BEDROCK] = bedrock_config
            self._logger.debug("Bedrock configurado via variáveis de ambiente")
        
        # Configurações padrão
        self._parsing_config = ParsingConfiguration()
        self._documentation_config = DocumentationConfiguration()
        
        self._logger.info(f"Configuração de ambiente carregada. Provedores: {list(self._ai_configurations.keys())}")

