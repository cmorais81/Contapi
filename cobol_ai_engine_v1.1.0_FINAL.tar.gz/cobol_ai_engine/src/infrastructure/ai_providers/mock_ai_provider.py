"""
Provedor de IA Mock para demonstração das capacidades do sistema.
Simula análises realistas baseadas no código COBOL real.
"""

import logging
import re
from typing import Dict, Any, List, Optional
from ...domain.interfaces.ai_provider import IAIProvider, AIRequest, AIResponse, AnalysisType
from ...domain.interfaces.configuration import IAIConfiguration


class MockAIProvider(IAIProvider):
    """Provedor de IA Mock que simula análises realistas."""
    
    def __init__(self, configuration: IAIConfiguration, logger: Optional[logging.Logger] = None):
        """
        Inicializa o provedor Mock.
        
        Args:
            configuration: Configuração (não utilizada no mock)
            logger: Logger para registrar operações
        """
        self._config = configuration
        self._logger = logger or logging.getLogger(__name__)
        
        # Base de conhecimento para análises específicas por programa
        self._program_knowledge = {
            'LHAN0542': {
                'purpose': 'Programa responsável por particionar arquivo BACEN DOC3040 em múltiplos arquivos menores',
                'business_rules': [
                    'Processa arquivo de entrada sequencial do BACEN',
                    'Particiona dados baseado em critérios de volume',
                    'Gera arquivos de saída numerados sequencialmente',
                    'Controla integridade dos dados particionados'
                ],
                'technical_aspects': [
                    'Utiliza processamento sequencial de arquivos',
                    'Implementa controle de buffer para otimização',
                    'Gerencia contadores de registros processados',
                    'Aplica validações de integridade de dados'
                ],
                'logic_rules': [
                    'Validação de formato de registro DOC3040',
                    'Controle de tamanho máximo por arquivo de saída',
                    'Verificação de sequência numérica dos registros',
                    'Aplicação de checksum para integridade',
                    'Controle de duplicatas por chave primária'
                ],
                'business_logic': [
                    'Arquivo deve ser particionado em blocos de 10.000 registros',
                    'Cada arquivo de saída deve manter sequência original',
                    'Registros inválidos são direcionados para arquivo de erro',
                    'Totalizadores devem ser mantidos para reconciliação',
                    'Log de processamento deve registrar início e fim'
                ],
                'complexity': 'Média - processamento de grandes volumes'
            },
            'LHAN0705': {
                'purpose': 'Programa de validação e formatação de dados BACEN para processamento posterior',
                'business_rules': [
                    'Valida formato e conteúdo dos registros BACEN',
                    'Aplica regras de negócio específicas do DOC3040',
                    'Formata dados para padrão interno do sistema',
                    'Gera relatórios de validação e erros'
                ],
                'technical_aspects': [
                    'Implementa múltiplas rotinas de validação',
                    'Utiliza tabelas de parâmetros para configuração',
                    'Gerencia diferentes tipos de registro',
                    'Controla fluxo de processamento condicional'
                ],
                'logic_rules': [
                    'Validação de CPF/CNPJ com dígito verificador',
                    'Verificação de datas válidas e consistentes',
                    'Controle de valores monetários dentro de limites',
                    'Validação de códigos de banco e agência',
                    'Verificação de campos obrigatórios por tipo de registro'
                ],
                'business_logic': [
                    'Registros tipo 01 devem ter CPF válido',
                    'Valores não podem exceder R$ 1.000.000,00',
                    'Data de movimento deve ser dia útil',
                    'Código do banco deve existir na tabela BACEN',
                    'Conta corrente deve ter formato padrão (8 dígitos + DV)'
                ],
                'complexity': 'Alta - múltiplas validações e regras complexas'
            },
            'LHAN0706': {
                'purpose': 'Programa de consolidação e sumarização de dados processados',
                'business_rules': [
                    'Consolida dados de múltiplas fontes',
                    'Calcula totalizadores e estatísticas',
                    'Gera resumos executivos',
                    'Prepara dados para relatórios gerenciais'
                ],
                'technical_aspects': [
                    'Utiliza estruturas de dados complexas',
                    'Implementa algoritmos de agregação',
                    'Gerencia memória para grandes volumes',
                    'Otimiza acesso a arquivos indexados'
                ],
                'logic_rules': [
                    'Agrupamento por código de banco e data',
                    'Cálculo de somatórias por tipo de operação',
                    'Geração de médias ponderadas',
                    'Identificação de outliers estatísticos',
                    'Aplicação de regras de arredondamento BACEN'
                ],
                'business_logic': [
                    'Consolidação deve ser feita por instituição financeira',
                    'Totais devem bater com arquivos de origem',
                    'Diferenças acima de R$ 0,01 geram alerta',
                    'Relatório deve incluir quantidade e valor',
                    'Estatísticas devem seguir padrão BACEN'
                ],
                'complexity': 'Alta - processamento analítico complexo'
            },
            'LHBR0700': {
                'purpose': 'Programa utilitário para geração de relatórios e arquivos de controle',
                'business_rules': [
                    'Gera relatórios padronizados do BACEN',
                    'Cria arquivos de controle para auditoria',
                    'Formata saídas conforme especificações',
                    'Controla numeração e sequenciamento'
                ],
                'technical_aspects': [
                    'Utiliza rotinas de formatação avançada',
                    'Implementa controle de layout de relatórios',
                    'Gerencia impressão e arquivos de saída',
                    'Aplica máscaras e formatações específicas'
                ],
                'logic_rules': [
                    'Formatação de valores monetários com 2 decimais',
                    'Aplicação de máscaras para CPF/CNPJ',
                    'Controle de quebra de página por seção',
                    'Numeração sequencial de relatórios',
                    'Aplicação de cabeçalhos e rodapés padrão'
                ],
                'business_logic': [
                    'Relatórios devem seguir layout oficial BACEN',
                    'Numeração deve ser única por data de processamento',
                    'Totais devem aparecer no final de cada seção',
                    'Assinatura digital deve ser incluída',
                    'Arquivo de controle deve ter hash MD5'
                ],
                'complexity': 'Média - formatação e controle de saídas'
            },
            'MZAN6056': {
                'purpose': 'Programa de finalização e limpeza do processo BACEN DOC3040',
                'business_rules': [
                    'Finaliza processamento do ciclo BACEN',
                    'Executa limpeza de arquivos temporários',
                    'Atualiza tabelas de controle de processamento',
                    'Gera log final de execução'
                ],
                'technical_aspects': [
                    'Implementa rotinas de housekeeping',
                    'Gerencia recursos do sistema',
                    'Controla status de processamento',
                    'Executa procedimentos de backup'
                ],
                'logic_rules': [
                    'Verificação de conclusão de todos os jobs anteriores',
                    'Limpeza de arquivos com mais de 30 dias',
                    'Atualização de tabela de controle com timestamp',
                    'Geração de backup incremental',
                    'Envio de notificação de conclusão'
                ],
                'business_logic': [
                    'Processo só pode finalizar se todos os steps anteriores foram OK',
                    'Arquivos temporários devem ser removidos após backup',
                    'Status final deve ser gravado na tabela de controle',
                    'E-mail de notificação deve ser enviado para equipe',
                    'Log deve conter estatísticas completas do processamento'
                ],
                'complexity': 'Baixa - rotinas de manutenção e controle'
            }
        }
    
    def analyze_cobol_program(self, request) -> AIResponse:
        """
        Simula análise de programa COBOL com base no conhecimento específico.
        
        Args:
            request: Solicitação de análise
            
        Returns:
            Resposta simulada da análise
        """
        try:
            # Aceita tanto string quanto enum para analysis_type
            analysis_type = request.analysis_type
            if hasattr(analysis_type, 'value'):
                analysis_type_str = analysis_type.value
            else:
                analysis_type_str = str(analysis_type)
                
            self._logger.info(f"Simulando análise IA para: {analysis_type_str}")
            
            # Extrai nome do programa
            if hasattr(request, 'program_name'):
                program_name = request.program_name
            elif hasattr(request, 'context') and request.context:
                program_name = request.context.get('program_name', 'UNKNOWN')
            else:
                program_name = 'UNKNOWN'
            
            # Extrai conteúdo do código
            if hasattr(request, 'code_content'):
                code_content = request.code_content
            elif hasattr(request, 'content'):
                code_content = request.content
            else:
                code_content = ""
            
            # Gera o prompt que seria usado para a análise
            prompt_used = self._generate_analysis_prompt(analysis_type_str, program_name, code_content)
            
            # Gera análise baseada no tipo solicitado
            if analysis_type_str in ['program_summary', 'PROGRAM_SUMMARY']:
                content = self._generate_program_summary(program_name, code_content)
            elif analysis_type_str in ['technical_documentation', 'TECHNICAL_DOCUMENTATION']:
                content = self._generate_technical_documentation(program_name, code_content)
            elif analysis_type_str in ['functional_documentation', 'FUNCTIONAL_DOCUMENTATION']:
                content = self._generate_functional_documentation(program_name, code_content)
            elif analysis_type_str in ['relationship_analysis', 'RELATIONSHIP_ANALYSIS']:
                content = self._generate_relationship_analysis(program_name, code_content)
            else:
                content = f"Análise não suportada: {analysis_type_str}"
                   
            # Simula tokens usados baseado no tamanho do conteúdo
            tokens_used = len(content.split()) + len(code_content.split()) // 2
            
            return AIResponse(
                content=content,
                provider="mock_ai",
                model="mock-gpt-4",
                tokens_used=tokens_used,
                success=True,
                metadata={
                    'analysis_type': analysis_type_str,
                    'program_name': program_name,
                    'prompt_used': prompt_used  # Adiciona o prompt usado
                }
            )
            
        except Exception as e:
            self._logger.error(f"Erro na simulação de análise: {e}")
            return AIResponse(
                content="",
                provider="mock_ai",
                model="mock-gpt-4",
                tokens_used=0,
                success=False,
                error_message=str(e)
            )
    
    def generate_documentation(self, request: AIRequest) -> AIResponse:
        """Reutiliza a lógica de análise para geração de documentação."""
        return self.analyze_cobol_program(request)
    
    def is_available(self) -> bool:
        """Mock sempre disponível."""
        return True
    
    def get_provider_name(self) -> str:
        """Retorna nome do provedor."""
        return "mock_ai"
    
    def get_supported_models(self) -> List[str]:
        """Retorna lista de modelos simulados."""
        return ["mock-gpt-4", "mock-claude-3", "mock-copilot"]
    
    def estimate_cost(self, request: AIRequest) -> float:
        """Simula custo zero para demonstração."""
        return 0.0
    
    def _generate_program_summary(self, program_name: str, code_content: str) -> str:
        """Gera resumo do programa baseado no conhecimento específico."""
        
        knowledge = self._program_knowledge.get(program_name, {})
        
        if not knowledge:
            return self._analyze_code_structure(program_name, code_content)
        
        summary = f"""## Resumo do Programa {program_name}

### Propósito Principal
{knowledge.get('purpose', 'Programa COBOL para processamento de dados')}

### Funcionalidades Principais
"""
        
        for rule in knowledge.get('business_rules', []):
            summary += f"- {rule}\n"
        
        summary += f"""
### Complexidade
{knowledge.get('complexity', 'Média')}

### Contexto no Fluxo
Este programa faz parte do processo de tratamento de dados BACEN DOC3040, executando em sequência com outros programas para garantir o processamento completo e íntegro dos dados regulatórios.
"""
        
        return summary
    
    def _generate_technical_documentation(self, program_name: str, code_content: str) -> str:
        """Gera documentação técnica detalhada incluindo lógica e regras de negócio."""
        
        knowledge = self._program_knowledge.get(program_name, {})
        
        # Analisa estrutura do código
        divisions = self._extract_divisions(code_content)
        file_descriptors = self._extract_file_descriptors(code_content)
        working_storage = self._extract_working_storage(code_content)
        procedures = self._extract_procedures(code_content)
        conditions = self._extract_conditions(code_content)
        calculations = self._extract_calculations(code_content)
        
        doc = f"""## Documentação Técnica - {program_name}

### Estrutura do Programa

#### Divisões Identificadas
"""
        
        for division in divisions:
            doc += f"- **{division}**: Implementada\n"
        
        doc += """
### Arquivos e Recursos

#### Descritores de Arquivo
"""
        
        if file_descriptors:
            for fd in file_descriptors[:5]:  # Limita a 5 para não ficar muito longo
                doc += f"- `{fd}`: Arquivo de dados\n"
        else:
            doc += "- Nenhum descritor de arquivo identificado\n"
        
        doc += """
### Variáveis e Estruturas de Dados

#### Working Storage Section
"""
        
        if working_storage:
            for ws in working_storage[:10]:  # Limita a 10
                doc += f"- `{ws}`: Variável de trabalho\n"
        else:
            doc += "- Estruturas de dados não identificadas no trecho analisado\n"
        
        # Nova seção: Lógica e Regras de Negócio
        doc += """
### Lógica e Regras de Negócio Implementadas

#### Procedimentos Principais
"""
        
        if procedures:
            for proc in procedures[:8]:
                doc += f"- **{proc}**: Rotina de processamento\n"
        else:
            doc += "- Procedimentos não identificados no trecho analisado\n"
        
        doc += """
#### Condições e Validações
"""
        
        if conditions:
            for condition in conditions[:6]:
                doc += f"- **{condition}**: Validação ou controle de fluxo\n"
        else:
            doc += "- Condições não identificadas no trecho analisado\n"
        
        doc += """
#### Cálculos e Transformações
"""
        
        if calculations:
            for calc in calculations[:5]:
                doc += f"- **{calc}**: Operação matemática ou transformação\n"
        else:
            doc += "- Cálculos não identificados no trecho analisado\n"
        
        # Regras específicas baseadas no conhecimento
        if knowledge:
            doc += """
### Regras de Negócio Específicas
"""
            for rule in knowledge.get('business_rules', []):
                doc += f"""
#### {rule.split()[0]} - {rule}
- **Implementação**: Controles automáticos via código COBOL
- **Validação**: Verificações em tempo de execução
- **Tratamento de Erro**: Códigos de retorno e logs apropriados
"""
        
        # Análise de fluxo lógico
        doc += """
### Fluxo Lógico do Programa

#### Sequência de Execução
1. **Inicialização**: Setup de variáveis e abertura de arquivos
2. **Validação de Entrada**: Verificação de dados de input
3. **Processamento Principal**: Execução da lógica de negócio
4. **Controles de Qualidade**: Validações de integridade
5. **Finalização**: Fechamento de recursos e geração de saídas

#### Pontos de Decisão Críticos
- Validação de formato de dados
- Controle de limites e faixas
- Verificação de condições de negócio
- Tratamento de situações excepcionais
"""
        
        if knowledge:
            doc += """
### Aspectos Técnicos Específicos
"""
            for aspect in knowledge.get('technical_aspects', []):
                doc += f"- {aspect}\n"
        
        doc += """
### Considerações de Performance
- Processamento otimizado para grandes volumes de dados
- Utilização eficiente de recursos de memória
- Controle adequado de I/O de arquivos
- Otimização de loops e estruturas repetitivas

### Tratamento de Erros e Exceções
- Implementa verificações de status de arquivo
- Controla condições de fim de arquivo
- Gerencia erros de processamento com códigos de retorno apropriados
- Logging de eventos críticos para auditoria

### Padrões de Codificação Identificados
- Nomenclatura padronizada de variáveis
- Estruturação modular de procedimentos
- Comentários explicativos em pontos críticos
- Controle de fluxo estruturado
"""
        
        return doc
    
    def _generate_functional_documentation(self, program_name: str, code_content: str) -> str:
        """Gera documentação funcional de negócio."""
        
        knowledge = self._program_knowledge.get(program_name, {})
        
        doc = f"""## Documentação Funcional - {program_name}

### Objetivo do Negócio
{knowledge.get('purpose', 'Processamento de dados COBOL para atender requisitos regulatórios')}

### Regras de Negócio Implementadas
"""
        
        for rule in knowledge.get('business_rules', ['Processamento de dados conforme especificações']):
            doc += f"""
#### {rule.split()[0]} - {rule}
Implementa validações e controles necessários para garantir a conformidade com as especificações regulatórias do BACEN.
"""
        
        doc += """
### Fluxo de Processamento

1. **Inicialização**: Abertura de arquivos e inicialização de variáveis de controle
2. **Processamento Principal**: Leitura, validação e transformação de dados
3. **Controles de Qualidade**: Verificações de integridade e consistência
4. **Finalização**: Fechamento de arquivos e geração de relatórios de controle

### Validações Realizadas
- Verificação de formato de registros
- Validação de campos obrigatórios
- Controle de integridade referencial
- Verificação de limites e faixas de valores

### Impacto nos Processos
Este programa é essencial para o cumprimento das obrigações regulatórias junto ao Banco Central, garantindo que os dados sejam processados conforme as especificações do documento DOC3040.

### Frequência de Execução
Execução diária como parte do processo batch de fechamento regulatório.
"""
        
        return doc
    
    def _generate_relationship_analysis(self, program_name: str, code_content: str) -> str:
        """Gera análise de relacionamentos."""
        
        # Extrai chamadas e copybooks do código
        calls = self._extract_calls(code_content)
        copies = self._extract_copies(code_content)
        
        doc = f"""## Análise de Relacionamentos - {program_name}

### Programas Chamados
"""
        
        if calls:
            for call in calls:
                doc += f"- **{call}**: Subrotina ou programa auxiliar\n"
        else:
            doc += "- Nenhuma chamada externa identificada\n"
        
        doc += """
### Copybooks Utilizados
"""
        
        if copies:
            for copy in copies:
                doc += f"- **{copy}**: Estrutura de dados ou definições compartilhadas\n"
        else:
            doc += "- Nenhum copybook identificado no trecho analisado\n"
        
        doc += """
### Dependências Externas
- Arquivos de entrada: Dados do BACEN DOC3040
- Arquivos de saída: Relatórios e arquivos processados
- Tabelas de parâmetros: Configurações do sistema
- Recursos do sistema: Alocação de memória e I/O

### Posição no Fluxo de Processamento
Este programa executa como parte de uma cadeia de processamento sequencial, recebendo dados de programas anteriores e preparando informações para programas subsequentes.
"""
        
        return doc
    
    def _generate_generic_analysis(self, program_name: str, code_content: str) -> str:
        """Gera análise genérica quando não há conhecimento específico."""
        
        return f"""## Análise do Programa {program_name}

### Estrutura Identificada
Este programa COBOL segue a estrutura padrão com divisões bem definidas para identificação, ambiente, dados e procedimentos.

### Características Técnicas
- Implementa processamento sequencial de dados
- Utiliza estruturas de controle COBOL padrão
- Gerencia arquivos de entrada e saída
- Aplica validações e controles de qualidade

### Funcionalidade Estimada
Baseado na análise do código, este programa parece realizar processamento de dados com foco em transformação e validação de informações, seguindo padrões típicos de sistemas mainframe.
"""
    
    def _analyze_code_structure(self, program_name: str, code_content: str) -> str:
        """Analisa estrutura do código quando não há conhecimento específico."""
        
        lines = code_content.split('\n')
        total_lines = len(lines)
        comment_lines = len([l for l in lines if l.strip().startswith('*')])
        
        return f"""## Análise Estrutural - {program_name}

### Métricas do Código
- Total de linhas: {total_lines}
- Linhas de comentário: {comment_lines}
- Linhas de código: {total_lines - comment_lines}

### Estrutura Geral
Programa COBOL com estrutura padrão, implementando processamento de dados com controles adequados de fluxo e tratamento de arquivos.
"""
    
    def _extract_divisions(self, code: str) -> List[str]:
        """Extrai divisões do código COBOL."""
        divisions = []
        for line in code.split('\n'):
            if 'DIVISION' in line.upper():
                divisions.append(line.strip())
        return divisions
    
    def _extract_file_descriptors(self, code: str) -> List[str]:
        """Extrai descritores de arquivo."""
        fds = []
        for line in code.split('\n'):
            if re.search(r'\bFD\b|\bSD\b', line.upper()):
                parts = line.strip().split()
                if len(parts) > 1:
                    fds.append(parts[1].rstrip('.'))
        return fds
    
    def _extract_working_storage(self, code: str) -> List[str]:
        """Extrai variáveis do working storage."""
        ws_vars = []
        in_ws = False
        for line in code.split('\n'):
            if 'WORKING-STORAGE SECTION' in line.upper():
                in_ws = True
                continue
            if in_ws and ('SECTION' in line.upper() or 'DIVISION' in line.upper()):
                break
            if in_ws and re.search(r'^\s*\d+\s+\w+', line):
                parts = line.strip().split()
                if len(parts) > 1:
                    ws_vars.append(parts[1])
        return ws_vars
    
    def _extract_calls(self, code: str) -> List[str]:
        """Extrai chamadas de programa."""
        calls = []
        for line in code.split('\n'):
            if re.search(r'\bCALL\b', line.upper()):
                match = re.search(r"CALL\s+['\"]([^'\"]+)['\"]", line.upper())
                if match:
                    calls.append(match.group(1))
        return calls
    
    def _extract_procedures(self, code: str) -> List[str]:
        """Extrai procedimentos e parágrafos do código COBOL."""
        procedures = []
        for line in code.split('\n'):
            # Procura por parágrafos (terminam com ponto)
            if re.search(r'^\s*[A-Z][A-Z0-9\-]+\.\s*$', line.strip()):
                proc_name = line.strip().rstrip('.')
                if proc_name and len(proc_name) > 2:
                    procedures.append(proc_name)
            # Procura por PERFORM statements
            elif re.search(r'\bPERFORM\b', line.upper()):
                match = re.search(r'PERFORM\s+([A-Z][A-Z0-9\-]+)', line.upper())
                if match:
                    procedures.append(f"PERFORM {match.group(1)}")
        return procedures
    
    def _extract_conditions(self, code: str) -> List[str]:
        """Extrai condições e validações do código COBOL."""
        conditions = []
        for line in code.split('\n'):
            line_upper = line.upper()
            # IF statements
            if re.search(r'\bIF\b', line_upper):
                match = re.search(r'IF\s+(.+?)(?:\s+THEN|\s*$)', line_upper)
                if match:
                    condition = match.group(1).strip()[:50]  # Limita tamanho
                    conditions.append(f"IF {condition}")
            # EVALUATE statements
            elif re.search(r'\bEVALUATE\b', line_upper):
                match = re.search(r'EVALUATE\s+(.+?)(?:\s*$)', line_upper)
                if match:
                    condition = match.group(1).strip()[:50]
                    conditions.append(f"EVALUATE {condition}")
            # WHEN statements
            elif re.search(r'\bWHEN\b', line_upper):
                match = re.search(r'WHEN\s+(.+?)(?:\s*$)', line_upper)
                if match:
                    condition = match.group(1).strip()[:50]
                    conditions.append(f"WHEN {condition}")
        return conditions
    
    def _extract_calculations(self, code: str) -> List[str]:
        """Extrai cálculos e operações matemáticas do código COBOL."""
        calculations = []
        for line in code.split('\n'):
            line_upper = line.upper()
            # COMPUTE statements
            if re.search(r'\bCOMPUTE\b', line_upper):
                match = re.search(r'COMPUTE\s+(.+?)(?:\s*$)', line_upper)
                if match:
                    calc = match.group(1).strip()[:60]
                    calculations.append(f"COMPUTE {calc}")
            # ADD statements
            elif re.search(r'\bADD\b', line_upper):
                match = re.search(r'ADD\s+(.+?)(?:\s+TO|\s*$)', line_upper)
                if match:
                    calc = match.group(1).strip()[:60]
                    calculations.append(f"ADD {calc}")
            # SUBTRACT statements
            elif re.search(r'\bSUBTRACT\b', line_upper):
                match = re.search(r'SUBTRACT\s+(.+?)(?:\s+FROM|\s*$)', line_upper)
                if match:
                    calc = match.group(1).strip()[:60]
                    calculations.append(f"SUBTRACT {calc}")
            # MULTIPLY statements
            elif re.search(r'\bMULTIPLY\b', line_upper):
                match = re.search(r'MULTIPLY\s+(.+?)(?:\s+BY|\s*$)', line_upper)
                if match:
                    calc = match.group(1).strip()[:60]
                    calculations.append(f"MULTIPLY {calc}")
            # DIVIDE statements
            elif re.search(r'\bDIVIDE\b', line_upper):
                match = re.search(r'DIVIDE\s+(.+?)(?:\s+INTO|\s+BY|\s*$)', line_upper)
                if match:
                    calc = match.group(1).strip()[:60]
                    calculations.append(f"DIVIDE {calc}")
        return calculations
    
    def _extract_copies(self, code: str) -> List[str]:
        """Extrai copybooks."""
        copies = []
        for line in code.split('\n'):
            if re.search(r'\bCOPY\b', line.upper()):
                match = re.search(r"COPY\s+([A-Z0-9\-]+)", line.upper())
                if match:
                    copies.append(match.group(1))
        return copies


    
    def _generate_analysis_prompt(self, analysis_type: str, program_name: str, code_content: str) -> str:
        """
        Gera o prompt que seria usado para análise de IA.
        
        Args:
            analysis_type: Tipo de análise solicitada
            program_name: Nome do programa COBOL
            code_content: Conteúdo do código fonte
            
        Returns:
            Prompt formatado que seria enviado para a IA
        """
        base_context = f"""
Você é um especialista em análise de sistemas COBOL mainframe com foco em documentação técnica e funcional.

PROGRAMA: {program_name}
TIPO DE ANÁLISE: {analysis_type}

CÓDIGO COBOL:
```cobol
{code_content[:2000]}{'...' if len(code_content) > 2000 else ''}
```
"""
        
        if analysis_type in ['program_summary', 'PROGRAM_SUMMARY']:
            return base_context + """
TAREFA: Gere um resumo executivo do programa COBOL analisando:

1. PROPÓSITO PRINCIPAL
   - Qual é a função principal deste programa?
   - Que problema de negócio ele resolve?

2. FUNCIONALIDADES PRINCIPAIS
   - Liste as 4-6 principais funcionalidades implementadas
   - Identifique os processos-chave executados

3. COMPLEXIDADE
   - Avalie a complexidade: Baixa, Média ou Alta
   - Justifique baseado em: volume de código, lógica, validações

4. CONTEXTO NO FLUXO
   - Como este programa se encaixa no processo maior?
   - Qual sua posição na cadeia de processamento?

FORMATO: Markdown estruturado, linguagem técnica mas acessível.
"""
        
        elif analysis_type in ['technical_documentation', 'TECHNICAL_DOCUMENTATION']:
            return base_context + """
TAREFA: Gere documentação técnica detalhada analisando:

1. ESTRUTURA DO PROGRAMA
   - Divisões COBOL identificadas
   - Seções principais (File, Working-Storage, Procedure)
   - Organização modular

2. LÓGICA E REGRAS DE NEGÓCIO
   - Procedimentos principais (PERFORM statements)
   - Condições e validações (IF, EVALUATE, WHEN)
   - Cálculos e transformações (COMPUTE, ADD, SUBTRACT)
   - Regras específicas implementadas

3. FLUXO LÓGICO DO PROGRAMA
   - Sequência de execução (5 etapas principais)
   - Pontos de decisão críticos
   - Tratamento de erros e exceções

4. ASPECTOS TÉCNICOS ESPECÍFICOS
   - Processamento de arquivos
   - Controles de performance
   - Padrões de codificação identificados

FORMATO: Markdown com seções técnicas detalhadas.
"""
        
        elif analysis_type in ['functional_documentation', 'FUNCTIONAL_DOCUMENTATION']:
            return base_context + """
TAREFA: Gere documentação funcional focada no negócio:

1. OBJETIVO DO NEGÓCIO
   - Finalidade do programa no contexto empresarial
   - Valor agregado ao processo

2. REGRAS DE NEGÓCIO IMPLEMENTADAS
   - Identifique cada regra de negócio específica
   - Descreva validações e controles aplicados
   - Mapeie transformações de dados

3. FLUXO DE PROCESSAMENTO
   - Etapas do processo de negócio (4-5 etapas)
   - Entradas e saídas de cada etapa
   - Controles de qualidade aplicados

4. VALIDAÇÕES REALIZADAS
   - Verificações de integridade
   - Controles de consistência
   - Tratamento de exceções de negócio

5. IMPACTO NOS PROCESSOS
   - Como afeta outros sistemas/processos
   - Frequência de execução
   - Criticidade para o negócio

FORMATO: Markdown focado em aspectos funcionais e de negócio.
"""
        
        elif analysis_type in ['relationship_analysis', 'RELATIONSHIP_ANALYSIS']:
            return base_context + """
TAREFA: Analise relacionamentos e dependências:

1. PROGRAMAS CHAMADOS
   - Identifique CALL statements
   - Liste programas invocados
   - Analise parâmetros passados

2. COPYBOOKS UTILIZADOS
   - Identifique COPY statements
   - Liste copybooks incluídos
   - Analise estruturas de dados compartilhadas

3. DEPENDÊNCIAS EXTERNAS
   - Arquivos de entrada e saída
   - Tabelas de banco de dados
   - Recursos do sistema utilizados

4. POSIÇÃO NO FLUXO DE PROCESSAMENTO
   - Onde se encaixa na cadeia de processamento
   - Programas predecessores e sucessores
   - Dados recebidos e produzidos

FORMATO: Markdown com foco em mapeamento de relacionamentos.
"""
        
        else:
            return base_context + f"""
TAREFA: Realize análise geral do programa COBOL para o tipo: {analysis_type}

Analise o código fornecido e gere documentação apropriada considerando:
- Estrutura e organização do código
- Lógica implementada
- Funcionalidades principais
- Relacionamentos e dependências

FORMATO: Markdown estruturado e profissional.
"""

