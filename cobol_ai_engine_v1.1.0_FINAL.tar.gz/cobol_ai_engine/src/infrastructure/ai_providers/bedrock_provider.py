"""
Provedor AWS Bedrock seguindo padrão Strategy.
Segue os princípios SOLID, especialmente SRP e DIP.
"""

import logging
import json
import boto3
from typing import Dict, Any, List, Optional
from botocore.exceptions import ClientError, NoCredentialsError
from ...domain.interfaces.ai_provider import IAIProvider, AIRequest, AIResponse, AnalysisType
from ...domain.interfaces.configuration import IAIConfiguration
from ...domain.entities.exceptions import AIProviderError


class BedrockProvider(IAIProvider):
    """Provedor de IA usando AWS Bedrock."""
    
    def __init__(self, configuration: IAIConfiguration, logger: Optional[logging.Logger] = None):
        """
        Inicializa o provedor Bedrock.
        
        Args:
            configuration: Configuração do Bedrock
            logger: Logger para registrar operações
        """
        self._config = configuration
        self._logger = logger or logging.getLogger(__name__)
        
        # Obtém parâmetros adicionais
        additional_params = self._config.get_additional_parameters()
        
        try:
            # Inicializa cliente Bedrock
            self._client = boto3.client(
                'bedrock-runtime',
                aws_access_key_id=self._config.get_api_key(),
                aws_secret_access_key=additional_params.get('aws_secret_access_key'),
                region_name=additional_params.get('aws_region', 'us-east-1')
            )
            
            self._logger.info(f"Cliente Bedrock inicializado para região: {additional_params.get('aws_region', 'us-east-1')}")
            
        except Exception as e:
            self._logger.error(f"Erro inicializando cliente Bedrock: {str(e)}")
            raise AIProviderError(f"Erro inicializando Bedrock: {str(e)}", provider="bedrock")
    
    def analyze_cobol_program(self, request: AIRequest) -> AIResponse:
        """
        Analisa um programa COBOL usando AWS Bedrock.
        
        Args:
            request: Solicitação de análise
            
        Returns:
            Resposta da análise
        """
        try:
            self._logger.info(f"Analisando programa COBOL com Bedrock: {request.analysis_type.value}")
            
            # Gera prompt específico para o tipo de análise
            prompt = self._generate_analysis_prompt(request)
            
            # Prepara payload baseado no modelo
            model_id = self._config.get_model_name()
            
            if 'claude' in model_id.lower():
                payload = self._prepare_claude_payload(prompt, request)
            elif 'titan' in model_id.lower():
                payload = self._prepare_titan_payload(prompt, request)
            else:
                # Payload genérico
                payload = {
                    'inputText': prompt,
                    'textGenerationConfig': {
                        'maxTokenCount': request.max_tokens or self._config.get_max_tokens(),
                        'temperature': request.temperature or self._config.get_temperature(),
                        'topP': 0.9
                    }
                }
            
            # Faz chamada para Bedrock
            response = self._client.invoke_model(
                modelId=model_id,
                body=json.dumps(payload),
                contentType='application/json'
            )
            
            # Processa resposta
            response_body = json.loads(response['body'].read())
            
            if 'claude' in model_id.lower():
                content = response_body['content'][0]['text']
                tokens_used = response_body.get('usage', {}).get('input_tokens', 0) + \
                             response_body.get('usage', {}).get('output_tokens', 0)
            elif 'titan' in model_id.lower():
                content = response_body['results'][0]['outputText']
                tokens_used = response_body.get('inputTextTokenCount', 0) + \
                             len(content.split()) * 1.3  # Estimativa
            else:
                content = response_body.get('outputText', response_body.get('content', ''))
                tokens_used = len(content.split()) * 1.3  # Estimativa
            
            self._logger.info(f"Análise concluída. Tokens estimados: {int(tokens_used)}")
            
            return AIResponse(
                content=content,
                provider="bedrock",
                model=model_id,
                tokens_used=int(tokens_used),
                success=True,
                metadata={
                    'model_id': model_id,
                    'response_metadata': response.get('ResponseMetadata', {})
                }
            )
            
        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            
            self._logger.error(f"Erro AWS Bedrock: {error_code} - {error_message}")
            
            return AIResponse(
                content="",
                provider="bedrock",
                model=self._config.get_model_name(),
                tokens_used=0,
                success=False,
                error_message=f"{error_code}: {error_message}"
            )
            
        except Exception as e:
            self._logger.error(f"Erro na análise Bedrock: {str(e)}")
            
            return AIResponse(
                content="",
                provider="bedrock",
                model=self._config.get_model_name(),
                tokens_used=0,
                success=False,
                error_message=str(e)
            )
    
    def generate_documentation(self, request: AIRequest) -> AIResponse:
        """
        Gera documentação usando AWS Bedrock.
        
        Args:
            request: Solicitação de geração
            
        Returns:
            Documentação gerada
        """
        # Reutiliza a lógica de análise para geração de documentação
        return self.analyze_cobol_program(request)
    
    def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        
        Returns:
            True se disponível, False caso contrário
        """
        try:
            # Testa conectividade listando modelos
            self._client.list_foundation_models()
            return True
            
        except Exception as e:
            self._logger.warning(f"Bedrock não disponível: {str(e)}")
            return False
    
    def get_provider_name(self) -> str:
        """Retorna nome do provedor."""
        return "bedrock"
    
    def get_supported_models(self) -> List[str]:
        """Retorna lista de modelos suportados."""
        return [
            "anthropic.claude-3-sonnet-20240229-v1:0",
            "anthropic.claude-3-haiku-20240307-v1:0",
            "anthropic.claude-v2:1",
            "anthropic.claude-v2",
            "amazon.titan-text-express-v1",
            "amazon.titan-text-lite-v1"
        ]
    
    def estimate_cost(self, request: AIRequest) -> float:
        """
        Estima custo da solicitação.
        
        Args:
            request: Solicitação a ser estimada
            
        Returns:
            Custo estimado em USD
        """
        # Estimativa baseada no modelo e tokens
        model = self._config.get_model_name()
        estimated_input_tokens = len(request.content.split()) * 1.3
        estimated_output_tokens = request.max_tokens or self._config.get_max_tokens()
        
        # Preços aproximados por 1K tokens (valores de referência)
        pricing = {
            'anthropic.claude-3-sonnet-20240229-v1:0': {'input': 0.003, 'output': 0.015},
            'anthropic.claude-3-haiku-20240307-v1:0': {'input': 0.00025, 'output': 0.00125},
            'anthropic.claude-v2:1': {'input': 0.008, 'output': 0.024},
            'amazon.titan-text-express-v1': {'input': 0.0008, 'output': 0.0016}
        }
        
        if model in pricing:
            input_cost = (estimated_input_tokens / 1000) * pricing[model]['input']
            output_cost = (estimated_output_tokens / 1000) * pricing[model]['output']
            return input_cost + output_cost
        
        return 0.01  # Estimativa padrão
    
    def _prepare_claude_payload(self, prompt: str, request: AIRequest) -> Dict[str, Any]:
        """Prepara payload específico para modelos Claude."""
        return {
            'anthropic_version': 'bedrock-2023-05-31',
            'max_tokens': request.max_tokens or self._config.get_max_tokens(),
            'temperature': request.temperature or self._config.get_temperature(),
            'messages': [
                {
                    'role': 'user',
                    'content': prompt
                }
            ]
        }
    
    def _prepare_titan_payload(self, prompt: str, request: AIRequest) -> Dict[str, Any]:
        """Prepara payload específico para modelos Titan."""
        return {
            'inputText': prompt,
            'textGenerationConfig': {
                'maxTokenCount': request.max_tokens or self._config.get_max_tokens(),
                'temperature': request.temperature or self._config.get_temperature(),
                'topP': 0.9,
                'stopSequences': []
            }
        }
    
    def _generate_analysis_prompt(self, request: AIRequest) -> str:
        """Gera prompt específico para o tipo de análise."""
        base_prompt = f"""
Analise o seguinte código COBOL e forneça uma análise detalhada:

```cobol
{request.content}
```

Contexto adicional:
"""
        
        # Adiciona contexto específico
        for key, value in request.context.items():
            base_prompt += f"- {key}: {value}\n"
        
        # Adiciona instruções específicas por tipo de análise
        if request.analysis_type == AnalysisType.PROGRAM_SUMMARY:
            base_prompt += """
Por favor, forneça:
1. Resumo do propósito do programa
2. Principais funcionalidades
3. Arquivos de entrada e saída
4. Dependências identificadas
"""
        
        elif request.analysis_type == AnalysisType.TECHNICAL_DOCUMENTATION:
            base_prompt += """
Por favor, forneça documentação técnica incluindo:
1. Estrutura do programa (divisões)
2. Variáveis principais e suas funções
3. Lógica de processamento
4. Tratamento de erros
5. Performance e complexidade
"""
        
        elif request.analysis_type == AnalysisType.FUNCTIONAL_DOCUMENTATION:
            base_prompt += """
Por favor, forneça documentação funcional incluindo:
1. Objetivo do negócio
2. Regras de negócio implementadas
3. Fluxo de processamento
4. Validações realizadas
5. Impacto nos processos
"""
        
        elif request.analysis_type == AnalysisType.RELATIONSHIP_ANALYSIS:
            base_prompt += """
Por favor, analise os relacionamentos:
1. Programas chamados (CALL statements)
2. Copybooks utilizados (COPY statements)
3. Arquivos acessados
4. Dependências externas
"""
        
        base_prompt += "\nFormate a resposta em Markdown sem usar ícones ou referências a IA."
        
        return base_prompt

