"""
Provedor OpenAI seguindo padrão Strategy.
Segue os princípios SOLID, especialmente SRP e DIP.
"""

import logging
import requests
import json
from typing import Dict, Any, List, Optional
from ...domain.interfaces.ai_provider import IAIProvider, AIRequest, AIResponse, AnalysisType
from ...domain.interfaces.configuration import IAIConfiguration
from ...domain.entities.exceptions import AIProviderError


class OpenAIProvider(IAIProvider):
    """Provedor de IA usando OpenAI API."""
    
    def __init__(self, configuration: IAIConfiguration, logger: Optional[logging.Logger] = None):
        """
        Inicializa o provedor OpenAI.
        
        Args:
            configuration: Configuração do OpenAI
            logger: Logger para registrar operações
        """
        self._config = configuration
        self._logger = logger or logging.getLogger(__name__)
        self._session = requests.Session()
        
        # Configura headers padrão
        self._session.headers.update({
            'Authorization': f'Bearer {self._config.get_api_key()}',
            'Content-Type': 'application/json'
        })
        
        # Adiciona organização se configurada
        additional_params = self._config.get_additional_parameters()
        if 'organization' in additional_params and additional_params['organization']:
            self._session.headers['OpenAI-Organization'] = additional_params['organization']
    
    def analyze_cobol_program(self, request: AIRequest) -> AIResponse:
        """
        Analisa um programa COBOL usando OpenAI.
        
        Args:
            request: Solicitação de análise
            
        Returns:
            Resposta da análise
        """
        try:
            self._logger.info(f"Analisando programa COBOL com OpenAI: {request.analysis_type.value}")
            
            # Gera prompt específico para o tipo de análise
            prompt = self._generate_analysis_prompt(request)
            
            # Prepara payload para API
            payload = {
                'model': self._config.get_model_name(),
                'messages': [
                    {
                        'role': 'system',
                        'content': self._get_system_prompt(request.analysis_type)
                    },
                    {
                        'role': 'user',
                        'content': prompt
                    }
                ],
                'max_tokens': request.max_tokens or self._config.get_max_tokens(),
                'temperature': request.temperature or self._config.get_temperature()
            }
            
            # Adiciona parâmetros adicionais
            payload.update(request.additional_parameters)
            
            # Faz chamada para API
            response = self._session.post(
                f"{self._config.get_api_endpoint()}/chat/completions",
                json=payload,
                timeout=30
            )
            
            if response.status_code != 200:
                raise AIProviderError(
                    f"Erro na API OpenAI: {response.status_code} - {response.text}",
                    provider="openai",
                    error_code=str(response.status_code)
                )
            
            result = response.json()
            
            # Extrai resposta
            content = result['choices'][0]['message']['content']
            tokens_used = result['usage']['total_tokens']
            
            self._logger.info(f"Análise concluída. Tokens usados: {tokens_used}")
            
            return AIResponse(
                content=content,
                provider="openai",
                model=self._config.get_model_name(),
                tokens_used=tokens_used,
                success=True,
                metadata={
                    'finish_reason': result['choices'][0]['finish_reason'],
                    'prompt_tokens': result['usage']['prompt_tokens'],
                    'completion_tokens': result['usage']['completion_tokens']
                }
            )
            
        except Exception as e:
            self._logger.error(f"Erro na análise OpenAI: {str(e)}")
            
            if isinstance(e, AIProviderError):
                raise
            
            return AIResponse(
                content="",
                provider="openai",
                model=self._config.get_model_name(),
                tokens_used=0,
                success=False,
                error_message=str(e)
            )
    
    def generate_documentation(self, request: AIRequest) -> AIResponse:
        """
        Gera documentação usando OpenAI.
        
        Args:
            request: Solicitação de geração
            
        Returns:
            Documentação gerada
        """
        # Reutiliza a lógica de análise para geração de documentação
        return self.analyze_cobol_program(request)
    
    def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        
        Returns:
            True se disponível, False caso contrário
        """
        try:
            # Testa conectividade com uma chamada simples
            response = self._session.get(
                f"{self._config.get_api_endpoint()}/models",
                timeout=5
            )
            return response.status_code == 200
            
        except Exception as e:
            self._logger.warning(f"OpenAI não disponível: {str(e)}")
            return False
    
    def get_provider_name(self) -> str:
        """Retorna nome do provedor."""
        return "openai"
    
    def get_supported_models(self) -> List[str]:
        """Retorna lista de modelos suportados."""
        return [
            "gpt-4",
            "gpt-4-turbo",
            "gpt-4-turbo-preview",
            "gpt-3.5-turbo",
            "gpt-3.5-turbo-16k"
        ]
    
    def estimate_cost(self, request: AIRequest) -> float:
        """
        Estima custo da solicitação.
        
        Args:
            request: Solicitação a ser estimada
            
        Returns:
            Custo estimado em USD
        """
        # Estimativa baseada no modelo e tokens
        model = self._config.get_model_name()
        estimated_tokens = len(request.content.split()) * 1.3  # Aproximação
        
        # Preços aproximados por 1K tokens (valores de referência)
        pricing = {
            'gpt-4': {'input': 0.03, 'output': 0.06},
            'gpt-4-turbo': {'input': 0.01, 'output': 0.03},
            'gpt-3.5-turbo': {'input': 0.001, 'output': 0.002}
        }
        
        if model in pricing:
            input_cost = (estimated_tokens / 1000) * pricing[model]['input']
            output_tokens = request.max_tokens or self._config.get_max_tokens()
            output_cost = (output_tokens / 1000) * pricing[model]['output']
            return input_cost + output_cost
        
        return 0.05  # Estimativa padrão
    
    def _generate_analysis_prompt(self, request: AIRequest) -> str:
        """Gera prompt específico para o tipo de análise."""
        base_prompt = f"""
Analise o seguinte código COBOL e forneça uma análise detalhada:

```cobol
{request.content}
```

Contexto adicional:
"""
        
        # Adiciona contexto específico
        for key, value in request.context.items():
            base_prompt += f"- {key}: {value}\n"
        
        # Adiciona instruções específicas por tipo de análise
        if request.analysis_type == AnalysisType.PROGRAM_SUMMARY:
            base_prompt += """
Por favor, forneça:
1. Resumo do propósito do programa
2. Principais funcionalidades
3. Arquivos de entrada e saída
4. Dependências identificadas
"""
        
        elif request.analysis_type == AnalysisType.TECHNICAL_DOCUMENTATION:
            base_prompt += """
Por favor, forneça documentação técnica incluindo:
1. Estrutura do programa (divisões)
2. Variáveis principais e suas funções
3. Lógica de processamento
4. Tratamento de erros
5. Performance e complexidade
"""
        
        elif request.analysis_type == AnalysisType.FUNCTIONAL_DOCUMENTATION:
            base_prompt += """
Por favor, forneça documentação funcional incluindo:
1. Objetivo do negócio
2. Regras de negócio implementadas
3. Fluxo de processamento
4. Validações realizadas
5. Impacto nos processos
"""
        
        elif request.analysis_type == AnalysisType.RELATIONSHIP_ANALYSIS:
            base_prompt += """
Por favor, analise os relacionamentos:
1. Programas chamados (CALL statements)
2. Copybooks utilizados (COPY statements)
3. Arquivos acessados
4. Dependências externas
"""
        
        base_prompt += "\nFormate a resposta em Markdown sem usar ícones ou referências a IA."
        
        return base_prompt
    
    def _get_system_prompt(self, analysis_type: AnalysisType) -> str:
        """Retorna prompt do sistema baseado no tipo de análise."""
        base_system = """Você é um especialista em análise de código COBOL com vasta experiência em sistemas mainframe e documentação técnica. 

Diretrizes importantes:
- Forneça análises precisas e detalhadas
- Use linguagem técnica apropriada
- Não mencione que você é uma IA
- Não use ícones ou emojis
- Formate em Markdown limpo
- Foque em aspectos práticos e relevantes
- Considere boas práticas de COBOL"""
        
        if analysis_type == AnalysisType.TECHNICAL_DOCUMENTATION:
            return base_system + "\nFoque em aspectos técnicos, estrutura de código e implementação."
        
        elif analysis_type == AnalysisType.FUNCTIONAL_DOCUMENTATION:
            return base_system + "\nFoque em aspectos funcionais, regras de negócio e processos."
        
        return base_system

