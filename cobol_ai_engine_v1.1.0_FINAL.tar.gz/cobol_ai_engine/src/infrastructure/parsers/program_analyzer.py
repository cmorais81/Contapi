"""
Analisador de relacionamentos e sequência entre programas COBOL.
Segue os princípios SOLID, especialmente SRP e OCP.
"""

import re
import logging
from typing import List, Dict, Any, Set, Optional, Tuple
from ...domain.interfaces.cobol_parser import IProgramAnalyzer
from ...domain.entities.cobol_program import CobolProgram
from ...domain.entities.cobol_book import CobolBook
from ...domain.entities.exceptions import CobolAnalysisError


class ProgramAnalyzer(IProgramAnalyzer):
    """Analisa relacionamentos e dependências entre programas COBOL."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Inicializa o analisador.
        
        Args:
            logger: Logger para registrar operações
        """
        self._logger = logger or logging.getLogger(__name__)
        self._call_pattern = re.compile(r'CALL\s+["\']?([A-Z0-9\-]+)["\']?', re.IGNORECASE)
        self._copy_pattern = re.compile(r'COPY\s+([A-Z0-9\-]+)', re.IGNORECASE)
        
    def analyze_relationships(self, programs: List[CobolProgram], books: List[CobolBook]) -> Dict[str, Any]:
        """
        Analisa relacionamentos e dependências entre programas.
        
        Args:
            programs: Lista de programas COBOL
            books: Lista de books/copybooks
            
        Returns:
            Dicionário com análise de relacionamentos
        """
        try:
            self._logger.info(f"Iniciando análise de relacionamentos para {len(programs)} programas e {len(books)} books")
            
            # Extrai chamadas e dependências
            call_relationships = self._extract_call_relationships(programs)
            copy_relationships = self._extract_copy_relationships(programs, books)
            
            # Analisa fluxo de dados
            data_flow = self._analyze_data_flow(programs, call_relationships)
            
            # Identifica programas principais e auxiliares
            program_roles = self._identify_program_roles(programs, call_relationships)
            
            # Analisa complexidade de relacionamentos
            complexity_metrics = self._calculate_complexity_metrics(programs, call_relationships, copy_relationships)
            
            analysis = {
                'summary': {
                    'total_programs': len(programs),
                    'total_books': len(books),
                    'total_call_relationships': len(call_relationships),
                    'total_copy_relationships': sum(len(copies) for copies in copy_relationships.values())
                },
                'call_relationships': call_relationships,
                'copy_relationships': copy_relationships,
                'data_flow': data_flow,
                'program_roles': program_roles,
                'complexity_metrics': complexity_metrics,
                'shared_resources': self._identify_shared_resources(books),
                'dependency_graph': self._build_dependency_graph(programs, call_relationships, copy_relationships)
            }
            
            self._logger.info("Análise de relacionamentos concluída com sucesso")
            return analysis
            
        except Exception as e:
            raise CobolAnalysisError(f"Erro durante análise de relacionamentos: {str(e)}")
    
    def identify_program_sequence(self, programs: List[CobolProgram]) -> List[str]:
        """
        Identifica sequência/linhagem entre programas.
        
        Args:
            programs: Lista de programas COBOL
            
        Returns:
            Lista ordenada de nomes de programas na sequência de execução
        """
        try:
            self._logger.info(f"Identificando sequência de execução para {len(programs)} programas")
            
            # Extrai relacionamentos de chamada
            call_relationships = self._extract_call_relationships(programs)
            
            # Identifica programa raiz (não é chamado por nenhum outro)
            all_called = set()
            for caller, callees in call_relationships.items():
                all_called.update(callees)
            
            program_names = {prog.name for prog in programs}
            root_programs = program_names - all_called
            
            # Constrói sequência baseada em padrões de nomenclatura e chamadas
            sequence = self._build_execution_sequence(programs, call_relationships, root_programs)
            
            self._logger.info(f"Sequência identificada: {' -> '.join(sequence)}")
            return sequence
            
        except Exception as e:
            raise CobolAnalysisError(f"Erro identificando sequência de programas: {str(e)}")
    
    def _extract_call_relationships(self, programs: List[CobolProgram]) -> Dict[str, Set[str]]:
        """Extrai relacionamentos de CALL entre programas."""
        relationships = {}
        
        for program in programs:
            called_programs = set()
            
            # Procura por CALL statements no código
            for line in program.source_lines:
                matches = self._call_pattern.findall(line)
                for match in matches:
                    # Remove prefixos comuns (CT-, WDRAM, etc.)
                    clean_name = match.replace('CT-', '').replace('WDRAM', '').strip()
                    if clean_name and clean_name != program.name:
                        called_programs.add(clean_name)
            
            if called_programs:
                relationships[program.name] = called_programs
                
        return relationships
    
    def _extract_copy_relationships(self, programs: List[CobolProgram], books: List[CobolBook]) -> Dict[str, Set[str]]:
        """Extrai relacionamentos de COPY entre programas e books."""
        relationships = {}
        book_names = {book.name for book in books}
        
        for program in programs:
            used_books = set()
            
            # Procura por COPY statements no código
            for line in program.source_lines:
                matches = self._copy_pattern.findall(line)
                for match in matches:
                    clean_name = match.strip().rstrip('.')
                    if clean_name in book_names:
                        used_books.add(clean_name)
            
            if used_books:
                relationships[program.name] = used_books
                
        return relationships
    
    def _analyze_data_flow(self, programs: List[CobolProgram], call_relationships: Dict[str, Set[str]]) -> Dict[str, Any]:
        """Analisa fluxo de dados entre programas."""
        data_flow = {
            'entry_points': [],
            'processing_chain': [],
            'exit_points': []
        }
        
        # Identifica pontos de entrada (não são chamados)
        all_called = set()
        for callees in call_relationships.values():
            all_called.update(callees)
        
        program_names = {prog.name for prog in programs}
        entry_points = program_names - all_called
        data_flow['entry_points'] = list(entry_points)
        
        # Identifica pontos de saída (não chamam outros)
        exit_points = program_names - set(call_relationships.keys())
        data_flow['exit_points'] = list(exit_points)
        
        # Constrói cadeia de processamento
        for entry in entry_points:
            chain = self._build_processing_chain(entry, call_relationships)
            if len(chain) > 1:
                data_flow['processing_chain'].append(chain)
        
        return data_flow
    
    def _build_processing_chain(self, start_program: str, call_relationships: Dict[str, Set[str]], visited: Set[str] = None) -> List[str]:
        """Constrói cadeia de processamento a partir de um programa."""
        if visited is None:
            visited = set()
        
        if start_program in visited:
            return [start_program]  # Evita ciclos
        
        visited.add(start_program)
        chain = [start_program]
        
        if start_program in call_relationships:
            for called_program in call_relationships[start_program]:
                sub_chain = self._build_processing_chain(called_program, call_relationships, visited.copy())
                if len(sub_chain) > 1:
                    chain.extend(sub_chain[1:])  # Remove duplicata do primeiro elemento
                    break  # Pega apenas o primeiro caminho para simplicidade
        
        return chain
    
    def _identify_program_roles(self, programs: List[CobolProgram], call_relationships: Dict[str, Set[str]]) -> Dict[str, str]:
        """Identifica papéis dos programas (principal, auxiliar, utilitário)."""
        roles = {}
        
        # Conta quantas vezes cada programa é chamado
        call_count = {}
        for callees in call_relationships.values():
            for callee in callees:
                call_count[callee] = call_count.get(callee, 0) + 1
        
        for program in programs:
            name = program.name
            
            # Programa principal: não é chamado por outros ou é chamado poucas vezes
            if name not in call_count or call_count[name] <= 1:
                if name in call_relationships and len(call_relationships[name]) > 0:
                    roles[name] = 'principal'
                else:
                    roles[name] = 'standalone'
            
            # Utilitário: chamado por múltiplos programas
            elif call_count[name] > 2:
                roles[name] = 'utilitario'
            
            # Auxiliar: chamado por poucos programas
            else:
                roles[name] = 'auxiliar'
        
        return roles
    
    def _calculate_complexity_metrics(self, programs: List[CobolProgram], 
                                    call_relationships: Dict[str, Set[str]], 
                                    copy_relationships: Dict[str, Set[str]]) -> Dict[str, Any]:
        """Calcula métricas de complexidade dos relacionamentos."""
        metrics = {
            'coupling_metrics': {},
            'cohesion_metrics': {},
            'overall_complexity': 0
        }
        
        for program in programs:
            name = program.name
            
            # Métricas de acoplamento
            efferent_coupling = len(call_relationships.get(name, set()))  # Programas que este chama
            afferent_coupling = sum(1 for callees in call_relationships.values() if name in callees)  # Programas que chamam este
            
            metrics['coupling_metrics'][name] = {
                'efferent_coupling': efferent_coupling,
                'afferent_coupling': afferent_coupling,
                'instability': efferent_coupling / (efferent_coupling + afferent_coupling) if (efferent_coupling + afferent_coupling) > 0 else 0,
                'used_books': len(copy_relationships.get(name, set()))
            }
        
        # Complexidade geral
        total_relationships = sum(len(callees) for callees in call_relationships.values())
        metrics['overall_complexity'] = total_relationships
        
        return metrics
    
    def _identify_shared_resources(self, books: List[CobolBook]) -> List[Dict[str, Any]]:
        """Identifica recursos compartilhados (books usados por múltiplos programas)."""
        shared = []
        
        for book in books:
            if book.is_shared_resource():
                shared.append({
                    'name': book.name,
                    'type': book.book_type.value,
                    'usage_count': book.get_usage_count(),
                    'used_by': list(book.used_by_programs)
                })
        
        return sorted(shared, key=lambda x: x['usage_count'], reverse=True)
    
    def _build_dependency_graph(self, programs: List[CobolProgram], 
                               call_relationships: Dict[str, Set[str]], 
                               copy_relationships: Dict[str, Set[str]]) -> Dict[str, Any]:
        """Constrói grafo de dependências."""
        graph = {
            'nodes': [],
            'edges': []
        }
        
        # Adiciona nós (programas)
        for program in programs:
            graph['nodes'].append({
                'id': program.name,
                'type': 'program',
                'complexity': program.get_complexity_metrics()['total_lines']
            })
        
        # Adiciona arestas (relacionamentos)
        for caller, callees in call_relationships.items():
            for callee in callees:
                graph['edges'].append({
                    'source': caller,
                    'target': callee,
                    'type': 'call'
                })
        
        for program, books in copy_relationships.items():
            for book in books:
                graph['edges'].append({
                    'source': program,
                    'target': book,
                    'type': 'copy'
                })
        
        return graph
    
    def _build_execution_sequence(self, programs: List[CobolProgram], 
                                 call_relationships: Dict[str, Set[str]], 
                                 root_programs: Set[str]) -> List[str]:
        """Constrói sequência de execução baseada em padrões e relacionamentos."""
        sequence = []
        
        # Ordena programas por padrões de nomenclatura
        program_list = sorted(programs, key=lambda p: p.name)
        
        # Identifica padrões de sequência nos nomes
        lhan_programs = [p for p in program_list if p.name.startswith('LHAN')]
        lhbr_programs = [p for p in program_list if p.name.startswith('LHBR')]
        mzan_programs = [p for p in program_list if p.name.startswith('MZAN')]
        
        # Constrói sequência baseada em padrões identificados
        if lhan_programs:
            # LHAN programs parecem ser sequenciais
            lhan_sorted = sorted(lhan_programs, key=lambda p: p.name)
            sequence.extend([p.name for p in lhan_sorted])
        
        if lhbr_programs:
            sequence.extend([p.name for p in lhbr_programs])
        
        if mzan_programs:
            sequence.extend([p.name for p in mzan_programs])
        
        # Adiciona programas restantes
        remaining = [p.name for p in programs if p.name not in sequence]
        sequence.extend(remaining)
        
        return sequence

