"""
Extrator de linhas válidas COBOL (colunas 1-72).
Segue o princípio Single Responsibility (SRP).
"""

import logging
from typing import List, Optional
from ...domain.interfaces.cobol_parser import ICobolLineExtractor
from ...domain.entities.exceptions import CobolParseError


class CobolLineExtractor(ICobolLineExtractor):
    """Extrai linhas válidas COBOL respeitando formato de colunas."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Inicializa o extrator.
        
        Args:
            logger: Logger para registrar operações
        """
        self._logger = logger or logging.getLogger(__name__)
        
    def extract_cobol_lines(self, raw_lines: List[str]) -> List[str]:
        """
        Extrai linhas válidas COBOL (colunas 1-72).
        
        Args:
            raw_lines: Linhas brutas do arquivo
            
        Returns:
            Lista de linhas COBOL válidas
            
        Raises:
            CobolParseError: Erro durante extração
        """
        try:
            cobol_lines = []
            
            for line_num, line in enumerate(raw_lines, 1):
                # Remove caractere 'V' da coluna 1 se presente (resultado do utilitário)
                if line.startswith('V'):
                    line = line[1:]
                
                # Extrai colunas 1-72 (padrão COBOL)
                cobol_line = line[:72] if len(line) >= 72 else line
                
                # Remove espaços em branco no final
                cobol_line = cobol_line.rstrip()
                
                cobol_lines.append(cobol_line)
            
            self._logger.debug(f"Extraídas {len(cobol_lines)} linhas COBOL válidas de {len(raw_lines)} linhas brutas")
            
            return cobol_lines
            
        except Exception as e:
            raise CobolParseError(f"Erro durante extração de linhas COBOL: {str(e)}")
    
    def clean_sequence_numbers(self, lines: List[str]) -> List[str]:
        """
        Remove números de sequência das colunas 1-6 se presentes.
        
        Args:
            lines: Linhas COBOL
            
        Returns:
            Linhas sem números de sequência
        """
        cleaned_lines = []
        
        for line in lines:
            if len(line) >= 6:
                # Verifica se colunas 1-6 contêm apenas números ou espaços
                sequence_area = line[:6]
                if sequence_area.strip().isdigit() or sequence_area.strip() == '':
                    # Remove área de sequência, mantém resto da linha
                    cleaned_line = line[6:] if len(line) > 6 else ''
                else:
                    # Mantém linha original se não parece ter números de sequência
                    cleaned_line = line
            else:
                cleaned_line = line
                
            cleaned_lines.append(cleaned_line)
        
        return cleaned_lines
    
    def validate_cobol_format(self, lines: List[str]) -> List[str]:
        """
        Valida e corrige formato das linhas COBOL.
        
        Args:
            lines: Linhas COBOL
            
        Returns:
            Lista de problemas encontrados
        """
        issues = []
        
        for line_num, line in enumerate(lines, 1):
            # Verifica se linha excede 72 colunas
            if len(line) > 72:
                issues.append(f"Linha {line_num}: excede 72 colunas ({len(line)} colunas)")
            
            # Verifica área de indicador (coluna 7)
            if len(line) >= 7:
                indicator = line[6]  # Coluna 7 (índice 6)
                if indicator not in [' ', '*', '/', '-', 'D', 'd']:
                    issues.append(f"Linha {line_num}: indicador inválido na coluna 7: '{indicator}'")
        
        return issues
    
    def get_line_statistics(self, lines: List[str]) -> dict:
        """
        Retorna estatísticas das linhas processadas.
        
        Args:
            lines: Linhas COBOL processadas
            
        Returns:
            Dicionário com estatísticas
        """
        stats = {
            'total_lines': len(lines),
            'empty_lines': 0,
            'comment_lines': 0,
            'code_lines': 0,
            'max_length': 0,
            'min_length': float('inf') if lines else 0,
            'avg_length': 0
        }
        
        total_length = 0
        
        for line in lines:
            length = len(line)
            total_length += length
            
            if length > stats['max_length']:
                stats['max_length'] = length
            if length < stats['min_length']:
                stats['min_length'] = length
            
            if not line.strip():
                stats['empty_lines'] += 1
            elif len(line) >= 7 and line[6] == '*':
                stats['comment_lines'] += 1
            else:
                stats['code_lines'] += 1
        
        if lines:
            stats['avg_length'] = total_length / len(lines)
            
        if stats['min_length'] == float('inf'):
            stats['min_length'] = 0
        
        return stats

