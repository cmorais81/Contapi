"""
Parser para books/copybooks COBOL.
Segue os princípios SOLID, especialmente SRP e DIP.
"""

import re
import logging
from typing import List, Optional, Dict, Set, Any
from ...domain.interfaces.cobol_parser import IBooksParser
from ...domain.entities.cobol_book import CobolBook, BookType
from ...domain.entities.exceptions import CobolParseError


class BooksParser(IBooksParser):
    """Parser para arquivos de books/copybooks COBOL."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Inicializa o parser de books.
        
        Args:
            logger: Logger para registrar operações
        """
        self._logger = logger or logging.getLogger(__name__)
        self._vmember_pattern = re.compile(r'^VMEMBER NAME\s+(\w+)')
        self._table_pattern = re.compile(r'(\d{4})\s+(.+)', re.IGNORECASE)
        self._constant_pattern = re.compile(r'(\w+)\s+VALUE\s+["\']([^"\']+)["\']', re.IGNORECASE)
        
    def parse_books(self, file_path: str) -> List[CobolBook]:
        """
        Parseia arquivo de books/copybooks.
        
        Args:
            file_path: Caminho para o arquivo de books
            
        Returns:
            Lista de books parseados
            
        Raises:
            CobolParseError: Erro durante parsing
        """
        try:
            self._logger.info(f"Iniciando parsing de books: {file_path}")
            
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as file:
                content = file.read()
            
            # Extrai books individuais
            raw_books = self._extract_individual_books(content)
            
            # Parseia cada book
            books = []
            for book_name, book_content in raw_books.items():
                book = self._parse_individual_book(book_name, book_content)
                books.append(book)
            
            self._logger.info(f"Parsing concluído. {len(books)} books parseados")
            return books
            
        except Exception as e:
            raise CobolParseError(f"Erro parsing books de {file_path}: {str(e)}")
    
    def _extract_individual_books(self, file_content: str) -> Dict[str, str]:
        """Extrai books individuais do arquivo empilhado."""
        books = {}
        lines = file_content.split('\n')
        current_book = None
        current_lines = []
        
        for line_num, line in enumerate(lines, 1):
            # Verifica se é início de novo book
            match = self._vmember_pattern.match(line.strip())
            if match:
                # Salva book anterior se existir
                if current_book and current_lines:
                    books[current_book] = '\n'.join(current_lines)
                    self._logger.debug(f"Book {current_book} extraído com {len(current_lines)} linhas")
                
                # Inicia novo book
                current_book = match.group(1).strip()
                current_lines = []
                self._logger.debug(f"Iniciando extração do book {current_book} na linha {line_num}")
                continue
            
            # Adiciona linha ao book atual
            if current_book:
                current_lines.append(line)
        
        # Salva último book
        if current_book and current_lines:
            books[current_book] = '\n'.join(current_lines)
            self._logger.debug(f"Book {current_book} extraído com {len(current_lines)} linhas")
        
        return books
    
    def _parse_individual_book(self, book_name: str, book_content: str) -> CobolBook:
        """Parseia um book individual."""
        book = CobolBook(name=book_name)
        lines = book_content.split('\n')
        
        # Remove linhas com 'V' no início (utilitário)
        clean_lines = []
        for line in lines:
            if line.startswith('V'):
                line = line[1:]
            clean_lines.append(line[:72] if len(line) >= 72 else line)
        
        book.source_lines = clean_lines
        
        # Extrai informações específicas
        self._extract_book_description(book, clean_lines)
        self._extract_comments(book, clean_lines)
        self._extract_data_structures(book, clean_lines)
        self._extract_constants(book, clean_lines)
        self._extract_tables(book, clean_lines)
        
        # Infere tipo do book
        book.book_type = book.infer_book_type()
        
        self._logger.debug(f"Book {book_name} parseado: tipo={book.book_type.value}, "
                          f"estruturas={len(book.data_structures)}, "
                          f"constantes={len(book.constants)}, "
                          f"tabelas={len(book.tables)}")
        
        return book
    
    def _extract_book_description(self, book: CobolBook, lines: List[str]) -> None:
        """Extrai descrição do book dos comentários iniciais."""
        description_lines = []
        
        for line in lines[:20]:  # Procura nos primeiros 20 linhas
            if len(line) >= 7 and line[6] == '*':
                comment = line[7:].strip()
                if comment and not comment.startswith('-') and not comment.startswith('*'):
                    description_lines.append(comment)
        
        if description_lines:
            book.description = ' '.join(description_lines)
    
    def _extract_comments(self, book: CobolBook, lines: List[str]) -> None:
        """Extrai comentários do book."""
        for line in lines:
            if len(line) >= 7 and line[6] == '*':
                comment = line[7:].strip()
                if comment:
                    book.comments.append(comment)
    
    def _extract_data_structures(self, book: CobolBook, lines: List[str]) -> None:
        """Extrai estruturas de dados do book."""
        in_structure = False
        current_structure = []
        
        for line in lines:
            # Ignora comentários
            if len(line) >= 7 and line[6] == '*':
                continue
            
            code_line = line[7:].strip() if len(line) > 7 else line.strip()
            
            # Identifica início de estrutura (níveis 01, 05, 10, etc.)
            if re.match(r'^\d{2}\s+\w+', code_line):
                if in_structure and current_structure:
                    book.add_data_structure('\n'.join(current_structure))
                    current_structure = []
                
                in_structure = True
                current_structure.append(code_line)
            elif in_structure and code_line:
                current_structure.append(code_line)
            elif in_structure and not code_line:
                # Linha vazia pode indicar fim da estrutura
                if current_structure:
                    book.add_data_structure('\n'.join(current_structure))
                    current_structure = []
                in_structure = False
        
        # Adiciona última estrutura se existir
        if current_structure:
            book.add_data_structure('\n'.join(current_structure))
    
    def _extract_constants(self, book: CobolBook, lines: List[str]) -> None:
        """Extrai constantes definidas no book."""
        for line in lines:
            # Ignora comentários
            if len(line) >= 7 and line[6] == '*':
                continue
            
            code_line = line[7:].strip() if len(line) > 7 else line.strip()
            
            # Procura por definições de constantes
            match = self._constant_pattern.search(code_line)
            if match:
                const_name = match.group(1)
                const_value = match.group(2)
                book.add_constant(const_name, const_value)
    
    def _extract_tables(self, book: CobolBook, lines: List[str]) -> None:
        """Extrai tabelas de códigos do book."""
        current_table = []
        table_name = None
        
        for line in lines:
            # Ignora comentários
            if len(line) >= 7 and line[6] == '*':
                continue
            
            code_line = line[7:].strip() if len(line) > 7 else line.strip()
            
            # Identifica tabelas de códigos (padrão: código numérico + descrição)
            match = self._table_pattern.match(code_line)
            if match:
                code = match.group(1)
                description = match.group(2)
                
                if not table_name:
                    table_name = f"Tabela de códigos {book.name}"
                
                current_table.append(f"{code}: {description}")
            elif current_table and not code_line:
                # Fim da tabela
                if current_table:
                    book.add_table(f"{table_name}\n" + '\n'.join(current_table))
                    current_table = []
                    table_name = None
        
        # Adiciona última tabela se existir
        if current_table and table_name:
            book.add_table(f"{table_name}\n" + '\n'.join(current_table))
    
    def get_books_statistics(self, books: List[CobolBook]) -> Dict[str, Any]:
        """Retorna estatísticas dos books parseados."""
        stats = {
            'total_books': len(books),
            'by_type': {},
            'shared_books': 0,
            'total_structures': 0,
            'total_constants': 0,
            'total_tables': 0
        }
        
        for book in books:
            # Conta por tipo
            book_type = book.book_type.value
            stats['by_type'][book_type] = stats['by_type'].get(book_type, 0) + 1
            
            # Conta recursos compartilhados
            if book.is_shared_resource():
                stats['shared_books'] += 1
            
            # Soma totais
            stats['total_structures'] += len(book.data_structures)
            stats['total_constants'] += len(book.constants)
            stats['total_tables'] += len(book.tables)
        
        return stats

