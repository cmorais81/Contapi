"""
Identificador de comentários em código COBOL.
Segue o princípio Single Responsibility (SRP).
"""

import logging
from typing import List, Optional, Tuple
from ...domain.interfaces.cobol_parser import ICommentIdentifier


class CommentIdentifier(ICommentIdentifier):
    """Identifica comentários em linhas COBOL."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Inicializa o identificador.
        
        Args:
            logger: Logger para registrar operações
        """
        self._logger = logger or logging.getLogger(__name__)
        
    def is_comment(self, line: str) -> bool:
        """
        Verifica se uma linha é comentário (coluna 7 com *).
        
        Args:
            line: Linha a ser verificada
            
        Returns:
            True se for comentário, False caso contrário
        """
        # Linha vazia não é comentário
        if not line.strip():
            return False
            
        # Verifica se tem pelo menos 7 caracteres para acessar coluna 7
        if len(line) < 7:
            return False
            
        # Coluna 7 (índice 6) com asterisco indica comentário
        return line[6] == '*'
    
    def is_debug_line(self, line: str) -> bool:
        """
        Verifica se uma linha é de debug (coluna 7 com D).
        
        Args:
            line: Linha a ser verificada
            
        Returns:
            True se for linha de debug, False caso contrário
        """
        if not line.strip() or len(line) < 7:
            return False
            
        return line[6].upper() == 'D'
    
    def is_continuation_line(self, line: str) -> bool:
        """
        Verifica se uma linha é continuação (coluna 7 com -).
        
        Args:
            line: Linha a ser verificada
            
        Returns:
            True se for linha de continuação, False caso contrário
        """
        if not line.strip() or len(line) < 7:
            return False
            
        return line[6] == '-'
    
    def get_line_type(self, line: str) -> str:
        """
        Determina o tipo da linha COBOL.
        
        Args:
            line: Linha a ser analisada
            
        Returns:
            Tipo da linha: 'comment', 'debug', 'continuation', 'code', 'empty'
        """
        if not line.strip():
            return 'empty'
            
        if len(line) < 7:
            return 'code'  # Assume código se muito curta
            
        indicator = line[6]
        
        if indicator == '*':
            return 'comment'
        elif indicator.upper() == 'D':
            return 'debug'
        elif indicator == '-':
            return 'continuation'
        else:
            return 'code'
    
    def extract_comments(self, lines: List[str]) -> List[Tuple[int, str]]:
        """
        Extrai todos os comentários de uma lista de linhas.
        
        Args:
            lines: Lista de linhas COBOL
            
        Returns:
            Lista de tuplas (número_da_linha, texto_do_comentário)
        """
        comments = []
        
        for line_num, line in enumerate(lines, 1):
            if self.is_comment(line):
                # Remove indicador de comentário e espaços extras
                comment_text = line[7:].strip() if len(line) > 7 else ''
                comments.append((line_num, comment_text))
        
        self._logger.debug(f"Extraídos {len(comments)} comentários de {len(lines)} linhas")
        
        return comments
    
    def extract_version_history(self, lines: List[str]) -> List[dict]:
        """
        Extrai histórico de versões dos comentários.
        
        Args:
            lines: Lista de linhas COBOL
            
        Returns:
            Lista de dicionários com informações de versão
        """
        version_history = []
        comments = self.extract_comments(lines)
        
        for line_num, comment in comments:
            # Procura padrões de versionamento nos comentários
            comment_upper = comment.upper()
            
            # Padrão: ** 01 * 11/01/11 * EDIVALDO * NOVO **
            if '*' in comment and any(keyword in comment_upper for keyword in ['VERSAO', 'VERSION', 'DATA', 'AUTOR']):
                parts = [part.strip() for part in comment.split('*') if part.strip()]
                
                if len(parts) >= 3:
                    try:
                        version_info = {
                            'line_number': line_num,
                            'version': parts[0] if parts[0].isdigit() else '',
                            'date': parts[1] if '/' in parts[1] else '',
                            'author': parts[2] if len(parts) > 2 else '',
                            'description': parts[3] if len(parts) > 3 else '',
                            'raw_comment': comment
                        }
                        version_history.append(version_info)
                    except (IndexError, ValueError):
                        # Ignora comentários que não seguem o padrão esperado
                        continue
        
        self._logger.debug(f"Extraído histórico de {len(version_history)} versões")
        
        return version_history
    
    def get_comment_statistics(self, lines: List[str]) -> dict:
        """
        Retorna estatísticas sobre comentários.
        
        Args:
            lines: Lista de linhas COBOL
            
        Returns:
            Dicionário com estatísticas de comentários
        """
        stats = {
            'total_lines': len(lines),
            'comment_lines': 0,
            'debug_lines': 0,
            'continuation_lines': 0,
            'code_lines': 0,
            'empty_lines': 0,
            'comment_percentage': 0.0
        }
        
        for line in lines:
            line_type = self.get_line_type(line)
            
            if line_type == 'comment':
                stats['comment_lines'] += 1
            elif line_type == 'debug':
                stats['debug_lines'] += 1
            elif line_type == 'continuation':
                stats['continuation_lines'] += 1
            elif line_type == 'code':
                stats['code_lines'] += 1
            elif line_type == 'empty':
                stats['empty_lines'] += 1
        
        if stats['total_lines'] > 0:
            stats['comment_percentage'] = (stats['comment_lines'] / stats['total_lines']) * 100
        
        return stats

