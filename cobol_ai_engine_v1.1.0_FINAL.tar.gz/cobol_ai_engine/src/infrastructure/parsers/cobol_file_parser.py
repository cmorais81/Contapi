"""
Implementação concreta do parser de arquivos COBOL empilhados.
Segue os princípios SOLID, especialmente SRP e DIP.
"""

import re
import logging
from typing import Dict, List, Optional
from ...domain.interfaces.cobol_parser import ICobolFileParser
from ...domain.entities.exceptions import CobolParseError


class CobolFileParser(ICobolFileParser):
    """Parser para arquivos COBOL empilhados com múltiplos programas."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Inicializa o parser.
        
        Args:
            logger: Logger para registrar operações (DIP - Dependency Inversion)
        """
        self._logger = logger or logging.getLogger(__name__)
        self._vmember_pattern = re.compile(r'^VMEMBER NAME\s+(\w+)')
        
    def extract_programs(self, file_content: str) -> Dict[str, str]:
        """
        Extrai programas individuais de arquivo empilhado.
        
        Args:
            file_content: Conteúdo do arquivo empilhado
            
        Returns:
            Dicionário com nome do programa como chave e código como valor
            
        Raises:
            CobolParseError: Erro durante extração dos programas
        """
        try:
            programs = {}
            lines = file_content.split('\n')
            current_program = None
            current_lines = []
            
            self._logger.info(f"Iniciando extração de programas. Total de linhas: {len(lines)}")
            
            for line_num, line in enumerate(lines, 1):
                # Verifica se é início de novo programa
                match = self._vmember_pattern.match(line.strip())
                if match:
                    # Salva programa anterior se existir
                    if current_program and current_lines:
                        programs[current_program] = '\n'.join(current_lines)
                        self._logger.debug(f"Programa {current_program} extraído com {len(current_lines)} linhas")
                    
                    # Inicia novo programa
                    current_program = match.group(1).strip()
                    current_lines = []
                    self._logger.debug(f"Iniciando extração do programa {current_program} na linha {line_num}")
                    continue
                
                # Adiciona linha ao programa atual
                if current_program:
                    current_lines.append(line)
            
            # Salva último programa
            if current_program and current_lines:
                programs[current_program] = '\n'.join(current_lines)
                self._logger.debug(f"Programa {current_program} extraído com {len(current_lines)} linhas")
            
            self._logger.info(f"Extração concluída. {len(programs)} programas encontrados: {list(programs.keys())}")
            
            if not programs:
                raise CobolParseError("Nenhum programa encontrado no arquivo")
                
            return programs
            
        except Exception as e:
            if isinstance(e, CobolParseError):
                raise
            raise CobolParseError(f"Erro inesperado durante extração: {str(e)}")
    
    def validate_program_structure(self, program_name: str, program_content: str) -> bool:
        """
        Valida estrutura básica de um programa COBOL.
        
        Args:
            program_name: Nome do programa
            program_content: Conteúdo do programa
            
        Returns:
            True se estrutura é válida, False caso contrário
        """
        try:
            lines = program_content.split('\n')
            
            # Verifica se tem divisões básicas
            has_identification = any('IDENTIFICATION' in line and 'DIVISION' in line for line in lines)
            has_program_id = any('PROGRAM-ID' in line for line in lines)
            
            if not has_identification:
                self._logger.warning(f"Programa {program_name}: IDENTIFICATION DIVISION não encontrada")
                return False
                
            if not has_program_id:
                self._logger.warning(f"Programa {program_name}: PROGRAM-ID não encontrado")
                return False
            
            return True
            
        except Exception as e:
            self._logger.error(f"Erro validando programa {program_name}: {str(e)}")
            return False
    
    def get_program_statistics(self, programs: Dict[str, str]) -> Dict[str, Dict[str, int]]:
        """
        Retorna estatísticas dos programas extraídos.
        
        Args:
            programs: Dicionário de programas extraídos
            
        Returns:
            Estatísticas por programa
        """
        statistics = {}
        
        for program_name, content in programs.items():
            lines = content.split('\n')
            
            statistics[program_name] = {
                'total_lines': len(lines),
                'non_empty_lines': len([line for line in lines if line.strip()]),
                'comment_lines': len([line for line in lines if line.strip().startswith('*')]),
                'code_lines': len([line for line in lines if line.strip() and not line.strip().startswith('*')]),
                'is_valid': self.validate_program_structure(program_name, content)
            }
        
        return statistics

