#!/bin/bash

# Exemplo Básico - COBOL AI Engine
# Este script demonstra o uso básico da ferramenta

echo "=== COBOL AI Engine - Exemplo Básico ==="
echo

# Verificar se os arquivos de exemplo existem
if [ ! -f "dados/fontes.txt" ]; then
    echo "❌ Arquivo dados/fontes.txt não encontrado"
    echo "   Copie seus arquivos COBOL para a pasta dados/"
    exit 1
fi

if [ ! -f "dados/books.txt" ]; then
    echo "❌ Arquivo dados/books.txt não encontrado"
    echo "   Copie seus arquivos de copybooks para a pasta dados/"
    exit 1
fi

echo "✅ Arquivos de entrada encontrados"
echo

# Criar diretório de saída
mkdir -p saida/exemplo_basico

echo "🚀 Executando análise básica (sem IA)..."
echo

# Executar análise básica
python3 ../main.py \
    --fontes dados/fontes.txt \
    --books dados/books.txt \
    --output saida/exemplo_basico \
    --log-level INFO

echo
echo "✅ Análise concluída!"
echo
echo "📁 Arquivos gerados em: saida/exemplo_basico/"
echo

# Listar arquivos gerados
if [ -d "saida/exemplo_basico" ]; then
    echo "📄 Documentação gerada:"
    ls -la saida/exemplo_basico/*.md 2>/dev/null | while read line; do
        echo "   $line"
    done
else
    echo "❌ Diretório de saída não foi criado"
fi

echo
echo "🎉 Exemplo básico concluído!"
echo "   Para análise com IA, configure as variáveis de ambiente:"
echo "   export OPENAI_API_KEY=\"sua_chave_aqui\""

