#!/bin/bash

# Exemplo com IA - COBOL AI Engine
# Este script demonstra o uso com análise de IA

echo "=== COBOL AI Engine - Exemplo com IA ==="
echo

# Verificar se as chaves de API estão configuradas
if [ -z "$OPENAI_API_KEY" ] && [ -z "$AWS_ACCESS_KEY_ID" ]; then
    echo "⚠️  Nenhuma chave de API configurada"
    echo "   Para usar IA, configure uma das opções:"
    echo
    echo "   OpenAI:"
    echo "   export OPENAI_API_KEY=\"sua_chave_openai\""
    echo
    echo "   AWS Bedrock:"
    echo "   export AWS_ACCESS_KEY_ID=\"sua_chave_aws\""
    echo "   export AWS_SECRET_ACCESS_KEY=\"sua_chave_secreta\""
    echo
    echo "   Executando com Mock AI para demonstração..."
    USE_MOCK=true
else
    echo "✅ Chaves de API configuradas"
    USE_MOCK=false
fi

echo

# Verificar arquivos de entrada
if [ ! -f "dados/fontes.txt" ]; then
    echo "❌ Arquivo dados/fontes.txt não encontrado"
    echo "   Copie seus arquivos COBOL para a pasta dados/"
    exit 1
fi

if [ ! -f "dados/books.txt" ]; then
    echo "❌ Arquivo dados/books.txt não encontrado"
    echo "   Copie seus arquivos de copybooks para a pasta dados/"
    exit 1
fi

# Criar diretório de saída
mkdir -p saida/exemplo_com_ia

echo "🤖 Executando análise com IA..."
echo

# Configurar arquivo de configuração baseado na disponibilidade de APIs
if [ "$USE_MOCK" = true ]; then
    CONFIG_FILE="config/mock_ai.yaml"
    cat > "$CONFIG_FILE" << EOF
ai:
  primary_provider: "mock_ai"
  providers:
    mock_ai:
      api_key: "mock_key"
      model_name: "mock-gpt-4"
      max_tokens: 4000
      temperature: 0.3

documentation:
  language: "pt-br"
  template_style: "technical"
  include_complexity_metrics: true
  include_sequence_analysis: true

logging:
  level: "INFO"
  console: true
EOF
    echo "📝 Usando configuração Mock AI"
else
    CONFIG_FILE="../config/config.yaml"
    echo "📝 Usando configuração padrão com APIs reais"
fi

echo

# Executar análise com IA
python3 ../main.py \
    --fontes dados/fontes.txt \
    --books dados/books.txt \
    --output saida/exemplo_com_ia \
    --config "$CONFIG_FILE" \
    --log-level INFO

echo
echo "✅ Análise com IA concluída!"
echo

# Mostrar estatísticas
if [ -f "saida/exemplo_com_ia/relatorio_completo.md" ]; then
    echo "📊 Estatísticas da análise:"
    
    # Contar programas analisados
    PROGRAMAS=$(find saida/exemplo_com_ia -name "*.md" -not -name "relatorio_completo.md" | wc -l)
    echo "   📄 Programas analisados: $PROGRAMAS"
    
    # Mostrar arquivos gerados
    echo "   📁 Arquivos gerados:"
    ls -la saida/exemplo_com_ia/*.md | while read line; do
        echo "      $line"
    done
    
    echo
    echo "🎯 Para ver a análise detalhada:"
    echo "   cat saida/exemplo_com_ia/relatorio_completo.md"
else
    echo "❌ Relatório não foi gerado"
fi

echo
echo "🎉 Exemplo com IA concluído!"

# Limpeza
if [ "$USE_MOCK" = true ] && [ -f "$CONFIG_FILE" ]; then
    rm -f "$CONFIG_FILE"
fi

