"""
Teste completo do sistema COBOL AI Engine.
"""

import sys
import os
sys.path.append('/home/ubuntu/cobol_ai_engine')

from src.application.services.cobol_engine import CobolEngine
import logging

# Configura logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def test_complete_system():
    """Testa o sistema completo."""
    
    logger.info("=== Teste Completo do COBOL AI Engine ===")
    
    try:
        # Inicializa o motor
        engine = CobolEngine(
            config_path='/home/ubuntu/cobol_ai_engine/config/config.yaml',
            logger=logger
        )
        
        # Processa os arquivos de exemplo
        results = engine.process_cobol_files(
            fontes_path='/home/ubuntu/upload/fontes.txt',
            books_path='/home/ubuntu/upload/BOOKS.txt',
            output_dir='/home/ubuntu/cobol_ai_engine/output'
        )
        
        # Mostra resultados
        logger.info("=== Resultados do Processamento ===")
        logger.info(f"Programas processados: {results['programs_count']}")
        logger.info(f"Books processados: {results['books_count']}")
        logger.info(f"Sequência identificada: {' -> '.join(results['sequence'])}")
        logger.info(f"Relacionamentos: {results['relationships']}")
        logger.info(f"Arquivos de documentação gerados: {len(results['documentation_files'])}")
        
        # Mostra resumo da análise de IA
        ai_summary = results['ai_analysis_summary']
        logger.info(f"Análises de IA bem-sucedidas: {ai_summary['successful_analyses']}/{ai_summary['total_programs']}")
        logger.info(f"Taxa de sucesso: {ai_summary['success_rate']:.1f}%")
        logger.info(f"Tokens totais usados: {ai_summary['total_tokens_used']}")
        logger.info(f"Provedores utilizados: {ai_summary['providers_used']}")
        
        # Lista arquivos gerados
        logger.info("\n=== Arquivos Gerados ===")
        for file_path in results['documentation_files']:
            logger.info(f"- {file_path}")
        
        logger.info("\n✓ Teste completo executado com sucesso!")
        
    except Exception as e:
        logger.error(f"✗ Erro no teste completo: {e}")
        raise

if __name__ == "__main__":
    test_complete_system()

