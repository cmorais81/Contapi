# Manual de Configuração - COBOL AI Engine v1.0

## 📋 Índice

1. [Visão Geral](#visão-geral)
2. [Estrutura de Configuração](#estrutura-de-configuração)
3. [Configuração de IA](#configuração-de-ia)
4. [Configuração de Parsing](#configuração-de-parsing)
5. [Configuração de Documentação](#configuração-de-documentação)
6. [Configuração de Logging](#configuração-de-logging)
7. [Configuração de Performance](#configuração-de-performance)
8. [Ambientes](#ambientes)
9. [Segurança](#segurança)
10. [Exemplos Completos](#exemplos-completos)

## 🎯 Visão Geral

O COBOL AI Engine utiliza um sistema de configuração flexível baseado em arquivos YAML e variáveis de ambiente. A configuração permite personalizar todos os aspectos do processamento, desde provedores de IA até formatos de documentação.

### Hierarquia de Configuração

1. **Arquivo de configuração** (`config/config.yaml`)
2. **Variáveis de ambiente** (sobrescreve arquivo)
3. **Parâmetros de linha de comando** (sobrescreve tudo)

### Localização dos Arquivos

```
cobol_ai_engine/
├── config/
│   ├── config.yaml          # Configuração padrão
│   ├── development.yaml     # Ambiente de desenvolvimento
│   ├── production.yaml      # Ambiente de produção
│   └── testing.yaml         # Ambiente de testes
```

## 🏗️ Estrutura de Configuração

### Arquivo Base (config.yaml)

```yaml
# Configuração do COBOL AI Engine
version: "1.0"

# Configurações de IA
ai:
  primary_provider: "openai"
  fallback_providers: ["bedrock"]
  timeout: 30
  max_retries: 3
  providers:
    openai:
      api_key: "${OPENAI_API_KEY}"
      model_name: "gpt-4"
      max_tokens: 4000
      temperature: 0.3
    bedrock:
      aws_access_key_id: "${AWS_ACCESS_KEY_ID}"
      aws_secret_access_key: "${AWS_SECRET_ACCESS_KEY}"
      aws_region: "us-east-1"
      model_name: "anthropic.claude-3-sonnet-20240229-v1:0"

# Configurações de parsing COBOL
parsing:
  validate_cobol_format: true
  extract_comments: true
  max_line_length: 72
  encoding: "utf-8"
  member_name_pattern: "VMEMBER NAME"

# Configurações de documentação
documentation:
  language: "pt-br"
  template_style: "technical"
  include_complexity_metrics: true
  include_sequence_analysis: true
  include_relationship_diagram: false
  output_format: "markdown"

# Configurações de logging
logging:
  level: "INFO"
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  file: null
  console: true

# Configurações de performance
performance:
  max_concurrent_requests: 3
  chunk_size: 1000
  memory_limit_mb: 1024
  cache_enabled: true
```

## 🤖 Configuração de IA

### OpenAI

#### Configuração Básica
```yaml
ai:
  primary_provider: "openai"
  providers:
    openai:
      api_key: "${OPENAI_API_KEY}"
      model_name: "gpt-4"
      max_tokens: 4000
      temperature: 0.3
```

#### Configuração Avançada
```yaml
ai:
  providers:
    openai:
      api_key: "${OPENAI_API_KEY}"
      api_endpoint: "https://api.openai.com/v1"
      model_name: "gpt-4"
      max_tokens: 4000
      temperature: 0.3
      top_p: 1.0
      frequency_penalty: 0.0
      presence_penalty: 0.0
      organization: "${OPENAI_ORG_ID}"
      timeout: 30
      max_retries: 3
      additional_parameters:
        stream: false
        logprobs: null
```

#### Modelos Suportados
- `gpt-4`: Melhor qualidade, mais caro
- `gpt-4-turbo`: Balanceado
- `gpt-3.5-turbo`: Mais rápido, mais barato

### AWS Bedrock

#### Configuração Básica
```yaml
ai:
  primary_provider: "bedrock"
  providers:
    bedrock:
      aws_access_key_id: "${AWS_ACCESS_KEY_ID}"
      aws_secret_access_key: "${AWS_SECRET_ACCESS_KEY}"
      aws_region: "us-east-1"
      model_name: "anthropic.claude-3-sonnet-20240229-v1:0"
```

#### Configuração Avançada
```yaml
ai:
  providers:
    bedrock:
      aws_access_key_id: "${AWS_ACCESS_KEY_ID}"
      aws_secret_access_key: "${AWS_SECRET_ACCESS_KEY}"
      aws_session_token: "${AWS_SESSION_TOKEN}"  # Opcional
      aws_region: "us-east-1"
      model_name: "anthropic.claude-3-sonnet-20240229-v1:0"
      max_tokens: 4000
      temperature: 0.3
      top_p: 0.9
      timeout: 60
      additional_parameters:
        anthropic_version: "bedrock-2023-05-31"
```

#### Modelos Suportados
- `anthropic.claude-3-opus-20240229-v1:0`: Máxima qualidade
- `anthropic.claude-3-sonnet-20240229-v1:0`: Balanceado
- `anthropic.claude-3-haiku-20240307-v1:0`: Mais rápido

### Configuração Multi-Provider

```yaml
ai:
  primary_provider: "openai"
  fallback_providers: ["bedrock", "mock_ai"]
  timeout: 30
  max_retries: 3
  
  # Estratégia de fallback
  fallback_strategy: "sequential"  # ou "parallel"
  
  # Configuração de custos (opcional)
  cost_limits:
    daily_limit_usd: 50.0
    per_request_limit_usd: 1.0
  
  providers:
    openai:
      api_key: "${OPENAI_API_KEY}"
      model_name: "gpt-4"
      priority: 10
      
    bedrock:
      aws_access_key_id: "${AWS_ACCESS_KEY_ID}"
      aws_secret_access_key: "${AWS_SECRET_ACCESS_KEY}"
      aws_region: "us-east-1"
      model_name: "anthropic.claude-3-sonnet-20240229-v1:0"
      priority: 5
      
    mock_ai:
      api_key: "mock_key"
      model_name: "mock-gpt-4"
      priority: 1
```

## 📝 Configuração de Parsing

### Configuração Básica
```yaml
parsing:
  validate_cobol_format: true
  extract_comments: true
  max_line_length: 72
  encoding: "utf-8"
```

### Configuração Avançada
```yaml
parsing:
  # Validação de formato
  validate_cobol_format: true
  strict_column_validation: false
  
  # Extração de conteúdo
  extract_comments: true
  extract_copy_statements: true
  extract_call_statements: true
  extract_file_descriptors: true
  
  # Formatação
  max_line_length: 72
  comment_column: 7
  sequence_area_start: 1
  sequence_area_end: 6
  
  # Encoding e caracteres
  encoding: "utf-8"
  line_ending: "auto"  # "auto", "unix", "windows"
  
  # Padrões de identificação
  member_name_pattern: "VMEMBER NAME"
  program_id_pattern: "PROGRAM-ID\\."
  division_patterns:
    - "IDENTIFICATION DIVISION"
    - "ENVIRONMENT DIVISION"
    - "DATA DIVISION"
    - "PROCEDURE DIVISION"
  
  # Filtros
  ignore_empty_lines: true
  ignore_sequence_numbers: true
  
  # Performance
  chunk_size: 1000
  parallel_processing: false
```

### Configuração para Diferentes Mainframes

#### IBM z/OS
```yaml
parsing:
  max_line_length: 72
  comment_column: 7
  sequence_area_start: 1
  sequence_area_end: 6
  member_name_pattern: "VMEMBER NAME"
```

#### Unisys
```yaml
parsing:
  max_line_length: 80
  comment_column: 1
  sequence_area_start: 73
  sequence_area_end: 80
  member_name_pattern: "\\*MEMBER"
```

#### Fujitsu
```yaml
parsing:
  max_line_length: 72
  comment_column: 7
  sequence_area_start: 1
  sequence_area_end: 6
  member_name_pattern: "\\$SET"
```

## 📚 Configuração de Documentação

### Configuração Básica
```yaml
documentation:
  language: "pt-br"
  template_style: "technical"
  output_format: "markdown"
```

### Configuração Avançada
```yaml
documentation:
  # Idioma e localização
  language: "pt-br"  # "en", "pt-br", "es"
  date_format: "%d/%m/%Y"
  time_format: "%H:%M:%S"
  
  # Estilo e template
  template_style: "technical"  # "technical", "business", "minimal", "corporate"
  output_format: "markdown"   # "markdown", "html", "pdf"
  
  # Conteúdo incluído
  include_complexity_metrics: true
  include_sequence_analysis: true
  include_relationship_diagram: false
  include_code_snippets: true
  include_version_history: false
  include_author_info: true
  
  # Formatação
  max_code_snippet_lines: 20
  table_of_contents: true
  numbered_sections: false
  
  # Análise de relacionamentos
  relationship_analysis:
    include_call_graph: true
    include_copy_dependencies: true
    include_file_dependencies: true
    max_depth: 3
  
  # Métricas de complexidade
  complexity_metrics:
    cyclomatic_complexity: true
    lines_of_code: true
    comment_ratio: true
    nesting_depth: true
  
  # Customização de seções
  sections:
    summary: true
    technical_details: true
    functional_details: true
    relationships: true
    complexity: true
    recommendations: false
```

### Templates Personalizados

#### Template Técnico
```yaml
documentation:
  template_style: "technical"
  sections:
    summary: true
    architecture: true
    technical_details: true
    code_analysis: true
    performance: true
    relationships: true
```

#### Template de Negócio
```yaml
documentation:
  template_style: "business"
  sections:
    executive_summary: true
    business_purpose: true
    functional_requirements: true
    process_flow: true
    business_rules: true
    compliance: true
```

#### Template Corporativo
```yaml
documentation:
  template_style: "corporate"
  sections:
    cover_page: true
    executive_summary: true
    technical_overview: true
    detailed_analysis: true
    recommendations: true
    appendices: true
  
  branding:
    company_name: "Sua Empresa"
    logo_path: "assets/logo.png"
    color_scheme: "corporate"
```

## 📊 Configuração de Logging

### Configuração Básica
```yaml
logging:
  level: "INFO"
  console: true
```

### Configuração Avançada
```yaml
logging:
  # Nível de logging
  level: "INFO"  # "DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"
  
  # Saídas
  console: true
  file: "logs/cobol_engine.log"
  
  # Formatação
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  date_format: "%Y-%m-%d %H:%M:%S"
  
  # Rotação de logs
  rotation:
    enabled: true
    max_size_mb: 10
    backup_count: 5
    
  # Logs específicos
  loggers:
    "src.infrastructure.parsers": "DEBUG"
    "src.infrastructure.ai_providers": "INFO"
    "src.application.services": "INFO"
    
  # Filtros
  filters:
    exclude_patterns:
      - "Token usage:"
      - "HTTP request"
    include_only_errors: false
```

### Configuração para Produção
```yaml
logging:
  level: "WARNING"
  console: false
  file: "/var/log/cobol_engine/app.log"
  
  rotation:
    enabled: true
    max_size_mb: 50
    backup_count: 10
    
  # Logs estruturados para análise
  structured: true
  format: "json"
  
  # Integração com sistemas de monitoramento
  external_handlers:
    syslog:
      enabled: true
      host: "log-server.empresa.com"
      port: 514
    elasticsearch:
      enabled: false
      host: "elastic.empresa.com"
      index: "cobol-engine-logs"
```

## ⚡ Configuração de Performance

### Configuração Básica
```yaml
performance:
  max_concurrent_requests: 3
  chunk_size: 1000
```

### Configuração Avançada
```yaml
performance:
  # Concorrência
  max_concurrent_requests: 3
  max_workers: 4
  
  # Processamento
  chunk_size: 1000
  batch_size: 10
  
  # Memória
  memory_limit_mb: 1024
  gc_threshold: 0.8
  
  # Cache
  cache_enabled: true
  cache_size_mb: 256
  cache_ttl_seconds: 3600
  
  # Timeouts
  request_timeout: 30
  connection_timeout: 10
  read_timeout: 60
  
  # Otimizações
  lazy_loading: true
  streaming_enabled: false
  compression_enabled: true
```

### Configuração para Grandes Volumes
```yaml
performance:
  # Processamento otimizado para arquivos grandes
  max_concurrent_requests: 1
  chunk_size: 5000
  batch_size: 50
  
  # Memória expandida
  memory_limit_mb: 4096
  gc_threshold: 0.9
  
  # Cache otimizado
  cache_enabled: true
  cache_size_mb: 1024
  
  # Streaming para arquivos muito grandes
  streaming_enabled: true
  stream_chunk_size: 1024
```

## 🌍 Ambientes

### Desenvolvimento (development.yaml)
```yaml
ai:
  primary_provider: "mock_ai"
  
parsing:
  validate_cobol_format: false
  
documentation:
  template_style: "minimal"
  
logging:
  level: "DEBUG"
  console: true
  file: "logs/dev.log"
  
performance:
  max_concurrent_requests: 1
  cache_enabled: false
```

### Teste (testing.yaml)
```yaml
ai:
  primary_provider: "mock_ai"
  
parsing:
  validate_cobol_format: true
  
documentation:
  template_style: "technical"
  include_complexity_metrics: false
  
logging:
  level: "INFO"
  console: true
  file: "logs/test.log"
  
performance:
  max_concurrent_requests: 2
  cache_enabled: true
```

### Produção (production.yaml)
```yaml
ai:
  primary_provider: "openai"
  fallback_providers: ["bedrock"]
  
parsing:
  validate_cobol_format: true
  strict_column_validation: true
  
documentation:
  template_style: "corporate"
  include_complexity_metrics: true
  include_sequence_analysis: true
  
logging:
  level: "WARNING"
  console: false
  file: "/var/log/cobol_engine/prod.log"
  
performance:
  max_concurrent_requests: 5
  memory_limit_mb: 2048
  cache_enabled: true
```

## 🔒 Segurança

### Configuração de Segurança
```yaml
security:
  # Criptografia de chaves
  encrypt_api_keys: true
  encryption_key: "${ENCRYPTION_KEY}"
  
  # Validação de entrada
  validate_input_files: true
  max_file_size_mb: 100
  allowed_file_extensions: [".txt", ".cob", ".cbl"]
  
  # Sanitização
  sanitize_output: true
  remove_sensitive_data: true
  
  # Auditoria
  audit_enabled: true
  audit_file: "/var/log/cobol_engine/audit.log"
  
  # Rate limiting
  rate_limiting:
    enabled: true
    requests_per_minute: 60
    requests_per_hour: 1000
```

### Variáveis de Ambiente Seguras
```bash
# Chaves de API
export OPENAI_API_KEY="sk-..."
export AWS_ACCESS_KEY_ID="AKIA..."
export AWS_SECRET_ACCESS_KEY="..."

# Criptografia
export ENCRYPTION_KEY="sua_chave_de_criptografia"

# Configuração de ambiente
export COBOL_ENGINE_ENV="production"
export COBOL_ENGINE_CONFIG="/etc/cobol_engine/config.yaml"
```

## 📋 Exemplos Completos

### Configuração Empresarial Completa
```yaml
# config/empresa.yaml
version: "1.0"
environment: "production"

ai:
  primary_provider: "bedrock"
  fallback_providers: ["openai"]
  timeout: 60
  max_retries: 3
  
  cost_limits:
    daily_limit_usd: 100.0
    per_request_limit_usd: 2.0
  
  providers:
    bedrock:
      aws_access_key_id: "${AWS_ACCESS_KEY_ID}"
      aws_secret_access_key: "${AWS_SECRET_ACCESS_KEY}"
      aws_region: "us-east-1"
      model_name: "anthropic.claude-3-sonnet-20240229-v1:0"
      max_tokens: 4000
      temperature: 0.2
      
    openai:
      api_key: "${OPENAI_API_KEY}"
      model_name: "gpt-4"
      max_tokens: 4000
      temperature: 0.2

parsing:
  validate_cobol_format: true
  strict_column_validation: true
  extract_comments: true
  extract_copy_statements: true
  extract_call_statements: true
  max_line_length: 72
  encoding: "utf-8"
  
  # Padrões específicos da empresa
  member_name_pattern: "VMEMBER NAME"
  program_id_pattern: "PROGRAM-ID\\."

documentation:
  language: "pt-br"
  template_style: "corporate"
  output_format: "markdown"
  
  include_complexity_metrics: true
  include_sequence_analysis: true
  include_relationship_diagram: true
  include_code_snippets: true
  include_author_info: true
  
  branding:
    company_name: "Banco Exemplo S.A."
    department: "Tecnologia da Informação"
    project: "Modernização Mainframe"
  
  sections:
    cover_page: true
    executive_summary: true
    technical_overview: true
    detailed_analysis: true
    relationships: true
    complexity: true
    recommendations: true

logging:
  level: "INFO"
  console: false
  file: "/var/log/cobol_engine/empresa.log"
  
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  
  rotation:
    enabled: true
    max_size_mb: 50
    backup_count: 10
  
  external_handlers:
    syslog:
      enabled: true
      host: "log.empresa.com"
      port: 514

performance:
  max_concurrent_requests: 5
  chunk_size: 2000
  memory_limit_mb: 2048
  
  cache_enabled: true
  cache_size_mb: 512
  cache_ttl_seconds: 7200

security:
  encrypt_api_keys: true
  validate_input_files: true
  max_file_size_mb: 500
  audit_enabled: true
  audit_file: "/var/log/cobol_engine/audit.log"
```

### Uso da Configuração
```bash
# Usar configuração específica
python3 main.py \
  --config config/empresa.yaml \
  --fontes /mainframe/fontes.txt \
  --books /mainframe/books.txt \
  --output /docs/analise_mainframe
```

---

*Manual de Configuração - COBOL AI Engine v1.0*
*Última atualização: Setembro 2025*

