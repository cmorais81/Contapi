"""
Teste do gerador de documentação.
"""

import sys
import os
sys.path.append('/home/ubuntu/cobol_ai_engine')

from src.application.services.documentation_generator import MarkdownDocumentationGenerator, MarkdownFormatter
from src.domain.entities.cobol_program import CobolProgram
import logging

# Configura logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_documentation_generator():
    """Testa o gerador de documentação."""
    
    logger.info("=== Testando Gerador de Documentação ===")
    
    # Cria formatador e gerador
    formatter = MarkdownFormatter()
    generator = MarkdownDocumentationGenerator(formatter, logger)
    
    # Cria programa de exemplo
    program = CobolProgram(name="TEST001", author="Tester")
    program.add_called_program("SUB001")
    program.add_used_copybook("CPY001")
    
    # Cria resultados de análise de exemplo
    analysis_results = {
        'summary': 'Este é um programa de teste.',
        'technical_details': {
            'estrutura': 'Estrutura simples com 3 divisões.',
            'logica': 'Lógica de processamento básica.'
        },
        'functional_details': {
            'objetivo': 'Testar o gerador de documentação.',
            'regras': 'Nenhuma regra de negócio complexa.'
        },
        'relationships': {
            'called_programs': ['SUB001', 'SUB002'],
            'used_copybooks': ['CPY001']
        }
    }
    
    # Gera documentação
    try:
        documentation = generator.generate_documentation(program, analysis_results)
        logger.info("✓ Documentação gerada com sucesso")
        
        logger.info("-" * 50)
        logger.info(documentation)
        logger.info("-" * 50)
        
        # Salva documentação
        output_path = "/home/ubuntu/cobol_ai_engine/docs/TEST001.md"
        generator.save_documentation(documentation, output_path)
        logger.info(f"✓ Documentação salva em: {output_path}")
        
    except Exception as e:
        logger.error(f"✗ Erro gerando documentação: {e}")

if __name__ == "__main__":
    test_documentation_generator()


