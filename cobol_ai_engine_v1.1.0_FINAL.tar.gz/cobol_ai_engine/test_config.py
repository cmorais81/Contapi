"""
Teste do sistema de configuração.
"""

import sys
import os
sys.path.append('/home/ubuntu/cobol_ai_engine')

from src.infrastructure.config.configuration_manager import ConfigurationManager
from src.domain.interfaces.configuration import AIProviderType
import logging

# Configura logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_configuration():
    """Testa o sistema de configuração."""
    
    logger.info("=== Testando Sistema de Configuração ===")
    
    # Testa carregamento de arquivo
    config_manager = ConfigurationManager(logger)
    
    try:
        config_manager.load_from_file('/home/ubuntu/cobol_ai_engine/config/config.yaml')
        logger.info("✓ Configuração carregada do arquivo YAML")
    except Exception as e:
        logger.error(f"✗ Erro carregando configuração: {e}")
        
        # Fallback para variáveis de ambiente
        logger.info("Tentando carregar de variáveis de ambiente...")
        config_manager.load_from_environment()
        logger.info("✓ Configuração carregada de variáveis de ambiente")
    
    # Testa validação
    is_valid = config_manager.is_valid()
    logger.info(f"Configuração válida: {is_valid}")
    
    # Testa provedor primário
    primary = config_manager.get_primary_provider()
    logger.info(f"Provedor primário: {primary.value}")
    
    # Testa provedores de fallback
    fallbacks = config_manager.get_fallback_providers()
    logger.info(f"Provedores de fallback: {[p.value for p in fallbacks]}")
    
    # Testa configurações específicas
    try:
        openai_config = config_manager.get_ai_configuration(AIProviderType.OPENAI)
        logger.info(f"✓ OpenAI configurado: modelo={openai_config.get_model_name()}, "
                   f"max_tokens={openai_config.get_max_tokens()}")
    except Exception as e:
        logger.warning(f"OpenAI não configurado: {e}")
    
    # Testa configurações de parsing
    parsing_config = config_manager.get_parsing_configuration()
    logger.info(f"Configuração de parsing: {parsing_config}")
    
    # Testa configurações de documentação
    doc_config = config_manager.get_documentation_configuration()
    logger.info(f"Configuração de documentação: {doc_config}")

if __name__ == "__main__":
    test_configuration()

