# Arquitetura do COBOL AI Engine

## Visão Geral

O COBOL AI Engine foi projetado seguindo os princípios de Clean Architecture e SOLID, garantindo alta manutenibilidade, extensibilidade e testabilidade.

## Estrutura de Camadas

### 1. Domain Layer (Domínio)

**Localização**: `src/domain/`

Contém as regras de negócio centrais e entidades do sistema.

#### Entidades
- `CobolProgram`: Representa um programa COBOL com suas características
- `CobolBook`: Representa copybooks e estruturas de dados
- `AIConfiguration`: Configurações específicas de provedores de IA

#### Interfaces
- `ICobolParser`: Contratos para parsing de COBOL
- `IAIProvider`: Contratos para provedores de IA
- `IConfigurationManager`: Contratos para gerenciamento de configuração
- `IDocumentationGenerator`: Contratos para geração de documentação

### 2. Infrastructure Layer (Infraestrutura)

**Localização**: `src/infrastructure/`

Implementações concretas das interfaces do domínio.

#### Parsers (`parsers/`)
- `CobolFileParser`: Parse de arquivos empilhados
- `CobolLineExtractor`: Extração de linhas válidas COBOL
- `CommentIdentifier`: Identificação de comentários
- `BooksParser`: Parse de copybooks
- `ProgramAnalyzer`: Análise de relacionamentos

#### AI Providers (`ai_providers/`)
- `OpenAIProvider`: Integração com OpenAI API
- `BedrockProvider`: Integração com AWS Bedrock
- `AIProviderFactory`: Factory para criação de provedores
- `AIOrchestrator`: Orquestração com fallback

#### Configuration (`config/`)
- `ConfigurationManager`: Gerenciamento de configurações

### 3. Application Layer (Aplicação)

**Localização**: `src/application/`

Orquestra as operações e implementa casos de uso.

#### Services (`services/`)
- `CobolEngine`: Motor principal do sistema
- `MarkdownDocumentationGenerator`: Geração de documentação

## Fluxo de Dados

```
Arquivos COBOL → Parser → Análise → IA → Documentação → Markdown
     ↓              ↓        ↓      ↓         ↓           ↓
  fontes.txt   CobolProgram  |   AIRequest  DocData   arquivo.md
  books.txt    CobolBook     |   AIResponse
                            ↓
                    Relacionamentos
                    Sequência
                    Complexidade
```

## Princípios SOLID Aplicados

### Single Responsibility Principle (SRP)

Cada classe tem uma única responsabilidade:

- `CobolFileParser`: Apenas parsing de arquivos
- `OpenAIProvider`: Apenas integração com OpenAI
- `MarkdownFormatter`: Apenas formatação Markdown

### Open/Closed Principle (OCP)

Sistema aberto para extensão, fechado para modificação:

- Novos provedores de IA podem ser adicionados sem modificar código existente
- Novos formatos de documentação podem ser implementados
- Sistema de configuração extensível

### Liskov Substitution Principle (LSP)

Objetos podem ser substituídos por instâncias de subtipos:

- Qualquer `IAIProvider` pode ser usado intercambiavelmente
- Diferentes `IDocumentationGenerator` são substituíveis

### Interface Segregation Principle (ISP)

Interfaces específicas e coesas:

- `ICobolParser` separado de `IBooksParser`
- `IAIProvider` focado apenas em análise de IA
- Interfaces pequenas e específicas

### Dependency Inversion Principle (DIP)

Dependência de abstrações, não de implementações:

- `CobolEngine` depende de interfaces, não de classes concretas
- Injeção de dependência via construtores
- Configuração externa de dependências

## Padrões de Design

### Strategy Pattern

**Uso**: Provedores de IA intercambiáveis

```python
class IAIProvider(ABC):
    @abstractmethod
    def analyze_cobol_program(self, request: AIRequest) -> AIResponse:
        pass

class OpenAIProvider(IAIProvider):
    def analyze_cobol_program(self, request: AIRequest) -> AIResponse:
        # Implementação específica OpenAI
        
class BedrockProvider(IAIProvider):
    def analyze_cobol_program(self, request: AIRequest) -> AIResponse:
        # Implementação específica Bedrock
```

### Factory Method Pattern

**Uso**: Criação de provedores de IA

```python
class AIProviderFactory:
    def create_provider(self, provider_type: str, config: IAIConfiguration) -> IAIProvider:
        if provider_type == "openai":
            return OpenAIProvider(config)
        elif provider_type == "bedrock":
            return BedrockProvider(config)
```

### Template Method Pattern

**Uso**: Geração de documentação

```python
class BaseDocumentationGenerator:
    def generate_documentation(self, program, analysis):
        # Template method
        parts = []
        parts.append(self._generate_header(program, analysis))
        parts.append(self._generate_summary(program, analysis))
        parts.append(self._generate_technical_details(program, analysis))
        return "\n".join(parts)
    
    # Métodos abstratos para subclasses implementarem
    @abstractmethod
    def _generate_summary(self, program, analysis):
        pass
```

### Observer Pattern

**Uso**: Sistema de logging

Logging estruturado em todas as camadas para observabilidade.

## Configuração e Extensibilidade

### Sistema de Configuração

```yaml
ai:
  primary_provider: "openai"
  fallback_providers: ["bedrock"]
  providers:
    openai:
      api_key: "${OPENAI_API_KEY}"
      model_name: "gpt-4"
```

### Extensão para Novos Provedores

1. Implementar `IAIProvider`
2. Registrar na `AIProviderFactory`
3. Adicionar configuração específica
4. Implementar testes

### Extensão para Novos Formatos

1. Implementar `IDocumentationGenerator`
2. Criar formatador específico
3. Registrar no sistema
4. Configurar templates

## Tratamento de Erros

### Hierarquia de Exceções

```python
CobolEngineError (base)
├── CobolParseError
├── AIProviderError
├── ConfigurationError
└── DocumentationGenerationError
```

### Estratégias de Recuperação

- **Parsing**: Continua processamento mesmo com erros em programas individuais
- **IA**: Sistema de fallback automático entre provedores
- **Configuração**: Fallback para variáveis de ambiente
- **Documentação**: Gera documentação básica mesmo sem análise de IA

## Performance e Escalabilidade

### Otimizações Implementadas

- Parsing incremental de arquivos grandes
- Cache de configurações
- Reutilização de conexões HTTP
- Processamento lazy de análises

### Pontos de Extensão para Escala

- Processamento paralelo de programas
- Cache de resultados de IA
- Processamento assíncrono
- Distribuição de carga entre provedores

## Segurança

### Proteção de Credenciais

- Configuração via variáveis de ambiente
- Não exposição de chaves em logs
- Validação de configurações

### Validação de Entrada

- Validação de formato COBOL
- Sanitização de conteúdo para IA
- Limitação de tamanho de arquivos

## Monitoramento e Observabilidade

### Logging Estruturado

```python
logger.info("Processamento iniciado", extra={
    'programs_count': len(programs),
    'provider': provider_name,
    'tokens_estimated': estimated_tokens
})
```

### Métricas Coletadas

- Tempo de processamento por fase
- Tokens consumidos por provedor
- Taxa de sucesso de análises
- Estatísticas de parsing

## Testes

### Estratégia de Testes

- **Unitários**: Cada classe isoladamente
- **Integração**: Componentes trabalhando juntos
- **Sistema**: Fluxo completo end-to-end
- **Mocks**: Para APIs externas

### Cobertura

- Parsing: 95%+
- Configuração: 90%+
- Geração de documentação: 85%+
- Integração IA: 80%+ (limitado por APIs externas)

## Deployment

### Requisitos Mínimos

- Python 3.11+
- 512MB RAM
- 100MB espaço em disco

### Configuração de Produção

- Variáveis de ambiente para credenciais
- Logging para arquivo
- Monitoramento de recursos
- Backup de configurações

## Roadmap Técnico

### Próximas Melhorias

1. **Performance**
   - Processamento paralelo
   - Cache inteligente
   - Otimização de memória

2. **Funcionalidades**
   - Análise de performance de código
   - Geração de diagramas
   - Interface web

3. **Integrações**
   - Mais provedores de IA
   - Sistemas de versionamento
   - Ferramentas de CI/CD

4. **Qualidade**
   - Análise estática de código
   - Testes de carga
   - Documentação automática

