"""
COBOL AI Engine v2.0.0 - Módulo Principal
Interface simplificada para importação em notebooks e scripts Python.
"""

# Importações principais
from src.api.cobol_analyzer import COBOLAnalyzer, analyze_cobol, analyze_cobol_file

# Versão
__version__ = "2.0.0"

# Exportar classes e funções principais
__all__ = [
    'COBOLAnalyzer',
    'analyze_cobol',
    'analyze_cobol_file',
    '__version__'
]

# Função de conveniência para criar analisador
def create_analyzer(provider="enhanced_mock", config_path=None):
    """
    Cria uma instância do analisador COBOL.
    
    Args:
        provider: Provedor de IA ("openai", "databricks", "bedrock", "enhanced_mock")
        config_path: Caminho para configuração personalizada (opcional)
        
    Returns:
        Instância do COBOLAnalyzer
    """
    return COBOLAnalyzer(config_path=config_path, provider=provider)

# Informações sobre provedores disponíveis
AVAILABLE_PROVIDERS = {
    "enhanced_mock": "Provider mock inteligente (sempre funciona)",
    "basic": "Provider básico (fallback final)",
    "openai": "OpenAI GPT (requer OPENAI_API_KEY)",
    "databricks": "Databricks Foundation Models (requer credenciais)",
    "bedrock": "AWS Bedrock Claude (requer credenciais AWS)",
    "luzia": "LuzIA Corporativo (requer credenciais corporativas)"
}

def list_providers():
    """Lista todos os provedores disponíveis com descrições."""
    print("Provedores Disponíveis:")
    print("=" * 50)
    for provider, description in AVAILABLE_PROVIDERS.items():
        print(f"• {provider}: {description}")

def quick_start_guide():
    """Exibe guia de início rápido."""
    print("""
COBOL AI Engine v2.0.0 - Guia de Início Rápido
===============================================

1. ANÁLISE SIMPLES DE CÓDIGO:
   ```python
   import cobol_ai_engine as cae
   
   codigo_cobol = '''
   IDENTIFICATION DIVISION.
   PROGRAM-ID. HELLO-WORLD.
   PROCEDURE DIVISION.
   DISPLAY 'Hello, World!'.
   STOP RUN.
   '''
   
   resultado = cae.analyze_cobol(codigo_cobol)
   print(resultado['documentation'])
   ```

2. ANÁLISE DE ARQUIVO:
   ```python
   resultado = cae.analyze_cobol_file('meu_programa.cbl')
   ```

3. USO AVANÇADO COM CLASSE:
   ```python
   analyzer = cae.create_analyzer(provider='openai')
   resultado = analyzer.analyze_code(codigo_cobol)
   ```

4. ANÁLISE DE MÚLTIPLOS ARQUIVOS:
   ```python
   analyzer = cae.create_analyzer()
   resultados = analyzer.analyze_directory('/caminho/para/cobol/')
   ```

5. GERAR RELATÓRIO PDF:
   ```python
   analyzer.generate_report(resultados, 'relatorio.pdf', format='pdf')
   ```

Para mais informações, consulte a documentação completa.
    """)

# Exibir informações quando importado
def _show_welcome():
    """Exibe mensagem de boas-vindas."""
    print(f"COBOL AI Engine v{__version__} carregado com sucesso!")
    print("Digite cobol_ai_engine.quick_start_guide() para ver exemplos de uso.")

# Executar welcome apenas se importado interativamente
import sys
if hasattr(sys, 'ps1'):  # Verifica se está em modo interativo
    _show_welcome()

