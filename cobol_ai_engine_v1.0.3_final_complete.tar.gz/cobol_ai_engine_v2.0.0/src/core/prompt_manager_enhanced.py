"""
COBOL AI Engine v3.0.0 - Enhanced Prompt Manager
Gerenciador aprimorado de prompts com suporte a múltiplos modelos e engenharia de prompt dinâmica.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import yaml
import os

class EnhancedPromptManager:
    """
    Gerenciador aprimorado de prompts que adapta dinamicamente os prompts
    baseado no modelo de IA selecionado e no contexto da análise.
    """
    
    def __init__(self, model_name: str = 'default', config_path: str = 'config/prompts.yaml'):
        """
        Inicializa o gerenciador de prompts aprimorado.
        
        Args:
            model_name: Nome do modelo de IA a ser usado
            config_path: Caminho para o arquivo de configuração de prompts
        """
        self.logger = logging.getLogger(__name__)
        self.model_name = model_name
        self.config_path = config_path
        
        # Carregar configuração base
        self.config = self._load_config()
        
        # Configurações específicas por modelo
        self.model_configs = {
            'claude_3_5_sonnet': {
                'persona': 'especialista sênior em COBOL com 20+ anos de experiência',
                'analysis_depth': 'máxima',
                'technical_focus': 'alto',
                'business_context': True,
                'regulatory_emphasis': True
            },
            'luzia': {
                'persona': 'analista experiente em sistemas legados',
                'analysis_depth': 'detalhada',
                'technical_focus': 'médio',
                'business_context': True,
                'regulatory_emphasis': False
            },
            'openai_gpt4': {
                'persona': 'consultor em modernização de sistemas',
                'analysis_depth': 'balanceada',
                'technical_focus': 'médio',
                'business_context': True,
                'regulatory_emphasis': False
            },
            'default': {
                'persona': 'analista de sistemas COBOL',
                'analysis_depth': 'padrão',
                'technical_focus': 'médio',
                'business_context': True,
                'regulatory_emphasis': False
            }
        }
        
        self.current_model_config = self.model_configs.get(model_name, self.model_configs['default'])
        
        self.logger.info(f"Gerenciador de Prompts Aprimorado inicializado para o modelo: {model_name}")
    
    def _load_config(self) -> Dict[str, Any]:
        """Carrega configuração de prompts."""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    return yaml.safe_load(f)
            else:
                return self._get_default_config()
        except Exception as e:
            self.logger.warning(f"Erro ao carregar configuração: {e}. Usando configuração padrão.")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão de prompts."""
        return {
            'analysis_questions': {
                'functional': {
                    'question': 'Qual é o objetivo funcional e o propósito de negócio deste programa?',
                    'required': True
                },
                'technical': {
                    'question': 'Como está estruturado tecnicamente este programa?',
                    'required': True
                },
                'business_rules': {
                    'question': 'Quais regras de negócio estão implementadas?',
                    'required': True
                }
            }
        }
    
    def generate_base_prompt(self, program_name: str, program_code: str, context: Dict[str, Any] = None) -> str:
        """
        Gera prompt base adaptado ao modelo selecionado.
        
        Args:
            program_name: Nome do programa COBOL
            program_code: Código fonte do programa
            context: Contexto adicional (books, pré-análise, etc.)
            
        Returns:
            Prompt otimizado para o modelo
        """
        if context is None:
            context = {}
        
        prompt_parts = []
        
        # Cabeçalho adaptado ao modelo
        prompt_parts.append(self._generate_model_specific_header())
        
        # Informações do programa
        prompt_parts.append(f"\n--- Programa COBOL para Análise ---")
        prompt_parts.append(f"Nome do Programa: {program_name}")
        prompt_parts.append(f"Tamanho do Código: {len(program_code)} caracteres")
        
        # Adicionar informações contextuais
        self._append_contextual_information(prompt_parts, context)
        
        # Código do programa
        prompt_parts.append(f"\n--- Código Fonte ---")
        prompt_parts.append(f"```cobol")
        prompt_parts.append(program_code)
        prompt_parts.append(f"```")
        
        # Perguntas de análise adaptadas
        self._append_analysis_questions(prompt_parts)
        
        # Diretrizes específicas do modelo
        prompt_parts.append(self._generate_model_specific_guidelines())
        
        return '\n'.join(prompt_parts)
    
    def _generate_model_specific_header(self) -> str:
        """Gera cabeçalho específico para o modelo."""
        config = self.current_model_config
        
        header = f"""Você é um {config['persona']} especializado na análise de programas COBOL.

Sua tarefa é realizar uma análise {config['analysis_depth']} do programa COBOL fornecido, com foco {config['technical_focus']} em aspectos técnicos."""
        
        if config['business_context']:
            header += " Inclua sempre o contexto de negócio e o impacto funcional."
        
        if config['regulatory_emphasis']:
            header += " Dê atenção especial a aspectos regulatórios e de compliance."
        
        return header
    
    def _append_contextual_information(self, prompt_parts: List[str], context: Dict[str, Any]) -> None:
        """Adiciona informações de contexto, como books e pré-análise, ao prompt."""
        books = context.get('books', [])
        if books:
            prompt_parts.append("\n--- Copybooks (Books) Relacionados ---")
            for book in books:
                # Verificar se book é um objeto com atributo name ou um dicionário
                if hasattr(book, 'name'):
                    book_name = book.name
                elif isinstance(book, dict):
                    book_name = book.get('name', str(book))
                else:
                    book_name = str(book)
                prompt_parts.append(f"- {book_name}")
            prompt_parts.append("Considere as estruturas de dados definidas nestes copybooks ao analisar o programa.")

        pre_analysis = context.get('pre_analysis', {})
        if pre_analysis:
            prompt_parts.append("\n--- Insights da Pré-Análise Automática ---")
            self._append_pre_analysis_details(prompt_parts, pre_analysis)

    def _append_pre_analysis_details(self, prompt_parts: List[str], pre_analysis: Dict[str, Any]) -> None:
        """Formata e adiciona os detalhes da pré-análise ao prompt."""
        if 'enhanced_comments' in pre_analysis and pre_analysis['enhanced_comments']:
            prompt_parts.append("\nComentários Categorizados:")
            for comment in pre_analysis['enhanced_comments'][:5]:  # Limita para 5
                category = comment.get('category', 'técnico')
                impact = comment.get('business_impact', 'baixo')
                prompt_parts.append(f"- [{category.upper()}] {comment.get('text', '').strip()[:100]}... (Impacto: {impact})")

        if 'logic_flows' in pre_analysis and pre_analysis['logic_flows']:
            prompt_parts.append("\nFluxos Lógicos Identificados:")
            for flow in pre_analysis['logic_flows'][:3]:  # Limita para 3
                flow_type = flow.get('type', 'desconhecido')
                purpose = flow.get('business_purpose', 'não identificado')
                complexity = flow.get('complexity_score', 0)
                prompt_parts.append(f"- {flow_type.title()}: {purpose} (Complexidade: {complexity}/10)")

        if 'business_entities' in pre_analysis and pre_analysis['business_entities']:
            entities = [entity.get('name', '') for entity in pre_analysis['business_entities'][:5]]
            prompt_parts.append(f"\nEntidades de Negócio: {', '.join(entities)}")

        if 'regulatory_compliance' in pre_analysis:
            compliance = pre_analysis['regulatory_compliance']
            level = compliance.get('compliance_level', 'desconhecido')
            refs = compliance.get('regulatory_references', [])
            if refs:
                prompt_parts.append(f"\nConformidade Regulatória: {level.title()} ({len(refs)} referências encontradas)")

    def _append_analysis_questions(self, prompt_parts: List[str]) -> None:
        """Adiciona as perguntas de análise ao prompt."""
        questions = self.config.get('analysis_questions', {})
        if questions:
            prompt_parts.append("\n--- Questões para Análise ---")
            for i, (key, q_data) in enumerate(questions.items(), 1):
                prompt_parts.append(f"\n{i}. {q_data['question']}")
                if 'description' in q_data:
                    prompt_parts.append(f"   (Foco: {q_data['description']})")

    def _generate_model_specific_guidelines(self) -> str:
        """Gera diretrizes específicas para o modelo."""
        config = self.current_model_config
        
        guidelines = f"\n--- Diretrizes de Análise ---"
        
        if config['analysis_depth'] == 'máxima':
            guidelines += "\n- Forneça análise extremamente detalhada com pelo menos 6 seções distintas"
            guidelines += "\n- Cada seção deve ter no mínimo 3-4 parágrafos substantivos"
            guidelines += "\n- Inclua análise técnica, funcional, arquitetural e de negócio"
        elif config['analysis_depth'] == 'detalhada':
            guidelines += "\n- Forneça análise detalhada com pelo menos 4 seções principais"
            guidelines += "\n- Foque em aspectos funcionais e técnicos relevantes"
        else:
            guidelines += "\n- Forneça análise balanceada cobrindo os aspectos principais"
        
        if config['business_context']:
            guidelines += "\n- Sempre contextualize tecnicamente dentro do domínio de negócio"
            guidelines += "\n- Explique o impacto e valor de cada funcionalidade identificada"
        
        if config['regulatory_emphasis']:
            guidelines += "\n- Identifique e explique qualquer aspecto regulatório ou de compliance"
            guidelines += "\n- Mencione implicações de auditoria e controles internos"
        
        guidelines += f"\n- Use linguagem técnica precisa apropriada para {config['persona']}"
        guidelines += "\n- Estruture a resposta de forma clara e profissional"
        
        return guidelines
    
    def get_system_prompt(self) -> str:
        """Retorna o prompt de sistema usado."""
        return f"Sistema de análise COBOL configurado para modelo {self.model_name} com persona: {self.current_model_config['persona']}"
    
    def get_prompt_strategy(self) -> str:
        """Retorna a estratégia de prompt utilizada."""
        config = self.current_model_config
        return f"Estratégia: {config['analysis_depth']} depth, {config['technical_focus']} technical focus, business_context: {config['business_context']}"
    
    def get_analysis_questions_list(self) -> List[str]:
        """Retorna lista das perguntas de análise."""
        questions = self.config.get('analysis_questions', {})
        return [q_data['question'] for q_data in questions.values()]
    
    def get_model_configuration(self) -> Dict[str, Any]:
        """Retorna a configuração do modelo atual."""
        return self.current_model_config.copy()
    
    def get_prompt_metadata(self) -> Dict[str, Any]:
        """Retorna metadados sobre o prompt gerado."""
        return {
            'model_name': self.model_name,
            'model_config': self.current_model_config,
            'questions_count': len(self.config.get('analysis_questions', {})),
            'config_source': self.config_path,
            'timestamp': str(datetime.now())
        }
    
    def get_transparency_info(self) -> Dict[str, Any]:
        """Retorna informações completas para transparência."""
        return {
            'prompt_manager_version': '3.0.0',
            'model_selected': self.model_name,
            'model_configuration': self.current_model_config,
            'analysis_questions': self.get_analysis_questions_list(),
            'prompt_strategy': self.get_prompt_strategy(),
            'system_prompt': self.get_system_prompt(),
            'config_file': self.config_path,
            'transparency_level': 'complete'
        }
