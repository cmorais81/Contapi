# Guia de Instalação - COBOL AI Engine v1.0.2

## Instalação Rápida

### 1. Extrair o Pacote
```bash
tar -xzf cobol_ai_engine_v1.0.2.tar.gz
cd cobol_ai_engine_v2.0.0/
```

### 2. Instalar Dependências
```bash
pip install -r requirements.txt
```

### 3. Configurar API
```bash
# Para LuzIA
export LUZIA_API_KEY="sua_chave_luzia_aqui"

# Para OpenAI (opcional)
export OPENAI_API_KEY="sua_chave_openai_aqui"
```

### 4. Teste Básico
```bash
python main.py examples/fontes.txt --models "mock_enhanced"
```

## Uso

### Modelo Único
```bash
python main.py examples/fontes.txt --models "claude_3_5_sonnet"
```

### Múltiplos Modelos
```bash
python main.py examples/fontes.txt --models '["claude_3_5_sonnet","luzia_standard"]'
```

### Com Copybooks
```bash
python main.py examples/fontes.txt --books examples/BOOKS.txt --models "claude_3_5_sonnet" --pdf
```

## Configuração

Edite `config/config.yaml` para personalizar:
- Modelos padrão
- Configurações de API
- Parâmetros de análise

## Estrutura de Saída

### Modelo Único
```
output/
├── PROGRAMA1.md
├── PROGRAMA2.md
└── ...
```

### Múltiplos Modelos
```
output/
├── model_claude_3_5_sonnet/
├── model_luzia_standard/
└── relatorio_comparativo_modelos.md
```

## Solução de Problemas

### Erro de Autenticação
Verifique se as variáveis de ambiente estão configuradas:
```bash
echo $LUZIA_API_KEY
```

### Modelo Não Encontrado
Verifique se o modelo está em `config/config.yaml`

### Arquivo Não Encontrado
Verifique o caminho do arquivo de fontes

---

**Versão**: 1.0.2  
**Compatibilidade**: Python 3.11+
