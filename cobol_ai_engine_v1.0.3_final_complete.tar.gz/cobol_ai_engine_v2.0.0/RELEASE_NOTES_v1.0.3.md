# Release Notes - COBOL AI Engine v1.0.3

## Principais Mudanças

### Interface de Linha de Comando Aprimorada

**Parâmetro --fontes Obrigatório**: O arquivo de fontes agora deve ser especificado com `--fontes` em vez de ser um argumento posicional, tornando a interface mais clara e consistente.

**Modelos Automáticos da Configuração**: O sistema agora usa automaticamente os modelos definidos em `config/config.yaml` na seção `ai.default_models`, eliminando a necessidade de especificar modelos manualmente na maioria dos casos.

**Parâmetro --models Opcional**: O parâmetro `--models` agora é opcional e serve apenas para sobrescrever os modelos configurados quando necessário.

### Limpeza e Organização

**Pasta old/ Criada**: Arquivos de versões anteriores e documentação versionada foram movidos para a pasta `old/` para manter o projeto limpo.

**Documentação Atualizada**: Todos os materiais de referência foram atualizados sem uso de ícones ou referências externas.

**Arquivos Desnecessários Removidos**: Limpeza completa de arquivos temporários, cache e duplicados.

## Comandos Atualizados

### Antes (v1.0.2)
```bash
python main.py fontes.txt --models "claude_3_5_sonnet"
```

### Agora (v1.0.3)
```bash
# Usa modelos da configuração automaticamente
python main.py --fontes fontes.txt

# Ou sobrescreve se necessário
python main.py --fontes fontes.txt --models "claude_3_5_sonnet"
```

## Configuração Automática

### Arquivo config/config.yaml
```yaml
ai:
  default_models:
    - "claude_3_5_sonnet"
    - "luzia_standard"
```

O sistema agora lê automaticamente esta configuração e usa os modelos especificados, simplificando o uso diário.

## Exemplos de Uso

### Uso Padrão (Recomendado)
```bash
# Análise básica com modelos configurados
python main.py --fontes examples/fontes.txt

# Análise completa com copybooks e HTML
python main.py --fontes examples/fontes.txt --books examples/BOOKS.txt --pdf
```

### Uso Avançado
```bash
# Sobrescrever modelos da configuração
python main.py --fontes examples/fontes.txt --models "mock_enhanced"

# Múltiplos modelos específicos
python main.py --fontes examples/fontes.txt --models '["claude_3_5_sonnet","luzia_standard"]'
```

## Benefícios das Mudanças

**Simplicidade**: Não é mais necessário especificar modelos na linha de comando para uso normal.

**Consistência**: Interface de linha de comando mais padronizada com parâmetros nomeados.

**Flexibilidade**: Configuração centralizada com possibilidade de sobrescrita quando necessário.

**Organização**: Projeto mais limpo com arquivos antigos organizados na pasta `old/`.

**Manutenibilidade**: Documentação atualizada e sem dependências externas de formatação.

## Migração da v1.0.2

### Mudanças Necessárias
1. **Comando**: Adicionar `--fontes` antes do nome do arquivo
2. **Configuração**: Definir modelos padrão em `config/config.yaml`
3. **Documentação**: Consultar novos arquivos README.md e INSTALACAO.md

### Script de Migração
```bash
# Antes
python main.py fontes.txt --models "claude_3_5_sonnet"

# Depois
python main.py --fontes fontes.txt
# (modelo já configurado em config.yaml)
```

## Arquivos na Pasta old/

- `DOCUMENTACAO_TECNICA_v1.0.2.md`: Documentação técnica da versão anterior
- `INSTALACAO_v1.0.2.md`: Guia de instalação da versão anterior
- `README_HTML_UPDATE.md`: Documentação sobre funcionalidade HTML
- `README_v1.0.2.md`: README da versão anterior

Estes arquivos foram preservados para referência e podem conter informações úteis para casos específicos.

## Compatibilidade

### Mantida
- Todas as funcionalidades principais
- Suporte a múltiplos modelos
- Geração HTML para PDF
- Transparência de prompts
- Configuração via YAML

### Alterada
- Sintaxe da linha de comando (--fontes obrigatório)
- Seleção automática de modelos da configuração
- Organização de arquivos (pasta old/)

## Testes Realizados

### Funcionalidade Básica
- Análise com modelos da configuração: ✅
- Análise com sobrescrita de modelos: ✅
- Geração HTML para PDF: ✅
- Múltiplos modelos: ✅

### Interface
- Parâmetro --fontes obrigatório: ✅
- Parâmetro --models opcional: ✅
- Mensagens de erro claras: ✅
- Help atualizado: ✅

### Organização
- Pasta old/ criada: ✅
- Arquivos limpos: ✅
- Documentação atualizada: ✅
- Pacote final otimizado: ✅

## Próximos Passos

1. **Atualizar scripts existentes** para usar `--fontes`
2. **Configurar modelos padrão** em `config/config.yaml`
3. **Testar com seus arquivos COBOL**
4. **Explorar pasta old/** se precisar de referências antigas

---

**COBOL AI Engine v1.0.3 - Interface Simplificada e Configuração Automática**  
**Data de Release**: 21 de Setembro de 2025
