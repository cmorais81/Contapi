#!/usr/bin/env python3
"""
Script para implementar suporte aprimorado a múltiplos modelos LLM no COBOL to Docs v1.0
Adiciona funcionalidades avançadas de seleção e gerenciamento de modelos
"""

import os
import sys
import json
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional

def setup_logging():
    """Configura logging para o script"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    return logging.getLogger(__name__)

def update_main_py_for_model_support():
    """Atualiza o main.py para melhor suporte a múltiplos modelos"""
    logger = logging.getLogger(__name__)
    
    main_py_path = "/home/ubuntu/cobol_to_docs_v1.0_final/main.py"
    
    # Ler o arquivo atual
    with open(main_py_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Adicionar argumento --model (singular) se não existir
    if '--model' not in content and 'add_argument(\'--model\'' not in content:
        # Encontrar a linha onde adicionar o argumento --model
        lines = content.split('\n')
        new_lines = []
        
        for i, line in enumerate(lines):
            new_lines.append(line)
            
            # Adicionar --model após --models
            if "parser.add_argument('--models'" in line:
                new_lines.append("    parser.add_argument('--model', type=str, help='Modelo específico de IA (alternativa ao --models)')")
        
        content = '\n'.join(new_lines)
        logger.info("Adicionado argumento --model ao main.py")
    
    # Atualizar a função de processamento de modelos
    model_processing_code = '''
def get_models_from_args(args, config_manager) -> List[str]:
    """Obtém lista de modelos a partir dos argumentos da linha de comando"""
    logger = logging.getLogger(__name__)
    
    # Prioridade: --model > --models > configuração padrão
    if hasattr(args, 'model') and args.model:
        logger.info(f"Usando modelo específico: {args.model}")
        return [args.model]
    
    if hasattr(args, 'models') and args.models:
        models = parse_models_argument(args.models)
        logger.info(f"Usando modelos especificados: {models}")
        return models
    
    # Usar modelo padrão da configuração
    default_provider = config_manager.config.get('ai', {}).get('primary_provider', 'luzia')
    
    if default_provider == 'luzia':
        # Pegar o primeiro modelo configurado do LuzIA
        luzia_models = config_manager.config.get('providers', {}).get('luzia', {}).get('models', {})
        if luzia_models:
            first_model = list(luzia_models.values())[0].get('name', 'aws-claude-3-5-sonnet')
            logger.info(f"Usando modelo padrão do LuzIA: {first_model}")
            return [first_model]
    
    # Fallback
    logger.info("Usando modelo fallback: enhanced_mock")
    return ['enhanced_mock']
'''
    
    # Inserir a nova função se não existir
    if 'def get_models_from_args(' not in content:
        # Encontrar onde inserir (após parse_models_argument)
        insertion_point = content.find('def analyze_program_with_model(')
        if insertion_point > 0:
            content = content[:insertion_point] + model_processing_code + '\n\n' + content[insertion_point:]
            logger.info("Adicionada função get_models_from_args ao main.py")
    
    # Salvar o arquivo atualizado
    with open(main_py_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    logger.info("main.py atualizado com suporte aprimorado a múltiplos modelos")

def create_model_selector_utility():
    """Cria utilitário para seleção interativa de modelos"""
    logger = logging.getLogger(__name__)
    
    selector_path = "/home/ubuntu/cobol_to_docs_v1.0_final/select_model.py"
    
    selector_code = '''#!/usr/bin/env python3
"""
Utilitário para seleção interativa de modelos LLM
"""

import sys
import os
import yaml
from typing import Dict, List

def load_config():
    """Carrega configuração do sistema"""
    config_path = "config/config.yaml"
    
    if not os.path.exists(config_path):
        print("Erro: Arquivo de configuração não encontrado")
        sys.exit(1)
    
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def display_available_models(config: Dict) -> Dict[str, Dict]:
    """Exibe modelos disponíveis e retorna mapeamento"""
    print("\\n=== MODELOS LLM DISPONÍVEIS ===\\n")
    
    models_info = {}
    counter = 1
    
    # Modelos LuzIA
    luzia_models = config.get('providers', {}).get('luzia', {}).get('models', {})
    if luzia_models:
        print("🚀 MODELOS LUZIA (Recomendados):")
        for model_key, model_config in luzia_models.items():
            model_name = model_config.get('name', model_key)
            description = model_config.get('description', 'Sem descrição')
            max_tokens = model_config.get('max_tokens', 'N/A')
            context_window = model_config.get('context_window', 'N/A')
            
            print(f"   {counter}. {model_name}")
            print(f"      Descrição: {description}")
            print(f"      Max Tokens: {max_tokens:,} | Context: {context_window:,}")
            print()
            
            models_info[str(counter)] = {
                'name': model_name,
                'provider': 'luzia',
                'config': model_config
            }
            counter += 1
    
    # Outros provedores
    other_providers = ['enhanced_mock', 'openai', 'bedrock', 'databricks']
    for provider in other_providers:
        provider_config = config.get('providers', {}).get(provider, {})
        if provider_config.get('enabled', False):
            models = provider_config.get('models', {})
            if models:
                print(f"🔧 MODELOS {provider.upper()}:")
                for model_key, model_config in models.items():
                    model_name = model_config.get('name', model_key)
                    max_tokens = model_config.get('max_tokens', 'N/A')
                    
                    print(f"   {counter}. {model_name} ({provider})")
                    print(f"      Max Tokens: {max_tokens}")
                    print()
                    
                    models_info[str(counter)] = {
                        'name': model_name,
                        'provider': provider,
                        'config': model_config
                    }
                    counter += 1
    
    return models_info

def select_model_interactive(models_info: Dict) -> str:
    """Seleção interativa de modelo"""
    while True:
        try:
            choice = input("\\nEscolha um modelo (número) ou 'q' para sair: ").strip()
            
            if choice.lower() == 'q':
                print("Saindo...")
                sys.exit(0)
            
            if choice in models_info:
                selected = models_info[choice]
                model_name = selected['name']
                provider = selected['provider']
                
                print(f"\\n✅ MODELO SELECIONADO:")
                print(f"   Nome: {model_name}")
                print(f"   Provider: {provider}")
                
                return model_name
            else:
                print("❌ Opção inválida. Tente novamente.")
                
        except KeyboardInterrupt:
            print("\\n\\nSaindo...")
            sys.exit(0)

def generate_command(model_name: str, fontes_file: str = None) -> str:
    """Gera comando para execução"""
    if not fontes_file:
        fontes_file = "examples/fontes.txt"
    
    return f"python3 main.py --fontes {fontes_file} --model {model_name}"

def main():
    """Função principal"""
    print("🤖 SELETOR DE MODELOS LLM - COBOL to Docs v1.0")
    print("=" * 50)
    
    # Carregar configuração
    config = load_config()
    
    # Exibir modelos disponíveis
    models_info = display_available_models(config)
    
    if not models_info:
        print("❌ Nenhum modelo disponível encontrado na configuração")
        sys.exit(1)
    
    # Seleção interativa
    selected_model = select_model_interactive(models_info)
    
    # Gerar comando
    print("\\n🚀 COMANDO PARA EXECUÇÃO:")
    print("-" * 30)
    
    # Verificar se existe arquivo de fontes padrão
    default_fontes = "examples/fontes.txt"
    if os.path.exists(default_fontes):
        cmd = generate_command(selected_model, default_fontes)
        print(f"   {cmd}")
        print()
        
        execute = input("Executar agora? (s/N): ").strip().lower()
        if execute in ['s', 'sim', 'y', 'yes']:
            print("\\n🔄 Executando análise...")
            os.system(cmd)
        else:
            print("\\n📋 Comando copiado. Execute manualmente quando desejar.")
    else:
        cmd = generate_command(selected_model, "<seu_arquivo_fontes.txt>")
        print(f"   {cmd}")
        print("\\n📝 Substitua <seu_arquivo_fontes.txt> pelo seu arquivo de fontes")

if __name__ == "__main__":
    main()
'''
    
    with open(selector_path, 'w', encoding='utf-8') as f:
        f.write(selector_code)
    
    # Tornar executável
    os.chmod(selector_path, 0o755)
    
    logger.info(f"Utilitário de seleção de modelos criado: {selector_path}")

def create_model_benchmark_utility():
    """Cria utilitário para benchmark de modelos"""
    logger = logging.getLogger(__name__)
    
    benchmark_path = "/home/ubuntu/cobol_to_docs_v1.0_final/benchmark_models.py"
    
    benchmark_code = '''#!/usr/bin/env python3
"""
Utilitário para benchmark de múltiplos modelos LLM
Compara performance, qualidade e custos
"""

import os
import sys
import time
import json
import yaml
from datetime import datetime
from typing import Dict, List, Any

def load_config():
    """Carrega configuração do sistema"""
    config_path = "config/config.yaml"
    
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def get_luzia_models(config: Dict) -> List[str]:
    """Obtém lista de modelos LuzIA configurados"""
    luzia_models = config.get('providers', {}).get('luzia', {}).get('models', {})
    return [model_config.get('name') for model_config in luzia_models.values()]

def run_benchmark(models: List[str], test_program: str = "examples/fontes.txt"):
    """Executa benchmark com múltiplos modelos"""
    print("🏁 INICIANDO BENCHMARK DE MODELOS LLM")
    print("=" * 50)
    
    results = {}
    
    for i, model in enumerate(models, 1):
        print(f"\\n🔄 TESTANDO MODELO {i}/{len(models)}: {model}")
        print("-" * 40)
        
        # Criar diretório específico para o teste
        output_dir = f"benchmark_output/test_{model.replace('-', '_').replace('/', '_')}"
        os.makedirs(output_dir, exist_ok=True)
        
        # Comando de teste
        cmd = f"python3 main.py --fontes {test_program} --model {model} --output {output_dir}"
        
        # Medir tempo de execução
        start_time = time.time()
        
        print(f"Executando: {cmd}")
        exit_code = os.system(cmd)
        
        execution_time = time.time() - start_time
        
        # Coletar resultados
        results[model] = {
            'execution_time': execution_time,
            'success': exit_code == 0,
            'output_dir': output_dir,
            'timestamp': datetime.now().isoformat()
        }
        
        if exit_code == 0:
            print(f"✅ Sucesso em {execution_time:.2f}s")
            
            # Tentar coletar estatísticas adicionais
            try:
                # Procurar por arquivos de saída
                output_files = []
                for root, dirs, files in os.walk(output_dir):
                    output_files.extend([os.path.join(root, f) for f in files if f.endswith('.md')])
                
                results[model]['output_files'] = len(output_files)
                
                # Verificar tamanho dos arquivos gerados
                total_size = sum(os.path.getsize(f) for f in output_files)
                results[model]['total_output_size'] = total_size
                
            except Exception as e:
                print(f"⚠️  Erro ao coletar estatísticas: {e}")
        else:
            print(f"❌ Falha (código: {exit_code})")
    
    return results

def generate_benchmark_report(results: Dict[str, Any]):
    """Gera relatório de benchmark"""
    print("\\n" + "=" * 60)
    print("📊 RELATÓRIO DE BENCHMARK")
    print("=" * 60)
    
    successful_models = [model for model, data in results.items() if data['success']]
    failed_models = [model for model, data in results.items() if not data['success']]
    
    print(f"\\n✅ MODELOS BEM-SUCEDIDOS: {len(successful_models)}")
    for model in successful_models:
        data = results[model]
        print(f"   • {model}: {data['execution_time']:.2f}s")
        if 'output_files' in data:
            print(f"     Arquivos gerados: {data['output_files']}")
            print(f"     Tamanho total: {data['total_output_size']:,} bytes")
    
    if failed_models:
        print(f"\\n❌ MODELOS COM FALHA: {len(failed_models)}")
        for model in failed_models:
            print(f"   • {model}")
    
    # Ranking por performance
    if successful_models:
        print("\\n🏆 RANKING POR VELOCIDADE:")
        sorted_models = sorted(
            [(model, results[model]['execution_time']) for model in successful_models],
            key=lambda x: x[1]
        )
        
        for i, (model, time_taken) in enumerate(sorted_models, 1):
            print(f"   {i}. {model}: {time_taken:.2f}s")
    
    # Salvar relatório detalhado
    report_file = f"benchmark_output/benchmark_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    os.makedirs("benchmark_output", exist_ok=True)
    
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    print(f"\\n📄 Relatório detalhado salvo em: {report_file}")

def main():
    """Função principal"""
    print("🚀 BENCHMARK DE MODELOS LLM - COBOL to Docs v1.0")
    
    # Carregar configuração
    config = load_config()
    
    # Obter modelos LuzIA
    luzia_models = get_luzia_models(config)
    
    if not luzia_models:
        print("❌ Nenhum modelo LuzIA encontrado na configuração")
        sys.exit(1)
    
    print(f"\\n📋 MODELOS PARA TESTE: {len(luzia_models)}")
    for i, model in enumerate(luzia_models, 1):
        print(f"   {i}. {model}")
    
    # Verificar arquivo de teste
    test_file = "examples/fontes.txt"
    if not os.path.exists(test_file):
        print(f"\\n❌ Arquivo de teste não encontrado: {test_file}")
        print("Crie o arquivo ou especifique outro arquivo de fontes")
        sys.exit(1)
    
    print(f"\\n📁 Arquivo de teste: {test_file}")
    
    # Confirmar execução
    confirm = input("\\nIniciar benchmark? (s/N): ").strip().lower()
    if confirm not in ['s', 'sim', 'y', 'yes']:
        print("Benchmark cancelado")
        sys.exit(0)
    
    # Executar benchmark
    results = run_benchmark(luzia_models, test_file)
    
    # Gerar relatório
    generate_benchmark_report(results)

if __name__ == "__main__":
    main()
'''
    
    with open(benchmark_path, 'w', encoding='utf-8') as f:
        f.write(benchmark_code)
    
    # Tornar executável
    os.chmod(benchmark_path, 0o755)
    
    logger.info(f"Utilitário de benchmark criado: {benchmark_path}")

def update_luzia_provider_for_model_selection():
    """Atualiza o LuziaProvider para melhor suporte a seleção de modelos"""
    logger = logging.getLogger(__name__)
    
    provider_path = "/home/ubuntu/cobol_to_docs_v1.0_final/src/providers/luzia_provider.py"
    
    # Ler arquivo atual
    with open(provider_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Adicionar método para listar modelos disponíveis se não existir
    if 'def list_available_models(' not in content:
        list_models_method = '''
    def list_available_models(self) -> List[Dict[str, Any]]:
        """
        Lista todos os modelos disponíveis configurados
        
        Returns:
            Lista de dicionários com informações dos modelos
        """
        models_info = []
        models_config = self.luzia_config.get('models', {})
        
        for model_key, model_config in models_config.items():
            models_info.append({
                'key': model_key,
                'name': model_config.get('name', model_key),
                'description': model_config.get('description', 'Sem descrição'),
                'max_tokens': model_config.get('max_tokens', 8192),
                'context_window': model_config.get('context_window', 200000),
                'timeout': model_config.get('timeout', 120),
                'temperature': model_config.get('temperature', 0.1)
            })
        
        return models_info
    
    def get_recommended_model(self, task_type: str = "general") -> str:
        """
        Obtém modelo recomendado baseado no tipo de tarefa
        
        Args:
            task_type: Tipo de tarefa ("general", "complex", "fast", "large_context")
            
        Returns:
            Nome do modelo recomendado
        """
        models_config = self.luzia_config.get('models', {})
        
        if task_type == "complex":
            # Priorizar Claude 3.5 Sonnet para análises complexas
            for model_config in models_config.values():
                if 'sonnet' in model_config.get('name', '').lower():
                    return model_config.get('name')
        
        elif task_type == "fast":
            # Priorizar Haiku para análises rápidas
            for model_config in models_config.values():
                if 'haiku' in model_config.get('name', '').lower():
                    return model_config.get('name')
        
        elif task_type == "large_context":
            # Priorizar Amazon Nova Pro para contexto extenso
            for model_config in models_config.values():
                if 'nova' in model_config.get('name', '').lower():
                    return model_config.get('name')
        
        # Fallback para o primeiro modelo configurado
        if models_config:
            return list(models_config.values())[0].get('name', 'aws-claude-3-5-sonnet')
        
        return 'aws-claude-3-5-sonnet'
'''
        
        # Inserir antes do último método
        insertion_point = content.rfind('    def ')
        if insertion_point > 0:
            # Encontrar o final do último método
            next_class_or_end = content.find('\nclass ', insertion_point)
            if next_class_or_end == -1:
                next_class_or_end = len(content)
            
            content = content[:next_class_or_end] + list_models_method + content[next_class_or_end:]
            logger.info("Adicionados métodos de listagem e recomendação de modelos ao LuziaProvider")
    
    # Salvar arquivo atualizado
    with open(provider_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    logger.info("LuziaProvider atualizado com suporte aprimorado a modelos")

def create_model_info_utility():
    """Cria utilitário para exibir informações detalhadas dos modelos"""
    logger = logging.getLogger(__name__)
    
    info_path = "/home/ubuntu/cobol_to_docs_v1.0_final/model_info.py"
    
    info_code = '''#!/usr/bin/env python3
"""
Utilitário para exibir informações detalhadas dos modelos LLM configurados
"""

import sys
import os
import yaml
from typing import Dict, Any

def load_config():
    """Carrega configuração do sistema"""
    config_path = "config/config.yaml"
    
    if not os.path.exists(config_path):
        print("Erro: Arquivo de configuração não encontrado")
        sys.exit(1)
    
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def display_model_details(config: Dict[str, Any]):
    """Exibe detalhes completos dos modelos"""
    print("🤖 INFORMAÇÕES DETALHADAS DOS MODELOS LLM")
    print("=" * 60)
    
    # Modelos LuzIA
    luzia_config = config.get('providers', {}).get('luzia', {})
    luzia_models = luzia_config.get('models', {})
    
    if luzia_models:
        print("\\n🚀 MODELOS LUZIA:")
        print("-" * 30)
        
        for model_key, model_config in luzia_models.items():
            print(f"\\n📋 {model_key.upper()}")
            print(f"   Nome: {model_config.get('name', 'N/A')}")
            print(f"   Descrição: {model_config.get('description', 'Sem descrição')}")
            print(f"   Max Tokens: {model_config.get('max_tokens', 'N/A'):,}")
            print(f"   Context Window: {model_config.get('context_window', 'N/A'):,}")
            print(f"   Temperature: {model_config.get('temperature', 'N/A')}")
            print(f"   Timeout: {model_config.get('timeout', 'N/A')}s")
            
            # Recomendações de uso
            model_name = model_config.get('name', '').lower()
            if 'sonnet' in model_name:
                print("   💡 Recomendado para: Análises complexas e detalhadas")
            elif 'haiku' in model_name:
                print("   💡 Recomendado para: Análises rápidas e eficientes")
            elif 'nova' in model_name:
                print("   💡 Recomendado para: Contexto extenso e análises robustas")
            elif 'gpt' in model_name:
                print("   💡 Recomendado para: Análises balanceadas e gerais")
    
    # Configurações gerais do LuzIA
    if luzia_config:
        print("\\n🔧 CONFIGURAÇÕES LUZIA:")
        print("-" * 25)
        print(f"   Status: {'Habilitado' if luzia_config.get('enabled', False) else 'Desabilitado'}")
        print(f"   URL Auth: {luzia_config.get('auth_url', 'N/A')[:50]}...")
        print(f"   URL API: {luzia_config.get('api_url', 'N/A')[:50]}...")
        
        retry_config = luzia_config.get('retry', {})
        print(f"   Max Tentativas: {retry_config.get('max_attempts', 'N/A')}")
        
        rate_limit = luzia_config.get('rate_limit', {})
        print(f"   Rate Limit: {rate_limit.get('requests_per_minute', 'N/A')} req/min")
    
    # Outros provedores
    other_providers = ['enhanced_mock', 'openai', 'bedrock', 'databricks']
    for provider_name in other_providers:
        provider_config = config.get('providers', {}).get(provider_name, {})
        if provider_config.get('enabled', False):
            models = provider_config.get('models', {})
            if models:
                print(f"\\n🔧 MODELOS {provider_name.upper()}:")
                print("-" * 30)
                
                for model_key, model_config in models.items():
                    print(f"   • {model_config.get('name', model_key)}")
                    print(f"     Max Tokens: {model_config.get('max_tokens', 'N/A'):,}")
                    print(f"     Context: {model_config.get('context_window', 'N/A'):,}")

def display_usage_recommendations():
    """Exibe recomendações de uso por cenário"""
    print("\\n" + "=" * 60)
    print("💡 RECOMENDAÇÕES DE USO POR CENÁRIO")
    print("=" * 60)
    
    scenarios = [
        {
            'title': '🎯 ANÁLISE CRÍTICA DE SISTEMAS CADOC',
            'model': 'aws-claude-3-5-sonnet',
            'reason': 'Máxima qualidade e profundidade de análise',
            'command': 'python3 main.py --fontes programa.txt --model aws-claude-3-5-sonnet'
        },
        {
            'title': '⚡ PROCESSAMENTO EM LOTE RÁPIDO',
            'model': 'aws-claude-3-5-haiku',
            'reason': 'Velocidade e eficiência para múltiplos programas',
            'command': 'python3 main.py --fontes lote.txt --model aws-claude-3-5-haiku'
        },
        {
            'title': '📚 PROGRAMAS MUITO GRANDES (>100KB)',
            'model': 'amazon-nova-pro-v1',
            'reason': 'Context window de 300K tokens',
            'command': 'python3 main.py --fontes programa_grande.txt --model amazon-nova-pro-v1'
        },
        {
            'title': '🔄 ANÁLISE BALANCEADA GERAL',
            'model': 'azure-gpt-4o-exp',
            'reason': 'Equilíbrio entre qualidade e velocidade',
            'command': 'python3 main.py --fontes programa.txt --model azure-gpt-4o-exp'
        },
        {
            'title': '🧪 TESTE E DESENVOLVIMENTO',
            'model': 'enhanced_mock',
            'reason': 'Sem custos, resposta imediata',
            'command': 'python3 main.py --fontes programa.txt --model enhanced_mock'
        }
    ]
    
    for scenario in scenarios:
        print(f"\\n{scenario['title']}")
        print(f"   Modelo: {scenario['model']}")
        print(f"   Motivo: {scenario['reason']}")
        print(f"   Comando: {scenario['command']}")

def main():
    """Função principal"""
    # Carregar configuração
    config = load_config()
    
    # Exibir informações dos modelos
    display_model_details(config)
    
    # Exibir recomendações de uso
    display_usage_recommendations()
    
    print("\\n" + "=" * 60)
    print("📖 Para mais informações, consulte a documentação do sistema")

if __name__ == "__main__":
    main()
'''
    
    with open(info_path, 'w', encoding='utf-8') as f:
        f.write(info_code)
    
    # Tornar executável
    os.chmod(info_path, 0o755)
    
    logger.info(f"Utilitário de informações de modelos criado: {info_path}")

def main():
    """Função principal do script de implementação"""
    logger = setup_logging()
    
    logger.info("=== IMPLEMENTANDO SUPORTE APRIMORADO A MÚLTIPLOS MODELOS LLM ===")
    
    try:
        # 1. Atualizar main.py
        logger.info("1. Atualizando main.py para melhor suporte a modelos...")
        update_main_py_for_model_support()
        
        # 2. Atualizar LuziaProvider
        logger.info("2. Atualizando LuziaProvider...")
        update_luzia_provider_for_model_selection()
        
        # 3. Criar utilitários
        logger.info("3. Criando utilitário de seleção de modelos...")
        create_model_selector_utility()
        
        logger.info("4. Criando utilitário de benchmark...")
        create_model_benchmark_utility()
        
        logger.info("5. Criando utilitário de informações...")
        create_model_info_utility()
        
        logger.info("=== IMPLEMENTAÇÃO CONCLUÍDA COM SUCESSO ===")
        
        print("\n🎉 SUPORTE APRIMORADO A MÚLTIPLOS MODELOS IMPLEMENTADO!")
        print("=" * 60)
        print("\n📋 NOVOS RECURSOS DISPONÍVEIS:")
        print("   • Argumento --model para seleção específica")
        print("   • Utilitário interativo de seleção (./select_model.py)")
        print("   • Benchmark automático de modelos (./benchmark_models.py)")
        print("   • Informações detalhadas dos modelos (./model_info.py)")
        print("\n🚀 EXEMPLOS DE USO:")
        print("   python3 main.py --fontes programa.txt --model aws-claude-3-5-sonnet")
        print("   python3 select_model.py")
        print("   python3 benchmark_models.py")
        print("   python3 model_info.py")
        
    except Exception as e:
        logger.error(f"Erro durante implementação: {e}")
        raise

if __name__ == "__main__":
    main()
