#!/usr/bin/env python3
"""
Lineage Service - Sistema de Governança de Dados
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

app = FastAPI(
    title="Lineage Service - Governança de Dados",
    description="Lineage Service do Sistema de Governança de Dados",
    version="1.1.0"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Endpoint raiz"""
    return {
        "message": "Lineage Service - Sistema de Governança de Dados",
        "status": "running"
    }

@app.get("/health")
async def health_check():
    """Health check do serviço"""
    return {"status": "healthy", "service": "lineage-service"}

@app.get("/api/v1/status")
async def get_status():
    """Status do serviço"""
    return {
        "service": "lineage-service",
        "status": "operational",
        "version": "1.1.0"
    }

if __name__ == "__main__":
    print("Iniciando Lineage Service na porta 8007...")
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8007,
        log_level="info"
    )
