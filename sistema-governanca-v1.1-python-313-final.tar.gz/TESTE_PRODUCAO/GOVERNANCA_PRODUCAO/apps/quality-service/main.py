#!/usr/bin/env python3
"""
Quality Service - Sistema de Governança de Dados
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

app = FastAPI(
    title="Quality Service - Governança de Dados",
    description="Quality Service do Sistema de Governança de Dados",
    version="1.1.0"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Endpoint raiz"""
    return {
        "message": "Quality Service - Sistema de Governança de Dados",
        "status": "running"
    }

@app.get("/health")
async def health_check():
    """Health check do serviço"""
    return {"status": "healthy", "service": "quality-service"}

@app.get("/api/v1/status")
async def get_status():
    """Status do serviço"""
    return {
        "service": "quality-service",
        "status": "operational",
        "version": "1.1.0"
    }

if __name__ == "__main__":
    print("Iniciando Quality Service na porta 8005...")
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8005,
        log_level="info"
    )
