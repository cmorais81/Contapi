"""
Modelos de dados para contratos
"""

from sqlalchemy import Column, String, Text, DateTime, Boolean, Integer, JSON
from sqlalchemy.dialects.postgresql import UUID
from config.database import Base
import uuid
from datetime import datetime

class DataContract(Base):
    """Modelo para contratos de dados"""
    __tablename__ = "data_contracts"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    version = Column(String(50), nullable=False, default="1.0.0")
    status = Column(String(50), nullable=False, default="draft")
    schema_definition = Column(JSON)
    data_source_id = Column(UUID(as_uuid=True))
    owner_id = Column(UUID(as_uuid=True))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """Converter para dicionário"""
        return {
            "id": str(self.id),
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "status": self.status,
            "schema_definition": self.schema_definition,
            "data_source_id": str(self.data_source_id) if self.data_source_id else None,
            "owner_id": str(self.owner_id) if self.owner_id else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }

class ContractVersion(Base):
    """Modelo para versões de contratos"""
    __tablename__ = "contract_versions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(UUID(as_uuid=True), nullable=False)
    version_number = Column(String(50), nullable=False)
    schema_definition = Column(JSON)
    change_description = Column(Text)
    is_active = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """Converter para dicionário"""
        return {
            "id": str(self.id),
            "contract_id": str(self.contract_id),
            "version_number": self.version_number,
            "schema_definition": self.schema_definition,
            "change_description": self.change_description,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None
        }
