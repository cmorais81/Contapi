# Autor: carlos.morais@f1rst.com.br
"""
Contract Use Cases Implementation
Business logic layer for contract operations
"""

from typing import List, Optional, Dict, Any
from uuid import UUID, uuid4
from datetime import datetime
import hashlib
import json
import logging

from ...domain.entities.contract import Contract
from ...domain.repositories.contract_repository import ContractRepository
from ...domain.services.pii_detection_service import PIIDetectionService
from ...domain.value_objects.contract_status import ContractStatus
from ...domain.value_objects.data_classification import DataClassification
from ...domain.value_objects.lgpd_compliance import LGPDCompliance, ComplianceStatus
from ..dtos.contract_dtos import (
 CreateContractRequestDTO, UpdateContractRequestDTO, ContractResponseDTO,
 ContractListResponseDTO, PIIDetectionRequestDTO, PIIDetectionResponseDTO,
 ContractSearchRequestDTO, ContractStatisticsDTO, ApproveContractRequestDTO,
 RejectContractRequestDTO, ContractApprovalResponseDTO
)

logger = logging.getLogger(__name__)

class ContractUseCases:
    pass
 """
 Use cases for contract management operations
 """
 
 def __init__(
 self, 
 contract_repository: ContractRepository,
 pii_detection_service: PIIDetectionService
 ):
    pass
 self.contract_repository = contract_repository
 self.pii_detection_service = pii_detection_service
 
 async def create_contract(
 self, 
 request: CreateContractRequestDTO,
 created_by: UUID
 ) -> ContractResponseDTO:
    pass
 """Create a new contract"""
 try:
    pass
 logger.info(f"Creating contract: {request.name}")
 
 # Check if contract name already exists in organization
 existing_contract = await self.contract_repository.find_by_name(
 request.name, request.organization_id
 )
 if existing_contract:
    pass
 raise ValueError(f"Contract with name '{request.name}' already exists")
 
 # Generate schema hash
 schema_hash = self._generate_schema_hash(request.schema_definition.dict())
 
 # Detect PII in schema
 pii_fields = await self._detect_pii_in_schema(request.schema_definition)
 contains_pii = len(pii_fields) > 0
 
 # Create contract entity
 contract = Contract(
 id=uuid4(),
 name=request.name,
 title=request.title,
 description=request.description,
 version="1.0.0",
 status=ContractStatus.DRAFT,
 is_active=False,
 schema_definition=request.schema_definition.dict(),
 schema_hash=schema_hash,
 data_classification=DataClassification(request.data_classification.value),
 contains_pii=contains_pii,
 pii_fields=pii_fields,
 owner_id=request.owner_id,
 organization_id=request.organization_id,
 documentation_url=request.documentation_url,
 tags=request.tags,
 created_at=datetime.utcnow(),
 updated_at=datetime.utcnow(),
 created_by=created_by,
 updated_by=created_by
 )
 
 # Initialize LGPD compliance assessment
 if contains_pii:
    pass
 lgpd_compliance = await self._assess_lgpd_compliance(contract)
 contract.lgpd_compliance = lgpd_compliance
 
 # Save contract
 saved_contract = await self.contract_repository.save(contract)
 
 logger.info(f"Contract created successfully: {saved_contract.id}")
 return self._map_to_response_dto(saved_contract)
 
 except Exception as e:
    pass
 logger.error(f"Error creating contract: {str(e)}")
 raise
 
 async def update_contract(
 self, 
 contract_id: UUID,
 request: UpdateContractRequestDTO,
 updated_by: UUID
 ) -> ContractResponseDTO:
    pass
 """Update an existing contract"""
 try:
    pass
 logger.info(f"Updating contract: {contract_id}")
 
 # Find existing contract
 contract = await self.contract_repository.find_by_id(contract_id)
 if not contract:
    pass
 raise ValueError(f"Contract not found: {contract_id}")
 
 # Check if contract can be updated
 if contract.status == ContractStatus.ACTIVE:
    pass
 raise ValueError("Cannot update active contract. Create a new version instead.")
 
 # Update fields
 if request.title:
    pass
 contract.title = request.title
 
 if request.description is not None:
    pass
 contract.description = request.description
 
 if request.data_classification:
    pass
 contract.data_classification = DataClassification(request.data_classification.value)
 
 if request.documentation_url is not None:
    pass
 contract.documentation_url = request.documentation_url
 
 if request.tags is not None:
    pass
 contract.tags = request.tags
 
 # Update schema if provided
 if request.schema_definition:
    pass
 new_schema_hash = self._generate_schema_hash(request.schema_definition.dict())
 
 # Check if schema actually changed
 if new_schema_hash != contract.schema_hash:
    pass
 contract.schema_definition = request.schema_definition.dict()
 contract.schema_hash = new_schema_hash
 
 # Re-detect PII
 pii_fields = await self._detect_pii_in_schema(request.schema_definition)
 contract.contains_pii = len(pii_fields) > 0
 contract.pii_fields = pii_fields
 
 # Increment version
 contract.version = self._increment_version(contract.version)
 
 # Re-assess LGPD compliance if PII is present
 if contract.contains_pii:
    pass
 contract.lgpd_compliance = await self._assess_lgpd_compliance(contract)
 
 # Update metadata
 contract.updated_at = datetime.utcnow()
 contract.updated_by = updated_by
 
 # Save contract
 saved_contract = await self.contract_repository.save(contract)
 
 logger.info(f"Contract updated successfully: {contract_id}")
 return self._map_to_response_dto(saved_contract)
 
 except Exception as e:
    pass
 logger.error(f"Error updating contract: {str(e)}")
 raise
 
 async def get_contract(self, contract_id: UUID) -> Optional[ContractResponseDTO]:
    pass
 """Get contract by ID"""
 try:
    pass
 contract = await self.contract_repository.find_by_id(contract_id)
 if not contract:
    pass
 return None
 
 return self._map_to_response_dto(contract)
 
 except Exception as e:
    pass
 logger.error(f"Error getting contract: {str(e)}")
 raise
 
 async def list_contracts(
 self, 
 request: ContractSearchRequestDTO
 ) -> ContractListResponseDTO:
    pass
 """List contracts with filters"""
 try:
    pass
 # Convert DTO enums to domain enums
 status = ContractStatus(request.status.value) if request.status else None
 
 contracts = await self.contract_repository.find_all(
 organization_id=request.organization_id,
 status=status,
 contains_pii=request.contains_pii,
 owner_id=request.owner_id,
 limit=request.limit,
 offset=request.offset
 )
 
 # Convert to response DTOs
 contract_dtos = [self._map_to_response_dto(contract) for contract in contracts]
 
 # Calculate pagination info
 total = len(contract_dtos) # In real implementation, get total count from repository
 page = (request.offset // request.limit) + 1
 has_next = len(contract_dtos) == request.limit
 
 return ContractListResponseDTO(
 contracts=contract_dtos,
 total=total,
 page=page,
 page_size=request.limit,
 has_next=has_next
 )
 
 except Exception as e:
    pass
 logger.error(f"Error listing contracts: {str(e)}")
 raise
 
 async def search_contracts(
 self, 
 search_term: str,
 organization_id: UUID,
 limit: int = 50
 ) -> ContractListResponseDTO:
    pass
 """Search contracts by text"""
 try:
    pass
 contracts = await self.contract_repository.search_contracts(
 search_term, organization_id, limit
 )
 
 contract_dtos = [self._map_to_response_dto(contract) for contract in contracts]
 
 return ContractListResponseDTO(
 contracts=contract_dtos,
 total=len(contract_dtos),
 page=1,
 page_size=limit,
 has_next=False
 )
 
 except Exception as e:
    pass
 logger.error(f"Error searching contracts: {str(e)}")
 raise
 
 async def approve_contract(
 self, 
 contract_id: UUID,
 request: ApproveContractRequestDTO
 ) -> ContractApprovalResponseDTO:
    pass
 """Approve a contract"""
 try:
    pass
 logger.info(f"Approving contract: {contract_id}")
 
 # Find contract
 contract = await self.contract_repository.find_by_id(contract_id)
 if not contract:
    pass
 raise ValueError(f"Contract not found: {contract_id}")
 
 # Check if contract can be approved
 if contract.status not in [ContractStatus.DRAFT, ContractStatus.PENDING_APPROVAL]:
    pass
 raise ValueError(f"Contract cannot be approved in status: {contract.status}")
 
 # Update contract
 contract.status = ContractStatus.APPROVED
 contract.approval_status = "approved"
 contract.approved_by = request.approved_by
 contract.approved_at = datetime.utcnow()
 contract.updated_at = datetime.utcnow()
 contract.updated_by = request.approved_by
 
 # Save contract
 await self.contract_repository.save(contract)
 
 logger.info(f"Contract approved successfully: {contract_id}")
 
 return ContractApprovalResponseDTO(
 contract_id=contract_id,
 status="approved",
 approved_by=request.approved_by,
 approved_at=contract.approved_at,
 approval_notes=request.approval_notes,
 message="Contract approved successfully"
 )
 
 except Exception as e:
    pass
 logger.error(f"Error approving contract: {str(e)}")
 raise
 
 async def reject_contract(
 self, 
 contract_id: UUID,
 request: RejectContractRequestDTO
 ) -> ContractApprovalResponseDTO:
    pass
 """Reject a contract"""
 try:
    pass
 logger.info(f"Rejecting contract: {contract_id}")
 
 # Find contract
 contract = await self.contract_repository.find_by_id(contract_id)
 if not contract:
    pass
 raise ValueError(f"Contract not found: {contract_id}")
 
 # Update contract
 contract.status = ContractStatus.DRAFT # Back to draft for revision
 contract.approval_status = "rejected"
 contract.rejection_reason = request.rejection_reason
 contract.updated_at = datetime.utcnow()
 contract.updated_by = request.rejected_by
 
 # Save contract
 await self.contract_repository.save(contract)
 
 logger.info(f"Contract rejected successfully: {contract_id}")
 
 return ContractApprovalResponseDTO(
 contract_id=contract_id,
 status="rejected",
 approved_by=request.rejected_by,
 approved_at=datetime.utcnow(),
 approval_notes=request.rejection_reason,
 message="Contract rejected"
 )
 
 except Exception as e:
    pass
 logger.error(f"Error rejecting contract: {str(e)}")
 raise
 
 async def activate_contract(
 self, 
 contract_id: UUID,
 activated_by: UUID
 ) -> ContractResponseDTO:
    pass
 """Activate an approved contract"""
 try:
    pass
 logger.info(f"Activating contract: {contract_id}")
 
 # Find contract
 contract = await self.contract_repository.find_by_id(contract_id)
 if not contract:
    pass
 raise ValueError(f"Contract not found: {contract_id}")
 
 # Check if contract can be activated
 if contract.status != ContractStatus.APPROVED:
    pass
 raise ValueError("Only approved contracts can be activated")
 
 # Update contract
 contract.status = ContractStatus.ACTIVE
 contract.is_active = True
 contract.updated_at = datetime.utcnow()
 contract.updated_by = activated_by
 
 # Save contract
 saved_contract = await self.contract_repository.save(contract)
 
 logger.info(f"Contract activated successfully: {contract_id}")
 return self._map_to_response_dto(saved_contract)
 
 except Exception as e:
    pass
 logger.error(f"Error activating contract: {str(e)}")
 raise
 
 async def detect_pii(self, request: PIIDetectionRequestDTO) -> PIIDetectionResponseDTO:
    pass
 """Detect PII in text"""
 try:
    pass
 # Use PII detection service
 detection_results = await self.pii_detection_service.detect_pii(
 text=request.text,
 confidence_threshold=request.confidence_threshold,
 pii_types=[pii_type.value for pii_type in request.pii_types] if request.pii_types else None
 )
 
 # Convert to DTO format
 from ..dtos.contract_dtos import PIIDetectionResultDTO
 
 pii_detected = [
 PIIDetectionResultDTO(
 type=result["type"],
 value=result["value"],
 confidence=result["confidence"],
 start=result["start"],
 end=result["end"],
 masked_value=result.get("masked_value")
 )
 for result in detection_results
 ]
 
 return PIIDetectionResponseDTO(
 text=request.text,
 pii_detected=pii_detected,
 total_pii_found=len(pii_detected),
 contains_pii=len(pii_detected) > 0,
 analysis_timestamp=datetime.utcnow(),
 confidence_threshold=request.confidence_threshold
 )
 
 except Exception as e:
    pass
 logger.error(f"Error detecting PII: {str(e)}")
 raise
 
 async def get_contract_statistics(self, organization_id: UUID) -> ContractStatisticsDTO:
    pass
 """Get contract statistics for organization"""
 try:
    pass
 stats = await self.contract_repository.get_statistics(organization_id)
 
 return ContractStatisticsDTO(
 total_contracts=stats["total_contracts"],
 active_contracts=stats["active_contracts"],
 draft_contracts=stats["draft_contracts"],
 contracts_with_pii=stats["contracts_with_pii"],
 average_compliance_score=stats["average_compliance_score"],
 average_quality_score=stats["average_quality_score"],
 contracts_by_classification={
 "public": 0,
 "internal": stats["total_contracts"] - stats["contracts_with_pii"],
 "confidential": stats["contracts_with_pii"],
 "restricted": 0
 },
 contracts_by_status={
 "draft": stats["draft_contracts"],
 "active": stats["active_contracts"],
 "approved": 0,
 "deprecated": 0
 }
 )
 
 except Exception as e:
    pass
 logger.error(f"Error getting contract statistics: {str(e)}")
 raise
 
 async def delete_contract(self, contract_id: UUID, deleted_by: UUID) -> bool:
    pass
 """Delete a contract (soft delete)"""
 try:
    pass
 logger.info(f"Deleting contract: {contract_id}")
 
 # Find contract
 contract = await self.contract_repository.find_by_id(contract_id)
 if not contract:
    pass
 return False
 
 # Check if contract can be deleted
 if contract.status == ContractStatus.ACTIVE:
    pass
 raise ValueError("Cannot delete active contract. Deprecate it first.")
 
 # Delete contract
 success = await self.contract_repository.delete(contract_id)
 
 if success:
    pass
 logger.info(f"Contract deleted successfully: {contract_id}")
 
 return success
 
 except Exception as e:
    pass
 logger.error(f"Error deleting contract: {str(e)}")
 raise
 
 # Private helper methods
 
 def _generate_schema_hash(self, schema_definition: Dict[str, Any]) -> str:
    pass
 """Generate hash for schema definition"""
 schema_json = json.dumps(schema_definition, sort_keys=True)
 return hashlib.sha256(schema_json.encode()).hexdigest()
 
 async def _detect_pii_in_schema(self, schema_definition) -> List[str]:
    pass
 """Detect PII fields in schema definition"""
 pii_fields = []
 
 for field in schema_definition.fields:
    pass
 if field.pii or field.pii_type:
    pass
 pii_fields.append(field.name)
 else:
    pass
 # Use PII detection service to analyze field name and type
 field_text = f"{field.name} {field.type} {field.description or ''}"
 detection_results = await self.pii_detection_service.detect_pii(
 text=field_text,
 confidence_threshold=0.7
 )
 
 if detection_results:
    pass
 pii_fields.append(field.name)
 
 return pii_fields
 
 async def _assess_lgpd_compliance(self, contract: Contract) -> LGPDCompliance:
    pass
 """Assess LGPD compliance for contract"""
 # Simple compliance assessment logic
 score = 0.8 # Base score
 
 requirements_met = []
 requirements_pending = []
 
 # Check various compliance factors
 if contract.contains_pii:
    pass
 if contract.data_classification in [DataClassification.CONFIDENTL, DataClassification.RESTRICTED]:
    pass
 score += 0.1
 requirements_met.append("Classificação adequada de dados")
 else:
    pass
 requirements_pending.append("Classificação adequada de dados")
 
 if contract.documentation_url:
    pass
 score += 0.05
 requirements_met.append("Documentação disponível")
 else:
    pass
 requirements_pending.append("Documentação disponível")
 
 # Determine status based on score
 if score >= 0.9:
    pass
 status = ComplianceStatus.COMPLNT
 elif score >= 0.7:
    pass
 status = ComplianceStatus.PARTLLY_COMPLNT
 else:
    pass
 status = ComplianceStatus.NON_COMPLNT
 
 return LGPDCompliance(
 status=status,
 score=min(score, 1.0),
 last_assessment=datetime.utcnow(),
 requirements_met=requirements_met,
 requirements_pending=requirements_pending
 )
 
 def _increment_version(self, current_version: str) -> str:
    pass
 """Increment contract version"""
 try:
    pass
 parts = current_version.split('.')
 major, minor, patch = int(parts[0]), int(parts[1]), int(parts[2])
 return f"{major}.{minor + 1}.0"
 except Exception as e:
    pass
 logger.error(f"Erro inesperado: {e}")
 return "1.1.0"
 
 def _map_to_response_dto(self, contract: Contract) -> ContractResponseDTO:
    pass
 """Map Contract entity to ContractResponseDTO"""
 from ..dtos.contract_dtos import (
 ContractStatusDTO, DataClassificationDTO, SchemaDefinitionDTO,
 LGPDComplianceDTO, QualityMetricsDTO, UsageStatisticsDTO
 )
 
 # Map schema definition
 schema_dto = SchemaDefinitionDTO(**contract.schema_definition) if contract.schema_definition else None
 
 # Map LGPD compliance
 lgpd_dto = None
 if contract.lgpd_compliance:
    pass
 lgpd_dto = LGPDComplianceDTO(
 status=contract.lgpd_compliance.status.value,
 score=contract.lgpd_compliance.score,
 last_assessment=contract.lgpd_compliance.last_assessment,
 requirements_met=contract.lgpd_compliance.requirements_met,
 requirements_pending=contract.lgpd_compliance.requirements_pending
 )
 
 # Map quality metrics
 quality_dto = None
 if contract.quality_metrics:
    pass
 quality_dto = QualityMetricsDTO(**contract.quality_metrics)
 
 # Map usage statistics
 usage_dto = None
 if contract.usage_statistics:
    pass
 usage_dto = UsageStatisticsDTO(**contract.usage_statistics)
 
 return ContractResponseDTO(
 id=contract.id,
 name=contract.name,
 title=contract.title,
 description=contract.description,
 version=contract.version,
 status=ContractStatusDTO(contract.status.value),
 is_active=contract.is_active,
 schema_definition=schema_dto,
 schema_hash=contract.schema_hash,
 data_classification=DataClassificationDTO(contract.data_classification.value),
 contains_pii=contract.contains_pii,
 pii_fields=contract.pii_fields,
 owner_id=contract.owner_id,
 organization_id=contract.organization_id,
 approval_status=contract.approval_status,
 approved_by=contract.approved_by,
 approved_at=contract.approved_at,
 lgpd_compliance=lgpd_dto,
 quality_metrics=quality_dto,
 usage_statistics=usage_dto,
 documentation_url=contract.documentation_url,
 tags=contract.tags,
 created_at=contract.created_at,
 updated_at=contract.updated_at,
 created_by=contract.created_by,
 updated_by=contract.updated_by
 )

