from config.middleware import get_current_user, require_user
"""
Contract Service - Serviço de Contratos de Dados
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List
import uvicorn
import sys
import os

# Adicionar diretório raiz ao path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from config.database import get_database, test_connection, init_database
from src.domain.models.contract import DataContract
from src.infrastructure.repositories.contract_repository import ContractRepository

app = FastAPI(
    title="Contract Service - Governança de Dados",
    description="Serviço para gerenciamento de contratos de dados",
    version="1.1.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    """Evento de inicialização"""
    print("Iniciando Contract Service...")
    if test_connection():
        init_database()
        print("Contract Service iniciado com sucesso!")
    else:
        print("Erro: Não foi possível conectar ao banco de dados")

@app.get("/")
async def root():
    """Endpoint raiz"""
    return {
        "service": "contract-service",
        "version": "1.1.0",
        "status": "running",
        "database": "connected"
    }

@app.get("/health")
async def health_check():
    """Health check"""
    return {"status": "healthy", "service": "contract-service"}

@app.post("/api/v1/contracts")
async def create_contract(
    contract_data: dict,
    db: Session = Depends(get_database)
):
    """Criar novo contrato"""
    try:
        repository = ContractRepository(db)
        contract = repository.create_contract(contract_data)
        return contract.to_dict()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/v1/contracts")
async def list_contracts(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_database)
):
    """Listar contratos"""
    try:
        repository = ContractRepository(db)
        contracts = repository.get_contracts(skip=skip, limit=limit)
        return [contract.to_dict() for contract in contracts]
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/v1/contracts/{contract_id}")
async def get_contract(
    contract_id: str,
    db: Session = Depends(get_database)
):
    """Obter contrato por ID"""
    try:
        repository = ContractRepository(db)
        contract = repository.get_contract(contract_id)
        if not contract:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        return contract.to_dict()
    except ValueError:
        raise HTTPException(status_code=400, detail="ID inválido")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.put("/api/v1/contracts/{contract_id}")
async def update_contract(
    contract_id: str,
    contract_data: dict,
    db: Session = Depends(get_database)
):
    """Atualizar contrato"""
    try:
        repository = ContractRepository(db)
        contract = repository.update_contract(contract_id, contract_data)
        if not contract:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        return contract.to_dict()
    except ValueError:
        raise HTTPException(status_code=400, detail="ID inválido")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.delete("/api/v1/contracts/{contract_id}")
async def delete_contract(
    contract_id: str,
    db: Session = Depends(get_database)
):
    """Deletar contrato"""
    try:
        repository = ContractRepository(db)
        success = repository.delete_contract(contract_id)
        if not success:
            raise HTTPException(status_code=404, detail="Contrato não encontrado")
        return {"message": "Contrato deletado com sucesso"}
    except ValueError:
        raise HTTPException(status_code=400, detail="ID inválido")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/v1/contracts/status/{status}")
async def get_contracts_by_status(
    status: str,
    db: Session = Depends(get_database)
):
    """Obter contratos por status"""
    try:
        repository = ContractRepository(db)
        contracts = repository.get_contracts_by_status(status)
        return [contract.to_dict() for contract in contracts]
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

if __name__ == "__main__":
    print("Iniciando Contract Service na porta 8003...")
    uvicorn.run(app, host="0.0.0.0", port=8003)
