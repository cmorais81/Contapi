# COBOL to Docs v1.0 - Sistema Completo

Sistema profissional de análise e documentação de programas COBOL com todas as correções do especialista aplicadas.

## 🎯 Correções do Especialista Implementadas

### ✅ Análise Profunda sem Comentários
- Sistema infere funcionalidades através da estrutura do código
- Não depende de comentários para gerar análises detalhadas
- Evidências obrigatórias para cada conclusão

### ✅ Regras de Negócio Específicas
- Identificação automática de regras institucionais
- Mapeamento de limites e validações
- Análise de condicionais para extrair regras concretas

### ✅ Análise Detalhada de Copybooks
- Mapeamento específico de copybooks CADOC
- Análise de impacto e dependências
- Recomendações técnicas para cada copybook

### ✅ Aprendizado Automático
- Extração de conhecimento para base RAG
- Padrões técnicos identificados automaticamente
- Conhecimento específico do domínio bancário/CADOC

## 🚀 Uso

### Análise Básica
```bash
python main.py --fontes programa.cbl --output resultado
```

### Múltiplos Arquivos
```bash
python main.py --fontes "*.cbl" --output analises
```

### Com Copybooks
```bash
python main.py --fontes programa.cbl --books copybooks.txt --output resultado
```

### Diferentes Modelos
```bash
# LuzIA (produção)
python main.py --fontes programa.cbl --models luzia --output resultado

# Enhanced Mock (desenvolvimento)
python main.py --fontes programa.cbl --models enhanced_mock --output resultado

# GitHub Copilot
python main.py --fontes programa.cbl --models github_copilot --output resultado
```

## 📊 Modelos Disponíveis

### LuzIA (Santander)
- **Claude 3.5 Sonnet**: Análises complexas e detalhadas
- **Claude 3 Haiku**: Análises rápidas
- **Amazon Nova Pro**: Análises técnicas especializadas
- **GPT-4 Omni**: Análises abrangentes

### Enhanced Mock
- **enhanced-mock-gpt-4**: Análise profissional offline com correções do especialista

### GitHub Copilot
- **GPT-4**: Análise via GitHub Copilot

## 📁 Estrutura de Saída

```
resultado/
├── programa_analise_funcional.md    # Análise principal
├── ai_requests/
│   └── programa_ai_request.json     # Request para auditoria
└── ai_responses/
    └── programa_ai_response.json    # Response para auditoria
```

## ⚙️ Configuração

### Variáveis de Ambiente
```bash
export LUZIA_API_KEY="sua_chave_luzia"
export GITHUB_TOKEN="seu_token_github"
```

### Arquivo de Configuração
Editar `config/config.yaml` para personalizar:
- Providers de IA
- Parâmetros de análise
- Configurações de saída

## 🎯 Características da Análise

### Funcionalidades Identificadas
- Gestão de arquivos específicos inferida da estrutura
- Procedimentos principais mapeados automaticamente
- Processamento numérico detalhado

### Regras de Negócio
- Regras institucionais concretas (PARM-EMP, instituições específicas)
- Controles de limite específicos (80 bilhões, 90% capacidade)
- Validações de dados técnicas

### Estruturas Técnicas
- Descritores de arquivo com propósito inferido
- Estruturas de registro detalhadas
- Campos com layouts e finalidades específicas

### Integrações
- Copybooks CADOC identificados e analisados
- Módulos externos mapeados (DRAM0082)
- Interfaces de arquivo documentadas

### Conhecimento Extraído
- Padrões técnicos para aprendizado automático
- Regras de negócio específicas do domínio
- Técnicas de implementação interessantes

## 🔧 Funcionalidades Técnicas

- **Sistema RAG**: Base de conhecimento com aprendizado contínuo
- **Múltiplos Providers**: LuzIA, Enhanced Mock, GitHub Copilot
- **Análise Profissional**: Linguagem técnica de nível sênior
- **Auditoria Completa**: Requests/responses para transparência
- **Configuração Flexível**: Adaptável a diferentes ambientes

## 📋 Requisitos

- Python 3.8+
- Dependências listadas em `requirements.txt`
- Acesso a APIs (LuzIA, GitHub) conforme necessário

## 🏢 Ambiente Corporativo

Sistema desenvolvido para ambiente Santander com:
- Integração LuzIA nativa
- Foco em sistemas CADOC
- Conformidade com padrões corporativos
- Análises de nível profissional

---
**COBOL to Docs v1.0** - Sistema Completo com Correções do Especialista
