#!/usr/bin/env python3
"""
Teste específico para análises sênior focadas em funcionalidades e regras
"""

import os
import sys
import subprocess
import logging

def setup_logging():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    return logging.getLogger(__name__)

def test_senior_analysis():
    """Testa análises sênior focadas"""
    logger = setup_logging()
    
    logger.info("=== TESTE ANÁLISE SÊNIOR FOCADA ===")
    
    # Executar análise
    cmd = [
        'python3', 'main.py',
        '--fontes', 'examples/fontes.txt',
        '--books', 'examples/books.txt',
        '--models', 'enhanced_mock',
        '--output', 'teste_senior_focado'
    ]
    
    logger.info(f"Executando: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        
        if result.returncode == 0:
            logger.info("✅ Execução bem-sucedida")
            
            # Verificar arquivos gerados
            output_dir = "teste_senior_focado"
            if os.path.exists(output_dir):
                # Buscar arquivos de análise
                for root, dirs, files in os.walk(output_dir):
                    for file in files:
                        if file.endswith('_analise_funcional.md'):
                            analysis_path = os.path.join(root, file)
                            with open(analysis_path, 'r', encoding='utf-8') as f:
                                analysis_content = f.read()
                            
                            logger.info(f"Análise encontrada: {file} ({len(analysis_content)} chars)")
                            
                            # VALIDAÇÕES ESPECÍFICAS DO ESPECIALISTA
                            validations = {
                                'Funcionalidades específicas': 'FUNCIONALIDADES IMPLEMENTADAS' in analysis_content.upper(),
                                'Regras de negócio detalhadas': 'REGRAS DE NEGÓCIO' in analysis_content.upper(),
                                'Estruturas de dados': 'ESTRUTURAS DE DADOS' in analysis_content.upper(),
                                'Integrações mapeadas': 'INTEGRAÇÕES' in analysis_content.upper(),
                                'Análise técnica': 'ANÁLISE' in analysis_content.upper(),
                                'Sem linguagem genérica': 'Este programa' not in analysis_content and 'sistema permite' not in analysis_content,
                                'Foco em código real': 'CLIENTE' in analysis_content.upper() or 'CONTA' in analysis_content.upper(),
                                'Nível sênior': len(analysis_content) > 1000 and 'Linha' in analysis_content
                            }
                            
                            passed = 0
                            for check, result in validations.items():
                                status = '✅' if result else '❌'
                                logger.info(f"{status} {check}")
                                if result:
                                    passed += 1
                            
                            score = (passed / len(validations)) * 100
                            logger.info(f"Score de qualidade sênior: {score:.1f}% ({passed}/{len(validations)})")
                            
                            # Mostrar amostra da análise
                            logger.info("\n=== AMOSTRA DA ANÁLISE ===")
                            lines = analysis_content.split('\n')[:15]
                            for line in lines:
                                if line.strip():
                                    logger.info(line)
                            logger.info("=== FIM DA AMOSTRA ===\n")
                            
                            return score >= 75.0
                            
            else:
                logger.error("Diretório de saída não criado")
                return False
        else:
            logger.error(f"Erro na execução: {result.stderr}")
            return False
            
    except Exception as e:
        logger.error(f"Erro no teste: {e}")
        return False

if __name__ == "__main__":
    success = test_senior_analysis()
    sys.exit(0 if success else 1)
