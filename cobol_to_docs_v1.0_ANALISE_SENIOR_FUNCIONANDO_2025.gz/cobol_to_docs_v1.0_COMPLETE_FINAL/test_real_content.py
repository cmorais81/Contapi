#!/usr/bin/env python3
"""
Teste com conteúdo real dos arquivos fontes.txt e books.txt
"""

import os
import sys
import subprocess
import logging

def setup_logging():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    return logging.getLogger(__name__)

def test_real_content():
    """Testa sistema com conteúdo real"""
    logger = setup_logging()
    
    logger.info("=== TESTE COM CONTEÚDO REAL ===")
    
    # Verificar arquivos
    fontes_path = "examples/fontes.txt"
    books_path = "examples/books.txt"
    
    if not os.path.exists(fontes_path):
        logger.error(f"Arquivo não encontrado: {fontes_path}")
        return False
    
    if not os.path.exists(books_path):
        logger.error(f"Arquivo não encontrado: {books_path}")
        return False
    
    # Verificar conteúdo dos arquivos
    with open(fontes_path, 'r', encoding='utf-8') as f:
        fontes_content = f.read()
    
    with open(books_path, 'r', encoding='utf-8') as f:
        books_content = f.read()
    
    logger.info(f"Fontes.txt: {len(fontes_content)} caracteres")
    logger.info(f"Books.txt: {len(books_content)} caracteres")
    
    # Executar análise
    cmd = [
        'python3', 'main.py',
        '--fontes', fontes_path,
        '--books', books_path,
        '--models', 'enhanced_mock',
        '--output', 'teste_conteudo_real'
    ]
    
    logger.info(f"Executando: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        
        if result.returncode == 0:
            logger.info("✅ Execução bem-sucedida")
            
            # Verificar arquivos gerados
            output_dir = "teste_conteudo_real"
            if os.path.exists(output_dir):
                files = os.listdir(output_dir)
                logger.info(f"Arquivos gerados: {files}")
                
                # Verificar análise gerada
                for file in files:
                    if file.endswith('_analise_funcional.md'):
                        analysis_path = os.path.join(output_dir, file)
                        with open(analysis_path, 'r', encoding='utf-8') as f:
                            analysis_content = f.read()
                        
                        logger.info(f"Análise gerada: {len(analysis_content)} caracteres")
                        
                        # Verificar se contém funcionalidades específicas
                        checks = {
                            'Funcionalidades identificadas': 'FUNCIONALIDADES' in analysis_content.upper(),
                            'Regras de negócio': 'REGRAS DE NEGÓCIO' in analysis_content.upper() or 'BUSINESS RULES' in analysis_content.upper(),
                            'Conteúdo COBOL': 'CLIENTE' in analysis_content.upper() or 'CONTA' in analysis_content.upper(),
                            'Copybooks': 'COPY' in analysis_content.upper() or 'REG-CLIENTE' in analysis_content.upper(),
                            'Análise profissional': len(analysis_content) > 5000
                        }
                        
                        for check, result in checks.items():
                            logger.info(f"{check}: {'✅' if result else '❌'}")
                        
                        return all(checks.values())
            else:
                logger.error("Diretório de saída não criado")
                return False
        else:
            logger.error(f"Erro na execução: {result.stderr}")
            logger.info(f"Stdout: {result.stdout}")
            return False
            
    except Exception as e:
        logger.error(f"Erro no teste: {e}")
        return False

if __name__ == "__main__":
    success = test_real_content()
    sys.exit(0 if success else 1)
