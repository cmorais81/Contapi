#!/usr/bin/env python3
"""
Teste direto para verificar geração de análises
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

import logging
from src.parsers.cobol_parser_original import COBOLParser
from src.providers.enhanced_mock_provider import EnhancedMockProvider
from src.core.analysis_request import AnalysisRequest
from src.generators.documentation_generator import DocumentationGenerator

def setup_logging():
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    return logging.getLogger(__name__)

def test_direct_analysis():
    """Teste direto de análise"""
    logger = setup_logging()
    
    logger.info("=== TESTE DIRETO DE ANÁLISE ===")
    
    try:
        # 1. Parse dos arquivos
        parser = COBOLParser()
        programs, books = parser.parse_file("examples/fontes.txt")
        
        if not programs:
            logger.error("Nenhum programa encontrado")
            return False
        
        program = programs[0]
        logger.info(f"Programa encontrado: {program.name} ({len(program.content)} chars)")
        
        # 2. Análise com Enhanced Mock
        config = {"enhanced_mock": {"enabled": True}}
        provider = EnhancedMockProvider(config)
        
        request = AnalysisRequest(
            program_name=program.name,
            program_content=program.content,
            model="enhanced_mock",
            prompt="Analise este programa COBOL",
            analysis_type="individual"
        )
        
        logger.info("Executando análise...")
        result = provider.analyze(request)
        
        if result and hasattr(result, 'analysis_content'):
            logger.info(f"Análise gerada: {len(result.analysis_content)} caracteres")
            
            # 3. Gerar documentação
            doc_generator = DocumentationGenerator()
            output_dir = "teste_direto"
            os.makedirs(output_dir, exist_ok=True)
            
            doc_file = doc_generator.generate_program_documentation(
                program=program,
                ai_response=result
            )
            
            if doc_file and os.path.exists(doc_file):
                logger.info(f"✅ Arquivo gerado: {doc_file}")
                
                # Verificar conteúdo
                with open(doc_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                logger.info(f"Conteúdo do arquivo: {len(content)} caracteres")
                
                # Validações específicas
                checks = {
                    'Funcionalidades': 'FUNCIONALIDADES' in content.upper(),
                    'Regras de negócio': 'REGRAS' in content.upper(),
                    'Estruturas': 'ESTRUTURAS' in content.upper(),
                    'Conteúdo real': 'CLIENTE' in content.upper() or 'CONTA' in content.upper(),
                    'Análise técnica': len(content) > 500
                }
                
                for check, passed in checks.items():
                    status = '✅' if passed else '❌'
                    logger.info(f"{status} {check}")
                
                # Mostrar amostra
                logger.info("\n=== AMOSTRA DO ARQUIVO ===")
                lines = content.split('\n')[:20]
                for line in lines:
                    if line.strip():
                        logger.info(line)
                logger.info("=== FIM DA AMOSTRA ===")
                
                return all(checks.values())
            else:
                logger.error("Arquivo de documentação não foi gerado")
                return False
        else:
            logger.error("Análise não foi gerada")
            return False
            
    except Exception as e:
        logger.error(f"Erro no teste: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_direct_analysis()
    sys.exit(0 if success else 1)
