# sbr-thpf-cobol-to-docs

Este é o pacote de análise de código COBOL, com integração aprimorada com a LuzIA e uma estrutura de projeto organizada para facilitar o desenvolvimento e a manutenção.

## Estrutura do Projeto

```
sbr-thpf-cobol-to-docs/
├── .gitignore
├── CHANGELOG.md
├── LICENSE
├── pytest.ini
├── README.md              # Este documento
├── requirements.txt
├── setup.py               # Arquivo de configuração para instalação via pip
└── cobol_to_docs/         # Diretório principal da aplicação
    ├── runner/            # Scripts executáveis (main.py, cli.py, cobol_to_docs.py)
    │   ├── main.py
    │   ├── cli.py
    │   └── cobol_to_docs.py
    ├── config/            # Configurações principais (config.yaml, prompts, etc.)
    ├── src/               # Código-fonte da aplicação
    │   ├── core/          # Componentes centrais (config, prompt_manager)
    │   ├── providers/     # Provedores de IA (inclui luzia_provider.py corrigido)
    │   ├── analyzers/     # Analisadores COBOL
    │   ├── generators/    # Geradores de documentação
    │   ├── parsers/       # Parsers COBOL
    │   ├── rag/           # Sistema RAG (Retrieval-Augmented Generation)
    │   └── utils/         # Utilitários
    ├── data/              # Base de conhecimento RAG, embeddings, etc.
    ├── examples/          # Exemplos de programas COBOL para análise
    ├── docs/              # Documentação adicional do projeto
    └── logs/              # Logs da aplicação
```

## Configuração da LuzIA

Para que a integração com a LuzIA funcione corretamente, é necessário configurar as seguintes variáveis de ambiente:

*   `LUZIA_CLIENT_ID`: Seu ID de cliente para autenticação na API da LuzIA.
*   `LUZIA_CLIENT_SECRET`: Seu segredo de cliente para autenticação na API da LuzIA.

**Exemplo de configuração (Linux/macOS):**

```bash
export LUZIA_CLIENT_ID="seu_client_id_aqui"
export LUZIA_CLIENT_SECRET="seu_client_secret_aqui"
```

## Instalação

1.  **Clone o repositório:**
    ```bash
    git clone <URL_DO_REPOSITORIO>
    cd sbr-thpf-cobol-to-docs
    ```
2.  **Instale as dependências:**
    ```bash
    pip install -r requirements.txt
    ```
3.  **Instale o pacote (modo editável para desenvolvimento):**
    ```bash
    pip install -e .
    ```

## Uso

Para executar a análise de um programa COBOL usando a LuzIA:

```bash
python cobol_to_docs/runner/main.py --program-path <caminho_para_seu_programa.cbl> --provider luzia
```

Para mais opções, consulte:

```bash
python cobol_to_docs/runner/main.py --help
```

## Testes

Para executar os testes, utilize:

```bash
pytest
```

