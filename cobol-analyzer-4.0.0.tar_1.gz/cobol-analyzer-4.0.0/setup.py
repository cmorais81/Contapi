#!/usr/bin/env python3

from setuptools import setup, find_packages

setup(
    name="cobol-analyzer",
    version="4.0.0",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    entry_points={
        "console_scripts": [
            "cobol-analyzer = cli:main",
        ],
    },
    install_requires=[
        "pyyaml",
        "openai",
        "boto3",
        "requests",
        "click",
    ],
)

