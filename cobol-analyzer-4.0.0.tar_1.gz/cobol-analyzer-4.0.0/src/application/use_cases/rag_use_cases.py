#!/usr/bin/env python3

from typing import List

from src.domain.models import KnowledgeItem
from src.domain.repositories import KnowledgeRepository

class AddToKnowledgeBase:
    """Use case for adding an item to the knowledge base."""

    def __init__(self, repository: KnowledgeRepository):
        self.repository = repository

    def execute(self, item: KnowledgeItem):
        """Executes the use case."""
        self.repository.add(item)

class SearchKnowledgeBase:
    """Use case for searching the knowledge base."""

    def __init__(self, repository: KnowledgeRepository):
        self.repository = repository

    def execute(self, query: str) -> List[KnowledgeItem]:
        """Executes the use case."""
        return self.repository.find(query)

