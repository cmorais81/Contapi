"""
Use Case: Analyze a Single COBOL Program
"""

import logging
import os
import time
from typing import Dict, Any, List

from src.domain.models import CobolProgram, CobolBook
from src.config import ConfigManager
from src.application.services.prompt_manager import PromptManager
from src.infrastructure.providers.enhanced_provider_manager import EnhancedProviderManager
from src.generators.documentation_generator import DocumentationGenerator
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration import RAGIntegration
from src.utils.cobol_preprocessor import COBOLPreprocessor

logger = logging.getLogger(__name__)

class AnalyzeSingleProgramUseCase:
    def __init__(
        self,
        config_manager: ConfigManager,
        cost_calculator: CostCalculator,
        rag_integration: RAGIntegration,
        provider_manager: EnhancedProviderManager,
    ):
        self.config_manager = config_manager
        self.cost_calculator = cost_calculator
        self.rag_integration = rag_integration
        self.provider_manager = provider_manager
        self.prompt_manager = PromptManager(self.config_manager)

    def execute(
        self, 
        program: CobolProgram, 
        books: List[CobolBook], 
        model: str, 
        output_dir: str, 
        is_multi_model: bool, 
        args: Any
    ) -> Dict[str, Any]:
        """Analyzes a single COBOL program with a specific model."""
        
        if is_multi_model:
            model_output_dir = os.path.join(output_dir, f"model_{model.replace('/', '_').replace('-', '_')}")
            os.makedirs(model_output_dir, exist_ok=True)
        else:
            model_output_dir = output_dir

        try:
            doc_generator = DocumentationGenerator(model_output_dir)
            analyzer = EnhancedCOBOLAnalyzer(self.provider_manager, self.prompt_manager, self.rag_integration)

            preprocessor = COBOLPreprocessor()
            if hasattr(args, "no_comments") and args.no_comments:
                program.content, _ = preprocessor.remove_comments(program.content)

            start_time = time.time()
            analysis_result = analyzer.analyze_program(program, model)
            analysis_time = time.time() - start_time

            if not analysis_result.success:
                return self._handle_failure(program, model, analysis_time, analysis_result.error_message, model_output_dir)

            cost_info = self.cost_calculator.tokens_analytics(
                {"usage": [{"total_tokens": analysis_result.tokens_used}]},
                analysis_result.model
            )

            doc_generator.generate_program_documentation(program, analysis_result)

            if self.rag_integration:
                self.rag_integration.add_program_analysis_to_knowledge_base(
                    program.name,
                    analysis_result.content,
                    program.content
                )

            return self._handle_success(program, model, analysis_result, analysis_time, model_output_dir)

        except Exception as e:
            logger.error(f"Error analyzing {program.name} with {model}: {e}")
            return self._handle_failure(program, model, 0, str(e), model_output_dir)

    def _handle_success(self, program, model, result, analysis_time, output_dir):
        logger.info(f"Successfully analyzed {program.name} with {model}.")
        return {
            "success": True,
            "program_name": program.name,
            "model": model,
            "tokens_used": result.tokens_used,
            "analysis_time": analysis_time,
            "output_dir": output_dir,
        }

    def _handle_failure(self, program, model, analysis_time, error_message, output_dir):
        logger.error(f"Failed to analyze {program.name} with {model}: {error_message}")
        return {
            "success": False,
            "program_name": program.name,
            "model": model,
            "error": error_message,
            "tokens_used": 0,
            "analysis_time": analysis_time,
            "output_dir": output_dir,
        }

