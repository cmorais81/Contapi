#!/usr/bin/env python3

from .models import CobolProgram, AnalysisResult

class CobolAnalysisService:
    def analyze(self, program: CobolProgram) -> AnalysisResult:
        # Lógica de análise do programa COBOL
        summary = f"Análise do programa {program.name}"
        details = {"lines": len(program.content.splitlines())}
        return AnalysisResult(program.name, summary, details)

