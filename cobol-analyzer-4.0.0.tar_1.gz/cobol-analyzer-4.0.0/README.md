"""# COBOL Analyzer

Uma ferramenta de análise de código COBOL com tecnologia de IA para modernização e documentação de sistemas legados.

## Visão Geral

O COBOL Analyzer é uma aplicação projetada para analisar programas COBOL, extrair lógica de negócio, gerar documentação e fornecer insights para projetos de modernização. A ferramenta utiliza modelos de linguagem de IA para realizar uma análise profunda do código, incluindo a interpretação de comentários e a identificação de regras de negócio complexas.

## Funcionalidades

- **Análise de Código COBOL:** Análise sintática e semântica de programas COBOL.
- **Geração de Documentação:** Criação automática de documentação técnica e funcional em formato Markdown.
- **Extração de Regras de Negócio:** Identificação e extração de regras de negócio do código-fonte.
- **Suporte a Múltiplos Modelos de IA:** Integração com diversos provedores e modelos de IA, permitindo a comparação de resultados.
- **Sistema RAG (Retrieval-Augmented Generation):** Base de conhecimento para enriquecimento das análises com informações de análises anteriores.
- **Interface de Linha de Comando (CLI):** Operação simplificada através de uma CLI intuitiva.
- **Arquitetura em Camadas:** Design de software moderno, seguindo os princípios SOLID para manutenibilidade e extensibilidade.

## Arquitetura

A aplicação segue uma arquitetura em camadas, separando as responsabilidades em três níveis principais:

- **Domínio:** Contém os modelos e a lógica de negócio principal da aplicação.
- **Aplicação:** Orquestra os casos de uso e a interação entre o domínio e a infraestrutura.
- **Infraestrutura:** Gerencia os detalhes de implementação, como acesso a arquivos, provedores de IA e persistência de dados.

Essa arquitetura promove um baixo acoplamento e alta coesão, facilitando a manutenção, a extensibilidade e a testabilidade do sistema.

## Instalação

Para instalar a aplicação como um pacote, utilize o `pip`:

```bash
pip install .
```

## Uso

A aplicação pode ser utilizada de duas formas: através da CLI (após a instalação) ou executando o script `cli.py` diretamente.

### Interface de Linha de Comando (CLI)

Após a instalação, a aplicação pode ser executada com o comando `cobol-analyzer`:

```bash
cobol-analyzer [OPTIONS] COMMAND [ARGS]...
```

**Comandos:**

- `analyze`: Analisa programas COBOL.
- `rag`: Gerencia a base de conhecimento do RAG.

**Exemplo de Análise:**

```bash
cobol-analyzer --config /path/to/config.yaml analyze --fontes /path/to/programs.txt
```

### Execução Direta

Para executar a aplicação diretamente, utilize o seguinte comando:

```bash
python3 src/cli.py --config config/config.yaml analyze --fontes data/test_programs.txt
```

## Configuração

A aplicação é configurada através do arquivo `config/config.yaml`. Este arquivo permite definir:

- **Provedores de IA:** Configuração de diferentes provedores (OpenAI, Bedrock, etc.).
- **Modelos de IA:** Definição de modelos específicos para cada provedor.
- **Logging:** Nível e formato dos logs.
- **Sistema RAG:** Configurações da base de conhecimento.

## Sistema RAG

A funcionalidade RAG permite criar e gerenciar uma base de conhecimento que é utilizada para enriquecer as análises. A CLI oferece comandos para adicionar e pesquisar itens na base de conhecimento.

**Adicionar um item:**

```bash
cobol-analyzer rag add "Nome do Item" "Descrição" "Conteúdo" "Categoria" "tag1" "tag2"
```

**Pesquisar na base:**

```bash
cobol-analyzer rag search "Termo de busca"
```

## Desenvolvimento

Para executar os testes unitários, utilize o `pytest`:

```bash
pytest
```

"""
