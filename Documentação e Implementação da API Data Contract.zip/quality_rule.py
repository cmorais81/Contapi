"""
Quality Rule model.
"""

from sqlalchemy import Boolean, Column, ForeignKey, String, Text
from app.models.base import GUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import QualityMixin


class QualityRule(BaseModel, QualityMixin):
    """
    Quality Rule model.
    
    Data quality rules and validations.
    """

    __tablename__ = "quality_rules"

    # Foreign key to contract
    contract_id = Column(
        GUID(),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to contract"
    )

    # Rule definition
    rule_name = Column(
        String(255),
        nullable=False,
        doc="Quality rule name"
    )

    rule_description = Column(
        Text,
        doc="Rule description"
    )

    rule_type = Column(
        String(100),
        nullable=False,
        doc="Type: completeness, uniqueness, validity, consistency, accuracy"
    )

    rule_expression = Column(
        Text,
        nullable=False,
        doc="Rule expression (SQL, Python, etc.)"
    )

    # Configuration
    target_table = Column(
        String(255),
        doc="Target table for validation"
    )

    target_column = Column(
        String(255),
        doc="Target column for validation"
    )

    execution_frequency = Column(
        String(50),
        doc="Execution frequency: hourly, daily, weekly, monthly"
    )

    is_enabled = Column(
        Boolean,
        default=True,
        doc="Rule is enabled"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="quality_rules"
    )

    executions = relationship(
        "QualityExecution",
        back_populates="quality_rule",
        cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<QualityRule(name={self.rule_name}, type={self.rule_type})>"

