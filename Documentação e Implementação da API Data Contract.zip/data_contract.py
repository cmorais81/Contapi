"""
Data Contract model.
"""

from sqlalchemy import Boolean, Column, String, Text
from app.models.base import GUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import UnityMixin


class DataContract(BaseModel, UnityMixin):
    """
    Data Contract model.
    
    Central table for data contracts with Unity Catalog integration.
    """

    __tablename__ = "data_contracts"

    # Contract identification
    contract_name = Column(
        String(255),
        nullable=False,
        unique=True,
        index=True,
        doc="Unique contract name"
    )

    contract_description = Column(
        Text,
        doc="Detailed contract description"
    )

    contract_owner = Column(
        String(255),
        doc="Contract owner responsible"
    )

    business_domain = Column(
        String(100),
        index=True,
        doc="Business domain (sales, marketing, etc.)"
    )

    # Data configuration
    data_location = Column(
        String(500),
        doc="Physical data location"
    )

    data_format = Column(
        String(50),
        doc="Data format: delta, iceberg, parquet, json, csv, avro"
    )

    table_format = Column(
        String(50),
        doc="Table format: delta, iceberg, hudi"
    )

    # ABAC configuration
    abac_enabled = Column(
        Boolean,
        default=False,
        doc="Attribute-based access control enabled"
    )

    abac_policy_id = Column(
        GUID(),
        doc="Reference to ABAC policy"
    )

    # Monitoring
    monitoring_enabled = Column(
        Boolean,
        default=True,
        doc="Quality monitoring enabled"
    )

    alert_threshold_percent = Column(
        String(10),  # Using String to handle numeric as text
        doc="Alert threshold for quality (0-100)"
    )

    # Status
    contract_status = Column(
        String(50),
        default="draft",
        index=True,
        doc="Status: draft, active, deprecated, archived"
    )

    # Relationships
    versions = relationship(
        "ContractVersion",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    layouts = relationship(
        "ContractLayout",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    custom_properties = relationship(
        "ContractCustomProperty",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    fundamentals = relationship(
        "ContractFundamental",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    team_definitions = relationship(
        "ContractTeamDefinition",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    sla_definitions = relationship(
        "ContractSLADefinition",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    pricing_definitions = relationship(
        "ContractPricingDefinition",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    schema_definitions = relationship(
        "ContractSchemaDefinition",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    data_objects = relationship(
        "DataObject",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    quality_definitions = relationship(
        "ContractQualityDefinition",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    quality_rules = relationship(
        "QualityRule",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    cluster_metrics = relationship(
        "ClusterMetric",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    job_metrics = relationship(
        "JobMetric",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    query_metrics = relationship(
        "QueryMetric",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    storage_metrics = relationship(
        "StorageMetric",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    quality_aggregates = relationship(
        "DataQualityAggregate",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    anomaly_detections = relationship(
        "DataAnomalyDetection",
        back_populates="contract",
        cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<DataContract(name={self.contract_name}, status={self.contract_status})>"

