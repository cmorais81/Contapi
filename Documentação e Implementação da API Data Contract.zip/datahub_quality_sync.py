#!/usr/bin/env python3
"""
DataHub Quality Sync Service - Sincronização de métricas de qualidade
Responsável por publicar e sincronizar scores de qualidade com DataHub
"""

import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import Enum
import uuid

import asyncpg
from datahub_connector import DataHubConnector, QualityScore, ComplianceStatus

logger = logging.getLogger(__name__)

class QualityLevel(Enum):
    """Níveis de qualidade"""
    EXCELLENT = "excellent"  # 90-100%
    GOOD = "good"           # 75-89%
    FAIR = "fair"           # 60-74%
    POOR = "poor"           # 0-59%

class QualityDimension(Enum):
    """Dimensões de qualidade"""
    COMPLETENESS = "completeness"
    UNIQUENESS = "uniqueness"
    VALIDITY = "validity"
    CONSISTENCY = "consistency"
    ACCURACY = "accuracy"
    TIMELINESS = "timeliness"

@dataclass
class QualityRule:
    """Definição de regra de qualidade"""
    id: str
    name: str
    dimension: QualityDimension
    description: str
    sql_expression: str
    threshold: float
    weight: float = 1.0
    is_active: bool = True
    created_by: str = ""
    created_at: datetime = None

@dataclass
class QualityExecution:
    """Resultado de execução de qualidade"""
    execution_id: str
    dataset_urn: str
    rule_id: str
    score: float
    passed: bool
    execution_time: datetime
    details: Dict[str, Any]
    error_message: Optional[str] = None

@dataclass
class DatasetQualityProfile:
    """Perfil de qualidade de um dataset"""
    dataset_urn: str
    overall_score: float
    dimension_scores: Dict[QualityDimension, float]
    quality_level: QualityLevel
    total_rules: int
    passed_rules: int
    failed_rules: int
    last_execution: datetime
    trend: str  # improving, stable, declining
    issues: List[str]

class DataHubQualitySync:
    """Serviço de sincronização de qualidade com DataHub"""
    
    def __init__(self, datahub_connector: DataHubConnector, db_pool: asyncpg.Pool):
        self.datahub = datahub_connector
        self.db_pool = db_pool
        self.running = False
        self.sync_interval = 300  # 5 minutos
        self.batch_size = 50

    async def start_sync_service(self):
        """Inicia o serviço de sincronização"""
        self.running = True
        logger.info("Starting DataHub Quality Sync Service")
        
        # Iniciar workers
        tasks = [
            asyncio.create_task(self._quality_sync_worker()),
            asyncio.create_task(self._compliance_sync_worker()),
            asyncio.create_task(self._quality_trend_analyzer()),
            asyncio.create_task(self._quality_alert_monitor())
        ]
        
        try:
            await asyncio.gather(*tasks)
        except Exception as e:
            logger.error(f"Error in sync service: {e}")
        finally:
            self.running = False

    async def stop_sync_service(self):
        """Para o serviço de sincronização"""
        self.running = False
        logger.info("Stopping DataHub Quality Sync Service")

    # ==================== QUALITY SYNCHRONIZATION ====================

    async def _quality_sync_worker(self):
        """Worker que sincroniza scores de qualidade"""
        while self.running:
            try:
                # Buscar datasets com scores atualizados
                datasets_to_sync = await self._get_datasets_with_updated_quality()
                
                if not datasets_to_sync:
                    await asyncio.sleep(self.sync_interval)
                    continue
                
                logger.info(f"Syncing quality scores for {len(datasets_to_sync)} datasets")
                
                # Processar em batches
                for i in range(0, len(datasets_to_sync), self.batch_size):
                    batch = datasets_to_sync[i:i + self.batch_size]
                    await self._sync_quality_batch(batch)
                
                await asyncio.sleep(self.sync_interval)
                
            except Exception as e:
                logger.error(f"Error in quality sync worker: {e}")
                await asyncio.sleep(60)

    async def _get_datasets_with_updated_quality(self) -> List[str]:
        """Obtém datasets com scores de qualidade atualizados"""
        async with self.db_pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT DISTINCT de.datahub_urn
                FROM datahub_entities de
                JOIN quality_executions qe ON de.datahub_urn = qe.dataset_urn
                WHERE qe.execution_time > de.last_sync_timestamp
                   OR de.last_sync_timestamp IS NULL
                ORDER BY qe.execution_time DESC
                LIMIT 1000
            """)
            
            return [row['datahub_urn'] for row in rows]

    async def _sync_quality_batch(self, dataset_urns: List[str]):
        """Sincroniza batch de datasets"""
        for dataset_urn in dataset_urns:
            try:
                # Calcular perfil de qualidade
                quality_profile = await self._calculate_quality_profile(dataset_urn)
                
                if quality_profile:
                    # Criar objeto QualityScore
                    quality_score = QualityScore(
                        overall=quality_profile.overall_score,
                        completeness=quality_profile.dimension_scores.get(QualityDimension.COMPLETENESS, 0),
                        uniqueness=quality_profile.dimension_scores.get(QualityDimension.UNIQUENESS, 0),
                        validity=quality_profile.dimension_scores.get(QualityDimension.VALIDITY, 0),
                        consistency=quality_profile.dimension_scores.get(QualityDimension.CONSISTENCY, 0),
                        accuracy=quality_profile.dimension_scores.get(QualityDimension.ACCURACY, 0),
                        last_calculated=quality_profile.last_execution
                    )
                    
                    # Publicar para DataHub
                    success = await self.datahub.publish_quality_scores(dataset_urn, quality_score)
                    
                    if success:
                        # Atualizar timestamp de sincronização
                        await self._update_sync_timestamp(dataset_urn)
                        logger.debug(f"Synced quality scores for {dataset_urn}")
                    else:
                        logger.error(f"Failed to sync quality scores for {dataset_urn}")
                
            except Exception as e:
                logger.error(f"Error syncing quality for {dataset_urn}: {e}")

    async def _calculate_quality_profile(self, dataset_urn: str) -> Optional[DatasetQualityProfile]:
        """Calcula perfil de qualidade para um dataset"""
        async with self.db_pool.acquire() as conn:
            # Buscar execuções recentes de qualidade
            rows = await conn.fetch("""
                SELECT qe.*, qr.dimension, qr.weight
                FROM quality_executions qe
                JOIN quality_rules qr ON qe.rule_id = qr.id
                WHERE qe.dataset_urn = $1
                  AND qe.execution_time > NOW() - INTERVAL '24 hours'
                ORDER BY qe.execution_time DESC
            """, dataset_urn)
            
            if not rows:
                return None
            
            # Agrupar por dimensão
            dimension_scores = {}
            dimension_weights = {}
            total_rules = len(rows)
            passed_rules = 0
            issues = []
            
            for row in rows:
                dimension = QualityDimension(row['dimension'])
                score = row['score']
                weight = row['weight']
                passed = row['passed']
                
                if passed:
                    passed_rules += 1
                else:
                    issues.append(f"Rule {row['rule_id']} failed with score {score:.2f}")
                
                if dimension not in dimension_scores:
                    dimension_scores[dimension] = []
                    dimension_weights[dimension] = []
                
                dimension_scores[dimension].append(score)
                dimension_weights[dimension].append(weight)
            
            # Calcular scores ponderados por dimensão
            final_dimension_scores = {}
            for dimension, scores in dimension_scores.items():
                weights = dimension_weights[dimension]
                weighted_score = sum(s * w for s, w in zip(scores, weights)) / sum(weights)
                final_dimension_scores[dimension] = weighted_score
            
            # Calcular score geral
            overall_score = sum(final_dimension_scores.values()) / len(final_dimension_scores)
            
            # Determinar nível de qualidade
            quality_level = self._get_quality_level(overall_score)
            
            # Calcular trend
            trend = await self._calculate_quality_trend(dataset_urn)
            
            return DatasetQualityProfile(
                dataset_urn=dataset_urn,
                overall_score=overall_score,
                dimension_scores=final_dimension_scores,
                quality_level=quality_level,
                total_rules=total_rules,
                passed_rules=passed_rules,
                failed_rules=total_rules - passed_rules,
                last_execution=rows[0]['execution_time'],
                trend=trend,
                issues=issues[:5]  # Top 5 issues
            )

    def _get_quality_level(self, score: float) -> QualityLevel:
        """Determina nível de qualidade baseado no score"""
        if score >= 90:
            return QualityLevel.EXCELLENT
        elif score >= 75:
            return QualityLevel.GOOD
        elif score >= 60:
            return QualityLevel.FAIR
        else:
            return QualityLevel.POOR

    async def _calculate_quality_trend(self, dataset_urn: str) -> str:
        """Calcula tendência de qualidade"""
        async with self.db_pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT 
                    DATE_TRUNC('day', execution_time) as day,
                    AVG(score) as avg_score
                FROM quality_executions
                WHERE dataset_urn = $1
                  AND execution_time > NOW() - INTERVAL '7 days'
                GROUP BY DATE_TRUNC('day', execution_time)
                ORDER BY day DESC
                LIMIT 7
            """, dataset_urn)
            
            if len(rows) < 2:
                return "stable"
            
            # Calcular tendência linear simples
            scores = [row['avg_score'] for row in reversed(rows)]
            if len(scores) >= 3:
                recent_avg = sum(scores[-3:]) / 3
                older_avg = sum(scores[:-3]) / (len(scores) - 3) if len(scores) > 3 else scores[0]
                
                if recent_avg > older_avg + 5:
                    return "improving"
                elif recent_avg < older_avg - 5:
                    return "declining"
            
            return "stable"

    # ==================== COMPLIANCE SYNCHRONIZATION ====================

    async def _compliance_sync_worker(self):
        """Worker que sincroniza status de compliance"""
        while self.running:
            try:
                # Buscar datasets com compliance atualizado
                datasets_to_sync = await self._get_datasets_with_updated_compliance()
                
                if not datasets_to_sync:
                    await asyncio.sleep(self.sync_interval)
                    continue
                
                logger.info(f"Syncing compliance status for {len(datasets_to_sync)} datasets")
                
                # Processar em batches
                for i in range(0, len(datasets_to_sync), self.batch_size):
                    batch = datasets_to_sync[i:i + self.batch_size]
                    await self._sync_compliance_batch(batch)
                
                await asyncio.sleep(self.sync_interval)
                
            except Exception as e:
                logger.error(f"Error in compliance sync worker: {e}")
                await asyncio.sleep(60)

    async def _get_datasets_with_updated_compliance(self) -> List[str]:
        """Obtém datasets com compliance atualizado"""
        async with self.db_pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT DISTINCT de.datahub_urn
                FROM datahub_entities de
                JOIN privacy_scans ps ON de.datahub_urn = ps.dataset_urn
                WHERE ps.scan_timestamp > de.last_compliance_sync
                   OR de.last_compliance_sync IS NULL
                ORDER BY ps.scan_timestamp DESC
                LIMIT 1000
            """)
            
            return [row['datahub_urn'] for row in rows]

    async def _sync_compliance_batch(self, dataset_urns: List[str]):
        """Sincroniza batch de compliance"""
        for dataset_urn in dataset_urns:
            try:
                # Calcular status de compliance
                compliance_status = await self._calculate_compliance_status(dataset_urn)
                
                if compliance_status:
                    # Publicar para DataHub
                    success = await self.datahub.publish_compliance_status(dataset_urn, compliance_status)
                    
                    if success:
                        # Atualizar timestamp de sincronização
                        await self._update_compliance_sync_timestamp(dataset_urn)
                        logger.debug(f"Synced compliance status for {dataset_urn}")
                    else:
                        logger.error(f"Failed to sync compliance for {dataset_urn}")
                
            except Exception as e:
                logger.error(f"Error syncing compliance for {dataset_urn}: {e}")

    async def _calculate_compliance_status(self, dataset_urn: str) -> Optional[ComplianceStatus]:
        """Calcula status de compliance para um dataset"""
        async with self.db_pool.acquire() as conn:
            # Buscar informações de PII
            pii_row = await conn.fetchrow("""
                SELECT 
                    COUNT(*) as pii_fields_count,
                    MAX(scan_timestamp) as last_scan
                FROM privacy_scans
                WHERE dataset_urn = $1 AND pii_detected = true
            """, dataset_urn)
            
            # Buscar políticas aplicadas
            policies_row = await conn.fetchrow("""
                SELECT 
                    COUNT(CASE WHEN policy_type = 'gdpr' THEN 1 END) > 0 as gdpr_compliant,
                    COUNT(CASE WHEN policy_type = 'lgpd' THEN 1 END) > 0 as lgpd_compliant,
                    COUNT(CASE WHEN policy_type = 'ccpa' THEN 1 END) > 0 as ccpa_compliant,
                    COUNT(CASE WHEN policy_type = 'retention' THEN 1 END) > 0 as retention_defined
                FROM privacy_policies pp
                JOIN dataset_policies dp ON pp.id = dp.policy_id
                WHERE dp.dataset_urn = $1 AND pp.is_active = true
            """, dataset_urn)
            
            # Buscar informações de mascaramento
            masking_row = await conn.fetchrow("""
                SELECT COUNT(*) > 0 as masking_applied
                FROM masking_rules mr
                JOIN dataset_masking dm ON mr.id = dm.rule_id
                WHERE dm.dataset_urn = $1 AND mr.is_active = true
            """, dataset_urn)
            
            if not pii_row or not policies_row or not masking_row:
                return None
            
            return ComplianceStatus(
                gdpr_compliant=policies_row['gdpr_compliant'] or False,
                lgpd_compliant=policies_row['lgpd_compliant'] or False,
                ccpa_compliant=policies_row['ccpa_compliant'] or False,
                pii_fields_count=pii_row['pii_fields_count'] or 0,
                masking_applied=masking_row['masking_applied'] or False,
                retention_policy_defined=policies_row['retention_defined'] or False,
                last_audit=pii_row['last_scan']
            )

    # ==================== QUALITY MONITORING ====================

    async def _quality_trend_analyzer(self):
        """Analisa tendências de qualidade"""
        while self.running:
            try:
                # Executar análise de tendências a cada hora
                await self._analyze_quality_trends()
                await asyncio.sleep(3600)  # 1 hora
                
            except Exception as e:
                logger.error(f"Error in quality trend analyzer: {e}")
                await asyncio.sleep(3600)

    async def _analyze_quality_trends(self):
        """Executa análise de tendências de qualidade"""
        async with self.db_pool.acquire() as conn:
            # Identificar datasets com declínio de qualidade
            declining_datasets = await conn.fetch("""
                WITH quality_trends AS (
                    SELECT 
                        dataset_urn,
                        AVG(CASE WHEN execution_time > NOW() - INTERVAL '1 day' THEN score END) as recent_score,
                        AVG(CASE WHEN execution_time BETWEEN NOW() - INTERVAL '7 days' AND NOW() - INTERVAL '1 day' THEN score END) as previous_score
                    FROM quality_executions
                    WHERE execution_time > NOW() - INTERVAL '7 days'
                    GROUP BY dataset_urn
                    HAVING COUNT(*) >= 10
                )
                SELECT dataset_urn, recent_score, previous_score,
                       (recent_score - previous_score) as score_change
                FROM quality_trends
                WHERE recent_score < previous_score - 10
                ORDER BY score_change ASC
                LIMIT 20
            """)
            
            # Processar datasets em declínio
            for row in declining_datasets:
                await self._handle_quality_decline(
                    row['dataset_urn'], 
                    row['recent_score'], 
                    row['previous_score']
                )

    async def _handle_quality_decline(self, dataset_urn: str, recent_score: float, previous_score: float):
        """Trata declínio de qualidade"""
        decline_percentage = ((previous_score - recent_score) / previous_score) * 100
        
        # Criar alerta
        alert_data = {
            'type': 'quality_decline',
            'dataset_urn': dataset_urn,
            'recent_score': recent_score,
            'previous_score': previous_score,
            'decline_percentage': decline_percentage,
            'severity': 'high' if decline_percentage > 20 else 'medium'
        }
        
        await self._create_quality_alert(alert_data)
        
        # Notificar stakeholders se declínio for significativo
        if decline_percentage > 15:
            await self._notify_quality_decline(dataset_urn, alert_data)

    async def _quality_alert_monitor(self):
        """Monitor de alertas de qualidade"""
        while self.running:
            try:
                # Verificar alertas pendentes
                await self._process_quality_alerts()
                await asyncio.sleep(300)  # 5 minutos
                
            except Exception as e:
                logger.error(f"Error in quality alert monitor: {e}")
                await asyncio.sleep(300)

    async def _process_quality_alerts(self):
        """Processa alertas de qualidade pendentes"""
        async with self.db_pool.acquire() as conn:
            alerts = await conn.fetch("""
                SELECT * FROM quality_alerts
                WHERE status = 'pending'
                  AND created_at > NOW() - INTERVAL '1 hour'
                ORDER BY severity, created_at
                LIMIT 50
            """)
            
            for alert in alerts:
                await self._process_single_alert(dict(alert))

    async def _process_single_alert(self, alert: Dict[str, Any]):
        """Processa um alerta individual"""
        alert_type = alert['alert_type']
        dataset_urn = alert['dataset_urn']
        
        if alert_type == 'quality_decline':
            # Executar diagnóstico automático
            diagnosis = await self._diagnose_quality_issues(dataset_urn)
            
            # Atualizar alerta com diagnóstico
            await self._update_alert_with_diagnosis(alert['id'], diagnosis)
            
        elif alert_type == 'compliance_violation':
            # Verificar políticas de compliance
            await self._verify_compliance_policies(dataset_urn)
            
        # Marcar alerta como processado
        await self._mark_alert_processed(alert['id'])

    # ==================== UTILITY METHODS ====================

    async def _update_sync_timestamp(self, dataset_urn: str):
        """Atualiza timestamp de sincronização de qualidade"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                UPDATE datahub_entities 
                SET last_sync_timestamp = NOW()
                WHERE datahub_urn = $1
            """, dataset_urn)

    async def _update_compliance_sync_timestamp(self, dataset_urn: str):
        """Atualiza timestamp de sincronização de compliance"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                UPDATE datahub_entities 
                SET last_compliance_sync = NOW()
                WHERE datahub_urn = $1
            """, dataset_urn)

    async def _create_quality_alert(self, alert_data: Dict[str, Any]):
        """Cria alerta de qualidade"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO quality_alerts 
                (id, alert_type, dataset_urn, severity, details, status)
                VALUES ($1, $2, $3, $4, $5, $6)
            """, 
                str(uuid.uuid4()),
                alert_data['type'],
                alert_data['dataset_urn'],
                alert_data['severity'],
                json.dumps(alert_data),
                'pending'
            )

    async def _notify_quality_decline(self, dataset_urn: str, alert_data: Dict[str, Any]):
        """Notifica sobre declínio de qualidade"""
        # Implementar notificação via email, Slack, etc.
        logger.warning(f"Quality decline detected for {dataset_urn}: {alert_data}")

    async def _diagnose_quality_issues(self, dataset_urn: str) -> Dict[str, Any]:
        """Executa diagnóstico automático de problemas de qualidade"""
        # Implementar lógica de diagnóstico
        return {"diagnosis": "automated_diagnosis_placeholder"}

    async def _update_alert_with_diagnosis(self, alert_id: str, diagnosis: Dict[str, Any]):
        """Atualiza alerta com diagnóstico"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                UPDATE quality_alerts 
                SET diagnosis = $1, updated_at = NOW()
                WHERE id = $2
            """, json.dumps(diagnosis), alert_id)

    async def _verify_compliance_policies(self, dataset_urn: str):
        """Verifica políticas de compliance"""
        # Implementar verificação de políticas
        pass

    async def _mark_alert_processed(self, alert_id: str):
        """Marca alerta como processado"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                UPDATE quality_alerts 
                SET status = 'processed', updated_at = NOW()
                WHERE id = $1
            """, alert_id)

    # ==================== PUBLIC API ====================

    async def sync_dataset_quality(self, dataset_urn: str) -> bool:
        """Sincroniza qualidade de um dataset específico"""
        try:
            quality_profile = await self._calculate_quality_profile(dataset_urn)
            
            if quality_profile:
                quality_score = QualityScore(
                    overall=quality_profile.overall_score,
                    completeness=quality_profile.dimension_scores.get(QualityDimension.COMPLETENESS, 0),
                    uniqueness=quality_profile.dimension_scores.get(QualityDimension.UNIQUENESS, 0),
                    validity=quality_profile.dimension_scores.get(QualityDimension.VALIDITY, 0),
                    consistency=quality_profile.dimension_scores.get(QualityDimension.CONSISTENCY, 0),
                    accuracy=quality_profile.dimension_scores.get(QualityDimension.ACCURACY, 0),
                    last_calculated=quality_profile.last_execution
                )
                
                success = await self.datahub.publish_quality_scores(dataset_urn, quality_score)
                
                if success:
                    await self._update_sync_timestamp(dataset_urn)
                
                return success
            
            return False
            
        except Exception as e:
            logger.error(f"Error syncing quality for {dataset_urn}: {e}")
            return False

    async def sync_dataset_compliance(self, dataset_urn: str) -> bool:
        """Sincroniza compliance de um dataset específico"""
        try:
            compliance_status = await self._calculate_compliance_status(dataset_urn)
            
            if compliance_status:
                success = await self.datahub.publish_compliance_status(dataset_urn, compliance_status)
                
                if success:
                    await self._update_compliance_sync_timestamp(dataset_urn)
                
                return success
            
            return False
            
        except Exception as e:
            logger.error(f"Error syncing compliance for {dataset_urn}: {e}")
            return False

    async def get_quality_summary(self) -> Dict[str, Any]:
        """Obtém resumo geral de qualidade"""
        async with self.db_pool.acquire() as conn:
            summary = await conn.fetchrow("""
                SELECT 
                    COUNT(DISTINCT dataset_urn) as total_datasets,
                    AVG(score) as avg_quality_score,
                    COUNT(CASE WHEN score >= 90 THEN 1 END) as excellent_datasets,
                    COUNT(CASE WHEN score >= 75 AND score < 90 THEN 1 END) as good_datasets,
                    COUNT(CASE WHEN score >= 60 AND score < 75 THEN 1 END) as fair_datasets,
                    COUNT(CASE WHEN score < 60 THEN 1 END) as poor_datasets
                FROM quality_executions
                WHERE execution_time > NOW() - INTERVAL '24 hours'
            """)
            
            return dict(summary) if summary else {}


if __name__ == "__main__":
    # Exemplo de uso
    import asyncio
    import os
    from datahub_connector import DataHubConnectorFactory
    
    async def main():
        logging.basicConfig(level=logging.INFO)
        
        # Configurar banco
        db_pool = await asyncpg.create_pool(
            host=os.getenv('DB_HOST', 'localhost'),
            port=os.getenv('DB_PORT', 5432),
            user=os.getenv('DB_USER', 'postgres'),
            password=os.getenv('DB_PASSWORD', ''),
            database=os.getenv('DB_NAME', 'governance')
        )
        
        # Criar connector DataHub
        datahub_connector = DataHubConnectorFactory.create_from_env(db_pool)
        
        # Criar serviço de sincronização
        quality_sync = DataHubQualitySync(datahub_connector, db_pool)
        
        try:
            # Iniciar serviço
            await quality_sync.start_sync_service()
        except KeyboardInterrupt:
            logger.info("Shutting down...")
        finally:
            await quality_sync.stop_sync_service()
            await db_pool.close()
    
    asyncio.run(main())

