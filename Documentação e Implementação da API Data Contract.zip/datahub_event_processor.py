#!/usr/bin/env python3
"""
DataHub Event Processor - Processamento avançado de eventos do DataHub
Responsável por processar eventos complexos e orquestrar workflows
"""

import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable, Set
from dataclasses import dataclass, field
from enum import Enum
import uuid

import asyncpg
from kafka import KafkaConsumer, KafkaProducer
from kafka.errors import KafkaError

logger = logging.getLogger(__name__)

class EventType(Enum):
    """Tipos de eventos processados"""
    SCHEMA_CHANGE = "schema_change"
    DATASET_DISCOVERY = "dataset_discovery"
    OWNERSHIP_CHANGE = "ownership_change"
    TAGS_CHANGE = "tags_change"
    LINEAGE_UPDATE = "lineage_update"
    ACCESS_EVENT = "access_event"
    QUALITY_UPDATE = "quality_update"
    COMPLIANCE_UPDATE = "compliance_update"

class EventPriority(Enum):
    """Prioridades de processamento de eventos"""
    CRITICAL = 1
    HIGH = 2
    MEDIUM = 3
    LOW = 4

@dataclass
class ProcessingRule:
    """Regra de processamento para eventos"""
    event_type: EventType
    priority: EventPriority
    batch_size: int = 1
    max_retry_attempts: int = 3
    retry_delay_seconds: int = 5
    timeout_seconds: int = 30
    requires_approval: bool = False
    notification_channels: List[str] = field(default_factory=list)

@dataclass
class EventContext:
    """Contexto de processamento de evento"""
    event_id: str
    event_type: EventType
    entity_urn: str
    timestamp: datetime
    payload: Dict[str, Any]
    priority: EventPriority
    retry_count: int = 0
    processing_started: Optional[datetime] = None
    processing_completed: Optional[datetime] = None
    status: str = "pending"  # pending, processing, completed, failed
    error_message: Optional[str] = None

class DataHubEventProcessor:
    """Processador avançado de eventos do DataHub"""
    
    def __init__(self, db_pool: asyncpg.Pool, kafka_config: Dict[str, Any]):
        self.db_pool = db_pool
        self.kafka_config = kafka_config
        self.consumer: Optional[KafkaConsumer] = None
        self.producer: Optional[KafkaProducer] = None
        self.processing_rules: Dict[EventType, ProcessingRule] = {}
        self.event_handlers: Dict[EventType, Callable] = {}
        self.running = False
        self.worker_tasks: List[asyncio.Task] = []
        
        # Configurar regras padrão
        self._setup_default_rules()
        self._setup_event_handlers()

    def _setup_default_rules(self):
        """Configura regras padrão de processamento"""
        self.processing_rules = {
            EventType.SCHEMA_CHANGE: ProcessingRule(
                event_type=EventType.SCHEMA_CHANGE,
                priority=EventPriority.CRITICAL,
                batch_size=1,
                max_retry_attempts=5,
                requires_approval=True,
                notification_channels=['email', 'slack']
            ),
            EventType.DATASET_DISCOVERY: ProcessingRule(
                event_type=EventType.DATASET_DISCOVERY,
                priority=EventPriority.HIGH,
                batch_size=5,
                max_retry_attempts=3,
                notification_channels=['slack']
            ),
            EventType.OWNERSHIP_CHANGE: ProcessingRule(
                event_type=EventType.OWNERSHIP_CHANGE,
                priority=EventPriority.MEDIUM,
                batch_size=10,
                max_retry_attempts=3,
                notification_channels=['email']
            ),
            EventType.TAGS_CHANGE: ProcessingRule(
                event_type=EventType.TAGS_CHANGE,
                priority=EventPriority.LOW,
                batch_size=20,
                max_retry_attempts=2
            ),
            EventType.LINEAGE_UPDATE: ProcessingRule(
                event_type=EventType.LINEAGE_UPDATE,
                priority=EventPriority.MEDIUM,
                batch_size=5,
                max_retry_attempts=3
            ),
            EventType.ACCESS_EVENT: ProcessingRule(
                event_type=EventType.ACCESS_EVENT,
                priority=EventPriority.LOW,
                batch_size=50,
                max_retry_attempts=1
            )
        }

    def _setup_event_handlers(self):
        """Configura handlers para diferentes tipos de eventos"""
        self.event_handlers = {
            EventType.SCHEMA_CHANGE: self._handle_schema_change,
            EventType.DATASET_DISCOVERY: self._handle_dataset_discovery,
            EventType.OWNERSHIP_CHANGE: self._handle_ownership_change,
            EventType.TAGS_CHANGE: self._handle_tags_change,
            EventType.LINEAGE_UPDATE: self._handle_lineage_update,
            EventType.ACCESS_EVENT: self._handle_access_event,
            EventType.QUALITY_UPDATE: self._handle_quality_update,
            EventType.COMPLIANCE_UPDATE: self._handle_compliance_update
        }

    async def start(self):
        """Inicia o processador de eventos"""
        try:
            self.running = True
            
            # Configurar Kafka consumer
            self.consumer = KafkaConsumer(
                'MetadataChangeEvent_v4',
                'MetadataAuditEvent_v4',
                'DataHubUsageEvent_v1',
                bootstrap_servers=self.kafka_config['bootstrap_servers'],
                value_deserializer=lambda m: json.loads(m.decode('utf-8')),
                group_id='governance_event_processor',
                enable_auto_commit=False,
                max_poll_records=100
            )
            
            # Configurar Kafka producer
            self.producer = KafkaProducer(
                bootstrap_servers=self.kafka_config['bootstrap_servers'],
                value_serializer=lambda v: json.dumps(v).encode('utf-8')
            )
            
            # Iniciar workers de processamento
            self.worker_tasks = [
                asyncio.create_task(self._event_consumer_worker()),
                asyncio.create_task(self._event_processor_worker()),
                asyncio.create_task(self._retry_worker()),
                asyncio.create_task(self._cleanup_worker())
            ]
            
            logger.info("DataHub Event Processor started successfully")
            
            # Aguardar conclusão dos workers
            await asyncio.gather(*self.worker_tasks)
            
        except Exception as e:
            logger.error(f"Failed to start event processor: {e}")
            await self.stop()

    async def stop(self):
        """Para o processador de eventos"""
        self.running = False
        
        # Cancelar tasks
        for task in self.worker_tasks:
            task.cancel()
        
        # Fechar conexões Kafka
        if self.consumer:
            self.consumer.close()
        if self.producer:
            self.producer.close()
            
        logger.info("DataHub Event Processor stopped")

    async def _event_consumer_worker(self):
        """Worker que consome eventos do Kafka"""
        while self.running:
            try:
                # Poll por mensagens
                message_batch = self.consumer.poll(timeout_ms=1000)
                
                for topic_partition, messages in message_batch.items():
                    for message in messages:
                        try:
                            # Processar evento
                            await self._process_raw_event(message.value)
                            
                        except Exception as e:
                            logger.error(f"Error processing raw event: {e}")
                
                # Commit offsets
                self.consumer.commit()
                
            except Exception as e:
                logger.error(f"Error in event consumer worker: {e}")
                await asyncio.sleep(5)

    async def _process_raw_event(self, raw_event: Dict[str, Any]):
        """Processa evento bruto do DataHub"""
        try:
            # Determinar tipo de evento
            event_type = self._determine_event_type(raw_event)
            if not event_type:
                return
            
            # Extrair informações básicas
            entity_urn = raw_event.get('entityUrn', '')
            timestamp = datetime.fromisoformat(
                raw_event.get('auditHeader', {}).get('time', datetime.now().isoformat())
            )
            
            # Criar contexto de evento
            event_context = EventContext(
                event_id=str(uuid.uuid4()),
                event_type=event_type,
                entity_urn=entity_urn,
                timestamp=timestamp,
                payload=raw_event,
                priority=self.processing_rules[event_type].priority
            )
            
            # Salvar evento para processamento
            await self._save_event_for_processing(event_context)
            
            logger.debug(f"Queued event {event_context.event_id} for processing")
            
        except Exception as e:
            logger.error(f"Error processing raw event: {e}")

    def _determine_event_type(self, event: Dict[str, Any]) -> Optional[EventType]:
        """Determina o tipo de evento baseado no payload"""
        aspect_name = event.get('aspectName', '')
        
        if aspect_name == 'schemaMetadata':
            return EventType.SCHEMA_CHANGE
        elif aspect_name == 'datasetProperties':
            return EventType.DATASET_DISCOVERY
        elif aspect_name == 'ownership':
            return EventType.OWNERSHIP_CHANGE
        elif aspect_name == 'globalTags':
            return EventType.TAGS_CHANGE
        elif aspect_name == 'upstreamLineage':
            return EventType.LINEAGE_UPDATE
        elif event.get('eventType') == 'DatasetUsageEvent':
            return EventType.ACCESS_EVENT
        
        return None

    async def _save_event_for_processing(self, event_context: EventContext):
        """Salva evento na fila de processamento"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO datahub_event_queue 
                (event_id, event_type, entity_urn, timestamp, payload, priority, status)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
            """, 
                event_context.event_id,
                event_context.event_type.value,
                event_context.entity_urn,
                event_context.timestamp,
                json.dumps(event_context.payload),
                event_context.priority.value,
                event_context.status
            )

    async def _event_processor_worker(self):
        """Worker que processa eventos da fila"""
        while self.running:
            try:
                # Buscar eventos para processar (ordenados por prioridade)
                events = await self._get_events_to_process()
                
                if not events:
                    await asyncio.sleep(1)
                    continue
                
                # Processar eventos em batches por tipo
                events_by_type = {}
                for event in events:
                    event_type = EventType(event['event_type'])
                    if event_type not in events_by_type:
                        events_by_type[event_type] = []
                    events_by_type[event_type].append(event)
                
                # Processar cada tipo de evento
                for event_type, event_list in events_by_type.items():
                    rule = self.processing_rules[event_type]
                    handler = self.event_handlers[event_type]
                    
                    # Processar em batches
                    for i in range(0, len(event_list), rule.batch_size):
                        batch = event_list[i:i + rule.batch_size]
                        await self._process_event_batch(batch, handler, rule)
                
            except Exception as e:
                logger.error(f"Error in event processor worker: {e}")
                await asyncio.sleep(5)

    async def _get_events_to_process(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Obtém eventos para processar da fila"""
        async with self.db_pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT * FROM datahub_event_queue 
                WHERE status = 'pending' 
                ORDER BY priority ASC, timestamp ASC 
                LIMIT $1
            """, limit)
            
            return [dict(row) for row in rows]

    async def _process_event_batch(self, events: List[Dict[str, Any]], 
                                  handler: Callable, rule: ProcessingRule):
        """Processa um batch de eventos"""
        try:
            # Marcar eventos como em processamento
            event_ids = [event['event_id'] for event in events]
            await self._update_event_status(event_ids, 'processing')
            
            # Processar eventos
            for event in events:
                try:
                    event_context = EventContext(
                        event_id=event['event_id'],
                        event_type=EventType(event['event_type']),
                        entity_urn=event['entity_urn'],
                        timestamp=event['timestamp'],
                        payload=json.loads(event['payload']),
                        priority=EventPriority(event['priority']),
                        retry_count=event.get('retry_count', 0)
                    )
                    
                    # Executar handler com timeout
                    await asyncio.wait_for(
                        handler(event_context),
                        timeout=rule.timeout_seconds
                    )
                    
                    # Marcar como concluído
                    await self._update_event_status([event['event_id']], 'completed')
                    
                    logger.debug(f"Successfully processed event {event['event_id']}")
                    
                except asyncio.TimeoutError:
                    logger.error(f"Timeout processing event {event['event_id']}")
                    await self._handle_event_failure(event, "Timeout")
                    
                except Exception as e:
                    logger.error(f"Error processing event {event['event_id']}: {e}")
                    await self._handle_event_failure(event, str(e))
            
        except Exception as e:
            logger.error(f"Error processing event batch: {e}")

    async def _update_event_status(self, event_ids: List[str], status: str):
        """Atualiza status de eventos"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                UPDATE datahub_event_queue 
                SET status = $1, updated_at = NOW()
                WHERE event_id = ANY($2)
            """, status, event_ids)

    async def _handle_event_failure(self, event: Dict[str, Any], error_message: str):
        """Trata falha no processamento de evento"""
        event_id = event['event_id']
        retry_count = event.get('retry_count', 0) + 1
        event_type = EventType(event['event_type'])
        rule = self.processing_rules[event_type]
        
        if retry_count <= rule.max_retry_attempts:
            # Agendar retry
            retry_time = datetime.now() + timedelta(seconds=rule.retry_delay_seconds * retry_count)
            
            async with self.db_pool.acquire() as conn:
                await conn.execute("""
                    UPDATE datahub_event_queue 
                    SET status = 'pending', retry_count = $1, 
                        retry_after = $2, error_message = $3, updated_at = NOW()
                    WHERE event_id = $4
                """, retry_count, retry_time, error_message, event_id)
                
            logger.info(f"Scheduled retry {retry_count} for event {event_id}")
        else:
            # Marcar como falha permanente
            async with self.db_pool.acquire() as conn:
                await conn.execute("""
                    UPDATE datahub_event_queue 
                    SET status = 'failed', error_message = $1, updated_at = NOW()
                    WHERE event_id = $2
                """, error_message, event_id)
                
            logger.error(f"Event {event_id} failed permanently after {retry_count} attempts")

    # ==================== EVENT HANDLERS ====================

    async def _handle_schema_change(self, event_context: EventContext):
        """Processa mudanças de esquema"""
        entity_urn = event_context.entity_urn
        schema_data = event_context.payload.get('aspect', {})
        
        logger.info(f"Processing schema change for {entity_urn}")
        
        # Verificar se existe contrato para este dataset
        contract = await self._get_contract_by_urn(entity_urn)
        
        if contract:
            # Analisar breaking changes
            breaking_changes = await self._analyze_breaking_changes(
                contract, schema_data
            )
            
            if breaking_changes:
                # Criar workflow de aprovação para breaking changes
                await self._create_approval_workflow(
                    entity_urn, 'schema_breaking_change', {
                        'contract_id': contract['id'],
                        'breaking_changes': breaking_changes,
                        'new_schema': schema_data
                    }
                )
                
                # Notificar stakeholders
                await self._notify_stakeholders(
                    entity_urn, 'breaking_change_detected', {
                        'changes': breaking_changes,
                        'contract_version': contract['version']
                    }
                )
            else:
                # Atualizar contrato automaticamente para mudanças não-breaking
                await self._update_contract_schema(contract['id'], schema_data)
        else:
            # Criar proposta de contrato para novo dataset
            await self._create_contract_proposal(entity_urn, schema_data)

    async def _handle_dataset_discovery(self, event_context: EventContext):
        """Processa descoberta de novos datasets"""
        entity_urn = event_context.entity_urn
        properties = event_context.payload.get('aspect', {})
        
        logger.info(f"Processing dataset discovery for {entity_urn}")
        
        # Verificar se já existe registro
        existing = await self._get_datahub_entity(entity_urn)
        if existing:
            return
        
        # Registrar nova entidade
        await self._register_datahub_entity(entity_urn, properties)
        
        # Iniciar profiling automático
        await self._schedule_automatic_profiling(entity_urn)
        
        # Executar detecção de PII
        await self._schedule_pii_detection(entity_urn)
        
        # Notificar data stewards
        await self._notify_stakeholders(
            entity_urn, 'new_dataset_discovered', {
                'platform': self._extract_platform(entity_urn),
                'name': properties.get('name', ''),
                'description': properties.get('description', '')
            }
        )

    async def _handle_ownership_change(self, event_context: EventContext):
        """Processa mudanças de ownership"""
        entity_urn = event_context.entity_urn
        ownership_data = event_context.payload.get('aspect', {})
        
        logger.info(f"Processing ownership change for {entity_urn}")
        
        # Atualizar ownership no contrato se existir
        contract = await self._get_contract_by_urn(entity_urn)
        if contract:
            await self._update_contract_ownership(contract['id'], ownership_data)
        
        # Atualizar permissões de acesso
        await self._update_access_permissions(entity_urn, ownership_data)

    async def _handle_tags_change(self, event_context: EventContext):
        """Processa mudanças de tags"""
        entity_urn = event_context.entity_urn
        tags_data = event_context.payload.get('aspect', {})
        
        logger.info(f"Processing tags change for {entity_urn}")
        
        # Extrair tags
        tags = []
        for tag in tags_data.get('tags', []):
            tags.append(tag.get('tag', ''))
        
        # Atualizar tags no contrato
        contract = await self._get_contract_by_urn(entity_urn)
        if contract:
            await self._update_contract_tags(contract['id'], tags)
        
        # Verificar tags de compliance
        compliance_tags = ['PII', 'SENSITIVE', 'CONFIDENTIAL', 'PUBLIC']
        relevant_tags = [tag for tag in tags if tag.upper() in compliance_tags]
        
        if relevant_tags:
            await self._update_compliance_classification(entity_urn, relevant_tags)

    async def _handle_lineage_update(self, event_context: EventContext):
        """Processa atualizações de linhagem"""
        entity_urn = event_context.entity_urn
        lineage_data = event_context.payload.get('aspect', {})
        
        logger.info(f"Processing lineage update for {entity_urn}")
        
        # Extrair upstream datasets
        upstream_urns = []
        for upstream in lineage_data.get('upstreams', []):
            upstream_urns.append(upstream.get('dataset', ''))
        
        # Atualizar linhagem no banco
        await self._update_lineage_relationships(entity_urn, upstream_urns)
        
        # Propagar mudanças de qualidade através da linhagem
        await self._propagate_quality_impact(entity_urn, upstream_urns)

    async def _handle_access_event(self, event_context: EventContext):
        """Processa eventos de acesso"""
        entity_urn = event_context.entity_urn
        access_data = event_context.payload
        
        # Registrar métricas de uso
        await self._record_usage_metrics(entity_urn, access_data)
        
        # Verificar políticas de acesso
        await self._validate_access_policies(entity_urn, access_data)

    async def _handle_quality_update(self, event_context: EventContext):
        """Processa atualizações de qualidade"""
        entity_urn = event_context.entity_urn
        quality_data = event_context.payload
        
        logger.info(f"Processing quality update for {entity_urn}")
        
        # Atualizar scores de qualidade
        await self._update_quality_scores(entity_urn, quality_data)
        
        # Verificar SLAs de qualidade
        await self._check_quality_slas(entity_urn, quality_data)

    async def _handle_compliance_update(self, event_context: EventContext):
        """Processa atualizações de compliance"""
        entity_urn = event_context.entity_urn
        compliance_data = event_context.payload
        
        logger.info(f"Processing compliance update for {entity_urn}")
        
        # Atualizar status de compliance
        await self._update_compliance_status(entity_urn, compliance_data)
        
        # Gerar relatórios se necessário
        await self._generate_compliance_reports(entity_urn, compliance_data)

    # ==================== UTILITY METHODS ====================

    async def _retry_worker(self):
        """Worker que processa retries de eventos"""
        while self.running:
            try:
                # Buscar eventos para retry
                async with self.db_pool.acquire() as conn:
                    rows = await conn.fetch("""
                        UPDATE datahub_event_queue 
                        SET status = 'pending', retry_after = NULL
                        WHERE status = 'pending' AND retry_after IS NOT NULL 
                              AND retry_after <= NOW()
                        RETURNING event_id
                    """)
                
                if rows:
                    logger.info(f"Requeued {len(rows)} events for retry")
                
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                logger.error(f"Error in retry worker: {e}")
                await asyncio.sleep(60)

    async def _cleanup_worker(self):
        """Worker que limpa eventos antigos"""
        while self.running:
            try:
                # Limpar eventos concluídos há mais de 7 dias
                cutoff_date = datetime.now() - timedelta(days=7)
                
                async with self.db_pool.acquire() as conn:
                    result = await conn.execute("""
                        DELETE FROM datahub_event_queue 
                        WHERE status IN ('completed', 'failed') 
                              AND updated_at < $1
                    """, cutoff_date)
                
                if result != "DELETE 0":
                    logger.info(f"Cleaned up old events: {result}")
                
                await asyncio.sleep(3600)  # Run every hour
                
            except Exception as e:
                logger.error(f"Error in cleanup worker: {e}")
                await asyncio.sleep(3600)

    # Placeholder methods for integration with other components
    async def _get_contract_by_urn(self, entity_urn: str) -> Optional[Dict[str, Any]]:
        """Obtém contrato por URN - implementar integração"""
        pass

    async def _analyze_breaking_changes(self, contract: Dict, schema_data: Dict) -> List[str]:
        """Analisa breaking changes - implementar lógica"""
        return []

    async def _create_approval_workflow(self, entity_urn: str, workflow_type: str, data: Dict):
        """Cria workflow de aprovação - implementar integração"""
        pass

    async def _notify_stakeholders(self, entity_urn: str, event_type: str, data: Dict):
        """Notifica stakeholders - implementar integração"""
        pass

    async def _get_datahub_entity(self, entity_urn: str) -> Optional[Dict]:
        """Verifica se entidade já existe"""
        async with self.db_pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT * FROM datahub_entities WHERE datahub_urn = $1
            """, entity_urn)
            return dict(row) if row else None

    async def _register_datahub_entity(self, entity_urn: str, properties: Dict):
        """Registra nova entidade do DataHub"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO datahub_entities 
                (datahub_urn, entity_type, platform, name, metadata_json)
                VALUES ($1, $2, $3, $4, $5)
            """, 
                entity_urn,
                'dataset',  # Assumindo dataset por padrão
                self._extract_platform(entity_urn),
                properties.get('name', ''),
                json.dumps(properties)
            )

    def _extract_platform(self, entity_urn: str) -> str:
        """Extrai plataforma do URN"""
        # Exemplo: urn:li:dataset:(urn:li:dataPlatform:databricks,schema.table,PROD)
        try:
            parts = entity_urn.split(':')
            if len(parts) >= 6:
                return parts[5]
        except:
            pass
        return 'unknown'

    async def _schedule_automatic_profiling(self, entity_urn: str):
        """Agenda profiling automático"""
        # Implementar integração com quality orchestrator
        pass

    async def _schedule_pii_detection(self, entity_urn: str):
        """Agenda detecção de PII"""
        # Implementar integração com privacy engine
        pass


if __name__ == "__main__":
    # Exemplo de uso
    import asyncio
    import os
    
    async def main():
        logging.basicConfig(level=logging.INFO)
        
        # Configurar banco
        db_pool = await asyncpg.create_pool(
            host=os.getenv('DB_HOST', 'localhost'),
            port=os.getenv('DB_PORT', 5432),
            user=os.getenv('DB_USER', 'postgres'),
            password=os.getenv('DB_PASSWORD', ''),
            database=os.getenv('DB_NAME', 'governance')
        )
        
        # Configurar Kafka
        kafka_config = {
            'bootstrap_servers': os.getenv('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092').split(',')
        }
        
        # Criar e iniciar processador
        processor = DataHubEventProcessor(db_pool, kafka_config)
        
        try:
            await processor.start()
        except KeyboardInterrupt:
            logger.info("Shutting down...")
        finally:
            await processor.stop()
            await db_pool.close()
    
    asyncio.run(main())

