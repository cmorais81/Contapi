#!/bin/bash

# Data Governance Platform with DataHub Integration
# Installation Script

set -e

echo "🚀 Iniciando instalação da Plataforma de Governança de Dados com DataHub"
echo "=================================================================="

# Verificar pré-requisitos
echo "📋 Verificando pré-requisitos..."

# Verificar Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker não encontrado. Por favor, instale o Docker primeiro."
    exit 1
fi

# Verificar Docker Compose
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose não encontrado. Por favor, instale o Docker Compose primeiro."
    exit 1
fi

# Verificar Python 3.13+
if ! command -v python3.13 &> /dev/null; then
    echo "⚠️  Python 3.13 não encontrado. Tentando usar python3..."
    if ! command -v python3 &> /dev/null; then
        echo "❌ Python 3 não encontrado. Por favor, instale Python 3.13+."
        exit 1
    fi
    PYTHON_CMD="python3"
else
    PYTHON_CMD="python3.13"
fi

echo "✅ Pré-requisitos verificados"

# Criar diretórios necessários
echo "📁 Criando estrutura de diretórios..."
mkdir -p logs config data backups

# Configurar permissões
chmod +x scripts/*.sh

# Criar arquivo .env se não existir
if [ ! -f .env ]; then
    echo "⚙️  Criando arquivo de configuração .env..."
    cp config/.env.example .env
    echo "📝 Por favor, edite o arquivo .env com suas configurações específicas"
fi

# Instalar dependências Python (opcional para desenvolvimento local)
read -p "🐍 Deseja instalar dependências Python para desenvolvimento local? (y/n): " install_python
if [[ $install_python =~ ^[Yy]$ ]]; then
    echo "📦 Instalando dependências Python..."
    $PYTHON_CMD -m venv venv
    source venv/bin/activate
    pip install --upgrade pip
    pip install -r requirements.txt
    echo "✅ Dependências Python instaladas"
fi

# Construir imagens Docker
echo "🐳 Construindo imagens Docker..."
docker-compose build

# Inicializar banco de dados
echo "🗄️  Inicializando banco de dados..."
docker-compose up -d postgres
sleep 10
docker-compose exec postgres psql -U governance -d governance -f /docker-entrypoint-initdb.d/init_db.sql

# Executar migrações
echo "🔄 Executando migrações de banco de dados..."
docker-compose run --rm governance-api alembic upgrade head

# Iniciar serviços
echo "🚀 Iniciando todos os serviços..."
docker-compose up -d

# Aguardar serviços ficarem prontos
echo "⏳ Aguardando serviços ficarem prontos..."
sleep 30

# Verificar saúde dos serviços
echo "🏥 Verificando saúde dos serviços..."

# Verificar DataHub GMS
if curl -f http://localhost:8080/health > /dev/null 2>&1; then
    echo "✅ DataHub GMS está funcionando"
else
    echo "⚠️  DataHub GMS ainda não está pronto"
fi

# Verificar DataHub Frontend
if curl -f http://localhost:9002 > /dev/null 2>&1; then
    echo "✅ DataHub Frontend está funcionando"
else
    echo "⚠️  DataHub Frontend ainda não está pronto"
fi

# Verificar Governance API
if curl -f http://localhost:8000/health > /dev/null 2>&1; then
    echo "✅ Governance API está funcionando"
else
    echo "⚠️  Governance API ainda não está pronto"
fi

echo ""
echo "🎉 Instalação concluída!"
echo "=================================================================="
echo ""
echo "📊 URLs dos Serviços:"
echo "   • DataHub Frontend: http://localhost:9002"
echo "   • DataHub GMS API: http://localhost:8080"
echo "   • Governance API: http://localhost:8000"
echo "   • Governance API Docs: http://localhost:8000/api/v1/docs"
echo "   • Prometheus: http://localhost:9090"
echo "   • Grafana: http://localhost:3000 (admin/admin)"
echo ""
echo "📚 Próximos passos:"
echo "   1. Acesse o DataHub Frontend em http://localhost:9002"
echo "   2. Configure suas fontes de dados no DataHub"
echo "   3. Acesse a API de Governança em http://localhost:8000/api/v1/docs"
echo "   4. Configure políticas de qualidade e privacidade"
echo ""
echo "📖 Para mais informações, consulte a documentação em docs/"
echo ""
echo "🔧 Para parar os serviços: docker-compose down"
echo "🔄 Para reiniciar: docker-compose restart"
echo "📋 Para ver logs: docker-compose logs -f [service-name]"

