"""
Contract Version model.
"""

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, String, Text
from app.models.base import GUID
from sqlalchemy.orm import relationship

from app.models.base import BaseModel
from app.models.mixins import AuditMixin


class ContractVersion(BaseModel, AuditMixin):
    """
    Contract Version model.
    
    Versioning of contracts with support for multiple active versions.
    """

    __tablename__ = "contract_versions"

    # Foreign key to contract
    contract_id = Column(
        GUID(),
        ForeignKey("data_contracts.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
        doc="Reference to parent contract"
    )

    # Version information
    version_number = Column(
        String(50),
        nullable=False,
        doc="Version number (semver: 1.0.0)"
    )

    version_description = Column(
        Text,
        doc="Description of changes in this version"
    )

    schema_version = Column(
        String(50),
        doc="Data schema version"
    )

    is_breaking_change = Column(
        Boolean,
        default=False,
        doc="Indicates if it's a breaking change"
    )

    # Modern format integration
    delta_lake_enabled = Column(
        Boolean,
        default=True,
        doc="Delta Lake support enabled"
    )

    iceberg_enabled = Column(
        Boolean,
        default=False,
        doc="Apache Iceberg support enabled"
    )

    # Status
    version_status = Column(
        String(50),
        default="draft",
        index=True,
        doc="Status: draft, active, deprecated, archived"
    )

    # Relationships
    contract = relationship(
        "DataContract",
        back_populates="versions"
    )

    def __repr__(self) -> str:
        return f"<ContractVersion(version={self.version_number}, status={self.version_status})>"

