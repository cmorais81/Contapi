"""
DataHub Integration Module
==========================

Este módulo fornece integração completa com LinkedIn DataHub para a plataforma
de governança de dados. Inclui conectores, processadores de eventos e 
sincronização de qualidade.

Componentes principais:
- DataHubConnector: Conectividade principal com DataHub
- DataHubEventProcessor: Processamento de eventos em tempo real
- DataHubQualitySync: Sincronização de métricas de qualidade

Exemplo de uso:
    from datahub_integration import DataHubConnector, DataHubEventProcessor
    
    # Criar connector
    connector = DataHubConnector(config, db_pool)
    
    # Sincronizar dataset
    await connector.sync_dataset_to_datahub(dataset_urn, contract_data)
"""

from .datahub_connector import (
    DataHubConnector,
    DataHubConfig,
    QualityScore,
    ComplianceStatus,
    DataHubConnectorFactory
)

from .datahub_event_processor import (
    DataHubEventProcessor,
    EventType,
    EventPriority,
    ProcessingRule,
    EventContext
)

from .datahub_quality_sync import (
    DataHubQualitySync,
    QualityLevel,
    QualityDimension,
    QualityRule,
    QualityExecution,
    DatasetQualityProfile
)

__version__ = "1.0.0"
__author__ = "Manus AI"
__email__ = "support@manus.ai"

__all__ = [
    # DataHub Connector
    "DataHubConnector",
    "DataHubConfig", 
    "QualityScore",
    "ComplianceStatus",
    "DataHubConnectorFactory",
    
    # Event Processor
    "DataHubEventProcessor",
    "EventType",
    "EventPriority", 
    "ProcessingRule",
    "EventContext",
    
    # Quality Sync
    "DataHubQualitySync",
    "QualityLevel",
    "QualityDimension",
    "QualityRule",
    "QualityExecution",
    "DatasetQualityProfile"
]

