#!/usr/bin/env python3
"""
DataHub Connector - Integração principal com DataHub
Responsável por sincronização bidirecional de metadados e eventos
"""

import asyncio
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass
from urllib.parse import urljoin

import aiohttp
import asyncpg
from kafka import KafkaConsumer, KafkaProducer
from kafka.errors import KafkaError

# DataHub SDK imports
from datahub.emitter.mce_builder import make_data_platform_urn, make_dataset_urn
from datahub.emitter.rest_emitter import DatahubRestEmitter
from datahub.metadata.com.linkedin.pegasus2avro.dataset import (
    DatasetProperties, DatasetSnapshot
)
from datahub.metadata.com.linkedin.pegasus2avro.schema import (
    SchemaMetadata, SchemaField, SchemaFieldDataType
)
from datahub.metadata.com.linkedin.pegasus2avro.common import Status
from datahub.metadata.schema_classes import MetadataChangeEventClass

logger = logging.getLogger(__name__)

@dataclass
class DataHubConfig:
    """Configuração para conexão com DataHub"""
    server_url: str
    token: str
    kafka_bootstrap_servers: List[str]
    kafka_schema_registry_url: str
    gms_url: str
    frontend_url: str

@dataclass
class QualityScore:
    """Estrutura para scores de qualidade"""
    overall: float
    completeness: float
    uniqueness: float
    validity: float
    consistency: float
    accuracy: float
    last_calculated: datetime

@dataclass
class ComplianceStatus:
    """Status de compliance para um dataset"""
    gdpr_compliant: bool
    lgpd_compliant: bool
    ccpa_compliant: bool
    pii_fields_count: int
    masking_applied: bool
    retention_policy_defined: bool
    last_audit: Optional[datetime]

class DataHubConnector:
    """Conector principal para integração com DataHub"""
    
    def __init__(self, config: DataHubConfig, db_pool: asyncpg.Pool):
        self.config = config
        self.db_pool = db_pool
        self.emitter = DatahubRestEmitter(config.server_url, config.token)
        self.session: Optional[aiohttp.ClientSession] = None
        self.kafka_producer: Optional[KafkaProducer] = None
        self.kafka_consumer: Optional[KafkaConsumer] = None
        
    async def __aenter__(self):
        """Context manager entry"""
        self.session = aiohttp.ClientSession()
        self.kafka_producer = KafkaProducer(
            bootstrap_servers=self.config.kafka_bootstrap_servers,
            value_serializer=lambda v: json.dumps(v).encode('utf-8')
        )
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit"""
        if self.session:
            await self.session.close()
        if self.kafka_producer:
            self.kafka_producer.close()
        if self.kafka_consumer:
            self.kafka_consumer.close()

    # ==================== METADATA SYNCHRONIZATION ====================
    
    async def sync_dataset_to_datahub(self, dataset_urn: str, contract_data: Dict[str, Any]) -> bool:
        """
        Sincroniza metadados de contrato para DataHub
        
        Args:
            dataset_urn: URN do dataset no DataHub
            contract_data: Dados do contrato de dados
            
        Returns:
            bool: True se sincronização foi bem-sucedida
        """
        try:
            # Preparar propriedades do dataset
            custom_properties = {
                'contract_version': str(contract_data.get('version', '1.0')),
                'contract_status': contract_data.get('status', 'active'),
                'data_owner': contract_data.get('owner', ''),
                'business_domain': contract_data.get('domain', ''),
                'criticality': contract_data.get('criticality', 'medium'),
                'last_updated': datetime.now().isoformat()
            }
            
            # Adicionar scores de qualidade se disponíveis
            if 'quality_scores' in contract_data:
                quality = contract_data['quality_scores']
                custom_properties.update({
                    'quality_overall': str(quality.get('overall', 0)),
                    'quality_completeness': str(quality.get('completeness', 0)),
                    'quality_uniqueness': str(quality.get('uniqueness', 0)),
                    'quality_validity': str(quality.get('validity', 0))
                })
            
            # Adicionar informações de compliance
            if 'compliance_status' in contract_data:
                compliance = contract_data['compliance_status']
                custom_properties.update({
                    'gdpr_compliant': str(compliance.get('gdpr_compliant', False)),
                    'lgpd_compliant': str(compliance.get('lgpd_compliant', False)),
                    'pii_detected': str(compliance.get('pii_fields_count', 0) > 0),
                    'masking_applied': str(compliance.get('masking_applied', False))
                })
            
            # Criar propriedades do dataset
            dataset_properties = DatasetProperties(
                description=contract_data.get('description', ''),
                customProperties=custom_properties,
                tags=contract_data.get('tags', [])
            )
            
            # Emitir mudança de metadados
            mce = MetadataChangeEventClass(
                proposedSnapshot=DatasetSnapshot(
                    urn=dataset_urn,
                    aspects=[dataset_properties]
                )
            )
            
            self.emitter.emit_mce(mce)
            
            # Registrar sincronização no banco
            await self._log_sync_operation(
                dataset_urn, 'outbound', 'update', 'success', contract_data
            )
            
            logger.info(f"Successfully synced contract data to DataHub for {dataset_urn}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to sync dataset to DataHub: {e}")
            await self._log_sync_operation(
                dataset_urn, 'outbound', 'update', 'failed', 
                contract_data, str(e)
            )
            return False

    async def get_dataset_from_datahub(self, dataset_urn: str) -> Optional[Dict[str, Any]]:
        """
        Obtém metadados de dataset do DataHub
        
        Args:
            dataset_urn: URN do dataset no DataHub
            
        Returns:
            Dict com metadados do dataset ou None se não encontrado
        """
        try:
            # Usar GraphQL API para obter metadados completos
            query = """
            query getDataset($urn: String!) {
                dataset(urn: $urn) {
                    urn
                    name
                    description
                    platform {
                        name
                    }
                    schemaMetadata {
                        fields {
                            fieldPath
                            type
                            nativeDataType
                            description
                        }
                    }
                    properties {
                        customProperties {
                            key
                            value
                        }
                    }
                    ownership {
                        owners {
                            owner {
                                ... on CorpUser {
                                    username
                                }
                            }
                            type
                        }
                    }
                    tags {
                        tags {
                            tag {
                                name
                            }
                        }
                    }
                }
            }
            """
            
            variables = {"urn": dataset_urn}
            
            async with self.session.post(
                urljoin(self.config.server_url, '/api/graphql'),
                json={"query": query, "variables": variables},
                headers={"Authorization": f"Bearer {self.config.token}"}
            ) as response:
                if response.status == 200:
                    data = await response.json()
                    dataset = data.get('data', {}).get('dataset')
                    
                    if dataset:
                        # Transformar dados do DataHub para formato interno
                        return self._transform_datahub_dataset(dataset)
                    
                logger.warning(f"Dataset not found in DataHub: {dataset_urn}")
                return None
                
        except Exception as e:
            logger.error(f"Failed to get dataset from DataHub: {e}")
            return None

    def _transform_datahub_dataset(self, datahub_dataset: Dict[str, Any]) -> Dict[str, Any]:
        """Transforma dados do DataHub para formato interno"""
        
        # Extrair propriedades customizadas
        custom_props = {}
        if datahub_dataset.get('properties', {}).get('customProperties'):
            for prop in datahub_dataset['properties']['customProperties']:
                custom_props[prop['key']] = prop['value']
        
        # Extrair esquema
        schema_fields = []
        if datahub_dataset.get('schemaMetadata', {}).get('fields'):
            for field in datahub_dataset['schemaMetadata']['fields']:
                schema_fields.append({
                    'name': field['fieldPath'],
                    'type': field['type'],
                    'native_type': field.get('nativeDataType', ''),
                    'description': field.get('description', '')
                })
        
        # Extrair ownership
        owners = []
        if datahub_dataset.get('ownership', {}).get('owners'):
            for owner in datahub_dataset['ownership']['owners']:
                if owner.get('owner', {}).get('username'):
                    owners.append({
                        'username': owner['owner']['username'],
                        'type': owner.get('type', 'DATAOWNER')
                    })
        
        # Extrair tags
        tags = []
        if datahub_dataset.get('tags', {}).get('tags'):
            for tag in datahub_dataset['tags']['tags']:
                tags.append(tag['tag']['name'])
        
        return {
            'urn': datahub_dataset['urn'],
            'name': datahub_dataset.get('name', ''),
            'description': datahub_dataset.get('description', ''),
            'platform': datahub_dataset.get('platform', {}).get('name', ''),
            'schema_fields': schema_fields,
            'custom_properties': custom_props,
            'owners': owners,
            'tags': tags
        }

    # ==================== QUALITY SCORE PUBLISHING ====================
    
    async def publish_quality_scores(self, dataset_urn: str, scores: QualityScore) -> bool:
        """
        Publica scores de qualidade para DataHub
        
        Args:
            dataset_urn: URN do dataset
            scores: Scores de qualidade calculados
            
        Returns:
            bool: True se publicação foi bem-sucedida
        """
        try:
            # Preparar metadados de qualidade
            quality_properties = {
                'quality_overall_score': str(round(scores.overall, 2)),
                'quality_completeness_score': str(round(scores.completeness, 2)),
                'quality_uniqueness_score': str(round(scores.uniqueness, 2)),
                'quality_validity_score': str(round(scores.validity, 2)),
                'quality_consistency_score': str(round(scores.consistency, 2)),
                'quality_accuracy_score': str(round(scores.accuracy, 2)),
                'quality_last_calculated': scores.last_calculated.isoformat(),
                'quality_status': self._get_quality_status(scores.overall)
            }
            
            # Atualizar propriedades customizadas
            await self._update_custom_properties(dataset_urn, quality_properties)
            
            # Salvar no banco local para histórico
            await self._save_quality_scores(dataset_urn, scores)
            
            # Publicar evento de atualização de qualidade
            await self._publish_quality_event(dataset_urn, scores)
            
            logger.info(f"Published quality scores for {dataset_urn}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to publish quality scores: {e}")
            return False

    async def publish_compliance_status(self, dataset_urn: str, status: ComplianceStatus) -> bool:
        """
        Publica status de compliance para DataHub
        
        Args:
            dataset_urn: URN do dataset
            status: Status de compliance
            
        Returns:
            bool: True se publicação foi bem-sucedida
        """
        try:
            compliance_properties = {
                'compliance_gdpr_status': str(status.gdpr_compliant),
                'compliance_lgpd_status': str(status.lgpd_compliant),
                'compliance_ccpa_status': str(status.ccpa_compliant),
                'compliance_pii_fields': str(status.pii_fields_count),
                'compliance_masking_applied': str(status.masking_applied),
                'compliance_retention_defined': str(status.retention_policy_defined),
                'compliance_last_audit': status.last_audit.isoformat() if status.last_audit else '',
                'compliance_overall_status': self._get_compliance_status(status)
            }
            
            await self._update_custom_properties(dataset_urn, compliance_properties)
            
            # Adicionar tags de compliance
            compliance_tags = []
            if status.gdpr_compliant:
                compliance_tags.append('GDPR_COMPLIANT')
            if status.lgpd_compliant:
                compliance_tags.append('LGPD_COMPLIANT')
            if status.pii_fields_count > 0:
                compliance_tags.append('CONTAINS_PII')
            if status.masking_applied:
                compliance_tags.append('MASKING_APPLIED')
                
            await self._add_tags(dataset_urn, compliance_tags)
            
            logger.info(f"Published compliance status for {dataset_urn}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to publish compliance status: {e}")
            return False

    # ==================== EVENT PROCESSING ====================
    
    async def start_event_consumer(self, callback: Callable[[Dict[str, Any]], None]):
        """
        Inicia consumer de eventos do DataHub
        
        Args:
            callback: Função para processar eventos recebidos
        """
        try:
            self.kafka_consumer = KafkaConsumer(
                'MetadataChangeEvent_v4',
                'MetadataAuditEvent_v4',
                bootstrap_servers=self.config.kafka_bootstrap_servers,
                value_deserializer=lambda m: json.loads(m.decode('utf-8')),
                group_id='governance_platform_consumer'
            )
            
            logger.info("Started DataHub event consumer")
            
            for message in self.kafka_consumer:
                try:
                    event_data = message.value
                    await self._process_datahub_event(event_data, callback)
                    
                except Exception as e:
                    logger.error(f"Error processing DataHub event: {e}")
                    
        except Exception as e:
            logger.error(f"Failed to start event consumer: {e}")

    async def _process_datahub_event(self, event: Dict[str, Any], callback: Callable):
        """Processa eventos recebidos do DataHub"""
        
        event_type = event.get('auditHeader', {}).get('server', {}).get('instance')
        entity_urn = event.get('entityUrn', '')
        aspect_name = event.get('aspectName', '')
        
        logger.debug(f"Processing DataHub event: {aspect_name} for {entity_urn}")
        
        # Processar diferentes tipos de eventos
        if aspect_name == 'schemaMetadata':
            await self._handle_schema_change_event(entity_urn, event)
        elif aspect_name == 'datasetProperties':
            await self._handle_properties_change_event(entity_urn, event)
        elif aspect_name == 'ownership':
            await self._handle_ownership_change_event(entity_urn, event)
        elif aspect_name == 'globalTags':
            await self._handle_tags_change_event(entity_urn, event)
            
        # Chamar callback customizado
        if callback:
            await callback(event)

    async def _handle_schema_change_event(self, entity_urn: str, event: Dict[str, Any]):
        """Processa mudanças de esquema"""
        try:
            # Detectar breaking changes
            schema_data = event.get('aspect', {})
            
            # Verificar se existe contrato para este dataset
            contract = await self._get_contract_by_urn(entity_urn)
            if contract:
                # Analisar impacto da mudança
                breaking_changes = await self._detect_breaking_changes(
                    contract['schema'], schema_data
                )
                
                if breaking_changes:
                    # Notificar stakeholders sobre breaking changes
                    await self._notify_breaking_changes(entity_urn, breaking_changes)
                    
                # Atualizar contrato com novo esquema
                await self._update_contract_schema(contract['id'], schema_data)
                
            else:
                # Criar proposta de contrato para novo dataset
                await self._create_contract_proposal(entity_urn, schema_data)
                
        except Exception as e:
            logger.error(f"Error handling schema change event: {e}")

    # ==================== UTILITY METHODS ====================
    
    async def _update_custom_properties(self, dataset_urn: str, properties: Dict[str, str]):
        """Atualiza propriedades customizadas no DataHub"""
        try:
            # Obter propriedades existentes
            existing_dataset = await self.get_dataset_from_datahub(dataset_urn)
            existing_props = existing_dataset.get('custom_properties', {}) if existing_dataset else {}
            
            # Merge com novas propriedades
            updated_props = {**existing_props, **properties}
            
            # Criar dataset properties
            dataset_properties = DatasetProperties(
                customProperties=updated_props
            )
            
            # Emitir mudança
            mce = MetadataChangeEventClass(
                proposedSnapshot=DatasetSnapshot(
                    urn=dataset_urn,
                    aspects=[dataset_properties]
                )
            )
            
            self.emitter.emit_mce(mce)
            
        except Exception as e:
            logger.error(f"Failed to update custom properties: {e}")

    async def _add_tags(self, dataset_urn: str, tags: List[str]):
        """Adiciona tags ao dataset no DataHub"""
        # Implementação para adicionar tags via DataHub API
        pass

    def _get_quality_status(self, overall_score: float) -> str:
        """Determina status de qualidade baseado no score"""
        if overall_score >= 90:
            return "EXCELLENT"
        elif overall_score >= 75:
            return "GOOD"
        elif overall_score >= 60:
            return "FAIR"
        else:
            return "POOR"

    def _get_compliance_status(self, status: ComplianceStatus) -> str:
        """Determina status geral de compliance"""
        if status.gdpr_compliant and status.lgpd_compliant and status.retention_policy_defined:
            return "COMPLIANT"
        elif status.pii_fields_count > 0 and not status.masking_applied:
            return "AT_RISK"
        else:
            return "PARTIAL"

    async def _log_sync_operation(self, entity_urn: str, sync_type: str, 
                                 operation: str, status: str, payload: Dict[str, Any], 
                                 error_message: str = None):
        """Registra operação de sincronização no banco"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO datahub_sync_log 
                (entity_urn, sync_type, operation, status, error_message, payload)
                VALUES ($1, $2, $3, $4, $5, $6)
            """, entity_urn, sync_type, operation, status, error_message, json.dumps(payload))

    async def _save_quality_scores(self, entity_urn: str, scores: QualityScore):
        """Salva scores de qualidade no banco local"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO datahub_quality_scores 
                (entity_urn, overall_score, completeness_score, uniqueness_score, 
                 validity_score, consistency_score, accuracy_score, last_calculated)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                ON CONFLICT (entity_urn) DO UPDATE SET
                    overall_score = EXCLUDED.overall_score,
                    completeness_score = EXCLUDED.completeness_score,
                    uniqueness_score = EXCLUDED.uniqueness_score,
                    validity_score = EXCLUDED.validity_score,
                    consistency_score = EXCLUDED.consistency_score,
                    accuracy_score = EXCLUDED.accuracy_score,
                    last_calculated = EXCLUDED.last_calculated,
                    updated_at = NOW()
            """, entity_urn, scores.overall, scores.completeness, scores.uniqueness,
                scores.validity, scores.consistency, scores.accuracy, scores.last_calculated)

    async def _publish_quality_event(self, dataset_urn: str, scores: QualityScore):
        """Publica evento de atualização de qualidade"""
        event = {
            'event_type': 'quality_score_updated',
            'dataset_urn': dataset_urn,
            'scores': {
                'overall': scores.overall,
                'completeness': scores.completeness,
                'uniqueness': scores.uniqueness,
                'validity': scores.validity,
                'consistency': scores.consistency,
                'accuracy': scores.accuracy
            },
            'timestamp': scores.last_calculated.isoformat()
        }
        
        if self.kafka_producer:
            self.kafka_producer.send('governance_quality_events', event)

    async def _get_contract_by_urn(self, entity_urn: str) -> Optional[Dict[str, Any]]:
        """Obtém contrato associado ao URN do DataHub"""
        async with self.db_pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT dc.* FROM data_contracts dc
                JOIN datahub_entities de ON dc.external_id = de.datahub_urn
                WHERE de.datahub_urn = $1
            """, entity_urn)
            
            return dict(row) if row else None

    async def _detect_breaking_changes(self, old_schema: Dict, new_schema: Dict) -> List[str]:
        """Detecta breaking changes entre esquemas"""
        breaking_changes = []
        
        # Implementar lógica de detecção de breaking changes
        # - Campos removidos
        # - Tipos de dados alterados
        # - Constraints adicionadas
        
        return breaking_changes

    async def _notify_breaking_changes(self, entity_urn: str, changes: List[str]):
        """Notifica stakeholders sobre breaking changes"""
        # Implementar notificação via email, Slack, etc.
        pass

    async def _update_contract_schema(self, contract_id: str, schema_data: Dict):
        """Atualiza esquema do contrato"""
        # Implementar atualização do esquema no contrato
        pass

    async def _create_contract_proposal(self, entity_urn: str, schema_data: Dict):
        """Cria proposta de contrato para novo dataset"""
        # Implementar criação automática de proposta de contrato
        pass


# ==================== FACTORY E CONFIGURAÇÃO ====================

class DataHubConnectorFactory:
    """Factory para criar instâncias do DataHub Connector"""
    
    @staticmethod
    def create_from_config(config_dict: Dict[str, Any], db_pool: asyncpg.Pool) -> DataHubConnector:
        """Cria connector a partir de dicionário de configuração"""
        config = DataHubConfig(
            server_url=config_dict['datahub_server_url'],
            token=config_dict['datahub_token'],
            kafka_bootstrap_servers=config_dict['kafka_bootstrap_servers'],
            kafka_schema_registry_url=config_dict['kafka_schema_registry_url'],
            gms_url=config_dict['datahub_gms_url'],
            frontend_url=config_dict['datahub_frontend_url']
        )
        
        return DataHubConnector(config, db_pool)

    @staticmethod
    def create_from_env(db_pool: asyncpg.Pool) -> DataHubConnector:
        """Cria connector a partir de variáveis de ambiente"""
        import os
        
        config = DataHubConfig(
            server_url=os.getenv('DATAHUB_SERVER_URL', 'http://localhost:8080'),
            token=os.getenv('DATAHUB_TOKEN', ''),
            kafka_bootstrap_servers=os.getenv('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092').split(','),
            kafka_schema_registry_url=os.getenv('KAFKA_SCHEMA_REGISTRY_URL', 'http://localhost:8081'),
            gms_url=os.getenv('DATAHUB_GMS_URL', 'http://localhost:8080'),
            frontend_url=os.getenv('DATAHUB_FRONTEND_URL', 'http://localhost:9002')
        )
        
        return DataHubConnector(config, db_pool)


if __name__ == "__main__":
    # Exemplo de uso
    import asyncio
    import os
    
    async def main():
        # Configurar logging
        logging.basicConfig(level=logging.INFO)
        
        # Criar pool de conexão com banco
        db_pool = await asyncpg.create_pool(
            host=os.getenv('DB_HOST', 'localhost'),
            port=os.getenv('DB_PORT', 5432),
            user=os.getenv('DB_USER', 'postgres'),
            password=os.getenv('DB_PASSWORD', ''),
            database=os.getenv('DB_NAME', 'governance')
        )
        
        # Criar connector
        connector = DataHubConnectorFactory.create_from_env(db_pool)
        
        async with connector:
            # Exemplo: sincronizar dataset
            dataset_urn = "urn:li:dataset:(urn:li:dataPlatform:databricks,schema.table,PROD)"
            contract_data = {
                'version': '1.0',
                'status': 'active',
                'owner': 'data-team@company.com',
                'domain': 'customer',
                'description': 'Customer profile data',
                'quality_scores': {
                    'overall': 85.5,
                    'completeness': 90.0,
                    'uniqueness': 95.0,
                    'validity': 80.0
                }
            }
            
            success = await connector.sync_dataset_to_datahub(dataset_urn, contract_data)
            print(f"Sync result: {success}")
        
        await db_pool.close()
    
    asyncio.run(main())

