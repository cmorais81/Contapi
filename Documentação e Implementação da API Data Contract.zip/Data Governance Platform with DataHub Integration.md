# Data Governance Platform with DataHub Integration

Uma plataforma completa de governança de dados com integração nativa ao LinkedIn DataHub, focada em qualidade de dados, detecção de PII, mascaramento e compliance regulatório.

## 🎯 Visão Geral

Esta plataforma combina as capacidades de descoberta e catalogação do DataHub com funcionalidades avançadas de governança, incluindo:

- **Qualidade de Dados**: Monitoramento automático com 6 dimensões de qualidade
- **Detecção de PII**: Identificação automática usando ML e análise semântica  
- **Mascaramento**: Múltiplas técnicas de anonimização e proteção
- **Contratos de Dados**: Acordos formais sobre estrutura e qualidade
- **Compliance**: Automação para GDPR, LGPD, CCPA e outras regulamentações
- **Linhagem Avançada**: Propagação de impacto e análise de dependências

## 🏗️ Arquitetura

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   DataHub UI    │    │ Governance UI   │    │   Grafana       │
│   (Port 9002)   │    │   (Port 8000)   │    │   (Port 3000)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   DataHub GMS   │◄──►│ Governance API  │◄──►│  Prometheus     │
│   (Port 8080)   │    │                 │    │   (Port 9090)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │
┌─────────────────┐    ┌─────────────────┐
│     Kafka       │◄──►│   PostgreSQL    │
│   (Port 9092)   │    │   (Port 5432)   │
└─────────────────┘    └─────────────────┘
         │
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│ Elasticsearch   │    │     Neo4j       │    │     Redis       │
│   (Port 9200)   │    │   (Port 7474)   │    │   (Port 6379)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🚀 Instalação Rápida

### Pré-requisitos

- Docker 20.10+
- Docker Compose 2.0+
- Python 3.13+ (opcional, para desenvolvimento)
- 8GB RAM mínimo
- 20GB espaço em disco

### Instalação Automática

```bash
# Clonar ou extrair o projeto
cd data-governance-platform-datahub-complete

# Executar script de instalação
chmod +x scripts/install.sh
./scripts/install.sh
```

### Instalação Manual

```bash
# 1. Configurar ambiente
cp config/.env.example .env
# Editar .env com suas configurações

# 2. Construir e iniciar serviços
docker-compose build
docker-compose up -d

# 3. Aguardar inicialização (2-3 minutos)
docker-compose logs -f governance-api

# 4. Verificar saúde dos serviços
curl http://localhost:8000/health
curl http://localhost:8080/health
```

## 📊 Acesso aos Serviços

| Serviço | URL | Credenciais |
|---------|-----|-------------|
| **DataHub Frontend** | http://localhost:9002 | - |
| **Governance API** | http://localhost:8000 | - |
| **API Documentation** | http://localhost:8000/api/v1/docs | - |
| **Grafana** | http://localhost:3000 | admin/admin |
| **Prometheus** | http://localhost:9090 | - |
| **Neo4j Browser** | http://localhost:7474 | neo4j/datahub |

## 🔧 Configuração

### Variáveis de Ambiente

Principais configurações no arquivo `.env`:

```bash
# Database
DB_HOST=postgres
DB_NAME=governance
DB_USER=governance
DB_PASSWORD=governance123

# DataHub
DATAHUB_SERVER_URL=http://datahub-gms:8080
DATAHUB_TOKEN=your-datahub-token

# Security
SECRET_KEY=your-secret-key-change-this
JWT_SECRET_KEY=your-jwt-secret

# Features
ENABLE_PII_DETECTION=true
ENABLE_QUALITY_MONITORING=true
ENABLE_MASKING=true
```

### Configuração do DataHub

1. Acesse http://localhost:9002
2. Configure suas fontes de dados
3. Execute ingestion para popular metadados
4. A plataforma de governança sincronizará automaticamente

## 📚 Documentação

### Estrutura de Documentação

```
docs/
├── documentacao_completa_datahub.md    # Documentação técnica completa
├── api/                                # Documentação da API
├── integration/                        # Guias de integração
├── deployment/                         # Guias de deployment
└── examples/                          # Exemplos de uso
```

### Guias Principais

- **[Documentação Técnica Completa](docs/documentacao_completa_datahub.md)**: Arquitetura, implementação e operação
- **[API Reference](http://localhost:8000/api/v1/docs)**: Documentação interativa da API
- **[Integration Guide](docs/integration/)**: Como integrar com sistemas existentes
- **[Deployment Guide](docs/deployment/)**: Deployment em produção

## 🔍 Funcionalidades Principais

### 1. Qualidade de Dados

```python
# Exemplo: Configurar regra de qualidade
from datahub_integration import DataHubQualitySync

quality_sync = DataHubQualitySync(config, db_pool)

# Criar regra de completude
rule = {
    "name": "customer_email_completeness",
    "dataset_urn": "urn:li:dataset:(urn:li:dataPlatform:postgres,customers,PROD)",
    "column": "email",
    "dimension": "completeness",
    "threshold": 0.95
}

await quality_sync.create_quality_rule(rule)
```

### 2. Detecção de PII

```python
# Exemplo: Detectar PII em dataset
from datahub_integration import DataHubConnector

connector = DataHubConnector(config, db_pool)

# Executar detecção de PII
pii_results = await connector.detect_pii_in_dataset(
    dataset_urn="urn:li:dataset:(urn:li:dataPlatform:postgres,customers,PROD)"
)

# Aplicar tags de PII no DataHub
await connector.apply_pii_tags(dataset_urn, pii_results)
```

### 3. Mascaramento de Dados

```python
# Exemplo: Configurar política de mascaramento
masking_policy = {
    "name": "customer_data_masking",
    "dataset_urn": "urn:li:dataset:(urn:li:dataPlatform:postgres,customers,PROD)",
    "rules": [
        {
            "column": "email",
            "technique": "tokenization",
            "context": ["analytics", "reporting"]
        },
        {
            "column": "phone",
            "technique": "deterministic_masking",
            "context": ["development", "testing"]
        }
    ]
}

await connector.create_masking_policy(masking_policy)
```

### 4. Contratos de Dados

```python
# Exemplo: Criar contrato de dados
contract = {
    "dataset_urn": "urn:li:dataset:(urn:li:dataPlatform:postgres,orders,PROD)",
    "version": "1.0.0",
    "schema_definition": {...},
    "quality_slas": {
        "completeness": 0.99,
        "uniqueness": 1.0,
        "validity": 0.95
    },
    "privacy_classification": "SENSITIVE",
    "retention_policy": "7_YEARS"
}

await connector.create_data_contract(contract)
```

## 🔄 Operação

### Comandos Úteis

```bash
# Ver logs de todos os serviços
docker-compose logs -f

# Ver logs de serviço específico
docker-compose logs -f governance-api

# Reiniciar serviço específico
docker-compose restart governance-api

# Executar migrações de banco
docker-compose exec governance-api alembic upgrade head

# Backup do banco de dados
docker-compose exec postgres pg_dump -U governance governance > backup.sql

# Monitorar recursos
docker stats
```

### Monitoramento

- **Prometheus**: Métricas de sistema e aplicação
- **Grafana**: Dashboards visuais e alertas
- **Logs**: Centralizados via Docker Compose
- **Health Checks**: Endpoints de saúde em todos os serviços

## 🧪 Testes

### Executar Testes

```bash
# Testes unitários
docker-compose exec governance-api pytest tests/unit/

# Testes de integração
docker-compose exec governance-api pytest tests/integration/

# Testes end-to-end
docker-compose exec governance-api pytest tests/e2e/

# Cobertura de testes
docker-compose exec governance-api pytest --cov=app tests/
```

### Testes de Carga

```bash
# Instalar ferramentas de teste
pip install locust

# Executar testes de carga
locust -f tests/load/locustfile.py --host=http://localhost:8000
```

## 🚀 Deployment em Produção

### Kubernetes

```bash
# Aplicar manifests Kubernetes
kubectl apply -f k8s/

# Verificar status
kubectl get pods -n data-governance
```

### Docker Swarm

```bash
# Inicializar swarm
docker swarm init

# Deploy stack
docker stack deploy -c docker-compose.prod.yml governance-stack
```

## 🤝 Contribuição

### Estrutura do Projeto

```
data-governance-platform-datahub-complete/
├── app/                        # Código principal da API
├── datahub_integration/        # Módulos de integração DataHub
├── docs/                       # Documentação
├── scripts/                    # Scripts de instalação e manutenção
├── config/                     # Arquivos de configuração
├── tests/                      # Testes automatizados
├── k8s/                       # Manifests Kubernetes
├── docker-compose.yml         # Configuração Docker Compose
├── Dockerfile                 # Imagem Docker
├── requirements.txt           # Dependências Python
└── README.md                  # Este arquivo
```

### Guidelines de Desenvolvimento

1. **Código**: Seguir PEP 8 e usar type hints
2. **Testes**: Cobertura mínima de 80%
3. **Documentação**: Documentar todas as APIs públicas
4. **Commits**: Usar conventional commits
5. **PRs**: Incluir testes e documentação

## 📞 Suporte

### Recursos de Ajuda

- **Documentação**: [docs/](docs/)
- **Issues**: Reportar problemas via GitHub Issues
- **Discussions**: Discussões da comunidade
- **Wiki**: Base de conhecimento

### Troubleshooting

#### Problemas Comuns

1. **Serviços não iniciam**: Verificar logs com `docker-compose logs`
2. **Conectividade DataHub**: Verificar configuração de rede
3. **Performance lenta**: Aumentar recursos Docker
4. **Erros de permissão**: Verificar volumes e usuários

#### Logs Importantes

```bash
# Logs da API de Governança
docker-compose logs governance-api

# Logs do DataHub GMS
docker-compose logs datahub-gms

# Logs do processador de eventos
docker-compose logs datahub-event-processor
```

## 📄 Licença

Este projeto está licenciado sob a Licença MIT. Veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🙏 Agradecimentos

- **LinkedIn DataHub**: Pela excelente plataforma de metadados
- **FastAPI**: Pelo framework web moderno e rápido
- **Comunidade Open Source**: Por todas as bibliotecas utilizadas

---

**Desenvolvido por**: Manus AI  
**Versão**: 1.0.0  
**Data**: Janeiro 2025

