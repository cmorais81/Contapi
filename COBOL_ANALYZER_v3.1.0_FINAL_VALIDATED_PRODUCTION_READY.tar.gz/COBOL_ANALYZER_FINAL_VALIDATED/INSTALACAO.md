# Guia de Instalação - COBOL Analyzer v3.1.0

## 🎯 Pré-requisitos

### Sistema Operacional
- ✅ Linux (Ubuntu 20.04+, RHEL 8+, CentOS 8+)
- ✅ Windows 10/11 (com WSL2 recomendado)
- ✅ macOS 11+ (Intel/Apple Silicon)

### Software Necessário
- **Python 3.11+** (obrigatório)
- **pip3** (gerenciador de pacotes Python)
- **4GB RAM** mínimo (8GB recomendado)
- **2GB espaço livre** em disco
- **Conexão internet** (para provedores de IA)

### Verificação de Pré-requisitos
```bash
# Verificar versão do Python
python3 --version  # Deve ser 3.11+

# Verificar pip
pip3 --version

# Verificar espaço em disco
df -h

# Verificar memória
free -h
```

## 📦 Métodos de Instalação

### Método 1: Instalação via pip (Recomendado)
```bash
# 1. Extrair o pacote
cd COBOL_ANALYZER_FINAL_VALIDATED
cd cobol-analyzer-v3.1.0

# 2. Instalar em modo desenvolvimento
pip3 install -e .

# 3. Verificar instalação
python3 -c "import cobol_to_docs; print('Instalação bem-sucedida!')"
```

### Método 2: Instalação manual
```bash
# 1. Instalar dependências
cd cobol-analyzer-v3.1.0
pip3 install -r requirements.txt

# 2. Instalar o pacote
python3 setup.py install

# 3. Verificar instalação
python3 -c "import cobol_to_docs; print('Instalação bem-sucedida!')"
```

### Método 3: Ambiente virtual (Isolado)
```bash
# 1. Criar ambiente virtual
python3 -m venv cobol-analyzer-env

# 2. Ativar ambiente
source cobol-analyzer-env/bin/activate  # Linux/macOS
# ou
cobol-analyzer-env\Scripts\activate     # Windows

# 3. Instalar
cd cobol-analyzer-v3.1.0
pip install -e .

# 4. Verificar
python -c "import cobol_to_docs; print('Instalação bem-sucedida!')"
```

## 🔧 Configuração Inicial

### 1. Inicializar Projeto
```bash
# Criar diretório de trabalho
mkdir meu-projeto-cobol
cd meu-projeto-cobol

# Inicializar estrutura
python /caminho/para/cobol-analyzer-v3.1.0/cobol_to_docs/runner/cobol_to_docs.py --init
```

### 2. Verificar Status do Sistema
```bash
python /caminho/para/cobol-analyzer-v3.1.0/cobol_to_docs/runner/main.py --status
```

**Saída esperada:**
```
=== STATUS DO SISTEMA COBOL ANALYZER ===
Providers configurados: 7
  - luzia, openai, github_copilot, enhanced_mock, bedrock, gemini, claude
Sistema RAG: Disponível
Diretório config: OK
Sistema pronto para uso!
```

## 🔑 Configuração de Credenciais

### Provedores Suportados

#### 1. OpenAI (GPT-4, GPT-3.5)
```bash
export OPENAI_API_KEY="sk-..."
```

#### 2. Anthropic (Claude)
```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

#### 3. AWS Bedrock
```bash
export AWS_ACCESS_KEY_ID="AKIA..."
export AWS_SECRET_ACCESS_KEY="..."
export AWS_DEFAULT_REGION="us-east-1"
```

#### 4. Google Gemini
```bash
export GOOGLE_API_KEY="AIza..."
```

#### 5. GitHub Copilot
```bash
export GITHUB_TOKEN="ghp_..."
```

#### 6. LuzIA (Santander)
```bash
export LUZIA_CLIENT_ID="..."
export LUZIA_CLIENT_SECRET="..."
```

### Configuração Permanente
```bash
# Adicionar ao ~/.bashrc ou ~/.zshrc
echo 'export OPENAI_API_KEY="sua_chave"' >> ~/.bashrc
echo 'export ANTHROPIC_API_KEY="sua_chave"' >> ~/.bashrc

# Recarregar configuração
source ~/.bashrc
```

## 🧪 Teste de Instalação

### Teste Básico
```bash
# 1. Criar arquivo de teste
echo "       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTE-INSTALL.
       PROCEDURE DIVISION.
       DISPLAY 'Hello World'.
       STOP RUN." > teste.cbl

# 2. Criar lista de fontes
echo "teste.cbl" > fontes.txt

# 3. Executar análise
python /caminho/para/cobol-analyzer-v3.1.0/cobol_to_docs/runner/main.py --fontes fontes.txt --models enhanced_mock
```

### Teste com Arquivos Reais
```bash
# Usar arquivos de exemplo inclusos
cd ../testes/arquivos-exemplo
echo "fontes.txt" > lista_fontes.txt

python /caminho/para/cobol-analyzer-v3.1.0/cobol_to_docs/runner/main.py --fontes lista_fontes.txt --models enhanced_mock
```

### Teste de Múltiplos Modelos
```bash
# Testar com múltiplos provedores (se credenciais configuradas)
python /caminho/para/cobol-analyzer-v3.1.0/cobol_to_docs/runner/main.py --fontes fontes.txt --models enhanced_mock,gpt-4
```

## 🛠️ Configuração Avançada

### Personalizar Configurações
```bash
# Editar arquivo de configuração
nano config/config.yaml
```

**Exemplo de configuração personalizada:**
```yaml
# config/config.yaml
system:
  default_provider: "openai"
  max_tokens: 8192
  temperature: 0.1
  
encoding:
  primary: "utf-8"
  fallbacks: ["latin1", "cp1252", "iso-8859-1"]
  
output:
  format: "markdown"
  include_metadata: true
  
rag:
  enabled: true
  similarity_threshold: 0.7
```

### Configurar Logs
```bash
# Nível de log (DEBUG, INFO, WARNING, ERROR)
export COBOL_ANALYZER_LOG_LEVEL="INFO"

# Diretório de logs personalizado
export COBOL_ANALYZER_LOG_DIR="/var/log/cobol-analyzer"
```

## 🔍 Troubleshooting

### Problemas Comuns

#### 1. Erro de Importação
```bash
# Erro: ModuleNotFoundError: No module named 'cobol_to_docs'
# Solução: Reinstalar o pacote
pip3 uninstall cobol-to-docs
cd cobol-analyzer-v3.1.0
pip3 install -e .
```

#### 2. Erro de Permissão
```bash
# Erro: Permission denied
# Solução: Usar --user ou sudo
pip3 install --user -e .
# ou
sudo pip3 install -e .
```

#### 3. Dependências Não Encontradas
```bash
# Erro: No module named 'requests'
# Solução: Instalar dependências manualmente
pip3 install requests pyyaml openai anthropic boto3
```

#### 4. Erro de Encoding
```bash
# Erro: UnicodeDecodeError
# Solução: Verificar encoding do arquivo
file -i seu_arquivo.cbl
# Configurar encoding no config.yaml se necessário
```

#### 5. Credenciais Inválidas
```bash
# Erro: Authentication failed
# Solução: Verificar variáveis de ambiente
env | grep -E "OPENAI|ANTHROPIC|AWS"
# Verificar validade das chaves nos respectivos portais
```

### Diagnóstico Avançado

#### Verificar Logs
```bash
# Logs principais
tail -f logs/*.log

# Logs RAG
tail -f logs/rag_*.log

# Logs de erro
grep -i error logs/*.log
```

#### Modo Debug
```bash
# Executar com logs detalhados
export COBOL_ANALYZER_LOG_LEVEL="DEBUG"
python cobol_to_docs/runner/main.py --status
```

#### Teste de Conectividade
```bash
# Testar conexão com provedores
python3 -c "
import requests
try:
    r = requests.get('https://api.openai.com/v1/models', timeout=5)
    print('OpenAI: OK' if r.status_code == 401 else 'OpenAI: Erro')
except:
    print('OpenAI: Sem conexão')
"
```

## 📊 Validação da Instalação

### Checklist de Validação
- [ ] Python 3.11+ instalado
- [ ] Pacote cobol_to_docs importável
- [ ] Comando `--status` executa sem erro
- [ ] Pelo menos um provedor configurado
- [ ] Teste básico executa com sucesso
- [ ] Logs são gerados corretamente

### Script de Validação Automática
```bash
#!/bin/bash
# validate_installation.sh

echo "=== VALIDAÇÃO DA INSTALAÇÃO ==="

# 1. Verificar Python
python3 --version || { echo "❌ Python 3.11+ necessário"; exit 1; }

# 2. Verificar importação
python3 -c "import cobol_to_docs" || { echo "❌ Módulo não encontrado"; exit 1; }

# 3. Verificar status
python3 cobol_to_docs/runner/main.py --status || { echo "❌ Erro no status"; exit 1; }

# 4. Teste básico
echo "IDENTIFICATION DIVISION. PROGRAM-ID. TEST." > test.cbl
echo "test.cbl" > test_fontes.txt
python3 cobol_to_docs/runner/main.py --fontes test_fontes.txt --models enhanced_mock || { echo "❌ Teste falhou"; exit 1; }

echo "✅ INSTALAÇÃO VALIDADA COM SUCESSO!"
```

## 🚀 Próximos Passos

Após a instalação bem-sucedida:

1. **Ler documentação**: `documentacao/relatorios-validacao/`
2. **Executar exemplos**: `testes/arquivos-exemplo/`
3. **Configurar provedores**: Adicionar credenciais de IA
4. **Testar com seus arquivos**: Analisar código COBOL real
5. **Explorar funcionalidades**: RAG, múltiplos modelos, etc.

## 📞 Suporte

Para problemas de instalação:
1. Verificar logs em `logs/`
2. Consultar seção Troubleshooting
3. Executar script de validação
4. Verificar documentação técnica

---

**COBOL Analyzer v3.1.0** - Instalação validada e pronta para produção ✅
