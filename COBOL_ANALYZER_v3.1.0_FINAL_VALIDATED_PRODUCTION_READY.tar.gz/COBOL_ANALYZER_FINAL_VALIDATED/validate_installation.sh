#!/bin/bash

# COBOL Analyzer v3.1.0 - Script de Validação da Instalação
# Este script verifica se a instalação foi bem-sucedida

set -e  # Parar em caso de erro

echo "=================================================================="
echo "COBOL ANALYZER v3.1.0 - VALIDAÇÃO DA INSTALAÇÃO"
echo "=================================================================="
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✅ OK]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠️  WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[❌ ERRO]${NC} $1"
}

# Contadores
TESTS_TOTAL=0
TESTS_PASSED=0
TESTS_FAILED=0

# Função para executar teste
run_test() {
    local test_name="$1"
    local test_command="$2"
    
    TESTS_TOTAL=$((TESTS_TOTAL + 1))
    log_info "Teste $TESTS_TOTAL: $test_name"
    
    if eval "$test_command" >/dev/null 2>&1; then
        log_success "$test_name"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        log_error "$test_name"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

# Função para executar teste com output
run_test_with_output() {
    local test_name="$1"
    local test_command="$2"
    
    TESTS_TOTAL=$((TESTS_TOTAL + 1))
    log_info "Teste $TESTS_TOTAL: $test_name"
    
    local output
    if output=$(eval "$test_command" 2>&1); then
        log_success "$test_name"
        echo "   Output: $output"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    else
        log_error "$test_name"
        echo "   Erro: $output"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    fi
}

echo "1. VERIFICAÇÃO DE PRÉ-REQUISITOS"
echo "================================"

# Teste 1: Verificar Python
run_test_with_output "Python 3.11+ instalado" "python3 --version | grep -E 'Python 3\.(1[1-9]|[2-9][0-9])'"

# Teste 2: Verificar pip
run_test "pip3 disponível" "which pip3"

# Teste 3: Verificar espaço em disco (mínimo 1GB)
run_test "Espaço em disco suficiente" "[ \$(df . | tail -1 | awk '{print \$4}') -gt 1048576 ]"

echo ""
echo "2. VERIFICAÇÃO DA INSTALAÇÃO"
echo "============================"

# Teste 4: Verificar se o diretório existe
run_test "Diretório cobol-analyzer-v3.1.0 existe" "[ -d 'cobol-analyzer-v3.1.0' ]"

# Teste 5: Verificar estrutura de diretórios
run_test "Estrutura de diretórios correta" "[ -d 'cobol-analyzer-v3.1.0/cobol_to_docs' ] && [ -d 'cobol-analyzer-v3.1.0/tests' ]"

# Teste 6: Verificar arquivos principais
run_test "Arquivos principais existem" "[ -f 'cobol-analyzer-v3.1.0/cobol_to_docs/runner/main.py' ] && [ -f 'cobol-analyzer-v3.1.0/setup.py' ]"

echo ""
echo "3. VERIFICAÇÃO DE IMPORTAÇÃO"
echo "============================"

# Teste 7: Tentar importar o módulo
cd cobol-analyzer-v3.1.0
run_test "Módulo cobol_to_docs importável" "python3 -c 'import sys; sys.path.insert(0, \".\"); import cobol_to_docs'"

echo ""
echo "4. VERIFICAÇÃO FUNCIONAL"
echo "========================"

# Teste 8: Verificar comando --status
run_test "Comando --status executa" "python3 cobol_to_docs/runner/main.py --status"

# Teste 9: Verificar inicialização
run_test "Comando --init executa" "cd /tmp && python3 $(pwd)/cobol_to_docs/runner/cobol_to_docs.py --init"

echo ""
echo "5. TESTE DE ANÁLISE BÁSICA"
echo "=========================="

# Criar arquivo de teste
cat > /tmp/test_program.cbl << 'EOF'
       IDENTIFICATION DIVISION.
       PROGRAM-ID. TEST-VALIDATION.
       DATA DIVISION.
       01 COUNTER PIC 9(3) VALUE 0.
       PROCEDURE DIVISION.
       DISPLAY 'Teste de validação'.
       ADD 1 TO COUNTER.
       STOP RUN.
EOF

echo "test_program.cbl" > /tmp/test_fontes.txt

# Teste 10: Análise básica
cd /tmp
run_test "Análise básica funciona" "python3 $(pwd)/cobol-analyzer-v3.1.0/cobol_to_docs/runner/main.py --fontes test_fontes.txt --models enhanced_mock"

# Teste 11: Verificar arquivos gerados
run_test "Arquivos de saída gerados" "[ -f 'output/TEST-VALIDATION_analise_funcional.md' ]"

echo ""
echo "6. VERIFICAÇÃO DE CONFIGURAÇÃO"
echo "=============================="

cd $(pwd)/cobol-analyzer-v3.1.0

# Teste 12: Verificar arquivos de configuração
run_test "Arquivos de configuração existem" "[ -f 'cobol_to_docs/config/config.yaml' ] && [ -f 'cobol_to_docs/config/prompts_cadoc_deep_analysis.yaml' ]"

# Teste 13: Verificar base de conhecimento RAG
run_test "Base de conhecimento RAG existe" "[ -f 'cobol_to_docs/data/cobol_knowledge_base.json' ]"

echo ""
echo "7. TESTES UNITÁRIOS"
echo "==================="

# Teste 14: Executar testes unitários (se pytest disponível)
if command -v pytest >/dev/null 2>&1; then
    run_test "Testes unitários passam" "python3 -m pytest tests/ -v --tb=short"
else
    log_warning "pytest não encontrado - pulando testes unitários"
fi

echo ""
echo "8. VERIFICAÇÃO DE PROVEDORES"
echo "============================"

# Teste 15: Verificar se pelo menos um provedor está configurado
if python3 cobol_to_docs/runner/main.py --status 2>&1 | grep -q "Providers configurados: [1-9]"; then
    log_success "Pelo menos um provedor configurado"
    TESTS_PASSED=$((TESTS_PASSED + 1))
else
    log_warning "Nenhum provedor configurado (normal se credenciais não foram definidas)"
fi
TESTS_TOTAL=$((TESTS_TOTAL + 1))

echo ""
echo "9. TESTE COM ARQUIVOS REAIS"
echo "==========================="

# Teste 16: Verificar se arquivos de exemplo existem
if [ -f "../testes/arquivos-exemplo/fontes.txt" ]; then
    run_test "Arquivos de exemplo disponíveis" "[ -f '../testes/arquivos-exemplo/fontes.txt' ]"
    
    # Teste 17: Análise com arquivo real
    cd /tmp
    run_test "Análise com arquivo real" "python3 $(pwd)/cobol-analyzer-v3.1.0/cobol_to_docs/runner/main.py --fontes $(pwd)/cobol-analyzer-v3.1.0/../testes/arquivos-exemplo/fontes.txt --models enhanced_mock --output analise_real"
else
    log_warning "Arquivos de exemplo não encontrados - pulando teste com arquivos reais"
    TESTS_TOTAL=$((TESTS_TOTAL + 2))
fi

echo ""
echo "=================================================================="
echo "RESULTADO DA VALIDAÇÃO"
echo "=================================================================="

echo ""
echo "📊 ESTATÍSTICAS:"
echo "   Total de testes: $TESTS_TOTAL"
echo "   Testes passaram: $TESTS_PASSED"
echo "   Testes falharam: $TESTS_FAILED"

if [ $TESTS_FAILED -eq 0 ]; then
    echo ""
    log_success "🎉 VALIDAÇÃO COMPLETA - INSTALAÇÃO BEM-SUCEDIDA!"
    echo ""
    echo "✅ O COBOL Analyzer v3.1.0 está pronto para uso!"
    echo ""
    echo "📚 PRÓXIMOS PASSOS:"
    echo "   1. Configurar credenciais de IA (opcional)"
    echo "   2. Ler documentação em documentacao/"
    echo "   3. Testar com seus arquivos COBOL"
    echo "   4. Explorar funcionalidades avançadas"
    echo ""
    echo "🚀 COMANDOS ÚTEIS:"
    echo "   # Verificar status"
    echo "   python3 cobol_to_docs/runner/main.py --status"
    echo ""
    echo "   # Inicializar projeto"
    echo "   python3 cobol_to_docs/runner/cobol_to_docs.py --init"
    echo ""
    echo "   # Analisar programas"
    echo "   python3 cobol_to_docs/runner/main.py --fontes lista.txt --models enhanced_mock"
    echo ""
    exit 0
else
    echo ""
    log_error "❌ VALIDAÇÃO FALHOU - PROBLEMAS ENCONTRADOS!"
    echo ""
    echo "🔧 AÇÕES RECOMENDADAS:"
    echo "   1. Verificar pré-requisitos (Python 3.11+)"
    echo "   2. Reinstalar o pacote: pip3 install -e ."
    echo "   3. Verificar permissões de arquivo"
    echo "   4. Consultar INSTALACAO.md para troubleshooting"
    echo ""
    echo "📋 LOGS DE DIAGNÓSTICO:"
    echo "   - Verificar logs em logs/"
    echo "   - Executar com DEBUG: export COBOL_ANALYZER_LOG_LEVEL=DEBUG"
    echo ""
    exit 1
fi
