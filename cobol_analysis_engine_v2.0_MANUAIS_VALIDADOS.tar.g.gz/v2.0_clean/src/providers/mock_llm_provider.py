import logging

class MockLLMProvider:
    def __init__(self, config=None):
        self.logger = logging.getLogger(__name__)
        self.logger.info("Mock LLM Provider inicializado.")

    def generate_text(self, prompt: str) -> str:
        self.logger.info("Gerando texto com o Mock LLM Provider.")
        # Simula a resposta para o programa LHAN0542
        if "LHAN0542" in prompt:
            return """
```yaml
purpose: "Particionar o arquivo de entrada (LHS542E1) em múltiplos arquivos de saída (LHS542S1, LHS542S2, LHS542S3) com base no tipo de registro e em um limite de tamanho por arquivo."
business_rules:
  - "Se o tipo de registro (WS-TIPO-REGISTRO) for '01' ou '02', o registro é gravado no arquivo de saída LHS542S1."
  - "Se o tipo de registro for '03', o registro é gravado no arquivo de saída LHS542S2."
  - "Se o contador de registros para S1 (WS-CONT-S1) exceder o máximo (WS-MAX-REGISTROS), o arquivo S1DQ0705 é fechado e reaberto, zerando o contador."
  - "Se o contador de registros para S2 (WS-CONT-S2) exceder o máximo (WS-MAX-REGISTROS), o arquivo S2DQ0705 é fechado e reaberto, zerando o contador."
  - "Registros com tipo inválido (não numérico, espaços, ou diferente de '01', '02', '03') são rejeitados e uma mensagem é exibida."
data_flow: "O programa lê registros do arquivo de entrada E1DQ0705. Cada registro é validado. Com base no tipo de registro, ele é roteado para um dos dois arquivos de saída principais (S1DQ0705 ou S2DQ0705). Há uma lógica de particionamento que cria novos arquivos de saída quando o número de registros atinge um limite."
critical_logic_points:
  - "A lógica de particionamento dinâmico nas seções 2210-GRAVAR-S1 e 2220-GRAVAR-S2, que garante que os arquivos de saída não excedam um tamanho máximo."
  - "A validação de registro na seção 2100-VALIDAR-REGISTRO, que garante a integridade dos dados antes do processamento."
  - "A chamada para a sub-rotina 'WDRAM0082' na inicialização, que parece ser um ponto crítico para a alocação de recursos, e cujo fracasso leva a um término anormal."
```
"""
        return "purpose: 'Não foi possível determinar o propósito.'\nbusiness_rules: []\ndata_flow: ''\ncritical_logic_points: []"
