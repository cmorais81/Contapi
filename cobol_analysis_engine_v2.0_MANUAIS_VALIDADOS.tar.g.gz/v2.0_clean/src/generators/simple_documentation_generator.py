"""
Gerador de Documentação Simples - COBOL Analysis Engine v2.0
Foca no essencial: o que o programa faz, regras e particularidades
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import logging

class SimpleDocumentationGenerator:
    """Gerador de documentação simples e focada no essencial"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def generate_documentation(self, 
                             program_name: str,
                             cobol_code: str,
                             analysis_results: Dict[str, Any],
                             copybooks: Optional[Dict] = None,
                             prompt_history: Optional[List[Dict]] = None,
                             output_path: str = None) -> str:
        """Gera documentação simples e focada"""
        
        sections = []
        
        # Cabeçalho
        sections.append(self._generate_header(program_name))
        
        # O que o programa faz
        sections.append(self._generate_purpose_section(program_name, cobol_code, analysis_results))
        
        # Regras de negócio
        sections.append(self._generate_business_rules_section(analysis_results))
        
        # Particularidades
        sections.append(self._generate_particularities_section(analysis_results))
        
        # Arquivos e dados
        sections.append(self._generate_data_section(cobol_code, copybooks))
        
        # Prompts e respostas (se disponível)
        if prompt_history:
            sections.append(self._generate_prompts_section(prompt_history))
        
        documentation = "\n\n".join(sections)
        
        # Salvar se caminho fornecido
        if output_path:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(documentation)
            self.logger.info(f"Documentação salva em: {output_path}")
        
        return documentation
    
    def _generate_header(self, program_name: str) -> str:
        """Gera cabeçalho simples"""
        return f"""# Análise do Programa COBOL: {program_name}

**Data da Análise:** {datetime.now().strftime("%d/%m/%Y às %H:%M")}  
**Gerado por:** COBOL Analysis Engine v2.0 com LuzIA  

---"""
    
    def _generate_purpose_section(self, program_name: str, cobol_code: str, analysis_results: Dict) -> str:
        """Gera seção sobre o propósito do programa"""
        
        section = "## 🎯 O que este programa faz\n\n"
        
        # Tentar extrair objetivo dos comentários
        objective_from_code = self._extract_objective_from_comments(cobol_code)
        if objective_from_code:
            section += f"**Objetivo identificado no código:**\n{objective_from_code}\n\n"
        
        # Adicionar análise da IA se disponível
        ai_analysis = self._get_ai_purpose_analysis(analysis_results)
        if ai_analysis:
            section += f"**Explicação detalhada:**\n{ai_analysis}\n\n"
        
        # Fluxo básico
        basic_flow = self._extract_basic_flow(cobol_code)
        if basic_flow:
            section += f"**Fluxo de processamento:**\n{basic_flow}\n"
        
        return section
    
    def _generate_business_rules_section(self, analysis_results: Dict) -> str:
        """Gera seção de regras de negócio"""
        
        section = "## 📋 Regras de Negócio\n\n"
        
        # Buscar regras na análise da IA
        business_rules = self._extract_business_rules(analysis_results)
        
        if business_rules:
            for i, rule in enumerate(business_rules, 1):
                section += f"**{i}.** {rule}\n\n"
        else:
            section += "*Nenhuma regra de negócio específica foi identificada automaticamente.*\n\n"
        
        return section
    
    def _generate_particularities_section(self, analysis_results: Dict) -> str:
        """Gera seção de particularidades"""
        
        section = "## ⚠️ Particularidades e Pontos de Atenção\n\n"
        
        particularities = self._extract_particularities(analysis_results)
        
        if particularities:
            for particularity in particularities:
                section += f"- {particularity}\n"
            section += "\n"
        else:
            section += "*Nenhuma particularidade específica foi identificada.*\n\n"
        
        return section
    
    def _generate_data_section(self, cobol_code: str, copybooks: Optional[Dict]) -> str:
        """Gera seção de arquivos e dados"""
        
        section = "## 📁 Arquivos e Estruturas de Dados\n\n"
        
        # Extrair arquivos do código
        files = self._extract_files_from_code(cobol_code)
        if files:
            section += "**Arquivos processados:**\n"
            for file_info in files:
                section += f"- {file_info}\n"
            section += "\n"
        
        # Informações de copybooks
        if copybooks:
            section += "**Copybooks utilizados:**\n"
            for name, content in copybooks.items():
                description = self._get_copybook_description(content)
                section += f"- **{name}**: {description}\n"
            section += "\n"
        
        return section
    
    def _generate_prompts_section(self, prompt_history: List[Dict]) -> str:
        """Gera seção com prompts e respostas"""
        
        section = "## 🔍 Detalhes da Análise com IA\n\n"
        section += "*Esta seção mostra os prompts enviados para as IAs e as respostas originais recebidas.*\n\n"
        
        for i, entry in enumerate(prompt_history, 1):
            provider = entry.get('provider', 'IA').upper()
            prompt_type = entry.get('prompt_type', 'Análise Geral')
            success = entry.get('success', False)
            execution_time = entry.get('execution_time', 0)
            model = entry.get('model', 'N/A')
            
            # Status da análise
            status_icon = "✅" if success else "❌"
            section += f"### {status_icon} Análise {i}: {prompt_type}\n\n"
            
            # Informações da IA
            section += f"**Provedor:** {provider}  \n"
            section += f"**Modelo:** {model}  \n"
            section += f"**Tempo:** {execution_time:.2f}s  \n"
            section += f"**Status:** {'Sucesso' if success else 'Falha'}  \n\n"
            
            # Prompt enviado
            section += "**📤 Prompt enviado:**\n"
            prompt_text = entry.get('prompt', 'N/A')
            if len(prompt_text) > 1000:
                prompt_text = prompt_text[:1000] + "...\n[Prompt truncado - muito longo]"
            section += f"```\n{prompt_text}\n```\n\n"
            
            # Resposta recebida
            section += f"**📥 Resposta original do {provider}:**\n"
            response_text = entry.get('response', 'N/A')
            if len(response_text) > 2000:
                response_text = response_text[:2000] + "...\n[Resposta truncada - muito longa]"
            section += f"```\n{response_text}\n```\n\n"
            
            section += "---\n\n"
        
        # Resumo das análises
        total_analyses = len(prompt_history)
        successful_analyses = len([entry for entry in prompt_history if entry.get('success', False)])
        
        section += f"**📊 Resumo das Análises:**\n"
        section += f"- Total de análises: {total_analyses}\n"
        section += f"- Análises bem-sucedidas: {successful_analyses}\n"
        section += f"- Taxa de sucesso: {(successful_analyses/total_analyses*100):.1f}%\n\n"
        
        return section
    
    def _extract_objective_from_comments(self, cobol_code: str) -> str:
        """Extrai objetivo dos comentários do código"""
        
        lines = cobol_code.split('\n')
        objective_lines = []
        
        in_objective_section = False
        
        for line in lines:
            line_upper = line.upper().strip()
            
            # Procurar início da seção de objetivo
            if 'OBJETIVO' in line_upper and ('PROGRAMA' in line_upper or 'SYSTEM' in line_upper):
                in_objective_section = True
                continue
            
            # Se estamos na seção de objetivo
            if in_objective_section:
                # Parar se encontrar outra seção
                if line_upper.startswith('*') and ('VERSAO' in line_upper or 'AUTHOR' in line_upper or 'DATA' in line_upper):
                    break
                
                # Extrair texto do comentário
                if line.strip().startswith('*'):
                    text = line.strip()[1:].strip()
                    if text and not text.startswith('*'):
                        objective_lines.append(text)
        
        return ' '.join(objective_lines) if objective_lines else ""
    
    def _get_ai_purpose_analysis(self, analysis_results: Dict) -> str:
        """Extrai análise de propósito da IA"""
        
        # Buscar em diferentes estruturas de resposta
        for provider_result in analysis_results.get('providers', []):
            content = provider_result.get('content', '')
            if isinstance(content, str) and content:
                return content[:500] + "..." if len(content) > 500 else content
        
        return ""
    
    def _extract_basic_flow(self, cobol_code: str) -> str:
        """Extrai fluxo básico do programa"""
        
        lines = cobol_code.split('\n')
        flow_steps = []
        
        # Procurar seções da PROCEDURE DIVISION
        for line in lines:
            line_stripped = line.strip().upper()
            
            if line_stripped.endswith('SECTION.') and not line_stripped.startswith('*'):
                section_name = line_stripped.replace('SECTION.', '').strip()
                if section_name and section_name not in ['PROCEDURE', 'CONFIGURATION', 'INPUT-OUTPUT', 'FILE', 'WORKING-STORAGE']:
                    # Tentar interpretar o nome da seção
                    if 'INICIAL' in section_name or 'INIT' in section_name:
                        flow_steps.append("1. Inicialização")
                    elif 'PROCESS' in section_name or 'PRINCIPAL' in section_name:
                        flow_steps.append("2. Processamento principal")
                    elif 'FINAL' in section_name or 'FIM' in section_name:
                        flow_steps.append("3. Finalização")
                    else:
                        flow_steps.append(f"• {section_name.replace('-', ' ').title()}")
        
        return '\n'.join(flow_steps) if flow_steps else "Fluxo não identificado automaticamente"
    
    def _extract_business_rules(self, analysis_results: Dict) -> List[str]:
        """Extrai regras de negócio da análise"""
        
        rules = []
        
        # Buscar regras em diferentes estruturas
        for provider_result in analysis_results.get('providers', []):
            content = provider_result.get('content', '')
            
            if isinstance(content, str):
                # Procurar por padrões de regras
                lines = content.split('\n')
                for line in lines:
                    line_clean = line.strip()
                    if any(keyword in line_clean.lower() for keyword in ['regra', 'validação', 'critério', 'condição']):
                        if len(line_clean) > 10 and len(line_clean) < 200:
                            rules.append(line_clean)
        
        return rules[:5]  # Limitar a 5 regras principais
    
    def _extract_particularities(self, analysis_results: Dict) -> List[str]:
        """Extrai particularidades da análise"""
        
        particularities = []
        
        # Buscar particularidades em diferentes estruturas
        for provider_result in analysis_results.get('providers', []):
            content = provider_result.get('content', '')
            
            if isinstance(content, str):
                lines = content.split('\n')
                for line in lines:
                    line_clean = line.strip()
                    if any(keyword in line_clean.lower() for keyword in ['atenção', 'cuidado', 'importante', 'observação', 'particular']):
                        if len(line_clean) > 10 and len(line_clean) < 200:
                            particularities.append(line_clean)
        
        return particularities[:3]  # Limitar a 3 particularidades
    
    def _extract_files_from_code(self, cobol_code: str) -> List[str]:
        """Extrai informações de arquivos do código"""
        
        files = []
        lines = cobol_code.split('\n')
        
        for line in lines:
            line_upper = line.upper().strip()
            
            # Procurar por SELECT statements
            if line_upper.startswith('SELECT '):
                parts = line_upper.split()
                if len(parts) >= 2:
                    file_name = parts[1]
                    files.append(f"**{file_name}**: Arquivo de dados")
            
            # Procurar por FD statements
            elif line_upper.startswith('FD '):
                parts = line_upper.split()
                if len(parts) >= 2:
                    file_name = parts[1]
                    files.append(f"**{file_name}**: Definição de arquivo")
        
        return files
    
    def _get_copybook_description(self, content: str) -> str:
        """Gera descrição simples do copybook"""
        
        lines = content.split('\n')
        field_count = 0
        
        for line in lines:
            if any(level in line.strip() for level in ['01 ', '05 ', '10 ', '15 ', '20 ']):
                field_count += 1
        
        if field_count > 0:
            return f"Layout de dados com {field_count} campos"
        else:
            return "Copybook de configuração"
