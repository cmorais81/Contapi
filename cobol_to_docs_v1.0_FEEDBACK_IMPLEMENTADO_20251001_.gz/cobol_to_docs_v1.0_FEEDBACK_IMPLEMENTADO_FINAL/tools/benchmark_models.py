#!/usr/bin/env python3
"""
Utilitário para benchmark de múltiplos modelos LLM
Compara performance, qualidade e custos
"""

import os
import sys
import time
import json
import yaml
from datetime import datetime
from typing import Dict, List, Any

def load_config():
    """Carrega configuração do sistema"""
    config_path = "config/config.yaml"
    
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def get_luzia_models(config: Dict) -> List[str]:
    """Obtém lista de modelos LuzIA configurados"""
    luzia_models = config.get('providers', {}).get('luzia', {}).get('models', {})
    return [model_config.get('name') for model_config in luzia_models.values()]

def run_benchmark(models: List[str], test_program: str = "examples/fontes.txt"):
    """Executa benchmark com múltiplos modelos"""
    print("🏁 INICIANDO BENCHMARK DE MODELOS LLM")
    print("=" * 50)
    
    results = {}
    
    for i, model in enumerate(models, 1):
        print(f"\n🔄 TESTANDO MODELO {i}/{len(models)}: {model}")
        print("-" * 40)
        
        # Criar diretório específico para o teste
        output_dir = f"benchmark_output/test_{model.replace('-', '_').replace('/', '_')}"
        os.makedirs(output_dir, exist_ok=True)
        
        # Comando de teste
        cmd = f"python3 main.py --fontes {test_program} --model {model} --output {output_dir}"
        
        # Medir tempo de execução
        start_time = time.time()
        
        print(f"Executando: {cmd}")
        exit_code = os.system(cmd)
        
        execution_time = time.time() - start_time
        
        # Coletar resultados
        results[model] = {
            'execution_time': execution_time,
            'success': exit_code == 0,
            'output_dir': output_dir,
            'timestamp': datetime.now().isoformat()
        }
        
        if exit_code == 0:
            print(f"✅ Sucesso em {execution_time:.2f}s")
            
            # Tentar coletar estatísticas adicionais
            try:
                # Procurar por arquivos de saída
                output_files = []
                for root, dirs, files in os.walk(output_dir):
                    output_files.extend([os.path.join(root, f) for f in files if f.endswith('.md')])
                
                results[model]['output_files'] = len(output_files)
                
                # Verificar tamanho dos arquivos gerados
                total_size = sum(os.path.getsize(f) for f in output_files)
                results[model]['total_output_size'] = total_size
                
            except Exception as e:
                print(f"⚠️  Erro ao coletar estatísticas: {e}")
        else:
            print(f"❌ Falha (código: {exit_code})")
    
    return results

def generate_benchmark_report(results: Dict[str, Any]):
    """Gera relatório de benchmark"""
    print("\n" + "=" * 60)
    print("📊 RELATÓRIO DE BENCHMARK")
    print("=" * 60)
    
    successful_models = [model for model, data in results.items() if data['success']]
    failed_models = [model for model, data in results.items() if not data['success']]
    
    print(f"\n✅ MODELOS BEM-SUCEDIDOS: {len(successful_models)}")
    for model in successful_models:
        data = results[model]
        print(f"   • {model}: {data['execution_time']:.2f}s")
        if 'output_files' in data:
            print(f"     Arquivos gerados: {data['output_files']}")
            print(f"     Tamanho total: {data['total_output_size']:,} bytes")
    
    if failed_models:
        print(f"\n❌ MODELOS COM FALHA: {len(failed_models)}")
        for model in failed_models:
            print(f"   • {model}")
    
    # Ranking por performance
    if successful_models:
        print("\n🏆 RANKING POR VELOCIDADE:")
        sorted_models = sorted(
            [(model, results[model]['execution_time']) for model in successful_models],
            key=lambda x: x[1]
        )
        
        for i, (model, time_taken) in enumerate(sorted_models, 1):
            print(f"   {i}. {model}: {time_taken:.2f}s")
    
    # Salvar relatório detalhado
    report_file = f"benchmark_output/benchmark_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    os.makedirs("benchmark_output", exist_ok=True)
    
    with open(report_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    print(f"\n📄 Relatório detalhado salvo em: {report_file}")

def main():
    """Função principal"""
    print("🚀 BENCHMARK DE MODELOS LLM - COBOL to Docs v1.0")
    
    # Carregar configuração
    config = load_config()
    
    # Obter modelos LuzIA
    luzia_models = get_luzia_models(config)
    
    if not luzia_models:
        print("❌ Nenhum modelo LuzIA encontrado na configuração")
        sys.exit(1)
    
    print(f"\n📋 MODELOS PARA TESTE: {len(luzia_models)}")
    for i, model in enumerate(luzia_models, 1):
        print(f"   {i}. {model}")
    
    # Verificar arquivo de teste
    test_file = "examples/fontes.txt"
    if not os.path.exists(test_file):
        print(f"\n❌ Arquivo de teste não encontrado: {test_file}")
        print("Crie o arquivo ou especifique outro arquivo de fontes")
        sys.exit(1)
    
    print(f"\n📁 Arquivo de teste: {test_file}")
    
    # Confirmar execução
    confirm = input("\nIniciar benchmark? (s/N): ").strip().lower()
    if confirm not in ['s', 'sim', 'y', 'yes']:
        print("Benchmark cancelado")
        sys.exit(0)
    
    # Executar benchmark
    results = run_benchmark(luzia_models, test_file)
    
    # Gerar relatório
    generate_benchmark_report(results)

if __name__ == "__main__":
    main()
