#!/usr/bin/env python3
"""
Utilitário para seleção interativa de modelos LLM
"""

import sys
import os
import yaml
from typing import Dict, List

def load_config():
    """Carrega configuração do sistema"""
    config_path = "config/config.yaml"
    
    if not os.path.exists(config_path):
        print("Erro: Arquivo de configuração não encontrado")
        sys.exit(1)
    
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def display_available_models(config: Dict) -> Dict[str, Dict]:
    """Exibe modelos disponíveis e retorna mapeamento"""
    print("\n=== MODELOS LLM DISPONÍVEIS ===\n")
    
    models_info = {}
    counter = 1
    
    # Modelos LuzIA
    luzia_models = config.get('providers', {}).get('luzia', {}).get('models', {})
    if luzia_models:
        print("🚀 MODELOS LUZIA (Recomendados):")
        for model_key, model_config in luzia_models.items():
            model_name = model_config.get('name', model_key)
            description = model_config.get('description', 'Sem descrição')
            max_tokens = model_config.get('max_tokens', 'N/A')
            context_window = model_config.get('context_window', 'N/A')
            
            print(f"   {counter}. {model_name}")
            print(f"      Descrição: {description}")
            print(f"      Max Tokens: {max_tokens:,} | Context: {context_window:,}")
            print()
            
            models_info[str(counter)] = {
                'name': model_name,
                'provider': 'luzia',
                'config': model_config
            }
            counter += 1
    
    # Outros provedores
    other_providers = ['enhanced_mock', 'openai', 'bedrock', 'databricks']
    for provider in other_providers:
        provider_config = config.get('providers', {}).get(provider, {})
        if provider_config.get('enabled', False):
            models = provider_config.get('models', {})
            if models:
                print(f"🔧 MODELOS {provider.upper()}:")
                for model_key, model_config in models.items():
                    model_name = model_config.get('name', model_key)
                    max_tokens = model_config.get('max_tokens', 'N/A')
                    
                    print(f"   {counter}. {model_name} ({provider})")
                    print(f"      Max Tokens: {max_tokens}")
                    print()
                    
                    models_info[str(counter)] = {
                        'name': model_name,
                        'provider': provider,
                        'config': model_config
                    }
                    counter += 1
    
    return models_info

def select_model_interactive(models_info: Dict) -> str:
    """Seleção interativa de modelo"""
    while True:
        try:
            choice = input("\nEscolha um modelo (número) ou 'q' para sair: ").strip()
            
            if choice.lower() == 'q':
                print("Saindo...")
                sys.exit(0)
            
            if choice in models_info:
                selected = models_info[choice]
                model_name = selected['name']
                provider = selected['provider']
                
                print(f"\n✅ MODELO SELECIONADO:")
                print(f"   Nome: {model_name}")
                print(f"   Provider: {provider}")
                
                return model_name
            else:
                print("❌ Opção inválida. Tente novamente.")
                
        except KeyboardInterrupt:
            print("\n\nSaindo...")
            sys.exit(0)

def generate_command(model_name: str, fontes_file: str = None) -> str:
    """Gera comando para execução"""
    if not fontes_file:
        fontes_file = "examples/fontes.txt"
    
    return f"python3 main.py --fontes {fontes_file} --model {model_name}"

def main():
    """Função principal"""
    print("🤖 SELETOR DE MODELOS LLM - COBOL to Docs v1.0")
    print("=" * 50)
    
    # Carregar configuração
    config = load_config()
    
    # Exibir modelos disponíveis
    models_info = display_available_models(config)
    
    if not models_info:
        print("❌ Nenhum modelo disponível encontrado na configuração")
        sys.exit(1)
    
    # Seleção interativa
    selected_model = select_model_interactive(models_info)
    
    # Gerar comando
    print("\n🚀 COMANDO PARA EXECUÇÃO:")
    print("-" * 30)
    
    # Verificar se existe arquivo de fontes padrão
    default_fontes = "examples/fontes.txt"
    if os.path.exists(default_fontes):
        cmd = generate_command(selected_model, default_fontes)
        print(f"   {cmd}")
        print()
        
        execute = input("Executar agora? (s/N): ").strip().lower()
        if execute in ['s', 'sim', 'y', 'yes']:
            print("\n🔄 Executando análise...")
            os.system(cmd)
        else:
            print("\n📋 Comando copiado. Execute manualmente quando desejar.")
    else:
        cmd = generate_command(selected_model, "<seu_arquivo_fontes.txt>")
        print(f"   {cmd}")
        print("\n📝 Substitua <seu_arquivo_fontes.txt> pelo seu arquivo de fontes")

if __name__ == "__main__":
    main()
