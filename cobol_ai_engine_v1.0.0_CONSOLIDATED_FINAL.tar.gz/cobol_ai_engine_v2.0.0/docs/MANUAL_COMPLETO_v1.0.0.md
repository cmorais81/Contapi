# 📚 COBOL AI Engine v1.0.0 - Manual Completo

## 🎯 VISÃO GERAL

O **COBOL AI Engine v1.0.0** é uma ferramenta avançada de análise e documentação de programas COBOL que combina parsing interno com inteligência artificial para gerar documentação funcional detalhada.

### ✨ Principais Características
- **Análise Universal:** Funciona com qualquer programa COBOL (não apenas padrões específicos)
- **Documentação Funcional:** Gera especificações técnicas para reimplementação
- **Multi-LLM:** Suporte a OpenAI, GitHub Copilot, LuzIA e outros
- **Compatibilidade Total:** macOS, Linux, Windows com Python 3.11+

---

## 🚀 INSTALAÇÃO

### 📋 Pré-requisitos
- **Python 3.11+** (recomendado 3.11.5+)
- **macOS 12.0+** / **Linux** / **Windows 10+**
- **8GB RAM** mínimo (16GB recomendado)
- **2GB espaço livre** em disco

### 🍎 Instalação no macOS (Recomendada)

#### Método 1: Instalação Automática
```bash
# Extrair e instalar em um comando
tar -xzf cobol_ai_engine_v1.0.0.tar.gz
cd cobol_ai_engine_v2.0.0
./install_macos.sh
```

#### Método 2: Instalação Manual
```bash
# 1. Extrair
tar -xzf cobol_ai_engine_v1.0.0.tar.gz
cd cobol_ai_engine_v2.0.0

# 2. Criar ambiente virtual
python3.11 -m venv venv
source venv/bin/activate

# 3. Instalar dependências
pip install -r requirements_macos.txt

# 4. Verificar instalação
python check_macos_compatibility.py
```

### 🐧 Instalação no Linux
```bash
# 1. Extrair
tar -xzf cobol_ai_engine_v1.0.0.tar.gz
cd cobol_ai_engine_v2.0.0

# 2. Instalar Python 3.11+ (se necessário)
sudo apt update
sudo apt install python3.11 python3.11-venv python3.11-pip

# 3. Criar ambiente virtual
python3.11 -m venv venv
source venv/bin/activate

# 4. Instalar dependências
pip install -r requirements.txt
```

### 🪟 Instalação no Windows
```powershell
# 1. Extrair (usar 7-Zip ou WinRAR)
# 2. Abrir PowerShell como Administrador
cd cobol_ai_engine_v2.0.0

# 3. Criar ambiente virtual
python -m venv venv
venv\Scripts\activate

# 4. Instalar dependências
pip install -r requirements.txt
```

---

## 🎮 FORMAS DE EXECUÇÃO

### 1. 🚀 Demo Rápida (Recomendada para Primeiro Uso)

```bash
python main_demo.py
```

**O que faz:**
- Processa os primeiros 3 programas do arquivo `examples/fontes_teste.txt`
- Tempo de execução: 30-60 segundos
- Gera relatórios de demonstração
- Ideal para validar instalação

### 2. 📊 Análise Completa

```bash
python main.py examples/fontes.txt examples/BOOKS.txt
```

**O que faz:**
- Processa TODOS os programas do arquivo fontes.txt
- Resolve copybooks do BOOKS.txt
- Gera documentação funcional completa
- Tempo: 10-30 minutos (dependendo do tamanho)

### 3. 🎯 Análise com Modo de Demonstração

```bash
python main.py examples/fontes.txt examples/BOOKS.txt --demo-mode
```

**O que faz:**
- Processa apenas os primeiros 3 programas
- Ativa logging verboso automaticamente
- Ideal para testes rápidos

### 4. 🔧 Análise com Configuração Personalizada

```bash
python main.py examples/fontes.txt examples/BOOKS.txt --config config/config_personalizado.yaml
```

### 5. 🤖 Análise com Provedor LLM Específico

```bash
# Usando OpenAI
python main.py fontes.txt books.txt --provider openai --fallback-provider enhanced_mock

# Usando GitHub Copilot
python main.py fontes.txt books.txt --provider copilot

# Usando LuzIA
python main.py fontes.txt books.txt --provider luzia

# Usando Mock para testes
python main.py fontes.txt books.txt --provider enhanced_mock
```

### 6. 📋 Análise Filtrada

```bash
# Filtrar programas por padrão
python main.py fontes.txt books.txt --filter-pattern "LH.*"

# Excluir programas por padrão
python main.py fontes.txt books.txt --exclude-pattern "TEST.*"

# Limitar por número de linhas
python main.py fontes.txt books.txt --min-lines 100 --max-lines 5000

# Limitar número de programas
python main.py fontes.txt books.txt --max-programs 50
```

### 7. 🔍 Análise com Profundidade Específica

```bash
# Análise básica (mais rápida)
python main.py fontes.txt books.txt --analysis-depth basic

# Análise padrão
python main.py fontes.txt books.txt --analysis-depth standard

# Análise detalhada
python main.py fontes.txt books.txt --analysis-depth detailed

# Análise máxima (mais completa)
python main.py fontes.txt books.txt --analysis-depth maximum
```

### 8. 📄 Análise com Formato de Saída Específico

```bash
# Saída em Markdown (padrão)
python main.py fontes.txt books.txt --format markdown

# Saída em JSON
python main.py fontes.txt books.txt --format json

# Saída em HTML
python main.py fontes.txt books.txt --format html
```

### 9. 📊 Análise com Validação e Qualidade

```bash
# Com validação de sintaxe COBOL
python main.py fontes.txt books.txt --validate-syntax

# Com score mínimo de reimplementação
python main.py fontes.txt books.txt --min-score 70

# Combinando validações
python main.py fontes.txt books.txt --validate-syntax --min-score 60
```

### 10. 🔧 Análise com Controle de Logging

```bash
# Modo verboso
python main.py fontes.txt books.txt --verbose

# Modo silencioso
python main.py fontes.txt books.txt --quiet

# Nível de log específico
python main.py fontes.txt books.txt --log-level DEBUG

# Log em arquivo específico
python main.py fontes.txt books.txt --log-file minha_analise.log

# Sem log no console
python main.py fontes.txt books.txt --no-console-log --log-file analysis.log
```

## 🎛️ OPÇÕES DE LINHA DE COMANDO COMPLETAS

### Sintaxe Geral
```bash
python main.py <arquivo_fontes> <arquivo_books> [opções]
```

### 📋 Argumentos Obrigatórios
| Argumento | Descrição |
|-----------|-----------|
| `fontes_file` | Arquivo com lista de programas COBOL |
| `books_file` | Arquivo com copybooks |

### ⚙️ Opções Básicas
| Opção | Descrição | Padrão |
|-------|-----------|---------|
| `--output`, `-o` | Diretório de saída | `functional_analysis_results_v15` |
| `--config`, `-c` | Arquivo de configuração | `config/config.yaml` |
| `--help`, `-h` | Exibe ajuda | - |

### 🎯 Modos de Operação
| Opção | Descrição |
|-------|-----------|
| `--demo-mode` | Modo de demonstração (3 programas) |
| `--verbose`, `-v` | Logging detalhado |
| `--quiet`, `-q` | Modo silencioso (apenas erros) |

### 🤖 Controle de Provedores LLM
| Opção | Valores Possíveis | Descrição |
|-------|-------------------|-----------|
| `--provider` | `openai`, `copilot`, `luzia`, `enhanced_mock`, `mock` | Provedor LLM principal |
| `--fallback-provider` | `openai`, `copilot`, `luzia`, `enhanced_mock`, `mock` | Provedor de fallback |

### 🔍 Controle de Análise
| Opção | Valores/Tipo | Descrição |
|-------|--------------|-----------|
| `--max-programs` | Número inteiro | Máximo de programas a analisar |
| `--timeout` | Segundos | Timeout por programa |
| `--analysis-depth` | `basic`, `standard`, `detailed`, `maximum` | Profundidade da análise |

### 🎯 Filtros e Seleção
| Opção | Tipo | Descrição |
|-------|------|-----------|
| `--filter-pattern` | Regex | Filtra programas por padrão |
| `--exclude-pattern` | Regex | Exclui programas por padrão |
| `--min-lines` | Número | Mínimo de linhas por programa |
| `--max-lines` | Número | Máximo de linhas por programa |

### 📄 Controle de Saída
| Opção | Valores | Descrição |
|-------|---------|-----------|
| `--format` | `markdown`, `json`, `html`, `pdf` | Formato de saída |
| `--no-consolidate` | - | Não gera relatório consolidado |

### 📊 Controle de Logging
| Opção | Valores/Tipo | Descrição |
|-------|--------------|-----------|
| `--log-level` | `DEBUG`, `INFO`, `WARNING`, `ERROR` | Nível de logging |
| `--log-file` | Caminho | Arquivo de log personalizado |
| `--no-console-log` | - | Desabilita log no console |

### ✅ Validação e Qualidade
| Opção | Valores/Tipo | Descrição |
|-------|--------------|-----------|
| `--validate-syntax` | - | Valida sintaxe COBOL |
| `--min-score` | 0-100 | Score mínimo de reimplementação |

### 📝 Exemplos Práticos de Uso

#### Desenvolvimento Rápido
```bash
python main.py fontes.txt books.txt --demo-mode --provider enhanced_mock --format json --quiet
```

#### Produção Completa
```bash
python main.py fontes.txt books.txt --provider openai --analysis-depth maximum --validate-syntax --min-score 60
```

#### CI/CD Pipeline
```bash
python main.py fontes.txt books.txt --provider enhanced_mock --max-programs 100 --format json --quiet --log-file pipeline.log
```

#### Análise Filtrada
```bash
python main.py fontes.txt books.txt --filter-pattern "LH.*" --min-lines 50 --max-programs 50 --verbose
```

---

## ⚙️ CONFIGURAÇÃO

### 📄 Arquivo Principal: `config/config.yaml`

```yaml
# Configuração do COBOL AI Engine v1.0.0
analysis:
  max_programs: 1000          # Máximo de programas a processar
  timeout_per_program: 300    # Timeout por programa (segundos)
  enable_copybook_resolution: true
  
output:
  format: "markdown"          # markdown, json, html
  include_code_examples: true
  include_business_rules: true
  
providers:
  primary: "openai"          # openai, copilot, luzia, mock
  fallback: "enhanced_mock"
  
logging:
  level: "INFO"              # DEBUG, INFO, WARNING, ERROR
  file: "logs/analysis.log"
```

### 🤖 Configuração de LLMs

#### OpenAI (GPT-4):
```bash
export OPENAI_API_KEY="sua_chave_aqui"
```

#### GitHub Copilot:
```bash
export GITHUB_TOKEN="seu_token_aqui"
```

#### LuzIA (Corporativo):
```yaml
# Em config/config.yaml
providers:
  luzia:
    endpoint: "https://api.luzia.com/v1"
    model: "aws-claude-3-5-sonnet"
    api_key: "${LUZIA_API_KEY}"
```

---

## 📁 ESTRUTURA DE ARQUIVOS

### 📂 Entrada Esperada

#### `fontes.txt` - Lista de Programas COBOL
```
LHAN0542
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LHAN0542.
       ...
       END PROGRAM LHAN0542.

LHAN0705
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LHAN0705.
       ...
```

#### `BOOKS.txt` - Copybooks
```
MZTCM530
       01  REGISTRO-ENTRADA.
           05  TIPO-REGISTRO    PIC X(02).
           05  NUMERO-CONTA     PIC 9(13).
           ...
```

### 📂 Saída Gerada

```
results/
├── CONSOLIDATED_REPORT.md           # Relatório consolidado
├── LHAN0542/
│   ├── LHAN0542_FUNCTIONAL_DOCS.md # Documentação funcional
│   ├── LHAN0542_analysis_data.json # Dados estruturados
│   └── LHAN0542_code_examples/     # Exemplos de código
│       ├── java_implementation.java
│       └── python_implementation.py
└── logs/
    └── analysis.log                # Logs detalhados
```

---

## 📊 TIPOS DE ANÁLISE

### 1. 🏗️ Análise Estrutural
- **Divisões COBOL:** Identification, Environment, Data, Procedure
- **Seções:** File, Working-Storage, Linkage, Local-Storage
- **Hierarquia:** Níveis 01-88, grupos e campos elementares
- **Tipos de dados:** PIC X, 9, S9, COMP, COMP-3

### 2. 🧠 Análise de Lógica de Negócio
- **Estruturas de controle:** IF-ELSE, EVALUATE, PERFORM
- **Loops:** PERFORM UNTIL, PERFORM VARYING
- **Chamadas:** CALL, GOBACK, EXIT
- **Operações:** MOVE, ADD, SUBTRACT, MULTIPLY, DIVIDE

### 3. 📋 Análise de Arquivos
- **Definições:** FD, SELECT, ASSIGN
- **Operações:** OPEN, READ, WRITE, CLOSE
- **Organização:** SEQUENTIAL, INDEXED, RELATIVE
- **Acesso:** RANDOM, DYNAMIC, SEQUENTIAL

### 4. 🔍 Análise de Copybooks
- **Resolução:** COPY statements
- **Estruturas:** Layouts de registro
- **Relacionamentos:** Dependências entre copybooks

---

## 📈 INTERPRETAÇÃO DOS RESULTADOS

### 🎯 Score de Entendimento
- **90-100%:** Excelente - Programa totalmente compreendido
- **70-89%:** Bom - Maioria das funcionalidades identificadas
- **50-69%:** Médio - Estrutura básica compreendida
- **30-49%:** Baixo - Análise superficial
- **0-29%:** Crítico - Falha na análise

### 📊 Métricas de Qualidade
- **Completude:** % de elementos identificados
- **Precisão:** Qualidade da análise realizada
- **Prontidão:** Capacidade de reimplementação

### 🚨 Indicadores de Problemas
- **Score < 50%:** Programa complexo, requer análise manual
- **Muitos "Não identificado":** Padrões não reconhecidos
- **Código gerado genérico:** Lógica específica não capturada

---

## 🛠️ SOLUÇÃO DE PROBLEMAS

### ❌ Problemas Comuns

#### 1. Erro de Import
```bash
ModuleNotFoundError: No module named 'xyz'
```
**Solução:**
```bash
pip install -r requirements_macos.txt
export PYTHONPATH=./src
```

#### 2. Arquivo não encontrado
```bash
FileNotFoundError: [Errno 2] No such file or directory: 'examples/fontes.txt'
```
**Solução:**
```bash
# Verificar se está no diretório correto
pwd
ls examples/
```

#### 3. Timeout na análise
```bash
TimeoutError: Analysis timeout after 300 seconds
```
**Solução:**
```yaml
# Aumentar timeout em config/config.yaml
analysis:
  timeout_per_program: 600
```

#### 4. Memória insuficiente
```bash
MemoryError: Unable to allocate memory
```
**Solução:**
```yaml
# Reduzir programas simultâneos
analysis:
  max_programs: 100
```

### 🔧 Modo Debug

```bash
# Ativar logs detalhados
export COBOL_AI_DEBUG=1
python main.py examples/fontes.txt examples/BOOKS.txt
```

### 📞 Suporte

#### Logs Importantes:
- `logs/analysis.log` - Log principal
- `logs/error.log` - Erros específicos
- `logs/debug.log` - Informações detalhadas

#### Informações para Suporte:
```bash
# Gerar relatório de sistema
python check_macos_compatibility.py > system_info.txt
```

---

## 🚀 CASOS DE USO

### 1. 📋 Inventário de Sistema Legacy
```bash
# Analisar todos os programas para inventário
python main.py sistema_completo.txt copybooks.txt
```

### 2. 🔄 Modernização Incremental
```bash
# Analisar programas prioritários primeiro
python main.py programas_criticos.txt copybooks.txt
```

### 3. 📚 Documentação de Sistema
```bash
# Gerar documentação completa
python main.py todos_programas.txt todos_copybooks.txt
```

### 4. 🧪 Análise de Impacto
```bash
# Analisar dependências antes de mudanças
python main.py programas_afetados.txt copybooks.txt
```

---

## 🎯 MELHORES PRÁTICAS

### ✅ Preparação dos Dados
1. **Organize arquivos:** Um programa por seção no fontes.txt
2. **Inclua copybooks:** Todos os COPY statements devem ter correspondência
3. **Valide sintaxe:** Programas devem compilar sem erros críticos
4. **Documente contexto:** Adicione comentários sobre regras de negócio

### ✅ Configuração Otimizada
1. **Use SSD:** Para melhor performance de I/O
2. **Memória adequada:** 16GB+ para análises grandes
3. **LLM configurado:** Para melhor qualidade de análise
4. **Backup regular:** Dos resultados gerados

### ✅ Interpretação dos Resultados
1. **Foque no score:** Programas com score > 70% são confiáveis
2. **Valide manualmente:** Especialmente regras de negócio críticas
3. **Use como base:** Para análise manual mais profunda
4. **Documente descobertas:** Adicione contexto aos relatórios

---

## 📊 ESPECIFICAÇÕES TÉCNICAS

### 🔧 Requisitos de Sistema
- **CPU:** 2+ cores (4+ recomendado)
- **RAM:** 8GB mínimo (16GB recomendado)
- **Disco:** 2GB livres (10GB para análises grandes)
- **Rede:** Para acesso a LLMs (opcional)

### 📈 Performance
- **Programas pequenos** (<1000 linhas): 10-30 segundos
- **Programas médios** (1000-5000 linhas): 1-3 minutos
- **Programas grandes** (5000+ linhas): 3-10 minutos
- **Análise completa** (100+ programas): 1-4 horas

### 🔒 Segurança
- **Dados locais:** Processamento local por padrão
- **LLM opcional:** Pode ser desabilitado
- **Logs seguros:** Sem exposição de dados sensíveis
- **Configuração flexível:** Controle total sobre dados enviados

---

## 🎉 CONCLUSÃO

O **COBOL AI Engine v1.0.0** é uma ferramenta poderosa para análise e documentação de sistemas COBOL legacy. Com sua abordagem universal e flexível, oferece uma base sólida para projetos de modernização e documentação.

### 🏆 Principais Benefícios
- **Acelera análise** de sistemas legacy
- **Padroniza documentação** técnica
- **Facilita modernização** incremental
- **Reduz dependência** de especialistas COBOL

### 🚀 Próximos Passos
1. **Execute a demo** para validar instalação
2. **Analise programas piloto** para avaliar qualidade
3. **Configure LLMs** para melhor precisão
4. **Integre no workflow** de modernização

**Boa análise!** 🎯

