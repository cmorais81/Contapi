#!/usr/bin/env python3
"""
COBOL AI Engine v1.0.0 - Universal Functional Documentation
Script principal com opções expandidas de linha de comando.
"""

import os
import sys
import logging
import argparse
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

# Adiciona o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Imports dos componentes
from analyzers.universal_structure_analyzer import UniversalStructureAnalyzer
from analyzers.universal_business_logic_extractor import UniversalBusinessLogicExtractor
from generators.universal_functional_documentation_generator import UniversalFunctionalDocumentationGenerator
from parsers.multi_program_cobol_parser import MultiProgramCobolParser
from utils.extract_programs import extract_programs_from_file
from utils.extract_books import extract_books_from_file


class UniversalFunctionalAnalyzer:
    """
    Analisador universal que gera documentação funcional para qualquer programa COBOL.
    """
    
    def __init__(self, args=None):
        self.args = args or {}
        self.setup_logging()
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Inicializa componentes
        self.structure_analyzer = UniversalStructureAnalyzer()
        self.business_logic_extractor = UniversalBusinessLogicExtractor()
        self.documentation_generator = UniversalFunctionalDocumentationGenerator()
        self.cobol_parser = MultiProgramCobolParser()
        
        # Configuração padrão
        self.config = {}
        
        self.logger.info("COBOL AI Engine v1.0.0 - Universal Functional Documentation inicializado")
    
    def setup_logging(self):
        """Configura logging baseado nos argumentos."""
        # Determina nível de logging
        if hasattr(self.args, 'quiet') and self.args.quiet:
            level = logging.ERROR
        elif hasattr(self.args, 'log_level') and self.args.log_level:
            level = getattr(logging, self.args.log_level.upper(), logging.INFO)
        elif hasattr(self.args, 'verbose') and self.args.verbose:
            level = logging.DEBUG
        else:
            level = logging.INFO
        
        # Configura handlers
        handlers = []
        
        # Console logging (se não estiver em modo quiet)
        if not (hasattr(self.args, 'quiet') and self.args.quiet):
            if not (hasattr(self.args, 'no_console_log') and self.args.no_console_log):
                handlers.append(logging.StreamHandler(sys.stdout))
        
        # File logging
        log_file = 'cobol_ai_engine_v1.0.0.log'
        if hasattr(self.args, 'log_file') and self.args.log_file:
            log_file = self.args.log_file
        handlers.append(logging.FileHandler(log_file))
        
        logging.basicConfig(
            level=level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=handlers
        )
    
    def load_config(self, config_file: str):
        """Carrega configuração de arquivo YAML."""
        try:
            import yaml
            with open(config_file, 'r', encoding='utf-8') as f:
                self.config = yaml.safe_load(f)
            self.logger.info(f"Configuração carregada de: {config_file}")
            
            # Aplica configurações de logging se especificadas (mas argumentos têm precedência)
            if 'logging' in self.config and not hasattr(self.args, 'log_level'):
                log_config = self.config['logging']
                if 'level' in log_config:
                    level = getattr(logging, log_config['level'].upper(), logging.INFO)
                    logging.getLogger().setLevel(level)
                    
        except Exception as e:
            self.logger.warning(f"Erro ao carregar configuração: {e}")
            self.logger.info("Usando configuração padrão")
    
    def get_effective_config(self, key_path: str, default=None):
        """Obtém configuração efetiva, priorizando argumentos de linha de comando."""
        # Verifica se há override via argumentos
        arg_name = key_path.replace('.', '_').replace('/', '_')
        if hasattr(self.args, arg_name):
            return getattr(self.args, arg_name)
        
        # Busca no arquivo de configuração
        keys = key_path.split('.')
        value = self.config
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        return value
    
    def filter_programs(self, programs: List[Dict], demo_mode: bool = False) -> List[Dict]:
        """Aplica filtros aos programas baseado na configuração e argumentos."""
        filtered_programs = programs.copy()
        
        # Filtro por padrão (regex)
        if hasattr(self.args, 'filter_pattern') and self.args.filter_pattern:
            import re
            pattern = re.compile(self.args.filter_pattern)
            filtered_programs = [p for p in filtered_programs 
                               if pattern.search(p.get('name', ''))]
            self.logger.info(f"Filtro por padrão '{self.args.filter_pattern}': {len(filtered_programs)} programas")
        
        # Exclusão por padrão
        if hasattr(self.args, 'exclude_pattern') and self.args.exclude_pattern:
            import re
            pattern = re.compile(self.args.exclude_pattern)
            filtered_programs = [p for p in filtered_programs 
                               if not pattern.search(p.get('name', ''))]
            self.logger.info(f"Exclusão por padrão '{self.args.exclude_pattern}': {len(filtered_programs)} programas")
        
        # Filtro por tamanho de linhas
        if hasattr(self.args, 'min_lines') and self.args.min_lines:
            filtered_programs = [p for p in filtered_programs 
                               if len(p.get('content', '').splitlines()) >= self.args.min_lines]
            self.logger.info(f"Filtro mínimo de linhas ({self.args.min_lines}): {len(filtered_programs)} programas")
        
        if hasattr(self.args, 'max_lines') and self.args.max_lines:
            filtered_programs = [p for p in filtered_programs 
                               if len(p.get('content', '').splitlines()) <= self.args.max_lines]
            self.logger.info(f"Filtro máximo de linhas ({self.args.max_lines}): {len(filtered_programs)} programas")
        
        # Limitação por número máximo
        max_programs = self.get_effective_config('analysis.max_programs', 1000)
        if demo_mode:
            max_programs = 3
            self.logger.info("🚀 Modo de demonstração ativado")
        
        if len(filtered_programs) > max_programs:
            filtered_programs = filtered_programs[:max_programs]
            self.logger.info(f"Limitando análise a {max_programs} programas")
        
        return filtered_programs
    
    def analyze_programs(self, fontes_file: str, books_file: str, output_dir: str = "functional_analysis_results_v15", demo_mode: bool = False) -> Dict[str, Any]:
        """
        Analisa todos os programas COBOL e gera documentação funcional.
        """
        self.logger.info(f"Iniciando análise funcional universal")
        self.logger.info(f"Fontes: {fontes_file}")
        self.logger.info(f"Books: {books_file}")
        
        # Aplica configurações
        timeout_per_program = self.get_effective_config('analysis.timeout_per_program', 300)
        analysis_depth = getattr(self.args, 'analysis_depth', 'standard')
        
        self.logger.info(f"Configurações: timeout={timeout_per_program}s, depth={analysis_depth}")
        
        # Cria diretório de saída
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        try:
            # Extrai programas e copybooks
            self.logger.info("Extraindo programas COBOL...")
            programs = extract_programs_from_file(fontes_file)
            
            # Aplica filtros
            programs = self.filter_programs(programs, demo_mode)
            self.logger.info(f"Programas selecionados para análise: {len(programs)}")
            
            self.logger.info("Extraindo copybooks...")
            copybooks = extract_books_from_file(books_file)
            self.logger.info(f"Extraídos {len(copybooks)} copybooks")
            
            # Resultados consolidados
            consolidated_results = {
                'analysis_date': datetime.now().isoformat(),
                'version': '1.0.0 - Universal Functional Documentation',
                'configuration': {
                    'demo_mode': demo_mode,
                    'analysis_depth': analysis_depth,
                    'timeout_per_program': timeout_per_program,
                    'provider': getattr(self.args, 'provider', 'default'),
                    'format': getattr(self.args, 'format', 'markdown')
                },
                'total_programs': len(programs),
                'total_copybooks': len(copybooks),
                'programs_analyzed': 0,
                'programs_successful': 0,
                'programs_failed': 0,
                'average_reimplementation_score': 0.0,
                'programs': {},
                'summary_statistics': {}
            }
            
            # Analisa cada programa
            reimpl_scores = []
            
            for i, program in enumerate(programs, 1):
                program_name = program.get('name', f'PROGRAM_{i}')
                self.logger.info(f"Analisando programa {i}/{len(programs)}: {program_name}")
                
                try:
                    # Análise do programa
                    program_result = self._analyze_single_program(
                        program, copybooks, output_path, program_name
                    )
                    
                    consolidated_results['programs'][program_name] = program_result
                    consolidated_results['programs_successful'] += 1
                    
                    # Coleta score de reimplementação
                    reimpl_score = program_result.get('reimplementation_score', 0.0)
                    reimpl_scores.append(reimpl_score)
                    
                    self.logger.info(f"✅ {program_name} analisado com sucesso (Score: {reimpl_score:.1f}%)")
                    
                except Exception as e:
                    self.logger.error(f"❌ Erro ao analisar {program_name}: {str(e)}")
                    consolidated_results['programs_failed'] += 1
                    consolidated_results['programs'][program_name] = {
                        'status': 'failed',
                        'error': str(e),
                        'reimplementation_score': 0.0
                    }
                
                consolidated_results['programs_analyzed'] += 1
            
            # Calcula estatísticas finais
            if reimpl_scores:
                consolidated_results['average_reimplementation_score'] = sum(reimpl_scores) / len(reimpl_scores)
            
            consolidated_results['summary_statistics'] = self._generate_summary_statistics(consolidated_results)
            
            # Gera relatório consolidado
            self._generate_consolidated_report(consolidated_results, output_path)
            
            # Log final
            success_rate = (consolidated_results['programs_successful'] / consolidated_results['total_programs']) * 100
            avg_score = consolidated_results['average_reimplementation_score']
            
            self.logger.info(f"🎯 Análise Funcional Universal Finalizada!")
            self.logger.info(f"📊 {consolidated_results['programs_successful']}/{consolidated_results['total_programs']} programas analisados com sucesso ({success_rate:.1f}%)")
            self.logger.info(f"📈 Score médio de reimplementação: {avg_score:.1f}%")
            
            # Avaliação qualitativa
            if avg_score >= 70:
                self.logger.info("🎉 EXCELENTE! Maioria dos programas com alta capacidade de reimplementação!")
            elif avg_score >= 50:
                self.logger.info("👍 BOM! Programas com capacidade média de reimplementação!")
            else:
                self.logger.info("⚠️ ATENÇÃO! Programas requerem análise manual adicional!")
            
            return consolidated_results
            
        except Exception as e:
            self.logger.error(f"Erro na análise: {str(e)}")
            raise
    
    def _analyze_single_program(self, program: Dict[str, Any], copybooks: List[Dict], 
                               output_path: Path, program_name: str) -> Dict[str, Any]:
        """Analisa um programa individual."""
        
        # Cria diretório para o programa
        program_dir = output_path / program_name
        program_dir.mkdir(exist_ok=True)
        
        # Obtém código COBOL
        cobol_code = program.get('content', '')
        if not cobol_code:
            raise ValueError(f"Código COBOL não encontrado para {program_name}")
        
        # Análise estrutural universal
        self.logger.debug(f"Executando análise estrutural para {program_name}")
        structure_analysis = self.structure_analyzer.analyze(cobol_code, copybooks)
        
        # Extração de lógica de negócio universal
        self.logger.debug(f"Extraindo lógica de negócio para {program_name}")
        business_logic = self.business_logic_extractor.extract(cobol_code, structure_analysis)
        
        # Gera documentação funcional
        self.logger.debug(f"Gerando documentação funcional para {program_name}")
        functional_documentation = self.documentation_generator.generate(
            structure_analysis, business_logic, program_name
        )
        
        # Salva documentação
        doc_file = program_dir / f"{program_name}_FUNCTIONAL_DOCS_v1.0.0.md"
        with open(doc_file, 'w', encoding='utf-8') as f:
            f.write(functional_documentation)
        
        # Salva dados de análise em JSON
        import json
        analysis_data = {
            'program_name': program_name,
            'analysis_date': datetime.now().isoformat(),
            'structure_analysis': structure_analysis,
            'business_logic': business_logic,
            'reimplementation_score': self._calculate_reimplementation_score(structure_analysis, business_logic)
        }
        
        json_file = program_dir / f"{program_name}_analysis_data_v1.0.0.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(analysis_data, f, indent=2, ensure_ascii=False, default=str)
        
        return {
            'status': 'success',
            'program_name': program_name,
            'documentation_file': str(doc_file),
            'analysis_data_file': str(json_file),
            'reimplementation_score': analysis_data['reimplementation_score'],
            'structure_analysis': structure_analysis,
            'business_logic': business_logic
        }
    
    def _calculate_reimplementation_score(self, structure_analysis: Dict[str, Any], business_logic: Dict[str, Any]) -> float:
        """Calcula score de capacidade de reimplementação."""
        score = 0.0
        
        # Estruturas identificadas (30%)
        files = structure_analysis.get('files', [])
        if files:
            score += min(30.0, len(files) * 5)
        
        # Regras de negócio (40%)
        rules = business_logic.get('business_rules', [])
        if rules:
            avg_confidence = sum(rule.get('confidence', 0.0) for rule in rules) / len(rules)
            score += avg_confidence * 40
        
        # Fluxos de dados (20%)
        data_flows = business_logic.get('data_flows', [])
        if data_flows:
            score += min(20.0, len(data_flows) * 2)
        
        # Padrões identificados (10%)
        patterns = business_logic.get('patterns', [])
        if patterns:
            avg_pattern_confidence = sum(p.get('confidence', 0.0) for p in patterns) / len(patterns)
            score += avg_pattern_confidence * 10
        
        return min(100.0, score)
    
    def _generate_summary_statistics(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Gera estatísticas resumidas."""
        programs = results.get('programs', {})
        
        # Distribui scores por faixas
        score_ranges = {
            'high_readiness': 0,  # 70-100%
            'medium_readiness': 0,  # 40-69%
            'low_readiness': 0  # 0-39%
        }
        
        total_files = 0
        total_rules = 0
        total_complexity = 0
        
        for program_name, program_data in programs.items():
            if program_data.get('status') == 'success':
                score = program_data.get('reimplementation_score', 0.0)
                
                if score >= 70:
                    score_ranges['high_readiness'] += 1
                elif score >= 40:
                    score_ranges['medium_readiness'] += 1
                else:
                    score_ranges['low_readiness'] += 1
                
                # Coleta estatísticas adicionais
                structure = program_data.get('structure_analysis', {})
                business = program_data.get('business_logic', {})
                
                total_files += len(structure.get('files', []))
                total_rules += len(business.get('business_rules', []))
                total_complexity += business.get('complexity_analysis', {}).get('total_complexity', 0)
        
        successful_programs = results.get('programs_successful', 0)
        
        return {
            'score_distribution': score_ranges,
            'average_files_per_program': total_files / max(successful_programs, 1),
            'average_rules_per_program': total_rules / max(successful_programs, 1),
            'average_complexity_per_program': total_complexity / max(successful_programs, 1),
            'total_files_identified': total_files,
            'total_rules_identified': total_rules,
            'total_complexity_points': total_complexity
        }
    
    def _generate_consolidated_report(self, results: Dict[str, Any], output_path: Path):
        """Gera relatório consolidado."""
        
        report_content = f"""# 📋 Relatório Consolidado - Análise Funcional Universal v1.0.0

**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Versão:** 1.0.0 - Universal Functional Documentation  
**Tipo:** Análise Funcional Completa  

## 📊 RESUMO EXECUTIVO

### Estatísticas Gerais
- **Total de Programas:** {results['total_programs']}
- **Programas Analisados:** {results['programs_analyzed']}
- **Sucessos:** {results['programs_successful']} ({(results['programs_successful']/results['total_programs']*100):.1f}%)
- **Falhas:** {results['programs_failed']} ({(results['programs_failed']/results['total_programs']*100):.1f}%)
- **Score Médio de Reimplementação:** {results['average_reimplementation_score']:.1f}%

### Configuração Utilizada
- **Modo:** {'Demonstração' if results['configuration']['demo_mode'] else 'Completo'}
- **Profundidade:** {results['configuration']['analysis_depth']}
- **Provedor:** {results['configuration']['provider']}
- **Formato:** {results['configuration']['format']}
- **Timeout:** {results['configuration']['timeout_per_program']}s

### Distribuição de Capacidade de Reimplementação
- **🟢 Alta Capacidade (70-100%):** {results['summary_statistics']['score_distribution']['high_readiness']} programas
- **🟡 Média Capacidade (40-69%):** {results['summary_statistics']['score_distribution']['medium_readiness']} programas  
- **🔴 Baixa Capacidade (0-39%):** {results['summary_statistics']['score_distribution']['low_readiness']} programas

## 🎯 ANÁLISE DETALHADA

### Métricas Técnicas
- **Arquivos Identificados:** {results['summary_statistics']['total_files_identified']}
- **Regras de Negócio:** {results['summary_statistics']['total_rules_identified']}
- **Pontos de Complexidade:** {results['summary_statistics']['total_complexity_points']}
- **Média de Arquivos/Programa:** {results['summary_statistics']['average_files_per_program']:.1f}
- **Média de Regras/Programa:** {results['summary_statistics']['average_rules_per_program']:.1f}

---

**Relatório gerado por:** COBOL AI Engine v1.0.0 - Universal Functional Documentation  
**Qualidade:** {"ALTA" if results['average_reimplementation_score'] > 70 else "MÉDIA" if results['average_reimplementation_score'] > 40 else "BAIXA"}  
**Recomendação:** {"Prosseguir com modernização" if results['average_reimplementation_score'] > 50 else "Análise manual adicional necessária"}
"""
        
        # Salva relatório
        report_file = output_path / "CONSOLIDATED_FUNCTIONAL_REPORT_v1.0.0.md"
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        self.logger.info(f"Relatório consolidado salvo em: {report_file}")


def create_argument_parser():
    """Cria parser de argumentos com todas as opções."""
    parser = argparse.ArgumentParser(
        description='COBOL AI Engine v1.0.0 - Universal Functional Documentation',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  %(prog)s fontes.txt books.txt
  %(prog)s fontes.txt books.txt --demo-mode --verbose
  %(prog)s fontes.txt books.txt --provider openai --format json
  %(prog)s fontes.txt books.txt --config config/prod.yaml --max-programs 100
        """
    )
    
    # Argumentos obrigatórios
    parser.add_argument('fontes_file', help='Arquivo com lista de programas COBOL')
    parser.add_argument('books_file', help='Arquivo com copybooks')
    
    # Configuração básica
    parser.add_argument('--output', '-o', default='functional_analysis_results_v15',
                       help='Diretório de saída (default: functional_analysis_results_v15)')
    parser.add_argument('--config', '-c', default='config/config.yaml',
                       help='Arquivo de configuração (default: config/config.yaml)')
    
    # Modos de operação
    parser.add_argument('--demo-mode', action='store_true',
                       help='Executa em modo de demonstração (primeiros 3 programas)')
    
    # Controle de provedores LLM
    parser.add_argument('--provider', choices=['openai', 'copilot', 'luzia', 'enhanced_mock', 'mock'],
                       help='Provedor LLM principal')
    parser.add_argument('--fallback-provider', choices=['openai', 'copilot', 'luzia', 'enhanced_mock', 'mock'],
                       help='Provedor LLM de fallback')
    
    # Controle de análise
    parser.add_argument('--max-programs', type=int,
                       help='Máximo de programas a analisar')
    parser.add_argument('--timeout', type=int,
                       help='Timeout por programa em segundos')
    parser.add_argument('--analysis-depth', choices=['basic', 'standard', 'detailed', 'maximum'],
                       default='standard', help='Profundidade da análise')
    
    # Filtros
    parser.add_argument('--filter-pattern',
                       help='Filtra programas por padrão regex')
    parser.add_argument('--exclude-pattern',
                       help='Exclui programas por padrão regex')
    parser.add_argument('--min-lines', type=int,
                       help='Mínimo de linhas por programa')
    parser.add_argument('--max-lines', type=int,
                       help='Máximo de linhas por programa')
    
    # Controle de saída
    parser.add_argument('--format', choices=['markdown', 'json', 'html', 'pdf'],
                       default='markdown', help='Formato de saída')
    parser.add_argument('--no-consolidate', action='store_true',
                       help='Não gera relatório consolidado')
    
    # Controle de logging
    parser.add_argument('--log-level', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                       help='Nível de logging')
    parser.add_argument('--log-file',
                       help='Arquivo de log personalizado')
    parser.add_argument('--no-console-log', action='store_true',
                       help='Desabilita log no console')
    parser.add_argument('--quiet', '-q', action='store_true',
                       help='Modo silencioso (apenas erros)')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='Ativa modo verboso de logging')
    
    # Validação
    parser.add_argument('--validate-syntax', action='store_true',
                       help='Valida sintaxe COBOL antes da análise')
    parser.add_argument('--min-score', type=int, choices=range(0, 101), metavar='[0-100]',
                       help='Score mínimo de reimplementação (0-100)')
    
    return parser


def main():
    """Função principal."""
    parser = create_argument_parser()
    args = parser.parse_args()
    
    # Configura logging baseado nos argumentos (antes de criar o analyzer)
    if args.quiet:
        logging.basicConfig(level=logging.ERROR)
    elif args.verbose:
        logging.basicConfig(level=logging.DEBUG)
    elif args.log_level:
        level = getattr(logging, args.log_level.upper(), logging.INFO)
        logging.basicConfig(level=level)
    
    # Valida arquivo de configuração
    if not os.path.exists(args.config):
        print(f"⚠️ Arquivo de configuração não encontrado: {args.config}")
        print("Usando configuração padrão...")
    else:
        print(f"📋 Usando configuração: {args.config}")
    
    # Valida arquivos de entrada
    if not os.path.exists(args.fontes_file):
        print(f"❌ Arquivo de fontes não encontrado: {args.fontes_file}")
        return 1
    
    if not os.path.exists(args.books_file):
        print(f"❌ Arquivo de books não encontrado: {args.books_file}")
        return 1
    
    try:
        # Executa análise
        analyzer = UniversalFunctionalAnalyzer(args)
        
        # Carrega configuração se especificada
        if os.path.exists(args.config):
            analyzer.load_config(args.config)
        
        results = analyzer.analyze_programs(
            args.fontes_file, 
            args.books_file, 
            args.output, 
            demo_mode=args.demo_mode
        )
        
        # Validação de score mínimo
        if args.min_score and results['average_reimplementation_score'] < args.min_score:
            print(f"⚠️ Score médio ({results['average_reimplementation_score']:.1f}%) abaixo do mínimo ({args.min_score}%)")
            return 2
        
        print(f"\n🎯 Análise concluída com sucesso!")
        print(f"📊 Resultados salvos em: {args.output}")
        print(f"📈 Score médio de reimplementação: {results['average_reimplementation_score']:.1f}%")
        
        return 0
        
    except Exception as e:
        print(f"❌ Erro na análise: {str(e)}")
        return 1


if __name__ == "__main__":
    exit(main())
