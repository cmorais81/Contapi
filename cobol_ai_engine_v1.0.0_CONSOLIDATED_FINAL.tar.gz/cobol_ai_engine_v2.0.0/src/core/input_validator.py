#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
COBOL AI Engine v2.3.0 - Input Validator
Sistema robusto de validação baseado na avaliação crítica

Autor: Manus AI
Data: 17 de Setembro de 2025
"""

import logging
import os
import re
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from dataclasses import dataclass
from enum import Enum


class ValidationLevel(Enum):
    """Níveis de validação disponíveis."""
    BASIC = "basic"
    STANDARD = "standard"
    STRICT = "strict"
    PARANOID = "paranoid"


@dataclass
class ValidationResult:
    """Resultado de uma validação."""
    is_valid: bool
    errors: List[str]
    warnings: List[str]
    suggestions: List[str]
    metadata: Dict[str, Any]


@dataclass
class COBOLFileInfo:
    """Informações de um arquivo COBOL validado."""
    path: str
    exists: bool
    size_bytes: int
    line_count: int
    has_cobol_structure: bool
    program_name: Optional[str]
    divisions_found: List[str]
    syntax_errors: List[str]
    encoding: str


class InputValidator:
    """
    Validador robusto de entrada baseado na avaliação crítica.
    
    Implementa validação em múltiplas camadas:
    1. Validação de arquivos e caminhos
    2. Validação de estrutura COBOL
    3. Validação de sintaxe básica
    4. Validação de configuração
    """
    
    def __init__(self, validation_level: ValidationLevel = ValidationLevel.STANDARD):
        """
        Inicializa o validador.
        
        Args:
            validation_level: Nível de rigor da validação
        """
        self.logger = logging.getLogger(__name__)
        self.validation_level = validation_level
        
        # Padrões COBOL para validação
        self.cobol_patterns = {
            'program_id': re.compile(r'^\s*PROGRAM-ID\.\s+([A-Z0-9\-]+)', re.IGNORECASE | re.MULTILINE),
            'division': re.compile(r'^\s*(IDENTIFICATION|ENVIRONMENT|DATA|PROCEDURE)\s+DIVISION', re.IGNORECASE | re.MULTILINE),
            'section': re.compile(r'^\s*[A-Z\-]+\s+SECTION', re.IGNORECASE | re.MULTILINE),
            'pic_clause': re.compile(r'\s+PIC\s+[X9VS\(\)]+', re.IGNORECASE),
            'perform': re.compile(r'\s+PERFORM\s+', re.IGNORECASE),
            'if_statement': re.compile(r'\s+IF\s+', re.IGNORECASE),
            'move_statement': re.compile(r'\s+MOVE\s+', re.IGNORECASE)
        }
        
        # Extensões válidas para arquivos COBOL
        self.valid_cobol_extensions = {'.cbl', '.cob', '.cobol', '.txt', '.dat'}
        
        # Tamanhos máximos recomendados
        self.max_file_size_mb = 50
        self.max_lines_per_file = 50000
        
        self.logger.info(f"Input Validator inicializado - Nível: {validation_level.value}")
    
    def validate_source_files(self, sources_file: str) -> ValidationResult:
        """
        Valida arquivo de lista de fontes.
        
        Args:
            sources_file: Caminho para arquivo com lista de programas
            
        Returns:
            Resultado da validação
        """
        errors = []
        warnings = []
        suggestions = []
        metadata = {}
        
        try:
            # Verificar se arquivo de fontes existe
            if not os.path.exists(sources_file):
                errors.append(f"Arquivo de fontes não encontrado: {sources_file}")
                return ValidationResult(False, errors, warnings, suggestions, metadata)
            
            # Ler e validar conteúdo
            with open(sources_file, 'r', encoding='utf-8') as f:
                lines = [line.strip() for line in f.readlines() if line.strip()]
            
            if not lines:
                errors.append(f"Arquivo de fontes está vazio: {sources_file}")
                return ValidationResult(False, errors, warnings, suggestions, metadata)
            
            # Validar cada arquivo listado
            valid_files = []
            invalid_files = []
            cobol_files_info = []
            
            for i, file_path in enumerate(lines, 1):
                # Remover comentários (linhas que começam com #)
                if file_path.startswith('#'):
                    continue
                
                file_validation = self._validate_cobol_file(file_path)
                
                if file_validation.is_valid:
                    valid_files.append(file_path)
                    cobol_files_info.append(file_validation.metadata.get('file_info'))
                else:
                    invalid_files.append(file_path)
                    errors.extend([f"Linha {i}: {error}" for error in file_validation.errors])
                    warnings.extend([f"Linha {i}: {warning}" for warning in file_validation.warnings])
            
            # Estatísticas
            metadata.update({
                'total_files_listed': len(lines),
                'valid_files': len(valid_files),
                'invalid_files': len(invalid_files),
                'cobol_files_info': cobol_files_info,
                'total_size_mb': sum(info.size_bytes for info in cobol_files_info) / (1024 * 1024),
                'total_lines': sum(info.line_count for info in cobol_files_info)
            })
            
            # Validações específicas por nível
            if self.validation_level in [ValidationLevel.STRICT, ValidationLevel.PARANOID]:
                self._strict_validation_checks(valid_files, warnings, suggestions)
            
            # Sugestões gerais
            if len(valid_files) == 0:
                errors.append("Nenhum arquivo COBOL válido encontrado")
            elif len(valid_files) < len(lines) / 2:
                warnings.append(f"Apenas {len(valid_files)} de {len(lines)} arquivos são válidos")
            
            if metadata.get('total_size_mb', 0) > 100:
                warnings.append(f"Tamanho total dos arquivos é grande: {metadata['total_size_mb']:.1f}MB")
            
            is_valid = len(errors) == 0 and len(valid_files) > 0
            
            self.logger.info(f"Validação de fontes: {len(valid_files)} válidos, {len(invalid_files)} inválidos")
            
            return ValidationResult(is_valid, errors, warnings, suggestions, metadata)
            
        except Exception as e:
            errors.append(f"Erro durante validação de fontes: {str(e)}")
            return ValidationResult(False, errors, warnings, suggestions, metadata)
    
    def validate_copybooks_file(self, copybooks_file: str) -> ValidationResult:
        """
        Valida arquivo de lista de copybooks.
        
        Args:
            copybooks_file: Caminho para arquivo com lista de copybooks
            
        Returns:
            Resultado da validação
        """
        if not copybooks_file:
            # Copybooks são opcionais
            return ValidationResult(True, [], [], [], {'copybooks_provided': False})
        
        # Usar mesma lógica de validação de fontes
        result = self.validate_source_files(copybooks_file)
        result.metadata['copybooks_provided'] = True
        
        return result
    
    def validate_configuration(self, config: Dict[str, Any]) -> ValidationResult:
        """
        Valida configuração do sistema.
        
        Args:
            config: Dicionário de configuração
            
        Returns:
            Resultado da validação
        """
        errors = []
        warnings = []
        suggestions = []
        metadata = {}
        
        try:
            # Validar estrutura básica
            required_sections = ['ai', 'output']
            for section in required_sections:
                if section not in config:
                    errors.append(f"Seção obrigatória ausente na configuração: {section}")
            
            # Validar configuração de AI
            if 'ai' in config:
                ai_validation = self._validate_ai_config(config['ai'])
                errors.extend(ai_validation.errors)
                warnings.extend(ai_validation.warnings)
                suggestions.extend(ai_validation.suggestions)
                metadata.update(ai_validation.metadata)
            
            # Validar configuração de output
            if 'output' in config:
                output_validation = self._validate_output_config(config['output'])
                errors.extend(output_validation.errors)
                warnings.extend(output_validation.warnings)
            
            # Validações específicas por nível
            if self.validation_level == ValidationLevel.PARANOID:
                self._paranoid_config_validation(config, warnings, suggestions)
            
            is_valid = len(errors) == 0
            
            return ValidationResult(is_valid, errors, warnings, suggestions, metadata)
            
        except Exception as e:
            errors.append(f"Erro durante validação de configuração: {str(e)}")
            return ValidationResult(False, errors, warnings, suggestions, metadata)
    
    def _validate_cobol_file(self, file_path: str) -> ValidationResult:
        """Valida um arquivo COBOL individual."""
        errors = []
        warnings = []
        suggestions = []
        metadata = {}
        
        try:
            # Verificar se arquivo existe
            if not os.path.exists(file_path):
                errors.append(f"Arquivo não encontrado: {file_path}")
                return ValidationResult(False, errors, warnings, suggestions, metadata)
            
            # Verificar extensão
            file_ext = Path(file_path).suffix.lower()
            if file_ext not in self.valid_cobol_extensions:
                warnings.append(f"Extensão não padrão para COBOL: {file_ext}")
            
            # Verificar tamanho
            file_size = os.path.getsize(file_path)
            if file_size == 0:
                errors.append(f"Arquivo vazio: {file_path}")
                return ValidationResult(False, errors, warnings, suggestions, metadata)
            
            if file_size > self.max_file_size_mb * 1024 * 1024:
                warnings.append(f"Arquivo muito grande: {file_size / (1024*1024):.1f}MB")
            
            # Ler conteúdo
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                encoding = 'utf-8'
            except UnicodeDecodeError:
                try:
                    with open(file_path, 'r', encoding='latin-1') as f:
                        content = f.read()
                    encoding = 'latin-1'
                    warnings.append(f"Arquivo não está em UTF-8: {file_path}")
                except Exception as e:
                    errors.append(f"Erro de codificação: {file_path} - {str(e)}")
                    return ValidationResult(False, errors, warnings, suggestions, metadata)
            
            lines = content.split('\n')
            line_count = len(lines)
            
            if line_count > self.max_lines_per_file:
                warnings.append(f"Arquivo muito longo: {line_count} linhas")
            
            # Validar estrutura COBOL
            cobol_validation = self._validate_cobol_structure(content, file_path)
            errors.extend(cobol_validation.errors)
            warnings.extend(cobol_validation.warnings)
            suggestions.extend(cobol_validation.suggestions)
            
            # Criar informações do arquivo
            file_info = COBOLFileInfo(
                path=file_path,
                exists=True,
                size_bytes=file_size,
                line_count=line_count,
                has_cobol_structure=cobol_validation.metadata.get('has_cobol_structure', False),
                program_name=cobol_validation.metadata.get('program_name'),
                divisions_found=cobol_validation.metadata.get('divisions_found', []),
                syntax_errors=cobol_validation.errors,
                encoding=encoding
            )
            
            metadata['file_info'] = file_info
            
            is_valid = len(errors) == 0
            
            return ValidationResult(is_valid, errors, warnings, suggestions, metadata)
            
        except Exception as e:
            errors.append(f"Erro durante validação de arquivo: {str(e)}")
            return ValidationResult(False, errors, warnings, suggestions, metadata)
    
    def _validate_cobol_structure(self, content: str, file_path: str) -> ValidationResult:
        """Valida estrutura básica COBOL."""
        errors = []
        warnings = []
        suggestions = []
        metadata = {}
        
        # Verificar PROGRAM-ID
        program_id_match = self.cobol_patterns['program_id'].search(content)
        if program_id_match:
            program_name = program_id_match.group(1)
            metadata['program_name'] = program_name
        else:
            if self.validation_level in [ValidationLevel.STRICT, ValidationLevel.PARANOID]:
                errors.append(f"PROGRAM-ID não encontrado: {file_path}")
            else:
                warnings.append(f"PROGRAM-ID não encontrado: {file_path}")
        
        # Verificar divisões
        divisions_found = []
        for match in self.cobol_patterns['division'].finditer(content):
            division = match.group(1).upper()
            divisions_found.append(division)
        
        metadata['divisions_found'] = divisions_found
        
        # Validar divisões obrigatórias
        required_divisions = ['IDENTIFICATION', 'PROCEDURE']
        missing_divisions = [div for div in required_divisions if div not in divisions_found]
        
        if missing_divisions:
            if self.validation_level == ValidationLevel.PARANOID:
                errors.extend([f"Divisão obrigatória ausente: {div}" for div in missing_divisions])
            else:
                warnings.extend([f"Divisão recomendada ausente: {div}" for div in missing_divisions])
        
        # Verificar se tem estrutura COBOL mínima
        has_cobol_structure = (
            len(divisions_found) >= 1 or
            self.cobol_patterns['pic_clause'].search(content) or
            self.cobol_patterns['perform'].search(content) or
            self.cobol_patterns['move_statement'].search(content)
        )
        
        metadata['has_cobol_structure'] = has_cobol_structure
        
        if not has_cobol_structure:
            if self.validation_level in [ValidationLevel.STRICT, ValidationLevel.PARANOID]:
                errors.append(f"Arquivo não parece conter código COBOL válido: {file_path}")
            else:
                warnings.append(f"Estrutura COBOL não detectada: {file_path}")
        
        # Validações adicionais para níveis mais rigorosos
        if self.validation_level == ValidationLevel.PARANOID:
            self._paranoid_cobol_validation(content, file_path, errors, warnings, suggestions)
        
        is_valid = len(errors) == 0
        
        return ValidationResult(is_valid, errors, warnings, suggestions, metadata)
    
    def _validate_ai_config(self, ai_config: Dict[str, Any]) -> ValidationResult:
        """Valida configuração de AI."""
        errors = []
        warnings = []
        suggestions = []
        metadata = {}
        
        # Verificar providers
        if 'providers' not in ai_config:
            errors.append("Seção 'providers' ausente na configuração de AI")
            return ValidationResult(False, errors, warnings, suggestions, metadata)
        
        providers = ai_config['providers']
        enabled_providers = []
        
        for provider_name, provider_config in providers.items():
            if provider_config.get('enabled', False):
                enabled_providers.append(provider_name)
                
                # Validar configuração específica do provider
                if provider_name == 'luzia':
                    if not provider_config.get('client_id') or not provider_config.get('client_secret'):
                        errors.append(f"Credenciais do LuzIA incompletas")
                elif provider_name == 'copilot':
                    if not provider_config.get('api_token'):
                        errors.append(f"Token do GitHub Copilot ausente")
        
        if not enabled_providers:
            errors.append("Nenhum provider de AI habilitado")
        else:
            metadata['enabled_providers'] = enabled_providers
        
        # Verificar provider primário
        primary_provider = ai_config.get('primary_provider')
        if primary_provider and primary_provider not in enabled_providers:
            errors.append(f"Provider primário '{primary_provider}' não está habilitado")
        
        is_valid = len(errors) == 0
        
        return ValidationResult(is_valid, errors, warnings, suggestions, metadata)
    
    def _validate_output_config(self, output_config: Dict[str, Any]) -> ValidationResult:
        """Valida configuração de output."""
        errors = []
        warnings = []
        suggestions = []
        metadata = {}
        
        # Validações básicas de output
        default_format = output_config.get('default_format', 'markdown')
        if default_format not in ['markdown', 'html', 'pdf']:
            warnings.append(f"Formato de output não padrão: {default_format}")
        
        is_valid = len(errors) == 0
        
        return ValidationResult(is_valid, errors, warnings, suggestions, metadata)
    
    def _strict_validation_checks(self, valid_files: List[str], warnings: List[str], suggestions: List[str]):
        """Validações adicionais para modo strict."""
        
        # Verificar se há muitos arquivos pequenos
        small_files = [f for f in valid_files if os.path.getsize(f) < 1024]  # < 1KB
        if len(small_files) > len(valid_files) * 0.3:
            warnings.append(f"Muitos arquivos pequenos detectados: {len(small_files)}")
            suggestions.append("Considere consolidar arquivos pequenos para melhor performance")
        
        # Verificar padrões de nomenclatura
        non_standard_names = []
        for file_path in valid_files:
            filename = Path(file_path).stem
            if not re.match(r'^[A-Z][A-Z0-9]{3,7}$', filename):
                non_standard_names.append(filename)
        
        if non_standard_names:
            warnings.append(f"Nomes não padrão detectados: {len(non_standard_names)} arquivos")
            suggestions.append("Considere padronizar nomenclatura: AAAANNNN (4-8 caracteres)")
    
    def _paranoid_cobol_validation(self, content: str, file_path: str, 
                                 errors: List[str], warnings: List[str], suggestions: List[str]):
        """Validações extremamente rigorosas para modo paranoid."""
        
        # Verificar linhas muito longas (padrão COBOL é 72 colunas)
        lines = content.split('\n')
        long_lines = [i+1 for i, line in enumerate(lines) if len(line) > 72]
        if long_lines:
            warnings.append(f"Linhas > 72 caracteres: {len(long_lines)} linhas")
        
        # Verificar caracteres não ASCII
        non_ascii_chars = [c for c in content if ord(c) > 127]
        if non_ascii_chars:
            warnings.append(f"Caracteres não-ASCII encontrados: {len(set(non_ascii_chars))}")
        
        # Verificar tabs (COBOL tradicionalmente usa espaços)
        if '\t' in content:
            warnings.append("Caracteres TAB encontrados (recomenda-se usar espaços)")
        
        # Verificar estrutura de colunas COBOL
        self._validate_cobol_columns(lines, warnings, suggestions)
    
    def _validate_cobol_columns(self, lines: List[str], warnings: List[str], suggestions: List[str]):
        """Valida estrutura de colunas COBOL tradicional."""
        
        issues = 0
        for i, line in enumerate(lines[:100], 1):  # Verificar apenas primeiras 100 linhas
            if len(line) > 6:
                # Coluna 7 deve ser espaço ou continuação
                if len(line) > 6 and line[6] not in [' ', '*', '-']:
                    issues += 1
        
        if issues > len(lines) * 0.1:  # Mais de 10% das linhas
            warnings.append("Possível problema na estrutura de colunas COBOL")
            suggestions.append("Verifique se o código segue formato de colunas COBOL padrão")
    
    def _paranoid_config_validation(self, config: Dict[str, Any], warnings: List[str], suggestions: List[str]):
        """Validações paranóicas de configuração."""
        
        # Verificar configurações de segurança
        if 'security' not in config:
            warnings.append("Seção de segurança ausente na configuração")
            suggestions.append("Considere adicionar configurações de segurança")
        
        # Verificar configurações de logging
        if 'logging' not in config:
            warnings.append("Configuração de logging ausente")
            suggestions.append("Configure logging para melhor rastreabilidade")
        
        # Verificar limites de recursos
        if 'performance' not in config:
            warnings.append("Configurações de performance ausentes")
            suggestions.append("Configure limites de recursos para evitar sobrecarga")
    
    def get_validation_summary(self, results: List[ValidationResult]) -> Dict[str, Any]:
        """Gera resumo de múltiplas validações."""
        
        total_errors = sum(len(r.errors) for r in results)
        total_warnings = sum(len(r.warnings) for r in results)
        total_suggestions = sum(len(r.suggestions) for r in results)
        
        valid_results = sum(1 for r in results if r.is_valid)
        
        return {
            'total_validations': len(results),
            'valid_results': valid_results,
            'invalid_results': len(results) - valid_results,
            'total_errors': total_errors,
            'total_warnings': total_warnings,
            'total_suggestions': total_suggestions,
            'overall_valid': total_errors == 0,
            'validation_level': self.validation_level.value
        }
