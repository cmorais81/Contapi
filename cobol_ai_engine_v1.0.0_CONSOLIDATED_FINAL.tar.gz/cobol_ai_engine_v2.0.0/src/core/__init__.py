"""Componentes core do COBOL AI Engine v15.0"""

# Imports com tratamento de erro
try:
    from .config import ConfigManager
except ImportError:
    ConfigManager = None

try:
    from .prompt_manager import PromptManager
except ImportError:
    PromptManager = None

try:
    from .token_manager import TokenManager
except ImportError:
    TokenManager = None

try:
    from .exceptions import COBOLAnalysisError, ConfigurationError
except ImportError:
    COBOLAnalysisError = ConfigurationError = None

try:
    from .input_validator import InputValidator
except ImportError:
    InputValidator = None

try:
    from .preset_manager import PresetManager
except ImportError:
    PresetManager = None

__all__ = [
    'ConfigManager', 'PromptManager', 'TokenManager',
    'COBOLAnalysisError', 'ConfigurationError',
    'InputValidator', 'PresetManager'
]
