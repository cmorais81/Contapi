import logging
from typing import Dict, Any
from datetime import datetime

class AdvancedDocumentationGenerator:
    """
    Gerador de documentação avançado que utiliza a análise híbrida completa
    para produzir documentação técnica extremamente detalhada e precisa.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def generate(self, analysis_results: Dict[str, Any], target_language: str = "java") -> str:
        """Gera documentação técnica completa e detalhada."""
        doc = []
        doc.append(self._generate_header(analysis_results))
        doc.append(self._generate_executive_summary(analysis_results))
        doc.append(self._generate_detailed_architecture(analysis_results))
        doc.append(self._generate_business_logic_detailed(analysis_results))
        doc.append(self._generate_technical_specifications(analysis_results))
        doc.append(self._generate_implementation_guide(analysis_results, target_language))
        doc.append(self._generate_validation_checklist(analysis_results))
        return "\n\n".join(doc)

    def _generate_header(self, data: Dict[str, Any]) -> str:
        program_name = data.get("program_name", "UNKNOWN")
        return f"""# Documentação Técnica Completa: {program_name}

**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M')}  
**Versão do Analisador:** COBOL AI Engine v8.0 - Análise Híbrida Avançada  
**Método de Análise:** Combinação de parsing estrutural + análise semântica via LLM"""

    def _generate_executive_summary(self, data: Dict[str, Any]) -> str:
        hybrid_analysis = data.get("functional_analysis", {})
        purpose = hybrid_analysis.get("program_purpose", "Não determinado")
        
        return f"""## 1. Resumo Executivo

### Propósito do Programa
{purpose}

### Classificação
- **Tipo:** {self._classify_program_type(hybrid_analysis)}
- **Complexidade:** {self._assess_complexity(hybrid_analysis)}
- **Criticidade:** {self._assess_criticality(hybrid_analysis)}"""

    def _generate_detailed_architecture(self, data: Dict[str, Any]) -> str:
        hybrid_analysis = data.get("functional_analysis", {})
        
        doc = ["## 2. Arquitetura Detalhada de Dados"]
        
        # Arquivos de Entrada
        doc.append("### 2.1 Arquivos de Entrada")
        input_files = hybrid_analysis.get("input_files", [])
        if input_files:
            doc.append("| Nome Lógico | Nome Físico | Tamanho Reg. | Formato | Descrição |")
            doc.append("|---|---|---|---|---|")
            for file_info in input_files:
                doc.append(f"| {file_info.get('logical_name', 'N/A')} | {file_info.get('physical_name', 'N/A')} | {file_info.get('record_size', 'N/A')} | {file_info.get('format', 'N/A')} | {file_info.get('description', 'N/A')} |")
            
            # Detalhamento dos campos de cada arquivo
            for file_info in input_files:
                if file_info.get('fields'):
                    doc.append(f"\n#### Estrutura de {file_info.get('logical_name', 'Arquivo')}")
                    doc.append("| Campo | Posição | Tamanho | Tipo | PIC | Uso |")
                    doc.append("|---|---|---|---|---|---|")
                    for field in file_info['fields']:
                        doc.append(f"| {field.get('name', 'N/A')} | {field.get('position', 'N/A')} | {field.get('length', 'N/A')} | {field.get('type', 'N/A')} | {field.get('picture', 'N/A')} | {field.get('usage', 'N/A')} |")
        else:
            doc.append("Nenhum arquivo de entrada identificado.")

        # Arquivos de Saída
        doc.append("\n### 2.2 Arquivos de Saída")
        output_files = hybrid_analysis.get("output_files", [])
        if output_files:
            doc.append("| Nome Lógico | Nome Físico | Tamanho Reg. | Formato | Descrição |")
            doc.append("|---|---|---|---|---|")
            for file_info in output_files:
                doc.append(f"| {file_info.get('logical_name', 'N/A')} | {file_info.get('physical_name', 'N/A')} | {file_info.get('record_size', 'N/A')} | {file_info.get('format', 'N/A')} | {file_info.get('description', 'N/A')} |")
        else:
            doc.append("Nenhum arquivo de saída identificado.")

        # Estruturas de Dados
        doc.append("\n### 2.3 Estruturas de Dados (Working-Storage)")
        data_structures = hybrid_analysis.get("data_structures", [])
        if data_structures:
            doc.append("| Campo | Tipo | Tamanho | Valor Inicial | Propósito |")
            doc.append("|---|---|---|---|---|")
            for struct in data_structures:
                doc.append(f"| {struct.get('name', 'N/A')} | {struct.get('type', 'N/A')} | {struct.get('size', 'N/A')} | {struct.get('initial_value', 'N/A')} | {struct.get('purpose', 'N/A')} |")
        else:
            doc.append("Nenhuma estrutura de dados identificada.")

        return "\n".join(doc)

    def _generate_business_logic_detailed(self, data: Dict[str, Any]) -> str:
        hybrid_analysis = data.get("functional_analysis", {})
        
        doc = ["## 3. Lógica de Negócio Detalhada"]
        
        # Lógica passo a passo
        doc.append("### 3.1 Fluxo de Processamento")
        business_logic = hybrid_analysis.get("business_logic", [])
        if business_logic:
            for step in business_logic:
                step_num = step.get("step", "N/A")
                description = step.get("description", "N/A")
                conditions = step.get("conditions", "N/A")
                actions = step.get("actions", "N/A")
                
                doc.append(f"#### Passo {step_num}: {description}")
                doc.append(f"**Condições:** {conditions}")
                doc.append(f"**Ações:** {actions}")
        else:
            doc.append("Lógica de negócio não detalhada.")

        # Fluxo de controle
        doc.append("\n### 3.2 Fluxo de Controle")
        control_flow = hybrid_analysis.get("control_flow", [])
        if control_flow:
            doc.append("| Parágrafo | Chama | Condições |")
            doc.append("|---|---|---|")
            for flow in control_flow:
                paragraph = flow.get("paragraph", "N/A")
                calls = ", ".join(flow.get("calls", []))
                conditions = flow.get("conditions", "N/A")
                doc.append(f"| {paragraph} | {calls} | {conditions} |")
        else:
            doc.append("Fluxo de controle não mapeado.")

        return "\n".join(doc)

    def _generate_technical_specifications(self, data: Dict[str, Any]) -> str:
        hybrid_analysis = data.get("functional_analysis", {})
        
        doc = ["## 4. Especificações Técnicas"]
        
        # Constantes e limites
        doc.append("### 4.1 Constantes e Limites")
        constants = hybrid_analysis.get("constants_and_limits", [])
        if constants:
            doc.append("| Nome | Valor | Uso |")
            doc.append("|---|---|---|")
            for const in constants:
                doc.append(f"| {const.get('name', 'N/A')} | {const.get('value', 'N/A')} | {const.get('usage', 'N/A')} |")
        else:
            doc.append("Nenhuma constante identificada.")

        # Tratamento de erros
        doc.append("\n### 4.2 Tratamento de Erros")
        error_handling = hybrid_analysis.get("error_handling", [])
        if error_handling:
            doc.append("| Condição de Erro | Ação |")
            doc.append("|---|---|")
            for error in error_handling:
                doc.append(f"| {error.get('condition', 'N/A')} | {error.get('action', 'N/A')} |")
        else:
            doc.append("Tratamento de erros não documentado.")

        # Considerações de performance
        doc.append("\n### 4.3 Considerações de Performance")
        performance = hybrid_analysis.get("performance_considerations", [])
        if performance:
            for perf in performance:
                doc.append(f"- **{perf.get('aspect', 'N/A')}:** {perf.get('details', 'N/A')}")
        else:
            doc.append("Nenhuma consideração de performance identificada.")

        return "\n".join(doc)

    def _generate_implementation_guide(self, data: Dict[str, Any], target_language: str) -> str:
        hybrid_analysis = data.get("functional_analysis", {})
        program_name = data.get("program_name", "CobolProgram")
        
        doc = [f"## 5. Guia de Implementação ({target_language.title()})"]
        
        if target_language.lower() == "java":
            doc.append(self._generate_java_implementation(hybrid_analysis, program_name))
        elif target_language.lower() == "python":
            doc.append(self._generate_python_implementation(hybrid_analysis, program_name))
        else:
            doc.append("Linguagem de implementação não suportada.")

        return "\n".join(doc)

    def _generate_java_implementation(self, analysis: Dict[str, Any], program_name: str) -> str:
        class_name = program_name.replace("-", "")
        
        code = [f"```java"]
        code.append(f"public class {class_name} {{")
        code.append("")
        
        # Constantes
        constants = analysis.get("constants_and_limits", [])
        if constants:
            code.append("    // Constantes do programa")
            for const in constants:
                name = const.get('name', 'UNKNOWN').replace('-', '_').upper()
                value = const.get('value', '""')
                code.append(f"    private static final String {name} = {value};")
            code.append("")
        
        # Estruturas de dados
        data_structures = analysis.get("data_structures", [])
        if data_structures:
            code.append("    // Estruturas de dados")
            for struct in data_structures:
                name = struct.get('name', 'unknown').replace('-', '_').lower()
                java_type = self._cobol_to_java_type(struct.get('type', 'String'))
                code.append(f"    private {java_type} {name};")
            code.append("")
        
        # Método principal
        code.append("    public void process() {")
        
        # Lógica de negócio
        business_logic = analysis.get("business_logic", [])
        if business_logic:
            code.append("        // Implementação da lógica de negócio")
            for step in business_logic:
                description = step.get('description', 'Passo não descrito')
                code.append(f"        // {description}")
                actions = step.get('actions', 'Ações não especificadas')
                code.append(f"        // TODO: {actions}")
                code.append("")
        
        code.append("    }")
        code.append("}")
        code.append("```")
        
        return "\n".join(code)

    def _generate_python_implementation(self, analysis: Dict[str, Any], program_name: str) -> str:
        class_name = program_name.replace("-", "").title()
        
        code = ["```python"]
        code.append(f"class {class_name}:")
        code.append("    def __init__(self):")
        
        # Inicialização de variáveis
        data_structures = analysis.get("data_structures", [])
        if data_structures:
            for struct in data_structures:
                name = struct.get('name', 'unknown').replace('-', '_').lower()
                initial_value = struct.get('initial_value', 'None')
                code.append(f"        self.{name} = {initial_value}")
        else:
            code.append("        pass")
        
        code.append("")
        code.append("    def process(self):")
        code.append("        \"\"\"Método principal de processamento\"\"\"")
        
        # Lógica de negócio
        business_logic = analysis.get("business_logic", [])
        if business_logic:
            for step in business_logic:
                description = step.get('description', 'Passo não descrito')
                code.append(f"        # {description}")
                actions = step.get('actions', 'Ações não especificadas')
                code.append(f"        # TODO: {actions}")
                code.append("")
        else:
            code.append("        pass")
        
        code.append("```")
        
        return "\n".join(code)

    def _generate_validation_checklist(self, data: Dict[str, Any]) -> str:
        doc = ["## 6. Checklist de Validação da Implementação"]
        doc.append("Use este checklist para validar se sua implementação está completa:")
        doc.append("")
        
        hybrid_analysis = data.get("functional_analysis", {})
        
        # Checklist baseado na análise
        checklist_items = [
            "[ ] Todos os arquivos de entrada foram implementados com estruturas corretas",
            "[ ] Todos os arquivos de saída foram implementados com formatos corretos",
            "[ ] Todas as estruturas de dados foram definidas com tipos apropriados",
            "[ ] Todas as constantes e limites foram definidos corretamente",
            "[ ] A lógica de negócio foi implementada passo a passo conforme especificado",
            "[ ] O fluxo de controle segue a sequência correta de parágrafos",
            "[ ] O tratamento de erros foi implementado para todas as condições identificadas",
            "[ ] As considerações de performance foram aplicadas",
            "[ ] Testes unitários foram criados para cada regra de negócio",
            "[ ] Testes de integração foram criados para o fluxo completo"
        ]
        
        doc.extend(checklist_items)
        
        return "\n".join(doc)

    def _classify_program_type(self, analysis: Dict[str, Any]) -> str:
        purpose = analysis.get("program_purpose", "").lower()
        if "batch" in purpose or "arquivo" in purpose:
            return "Processamento em Lote"
        elif "online" in purpose or "transacao" in purpose:
            return "Transacional Online"
        elif "relatorio" in purpose or "report" in purpose:
            return "Geração de Relatórios"
        else:
            return "Não Classificado"

    def _assess_complexity(self, analysis: Dict[str, Any]) -> str:
        business_logic_count = len(analysis.get("business_logic", []))
        if business_logic_count > 10:
            return "Alta"
        elif business_logic_count > 5:
            return "Média"
        else:
            return "Baixa"

    def _assess_criticality(self, analysis: Dict[str, Any]) -> str:
        # Análise simples baseada em palavras-chave
        purpose = analysis.get("program_purpose", "").lower()
        if any(word in purpose for word in ["financeiro", "pagamento", "contabil"]):
            return "Crítica"
        elif any(word in purpose for word in ["relatorio", "consulta"]):
            return "Baixa"
        else:
            return "Média"

    def _cobol_to_java_type(self, cobol_type: str) -> str:
        type_mapping = {
            "numeric": "BigDecimal",
            "alphanumeric": "String",
            "group": "Object",
            "binary": "byte[]"
        }
        return type_mapping.get(cobol_type.lower(), "String")
