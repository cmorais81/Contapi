#!/usr/bin/env python3
"""
COBOL AI Engine v1.0.0 - LuzIA Provider Consolidado
Provedor LuzIA unificado com suporte para API REST e AWS Bedrock.
"""

import os
import json
import logging
import time
import warnings
from typing import Dict, Any, Optional, List
from datetime import datetime

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

try:
    import boto3
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse


class LuziaProvider(BaseProvider):
    """
    Provedor LuzIA consolidado com suporte para:
    1. API REST (configuração padrão)
    2. AWS Bedrock (configuração aws)
    
    Características:
    - Lê configurações do config.yaml
    - Suporte a token splitting
    - Retry automático com backoff
    - Rate limiting
    - Fallback entre modos
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor LuzIA consolidado.
        
        Args:
            config: Configuração do provedor
        """
        super().__init__(config)
        self.logger = logging.getLogger(__name__)
        
        # Configurações básicas
        self.mode = config.get('mode', 'rest')  # 'rest' ou 'aws'
        self.model = config.get('model', 'aws-claude-3-5-sonnet')
        self.temperature = config.get('temperature', 0.05)
        self.max_tokens = config.get('max_tokens', 8000)
        self.timeout = config.get('timeout', 180)
        
        # Configurações de retry
        retry_config = config.get('retry', {})
        self.max_attempts = retry_config.get('max_attempts', 3)
        self.base_delay = retry_config.get('base_delay', 2.0)
        self.max_delay = retry_config.get('max_delay', 30.0)
        self.backoff_multiplier = retry_config.get('backoff_multiplier', 2.0)
        self.requests_per_minute = retry_config.get('requests_per_minute', 8)
        
        # Inicializa o modo apropriado
        if self.mode == 'aws':
            self._init_aws_mode(config)
        else:
            self._init_rest_mode(config)
        
        self.logger.info(f"LuzIA Provider inicializado em modo {self.mode}")
    
    def _init_rest_mode(self, config: Dict[str, Any]):
        """Inicializa modo REST API."""
        self.client_id = config.get('client_id', '')
        self.client_secret = config.get('client_secret', '')
        self.auth_url = config.get('auth_url', '')
        self.api_url = config.get('api_url', '')
        
        if not all([self.client_id, self.client_secret, self.auth_url, self.api_url]):
            self.logger.warning("Configurações REST incompletas, usando modo mock")
            self.mode = 'mock'
        
        self.access_token = None
        self.token_expires_at = 0
        self.last_request_time = 0
    
    def _init_aws_mode(self, config: Dict[str, Any]):
        """Inicializa modo AWS Bedrock."""
        if not BOTO3_AVAILABLE:
            self.logger.warning("boto3 não disponível, usando modo mock")
            self.mode = 'mock'
            return
        
        self.region_name = config.get('region_name', 'us-east-1')
        self.model_id = config.get('model_id', 'anthropic.claude-3-5-sonnet-20240620-v1:0')
        
        try:
            self.bedrock_client = boto3.client(
                service_name='bedrock-runtime',
                region_name=self.region_name
            )
        except Exception as e:
            self.logger.warning(f"Erro ao inicializar AWS Bedrock: {e}, usando modo mock")
            self.mode = 'mock'
    
    def _get_access_token(self) -> Optional[str]:
        """Obtém token de acesso para API REST."""
        if self.mode != 'rest':
            return None
        
        current_time = time.time()
        
        # Verifica se o token ainda é válido
        if self.access_token and current_time < self.token_expires_at:
            return self.access_token
        
        try:
            # Solicita novo token
            auth_data = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            response = requests.post(
                self.auth_url,
                data=auth_data,
                timeout=30,
                verify=False
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self.access_token = token_data.get('access_token')
                expires_in = token_data.get('expires_in', 3600)
                self.token_expires_at = current_time + expires_in - 60  # Margem de 60s
                
                self.logger.info("Token de acesso obtido com sucesso")
                return self.access_token
            else:
                self.logger.error(f"Erro ao obter token: {response.status_code}")
                return None
                
        except Exception as e:
            self.logger.error(f"Erro na autenticação: {e}")
            return None
    
    def _rate_limit(self):
        """Implementa rate limiting."""
        if self.requests_per_minute <= 0:
            return
        
        min_interval = 60.0 / self.requests_per_minute
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < min_interval:
            sleep_time = min_interval - time_since_last
            self.logger.debug(f"Rate limiting: aguardando {sleep_time:.2f}s")
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def _make_rest_request(self, prompt: str) -> str:
        """Faz requisição via API REST."""
        token = self._get_access_token()
        if not token:
            raise Exception("Não foi possível obter token de acesso")
        
        self._rate_limit()
        
        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        
        payload = {
            'model': self.model,
            'messages': [
                {
                    'role': 'user',
                    'content': prompt
                }
            ],
            'temperature': self.temperature,
            'max_tokens': self.max_tokens
        }
        
        response = requests.post(
            f"{self.api_url}/chat/completions",
            headers=headers,
            json=payload,
            timeout=self.timeout,
            verify=False
        )
        
        if response.status_code == 200:
            result = response.json()
            return result.get('choices', [{}])[0].get('message', {}).get('content', '')
        else:
            raise Exception(f"Erro na API REST: {response.status_code} - {response.text}")
    
    def _make_aws_request(self, prompt: str) -> str:
        """Faz requisição via AWS Bedrock."""
        body = json.dumps({
            "prompt": f"\n\nHuman: {prompt}\n\nAssistant:",
            "max_tokens_to_sample": self.max_tokens,
            "temperature": self.temperature,
            "top_p": 0.9,
        })
        
        response = self.bedrock_client.invoke_model(
            body=body,
            modelId=self.model_id,
            accept='application/json',
            contentType='application/json'
        )
        
        response_body = json.loads(response['body'].read())
        return response_body.get('completion', '')
    
    def _make_mock_request(self, prompt: str) -> str:
        """Gera resposta mock para testes."""
        self.logger.info("Usando resposta mock do LuzIA")
        
        # Resposta específica para análise COBOL
        if "COBOL" in prompt.upper() or "PROGRAM" in prompt.upper():
            return """
## Análise Funcional do Programa COBOL

### Propósito
Este programa COBOL processa arquivos de dados realizando validações, transformações e geração de relatórios.

### Regras de Negócio Identificadas
1. **Validação de Entrada**: Verifica integridade dos dados de entrada
2. **Processamento Condicional**: Aplica regras baseadas em tipos de registro
3. **Geração de Saída**: Produz arquivos formatados e relatórios

### Fluxo de Dados
- **Entrada**: Arquivo principal de dados
- **Processamento**: Validação, transformação e cálculos
- **Saída**: Arquivos processados e relatórios

### Pontos Críticos
- Validação de campos obrigatórios
- Tratamento de erros e exceções
- Controle de integridade referencial

### Score de Reimplementação: 75%
O programa apresenta estrutura clara e lógica bem definida, facilitando a reimplementação.
"""
        
        return "Análise realizada com sucesso usando provedor mock LuzIA."
    
    def generate_text(self, request: AIRequest) -> AIResponse:
        """
        Gera texto usando o provedor LuzIA.
        
        Args:
            request: Requisição de IA
            
        Returns:
            Resposta da IA
        """
        start_time = time.time()
        
        for attempt in range(self.max_attempts):
            try:
                self.logger.info(f"LuzIA: Tentativa {attempt + 1}/{self.max_attempts}")
                
                # Escolhe o método baseado no modo
                if self.mode == 'rest':
                    response_text = self._make_rest_request(request.prompt)
                elif self.mode == 'aws':
                    response_text = self._make_aws_request(request.prompt)
                else:
                    response_text = self._make_mock_request(request.prompt)
                
                # Sucesso
                end_time = time.time()
                
                return AIResponse(
                    content=response_text,
                    model=self.model,
                    provider="luzia",
                    tokens_used=len(response_text.split()),
                    response_time=end_time - start_time,
                    success=True
                )
                
            except Exception as e:
                self.logger.warning(f"Tentativa {attempt + 1} falhou: {e}")
                
                if attempt < self.max_attempts - 1:
                    delay = min(self.base_delay * (self.backoff_multiplier ** attempt), self.max_delay)
                    self.logger.info(f"Aguardando {delay:.2f}s antes da próxima tentativa")
                    time.sleep(delay)
                else:
                    # Última tentativa falhou, usar mock
                    self.logger.error("Todas as tentativas falharam, usando resposta mock")
                    response_text = self._make_mock_request(request.prompt)
                    
                    end_time = time.time()
                    return AIResponse(
                        content=response_text,
                        model="luzia-mock",
                        provider="luzia",
                        tokens_used=len(response_text.split()),
                        response_time=end_time - start_time,
                        success=False,
                        error=str(e)
                    )
    
    def is_available(self) -> bool:
        """Verifica se o provedor está disponível."""
        if self.mode == 'rest':
            return REQUESTS_AVAILABLE and bool(self.client_id and self.client_secret)
        elif self.mode == 'aws':
            return BOTO3_AVAILABLE
        else:
            return True  # Mock sempre disponível
    
    def get_model_info(self) -> Dict[str, Any]:
        """Retorna informações do modelo."""
        return {
            'provider': 'luzia',
            'mode': self.mode,
            'model': self.model,
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'available': self.is_available()
        }


# Classe para compatibilidade com código existente
class LuziaAWSProvider(LuziaProvider):
    """Alias para compatibilidade com código existente."""
    
    def __init__(self, config: Dict[str, Any]):
        # Força modo AWS
        config['mode'] = 'aws'
        super().__init__(config)
