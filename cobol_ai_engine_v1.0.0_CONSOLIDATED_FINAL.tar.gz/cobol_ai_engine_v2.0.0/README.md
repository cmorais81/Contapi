# COBOL AI Engine v1.0.0

Uma ferramenta avançada de análise e documentação de programas COBOL que combina parsing interno com inteligência artificial para gerar documentação funcional detalhada.

## Características Principais

- **Análise Universal:** Funciona com qualquer programa COBOL (não apenas padrões específicos)
- **Documentação Funcional:** Gera especificações técnicas para reimplementação
- **Multi-LLM:** Suporte a OpenAI, GitHub Copilot, LuzIA e outros
- **Compatibilidade Total:** macOS, Linux, Windows com Python 3.11+

## Instalação Rápida

```bash
# 1. Extrair o pacote
tar -xzf cobol_ai_engine_v1.0.0_FINAL.tar.gz
cd cobol_ai_engine_v2.0.0

# 2. Instalar dependências
python3.11 -m venv venv
source venv/bin/activate  # Linux/macOS
# ou venv\Scripts\activate  # Windows
pip install -r requirements.txt

# 3. Executar demonstração
python main_demo.py
```

## Uso Básico

```bash
# Análise completa
python main.py examples/fontes.txt examples/BOOKS.txt

# Análise com configuração personalizada
python main.py examples/fontes.txt examples/BOOKS.txt --config config/config.yaml

# Modo verboso
python main.py examples/fontes.txt examples/BOOKS.txt --verbose
```

## Documentação

- **Manual Completo:** `docs/MANUAL_COMPLETO_v1.0.0.md`
- **Guia de Início Rápido:** `docs/GUIA_INICIO_RAPIDO.md`
- **Manual de Configuração:** `docs/MANUAL_CONFIGURACAO.md`
- **Manual de Provedores:** `docs/MANUAL_PROVEDORES.md`
- **Notas de Lançamento:** `docs/RELEASE_NOTES_v1.0.0.md`

## Estrutura do Projeto

```
cobol_ai_engine_v2.0.0/
├── main.py                    # Script principal
├── main_demo.py              # Demonstração rápida
├── config/                   # Configurações
├── docs/                     # Documentação
├── examples/                 # Arquivos de exemplo
├── src/                      # Código fonte
│   ├── analyzers/           # Analisadores
│   ├── generators/          # Geradores de documentação
│   ├── parsers/             # Parsers COBOL
│   ├── providers/           # Provedores LLM
│   └── utils/               # Utilitários
├── requirements.txt         # Dependências Linux/Windows
└── requirements_macos.txt   # Dependências macOS
```

## Suporte

Para dúvidas e suporte, consulte a documentação completa em `docs/`.

---

**Versão:** 1.0.0  
**Data:** Setembro 2025  
**Compatibilidade:** Python 3.11+, Linux, macOS, Windows
