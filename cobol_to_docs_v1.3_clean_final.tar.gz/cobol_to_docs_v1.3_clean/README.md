# COBOL to Docs v1.3

Análise e Documentação de Código COBOL com Inteligência Artificial e RAG

## Visão Geral

O COBOL to Docs v1.3 é uma ferramenta de linha de comando projetada para analisar, documentar e auxiliar na modernização de sistemas legados escritos em COBOL. Sua principal característica é um sistema avançado de Geração Aumentada por Recuperação (RAG), que enriquece as análises com uma base de conhecimento especializada em COBOL, DB2, CICS e práticas do setor bancário.

A ferramenta gera documentação funcional detalhada, fornece insights técnicos profundos, identifica padrões de código, extrai regras de negócio e oferece recomendações estratégicas para modernização.

## Principais Funcionalidades da v1.3

- Análise Inteligente com RAG: Utiliza uma base de conhecimento consolidada para enriquecer as análises
- Auto-Learning: A base de conhecimento RAG se expande automaticamente a cada análise bem-sucedida
- Logging Transparente: Gera relatórios detalhados sobre o uso do RAG a cada execução
- Múltiplos Modos de Análise: Desde visão funcional até análise técnica profunda e sistêmica
- Suporte a Múltiplos Provedores: Compatível com LuzIA (Claude 3.5), OpenAI (GPT-4), Bedrock e outros
- Análise de Modernização: Gera recomendações para migração e tradução para Python
- Flexibilidade: Altamente configurável através de arquivos YAML
- Múltiplos Formatos: Documentação em Markdown com opção de conversão para PDF

## Instalação Rápida

1. Extraia o pacote:
   ```bash
   tar -xzf cobol_to_docs_v1.3.tar.gz
   cd cobol_to_docs_v1.3
   ```

2. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```

3. Execute sua primeira análise:
   ```bash
   python main.py --fontes examples/fontes.txt
   ```

## Como Usar

A ferramenta é operada via linha de comando. O uso mais básico envolve fornecer um arquivo ou uma lista de arquivos COBOL.

```bash
# Analisar uma lista de programas
python main.py --fontes examples/fontes.txt

# Análise consolidada com copybooks e saída em PDF
python main.py --fontes examples/fontes.txt --books examples/books.txt --consolidado --pdf
```

Para uma lista completa de comandos e suas combinações, consulte o arquivo `docs/GUIA_DE_COMANDOS.md`.

## Documentação Completa

O pacote inclui documentação detalhada na pasta `docs/`:

- `GUIA_COMPLETO_USO_v1.3.md`: Guia detalhado sobre todas as funcionalidades
- `GUIA_DE_COMANDOS.md`: Exemplos práticos de todos os comandos
- `DOCUMENTACAO_TECNICA.md`: Detalhes sobre arquitetura e funcionamento interno

## Sistema RAG

O sistema RAG (Retrieval-Augmented Generation) é o diferencial da v1.3:

- Base de conhecimento especializada em COBOL, sistemas bancários e mainframe
- Busca semântica automática por padrões relevantes
- Enriquecimento inteligente dos prompts enviados para IA
- Logging transparente de todas as operações para auditoria
- Auto-aprendizado contínuo a partir das análises realizadas

## Configuração

A ferramenta é configurada através do arquivo `config/config.yaml`:

```yaml
# Configuração do RAG
rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base.json"
  auto_learn: true
  log_dir: "logs"
  enable_console_logs: true

# Provedores de IA
ai:
  primary_provider: "luzia"
  fallback_providers: ["enhanced_mock"]
```

## Contribuição

Este projeto é extensível. Você pode contribuir:

- Enriquecendo a base de conhecimento RAG no arquivo `data/cobol_knowledge_base.json`
- Criando novos prompts em `config/prompts_melhorado_rag.yaml`
- Adicionando novos provedores de IA na pasta `src/providers/`

## Versão

1.3.0 - Sistema RAG com logging transparente e base de conhecimento consolidada

## Autor

Carlos Morais - Setembro 2025
