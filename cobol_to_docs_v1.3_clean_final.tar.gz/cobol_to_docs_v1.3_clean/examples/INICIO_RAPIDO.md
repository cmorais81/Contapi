# Início Rápido - COBOL to Docs v1.1

**Autor:** Carlos Morais  
**Tempo estimado:** 5 minutos

Guia para começar a usar o COBOL to Docs v1.1 rapidamente.

## Pré-requisitos

- Python 3.11+
- Arquivos COBOL (.cbl, .cob) ou copybooks (.cpy)

## Passo 1: Verificar Sistema

```bash
python3 main.py --status
```

**Resultado esperado:**
```
enhanced_mock: Disponível
basic: Disponível
Sistema pronto para uso
```

## Passo 2: Primeira Análise

### Opção A: Usar Exemplos Incluídos
```bash
python3 main.py --fontes examples/fontes.txt --models enhanced_mock
```

### Opção B: Usar Seus Arquivos
```bash
# Criar lista de seus arquivos
echo "meu_programa.cbl" > meus_fontes.txt

# Analisar
python3 main.py --fontes meus_fontes.txt --models enhanced_mock
```

### Opção C: Código COBOL Direto
```bash
# Se você tem um arquivo com código COBOL completo
python3 main.py --fontes arquivo_com_codigo.txt --models enhanced_mock
```

## Passo 3: Ver Resultados

```bash
# Listar arquivos gerados
ls -la output/

# Ver documentação gerada
cat output/*_analise_funcional.md
```

## Passo 4: Análise com Copybooks

```bash
python3 main.py --fontes examples/fontes.txt --books examples/books.txt --models enhanced_mock
```

## Comandos Essenciais

### Status do Sistema
```bash
python3 main.py --status
```

### Análise Básica
```bash
python3 main.py --fontes ARQUIVO_FONTES --models enhanced_mock
```

### Análise Completa
```bash
python3 main.py --fontes ARQUIVO_FONTES --books ARQUIVO_BOOKS --models enhanced_mock
```

### Gerar Prompts Personalizados
```bash
python3 generate_prompts.py --input requisitos.txt
```

### Análise Multi-Modelo
```bash
python3 main.py --fontes ARQUIVO_FONTES --models '["enhanced_mock","basic"]'
```

## Formatos de Arquivo Suportados

### Lista de Arquivos (fontes.txt)
```
# Comentários começam com #
programa1.cbl
programa2.cbl
copybook1.cpy
```

### Código COBOL Direto
```
IDENTIFICATION DIVISION.
PROGRAM-ID. MEU-PROGRAMA.
PROCEDURE DIVISION.
DISPLAY 'HELLO WORLD'.
STOP RUN.
```

## Resultados Gerados

Após cada análise, você encontrará:

- **programa_analise_funcional.md** - Documentação principal
- **programa_ai_response.json** - Resposta completa da IA
- **programa_ai_request.json** - Parâmetros da requisição

## Exemplo Completo

```bash
# 1. Verificar sistema
python3 main.py --status

# 2. Análise com exemplos
python3 main.py --fontes examples/fontes.txt --books examples/books.txt --models enhanced_mock

# 3. Ver resultados
ls output/
cat output/*_analise_funcional.md

# 4. Gerar prompts personalizados
python3 generate_prompts.py --input examples/requisitos_exemplo.txt

# 5. Usar prompts personalizados
python3 main.py --fontes examples/fontes.txt --prompts-file requisitos_exemplo_prompts.yaml
```

## Troubleshooting Rápido

### "Arquivo não encontrado"
- Verifique se o arquivo existe
- Use caminho completo ou relativo correto

### "Provider não disponível"
- Use `enhanced_mock` para testes
- Configure credenciais em `config/config.yaml` para providers reais

### "Nenhum arquivo processado"
- Verifique formato do arquivo de fontes
- Certifique-se que não há apenas comentários

## Próximos Passos

1. **Tutorial Completo:** `jupyter notebook examples/COBOL_to_Docs_Tutorial.ipynb`
2. **Documentação:** `docs/GUIA_COMPLETO_USO.md`
3. **Configuração Avançada:** `docs/DOCUMENTACAO_TECNICA.md`

## Exemplo de Saída

```
COBOL to Docs v1.1 - Iniciando análise
Detectado código COBOL direto em fontes.txt
Código COBOL salvo temporariamente em: /tmp/tmp123.cbl
Iniciando análise do programa: MEU-PROGRAMA
enhanced_mock respondeu em 0.51s - 1,234 tokens
Documentação funcional gerada: MEU-PROGRAMA_analise_funcional.md

Análises bem-sucedidas: 1/1
Taxa de sucesso geral: 100.0%
Total de tokens utilizados: 1,234
Tempo total de processamento: 0.51s
Documentação gerada em: output
```

---

**Pronto! Você já está usando o COBOL to Docs v1.1**

Para funcionalidades avançadas, consulte a documentação completa em `docs/`.

**COBOL to Docs v1.1 - Desenvolvido por Carlos Morais**
