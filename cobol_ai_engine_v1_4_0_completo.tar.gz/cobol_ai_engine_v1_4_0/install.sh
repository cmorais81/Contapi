#!/bin/bash

# COBOL AI Engine v1.4.0 - Script de Instalação Automática
# Este script configura automaticamente o ambiente para teste

set -e  # Parar em caso de erro

echo "============================================================"
echo "COBOL AI Engine v1.4.0 - Instalação Automática"
echo "============================================================"

# Verificar Python
echo "1. Verificando Python..."
if ! command -v python3 &> /dev/null; then
    echo "ERRO: Python 3 não encontrado. Instale Python 3.8+ primeiro."
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
echo "   Python encontrado: $PYTHON_VERSION"

# Verificar pip
echo "2. Verificando pip..."
if ! command -v pip3 &> /dev/null; then
    echo "ERRO: pip3 não encontrado. Instale pip primeiro."
    exit 1
fi
echo "   pip3 encontrado"

# Criar diretórios necessários
echo "3. Criando estrutura de diretórios..."
mkdir -p logs
mkdir -p output
mkdir -p examples
mkdir -p src/providers
mkdir -p src/utils
echo "   Diretórios criados"

# Instalar dependências
echo "4. Instalando dependências Python..."
pip3 install --user requests urllib3 python-dateutil
echo "   Dependências instaladas"

# Verificar instalação
echo "5. Verificando instalação..."
python3 -c "import requests, urllib3; print('   Dependências OK')"

# Criar arquivo de exemplo se não existir
if [ ! -f "examples/fontes.txt" ]; then
    echo "6. Criando arquivo de exemplo..."
    cat > examples/fontes.txt << 'EOF'
PROGRAM-ID. EXEMPLO-TESTE.
IDENTIFICATION DIVISION.
PROGRAM-ID. EXEMPLO-TESTE.
AUTHOR. SISTEMA-TESTE.
DATE-WRITTEN. 22/09/2025.

ENVIRONMENT DIVISION.
CONFIGURATION SECTION.
SOURCE-COMPUTER. IBM-370.
OBJECT-COMPUTER. IBM-370.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CONTADOR         PIC 9(3) VALUE 0.
01 WS-MENSAGEM         PIC X(50) VALUE 'SISTEMA FUNCIONANDO CORRETAMENTE'.
01 WS-STATUS           PIC X(10) VALUE 'ATIVO'.

PROCEDURE DIVISION.
MAIN-PARA.
    DISPLAY 'INICIANDO PROGRAMA DE TESTE'.
    PERFORM PROCESSAR-DADOS.
    DISPLAY 'PROGRAMA FINALIZADO COM SUCESSO'.
    STOP RUN.

PROCESSAR-DADOS.
    MOVE 1 TO WS-CONTADOR.
    DISPLAY WS-MENSAGEM.
    DISPLAY 'CONTADOR: ' WS-CONTADOR.
    DISPLAY 'STATUS: ' WS-STATUS.

PROGRAM-ID. SEGUNDO-PROGRAMA.
IDENTIFICATION DIVISION.
PROGRAM-ID. SEGUNDO-PROGRAMA.
AUTHOR. SISTEMA-TESTE.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-VALOR            PIC 9(5)V99 VALUE 100.50.
01 WS-RESULTADO        PIC 9(5)V99 VALUE ZERO.

PROCEDURE DIVISION.
INICIO.
    COMPUTE WS-RESULTADO = WS-VALOR * 1.10.
    DISPLAY 'VALOR ORIGINAL: ' WS-VALOR.
    DISPLAY 'RESULTADO: ' WS-RESULTADO.
    STOP RUN.
EOF
    echo "   Arquivo de exemplo criado"
else
    echo "6. Arquivo de exemplo já existe"
fi

# Verificar permissões
echo "7. Configurando permissões..."
chmod +x *.py 2>/dev/null || true
echo "   Permissões configuradas"

echo ""
echo "============================================================"
echo "INSTALAÇÃO CONCLUÍDA COM SUCESSO!"
echo "============================================================"
echo ""
echo "Próximos passos:"
echo ""
echo "1. Configure suas credenciais LuzIA:"
echo "   export LUZIA_CLIENT_ID=\"seu_client_id\""
echo "   export LUZIA_CLIENT_SECRET=\"seu_client_secret\""
echo ""
echo "2. Teste a conectividade:"
echo "   python3 luzia_provider_standalone.py"
echo ""
echo "3. Execute uma análise de teste:"
echo "   python3 main_final_v1_4_0.py examples/fontes.txt"
echo ""
echo "4. Para testes completos:"
echo "   python3 test_enhanced_system.py"
echo ""
echo "Documentação disponível:"
echo "- README_v1_4_0.md"
echo "- GUIA_INSTALACAO_v1_4_0.md"
echo "- CORRECOES_IMPLEMENTADAS_v1_4_0.md"
echo ""
echo "============================================================"
