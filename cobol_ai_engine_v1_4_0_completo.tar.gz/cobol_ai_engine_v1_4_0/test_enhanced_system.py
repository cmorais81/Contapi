#!/usr/bin/env python3
"""
Teste do Sistema COBOL AI Engine v1.4.0 Enhanced
Script independente para validar as correções implementadas.
"""

import os
import sys
import json
import time
import logging
from datetime import datetime
from pathlib import Path

# Importar módulos diretamente
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def setup_test_logging():
    """Configura logging para testes."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    return logging.getLogger('TestEnhancedSystem')

def test_token_manager():
    """Testa o gerenciador de tokens."""
    logger = logging.getLogger('TestTokenManager')
    logger.info("=== TESTANDO TOKEN MANAGER ===")
    
    try:
        from providers.luzia_provider_enhanced import TokenManager
        
        client_id = os.getenv("LUZIA_CLIENT_ID")
        client_secret = os.getenv("LUZIA_CLIENT_SECRET")
        auth_url = "https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token"
        
        if not client_id or not client_secret:
            logger.warning("Credenciais não configuradas, simulando teste...")
            return {
                "test": "token_manager",
                "status": "skipped",
                "reason": "credentials_not_configured"
            }
        
        token_manager = TokenManager(client_id, client_secret, auth_url)
        
        # Testar obtenção de token
        logger.info("Testando obtenção de token...")
        token = token_manager.get_valid_token()
        
        if token:
            logger.info("Token obtido com sucesso")
            
            # Testar validação de token
            is_valid = token_manager.is_token_valid()
            logger.info(f"Token válido: {is_valid}")
            
            return {
                "test": "token_manager",
                "status": "success",
                "token_obtained": True,
                "token_valid": is_valid,
                "expires_at": token_manager.token_expires_at.isoformat() if token_manager.token_expires_at else None
            }
        else:
            logger.error("Falha ao obter token")
            return {
                "test": "token_manager",
                "status": "failed",
                "error": "failed_to_obtain_token"
            }
            
    except Exception as e:
        logger.error(f"Erro no teste do Token Manager: {e}")
        return {
            "test": "token_manager",
            "status": "error",
            "error": str(e)
        }

def test_luzia_provider():
    """Testa o provedor LuzIA aprimorado."""
    logger = logging.getLogger('TestLuziaProvider')
    logger.info("=== TESTANDO LUZIA PROVIDER ===")
    
    try:
        from providers.luzia_provider_enhanced import LuziaProviderEnhanced
        
        provider = LuziaProviderEnhanced()
        
        # Testar conectividade
        logger.info("Testando conectividade...")
        connectivity = provider.check_connectivity()
        
        logger.info(f"Resultado da conectividade: {connectivity}")
        
        if connectivity.get("success"):
            # Testar análise com programa pequeno
            logger.info("Testando análise de programa...")
            
            test_program = """PROGRAM-ID. TEST-PROGRAM.
IDENTIFICATION DIVISION.
PROGRAM-ID. TEST-PROGRAM.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-COUNTER PIC 9(3) VALUE 0.
PROCEDURE DIVISION.
MAIN-PARA.
    DISPLAY 'HELLO WORLD'.
    STOP RUN."""
            
            start_time = time.time()
            result = provider.analyze_program("TEST-PROGRAM", test_program)
            processing_time = int((time.time() - start_time) * 1000)
            
            return {
                "test": "luzia_provider",
                "status": "success" if result.get("success") else "failed",
                "connectivity": connectivity,
                "analysis_result": {
                    "success": result.get("success"),
                    "provider": result.get("provider"),
                    "model": result.get("model"),
                    "status_code": result.get("status_code"),
                    "processing_time_ms": processing_time,
                    "error": result.get("error") if not result.get("success") else None
                }
            }
        else:
            return {
                "test": "luzia_provider",
                "status": "failed",
                "connectivity": connectivity,
                "error": "connectivity_failed"
            }
            
    except Exception as e:
        logger.error(f"Erro no teste do LuzIA Provider: {e}")
        return {
            "test": "luzia_provider",
            "status": "error",
            "error": str(e)
        }

def test_audit_logger():
    """Testa o sistema de auditoria."""
    logger = logging.getLogger('TestAuditLogger')
    logger.info("=== TESTANDO AUDIT LOGGER ===")
    
    try:
        from utils.audit_logger import AuditLogger
        
        # Criar diretório de teste
        test_dir = "test_audit_output"
        audit_logger = AuditLogger(test_dir)
        
        # Testar sessão
        session_id = audit_logger.start_session(2)
        logger.info(f"Sessão iniciada: {session_id}")
        
        # Testar log de requisição
        req_id = audit_logger.log_request(
            "TEST_PROGRAM", "luzia_enhanced", "aws-claude-3-5-sonnet",
            "https://test.api.com/analyze", "POST",
            {"Content-Type": "application/json"},
            {"query": "test query", "model": "claude"}
        )
        logger.info(f"Requisição registrada: {req_id}")
        
        # Testar log de resposta
        audit_logger.log_response(
            req_id, 200, {"result": "test analysis"}, True, None, 1500
        )
        logger.info("Resposta registrada")
        
        # Testar log de resultado
        audit_logger.log_analysis_result("TEST_PROGRAM", True, 1500)
        logger.info("Resultado registrado")
        
        # Finalizar sessão
        summary = audit_logger.end_session()
        logger.info(f"Sessão finalizada: {summary}")
        
        # Verificar arquivos gerados
        audit_dir = Path(test_dir) / 'audit'
        files_created = list(audit_dir.glob('*'))
        
        return {
            "test": "audit_logger",
            "status": "success",
            "session_id": session_id,
            "files_created": len(files_created),
            "session_summary": summary
        }
        
    except Exception as e:
        logger.error(f"Erro no teste do Audit Logger: {e}")
        return {
            "test": "audit_logger",
            "status": "error",
            "error": str(e)
        }

def test_response_processor():
    """Testa o processador de respostas."""
    logger = logging.getLogger('TestResponseProcessor')
    logger.info("=== TESTANDO RESPONSE PROCESSOR ===")
    
    try:
        from utils.audit_logger import AuditLogger
        
        # Criar audit logger para o teste
        audit_logger = AuditLogger("test_response_processor")
        
        # Simular classe ResponseProcessor (versão simplificada)
        class TestResponseProcessor:
            def __init__(self, audit_logger):
                self.audit_logger = audit_logger
                self.logger = logging.getLogger('TestResponseProcessor')
            
            def extract_content(self, response_data):
                """Extrai conteúdo da resposta."""
                if isinstance(response_data, dict):
                    # Testar diferentes estruturas
                    if 'output' in response_data:
                        return response_data['output']
                    elif 'result' in response_data:
                        return response_data['result']
                    elif 'content' in response_data:
                        return response_data['content']
                
                return json.dumps(response_data, indent=2)
        
        processor = TestResponseProcessor(audit_logger)
        
        # Testar diferentes estruturas de resposta
        test_cases = [
            {"output": "Análise do programa COBOL..."},
            {"result": "Resultado da análise..."},
            {"content": "Conteúdo da resposta..."},
            {"choices": [{"message": {"content": "Resposta via choices..."}}]},
            {"unknown_structure": "dados não estruturados"}
        ]
        
        results = []
        for i, test_case in enumerate(test_cases):
            content = processor.extract_content(test_case)
            results.append({
                "test_case": i + 1,
                "input_structure": list(test_case.keys()),
                "extracted_content_length": len(content),
                "extraction_successful": len(content) > 0
            })
        
        return {
            "test": "response_processor",
            "status": "success",
            "test_cases_processed": len(test_cases),
            "results": results
        }
        
    except Exception as e:
        logger.error(f"Erro no teste do Response Processor: {e}")
        return {
            "test": "response_processor",
            "status": "error",
            "error": str(e)
        }

def test_http_status_handling():
    """Testa o tratamento de diferentes códigos de status HTTP."""
    logger = logging.getLogger('TestHTTPStatus')
    logger.info("=== TESTANDO TRATAMENTO DE STATUS HTTP ===")
    
    try:
        from providers.luzia_provider_enhanced import LuziaProviderEnhanced
        
        # Simular diferentes respostas HTTP
        class MockResponse:
            def __init__(self, status_code, json_data=None, text=""):
                self.status_code = status_code
                self._json_data = json_data or {}
                self.text = text
            
            def json(self):
                if self._json_data:
                    return self._json_data
                raise ValueError("No JSON data")
        
        provider = LuziaProviderEnhanced()
        
        # Testar diferentes códigos de status
        test_responses = [
            MockResponse(200, {"output": "Success response"}),
            MockResponse(201, {"result": "Created response"}),
            MockResponse(202, {"message": "Accepted response"}),
            MockResponse(401, text="Unauthorized"),
            MockResponse(400, text="Bad Request"),
            MockResponse(500, text="Internal Server Error")
        ]
        
        results = []
        for response in test_responses:
            success, result = provider._handle_http_response(response)
            results.append({
                "status_code": response.status_code,
                "handled_successfully": success,
                "result_type": type(result).__name__,
                "has_error": "error" in result if isinstance(result, dict) else False
            })
        
        return {
            "test": "http_status_handling",
            "status": "success",
            "test_cases": len(test_responses),
            "results": results
        }
        
    except Exception as e:
        logger.error(f"Erro no teste de Status HTTP: {e}")
        return {
            "test": "http_status_handling",
            "status": "error",
            "error": str(e)
        }

def main():
    """Executa todos os testes."""
    logger = setup_test_logging()
    
    print("=" * 70)
    print("TESTE DO SISTEMA COBOL AI ENGINE v1.4.0 ENHANCED")
    print("=" * 70)
    
    # Verificar variáveis de ambiente
    client_id = os.getenv("LUZIA_CLIENT_ID")
    client_secret = os.getenv("LUZIA_CLIENT_SECRET")
    
    print(f"Credenciais configuradas: {bool(client_id and client_secret)}")
    if not (client_id and client_secret):
        print("AVISO: Alguns testes serão limitados sem credenciais LuzIA")
    
    print("\n" + "=" * 70)
    
    # Executar testes
    tests = [
        test_token_manager,
        test_luzia_provider,
        test_audit_logger,
        test_response_processor,
        test_http_status_handling
    ]
    
    results = []
    for test_func in tests:
        try:
            result = test_func()
            results.append(result)
            
            status_icon = {
                "success": "✅",
                "failed": "❌", 
                "error": "💥",
                "skipped": "⏭️"
            }.get(result.get("status"), "❓")
            
            print(f"{status_icon} {result['test']}: {result['status']}")
            
            if result.get("error"):
                print(f"   Erro: {result['error']}")
            
        except Exception as e:
            print(f"💥 {test_func.__name__}: ERRO - {e}")
            results.append({
                "test": test_func.__name__,
                "status": "error",
                "error": str(e)
            })
    
    # Relatório final
    print("\n" + "=" * 70)
    print("RELATÓRIO FINAL DOS TESTES")
    print("=" * 70)
    
    success_count = sum(1 for r in results if r.get("status") == "success")
    failed_count = sum(1 for r in results if r.get("status") == "failed")
    error_count = sum(1 for r in results if r.get("status") == "error")
    skipped_count = sum(1 for r in results if r.get("status") == "skipped")
    
    print(f"Total de testes: {len(results)}")
    print(f"Sucessos: {success_count}")
    print(f"Falhas: {failed_count}")
    print(f"Erros: {error_count}")
    print(f"Pulados: {skipped_count}")
    
    success_rate = (success_count / len(results)) * 100 if results else 0
    print(f"Taxa de sucesso: {success_rate:.1f}%")
    
    # Salvar resultados detalhados
    results_file = f"test_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(results_file, 'w', encoding='utf-8') as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "system_version": "COBOL AI Engine v1.4.0 Enhanced",
            "credentials_configured": bool(client_id and client_secret),
            "summary": {
                "total_tests": len(results),
                "success_count": success_count,
                "failed_count": failed_count,
                "error_count": error_count,
                "skipped_count": skipped_count,
                "success_rate": success_rate
            },
            "detailed_results": results
        }, f, indent=2, ensure_ascii=False)
    
    print(f"\nResultados detalhados salvos em: {results_file}")
    print("=" * 70)
    
    return 0 if error_count == 0 else 1

if __name__ == "__main__":
    sys.exit(main())
