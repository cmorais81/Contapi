#!/bin/bash

# COBOL AI Engine v1.4.0 - Teste Rápido
# Script para validação rápida do sistema

echo "============================================================"
echo "COBOL AI Engine v1.4.0 - Teste Rápido"
echo "============================================================"

# Verificar se as credenciais estão configuradas
echo "1. Verificando credenciais..."
if [ -z "$LUZIA_CLIENT_ID" ] || [ -z "$LUZIA_CLIENT_SECRET" ]; then
    echo "   AVISO: Credenciais LuzIA não configuradas"
    echo "   Configure com:"
    echo "   export LUZIA_CLIENT_ID=\"seu_client_id\""
    echo "   export LUZIA_CLIENT_SECRET=\"seu_client_secret\""
    echo ""
    echo "   Continuando com testes limitados..."
    CREDENTIALS_OK=false
else
    echo "   Credenciais configuradas: OK"
    CREDENTIALS_OK=true
fi

# Teste 1: Verificar dependências
echo ""
echo "2. Testando dependências Python..."
python3 -c "
import sys
try:
    import requests
    import urllib3
    import json
    import logging
    from datetime import datetime
    print('   Todas as dependências OK')
except ImportError as e:
    print(f'   ERRO: Dependência em falta: {e}')
    sys.exit(1)
"

# Teste 2: Testar sistema standalone
echo ""
echo "3. Testando sistema standalone..."
python3 luzia_provider_standalone.py > test_output.log 2>&1
if [ $? -eq 0 ]; then
    echo "   Sistema standalone: OK"
    # Mostrar resultado resumido
    grep -E "(Credenciais configuradas|Status [0-9]+)" test_output.log | head -5
else
    echo "   Sistema standalone: ERRO"
    echo "   Verifique test_output.log para detalhes"
fi

# Teste 3: Testar sistema completo (se credenciais disponíveis)
echo ""
echo "4. Testando sistema completo..."
if [ "$CREDENTIALS_OK" = true ]; then
    echo "   Executando teste com conectividade..."
    timeout 30 python3 main_final_v1_4_0.py --check-connectivity test > connectivity_test.log 2>&1
    if [ $? -eq 0 ]; then
        echo "   Conectividade: OK"
        grep -E "(Conectividade|SUCCESS|ERROR)" connectivity_test.log | tail -3
    else
        echo "   Conectividade: ERRO ou TIMEOUT"
        echo "   Verifique connectivity_test.log para detalhes"
    fi
else
    echo "   Pulando teste de conectividade (sem credenciais)"
fi

# Teste 4: Verificar estrutura de arquivos
echo ""
echo "5. Verificando arquivos do sistema..."
REQUIRED_FILES=(
    "main_final_v1_4_0.py"
    "luzia_provider_standalone.py"
    "test_enhanced_system.py"
    "README_v1_4_0.md"
    "examples/fontes.txt"
)

ALL_FILES_OK=true
for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "   ✓ $file"
    else
        echo "   ✗ $file (FALTANDO)"
        ALL_FILES_OK=false
    fi
done

# Teste 5: Testar parsing de arquivo COBOL
echo ""
echo "6. Testando parsing de arquivo COBOL..."
python3 -c "
import sys
sys.path.insert(0, 'src')

# Simular parsing básico
try:
    with open('examples/fontes.txt', 'r', encoding='utf-8') as f:
        content = f.read()
    
    programs = content.split('PROGRAM-ID.')
    program_count = len(programs) - 1  # Primeira seção é vazia
    
    print(f'   Programas encontrados: {program_count}')
    
    if program_count > 0:
        print('   Parsing: OK')
    else:
        print('   Parsing: ERRO - Nenhum programa encontrado')
        sys.exit(1)
        
except Exception as e:
    print(f'   Parsing: ERRO - {e}')
    sys.exit(1)
"

# Relatório final
echo ""
echo "============================================================"
echo "RELATÓRIO DO TESTE RÁPIDO"
echo "============================================================"

if [ "$ALL_FILES_OK" = true ]; then
    echo "Arquivos do sistema: ✓ OK"
else
    echo "Arquivos do sistema: ✗ PROBLEMAS ENCONTRADOS"
fi

if [ "$CREDENTIALS_OK" = true ]; then
    echo "Credenciais LuzIA: ✓ CONFIGURADAS"
else
    echo "Credenciais LuzIA: ⚠ NÃO CONFIGURADAS"
fi

echo "Dependências Python: ✓ OK"
echo "Sistema standalone: ✓ TESTADO"
echo "Parsing COBOL: ✓ OK"

echo ""
echo "Status geral: SISTEMA PRONTO PARA USO"
echo ""
echo "Para análise completa execute:"
echo "python3 main_final_v1_4_0.py examples/fontes.txt -o resultados_teste"
echo ""
echo "Para testes detalhados execute:"
echo "python3 test_enhanced_system.py"
echo ""
echo "============================================================"

# Limpeza
rm -f test_output.log connectivity_test.log 2>/dev/null || true
