"""
COBOL AI Engine v2.6.0 - Provider Manager
Gerenciador completo de provedores de IA com TODOS os métodos implementados.
"""

import logging
import time
import tiktoken
from typing import Dict, List, Any, Optional
from .base_provider import BaseProvider, AIRequest, AIResponse
from .luzia_provider import LuziaProvider
from .enhanced_mock_provider import EnhancedMockProvider
from .basic_provider import BasicProvider
from .databricks_provider import DatabricksProvider
from .bedrock_provider import BedrockProvider
from .openai_provider import OpenAIProvider


class ProviderManager:
    """
    Gerenciador de provedores de IA.
    TODOS OS MÉTODOS IMPLEMENTADOS - corrige erros das imagens.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o gerenciador de provedores."""
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.providers: Dict[str, BaseProvider] = {}
        self.statistics: Dict[str, Dict[str, Any]] = {}
        self.tokenizer = tiktoken.get_encoding("cl100k_base")
        
        # Configuração de provedores
        ai_config = config.get('ai', {})
        self.primary_provider = ai_config.get('primary_provider', 'enhanced_mock')
        self.fallback_providers = ai_config.get('fallback_providers', ['basic'])
        
        # Inicializar provedores
        self._initialize_providers(ai_config)
        
        self.logger.info(f"Provider Manager inicializado - Primário: {self.primary_provider}")
    
    def _initialize_providers(self, ai_config: Dict[str, Any]) -> None:
        """Inicializa todos os provedores disponíveis."""
        providers_config = ai_config.get('providers', {})
        
        # Provedores disponíveis
        available_providers = {
            'luzia': LuziaProvider,
            'enhanced_mock': EnhancedMockProvider,
            'basic': BasicProvider,
            'databricks': DatabricksProvider,
            'bedrock': BedrockProvider,
            'openai': OpenAIProvider
        }
        
        for provider_name, provider_class in available_providers.items():
            try:
                provider_config = providers_config.get(provider_name, {})
                
                # Sempre inicializar enhanced_mock e basic como fallback
                if provider_config.get('enabled', False) or provider_name in ['enhanced_mock', 'basic']:
                    # CORRIGIDO: Passar configuração corretamente
                    provider = provider_class(provider_config)
                    self.providers[provider_name] = provider
                    
                    # Inicializar estatísticas
                    self.statistics[provider_name] = {
                        'total_requests': 0,
                        'successful_requests': 0,
                        'failed_requests': 0,
                        'total_tokens': 0,
                        'average_response_time': 0.0,
                        'last_request_time': None,
                        'consecutive_failures': 0
                    }
                    
                    self.logger.info(f"Provedor {provider_name} inicializado com sucesso")
                    
            except Exception as e:
                self.logger.error(f"Erro ao inicializar provedor {provider_name}: {str(e)}")
    
    def get_available_providers(self) -> List[str]:
        """
        Retorna lista de provedores disponíveis.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        available = []
        for name, provider in self.providers.items():
            try:
                if provider.is_available():
                    available.append(name)
            except Exception as e:
                self.logger.error(f"Erro ao verificar disponibilidade do {name}: {e}")
        
        return available
    
    def get_provider_statistics(self, provider_name: str) -> Dict[str, Any]:
        """
        Retorna estatísticas de um provedor específico.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        if provider_name not in self.providers:
            return {}
        
        stats = self.statistics.get(provider_name, {})
        
        # Adicionar estatísticas do próprio provider
        try:
            provider_stats = self.providers[provider_name].get_statistics()
            stats.update(provider_stats)
        except Exception as e:
            self.logger.error(f"Erro ao obter estatísticas do {provider_name}: {e}")
        
        return stats
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando o sistema de fallback.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        max_tokens = self.config.get('ai', {}).get('global_max_tokens', 8192)
        prompt_tokens = len(self.tokenizer.encode(request.prompt))

        if prompt_tokens > max_tokens:
            self.logger.info(f"Prompt com {prompt_tokens} tokens excede o limite de {max_tokens}. Dividindo em chunks...")
            chunks = self._split_prompt(request.prompt, max_tokens)
            consolidated_content = ""
            total_tokens_used = 0

            for i, chunk in enumerate(chunks):
                self.logger.info(f"Processando chunk {i+1}/{len(chunks)}...")
                chunk_request = AIRequest(prompt=chunk, max_tokens=max_tokens, temperature=request.temperature)
                response = self._try_provider(self.primary_provider, chunk_request)
                if response.success:
                    consolidated_content += response.content
                    total_tokens_used += response.tokens_used
                else:
                    return AIResponse(
                        success=False,
                        content="",
                        tokens_used=total_tokens_used,
                        model="none",
                        provider=self.primary_provider,
                        error_message=f"Falha ao processar o chunk {i+1}: {response.error_message}"
                    )
            
            return AIResponse(
                success=True,
                content=consolidated_content,
                tokens_used=total_tokens_used,
                model=self.primary_provider,
                provider=self.primary_provider,
                error_message=""
            )
        else:
            # Tentar provedor primário primeiro
            if self.primary_provider in self.providers:
                response = self._try_provider(self.primary_provider, request)
                if response.success:
                    return response
            
            # Tentar provedores de fallback
            for fallback_provider in self.fallback_providers:
                if fallback_provider in self.providers:
                    response = self._try_provider(fallback_provider, request)
                    if response.success:
                        return response
            
            # Se todos falharam, retornar erro
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model="none",
                provider="none",
                error_message="Todos os provedores falharam"
            )

    def _split_prompt(self, prompt: str, max_tokens: int) -> List[str]:
        tokens = self.tokenizer.encode(prompt)
        chunks = []
        current_chunk = []
        current_length = 0

        for token in tokens:
            if current_length + 1 > max_tokens:
                chunks.append(self.tokenizer.decode(current_chunk))
                current_chunk = []
                current_length = 0
            current_chunk.append(token)
            current_length += 1
        
        if current_chunk:
            chunks.append(self.tokenizer.decode(current_chunk))

        return chunks

    def analyze_with_specific_provider(self, provider_name: str, request: AIRequest) -> AIResponse:
        """
        Analisa usando um provedor específico.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        if provider_name not in self.providers:
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model="none",
                provider=provider_name,
                error_message=f"Provedor {provider_name} não encontrado"
            )
        
        return self._try_provider(provider_name, request)
    
    def get_provider_status(self, provider_name: str) -> Dict[str, Any]:
        """
        Retorna status detalhado de um provedor.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        if provider_name not in self.providers:
            return {
                'available': False,
                'error': f'Provedor {provider_name} não encontrado'
            }
        
        try:
            provider = self.providers[provider_name]
            stats = self.get_provider_statistics(provider_name)
            
            return {
                'available': provider.is_available(),
                'enabled"))
