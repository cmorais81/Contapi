import pytest
from src.config import ConfigManager

def test_config_manager_loads_config():
    config_manager = ConfigManager(config_path="cobol_analyzer_refactored/tests/config/test_config.yaml")
    assert config_manager.get("ai")["primary_provider"] == "test_provider"

def test_config_manager_gets_provider_config():
    config_manager = ConfigManager(config_path="cobol_analyzer_refactored/tests/config/test_config.yaml")
    provider_config = config_manager.get_provider_config("test_provider")
    assert provider_config["enabled"] is True
    assert provider_config["model"] == "test_model"

