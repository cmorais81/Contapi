# COBOL Analyzer v4.0.0 - Instalação e Uso

## Instalação Rápida

### Opção 1: Uso Direto (Recomendado)
```bash
# Extrair o pacote
tar -xzf COBOL_ANALYZER_v4.0.0_FINAL.tar.gz
cd cobol_analyzer_refactored

# Instalar dependências
pip install -r requirements.txt

# Usar diretamente
python3 main.py --help
```

### Opção 2: Instalação como Pacote
```bash
# Extrair e instalar
tar -xzf COBOL_ANALYZER_v4.0.0_FINAL.tar.gz
cd cobol_analyzer_refactored
pip install .

# Usar como comando
cobol-analyzer --help
```

## Uso Básico

### Analisar Programas COBOL
```bash
# Usando main.py
python3 main.py --config config/config.yaml analyze --fontes data/test_programs.txt

# Usando CLI instalada
cobol-analyzer --config config/config.yaml analyze --fontes data/test_programs.txt
```

### Gerenciar Base de Conhecimento RAG
```bash
# Adicionar conhecimento
python3 main.py rag add "Nome" "Descrição" "Conteúdo" "Categoria" "tag1" "tag2"

# Pesquisar na base
python3 main.py rag search "termo de busca"
```

## Estrutura do Projeto

- `main.py` - Ponto de entrada principal (compatibilidade)
- `src/cli.py` - Interface de linha de comando
- `config/` - Arquivos de configuração
- `prompts/` - Templates de prompts para IA
- `data/` - Dados de exemplo e base de conhecimento
- `src/` - Código-fonte da aplicação

## Funcionalidades

- ✅ Análise de código COBOL com IA
- ✅ Geração de documentação automática
- ✅ Sistema RAG para aprendizado contínuo
- ✅ Múltiplos provedores de IA
- ✅ Arquitetura modular e extensível
- ✅ Testes unitários incluídos

## Suporte

Para dúvidas ou problemas, consulte a documentação completa em `README.md` e `docs/arquitetura.md`.
