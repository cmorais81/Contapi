#!/usr/bin/env python3
"""
COBOL Analyzer - Main Entry Point (Compatibility)
Mantém compatibilidade com a versão original do main.py
"""

import sys
import os

# Adicionar o diretório src ao path para importações
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.cli import main

if __name__ == '__main__':
    main()
