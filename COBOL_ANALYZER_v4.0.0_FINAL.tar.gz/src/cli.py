"""
COBOL Analyzer CLI
"""

import logging
import click

from .config import ConfigManager
from .application.use_cases.analyze_programs import AnalyzeProgramsUseCase
from .application.use_cases.rag_use_cases import AddToKnowledgeBase, SearchKnowledgeBase
from .infrastructure.persistence.file_knowledge_repository import FileKnowledgeRepository
from .infrastructure.providers.enhanced_provider_manager import EnhancedProviderManager
from .parsers.cobol_parser_original import COBOLParser
from .utils.cost_calculator import CostCalculator
from .rag.rag_integration import RAGIntegration
from .domain.models import KnowledgeItem


@click.group()
@click.option('--config', 'config_path', default='config/config.yaml', help='Path to the configuration file.')
@click.pass_context
def main(ctx, config_path):
    """COBOL Analyzer CLI"""
    # Load configuration
    config_manager = ConfigManager(config_path)
    ctx.obj = {
        'config_manager': config_manager
    }
    logging.basicConfig(level=config_manager.get('logging', {}).get('level', 'INFO'),
                        format=config_manager.get('logging', {}).get('format', '%(asctime)s - %(name)s - %(levelname)s - %(message)s'))

@main.command()
@click.option('--fontes', required=True, help='Path to the file containing the list of COBOL programs to analyze.')
@click.option('--books', help='Path to the file containing the list of COBOL copybooks.')
@click.option('--output', default='output', help='Path to the output directory.')
@click.option('--models', help='Comma-separated list of models to use for the analysis.')
@click.pass_context
def analyze(ctx, fontes, books, output, models):
    """Analyzes COBOL programs."""
    print(f"Analisando fontes de {fontes}...")
    
    config_manager = ctx.obj['config_manager']
    
    # Inicializar dependências
    cost_calculator = CostCalculator()
    rag_integration = RAGIntegration(config_manager)
    parser = COBOLParser()
    provider_manager = EnhancedProviderManager(config_manager.get_all())

    # Criar e executar o caso de uso
    use_case = AnalyzeProgramsUseCase(config_manager, cost_calculator, rag_integration, parser, provider_manager)
    
    args = {
        "fontes": fontes,
        "books": books,
        "output": output,
        "models": models
    }
    use_case.execute(args)
    
    print(f"Análise concluída. Resultados em: {output}")

@main.group()
@click.pass_context
def rag(ctx):
    """Manages the RAG knowledge base."""
    pass

@rag.command()
@click.option('--data-path', default='data/knowledge_base', help='Path to the knowledge base directory.')
@click.argument('name')
@click.argument('description')
@click.argument('content')
@click.argument('category')
@click.argument('tags', nargs=-1)
@click.pass_context
def add(ctx, data_path, name, description, content, category, tags):
    """Adds an item to the knowledge base."""
    repository = FileKnowledgeRepository(data_path)
    use_case = AddToKnowledgeBase(repository)
    item = KnowledgeItem(name=name, description=description, content=content, category=category, tags=list(tags))
    use_case.execute(item)
    print(f"Item '{name}' adicionado à base de conhecimento.")

@rag.command()
@click.option('--data-path', default='data/knowledge_base', help='Path to the knowledge base directory.')
@click.argument('query')
@click.pass_context
def search(ctx, data_path, query):
    """Searches the knowledge base."""
    repository = FileKnowledgeRepository(data_path)
    use_case = SearchKnowledgeBase(repository)
    results = use_case.execute(query)
    for item in results:
        print(f"- {item.name}: {item.description}")

if __name__ == '__main__':
    main()
