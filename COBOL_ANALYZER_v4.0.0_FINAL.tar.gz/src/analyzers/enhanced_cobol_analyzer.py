"""
Enhanced COBOL Analyzer
"""

import logging
from typing import Dict, Any, List

from src.infrastructure.providers.base_provider import AIRequest, AIResponse
from src.domain.models import CobolProgram, AnalysisResult
from src.application.services.prompt_manager import PromptManager
from src.infrastructure.providers.enhanced_provider_manager import EnhancedProviderManager
from src.rag.rag_integration import RAGIntegration

logger = logging.getLogger(__name__)

class EnhancedCOBOLAnalyzer:
    """
    Analisador aprimorado de código COBOL com foco em análise profunda
    de comentários e extração de lógica de negócio.
    """
    
    def __init__(self, provider_manager: EnhancedProviderManager, prompt_manager: PromptManager, rag_integration: RAGIntegration = None):
        self.logger = logging.getLogger(__name__)
        self.provider_manager = provider_manager
        self.prompt_manager = prompt_manager
        self.rag_integration = rag_integration
        
        if rag_integration and rag_integration.is_enabled():
            self.logger.info("Enhanced COBOL Analyzer inicializado com RAG ativo")
        else:
            self.logger.info("Enhanced COBOL Analyzer inicializado sem RAG")
    
    def analyze_program(self, program: CobolProgram, model: str) -> AnalysisResult:
        """
        Analisa um programa COBOL usando IA.
        """
        try:
            self.logger.info(f"Iniciando análise do programa: {program.name}")
            
            # Gerar prompt base
            base_prompt = self.prompt_manager.generate_analysis_prompt(program.name, program.content)
            
            # Enriquecer com RAG se disponível
            if self.rag_integration and self.rag_integration.is_enabled():
                self.logger.info(f"*** ENRIQUECENDO ANÁLISE COM RAG para {program.name} ***")
                prompt = self.rag_integration.enhance_analysis_prompt(
                    program.name, 
                    program.content, 
                    base_prompt, 
                    "cobol_analysis"
                )
            else:
                prompt = base_prompt
            
            # Criar request para IA
            ai_request = AIRequest(
                prompt=prompt,
                program_name=program.name,
                program_code=program.content,
                context={}
            )
            
            # Fazer análise com IA
            if model and model != 'auto':
                self.logger.info(f"Usando modelo específico: {model} (sem fallback)")
                response = self.provider_manager.analyze_with_model(model, ai_request)
            else:
                self.logger.info("Usando análise com fallback automático")
                response = self.provider_manager.analyze(ai_request)
            
            return AnalysisResult(
                success=response.success,
                program_name=program.name,
                model=response.model,
                provider=response.provider,
                content=response.content,
                tokens_used=response.tokens_used,
                prompts_used=response.prompts_used,
                error_message=response.error_message,
            )
                
        except Exception as e:
            self.logger.error(f"Erro na análise do programa {program.name}: {str(e)}")
            return AnalysisResult(
                success=False,
                program_name=program.name,
                model=model,
                provider="unknown",
                content="",
                tokens_used=0,
                error_message=str(e)
            )

