'''
Configuration Manager
'''

import os
import yaml
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

class ConfigManager:
    '''Manages the application configuration.'''

    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or self._find_config_file()
        self.config = self._load_config()

    def _find_config_file(self) -> str:
        '''Finds the configuration file in default locations.'''
        default_paths = [
            "config/config.yaml",
            "../config/config.yaml",
            os.path.join(os.path.dirname(__file__), "..", "config", "config.yaml"),
        ]
        for path in default_paths:
            if os.path.exists(path):
                return path
        raise FileNotFoundError("Configuration file (config.yaml) not found.")

    def _load_config(self) -> Dict[str, Any]:
        '''Loads the configuration from a YAML file.'''
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            config = self._substitute_env_vars(config)
            logger.info(f"Configuration loaded from: {self.config_path}")
            return config
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            return {}

    def _substitute_env_vars(self, obj: Any) -> Any:
        '''Recursively substitutes environment variables in the configuration.'''
        if isinstance(obj, dict):
            return {k: self._substitute_env_vars(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [self._substitute_env_vars(i) for i in obj]
        if isinstance(obj, str) and obj.startswith('${') and obj.endswith('}'):
            var_name = obj[2:-1]
            return os.getenv(var_name, obj)
        return obj

    def get(self, key: str, default: Any = None) -> Any:
        '''Gets a configuration value.'''
        return self.config.get(key, default)

    def get_provider_config(self, provider_name: str) -> Dict[str, Any]:
        '''Gets the configuration for a specific provider.'''
        return self.get("providers", {}).get(provider_name, {})

    def get_all(self) -> Dict[str, Any]:
        """Returns the entire configuration dictionary."""
        return self.config

