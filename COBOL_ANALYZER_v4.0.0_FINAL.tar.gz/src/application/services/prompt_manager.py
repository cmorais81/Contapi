
import logging
import yaml
from typing import Dict, Any

from src.config import ConfigManager

logger = logging.getLogger(__name__)

class PromptManager:
    """Manages the generation of prompts for the AI models."""

    def __init__(self, config_manager: ConfigManager):
        self.config_manager = config_manager
        self.prompts_config = self._load_prompts_config()

    def _load_prompts_config(self) -> Dict[str, Any]:
        """Loads the prompts configuration."""
        prompts_file = self.config_manager.get("prompts_file", "config/prompts.yaml")
        try:
            with open(prompts_file, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            logger.error(f"Prompts file not found: {prompts_file}")
            return {}

    def get_system_prompt(self) -> str:
        """Gets the system prompt."""
        return self.prompts_config.get("system_prompt", "")

    def generate_analysis_prompt(self, program_name: str, program_code: str) -> str:
        """Generates the prompt for COBOL program analysis."""
        system_prompt = self.get_system_prompt()
        analysis_questions = self.prompts_config.get("analysis_questions", {})

        prompt_parts = [system_prompt]
        prompt_parts.append(f"\n--- PROGRAMA PARA ANÁLISE ---")
        prompt_parts.append(f"Nome: {program_name}")
        prompt_parts.append(f"Código:\n{program_code}")

        if analysis_questions:
            prompt_parts.append("\n--- QUESTÕES DE ANÁLISE ---")
            for i, question_data in enumerate(analysis_questions, 1):
                prompt_parts.append(f"{i}. {question_data.get('question', '')}")

        return "\n".join(prompt_parts)

