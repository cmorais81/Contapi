#!/usr/bin/env python3

class ApplicationService:
    pass

