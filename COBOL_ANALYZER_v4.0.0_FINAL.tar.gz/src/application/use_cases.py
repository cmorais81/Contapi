#!/usr/bin/env python3

from src.domain.models import CobolProgram
from src.domain.services import CobolAnalysisService
from src.infrastructure.providers.base_provider import AIRequest, AIResponse
from src.infrastructure.providers.provider_manager import ProviderManager

class AnalyzeCobolProgram:
    def __init__(self, analysis_service: CobolAnalysisService, provider_manager: ProviderManager):
        self.analysis_service = analysis_service
        self.provider_manager = provider_manager

    def execute(self, program: CobolProgram) -> AIResponse:
        analysis_result = self.analysis_service.analyze(program)
        
        prompt = f"Analise o seguinte programa COBOL:\n\n{program.content}"
        ai_request = AIRequest(prompt, program.name, program.content, {})
        
        ai_response = self.provider_manager.analyze(ai_request)
        
        return ai_response

