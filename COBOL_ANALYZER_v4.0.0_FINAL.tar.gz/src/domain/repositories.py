#!/usr/bin/env python3

from abc import ABC, abstractmethod
from typing import List

from src.domain.models import KnowledgeItem

class KnowledgeRepository(ABC):
    """Interface for the knowledge repository."""

    @abstractmethod
    def add(self, item: KnowledgeItem):
        """Adds an item to the repository."""
        pass

    @abstractmethod
    def find(self, query: str) -> List[KnowledgeItem]:
        """Finds items in the repository based on a query."""
        pass

