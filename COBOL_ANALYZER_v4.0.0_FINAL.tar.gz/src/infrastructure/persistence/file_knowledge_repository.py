#!/usr/bin/env python3

import os
import json
from typing import List

from src.domain.models import KnowledgeItem
from src.domain.repositories import KnowledgeRepository

class FileKnowledgeRepository(KnowledgeRepository):
    """File-based implementation of the knowledge repository."""

    def __init__(self, data_path: str):
        self.data_path = data_path
        if not os.path.exists(self.data_path):
            os.makedirs(self.data_path)

    def add(self, item: KnowledgeItem):
        """Adds an item to the repository as a JSON file."""
        file_path = os.path.join(self.data_path, f"{item.id}.json")
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(item.__dict__, f, indent=4)

    def find(self, query: str) -> List[KnowledgeItem]:
        """Finds items by searching for the query in the file content."""
        results = []
        for filename in os.listdir(self.data_path):
            if filename.endswith(".json"):
                file_path = os.path.join(self.data_path, filename)
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    if query in data.get("content", ""):
                        results.append(KnowledgeItem(**data))
        return results

