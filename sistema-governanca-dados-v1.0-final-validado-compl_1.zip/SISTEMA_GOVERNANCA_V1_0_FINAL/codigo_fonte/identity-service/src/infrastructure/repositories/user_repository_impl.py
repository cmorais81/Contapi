# Autor: carlos.morais@f1rst.com.br
"""
User Repository Implementation
SQLAlchemy implementation for user data access
"""

import hashlib
import secrets
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from uuid import UUID, uuid4
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, func, desc, asc
from sqlalchemy.exc import IntegrityError

from ..models import User, Organization
from ...domain.repositories.user_repository import UserRepository
from ...domain.entities.user import User as UserEntity
from ...domain.value_objects.user_role import UserRole
from ...domain.value_objects.user_status import UserStatus
from ...application.dtos.user_dtos import Permission


class UserRepositoryImpl(UserRepository):
    """SQLAlchemy implementation of user repository"""
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    def save(self, user: UserEntity) -> UserEntity:
        """Save user entity to database"""
        try:
            # Check if user exists
            existing_user = self.db.query(User).filter(User.id == user.id).first()
            
            if existing_user:
                # Update existing user
                self._update_user_model(existing_user, user)
            else:
                # Create new user
                user_model = self._create_user_model(user)
                self.db.add(user_model)
            
            self.db.commit()
            
            # Reload and return updated entity
            return self.find_by_id(user.id)
            
        except IntegrityError as e:
            self.db.rollback()
            if "email" in str(e):
                raise ValueError("Email already exists")
            raise ValueError(f"Database integrity error: {str(e)}")
        except Exception as e:
            self.db.rollback()
            raise RuntimeError(f"Failed to save user: {str(e)}")
    
    def find_by_id(self, user_id: UUID) -> Optional[UserEntity]:
        """Find user by ID"""
        try:
            user_model = (
                self.db.query(User)
                .options(joinedload(User.organization))
                .filter(User.id == user_id)
                .first()
            )
            
            if not user_model:
                return None
            
            return self._model_to_entity(user_model)
            
        except Exception as e:
            raise RuntimeError(f"Failed to find user by ID: {str(e)}")
    
    def find_by_email(self, email: str) -> Optional[UserEntity]:
        """Find user by email"""
        try:
            user_model = (
                self.db.query(User)
                .options(joinedload(User.organization))
                .filter(User.email == email.lower())
                .first()
            )
            
            if not user_model:
                return None
            
            return self._model_to_entity(user_model)
            
        except Exception as e:
            raise RuntimeError(f"Failed to find user by email: {str(e)}")
    
    def find_by_organization(self, organization_id: UUID, limit: int = 100, offset: int = 0) -> List[UserEntity]:
        """Find users by organization"""
        try:
            user_models = (
                self.db.query(User)
                .options(joinedload(User.organization))
                .filter(User.organization_id == organization_id)
                .order_by(User.name)
                .limit(limit)
                .offset(offset)
                .all()
            )
            
            return [self._model_to_entity(model) for model in user_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find users by organization: {str(e)}")
    
    def find_by_role(self, role: UserRole, organization_id: Optional[UUID] = None) -> List[UserEntity]:
        """Find users by role"""
        try:
            query = self.db.query(User).options(joinedload(User.organization))
            query = query.filter(User.role == role.value)
            
            if organization_id:
                query = query.filter(User.organization_id == organization_id)
            
            user_models = query.order_by(User.name).all()
            return [self._model_to_entity(model) for model in user_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find users by role: {str(e)}")
    
    def find_by_status(self, status: UserStatus, organization_id: Optional[UUID] = None) -> List[UserEntity]:
        """Find users by status"""
        try:
            query = self.db.query(User).options(joinedload(User.organization))
            query = query.filter(User.status == status.value)
            
            if organization_id:
                query = query.filter(User.organization_id == organization_id)
            
            user_models = query.order_by(User.name).all()
            return [self._model_to_entity(model) for model in user_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find users by status: {str(e)}")
    
    def search_users(self, search_term: str, organization_id: Optional[UUID] = None, 
                    limit: int = 100, offset: int = 0) -> List[UserEntity]:
        """Search users by name or email"""
        try:
            search_pattern = f"%{search_term.lower()}%"
            
            query = self.db.query(User).options(joinedload(User.organization))
            query = query.filter(
                or_(
                    func.lower(User.name).like(search_pattern),
                    func.lower(User.email).like(search_pattern),
                    func.lower(User.department).like(search_pattern),
                    func.lower(User.job_title).like(search_pattern)
                )
            )
            
            if organization_id:
                query = query.filter(User.organization_id == organization_id)
            
            user_models = (
                query.order_by(User.name)
                .limit(limit)
                .offset(offset)
                .all()
            )
            
            return [self._model_to_entity(model) for model in user_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to search users: {str(e)}")
    
    def find_with_filters(self, filters: Dict[str, Any], limit: int = 100, offset: int = 0) -> List[UserEntity]:
        """Find users with multiple filters"""
        try:
            query = self.db.query(User).options(joinedload(User.organization))
            
            # Apply filters
            if filters.get('organization_id'):
                query = query.filter(User.organization_id == filters['organization_id'])
            
            if filters.get('role'):
                query = query.filter(User.role == filters['role'])
            
            if filters.get('status'):
                query = query.filter(User.status == filters['status'])
            
            if filters.get('department'):
                query = query.filter(User.department == filters['department'])
            
            if filters.get('created_after'):
                query = query.filter(User.created_at >= filters['created_after'])
            
            if filters.get('created_before'):
                query = query.filter(User.created_at <= filters['created_before'])
            
            if filters.get('last_login_after'):
                query = query.filter(User.last_login >= filters['last_login_after'])
            
            if filters.get('last_login_before'):
                query = query.filter(User.last_login <= filters['last_login_before'])
            
            user_models = (
                query.order_by(User.name)
                .limit(limit)
                .offset(offset)
                .all()
            )
            
            return [self._model_to_entity(model) for model in user_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find users with filters: {str(e)}")
    
    def count_by_organization(self, organization_id: UUID) -> int:
        """Count users in organization"""
        try:
            return (
                self.db.query(func.count(User.id))
                .filter(User.organization_id == organization_id)
                .scalar()
            )
        except Exception as e:
            raise RuntimeError(f"Failed to count users: {str(e)}")
    
    def count_by_status(self, organization_id: UUID) -> Dict[str, int]:
        """Count users by status in organization"""
        try:
            results = (
                self.db.query(User.status, func.count(User.id))
                .filter(User.organization_id == organization_id)
                .group_by(User.status)
                .all()
            )
            
            return {status: count for status, count in results}
            
        except Exception as e:
            raise RuntimeError(f"Failed to count users by status: {str(e)}")
    
    def count_by_role(self, organization_id: UUID) -> Dict[str, int]:
        """Count users by role in organization"""
        try:
            results = (
                self.db.query(User.role, func.count(User.id))
                .filter(User.organization_id == organization_id)
                .group_by(User.role)
                .all()
            )
            
            return {role: count for role, count in results}
            
        except Exception as e:
            raise RuntimeError(f"Failed to count users by role: {str(e)}")
    
    def get_recent_logins(self, organization_id: UUID, hours: int = 24) -> int:
        """Get count of recent logins"""
        try:
            since = datetime.utcnow() - timedelta(hours=hours)
            
            return (
                self.db.query(func.count(User.id))
                .filter(
                    and_(
                        User.organization_id == organization_id,
                        User.last_login >= since
                    )
                )
                .scalar()
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to get recent logins: {str(e)}")
    
    def get_failed_login_attempts(self, organization_id: UUID, hours: int = 24) -> int:
        """Get count of failed login attempts"""
        try:
            # This would typically come from a separate audit log table
            # For now, return sum of failed_login_attempts for users with recent failures
            return (
                self.db.query(func.sum(User.failed_login_attempts))
                .filter(User.organization_id == organization_id)
                .scalar() or 0
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to get failed login attempts: {str(e)}")
    
    def update_last_login(self, user_id: UUID, ip_address: str, user_agent: str) -> bool:
        """Update user's last login information"""
        try:
            user_model = self.db.query(User).filter(User.id == user_id).first()
            if not user_model:
                return False
            
            user_model.last_login = datetime.utcnow()
            user_model.failed_login_attempts = 0  # Reset on successful login
            user_model.updated_at = datetime.utcnow()
            
            self.db.commit()
            return True
            
        except Exception as e:
            self.db.rollback()
            raise RuntimeError(f"Failed to update last login: {str(e)}")
    
    def increment_failed_login_attempts(self, user_id: UUID) -> int:
        """Increment failed login attempts and return new count"""
        try:
            user_model = self.db.query(User).filter(User.id == user_id).first()
            if not user_model:
                return 0
            
            user_model.failed_login_attempts += 1
            user_model.updated_at = datetime.utcnow()
            
            # Lock account after 5 failed attempts
            if user_model.failed_login_attempts >= 5:
                user_model.is_locked = True
                user_model.locked_at = datetime.utcnow()
            
            self.db.commit()
            return user_model.failed_login_attempts
            
        except Exception as e:
            self.db.rollback()
            raise RuntimeError(f"Failed to increment failed login attempts: {str(e)}")
    
    def unlock_user(self, user_id: UUID) -> bool:
        """Unlock user account"""
        try:
            user_model = self.db.query(User).filter(User.id == user_id).first()
            if not user_model:
                return False
            
            user_model.is_locked = False
            user_model.locked_at = None
            user_model.failed_login_attempts = 0
            user_model.updated_at = datetime.utcnow()
            
            self.db.commit()
            return True
            
        except Exception as e:
            self.db.rollback()
            raise RuntimeError(f"Failed to unlock user: {str(e)}")
    
    def delete(self, user_id: UUID) -> bool:
        """Soft delete user"""
        try:
            user_model = self.db.query(User).filter(User.id == user_id).first()
            if not user_model:
                return False
            
            user_model.status = UserStatus.INACTIVE.value
            user_model.deleted_at = datetime.utcnow()
            user_model.updated_at = datetime.utcnow()
            
            self.db.commit()
            return True
            
        except Exception as e:
            self.db.rollback()
            raise RuntimeError(f"Failed to delete user: {str(e)}")
    
    def exists_by_email(self, email: str, exclude_user_id: Optional[UUID] = None) -> bool:
        """Check if email already exists"""
        try:
            query = self.db.query(User).filter(User.email == email.lower())
            
            if exclude_user_id:
                query = query.filter(User.id != exclude_user_id)
            
            return query.first() is not None
            
        except Exception as e:
            raise RuntimeError(f"Failed to check email existence: {str(e)}")
    
    def _create_user_model(self, user: UserEntity) -> User:
        """Create SQLAlchemy model from entity"""
        return User(
            id=user.id,
            email=user.email.lower(),
            name=user.name,
            password_hash=user.password_hash,
            password_salt=user.password_salt,
            role=user.role.value,
            status=user.status.value,
            organization_id=user.organization_id,
            department=user.department,
            job_title=user.job_title,
            phone=user.phone,
            two_factor_enabled=user.two_factor_enabled,
            two_factor_secret=user.two_factor_secret,
            failed_login_attempts=user.failed_login_attempts,
            is_locked=user.is_locked,
            locked_at=user.locked_at,
            last_login=user.last_login,
            created_at=user.created_at,
            updated_at=user.updated_at
        )
    
    def _update_user_model(self, user_model: User, user: UserEntity):
        """Update SQLAlchemy model from entity"""
        user_model.email = user.email.lower()
        user_model.name = user.name
        user_model.password_hash = user.password_hash
        user_model.password_salt = user.password_salt
        user_model.role = user.role.value
        user_model.status = user.status.value
        user_model.organization_id = user.organization_id
        user_model.department = user.department
        user_model.job_title = user.job_title
        user_model.phone = user.phone
        user_model.two_factor_enabled = user.two_factor_enabled
        user_model.two_factor_secret = user.two_factor_secret
        user_model.failed_login_attempts = user.failed_login_attempts
        user_model.is_locked = user.is_locked
        user_model.locked_at = user.locked_at
        user_model.last_login = user.last_login
        user_model.updated_at = user.updated_at
    
    def _model_to_entity(self, user_model: User) -> UserEntity:
        """Convert SQLAlchemy model to entity"""
        return UserEntity(
            id=user_model.id,
            email=user_model.email,
            name=user_model.name,
            password_hash=user_model.password_hash,
            password_salt=user_model.password_salt,
            role=UserRole(user_model.role),
            status=UserStatus(user_model.status),
            organization_id=user_model.organization_id,
            organization_name=user_model.organization.name if user_model.organization else None,
            department=user_model.department,
            job_title=user_model.job_title,
            phone=user_model.phone,
            two_factor_enabled=user_model.two_factor_enabled,
            two_factor_secret=user_model.two_factor_secret,
            failed_login_attempts=user_model.failed_login_attempts,
            is_locked=user_model.is_locked,
            locked_at=user_model.locked_at,
            last_login=user_model.last_login,
            created_at=user_model.created_at,
            updated_at=user_model.updated_at
        )
    
    @staticmethod
    def hash_password(password: str, salt: Optional[str] = None) -> tuple[str, str]:
        """Hash password with salt"""
        if salt is None:
            salt = secrets.token_hex(32)
        
        password_hash = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt.encode('utf-8'),
            100000  # iterations
        ).hex()
        
        return password_hash, salt
    
    @staticmethod
    def verify_password(password: str, password_hash: str, salt: str) -> bool:
        """Verify password against hash"""
        computed_hash, _ = UserRepositoryImpl.hash_password(password, salt)
        return computed_hash == password_hash

