# Autor: carlos.morais@f1rst.com.br
"""
User Domain Entity
Core business entity for user identity and access management
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Set
from uuid import UUID, uuid4
from enum import Enum
import hashlib
import secrets

from ..value_objects.user_role import UserRole, Permission
from ..value_objects.user_status import UserStatus
from ..events.user_events import (
    UserCreated, UserUpdated, UserActivated, UserDeactivated,
    UserRoleChanged, UserPasswordChanged, UserLoginAttempted,
    UserSessionCreated, UserSessionExpired
)


@dataclass
class User:
    """
    User aggregate root representing a system user
    """
    # Identity
    id: UUID = field(default_factory=uuid4)
    email: str = ""
    username: str = ""
    
    # Personal information
    full_name: str = ""
    first_name: str = ""
    last_name: str = ""
    phone: Optional[str] = None
    
    # Authentication
    password_hash: str = ""
    password_salt: str = ""
    password_changed_at: Optional[datetime] = None
    password_expires_at: Optional[datetime] = None
    failed_login_attempts: int = 0
    last_login_at: Optional[datetime] = None
    last_login_ip: Optional[str] = None
    
    # Authorization
    roles: List[UserRole] = field(default_factory=list)
    permissions: Set[Permission] = field(default_factory=set)
    
    # Organization
    organization_id: UUID = field(default_factory=uuid4)
    department: Optional[str] = None
    job_title: Optional[str] = None
    manager_id: Optional[UUID] = None
    
    # Status and lifecycle
    status: UserStatus = field(default=UserStatus.PENDING)
    is_active: bool = True
    is_verified: bool = False
    email_verified_at: Optional[datetime] = None
    
    # Security
    two_factor_enabled: bool = False
    two_factor_secret: Optional[str] = None
    security_questions: Dict[str, str] = field(default_factory=dict)
    
    # Preferences
    language: str = "pt-BR"
    timezone: str = "America/Sao_Paulo"
    notification_preferences: Dict[str, bool] = field(default_factory=dict)
    
    # Audit fields
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    created_by: Optional[UUID] = None
    updated_by: Optional[UUID] = None
    deleted_at: Optional[datetime] = None
    
    # Domain events
    _domain_events: List[Any] = field(default_factory=list, init=False)
    
    def __post_init__(self):
        """Post-initialization validation and setup"""
        if not self.email:
            raise ValueError("Email is required")
        
        if not self.full_name:
            raise ValueError("Full name is required")
        
        # Set username from email if not provided
        if not self.username:
            self.username = self.email.split('@')[0]
        
        # Initialize default notification preferences
        if not self.notification_preferences:
            self.notification_preferences = {
                'email_notifications': True,
                'contract_updates': True,
                'approval_requests': True,
                'system_alerts': True
            }
        
        # Derive permissions from roles
        self._update_permissions_from_roles()
    
    def create(self, created_by: Optional[UUID] = None) -> None:
        """Create a new user"""
        if self.status != UserStatus.PENDING:
            raise ValueError("Can only create users in pending status")
        
        self.created_by = created_by
        self.updated_by = created_by
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
        
        # Generate password salt if not provided
        if not self.password_salt:
            self.password_salt = secrets.token_hex(32)
        
        # Raise domain event
        self._add_domain_event(UserCreated(
            user_id=self.id,
            email=self.email,
            full_name=self.full_name,
            organization_id=self.organization_id,
            created_by=created_by,
            occurred_at=datetime.utcnow()
        ))
    
    def update(self, updated_by: UUID, **kwargs) -> None:
        """Update user fields"""
        old_values = {}
        for key, value in kwargs.items():
            if hasattr(self, key):
                old_values[key] = getattr(self, key)
                setattr(self, key, value)
        
        self.updated_by = updated_by
        self.updated_at = datetime.utcnow()
        
        # Update permissions if roles changed
        if 'roles' in kwargs:
            self._update_permissions_from_roles()
        
        # Raise domain event
        self._add_domain_event(UserUpdated(
            user_id=self.id,
            updated_fields=list(kwargs.keys()),
            old_values=old_values,
            new_values=kwargs,
            updated_by=updated_by,
            occurred_at=datetime.utcnow()
        ))
    
    def set_password(self, password: str, changed_by: UUID) -> None:
        """Set user password with hashing"""
        if len(password) < 8:
            raise ValueError("Password must be at least 8 characters long")
        
        # Generate new salt
        self.password_salt = secrets.token_hex(32)
        
        # Hash password with salt
        self.password_hash = self._hash_password(password, self.password_salt)
        self.password_changed_at = datetime.utcnow()
        self.password_expires_at = datetime.utcnow() + timedelta(days=90)
        self.updated_by = changed_by
        self.updated_at = datetime.utcnow()
        
        # Reset failed attempts
        self.failed_login_attempts = 0
        
        # Raise domain event
        self._add_domain_event(UserPasswordChanged(
            user_id=self.id,
            changed_by=changed_by,
            occurred_at=datetime.utcnow()
        ))
    
    def verify_password(self, password: str) -> bool:
        """Verify password against stored hash"""
        if not self.password_hash or not self.password_salt:
            return False
        
        password_hash = self._hash_password(password, self.password_salt)
        return password_hash == self.password_hash
    
    def attempt_login(self, password: str, ip_address: str) -> bool:
        """Attempt user login"""
        # Check if account is locked
        if self.failed_login_attempts >= 5:
            raise ValueError("Account is locked due to too many failed attempts")
        
        # Check if user is active
        if not self.is_active or self.status != UserStatus.ACTIVE:
            raise ValueError("User account is not active")
        
        # Verify password
        login_successful = self.verify_password(password)
        
        # Raise domain event
        self._add_domain_event(UserLoginAttempted(
            user_id=self.id,
            ip_address=ip_address,
            successful=login_successful,
            occurred_at=datetime.utcnow()
        ))
        
        if login_successful:
            # Reset failed attempts and update last login
            self.failed_login_attempts = 0
            self.last_login_at = datetime.utcnow()
            self.last_login_ip = ip_address
            self.updated_at = datetime.utcnow()
        else:
            # Increment failed attempts
            self.failed_login_attempts += 1
            self.updated_at = datetime.utcnow()
        
        return login_successful
    
    def activate(self, activated_by: UUID) -> None:
        """Activate user account"""
        if self.status == UserStatus.ACTIVE:
            return  # Already active
        
        self.status = UserStatus.ACTIVE
        self.is_active = True
        self.updated_by = activated_by
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(UserActivated(
            user_id=self.id,
            activated_by=activated_by,
            occurred_at=datetime.utcnow()
        ))
    
    def deactivate(self, deactivated_by: UUID, reason: str) -> None:
        """Deactivate user account"""
        if self.status == UserStatus.INACTIVE:
            return  # Already inactive
        
        self.status = UserStatus.INACTIVE
        self.is_active = False
        self.updated_by = deactivated_by
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(UserDeactivated(
            user_id=self.id,
            deactivated_by=deactivated_by,
            reason=reason,
            occurred_at=datetime.utcnow()
        ))
    
    def add_role(self, role: UserRole, assigned_by: UUID) -> None:
        """Add role to user"""
        if role not in self.roles:
            self.roles.append(role)
            self._update_permissions_from_roles()
            self.updated_by = assigned_by
            self.updated_at = datetime.utcnow()
            
            # Raise domain event
            self._add_domain_event(UserRoleChanged(
                user_id=self.id,
                action="added",
                role=role.value,
                assigned_by=assigned_by,
                occurred_at=datetime.utcnow()
            ))
    
    def remove_role(self, role: UserRole, removed_by: UUID) -> None:
        """Remove role from user"""
        if role in self.roles:
            self.roles.remove(role)
            self._update_permissions_from_roles()
            self.updated_by = removed_by
            self.updated_at = datetime.utcnow()
            
            # Raise domain event
            self._add_domain_event(UserRoleChanged(
                user_id=self.id,
                action="removed",
                role=role.value,
                assigned_by=removed_by,
                occurred_at=datetime.utcnow()
            ))
    
    def has_permission(self, permission: Permission) -> bool:
        """Check if user has specific permission"""
        return permission in self.permissions
    
    def has_role(self, role: UserRole) -> bool:
        """Check if user has specific role"""
        return role in self.roles
    
    def can_access_contract(self, contract_owner_id: UUID, contract_org_id: UUID) -> bool:
        """Check if user can access a specific contract"""
        # Admin can access everything
        if UserRole.ADMIN in self.roles:
            return True
        
        # Owner can access their own contracts
        if contract_owner_id == self.id:
            return True
        
        # Same organization members with appropriate roles
        if contract_org_id == self.organization_id:
            if UserRole.DATA_OWNER in self.roles or UserRole.DATA_STEWARD in self.roles:
                return True
        
        return False
    
    def can_approve_contract(self) -> bool:
        """Check if user can approve contracts"""
        return UserRole.DATA_OWNER in self.roles or UserRole.ADMIN in self.roles
    
    def verify_email(self) -> None:
        """Mark email as verified"""
        self.is_verified = True
        self.email_verified_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
    
    def enable_two_factor(self, secret: str) -> None:
        """Enable two-factor authentication"""
        self.two_factor_enabled = True
        self.two_factor_secret = secret
        self.updated_at = datetime.utcnow()
    
    def disable_two_factor(self) -> None:
        """Disable two-factor authentication"""
        self.two_factor_enabled = False
        self.two_factor_secret = None
        self.updated_at = datetime.utcnow()
    
    def is_password_expired(self) -> bool:
        """Check if password is expired"""
        if not self.password_expires_at:
            return False
        return datetime.utcnow() > self.password_expires_at
    
    def is_account_locked(self) -> bool:
        """Check if account is locked"""
        return self.failed_login_attempts >= 5
    
    def unlock_account(self, unlocked_by: UUID) -> None:
        """Unlock user account"""
        self.failed_login_attempts = 0
        self.updated_by = unlocked_by
        self.updated_at = datetime.utcnow()
    
    def get_domain_events(self) -> List[Any]:
        """Get and clear domain events"""
        events = self._domain_events.copy()
        self._domain_events.clear()
        return events
    
    def _add_domain_event(self, event: Any) -> None:
        """Add a domain event"""
        self._domain_events.append(event)
    
    def _hash_password(self, password: str, salt: str) -> str:
        """Hash password with salt using SHA-256"""
        return hashlib.sha256((password + salt).encode()).hexdigest()
    
    def _update_permissions_from_roles(self) -> None:
        """Update permissions based on current roles"""
        self.permissions.clear()
        for role in self.roles:
            self.permissions.update(role.get_permissions())


@dataclass
class UserSession:
    """User session for tracking active sessions"""
    id: UUID = field(default_factory=uuid4)
    user_id: UUID = field(default_factory=uuid4)
    session_token: str = ""
    refresh_token: str = ""
    
    # Session details
    ip_address: str = ""
    user_agent: str = ""
    device_info: Optional[str] = None
    
    # Timing
    created_at: datetime = field(default_factory=datetime.utcnow)
    expires_at: datetime = field(default_factory=lambda: datetime.utcnow() + timedelta(hours=8))
    last_activity_at: datetime = field(default_factory=datetime.utcnow)
    
    # Status
    is_active: bool = True
    revoked_at: Optional[datetime] = None
    revoked_by: Optional[UUID] = None
    
    def is_expired(self) -> bool:
        """Check if session is expired"""
        return datetime.utcnow() > self.expires_at
    
    def is_valid(self) -> bool:
        """Check if session is valid"""
        return self.is_active and not self.is_expired() and not self.revoked_at
    
    def refresh(self, new_token: str, new_refresh_token: str) -> None:
        """Refresh session with new tokens"""
        self.session_token = new_token
        self.refresh_token = new_refresh_token
        self.expires_at = datetime.utcnow() + timedelta(hours=8)
        self.last_activity_at = datetime.utcnow()
    
    def revoke(self, revoked_by: UUID) -> None:
        """Revoke session"""
        self.is_active = False
        self.revoked_at = datetime.utcnow()
        self.revoked_by = revoked_by
    
    def update_activity(self) -> None:
        """Update last activity timestamp"""
        self.last_activity_at = datetime.utcnow()


@dataclass
class UserProfile:
    """Extended user profile information"""
    user_id: UUID = field(default_factory=uuid4)
    
    # Professional information
    bio: Optional[str] = None
    skills: List[str] = field(default_factory=list)
    certifications: List[str] = field(default_factory=list)
    experience_years: Optional[int] = None
    
    # Contact preferences
    preferred_contact_method: str = "email"
    work_hours_start: Optional[str] = None
    work_hours_end: Optional[str] = None
    
    # Social links
    linkedin_url: Optional[str] = None
    github_url: Optional[str] = None
    
    # Avatar and display
    avatar_url: Optional[str] = None
    display_name: Optional[str] = None
    
    # Audit fields
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)

