# Autor: carlos.morais@f1rst.com.br
"""
User Role and Permission Value Objects
Defines roles and permissions for the governance platform
"""

from enum import Enum
from dataclasses import dataclass
from typing import Set, List, Dict, Any


class Permission(Enum):
    """System permissions"""
    # Contract permissions
    CONTRACT_CREATE = "contract:create"
    CONTRACT_READ = "contract:read"
    CONTRACT_UPDATE = "contract:update"
    CONTRACT_DELETE = "contract:delete"
    CONTRACT_APPROVE = "contract:approve"
    CONTRACT_ACTIVATE = "contract:activate"
    CONTRACT_SUSPEND = "contract:suspend"
    
    # User management permissions
    USER_CREATE = "user:create"
    USER_READ = "user:read"
    USER_UPDATE = "user:update"
    USER_DELETE = "user:delete"
    USER_MANAGE_ROLES = "user:manage_roles"
    
    # Organization permissions
    ORG_MANAGE = "organization:manage"
    ORG_VIEW_ALL = "organization:view_all"
    
    # Data permissions
    DATA_READ = "data:read"
    DATA_WRITE = "data:write"
    DATA_EXPORT = "data:export"
    DATA_MASK = "data:mask"
    DATA_CLASSIFY = "data:classify"
    
    # Quality permissions
    QUALITY_DEFINE_RULES = "quality:define_rules"
    QUALITY_VIEW_METRICS = "quality:view_metrics"
    QUALITY_MANAGE_ALERTS = "quality:manage_alerts"
    
    # Analytics permissions
    ANALYTICS_VIEW = "analytics:view"
    ANALYTICS_CREATE_REPORTS = "analytics:create_reports"
    ANALYTICS_EXPORT = "analytics:export"
    
    # System administration
    SYSTEM_ADMIN = "system:admin"
    SYSTEM_CONFIG = "system:config"
    SYSTEM_MONITOR = "system:monitor"
    SYSTEM_AUDIT = "system:audit"
    
    # Workflow permissions
    WORKFLOW_CREATE = "workflow:create"
    WORKFLOW_EXECUTE = "workflow:execute"
    WORKFLOW_MONITOR = "workflow:monitor"
    
    # Catalog permissions
    CATALOG_BROWSE = "catalog:browse"
    CATALOG_MANAGE = "catalog:manage"
    CATALOG_PUBLISH = "catalog:publish"


class UserRole(Enum):
    """User roles in the governance platform"""
    ADMIN = "admin"
    DATA_OWNER = "data_owner"
    DATA_STEWARD = "data_steward"
    DATA_ENGINEER = "data_engineer"
    DATA_ANALYST = "data_analyst"
    BUSINESS_USER = "business_user"
    COMPLNCE_OFFICER = "compliance_officer"
    AUDITOR = "auditor"
    VIEWER = "viewer"
    
    def __str__(self) -> str:
        return self.value
    
    @classmethod
    def from_string(cls, value: str) -> 'UserRole':
        """Create role from string value"""
        for role in cls:
            if role.value == value.lower():
                return role
        raise ValueError(f"Invalid user role: {value}")
    
    def get_permissions(self) -> Set[Permission]:
        """Get permissions for this role"""
        role_permissions = {
            UserRole.ADMIN: {
                # Full system access
                Permission.SYSTEM_ADMIN,
                Permission.SYSTEM_CONFIG,
                Permission.SYSTEM_MONITOR,
                Permission.SYSTEM_AUDIT,
                
                # Full contract access
                Permission.CONTRACT_CREATE,
                Permission.CONTRACT_READ,
                Permission.CONTRACT_UPDATE,
                Permission.CONTRACT_DELETE,
                Permission.CONTRACT_APPROVE,
                Permission.CONTRACT_ACTIVATE,
                Permission.CONTRACT_SUSPEND,
                
                # Full user management
                Permission.USER_CREATE,
                Permission.USER_READ,
                Permission.USER_UPDATE,
                Permission.USER_DELETE,
                Permission.USER_MANAGE_ROLES,
                
                # Organization management
                Permission.ORG_MANAGE,
                Permission.ORG_VIEW_ALL,
                
                # Full data access
                Permission.DATA_READ,
                Permission.DATA_WRITE,
                Permission.DATA_EXPORT,
                Permission.DATA_MASK,
                Permission.DATA_CLASSIFY,
                
                # Quality management
                Permission.QUALITY_DEFINE_RULES,
                Permission.QUALITY_VIEW_METRICS,
                Permission.QUALITY_MANAGE_ALERTS,
                
                # Analytics
                Permission.ANALYTICS_VIEW,
                Permission.ANALYTICS_CREATE_REPORTS,
                Permission.ANALYTICS_EXPORT,
                
                # Workflow
                Permission.WORKFLOW_CREATE,
                Permission.WORKFLOW_EXECUTE,
                Permission.WORKFLOW_MONITOR,
                
                # Catalog
                Permission.CATALOG_BROWSE,
                Permission.CATALOG_MANAGE,
                Permission.CATALOG_PUBLISH
            },
            
            UserRole.DATA_OWNER: {
                # Contract management
                Permission.CONTRACT_CREATE,
                Permission.CONTRACT_READ,
                Permission.CONTRACT_UPDATE,
                Permission.CONTRACT_APPROVE,
                Permission.CONTRACT_ACTIVATE,
                Permission.CONTRACT_SUSPEND,
                
                # Data governance
                Permission.DATA_READ,
                Permission.DATA_WRITE,
                Permission.DATA_CLASSIFY,
                
                # Quality oversight
                Permission.QUALITY_DEFINE_RULES,
                Permission.QUALITY_VIEW_METRICS,
                Permission.QUALITY_MANAGE_ALERTS,
                
                # Analytics
                Permission.ANALYTICS_VIEW,
                Permission.ANALYTICS_CREATE_REPORTS,
                
                # Catalog management
                Permission.CATALOG_BROWSE,
                Permission.CATALOG_MANAGE,
                Permission.CATALOG_PUBLISH,
                
                # User management (limited)
                Permission.USER_READ
            },
            
            UserRole.DATA_STEWARD: {
                # Contract operations
                Permission.CONTRACT_CREATE,
                Permission.CONTRACT_READ,
                Permission.CONTRACT_UPDATE,
                
                # Data management
                Permission.DATA_READ,
                Permission.DATA_WRITE,
                Permission.DATA_CLASSIFY,
                Permission.DATA_MASK,
                
                # Quality management
                Permission.QUALITY_DEFINE_RULES,
                Permission.QUALITY_VIEW_METRICS,
                
                # Analytics
                Permission.ANALYTICS_VIEW,
                
                # Catalog
                Permission.CATALOG_BROWSE,
                Permission.CATALOG_MANAGE,
                
                # Workflow
                Permission.WORKFLOW_CREATE,
                Permission.WORKFLOW_EXECUTE
            },
            
            UserRole.DATA_ENGINEER: {
                # Contract technical operations
                Permission.CONTRACT_READ,
                Permission.CONTRACT_UPDATE,
                
                # Data operations
                Permission.DATA_READ,
                Permission.DATA_WRITE,
                Permission.DATA_MASK,
                
                # Quality implementation
                Permission.QUALITY_VIEW_METRICS,
                
                # Analytics
                Permission.ANALYTICS_VIEW,
                
                # Catalog
                Permission.CATALOG_BROWSE,
                
                # Workflow
                Permission.WORKFLOW_EXECUTE,
                Permission.WORKFLOW_MONITOR
            },
            
            UserRole.DATA_ANALYST: {
                # Contract viewing
                Permission.CONTRACT_READ,
                
                # Data access
                Permission.DATA_READ,
                Permission.DATA_EXPORT,
                
                # Quality viewing
                Permission.QUALITY_VIEW_METRICS,
                
                # Analytics
                Permission.ANALYTICS_VIEW,
                Permission.ANALYTICS_CREATE_REPORTS,
                Permission.ANALYTICS_EXPORT,
                
                # Catalog
                Permission.CATALOG_BROWSE
            },
            
            UserRole.BUSINESS_USER: {
                # Limited contract access
                Permission.CONTRACT_READ,
                
                # Data consumption
                Permission.DATA_READ,
                
                # Analytics viewing
                Permission.ANALYTICS_VIEW,
                
                # Catalog browsing
                Permission.CATALOG_BROWSE
            },
            
            UserRole.COMPLNCE_OFFICER: {
                # Contract compliance
                Permission.CONTRACT_READ,
                Permission.CONTRACT_APPROVE,
                
                # Data governance
                Permission.DATA_READ,
                Permission.DATA_CLASSIFY,
                
                # Quality oversight
                Permission.QUALITY_VIEW_METRICS,
                Permission.QUALITY_MANAGE_ALERTS,
                
                # Analytics for compliance
                Permission.ANALYTICS_VIEW,
                Permission.ANALYTICS_CREATE_REPORTS,
                
                # System audit
                Permission.SYSTEM_AUDIT,
                
                # Catalog
                Permission.CATALOG_BROWSE
            },
            
            UserRole.AUDITOR: {
                # Read-only access for auditing
                Permission.CONTRACT_READ,
                Permission.DATA_READ,
                Permission.QUALITY_VIEW_METRICS,
                Permission.ANALYTICS_VIEW,
                Permission.SYSTEM_AUDIT,
                Permission.CATALOG_BROWSE,
                Permission.USER_READ
            },
            
            UserRole.VIEWER: {
                # Minimal read access
                Permission.CONTRACT_READ,
                Permission.DATA_READ,
                Permission.ANALYTICS_VIEW,
                Permission.CATALOG_BROWSE
            }
        }
        
        return role_permissions.get(self, set())
    
    def get_description(self) -> str:
        """Get role description"""
        descriptions = {
            UserRole.ADMIN: "Administrador do sistema com acesso completo",
            UserRole.DATA_OWNER: "Proprietário de dados responsável pela governança",
            UserRole.DATA_STEWARD: "Curador de dados responsável pela qualidade",
            UserRole.DATA_ENGINEER: "Engenheiro de dados responsável pela implementação",
            UserRole.DATA_ANALYST: "Analista de dados que consome informações",
            UserRole.BUSINESS_USER: "Usuário de negócio com acesso limitado",
            UserRole.COMPLNCE_OFFICER: "Oficial de compliance responsável pela conformidade",
            UserRole.AUDITOR: "Auditor com acesso somente leitura",
            UserRole.VIEWER: "Visualizador com acesso mínimo"
        }
        return descriptions.get(self, "Papel não definido")
    
    def can_approve_contracts(self) -> bool:
        """Check if role can approve contracts"""
        return Permission.CONTRACT_APPROVE in self.get_permissions()
    
    def can_manage_users(self) -> bool:
        """Check if role can manage users"""
        return Permission.USER_MANAGE_ROLES in self.get_permissions()
    
    def is_admin_role(self) -> bool:
        """Check if this is an admin role"""
        return self == UserRole.ADMIN
    
    def is_data_governance_role(self) -> bool:
        """Check if this is a data governance role"""
        return self in [UserRole.DATA_OWNER, UserRole.DATA_STEWARD, UserRole.COMPLNCE_OFFICER]


@dataclass(frozen=True)
class RoleAssignment:
    """Represents a role assignment with metadata"""
    user_id: str
    role: UserRole
    assigned_by: str
    assigned_at: str
    expires_at: str = None
    scope: str = "global"  # global, organization, dataset
    scope_id: str = None
    
    def is_expired(self) -> bool:
        """Check if role assignment is expired"""
        if not self.expires_at:
            return False
        from datetime import datetime
        return datetime.fromisoformat(self.expires_at) < datetime.utcnow()
    
    def is_scoped(self) -> bool:
        """Check if role is scoped to specific resource"""
        return self.scope != "global"


@dataclass
class PermissionCheck:
    """Helper for checking permissions"""
    user_roles: List[UserRole]
    required_permission: Permission
    resource_context: Dict[str, Any] = None
    
    def is_allowed(self) -> bool:
        """Check if user has required permission"""
        user_permissions = set()
        for role in self.user_roles:
            user_permissions.update(role.get_permissions())
        
        return self.required_permission in user_permissions
    
    def get_missing_permissions(self) -> Set[Permission]:
        """Get missing permissions"""
        user_permissions = set()
        for role in self.user_roles:
            user_permissions.update(role.get_permissions())
        
        if self.required_permission not in user_permissions:
            return {self.required_permission}
        return set()


# Predefined role hierarchies
ROLE_HIERARCHY = {
    UserRole.ADMIN: [UserRole.DATA_OWNER, UserRole.COMPLNCE_OFFICER, UserRole.AUDITOR],
    UserRole.DATA_OWNER: [UserRole.DATA_STEWARD, UserRole.DATA_ANALYST],
    UserRole.DATA_STEWARD: [UserRole.DATA_ENGINEER, UserRole.BUSINESS_USER],
    UserRole.COMPLNCE_OFFICER: [UserRole.AUDITOR],
    UserRole.DATA_ENGINEER: [UserRole.VIEWER],
    UserRole.DATA_ANALYST: [UserRole.VIEWER],
    UserRole.BUSINESS_USER: [UserRole.VIEWER]
}


def get_effective_permissions(roles: List[UserRole]) -> Set[Permission]:
    """Get effective permissions from multiple roles"""
    permissions = set()
    for role in roles:
        permissions.update(role.get_permissions())
    return permissions


def can_user_access_resource(user_roles: List[UserRole], 
                           required_permission: Permission,
                           resource_owner_id: str = None,
                           user_id: str = None,
                           organization_id: str = None,
                           user_org_id: str = None) -> bool:
    """Check if user can access a resource"""
    # Check basic permission
    user_permissions = get_effective_permissions(user_roles)
    if required_permission not in user_permissions:
        return False
    
    # Admin can access everything
    if UserRole.ADMIN in user_roles:
        return True
    
    # Owner can access their own resources
    if resource_owner_id and user_id and resource_owner_id == user_id:
        return True
    
    # Same organization access for certain roles
    if organization_id and user_org_id and organization_id == user_org_id:
        governance_roles = [UserRole.DATA_OWNER, UserRole.DATA_STEWARD, UserRole.COMPLNCE_OFFICER]
        if any(role in user_roles for role in governance_roles):
            return True
    
    return False

