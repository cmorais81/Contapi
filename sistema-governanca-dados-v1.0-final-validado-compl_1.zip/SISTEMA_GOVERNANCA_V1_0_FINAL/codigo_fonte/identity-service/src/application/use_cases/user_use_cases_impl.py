# Autor: carlos.morais@f1rst.com.br
"""
User Use Cases Implementation
Business logic for user management operations
"""

import jwt
import secrets
import qrcode
import io
import base64
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from uuid import UUID, uuid4

from ...domain.entities.user import User as UserEntity
from ...domain.repositories.user_repository import UserRepository
from ...domain.value_objects.user_role import UserRole
from ...domain.value_objects.user_status import UserStatus
from ...domain.services.auth_service import AuthService
from ...domain.services.permission_service import PermissionService
from ..dtos.user_dtos import (
    CreateUserRequest, UpdateUserRequest, ChangePasswordRequest,
    LoginRequest, RefreshTokenRequest, AssignRoleRequest,
    UserResponse, UserListResponse, LoginResponse, TokenResponse,
    UserPermissionsResponse, UserStatisticsResponse, UserSearchRequest,
    UserFilterRequest, Permission, UserRole as UserRoleDTO,
    UserStatus as UserStatusDTO, Enable2FARequest, Enable2FAResponse,
    Verify2FARequest, PasswordResetRequest, PasswordResetConfirmRequest
)


class UserUseCasesImpl:
    """Implementation of user use cases"""
    
    def __init__(self, user_repository: UserRepository):
        self.user_repository = user_repository
        self.auth_service = AuthService()
        self.permission_service = PermissionService()
        
        # JWT configuration
        self.jwt_secret = "your-secret-key-here"  # Should come from environment
        self.jwt_algorithm = "HS256"
        self.access_token_expire_minutes = 30
        self.refresh_token_expire_days = 7
    
    async def create_user(self, request: CreateUserRequest) -> UserResponse:
        """Create a new user"""
        try:
            # Check if email already exists
            if self.user_repository.exists_by_email(request.email):
                raise ValueError("Email already exists")
            
            # Hash password
            password_hash, password_salt = self.user_repository.hash_password(request.password)
            
            # Create user entity
            user = UserEntity(
                id=uuid4(),
                email=request.email.lower(),
                name=request.name,
                password_hash=password_hash,
                password_salt=password_salt,
                role=UserRole(request.role.value),
                status=UserStatus.PENDING_ACTIVATION,
                organization_id=request.organization_id,
                department=request.department,
                job_title=request.job_title,
                phone=request.phone,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            # Save user
            saved_user = self.user_repository.save(user)
            
            # Convert to response DTO
            return self._entity_to_response(saved_user)
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to create user: {str(e)}")
    
    async def get_user(self, user_id: UUID) -> Optional[UserResponse]:
        """Get user by ID"""
        try:
            user = self.user_repository.find_by_id(user_id)
            if not user:
                return None
            
            return self._entity_to_response(user)
            
        except Exception as e:
            raise RuntimeError(f"Failed to get user: {str(e)}")
    
    async def update_user(self, user_id: UUID, request: UpdateUserRequest) -> Optional[UserResponse]:
        """Update user information"""
        try:
            user = self.user_repository.find_by_id(user_id)
            if not user:
                return None
            
            # Update fields
            if request.name is not None:
                user.name = request.name
            if request.department is not None:
                user.department = request.department
            if request.job_title is not None:
                user.job_title = request.job_title
            if request.phone is not None:
                user.phone = request.phone
            if request.status is not None:
                user.status = UserStatus(request.status.value)
            
            user.updated_at = datetime.utcnow()
            
            # Save updated user
            updated_user = self.user_repository.save(user)
            
            return self._entity_to_response(updated_user)
            
        except Exception as e:
            raise RuntimeError(f"Failed to update user: {str(e)}")
    
    async def change_password(self, user_id: UUID, request: ChangePasswordRequest) -> bool:
        """Change user password"""
        try:
            user = self.user_repository.find_by_id(user_id)
            if not user:
                return False
            
            # Verify current password
            if not self.user_repository.verify_password(
                request.current_password, user.password_hash, user.password_salt
            ):
                raise ValueError("Current password is incorrect")
            
            # Hash new password
            new_hash, new_salt = self.user_repository.hash_password(request.new_password)
            
            # Update password
            user.password_hash = new_hash
            user.password_salt = new_salt
            user.updated_at = datetime.utcnow()
            
            self.user_repository.save(user)
            return True
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to change password: {str(e)}")
    
    async def login(self, request: LoginRequest) -> Optional[LoginResponse]:
        """Authenticate user and return tokens"""
        try:
            # Find user by email
            user = self.user_repository.find_by_email(request.email)
            if not user:
                return None
            
            # Check if account is locked
            if user.is_locked:
                raise ValueError("Account is locked due to too many failed login attempts")
            
            # Check if account is active
            if user.status != UserStatus.ACTIVE:
                raise ValueError("Account is not active")
            
            # Verify password
            if not self.user_repository.verify_password(
                request.password, user.password_hash, user.password_salt
            ):
                # Increment failed login attempts
                self.user_repository.increment_failed_login_attempts(user.id)
                return None
            
            # Update last login
            self.user_repository.update_last_login(user.id, "127.0.0.1", "API")
            
            # Generate tokens
            access_token = self._generate_access_token(user)
            refresh_token = self._generate_refresh_token(user)
            
            return LoginResponse(
                access_token=access_token,
                refresh_token=refresh_token,
                expires_in=self.access_token_expire_minutes * 60,
                user=self._entity_to_response(user)
            )
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to login: {str(e)}")
    
    async def refresh_token(self, request: RefreshTokenRequest) -> Optional[TokenResponse]:
        """Refresh access token"""
        try:
            # Decode refresh token
            payload = jwt.decode(
                request.refresh_token,
                self.jwt_secret,
                algorithms=[self.jwt_algorithm]
            )
            
            user_id = UUID(payload.get("sub"))
            token_type = payload.get("type")
            
            if token_type != "refresh":
                raise ValueError("Invalid token type")
            
            # Find user
            user = self.user_repository.find_by_id(user_id)
            if not user or user.status != UserStatus.ACTIVE:
                return None
            
            # Generate new access token
            access_token = self._generate_access_token(user)
            
            return TokenResponse(
                access_token=access_token,
                expires_in=self.access_token_expire_minutes * 60
            )
            
        except jwt.ExpiredSignatureError:
            raise ValueError("Refresh token has expired")
        except jwt.InvalidTokenError:
            raise ValueError("Invalid refresh token")
        except Exception as e:
            raise RuntimeError(f"Failed to refresh token: {str(e)}")
    
    async def list_users(self, organization_id: Optional[UUID] = None, 
                        role: Optional[UserRoleDTO] = None,
                        status: Optional[UserStatusDTO] = None,
                        limit: int = 100, offset: int = 0) -> UserListResponse:
        """List users with filters"""
        try:
            filters = {}
            if organization_id:
                filters['organization_id'] = organization_id
            if role:
                filters['role'] = role.value
            if status:
                filters['status'] = status.value
            
            users = self.user_repository.find_with_filters(filters, limit, offset)
            
            # Get total count
            total = len(users)  # Simplified - should be a separate count query
            
            return UserListResponse(
                users=[self._entity_to_response(user) for user in users],
                total=total,
                limit=limit,
                offset=offset,
                has_more=total > offset + limit
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to list users: {str(e)}")
    
    async def search_users(self, request: UserSearchRequest) -> UserListResponse:
        """Search users by text"""
        try:
            users = self.user_repository.search_users(
                request.search_term,
                request.organization_id,
                request.limit,
                request.offset
            )
            
            total = len(users)  # Simplified
            
            return UserListResponse(
                users=[self._entity_to_response(user) for user in users],
                total=total,
                limit=request.limit,
                offset=request.offset,
                has_more=total > request.offset + request.limit
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to search users: {str(e)}")
    
    async def assign_role(self, request: AssignRoleRequest) -> bool:
        """Assign role to user"""
        try:
            user = self.user_repository.find_by_id(request.user_id)
            if not user:
                return False
            
            # Update role
            user.role = UserRole(request.role.value)
            user.updated_at = datetime.utcnow()
            
            self.user_repository.save(user)
            return True
            
        except Exception as e:
            raise RuntimeError(f"Failed to assign role: {str(e)}")
    
    async def get_user_permissions(self, user_id: UUID) -> Optional[UserPermissionsResponse]:
        """Get user permissions"""
        try:
            user = self.user_repository.find_by_id(user_id)
            if not user:
                return None
            
            # Get permissions for role
            permissions = self.permission_service.get_permissions_for_role(user.role)
            
            return UserPermissionsResponse(
                user_id=user.id,
                role=UserRoleDTO(user.role.value),
                permissions=permissions,
                organization_permissions={str(user.organization_id): permissions}
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to get user permissions: {str(e)}")
    
    async def get_user_statistics(self, organization_id: UUID) -> UserStatisticsResponse:
        """Get user statistics for organization"""
        try:
            total_users = self.user_repository.count_by_organization(organization_id)
            status_counts = self.user_repository.count_by_status(organization_id)
            role_counts = self.user_repository.count_by_role(organization_id)
            recent_logins = self.user_repository.get_recent_logins(organization_id)
            failed_attempts = self.user_repository.get_failed_login_attempts(organization_id)
            
            return UserStatisticsResponse(
                organization_id=organization_id,
                total_users=total_users,
                active_users=status_counts.get('active', 0),
                inactive_users=status_counts.get('inactive', 0),
                suspended_users=status_counts.get('suspended', 0),
                users_by_role=role_counts,
                recent_logins=recent_logins,
                failed_login_attempts=failed_attempts
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to get user statistics: {str(e)}")
    
    async def enable_2fa(self, user_id: UUID, request: Enable2FARequest) -> Optional[Enable2FAResponse]:
        """Enable two-factor authentication"""
        try:
            user = self.user_repository.find_by_id(user_id)
            if not user:
                return None
            
            # Verify password
            if not self.user_repository.verify_password(
                request.password, user.password_hash, user.password_salt
            ):
                raise ValueError("Password is incorrect")
            
            # Generate secret
            secret = secrets.token_hex(16)
            
            # Generate QR code
            qr_code_url = f"otpauth://totp/Governance:{user.email}?secret={secret}&issuer=Governance"
            
            # Generate QR code image
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(qr_code_url)
            qr.make(fit=True)
            
            img = qr.make_image(fill_color="black", back_color="white")
            img_buffer = io.BytesIO()
            img.save(img_buffer, format='PNG')
            img_str = base64.b64encode(img_buffer.getvalue()).decode()
            
            # Generate backup codes
            backup_codes = [secrets.token_hex(8) for _ in range(10)]
            
            # Update user (but don't enable 2FA yet - wait for verification)
            user.two_factor_secret = secret
            user.updated_at = datetime.utcnow()
            self.user_repository.save(user)
            
            return Enable2FAResponse(
                secret_key=secret,
                qr_code_url=f"data:image/png;base64,{img_str}",
                backup_codes=backup_codes
            )
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to enable 2FA: {str(e)}")
    
    async def verify_2fa(self, user_id: UUID, request: Verify2FARequest) -> bool:
        """Verify 2FA code and enable 2FA"""
        try:
            user = self.user_repository.find_by_id(user_id)
            if not user or not user.two_factor_secret:
                return False
            
            # Verify code (simplified - should use proper TOTP verification)
            # For demo purposes, accept any 6-digit code
            if len(request.code) == 6 and request.code.isdigit():
                user.two_factor_enabled = True
                user.updated_at = datetime.utcnow()
                self.user_repository.save(user)
                return True
            
            return False
            
        except Exception as e:
            raise RuntimeError(f"Failed to verify 2FA: {str(e)}")
    
    async def delete_user(self, user_id: UUID) -> bool:
        """Delete user (soft delete)"""
        try:
            return self.user_repository.delete(user_id)
        except Exception as e:
            raise RuntimeError(f"Failed to delete user: {str(e)}")
    
    async def unlock_user(self, user_id: UUID) -> bool:
        """Unlock user account"""
        try:
            return self.user_repository.unlock_user(user_id)
        except Exception as e:
            raise RuntimeError(f"Failed to unlock user: {str(e)}")
    
    def _generate_access_token(self, user: UserEntity) -> str:
        """Generate JWT access token"""
        payload = {
            "sub": str(user.id),
            "email": user.email,
            "role": user.role.value,
            "org_id": str(user.organization_id),
            "type": "access",
            "iat": datetime.utcnow(),
            "exp": datetime.utcnow() + timedelta(minutes=self.access_token_expire_minutes)
        }
        
        return jwt.encode(payload, self.jwt_secret, algorithm=self.jwt_algorithm)
    
    def _generate_refresh_token(self, user: UserEntity) -> str:
        """Generate JWT refresh token"""
        payload = {
            "sub": str(user.id),
            "type": "refresh",
            "iat": datetime.utcnow(),
            "exp": datetime.utcnow() + timedelta(days=self.refresh_token_expire_days)
        }
        
        return jwt.encode(payload, self.jwt_secret, algorithm=self.jwt_algorithm)
    
    def _entity_to_response(self, user: UserEntity) -> UserResponse:
        """Convert user entity to response DTO"""
        return UserResponse(
            id=user.id,
            email=user.email,
            name=user.name,
            role=UserRoleDTO(user.role.value),
            status=UserStatusDTO(user.status.value),
            organization_id=user.organization_id,
            organization_name=user.organization_name,
            department=user.department,
            job_title=user.job_title,
            phone=user.phone,
            last_login=user.last_login,
            failed_login_attempts=user.failed_login_attempts,
            is_locked=user.is_locked,
            two_factor_enabled=user.two_factor_enabled,
            created_at=user.created_at,
            updated_at=user.updated_at
        )

