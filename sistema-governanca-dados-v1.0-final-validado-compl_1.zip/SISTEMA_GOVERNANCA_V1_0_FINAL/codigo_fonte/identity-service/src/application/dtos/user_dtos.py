# Autor: carlos.morais@f1rst.com.br
"""
User DTOs for Identity Service
Data Transfer Objects for user management operations
"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import UUID
from pydantic import BaseModel, EmailStr, Field, validator
from enum import Enum


class UserRole(str, Enum):
    """User roles enum"""
    ADMIN = "admin"
    DATA_OWNER = "data_owner"
    DATA_STEWARD = "data_steward"
    DATA_ENGINEER = "data_engineer"
    DATA_ANALYST = "data_analyst"
    BUSINESS_USER = "business_user"
    COMPLNCE_OFFICER = "compliance_officer"
    AUDITOR = "auditor"
    VIEWER = "viewer"


class UserStatus(str, Enum):
    """User status enum"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    PENDING_ACTIVATION = "pending_activation"


class Permission(str, Enum):
    """System permissions"""
    # Contract permissions
    CONTRACT_CREATE = "contract:create"
    CONTRACT_READ = "contract:read"
    CONTRACT_UPDATE = "contract:update"
    CONTRACT_DELETE = "contract:delete"
    CONTRACT_APPROVE = "contract:approve"
    CONTRACT_ACTIVATE = "contract:activate"
    
    # User permissions
    USER_CREATE = "user:create"
    USER_READ = "user:read"
    USER_UPDATE = "user:update"
    USER_DELETE = "user:delete"
    USER_MANAGE_ROLES = "user:manage_roles"
    
    # Dataset permissions
    DATASET_CREATE = "dataset:create"
    DATASET_READ = "dataset:read"
    DATASET_UPDATE = "dataset:update"
    DATASET_DELETE = "dataset:delete"
    DATASET_ACCESS = "dataset:access"
    
    # Quality permissions
    QUALITY_CREATE_RULES = "quality:create_rules"
    QUALITY_READ_METRICS = "quality:read_metrics"
    QUALITY_UPDATE_RULES = "quality:update_rules"
    QUALITY_DELETE_RULES = "quality:delete_rules"
    
    # Analytics permissions
    ANALYTICS_CREATE_REPORTS = "analytics:create_reports"
    ANALYTICS_READ_REPORTS = "analytics:read_reports"
    ANALYTICS_SHARE_REPORTS = "analytics:share_reports"
    
    # Governance permissions
    GOVERNANCE_CREATE_POLICIES = "governance:create_policies"
    GOVERNANCE_READ_POLICIES = "governance:read_policies"
    GOVERNANCE_UPDATE_POLICIES = "governance:update_policies"
    GOVERNANCE_ENFORCE_POLICIES = "governance:enforce_policies"
    
    # System permissions
    SYSTEM_ADMIN = "system:admin"
    SYSTEM_AUDIT = "system:audit"
    SYSTEM_MONITOR = "system:monitor"


# Request DTOs
class CreateUserRequest(BaseModel):
    """Request to create a new user"""
    email: EmailStr = Field(..., description="User email address")
    name: str = Field(..., min_length=2, max_length=100, description="Full name")
    password: str = Field(..., min_length=8, max_length=128, description="Password")
    role: UserRole = Field(..., description="User role")
    organization_id: UUID = Field(..., description="Organization ID")
    department: Optional[str] = Field(None, max_length=100, description="Department")
    job_title: Optional[str] = Field(None, max_length=100, description="Job title")
    phone: Optional[str] = Field(None, max_length=20, description="Phone number")
    
    @validator('password')
    def validate_password(cls, v):
        """Validate password strength"""
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        if not any(c.isupper() for c in v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not any(c.islower() for c in v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain at least one digit')
        return v


class UpdateUserRequest(BaseModel):
    """Request to update user information"""
    name: Optional[str] = Field(None, min_length=2, max_length=100)
    department: Optional[str] = Field(None, max_length=100)
    job_title: Optional[str] = Field(None, max_length=100)
    phone: Optional[str] = Field(None, max_length=20)
    status: Optional[UserStatus] = None
    
    class Config:
        use_enum_values = True


class ChangePasswordRequest(BaseModel):
    """Request to change user password"""
    current_password: str = Field(..., description="Current password")
    new_password: str = Field(..., min_length=8, max_length=128, description="New password")
    
    @validator('new_password')
    def validate_new_password(cls, v):
        """Validate new password strength"""
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        if not any(c.isupper() for c in v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not any(c.islower() for c in v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain at least one digit')
        return v


class LoginRequest(BaseModel):
    """Request to authenticate user"""
    email: EmailStr = Field(..., description="User email")
    password: str = Field(..., description="User password")
    remember_me: bool = Field(False, description="Remember login")


class RefreshTokenRequest(BaseModel):
    """Request to refresh access token"""
    refresh_token: str = Field(..., description="Refresh token")


class AssignRoleRequest(BaseModel):
    """Request to assign role to user"""
    user_id: UUID = Field(..., description="User ID")
    role: UserRole = Field(..., description="New role")
    organization_id: UUID = Field(..., description="Organization context")


class GrantPermissionRequest(BaseModel):
    """Request to grant specific permission"""
    user_id: UUID = Field(..., description="User ID")
    permission: Permission = Field(..., description="Permission to grant")
    resource_id: Optional[UUID] = Field(None, description="Specific resource ID")
    organization_id: UUID = Field(..., description="Organization context")


# Response DTOs
class UserResponse(BaseModel):
    """User information response"""
    id: UUID
    email: str
    name: str
    role: UserRole
    status: UserStatus
    organization_id: UUID
    organization_name: Optional[str] = None
    department: Optional[str] = None
    job_title: Optional[str] = None
    phone: Optional[str] = None
    last_login: Optional[datetime] = None
    failed_login_attempts: int = 0
    is_locked: bool = False
    two_factor_enabled: bool = False
    created_at: datetime
    updated_at: datetime
    
    class Config:
        use_enum_values = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class UserListResponse(BaseModel):
    """List of users response"""
    users: List[UserResponse]
    total: int
    limit: int
    offset: int
    has_more: bool


class LoginResponse(BaseModel):
    """Login response with tokens"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # seconds
    user: UserResponse


class TokenResponse(BaseModel):
    """Token refresh response"""
    access_token: str
    token_type: str = "bearer"
    expires_in: int


class UserPermissionsResponse(BaseModel):
    """User permissions response"""
    user_id: UUID
    role: UserRole
    permissions: List[Permission]
    organization_permissions: Dict[str, List[Permission]]  # org_id -> permissions
    
    class Config:
        use_enum_values = True


class UserSessionResponse(BaseModel):
    """User session information"""
    session_id: str
    user_id: UUID
    created_at: datetime
    last_activity: datetime
    ip_address: str
    user_agent: str
    is_active: bool
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class UserStatisticsResponse(BaseModel):
    """User statistics for organization"""
    organization_id: UUID
    total_users: int
    active_users: int
    inactive_users: int
    suspended_users: int
    users_by_role: Dict[str, int]
    recent_logins: int  # last 24h
    failed_login_attempts: int  # last 24h
    
    class Config:
        json_encoders = {
            UUID: lambda v: str(v)
        }


# Search and Filter DTOs
class UserSearchRequest(BaseModel):
    """Request to search users"""
    search_term: str = Field(..., min_length=2, description="Search term")
    organization_id: Optional[UUID] = None
    role: Optional[UserRole] = None
    status: Optional[UserStatus] = None
    department: Optional[str] = None
    limit: int = Field(100, ge=1, le=1000)
    offset: int = Field(0, ge=0)


class UserFilterRequest(BaseModel):
    """Request to filter users"""
    organization_id: Optional[UUID] = None
    role: Optional[UserRole] = None
    status: Optional[UserStatus] = None
    department: Optional[str] = None
    created_after: Optional[datetime] = None
    created_before: Optional[datetime] = None
    last_login_after: Optional[datetime] = None
    last_login_before: Optional[datetime] = None
    limit: int = Field(100, ge=1, le=1000)
    offset: int = Field(0, ge=0)


# Audit DTOs
class UserAuditLogResponse(BaseModel):
    """User audit log entry"""
    id: UUID
    user_id: UUID
    action: str
    resource_type: str
    resource_id: Optional[UUID] = None
    details: Dict[str, Any]
    ip_address: str
    user_agent: str
    timestamp: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class UserAuditLogListResponse(BaseModel):
    """List of user audit logs"""
    logs: List[UserAuditLogResponse]
    total: int
    limit: int
    offset: int


# Organization DTOs
class OrganizationResponse(BaseModel):
    """Organization information"""
    id: UUID
    name: str
    description: Optional[str] = None
    domain: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


# Role and Permission DTOs
class RolePermissionsResponse(BaseModel):
    """Role permissions mapping"""
    role: UserRole
    permissions: List[Permission]
    description: str
    
    class Config:
        use_enum_values = True


class PermissionResponse(BaseModel):
    """Permission details"""
    permission: Permission
    description: str
    resource_type: Optional[str] = None
    
    class Config:
        use_enum_values = True


# Validation DTOs
class EmailValidationRequest(BaseModel):
    """Request to validate email"""
    email: EmailStr


class EmailValidationResponse(BaseModel):
    """Email validation response"""
    email: str
    is_valid: bool
    is_available: bool
    suggestions: List[str] = []


# Two-Factor Authentication DTOs
class Enable2FARequest(BaseModel):
    """Request to enable 2FA"""
    password: str = Field(..., description="Current password for verification")


class Enable2FAResponse(BaseModel):
    """Response with 2FA setup information"""
    secret_key: str
    qr_code_url: str
    backup_codes: List[str]


class Verify2FARequest(BaseModel):
    """Request to verify 2FA code"""
    code: str = Field(..., min_length=6, max_length=6, description="6-digit code")


class Disable2FARequest(BaseModel):
    """Request to disable 2FA"""
    password: str = Field(..., description="Current password")
    code: str = Field(..., min_length=6, max_length=6, description="Current 2FA code")


# Password Reset DTOs
class PasswordResetRequest(BaseModel):
    """Request password reset"""
    email: EmailStr


class PasswordResetConfirmRequest(BaseModel):
    """Confirm password reset with token"""
    token: str = Field(..., description="Reset token")
    new_password: str = Field(..., min_length=8, max_length=128)
    
    @validator('new_password')
    def validate_new_password(cls, v):
        """Validate new password strength"""
        if len(v) < 8:
            raise ValueError('Password must be at least 8 characters long')
        if not any(c.isupper() for c in v):
            raise ValueError('Password must contain at least one uppercase letter')
        if not any(c.islower() for c in v):
            raise ValueError('Password must contain at least one lowercase letter')
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain at least one digit')
        return v


# Bulk Operations DTOs
class BulkUserCreateRequest(BaseModel):
    """Request to create multiple users"""
    users: List[CreateUserRequest] = Field(..., max_items=100)
    send_welcome_email: bool = Field(True, description="Send welcome emails")


class BulkUserUpdateRequest(BaseModel):
    """Request to update multiple users"""
    user_ids: List[UUID] = Field(..., max_items=100)
    updates: UpdateUserRequest


class BulkUserResponse(BaseModel):
    """Response for bulk operations"""
    successful: List[UUID]
    failed: List[Dict[str, Any]]  # {"user_id": UUID, "error": str}
    total_processed: int
    success_count: int
    failure_count: int

