# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
Identity Service - Microserviço de Gestão de Usuários
Versão: 4.0.1 - Corrigida com base na V3.2
Data: 27 de Janeiro de 2025
"""

import logging
from datetime import datetime
from typing import List, Optional
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Query, Path
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'config'))

try:
    from settings import get_settings
    settings = get_settings()
except ImportError:
    print("⚠️ Configurações centralizadas não encontradas, usando valores padrão")
    settings = None


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Identity Service",
    description="Microserviço para gestão de usuários e identidades - V4.0 Corrigido",
    version="4.0.1",
    contact={
        "name": " ",
        "email": "@example.com"
    }
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# PYDANTIC MODELS
# =====================================================

class UserBase(BaseModel):
    name: str = Field(..., description="Nome do usuário")
    email: str = Field(..., description="Email do usuário")
    role: str = Field("user", description="Papel do usuário")
    department: Optional[str] = Field(None, description="Departamento")

class UserCreate(UserBase):
    pass

class UserUpdate(UserBase):
    pass

class UserResponse(UserBase):
    id: str
    created_at: datetime
    updated_at: datetime
    is_active: bool

# =====================================================
# IN-MEMORY DATABASE (Simulação)
# =====================================================

users_db = {}
audit_logs = []

def log_audit(action: str, resource_id: str = None, details: str = None):
    """Log audit trail"""
    try:
        audit_logs.append({
            "id": str(uuid4()),
            "action": action,
            "resource_type": "users",
            "resource_id": resource_id,
            "details": details,
            "created_at": datetime.utcnow().isoformat()
        })
    except Exception as e:
        logger.error(f"Error logging audit: {e}")

def init_sample_data():
    """Initialize sample users"""
    sample_users = [
        {
            "id": str(uuid4()),
            "name": "Ana Silva",
            "email": "ana.silva@empresa.com",
            "role": "data_owner",
            "department": "Vendas",
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "Carlos Santos",
            "email": "carlos.santos@empresa.com",
            "role": "data_steward",
            "department": "TI",
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "Maria Oliveira",
            "email": "maria.oliveira@empresa.com",
            "role": "analyst",
            "department": "Marketing",
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
    ]
    
    for user in sample_users:
        users_db[user["id"]] = user
    
    logger.info(f"Initialized {len(sample_users)} sample users")

# =====================================================
# API ENDPOINTS
# =====================================================

@app.get("/", tags=["System"])
async def root():
    """Root endpoint with service information"""
    return {
        "service": "Identity Service",
        "version": "4.0.1",
        "status": "running",
        "description": "Microserviço para gestão de usuários e identidades - Corrigido",
        "corrections_applied": [
            "Dependências estabilizadas",
            "Error handling robusto",
            "Logs estruturados",
            "In-memory database funcional"
        ],
        "endpoints": {
            "health": "/health",
            "docs": "/docs",
            "users": "/api/v1/users"
        }
    }

@app.get("/health", tags=["System"])
async def health_check():
    """Health check endpoint"""
    try:
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "version": "4.0.1",
            "service": "identity-service",
            "port": 8002,
            "corrections_applied": True,
            "data_counts": {
                "users": len(users_db),
                "audit_logs": len(audit_logs)
            },
            "features": {
                "user_management": True,
                "role_management": True,
                "audit_trail": True
            }
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "status": "unhealthy",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

@app.get("/api/v1/users", response_model=List[UserResponse], tags=["Users"])
async def list_users(
    role: Optional[str] = Query(None, description="Filtrar por papel"),
    department: Optional[str] = Query(None, description="Filtrar por departamento"),
    is_active: Optional[bool] = Query(None, description="Filtrar por status ativo"),
    limit: int = Query(100, description="Limite de resultados")
):
    """Listar todos os usuários"""
    try:
        users = list(users_db.values())
        
        # Apply filters
        if role:
            users = [u for u in users if u["role"] == role]
        
        if department:
            users = [u for u in users if u["department"] == department]
            
        if is_active is not None:
            users = [u for u in users if u["is_active"] == is_active]
        
        # Apply limit
        users = users[:limit]
        
        # Convert datetime objects to ISO format
        for user in users:
            user["created_at"] = user["created_at"].isoformat()
            user["updated_at"] = user["updated_at"].isoformat()
        
        log_audit("list", details=f"Listed {len(users)} users")
        return users
        
    except Exception as e:
        logger.error(f"Error listing users: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing users: {str(e)}")

@app.get("/api/v1/users/{user_id}", response_model=UserResponse, tags=["Users"])
async def get_user(user_id: str = Path(..., description="ID do usuário")):
    """Buscar usuário específico por ID"""
    try:
        if user_id not in users_db:
            raise HTTPException(status_code=404, detail="User not found")
        
        user = users_db[user_id].copy()
        user["created_at"] = user["created_at"].isoformat()
        user["updated_at"] = user["updated_at"].isoformat()
        
        log_audit("get", resource_id=user_id)
        return user
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting user: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting user: {str(e)}")

@app.post("/api/v1/users", response_model=UserResponse, tags=["Users"])
async def create_user(user: UserCreate):
    """Criar novo usuário"""
    try:
        # Check if email already exists
        for existing_user in users_db.values():
            if existing_user["email"] == user.email:
                raise HTTPException(status_code=400, detail="Email already exists")
        
        user_id = str(uuid4())
        now = datetime.utcnow()
        
        new_user = {
            "id": user_id,
            "name": user.name,
            "email": user.email,
            "role": user.role,
            "department": user.department,
            "is_active": True,
            "created_at": now,
            "updated_at": now
        }
        
        users_db[user_id] = new_user
        
        log_audit("create", resource_id=user_id, details=f"Created user: {user.name}")
        
        # Convert datetime for response
        response_user = new_user.copy()
        response_user["created_at"] = response_user["created_at"].isoformat()
        response_user["updated_at"] = response_user["updated_at"].isoformat()
        
        return response_user
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating user: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating user: {str(e)}")

@app.put("/api/v1/users/{user_id}", response_model=UserResponse, tags=["Users"])
async def update_user(user_id: str, user: UserUpdate):
    """Atualizar usuário existente"""
    try:
        if user_id not in users_db:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Check if email already exists (excluding current user)
        for uid, existing_user in users_db.items():
            if uid != user_id and existing_user["email"] == user.email:
                raise HTTPException(status_code=400, detail="Email already exists")
        
        existing_user = users_db[user_id]
        
        # Update fields
        existing_user.update({
            "name": user.name,
            "email": user.email,
            "role": user.role,
            "department": user.department,
            "updated_at": datetime.utcnow()
        })
        
        log_audit("update", resource_id=user_id, details=f"Updated user: {user.name}")
        
        # Convert datetime for response
        response_user = existing_user.copy()
        response_user["created_at"] = response_user["created_at"].isoformat()
        response_user["updated_at"] = response_user["updated_at"].isoformat()
        
        return response_user
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating user: {e}")
        raise HTTPException(status_code=500, detail=f"Error updating user: {str(e)}")

@app.delete("/api/v1/users/{user_id}", tags=["Users"])
async def delete_user(user_id: str):
    """Deletar usuário (desativar)"""
    try:
        if user_id not in users_db:
            raise HTTPException(status_code=404, detail="User not found")
        
        user = users_db[user_id]
        user["is_active"] = False
        user["updated_at"] = datetime.utcnow()
        
        log_audit("delete", resource_id=user_id, details=f"Deactivated user: {user['name']}")
        
        return {"message": "User deactivated successfully", "id": user_id}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting user: {e}")
        raise HTTPException(status_code=500, detail=f"Error deleting user: {str(e)}")

@app.get("/api/v1/users/roles/available", tags=["Users"])
async def list_available_roles():
    """Listar papéis disponíveis no sistema"""
    try:
        roles = [
            {
                "role": "data_owner",
                "description": "Proprietário dos dados - responsável pela definição de políticas",
                "permissions": ["create_contracts", "approve_contracts", "manage_policies"]
            },
            {
                "role": "data_steward",
                "description": "Administrador de dados - responsável pela qualidade e governança",
                "permissions": ["manage_quality_rules", "monitor_compliance", "audit_data"]
            },
            {
                "role": "analyst",
                "description": "Analista de dados - usuário final com acesso aos dados",
                "permissions": ["view_data", "create_reports", "access_catalog"]
            },
            {
                "role": "admin",
                "description": "Administrador do sistema - acesso total",
                "permissions": ["manage_users", "system_config", "all_permissions"]
            }
        ]
        
        return {
            "available_roles": roles,
            "total_roles": len(roles)
        }
        
    except Exception as e:
        logger.error(f"Error listing roles: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing roles: {str(e)}")

@app.get("/api/v1/audit/logs", tags=["Audit"])
async def list_audit_logs(limit: int = Query(100, description="Limite de resultados")):
    """Listar logs de auditoria"""
    try:
        logs = audit_logs[-limit:] if limit < len(audit_logs) else audit_logs
        return logs
    except Exception as e:
        logger.error(f"Error listing audit logs: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing audit logs: {str(e)}")

# Initialize sample data on startup
@app.on_event("startup")
async def startup_event():
    """Initialize service on startup"""
    logger.info("Starting Identity Service V4.0.1 - Corrigido")
    init_sample_data()
    logger.info("Identity Service started successfully")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8002)

