"""
Identity Service - Microserviço de Identidade e Acesso
Sistema de Governança de Dados V5.0 - PostgreSQL

Responsável por:
- Gestão de usuários e roles
- Autenticação e autorização
- Controle de acesso granular
- Auditoria de acesso
- Gestão de sessões
"""

import logging
import uvicorn
from fastapi import FastAPI, HTTPException, Query, Path, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from uuid import uuid4, UUID
import hashlib
import jwt
import sys
import os

# Adicionar path do projeto
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from shared.database import get_db_session, get_db_health
from sqlalchemy import text

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Configurações JWT
JWT_SECRET = "governance_secret_key_2025"
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = 24

# =====================================================
# MODELOS PYDANTIC
# =====================================================

class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: str = Field(..., pattern=r"^[^@]+@[^@]+\.[^@]+$")
    password: str = Field(..., min_length=6)
    full_name: str = Field(..., min_length=1, max_length=100)
    department: Optional[str] = Field(None, max_length=100)
    role: str = Field("user", pattern="^(admin|data_steward|data_analyst|user|viewer)$")

class UserUpdate(BaseModel):
    email: Optional[str] = Field(None, pattern=r"^[^@]+@[^@]+\.[^@]+$")
    full_name: Optional[str] = Field(None, min_length=1, max_length=100)
    department: Optional[str] = Field(None, max_length=100)
    role: Optional[str] = Field(None, pattern="^(admin|data_steward|data_analyst|user|viewer)$")
    is_active: Optional[bool] = None

class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    full_name: str
    department: Optional[str]
    role: str
    is_active: bool
    last_login: Optional[datetime]
    created_at: datetime
    updated_at: datetime

class LoginRequest(BaseModel):
    username: str = Field(..., min_length=3)
    password: str = Field(..., min_length=6)

class LoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserResponse

class PasswordChangeRequest(BaseModel):
    current_password: str = Field(..., min_length=6)
    new_password: str = Field(..., min_length=6)

class RoleAssignmentRequest(BaseModel):
    user_id: str = Field(..., description="ID do usuário")
    role: str = Field(..., pattern="^(admin|data_steward|data_analyst|user|viewer)$")

class AccessControlRequest(BaseModel):
    user_id: str = Field(..., description="ID do usuário")
    resource_type: str = Field(..., description="Tipo de recurso")
    resource_id: str = Field(..., description="ID do recurso")
    action: str = Field(..., description="Ação solicitada")

class AccessControlResponse(BaseModel):
    allowed: bool
    reason: str
    user_role: str
    required_permissions: List[str]

# =====================================================
# POSTGRESQL DATABASE FUNCTIONS
# =====================================================

def hash_password(password: str) -> str:
    """Hash da senha usando SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password: str, hashed: str) -> bool:
    """Verifica senha"""
    return hash_password(password) == hashed

def create_access_token(user_data: Dict[str, Any]) -> str:
    """Cria token JWT"""
    payload = {
        "user_id": user_data["id"],
        "username": user_data["username"],
        "role": user_data["role"],
        "exp": datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)

def verify_token(token: str) -> Optional[Dict[str, Any]]:
    """Verifica token JWT"""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

def log_audit(action: str, user_id: str = None, details: str = None):
    """Log audit trail to PostgreSQL"""
    try:
        with get_db_session() as session:
            audit_sql = text("""
                INSERT INTO audit_events (event_type, resource_type, resource_id, action, details, created_at)
                VALUES (:event_type, :resource_type, :resource_id, :action, :details, CURRENT_TIMESTAMP)
            """)
            
            session.execute(audit_sql, {
                'event_type': 'identity_operation',
                'resource_type': 'users',
                'resource_id': user_id,
                'action': action,
                'details': details
            })
            session.commit()
            
    except Exception as e:
        logger.error(f"Error logging audit: {e}")

def init_sample_users():
    """Initialize sample users in PostgreSQL"""
    try:
        with get_db_session() as session:
            # Verificar se já existem usuários
            count_sql = text("SELECT COUNT(*) FROM users")
            result = session.execute(count_sql)
            count = result.fetchone()[0]
            
            if count > 0:
                logger.info(f"Users already exist in database: {count}")
                return
            
            sample_users = [
                {
                    "username": "admin",
                    "email": "admin@empresa.com",
                    "password_hash": hash_password("admin123"),
                    "full_name": "Administrador do Sistema",
                    "department": "TI",
                    "role": "admin",
                    "is_active": True
                },
                {
                    "username": "data_steward",
                    "email": "steward@empresa.com",
                    "password_hash": hash_password("steward123"),
                    "full_name": "Data Steward Principal",
                    "department": "Dados",
                    "role": "data_steward",
                    "is_active": True
                },
                {
                    "username": "analyst",
                    "email": "analyst@empresa.com",
                    "password_hash": hash_password("analyst123"),
                    "full_name": "Analista de Dados",
                    "department": "Analytics",
                    "role": "data_analyst",
                    "is_active": True
                },
                {
                    "username": "user1",
                    "email": "user1@empresa.com",
                    "password_hash": hash_password("user123"),
                    "full_name": "Usuário Padrão",
                    "department": "Vendas",
                    "role": "user",
                    "is_active": True
                },
                {
                    "username": "viewer",
                    "email": "viewer@empresa.com",
                    "password_hash": hash_password("viewer123"),
                    "full_name": "Visualizador",
                    "department": "Auditoria",
                    "role": "viewer",
                    "is_active": True
                }
            ]
            
            insert_sql = text("""
                INSERT INTO users (username, email, password_hash, full_name, department, role, is_active)
                VALUES (:username, :email, :password_hash, :full_name, :department, :role, :is_active)
            """)
            
            for user in sample_users:
                session.execute(insert_sql, user)
            
            session.commit()
            logger.info(f"Initialized {len(sample_users)} sample users in PostgreSQL")
            
    except Exception as e:
        logger.error(f"Error initializing sample users: {e}")

def get_user_from_db(user_id: str = None, username: str = None) -> Optional[Dict[str, Any]]:
    """Busca usuário no PostgreSQL"""
    try:
        with get_db_session() as session:
            if user_id:
                sql = text("""
                    SELECT id, username, email, password_hash, full_name, department, role, 
                           is_active, last_login, created_at, updated_at
                    FROM users WHERE id = :user_id
                """)
                params = {'user_id': user_id}
            elif username:
                sql = text("""
                    SELECT id, username, email, password_hash, full_name, department, role, 
                           is_active, last_login, created_at, updated_at
                    FROM users WHERE username = :username
                """)
                params = {'username': username}
            else:
                return None
            
            result = session.execute(sql, params).fetchone()
            
            if result:
                return {
                    'id': str(result.id),
                    'username': result.username,
                    'email': result.email,
                    'password_hash': result.password_hash,
                    'full_name': result.full_name,
                    'department': result.department,
                    'role': result.role,
                    'is_active': result.is_active,
                    'last_login': result.last_login,
                    'created_at': result.created_at,
                    'updated_at': result.updated_at
                }
            
            return None
            
    except Exception as e:
        logger.error(f"Error getting user: {e}")
        return None

def save_user_to_db(user_data: Dict[str, Any]) -> str:
    """Salva usuário no PostgreSQL"""
    try:
        with get_db_session() as session:
            user_id = str(uuid4())
            
            insert_sql = text("""
                INSERT INTO users (id, username, email, password_hash, full_name, department, role, is_active)
                VALUES (:id, :username, :email, :password_hash, :full_name, :department, :role, :is_active)
            """)
            
            session.execute(insert_sql, {
                'id': user_id,
                'username': user_data['username'],
                'email': user_data['email'],
                'password_hash': hash_password(user_data['password']),
                'full_name': user_data['full_name'],
                'department': user_data.get('department'),
                'role': user_data['role'],
                'is_active': True
            })
            
            session.commit()
            
            log_audit("CREATE", user_id, f"User created: {user_data['username']}")
            
            return user_id
            
    except Exception as e:
        logger.error(f"Error saving user: {e}")
        raise HTTPException(status_code=500, detail="Database error")

def update_user_in_db(user_id: str, update_data: Dict[str, Any]) -> bool:
    """Atualiza usuário no PostgreSQL"""
    try:
        with get_db_session() as session:
            # Construir SQL dinâmico
            set_clauses = []
            params = {'user_id': user_id}
            
            for field, value in update_data.items():
                if value is not None:
                    set_clauses.append(f"{field} = :{field}")
                    params[field] = value
            
            if not set_clauses:
                return True
            
            set_clauses.append("updated_at = CURRENT_TIMESTAMP")
            
            update_sql = text(f"""
                UPDATE users 
                SET {', '.join(set_clauses)}
                WHERE id = :user_id
            """)
            
            result = session.execute(update_sql, params)
            session.commit()
            
            if result.rowcount > 0:
                log_audit("UPDATE", user_id, "User updated")
                return True
            
            return False
            
    except Exception as e:
        logger.error(f"Error updating user: {e}")
        raise HTTPException(status_code=500, detail="Database error")

def update_last_login(user_id: str):
    """Atualiza último login"""
    try:
        with get_db_session() as session:
            update_sql = text("""
                UPDATE users 
                SET last_login = CURRENT_TIMESTAMP
                WHERE id = :user_id
            """)
            
            session.execute(update_sql, {'user_id': user_id})
            session.commit()
            
    except Exception as e:
        logger.error(f"Error updating last login: {e}")

def list_users_from_db(role: Optional[str] = None, active_only: bool = True) -> List[Dict[str, Any]]:
    """Lista usuários do PostgreSQL"""
    try:
        with get_db_session() as session:
            where_clauses = []
            params = {}
            
            if role:
                where_clauses.append("role = :role")
                params['role'] = role
            
            if active_only:
                where_clauses.append("is_active = true")
            
            where_clause = ""
            if where_clauses:
                where_clause = "WHERE " + " AND ".join(where_clauses)
            
            sql = text(f"""
                SELECT id, username, email, full_name, department, role, 
                       is_active, last_login, created_at, updated_at
                FROM users {where_clause}
                ORDER BY created_at DESC
            """)
            
            results = session.execute(sql, params).fetchall()
            
            users = []
            for result in results:
                users.append({
                    'id': str(result.id),
                    'username': result.username,
                    'email': result.email,
                    'full_name': result.full_name,
                    'department': result.department,
                    'role': result.role,
                    'is_active': result.is_active,
                    'last_login': result.last_login,
                    'created_at': result.created_at,
                    'updated_at': result.updated_at
                })
            
            return users
            
    except Exception as e:
        logger.error(f"Error listing users: {e}")
        return []

# =====================================================
# BUSINESS LOGIC FUNCTIONS
# =====================================================

def check_access_control(user_id: str, resource_type: str, resource_id: str, action: str) -> AccessControlResponse:
    """Verifica controle de acesso"""
    try:
        user = get_user_from_db(user_id=user_id)
        if not user or not user['is_active']:
            return AccessControlResponse(
                allowed=False,
                reason="User not found or inactive",
                user_role="",
                required_permissions=[]
            )
        
        user_role = user['role']
        
        # Definir permissões por role
        role_permissions = {
            'admin': ['*'],  # Acesso total
            'data_steward': ['contracts:read', 'contracts:write', 'quality:read', 'quality:write', 'governance:read', 'governance:write'],
            'data_analyst': ['contracts:read', 'quality:read', 'analytics:read', 'analytics:write', 'catalog:read'],
            'user': ['contracts:read', 'catalog:read', 'analytics:read'],
            'viewer': ['contracts:read', 'catalog:read']
        }
        
        user_permissions = role_permissions.get(user_role, [])
        required_permission = f"{resource_type}:{action}"
        
        # Verificar permissão
        allowed = False
        if '*' in user_permissions:  # Admin tem acesso total
            allowed = True
        elif required_permission in user_permissions:
            allowed = True
        elif f"{resource_type}:*" in user_permissions:
            allowed = True
        
        return AccessControlResponse(
            allowed=allowed,
            reason="Access granted" if allowed else f"Insufficient permissions for {required_permission}",
            user_role=user_role,
            required_permissions=[required_permission]
        )
        
    except Exception as e:
        logger.error(f"Error checking access control: {e}")
        return AccessControlResponse(
            allowed=False,
            reason="Access control check failed",
            user_role="",
            required_permissions=[]
        )

# =====================================================
# SECURITY DEPENDENCIES
# =====================================================

security = HTTPBearer()

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> Dict[str, Any]:
    """Dependency para obter usuário atual"""
    try:
        token = credentials.credentials
        payload = verify_token(token)
        
        if not payload:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired token"
            )
        
        user = get_user_from_db(user_id=payload['user_id'])
        if not user or not user['is_active']:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found or inactive"
            )
        
        return user
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting current user: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication failed"
        )

def require_role(required_role: str):
    """Dependency para verificar role específica"""
    def role_checker(current_user: Dict[str, Any] = Depends(get_current_user)):
        if current_user['role'] != required_role and current_user['role'] != 'admin':
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role '{required_role}' required"
            )
        return current_user
    return role_checker

# =====================================================
# CONFIGURAÇÃO DA APLICAÇÃO
# =====================================================

app = FastAPI(
    title="Identity Service",
    description="Microserviço de identidade e controle de acesso - V5.0 com PostgreSQL",
    version="5.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# ENDPOINTS
# =====================================================

@app.get("/")
async def root():
    """Endpoint raiz"""
    return {
        "service": "Identity Service",
        "version": "5.0.0",
        "description": "Microserviço de identidade e acesso com PostgreSQL",
        "status": "running",
        "database": "PostgreSQL",
        "features": [
            "Gestão de usuários",
            "Autenticação JWT",
            "Controle de acesso",
            "Auditoria completa",
            "Roles granulares"
        ]
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        db_health = get_db_health()
        
        if db_health.get("status") == "healthy":
            return {
                "status": "healthy",
                "service": "Identity Service",
                "version": "5.0.0",
                "database": db_health,
                "timestamp": datetime.utcnow().isoformat()
            }
        else:
            return JSONResponse(
                status_code=503,
                content={
                    "status": "unhealthy",
                    "service": "Identity Service",
                    "database": db_health
                }
            )
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "error": str(e)
            }
        )

@app.post("/api/v1/auth/login", response_model=LoginResponse)
async def login(request: LoginRequest):
    """Autenticação de usuário"""
    try:
        user = get_user_from_db(username=request.username)
        
        if not user or not user['is_active']:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials"
            )
        
        if not verify_password(request.password, user['password_hash']):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid credentials"
            )
        
        # Atualizar último login
        update_last_login(user['id'])
        
        # Criar token
        access_token = create_access_token(user)
        
        # Remover password_hash da resposta
        user_response = {k: v for k, v in user.items() if k != 'password_hash'}
        
        log_audit("LOGIN", user['id'], f"User logged in: {user['username']}")
        
        return LoginResponse(
            access_token=access_token,
            expires_in=JWT_EXPIRATION_HOURS * 3600,
            user=UserResponse(**user_response)
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error during login: {e}")
        raise HTTPException(status_code=500, detail="Login failed")

@app.post("/api/v1/users", response_model=UserResponse)
async def create_user(
    user: UserCreate,
    current_user: Dict[str, Any] = Depends(require_role("admin"))
):
    """Cria um novo usuário (apenas admin)"""
    try:
        # Verificar se username já existe
        existing_user = get_user_from_db(username=user.username)
        if existing_user:
            raise HTTPException(
                status_code=400,
                detail="Username already exists"
            )
        
        user_data = user.dict()
        user_id = save_user_to_db(user_data)
        
        # Buscar usuário criado
        created_user = get_user_from_db(user_id=user_id)
        if not created_user:
            raise HTTPException(status_code=500, detail="Failed to create user")
        
        # Remover password_hash da resposta
        user_response = {k: v for k, v in created_user.items() if k != 'password_hash'}
        
        return UserResponse(**user_response)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/v1/users", response_model=List[UserResponse])
async def list_users(
    role: Optional[str] = Query(None, description="Filtrar por role"),
    active_only: bool = Query(True, description="Apenas usuários ativos"),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Lista usuários"""
    try:
        users = list_users_from_db(role, active_only)
        
        # Remover password_hash de todos os usuários
        users_response = []
        for user in users:
            user_data = {k: v for k, v in user.items() if k != 'password_hash'}
            users_response.append(UserResponse(**user_data))
        
        log_audit("LIST", current_user['id'], f"Listed {len(users)} users")
        return users_response
        
    except Exception as e:
        logger.error(f"Error listing users: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/v1/users/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: str = Path(..., description="ID do usuário"),
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Busca um usuário específico"""
    try:
        user = get_user_from_db(user_id=user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Verificar se pode acessar (próprio usuário ou admin)
        if user_id != current_user['id'] and current_user['role'] != 'admin':
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Remover password_hash da resposta
        user_response = {k: v for k, v in user.items() if k != 'password_hash'}
        
        log_audit("READ", user_id, "User accessed")
        return UserResponse(**user_response)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.put("/api/v1/users/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: str = Path(..., description="ID do usuário"),
    user_update: UserUpdate = None,
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Atualiza um usuário"""
    try:
        # Verificar se usuário existe
        existing_user = get_user_from_db(user_id=user_id)
        if not existing_user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Verificar permissões (próprio usuário ou admin)
        if user_id != current_user['id'] and current_user['role'] != 'admin':
            raise HTTPException(status_code=403, detail="Access denied")
        
        # Se não é admin, não pode alterar role
        if current_user['role'] != 'admin' and user_update.role:
            raise HTTPException(status_code=403, detail="Cannot change role")
        
        # Atualizar apenas campos fornecidos
        update_data = {k: v for k, v in user_update.dict().items() if v is not None}
        
        if update_data:
            success = update_user_in_db(user_id, update_data)
            if not success:
                raise HTTPException(status_code=500, detail="Failed to update user")
        
        # Retornar usuário atualizado
        updated_user = get_user_from_db(user_id=user_id)
        user_response = {k: v for k, v in updated_user.items() if k != 'password_hash'}
        
        return UserResponse(**user_response)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/v1/users/{user_id}/change-password")
async def change_password(
    user_id: str = Path(..., description="ID do usuário"),
    request: PasswordChangeRequest = None,
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Altera senha do usuário"""
    try:
        # Verificar se pode alterar senha (próprio usuário ou admin)
        if user_id != current_user['id'] and current_user['role'] != 'admin':
            raise HTTPException(status_code=403, detail="Access denied")
        
        user = get_user_from_db(user_id=user_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        # Se não é admin, verificar senha atual
        if current_user['role'] != 'admin':
            if not verify_password(request.current_password, user['password_hash']):
                raise HTTPException(status_code=400, detail="Current password is incorrect")
        
        # Atualizar senha
        new_password_hash = hash_password(request.new_password)
        success = update_user_in_db(user_id, {'password_hash': new_password_hash})
        
        if not success:
            raise HTTPException(status_code=500, detail="Failed to change password")
        
        log_audit("PASSWORD_CHANGE", user_id, "Password changed")
        
        return {"message": "Password changed successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error changing password: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/v1/access/check", response_model=AccessControlResponse)
async def check_access(
    request: AccessControlRequest,
    current_user: Dict[str, Any] = Depends(get_current_user)
):
    """Verifica controle de acesso"""
    try:
        result = check_access_control(
            request.user_id,
            request.resource_type,
            request.resource_id,
            request.action
        )
        
        log_audit("ACCESS_CHECK", request.user_id, 
                 f"Access check: {request.resource_type}:{request.action} - {result.allowed}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error checking access: {e}")
        raise HTTPException(status_code=500, detail="Access check failed")

@app.get("/api/v1/users/me", response_model=UserResponse)
async def get_current_user_info(current_user: Dict[str, Any] = Depends(get_current_user)):
    """Obtém informações do usuário atual"""
    try:
        user_response = {k: v for k, v in current_user.items() if k != 'password_hash'}
        return UserResponse(**user_response)
    except Exception as e:
        logger.error(f"Error getting current user info: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

# =====================================================
# EVENTOS DE STARTUP/SHUTDOWN
# =====================================================

@app.on_event("startup")
async def startup_event():
    """Inicialização da aplicação"""
    logger.info("=== Identity Service Starting ===")
    logger.info("Version: 5.0.0 - PostgreSQL")
    
    try:
        # Verificar conexão com banco
        db_health = get_db_health()
        if db_health.get("status") == "healthy":
            logger.info("✅ PostgreSQL connection: OK")
            
            # Inicializar usuários de exemplo
            init_sample_users()
            
        else:
            logger.error("❌ PostgreSQL connection: FAILED")
            
    except Exception as e:
        logger.error(f"❌ Startup error: {e}")

@app.on_event("shutdown")
async def shutdown_event():
    """Encerramento da aplicação"""
    logger.info("=== Identity Service Shutting Down ===")

# =====================================================
# EXECUÇÃO PRINCIPAL
# =====================================================

if __name__ == "__main__":
    logger.info("Starting Identity Service with PostgreSQL...")
    
    try:
        uvicorn.run(
            "main_postgresql:app",
            host="0.0.0.0",
            port=8006,
            log_level="info",
            reload=False
        )
    except Exception as e:
        logger.error(f"Failed to start server: {e}")
        sys.exit(1)

