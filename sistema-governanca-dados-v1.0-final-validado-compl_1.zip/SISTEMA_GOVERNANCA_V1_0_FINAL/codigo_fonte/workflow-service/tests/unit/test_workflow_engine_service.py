# Autor: carlos.morais@f1rst.com.br
"""
Testes Unitários para Workflow Engine Service
"""

import pytest
import asyncio
from datetime import datetime, timedelta
from uuid import UUID, uuid4
from unittest.mock import Mock, AsyncMock, patch
from typing import List, Dict, Any

from src.domain.entities.workflow import Workflow, WorkflowStatus
from src.domain.value_objects.workflow_node import WorkflowNode, NodeType
from src.domain.value_objects.workflow_transition import WorkflowTransition, TransitionCondition
from src.domain.services.workflow_engine_service import (
    WorkflowEngineService, ExecutionStatus, TaskType, GatewayType, EventType,
    WorkflowInstance, WorkflowToken, TaskExecution
)


class TestWorkflowEngineService:
    """Testes para WorkflowEngineService"""
    
    @pytest.fixture
    def workflow_engine(self):
        """Instância do workflow engine"""
        return WorkflowEngineService()
    
    @pytest.fixture
    def simple_workflow(self):
        """Workflow simples para testes"""
        nodes = [
            WorkflowNode(
                id="start_1",
                name="Start Event",
                node_type=NodeType.START_EVENT,
                configuration={"event_type": "start"}
            ),
            WorkflowNode(
                id="task_1",
                name="User Task",
                node_type=NodeType.USER_TASK,
                configuration={
                    "task_type": "user_task",
                    "assigned_to": "user123",
                    "priority": 5
                }
            ),
            WorkflowNode(
                id="end_1",
                name="End Event",
                node_type=NodeType.END_EVENT,
                configuration={"event_type": "end"}
            )
        ]
        
        transitions = [
            WorkflowTransition(
                id="trans_1",
                from_node_id="start_1",
                to_node_id="task_1"
            ),
            WorkflowTransition(
                id="trans_2",
                from_node_id="task_1",
                to_node_id="end_1"
            )
        ]
        
        return Workflow(
            id=uuid4(),
            name="Simple Workflow",
            description="Workflow simples para testes",
            version="1.0.0",
            nodes=nodes,
            transitions=transitions,
            status=WorkflowStatus.ACTIVE,
            created_by="admin",
            created_at=datetime.utcnow()
        )
    
    @pytest.fixture
    def parallel_workflow(self):
        """Workflow com gateway paralelo para testes"""
        nodes = [
            WorkflowNode(
                id="start_1",
                name="Start Event",
                node_type=NodeType.START_EVENT,
                configuration={"event_type": "start"}
            ),
            WorkflowNode(
                id="parallel_fork",
                name="Parallel Gateway",
                node_type=NodeType.PARALLEL_GATEWAY,
                configuration={"gateway_type": "parallel"}
            ),
            WorkflowNode(
                id="task_1",
                name="Task 1",
                node_type=NodeType.SERVICE_TASK,
                configuration={
                    "task_type": "service_task",
                    "service_name": "service_1"
                }
            ),
            WorkflowNode(
                id="task_2",
                name="Task 2",
                node_type=NodeType.SERVICE_TASK,
                configuration={
                    "task_type": "service_task",
                    "service_name": "service_2"
                }
            ),
            WorkflowNode(
                id="parallel_join",
                name="Parallel Join",
                node_type=NodeType.PARALLEL_GATEWAY,
                configuration={"gateway_type": "parallel"}
            ),
            WorkflowNode(
                id="end_1",
                name="End Event",
                node_type=NodeType.END_EVENT,
                configuration={"event_type": "end"}
            )
        ]
        
        transitions = [
            WorkflowTransition(id="trans_1", from_node_id="start_1", to_node_id="parallel_fork"),
            WorkflowTransition(id="trans_2", from_node_id="parallel_fork", to_node_id="task_1"),
            WorkflowTransition(id="trans_3", from_node_id="parallel_fork", to_node_id="task_2"),
            WorkflowTransition(id="trans_4", from_node_id="task_1", to_node_id="parallel_join"),
            WorkflowTransition(id="trans_5", from_node_id="task_2", to_node_id="parallel_join"),
            WorkflowTransition(id="trans_6", from_node_id="parallel_join", to_node_id="end_1")
        ]
        
        return Workflow(
            id=uuid4(),
            name="Parallel Workflow",
            description="Workflow com execução paralela",
            version="1.0.0",
            nodes=nodes,
            transitions=transitions,
            status=WorkflowStatus.ACTIVE,
            created_by="admin",
            created_at=datetime.utcnow()
        )
    
    @pytest.fixture
    def conditional_workflow(self):
        """Workflow com gateway exclusivo e condições"""
        nodes = [
            WorkflowNode(
                id="start_1",
                name="Start Event",
                node_type=NodeType.START_EVENT,
                configuration={"event_type": "start"}
            ),
            WorkflowNode(
                id="exclusive_gateway",
                name="Exclusive Gateway",
                node_type=NodeType.EXCLUSIVE_GATEWAY,
                configuration={"gateway_type": "exclusive"}
            ),
            WorkflowNode(
                id="task_approved",
                name="Approved Task",
                node_type=NodeType.USER_TASK,
                configuration={"task_type": "user_task"}
            ),
            WorkflowNode(
                id="task_rejected",
                name="Rejected Task",
                node_type=NodeType.USER_TASK,
                configuration={"task_type": "user_task"}
            ),
            WorkflowNode(
                id="end_1",
                name="End Event",
                node_type=NodeType.END_EVENT,
                configuration={"event_type": "end"}
            )
        ]
        
        transitions = [
            WorkflowTransition(
                id="trans_1",
                from_node_id="start_1",
                to_node_id="exclusive_gateway"
            ),
            WorkflowTransition(
                id="trans_approved",
                from_node_id="exclusive_gateway",
                to_node_id="task_approved",
                condition=TransitionCondition(
                    condition_type="simple",
                    field="status",
                    operator="equals",
                    value="approved"
                )
            ),
            WorkflowTransition(
                id="trans_rejected",
                from_node_id="exclusive_gateway",
                to_node_id="task_rejected",
                condition=TransitionCondition(
                    condition_type="simple",
                    field="status",
                    operator="equals",
                    value="rejected"
                ),
                is_default=True
            ),
            WorkflowTransition(
                id="trans_end_approved",
                from_node_id="task_approved",
                to_node_id="end_1"
            ),
            WorkflowTransition(
                id="trans_end_rejected",
                from_node_id="task_rejected",
                to_node_id="end_1"
            )
        ]
        
        return Workflow(
            id=uuid4(),
            name="Conditional Workflow",
            description="Workflow com condições",
            version="1.0.0",
            nodes=nodes,
            transitions=transitions,
            status=WorkflowStatus.ACTIVE,
            created_by="admin",
            created_at=datetime.utcnow()
        )
    
    @pytest.mark.asyncio
    async def test_start_workflow_simple(self, workflow_engine, simple_workflow):
        """Testa início de workflow simples"""
        # Act
        instance = await workflow_engine.start_workflow(
            workflow=simple_workflow,
            variables={"test_var": "test_value"},
            started_by="user123"
        )
        
        # Assert
        assert isinstance(instance, WorkflowInstance)
        assert instance.workflow_id == simple_workflow.id
        assert instance.status == ExecutionStatus.RUNNING
        assert instance.started_by == "user123"
        assert instance.variables["test_var"] == "test_value"
        assert len(instance.tokens) == 1
        assert instance.tokens[0].workflow_instance_id == instance.id
        assert instance.started_at is not None
    
    @pytest.mark.asyncio
    async def test_start_workflow_no_start_event(self, workflow_engine):
        """Testa início de workflow sem evento de início"""
        # Arrange
        workflow_without_start = Workflow(
            id=uuid4(),
            name="Invalid Workflow",
            nodes=[
                WorkflowNode(
                    id="task_1",
                    name="Task",
                    node_type=NodeType.USER_TASK
                )
            ],
            transitions=[],
            status=WorkflowStatus.ACTIVE
        )
        
        # Act & Assert
        with pytest.raises(ValueError, match="Workflow deve ter pelo menos um evento de início"):
            await workflow_engine.start_workflow(workflow_without_start)
    
    @pytest.mark.asyncio
    async def test_execute_user_task(self, workflow_engine, simple_workflow):
        """Testa execução de tarefa de usuário"""
        # Arrange
        instance = await workflow_engine.start_workflow(simple_workflow)
        
        # Verificar se tarefa de usuário foi criada
        assert len(instance.current_tasks) == 1
        assert instance.current_tasks[0] == "task_1"
        
        # Verificar se token está aguardando
        user_task_token = None
        for token in instance.tokens:
            if token.current_node_id == "task_1":
                user_task_token = token
                break
        
        assert user_task_token is not None
        assert user_task_token.status == ExecutionStatus.WAITING
    
    @pytest.mark.asyncio
    async def test_complete_user_task(self, workflow_engine, simple_workflow):
        """Testa conclusão de tarefa de usuário"""
        # Arrange
        instance = await workflow_engine.start_workflow(simple_workflow)
        
        # Act
        result = await workflow_engine.complete_user_task(
            instance_id=instance.id,
            node_id="task_1",
            user_id="user123",
            result={"task_result": "completed"}
        )
        
        # Assert
        assert result is True
        
        # Verificar se tarefa foi removida das tarefas atuais
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        assert "task_1" not in updated_instance.current_tasks
        assert "task_1" in updated_instance.completed_tasks
        
        # Verificar se workflow foi completado (chegou ao end event)
        assert updated_instance.status == ExecutionStatus.COMPLETED
        assert updated_instance.completed_at is not None
    
    @pytest.mark.asyncio
    async def test_execute_service_task(self, workflow_engine):
        """Testa execução de tarefa de serviço"""
        # Arrange
        service_workflow = Workflow(
            id=uuid4(),
            name="Service Workflow",
            nodes=[
                WorkflowNode(
                    id="start_1",
                    name="Start",
                    node_type=NodeType.START_EVENT
                ),
                WorkflowNode(
                    id="service_task",
                    name="Service Task",
                    node_type=NodeType.SERVICE_TASK,
                    configuration={
                        "task_type": "service_task",
                        "service_name": "test_service",
                        "method": "process_data"
                    }
                ),
                WorkflowNode(
                    id="end_1",
                    name="End",
                    node_type=NodeType.END_EVENT
                )
            ],
            transitions=[
                WorkflowTransition(id="t1", from_node_id="start_1", to_node_id="service_task"),
                WorkflowTransition(id="t2", from_node_id="service_task", to_node_id="end_1")
            ],
            status=WorkflowStatus.ACTIVE
        )
        
        # Act
        instance = await workflow_engine.start_workflow(service_workflow)
        
        # Aguardar execução assíncrona
        await asyncio.sleep(0.2)
        
        # Assert
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        assert updated_instance.status == ExecutionStatus.COMPLETED
        
        # Verificar se dados do serviço foram adicionados ao token
        completed_token = updated_instance.tokens[0]
        assert "processed" in completed_token.data
    
    @pytest.mark.asyncio
    async def test_execute_parallel_gateway(self, workflow_engine, parallel_workflow):
        """Testa execução de gateway paralelo"""
        # Act
        instance = await workflow_engine.start_workflow(parallel_workflow)
        
        # Aguardar execução assíncrona
        await asyncio.sleep(0.3)
        
        # Assert
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        
        # Verificar se múltiplos tokens foram criados para execução paralela
        assert len(updated_instance.tokens) > 1
        
        # Verificar se workflow foi completado
        assert updated_instance.status == ExecutionStatus.COMPLETED
    
    @pytest.mark.asyncio
    async def test_execute_exclusive_gateway_with_condition(self, workflow_engine, conditional_workflow):
        """Testa execução de gateway exclusivo com condição"""
        # Arrange - Dados que atendem à condição "approved"
        variables = {"status": "approved"}
        
        # Act
        instance = await workflow_engine.start_workflow(
            workflow=conditional_workflow,
            variables=variables
        )
        
        # Aguardar execução
        await asyncio.sleep(0.2)
        
        # Assert
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        
        # Verificar se seguiu o caminho correto (task_approved)
        assert "task_approved" in updated_instance.current_tasks
        assert "task_rejected" not in updated_instance.current_tasks
    
    @pytest.mark.asyncio
    async def test_execute_exclusive_gateway_default_condition(self, workflow_engine, conditional_workflow):
        """Testa execução de gateway exclusivo com condição padrão"""
        # Arrange - Dados que não atendem à condição específica
        variables = {"status": "pending"}
        
        # Act
        instance = await workflow_engine.start_workflow(
            workflow=conditional_workflow,
            variables=variables
        )
        
        # Aguardar execução
        await asyncio.sleep(0.2)
        
        # Assert
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        
        # Verificar se seguiu o caminho padrão (task_rejected)
        assert "task_rejected" in updated_instance.current_tasks
        assert "task_approved" not in updated_instance.current_tasks
    
    @pytest.mark.asyncio
    async def test_execute_script_task(self, workflow_engine):
        """Testa execução de tarefa de script"""
        # Arrange
        script_workflow = Workflow(
            id=uuid4(),
            name="Script Workflow",
            nodes=[
                WorkflowNode(id="start_1", name="Start", node_type=NodeType.START_EVENT),
                WorkflowNode(
                    id="script_task",
                    name="Script Task",
                    node_type=NodeType.SCRIPT_TASK,
                    configuration={
                        "task_type": "script_task",
                        "script": "result = data['input'] * 2",
                        "script_type": "python"
                    }
                ),
                WorkflowNode(id="end_1", name="End", node_type=NodeType.END_EVENT)
            ],
            transitions=[
                WorkflowTransition(id="t1", from_node_id="start_1", to_node_id="script_task"),
                WorkflowTransition(id="t2", from_node_id="script_task", to_node_id="end_1")
            ],
            status=WorkflowStatus.ACTIVE
        )
        
        # Act
        instance = await workflow_engine.start_workflow(
            workflow=script_workflow,
            variables={"input": 5}
        )
        
        # Aguardar execução
        await asyncio.sleep(0.2)
        
        # Assert
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        assert updated_instance.status == ExecutionStatus.COMPLETED
        
        # Verificar se script foi executado
        completed_token = updated_instance.tokens[0]
        assert "script_executed" in completed_token.data
    
    @pytest.mark.asyncio
    async def test_execute_timer_event(self, workflow_engine):
        """Testa execução de evento de timer"""
        # Arrange
        timer_workflow = Workflow(
            id=uuid4(),
            name="Timer Workflow",
            nodes=[
                WorkflowNode(id="start_1", name="Start", node_type=NodeType.START_EVENT),
                WorkflowNode(
                    id="timer_event",
                    name="Timer Event",
                    node_type=NodeType.INTERMEDIATE_EVENT,
                    configuration={
                        "event_type": "timer",
                        "duration_seconds": 1
                    }
                ),
                WorkflowNode(id="end_1", name="End", node_type=NodeType.END_EVENT)
            ],
            transitions=[
                WorkflowTransition(id="t1", from_node_id="start_1", to_node_id="timer_event"),
                WorkflowTransition(id="t2", from_node_id="timer_event", to_node_id="end_1")
            ],
            status=WorkflowStatus.ACTIVE
        )
        
        # Act
        start_time = datetime.utcnow()
        instance = await workflow_engine.start_workflow(timer_workflow)
        
        # Aguardar timer + execução
        await asyncio.sleep(1.5)
        
        # Assert
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        assert updated_instance.status == ExecutionStatus.COMPLETED
        
        # Verificar se timer foi respeitado
        execution_time = (updated_instance.completed_at - start_time).total_seconds()
        assert execution_time >= 1.0  # Pelo menos 1 segundo devido ao timer
    
    @pytest.mark.asyncio
    async def test_cancel_workflow(self, workflow_engine, simple_workflow):
        """Testa cancelamento de workflow"""
        # Arrange
        instance = await workflow_engine.start_workflow(simple_workflow)
        
        # Act
        result = await workflow_engine.cancel_workflow(instance.id)
        
        # Assert
        assert result is True
        
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        assert updated_instance.status == ExecutionStatus.CANCELLED
        assert updated_instance.completed_at is not None
        
        # Verificar se todos os tokens foram cancelados
        for token in updated_instance.tokens:
            assert token.status == ExecutionStatus.CANCELLED
    
    @pytest.mark.asyncio
    async def test_suspend_and_resume_workflow(self, workflow_engine, simple_workflow):
        """Testa suspensão e retomada de workflow"""
        # Arrange
        instance = await workflow_engine.start_workflow(simple_workflow)
        
        # Act - Suspender
        suspend_result = await workflow_engine.suspend_workflow(instance.id)
        assert suspend_result is True
        
        suspended_instance = workflow_engine.get_workflow_instance(instance.id)
        assert suspended_instance.status == ExecutionStatus.SUSPENDED
        
        # Act - Resumir
        resume_result = await workflow_engine.resume_workflow(instance.id)
        assert resume_result is True
        
        # Assert
        resumed_instance = workflow_engine.get_workflow_instance(instance.id)
        assert resumed_instance.status == ExecutionStatus.RUNNING
    
    @pytest.mark.asyncio
    async def test_get_user_tasks(self, workflow_engine, simple_workflow):
        """Testa obtenção de tarefas de usuário"""
        # Arrange
        instance = await workflow_engine.start_workflow(simple_workflow)
        
        # Act
        user_tasks = workflow_engine.get_user_tasks("user123")
        
        # Assert
        assert len(user_tasks) == 1
        assert user_tasks[0]["instance_id"] == str(instance.id)
        assert user_tasks[0]["node_id"] == "task_1"
        assert user_tasks[0]["task_name"] == "User Task"
        assert user_tasks[0]["workflow_name"] == "Simple Workflow"
        assert user_tasks[0]["priority"] == 5
    
    @pytest.mark.asyncio
    async def test_send_message_to_workflow(self, workflow_engine):
        """Testa envio de mensagem para workflow"""
        # Arrange
        message_workflow = Workflow(
            id=uuid4(),
            name="Message Workflow",
            nodes=[
                WorkflowNode(id="start_1", name="Start", node_type=NodeType.START_EVENT),
                WorkflowNode(
                    id="message_event",
                    name="Message Event",
                    node_type=NodeType.INTERMEDIATE_EVENT,
                    configuration={
                        "event_type": "message",
                        "message_name": "test_message"
                    }
                ),
                WorkflowNode(id="end_1", name="End", node_type=NodeType.END_EVENT)
            ],
            transitions=[
                WorkflowTransition(id="t1", from_node_id="start_1", to_node_id="message_event"),
                WorkflowTransition(id="t2", from_node_id="message_event", to_node_id="end_1")
            ],
            status=WorkflowStatus.ACTIVE
        )
        
        instance = await workflow_engine.start_workflow(message_workflow)
        
        # Aguardar até chegar no evento de mensagem
        await asyncio.sleep(0.1)
        
        # Act
        await workflow_engine.send_message("test_message", {"data": "test_data"})
        
        # Aguardar processamento da mensagem
        await asyncio.sleep(0.1)
        
        # Assert
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        assert updated_instance.status == ExecutionStatus.COMPLETED
        
        # Verificar se dados da mensagem foram adicionados
        completed_token = updated_instance.tokens[0]
        assert "data" in completed_token.data
        assert completed_token.data["data"] == "test_data"
    
    @pytest.mark.asyncio
    async def test_send_signal_to_workflow(self, workflow_engine):
        """Testa envio de sinal para workflow"""
        # Arrange
        signal_workflow = Workflow(
            id=uuid4(),
            name="Signal Workflow",
            nodes=[
                WorkflowNode(id="start_1", name="Start", node_type=NodeType.START_EVENT),
                WorkflowNode(
                    id="signal_event",
                    name="Signal Event",
                    node_type=NodeType.INTERMEDIATE_EVENT,
                    configuration={
                        "event_type": "signal",
                        "signal_name": "test_signal"
                    }
                ),
                WorkflowNode(id="end_1", name="End", node_type=NodeType.END_EVENT)
            ],
            transitions=[
                WorkflowTransition(id="t1", from_node_id="start_1", to_node_id="signal_event"),
                WorkflowTransition(id="t2", from_node_id="signal_event", to_node_id="end_1")
            ],
            status=WorkflowStatus.ACTIVE
        )
        
        instance = await workflow_engine.start_workflow(signal_workflow)
        
        # Aguardar até chegar no evento de sinal
        await asyncio.sleep(0.1)
        
        # Act
        await workflow_engine.send_signal("test_signal", {"signal_data": "test_value"})
        
        # Aguardar processamento do sinal
        await asyncio.sleep(0.1)
        
        # Assert
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        assert updated_instance.status == ExecutionStatus.COMPLETED
        
        # Verificar se dados do sinal foram adicionados
        completed_token = updated_instance.tokens[0]
        assert "signal_data" in completed_token.data
        assert completed_token.data["signal_data"] == "test_value"
    
    @pytest.mark.asyncio
    async def test_generate_workflow_report(self, workflow_engine, simple_workflow):
        """Testa geração de relatório de workflow"""
        # Arrange
        instance = await workflow_engine.start_workflow(simple_workflow)
        
        # Completar tarefa para ter dados no relatório
        await workflow_engine.complete_user_task(
            instance_id=instance.id,
            node_id="task_1",
            user_id="user123",
            result={"completed": True}
        )
        
        # Act
        report = workflow_engine.generate_workflow_report(instance.id)
        
        # Assert
        assert "instance_id" in report
        assert "workflow_name" in report
        assert "status" in report
        assert "progress" in report
        assert "token_statistics" in report
        assert "execution_log" in report
        
        assert report["instance_id"] == str(instance.id)
        assert report["workflow_name"] == "Simple Workflow"
        assert report["status"] == "completed"
        assert report["progress"]["completion_percentage"] == 100.0
        assert len(report["execution_log"]) > 0
    
    @pytest.mark.asyncio
    async def test_workflow_with_error_handling(self, workflow_engine):
        """Testa workflow com tratamento de erro"""
        # Arrange
        error_workflow = Workflow(
            id=uuid4(),
            name="Error Workflow",
            nodes=[
                WorkflowNode(id="start_1", name="Start", node_type=NodeType.START_EVENT),
                WorkflowNode(
                    id="error_task",
                    name="Error Task",
                    node_type=NodeType.SERVICE_TASK,
                    configuration={
                        "task_type": "service_task",
                        "service_name": "failing_service",
                        "error_handling": {
                            "retry_count": 2,
                            "fail_workflow": True
                        }
                    }
                ),
                WorkflowNode(id="end_1", name="End", node_type=NodeType.END_EVENT)
            ],
            transitions=[
                WorkflowTransition(id="t1", from_node_id="start_1", to_node_id="error_task"),
                WorkflowTransition(id="t2", from_node_id="error_task", to_node_id="end_1")
            ],
            status=WorkflowStatus.ACTIVE
        )
        
        # Act
        instance = await workflow_engine.start_workflow(error_workflow)
        
        # Aguardar execução (que deve falhar)
        await asyncio.sleep(0.2)
        
        # Assert
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        
        # Verificar se workflow falhou devido ao erro
        # (Dependendo da implementação, pode ser FAILED ou ainda RUNNING)
        assert updated_instance.status in [ExecutionStatus.FAILED, ExecutionStatus.RUNNING]
        
        # Verificar se erro foi registrado no log
        error_logs = [
            log for log in updated_instance.execution_log
            if "erro" in log.get("message", "").lower()
        ]
        assert len(error_logs) >= 0  # Pode não ter erro se simulação não falhar
    
    @pytest.mark.asyncio
    async def test_workflow_performance_large_parallel_execution(self, workflow_engine):
        """Testa performance com execução paralela grande"""
        # Arrange - Workflow com muitas tarefas paralelas
        nodes = [WorkflowNode(id="start_1", name="Start", node_type=NodeType.START_EVENT)]
        nodes.append(WorkflowNode(id="fork", name="Fork", node_type=NodeType.PARALLEL_GATEWAY))
        
        # Criar 10 tarefas paralelas
        for i in range(10):
            nodes.append(WorkflowNode(
                id=f"task_{i}",
                name=f"Task {i}",
                node_type=NodeType.SERVICE_TASK,
                configuration={"task_type": "service_task", "service_name": f"service_{i}"}
            ))
        
        nodes.append(WorkflowNode(id="join", name="Join", node_type=NodeType.PARALLEL_GATEWAY))
        nodes.append(WorkflowNode(id="end_1", name="End", node_type=NodeType.END_EVENT))
        
        transitions = [WorkflowTransition(id="t_start", from_node_id="start_1", to_node_id="fork")]
        
        # Transições do fork para as tarefas
        for i in range(10):
            transitions.append(WorkflowTransition(id=f"t_fork_{i}", from_node_id="fork", to_node_id=f"task_{i}"))
            transitions.append(WorkflowTransition(id=f"t_join_{i}", from_node_id=f"task_{i}", to_node_id="join"))
        
        transitions.append(WorkflowTransition(id="t_end", from_node_id="join", to_node_id="end_1"))
        
        large_workflow = Workflow(
            id=uuid4(),
            name="Large Parallel Workflow",
            nodes=nodes,
            transitions=transitions,
            status=WorkflowStatus.ACTIVE
        )
        
        # Act
        start_time = datetime.utcnow()
        instance = await workflow_engine.start_workflow(large_workflow)
        
        # Aguardar execução completa
        await asyncio.sleep(1.0)
        
        end_time = datetime.utcnow()
        
        # Assert
        execution_time = (end_time - start_time).total_seconds()
        assert execution_time < 5.0  # Deve executar em menos de 5 segundos
        
        updated_instance = workflow_engine.get_workflow_instance(instance.id)
        assert updated_instance.status == ExecutionStatus.COMPLETED
        
        # Verificar se múltiplos tokens foram criados
        assert len(updated_instance.tokens) > 1
    
    @pytest.mark.asyncio
    async def test_get_active_instances(self, workflow_engine, simple_workflow):
        """Testa obtenção de instâncias ativas"""
        # Arrange
        instance1 = await workflow_engine.start_workflow(simple_workflow)
        instance2 = await workflow_engine.start_workflow(simple_workflow)
        
        # Cancelar uma instância
        await workflow_engine.cancel_workflow(instance2.id)
        
        # Act
        active_instances = workflow_engine.get_active_instances()
        
        # Assert
        assert len(active_instances) == 1
        assert active_instances[0].id == instance1.id
        assert active_instances[0].status in [ExecutionStatus.RUNNING, ExecutionStatus.WAITING]
    
    @pytest.mark.asyncio
    async def test_workflow_token_cloning(self, workflow_engine):
        """Testa clonagem de tokens para execução paralela"""
        # Arrange
        token = WorkflowToken(
            workflow_instance_id=uuid4(),
            current_node_id="test_node",
            data={"test": "data"}
        )
        
        # Act
        cloned_token = token.clone()
        
        # Assert
        assert cloned_token.id != token.id
        assert cloned_token.workflow_instance_id == token.workflow_instance_id
        assert cloned_token.current_node_id == token.current_node_id
        assert cloned_token.data == token.data
        assert cloned_token.parent_token_id == token.id
        assert cloned_token.status == ExecutionStatus.PENDING
    
    @pytest.mark.asyncio
    async def test_task_execution_overdue_detection(self, workflow_engine):
        """Testa detecção de tarefas atrasadas"""
        # Arrange
        past_due_date = datetime.utcnow() - timedelta(hours=1)
        task_execution = TaskExecution(
            workflow_instance_id=uuid4(),
            node_id="test_task",
            task_type=TaskType.USER_TASK,
            due_date=past_due_date
        )
        
        # Act
        is_overdue = task_execution.is_overdue()
        
        # Assert
        assert is_overdue is True
    
    @pytest.mark.asyncio
    async def test_workflow_instance_log_entry(self, workflow_engine, simple_workflow):
        """Testa adição de entradas no log de execução"""
        # Arrange
        instance = await workflow_engine.start_workflow(simple_workflow)
        
        # Act
        instance.add_log_entry("test_event", "test_node", "Test message", {"detail": "test"})
        
        # Assert
        assert len(instance.execution_log) > 0
        
        # Encontrar a entrada de teste
        test_entry = None
        for entry in instance.execution_log:
            if entry["event_type"] == "test_event":
                test_entry = entry
                break
        
        assert test_entry is not None
        assert test_entry["node_id"] == "test_node"
        assert test_entry["message"] == "Test message"
        assert test_entry["details"]["detail"] == "test"
        assert "timestamp" in test_entry


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

