# Autor: carlos.morais@f1rst.com.br
"""
Workflow Repository Implementation
SQLAlchemy implementation for workflow data access
"""

import json
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import text, func, and_, or_, desc, asc
from sqlalchemy.exc import SQLAlchemyError

# Import shared models
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'shared'))

from database.models.central_models import (
    WorkflowModel, WorkflowExecutionModel, TaskExecutionModel, 
    UserModel, OrganizationModel
)
from ...domain.entities.workflow import Workflow as WorkflowEntity
from ...domain.repositories.workflow_repository import WorkflowRepository
from ...application.dtos.workflow_dtos import (
    WorkflowType, WorkflowStatus, TaskStatus, Priority, ExecutionMode
)


class WorkflowRepositoryImpl(WorkflowRepository):
    """SQLAlchemy implementation of workflow repository"""
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    def save_workflow(self, workflow: WorkflowEntity) -> WorkflowEntity:
        """Save workflow"""
        try:
            # Check if workflow exists
            existing = self.db.query(WorkflowModel).filter(
                WorkflowModel.id == workflow.id
            ).first()
            
            if existing:
                # Update existing workflow
                existing.name = workflow.name
                existing.description = workflow.description
                existing.workflow_type = workflow.workflow_type.value
                existing.status = workflow.status.value
                existing.tasks = json.dumps(workflow.tasks) if workflow.tasks else None
                existing.config = json.dumps(workflow.config) if workflow.config else None
                existing.trigger_config = json.dumps(workflow.trigger_config) if workflow.trigger_config else None
                existing.variables = json.dumps(workflow.variables) if workflow.variables else None
                existing.tags = json.dumps(workflow.tags) if workflow.tags else None
                existing.priority = workflow.priority.value
                existing.progress_percentage = workflow.progress_percentage
                existing.started_at = workflow.started_at
                existing.completed_at = workflow.completed_at
                existing.duration_seconds = workflow.duration_seconds
                existing.next_execution = workflow.next_execution
                existing.execution_count = workflow.execution_count
                existing.success_count = workflow.success_count
                existing.failure_count = workflow.failure_count
                existing.enabled = workflow.enabled
                existing.updated_at = datetime.utcnow()
                
                model = existing
            else:
                # Create new workflow
                model = WorkflowModel(
                    id=workflow.id,
                    name=workflow.name,
                    description=workflow.description,
                    workflow_type=workflow.workflow_type.value,
                    status=workflow.status.value,
                    organization_id=workflow.organization_id,
                    created_by=workflow.created_by,
                    tasks=json.dumps(workflow.tasks) if workflow.tasks else None,
                    config=json.dumps(workflow.config) if workflow.config else None,
                    trigger_config=json.dumps(workflow.trigger_config) if workflow.trigger_config else None,
                    variables=json.dumps(workflow.variables) if workflow.variables else None,
                    tags=json.dumps(workflow.tags) if workflow.tags else None,
                    priority=workflow.priority.value,
                    progress_percentage=workflow.progress_percentage,
                    started_at=workflow.started_at,
                    completed_at=workflow.completed_at,
                    duration_seconds=workflow.duration_seconds,
                    next_execution=workflow.next_execution,
                    execution_count=workflow.execution_count,
                    success_count=workflow.success_count,
                    failure_count=workflow.failure_count,
                    enabled=workflow.enabled,
                    created_at=workflow.created_at,
                    updated_at=datetime.utcnow()
                )
                self.db.add(model)
            
            self.db.commit()
            self.db.refresh(model)
            
            return self._model_to_entity(model)
            
        except SQLAlchemyError as e:
            self.db.rollback()
            raise RuntimeError(f"Database error saving workflow: {str(e)}")
    
    def find_workflow_by_id(self, workflow_id: UUID) -> Optional[WorkflowEntity]:
        """Find workflow by ID"""
        try:
            model = self.db.query(WorkflowModel).filter(
                WorkflowModel.id == workflow_id,
                WorkflowModel.deleted_at.is_(None)
            ).first()
            
            if not model:
                return None
            
            return self._model_to_entity(model)
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error finding workflow: {str(e)}")
    
    def find_workflow_by_name(self, name: str, organization_id: UUID) -> Optional[WorkflowEntity]:
        """Find workflow by name and organization"""
        try:
            model = self.db.query(WorkflowModel).filter(
                WorkflowModel.name == name,
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.deleted_at.is_(None)
            ).first()
            
            if not model:
                return None
            
            return self._model_to_entity(model)
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error finding workflow by name: {str(e)}")
    
    def find_workflows_by_organization(self, organization_id: UUID, 
                                     limit: int = 100, offset: int = 0) -> List[WorkflowEntity]:
        """Find workflows by organization"""
        try:
            models = self.db.query(WorkflowModel).filter(
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.deleted_at.is_(None)
            ).order_by(desc(WorkflowModel.created_at)).limit(limit).offset(offset).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error finding workflows: {str(e)}")
    
    def find_workflows_with_filters(self, filters: Dict[str, Any], 
                                  limit: int = 100, offset: int = 0) -> List[WorkflowEntity]:
        """Find workflows with filters"""
        try:
            query = self.db.query(WorkflowModel).filter(
                WorkflowModel.deleted_at.is_(None)
            )
            
            # Apply filters
            if 'organization_id' in filters:
                query = query.filter(WorkflowModel.organization_id == filters['organization_id'])
            
            if 'workflow_type' in filters:
                query = query.filter(WorkflowModel.workflow_type == filters['workflow_type'])
            
            if 'status' in filters:
                query = query.filter(WorkflowModel.status == filters['status'])
            
            if 'priority' in filters:
                query = query.filter(WorkflowModel.priority == filters['priority'])
            
            if 'created_by' in filters:
                query = query.filter(WorkflowModel.created_by == filters['created_by'])
            
            if 'enabled' in filters:
                query = query.filter(WorkflowModel.enabled == filters['enabled'])
            
            if 'has_failures' in filters and filters['has_failures']:
                query = query.filter(WorkflowModel.failure_count > 0)
            
            if 'created_after' in filters:
                query = query.filter(WorkflowModel.created_at >= filters['created_after'])
            
            if 'created_before' in filters:
                query = query.filter(WorkflowModel.created_at <= filters['created_before'])
            
            if 'updated_after' in filters:
                query = query.filter(WorkflowModel.updated_at >= filters['updated_after'])
            
            if 'updated_before' in filters:
                query = query.filter(WorkflowModel.updated_at <= filters['updated_before'])
            
            models = query.order_by(desc(WorkflowModel.created_at)).limit(limit).offset(offset).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error filtering workflows: {str(e)}")
    
    def search_workflows(self, query_text: str, organization_id: Optional[UUID] = None,
                        limit: int = 100, offset: int = 0) -> List[WorkflowEntity]:
        """Search workflows by text"""
        try:
            query = self.db.query(WorkflowModel).filter(
                WorkflowModel.deleted_at.is_(None)
            )
            
            if organization_id:
                query = query.filter(WorkflowModel.organization_id == organization_id)
            
            # Text search in name, description, and tags
            search_filter = or_(
                WorkflowModel.name.ilike(f"%{query_text}%"),
                WorkflowModel.description.ilike(f"%{query_text}%"),
                WorkflowModel.tags.ilike(f"%{query_text}%")
            )
            
            query = query.filter(search_filter)
            
            models = query.order_by(desc(WorkflowModel.created_at)).limit(limit).offset(offset).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error searching workflows: {str(e)}")
    
    def find_workflows_by_type(self, workflow_type: WorkflowType, organization_id: UUID,
                             limit: int = 100, offset: int = 0) -> List[WorkflowEntity]:
        """Find workflows by type"""
        try:
            models = self.db.query(WorkflowModel).filter(
                WorkflowModel.workflow_type == workflow_type.value,
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.deleted_at.is_(None)
            ).order_by(desc(WorkflowModel.created_at)).limit(limit).offset(offset).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error finding workflows by type: {str(e)}")
    
    def find_workflows_by_status(self, status: WorkflowStatus, organization_id: UUID,
                               limit: int = 100, offset: int = 0) -> List[WorkflowEntity]:
        """Find workflows by status"""
        try:
            models = self.db.query(WorkflowModel).filter(
                WorkflowModel.status == status.value,
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.deleted_at.is_(None)
            ).order_by(desc(WorkflowModel.updated_at)).limit(limit).offset(offset).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error finding workflows by status: {str(e)}")
    
    def find_scheduled_workflows(self, execution_time: datetime) -> List[WorkflowEntity]:
        """Find workflows scheduled for execution"""
        try:
            models = self.db.query(WorkflowModel).filter(
                WorkflowModel.next_execution <= execution_time,
                WorkflowModel.enabled == True,
                WorkflowModel.status.in_(['pending', 'completed']),
                WorkflowModel.deleted_at.is_(None)
            ).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error finding scheduled workflows: {str(e)}")
    
    def find_running_workflows(self, organization_id: Optional[UUID] = None) -> List[WorkflowEntity]:
        """Find currently running workflows"""
        try:
            query = self.db.query(WorkflowModel).filter(
                WorkflowModel.status == 'running',
                WorkflowModel.deleted_at.is_(None)
            )
            
            if organization_id:
                query = query.filter(WorkflowModel.organization_id == organization_id)
            
            models = query.order_by(desc(WorkflowModel.started_at)).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error finding running workflows: {str(e)}")
    
    def find_failed_workflows(self, organization_id: UUID, 
                            hours_back: int = 24) -> List[WorkflowEntity]:
        """Find workflows that failed in the last N hours"""
        try:
            since_time = datetime.utcnow() - timedelta(hours=hours_back)
            
            models = self.db.query(WorkflowModel).filter(
                WorkflowModel.status == 'failed',
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.updated_at >= since_time,
                WorkflowModel.deleted_at.is_(None)
            ).order_by(desc(WorkflowModel.updated_at)).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error finding failed workflows: {str(e)}")
    
    def delete_workflow(self, workflow_id: UUID) -> bool:
        """Delete workflow (soft delete)"""
        try:
            model = self.db.query(WorkflowModel).filter(
                WorkflowModel.id == workflow_id,
                WorkflowModel.deleted_at.is_(None)
            ).first()
            
            if not model:
                return False
            
            model.deleted_at = datetime.utcnow()
            self.db.commit()
            
            return True
            
        except SQLAlchemyError as e:
            self.db.rollback()
            raise RuntimeError(f"Database error deleting workflow: {str(e)}")
    
    def get_workflow_statistics(self, organization_id: UUID) -> Dict[str, Any]:
        """Get workflow statistics for organization"""
        try:
            # Total workflows
            total_workflows = self.db.query(func.count(WorkflowModel.id)).filter(
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Active workflows
            active_workflows = self.db.query(func.count(WorkflowModel.id)).filter(
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.enabled == True,
                WorkflowModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Total executions
            total_executions = self.db.query(func.sum(WorkflowModel.execution_count)).filter(
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Successful executions
            successful_executions = self.db.query(func.sum(WorkflowModel.success_count)).filter(
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Failed executions
            failed_executions = self.db.query(func.sum(WorkflowModel.failure_count)).filter(
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Average execution time (simplified)
            avg_execution_time = self.db.query(func.avg(WorkflowModel.duration_seconds)).filter(
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.duration_seconds.isnot(None),
                WorkflowModel.deleted_at.is_(None)
            ).scalar() or 0.0
            
            # Workflows by type
            workflows_by_type = dict(self.db.query(
                WorkflowModel.workflow_type,
                func.count(WorkflowModel.id)
            ).filter(
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.deleted_at.is_(None)
            ).group_by(WorkflowModel.workflow_type).all())
            
            # Workflows by status
            workflows_by_status = dict(self.db.query(
                WorkflowModel.status,
                func.count(WorkflowModel.id)
            ).filter(
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.deleted_at.is_(None)
            ).group_by(WorkflowModel.status).all())
            
            # Most used workflows (by execution count)
            most_used = self.db.query(
                WorkflowModel.name,
                WorkflowModel.execution_count
            ).filter(
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.deleted_at.is_(None)
            ).order_by(desc(WorkflowModel.execution_count)).limit(5).all()
            
            most_used_workflows = [
                {"name": name, "execution_count": count}
                for name, count in most_used
            ]
            
            # Recent failures
            recent_failures = self.db.query(
                WorkflowModel.name,
                WorkflowModel.updated_at
            ).filter(
                WorkflowModel.organization_id == organization_id,
                WorkflowModel.status == 'failed',
                WorkflowModel.updated_at >= datetime.utcnow() - timedelta(hours=24),
                WorkflowModel.deleted_at.is_(None)
            ).order_by(desc(WorkflowModel.updated_at)).limit(5).all()
            
            recent_failures_list = [
                {"name": name, "failed_at": failed_at.isoformat()}
                for name, failed_at in recent_failures
            ]
            
            # Calculate success rate
            success_rate = (successful_executions / total_executions * 100) if total_executions > 0 else 100.0
            
            return {
                'total_workflows': total_workflows,
                'active_workflows': active_workflows,
                'total_executions': total_executions,
                'successful_executions': successful_executions,
                'failed_executions': failed_executions,
                'avg_execution_time': float(avg_execution_time),
                'workflows_by_type': workflows_by_type,
                'workflows_by_status': workflows_by_status,
                'success_rate': success_rate,
                'most_used_workflows': most_used_workflows,
                'recent_failures': recent_failures_list
            }
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error getting workflow statistics: {str(e)}")
    
    def get_workflow_metrics(self, workflow_id: UUID) -> Dict[str, Any]:
        """Get metrics for specific workflow"""
        try:
            workflow = self.db.query(WorkflowModel).filter(
                WorkflowModel.id == workflow_id,
                WorkflowModel.deleted_at.is_(None)
            ).first()
            
            if not workflow:
                return {}
            
            # Calculate min/max duration from executions (simplified)
            min_duration = workflow.duration_seconds or 0.0
            max_duration = workflow.duration_seconds or 0.0
            
            return {
                'workflow_id': workflow_id,
                'execution_count': workflow.execution_count,
                'success_count': workflow.success_count,
                'failure_count': workflow.failure_count,
                'avg_duration': workflow.duration_seconds or 0.0,
                'min_duration': min_duration,
                'max_duration': max_duration,
                'success_rate': (workflow.success_count / workflow.execution_count * 100) if workflow.execution_count > 0 else 100.0,
                'last_execution': workflow.completed_at,
                'next_execution': workflow.next_execution
            }
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error getting workflow metrics: {str(e)}")
    
    def get_workflow_health(self, workflow_id: UUID) -> Dict[str, Any]:
        """Get health assessment for workflow"""
        try:
            workflow = self.db.query(WorkflowModel).filter(
                WorkflowModel.id == workflow_id,
                WorkflowModel.deleted_at.is_(None)
            ).first()
            
            if not workflow:
                return {}
            
            # Calculate health score (simplified algorithm)
            health_score = 100.0
            issues = []
            recommendations = []
            
            # Check success rate
            if workflow.execution_count > 0:
                success_rate = workflow.success_count / workflow.execution_count * 100
                if success_rate < 80:
                    health_score -= 30
                    issues.append(f"Low success rate: {success_rate:.1f}%")
                    recommendations.append("Review workflow configuration and error handling")
                elif success_rate < 95:
                    health_score -= 10
                    issues.append(f"Moderate success rate: {success_rate:.1f}%")
            
            # Check if workflow is enabled
            if not workflow.enabled:
                health_score -= 20
                issues.append("Workflow is disabled")
                recommendations.append("Enable workflow if it should be active")
            
            # Check last execution time
            if workflow.completed_at:
                days_since_last = (datetime.utcnow() - workflow.completed_at).days
                if days_since_last > 30:
                    health_score -= 15
                    issues.append(f"No execution in {days_since_last} days")
                    recommendations.append("Check if workflow should be running more frequently")
            
            # Check for recent failures
            if workflow.failure_count > 0 and workflow.status == 'failed':
                health_score -= 25
                issues.append("Recent execution failures")
                recommendations.append("Investigate and fix failure causes")
            
            # Ensure health score doesn't go below 0
            health_score = max(0.0, health_score)
            
            return {
                'workflow_id': workflow_id,
                'health_score': health_score,
                'issues': issues,
                'recommendations': recommendations,
                'last_check': datetime.utcnow()
            }
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error getting workflow health: {str(e)}")
    
    def _model_to_entity(self, model: WorkflowModel) -> WorkflowEntity:
        """Convert model to entity"""
        # Get organization and user names
        org_name = ""
        user_name = ""
        
        if model.organization_id:
            org = self.db.query(OrganizationModel).filter(
                OrganizationModel.id == model.organization_id
            ).first()
            if org:
                org_name = org.name
        
        if model.created_by:
            user = self.db.query(UserModel).filter(
                UserModel.id == model.created_by
            ).first()
            if user:
                user_name = user.full_name or user.email
        
        return WorkflowEntity(
            id=model.id,
            name=model.name,
            description=model.description,
            workflow_type=WorkflowType(model.workflow_type),
            status=WorkflowStatus(model.status),
            organization_id=model.organization_id,
            organization_name=org_name,
            created_by=model.created_by,
            created_by_name=user_name,
            tasks=json.loads(model.tasks) if model.tasks else [],
            config=json.loads(model.config) if model.config else None,
            trigger_config=json.loads(model.trigger_config) if model.trigger_config else None,
            variables=json.loads(model.variables) if model.variables else [],
            tags=json.loads(model.tags) if model.tags else [],
            priority=Priority(model.priority),
            progress_percentage=model.progress_percentage,
            started_at=model.started_at,
            completed_at=model.completed_at,
            duration_seconds=model.duration_seconds,
            next_execution=model.next_execution,
            execution_count=model.execution_count,
            success_count=model.success_count,
            failure_count=model.failure_count,
            enabled=model.enabled,
            created_at=model.created_at,
            updated_at=model.updated_at
        )

