# Autor: carlos.morais@f1rst.com.br
"""
Workflow Service DTOs
Data Transfer Objects for workflow orchestration operations
"""

import json
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Union
from uuid import UUID
from enum import Enum
from pydantic import BaseModel, Field, validator, root_validator


# ============================================================================
# ENUMS
# ============================================================================

class WorkflowType(str, Enum):
    """Workflow types"""
    CONTRACT_APPROVAL = "contract_approval"
    DATA_QUALITY_CHECK = "data_quality_check"
    COMPLNCE_VALIDATION = "compliance_validation"
    DATA_MIGRATION = "data_migration"
    SCHEMA_EVOLUTION = "schema_evolution"
    PII_MASKING = "pii_masking"
    DATA_LINEAGE_UPDATE = "data_lineage_update"
    REPORT_GENERATION = "report_generation"
    CUSTOM_WORKFLOW = "custom_workflow"


class WorkflowStatus(str, Enum):
    """Workflow execution status"""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FLED = "failed"
    CANCELLED = "cancelled"
    TIMEOUT = "timeout"


class TaskStatus(str, Enum):
    """Task execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FLED = "failed"
    SKIPPED = "skipped"
    RETRYING = "retrying"


class TaskType(str, Enum):
    """Task types"""
    APPROVAL = "approval"
    VALIDATION = "validation"
    TRANSFORMATION = "transformation"
    NOTIFICATION = "notification"
    API_CALL = "api_call"
    SCRIPT_EXECUTION = "script_execution"
    CONDITION_CHECK = "condition_check"
    WT = "wait"
    PARALLEL_EXECUTION = "parallel_execution"
    CUSTOM = "custom"


class ExecutionMode(str, Enum):
    """Execution modes"""
    SEQUENTL = "sequential"
    PARALLEL = "parallel"
    CONDITIONAL = "conditional"
    LOOP = "loop"


class Priority(str, Enum):
    """Priority levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class TriggerType(str, Enum):
    """Trigger types"""
    MANUAL = "manual"
    SCHEDULED = "scheduled"
    EVENT_DRIVEN = "event_driven"
    API_TRIGGERED = "api_triggered"


# ============================================================================
# SUPPORTING DTOs
# ============================================================================

class TaskConfigDTO(BaseModel):
    """Task configuration"""
    task_type: TaskType
    name: str
    description: Optional[str] = None
    parameters: Optional[Dict[str, Any]] = None
    timeout_seconds: Optional[int] = Field(None, ge=1, le=86400)  # Max 24 hours
    retry_count: int = Field(0, ge=0, le=10)
    retry_delay_seconds: int = Field(30, ge=1, le=3600)
    depends_on: Optional[List[str]] = None  # Task names this task depends on
    condition: Optional[str] = None  # Condition for conditional execution
    parallel_group: Optional[str] = None  # Group for parallel execution


class WorkflowConfigDTO(BaseModel):
    """Workflow configuration"""
    execution_mode: ExecutionMode = ExecutionMode.SEQUENTL
    max_parallel_tasks: int = Field(5, ge=1, le=50)
    timeout_minutes: int = Field(60, ge=1, le=1440)  # Max 24 hours
    retry_policy: Optional[Dict[str, Any]] = None
    notification_config: Optional[Dict[str, Any]] = None
    variables: Optional[Dict[str, Any]] = None


class TriggerConfigDTO(BaseModel):
    """Trigger configuration"""
    trigger_type: TriggerType
    cron_expression: Optional[str] = None  # For scheduled triggers
    event_filters: Optional[Dict[str, Any]] = None  # For event-driven triggers
    webhook_url: Optional[str] = None  # For API triggers
    enabled: bool = True


class NotificationConfigDTO(BaseModel):
    """Notification configuration"""
    on_start: bool = False
    on_completion: bool = True
    on_failure: bool = True
    on_timeout: bool = True
    recipients: List[str] = Field(default_factory=list)
    channels: List[str] = Field(default_factory=lambda: ["email"])  # email, slack, webhook


class RetryPolicyDTO(BaseModel):
    """Retry policy configuration"""
    max_retries: int = Field(3, ge=0, le=10)
    initial_delay_seconds: int = Field(30, ge=1, le=3600)
    max_delay_seconds: int = Field(300, ge=1, le=3600)
    backoff_multiplier: float = Field(2.0, ge=1.0, le=10.0)
    retry_on_timeout: bool = True
    retry_on_failure: bool = True


class WorkflowVariableDTO(BaseModel):
    """Workflow variable"""
    name: str = Field(..., min_length=1, max_length=100)
    value: Union[str, int, float, bool, Dict[str, Any]]
    description: Optional[str] = None
    is_secret: bool = False


class TaskExecutionResultDTO(BaseModel):
    """Task execution result"""
    task_id: UUID
    task_name: str
    status: TaskStatus
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    output: Optional[Dict[str, Any]] = None
    error_message: Optional[str] = None
    retry_count: int = 0


class WorkflowExecutionMetricsDTO(BaseModel):
    """Workflow execution metrics"""
    total_tasks: int
    completed_tasks: int
    failed_tasks: int
    skipped_tasks: int
    pending_tasks: int
    success_rate: float = Field(ge=0.0, le=100.0)
    avg_task_duration: Optional[float] = None
    total_duration: Optional[float] = None


# ============================================================================
# REQUEST DTOs
# ============================================================================

class CreateWorkflowRequest(BaseModel):
    """Create workflow request"""
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    workflow_type: WorkflowType
    organization_id: UUID
    tasks: List[TaskConfigDTO] = Field(..., min_items=1, max_items=100)
    config: Optional[WorkflowConfigDTO] = None
    trigger_config: Optional[TriggerConfigDTO] = None
    variables: Optional[List[WorkflowVariableDTO]] = None
    tags: Optional[List[str]] = Field(None, max_items=20)
    enabled: bool = True

    @validator('tasks')
    def validate_tasks(cls, v):
        """Validate task configurations"""
        task_names = [task.name for task in v]
        if len(task_names) != len(set(task_names)):
            raise ValueError("Task names must be unique within workflow")
        
        # Validate dependencies
        for task in v:
            if task.depends_on:
                for dep in task.depends_on:
                    if dep not in task_names:
                        raise ValueError(f"Task '{task.name}' depends on non-existent task '{dep}'")
        
        return v


class UpdateWorkflowRequest(BaseModel):
    """Update workflow request"""
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    tasks: Optional[List[TaskConfigDTO]] = Field(None, min_items=1, max_items=100)
    config: Optional[WorkflowConfigDTO] = None
    trigger_config: Optional[TriggerConfigDTO] = None
    variables: Optional[List[WorkflowVariableDTO]] = None
    tags: Optional[List[str]] = Field(None, max_items=20)
    enabled: Optional[bool] = None

    @validator('tasks')
    def validate_tasks(cls, v):
        """Validate task configurations"""
        if v is not None:
            task_names = [task.name for task in v]
            if len(task_names) != len(set(task_names)):
                raise ValueError("Task names must be unique within workflow")
        return v


class ExecuteWorkflowRequest(BaseModel):
    """Execute workflow request"""
    workflow_id: UUID
    input_parameters: Optional[Dict[str, Any]] = None
    priority: Priority = Priority.MEDIUM
    scheduled_at: Optional[datetime] = None
    timeout_override: Optional[int] = Field(None, ge=1, le=1440)  # Minutes
    notification_override: Optional[NotificationConfigDTO] = None


class WorkflowSearchRequest(BaseModel):
    """Workflow search request"""
    query: Optional[str] = Field(None, min_length=1, max_length=200)
    workflow_type: Optional[WorkflowType] = None
    status: Optional[WorkflowStatus] = None
    organization_id: Optional[UUID] = None
    created_by: Optional[UUID] = None
    tags: Optional[List[str]] = None
    enabled: Optional[bool] = None
    created_after: Optional[datetime] = None
    created_before: Optional[datetime] = None


class WorkflowFilterRequest(BaseModel):
    """Workflow filter request"""
    organization_id: Optional[UUID] = None
    workflow_type: Optional[WorkflowType] = None
    status: Optional[WorkflowStatus] = None
    priority: Optional[Priority] = None
    created_by: Optional[UUID] = None
    enabled: Optional[bool] = None
    has_failures: Optional[bool] = None
    created_after: Optional[datetime] = None
    created_before: Optional[datetime] = None
    updated_after: Optional[datetime] = None
    updated_before: Optional[datetime] = None


class TaskActionRequest(BaseModel):
    """Task action request"""
    action: str = Field(..., regex="^(approve|reject|retry|skip|pause|resume)$")
    comment: Optional[str] = Field(None, max_length=500)
    parameters: Optional[Dict[str, Any]] = None


class WorkflowActionRequest(BaseModel):
    """Workflow action request"""
    action: str = Field(..., regex="^(pause|resume|cancel|restart)$")
    comment: Optional[str] = Field(None, max_length=500)
    force: bool = False


# ============================================================================
# RESPONSE DTOs
# ============================================================================

class TaskResponse(BaseModel):
    """Task response"""
    id: UUID
    name: str
    description: Optional[str]
    task_type: TaskType
    status: TaskStatus
    workflow_id: UUID
    order_index: int
    parameters: Optional[Dict[str, Any]]
    timeout_seconds: Optional[int]
    retry_count: int
    retry_delay_seconds: int
    depends_on: Optional[List[str]]
    condition: Optional[str]
    parallel_group: Optional[str]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    duration_seconds: Optional[float]
    output: Optional[Dict[str, Any]]
    error_message: Optional[str]
    retry_attempts: int
    created_at: datetime
    updated_at: datetime


class WorkflowResponse(BaseModel):
    """Workflow response"""
    id: UUID
    name: str
    description: Optional[str]
    workflow_type: WorkflowType
    status: WorkflowStatus
    organization_id: UUID
    organization_name: str
    created_by: UUID
    created_by_name: str
    tasks: List[TaskResponse]
    config: Optional[WorkflowConfigDTO]
    trigger_config: Optional[TriggerConfigDTO]
    variables: Optional[List[WorkflowVariableDTO]]
    tags: Optional[List[str]]
    priority: Priority
    progress_percentage: float = Field(ge=0.0, le=100.0)
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    duration_seconds: Optional[float]
    next_execution: Optional[datetime]
    execution_count: int
    success_count: int
    failure_count: int
    enabled: bool
    created_at: datetime
    updated_at: datetime


class WorkflowListResponse(BaseModel):
    """Workflow list response"""
    workflows: List[WorkflowResponse]
    total: int
    limit: int
    offset: int
    has_more: bool


class WorkflowExecutionResponse(BaseModel):
    """Workflow execution response"""
    id: UUID
    workflow_id: UUID
    workflow_name: str
    status: WorkflowStatus
    priority: Priority
    input_parameters: Optional[Dict[str, Any]]
    output: Optional[Dict[str, Any]]
    progress_percentage: float = Field(ge=0.0, le=100.0)
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    duration_seconds: Optional[float]
    task_executions: List[TaskExecutionResultDTO]
    metrics: WorkflowExecutionMetricsDTO
    error_message: Optional[str]
    created_at: datetime
    updated_at: datetime


class WorkflowExecutionListResponse(BaseModel):
    """Workflow execution list response"""
    executions: List[WorkflowExecutionResponse]
    total: int
    limit: int
    offset: int
    has_more: bool


class WorkflowStatisticsResponse(BaseModel):
    """Workflow statistics response"""
    organization_id: UUID
    total_workflows: int
    active_workflows: int
    total_executions: int
    successful_executions: int
    failed_executions: int
    avg_execution_time: float
    workflows_by_type: Dict[str, int]
    workflows_by_status: Dict[str, int]
    executions_by_status: Dict[str, int]
    success_rate: float = Field(ge=0.0, le=100.0)
    most_used_workflows: List[Dict[str, Any]]
    recent_failures: List[Dict[str, Any]]


class WorkflowTemplateResponse(BaseModel):
    """Workflow template response"""
    id: UUID
    name: str
    description: Optional[str]
    workflow_type: WorkflowType
    template_config: Dict[str, Any]
    default_tasks: List[TaskConfigDTO]
    variables: Optional[List[WorkflowVariableDTO]]
    tags: Optional[List[str]]
    usage_count: int
    created_by: UUID
    created_by_name: str
    created_at: datetime
    updated_at: datetime


class WorkflowTemplateListResponse(BaseModel):
    """Workflow template list response"""
    templates: List[WorkflowTemplateResponse]
    total: int
    limit: int
    offset: int
    has_more: bool


class WorkflowSummaryResponse(BaseModel):
    """Workflow summary response"""
    id: UUID
    name: str
    workflow_type: WorkflowType
    status: WorkflowStatus
    progress_percentage: float
    last_execution: Optional[datetime]
    success_rate: float
    enabled: bool


class TaskSummaryResponse(BaseModel):
    """Task summary response"""
    id: UUID
    name: str
    task_type: TaskType
    status: TaskStatus
    duration_seconds: Optional[float]
    retry_attempts: int


# ============================================================================
# UTILITY DTOs
# ============================================================================

class WorkflowValidationResponse(BaseModel):
    """Workflow validation response"""
    is_valid: bool
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    suggestions: List[str] = Field(default_factory=list)


class WorkflowMetricsResponse(BaseModel):
    """Workflow metrics response"""
    workflow_id: UUID
    execution_count: int
    success_count: int
    failure_count: int
    avg_duration: float
    min_duration: float
    max_duration: float
    success_rate: float
    last_execution: Optional[datetime]
    next_execution: Optional[datetime]


class WorkflowHealthResponse(BaseModel):
    """Workflow health response"""
    workflow_id: UUID
    health_score: float = Field(ge=0.0, le=100.0)
    issues: List[str] = Field(default_factory=list)
    recommendations: List[str] = Field(default_factory=list)
    last_check: datetime

