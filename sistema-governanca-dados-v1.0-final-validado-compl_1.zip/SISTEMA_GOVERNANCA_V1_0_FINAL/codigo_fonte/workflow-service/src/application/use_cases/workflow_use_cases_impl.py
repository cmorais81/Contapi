# Autor: carlos.morais@f1rst.com.br
"""
Workflow Use Cases Implementation
Business logic for workflow orchestration operations
"""

import json
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID, uuid4
from ...domain.entities.workflow import Workflow as WorkflowEntity
from ...domain.repositories.workflow_repository import WorkflowRepository
from ...application.dtos.workflow_dtos import (
    # Request DTOs
    CreateWorkflowRequest, UpdateWorkflowRequest, ExecuteWorkflowRequest,
    WorkflowSearchRequest, WorkflowFilterRequest, TaskActionRequest, WorkflowActionRequest,
    
    # Response DTOs
    WorkflowResponse, WorkflowListResponse, WorkflowExecutionResponse,
    WorkflowStatisticsResponse, WorkflowValidationResponse, WorkflowMetricsResponse,
    WorkflowHealthResponse, TaskResponse,
    
    # Enums
    WorkflowType, WorkflowStatus, TaskStatus, Priority, ExecutionMode
)


class WorkflowUseCases:
    """Workflow use cases implementation"""
    
    def __init__(self, workflow_repository: WorkflowRepository):
        self.workflow_repository = workflow_repository
    
    def create_workflow(self, request: CreateWorkflowRequest) -> WorkflowResponse:
        """Create new workflow"""
        try:
            # Check if workflow name already exists in organization
            existing = self.workflow_repository.find_workflow_by_name(
                request.name, request.organization_id
            )
            if existing:
                raise ValueError(f"Workflow with name '{request.name}' already exists in organization")
            
            # Validate workflow configuration
            validation_result = self._validate_workflow_config(request.tasks, request.config)
            if not validation_result.is_valid:
                raise ValueError(f"Invalid workflow configuration: {', '.join(validation_result.errors)}")
            
            # Create workflow entity
            workflow_id = uuid4()
            workflow = WorkflowEntity(
                id=workflow_id,
                name=request.name,
                description=request.description,
                workflow_type=request.workflow_type,
                status=WorkflowStatus.PENDING,
                organization_id=request.organization_id,
                created_by=request.organization_id,  # Simplified - should be current user
                tasks=self._process_tasks(request.tasks),
                config=request.config.dict() if request.config else None,
                trigger_config=request.trigger_config.dict() if request.trigger_config else None,
                variables=[var.dict() for var in request.variables] if request.variables else [],
                tags=request.tags or [],
                priority=Priority.MEDIUM,
                progress_percentage=0.0,
                started_at=None,
                completed_at=None,
                duration_seconds=None,
                next_execution=self._calculate_next_execution(request.trigger_config),
                execution_count=0,
                success_count=0,
                failure_count=0,
                enabled=request.enabled,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            # Save workflow
            saved_workflow = self.workflow_repository.save_workflow(workflow)
            
            return self._entity_to_response(saved_workflow)
            
        except Exception as e:
            raise RuntimeError(f"Error creating workflow: {str(e)}")
    
    def update_workflow(self, workflow_id: UUID, request: UpdateWorkflowRequest) -> WorkflowResponse:
        """Update existing workflow"""
        try:
            # Find existing workflow
            workflow = self.workflow_repository.find_workflow_by_id(workflow_id)
            if not workflow:
                raise ValueError(f"Workflow with ID {workflow_id} not found")
            
            # Check if workflow is running
            if workflow.status == WorkflowStatus.RUNNING:
                raise ValueError("Cannot update workflow while it's running")
            
            # Update fields
            if request.name is not None:
                # Check name uniqueness
                existing = self.workflow_repository.find_workflow_by_name(
                    request.name, workflow.organization_id
                )
                if existing and existing.id != workflow_id:
                    raise ValueError(f"Workflow with name '{request.name}' already exists in organization")
                workflow.name = request.name
            
            if request.description is not None:
                workflow.description = request.description
            
            if request.tasks is not None:
                # Validate new tasks
                validation_result = self._validate_workflow_config(request.tasks, request.config)
                if not validation_result.is_valid:
                    raise ValueError(f"Invalid workflow configuration: {', '.join(validation_result.errors)}")
                workflow.tasks = self._process_tasks(request.tasks)
            
            if request.config is not None:
                workflow.config = request.config.dict()
            
            if request.trigger_config is not None:
                workflow.trigger_config = request.trigger_config.dict()
                workflow.next_execution = self._calculate_next_execution(request.trigger_config)
            
            if request.variables is not None:
                workflow.variables = [var.dict() for var in request.variables]
            
            if request.tags is not None:
                workflow.tags = request.tags
            
            if request.enabled is not None:
                workflow.enabled = request.enabled
            
            workflow.updated_at = datetime.utcnow()
            
            # Save updated workflow
            saved_workflow = self.workflow_repository.save_workflow(workflow)
            
            return self._entity_to_response(saved_workflow)
            
        except Exception as e:
            raise RuntimeError(f"Error updating workflow: {str(e)}")
    
    def get_workflow(self, workflow_id: UUID) -> Optional[WorkflowResponse]:
        """Get workflow by ID"""
        try:
            workflow = self.workflow_repository.find_workflow_by_id(workflow_id)
            if not workflow:
                return None
            
            return self._entity_to_response(workflow)
            
        except Exception as e:
            raise RuntimeError(f"Error getting workflow: {str(e)}")
    
    def list_workflows(self, organization_id: UUID, limit: int = 100, offset: int = 0) -> WorkflowListResponse:
        """List workflows for organization"""
        try:
            workflows = self.workflow_repository.find_workflows_by_organization(
                organization_id, limit, offset
            )
            
            # Get total count (simplified)
            total = len(workflows) + offset
            
            workflow_responses = [self._entity_to_response(w) for w in workflows]
            
            return WorkflowListResponse(
                workflows=workflow_responses,
                total=total,
                limit=limit,
                offset=offset,
                has_more=len(workflows) == limit
            )
            
        except Exception as e:
            raise RuntimeError(f"Error listing workflows: {str(e)}")
    
    def search_workflows(self, request: WorkflowSearchRequest, 
                        limit: int = 100, offset: int = 0) -> WorkflowListResponse:
        """Search workflows"""
        try:
            if request.query:
                workflows = self.workflow_repository.search_workflows(
                    request.query, request.organization_id, limit, offset
                )
            else:
                # Convert search request to filters
                filters = {}
                if request.workflow_type:
                    filters['workflow_type'] = request.workflow_type.value
                if request.status:
                    filters['status'] = request.status.value
                if request.organization_id:
                    filters['organization_id'] = request.organization_id
                if request.created_by:
                    filters['created_by'] = request.created_by
                if request.enabled is not None:
                    filters['enabled'] = request.enabled
                if request.created_after:
                    filters['created_after'] = request.created_after
                if request.created_before:
                    filters['created_before'] = request.created_before
                
                workflows = self.workflow_repository.find_workflows_with_filters(
                    filters, limit, offset
                )
            
            # Get total count (simplified)
            total = len(workflows) + offset
            
            workflow_responses = [self._entity_to_response(w) for w in workflows]
            
            return WorkflowListResponse(
                workflows=workflow_responses,
                total=total,
                limit=limit,
                offset=offset,
                has_more=len(workflows) == limit
            )
            
        except Exception as e:
            raise RuntimeError(f"Error searching workflows: {str(e)}")
    
    def filter_workflows(self, request: WorkflowFilterRequest,
                        limit: int = 100, offset: int = 0) -> WorkflowListResponse:
        """Filter workflows"""
        try:
            # Convert filter request to dict
            filters = {}
            if request.organization_id:
                filters['organization_id'] = request.organization_id
            if request.workflow_type:
                filters['workflow_type'] = request.workflow_type.value
            if request.status:
                filters['status'] = request.status.value
            if request.priority:
                filters['priority'] = request.priority.value
            if request.created_by:
                filters['created_by'] = request.created_by
            if request.enabled is not None:
                filters['enabled'] = request.enabled
            if request.has_failures is not None:
                filters['has_failures'] = request.has_failures
            if request.created_after:
                filters['created_after'] = request.created_after
            if request.created_before:
                filters['created_before'] = request.created_before
            if request.updated_after:
                filters['updated_after'] = request.updated_after
            if request.updated_before:
                filters['updated_before'] = request.updated_before
            
            workflows = self.workflow_repository.find_workflows_with_filters(
                filters, limit, offset
            )
            
            # Get total count (simplified)
            total = len(workflows) + offset
            
            workflow_responses = [self._entity_to_response(w) for w in workflows]
            
            return WorkflowListResponse(
                workflows=workflow_responses,
                total=total,
                limit=limit,
                offset=offset,
                has_more=len(workflows) == limit
            )
            
        except Exception as e:
            raise RuntimeError(f"Error filtering workflows: {str(e)}")
    
    def execute_workflow(self, request: ExecuteWorkflowRequest) -> WorkflowExecutionResponse:
        """Execute workflow"""
        try:
            # Find workflow
            workflow = self.workflow_repository.find_workflow_by_id(request.workflow_id)
            if not workflow:
                raise ValueError(f"Workflow with ID {request.workflow_id} not found")
            
            if not workflow.enabled:
                raise ValueError("Cannot execute disabled workflow")
            
            if workflow.status == WorkflowStatus.RUNNING:
                raise ValueError("Workflow is already running")
            
            # Update workflow status
            workflow.status = WorkflowStatus.RUNNING
            workflow.started_at = datetime.utcnow()
            workflow.progress_percentage = 0.0
            workflow.execution_count += 1
            
            # Save updated workflow
            self.workflow_repository.save_workflow(workflow)
            
            # Create execution response (simplified - in real implementation would trigger actual execution)
            execution_response = WorkflowExecutionResponse(
                id=uuid4(),
                workflow_id=workflow.id,
                workflow_name=workflow.name,
                status=WorkflowStatus.RUNNING,
                priority=request.priority,
                input_parameters=request.input_parameters or {},
                output=None,
                progress_percentage=0.0,
                started_at=workflow.started_at,
                completed_at=None,
                duration_seconds=None,
                task_executions=[],
                metrics=self._create_execution_metrics(workflow),
                error_message=None,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            return execution_response
            
        except Exception as e:
            raise RuntimeError(f"Error executing workflow: {str(e)}")
    
    def perform_workflow_action(self, workflow_id: UUID, request: WorkflowActionRequest) -> WorkflowResponse:
        """Perform action on workflow"""
        try:
            # Find workflow
            workflow = self.workflow_repository.find_workflow_by_id(workflow_id)
            if not workflow:
                raise ValueError(f"Workflow with ID {workflow_id} not found")
            
            # Perform action
            if request.action == "pause":
                if workflow.status != WorkflowStatus.RUNNING:
                    raise ValueError("Can only pause running workflows")
                workflow.status = WorkflowStatus.PAUSED
                
            elif request.action == "resume":
                if workflow.status != WorkflowStatus.PAUSED:
                    raise ValueError("Can only resume paused workflows")
                workflow.status = WorkflowStatus.RUNNING
                
            elif request.action == "cancel":
                if workflow.status not in [WorkflowStatus.RUNNING, WorkflowStatus.PAUSED]:
                    raise ValueError("Can only cancel running or paused workflows")
                workflow.status = WorkflowStatus.CANCELLED
                workflow.completed_at = datetime.utcnow()
                if workflow.started_at:
                    workflow.duration_seconds = (workflow.completed_at - workflow.started_at).total_seconds()
                
            elif request.action == "restart":
                workflow.status = WorkflowStatus.PENDING
                workflow.started_at = None
                workflow.completed_at = None
                workflow.duration_seconds = None
                workflow.progress_percentage = 0.0
                
            else:
                raise ValueError(f"Unknown action: {request.action}")
            
            workflow.updated_at = datetime.utcnow()
            
            # Save updated workflow
            saved_workflow = self.workflow_repository.save_workflow(workflow)
            
            return self._entity_to_response(saved_workflow)
            
        except Exception as e:
            raise RuntimeError(f"Error performing workflow action: {str(e)}")
    
    def delete_workflow(self, workflow_id: UUID) -> bool:
        """Delete workflow"""
        try:
            # Find workflow
            workflow = self.workflow_repository.find_workflow_by_id(workflow_id)
            if not workflow:
                return False
            
            # Check if workflow is running
            if workflow.status == WorkflowStatus.RUNNING:
                raise ValueError("Cannot delete running workflow")
            
            return self.workflow_repository.delete_workflow(workflow_id)
            
        except Exception as e:
            raise RuntimeError(f"Error deleting workflow: {str(e)}")
    
    def get_workflow_statistics(self, organization_id: UUID) -> WorkflowStatisticsResponse:
        """Get workflow statistics"""
        try:
            stats = self.workflow_repository.get_workflow_statistics(organization_id)
            
            return WorkflowStatisticsResponse(
                organization_id=organization_id,
                total_workflows=stats['total_workflows'],
                active_workflows=stats['active_workflows'],
                total_executions=stats['total_executions'],
                successful_executions=stats['successful_executions'],
                failed_executions=stats['failed_executions'],
                avg_execution_time=stats['avg_execution_time'],
                workflows_by_type=stats['workflows_by_type'],
                workflows_by_status=stats['workflows_by_status'],
                executions_by_status={},  # Simplified
                success_rate=stats['success_rate'],
                most_used_workflows=stats['most_used_workflows'],
                recent_failures=stats['recent_failures']
            )
            
        except Exception as e:
            raise RuntimeError(f"Error getting workflow statistics: {str(e)}")
    
    def get_workflow_metrics(self, workflow_id: UUID) -> WorkflowMetricsResponse:
        """Get workflow metrics"""
        try:
            metrics = self.workflow_repository.get_workflow_metrics(workflow_id)
            
            if not metrics:
                raise ValueError(f"Workflow with ID {workflow_id} not found")
            
            return WorkflowMetricsResponse(
                workflow_id=workflow_id,
                execution_count=metrics['execution_count'],
                success_count=metrics['success_count'],
                failure_count=metrics['failure_count'],
                avg_duration=metrics['avg_duration'],
                min_duration=metrics['min_duration'],
                max_duration=metrics['max_duration'],
                success_rate=metrics['success_rate'],
                last_execution=metrics['last_execution'],
                next_execution=metrics['next_execution']
            )
            
        except Exception as e:
            raise RuntimeError(f"Error getting workflow metrics: {str(e)}")
    
    def get_workflow_health(self, workflow_id: UUID) -> WorkflowHealthResponse:
        """Get workflow health"""
        try:
            health = self.workflow_repository.get_workflow_health(workflow_id)
            
            if not health:
                raise ValueError(f"Workflow with ID {workflow_id} not found")
            
            return WorkflowHealthResponse(
                workflow_id=workflow_id,
                health_score=health['health_score'],
                issues=health['issues'],
                recommendations=health['recommendations'],
                last_check=health['last_check']
            )
            
        except Exception as e:
            raise RuntimeError(f"Error getting workflow health: {str(e)}")
    
    def validate_workflow(self, request: CreateWorkflowRequest) -> WorkflowValidationResponse:
        """Validate workflow configuration"""
        try:
            return self._validate_workflow_config(request.tasks, request.config)
            
        except Exception as e:
            return WorkflowValidationResponse(
                is_valid=False,
                errors=[f"Validation error: {str(e)}"],
                warnings=[],
                suggestions=[]
            )
    
    def _validate_workflow_config(self, tasks, config) -> WorkflowValidationResponse:
        """Validate workflow configuration"""
        errors = []
        warnings = []
        suggestions = []
        
        # Validate tasks
        if not tasks:
            errors.append("Workflow must have at least one task")
        
        task_names = [task.name for task in tasks]
        if len(task_names) != len(set(task_names)):
            errors.append("Task names must be unique")
        
        # Validate dependencies
        for task in tasks:
            if task.depends_on:
                for dep in task.depends_on:
                    if dep not in task_names:
                        errors.append(f"Task '{task.name}' depends on non-existent task '{dep}'")
        
        # Check for circular dependencies (simplified)
        # In real implementation, would use graph algorithms
        
        # Validate timeouts
        for task in tasks:
            if task.timeout_seconds and task.timeout_seconds > 86400:  # 24 hours
                warnings.append(f"Task '{task.name}' has very long timeout ({task.timeout_seconds}s)")
        
        # Validate config
        if config:
            if config.max_parallel_tasks > 50:
                warnings.append("High number of parallel tasks may impact performance")
            
            if config.timeout_minutes > 1440:  # 24 hours
                warnings.append("Very long workflow timeout")
        
        # Suggestions
        if len(tasks) > 20:
            suggestions.append("Consider breaking large workflows into smaller ones")
        
        if not any(task.task_type.value == "notification" for task in tasks):
            suggestions.append("Consider adding notification tasks for better monitoring")
        
        return WorkflowValidationResponse(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            suggestions=suggestions
        )
    
    def _process_tasks(self, tasks) -> List[Dict[str, Any]]:
        """Process and validate tasks"""
        processed_tasks = []
        
        for i, task in enumerate(tasks):
            processed_task = {
                "id": str(uuid4()),
                "name": task.name,
                "description": task.description,
                "task_type": task.task_type.value,
                "order_index": i,
                "parameters": task.parameters or {},
                "timeout_seconds": task.timeout_seconds,
                "retry_count": task.retry_count,
                "retry_delay_seconds": task.retry_delay_seconds,
                "depends_on": task.depends_on or [],
                "condition": task.condition,
                "parallel_group": task.parallel_group,
                "status": TaskStatus.PENDING.value,
                "started_at": None,
                "completed_at": None,
                "duration_seconds": None,
                "output": None,
                "error_message": None,
                "retry_attempts": 0
            }
            processed_tasks.append(processed_task)
        
        return processed_tasks
    
    def _calculate_next_execution(self, trigger_config) -> Optional[datetime]:
        """Calculate next execution time"""
        if not trigger_config or trigger_config.trigger_type.value != "scheduled":
            return None
        
        if not trigger_config.cron_expression:
            return None
        
        # Simplified cron parsing - in real implementation would use croniter
        # For now, just schedule for next hour
        return datetime.utcnow() + timedelta(hours=1)
    
    def _create_execution_metrics(self, workflow) -> Any:
        """Create execution metrics"""
        from ...application.dtos.workflow_dtos import WorkflowExecutionMetricsDTO
        
        total_tasks = len(workflow.tasks) if workflow.tasks else 0
        
        return WorkflowExecutionMetricsDTO(
            total_tasks=total_tasks,
            completed_tasks=0,
            failed_tasks=0,
            skipped_tasks=0,
            pending_tasks=total_tasks,
            success_rate=100.0,
            avg_task_duration=None,
            total_duration=None
        )
    
    def _entity_to_response(self, workflow: WorkflowEntity) -> WorkflowResponse:
        """Convert entity to response"""
        # Convert tasks to TaskResponse objects
        task_responses = []
        if workflow.tasks:
            for task_data in workflow.tasks:
                task_response = TaskResponse(
                    id=UUID(task_data['id']),
                    name=task_data['name'],
                    description=task_data.get('description'),
                    task_type=task_data['task_type'],
                    status=TaskStatus(task_data['status']),
                    workflow_id=workflow.id,
                    order_index=task_data['order_index'],
                    parameters=task_data.get('parameters'),
                    timeout_seconds=task_data.get('timeout_seconds'),
                    retry_count=task_data.get('retry_count', 0),
                    retry_delay_seconds=task_data.get('retry_delay_seconds', 30),
                    depends_on=task_data.get('depends_on'),
                    condition=task_data.get('condition'),
                    parallel_group=task_data.get('parallel_group'),
                    started_at=task_data.get('started_at'),
                    completed_at=task_data.get('completed_at'),
                    duration_seconds=task_data.get('duration_seconds'),
                    output=task_data.get('output'),
                    error_message=task_data.get('error_message'),
                    retry_attempts=task_data.get('retry_attempts', 0),
                    created_at=workflow.created_at,
                    updated_at=workflow.updated_at
                )
                task_responses.append(task_response)
        
        return WorkflowResponse(
            id=workflow.id,
            name=workflow.name,
            description=workflow.description,
            workflow_type=workflow.workflow_type,
            status=workflow.status,
            organization_id=workflow.organization_id,
            organization_name=workflow.organization_name,
            created_by=workflow.created_by,
            created_by_name=workflow.created_by_name,
            tasks=task_responses,
            config=workflow.config,
            trigger_config=workflow.trigger_config,
            variables=workflow.variables,
            tags=workflow.tags,
            priority=workflow.priority,
            progress_percentage=workflow.progress_percentage,
            started_at=workflow.started_at,
            completed_at=workflow.completed_at,
            duration_seconds=workflow.duration_seconds,
            next_execution=workflow.next_execution,
            execution_count=workflow.execution_count,
            success_count=workflow.success_count,
            failure_count=workflow.failure_count,
            enabled=workflow.enabled,
            created_at=workflow.created_at,
            updated_at=workflow.updated_at
        )

