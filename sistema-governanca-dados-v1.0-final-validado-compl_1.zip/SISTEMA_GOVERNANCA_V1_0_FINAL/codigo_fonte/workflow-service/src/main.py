# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
Workflow Service - Microserviço de Workflows e Processos
Versão: 4.0.1 - Corrigida com base na V3.2
Data: 27 de Janeiro de 2025
"""

import logging
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from uuid import uuid4
from enum import Enum

from fastapi import FastAPI, HTTPException, Query, Path, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'config'))

try:
    from settings import get_settings
    settings = get_settings()
except ImportError:
    print("⚠️ Configurações centralizadas não encontradas, usando valores padrão")
    settings = None


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Workflow Service",
    description="Microserviço para workflows e processos de aprovação - V4.0 Corrigido",
    version="4.0.1",
    contact={
        "name": " ",
        "email": "@example.com"
    }
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# ENUMS
# =====================================================

class WorkflowStatus(str, Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    INACTIVE = "inactive"
    ARCHIVED = "archived"

class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    REJECTED = "rejected"
    CANCELLED = "cancelled"

class TaskPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

class NotificationType(str, Enum):
    EML = "email"
    SLACK = "slack"
    WEBHOOK = "webhook"
    IN_APP = "in_app"

# =====================================================
# PYDANTIC MODELS
# =====================================================

class WorkflowBase(BaseModel):
    name: str = Field(..., description="Nome do workflow")
    description: Optional[str] = Field(None, description="Descrição do workflow")
    workflow_type: str = Field(..., description="Tipo do workflow")
    trigger_event: str = Field(..., description="Evento que dispara o workflow")
    auto_start: bool = Field(True, description="Iniciar automaticamente")

class WorkflowCreate(WorkflowBase):
    pass

class WorkflowUpdate(WorkflowBase):
    status: Optional[WorkflowStatus] = Field(None, description="Status do workflow")

class WorkflowResponse(WorkflowBase):
    id: str
    status: WorkflowStatus
    created_at: datetime
    updated_at: datetime
    created_by: str
    total_executions: int

class TaskBase(BaseModel):
    title: str = Field(..., description="Título da tarefa")
    description: Optional[str] = Field(None, description="Descrição da tarefa")
    task_type: str = Field(..., description="Tipo da tarefa")
    assignee: str = Field(..., description="Responsável pela tarefa")
    priority: TaskPriority = Field(TaskPriority.MEDIUM, description="Prioridade da tarefa")
    due_date: Optional[datetime] = Field(None, description="Data limite")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados adicionais")

class TaskCreate(TaskBase):
    workflow_id: str = Field(..., description="ID do workflow")

class TaskUpdate(BaseModel):
    status: Optional[TaskStatus] = Field(None, description="Status da tarefa")
    assignee: Optional[str] = Field(None, description="Novo responsável")
    priority: Optional[TaskPriority] = Field(None, description="Nova prioridade")
    due_date: Optional[datetime] = Field(None, description="Nova data limite")
    comments: Optional[str] = Field(None, description="Comentários")

class TaskResponse(TaskBase):
    id: str
    workflow_id: str
    status: TaskStatus
    created_at: datetime
    updated_at: datetime
    completed_at: Optional[datetime]
    comments: List[str]

class NotificationBase(BaseModel):
    recipient: str = Field(..., description="Destinatário da notificação")
    notification_type: NotificationType = Field(..., description="Tipo de notificação")
    subject: str = Field(..., description="Assunto da notificação")
    message: str = Field(..., description="Mensagem da notificação")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados adicionais")

class NotificationCreate(NotificationBase):
    task_id: Optional[str] = Field(None, description="ID da tarefa relacionada")
    workflow_id: Optional[str] = Field(None, description="ID do workflow relacionado")

class NotificationResponse(NotificationBase):
    id: str
    task_id: Optional[str]
    workflow_id: Optional[str]
    sent_at: Optional[datetime]
    is_read: bool
    created_at: datetime

class ApprovalRequest(BaseModel):
    task_id: str = Field(..., description="ID da tarefa")
    action: str = Field(..., description="Ação (approve/reject)")
    comments: Optional[str] = Field(None, description="Comentários da aprovação")

# =====================================================
# IN-MEMORY DATABASE (Simulação)
# =====================================================

workflows_db = {}
tasks_db = {}
notifications_db = {}
audit_logs = []

def log_audit(action: str, resource_id: str = None, details: str = None):
    """Log audit trail"""
    try:
        audit_logs.append({
            "id": str(uuid4()),
            "action": action,
            "resource_type": "workflow",
            "resource_id": resource_id,
            "details": details,
            "created_at": datetime.utcnow().isoformat()
        })
    except Exception as e:
        logger.error(f"Error logging audit: {e}")

def init_sample_data():
    """Initialize sample workflows, tasks and notifications"""
    # Sample workflows
    sample_workflows = [
        {
            "id": str(uuid4()),
            "name": "Contract Approval Workflow",
            "description": "Workflow para aprovação de contratos de dados",
            "workflow_type": "approval",
            "trigger_event": "contract_created",
            "auto_start": True,
            "status": WorkflowStatus.ACTIVE,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "created_by": "system",
            "total_executions": 15
        },
        {
            "id": str(uuid4()),
            "name": "Data Quality Review",
            "description": "Workflow para revisão de qualidade de dados",
            "workflow_type": "review",
            "trigger_event": "quality_issue_detected",
            "auto_start": True,
            "status": WorkflowStatus.ACTIVE,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "created_by": "data_team",
            "total_executions": 8
        },
        {
            "id": str(uuid4()),
            "name": "PII Detection Response",
            "description": "Workflow para resposta a detecção de PII",
            "workflow_type": "incident_response",
            "trigger_event": "pii_detected",
            "auto_start": True,
            "status": WorkflowStatus.ACTIVE,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "created_by": "privacy_team",
            "total_executions": 23
        },
        {
            "id": str(uuid4()),
            "name": "Monthly Compliance Report",
            "description": "Workflow para geração de relatório mensal de compliance",
            "workflow_type": "reporting",
            "trigger_event": "monthly_schedule",
            "auto_start": True,
            "status": WorkflowStatus.ACTIVE,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "created_by": "compliance_team",
            "total_executions": 3
        }
    ]
    
    for workflow in sample_workflows:
        workflows_db[workflow["id"]] = workflow
    
    # Sample tasks
    contract_workflow = sample_workflows[0]
    quality_workflow = sample_workflows[1]
    
    sample_tasks = [
        {
            "id": str(uuid4()),
            "workflow_id": contract_workflow["id"],
            "title": "Review Contract Terms",
            "description": "Revisar termos do contrato de dados de vendas",
            "task_type": "review",
            "assignee": "data_owner@empresa.com",
            "priority": TaskPriority.HIGH,
            "status": TaskStatus.PENDING,
            "due_date": datetime.utcnow() + timedelta(days=2),
            "metadata": {"contract_id": "contract_123", "department": "sales"},
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "completed_at": None,
            "comments": []
        },
        {
            "id": str(uuid4()),
            "workflow_id": contract_workflow["id"],
            "title": "Legal Approval",
            "description": "Aprovação jurídica do contrato",
            "task_type": "approval",
            "assignee": "legal@empresa.com",
            "priority": TaskPriority.MEDIUM,
            "status": TaskStatus.PENDING,
            "due_date": datetime.utcnow() + timedelta(days=5),
            "metadata": {"contract_id": "contract_123", "requires_signature": True},
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "completed_at": None,
            "comments": []
        },
        {
            "id": str(uuid4()),
            "workflow_id": quality_workflow["id"],
            "title": "Investigate Data Quality Issue",
            "description": "Investigar problema de qualidade na tabela customers",
            "task_type": "investigation",
            "assignee": "data_engineer@empresa.com",
            "priority": TaskPriority.URGENT,
            "status": TaskStatus.IN_PROGRESS,
            "due_date": datetime.utcnow() + timedelta(hours=4),
            "metadata": {"table": "customers", "issue_type": "completeness", "severity": "high"},
            "created_at": datetime.utcnow() - timedelta(hours=2),
            "updated_at": datetime.utcnow() - timedelta(minutes=30),
            "completed_at": None,
            "comments": ["Iniciando investigação", "Problema identificado na coluna email"]
        },
        {
            "id": str(uuid4()),
            "workflow_id": quality_workflow["id"],
            "title": "Fix Data Quality Issue",
            "description": "Corrigir problema de qualidade identificado",
            "task_type": "remediation",
            "assignee": "data_engineer@empresa.com",
            "priority": TaskPriority.HIGH,
            "status": TaskStatus.COMPLETED,
            "due_date": datetime.utcnow() - timedelta(hours=1),
            "metadata": {"table": "orders", "fix_applied": "data_validation_rule"},
            "created_at": datetime.utcnow() - timedelta(days=1),
            "updated_at": datetime.utcnow() - timedelta(hours=2),
            "completed_at": datetime.utcnow() - timedelta(hours=2),
            "comments": ["Regra de validação aplicada", "Problema resolvido"]
        }
    ]
    
    for task in sample_tasks:
        tasks_db[task["id"]] = task
    
    # Sample notifications
    sample_notifications = [
        {
            "id": str(uuid4()),
            "task_id": sample_tasks[0]["id"],
            "workflow_id": contract_workflow["id"],
            "recipient": "data_owner@empresa.com",
            "notification_type": NotificationType.EML,
            "subject": "Nova tarefa atribuída: Review Contract Terms",
            "message": "Você tem uma nova tarefa de alta prioridade para revisar termos de contrato.",
            "metadata": {"urgency": "high", "auto_generated": True},
            "sent_at": datetime.utcnow() - timedelta(minutes=30),
            "is_read": False,
            "created_at": datetime.utcnow() - timedelta(minutes=30)
        },
        {
            "id": str(uuid4()),
            "task_id": sample_tasks[2]["id"],
            "workflow_id": quality_workflow["id"],
            "recipient": "data_engineer@empresa.com",
            "notification_type": NotificationType.SLACK,
            "subject": "Tarefa urgente: Investigate Data Quality Issue",
            "message": "Problema crítico de qualidade detectado na tabela customers. Ação imediata necessária.",
            "metadata": {"channel": "#data-quality", "severity": "critical"},
            "sent_at": datetime.utcnow() - timedelta(hours=2),
            "is_read": True,
            "created_at": datetime.utcnow() - timedelta(hours=2)
        },
        {
            "id": str(uuid4()),
            "task_id": sample_tasks[3]["id"],
            "workflow_id": quality_workflow["id"],
            "recipient": "data_team@empresa.com",
            "notification_type": NotificationType.EML,
            "subject": "Tarefa concluída: Fix Data Quality Issue",
            "message": "Problema de qualidade na tabela orders foi resolvido com sucesso.",
            "metadata": {"completion_time": "2h", "success": True},
            "sent_at": datetime.utcnow() - timedelta(hours=2),
            "is_read": True,
            "created_at": datetime.utcnow() - timedelta(hours=2)
        }
    ]
    
    for notification in sample_notifications:
        notifications_db[notification["id"]] = notification
    
    logger.info(f"Initialized {len(sample_workflows)} workflows, {len(sample_tasks)} tasks, and {len(sample_notifications)} notifications")

def calculate_workflow_metrics(workflow_id: str) -> Dict[str, Any]:
    """Calculate metrics for a workflow"""
    workflow_tasks = [t for t in tasks_db.values() if t["workflow_id"] == workflow_id]
    
    if not workflow_tasks:
        return {
            "total_tasks": 0,
            "completed_tasks": 0,
            "pending_tasks": 0,
            "overdue_tasks": 0,
            "completion_rate": 0,
            "average_completion_time": 0
        }
    
    completed_tasks = [t for t in workflow_tasks if t["status"] == TaskStatus.COMPLETED]
    pending_tasks = [t for t in workflow_tasks if t["status"] == TaskStatus.PENDING]
    overdue_tasks = [t for t in pending_tasks if t["due_date"] and t["due_date"] < datetime.utcnow()]
    
    # Calculate average completion time
    completion_times = []
    for task in completed_tasks:
        if task["completed_at"] and task["created_at"]:
            completion_time = (task["completed_at"] - task["created_at"]).total_seconds() / 3600  # hours
            completion_times.append(completion_time)
    
    avg_completion_time = sum(completion_times) / len(completion_times) if completion_times else 0
    completion_rate = (len(completed_tasks) / len(workflow_tasks)) * 100 if workflow_tasks else 0
    
    return {
        "total_tasks": len(workflow_tasks),
        "completed_tasks": len(completed_tasks),
        "pending_tasks": len(pending_tasks),
        "overdue_tasks": len(overdue_tasks),
        "completion_rate": round(completion_rate, 2),
        "average_completion_time": round(avg_completion_time, 2)
    }

# =====================================================
# API ENDPOINTS
# =====================================================

@app.get("/", tags=["System"])
async def root():
    """Root endpoint with service information"""
    return {
        "service": "Workflow Service",
        "version": "4.0.1",
        "status": "running",
        "description": "Microserviço para workflows e processos de aprovação - Corrigido",
        "corrections_applied": [
            "Dependências estabilizadas",
            "Error handling robusto",
            "Logs estruturados",
            "In-memory database funcional"
        ],
        "endpoints": {
            "health": "/health",
            "docs": "/docs",
            "workflows": "/api/v1/workflows",
            "tasks": "/api/v1/tasks",
            "notifications": "/api/v1/notifications",
            "approvals": "/api/v1/approvals"
        }
    }

@app.get("/health", tags=["System"])
async def health_check():
    """Health check endpoint"""
    try:
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "version": "4.0.1",
            "service": "workflow-service",
            "port": 8006,
            "corrections_applied": True,
            "data_counts": {
                "workflows": len(workflows_db),
                "tasks": len(tasks_db),
                "notifications": len(notifications_db),
                "audit_logs": len(audit_logs)
            },
            "features": {
                "workflow_management": True,
                "task_management": True,
                "notification_system": True,
                "approval_process": True,
                "metrics_tracking": True,
                "audit_trail": True
            }
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "status": "unhealthy",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

@app.get("/api/v1/workflows", response_model=List[WorkflowResponse], tags=["Workflows"])
async def list_workflows(
    status: Optional[WorkflowStatus] = Query(None, description="Filtrar por status"),
    workflow_type: Optional[str] = Query(None, description="Filtrar por tipo"),
    created_by: Optional[str] = Query(None, description="Filtrar por criador"),
    limit: int = Query(100, description="Limite de resultados")
):
    """Listar todos os workflows"""
    try:
        workflows = list(workflows_db.values())
        
        # Apply filters
        if status:
            workflows = [w for w in workflows if w["status"] == status]
        
        if workflow_type:
            workflows = [w for w in workflows if w["workflow_type"] == workflow_type]
            
        if created_by:
            workflows = [w for w in workflows if w["created_by"] == created_by]
        
        # Apply limit
        workflows = workflows[:limit]
        
        # Convert datetime objects to ISO format
        for workflow in workflows:
            workflow["created_at"] = workflow["created_at"].isoformat()
            workflow["updated_at"] = workflow["updated_at"].isoformat()
        
        log_audit("list_workflows", details=f"Listed {len(workflows)} workflows")
        return workflows
        
    except Exception as e:
        logger.error(f"Error listing workflows: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing workflows: {str(e)}")

@app.get("/api/v1/workflows/{workflow_id}", response_model=WorkflowResponse, tags=["Workflows"])
async def get_workflow(workflow_id: str = Path(..., description="ID do workflow")):
    """Buscar workflow específico por ID"""
    try:
        if workflow_id not in workflows_db:
            raise HTTPException(status_code=404, detail="Workflow not found")
        
        workflow = workflows_db[workflow_id].copy()
        workflow["created_at"] = workflow["created_at"].isoformat()
        workflow["updated_at"] = workflow["updated_at"].isoformat()
        
        log_audit("get_workflow", resource_id=workflow_id)
        return workflow
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting workflow: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting workflow: {str(e)}")

@app.post("/api/v1/workflows", response_model=WorkflowResponse, tags=["Workflows"])
async def create_workflow(workflow: WorkflowCreate):
    """Criar novo workflow"""
    try:
        workflow_id = str(uuid4())
        now = datetime.utcnow()
        
        new_workflow = {
            "id": workflow_id,
            "name": workflow.name,
            "description": workflow.description,
            "workflow_type": workflow.workflow_type,
            "trigger_event": workflow.trigger_event,
            "auto_start": workflow.auto_start,
            "status": WorkflowStatus.DRAFT,
            "created_at": now,
            "updated_at": now,
            "created_by": "current_user",  # In real implementation, get from auth
            "total_executions": 0
        }
        
        workflows_db[workflow_id] = new_workflow
        
        log_audit("create_workflow", resource_id=workflow_id, details=f"Created workflow: {workflow.name}")
        
        # Convert datetime for response
        response_workflow = new_workflow.copy()
        response_workflow["created_at"] = response_workflow["created_at"].isoformat()
        response_workflow["updated_at"] = response_workflow["updated_at"].isoformat()
        
        return response_workflow
        
    except Exception as e:
        logger.error(f"Error creating workflow: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating workflow: {str(e)}")

@app.put("/api/v1/workflows/{workflow_id}", response_model=WorkflowResponse, tags=["Workflows"])
async def update_workflow(workflow_id: str, workflow: WorkflowUpdate):
    """Atualizar workflow existente"""
    try:
        if workflow_id not in workflows_db:
            raise HTTPException(status_code=404, detail="Workflow not found")
        
        existing_workflow = workflows_db[workflow_id]
        
        # Update fields
        existing_workflow.update({
            "name": workflow.name,
            "description": workflow.description,
            "workflow_type": workflow.workflow_type,
            "trigger_event": workflow.trigger_event,
            "auto_start": workflow.auto_start,
            "updated_at": datetime.utcnow()
        })
        
        if workflow.status:
            existing_workflow["status"] = workflow.status
        
        log_audit("update_workflow", resource_id=workflow_id, details=f"Updated workflow: {workflow.name}")
        
        # Convert datetime for response
        response_workflow = existing_workflow.copy()
        response_workflow["created_at"] = response_workflow["created_at"].isoformat()
        response_workflow["updated_at"] = response_workflow["updated_at"].isoformat()
        
        return response_workflow
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating workflow: {e}")
        raise HTTPException(status_code=500, detail=f"Error updating workflow: {str(e)}")

@app.get("/api/v1/workflows/{workflow_id}/metrics", tags=["Workflows"])
async def get_workflow_metrics(workflow_id: str):
    """Obter métricas de um workflow"""
    try:
        if workflow_id not in workflows_db:
            raise HTTPException(status_code=404, detail="Workflow not found")
        
        metrics = calculate_workflow_metrics(workflow_id)
        workflow = workflows_db[workflow_id]
        
        log_audit("get_workflow_metrics", resource_id=workflow_id)
        
        return {
            "workflow_id": workflow_id,
            "workflow_name": workflow["name"],
            "metrics": metrics,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting workflow metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting workflow metrics: {str(e)}")

@app.get("/api/v1/tasks", response_model=List[TaskResponse], tags=["Tasks"])
async def list_tasks(
    workflow_id: Optional[str] = Query(None, description="Filtrar por workflow"),
    status: Optional[TaskStatus] = Query(None, description="Filtrar por status"),
    assignee: Optional[str] = Query(None, description="Filtrar por responsável"),
    priority: Optional[TaskPriority] = Query(None, description="Filtrar por prioridade"),
    overdue_only: bool = Query(False, description="Apenas tarefas em atraso"),
    limit: int = Query(100, description="Limite de resultados")
):
    """Listar todas as tarefas"""
    try:
        tasks = list(tasks_db.values())
        
        # Apply filters
        if workflow_id:
            tasks = [t for t in tasks if t["workflow_id"] == workflow_id]
        
        if status:
            tasks = [t for t in tasks if t["status"] == status]
            
        if assignee:
            tasks = [t for t in tasks if t["assignee"] == assignee]
            
        if priority:
            tasks = [t for t in tasks if t["priority"] == priority]
            
        if overdue_only:
            now = datetime.utcnow()
            tasks = [t for t in tasks if t["due_date"] and t["due_date"] < now and t["status"] != TaskStatus.COMPLETED]
        
        # Sort by priority and due date
        priority_order = {TaskPriority.URGENT: 4, TaskPriority.HIGH: 3, TaskPriority.MEDIUM: 2, TaskPriority.LOW: 1}
        tasks.sort(key=lambda x: (priority_order.get(x["priority"], 0), x["due_date"] or datetime.max), reverse=True)
        
        # Apply limit
        tasks = tasks[:limit]
        
        # Convert datetime objects to ISO format
        for task in tasks:
            task["created_at"] = task["created_at"].isoformat()
            task["updated_at"] = task["updated_at"].isoformat()
            if task["due_date"]:
                task["due_date"] = task["due_date"].isoformat()
            if task["completed_at"]:
                task["completed_at"] = task["completed_at"].isoformat()
        
        log_audit("list_tasks", details=f"Listed {len(tasks)} tasks")
        return tasks
        
    except Exception as e:
        logger.error(f"Error listing tasks: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing tasks: {str(e)}")

@app.get("/api/v1/tasks/{task_id}", response_model=TaskResponse, tags=["Tasks"])
async def get_task(task_id: str = Path(..., description="ID da tarefa")):
    """Buscar tarefa específica por ID"""
    try:
        if task_id not in tasks_db:
            raise HTTPException(status_code=404, detail="Task not found")
        
        task = tasks_db[task_id].copy()
        task["created_at"] = task["created_at"].isoformat()
        task["updated_at"] = task["updated_at"].isoformat()
        if task["due_date"]:
            task["due_date"] = task["due_date"].isoformat()
        if task["completed_at"]:
            task["completed_at"] = task["completed_at"].isoformat()
        
        log_audit("get_task", resource_id=task_id)
        return task
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting task: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting task: {str(e)}")

@app.post("/api/v1/tasks", response_model=TaskResponse, tags=["Tasks"])
async def create_task(task: TaskCreate):
    """Criar nova tarefa"""
    try:
        if task.workflow_id not in workflows_db:
            raise HTTPException(status_code=404, detail="Workflow not found")
        
        task_id = str(uuid4())
        now = datetime.utcnow()
        
        new_task = {
            "id": task_id,
            "workflow_id": task.workflow_id,
            "title": task.title,
            "description": task.description,
            "task_type": task.task_type,
            "assignee": task.assignee,
            "priority": task.priority,
            "status": TaskStatus.PENDING,
            "due_date": task.due_date,
            "metadata": task.metadata or {},
            "created_at": now,
            "updated_at": now,
            "completed_at": None,
            "comments": []
        }
        
        tasks_db[task_id] = new_task
        
        log_audit("create_task", resource_id=task_id, details=f"Created task: {task.title}")
        
        # Convert datetime for response
        response_task = new_task.copy()
        response_task["created_at"] = response_task["created_at"].isoformat()
        response_task["updated_at"] = response_task["updated_at"].isoformat()
        if response_task["due_date"]:
            response_task["due_date"] = response_task["due_date"].isoformat()
        
        return response_task
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating task: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating task: {str(e)}")

@app.put("/api/v1/tasks/{task_id}", response_model=TaskResponse, tags=["Tasks"])
async def update_task(task_id: str, task_update: TaskUpdate):
    """Atualizar tarefa existente"""
    try:
        if task_id not in tasks_db:
            raise HTTPException(status_code=404, detail="Task not found")
        
        existing_task = tasks_db[task_id]
        now = datetime.utcnow()
        
        # Update fields
        if task_update.status:
            existing_task["status"] = task_update.status
            if task_update.status == TaskStatus.COMPLETED:
                existing_task["completed_at"] = now
        
        if task_update.assignee:
            existing_task["assignee"] = task_update.assignee
            
        if task_update.priority:
            existing_task["priority"] = task_update.priority
            
        if task_update.due_date:
            existing_task["due_date"] = task_update.due_date
            
        if task_update.comments:
            existing_task["comments"].append(f"{now.isoformat()}: {task_update.comments}")
        
        existing_task["updated_at"] = now
        
        log_audit("update_task", resource_id=task_id, details=f"Updated task: {existing_task['title']}")
        
        # Convert datetime for response
        response_task = existing_task.copy()
        response_task["created_at"] = response_task["created_at"].isoformat()
        response_task["updated_at"] = response_task["updated_at"].isoformat()
        if response_task["due_date"]:
            response_task["due_date"] = response_task["due_date"].isoformat()
        if response_task["completed_at"]:
            response_task["completed_at"] = response_task["completed_at"].isoformat()
        
        return response_task
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating task: {e}")
        raise HTTPException(status_code=500, detail=f"Error updating task: {str(e)}")

@app.post("/api/v1/approvals", tags=["Approvals"])
async def process_approval(approval: ApprovalRequest):
    """Processar aprovação de tarefa"""
    try:
        if approval.task_id not in tasks_db:
            raise HTTPException(status_code=404, detail="Task not found")
        
        task = tasks_db[approval.task_id]
        now = datetime.utcnow()
        
        if approval.action.lower() == "approve":
            task["status"] = TaskStatus.COMPLETED
            task["completed_at"] = now
            result = "approved"
        elif approval.action.lower() == "reject":
            task["status"] = TaskStatus.REJECTED
            result = "rejected"
        else:
            raise HTTPException(status_code=400, detail="Invalid action. Use 'approve' or 'reject'")
        
        if approval.comments:
            task["comments"].append(f"{now.isoformat()}: {approval.comments}")
        
        task["updated_at"] = now
        
        log_audit("process_approval", resource_id=approval.task_id, 
                 details=f"Task {result}: {task['title']}")
        
        return {
            "task_id": approval.task_id,
            "action": approval.action,
            "result": result,
            "timestamp": now.isoformat(),
            "comments": approval.comments
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing approval: {e}")
        raise HTTPException(status_code=500, detail=f"Error processing approval: {str(e)}")

@app.get("/api/v1/notifications", response_model=List[NotificationResponse], tags=["Notifications"])
async def list_notifications(
    recipient: Optional[str] = Query(None, description="Filtrar por destinatário"),
    notification_type: Optional[NotificationType] = Query(None, description="Filtrar por tipo"),
    is_read: Optional[bool] = Query(None, description="Filtrar por lidas/não lidas"),
    limit: int = Query(100, description="Limite de resultados")
):
    """Listar notificações"""
    try:
        notifications = list(notifications_db.values())
        
        # Apply filters
        if recipient:
            notifications = [n for n in notifications if n["recipient"] == recipient]
        
        if notification_type:
            notifications = [n for n in notifications if n["notification_type"] == notification_type]
            
        if is_read is not None:
            notifications = [n for n in notifications if n["is_read"] == is_read]
        
        # Sort by created_at (newest first)
        notifications.sort(key=lambda x: x["created_at"], reverse=True)
        
        # Apply limit
        notifications = notifications[:limit]
        
        # Convert datetime objects to ISO format
        for notification in notifications:
            notification["created_at"] = notification["created_at"].isoformat()
            if notification["sent_at"]:
                notification["sent_at"] = notification["sent_at"].isoformat()
        
        log_audit("list_notifications", details=f"Listed {len(notifications)} notifications")
        return notifications
        
    except Exception as e:
        logger.error(f"Error listing notifications: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing notifications: {str(e)}")

@app.post("/api/v1/notifications", response_model=NotificationResponse, tags=["Notifications"])
async def create_notification(notification: NotificationCreate):
    """Criar nova notificação"""
    try:
        notification_id = str(uuid4())
        now = datetime.utcnow()
        
        new_notification = {
            "id": notification_id,
            "task_id": notification.task_id,
            "workflow_id": notification.workflow_id,
            "recipient": notification.recipient,
            "notification_type": notification.notification_type,
            "subject": notification.subject,
            "message": notification.message,
            "metadata": notification.metadata or {},
            "sent_at": now,  # In real implementation, this would be set when actually sent
            "is_read": False,
            "created_at": now
        }
        
        notifications_db[notification_id] = new_notification
        
        log_audit("create_notification", resource_id=notification_id, 
                 details=f"Created notification for: {notification.recipient}")
        
        # Convert datetime for response
        response_notification = new_notification.copy()
        response_notification["created_at"] = response_notification["created_at"].isoformat()
        response_notification["sent_at"] = response_notification["sent_at"].isoformat()
        
        return response_notification
        
    except Exception as e:
        logger.error(f"Error creating notification: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating notification: {str(e)}")

@app.put("/api/v1/notifications/{notification_id}/read", tags=["Notifications"])
async def mark_notification_read(notification_id: str):
    """Marcar notificação como lida"""
    try:
        if notification_id not in notifications_db:
            raise HTTPException(status_code=404, detail="Notification not found")
        
        notification = notifications_db[notification_id]
        notification["is_read"] = True
        
        log_audit("mark_read", resource_id=notification_id, details="Marked notification as read")
        
        return {
            "notification_id": notification_id,
            "is_read": True,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error marking notification as read: {e}")
        raise HTTPException(status_code=500, detail=f"Error marking notification as read: {str(e)}")

@app.get("/api/v1/dashboard", tags=["Dashboard"])
async def get_workflow_dashboard():
    """Obter dashboard de workflows"""
    try:
        # Calculate overall statistics
        total_workflows = len(workflows_db)
        active_workflows = len([w for w in workflows_db.values() if w["status"] == WorkflowStatus.ACTIVE])
        total_tasks = len(tasks_db)
        pending_tasks = len([t for t in tasks_db.values() if t["status"] == TaskStatus.PENDING])
        overdue_tasks = len([t for t in tasks_db.values() 
                           if t["status"] == TaskStatus.PENDING and t["due_date"] and t["due_date"] < datetime.utcnow()])
        
        # Task status breakdown
        task_status_counts = {}
        for task in tasks_db.values():
            status = task["status"]
            task_status_counts[status] = task_status_counts.get(status, 0) + 1
        
        # Priority breakdown
        priority_counts = {}
        for task in tasks_db.values():
            if task["status"] == TaskStatus.PENDING:
                priority = task["priority"]
                priority_counts[priority] = priority_counts.get(priority, 0) + 1
        
        # Recent activity (last 24 hours)
        recent_cutoff = datetime.utcnow() - timedelta(hours=24)
        recent_tasks = len([t for t in tasks_db.values() if t["created_at"] >= recent_cutoff])
        recent_completions = len([t for t in tasks_db.values() 
                                if t["completed_at"] and t["completed_at"] >= recent_cutoff])
        
        # Top workflows by task count
        workflow_task_counts = {}
        for task in tasks_db.values():
            workflow_id = task["workflow_id"]
            workflow_task_counts[workflow_id] = workflow_task_counts.get(workflow_id, 0) + 1
        
        top_workflows = []
        for workflow_id, task_count in sorted(workflow_task_counts.items(), key=lambda x: x[1], reverse=True)[:5]:
            if workflow_id in workflows_db:
                workflow = workflows_db[workflow_id]
                metrics = calculate_workflow_metrics(workflow_id)
                top_workflows.append({
                    "workflow_id": workflow_id,
                    "name": workflow["name"],
                    "task_count": task_count,
                    "completion_rate": metrics["completion_rate"]
                })
        
        return {
            "summary": {
                "total_workflows": total_workflows,
                "active_workflows": active_workflows,
                "total_tasks": total_tasks,
                "pending_tasks": pending_tasks,
                "overdue_tasks": overdue_tasks,
                "recent_tasks_24h": recent_tasks,
                "recent_completions_24h": recent_completions
            },
            "task_status_breakdown": task_status_counts,
            "pending_priority_breakdown": priority_counts,
            "top_workflows": top_workflows,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting workflow dashboard: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting workflow dashboard: {str(e)}")

@app.get("/api/v1/audit/logs", tags=["Audit"])
async def list_audit_logs(limit: int = Query(100, description="Limite de resultados")):
    """Listar logs de auditoria"""
    try:
        logs = audit_logs[-limit:] if limit < len(audit_logs) else audit_logs
        return logs
    except Exception as e:
        logger.error(f"Error listing audit logs: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing audit logs: {str(e)}")

# Initialize sample data on startup
@app.on_event("startup")
async def startup_event():
    """Initialize service on startup"""
    logger.info("Starting Workflow Service V4.0.1 - Corrigido")
    init_sample_data()
    logger.info("Workflow Service started successfully")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8010)

