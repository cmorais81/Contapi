# Autor: carlos.morais@f1rst.com.br
"""
Workflow Domain Entity
Core business entity for workflow orchestration and automation
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Union
from uuid import UUID, uuid4
from enum import Enum
import json

from ..value_objects.workflow_status import WorkflowStatus
from ..value_objects.task_definition import TaskDefinition, TaskType
from ..events.workflow_events import (
    WorkflowCreated, WorkflowStarted, WorkflowCompleted,
    WorkflowFailed, TaskStarted, TaskCompleted, TaskFailed
)


class WorkflowType(Enum):
    """Types of workflows"""
    CONTRACT_APPROVAL = "contract_approval"
    DATA_QUALITY_CHECK = "data_quality_check"
    COMPLNCE_AUDIT = "compliance_audit"
    DATA_MIGRATION = "data_migration"
    SCHEMA_EVOLUTION = "schema_evolution"
    REPORT_GENERATION = "report_generation"
    DATA_LINEAGE_UPDATE = "data_lineage_update"
    PII_DETECTION = "pii_detection"
    CUSTOM = "custom"


class ExecutionMode(Enum):
    """Workflow execution modes"""
    SEQUENTL = "sequential"
    PARALLEL = "parallel"
    CONDITIONAL = "conditional"
    HYBRID = "hybrid"


@dataclass
class Workflow:
    """
    Workflow aggregate root for orchestrating governance processes
    """
    # Identity
    id: UUID = field(default_factory=uuid4)
    name: str = ""
    display_name: str = ""
    description: Optional[str] = None
    version: str = "1.0.0"
    
    # Workflow configuration
    workflow_type: WorkflowType = field(default=WorkflowType.CUSTOM)
    execution_mode: ExecutionMode = field(default=ExecutionMode.SEQUENTL)
    
    # Tasks and flow
    tasks: List[TaskDefinition] = field(default_factory=list)
    task_dependencies: Dict[str, List[str]] = field(default_factory=dict)
    conditional_logic: Dict[str, Any] = field(default_factory=dict)
    
    # Execution configuration
    timeout_minutes: int = 60
    retry_policy: Dict[str, Any] = field(default_factory=dict)
    error_handling: Dict[str, Any] = field(default_factory=dict)
    
    # Triggers
    trigger_type: str = "manual"  # manual, scheduled, event
    trigger_config: Dict[str, Any] = field(default_factory=dict)
    schedule_expression: Optional[str] = None
    
    # Status and lifecycle
    status: WorkflowStatus = field(default=WorkflowStatus.DRAFT)
    is_active: bool = False
    is_template: bool = False
    
    # Ownership
    owner_id: UUID = field(default_factory=uuid4)
    organization_id: UUID = field(default_factory=uuid4)
    
    # Execution history
    execution_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    last_execution_at: Optional[datetime] = None
    last_execution_status: Optional[str] = None
    average_execution_time_minutes: float = 0.0
    
    # Input/Output schema
    input_schema: Dict[str, Any] = field(default_factory=dict)
    output_schema: Dict[str, Any] = field(default_factory=dict)
    
    # Notifications
    notification_config: Dict[str, Any] = field(default_factory=dict)
    alert_on_failure: bool = True
    alert_recipients: List[str] = field(default_factory=list)
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    business_context: Optional[str] = None
    
    # Audit fields
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    created_by: UUID = field(default_factory=uuid4)
    updated_by: UUID = field(default_factory=uuid4)
    deleted_at: Optional[datetime] = None
    
    # Domain events
    _domain_events: List[Any] = field(default_factory=list, init=False)
    
    def __post_init__(self):
        """Post-initialization validation and setup"""
        if not self.name:
            raise ValueError("Workflow name is required")
        
        if not self.display_name:
            self.display_name = self.name.replace('_', ' ').title()
        
        # Initialize default retry policy
        if not self.retry_policy:
            self.retry_policy = {
                "max_attempts": 3,
                "retry_delay_seconds": 60,
                "exponential_backoff": True
            }
        
        # Initialize default error handling
        if not self.error_handling:
            self.error_handling = {
                "on_task_failure": "stop",  # stop, continue, retry
                "on_timeout": "fail",
                "cleanup_on_failure": True
            }
    
    def create(self, created_by: UUID) -> None:
        """Create a new workflow"""
        if self.status != WorkflowStatus.DRAFT:
            raise ValueError("Can only create workflows in draft status")
        
        self.created_by = created_by
        self.updated_by = created_by
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
        
        # Validate workflow definition
        if not self._validate_workflow():
            raise ValueError("Workflow validation failed")
        
        # Raise domain event
        self._add_domain_event(WorkflowCreated(
            workflow_id=self.id,
            name=self.name,
            workflow_type=self.workflow_type.value,
            owner_id=self.owner_id,
            created_by=created_by,
            occurred_at=datetime.utcnow()
        ))
    
    def update(self, updated_by: UUID, **kwargs) -> None:
        """Update workflow configuration"""
        if self.status == WorkflowStatus.RUNNING:
            raise ValueError("Cannot update running workflow")
        
        old_values = {}
        for key, value in kwargs.items():
            if hasattr(self, key):
                old_values[key] = getattr(self, key)
                setattr(self, key, value)
        
        self.updated_by = updated_by
        self.updated_at = datetime.utcnow()
        
        # Re-validate if critical fields changed
        if any(key in kwargs for key in ['tasks', 'task_dependencies', 'execution_mode']):
            if not self._validate_workflow():
                raise ValueError("Workflow validation failed after update")
    
    def activate(self, activated_by: UUID) -> None:
        """Activate workflow for execution"""
        if self.status == WorkflowStatus.ACTIVE:
            return  # Already active
        
        if not self._validate_workflow():
            raise ValueError("Cannot activate invalid workflow")
        
        self.status = WorkflowStatus.ACTIVE
        self.is_active = True
        self.updated_by = activated_by
        self.updated_at = datetime.utcnow()
    
    def deactivate(self, deactivated_by: UUID) -> None:
        """Deactivate workflow"""
        if self.status == WorkflowStatus.RUNNING:
            raise ValueError("Cannot deactivate running workflow")
        
        self.status = WorkflowStatus.INACTIVE
        self.is_active = False
        self.updated_by = deactivated_by
        self.updated_at = datetime.utcnow()
    
    def start_execution(self, started_by: UUID, input_data: Dict[str, Any]) -> 'WorkflowExecution':
        """Start workflow execution"""
        if not self.is_active:
            raise ValueError("Cannot execute inactive workflow")
        
        if self.status == WorkflowStatus.RUNNING:
            raise ValueError("Workflow is already running")
        
        # Validate input data
        if not self._validate_input(input_data):
            raise ValueError("Invalid input data")
        
        execution_id = uuid4()
        started_at = datetime.utcnow()
        
        # Update workflow status
        self.status = WorkflowStatus.RUNNING
        self.execution_count += 1
        self.last_execution_at = started_at
        self.updated_by = started_by
        self.updated_at = datetime.utcnow()
        
        # Create execution instance
        execution = WorkflowExecution(
            execution_id=execution_id,
            workflow_id=self.id,
            started_by=started_by,
            started_at=started_at,
            input_data=input_data,
            status="running"
        )
        
        # Raise domain event
        self._add_domain_event(WorkflowStarted(
            workflow_id=self.id,
            execution_id=execution_id,
            started_by=started_by,
            input_data=input_data,
            occurred_at=started_at
        ))
        
        return execution
    
    def complete_execution(self, execution_id: UUID, output_data: Dict[str, Any], execution_time_minutes: float) -> None:
        """Complete workflow execution"""
        self.status = WorkflowStatus.ACTIVE
        self.success_count += 1
        self.last_execution_status = "completed"
        
        # Update average execution time
        if self.average_execution_time_minutes == 0:
            self.average_execution_time_minutes = execution_time_minutes
        else:
            self.average_execution_time_minutes = (
                (self.average_execution_time_minutes * (self.success_count - 1) + execution_time_minutes) / 
                self.success_count
            )
        
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(WorkflowCompleted(
            workflow_id=self.id,
            execution_id=execution_id,
            output_data=output_data,
            execution_time_minutes=execution_time_minutes,
            occurred_at=datetime.utcnow()
        ))
    
    def fail_execution(self, execution_id: UUID, error_message: str) -> None:
        """Fail workflow execution"""
        self.status = WorkflowStatus.ACTIVE
        self.failure_count += 1
        self.last_execution_status = "failed"
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(WorkflowFailed(
            workflow_id=self.id,
            execution_id=execution_id,
            error_message=error_message,
            occurred_at=datetime.utcnow()
        ))
    
    def add_task(self, task: TaskDefinition) -> None:
        """Add task to workflow"""
        if task.id not in [t.id for t in self.tasks]:
            self.tasks.append(task)
            self.updated_at = datetime.utcnow()
    
    def remove_task(self, task_id: str) -> None:
        """Remove task from workflow"""
        self.tasks = [t for t in self.tasks if t.id != task_id]
        
        # Remove dependencies
        if task_id in self.task_dependencies:
            del self.task_dependencies[task_id]
        
        # Remove from other task dependencies
        for deps in self.task_dependencies.values():
            if task_id in deps:
                deps.remove(task_id)
        
        self.updated_at = datetime.utcnow()
    
    def add_dependency(self, task_id: str, depends_on: str) -> None:
        """Add task dependency"""
        if task_id not in self.task_dependencies:
            self.task_dependencies[task_id] = []
        
        if depends_on not in self.task_dependencies[task_id]:
            self.task_dependencies[task_id].append(depends_on)
            self.updated_at = datetime.utcnow()
    
    def get_task_execution_order(self) -> List[List[str]]:
        """Get task execution order based on dependencies"""
        if self.execution_mode == ExecutionMode.SEQUENTL:
            return [[task.id] for task in self.tasks]
        
        # Topological sort for dependency resolution
        return self._topological_sort()
    
    def get_success_rate(self) -> float:
        """Calculate workflow success rate"""
        if self.execution_count == 0:
            return 0.0
        return self.success_count / self.execution_count
    
    def is_healthy(self) -> bool:
        """Check if workflow is healthy"""
        return self.get_success_rate() >= 0.8
    
    def needs_attention(self) -> bool:
        """Check if workflow needs attention"""
        # Check success rate
        if self.get_success_rate() < 0.5:
            return True
        
        # Check if execution time is increasing
        if self.average_execution_time_minutes > self.timeout_minutes * 0.8:
            return True
        
        return False
    
    def create_template(self, template_name: str, created_by: UUID) -> 'Workflow':
        """Create template from this workflow"""
        template = Workflow(
            name=template_name,
            display_name=f"{template_name} Template",
            description=f"Template based on {self.name}",
            workflow_type=self.workflow_type,
            execution_mode=self.execution_mode,
            tasks=self.tasks.copy(),
            task_dependencies=self.task_dependencies.copy(),
            timeout_minutes=self.timeout_minutes,
            retry_policy=self.retry_policy.copy(),
            error_handling=self.error_handling.copy(),
            input_schema=self.input_schema.copy(),
            output_schema=self.output_schema.copy(),
            is_template=True,
            owner_id=self.owner_id,
            organization_id=self.organization_id,
            created_by=created_by,
            updated_by=created_by
        )
        
        return template
    
    def get_domain_events(self) -> List[Any]:
        """Get and clear domain events"""
        events = self._domain_events.copy()
        self._domain_events.clear()
        return events
    
    def _add_domain_event(self, event: Any) -> None:
        """Add a domain event"""
        self._domain_events.append(event)
    
    def _validate_workflow(self) -> bool:
        """Validate workflow configuration"""
        # Must have at least one task
        if not self.tasks:
            return False
        
        # All task IDs must be unique
        task_ids = [task.id for task in self.tasks]
        if len(task_ids) != len(set(task_ids)):
            return False
        
        # Dependencies must reference existing tasks
        all_task_ids = set(task_ids)
        for task_id, deps in self.task_dependencies.items():
            if task_id not in all_task_ids:
                return False
            for dep in deps:
                if dep not in all_task_ids:
                    return False
        
        # Check for circular dependencies
        if self._has_circular_dependencies():
            return False
        
        return True
    
    def _validate_input(self, input_data: Dict[str, Any]) -> bool:
        """Validate input data against schema"""
        if not self.input_schema:
            return True  # No schema to validate against
        
        # Simple validation - in real implementation would use JSON schema
        required_fields = self.input_schema.get('required', [])
        for field in required_fields:
            if field not in input_data:
                return False
        
        return True
    
    def _has_circular_dependencies(self) -> bool:
        """Check for circular dependencies"""
        visited = set()
        rec_stack = set()
        
        def has_cycle(task_id: str) -> bool:
            visited.add(task_id)
            rec_stack.add(task_id)
            
            for dep in self.task_dependencies.get(task_id, []):
                if dep not in visited:
                    if has_cycle(dep):
                        return True
                elif dep in rec_stack:
                    return True
            
            rec_stack.remove(task_id)
            return False
        
        for task in self.tasks:
            if task.id not in visited:
                if has_cycle(task.id):
                    return True
        
        return False
    
    def _topological_sort(self) -> List[List[str]]:
        """Perform topological sort for task execution order"""
        # Simple implementation - returns tasks that can run in parallel
        in_degree = {}
        
        # Initialize in-degree
        for task in self.tasks:
            in_degree[task.id] = 0
        
        # Calculate in-degree
        for task_id, deps in self.task_dependencies.items():
            in_degree[task_id] = len(deps)
        
        result = []
        queue = [task_id for task_id, degree in in_degree.items() if degree == 0]
        
        while queue:
            current_level = queue.copy()
            queue.clear()
            result.append(current_level)
            
            for task_id in current_level:
                # Reduce in-degree for dependent tasks
                for other_task_id, deps in self.task_dependencies.items():
                    if task_id in deps:
                        in_degree[other_task_id] -= 1
                        if in_degree[other_task_id] == 0:
                            queue.append(other_task_id)
        
        return result


@dataclass
class WorkflowExecution:
    """Represents a workflow execution instance"""
    execution_id: UUID = field(default_factory=uuid4)
    workflow_id: UUID = field(default_factory=uuid4)
    
    # Execution details
    started_by: UUID = field(default_factory=uuid4)
    started_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    
    # Status
    status: str = "running"  # running, completed, failed, cancelled
    current_task_id: Optional[str] = None
    progress_percentage: float = 0.0
    
    # Data
    input_data: Dict[str, Any] = field(default_factory=dict)
    output_data: Dict[str, Any] = field(default_factory=dict)
    context_data: Dict[str, Any] = field(default_factory=dict)
    
    # Task executions
    task_executions: List['TaskExecution'] = field(default_factory=list)
    
    # Error handling
    error_message: Optional[str] = None
    failed_task_id: Optional[str] = None
    retry_count: int = 0
    
    def add_task_execution(self, task_execution: 'TaskExecution') -> None:
        """Add task execution to workflow execution"""
        self.task_executions.append(task_execution)
        self.current_task_id = task_execution.task_id
        
        # Update progress
        completed_tasks = len([te for te in self.task_executions if te.status == "completed"])
        total_tasks = len(self.task_executions) + 1  # Estimate
        self.progress_percentage = (completed_tasks / total_tasks) * 100
    
    def complete(self, output_data: Dict[str, Any]) -> None:
        """Complete workflow execution"""
        self.status = "completed"
        self.completed_at = datetime.utcnow()
        self.output_data = output_data
        self.progress_percentage = 100.0
        self.current_task_id = None
    
    def fail(self, error_message: str, failed_task_id: Optional[str] = None) -> None:
        """Fail workflow execution"""
        self.status = "failed"
        self.completed_at = datetime.utcnow()
        self.error_message = error_message
        self.failed_task_id = failed_task_id
        self.current_task_id = None
    
    def get_execution_time_minutes(self) -> float:
        """Get execution time in minutes"""
        if not self.completed_at:
            end_time = datetime.utcnow()
        else:
            end_time = self.completed_at
        
        return (end_time - self.started_at).total_seconds() / 60
    
    def is_completed(self) -> bool:
        """Check if execution is completed"""
        return self.status in ['completed', 'failed', 'cancelled']


@dataclass
class TaskExecution:
    """Represents a task execution within a workflow"""
    execution_id: UUID = field(default_factory=uuid4)
    task_id: str = ""
    workflow_execution_id: UUID = field(default_factory=uuid4)
    
    # Timing
    started_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    
    # Status
    status: str = "running"  # running, completed, failed, skipped
    
    # Data
    input_data: Dict[str, Any] = field(default_factory=dict)
    output_data: Dict[str, Any] = field(default_factory=dict)
    
    # Error handling
    error_message: Optional[str] = None
    retry_count: int = 0
    
    def complete(self, output_data: Dict[str, Any]) -> None:
        """Complete task execution"""
        self.status = "completed"
        self.completed_at = datetime.utcnow()
        self.output_data = output_data
    
    def fail(self, error_message: str) -> None:
        """Fail task execution"""
        self.status = "failed"
        self.completed_at = datetime.utcnow()
        self.error_message = error_message
    
    def get_execution_time_seconds(self) -> float:
        """Get execution time in seconds"""
        if not self.completed_at:
            end_time = datetime.utcnow()
        else:
            end_time = self.completed_at
        
        return (end_time - self.started_at).total_seconds()


@dataclass
class WorkflowTemplate:
    """Template for creating workflows"""
    id: UUID = field(default_factory=uuid4)
    name: str = ""
    description: str = ""
    workflow_type: WorkflowType = field(default=WorkflowType.CUSTOM)
    
    # Template definition
    task_templates: List[Dict[str, Any]] = field(default_factory=list)
    default_config: Dict[str, Any] = field(default_factory=dict)
    
    # Metadata
    category: str = "general"
    tags: List[str] = field(default_factory=list)
    use_cases: List[str] = field(default_factory=list)
    
    # Audit
    created_at: datetime = field(default_factory=datetime.utcnow)
    created_by: UUID = field(default_factory=uuid4)
    
    def create_workflow(self, parameters: Dict[str, Any], owner_id: UUID) -> Workflow:
        """Create a workflow from this template"""
        # Create tasks from templates
        tasks = []
        for task_template in self.task_templates:
            task = TaskDefinition(
                id=task_template['id'],
                name=task_template['name'],
                task_type=TaskType(task_template['type']),
                configuration=task_template.get('configuration', {}),
                timeout_minutes=task_template.get('timeout_minutes', 30)
            )
            tasks.append(task)
        
        return Workflow(
            name=parameters.get('name', self.name),
            description=parameters.get('description', self.description),
            workflow_type=self.workflow_type,
            tasks=tasks,
            task_dependencies=self.default_config.get('task_dependencies', {}),
            timeout_minutes=parameters.get('timeout_minutes', 60),
            owner_id=owner_id,
            organization_id=parameters.get('organization_id', uuid4())
        )

