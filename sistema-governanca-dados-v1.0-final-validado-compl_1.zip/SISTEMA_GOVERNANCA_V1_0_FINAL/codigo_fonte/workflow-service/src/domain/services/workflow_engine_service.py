# Autor: carlos.morais@f1rst.com.br
"""
Workflow Engine Service - Engine BPMN Completo para Workflows
"""

import asyncio
import json
import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Set, Tuple, Union, Callable
from uuid import UUID
from enum import Enum
from dataclasses import dataclass, field

from ..entities.workflow import Workflow, WorkflowStatus
from ..value_objects.workflow_node import WorkflowNode, NodeType
from ..value_objects.workflow_transition import WorkflowTransition, TransitionCondition


class ExecutionStatus(Enum):
    """Status de execução de workflow"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    SUSPENDED = "suspended"
    WAITING = "waiting"


class TaskType(Enum):
    """Tipos de tarefas BPMN"""
    USER_TASK = "user_task"
    SERVICE_TASK = "service_task"
    SCRIPT_TASK = "script_task"
    SEND_TASK = "send_task"
    RECEIVE_TASK = "receive_task"
    MANUAL_TASK = "manual_task"
    BUSINESS_RULE_TASK = "business_rule_task"
    CALL_ACTIVITY = "call_activity"


class GatewayType(Enum):
    """Tipos de gateways BPMN"""
    EXCLUSIVE = "exclusive"  # XOR
    INCLUSIVE = "inclusive"  # OR
    PARALLEL = "parallel"    # AND
    EVENT_BASED = "event_based"
    COMPLEX = "complex"


class EventType(Enum):
    """Tipos de eventos BPMN"""
    START = "start"
    END = "end"
    INTERMEDIATE = "intermediate"
    BOUNDARY = "boundary"
    TIMER = "timer"
    MESSAGE = "message"
    SIGNAL = "signal"
    ERROR = "error"
    ESCALATION = "escalation"
    COMPENSATION = "compensation"
    CONDITIONAL = "conditional"


@dataclass
class WorkflowToken:
    """Token de execução do workflow"""
    id: UUID = field(default_factory=uuid.uuid4)
    workflow_instance_id: UUID = None
    current_node_id: str = ""
    data: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    status: ExecutionStatus = ExecutionStatus.PENDING
    parent_token_id: Optional[UUID] = None
    child_tokens: List[UUID] = field(default_factory=list)
    
    def clone(self) -> 'WorkflowToken':
        """Clona o token para execução paralela"""
        return WorkflowToken(
            id=uuid.uuid4(),
            workflow_instance_id=self.workflow_instance_id,
            current_node_id=self.current_node_id,
            data=self.data.copy(),
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
            status=ExecutionStatus.PENDING,
            parent_token_id=self.id
        )


@dataclass
class WorkflowInstance:
    """Instância de execução de workflow"""
    id: UUID = field(default_factory=uuid.uuid4)
    workflow_id: UUID = None
    workflow_definition: Workflow = None
    status: ExecutionStatus = ExecutionStatus.PENDING
    tokens: List[WorkflowToken] = field(default_factory=list)
    variables: Dict[str, Any] = field(default_factory=dict)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    started_by: str = ""
    current_tasks: List[str] = field(default_factory=list)
    completed_tasks: List[str] = field(default_factory=list)
    failed_tasks: List[str] = field(default_factory=list)
    execution_log: List[Dict[str, Any]] = field(default_factory=list)
    
    def add_log_entry(self, event_type: str, node_id: str, message: str, details: Dict[str, Any] = None):
        """Adiciona entrada no log de execução"""
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": event_type,
            "node_id": node_id,
            "message": message,
            "details": details or {}
        }
        self.execution_log.append(entry)


@dataclass
class TaskExecution:
    """Execução de uma tarefa"""
    id: UUID = field(default_factory=uuid.uuid4)
    workflow_instance_id: UUID = None
    node_id: str = ""
    task_type: TaskType = TaskType.USER_TASK
    status: ExecutionStatus = ExecutionStatus.PENDING
    assigned_to: Optional[str] = None
    assigned_group: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)
    result: Optional[Dict[str, Any]] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    due_date: Optional[datetime] = None
    priority: int = 5  # 1-10, 10 = highest
    
    def is_overdue(self) -> bool:
        """Verifica se a tarefa está atrasada"""
        return self.due_date and datetime.utcnow() > self.due_date


class WorkflowEngineService:
    """
    Engine BPMN Completo para Workflows
    
    Responsabilidades:
    - Executar workflows baseados em BPMN 2.0
    - Gerenciar tokens de execução
    - Suportar todos os elementos BPMN principais
    - Executar tarefas síncronas e assíncronas
    - Gerenciar gateways e condições
    - Tratar eventos e timers
    - Fornecer APIs de controle de workflow
    """
    
    def __init__(self):
        """Inicializa o workflow engine"""
        self._running_instances: Dict[UUID, WorkflowInstance] = {}
        self._task_handlers: Dict[TaskType, Callable] = {
            TaskType.USER_TASK: self._execute_user_task,
            TaskType.SERVICE_TASK: self._execute_service_task,
            TaskType.SCRIPT_TASK: self._execute_script_task,
            TaskType.SEND_TASK: self._execute_send_task,
            TaskType.RECEIVE_TASK: self._execute_receive_task,
            TaskType.MANUAL_TASK: self._execute_manual_task,
            TaskType.BUSINESS_RULE_TASK: self._execute_business_rule_task,
            TaskType.CALL_ACTIVITY: self._execute_call_activity
        }
        
        self._gateway_handlers: Dict[GatewayType, Callable] = {
            GatewayType.EXCLUSIVE: self._execute_exclusive_gateway,
            GatewayType.INCLUSIVE: self._execute_inclusive_gateway,
            GatewayType.PARALLEL: self._execute_parallel_gateway,
            GatewayType.EVENT_BASED: self._execute_event_based_gateway,
            GatewayType.COMPLEX: self._execute_complex_gateway
        }
        
        self._event_handlers: Dict[EventType, Callable] = {
            EventType.START: self._handle_start_event,
            EventType.END: self._handle_end_event,
            EventType.INTERMEDIATE: self._handle_intermediate_event,
            EventType.TIMER: self._handle_timer_event,
            EventType.MESSAGE: self._handle_message_event,
            EventType.SIGNAL: self._handle_signal_event,
            EventType.ERROR: self._handle_error_event
        }
        
        self._timers: Dict[UUID, asyncio.Task] = {}
        self._message_queue: Dict[str, List[Dict[str, Any]]] = {}
        self._signal_subscriptions: Dict[str, List[UUID]] = {}
    
    async def start_workflow(
        self,
        workflow: Workflow,
        variables: Dict[str, Any] = None,
        started_by: str = "system"
    ) -> WorkflowInstance:
        """
        Inicia uma nova instância de workflow
        
        Args:
            workflow: Definição do workflow
            variables: Variáveis iniciais
            started_by: Usuário que iniciou o workflow
            
        Returns:
            WorkflowInstance: Instância criada
        """
        # Criar instância
        instance = WorkflowInstance(
            workflow_id=workflow.id,
            workflow_definition=workflow,
            variables=variables or {},
            started_by=started_by,
            started_at=datetime.utcnow()
        )
        
        # Encontrar nó de início
        start_nodes = [
            node for node in workflow.nodes 
            if node.node_type == NodeType.START_EVENT
        ]
        
        if not start_nodes:
            raise ValueError("Workflow deve ter pelo menos um evento de início")
        
        start_node = start_nodes[0]
        
        # Criar token inicial
        initial_token = WorkflowToken(
            workflow_instance_id=instance.id,
            current_node_id=start_node.id,
            data=instance.variables.copy()
        )
        
        instance.tokens.append(initial_token)
        instance.status = ExecutionStatus.RUNNING
        instance.add_log_entry("workflow_started", start_node.id, f"Workflow iniciado por {started_by}")
        
        # Registrar instância
        self._running_instances[instance.id] = instance
        
        # Executar a partir do nó de início
        await self._execute_node(instance, initial_token, start_node)
        
        return instance
    
    async def _execute_node(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """
        Executa um nó do workflow
        
        Args:
            instance: Instância do workflow
            token: Token de execução
            node: Nó a ser executado
        """
        try:
            instance.add_log_entry("node_started", node.id, f"Executando nó {node.name}")
            
            # Atualizar token
            token.current_node_id = node.id
            token.updated_at = datetime.utcnow()
            token.status = ExecutionStatus.RUNNING
            
            # Executar baseado no tipo do nó
            if node.node_type in [NodeType.USER_TASK, NodeType.SERVICE_TASK, NodeType.SCRIPT_TASK]:
                await self._execute_task_node(instance, token, node)
            elif node.node_type in [NodeType.EXCLUSIVE_GATEWAY, NodeType.PARALLEL_GATEWAY, NodeType.INCLUSIVE_GATEWAY]:
                await self._execute_gateway_node(instance, token, node)
            elif node.node_type in [NodeType.START_EVENT, NodeType.END_EVENT, NodeType.INTERMEDIATE_EVENT]:
                await self._execute_event_node(instance, token, node)
            else:
                # Nó não suportado, continuar
                await self._continue_execution(instance, token, node)
            
        except Exception as e:
            instance.add_log_entry("node_failed", node.id, f"Erro na execução: {str(e)}")
            token.status = ExecutionStatus.FAILED
            await self._handle_execution_error(instance, token, node, e)
    
    async def _execute_task_node(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Executa um nó de tarefa"""
        task_config = node.configuration or {}
        task_type_str = task_config.get("task_type", "user_task")
        
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.USER_TASK
        
        # Criar execução de tarefa
        task_execution = TaskExecution(
            workflow_instance_id=instance.id,
            node_id=node.id,
            task_type=task_type,
            assigned_to=task_config.get("assigned_to"),
            assigned_group=task_config.get("assigned_group"),
            data=token.data.copy(),
            priority=task_config.get("priority", 5)
        )
        
        # Calcular due date se especificado
        if "due_date_offset" in task_config:
            offset_hours = task_config["due_date_offset"]
            task_execution.due_date = datetime.utcnow() + timedelta(hours=offset_hours)
        
        # Executar tarefa
        handler = self._task_handlers.get(task_type)
        if handler:
            await handler(instance, token, node, task_execution)
        else:
            # Handler padrão
            await self._execute_default_task(instance, token, node, task_execution)
    
    async def _execute_gateway_node(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Executa um nó de gateway"""
        gateway_config = node.configuration or {}
        gateway_type_str = gateway_config.get("gateway_type", "exclusive")
        
        try:
            gateway_type = GatewayType(gateway_type_str)
        except ValueError:
            gateway_type = GatewayType.EXCLUSIVE
        
        # Executar gateway
        handler = self._gateway_handlers.get(gateway_type)
        if handler:
            await handler(instance, token, node)
        else:
            # Gateway padrão (exclusive)
            await self._execute_exclusive_gateway(instance, token, node)
    
    async def _execute_event_node(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Executa um nó de evento"""
        event_config = node.configuration or {}
        event_type_str = event_config.get("event_type", "intermediate")
        
        try:
            event_type = EventType(event_type_str)
        except ValueError:
            event_type = EventType.INTERMEDIATE
        
        # Executar evento
        handler = self._event_handlers.get(event_type)
        if handler:
            await handler(instance, token, node)
        else:
            # Evento padrão (continuar)
            await self._continue_execution(instance, token, node)
    
    async def _execute_user_task(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode,
        task_execution: TaskExecution
    ):
        """Executa tarefa de usuário"""
        task_execution.status = ExecutionStatus.WAITING
        task_execution.started_at = datetime.utcnow()
        
        # Adicionar à lista de tarefas atuais
        instance.current_tasks.append(node.id)
        
        # Log
        instance.add_log_entry(
            "user_task_created", 
            node.id, 
            f"Tarefa de usuário criada para {task_execution.assigned_to or task_execution.assigned_group}"
        )
        
        # Token fica aguardando
        token.status = ExecutionStatus.WAITING
        
        # Em produção, isso notificaria o usuário/grupo
        print(f"USER TASK: {node.name} aguardando execução por {task_execution.assigned_to}")
    
    async def _execute_service_task(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode,
        task_execution: TaskExecution
    ):
        """Executa tarefa de serviço"""
        task_execution.status = ExecutionStatus.RUNNING
        task_execution.started_at = datetime.utcnow()
        
        config = node.configuration or {}
        service_name = config.get("service_name")
        method = config.get("method", "execute")
        parameters = config.get("parameters", {})
        
        try:
            # Simular chamada de serviço
            await asyncio.sleep(0.1)  # Simular latência
            
            # Resultado simulado
            result = {
                "status": "success",
                "data": {"processed": True, "timestamp": datetime.utcnow().isoformat()},
                "service": service_name,
                "method": method
            }
            
            # Atualizar dados do token
            token.data.update(result.get("data", {}))
            
            task_execution.result = result
            task_execution.status = ExecutionStatus.COMPLETED
            task_execution.completed_at = datetime.utcnow()
            
            instance.add_log_entry("service_task_completed", node.id, f"Serviço {service_name} executado com sucesso")
            
            # Continuar execução
            await self._continue_execution(instance, token, node)
            
        except Exception as e:
            task_execution.status = ExecutionStatus.FAILED
            instance.add_log_entry("service_task_failed", node.id, f"Falha no serviço {service_name}: {str(e)}")
            await self._handle_execution_error(instance, token, node, e)
    
    async def _execute_script_task(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode,
        task_execution: TaskExecution
    ):
        """Executa tarefa de script"""
        task_execution.status = ExecutionStatus.RUNNING
        task_execution.started_at = datetime.utcnow()
        
        config = node.configuration or {}
        script = config.get("script", "")
        script_type = config.get("script_type", "python")
        
        try:
            # Simular execução de script
            if script_type == "python":
                # Em produção, executaria o script Python de forma segura
                result = {"script_executed": True, "output": "Script executado com sucesso"}
            else:
                result = {"script_executed": True, "output": f"Script {script_type} executado"}
            
            # Atualizar dados do token
            token.data.update(result)
            
            task_execution.result = result
            task_execution.status = ExecutionStatus.COMPLETED
            task_execution.completed_at = datetime.utcnow()
            
            instance.add_log_entry("script_task_completed", node.id, "Script executado com sucesso")
            
            # Continuar execução
            await self._continue_execution(instance, token, node)
            
        except Exception as e:
            task_execution.status = ExecutionStatus.FAILED
            instance.add_log_entry("script_task_failed", node.id, f"Falha no script: {str(e)}")
            await self._handle_execution_error(instance, token, node, e)
    
    async def _execute_send_task(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode,
        task_execution: TaskExecution
    ):
        """Executa tarefa de envio"""
        config = node.configuration or {}
        message_type = config.get("message_type", "email")
        recipient = config.get("recipient")
        message_content = config.get("message", "")
        
        # Simular envio de mensagem
        result = {
            "message_sent": True,
            "message_type": message_type,
            "recipient": recipient,
            "sent_at": datetime.utcnow().isoformat()
        }
        
        task_execution.result = result
        task_execution.status = ExecutionStatus.COMPLETED
        task_execution.completed_at = datetime.utcnow()
        
        instance.add_log_entry("send_task_completed", node.id, f"Mensagem {message_type} enviada para {recipient}")
        
        # Continuar execução
        await self._continue_execution(instance, token, node)
    
    async def _execute_receive_task(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode,
        task_execution: TaskExecution
    ):
        """Executa tarefa de recebimento"""
        config = node.configuration or {}
        message_type = config.get("message_type", "email")
        timeout_minutes = config.get("timeout_minutes", 60)
        
        # Token fica aguardando mensagem
        token.status = ExecutionStatus.WAITING
        task_execution.status = ExecutionStatus.WAITING
        
        instance.add_log_entry("receive_task_waiting", node.id, f"Aguardando mensagem {message_type}")
        
        # Em produção, configuraria listener para mensagens
        # Por enquanto, simular recebimento após timeout
        if timeout_minutes > 0:
            await asyncio.sleep(min(timeout_minutes * 60, 5))  # Max 5 segundos para demo
        
        # Simular recebimento
        result = {
            "message_received": True,
            "message_type": message_type,
            "received_at": datetime.utcnow().isoformat(),
            "content": "Mensagem simulada"
        }
        
        token.data.update(result)
        task_execution.result = result
        task_execution.status = ExecutionStatus.COMPLETED
        task_execution.completed_at = datetime.utcnow()
        
        instance.add_log_entry("receive_task_completed", node.id, f"Mensagem {message_type} recebida")
        
        # Continuar execução
        await self._continue_execution(instance, token, node)
    
    async def _execute_manual_task(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode,
        task_execution: TaskExecution
    ):
        """Executa tarefa manual"""
        # Tarefa manual é similar à tarefa de usuário, mas sem sistema
        task_execution.status = ExecutionStatus.WAITING
        task_execution.started_at = datetime.utcnow()
        
        instance.current_tasks.append(node.id)
        instance.add_log_entry("manual_task_created", node.id, "Tarefa manual criada")
        
        token.status = ExecutionStatus.WAITING
        
        print(f"MANUAL TASK: {node.name} aguardando execução manual")
    
    async def _execute_business_rule_task(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode,
        task_execution: TaskExecution
    ):
        """Executa tarefa de regra de negócio"""
        config = node.configuration or {}
        rule_name = config.get("rule_name")
        rule_parameters = config.get("parameters", {})
        
        # Simular execução de regra de negócio
        result = {
            "rule_executed": True,
            "rule_name": rule_name,
            "result": "approved",  # Placeholder
            "score": 85.0
        }
        
        token.data.update(result)
        task_execution.result = result
        task_execution.status = ExecutionStatus.COMPLETED
        task_execution.completed_at = datetime.utcnow()
        
        instance.add_log_entry("business_rule_completed", node.id, f"Regra {rule_name} executada")
        
        # Continuar execução
        await self._continue_execution(instance, token, node)
    
    async def _execute_call_activity(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode,
        task_execution: TaskExecution
    ):
        """Executa call activity (sub-processo)"""
        config = node.configuration or {}
        subprocess_id = config.get("subprocess_id")
        
        # Simular execução de sub-processo
        result = {
            "subprocess_executed": True,
            "subprocess_id": subprocess_id,
            "subprocess_result": "completed"
        }
        
        token.data.update(result)
        task_execution.result = result
        task_execution.status = ExecutionStatus.COMPLETED
        task_execution.completed_at = datetime.utcnow()
        
        instance.add_log_entry("call_activity_completed", node.id, f"Sub-processo {subprocess_id} executado")
        
        # Continuar execução
        await self._continue_execution(instance, token, node)
    
    async def _execute_default_task(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode,
        task_execution: TaskExecution
    ):
        """Executa tarefa padrão"""
        task_execution.status = ExecutionStatus.COMPLETED
        task_execution.completed_at = datetime.utcnow()
        
        instance.add_log_entry("task_completed", node.id, f"Tarefa {node.name} executada")
        
        # Continuar execução
        await self._continue_execution(instance, token, node)
    
    async def _execute_exclusive_gateway(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Executa gateway exclusivo (XOR)"""
        # Encontrar transições de saída
        outgoing_transitions = [
            t for t in instance.workflow_definition.transitions
            if t.from_node_id == node.id
        ]
        
        if not outgoing_transitions:
            instance.add_log_entry("gateway_no_transitions", node.id, "Gateway sem transições de saída")
            return
        
        # Avaliar condições
        selected_transition = None
        for transition in outgoing_transitions:
            if await self._evaluate_transition_condition(transition, token.data):
                selected_transition = transition
                break
        
        # Se nenhuma condição foi atendida, usar transição padrão
        if not selected_transition:
            default_transitions = [t for t in outgoing_transitions if t.is_default]
            if default_transitions:
                selected_transition = default_transitions[0]
        
        if selected_transition:
            instance.add_log_entry("gateway_transition_selected", node.id, f"Transição selecionada: {selected_transition.id}")
            await self._follow_transition(instance, token, selected_transition)
        else:
            instance.add_log_entry("gateway_no_valid_transition", node.id, "Nenhuma transição válida encontrada")
            token.status = ExecutionStatus.FAILED
    
    async def _execute_parallel_gateway(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Executa gateway paralelo (AND)"""
        # Encontrar transições de saída
        outgoing_transitions = [
            t for t in instance.workflow_definition.transitions
            if t.from_node_id == node.id
        ]
        
        if not outgoing_transitions:
            return
        
        # Criar token para cada transição (fork)
        for i, transition in enumerate(outgoing_transitions):
            if i == 0:
                # Usar token atual para primeira transição
                await self._follow_transition(instance, token, transition)
            else:
                # Criar novo token para outras transições
                new_token = token.clone()
                instance.tokens.append(new_token)
                await self._follow_transition(instance, new_token, transition)
        
        instance.add_log_entry("parallel_gateway_fork", node.id, f"Fork criado para {len(outgoing_transitions)} transições")
    
    async def _execute_inclusive_gateway(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Executa gateway inclusivo (OR)"""
        # Encontrar transições de saída
        outgoing_transitions = [
            t for t in instance.workflow_definition.transitions
            if t.from_node_id == node.id
        ]
        
        if not outgoing_transitions:
            return
        
        # Avaliar todas as condições
        valid_transitions = []
        for transition in outgoing_transitions:
            if await self._evaluate_transition_condition(transition, token.data):
                valid_transitions.append(transition)
        
        # Se nenhuma condição foi atendida, usar transição padrão
        if not valid_transitions:
            default_transitions = [t for t in outgoing_transitions if t.is_default]
            valid_transitions = default_transitions
        
        # Criar token para cada transição válida
        for i, transition in enumerate(valid_transitions):
            if i == 0:
                # Usar token atual para primeira transição
                await self._follow_transition(instance, token, transition)
            else:
                # Criar novo token para outras transições
                new_token = token.clone()
                instance.tokens.append(new_token)
                await self._follow_transition(instance, new_token, transition)
        
        instance.add_log_entry("inclusive_gateway_executed", node.id, f"Gateway inclusivo executado para {len(valid_transitions)} transições")
    
    async def _execute_event_based_gateway(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Executa gateway baseado em eventos"""
        # Gateway baseado em eventos aguarda por eventos
        token.status = ExecutionStatus.WAITING
        instance.add_log_entry("event_gateway_waiting", node.id, "Gateway aguardando eventos")
        
        # Em produção, configuraria listeners para eventos
        # Por enquanto, simular evento após timeout
        await asyncio.sleep(2)
        
        # Simular recebimento de evento
        outgoing_transitions = [
            t for t in instance.workflow_definition.transitions
            if t.from_node_id == node.id
        ]
        
        if outgoing_transitions:
            # Selecionar primeira transição como exemplo
            selected_transition = outgoing_transitions[0]
            instance.add_log_entry("event_gateway_triggered", node.id, f"Evento recebido, seguindo transição {selected_transition.id}")
            await self._follow_transition(instance, token, selected_transition)
    
    async def _execute_complex_gateway(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Executa gateway complexo"""
        # Gateway complexo usa lógica customizada
        config = node.configuration or {}
        complex_condition = config.get("complex_condition", "true")
        
        # Simular avaliação de condição complexa
        condition_result = True  # Placeholder
        
        if condition_result:
            # Continuar como gateway exclusivo
            await self._execute_exclusive_gateway(instance, token, node)
        else:
            token.status = ExecutionStatus.FAILED
            instance.add_log_entry("complex_gateway_failed", node.id, "Condição complexa não atendida")
    
    async def _handle_start_event(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Trata evento de início"""
        instance.add_log_entry("start_event", node.id, "Evento de início processado")
        await self._continue_execution(instance, token, node)
    
    async def _handle_end_event(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Trata evento de fim"""
        token.status = ExecutionStatus.COMPLETED
        instance.add_log_entry("end_event", node.id, "Evento de fim alcançado")
        
        # Verificar se todos os tokens foram completados
        active_tokens = [t for t in instance.tokens if t.status not in [ExecutionStatus.COMPLETED, ExecutionStatus.FAILED]]
        
        if not active_tokens:
            instance.status = ExecutionStatus.COMPLETED
            instance.completed_at = datetime.utcnow()
            instance.add_log_entry("workflow_completed", node.id, "Workflow completado")
    
    async def _handle_intermediate_event(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Trata evento intermediário"""
        instance.add_log_entry("intermediate_event", node.id, "Evento intermediário processado")
        await self._continue_execution(instance, token, node)
    
    async def _handle_timer_event(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Trata evento de timer"""
        config = node.configuration or {}
        duration_seconds = config.get("duration_seconds", 60)
        
        instance.add_log_entry("timer_event_started", node.id, f"Timer iniciado por {duration_seconds} segundos")
        
        # Aguardar timer
        await asyncio.sleep(min(duration_seconds, 5))  # Max 5 segundos para demo
        
        instance.add_log_entry("timer_event_completed", node.id, "Timer completado")
        await self._continue_execution(instance, token, node)
    
    async def _handle_message_event(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Trata evento de mensagem"""
        config = node.configuration or {}
        message_name = config.get("message_name", "default")
        
        # Verificar se há mensagem na fila
        if message_name in self._message_queue and self._message_queue[message_name]:
            message = self._message_queue[message_name].pop(0)
            token.data.update(message)
            instance.add_log_entry("message_event_received", node.id, f"Mensagem {message_name} recebida")
            await self._continue_execution(instance, token, node)
        else:
            # Aguardar mensagem
            token.status = ExecutionStatus.WAITING
            instance.add_log_entry("message_event_waiting", node.id, f"Aguardando mensagem {message_name}")
    
    async def _handle_signal_event(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Trata evento de sinal"""
        config = node.configuration or {}
        signal_name = config.get("signal_name", "default")
        
        # Registrar para receber sinal
        if signal_name not in self._signal_subscriptions:
            self._signal_subscriptions[signal_name] = []
        
        self._signal_subscriptions[signal_name].append(instance.id)
        
        token.status = ExecutionStatus.WAITING
        instance.add_log_entry("signal_event_waiting", node.id, f"Aguardando sinal {signal_name}")
    
    async def _handle_error_event(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode
    ):
        """Trata evento de erro"""
        config = node.configuration or {}
        error_code = config.get("error_code", "GENERIC_ERROR")
        
        instance.add_log_entry("error_event", node.id, f"Evento de erro: {error_code}")
        
        # Marcar token como falho
        token.status = ExecutionStatus.FAILED
        
        # Verificar se há tratamento de erro
        # Em produção, procuraria boundary events ou catch events
        await self._handle_execution_error(instance, token, node, Exception(f"Error event: {error_code}"))
    
    async def _evaluate_transition_condition(
        self,
        transition: WorkflowTransition,
        data: Dict[str, Any]
    ) -> bool:
        """
        Avalia condição de transição
        
        Args:
            transition: Transição a ser avaliada
            data: Dados do token
            
        Returns:
            bool: True se condição for atendida
        """
        if not transition.condition:
            return True
        
        condition = transition.condition
        
        # Condições simples
        if condition.condition_type == "simple":
            field = condition.field
            operator = condition.operator
            value = condition.value
            
            if field not in data:
                return False
            
            field_value = data[field]
            
            if operator == "equals":
                return field_value == value
            elif operator == "not_equals":
                return field_value != value
            elif operator == "greater_than":
                return field_value > value
            elif operator == "less_than":
                return field_value < value
            elif operator == "contains":
                return value in str(field_value)
            
        # Condições de script
        elif condition.condition_type == "script":
            # Em produção, executaria script de forma segura
            # Por enquanto, simular avaliação
            return True
        
        return True
    
    async def _follow_transition(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        transition: WorkflowTransition
    ):
        """
        Segue uma transição para o próximo nó
        
        Args:
            instance: Instância do workflow
            token: Token de execução
            transition: Transição a ser seguida
        """
        # Encontrar nó de destino
        target_node = None
        for node in instance.workflow_definition.nodes:
            if node.id == transition.to_node_id:
                target_node = node
                break
        
        if target_node:
            instance.add_log_entry("transition_followed", transition.from_node_id, f"Seguindo transição para {target_node.id}")
            await self._execute_node(instance, token, target_node)
        else:
            instance.add_log_entry("transition_target_not_found", transition.from_node_id, f"Nó de destino {transition.to_node_id} não encontrado")
            token.status = ExecutionStatus.FAILED
    
    async def _continue_execution(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        current_node: WorkflowNode
    ):
        """
        Continua execução para o próximo nó
        
        Args:
            instance: Instância do workflow
            token: Token de execução
            current_node: Nó atual
        """
        # Encontrar transições de saída
        outgoing_transitions = [
            t for t in instance.workflow_definition.transitions
            if t.from_node_id == current_node.id
        ]
        
        if not outgoing_transitions:
            # Nó final sem transições
            token.status = ExecutionStatus.COMPLETED
            instance.add_log_entry("node_completed", current_node.id, "Nó completado sem transições de saída")
            return
        
        # Se há apenas uma transição, seguir automaticamente
        if len(outgoing_transitions) == 1:
            await self._follow_transition(instance, token, outgoing_transitions[0])
        else:
            # Múltiplas transições - tratar como gateway exclusivo
            for transition in outgoing_transitions:
                if await self._evaluate_transition_condition(transition, token.data):
                    await self._follow_transition(instance, token, transition)
                    return
            
            # Nenhuma condição atendida - usar transição padrão
            default_transitions = [t for t in outgoing_transitions if t.is_default]
            if default_transitions:
                await self._follow_transition(instance, token, default_transitions[0])
            else:
                token.status = ExecutionStatus.FAILED
                instance.add_log_entry("no_valid_transition", current_node.id, "Nenhuma transição válida encontrada")
    
    async def _handle_execution_error(
        self,
        instance: WorkflowInstance,
        token: WorkflowToken,
        node: WorkflowNode,
        error: Exception
    ):
        """
        Trata erro de execução
        
        Args:
            instance: Instância do workflow
            token: Token de execução
            node: Nó onde ocorreu o erro
            error: Exceção ocorrida
        """
        instance.add_log_entry("execution_error", node.id, f"Erro: {str(error)}")
        
        # Verificar se há tratamento de erro configurado
        error_handling = node.configuration.get("error_handling") if node.configuration else None
        
        if error_handling:
            retry_count = error_handling.get("retry_count", 0)
            if retry_count > 0:
                # Implementar retry
                instance.add_log_entry("error_retry", node.id, f"Tentando novamente ({retry_count} tentativas restantes)")
                # Em produção, implementaria lógica de retry
        
        # Marcar token como falho
        token.status = ExecutionStatus.FAILED
        
        # Verificar se deve falhar todo o workflow
        fail_workflow = error_handling.get("fail_workflow", True) if error_handling else True
        
        if fail_workflow:
            instance.status = ExecutionStatus.FAILED
            instance.add_log_entry("workflow_failed", node.id, f"Workflow falhou devido a erro em {node.id}")
    
    async def complete_user_task(
        self,
        instance_id: UUID,
        node_id: str,
        user_id: str,
        result: Dict[str, Any]
    ) -> bool:
        """
        Completa uma tarefa de usuário
        
        Args:
            instance_id: ID da instância
            node_id: ID do nó da tarefa
            user_id: ID do usuário
            result: Resultado da tarefa
            
        Returns:
            bool: True se completada com sucesso
        """
        instance = self._running_instances.get(instance_id)
        if not instance:
            return False
        
        # Encontrar token aguardando neste nó
        waiting_token = None
        for token in instance.tokens:
            if token.current_node_id == node_id and token.status == ExecutionStatus.WAITING:
                waiting_token = token
                break
        
        if not waiting_token:
            return False
        
        # Atualizar dados do token
        waiting_token.data.update(result)
        waiting_token.status = ExecutionStatus.RUNNING
        
        # Remover da lista de tarefas atuais
        if node_id in instance.current_tasks:
            instance.current_tasks.remove(node_id)
        
        instance.completed_tasks.append(node_id)
        instance.add_log_entry("user_task_completed", node_id, f"Tarefa completada por {user_id}")
        
        # Encontrar nó
        current_node = None
        for node in instance.workflow_definition.nodes:
            if node.id == node_id:
                current_node = node
                break
        
        if current_node:
            # Continuar execução
            await self._continue_execution(instance, waiting_token, current_node)
        
        return True
    
    async def cancel_workflow(self, instance_id: UUID) -> bool:
        """
        Cancela uma instância de workflow
        
        Args:
            instance_id: ID da instância
            
        Returns:
            bool: True se cancelada com sucesso
        """
        instance = self._running_instances.get(instance_id)
        if not instance:
            return False
        
        instance.status = ExecutionStatus.CANCELLED
        instance.completed_at = datetime.utcnow()
        
        # Cancelar todos os tokens
        for token in instance.tokens:
            if token.status in [ExecutionStatus.RUNNING, ExecutionStatus.WAITING]:
                token.status = ExecutionStatus.CANCELLED
        
        instance.add_log_entry("workflow_cancelled", "", "Workflow cancelado")
        
        return True
    
    async def suspend_workflow(self, instance_id: UUID) -> bool:
        """
        Suspende uma instância de workflow
        
        Args:
            instance_id: ID da instância
            
        Returns:
            bool: True se suspensa com sucesso
        """
        instance = self._running_instances.get(instance_id)
        if not instance:
            return False
        
        instance.status = ExecutionStatus.SUSPENDED
        
        # Suspender todos os tokens ativos
        for token in instance.tokens:
            if token.status == ExecutionStatus.RUNNING:
                token.status = ExecutionStatus.SUSPENDED
        
        instance.add_log_entry("workflow_suspended", "", "Workflow suspenso")
        
        return True
    
    async def resume_workflow(self, instance_id: UUID) -> bool:
        """
        Resume uma instância de workflow suspensa
        
        Args:
            instance_id: ID da instância
            
        Returns:
            bool: True se resumida com sucesso
        """
        instance = self._running_instances.get(instance_id)
        if not instance or instance.status != ExecutionStatus.SUSPENDED:
            return False
        
        instance.status = ExecutionStatus.RUNNING
        
        # Resumir tokens suspensos
        for token in instance.tokens:
            if token.status == ExecutionStatus.SUSPENDED:
                token.status = ExecutionStatus.RUNNING
        
        instance.add_log_entry("workflow_resumed", "", "Workflow resumido")
        
        # Continuar execução dos tokens ativos
        for token in instance.tokens:
            if token.status == ExecutionStatus.RUNNING:
                # Encontrar nó atual
                current_node = None
                for node in instance.workflow_definition.nodes:
                    if node.id == token.current_node_id:
                        current_node = node
                        break
                
                if current_node:
                    await self._continue_execution(instance, token, current_node)
        
        return True
    
    def get_workflow_instance(self, instance_id: UUID) -> Optional[WorkflowInstance]:
        """
        Obtém uma instância de workflow
        
        Args:
            instance_id: ID da instância
            
        Returns:
            WorkflowInstance: Instância ou None se não encontrada
        """
        return self._running_instances.get(instance_id)
    
    def get_active_instances(self) -> List[WorkflowInstance]:
        """
        Obtém todas as instâncias ativas
        
        Returns:
            List[WorkflowInstance]: Lista de instâncias ativas
        """
        return [
            instance for instance in self._running_instances.values()
            if instance.status in [ExecutionStatus.RUNNING, ExecutionStatus.WAITING, ExecutionStatus.SUSPENDED]
        ]
    
    def get_user_tasks(self, user_id: str) -> List[Dict[str, Any]]:
        """
        Obtém tarefas pendentes para um usuário
        
        Args:
            user_id: ID do usuário
            
        Returns:
            List[Dict]: Lista de tarefas pendentes
        """
        tasks = []
        
        for instance in self._running_instances.values():
            for node_id in instance.current_tasks:
                # Encontrar nó
                node = None
                for n in instance.workflow_definition.nodes:
                    if n.id == node_id:
                        node = n
                        break
                
                if node and node.configuration:
                    assigned_to = node.configuration.get("assigned_to")
                    assigned_group = node.configuration.get("assigned_group")
                    
                    # Verificar se tarefa é para este usuário
                    if assigned_to == user_id or (assigned_group and user_id in assigned_group):
                        tasks.append({
                            "instance_id": str(instance.id),
                            "node_id": node_id,
                            "task_name": node.name,
                            "workflow_name": instance.workflow_definition.name,
                            "created_at": instance.started_at.isoformat() if instance.started_at else None,
                            "priority": node.configuration.get("priority", 5)
                        })
        
        return sorted(tasks, key=lambda x: x["priority"], reverse=True)
    
    async def send_message(self, message_name: str, message_data: Dict[str, Any]):
        """
        Envia mensagem para workflows aguardando
        
        Args:
            message_name: Nome da mensagem
            message_data: Dados da mensagem
        """
        if message_name not in self._message_queue:
            self._message_queue[message_name] = []
        
        self._message_queue[message_name].append(message_data)
        
        # Notificar workflows aguardando esta mensagem
        for instance in self._running_instances.values():
            for token in instance.tokens:
                if token.status == ExecutionStatus.WAITING:
                    # Verificar se token está aguardando esta mensagem
                    current_node = None
                    for node in instance.workflow_definition.nodes:
                        if node.id == token.current_node_id:
                            current_node = node
                            break
                    
                    if (current_node and 
                        current_node.node_type == NodeType.INTERMEDIATE_EVENT and
                        current_node.configuration and
                        current_node.configuration.get("message_name") == message_name):
                        
                        # Processar mensagem
                        await self._handle_message_event(instance, token, current_node)
    
    async def send_signal(self, signal_name: str, signal_data: Dict[str, Any] = None):
        """
        Envia sinal para workflows subscritos
        
        Args:
            signal_name: Nome do sinal
            signal_data: Dados do sinal
        """
        if signal_name not in self._signal_subscriptions:
            return
        
        # Notificar todas as instâncias subscritas
        for instance_id in self._signal_subscriptions[signal_name]:
            instance = self._running_instances.get(instance_id)
            if not instance:
                continue
            
            # Encontrar tokens aguardando este sinal
            for token in instance.tokens:
                if token.status == ExecutionStatus.WAITING:
                    current_node = None
                    for node in instance.workflow_definition.nodes:
                        if node.id == token.current_node_id:
                            current_node = node
                            break
                    
                    if (current_node and 
                        current_node.node_type == NodeType.INTERMEDIATE_EVENT and
                        current_node.configuration and
                        current_node.configuration.get("signal_name") == signal_name):
                        
                        # Atualizar dados do token
                        if signal_data:
                            token.data.update(signal_data)
                        
                        instance.add_log_entry("signal_received", current_node.id, f"Sinal {signal_name} recebido")
                        await self._continue_execution(instance, token, current_node)
        
        # Limpar subscrições processadas
        self._signal_subscriptions[signal_name] = []
    
    def generate_workflow_report(self, instance_id: UUID) -> Dict[str, Any]:
        """
        Gera relatório de execução de workflow
        
        Args:
            instance_id: ID da instância
            
        Returns:
            Dict: Relatório de execução
        """
        instance = self._running_instances.get(instance_id)
        if not instance:
            return {"error": "Instância não encontrada"}
        
        # Calcular métricas
        total_nodes = len(instance.workflow_definition.nodes)
        completed_nodes = len(instance.completed_tasks)
        failed_nodes = len(instance.failed_tasks)
        pending_nodes = len(instance.current_tasks)
        
        # Calcular duração
        duration = None
        if instance.started_at:
            end_time = instance.completed_at or datetime.utcnow()
            duration = (end_time - instance.started_at).total_seconds()
        
        # Estatísticas de tokens
        token_stats = {
            "total": len(instance.tokens),
            "active": len([t for t in instance.tokens if t.status == ExecutionStatus.RUNNING]),
            "waiting": len([t for t in instance.tokens if t.status == ExecutionStatus.WAITING]),
            "completed": len([t for t in instance.tokens if t.status == ExecutionStatus.COMPLETED]),
            "failed": len([t for t in instance.tokens if t.status == ExecutionStatus.FAILED])
        }
        
        return {
            "instance_id": str(instance.id),
            "workflow_name": instance.workflow_definition.name,
            "status": instance.status.value,
            "started_at": instance.started_at.isoformat() if instance.started_at else None,
            "completed_at": instance.completed_at.isoformat() if instance.completed_at else None,
            "duration_seconds": duration,
            "started_by": instance.started_by,
            "progress": {
                "total_nodes": total_nodes,
                "completed_nodes": completed_nodes,
                "failed_nodes": failed_nodes,
                "pending_nodes": pending_nodes,
                "completion_percentage": (completed_nodes / total_nodes * 100) if total_nodes > 0 else 0
            },
            "token_statistics": token_stats,
            "current_tasks": instance.current_tasks,
            "execution_log": instance.execution_log[-10:],  # Últimas 10 entradas
            "variables": instance.variables
        }

