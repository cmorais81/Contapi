# Autor: carlos.morais@f1rst.com.br
"""
Catalog Use Cases Implementation
Business logic for data catalog management operations
"""

import asyncio
import json
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from uuid import UUID, uuid4

from ...domain.entities.dataset import Dataset as DatasetEntity
from ...domain.repositories.catalog_repository import CatalogRepository
from ...domain.value_objects.dataset_status import DatasetStatus
from ...domain.value_objects.dataset_type import DatasetType
from ...domain.value_objects.access_level import AccessLevel
from ...domain.value_objects.data_classification import DataClassification
from ...domain.services.data_discovery_service import DataDiscoveryService
from ...domain.services.data_profiling_service import DataProfilingService
from ...domain.services.lineage_service import LineageService
from ..dtos.catalog_dtos import (
    CreateDatasetRequest, UpdateDatasetRequest, DatasetSearchRequest, DatasetFilterRequest,
    DataLineageRequest, DatasetProfileRequest, DatasetResponse, DatasetListResponse,
    DatasetSummaryResponse, DataLineageResponse, DataLineageNodeResponse, DatasetProfileResponse,
    CatalogStatisticsResponse, DataDiscoveryResponse, BulkDatasetOperationRequest,
    BulkDatasetOperationResponse, DatasetNotificationRequest, DatasetNotificationResponse,
    DatasetLocationDTO, DatasetSchemaDTO, DatasetMetricsDTO, DatasetUsageDTO
)


class CatalogUseCasesImpl:
    """Implementation of catalog use cases"""
    
    def __init__(self, catalog_repository: CatalogRepository):
        self.catalog_repository = catalog_repository
        self.discovery_service = DataDiscoveryService()
        self.profiling_service = DataProfilingService()
        self.lineage_service = LineageService()
    
    async def create_dataset(self, request: CreateDatasetRequest) -> DatasetResponse:
        """Create a new dataset"""
        try:
            # Check if dataset name already exists
            if self.catalog_repository.exists_by_name(request.name, request.organization_id):
                raise ValueError("Dataset name already exists in organization")
            
            # Validate schema if provided
            if request.schema:
                await self._validate_schema(request.schema)
            
            # Create dataset entity
            dataset = DatasetEntity(
                id=uuid4(),
                name=request.name,
                title=request.title,
                description=request.description,
                dataset_type=request.dataset_type,
                status=DatasetStatus.DRAFT,
                organization_id=request.organization_id,
                organization_name="",  # Will be populated by repository
                owner_id=request.owner_id,
                owner_name="",  # Will be populated by repository
                location=request.location.dict() if request.location else {},
                schema=request.schema.dict() if request.schema else {},
                access_level=request.access_level,
                classification=request.classification,
                tags=request.tags or [],
                business_terms=request.business_terms or [],
                metadata=request.metadata or {},
                size_bytes=0,
                row_count=0,
                column_count=len(request.schema.fields) if request.schema else 0,
                quality_score=None,
                popularity_score=0.0,
                created_by=uuid4(),  # Should come from authenticated user
                created_by_name="",  # Will be populated by repository
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            # Save dataset
            saved_dataset = self.catalog_repository.save(dataset)
            
            # Convert to response DTO
            return self._entity_to_response(saved_dataset)
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to create dataset: {str(e)}")
    
    async def get_dataset(self, dataset_id: UUID) -> Optional[DatasetResponse]:
        """Get dataset by ID"""
        try:
            dataset = self.catalog_repository.find_by_id(dataset_id)
            if not dataset:
                return None
            
            return self._entity_to_response(dataset)
            
        except Exception as e:
            raise RuntimeError(f"Failed to get dataset: {str(e)}")
    
    async def update_dataset(self, dataset_id: UUID, request: UpdateDatasetRequest) -> Optional[DatasetResponse]:
        """Update dataset"""
        try:
            dataset = self.catalog_repository.find_by_id(dataset_id)
            if not dataset:
                return None
            
            # Update fields
            if request.title is not None:
                dataset.title = request.title
            
            if request.description is not None:
                dataset.description = request.description
            
            if request.owner_id is not None:
                dataset.owner_id = request.owner_id
            
            if request.location is not None:
                dataset.location = request.location.dict()
            
            if request.schema is not None:
                await self._validate_schema(request.schema)
                dataset.schema = request.schema.dict()
                dataset.column_count = len(request.schema.fields)
            
            if request.access_level is not None:
                dataset.access_level = request.access_level
            
            if request.classification is not None:
                dataset.classification = request.classification
            
            if request.status is not None:
                dataset.status = request.status
            
            if request.tags is not None:
                dataset.tags = request.tags
            
            if request.business_terms is not None:
                dataset.business_terms = request.business_terms
            
            if request.metadata is not None:
                dataset.metadata = request.metadata
            
            dataset.updated_at = datetime.utcnow()
            
            # Save updated dataset
            updated_dataset = self.catalog_repository.save(dataset)
            
            return self._entity_to_response(updated_dataset)
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to update dataset: {str(e)}")
    
    async def delete_dataset(self, dataset_id: UUID) -> bool:
        """Delete dataset"""
        try:
            return self.catalog_repository.delete(dataset_id)
        except Exception as e:
            raise RuntimeError(f"Failed to delete dataset: {str(e)}")
    
    async def list_datasets(self, organization_id: Optional[UUID] = None,
                           dataset_type: Optional[str] = None,
                           status: Optional[str] = None,
                           limit: int = 100, offset: int = 0) -> DatasetListResponse:
        """List datasets with filters"""
        try:
            filters = {}
            if organization_id:
                filters['organization_id'] = organization_id
            if dataset_type:
                filters['dataset_type'] = dataset_type
            if status:
                filters['status'] = status
            
            datasets = self.catalog_repository.find_with_filters(filters, limit, offset)
            
            # Get total count (simplified)
            total = len(datasets)
            
            return DatasetListResponse(
                datasets=[self._entity_to_response(dataset) for dataset in datasets],
                total=total,
                limit=limit,
                offset=offset,
                has_more=total > offset + limit
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to list datasets: {str(e)}")
    
    async def search_datasets(self, request: DatasetSearchRequest) -> DatasetListResponse:
        """Search datasets by text"""
        try:
            datasets = self.catalog_repository.search_datasets(
                request.search_term,
                request.organization_id,
                request.limit,
                request.offset
            )
            
            total = len(datasets)
            
            return DatasetListResponse(
                datasets=[self._entity_to_response(dataset) for dataset in datasets],
                total=total,
                limit=request.limit,
                offset=request.offset,
                has_more=total > request.offset + request.limit
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to search datasets: {str(e)}")
    
    async def filter_datasets(self, request: DatasetFilterRequest) -> DatasetListResponse:
        """Filter datasets with advanced criteria"""
        try:
            filters = {}
            
            if request.organization_id:
                filters['organization_id'] = request.organization_id
            if request.owner_id:
                filters['owner_id'] = request.owner_id
            if request.dataset_type:
                filters['dataset_type'] = request.dataset_type.value
            if request.status:
                filters['status'] = request.status.value
            if request.access_level:
                filters['access_level'] = request.access_level.value
            if request.classification:
                filters['classification'] = request.classification.value
            if request.tags:
                filters['tags'] = request.tags
            if request.business_terms:
                filters['business_terms'] = request.business_terms
            if request.created_after:
                filters['created_after'] = request.created_after
            if request.created_before:
                filters['created_before'] = request.created_before
            if request.updated_after:
                filters['updated_after'] = request.updated_after
            if request.updated_before:
                filters['updated_before'] = request.updated_before
            
            datasets = self.catalog_repository.find_with_filters(filters, request.limit, request.offset)
            
            total = len(datasets)
            
            return DatasetListResponse(
                datasets=[self._entity_to_response(dataset) for dataset in datasets],
                total=total,
                limit=request.limit,
                offset=request.offset,
                has_more=total > request.offset + request.limit
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to filter datasets: {str(e)}")
    
    async def get_data_lineage(self, request: DataLineageRequest) -> DataLineageResponse:
        """Get data lineage for dataset"""
        try:
            dataset = self.catalog_repository.find_by_id(request.dataset_id)
            if not dataset:
                raise ValueError("Dataset not found")
            
            # Get lineage data
            lineage_data = self.catalog_repository.get_lineage(
                request.dataset_id,
                request.direction.value,
                request.depth
            )
            
            # Convert to response format
            upstream_nodes = []
            downstream_nodes = []
            
            for node_data in lineage_data.get('upstream', []):
                node = DataLineageNodeResponse(
                    dataset_id=node_data['dataset_id'],
                    dataset_name=node_data['dataset_name'],
                    dataset_type=DatasetType(node_data['dataset_type']),
                    organization_name=node_data['organization_name'],
                    level=node_data['level'],
                    relationship_type=node_data['relationship_type'],
                    transformation_logic=node_data.get('transformation_logic')
                )
                upstream_nodes.append(node)
            
            for node_data in lineage_data.get('downstream', []):
                node = DataLineageNodeResponse(
                    dataset_id=node_data['dataset_id'],
                    dataset_name=node_data['dataset_name'],
                    dataset_type=DatasetType(node_data['dataset_type']),
                    organization_name=node_data['organization_name'],
                    level=node_data['level'],
                    relationship_type=node_data['relationship_type'],
                    transformation_logic=node_data.get('transformation_logic')
                )
                downstream_nodes.append(node)
            
            return DataLineageResponse(
                dataset_id=request.dataset_id,
                dataset_name=dataset.name,
                upstream_nodes=upstream_nodes,
                downstream_nodes=downstream_nodes,
                total_upstream=len(upstream_nodes),
                total_downstream=len(downstream_nodes)
            )
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to get data lineage: {str(e)}")
    
    async def profile_dataset(self, request: DatasetProfileRequest) -> DatasetProfileResponse:
        """Profile dataset for quality and structure analysis"""
        try:
            dataset = self.catalog_repository.find_by_id(request.dataset_id)
            if not dataset:
                raise ValueError("Dataset not found")
            
            # Perform data profiling (simplified implementation)
            profile_result = await self.profiling_service.profile_dataset(
                dataset,
                request.sample_size,
                request.include_statistics,
                request.include_patterns,
                request.include_quality
            )
            
            # Create field profiles
            field_profiles = []
            if dataset.schema and 'fields' in dataset.schema:
                for field in dataset.schema['fields']:
                    field_profile = {
                        "field_name": field['name'],
                        "data_type": field['data_type'],
                        "null_count": profile_result.get('null_counts', {}).get(field['name'], 0),
                        "null_percentage": profile_result.get('null_percentages', {}).get(field['name'], 0.0),
                        "unique_count": profile_result.get('unique_counts', {}).get(field['name'], 0),
                        "unique_percentage": profile_result.get('unique_percentages', {}).get(field['name'], 0.0),
                        "min_value": profile_result.get('min_values', {}).get(field['name']),
                        "max_value": profile_result.get('max_values', {}).get(field['name']),
                        "avg_value": profile_result.get('avg_values', {}).get(field['name']),
                        "patterns": profile_result.get('patterns', {}).get(field['name'], []),
                        "quality_score": profile_result.get('field_quality_scores', {}).get(field['name'], 100.0)
                    }
                    field_profiles.append(field_profile)
            
            # Identify data quality issues
            data_quality_issues = profile_result.get('quality_issues', [])
            
            # Generate suggested improvements
            suggested_improvements = profile_result.get('suggestions', [])
            
            return DatasetProfileResponse(
                dataset_id=request.dataset_id,
                dataset_name=dataset.name,
                profiling_date=datetime.utcnow(),
                total_records=profile_result.get('total_records', dataset.row_count or 0),
                total_columns=profile_result.get('total_columns', dataset.column_count or 0),
                size_bytes=profile_result.get('size_bytes', dataset.size_bytes or 0),
                field_profiles=field_profiles,
                data_quality_issues=data_quality_issues,
                suggested_improvements=suggested_improvements,
                overall_quality_score=profile_result.get('overall_quality_score', 100.0)
            )
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to profile dataset: {str(e)}")
    
    async def get_catalog_statistics(self, organization_id: UUID) -> CatalogStatisticsResponse:
        """Get catalog statistics for organization"""
        try:
            stats = self.catalog_repository.get_statistics(organization_id)
            
            # Get popular datasets
            popular_datasets = self.catalog_repository.find_popular_datasets(organization_id, 5)
            popular_summaries = [self._entity_to_summary(dataset) for dataset in popular_datasets]
            
            # Get recently updated datasets
            recent_datasets = self.catalog_repository.find_recently_updated(organization_id, 5)
            recent_summaries = [self._entity_to_summary(dataset) for dataset in recent_datasets]
            
            return CatalogStatisticsResponse(
                organization_id=organization_id,
                total_datasets=stats['total_datasets'],
                active_datasets=stats['active_datasets'],
                datasets_by_type=stats['datasets_by_type'],
                datasets_by_classification=stats['datasets_by_classification'],
                total_data_size=stats['total_data_size'],
                average_quality_score=stats['average_quality_score'],
                most_popular_datasets=popular_summaries,
                recently_updated_datasets=recent_summaries
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to get catalog statistics: {str(e)}")
    
    async def discover_data(self, search_term: str, organization_id: Optional[UUID] = None,
                           limit: int = 50, offset: int = 0) -> DataDiscoveryResponse:
        """Discover data using intelligent search"""
        try:
            # Perform intelligent search
            search_results = await self.discovery_service.discover_datasets(
                search_term, organization_id, limit, offset
            )
            
            # Convert results to summaries
            dataset_summaries = []
            for dataset in search_results['datasets']:
                summary = self._entity_to_summary(dataset)
                dataset_summaries.append(summary)
            
            return DataDiscoveryResponse(
                search_term=search_term,
                total_results=search_results['total'],
                datasets=dataset_summaries,
                suggested_terms=search_results.get('suggested_terms', []),
                facets=search_results.get('facets', {})
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to discover data: {str(e)}")
    
    async def bulk_update_datasets(self, request: BulkDatasetOperationRequest) -> BulkDatasetOperationResponse:
        """Perform bulk operations on datasets"""
        try:
            results = []
            errors = []
            successful = 0
            failed = 0
            
            for dataset_id in request.dataset_ids:
                try:
                    if request.operation == "activate":
                        dataset = self.catalog_repository.find_by_id(dataset_id)
                        if dataset:
                            dataset.status = DatasetStatus.ACTIVE
                            dataset.updated_at = datetime.utcnow()
                            self.catalog_repository.save(dataset)
                            results.append({"dataset_id": dataset_id, "status": "success"})
                            successful += 1
                        else:
                            errors.append({"dataset_id": dataset_id, "error": "Dataset not found"})
                            failed += 1
                    
                    elif request.operation == "deactivate":
                        dataset = self.catalog_repository.find_by_id(dataset_id)
                        if dataset:
                            dataset.status = DatasetStatus.DEPRECATED
                            dataset.updated_at = datetime.utcnow()
                            self.catalog_repository.save(dataset)
                            results.append({"dataset_id": dataset_id, "status": "success"})
                            successful += 1
                        else:
                            errors.append({"dataset_id": dataset_id, "error": "Dataset not found"})
                            failed += 1
                    
                    elif request.operation == "delete":
                        success = self.catalog_repository.delete(dataset_id)
                        if success:
                            results.append({"dataset_id": dataset_id, "status": "success"})
                            successful += 1
                        else:
                            errors.append({"dataset_id": dataset_id, "error": "Dataset not found"})
                            failed += 1
                    
                    else:
                        errors.append({"dataset_id": dataset_id, "error": f"Unknown operation: {request.operation}"})
                        failed += 1
                
                except Exception as e:
                    errors.append({"dataset_id": dataset_id, "error": str(e)})
                    failed += 1
            
            return BulkDatasetOperationResponse(
                operation=request.operation,
                total_requested=len(request.dataset_ids),
                successful=successful,
                failed=failed,
                results=results,
                errors=errors
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to perform bulk operation: {str(e)}")
    
    async def _validate_schema(self, schema: DatasetSchemaDTO):
        """Validate dataset schema"""
        if not schema.fields:
            raise ValueError("Schema must have at least one field")
        
        field_names = [field.name for field in schema.fields]
        if len(field_names) != len(set(field_names)):
            raise ValueError("Schema fields must have unique names")
        
        # Validate primary keys exist in fields
        if schema.primary_keys:
            for pk in schema.primary_keys:
                if pk not in field_names:
                    raise ValueError(f"Primary key '{pk}' not found in schema fields")
    
    def _entity_to_response(self, dataset: DatasetEntity) -> DatasetResponse:
        """Convert dataset entity to response DTO"""
        # Create location DTO
        location = DatasetLocationDTO(**dataset.location) if dataset.location else None
        
        # Create schema DTO
        schema = None
        if dataset.schema:
            try:
                schema = DatasetSchemaDTO(**dataset.schema)
            except Exception as e:
        logger.error(f"Erro inesperado: {e}")
                schema = None
        
        # Create metrics DTO
        metrics = DatasetMetricsDTO(
            row_count=dataset.row_count,
            column_count=dataset.column_count,
            size_bytes=dataset.size_bytes,
            last_updated=dataset.updated_at,
            quality_score=dataset.quality_score
        )
        
        # Create usage DTO
        usage = DatasetUsageDTO(
            popularity_score=dataset.popularity_score
        )
        
        return DatasetResponse(
            id=dataset.id,
            name=dataset.name,
            title=dataset.title,
            description=dataset.description,
            dataset_type=dataset.dataset_type,
            status=dataset.status,
            organization_id=dataset.organization_id,
            organization_name=dataset.organization_name,
            owner_id=dataset.owner_id,
            owner_name=dataset.owner_name,
            location=location,
            schema=schema,
            access_level=dataset.access_level,
            classification=dataset.classification,
            tags=dataset.tags,
            business_terms=dataset.business_terms,
            metadata=dataset.metadata,
            metrics=metrics,
            usage=usage,
            created_by=dataset.created_by,
            created_by_name=dataset.created_by_name,
            created_at=dataset.created_at,
            updated_at=dataset.updated_at
        )
    
    def _entity_to_summary(self, dataset: DatasetEntity) -> DatasetSummaryResponse:
        """Convert dataset entity to summary DTO"""
        return DatasetSummaryResponse(
            id=dataset.id,
            name=dataset.name,
            title=dataset.title,
            dataset_type=dataset.dataset_type,
            status=dataset.status,
            organization_name=dataset.organization_name,
            owner_name=dataset.owner_name,
            access_level=dataset.access_level,
            classification=dataset.classification,
            tags=dataset.tags,
            quality_score=dataset.quality_score,
            popularity_score=dataset.popularity_score,
            last_updated=dataset.updated_at
        )

