"""
Contract Service - Serviço de aplicação para contratos
Segue princípios SOLID - orquestra operações de domínio
"""

import re
from typing import List, Dict, Any, Optional
from datetime import datetime


class PIIDetectionService:
    """
    Serviço para detecção de PII (Personally Identifiable Information)
    Responsabilidade única: detectar campos que contêm informações pessoais
    """
    
    def __init__(self):
        # Padrões para detecção de PII
        self.pii_patterns = {
            'email': r'email|e-mail|mail',
            'cpf': r'cpf|documento|doc',
            'phone': r'phone|telefone|celular|fone',
            'name': r'name|nome|first_name|last_name|full_name',
            'address': r'address|endereco|rua|street',
            'birth': r'birth|nascimento|data_nascimento|birthday',
            'id': r'identity|identidade|rg|cnh',
            'credit_card': r'credit|cartao|card_number',
            'bank': r'bank|banco|conta|account',
            'salary': r'salary|salario|renda|income'
        }
    
    def detect_pii_fields(self, schema_definition: Dict[str, Any]) -> List[str]:
        """
        Detecta campos PII em uma definição de schema
        """
        pii_fields = []
        
        if not schema_definition or 'fields' not in schema_definition:
            return pii_fields
        
        fields = schema_definition.get('fields', [])
        
        for field in fields:
            if not isinstance(field, dict):
                continue
            
            field_name = field.get('name', '').lower()
            field_description = field.get('description', '').lower()
            
            # Verificar se campo está explicitamente marcado como PII
            if field.get('is_pii', False):
                pii_fields.append(field.get('name'))
                continue
            
            # Detectar PII por padrões no nome
            for pii_type, pattern in self.pii_patterns.items():
                if re.search(pattern, field_name, re.IGNORECASE):
                    pii_fields.append(field.get('name'))
                    break
            
            # Detectar PII por padrões na descrição
            else:
                for pii_type, pattern in self.pii_patterns.items():
                    if re.search(pattern, field_description, re.IGNORECASE):
                        pii_fields.append(field.get('name'))
                        break
        
        return list(set(pii_fields))  # Remover duplicatas


class ContractTemplateService:
    """
    Serviço para gerenciamento de templates de contratos
    Responsabilidade única: operações relacionadas a templates
    """
    
    def __init__(self):
        # Templates predefinidos
        self.templates = {
            'basic': {
                'id': 'basic',
                'name': 'Contrato Básico',
                'description': 'Template básico para contratos de dados',
                'schema_template': {
                    'type': 'object',
                    'fields': [
                        {
                            'name': 'id',
                            'type': 'string',
                            'required': True,
                            'description': 'Identificador único'
                        }
                    ]
                },
                'default_classification': 'internal',
                'required_compliance': []
            },
            'pii_data': {
                'id': 'pii_data',
                'name': 'Dados Pessoais',
                'description': 'Template para dados que contêm informações pessoais',
                'schema_template': {
                    'type': 'object',
                    'fields': [
                        {
                            'name': 'id',
                            'type': 'string',
                            'required': True,
                            'description': 'Identificador único'
                        },
                        {
                            'name': 'created_at',
                            'type': 'timestamp',
                            'required': True,
                            'description': 'Data de criação'
                        }
                    ]
                },
                'default_classification': 'confidential',
                'required_compliance': ['LGPD']
            },
            'financial': {
                'id': 'financial',
                'name': 'Dados Financeiros',
                'description': 'Template para dados financeiros sensíveis',
                'schema_template': {
                    'type': 'object',
                    'fields': [
                        {
                            'name': 'id',
                            'type': 'string',
                            'required': True,
                            'description': 'Identificador único'
                        },
                        {
                            'name': 'amount',
                            'type': 'decimal',
                            'required': True,
                            'description': 'Valor monetário'
                        },
                        {
                            'name': 'currency',
                            'type': 'string',
                            'required': True,
                            'description': 'Moeda'
                        }
                    ]
                },
                'default_classification': 'restricted',
                'required_compliance': ['SOX', 'PCI-DSS']
            }
        }
    
    def get_template(self, template_id: str) -> Optional[Dict[str, Any]]:
        """Retorna template por ID"""
        return self.templates.get(template_id)
    
    def list_templates(self) -> List[Dict[str, Any]]:
        """Lista todos os templates disponíveis"""
        return list(self.templates.values())
    
    def apply_template(self, template_id: str, custom_fields: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        """
        Aplica template e adiciona campos customizados
        """
        template = self.get_template(template_id)
        if not template:
            raise ValueError(f"Template '{template_id}' não encontrado")
        
        # Copiar schema do template
        schema = template['schema_template'].copy()
        
        # Adicionar campos customizados
        if custom_fields:
            schema['fields'].extend(custom_fields)
        
        return {
            'template_id': template_id,
            'template_name': template['name'],
            'schema_definition': schema,
            'default_classification': template['default_classification'],
            'required_compliance': template['required_compliance']
        }


class ContractService:
    """
    Serviço principal de contratos
    Orquestra operações complexas envolvendo múltiplos serviços
    """
    
    def __init__(self):
        self.pii_detection_service = PIIDetectionService()
        self.template_service = ContractTemplateService()
    
    async def detect_pii_fields(self, schema_definition: Dict[str, Any]) -> List[str]:
        """Detecta campos PII em schema"""
        return self.pii_detection_service.detect_pii_fields(schema_definition)
    
    async def create_from_template(self, 
        """Executa operação create_from_template."""
                                 template_id: str, 
                                 contract_data: Dict[str, Any],
                                 custom_fields: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        """
        Cria contrato a partir de template
        """
        try:
            # Aplicar template
            template_result = self.template_service.apply_template(template_id, custom_fields)
            
            # Mesclar dados do contrato com template
            contract_data.update({
                'template_id': template_result['template_id'],
                'template_name': template_result['template_name'],
                'schema_definition': template_result['schema_definition']
            })
            
            # Usar classificação padrão se não fornecida
            if 'data_classification' not in contract_data:
                contract_data['data_classification'] = template_result['default_classification']
            
            # Adicionar compliance obrigatório do template
            existing_compliance = contract_data.get('compliance_requirements', [])
            required_compliance = template_result['required_compliance']
            
            all_compliance = list(set(existing_compliance + required_compliance))
            contract_data['compliance_requirements'] = all_compliance
            
            # Detectar PII automaticamente
            pii_fields = await self.detect_pii_fields(template_result['schema_definition'])
            contract_data['pii_fields'] = pii_fields
            
            return contract_data
            
        except Exception as e:
            raise ValueError(f"Erro ao criar contrato a partir do template: {str(e)}")
    
    async def generate_compliance_report(self, contract_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Gera relatório de compliance para um contrato
        """
        report = {
            'contract_id': contract_data.get('id'),
            'contract_name': contract_data.get('name'),
            'classification': contract_data.get('data_classification'),
            'compliance_frameworks': contract_data.get('compliance_requirements', []),
            'pii_detected': bool(contract_data.get('pii_fields')),
            'pii_fields': contract_data.get('pii_fields', []),
            'recommendations': [],
            'risks': [],
            'generated_at': datetime.now().isoformat()
        }
        
        # Análise de riscos baseada na classificação
        classification = contract_data.get('data_classification')
        if classification == 'restricted':
            if not contract_data.get('compliance_requirements'):
                report['risks'].append('Dados restritos sem frameworks de compliance definidos')
            
            if not contract_data.get('sla_requirements'):
                report['recommendations'].append('Definir SLA para dados restritos')
        
        # Análise de PII
        if contract_data.get('pii_fields'):
            if 'LGPD' not in contract_data.get('compliance_requirements', []):
                report['risks'].append('Dados pessoais detectados sem compliance LGPD')
                report['recommendations'].append('Adicionar framework LGPD para dados pessoais')
        
        # Análise de schema
        if not contract_data.get('schema_definition'):
            report['recommendations'].append('Definir schema estruturado para melhor governança')
        
        return report
    
    def get_available_templates(self) -> List[Dict[str, Any]]:
        """Retorna templates disponíveis"""
        return self.template_service.list_templates()
    
    def validate_template_compatibility(self, template_id: str, schema_definition: Dict[str, Any]) -> bool:
        """
        Valida se schema é compatível com template
        """
        template = self.template_service.get_template(template_id)
        if not template:
            return False
        
        template_fields = {f['name'] for f in template['schema_template'].get('fields', [])}
        schema_fields = {f['name'] for f in schema_definition.get('fields', [])}
        
        # Template deve ter todos os campos obrigatórios
        required_fields = {f['name'] for f in template['schema_template'].get('fields', []) 
                          if f.get('required', False)}
        
        return required_fields.issubset(schema_fields)

