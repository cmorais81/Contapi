#!/usr/bin/env python3
"""
Extensões Databricks para Contract Service
Adiciona funcionalidades de integração com Databricks Unity Catalog
"""

import asyncio
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
import httpx
import asyncpg
from fastapi import HTTPException, status

logger = logging.getLogger(__name__)

@dataclass
class DatabricksTableMapping:
    """Mapeamento entre contrato e tabela Databricks"""
    contract_id: str
    catalog_name: str
    schema_name: str
    table_name: str
    mapping_type: str = "direct"
    sync_enabled: bool = True
    auto_update_classifications: bool = True
    auto_create_monitors: bool = True

class DatabricksContractExtensions:
    """Extensões do Contract Service para integração Databricks"""
    
    def __init__(self, db_pool: asyncpg.Pool, databricks_service_url: str = "http://localhost:8010"):
        self.db_pool = db_pool
        self.databricks_service_url = databricks_service_url
        self.http_client = httpx.AsyncClient(timeout=30.0)
        self.logger = logging.getLogger(f"{__name__}.DatabricksContractExtensions")
    
    async def create_contract_with_databricks_mapping(
        self,
        contract_data: Dict[str, Any],
        databricks_mapping: DatabricksTableMapping
    ) -> Dict[str, Any]:
        """Cria contrato com mapeamento Databricks"""
        self.logger.info(f"Creating contract with Databricks mapping: {databricks_mapping.table_name}")
        
        try:
            # Valida se a tabela existe no Databricks
            table_info = await self._get_databricks_table_info(
                databricks_mapping.catalog_name,
                databricks_mapping.schema_name,
                databricks_mapping.table_name
            )
            
            if not table_info:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Table {databricks_mapping.catalog_name}.{databricks_mapping.schema_name}.{databricks_mapping.table_name} not found in Databricks"
                )
            
            # Enriquece dados do contrato com informações do Databricks
            enriched_contract = await self._enrich_contract_with_databricks_metadata(
                contract_data, table_info
            )
            
            # Cria o contrato (simulação - em produção chamaria o Contract Service)
            contract_id = await self._create_contract(enriched_contract)
            
            # Cria mapeamento no banco
            databricks_mapping.contract_id = contract_id
            await self._store_databricks_mapping(databricks_mapping)
            
            # Se habilitado, cria classificações automáticas
            if databricks_mapping.auto_update_classifications:
                await self._sync_databricks_classifications(databricks_mapping)
            
            # Se habilitado, cria monitores de qualidade
            if databricks_mapping.auto_create_monitors:
                await self._create_quality_monitors(databricks_mapping)
            
            self.logger.info(f"Contract created with Databricks integration: {contract_id}")
            
            return {
                "contract_id": contract_id,
                "databricks_mapping": {
                    "table_name": f"{databricks_mapping.catalog_name}.{databricks_mapping.schema_name}.{databricks_mapping.table_name}",
                    "mapping_type": databricks_mapping.mapping_type,
                    "sync_enabled": databricks_mapping.sync_enabled,
                    "classifications_synced": databricks_mapping.auto_update_classifications,
                    "monitors_created": databricks_mapping.auto_create_monitors
                },
                "table_info": table_info,
                "created_at": datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Failed to create contract with Databricks mapping: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Contract creation failed: {str(e)}"
            )
    
    async def sync_contract_with_databricks(self, contract_id: str) -> Dict[str, Any]:
        """Sincroniza contrato existente com Databricks"""
        self.logger.info(f"Syncing contract {contract_id} with Databricks")
        
        try:
            # Busca mapeamento do contrato
            mapping = await self._get_contract_databricks_mapping(contract_id)
            if not mapping:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"No Databricks mapping found for contract {contract_id}"
                )
            
            # Busca informações atualizadas da tabela
            table_info = await self._get_databricks_table_info(
                mapping["catalog_name"],
                mapping["schema_name"],
                mapping["table_name"]
            )
            
            sync_results = {
                "contract_id": contract_id,
                "table_name": f"{mapping['catalog_name']}.{mapping['schema_name']}.{mapping['table_name']}",
                "sync_timestamp": datetime.now().isoformat(),
                "changes_detected": [],
                "classifications_updated": 0,
                "monitors_updated": 0
            }
            
            # Atualiza classificações se habilitado
            if mapping.get("auto_update_classifications", True):
                classifications_result = await self._sync_databricks_classifications(
                    DatabricksTableMapping(**mapping)
                )
                sync_results["classifications_updated"] = classifications_result.get("updated_count", 0)
                if classifications_result.get("updated_count", 0) > 0:
                    sync_results["changes_detected"].append("classifications")
            
            # Atualiza monitores se habilitado
            if mapping.get("auto_create_monitors", True):
                monitors_result = await self._update_quality_monitors(
                    DatabricksTableMapping(**mapping)
                )
                sync_results["monitors_updated"] = monitors_result.get("updated_count", 0)
                if monitors_result.get("updated_count", 0) > 0:
                    sync_results["changes_detected"].append("quality_monitors")
            
            # Atualiza timestamp da última sincronização
            await self._update_mapping_sync_timestamp(contract_id)
            
            self.logger.info(f"Contract sync completed: {sync_results}")
            return sync_results
            
        except Exception as e:
            self.logger.error(f"Failed to sync contract {contract_id} with Databricks: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Sync failed: {str(e)}"
            )
    
    async def get_contract_databricks_status(self, contract_id: str) -> Dict[str, Any]:
        """Obtém status da integração Databricks para um contrato"""
        try:
            # Busca mapeamento
            mapping = await self._get_contract_databricks_mapping(contract_id)
            if not mapping:
                return {
                    "contract_id": contract_id,
                    "databricks_integration": False,
                    "message": "No Databricks mapping found"
                }
            
            # Busca classificações
            classifications = await self._get_contract_classifications(contract_id)
            
            # Busca monitores de qualidade
            monitors = await self._get_contract_quality_monitors(contract_id)
            
            # Busca última sincronização
            last_sync = await self._get_last_sync_info(contract_id)
            
            return {
                "contract_id": contract_id,
                "databricks_integration": True,
                "table_name": f"{mapping['catalog_name']}.{mapping['schema_name']}.{mapping['table_name']}",
                "mapping_type": mapping.get("mapping_type", "direct"),
                "sync_enabled": mapping.get("sync_enabled", True),
                "classifications": {
                    "count": len(classifications),
                    "types": list(set(c["classification_type"] for c in classifications)),
                    "last_updated": max([c["scan_timestamp"] for c in classifications]) if classifications else None
                },
                "quality_monitors": {
                    "count": len(monitors),
                    "active_monitors": len([m for m in monitors if m["status"] == "ACTIVE"]),
                    "last_run": max([m.get("last_run") for m in monitors if m.get("last_run")]) if monitors else None
                },
                "last_sync": last_sync,
                "status": "healthy" if mapping.get("sync_enabled") else "disabled"
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get Databricks status for contract {contract_id}: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Status check failed: {str(e)}"
            )
    
    async def list_contracts_with_databricks_integration(self) -> List[Dict[str, Any]]:
        """Lista todos os contratos com integração Databricks"""
        try:
            async with self.db_pool.acquire() as conn:
                rows = await conn.fetch("""
                    SELECT 
                        dcm.contract_id,
                        dcm.catalog_name,
                        dcm.schema_name,
                        dcm.table_name,
                        dcm.mapping_type,
                        dcm.sync_enabled,
                        dcm.auto_update_classifications,
                        dcm.auto_create_monitors,
                        dcm.created_at,
                        dcm.updated_at,
                        COUNT(dc.id) as classification_count,
                        COUNT(dqm.id) as monitor_count
                    FROM databricks_contract_mappings dcm
                    LEFT JOIN databricks_classifications dc ON 
                        dc.table_name = CONCAT(dcm.catalog_name, '.', dcm.schema_name, '.', dcm.table_name)
                    LEFT JOIN databricks_quality_monitors dqm ON 
                        dqm.table_name = CONCAT(dcm.catalog_name, '.', dcm.schema_name, '.', dcm.table_name)
                    GROUP BY dcm.contract_id, dcm.catalog_name, dcm.schema_name, dcm.table_name,
                             dcm.mapping_type, dcm.sync_enabled, dcm.auto_update_classifications,
                             dcm.auto_create_monitors, dcm.created_at, dcm.updated_at
                    ORDER BY dcm.updated_at DESC
                """)
                
                contracts = []
                for row in rows:
                    contracts.append({
                        "contract_id": row["contract_id"],
                        "table_name": f"{row['catalog_name']}.{row['schema_name']}.{row['table_name']}",
                        "mapping_type": row["mapping_type"],
                        "sync_enabled": row["sync_enabled"],
                        "auto_update_classifications": row["auto_update_classifications"],
                        "auto_create_monitors": row["auto_create_monitors"],
                        "classification_count": row["classification_count"],
                        "monitor_count": row["monitor_count"],
                        "created_at": row["created_at"].isoformat(),
                        "updated_at": row["updated_at"].isoformat()
                    })
                
                return contracts
                
        except Exception as e:
            self.logger.error(f"Failed to list contracts with Databricks integration: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"List failed: {str(e)}"
            )
    
    # Métodos privados auxiliares
    
    async def _get_databricks_table_info(self, catalog_name: str, schema_name: str, table_name: str) -> Optional[Dict[str, Any]]:
        """Obtém informações de uma tabela do Databricks"""
        try:
            response = await self.http_client.get(
                f"{self.databricks_service_url}/api/v1/tables/{catalog_name}/{schema_name}/{table_name}/info"
            )
            if response.status_code == 200:
                return response.json()
            return None
        except Exception as e:
            self.logger.error(f"Failed to get table info from Databricks: {e}")
            return None
    
    async def _enrich_contract_with_databricks_metadata(
        self, 
        contract_data: Dict[str, Any], 
        table_info: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Enriquece dados do contrato com metadados do Databricks"""
        enriched = contract_data.copy()
        
        # Adiciona informações da tabela
        enriched["databricks_metadata"] = {
            "catalog_name": table_info["catalog_name"],
            "schema_name": table_info["schema_name"],
            "table_name": table_info["table_name"],
            "table_type": table_info["table_type"],
            "owner": table_info.get("owner"),
            "comment": table_info.get("comment"),
            "columns": table_info["columns"],
            "sync_timestamp": datetime.now().isoformat()
        }
        
        # Se não há schema definido no contrato, usa as colunas do Databricks
        if not enriched.get("schema") and table_info.get("columns"):
            enriched["schema"] = {
                "fields": [
                    {
                        "name": col["name"],
                        "type": col["type_name"],
                        "description": col.get("comment", ""),
                        "nullable": True,  # Databricks não fornece info de nullable via mock
                        "source": "databricks"
                    }
                    for col in table_info["columns"]
                ]
            }
        
        return enriched
    
    async def _create_contract(self, contract_data: Dict[str, Any]) -> str:
        """Cria contrato (simulação)"""
        # Em produção, faria chamada para o Contract Service
        contract_id = f"contract_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Simula armazenamento no banco
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO contracts (id, name, version, status, data, created_at, updated_at)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
            """,
                contract_id,
                contract_data.get("name", "Databricks Contract"),
                contract_data.get("version", "1.0.0"),
                "active",
                str(contract_data),  # JSON como string
                datetime.now(),
                datetime.now()
            )
        
        return contract_id
    
    async def _store_databricks_mapping(self, mapping: DatabricksTableMapping):
        """Armazena mapeamento Databricks no banco"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO databricks_contract_mappings (
                    contract_id, catalog_name, schema_name, table_name,
                    mapping_type, sync_enabled, auto_update_classifications,
                    auto_create_monitors, created_at, updated_at
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            """,
                mapping.contract_id,
                mapping.catalog_name,
                mapping.schema_name,
                mapping.table_name,
                mapping.mapping_type,
                mapping.sync_enabled,
                mapping.auto_update_classifications,
                mapping.auto_create_monitors,
                datetime.now(),
                datetime.now()
            )
    
    async def _sync_databricks_classifications(self, mapping: DatabricksTableMapping) -> Dict[str, Any]:
        """Sincroniza classificações do Databricks"""
        try:
            # Busca classificações do Databricks
            response = await self.http_client.get(
                f"{self.databricks_service_url}/api/v1/classifications/{mapping.catalog_name}/{mapping.schema_name}/{mapping.table_name}"
            )
            
            if response.status_code == 200:
                classifications_data = response.json()
                classifications = classifications_data.get("classifications", [])
                
                # Atualiza classificações no banco local
                updated_count = 0
                async with self.db_pool.acquire() as conn:
                    for classification in classifications:
                        await conn.execute("""
                            INSERT INTO databricks_classifications (
                                table_name, column_name, classification_type,
                                confidence, rationale, scan_timestamp, created_at
                            ) VALUES ($1, $2, $3, $4, $5, $6, $7)
                            ON CONFLICT (table_name, column_name, classification_type)
                            DO UPDATE SET
                                confidence = EXCLUDED.confidence,
                                rationale = EXCLUDED.rationale,
                                scan_timestamp = EXCLUDED.scan_timestamp,
                                created_at = EXCLUDED.created_at
                        """,
                            classification["table_name"],
                            classification["column_name"],
                            classification["classification_type"],
                            classification["confidence"],
                            classification["rationale"],
                            datetime.fromisoformat(classification["scan_timestamp"].replace('Z', '+00:00')),
                            datetime.now()
                        )
                        updated_count += 1
                
                return {"updated_count": updated_count, "status": "success"}
            else:
                return {"updated_count": 0, "status": "failed", "error": "Databricks API error"}
                
        except Exception as e:
            self.logger.error(f"Failed to sync classifications: {e}")
            return {"updated_count": 0, "status": "error", "error": str(e)}
    
    async def _create_quality_monitors(self, mapping: DatabricksTableMapping) -> Dict[str, Any]:
        """Cria monitores de qualidade no Databricks"""
        try:
            # Define regras básicas de qualidade
            quality_rules = [
                {"rule_type": "not_null", "column": "id", "threshold": 1.0},
                {"rule_type": "unique", "column": "id", "threshold": 1.0}
            ]
            
            # Cria monitor via Databricks Integration Service
            monitor_request = {
                "table_name": f"{mapping.catalog_name}.{mapping.schema_name}.{mapping.table_name}",
                "rules": quality_rules,
                "schedule": "daily",
                "alert_threshold": 0.95
            }
            
            response = await self.http_client.post(
                f"{self.databricks_service_url}/api/v1/quality/monitors",
                json=monitor_request
            )
            
            if response.status_code == 200:
                monitor_data = response.json()
                return {"monitor_id": monitor_data["monitor_id"], "status": "created"}
            else:
                return {"status": "failed", "error": "Failed to create monitor"}
                
        except Exception as e:
            self.logger.error(f"Failed to create quality monitors: {e}")
            return {"status": "error", "error": str(e)}
    
    async def _update_quality_monitors(self, mapping: DatabricksTableMapping) -> Dict[str, Any]:
        """Atualiza monitores de qualidade existentes"""
        # Implementação simplificada - em produção faria update real
        return {"updated_count": 1, "status": "updated"}
    
    async def _get_contract_databricks_mapping(self, contract_id: str) -> Optional[Dict[str, Any]]:
        """Busca mapeamento Databricks de um contrato"""
        async with self.db_pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT * FROM databricks_contract_mappings WHERE contract_id = $1
            """, contract_id)
            
            if row:
                return dict(row)
            return None
    
    async def _get_contract_classifications(self, contract_id: str) -> List[Dict[str, Any]]:
        """Busca classificações de um contrato"""
        mapping = await self._get_contract_databricks_mapping(contract_id)
        if not mapping:
            return []
        
        table_name = f"{mapping['catalog_name']}.{mapping['schema_name']}.{mapping['table_name']}"
        
        async with self.db_pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT * FROM databricks_classifications WHERE table_name = $1
            """, table_name)
            
            return [dict(row) for row in rows]
    
    async def _get_contract_quality_monitors(self, contract_id: str) -> List[Dict[str, Any]]:
        """Busca monitores de qualidade de um contrato"""
        mapping = await self._get_contract_databricks_mapping(contract_id)
        if not mapping:
            return []
        
        table_name = f"{mapping['catalog_name']}.{mapping['schema_name']}.{mapping['table_name']}"
        
        async with self.db_pool.acquire() as conn:
            rows = await conn.fetch("""
                SELECT * FROM databricks_quality_monitors WHERE table_name = $1
            """, table_name)
            
            return [dict(row) for row in rows]
    
    async def _get_last_sync_info(self, contract_id: str) -> Optional[Dict[str, Any]]:
        """Busca informações da última sincronização"""
        async with self.db_pool.acquire() as conn:
            row = await conn.fetchrow("""
                SELECT updated_at FROM databricks_contract_mappings WHERE contract_id = $1
            """, contract_id)
            
            if row:
                return {
                    "last_sync": row["updated_at"].isoformat(),
                    "status": "completed"
                }
            return None
    
    async def _update_mapping_sync_timestamp(self, contract_id: str):
        """Atualiza timestamp da última sincronização"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                UPDATE databricks_contract_mappings 
                SET updated_at = $1 
                WHERE contract_id = $2
            """, datetime.now(), contract_id)
    
    async def cleanup(self):
        """Limpa recursos"""
        await self.http_client.aclose()

