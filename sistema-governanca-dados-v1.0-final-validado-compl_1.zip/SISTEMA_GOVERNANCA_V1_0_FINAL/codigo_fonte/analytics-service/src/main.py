# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
Analytics Service - Microserviço de Analytics e Métricas
Versão: 4.0.1 - Corrigida com base na V3.2
Data: 27 de Janeiro de 2025
"""

import logging
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from uuid import uuid4
import random

from fastapi import FastAPI, HTTPException, Query, Path, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'config'))

try:
    from settings import get_settings
    settings = get_settings()
except ImportError:
    print("⚠️ Configurações centralizadas não encontradas, usando valores padrão")
    settings = None


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Analytics Service",
    description="Microserviço para analytics e métricas de governança - V4.0 Corrigido",
    version="4.0.1",
    contact={
        "name": " ",
        "email": "@example.com"
    }
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# PYDANTIC MODELS
# =====================================================

class MetricBase(BaseModel):
    name: str = Field(..., description="Nome da métrica")
    description: Optional[str] = Field(None, description="Descrição da métrica")
    metric_type: str = Field(..., description="Tipo da métrica")
    category: str = Field(..., description="Categoria da métrica")
    unit: Optional[str] = Field(None, description="Unidade de medida")

class MetricCreate(MetricBase):
    pass

class MetricResponse(MetricBase):
    id: str
    created_at: datetime
    updated_at: datetime
    is_active: bool

class MetricValueBase(BaseModel):
    metric_id: str = Field(..., description="ID da métrica")
    value: float = Field(..., description="Valor da métrica")
    timestamp: datetime = Field(..., description="Timestamp do valor")
    dimensions: Optional[Dict[str, Any]] = Field(None, description="Dimensões adicionais")

class MetricValueCreate(MetricValueBase):
    pass

class MetricValueResponse(MetricValueBase):
    id: str
    created_at: datetime

class ReportBase(BaseModel):
    name: str = Field(..., description="Nome do relatório")
    description: Optional[str] = Field(None, description="Descrição do relatório")
    report_type: str = Field(..., description="Tipo do relatório")
    frequency: str = Field("daily", description="Frequência de geração")
    recipients: List[str] = Field(default_factory=list, description="Lista de destinatários")

class ReportCreate(ReportBase):
    pass

class ReportResponse(ReportBase):
    id: str
    created_at: datetime
    updated_at: datetime
    last_generated: Optional[datetime]
    is_active: bool

class DashboardRequest(BaseModel):
    metrics: List[str] = Field(..., description="Lista de IDs de métricas")
    time_range: str = Field("7d", description="Período de tempo")
    group_by: Optional[str] = Field(None, description="Agrupar por dimensão")

# =====================================================
# IN-MEMORY DATABASE (Simulação)
# =====================================================

metrics_db = {}
metric_values_db = {}
reports_db = {}
audit_logs = []

def log_audit(action: str, resource_id: str = None, details: str = None):
    """Log audit trail"""
    try:
        audit_logs.append({
            "id": str(uuid4()),
            "action": action,
            "resource_type": "analytics",
            "resource_id": resource_id,
            "details": details,
            "created_at": datetime.utcnow().isoformat()
        })
    except Exception as e:
        logger.error(f"Error logging audit: {e}")

def generate_sample_data():
    """Generate sample metrics and values"""
    sample_metrics = [
        {
            "id": str(uuid4()),
            "name": "data_quality_score",
            "description": "Score geral de qualidade dos dados",
            "metric_type": "percentage",
            "category": "quality",
            "unit": "percent",
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "contracts_created",
            "description": "Número de contratos criados",
            "metric_type": "counter",
            "category": "contracts",
            "unit": "count",
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "pii_detected",
            "description": "Quantidade de PII detectado",
            "metric_type": "counter",
            "category": "privacy",
            "unit": "count",
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "compliance_score",
            "description": "Score de compliance LGPD/GDPR",
            "metric_type": "percentage",
            "category": "compliance",
            "unit": "percent",
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "entities_cataloged",
            "description": "Número de entidades catalogadas",
            "metric_type": "gauge",
            "category": "catalog",
            "unit": "count",
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
    ]
    
    for metric in sample_metrics:
        metrics_db[metric["id"]] = metric
    
    # Generate sample values for the last 30 days
    for metric in sample_metrics:
        for i in range(30):
            date = datetime.utcnow() - timedelta(days=i)
            
            # Generate realistic values based on metric type
            if metric["name"] == "data_quality_score":
                value = random.uniform(75, 95)
            elif metric["name"] == "contracts_created":
                value = random.randint(0, 5)
            elif metric["name"] == "pii_detected":
                value = random.randint(10, 50)
            elif metric["name"] == "compliance_score":
                value = random.uniform(60, 85)
            elif metric["name"] == "entities_cataloged":
                value = random.randint(100, 150)
            else:
                value = random.uniform(0, 100)
            
            value_id = str(uuid4())
            metric_values_db[value_id] = {
                "id": value_id,
                "metric_id": metric["id"],
                "value": value,
                "timestamp": date,
                "dimensions": {
                    "source": "system",
                    "environment": "production"
                },
                "created_at": datetime.utcnow()
            }
    
    # Sample reports
    sample_reports = [
        {
            "id": str(uuid4()),
            "name": "Daily Governance Report",
            "description": "Relatório diário de métricas de governança",
            "report_type": "governance_summary",
            "frequency": "daily",
            "recipients": ["admin@empresa.com", "data-team@empresa.com"],
            "last_generated": datetime.utcnow() - timedelta(hours=2),
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "Weekly Quality Report",
            "description": "Relatório semanal de qualidade de dados",
            "report_type": "quality_summary",
            "frequency": "weekly",
            "recipients": ["quality-team@empresa.com"],
            "last_generated": datetime.utcnow() - timedelta(days=1),
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "Monthly Compliance Report",
            "description": "Relatório mensal de compliance",
            "report_type": "compliance_summary",
            "frequency": "monthly",
            "recipients": ["compliance@empresa.com", "legal@empresa.com"],
            "last_generated": datetime.utcnow() - timedelta(days=7),
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
    ]
    
    for report in sample_reports:
        reports_db[report["id"]] = report
    
    logger.info(f"Generated {len(sample_metrics)} metrics, {len(metric_values_db)} values, and {len(sample_reports)} reports")

def calculate_trend(metric_id: str, days: int = 7) -> Dict[str, Any]:
    """Calculate trend for a metric"""
    values = [v for v in metric_values_db.values() 
              if v["metric_id"] == metric_id and 
              v["timestamp"] >= datetime.utcnow() - timedelta(days=days)]
    
    if len(values) < 2:
        return {"trend": "insufficient_data", "change": 0, "direction": "stable"}
    
    # Sort by timestamp
    values.sort(key=lambda x: x["timestamp"])
    
    # Calculate trend
    first_value = values[0]["value"]
    last_value = values[-1]["value"]
    change = ((last_value - first_value) / first_value) * 100 if first_value != 0 else 0
    
    if abs(change) < 5:
        direction = "stable"
    elif change > 0:
        direction = "increasing"
    else:
        direction = "decreasing"
    
    return {
        "trend": direction,
        "change": round(change, 2),
        "direction": direction,
        "first_value": first_value,
        "last_value": last_value,
        "data_points": len(values)
    }

# =====================================================
# API ENDPOINTS
# =====================================================

@app.get("/", tags=["System"])
async def root():
    """Root endpoint with service information"""
    return {
        "service": "Analytics Service",
        "version": "4.0.1",
        "status": "running",
        "description": "Microserviço para analytics e métricas de governança - Corrigido",
        "corrections_applied": [
            "Dependências estabilizadas",
            "Error handling robusto",
            "Logs estruturados",
            "In-memory database funcional"
        ],
        "endpoints": {
            "health": "/health",
            "docs": "/docs",
            "metrics": "/api/v1/metrics",
            "values": "/api/v1/values",
            "reports": "/api/v1/reports",
            "dashboard": "/api/v1/dashboard"
        }
    }

@app.get("/health", tags=["System"])
async def health_check():
    """Health check endpoint"""
    try:
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "version": "4.0.1",
            "service": "analytics-service",
            "port": 8005,
            "corrections_applied": True,
            "data_counts": {
                "metrics": len(metrics_db),
                "metric_values": len(metric_values_db),
                "reports": len(reports_db),
                "audit_logs": len(audit_logs)
            },
            "features": {
                "metrics_management": True,
                "value_tracking": True,
                "report_generation": True,
                "dashboard_creation": True,
                "trend_analysis": True,
                "audit_trail": True
            }
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "status": "unhealthy",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

@app.get("/api/v1/metrics", response_model=List[MetricResponse], tags=["Metrics"])
async def list_metrics(
    category: Optional[str] = Query(None, description="Filtrar por categoria"),
    metric_type: Optional[str] = Query(None, description="Filtrar por tipo"),
    is_active: Optional[bool] = Query(None, description="Filtrar por status ativo"),
    limit: int = Query(100, description="Limite de resultados")
):
    """Listar todas as métricas"""
    try:
        metrics = list(metrics_db.values())
        
        # Apply filters
        if category:
            metrics = [m for m in metrics if m["category"] == category]
        
        if metric_type:
            metrics = [m for m in metrics if m["metric_type"] == metric_type]
            
        if is_active is not None:
            metrics = [m for m in metrics if m["is_active"] == is_active]
        
        # Apply limit
        metrics = metrics[:limit]
        
        # Convert datetime objects to ISO format
        for metric in metrics:
            metric["created_at"] = metric["created_at"].isoformat()
            metric["updated_at"] = metric["updated_at"].isoformat()
        
        log_audit("list_metrics", details=f"Listed {len(metrics)} metrics")
        return metrics
        
    except Exception as e:
        logger.error(f"Error listing metrics: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing metrics: {str(e)}")

@app.get("/api/v1/metrics/{metric_id}", response_model=MetricResponse, tags=["Metrics"])
async def get_metric(metric_id: str = Path(..., description="ID da métrica")):
    """Buscar métrica específica por ID"""
    try:
        if metric_id not in metrics_db:
            raise HTTPException(status_code=404, detail="Metric not found")
        
        metric = metrics_db[metric_id].copy()
        metric["created_at"] = metric["created_at"].isoformat()
        metric["updated_at"] = metric["updated_at"].isoformat()
        
        log_audit("get_metric", resource_id=metric_id)
        return metric
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting metric: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting metric: {str(e)}")

@app.post("/api/v1/metrics", response_model=MetricResponse, tags=["Metrics"])
async def create_metric(metric: MetricCreate):
    """Criar nova métrica"""
    try:
        metric_id = str(uuid4())
        now = datetime.utcnow()
        
        new_metric = {
            "id": metric_id,
            "name": metric.name,
            "description": metric.description,
            "metric_type": metric.metric_type,
            "category": metric.category,
            "unit": metric.unit,
            "is_active": True,
            "created_at": now,
            "updated_at": now
        }
        
        metrics_db[metric_id] = new_metric
        
        log_audit("create_metric", resource_id=metric_id, details=f"Created metric: {metric.name}")
        
        # Convert datetime for response
        response_metric = new_metric.copy()
        response_metric["created_at"] = response_metric["created_at"].isoformat()
        response_metric["updated_at"] = response_metric["updated_at"].isoformat()
        
        return response_metric
        
    except Exception as e:
        logger.error(f"Error creating metric: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating metric: {str(e)}")

@app.post("/api/v1/values", response_model=MetricValueResponse, tags=["Values"])
async def record_metric_value(value: MetricValueCreate):
    """Registrar valor de métrica"""
    try:
        if value.metric_id not in metrics_db:
            raise HTTPException(status_code=404, detail="Metric not found")
        
        value_id = str(uuid4())
        now = datetime.utcnow()
        
        new_value = {
            "id": value_id,
            "metric_id": value.metric_id,
            "value": value.value,
            "timestamp": value.timestamp,
            "dimensions": value.dimensions or {},
            "created_at": now
        }
        
        metric_values_db[value_id] = new_value
        
        log_audit("record_value", resource_id=value_id, details=f"Recorded value {value.value} for metric {value.metric_id}")
        
        # Convert datetime for response
        response_value = new_value.copy()
        response_value["timestamp"] = response_value["timestamp"].isoformat()
        response_value["created_at"] = response_value["created_at"].isoformat()
        
        return response_value
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error recording metric value: {e}")
        raise HTTPException(status_code=500, detail=f"Error recording metric value: {str(e)}")

@app.get("/api/v1/metrics/{metric_id}/values", tags=["Values"])
async def get_metric_values(
    metric_id: str,
    start_date: Optional[str] = Query(None, description="Data início (ISO format)"),
    end_date: Optional[str] = Query(None, description="Data fim (ISO format)"),
    limit: int = Query(100, description="Limite de resultados")
):
    """Obter valores de uma métrica"""
    try:
        if metric_id not in metrics_db:
            raise HTTPException(status_code=404, detail="Metric not found")
        
        values = [v for v in metric_values_db.values() if v["metric_id"] == metric_id]
        
        # Apply date filters
        if start_date:
            start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            values = [v for v in values if v["timestamp"] >= start_dt]
        
        if end_date:
            end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            values = [v for v in values if v["timestamp"] <= end_dt]
        
        # Sort by timestamp (newest first)
        values.sort(key=lambda x: x["timestamp"], reverse=True)
        
        # Apply limit
        values = values[:limit]
        
        # Convert datetime objects to ISO format
        for value in values:
            value["timestamp"] = value["timestamp"].isoformat()
            value["created_at"] = value["created_at"].isoformat()
        
        log_audit("get_values", resource_id=metric_id, details=f"Retrieved {len(values)} values")
        return values
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting metric values: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting metric values: {str(e)}")

@app.get("/api/v1/metrics/{metric_id}/trend", tags=["Analytics"])
async def get_metric_trend(
    metric_id: str,
    days: int = Query(7, description="Número de dias para análise")
):
    """Obter tendência de uma métrica"""
    try:
        if metric_id not in metrics_db:
            raise HTTPException(status_code=404, detail="Metric not found")
        
        trend = calculate_trend(metric_id, days)
        
        log_audit("get_trend", resource_id=metric_id, details=f"Calculated trend for {days} days")
        return {
            "metric_id": metric_id,
            "metric_name": metrics_db[metric_id]["name"],
            "analysis_period_days": days,
            "trend": trend,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting metric trend: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting metric trend: {str(e)}")

@app.post("/api/v1/dashboard", tags=["Dashboard"])
async def create_dashboard(request: DashboardRequest):
    """Criar dashboard com métricas selecionadas"""
    try:
        dashboard_data = {
            "id": str(uuid4()),
            "created_at": datetime.utcnow().isoformat(),
            "time_range": request.time_range,
            "group_by": request.group_by,
            "metrics": []
        }
        
        # Parse time range
        if request.time_range.endswith('d'):
            days = int(request.time_range[:-1])
        elif request.time_range.endswith('h'):
            days = int(request.time_range[:-1]) / 24
        else:
            days = 7  # default
        
        start_date = datetime.utcnow() - timedelta(days=days)
        
        for metric_id in request.metrics:
            if metric_id not in metrics_db:
                continue
                
            metric = metrics_db[metric_id]
            
            # Get recent values
            values = [v for v in metric_values_db.values() 
                     if v["metric_id"] == metric_id and v["timestamp"] >= start_date]
            
            # Calculate statistics
            if values:
                current_value = max(values, key=lambda x: x["timestamp"])["value"]
                avg_value = sum(v["value"] for v in values) / len(values)
                min_value = min(v["value"] for v in values)
                max_value = max(v["value"] for v in values)
            else:
                current_value = avg_value = min_value = max_value = 0
            
            # Get trend
            trend = calculate_trend(metric_id, int(days))
            
            # Prepare time series data
            time_series = []
            for value in sorted(values, key=lambda x: x["timestamp"]):
                time_series.append({
                    "timestamp": value["timestamp"].isoformat(),
                    "value": value["value"]
                })
            
            dashboard_data["metrics"].append({
                "metric_id": metric_id,
                "name": metric["name"],
                "description": metric["description"],
                "category": metric["category"],
                "unit": metric["unit"],
                "current_value": current_value,
                "statistics": {
                    "average": round(avg_value, 2),
                    "minimum": min_value,
                    "maximum": max_value,
                    "data_points": len(values)
                },
                "trend": trend,
                "time_series": time_series[-50:]  # Last 50 points
            })
        
        log_audit("create_dashboard", details=f"Created dashboard with {len(request.metrics)} metrics")
        return dashboard_data
        
    except Exception as e:
        logger.error(f"Error creating dashboard: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating dashboard: {str(e)}")

@app.get("/api/v1/reports", response_model=List[ReportResponse], tags=["Reports"])
async def list_reports(
    report_type: Optional[str] = Query(None, description="Filtrar por tipo"),
    frequency: Optional[str] = Query(None, description="Filtrar por frequência"),
    is_active: Optional[bool] = Query(None, description="Filtrar por status ativo")
):
    """Listar relatórios"""
    try:
        reports = list(reports_db.values())
        
        # Apply filters
        if report_type:
            reports = [r for r in reports if r["report_type"] == report_type]
        
        if frequency:
            reports = [r for r in reports if r["frequency"] == frequency]
            
        if is_active is not None:
            reports = [r for r in reports if r["is_active"] == is_active]
        
        # Convert datetime objects to ISO format
        for report in reports:
            report["created_at"] = report["created_at"].isoformat()
            report["updated_at"] = report["updated_at"].isoformat()
            if report["last_generated"]:
                report["last_generated"] = report["last_generated"].isoformat()
        
        log_audit("list_reports", details=f"Listed {len(reports)} reports")
        return reports
        
    except Exception as e:
        logger.error(f"Error listing reports: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing reports: {str(e)}")

@app.post("/api/v1/reports", response_model=ReportResponse, tags=["Reports"])
async def create_report(report: ReportCreate):
    """Criar novo relatório"""
    try:
        report_id = str(uuid4())
        now = datetime.utcnow()
        
        new_report = {
            "id": report_id,
            "name": report.name,
            "description": report.description,
            "report_type": report.report_type,
            "frequency": report.frequency,
            "recipients": report.recipients,
            "last_generated": None,
            "is_active": True,
            "created_at": now,
            "updated_at": now
        }
        
        reports_db[report_id] = new_report
        
        log_audit("create_report", resource_id=report_id, details=f"Created report: {report.name}")
        
        # Convert datetime for response
        response_report = new_report.copy()
        response_report["created_at"] = response_report["created_at"].isoformat()
        response_report["updated_at"] = response_report["updated_at"].isoformat()
        
        return response_report
        
    except Exception as e:
        logger.error(f"Error creating report: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating report: {str(e)}")

@app.get("/api/v1/summary", tags=["Analytics"])
async def get_analytics_summary():
    """Obter resumo geral de analytics"""
    try:
        # Calculate summary statistics
        total_metrics = len([m for m in metrics_db.values() if m["is_active"]])
        total_values = len(metric_values_db)
        total_reports = len([r for r in reports_db.values() if r["is_active"]])
        
        # Categories breakdown
        categories = {}
        for metric in metrics_db.values():
            if metric["is_active"]:
                cat = metric["category"]
                categories[cat] = categories.get(cat, 0) + 1
        
        # Recent activity (last 24 hours)
        recent_cutoff = datetime.utcnow() - timedelta(hours=24)
        recent_values = len([v for v in metric_values_db.values() 
                           if v["created_at"] >= recent_cutoff])
        
        # Top metrics by activity
        metric_activity = {}
        for value in metric_values_db.values():
            metric_id = value["metric_id"]
            metric_activity[metric_id] = metric_activity.get(metric_id, 0) + 1
        
        top_metrics = []
        for metric_id, count in sorted(metric_activity.items(), key=lambda x: x[1], reverse=True)[:5]:
            if metric_id in metrics_db:
                top_metrics.append({
                    "metric_id": metric_id,
                    "name": metrics_db[metric_id]["name"],
                    "category": metrics_db[metric_id]["category"],
                    "value_count": count
                })
        
        return {
            "summary": {
                "total_metrics": total_metrics,
                "total_values": total_values,
                "total_reports": total_reports,
                "recent_values_24h": recent_values
            },
            "categories": categories,
            "top_metrics": top_metrics,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting analytics summary: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting analytics summary: {str(e)}")

@app.get("/api/v1/audit/logs", tags=["Audit"])
async def list_audit_logs(limit: int = Query(100, description="Limite de resultados")):
    """Listar logs de auditoria"""
    try:
        logs = audit_logs[-limit:] if limit < len(audit_logs) else audit_logs
        return logs
    except Exception as e:
        logger.error(f"Error listing audit logs: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing audit logs: {str(e)}")

# Initialize sample data on startup
@app.on_event("startup")
async def startup_event():
    """Initialize service on startup"""
    logger.info("Starting Analytics Service V4.0.1 - Corrigido")
    generate_sample_data()
    logger.info("Analytics Service started successfully")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8005)

