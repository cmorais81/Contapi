# Autor: carlos.morais@f1rst.com.br
from dataclasses import dataclass
from typing import Optional, Union
from decimal import Decimal

@dataclass(frozen=True)
class MetricValue:
    """Value object para valores de métricas"""
    value: Union[int, float, Decimal]
    unit: Optional[str] = None
    
    def __post_init__(self):
        if self.value is None:
            raise ValueError("Valor da métrica não pode ser None")
        if isinstance(self.value, (int, float)) and self.value < 0:
            raise ValueError("Valor da métrica deve ser positivo")
    
    def to_dict(self) -> dict:
        return {
            "value": float(self.value) if isinstance(self.value, Decimal) else self.value,
            "unit": self.unit
        }
