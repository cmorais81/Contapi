# Autor: carlos.morais@f1rst.com.br
from enum import Enum

class ChartType(Enum):
    """Tipos de gráficos disponíveis"""
    BAR = "bar"
    LINE = "line"
    PIE = "pie"
    SCATTER = "scatter"
    HISTOGRAM = "histogram"
    HEATMAP = "heatmap"
    GAUGE = "gauge"
    TABLE = "table"
