# Autor: carlos.morais@f1rst.com.br
"""
Analytics Report Domain Entity
Core business entity for analytics and reporting functionality
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Union
from uuid import UUID, uuid4
from enum import Enum
import json

from ..value_objects.report_type import ReportType, ReportFormat
from ..value_objects.metric_definition import MetricDefinition
from ..events.analytics_events import (
    ReportCreated, ReportGenerated, ReportScheduled,
    ReportShared, MetricCalculated, DashboardUpdated
)


class ReportStatus(Enum):
    """Report generation status"""
    DRAFT = "draft"
    SCHEDULED = "scheduled"
    GENERATING = "generating"
    COMPLETED = "completed"
    FLED = "failed"
    CANCELLED = "cancelled"


class ReportFrequency(Enum):
    """Report generation frequency"""
    ON_DEMAND = "on_demand"
    DLY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    YEARLY = "yearly"


@dataclass
class AnalyticsReport:
    """
    Analytics Report aggregate root for governance analytics and reporting
    """
    # Identity
    id: UUID = field(default_factory=uuid4)
    name: str = ""
    title: str = ""
    description: Optional[str] = None
    
    # Report configuration
    report_type: ReportType = field(default=ReportType.GOVERNANCE_OVERVIEW)
    report_format: ReportFormat = field(default=ReportFormat.PDF)
    frequency: ReportFrequency = field(default=ReportFrequency.ON_DEMAND)
    
    # Data sources and filters
    data_sources: List[UUID] = field(default_factory=list)  # Dataset IDs
    contract_ids: List[UUID] = field(default_factory=list)
    organization_ids: List[UUID] = field(default_factory=list)
    date_range_start: Optional[datetime] = None
    date_range_end: Optional[datetime] = None
    filters: Dict[str, Any] = field(default_factory=dict)
    
    # Metrics and KPIs
    metrics: List[MetricDefinition] = field(default_factory=list)
    kpi_targets: Dict[str, float] = field(default_factory=dict)
    
    # Report content
    sections: List[Dict[str, Any]] = field(default_factory=list)
    visualizations: List[Dict[str, Any]] = field(default_factory=list)
    summary_insights: List[str] = field(default_factory=list)
    
    # Generation and status
    status: ReportStatus = field(default=ReportStatus.DRAFT)
    last_generated_at: Optional[datetime] = None
    generation_time_seconds: Optional[int] = None
    file_path: Optional[str] = None
    file_size_bytes: Optional[int] = None
    
    # Scheduling
    schedule_expression: Optional[str] = None  # Cron expression
    next_generation_at: Optional[datetime] = None
    auto_distribute: bool = False
    
    # Ownership and access
    owner_id: UUID = field(default_factory=uuid4)
    organization_id: UUID = field(default_factory=uuid4)
    is_public: bool = False
    shared_with: List[UUID] = field(default_factory=list)  # User IDs
    
    # Distribution
    email_recipients: List[str] = field(default_factory=list)
    slack_channels: List[str] = field(default_factory=list)
    webhook_urls: List[str] = field(default_factory=list)
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    business_context: Optional[str] = None
    
    # Audit fields
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    created_by: UUID = field(default_factory=uuid4)
    updated_by: UUID = field(default_factory=uuid4)
    deleted_at: Optional[datetime] = None
    
    # Domain events
    _domain_events: List[Any] = field(default_factory=list, init=False)
    
    def __post_init__(self):
        """Post-initialization validation and setup"""
        if not self.name:
            raise ValueError("Report name is required")
        
        if not self.title:
            self.title = self.name.replace('_', ' ').title()
        
        # Set default date range if not provided
        if not self.date_range_start:
            self.date_range_start = datetime.utcnow() - timedelta(days=30)
        
        if not self.date_range_end:
            self.date_range_end = datetime.utcnow()
        
        # Initialize default sections based on report type
        if not self.sections:
            self.sections = self._get_default_sections()
    
    def create(self, created_by: UUID) -> None:
        """Create a new analytics report"""
        if self.status != ReportStatus.DRAFT:
            raise ValueError("Can only create reports in draft status")
        
        self.created_by = created_by
        self.updated_by = created_by
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(ReportCreated(
            report_id=self.id,
            name=self.name,
            report_type=self.report_type.value,
            owner_id=self.owner_id,
            created_by=created_by,
            occurred_at=datetime.utcnow()
        ))
    
    def update(self, updated_by: UUID, **kwargs) -> None:
        """Update report configuration"""
        old_values = {}
        for key, value in kwargs.items():
            if hasattr(self, key):
                old_values[key] = getattr(self, key)
                setattr(self, key, value)
        
        self.updated_by = updated_by
        self.updated_at = datetime.utcnow()
        
        # Reset generation status if configuration changed
        if any(key in kwargs for key in ['data_sources', 'metrics', 'filters', 'date_range_start', 'date_range_end']):
            if self.status == ReportStatus.COMPLETED:
                self.status = ReportStatus.DRAFT
    
    def schedule(self, scheduled_by: UUID, cron_expression: str) -> None:
        """Schedule report for automatic generation"""
        self.schedule_expression = cron_expression
        self.frequency = ReportFrequency.DLY  # Will be determined by cron
        self.status = ReportStatus.SCHEDULED
        self.next_generation_at = self._calculate_next_run_time()
        self.updated_by = scheduled_by
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(ReportScheduled(
            report_id=self.id,
            schedule_expression=cron_expression,
            next_run_at=self.next_generation_at,
            scheduled_by=scheduled_by,
            occurred_at=datetime.utcnow()
        ))
    
    def generate(self, generated_by: UUID) -> 'ReportGeneration':
        """Generate the report"""
        if self.status == ReportStatus.GENERATING:
            raise ValueError("Report is already being generated")
        
        generation_id = uuid4()
        started_at = datetime.utcnow()
        
        self.status = ReportStatus.GENERATING
        self.updated_by = generated_by
        self.updated_at = datetime.utcnow()
        
        try:
            # Simulate report generation
            generation_result = self._simulate_generation()
            
            # Update report with generation results
            self.status = ReportStatus.COMPLETED
            self.last_generated_at = started_at
            self.generation_time_seconds = generation_result.generation_time_seconds
            self.file_path = generation_result.file_path
            self.file_size_bytes = generation_result.file_size_bytes
            
            # Update next generation time if scheduled
            if self.frequency != ReportFrequency.ON_DEMAND:
                self.next_generation_at = self._calculate_next_run_time()
            
            # Raise domain event
            self._add_domain_event(ReportGenerated(
                report_id=self.id,
                generation_id=generation_id,
                file_path=self.file_path,
                file_size_bytes=self.file_size_bytes,
                generation_time_seconds=self.generation_time_seconds,
                generated_by=generated_by,
                occurred_at=started_at
            ))
            
            # Auto-distribute if configured
            if self.auto_distribute:
                self._distribute_report()
            
            return generation_result
            
        except Exception as e:
            # Handle generation failure
            self.status = ReportStatus.FLED
            self.updated_at = datetime.utcnow()
            
            generation_result = ReportGeneration(
                generation_id=generation_id,
                report_id=self.id,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                status="failed",
                error_message=str(e)
            )
            
            return generation_result
    
    def share_with_user(self, user_id: UUID, shared_by: UUID) -> None:
        """Share report with a user"""
        if user_id not in self.shared_with:
            self.shared_with.append(user_id)
            self.updated_by = shared_by
            self.updated_at = datetime.utcnow()
            
            # Raise domain event
            self._add_domain_event(ReportShared(
                report_id=self.id,
                shared_with_user_id=user_id,
                shared_by=shared_by,
                occurred_at=datetime.utcnow()
            ))
    
    def add_metric(self, metric: MetricDefinition) -> None:
        """Add metric to report"""
        if metric not in self.metrics:
            self.metrics.append(metric)
            self.updated_at = datetime.utcnow()
    
    def remove_metric(self, metric_name: str) -> None:
        """Remove metric from report"""
        self.metrics = [m for m in self.metrics if m.name != metric_name]
        self.updated_at = datetime.utcnow()
    
    def add_data_source(self, dataset_id: UUID) -> None:
        """Add data source to report"""
        if dataset_id not in self.data_sources:
            self.data_sources.append(dataset_id)
            self.updated_at = datetime.utcnow()
    
    def set_date_range(self, start_date: datetime, end_date: datetime) -> None:
        """Set report date range"""
        if start_date >= end_date:
            raise ValueError("Start date must be before end date")
        
        self.date_range_start = start_date
        self.date_range_end = end_date
        self.updated_at = datetime.utcnow()
        
        # Reset status if report was completed
        if self.status == ReportStatus.COMPLETED:
            self.status = ReportStatus.DRAFT
    
    def add_visualization(self, viz_config: Dict[str, Any]) -> None:
        """Add visualization to report"""
        self.visualizations.append(viz_config)
        self.updated_at = datetime.utcnow()
    
    def add_email_recipient(self, email: str) -> None:
        """Add email recipient for distribution"""
        if email not in self.email_recipients:
            self.email_recipients.append(email)
            self.updated_at = datetime.utcnow()
    
    def is_ready_for_generation(self) -> bool:
        """Check if report is ready for generation"""
        return (
            self.data_sources or self.contract_ids or self.organization_ids
        ) and self.metrics and self.status in [ReportStatus.DRAFT, ReportStatus.SCHEDULED]
    
    def is_stale(self, hours_threshold: int = 24) -> bool:
        """Check if report is stale (needs regeneration)"""
        if not self.last_generated_at:
            return True
        
        hours_since_generation = (datetime.utcnow() - self.last_generated_at).total_seconds() / 3600
        return hours_since_generation > hours_threshold
    
    def get_generation_frequency_days(self) -> int:
        """Get generation frequency in days"""
        frequency_days = {
            ReportFrequency.DLY: 1,
            ReportFrequency.WEEKLY: 7,
            ReportFrequency.MONTHLY: 30,
            ReportFrequency.QUARTERLY: 90,
            ReportFrequency.YEARLY: 365,
            ReportFrequency.ON_DEMAND: 0
        }
        return frequency_days.get(self.frequency, 0)
    
    def calculate_insights(self, metrics_data: Dict[str, Any]) -> List[str]:
        """Calculate insights from metrics data"""
        insights = []
        
        # Governance insights
        if 'compliance_score' in metrics_data:
            score = metrics_data['compliance_score']
            if score < 0.7:
                insights.append(f"Compliance score ({score:.1%}) is below target. Review LGPD requirements.")
            elif score > 0.9:
                insights.append(f"Excellent compliance score ({score:.1%}). Governance practices are effective.")
        
        # Quality insights
        if 'quality_score' in metrics_data:
            score = metrics_data['quality_score']
            if score < 0.8:
                insights.append(f"Data quality score ({score:.1%}) needs improvement. Focus on completeness and accuracy.")
        
        # Usage insights
        if 'dataset_usage' in metrics_data:
            usage = metrics_data['dataset_usage']
            if usage < 0.3:
                insights.append("Low dataset usage detected. Consider data discovery initiatives.")
        
        # Contract insights
        if 'active_contracts' in metrics_data and 'total_contracts' in metrics_data:
            active_rate = metrics_data['active_contracts'] / max(metrics_data['total_contracts'], 1)
            if active_rate < 0.5:
                insights.append("Many contracts are inactive. Review contract lifecycle management.")
        
        self.summary_insights = insights
        return insights
    
    def get_domain_events(self) -> List[Any]:
        """Get and clear domain events"""
        events = self._domain_events.copy()
        self._domain_events.clear()
        return events
    
    def _add_domain_event(self, event: Any) -> None:
        """Add a domain event"""
        self._domain_events.append(event)
    
    def _get_default_sections(self) -> List[Dict[str, Any]]:
        """Get default sections based on report type"""
        if self.report_type == ReportType.GOVERNANCE_OVERVIEW:
            return [
                {"name": "executive_summary", "title": "Executive Summary", "order": 1},
                {"name": "compliance_status", "title": "Compliance Status", "order": 2},
                {"name": "data_quality", "title": "Data Quality Metrics", "order": 3},
                {"name": "contract_status", "title": "Contract Status", "order": 4},
                {"name": "recommendations", "title": "Recommendations", "order": 5}
            ]
        elif self.report_type == ReportType.COMPLNCE_AUDIT:
            return [
                {"name": "audit_scope", "title": "Audit Scope", "order": 1},
                {"name": "lgpd_compliance", "title": "LGPD Compliance", "order": 2},
                {"name": "data_classification", "title": "Data Classification", "order": 3},
                {"name": "violations", "title": "Violations and Issues", "order": 4},
                {"name": "remediation", "title": "Remediation Plan", "order": 5}
            ]
        elif self.report_type == ReportType.QUALITY_METRICS:
            return [
                {"name": "quality_overview", "title": "Quality Overview", "order": 1},
                {"name": "completeness", "title": "Completeness Metrics", "order": 2},
                {"name": "accuracy", "title": "Accuracy Metrics", "order": 3},
                {"name": "consistency", "title": "Consistency Metrics", "order": 4},
                {"name": "trends", "title": "Quality Trends", "order": 5}
            ]
        else:
            return [
                {"name": "overview", "title": "Overview", "order": 1},
                {"name": "metrics", "title": "Key Metrics", "order": 2},
                {"name": "analysis", "title": "Analysis", "order": 3}
            ]
    
    def _calculate_next_run_time(self) -> Optional[datetime]:
        """Calculate next run time based on frequency"""
        if self.frequency == ReportFrequency.ON_DEMAND:
            return None
        
        now = datetime.utcnow()
        
        if self.frequency == ReportFrequency.DLY:
            return now + timedelta(days=1)
        elif self.frequency == ReportFrequency.WEEKLY:
            return now + timedelta(weeks=1)
        elif self.frequency == ReportFrequency.MONTHLY:
            return now + timedelta(days=30)
        elif self.frequency == ReportFrequency.QUARTERLY:
            return now + timedelta(days=90)
        elif self.frequency == ReportFrequency.YEARLY:
            return now + timedelta(days=365)
        
        return None
    
    def _simulate_generation(self) -> 'ReportGeneration':
        """Simulate report generation"""
        import random
        import time
        
        # Simulate generation time
        generation_time = random.randint(5, 30)
        time.sleep(0.1)  # Small delay to simulate work
        
        # Simulate file generation
        file_path = f"/reports/{self.id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.{self.report_format.value.lower()}"
        file_size = random.randint(100000, 5000000)  # 100KB to 5MB
        
        return ReportGeneration(
            generation_id=uuid4(),
            report_id=self.id,
            started_at=datetime.utcnow() - timedelta(seconds=generation_time),
            completed_at=datetime.utcnow(),
            status="completed",
            file_path=file_path,
            file_size_bytes=file_size,
            generation_time_seconds=generation_time
        )
    
    def _distribute_report(self) -> None:
        """Distribute report to configured recipients"""
        # In real implementation, this would send emails, post to Slack, etc.
        pass


@dataclass
class ReportGeneration:
    """Represents a report generation execution"""
    generation_id: UUID = field(default_factory=uuid4)
    report_id: UUID = field(default_factory=uuid4)
    
    # Timing
    started_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    generation_time_seconds: int = 0
    
    # Status
    status: str = "running"  # running, completed, failed
    error_message: Optional[str] = None
    
    # Output
    file_path: Optional[str] = None
    file_size_bytes: Optional[int] = None
    
    # Metrics generated
    metrics_calculated: Dict[str, float] = field(default_factory=dict)
    
    def is_completed(self) -> bool:
        """Check if generation is completed"""
        return self.status in ['completed', 'failed']
    
    def is_successful(self) -> bool:
        """Check if generation was successful"""
        return self.status == 'completed'


@dataclass
class Dashboard:
    """Dashboard for real-time analytics"""
    id: UUID = field(default_factory=uuid4)
    name: str = ""
    title: str = ""
    description: Optional[str] = None
    
    # Configuration
    widgets: List[Dict[str, Any]] = field(default_factory=list)
    layout: Dict[str, Any] = field(default_factory=dict)
    refresh_interval_seconds: int = 300  # 5 minutes
    
    # Data sources
    data_sources: List[UUID] = field(default_factory=list)
    filters: Dict[str, Any] = field(default_factory=dict)
    
    # Access control
    owner_id: UUID = field(default_factory=uuid4)
    is_public: bool = False
    shared_with: List[UUID] = field(default_factory=list)
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    
    # Audit
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    created_by: UUID = field(default_factory=uuid4)
    updated_by: UUID = field(default_factory=uuid4)
    
    def add_widget(self, widget_config: Dict[str, Any]) -> None:
        """Add widget to dashboard"""
        self.widgets.append(widget_config)
        self.updated_at = datetime.utcnow()
    
    def remove_widget(self, widget_id: str) -> None:
        """Remove widget from dashboard"""
        self.widgets = [w for w in self.widgets if w.get('id') != widget_id]
        self.updated_at = datetime.utcnow()

