# Autor: carlos.morais@f1rst.com.br
from typing import List, Dict, Any
from ..value_objects.metric_value import MetricValue

class MetricCalculatorService:
    """Serviço de domínio para cálculos de métricas"""
    
    def calculate_quality_score(self, metrics: List[MetricValue]) -> MetricValue:
        """Calcula score de qualidade baseado em métricas"""
        if not metrics:
            return MetricValue(0.0, "percentage")
        
        total = sum(m.value for m in metrics)
        average = total / len(metrics)
        return MetricValue(min(100.0, max(0.0, average)), "percentage")
    
    def calculate_trend(self, values: List[float]) -> str:
        """Calcula tendência dos valores"""
        if len(values) < 2:
            return "stable"
        
        recent = sum(values[-3:]) / min(3, len(values))
        older = sum(values[:-3]) / max(1, len(values) - 3)
        
        if recent > older * 1.1:
            return "increasing"
        elif recent < older * 0.9:
            return "decreasing"
        return "stable"
