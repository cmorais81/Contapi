# Autor: carlos.morais@f1rst.com.br
"""
Analytics Repository Implementation
SQLAlchemy implementation for analytics data access
"""

import json
from datetime import datetime, timedelta, date
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import text, func, and_, or_, desc, asc
from sqlalchemy.exc import SQLAlchemyError

# Import shared models
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'shared'))

from database.models.central_models import (
    AnalyticsReportModel, DashboardModel, ContractModel, UserModel, 
    DatasetModel, QualityRuleModel, QualityRuleExecutionModel,
    OrganizationModel, PIIClassificationModel
)
from ...domain.entities.analytics_report import AnalyticsReport as AnalyticsReportEntity
from ...domain.repositories.analytics_repository import AnalyticsRepository
from ...application.dtos.analytics_dtos import (
    ReportType, ReportStatus, DashboardType, MetricType, TimeGranularity
)


class AnalyticsRepositoryImpl(AnalyticsRepository):
    """SQLAlchemy implementation of analytics repository"""
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    def save_report(self, report: AnalyticsReportEntity) -> AnalyticsReportEntity:
        """Save analytics report"""
        try:
            # Check if report exists
            existing = self.db.query(AnalyticsReportModel).filter(
                AnalyticsReportModel.id == report.id
            ).first()
            
            if existing:
                # Update existing report
                existing.name = report.name
                existing.description = report.description
                existing.report_type = report.report_type.value
                existing.status = report.status.value
                existing.filters = json.dumps(report.filters) if report.filters else None
                existing.parameters = json.dumps(report.parameters) if report.parameters else None
                existing.format = report.format.value
                existing.schedule = json.dumps(report.schedule) if report.schedule else None
                existing.notifications = json.dumps(report.notifications) if report.notifications else None
                existing.file_url = report.file_url
                existing.file_size = report.file_size
                existing.generation_time = report.generation_time
                existing.last_generated = report.last_generated
                existing.next_generation = report.next_generation
                existing.enabled = report.enabled
                existing.updated_at = datetime.utcnow()
                
                model = existing
            else:
                # Create new report
                model = AnalyticsReportModel(
                    id=report.id,
                    name=report.name,
                    description=report.description,
                    report_type=report.report_type.value,
                    status=report.status.value,
                    organization_id=report.organization_id,
                    created_by=report.created_by,
                    filters=json.dumps(report.filters) if report.filters else None,
                    parameters=json.dumps(report.parameters) if report.parameters else None,
                    format=report.format.value,
                    schedule=json.dumps(report.schedule) if report.schedule else None,
                    notifications=json.dumps(report.notifications) if report.notifications else None,
                    file_url=report.file_url,
                    file_size=report.file_size,
                    generation_time=report.generation_time,
                    last_generated=report.last_generated,
                    next_generation=report.next_generation,
                    enabled=report.enabled,
                    created_at=report.created_at,
                    updated_at=datetime.utcnow()
                )
                self.db.add(model)
            
            self.db.commit()
            self.db.refresh(model)
            
            return self._model_to_entity(model)
            
        except SQLAlchemyError as e:
            self.db.rollback()
            raise RuntimeError(f"Database error saving report: {str(e)}")
    
    def find_report_by_id(self, report_id: UUID) -> Optional[AnalyticsReportEntity]:
        """Find report by ID"""
        try:
            model = self.db.query(AnalyticsReportModel).filter(
                AnalyticsReportModel.id == report_id,
                AnalyticsReportModel.deleted_at.is_(None)
            ).first()
            
            if not model:
                return None
            
            return self._model_to_entity(model)
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error finding report: {str(e)}")
    
    def find_reports_by_organization(self, organization_id: UUID, 
                                   limit: int = 100, offset: int = 0) -> List[AnalyticsReportEntity]:
        """Find reports by organization"""
        try:
            models = self.db.query(AnalyticsReportModel).filter(
                AnalyticsReportModel.organization_id == organization_id,
                AnalyticsReportModel.deleted_at.is_(None)
            ).order_by(desc(AnalyticsReportModel.created_at)).limit(limit).offset(offset).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error finding reports: {str(e)}")
    
    def find_reports_with_filters(self, filters: Dict[str, Any], 
                                limit: int = 100, offset: int = 0) -> List[AnalyticsReportEntity]:
        """Find reports with filters"""
        try:
            query = self.db.query(AnalyticsReportModel).filter(
                AnalyticsReportModel.deleted_at.is_(None)
            )
            
            # Apply filters
            if 'organization_id' in filters:
                query = query.filter(AnalyticsReportModel.organization_id == filters['organization_id'])
            
            if 'report_type' in filters:
                query = query.filter(AnalyticsReportModel.report_type == filters['report_type'])
            
            if 'status' in filters:
                query = query.filter(AnalyticsReportModel.status == filters['status'])
            
            if 'created_by' in filters:
                query = query.filter(AnalyticsReportModel.created_by == filters['created_by'])
            
            if 'enabled' in filters:
                query = query.filter(AnalyticsReportModel.enabled == filters['enabled'])
            
            if 'created_after' in filters:
                query = query.filter(AnalyticsReportModel.created_at >= filters['created_after'])
            
            if 'created_before' in filters:
                query = query.filter(AnalyticsReportModel.created_at <= filters['created_before'])
            
            models = query.order_by(desc(AnalyticsReportModel.created_at)).limit(limit).offset(offset).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error filtering reports: {str(e)}")
    
    def delete_report(self, report_id: UUID) -> bool:
        """Delete report (soft delete)"""
        try:
            model = self.db.query(AnalyticsReportModel).filter(
                AnalyticsReportModel.id == report_id,
                AnalyticsReportModel.deleted_at.is_(None)
            ).first()
            
            if not model:
                return False
            
            model.deleted_at = datetime.utcnow()
            self.db.commit()
            
            return True
            
        except SQLAlchemyError as e:
            self.db.rollback()
            raise RuntimeError(f"Database error deleting report: {str(e)}")
    
    def get_governance_overview_data(self, organization_id: UUID, 
                                   date_from: Optional[date] = None,
                                   date_to: Optional[date] = None) -> Dict[str, Any]:
        """Get governance overview analytics data"""
        try:
            # Default date range (last 30 days)
            if not date_from:
                date_from = (datetime.utcnow() - timedelta(days=30)).date()
            if not date_to:
                date_to = datetime.utcnow().date()
            
            # Total datasets
            total_datasets = self.db.query(func.count(DatasetModel.id)).filter(
                DatasetModel.organization_id == organization_id,
                DatasetModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Active datasets
            active_datasets = self.db.query(func.count(DatasetModel.id)).filter(
                DatasetModel.organization_id == organization_id,
                DatasetModel.status == 'active',
                DatasetModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Datasets with PII
            datasets_with_pii = self.db.query(func.count(func.distinct(PIIClassificationModel.dataset_id))).filter(
                PIIClassificationModel.organization_id == organization_id,
                PIIClassificationModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Total contracts
            contracts_count = self.db.query(func.count(ContractModel.id)).filter(
                ContractModel.organization_id == organization_id,
                ContractModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Active contracts
            active_contracts = self.db.query(func.count(ContractModel.id)).filter(
                ContractModel.organization_id == organization_id,
                ContractModel.status == 'active',
                ContractModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Pending approvals
            pending_approvals = self.db.query(func.count(ContractModel.id)).filter(
                ContractModel.organization_id == organization_id,
                ContractModel.status == 'pending_approval',
                ContractModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Users count
            users_count = self.db.query(func.count(UserModel.id)).filter(
                UserModel.organization_id == organization_id,
                UserModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Active users (last 30 days)
            active_users = self.db.query(func.count(UserModel.id)).filter(
                UserModel.organization_id == organization_id,
                UserModel.last_login >= datetime.utcnow() - timedelta(days=30),
                UserModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Average quality score
            quality_score_avg = self.db.query(func.avg(DatasetModel.quality_score)).filter(
                DatasetModel.organization_id == organization_id,
                DatasetModel.quality_score.isnot(None),
                DatasetModel.deleted_at.is_(None)
            ).scalar() or 0.0
            
            # Total data size
            data_size_total = self.db.query(func.sum(DatasetModel.size_bytes)).filter(
                DatasetModel.organization_id == organization_id,
                DatasetModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Datasets with quality issues (quality score < 80)
            datasets_with_quality_issues = self.db.query(func.count(DatasetModel.id)).filter(
                DatasetModel.organization_id == organization_id,
                DatasetModel.quality_score < 80,
                DatasetModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Calculate compliance score (simplified)
            compliance_score = 85.0  # Placeholder - would be calculated based on actual compliance rules
            
            return {
                'total_datasets': total_datasets,
                'active_datasets': active_datasets,
                'datasets_with_quality_issues': datasets_with_quality_issues,
                'datasets_with_pii': datasets_with_pii,
                'compliance_score': compliance_score,
                'quality_score_avg': float(quality_score_avg),
                'contracts_count': contracts_count,
                'active_contracts': active_contracts,
                'pending_approvals': pending_approvals,
                'users_count': users_count,
                'active_users': active_users,
                'data_size_total': data_size_total
            }
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error getting governance overview: {str(e)}")
    
    def get_data_quality_analytics(self, organization_id: UUID,
                                 date_from: Optional[date] = None,
                                 date_to: Optional[date] = None) -> Dict[str, Any]:
        """Get data quality analytics"""
        try:
            # Default date range
            if not date_from:
                date_from = (datetime.utcnow() - timedelta(days=30)).date()
            if not date_to:
                date_to = datetime.utcnow().date()
            
            # Overall quality score
            overall_quality_score = self.db.query(func.avg(DatasetModel.quality_score)).filter(
                DatasetModel.organization_id == organization_id,
                DatasetModel.quality_score.isnot(None),
                DatasetModel.deleted_at.is_(None)
            ).scalar() or 0.0
            
            # Quality by dataset
            quality_by_dataset = self.db.query(
                DatasetModel.name,
                DatasetModel.quality_score
            ).filter(
                DatasetModel.organization_id == organization_id,
                DatasetModel.quality_score.isnot(None),
                DatasetModel.deleted_at.is_(None)
            ).order_by(desc(DatasetModel.quality_score)).limit(10).all()
            
            # Quality by rule type
            quality_by_rule_type = self.db.query(
                QualityRuleModel.rule_type,
                func.avg(QualityRuleExecutionModel.success_rate).label('avg_success_rate')
            ).join(
                QualityRuleExecutionModel, QualityRuleModel.id == QualityRuleExecutionModel.rule_id
            ).filter(
                QualityRuleModel.organization_id == organization_id,
                QualityRuleExecutionModel.executed_at >= date_from,
                QualityRuleExecutionModel.executed_at <= date_to
            ).group_by(QualityRuleModel.rule_type).all()
            
            return {
                'overall_quality_score': float(overall_quality_score),
                'quality_by_dataset': [
                    {'dataset_name': name, 'quality_score': float(score or 0)}
                    for name, score in quality_by_dataset
                ],
                'quality_by_rule_type': [
                    {'rule_type': rule_type, 'avg_success_rate': float(rate or 0)}
                    for rule_type, rate in quality_by_rule_type
                ]
            }
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error getting quality analytics: {str(e)}")
    
    def get_usage_analytics(self, organization_id: UUID,
                          date_from: Optional[date] = None,
                          date_to: Optional[date] = None) -> Dict[str, Any]:
        """Get usage analytics"""
        try:
            # Default date range
            if not date_from:
                date_from = (datetime.utcnow() - timedelta(days=30)).date()
            if not date_to:
                date_to = datetime.utcnow().date()
            
            # Most accessed datasets (by popularity score)
            most_accessed_datasets = self.db.query(
                DatasetModel.name,
                DatasetModel.popularity_score
            ).filter(
                DatasetModel.organization_id == organization_id,
                DatasetModel.deleted_at.is_(None)
            ).order_by(desc(DatasetModel.popularity_score)).limit(10).all()
            
            # Unique users (simplified - would need access logs)
            unique_users = self.db.query(func.count(UserModel.id)).filter(
                UserModel.organization_id == organization_id,
                UserModel.last_login >= date_from,
                UserModel.deleted_at.is_(None)
            ).scalar() or 0
            
            return {
                'total_queries': 1000,  # Placeholder - would come from access logs
                'unique_users': unique_users,
                'most_accessed_datasets': [
                    {'dataset_name': name, 'popularity_score': float(score or 0)}
                    for name, score in most_accessed_datasets
                ],
                'usage_by_department': [  # Placeholder data
                    {'department': 'Analytics', 'usage_count': 450},
                    {'department': 'Engineering', 'usage_count': 320},
                    {'department': 'Business', 'usage_count': 230}
                ]
            }
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error getting usage analytics: {str(e)}")
    
    def get_compliance_analytics(self, organization_id: UUID,
                               date_from: Optional[date] = None,
                               date_to: Optional[date] = None) -> Dict[str, Any]:
        """Get compliance analytics"""
        try:
            # Datasets with PII
            datasets_with_pii = self.db.query(func.count(func.distinct(PIIClassificationModel.dataset_id))).filter(
                PIIClassificationModel.organization_id == organization_id,
                PIIClassificationModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Masked fields count
            masked_fields_count = self.db.query(func.count(PIIClassificationModel.id)).filter(
                PIIClassificationModel.organization_id == organization_id,
                PIIClassificationModel.masking_applied == True,
                PIIClassificationModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # LGPD compliance score (simplified calculation)
            total_pii_fields = self.db.query(func.count(PIIClassificationModel.id)).filter(
                PIIClassificationModel.organization_id == organization_id,
                PIIClassificationModel.deleted_at.is_(None)
            ).scalar() or 1
            
            lgpd_compliance_score = (masked_fields_count / total_pii_fields) * 100 if total_pii_fields > 0 else 100.0
            
            return {
                'lgpd_compliance_score': lgpd_compliance_score,
                'datasets_with_pii': datasets_with_pii,
                'masked_fields_count': masked_fields_count,
                'compliance_by_dataset': [],  # Would be populated with actual compliance data
                'compliance_violations': []   # Would be populated with actual violations
            }
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error getting compliance analytics: {str(e)}")
    
    def get_performance_analytics(self, organization_id: UUID,
                                date_from: Optional[date] = None,
                                date_to: Optional[date] = None) -> Dict[str, Any]:
        """Get performance analytics"""
        try:
            # Performance metrics (placeholder data - would come from monitoring)
            return {
                'avg_query_time': 2.5,  # seconds
                'total_data_processed': 1024 * 1024 * 1024 * 500,  # 500 GB
                'system_uptime': 99.9,  # percentage
                'error_rate': 0.1,  # percentage
                'performance_by_service': [
                    {'service': 'contract-service', 'avg_response_time': 150},
                    {'service': 'catalog-service', 'avg_response_time': 200},
                    {'service': 'quality-service', 'avg_response_time': 300}
                ]
            }
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error getting performance analytics: {str(e)}")
    
    def get_analytics_statistics(self, organization_id: UUID) -> Dict[str, Any]:
        """Get analytics service statistics"""
        try:
            # Total reports
            total_reports = self.db.query(func.count(AnalyticsReportModel.id)).filter(
                AnalyticsReportModel.organization_id == organization_id,
                AnalyticsReportModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Active reports
            active_reports = self.db.query(func.count(AnalyticsReportModel.id)).filter(
                AnalyticsReportModel.organization_id == organization_id,
                AnalyticsReportModel.enabled == True,
                AnalyticsReportModel.deleted_at.is_(None)
            ).scalar() or 0
            
            # Reports by type
            reports_by_type = dict(self.db.query(
                AnalyticsReportModel.report_type,
                func.count(AnalyticsReportModel.id)
            ).filter(
                AnalyticsReportModel.organization_id == organization_id,
                AnalyticsReportModel.deleted_at.is_(None)
            ).group_by(AnalyticsReportModel.report_type).all())
            
            return {
                'total_reports': total_reports,
                'active_reports': active_reports,
                'total_dashboards': 0,  # Would be implemented when dashboard model is added
                'active_dashboards': 0,
                'reports_by_type': reports_by_type,
                'dashboards_by_type': {},
                'total_generations': 0,  # Would come from generation logs
                'successful_generations': 0,
                'failed_generations': 0,
                'avg_generation_time': 0.0
            }
            
        except SQLAlchemyError as e:
            raise RuntimeError(f"Database error getting analytics statistics: {str(e)}")
    
    def _model_to_entity(self, model: AnalyticsReportModel) -> AnalyticsReportEntity:
        """Convert model to entity"""
        # Get organization and user names
        org_name = ""
        user_name = ""
        
        if model.organization_id:
            org = self.db.query(OrganizationModel).filter(
                OrganizationModel.id == model.organization_id
            ).first()
            if org:
                org_name = org.name
        
        if model.created_by:
            user = self.db.query(UserModel).filter(
                UserModel.id == model.created_by
            ).first()
            if user:
                user_name = user.full_name or user.email
        
        return AnalyticsReportEntity(
            id=model.id,
            name=model.name,
            description=model.description,
            report_type=ReportType(model.report_type),
            status=ReportStatus(model.status),
            organization_id=model.organization_id,
            organization_name=org_name,
            created_by=model.created_by,
            created_by_name=user_name,
            filters=json.loads(model.filters) if model.filters else None,
            parameters=json.loads(model.parameters) if model.parameters else None,
            format=model.format,
            schedule=json.loads(model.schedule) if model.schedule else None,
            notifications=json.loads(model.notifications) if model.notifications else None,
            file_url=model.file_url,
            file_size=model.file_size,
            generation_time=model.generation_time,
            last_generated=model.last_generated,
            next_generation=model.next_generation,
            enabled=model.enabled,
            created_at=model.created_at,
            updated_at=model.updated_at
        )

