# Autor: carlos.morais@f1rst.com.br
"""
Analytics Service DTOs
Data Transfer Objects for analytics and reporting operations
"""

from datetime import datetime, date
from typing import List, Optional, Dict, Any, Union
from uuid import UUID
from enum import Enum

from pydantic import BaseModel, Field, validator


# Enums
class ReportType(str, Enum):
    """Types of analytics reports"""
    GOVERNANCE_OVERVIEW = "governance_overview"
    DATA_QUALITY = "data_quality"
    USAGE_ANALYTICS = "usage_analytics"
    COMPLNCE_REPORT = "compliance_report"
    PERFORMANCE_METRICS = "performance_metrics"
    TREND_ANALYSIS = "trend_analysis"
    CUSTOM_REPORT = "custom_report"


class ReportFormat(str, Enum):
    """Report output formats"""
    PDF = "pdf"
    EXCEL = "excel"
    CSV = "csv"
    JSON = "json"
    HTML = "html"


class ReportStatus(str, Enum):
    """Report generation status"""
    PENDING = "pending"
    GENERATING = "generating"
    COMPLETED = "completed"
    FLED = "failed"
    CANCELLED = "cancelled"


class DashboardType(str, Enum):
    """Types of dashboards"""
    EXECUTIVE = "executive"
    OPERATIONAL = "operational"
    TECHNICAL = "technical"
    COMPLNCE = "compliance"
    CUSTOM = "custom"


class MetricType(str, Enum):
    """Types of metrics"""
    COUNT = "count"
    PERCENTAGE = "percentage"
    AVERAGE = "average"
    SUM = "sum"
    RATIO = "ratio"
    TREND = "trend"


class TimeGranularity(str, Enum):
    """Time granularity for analytics"""
    HOUR = "hour"
    DAY = "day"
    WEEK = "week"
    MONTH = "month"
    QUARTER = "quarter"
    YEAR = "year"


class ScheduleFrequency(str, Enum):
    """Report schedule frequencies"""
    DLY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    YEARLY = "yearly"


# Supporting DTOs
class MetricValueDTO(BaseModel):
    """Single metric value"""
    name: str
    value: Union[int, float, str]
    metric_type: MetricType
    unit: Optional[str] = None
    description: Optional[str] = None
    timestamp: datetime


class TimeSeriesDataPointDTO(BaseModel):
    """Time series data point"""
    timestamp: datetime
    value: Union[int, float]
    label: Optional[str] = None


class ChartDataDTO(BaseModel):
    """Chart data structure"""
    chart_type: str  # bar, line, pie, scatter, etc.
    title: str
    x_axis_label: Optional[str] = None
    y_axis_label: Optional[str] = None
    data_points: List[Dict[str, Any]]
    colors: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None


class FilterCriteriaDTO(BaseModel):
    """Filter criteria for analytics"""
    organization_id: Optional[UUID] = None
    dataset_ids: Optional[List[UUID]] = None
    user_ids: Optional[List[UUID]] = None
    date_from: Optional[date] = None
    date_to: Optional[date] = None
    tags: Optional[List[str]] = None
    categories: Optional[List[str]] = None
    custom_filters: Optional[Dict[str, Any]] = None


class ReportParametersDTO(BaseModel):
    """Report generation parameters"""
    title: Optional[str] = None
    description: Optional[str] = None
    include_charts: bool = True
    include_tables: bool = True
    include_summary: bool = True
    custom_sections: Optional[List[str]] = None
    template_id: Optional[UUID] = None


class ScheduleConfigDTO(BaseModel):
    """Schedule configuration"""
    frequency: ScheduleFrequency
    time_of_day: Optional[str] = None  # HH:MM format
    day_of_week: Optional[int] = None  # 0-6, Monday=0
    day_of_month: Optional[int] = None  # 1-31
    timezone: str = "UTC"
    enabled: bool = True


class NotificationConfigDTO(BaseModel):
    """Notification configuration"""
    email_recipients: Optional[List[str]] = None
    webhook_url: Optional[str] = None
    slack_channel: Optional[str] = None
    notify_on_success: bool = True
    notify_on_failure: bool = True


# Request DTOs
class CreateReportRequest(BaseModel):
    """Request to create a new report"""
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    report_type: ReportType
    organization_id: UUID
    filters: Optional[FilterCriteriaDTO] = None
    parameters: Optional[ReportParametersDTO] = None
    format: ReportFormat = ReportFormat.PDF
    schedule: Optional[ScheduleConfigDTO] = None
    notifications: Optional[NotificationConfigDTO] = None


class UpdateReportRequest(BaseModel):
    """Request to update a report"""
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    filters: Optional[FilterCriteriaDTO] = None
    parameters: Optional[ReportParametersDTO] = None
    format: Optional[ReportFormat] = None
    schedule: Optional[ScheduleConfigDTO] = None
    notifications: Optional[NotificationConfigDTO] = None
    enabled: Optional[bool] = None


class GenerateReportRequest(BaseModel):
    """Request to generate a report"""
    report_id: UUID
    format: Optional[ReportFormat] = None
    parameters: Optional[ReportParametersDTO] = None
    async_generation: bool = True


class CreateDashboardRequest(BaseModel):
    """Request to create a dashboard"""
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    dashboard_type: DashboardType
    organization_id: UUID
    layout: Dict[str, Any]  # Dashboard layout configuration
    widgets: List[Dict[str, Any]]  # Widget configurations
    filters: Optional[FilterCriteriaDTO] = None
    refresh_interval: Optional[int] = Field(None, ge=30)  # seconds
    is_public: bool = False


class UpdateDashboardRequest(BaseModel):
    """Request to update a dashboard"""
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    layout: Optional[Dict[str, Any]] = None
    widgets: Optional[List[Dict[str, Any]]] = None
    filters: Optional[FilterCriteriaDTO] = None
    refresh_interval: Optional[int] = Field(None, ge=30)
    is_public: Optional[bool] = None
    enabled: Optional[bool] = None


class AnalyticsQueryRequest(BaseModel):
    """Request for analytics query"""
    query_type: str  # governance, quality, usage, compliance, etc.
    organization_id: UUID
    filters: Optional[FilterCriteriaDTO] = None
    time_granularity: TimeGranularity = TimeGranularity.DAY
    limit: int = Field(100, ge=1, le=10000)
    include_trends: bool = False
    include_comparisons: bool = False


class MetricsRequest(BaseModel):
    """Request for metrics data"""
    metric_names: List[str]
    organization_id: UUID
    filters: Optional[FilterCriteriaDTO] = None
    time_range: Optional[int] = Field(None, ge=1, le=365)  # days
    aggregation: str = "sum"  # sum, avg, count, min, max


# Response DTOs
class ReportResponse(BaseModel):
    """Report response"""
    id: UUID
    name: str
    description: Optional[str]
    report_type: ReportType
    status: ReportStatus
    organization_id: UUID
    organization_name: str
    created_by: UUID
    created_by_name: str
    filters: Optional[FilterCriteriaDTO]
    parameters: Optional[ReportParametersDTO]
    format: ReportFormat
    schedule: Optional[ScheduleConfigDTO]
    notifications: Optional[NotificationConfigDTO]
    file_url: Optional[str]
    file_size: Optional[int]
    generation_time: Optional[float]  # seconds
    last_generated: Optional[datetime]
    next_generation: Optional[datetime]
    enabled: bool
    created_at: datetime
    updated_at: datetime


class ReportListResponse(BaseModel):
    """List of reports response"""
    reports: List[ReportResponse]
    total: int
    limit: int
    offset: int
    has_more: bool


class ReportGenerationResponse(BaseModel):
    """Report generation response"""
    generation_id: UUID
    report_id: UUID
    status: ReportStatus
    progress: int = Field(0, ge=0, le=100)
    message: Optional[str] = None
    file_url: Optional[str] = None
    file_size: Optional[int] = None
    generation_time: Optional[float] = None
    started_at: datetime
    completed_at: Optional[datetime] = None


class DashboardResponse(BaseModel):
    """Dashboard response"""
    id: UUID
    name: str
    description: Optional[str]
    dashboard_type: DashboardType
    organization_id: UUID
    organization_name: str
    created_by: UUID
    created_by_name: str
    layout: Dict[str, Any]
    widgets: List[Dict[str, Any]]
    filters: Optional[FilterCriteriaDTO]
    refresh_interval: Optional[int]
    is_public: bool
    enabled: bool
    view_count: int
    last_viewed: Optional[datetime]
    created_at: datetime
    updated_at: datetime


class DashboardListResponse(BaseModel):
    """List of dashboards response"""
    dashboards: List[DashboardResponse]
    total: int
    limit: int
    offset: int
    has_more: bool


class DashboardDataResponse(BaseModel):
    """Dashboard data response"""
    dashboard_id: UUID
    generated_at: datetime
    widgets_data: List[Dict[str, Any]]
    filters_applied: Optional[FilterCriteriaDTO]
    cache_expires_at: Optional[datetime]


class AnalyticsQueryResponse(BaseModel):
    """Analytics query response"""
    query_type: str
    organization_id: UUID
    generated_at: datetime
    data: List[Dict[str, Any]]
    charts: Optional[List[ChartDataDTO]] = None
    summary: Optional[Dict[str, Any]] = None
    trends: Optional[List[TimeSeriesDataPointDTO]] = None
    comparisons: Optional[Dict[str, Any]] = None
    total_records: int
    execution_time: float  # seconds


class MetricsResponse(BaseModel):
    """Metrics response"""
    organization_id: UUID
    generated_at: datetime
    metrics: List[MetricValueDTO]
    time_series: Optional[List[TimeSeriesDataPointDTO]] = None
    aggregation_period: Optional[str] = None


class GovernanceOverviewResponse(BaseModel):
    """Governance overview analytics"""
    organization_id: UUID
    generated_at: datetime
    total_datasets: int
    active_datasets: int
    datasets_with_quality_issues: int
    datasets_with_pii: int
    compliance_score: float
    quality_score_avg: float
    contracts_count: int
    active_contracts: int
    pending_approvals: int
    users_count: int
    active_users: int
    data_size_total: int
    charts: List[ChartDataDTO]
    trends: List[TimeSeriesDataPointDTO]


class DataQualityAnalyticsResponse(BaseModel):
    """Data quality analytics"""
    organization_id: UUID
    generated_at: datetime
    overall_quality_score: float
    quality_by_dataset: List[Dict[str, Any]]
    quality_by_rule_type: List[Dict[str, Any]]
    quality_trends: List[TimeSeriesDataPointDTO]
    top_quality_issues: List[Dict[str, Any]]
    quality_improvements: List[Dict[str, Any]]
    charts: List[ChartDataDTO]


class UsageAnalyticsResponse(BaseModel):
    """Usage analytics"""
    organization_id: UUID
    generated_at: datetime
    total_queries: int
    unique_users: int
    most_accessed_datasets: List[Dict[str, Any]]
    usage_by_department: List[Dict[str, Any]]
    usage_trends: List[TimeSeriesDataPointDTO]
    peak_usage_hours: List[Dict[str, Any]]
    charts: List[ChartDataDTO]


class ComplianceAnalyticsResponse(BaseModel):
    """Compliance analytics"""
    organization_id: UUID
    generated_at: datetime
    lgpd_compliance_score: float
    datasets_with_pii: int
    masked_fields_count: int
    compliance_by_dataset: List[Dict[str, Any]]
    compliance_trends: List[TimeSeriesDataPointDTO]
    compliance_violations: List[Dict[str, Any]]
    remediation_actions: List[Dict[str, Any]]
    charts: List[ChartDataDTO]


class PerformanceAnalyticsResponse(BaseModel):
    """Performance analytics"""
    organization_id: UUID
    generated_at: datetime
    avg_query_time: float
    total_data_processed: int
    system_uptime: float
    error_rate: float
    performance_by_service: List[Dict[str, Any]]
    performance_trends: List[TimeSeriesDataPointDTO]
    bottlenecks: List[Dict[str, Any]]
    charts: List[ChartDataDTO]


class TrendAnalysisResponse(BaseModel):
    """Trend analysis"""
    organization_id: UUID
    generated_at: datetime
    analysis_period: str
    data_growth_trend: List[TimeSeriesDataPointDTO]
    quality_trend: List[TimeSeriesDataPointDTO]
    usage_trend: List[TimeSeriesDataPointDTO]
    compliance_trend: List[TimeSeriesDataPointDTO]
    predictions: Optional[Dict[str, Any]] = None
    insights: List[str]
    recommendations: List[str]
    charts: List[ChartDataDTO]


# Summary DTOs
class ReportSummaryResponse(BaseModel):
    """Report summary"""
    id: UUID
    name: str
    report_type: ReportType
    status: ReportStatus
    organization_name: str
    created_by_name: str
    last_generated: Optional[datetime]
    next_generation: Optional[datetime]
    enabled: bool


class DashboardSummaryResponse(BaseModel):
    """Dashboard summary"""
    id: UUID
    name: str
    dashboard_type: DashboardType
    organization_name: str
    created_by_name: str
    is_public: bool
    enabled: bool
    view_count: int
    last_viewed: Optional[datetime]


# Statistics DTOs
class AnalyticsStatisticsResponse(BaseModel):
    """Analytics service statistics"""
    organization_id: UUID
    total_reports: int
    active_reports: int
    total_dashboards: int
    active_dashboards: int
    reports_by_type: Dict[str, int]
    dashboards_by_type: Dict[str, int]
    total_generations: int
    successful_generations: int
    failed_generations: int
    avg_generation_time: float
    most_popular_reports: List[ReportSummaryResponse]
    most_viewed_dashboards: List[DashboardSummaryResponse]

