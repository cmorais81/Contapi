# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
Catalog Service - Microserviço de Catálogo de Dados
Versão: 4.0.1 - Corrigida com base na V3.2
Data: 27 de Janeiro de 2025
"""

import logging
import re
from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Query, Path, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'config'))

try:
    from settings import get_settings
    settings = get_settings()
except ImportError:
    print("⚠️ Configurações centralizadas não encontradas, usando valores padrão")
    settings = None


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Catalog Service",
    description="Microserviço para catálogo de entidades de dados - V4.0 Corrigido",
    version="4.0.1",
    contact={
        "name": " ",
        "email": "@example.com"
    }
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# PYDANTIC MODELS
# =====================================================

class EntityBase(BaseModel):
    name: str = Field(..., description="Nome da entidade")
    description: Optional[str] = Field(None, description="Descrição da entidade")
    entity_type: str = Field("table", description="Tipo da entidade")
    schema_name: Optional[str] = Field(None, description="Nome do schema")
    database_name: Optional[str] = Field(None, description="Nome do banco")
    tags: List[str] = Field(default_factory=list, description="Tags da entidade")

class EntityCreate(EntityBase):
    pass

class EntityUpdate(EntityBase):
    pass

class EntityResponse(EntityBase):
    id: str
    created_at: datetime
    updated_at: datetime
    is_active: bool

class ColumnBase(BaseModel):
    name: str = Field(..., description="Nome da coluna")
    data_type: str = Field(..., description="Tipo de dados")
    description: Optional[str] = Field(None, description="Descrição da coluna")
    is_nullable: bool = Field(True, description="Permite valores nulos")
    is_primary_key: bool = Field(False, description="É chave primária")
    is_foreign_key: bool = Field(False, description="É chave estrangeira")

class ColumnCreate(ColumnBase):
    entity_id: str = Field(..., description="ID da entidade")

class ColumnResponse(ColumnBase):
    id: str
    entity_id: str
    created_at: datetime
    updated_at: datetime

class SearchRequest(BaseModel):
    query: str = Field(..., description="Termo de busca")
    entity_types: Optional[List[str]] = Field(None, description="Filtrar por tipos")
    tags: Optional[List[str]] = Field(None, description="Filtrar por tags")

# =====================================================
# IN-MEMORY DATABASE (Simulação)
# =====================================================

entities_db = {}
columns_db = {}
audit_logs = []

def log_audit(action: str, resource_id: str = None, details: str = None):
    """Log audit trail"""
    try:
        audit_logs.append({
            "id": str(uuid4()),
            "action": action,
            "resource_type": "catalog",
            "resource_id": resource_id,
            "details": details,
            "created_at": datetime.utcnow().isoformat()
        })
    except Exception as e:
        logger.error(f"Error logging audit: {e}")

def init_sample_data():
    """Initialize sample entities and columns"""
    sample_entities = [
        {
            "id": str(uuid4()),
            "name": "customers",
            "description": "Tabela de clientes com dados pessoais",
            "entity_type": "table",
            "schema_name": "sales",
            "database_name": "production",
            "tags": ["pii", "customers", "sales"],
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "orders",
            "description": "Tabela de pedidos e transações",
            "entity_type": "table",
            "schema_name": "sales",
            "database_name": "production",
            "tags": ["transactions", "orders", "sales"],
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "products",
            "description": "Catálogo de produtos",
            "entity_type": "table",
            "schema_name": "inventory",
            "database_name": "production",
            "tags": ["products", "inventory", "catalog"],
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "customer_analytics_view",
            "description": "View analítica de comportamento de clientes",
            "entity_type": "view",
            "schema_name": "analytics",
            "database_name": "datawarehouse",
            "tags": ["analytics", "customers", "view"],
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
    ]
    
    for entity in sample_entities:
        entities_db[entity["id"]] = entity
    
    # Sample columns for customers table
    customers_entity = next(e for e in sample_entities if e["name"] == "customers")
    sample_columns = [
        {
            "id": str(uuid4()),
            "entity_id": customers_entity["id"],
            "name": "customer_id",
            "data_type": "INTEGER",
            "description": "Identificador único do cliente",
            "is_nullable": False,
            "is_primary_key": True,
            "is_foreign_key": False,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "entity_id": customers_entity["id"],
            "name": "email",
            "data_type": "VARCHAR(255)",
            "description": "Email do cliente (PII)",
            "is_nullable": False,
            "is_primary_key": False,
            "is_foreign_key": False,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "entity_id": customers_entity["id"],
            "name": "full_name",
            "data_type": "VARCHAR(500)",
            "description": "Nome completo do cliente (PII)",
            "is_nullable": False,
            "is_primary_key": False,
            "is_foreign_key": False,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "entity_id": customers_entity["id"],
            "name": "created_at",
            "data_type": "TIMESTAMP",
            "description": "Data de criação do registro",
            "is_nullable": False,
            "is_primary_key": False,
            "is_foreign_key": False,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
    ]
    
    for column in sample_columns:
        columns_db[column["id"]] = column
    
    logger.info(f"Initialized {len(sample_entities)} sample entities and {len(sample_columns)} columns")

def search_entities(query: str, entity_types: List[str] = None, tags: List[str] = None) -> List[Dict]:
    """Search entities based on query and filters"""
    results = []
    query_lower = query.lower()
    
    for entity in entities_db.values():
        if not entity["is_active"]:
            continue
            
        # Text search in name and description
        name_match = query_lower in entity["name"].lower()
        desc_match = entity["description"] and query_lower in entity["description"].lower()
        tag_match = any(query_lower in tag.lower() for tag in entity["tags"])
        
        if not (name_match or desc_match or tag_match):
            continue
            
        # Filter by entity types
        if entity_types and entity["entity_type"] not in entity_types:
            continue
            
        # Filter by tags
        if tags and not any(tag in entity["tags"] for tag in tags):
            continue
            
        # Calculate relevance score
        score = 0
        if name_match:
            score += 10
        if desc_match:
            score += 5
        if tag_match:
            score += 3
            
        results.append({
            "entity": entity,
            "relevance_score": score,
            "match_reasons": {
                "name_match": name_match,
                "description_match": desc_match,
                "tag_match": tag_match
            }
        })
    
    # Sort by relevance score
    results.sort(key=lambda x: x["relevance_score"], reverse=True)
    return results

# =====================================================
# API ENDPOINTS
# =====================================================

@app.get("/", tags=["System"])
async def root():
    """Root endpoint with service information"""
    return {
        "service": "Catalog Service",
        "version": "4.0.1",
        "status": "running",
        "description": "Microserviço para catálogo de entidades de dados - Corrigido",
        "corrections_applied": [
            "Dependências estabilizadas",
            "Error handling robusto",
            "Logs estruturados",
            "In-memory database funcional"
        ],
        "endpoints": {
            "health": "/health",
            "docs": "/docs",
            "entities": "/api/v1/entities",
            "columns": "/api/v1/columns",
            "search": "/api/v1/search"
        }
    }

@app.get("/health", tags=["System"])
async def health_check():
    """Health check endpoint"""
    try:
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "version": "4.0.1",
            "service": "catalog-service",
            "port": 8004,
            "corrections_applied": True,
            "data_counts": {
                "entities": len(entities_db),
                "columns": len(columns_db),
                "audit_logs": len(audit_logs)
            },
            "features": {
                "entity_management": True,
                "column_management": True,
                "search_functionality": True,
                "metadata_management": True,
                "audit_trail": True
            }
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "status": "unhealthy",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

@app.get("/api/v1/entities", response_model=List[EntityResponse], tags=["Entities"])
async def list_entities(
    entity_type: Optional[str] = Query(None, description="Filtrar por tipo"),
    schema_name: Optional[str] = Query(None, description="Filtrar por schema"),
    database_name: Optional[str] = Query(None, description="Filtrar por banco"),
    is_active: Optional[bool] = Query(None, description="Filtrar por status ativo"),
    limit: int = Query(100, description="Limite de resultados")
):
    """Listar todas as entidades do catálogo"""
    try:
        entities = list(entities_db.values())
        
        # Apply filters
        if entity_type:
            entities = [e for e in entities if e["entity_type"] == entity_type]
        
        if schema_name:
            entities = [e for e in entities if e["schema_name"] == schema_name]
            
        if database_name:
            entities = [e for e in entities if e["database_name"] == database_name]
            
        if is_active is not None:
            entities = [e for e in entities if e["is_active"] == is_active]
        
        # Apply limit
        entities = entities[:limit]
        
        # Convert datetime objects to ISO format
        for entity in entities:
            entity["created_at"] = entity["created_at"].isoformat()
            entity["updated_at"] = entity["updated_at"].isoformat()
        
        log_audit("list", details=f"Listed {len(entities)} entities")
        return entities
        
    except Exception as e:
        logger.error(f"Error listing entities: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing entities: {str(e)}")

@app.get("/api/v1/entities/{entity_id}", response_model=EntityResponse, tags=["Entities"])
async def get_entity(entity_id: str = Path(..., description="ID da entidade")):
    """Buscar entidade específica por ID"""
    try:
        if entity_id not in entities_db:
            raise HTTPException(status_code=404, detail="Entity not found")
        
        entity = entities_db[entity_id].copy()
        entity["created_at"] = entity["created_at"].isoformat()
        entity["updated_at"] = entity["updated_at"].isoformat()
        
        log_audit("get", resource_id=entity_id)
        return entity
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting entity: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting entity: {str(e)}")

@app.post("/api/v1/entities", response_model=EntityResponse, tags=["Entities"])
async def create_entity(entity: EntityCreate):
    """Criar nova entidade no catálogo"""
    try:
        entity_id = str(uuid4())
        now = datetime.utcnow()
        
        new_entity = {
            "id": entity_id,
            "name": entity.name,
            "description": entity.description,
            "entity_type": entity.entity_type,
            "schema_name": entity.schema_name,
            "database_name": entity.database_name,
            "tags": entity.tags,
            "is_active": True,
            "created_at": now,
            "updated_at": now
        }
        
        entities_db[entity_id] = new_entity
        
        log_audit("create", resource_id=entity_id, details=f"Created entity: {entity.name}")
        
        # Convert datetime for response
        response_entity = new_entity.copy()
        response_entity["created_at"] = response_entity["created_at"].isoformat()
        response_entity["updated_at"] = response_entity["updated_at"].isoformat()
        
        return response_entity
        
    except Exception as e:
        logger.error(f"Error creating entity: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating entity: {str(e)}")

@app.put("/api/v1/entities/{entity_id}", response_model=EntityResponse, tags=["Entities"])
async def update_entity(entity_id: str, entity: EntityUpdate):
    """Atualizar entidade existente"""
    try:
        if entity_id not in entities_db:
            raise HTTPException(status_code=404, detail="Entity not found")
        
        existing_entity = entities_db[entity_id]
        
        # Update fields
        existing_entity.update({
            "name": entity.name,
            "description": entity.description,
            "entity_type": entity.entity_type,
            "schema_name": entity.schema_name,
            "database_name": entity.database_name,
            "tags": entity.tags,
            "updated_at": datetime.utcnow()
        })
        
        log_audit("update", resource_id=entity_id, details=f"Updated entity: {entity.name}")
        
        # Convert datetime for response
        response_entity = existing_entity.copy()
        response_entity["created_at"] = response_entity["created_at"].isoformat()
        response_entity["updated_at"] = response_entity["updated_at"].isoformat()
        
        return response_entity
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating entity: {e}")
        raise HTTPException(status_code=500, detail=f"Error updating entity: {str(e)}")

@app.delete("/api/v1/entities/{entity_id}", tags=["Entities"])
async def delete_entity(entity_id: str):
    """Deletar entidade (desativar)"""
    try:
        if entity_id not in entities_db:
            raise HTTPException(status_code=404, detail="Entity not found")
        
        entity = entities_db[entity_id]
        entity["is_active"] = False
        entity["updated_at"] = datetime.utcnow()
        
        log_audit("delete", resource_id=entity_id, details=f"Deactivated entity: {entity['name']}")
        
        return {"message": "Entity deactivated successfully", "id": entity_id}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting entity: {e}")
        raise HTTPException(status_code=500, detail=f"Error deleting entity: {str(e)}")

@app.get("/api/v1/entities/{entity_id}/columns", response_model=List[ColumnResponse], tags=["Columns"])
async def list_entity_columns(entity_id: str):
    """Listar colunas de uma entidade"""
    try:
        if entity_id not in entities_db:
            raise HTTPException(status_code=404, detail="Entity not found")
        
        columns = [col for col in columns_db.values() if col["entity_id"] == entity_id]
        
        # Convert datetime objects to ISO format
        for column in columns:
            column["created_at"] = column["created_at"].isoformat()
            column["updated_at"] = column["updated_at"].isoformat()
        
        log_audit("list_columns", resource_id=entity_id, details=f"Listed {len(columns)} columns")
        return columns
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing columns: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing columns: {str(e)}")

@app.post("/api/v1/columns", response_model=ColumnResponse, tags=["Columns"])
async def create_column(column: ColumnCreate):
    """Criar nova coluna"""
    try:
        if column.entity_id not in entities_db:
            raise HTTPException(status_code=404, detail="Entity not found")
        
        column_id = str(uuid4())
        now = datetime.utcnow()
        
        new_column = {
            "id": column_id,
            "entity_id": column.entity_id,
            "name": column.name,
            "data_type": column.data_type,
            "description": column.description,
            "is_nullable": column.is_nullable,
            "is_primary_key": column.is_primary_key,
            "is_foreign_key": column.is_foreign_key,
            "created_at": now,
            "updated_at": now
        }
        
        columns_db[column_id] = new_column
        
        log_audit("create_column", resource_id=column_id, details=f"Created column: {column.name}")
        
        # Convert datetime for response
        response_column = new_column.copy()
        response_column["created_at"] = response_column["created_at"].isoformat()
        response_column["updated_at"] = response_column["updated_at"].isoformat()
        
        return response_column
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating column: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating column: {str(e)}")

@app.post("/api/v1/search", tags=["Search"])
async def search_catalog(request: SearchRequest):
    """Buscar entidades no catálogo"""
    try:
        results = search_entities(request.query, request.entity_types, request.tags)
        
        # Format results
        formatted_results = []
        for result in results:
            entity = result["entity"].copy()
            entity["created_at"] = entity["created_at"].isoformat()
            entity["updated_at"] = entity["updated_at"].isoformat()
            
            formatted_results.append({
                "entity": entity,
                "relevance_score": result["relevance_score"],
                "match_reasons": result["match_reasons"]
            })
        
        log_audit("search", details=f"Search query: '{request.query}' - {len(results)} results")
        
        return {
            "query": request.query,
            "total_results": len(formatted_results),
            "results": formatted_results,
            "filters_applied": {
                "entity_types": request.entity_types,
                "tags": request.tags
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error searching catalog: {e}")
        raise HTTPException(status_code=500, detail=f"Error searching catalog: {str(e)}")

@app.get("/api/v1/statistics", tags=["Statistics"])
async def get_catalog_statistics():
    """Obter estatísticas do catálogo"""
    try:
        # Count by entity type
        entity_types = {}
        for entity in entities_db.values():
            if entity["is_active"]:
                entity_type = entity["entity_type"]
                entity_types[entity_type] = entity_types.get(entity_type, 0) + 1
        
        # Count by database
        databases = {}
        for entity in entities_db.values():
            if entity["is_active"] and entity["database_name"]:
                db_name = entity["database_name"]
                databases[db_name] = databases.get(db_name, 0) + 1
        
        # Count by schema
        schemas = {}
        for entity in entities_db.values():
            if entity["is_active"] and entity["schema_name"]:
                schema_name = entity["schema_name"]
                schemas[schema_name] = schemas.get(schema_name, 0) + 1
        
        # Most used tags
        tag_counts = {}
        for entity in entities_db.values():
            if entity["is_active"]:
                for tag in entity["tags"]:
                    tag_counts[tag] = tag_counts.get(tag, 0) + 1
        
        # Sort tags by usage
        top_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]
        
        return {
            "total_entities": len([e for e in entities_db.values() if e["is_active"]]),
            "total_columns": len(columns_db),
            "entity_types": entity_types,
            "databases": databases,
            "schemas": schemas,
            "top_tags": [{"tag": tag, "count": count} for tag, count in top_tags],
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting statistics: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting statistics: {str(e)}")

@app.get("/api/v1/audit/logs", tags=["Audit"])
async def list_audit_logs(limit: int = Query(100, description="Limite de resultados")):
    """Listar logs de auditoria"""
    try:
        logs = audit_logs[-limit:] if limit < len(audit_logs) else audit_logs
        return logs
    except Exception as e:
        logger.error(f"Error listing audit logs: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing audit logs: {str(e)}")

# Initialize sample data on startup
@app.on_event("startup")
async def startup_event():
    """Initialize service on startup"""
    logger.info("Starting Catalog Service V4.0.1 - Corrigido")
    init_sample_data()
    logger.info("Catalog Service started successfully")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8004)

