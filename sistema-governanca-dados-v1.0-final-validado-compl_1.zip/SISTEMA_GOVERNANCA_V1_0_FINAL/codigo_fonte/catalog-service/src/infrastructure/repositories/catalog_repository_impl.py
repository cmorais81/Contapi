# Autor: carlos.morais@f1rst.com.br
"""
Catalog Repository Implementation
SQLAlchemy implementation for catalog data access
"""

import json
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID

from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, func, desc, asc, text
from sqlalchemy.exc import IntegrityError

from ...domain.entities.dataset import Dataset as DatasetEntity
from ...domain.repositories.catalog_repository import CatalogRepository
from ...domain.value_objects.dataset_status import DatasetStatus
from ...domain.value_objects.dataset_type import DatasetType
from ...domain.value_objects.access_level import AccessLevel
from ...domain.value_objects.data_classification import DataClassification

# Import shared models
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'shared'))

from shared.database.models.central_models import (
    Dataset, Organization, User, DatasetVersion, DatasetProfile,
    DatasetUsage, DatasetLineage, DatasetTag, BusinessTerm
)


class CatalogRepositoryImpl(CatalogRepository):
    """SQLAlchemy implementation of catalog repository"""
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    def save(self, dataset: DatasetEntity) -> DatasetEntity:
        """Save dataset entity"""
        try:
            # Check if dataset exists
            existing = self.db.query(Dataset).filter(Dataset.id == dataset.id).first()
            
            if existing:
                # Update existing dataset
                self._update_model_from_entity(existing, dataset)
                model = existing
            else:
                # Create new dataset
                model = self._entity_to_model(dataset)
                self.db.add(model)
            
            self.db.commit()
            self.db.refresh(model)
            
            return self._model_to_entity(model)
            
        except IntegrityError as e:
            self.db.rollback()
            if "unique constraint" in str(e).lower():
                raise ValueError("Dataset name already exists in organization")
            raise RuntimeError(f"Database integrity error: {str(e)}")
        except Exception as e:
            self.db.rollback()
            raise RuntimeError(f"Failed to save dataset: {str(e)}")
    
    def find_by_id(self, dataset_id: UUID) -> Optional[DatasetEntity]:
        """Find dataset by ID"""
        try:
            model = (
                self.db.query(Dataset)
                .options(
                    joinedload(Dataset.organization),
                    joinedload(Dataset.owner),
                    joinedload(Dataset.created_by_user)
                )
                .filter(Dataset.id == dataset_id)
                .filter(Dataset.deleted_at.is_(None))
                .first()
            )
            
            return self._model_to_entity(model) if model else None
            
        except Exception as e:
            raise RuntimeError(f"Failed to find dataset by ID: {str(e)}")
    
    def find_by_name(self, name: str, organization_id: UUID) -> Optional[DatasetEntity]:
        """Find dataset by name within organization"""
        try:
            model = (
                self.db.query(Dataset)
                .options(
                    joinedload(Dataset.organization),
                    joinedload(Dataset.owner),
                    joinedload(Dataset.created_by_user)
                )
                .filter(Dataset.name == name)
                .filter(Dataset.organization_id == organization_id)
                .filter(Dataset.deleted_at.is_(None))
                .first()
            )
            
            return self._model_to_entity(model) if model else None
            
        except Exception as e:
            raise RuntimeError(f"Failed to find dataset by name: {str(e)}")
    
    def find_with_filters(self, filters: Dict[str, Any], limit: int = 100, offset: int = 0) -> List[DatasetEntity]:
        """Find datasets with filters"""
        try:
            query = (
                self.db.query(Dataset)
                .options(
                    joinedload(Dataset.organization),
                    joinedload(Dataset.owner),
                    joinedload(Dataset.created_by_user)
                )
                .filter(Dataset.deleted_at.is_(None))
            )
            
            # Apply filters
            if 'organization_id' in filters:
                query = query.filter(Dataset.organization_id == filters['organization_id'])
            
            if 'owner_id' in filters:
                query = query.filter(Dataset.owner_id == filters['owner_id'])
            
            if 'dataset_type' in filters:
                query = query.filter(Dataset.dataset_type == filters['dataset_type'])
            
            if 'status' in filters:
                query = query.filter(Dataset.status == filters['status'])
            
            if 'access_level' in filters:
                query = query.filter(Dataset.access_level == filters['access_level'])
            
            if 'classification' in filters:
                query = query.filter(Dataset.classification == filters['classification'])
            
            if 'created_after' in filters:
                query = query.filter(Dataset.created_at >= filters['created_after'])
            
            if 'created_before' in filters:
                query = query.filter(Dataset.created_at <= filters['created_before'])
            
            if 'updated_after' in filters:
                query = query.filter(Dataset.updated_at >= filters['updated_after'])
            
            if 'updated_before' in filters:
                query = query.filter(Dataset.updated_at <= filters['updated_before'])
            
            # Apply tags filter
            if 'tags' in filters and filters['tags']:
                tag_conditions = []
                for tag in filters['tags']:
                    tag_conditions.append(Dataset.tags.contains([tag]))
                query = query.filter(or_(*tag_conditions))
            
            # Apply business terms filter
            if 'business_terms' in filters and filters['business_terms']:
                term_conditions = []
                for term in filters['business_terms']:
                    term_conditions.append(Dataset.business_terms.contains([term]))
                query = query.filter(or_(*term_conditions))
            
            # Order by updated_at desc
            query = query.order_by(desc(Dataset.updated_at))
            
            # Apply pagination
            models = query.offset(offset).limit(limit).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find datasets with filters: {str(e)}")
    
    def search_datasets(self, search_term: str, organization_id: Optional[UUID] = None,
                       limit: int = 50, offset: int = 0) -> List[DatasetEntity]:
        """Search datasets by text"""
        try:
            # Build search conditions
            search_conditions = [
                Dataset.name.ilike(f"%{search_term}%"),
                Dataset.title.ilike(f"%{search_term}%"),
                Dataset.description.ilike(f"%{search_term}%")
            ]
            
            # Add tag search
            search_conditions.append(
                func.array_to_string(Dataset.tags, ' ').ilike(f"%{search_term}%")
            )
            
            # Add business terms search
            search_conditions.append(
                func.array_to_string(Dataset.business_terms, ' ').ilike(f"%{search_term}%")
            )
            
            query = (
                self.db.query(Dataset)
                .options(
                    joinedload(Dataset.organization),
                    joinedload(Dataset.owner),
                    joinedload(Dataset.created_by_user)
                )
                .filter(Dataset.deleted_at.is_(None))
                .filter(or_(*search_conditions))
            )
            
            if organization_id:
                query = query.filter(Dataset.organization_id == organization_id)
            
            # Order by relevance (simplified - by updated_at desc)
            query = query.order_by(desc(Dataset.updated_at))
            
            # Apply pagination
            models = query.offset(offset).limit(limit).all()
            
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to search datasets: {str(e)}")
    
    def find_popular_datasets(self, organization_id: UUID, limit: int = 10) -> List[DatasetEntity]:
        """Find most popular datasets"""
        try:
            # Join with usage statistics and order by popularity
            query = (
                self.db.query(Dataset)
                .options(
                    joinedload(Dataset.organization),
                    joinedload(Dataset.owner),
                    joinedload(Dataset.created_by_user)
                )
                .outerjoin(DatasetUsage)
                .filter(Dataset.organization_id == organization_id)
                .filter(Dataset.status == 'active')
                .filter(Dataset.deleted_at.is_(None))
                .order_by(desc(func.coalesce(DatasetUsage.popularity_score, 0)))
                .limit(limit)
            )
            
            models = query.all()
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find popular datasets: {str(e)}")
    
    def find_recently_updated(self, organization_id: UUID, limit: int = 10) -> List[DatasetEntity]:
        """Find recently updated datasets"""
        try:
            models = (
                self.db.query(Dataset)
                .options(
                    joinedload(Dataset.organization),
                    joinedload(Dataset.owner),
                    joinedload(Dataset.created_by_user)
                )
                .filter(Dataset.organization_id == organization_id)
                .filter(Dataset.status == 'active')
                .filter(Dataset.deleted_at.is_(None))
                .order_by(desc(Dataset.updated_at))
                .limit(limit)
                .all()
            )
            
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find recently updated datasets: {str(e)}")
    
    def get_lineage(self, dataset_id: UUID, direction: str = "both", depth: int = 3) -> Dict[str, Any]:
        """Get dataset lineage"""
        try:
            lineage_data = {
                "dataset_id": dataset_id,
                "upstream": [],
                "downstream": []
            }
            
            if direction in ["upstream", "both"]:
                upstream = self._get_lineage_recursive(dataset_id, "upstream", depth)
                lineage_data["upstream"] = upstream
            
            if direction in ["downstream", "both"]:
                downstream = self._get_lineage_recursive(dataset_id, "downstream", depth)
                lineage_data["downstream"] = downstream
            
            return lineage_data
            
        except Exception as e:
            raise RuntimeError(f"Failed to get dataset lineage: {str(e)}")
    
    def get_statistics(self, organization_id: UUID) -> Dict[str, Any]:
        """Get catalog statistics"""
        try:
            # Total datasets
            total_datasets = (
                self.db.query(func.count(Dataset.id))
                .filter(Dataset.organization_id == organization_id)
                .filter(Dataset.deleted_at.is_(None))
                .scalar()
            )
            
            # Active datasets
            active_datasets = (
                self.db.query(func.count(Dataset.id))
                .filter(Dataset.organization_id == organization_id)
                .filter(Dataset.status == 'active')
                .filter(Dataset.deleted_at.is_(None))
                .scalar()
            )
            
            # Datasets by type
            type_stats = (
                self.db.query(Dataset.dataset_type, func.count(Dataset.id))
                .filter(Dataset.organization_id == organization_id)
                .filter(Dataset.deleted_at.is_(None))
                .group_by(Dataset.dataset_type)
                .all()
            )
            
            datasets_by_type = {type_name: count for type_name, count in type_stats}
            
            # Datasets by classification
            classification_stats = (
                self.db.query(Dataset.classification, func.count(Dataset.id))
                .filter(Dataset.organization_id == organization_id)
                .filter(Dataset.deleted_at.is_(None))
                .group_by(Dataset.classification)
                .all()
            )
            
            datasets_by_classification = {classification: count for classification, count in classification_stats}
            
            # Total data size (simplified)
            total_size = (
                self.db.query(func.sum(Dataset.size_bytes))
                .filter(Dataset.organization_id == organization_id)
                .filter(Dataset.deleted_at.is_(None))
                .scalar() or 0
            )
            
            # Average quality score (simplified)
            avg_quality = (
                self.db.query(func.avg(Dataset.quality_score))
                .filter(Dataset.organization_id == organization_id)
                .filter(Dataset.deleted_at.is_(None))
                .filter(Dataset.quality_score.is_not(None))
                .scalar() or 0
            )
            
            return {
                "total_datasets": total_datasets,
                "active_datasets": active_datasets,
                "datasets_by_type": datasets_by_type,
                "datasets_by_classification": datasets_by_classification,
                "total_data_size": total_size,
                "average_quality_score": float(avg_quality) if avg_quality else 0.0
            }
            
        except Exception as e:
            raise RuntimeError(f"Failed to get catalog statistics: {str(e)}")
    
    def delete(self, dataset_id: UUID) -> bool:
        """Soft delete dataset"""
        try:
            model = self.db.query(Dataset).filter(Dataset.id == dataset_id).first()
            if not model:
                return False
            
            model.deleted_at = datetime.utcnow()
            model.status = 'archived'
            
            self.db.commit()
            return True
            
        except Exception as e:
            self.db.rollback()
            raise RuntimeError(f"Failed to delete dataset: {str(e)}")
    
    def exists_by_name(self, name: str, organization_id: UUID, exclude_id: Optional[UUID] = None) -> bool:
        """Check if dataset name exists in organization"""
        try:
            query = (
                self.db.query(Dataset.id)
                .filter(Dataset.name == name)
                .filter(Dataset.organization_id == organization_id)
                .filter(Dataset.deleted_at.is_(None))
            )
            
            if exclude_id:
                query = query.filter(Dataset.id != exclude_id)
            
            return query.first() is not None
            
        except Exception as e:
            raise RuntimeError(f"Failed to check dataset name existence: {str(e)}")
    
    def _get_lineage_recursive(self, dataset_id: UUID, direction: str, depth: int, current_depth: int = 0) -> List[Dict[str, Any]]:
        """Get lineage recursively"""
        if current_depth >= depth:
            return []
        
        try:
            if direction == "upstream":
                # Get parent datasets
                lineage_query = (
                    self.db.query(DatasetLineage, Dataset)
                    .join(Dataset, DatasetLineage.source_dataset_id == Dataset.id)
                    .filter(DatasetLineage.target_dataset_id == dataset_id)
                    .filter(Dataset.deleted_at.is_(None))
                )
            else:  # downstream
                # Get child datasets
                lineage_query = (
                    self.db.query(DatasetLineage, Dataset)
                    .join(Dataset, DatasetLineage.target_dataset_id == Dataset.id)
                    .filter(DatasetLineage.source_dataset_id == dataset_id)
                    .filter(Dataset.deleted_at.is_(None))
                )
            
            results = []
            for lineage, dataset in lineage_query.all():
                node = {
                    "dataset_id": dataset.id,
                    "dataset_name": dataset.name,
                    "dataset_type": dataset.dataset_type,
                    "organization_name": dataset.organization.name if dataset.organization else "Unknown",
                    "level": current_depth + 1,
                    "relationship_type": lineage.relationship_type,
                    "transformation_logic": lineage.transformation_logic
                }
                results.append(node)
                
                # Recursively get next level
                next_id = dataset.id
                next_level = self._get_lineage_recursive(next_id, direction, depth, current_depth + 1)
                results.extend(next_level)
            
            return results
            
        except Exception as e:
            raise RuntimeError(f"Failed to get lineage recursively: {str(e)}")
    
    def _entity_to_model(self, entity: DatasetEntity) -> Dataset:
        """Convert entity to SQLAlchemy model"""
        return Dataset(
            id=entity.id,
            name=entity.name,
            title=entity.title,
            description=entity.description,
            dataset_type=entity.dataset_type.value,
            status=entity.status.value,
            organization_id=entity.organization_id,
            owner_id=entity.owner_id,
            location=json.dumps(entity.location) if entity.location else None,
            schema_definition=json.dumps(entity.schema) if entity.schema else None,
            access_level=entity.access_level.value,
            classification=entity.classification.value,
            tags=entity.tags,
            business_terms=entity.business_terms,
            metadata=entity.metadata,
            size_bytes=entity.size_bytes,
            row_count=entity.row_count,
            column_count=entity.column_count,
            quality_score=entity.quality_score,
            popularity_score=entity.popularity_score,
            created_by=entity.created_by,
            created_at=entity.created_at,
            updated_at=entity.updated_at
        )
    
    def _update_model_from_entity(self, model: Dataset, entity: DatasetEntity):
        """Update SQLAlchemy model from entity"""
        model.title = entity.title
        model.description = entity.description
        model.dataset_type = entity.dataset_type.value
        model.status = entity.status.value
        model.owner_id = entity.owner_id
        model.location = json.dumps(entity.location) if entity.location else None
        model.schema_definition = json.dumps(entity.schema) if entity.schema else None
        model.access_level = entity.access_level.value
        model.classification = entity.classification.value
        model.tags = entity.tags
        model.business_terms = entity.business_terms
        model.metadata = entity.metadata
        model.size_bytes = entity.size_bytes
        model.row_count = entity.row_count
        model.column_count = entity.column_count
        model.quality_score = entity.quality_score
        model.popularity_score = entity.popularity_score
        model.updated_at = entity.updated_at
    
    def _model_to_entity(self, model: Dataset) -> DatasetEntity:
        """Convert SQLAlchemy model to entity"""
        return DatasetEntity(
            id=model.id,
            name=model.name,
            title=model.title,
            description=model.description,
            dataset_type=DatasetType(model.dataset_type),
            status=DatasetStatus(model.status),
            organization_id=model.organization_id,
            organization_name=model.organization.name if model.organization else "Unknown",
            owner_id=model.owner_id,
            owner_name=model.owner.full_name if model.owner else "Unknown",
            location=json.loads(model.location) if model.location else {},
            schema=json.loads(model.schema_definition) if model.schema_definition else {},
            access_level=AccessLevel(model.access_level),
            classification=DataClassification(model.classification),
            tags=model.tags or [],
            business_terms=model.business_terms or [],
            metadata=model.metadata or {},
            size_bytes=model.size_bytes,
            row_count=model.row_count,
            column_count=model.column_count,
            quality_score=model.quality_score,
            popularity_score=model.popularity_score or 0.0,
            created_by=model.created_by,
            created_by_name=model.created_by_user.full_name if model.created_by_user else "Unknown",
            created_at=model.created_at,
            updated_at=model.updated_at
        )

