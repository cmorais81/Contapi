# Autor: carlos.morais@f1rst.com.br
from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class MetadataTag:
    """Value object para tags de metadados"""
    key: str
    value: str
    category: Optional[str] = None
    
    def __post_init__(self):
        if not self.key or not self.key.strip():
            raise ValueError("Chave da tag não pode ser vazia")
        if not self.value or not self.value.strip():
            raise ValueError("Valor da tag não pode ser vazio")
    
    def to_dict(self) -> dict:
        return {
            "key": self.key,
            "value": self.value,
            "category": self.category
        }
