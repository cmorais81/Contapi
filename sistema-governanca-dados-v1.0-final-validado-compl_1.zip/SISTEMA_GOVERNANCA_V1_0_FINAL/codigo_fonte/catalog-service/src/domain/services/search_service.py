# Autor: carlos.morais@f1rst.com.br
from typing import List, Dict, Any
import re

class SearchService:
    """Serviço de domínio para busca no catálogo"""
    
    def parse_search_query(self, query: str) -> Dict[str, Any]:
        """Analisa query de busca e extrai filtros"""
        parsed = {
            "terms": [],
            "filters": {},
            "tags": []
        }
        
        # Extrair tags (formato: tag:value)
        tag_pattern = r'(\w+):(\w+)'
        tags = re.findall(tag_pattern, query)
        for key, value in tags:
            parsed["tags"].append({"key": key, "value": value})
        
        # Remover tags da query e extrair termos
        clean_query = re.sub(tag_pattern, '', query)
        terms = [term.strip() for term in clean_query.split() if term.strip()]
        parsed["terms"] = terms
        
        return parsed
    
    def calculate_relevance_score(self, item: Dict[str, Any], query_terms: List[str]) -> float:
        """Calcula score de relevância para um item"""
        if not query_terms:
            return 1.0
        
        score = 0.0
        searchable_text = f"{item.get('name', '')} {item.get('description', '')}".lower()
        
        for term in query_terms:
            term_lower = term.lower()
            if term_lower in searchable_text:
                # Boost para matches no nome
                if term_lower in item.get('name', '').lower():
                    score += 2.0
                else:
                    score += 1.0
        
        return score / len(query_terms)
