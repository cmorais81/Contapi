# Autor: carlos.morais@f1rst.com.br
"""
Dataset Domain Entity
Core business entity for data catalog and dataset management
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Set
from uuid import UUID, uuid4
from enum import Enum

from ..value_objects.dataset_status import DatasetStatus
from ..value_objects.data_lineage import DataLineage, LineageNode
from ..events.catalog_events import (
    DatasetCreated, DatasetUpdated, DatasetPublished,
    DatasetDeprecated, DatasetAccessed, LineageUpdated
)


class DatasetType(Enum):
    """Types of datasets"""
    TABLE = "table"
    VIEW = "view"
    FILE = "file"
    STREAM = "stream"
    API = "api"
    EXTERNAL = "external"
    VIRTUAL = "virtual"


class DataFormat(Enum):
    """Data formats"""
    PARQUET = "parquet"
    DELTA = "delta"
    CSV = "csv"
    JSON = "json"
    AVRO = "avro"
    ORC = "orc"
    XML = "xml"
    EXCEL = "excel"
    DATABASE = "database"


@dataclass
class Dataset:
    """
    Dataset aggregate root representing a data asset in the catalog
    """
    # Identity
    id: UUID = field(default_factory=uuid4)
    name: str = ""
    display_name: str = ""
    description: Optional[str] = None
    
    # Classification
    dataset_type: DatasetType = field(default=DatasetType.TABLE)
    data_format: DataFormat = field(default=DataFormat.PARQUET)
    domain: str = ""  # Business domain
    subdomain: Optional[str] = None
    
    # Location and access
    physical_location: str = ""  # Database, file path, URL
    connection_string: Optional[str] = None
    schema_name: Optional[str] = None
    table_name: Optional[str] = None
    
    # Schema and structure
    schema_definition: Dict[str, Any] = field(default_factory=dict)
    column_count: int = 0
    estimated_size_bytes: int = 0
    row_count_estimate: int = 0
    
    # Ownership and governance
    owner_id: UUID = field(default_factory=uuid4)
    steward_id: Optional[UUID] = None
    organization_id: UUID = field(default_factory=uuid4)
    business_owner: Optional[str] = None
    technical_owner: Optional[str] = None
    
    # Status and lifecycle
    status: DatasetStatus = field(default=DatasetStatus.DRAFT)
    is_published: bool = False
    is_deprecated: bool = False
    deprecation_date: Optional[datetime] = None
    retirement_date: Optional[datetime] = None
    
    # Quality and compliance
    quality_score: float = 0.0
    last_quality_check: Optional[datetime] = None
    compliance_status: str = "unknown"
    data_classification: str = "internal"
    contains_pii: bool = False
    pii_fields: List[str] = field(default_factory=list)
    
    # Usage and access
    access_count: int = 0
    last_accessed_at: Optional[datetime] = None
    last_accessed_by: Optional[UUID] = None
    popularity_score: float = 0.0
    
    # Lineage and relationships
    upstream_datasets: Set[UUID] = field(default_factory=set)
    downstream_datasets: Set[UUID] = field(default_factory=set)
    related_contracts: Set[UUID] = field(default_factory=set)
    
    # Metadata and discovery
    tags: List[str] = field(default_factory=list)
    business_terms: List[str] = field(default_factory=list)
    keywords: List[str] = field(default_factory=list)
    
    # Documentation
    documentation_url: Optional[str] = None
    sample_queries: List[str] = field(default_factory=list)
    usage_examples: List[str] = field(default_factory=list)
    
    # Technical metadata
    refresh_frequency: Optional[str] = None  # daily, weekly, monthly, real-time
    last_updated_at: Optional[datetime] = None
    update_frequency_actual: Optional[str] = None
    data_retention_days: Optional[int] = None
    
    # Audit fields
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    created_by: UUID = field(default_factory=uuid4)
    updated_by: UUID = field(default_factory=uuid4)
    deleted_at: Optional[datetime] = None
    
    # Domain events
    _domain_events: List[Any] = field(default_factory=list, init=False)
    
    def __post_init__(self):
        """Post-initialization validation and setup"""
        if not self.name:
            raise ValueError("Dataset name is required")
        
        if not self.display_name:
            self.display_name = self.name.replace('_', ' ').title()
        
        if not self.physical_location:
            raise ValueError("Physical location is required")
        
        # Initialize default values
        if not self.domain:
            self.domain = "general"
    
    def create(self, created_by: UUID) -> None:
        """Create a new dataset"""
        if self.status != DatasetStatus.DRAFT:
            raise ValueError("Can only create datasets in draft status")
        
        self.created_by = created_by
        self.updated_by = created_by
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(DatasetCreated(
            dataset_id=self.id,
            name=self.name,
            dataset_type=self.dataset_type.value,
            domain=self.domain,
            owner_id=self.owner_id,
            created_by=created_by,
            occurred_at=datetime.utcnow()
        ))
    
    def update(self, updated_by: UUID, **kwargs) -> None:
        """Update dataset fields"""
        old_values = {}
        for key, value in kwargs.items():
            if hasattr(self, key):
                old_values[key] = getattr(self, key)
                setattr(self, key, value)
        
        self.updated_by = updated_by
        self.updated_at = datetime.utcnow()
        
        # Update schema-related fields if schema changed
        if 'schema_definition' in kwargs:
            self._update_schema_metadata()
        
        # Raise domain event
        self._add_domain_event(DatasetUpdated(
            dataset_id=self.id,
            updated_fields=list(kwargs.keys()),
            old_values=old_values,
            new_values=kwargs,
            updated_by=updated_by,
            occurred_at=datetime.utcnow()
        ))
    
    def publish(self, published_by: UUID) -> None:
        """Publish dataset to catalog"""
        if self.status == DatasetStatus.PUBLISHED:
            return  # Already published
        
        # Validate dataset before publishing
        if not self._validate_for_publication():
            raise ValueError("Dataset validation failed, cannot publish")
        
        self.status = DatasetStatus.PUBLISHED
        self.is_published = True
        self.updated_by = published_by
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(DatasetPublished(
            dataset_id=self.id,
            published_by=published_by,
            occurred_at=datetime.utcnow()
        ))
    
    def deprecate(self, deprecated_by: UUID, reason: str, retirement_date: Optional[datetime] = None) -> None:
        """Deprecate dataset"""
        if self.is_deprecated:
            return  # Already deprecated
        
        self.is_deprecated = True
        self.deprecation_date = datetime.utcnow()
        self.retirement_date = retirement_date or (datetime.utcnow() + timedelta(days=90))
        self.updated_by = deprecated_by
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(DatasetDeprecated(
            dataset_id=self.id,
            deprecated_by=deprecated_by,
            reason=reason,
            retirement_date=self.retirement_date,
            occurred_at=datetime.utcnow()
        ))
    
    def record_access(self, accessed_by: UUID, access_type: str = "read") -> None:
        """Record dataset access"""
        self.access_count += 1
        self.last_accessed_at = datetime.utcnow()
        self.last_accessed_by = accessed_by
        
        # Update popularity score (simple algorithm)
        self._update_popularity_score()
        
        # Raise domain event
        self._add_domain_event(DatasetAccessed(
            dataset_id=self.id,
            accessed_by=accessed_by,
            access_type=access_type,
            occurred_at=datetime.utcnow()
        ))
    
    def add_upstream_dataset(self, upstream_id: UUID, updated_by: UUID) -> None:
        """Add upstream dataset dependency"""
        if upstream_id not in self.upstream_datasets:
            self.upstream_datasets.add(upstream_id)
            self.updated_by = updated_by
            self.updated_at = datetime.utcnow()
            
            # Raise lineage event
            self._add_domain_event(LineageUpdated(
                dataset_id=self.id,
                action="upstream_added",
                related_dataset_id=upstream_id,
                updated_by=updated_by,
                occurred_at=datetime.utcnow()
            ))
    
    def add_downstream_dataset(self, downstream_id: UUID, updated_by: UUID) -> None:
        """Add downstream dataset dependency"""
        if downstream_id not in self.downstream_datasets:
            self.downstream_datasets.add(downstream_id)
            self.updated_by = updated_by
            self.updated_at = datetime.utcnow()
            
            # Raise lineage event
            self._add_domain_event(LineageUpdated(
                dataset_id=self.id,
                action="downstream_added",
                related_dataset_id=downstream_id,
                updated_by=updated_by,
                occurred_at=datetime.utcnow()
            ))
    
    def link_contract(self, contract_id: UUID) -> None:
        """Link dataset to a contract"""
        self.related_contracts.add(contract_id)
        self.updated_at = datetime.utcnow()
    
    def unlink_contract(self, contract_id: UUID) -> None:
        """Unlink dataset from a contract"""
        self.related_contracts.discard(contract_id)
        self.updated_at = datetime.utcnow()
    
    def update_quality_score(self, score: float, checked_by: UUID) -> None:
        """Update dataset quality score"""
        if not 0.0 <= score <= 1.0:
            raise ValueError("Quality score must be between 0.0 and 1.0")
        
        self.quality_score = score
        self.last_quality_check = datetime.utcnow()
        self.updated_by = checked_by
        self.updated_at = datetime.utcnow()
    
    def mark_pii_detected(self, pii_fields: List[str]) -> None:
        """Mark dataset as containing PII"""
        self.contains_pii = True
        self.pii_fields = pii_fields
        self.updated_at = datetime.utcnow()
        
        # Automatically upgrade classification if PII detected
        if self.data_classification == "public":
            self.data_classification = "confidential"
    
    def add_tag(self, tag: str) -> None:
        """Add tag to dataset"""
        if tag not in self.tags:
            self.tags.append(tag)
            self.updated_at = datetime.utcnow()
    
    def remove_tag(self, tag: str) -> None:
        """Remove tag from dataset"""
        if tag in self.tags:
            self.tags.remove(tag)
            self.updated_at = datetime.utcnow()
    
    def add_business_term(self, term: str) -> None:
        """Add business term"""
        if term not in self.business_terms:
            self.business_terms.append(term)
            self.updated_at = datetime.utcnow()
    
    def is_active(self) -> bool:
        """Check if dataset is active"""
        return (
            self.status == DatasetStatus.PUBLISHED and
            not self.is_deprecated and
            (not self.retirement_date or datetime.utcnow() < self.retirement_date)
        )
    
    def is_stale(self, days_threshold: int = 30) -> bool:
        """Check if dataset is stale (not updated recently)"""
        if not self.last_updated_at:
            return True
        
        days_since_update = (datetime.utcnow() - self.last_updated_at).days
        return days_since_update > days_threshold
    
    def get_lineage_depth(self) -> Dict[str, int]:
        """Get lineage depth (upstream and downstream)"""
        return {
            'upstream_depth': len(self.upstream_datasets),
            'downstream_depth': len(self.downstream_datasets)
        }
    
    def get_usage_trend(self) -> str:
        """Get usage trend based on access patterns"""
        if not self.last_accessed_at:
            return "unused"
        
        days_since_access = (datetime.utcnow() - self.last_accessed_at).days
        
        if days_since_access <= 7:
            return "active"
        elif days_since_access <= 30:
            return "moderate"
        else:
            return "low"
    
    def calculate_business_value(self) -> float:
        """Calculate business value score"""
        # Simple algorithm based on multiple factors
        value_score = 0.0
        
        # Usage factor (40%)
        if self.access_count > 100:
            value_score += 0.4
        elif self.access_count > 10:
            value_score += 0.2
        
        # Quality factor (30%)
        value_score += self.quality_score * 0.3
        
        # Lineage factor (20%)
        lineage_score = min((len(self.upstream_datasets) + len(self.downstream_datasets)) / 10, 1.0)
        value_score += lineage_score * 0.2
        
        # Documentation factor (10%)
        if self.description and len(self.description) > 50:
            value_score += 0.05
        if self.documentation_url:
            value_score += 0.05
        
        return min(value_score, 1.0)
    
    def get_domain_events(self) -> List[Any]:
        """Get and clear domain events"""
        events = self._domain_events.copy()
        self._domain_events.clear()
        return events
    
    def _add_domain_event(self, event: Any) -> None:
        """Add a domain event"""
        self._domain_events.append(event)
    
    def _validate_for_publication(self) -> bool:
        """Validate dataset for publication"""
        # Basic validation requirements
        if not self.name or not self.description:
            return False
        
        if not self.owner_id:
            return False
        
        if not self.schema_definition:
            return False
        
        # Must have minimum documentation
        if len(self.description) < 20:
            return False
        
        return True
    
    def _update_schema_metadata(self) -> None:
        """Update schema-related metadata"""
        if self.schema_definition:
            fields = self.schema_definition.get('fields', [])
            self.column_count = len(fields)
            
            # Extract keywords from field names
            field_names = [field.get('name', '') for field in fields]
            self.keywords = list(set(self.keywords + field_names))
    
    def _update_popularity_score(self) -> None:
        """Update popularity score based on access patterns"""
        # Simple popularity algorithm
        base_score = min(self.access_count / 1000, 0.5)  # Max 0.5 from access count
        
        # Recency bonus
        if self.last_accessed_at:
            days_since_access = (datetime.utcnow() - self.last_accessed_at).days
            recency_score = max(0, (30 - days_since_access) / 30 * 0.3)  # Max 0.3 from recency
        else:
            recency_score = 0
        
        # Quality bonus
        quality_bonus = self.quality_score * 0.2  # Max 0.2 from quality
        
        self.popularity_score = min(base_score + recency_score + quality_bonus, 1.0)


@dataclass
class DatasetProfile:
    """Statistical profile of a dataset"""
    dataset_id: UUID = field(default_factory=uuid4)
    
    # Basic statistics
    row_count: int = 0
    column_count: int = 0
    size_bytes: int = 0
    
    # Data quality metrics
    completeness_rate: float = 0.0
    uniqueness_rate: float = 0.0
    validity_rate: float = 0.0
    
    # Column profiles
    column_profiles: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    
    # Sampling information
    sample_size: int = 0
    sample_percentage: float = 0.0
    profiled_at: datetime = field(default_factory=datetime.utcnow)
    profiled_by: UUID = field(default_factory=uuid4)
    
    def add_column_profile(self, column_name: str, profile_data: Dict[str, Any]) -> None:
        """Add column profile data"""
        self.column_profiles[column_name] = profile_data
    
    def get_overall_quality_score(self) -> float:
        """Calculate overall quality score"""
        return (self.completeness_rate + self.uniqueness_rate + self.validity_rate) / 3


@dataclass
class DatasetVersion:
    """Version of a dataset schema"""
    id: UUID = field(default_factory=uuid4)
    dataset_id: UUID = field(default_factory=uuid4)
    version_number: str = ""
    schema_definition: Dict[str, Any] = field(default_factory=dict)
    
    # Change information
    change_summary: Optional[str] = None
    change_type: str = "minor"  # major, minor, patch
    breaking_changes: bool = False
    
    # Audit
    created_at: datetime = field(default_factory=datetime.utcnow)
    created_by: UUID = field(default_factory=uuid4)
    
    def is_compatible_with(self, other_version: 'DatasetVersion') -> bool:
        """Check if this version is compatible with another"""
        # Simple compatibility check - in real implementation would be more sophisticated
        return not self.breaking_changes and not other_version.breaking_changes

