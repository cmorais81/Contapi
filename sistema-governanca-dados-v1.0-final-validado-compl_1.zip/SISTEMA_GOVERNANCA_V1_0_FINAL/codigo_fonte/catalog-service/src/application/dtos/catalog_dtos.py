# Autor: carlos.morais@f1rst.com.br
"""
Catalog Service DTOs
Data Transfer Objects for catalog management operations
"""

from datetime import datetime
from typing import List, Optional, Dict, Any, Union
from uuid import UUID
from enum import Enum

from pydantic import BaseModel, Field, validator


# Enums
class DatasetStatus(str, Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"


class DatasetType(str, Enum):
    TABLE = "table"
    VIEW = "view"
    FILE = "file"
    STREAM = "stream"
    API = "api"
    EXTERNAL = "external"


class DataFormat(str, Enum):
    PARQUET = "parquet"
    DELTA = "delta"
    CSV = "csv"
    JSON = "json"
    AVRO = "avro"
    ORC = "orc"
    XML = "xml"
    EXCEL = "excel"


class AccessLevel(str, Enum):
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTL = "confidential"
    RESTRICTED = "restricted"


class DataClassification(str, Enum):
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTL = "confidential"
    RESTRICTED = "restricted"
    PII = "pii"
    SENSITIVE = "sensitive"


class LineageDirection(str, Enum):
    UPSTREAM = "upstream"
    DOWNSTREAM = "downstream"
    BOTH = "both"


# Base DTOs
class SchemaFieldDTO(BaseModel):
    """Schema field information"""
    name: str = Field(..., description="Field name")
    data_type: str = Field(..., description="Data type")
    is_nullable: bool = Field(default=True, description="Whether field can be null")
    is_primary_key: bool = Field(default=False, description="Whether field is primary key")
    description: Optional[str] = Field(None, description="Field description")
    constraints: Optional[List[str]] = Field(default_factory=list, description="Field constraints")
    tags: Optional[List[str]] = Field(default_factory=list, description="Field tags")
    classification: Optional[DataClassification] = Field(None, description="Data classification")
    is_pii: bool = Field(default=False, description="Whether field contains PII")


class DatasetSchemaDTO(BaseModel):
    """Dataset schema information"""
    version: str = Field(..., description="Schema version")
    fields: List[SchemaFieldDTO] = Field(..., description="Schema fields")
    primary_keys: Optional[List[str]] = Field(default_factory=list, description="Primary key fields")
    foreign_keys: Optional[List[Dict[str, Any]]] = Field(default_factory=list, description="Foreign key relationships")
    indexes: Optional[List[Dict[str, Any]]] = Field(default_factory=list, description="Index definitions")
    partitions: Optional[List[str]] = Field(default_factory=list, description="Partition fields")


class DatasetLocationDTO(BaseModel):
    """Dataset location information"""
    storage_type: str = Field(..., description="Storage type (s3, hdfs, database, etc.)")
    connection_string: str = Field(..., description="Connection string or path")
    database_name: Optional[str] = Field(None, description="Database name")
    schema_name: Optional[str] = Field(None, description="Schema name")
    table_name: Optional[str] = Field(None, description="Table name")
    file_path: Optional[str] = Field(None, description="File path")
    format: Optional[DataFormat] = Field(None, description="Data format")


class DatasetMetricsDTO(BaseModel):
    """Dataset metrics information"""
    row_count: Optional[int] = Field(None, description="Number of rows")
    column_count: Optional[int] = Field(None, description="Number of columns")
    size_bytes: Optional[int] = Field(None, description="Size in bytes")
    last_updated: Optional[datetime] = Field(None, description="Last update timestamp")
    update_frequency: Optional[str] = Field(None, description="Update frequency")
    quality_score: Optional[float] = Field(None, ge=0, le=100, description="Quality score (0-100)")
    completeness_score: Optional[float] = Field(None, ge=0, le=100, description="Completeness score")
    accuracy_score: Optional[float] = Field(None, ge=0, le=100, description="Accuracy score")


class DatasetUsageDTO(BaseModel):
    """Dataset usage statistics"""
    view_count: int = Field(default=0, description="Number of views")
    download_count: int = Field(default=0, description="Number of downloads")
    query_count: int = Field(default=0, description="Number of queries")
    unique_users: int = Field(default=0, description="Number of unique users")
    last_accessed: Optional[datetime] = Field(None, description="Last access timestamp")
    popularity_score: float = Field(default=0.0, ge=0, le=100, description="Popularity score")


# Request DTOs
class CreateDatasetRequest(BaseModel):
    """Request to create a new dataset"""
    name: str = Field(..., min_length=1, max_length=255, description="Dataset name")
    title: str = Field(..., min_length=1, max_length=500, description="Dataset title")
    description: Optional[str] = Field(None, max_length=2000, description="Dataset description")
    dataset_type: DatasetType = Field(..., description="Dataset type")
    organization_id: UUID = Field(..., description="Organization ID")
    owner_id: UUID = Field(..., description="Owner user ID")
    location: DatasetLocationDTO = Field(..., description="Dataset location")
    schema: Optional[DatasetSchemaDTO] = Field(None, description="Dataset schema")
    access_level: AccessLevel = Field(default=AccessLevel.INTERNAL, description="Access level")
    classification: DataClassification = Field(default=DataClassification.INTERNAL, description="Data classification")
    tags: Optional[List[str]] = Field(default_factory=list, description="Dataset tags")
    business_terms: Optional[List[str]] = Field(default_factory=list, description="Business terms")
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional metadata")
    
    @validator('name')
    def validate_name(cls, v):
        if not v.replace('_', '').replace('-', '').isalnum():
            raise ValueError('Name must contain only alphanumeric characters, hyphens, and underscores')
        return v


class UpdateDatasetRequest(BaseModel):
    """Request to update a dataset"""
    title: Optional[str] = Field(None, min_length=1, max_length=500, description="Dataset title")
    description: Optional[str] = Field(None, max_length=2000, description="Dataset description")
    owner_id: Optional[UUID] = Field(None, description="Owner user ID")
    location: Optional[DatasetLocationDTO] = Field(None, description="Dataset location")
    schema: Optional[DatasetSchemaDTO] = Field(None, description="Dataset schema")
    access_level: Optional[AccessLevel] = Field(None, description="Access level")
    classification: Optional[DataClassification] = Field(None, description="Data classification")
    status: Optional[DatasetStatus] = Field(None, description="Dataset status")
    tags: Optional[List[str]] = Field(None, description="Dataset tags")
    business_terms: Optional[List[str]] = Field(None, description="Business terms")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")


class DatasetSearchRequest(BaseModel):
    """Request to search datasets"""
    search_term: str = Field(..., min_length=1, description="Search term")
    organization_id: Optional[UUID] = Field(None, description="Organization filter")
    dataset_type: Optional[DatasetType] = Field(None, description="Dataset type filter")
    access_level: Optional[AccessLevel] = Field(None, description="Access level filter")
    classification: Optional[DataClassification] = Field(None, description="Classification filter")
    tags: Optional[List[str]] = Field(None, description="Tag filters")
    business_terms: Optional[List[str]] = Field(None, description="Business term filters")
    limit: int = Field(default=50, ge=1, le=1000, description="Maximum results")
    offset: int = Field(default=0, ge=0, description="Results offset")


class DatasetFilterRequest(BaseModel):
    """Request to filter datasets"""
    organization_id: Optional[UUID] = Field(None, description="Organization filter")
    owner_id: Optional[UUID] = Field(None, description="Owner filter")
    dataset_type: Optional[DatasetType] = Field(None, description="Dataset type filter")
    status: Optional[DatasetStatus] = Field(None, description="Status filter")
    access_level: Optional[AccessLevel] = Field(None, description="Access level filter")
    classification: Optional[DataClassification] = Field(None, description="Classification filter")
    tags: Optional[List[str]] = Field(None, description="Tag filters")
    business_terms: Optional[List[str]] = Field(None, description="Business term filters")
    created_after: Optional[datetime] = Field(None, description="Created after date")
    created_before: Optional[datetime] = Field(None, description="Created before date")
    updated_after: Optional[datetime] = Field(None, description="Updated after date")
    updated_before: Optional[datetime] = Field(None, description="Updated before date")
    limit: int = Field(default=100, ge=1, le=1000, description="Maximum results")
    offset: int = Field(default=0, ge=0, description="Results offset")


class DataLineageRequest(BaseModel):
    """Request to get data lineage"""
    dataset_id: UUID = Field(..., description="Dataset ID")
    direction: LineageDirection = Field(default=LineageDirection.BOTH, description="Lineage direction")
    depth: int = Field(default=3, ge=1, le=10, description="Lineage depth")
    include_transformations: bool = Field(default=True, description="Include transformation details")


class DatasetProfileRequest(BaseModel):
    """Request to profile a dataset"""
    dataset_id: UUID = Field(..., description="Dataset ID")
    sample_size: Optional[int] = Field(None, ge=1000, le=1000000, description="Sample size for profiling")
    include_statistics: bool = Field(default=True, description="Include statistical analysis")
    include_patterns: bool = Field(default=True, description="Include pattern analysis")
    include_quality: bool = Field(default=True, description="Include quality assessment")


# Response DTOs
class DatasetResponse(BaseModel):
    """Dataset response"""
    id: UUID = Field(..., description="Dataset ID")
    name: str = Field(..., description="Dataset name")
    title: str = Field(..., description="Dataset title")
    description: Optional[str] = Field(None, description="Dataset description")
    dataset_type: DatasetType = Field(..., description="Dataset type")
    status: DatasetStatus = Field(..., description="Dataset status")
    organization_id: UUID = Field(..., description="Organization ID")
    organization_name: str = Field(..., description="Organization name")
    owner_id: UUID = Field(..., description="Owner user ID")
    owner_name: str = Field(..., description="Owner name")
    location: DatasetLocationDTO = Field(..., description="Dataset location")
    schema: Optional[DatasetSchemaDTO] = Field(None, description="Dataset schema")
    access_level: AccessLevel = Field(..., description="Access level")
    classification: DataClassification = Field(..., description="Data classification")
    tags: List[str] = Field(default_factory=list, description="Dataset tags")
    business_terms: List[str] = Field(default_factory=list, description="Business terms")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    metrics: Optional[DatasetMetricsDTO] = Field(None, description="Dataset metrics")
    usage: Optional[DatasetUsageDTO] = Field(None, description="Usage statistics")
    created_by: UUID = Field(..., description="Created by user ID")
    created_by_name: str = Field(..., description="Created by user name")
    created_at: datetime = Field(..., description="Creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")


class DatasetListResponse(BaseModel):
    """Dataset list response"""
    datasets: List[DatasetResponse] = Field(..., description="List of datasets")
    total: int = Field(..., description="Total number of datasets")
    limit: int = Field(..., description="Results limit")
    offset: int = Field(..., description="Results offset")
    has_more: bool = Field(..., description="Whether there are more results")


class DatasetSummaryResponse(BaseModel):
    """Dataset summary response"""
    id: UUID = Field(..., description="Dataset ID")
    name: str = Field(..., description="Dataset name")
    title: str = Field(..., description="Dataset title")
    dataset_type: DatasetType = Field(..., description="Dataset type")
    status: DatasetStatus = Field(..., description="Dataset status")
    organization_name: str = Field(..., description="Organization name")
    owner_name: str = Field(..., description="Owner name")
    access_level: AccessLevel = Field(..., description="Access level")
    classification: DataClassification = Field(..., description="Data classification")
    tags: List[str] = Field(default_factory=list, description="Dataset tags")
    quality_score: Optional[float] = Field(None, description="Quality score")
    popularity_score: float = Field(default=0.0, description="Popularity score")
    last_updated: Optional[datetime] = Field(None, description="Last update timestamp")


class DataLineageNodeResponse(BaseModel):
    """Data lineage node response"""
    dataset_id: UUID = Field(..., description="Dataset ID")
    dataset_name: str = Field(..., description="Dataset name")
    dataset_type: DatasetType = Field(..., description="Dataset type")
    organization_name: str = Field(..., description="Organization name")
    level: int = Field(..., description="Lineage level")
    relationship_type: str = Field(..., description="Relationship type")
    transformation_logic: Optional[str] = Field(None, description="Transformation logic")


class DataLineageResponse(BaseModel):
    """Data lineage response"""
    dataset_id: UUID = Field(..., description="Root dataset ID")
    dataset_name: str = Field(..., description="Root dataset name")
    upstream_nodes: List[DataLineageNodeResponse] = Field(default_factory=list, description="Upstream datasets")
    downstream_nodes: List[DataLineageNodeResponse] = Field(default_factory=list, description="Downstream datasets")
    total_upstream: int = Field(default=0, description="Total upstream datasets")
    total_downstream: int = Field(default=0, description="Total downstream datasets")


class DatasetProfileResponse(BaseModel):
    """Dataset profile response"""
    dataset_id: UUID = Field(..., description="Dataset ID")
    dataset_name: str = Field(..., description="Dataset name")
    profiling_date: datetime = Field(..., description="Profiling timestamp")
    total_records: int = Field(..., description="Total number of records")
    total_columns: int = Field(..., description="Total number of columns")
    size_bytes: int = Field(..., description="Dataset size in bytes")
    field_profiles: List[Dict[str, Any]] = Field(default_factory=list, description="Field-level profiles")
    data_quality_issues: List[Dict[str, Any]] = Field(default_factory=list, description="Quality issues found")
    suggested_improvements: List[str] = Field(default_factory=list, description="Suggested improvements")
    overall_quality_score: float = Field(..., ge=0, le=100, description="Overall quality score")


class CatalogStatisticsResponse(BaseModel):
    """Catalog statistics response"""
    organization_id: UUID = Field(..., description="Organization ID")
    total_datasets: int = Field(..., description="Total number of datasets")
    active_datasets: int = Field(..., description="Number of active datasets")
    datasets_by_type: Dict[str, int] = Field(default_factory=dict, description="Datasets by type")
    datasets_by_classification: Dict[str, int] = Field(default_factory=dict, description="Datasets by classification")
    total_data_size: int = Field(..., description="Total data size in bytes")
    average_quality_score: float = Field(..., description="Average quality score")
    most_popular_datasets: List[DatasetSummaryResponse] = Field(default_factory=list, description="Most popular datasets")
    recently_updated_datasets: List[DatasetSummaryResponse] = Field(default_factory=list, description="Recently updated datasets")


class DataDiscoveryResponse(BaseModel):
    """Data discovery response"""
    search_term: str = Field(..., description="Search term used")
    total_results: int = Field(..., description="Total number of results")
    datasets: List[DatasetSummaryResponse] = Field(default_factory=list, description="Matching datasets")
    suggested_terms: List[str] = Field(default_factory=list, description="Suggested search terms")
    facets: Dict[str, Dict[str, int]] = Field(default_factory=dict, description="Search facets")


# Bulk Operations
class BulkDatasetOperationRequest(BaseModel):
    """Bulk dataset operation request"""
    dataset_ids: List[UUID] = Field(..., min_items=1, max_items=100, description="Dataset IDs")
    operation: str = Field(..., description="Operation to perform")
    parameters: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Operation parameters")


class BulkDatasetOperationResponse(BaseModel):
    """Bulk dataset operation response"""
    operation: str = Field(..., description="Operation performed")
    total_requested: int = Field(..., description="Total datasets requested")
    successful: int = Field(..., description="Successful operations")
    failed: int = Field(..., description="Failed operations")
    results: List[Dict[str, Any]] = Field(default_factory=list, description="Operation results")
    errors: List[Dict[str, Any]] = Field(default_factory=list, description="Operation errors")


# Notification DTOs
class DatasetNotificationRequest(BaseModel):
    """Dataset notification request"""
    dataset_id: UUID = Field(..., description="Dataset ID")
    notification_type: str = Field(..., description="Notification type")
    message: str = Field(..., description="Notification message")
    recipients: List[UUID] = Field(..., description="Recipient user IDs")
    metadata: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional metadata")


class DatasetNotificationResponse(BaseModel):
    """Dataset notification response"""
    id: UUID = Field(..., description="Notification ID")
    dataset_id: UUID = Field(..., description="Dataset ID")
    notification_type: str = Field(..., description="Notification type")
    message: str = Field(..., description="Notification message")
    sent_to: int = Field(..., description="Number of recipients")
    sent_at: datetime = Field(..., description="Sent timestamp")
    status: str = Field(..., description="Notification status")

