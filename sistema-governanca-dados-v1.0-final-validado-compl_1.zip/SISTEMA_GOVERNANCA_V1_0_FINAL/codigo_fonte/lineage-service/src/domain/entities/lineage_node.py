"""
Entidade LineageNode - Nó de Linhagem de Dados
Sistema de Governança de Dados V5.0
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4
from enum import Enum

class NodeType(Enum):
    """Tipos de nós na linhagem"""
    SOURCE = "source"
    TRANSFORMATION = "transformation"
    TARGET = "target"
    INTERMEDIATE = "intermediate"

class LineageRelationType(Enum):
    """Tipos de relacionamento na linhagem"""
    DIRECT = "direct"
    DERIVED = "derived"
    AGGREGATED = "aggregated"
    FILTERED = "filtered"
    JOINED = "joined"
    UNION = "union"

@dataclass
class LineageNode:
    """
    Representa um nó na linhagem de dados
    
    Um nó pode ser uma fonte de dados, transformação ou destino,
    contendo metadados sobre sua posição no fluxo de dados.
    """
    
    id: UUID = field(default_factory=uuid4)
    name: str = ""
    node_type: NodeType = NodeType.SOURCE
    entity_id: Optional[UUID] = None
    source_system: str = ""
    description: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Informações de posicionamento
    level: int = 0  # Nível na hierarquia (0 = fonte, maior = mais derivado)
    position_x: float = 0.0  # Coordenada X para visualização
    position_y: float = 0.0  # Coordenada Y para visualização
    
    # Relacionamentos
    parent_nodes: List[UUID] = field(default_factory=list)
    child_nodes: List[UUID] = field(default_factory=list)
    
    # Auditoria
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    created_by: Optional[UUID] = None
    
    def __post_init__(self):
        """Validações após inicialização"""
        if not self.name:
            raise ValueError("Nome do nó é obrigatório")
        
        if self.level < 0:
            raise ValueError("Nível deve ser não-negativo")
    
    def add_parent(self, parent_id: UUID) -> None:
        """Adiciona um nó pai"""
        if parent_id not in self.parent_nodes:
            self.parent_nodes.append(parent_id)
            self.updated_at = datetime.utcnow()
    
    def add_child(self, child_id: UUID) -> None:
        """Adiciona um nó filho"""
        if child_id not in self.child_nodes:
            self.child_nodes.append(child_id)
            self.updated_at = datetime.utcnow()
    
    def remove_parent(self, parent_id: UUID) -> None:
        """Remove um nó pai"""
        if parent_id in self.parent_nodes:
            self.parent_nodes.remove(parent_id)
            self.updated_at = datetime.utcnow()
    
    def remove_child(self, child_id: UUID) -> None:
        """Remove um nó filho"""
        if child_id in self.child_nodes:
            self.child_nodes.remove(child_id)
            self.updated_at = datetime.utcnow()
    
    def is_source(self) -> bool:
        """Verifica se é um nó fonte (sem pais)"""
        return len(self.parent_nodes) == 0
    
    def is_sink(self) -> bool:
        """Verifica se é um nó destino (sem filhos)"""
        return len(self.child_nodes) == 0
    
    def is_intermediate(self) -> bool:
        """Verifica se é um nó intermediário"""
        return len(self.parent_nodes) > 0 and len(self.child_nodes) > 0
    
    def get_depth(self) -> int:
        """Retorna a profundidade do nó (número de pais)"""
        return len(self.parent_nodes)
    
    def get_breadth(self) -> int:
        """Retorna a largura do nó (número de filhos)"""
        return len(self.child_nodes)
    
    def update_metadata(self, new_metadata: Dict[str, Any]) -> None:
        """Atualiza metadados do nó"""
        self.metadata.update(new_metadata)
        self.updated_at = datetime.utcnow()
    
    def set_position(self, x: float, y: float) -> None:
        """Define posição para visualização"""
        self.position_x = x
        self.position_y = y
        self.updated_at = datetime.utcnow()
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            "id": str(self.id),
            "name": self.name,
            "node_type": self.node_type.value,
            "entity_id": str(self.entity_id) if self.entity_id else None,
            "source_system": self.source_system,
            "description": self.description,
            "metadata": self.metadata,
            "level": self.level,
            "position_x": self.position_x,
            "position_y": self.position_y,
            "parent_nodes": [str(pid) for pid in self.parent_nodes],
            "child_nodes": [str(cid) for cid in self.child_nodes],
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "created_by": str(self.created_by) if self.created_by else None,
            "is_source": self.is_source(),
            "is_sink": self.is_sink(),
            "is_intermediate": self.is_intermediate(),
            "depth": self.get_depth(),
            "breadth": self.get_breadth()
        }

@dataclass
class LineageRelationship:
    """
    Representa um relacionamento entre nós na linhagem
    """
    
    id: UUID = field(default_factory=uuid4)
    source_node_id: UUID = field(default_factory=uuid4)
    target_node_id: UUID = field(default_factory=uuid4)
    relationship_type: LineageRelationType = LineageRelationType.DIRECT
    transformation_id: Optional[UUID] = None
    
    # Força do relacionamento (0.0 a 1.0)
    strength: float = 1.0
    
    # Metadados específicos do relacionamento
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # Informações de transformação
    transformation_logic: str = ""
    column_mappings: Dict[str, str] = field(default_factory=dict)
    
    # Auditoria
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    created_by: Optional[UUID] = None
    
    def __post_init__(self):
        """Validações após inicialização"""
        if self.source_node_id == self.target_node_id:
            raise ValueError("Nó fonte e destino não podem ser iguais")
        
        if not 0.0 <= self.strength <= 1.0:
            raise ValueError("Força do relacionamento deve estar entre 0.0 e 1.0")
    
    def update_strength(self, new_strength: float) -> None:
        """Atualiza a força do relacionamento"""
        if not 0.0 <= new_strength <= 1.0:
            raise ValueError("Força deve estar entre 0.0 e 1.0")
        
        self.strength = new_strength
        self.updated_at = datetime.utcnow()
    
    def add_column_mapping(self, source_column: str, target_column: str) -> None:
        """Adiciona mapeamento de coluna"""
        self.column_mappings[source_column] = target_column
        self.updated_at = datetime.utcnow()
    
    def update_transformation_logic(self, logic: str) -> None:
        """Atualiza lógica de transformação"""
        self.transformation_logic = logic
        self.updated_at = datetime.utcnow()
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            "id": str(self.id),
            "source_node_id": str(self.source_node_id),
            "target_node_id": str(self.target_node_id),
            "relationship_type": self.relationship_type.value,
            "transformation_id": str(self.transformation_id) if self.transformation_id else None,
            "strength": self.strength,
            "metadata": self.metadata,
            "transformation_logic": self.transformation_logic,
            "column_mappings": self.column_mappings,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "created_by": str(self.created_by) if self.created_by else None
        }

