"""
Entidade Lineage para rastreamento de linhagem de dados
Autor: carlos.morais@f1rst.com.br
"""

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional, Dict, Any
from enum import Enum

class LineageType(Enum):
    """Tipos de linhagem de dados"""
    DATASET = "dataset"
    TRANSFORMATION = "transformation"
    COLUMN = "column"
    PROCESS = "process"

class LineageDirection(Enum):
    """Direção da linhagem"""
    UPSTREAM = "upstream"
    DOWNSTREAM = "downstream"
    BIDIRECTIONAL = "bidirectional"

@dataclass
class LineageNode:
    """Nó na linhagem de dados"""
    id: str
    name: str
    type: LineageType
    source_system: str
    metadata: Dict[str, Any]
    created_at: datetime
    updated_at: datetime

@dataclass
class LineageEdge:
    """Aresta na linhagem de dados"""
    id: str
    source_node_id: str
    target_node_id: str
    transformation_logic: Optional[str]
    confidence_score: float
    created_at: datetime

@dataclass
class Lineage:
    """Entidade principal de linhagem"""
    id: str
    asset_id: str
    nodes: List[LineageNode]
    edges: List[LineageEdge]
    direction: LineageDirection
    depth: int
    created_at: datetime
    updated_at: datetime
    
    def get_upstream_nodes(self) -> List[LineageNode]:
        """Retorna nós upstream"""
        upstream_ids = [edge.source_node_id for edge in self.edges]
        return [node for node in self.nodes if node.id in upstream_ids]
    
    def get_downstream_nodes(self) -> List[LineageNode]:
        """Retorna nós downstream"""
        downstream_ids = [edge.target_node_id for edge in self.edges]
        return [node for node in self.nodes if node.id in downstream_ids]
    
    def calculate_impact_score(self) -> float:
        """Calcula score de impacto baseado na linhagem"""
        if not self.edges:
            return 0.0
        
        total_confidence = sum(edge.confidence_score for edge in self.edges)
        return total_confidence / len(self.edges)
