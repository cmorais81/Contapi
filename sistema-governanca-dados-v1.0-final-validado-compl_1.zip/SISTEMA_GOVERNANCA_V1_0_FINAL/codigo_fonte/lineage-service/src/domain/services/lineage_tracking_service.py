"""
Serviço de rastreamento de linhagem de dados
Autor: carlos.morais@f1rst.com.br
"""

from typing import Dict, Any, List, Optional, Set
from datetime import datetime
import logging
import json
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)

class LineageType(Enum):
    """Tipos de linhagem de dados"""
    TABLE_TO_TABLE = "table_to_table"
    COLUMN_TO_COLUMN = "column_to_column"
    PROCESS_TO_TABLE = "process_to_table"
    API_TO_TABLE = "api_to_table"
    FILE_TO_TABLE = "file_to_table"

@dataclass
class LineageNode:
    """Nó na árvore de linhagem"""
    id: str
    name: str
    type: str
    schema: Optional[str] = None
    database: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

@dataclass
class LineageEdge:
    """Aresta na árvore de linhagem"""
    source_id: str
    target_id: str
    lineage_type: LineageType
    transformation: Optional[str] = None
    created_at: datetime = None
    metadata: Optional[Dict[str, Any]] = None

class LineageTrackingService:
    """Serviço para rastreamento de linhagem de dados"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.lineage_graph = {}
        self.nodes = {}
        self.edges = []
        
    def track_table_lineage(self, source_table: str, target_table: str, 
                          transformation: str = None) -> str:
        """
        Rastreia linhagem entre tabelas
        
        Args:
            source_table: Tabela de origem
            target_table: Tabela de destino
            transformation: Lógica de transformação aplicada
            
        Returns:
            ID da relação de linhagem criada
        """
        source_node = self._create_or_get_node(source_table, "table")
        target_node = self._create_or_get_node(target_table, "table")
        
        edge = LineageEdge(
            source_id=source_node.id,
            target_id=target_node.id,
            lineage_type=LineageType.TABLE_TO_TABLE,
            transformation=transformation,
            created_at=datetime.utcnow()
        )
        
        self.edges.append(edge)
        self._update_lineage_graph(edge)
        
        logger.info(f"Linhagem rastreada: {source_table} -> {target_table}")
        return f"{source_node.id}_{target_node.id}"
        
    def track_column_lineage(self, source_column: str, target_column: str,
                           source_table: str, target_table: str,
                           transformation: str = None) -> str:
        """
        Rastreia linhagem entre colunas específicas
        
        Args:
            source_column: Coluna de origem
            target_column: Coluna de destino
            source_table: Tabela da coluna de origem
            target_table: Tabela da coluna de destino
            transformation: Transformação aplicada na coluna
            
        Returns:
            ID da relação de linhagem criada
        """
        source_id = f"{source_table}.{source_column}"
        target_id = f"{target_table}.{target_column}"
        
        source_node = self._create_or_get_node(source_id, "column", metadata={
            "table": source_table,
            "column": source_column
        })
        target_node = self._create_or_get_node(target_id, "column", metadata={
            "table": target_table,
            "column": target_column
        })
        
        edge = LineageEdge(
            source_id=source_node.id,
            target_id=target_node.id,
            lineage_type=LineageType.COLUMN_TO_COLUMN,
            transformation=transformation,
            created_at=datetime.utcnow()
        )
        
        self.edges.append(edge)
        self._update_lineage_graph(edge)
        
        logger.info(f"Linhagem de coluna rastreada: {source_id} -> {target_id}")
        return f"{source_node.id}_{target_node.id}"
        
    def track_process_lineage(self, process_name: str, input_tables: List[str],
                            output_tables: List[str], process_metadata: Dict[str, Any] = None) -> str:
        """
        Rastreia linhagem de um processo (ETL, pipeline, etc.)
        
        Args:
            process_name: Nome do processo
            input_tables: Lista de tabelas de entrada
            output_tables: Lista de tabelas de saída
            process_metadata: Metadados do processo
            
        Returns:
            ID do processo na linhagem
        """
        process_node = self._create_or_get_node(process_name, "process", metadata=process_metadata)
        
        # Conectar inputs ao processo
        for input_table in input_tables:
            input_node = self._create_or_get_node(input_table, "table")
            edge = LineageEdge(
                source_id=input_node.id,
                target_id=process_node.id,
                lineage_type=LineageType.TABLE_TO_TABLE,
                created_at=datetime.utcnow()
            )
            self.edges.append(edge)
            self._update_lineage_graph(edge)
            
        # Conectar processo aos outputs
        for output_table in output_tables:
            output_node = self._create_or_get_node(output_table, "table")
            edge = LineageEdge(
                source_id=process_node.id,
                target_id=output_node.id,
                lineage_type=LineageType.PROCESS_TO_TABLE,
                created_at=datetime.utcnow()
            )
            self.edges.append(edge)
            self._update_lineage_graph(edge)
            
        logger.info(f"Linhagem de processo rastreada: {process_name}")
        return process_node.id
        
    def get_upstream_lineage(self, table_name: str, max_depth: int = 5) -> Dict[str, Any]:
        """
        Obtém a linhagem upstream (origem) de uma tabela
        
        Args:
            table_name: Nome da tabela
            max_depth: Profundidade máxima da busca
            
        Returns:
            Dict com a árvore de linhagem upstream
        """
        node = self._get_node_by_name(table_name)
        if not node:
            return {"error": f"Tabela {table_name} não encontrada"}
            
        upstream_tree = self._build_upstream_tree(node.id, max_depth)
        
        return {
            "table": table_name,
            "upstream_lineage": upstream_tree,
            "generated_at": datetime.utcnow().isoformat()
        }
        
    def get_downstream_lineage(self, table_name: str, max_depth: int = 5) -> Dict[str, Any]:
        """
        Obtém a linhagem downstream (destino) de uma tabela
        
        Args:
            table_name: Nome da tabela
            max_depth: Profundidade máxima da busca
            
        Returns:
            Dict com a árvore de linhagem downstream
        """
        node = self._get_node_by_name(table_name)
        if not node:
            return {"error": f"Tabela {table_name} não encontrada"}
            
        downstream_tree = self._build_downstream_tree(node.id, max_depth)
        
        return {
            "table": table_name,
            "downstream_lineage": downstream_tree,
            "generated_at": datetime.utcnow().isoformat()
        }
        
    def get_impact_analysis(self, table_name: str) -> Dict[str, Any]:
        """
        Realiza análise de impacto para uma tabela
        
        Args:
            table_name: Nome da tabela
            
        Returns:
            Dict com análise de impacto
        """
        downstream = self.get_downstream_lineage(table_name)
        
        if "error" in downstream:
            return downstream
            
        impact_analysis = {
            "source_table": table_name,
            "impact_scope": self._calculate_impact_scope(downstream["downstream_lineage"]),
            "affected_tables": self._extract_affected_tables(downstream["downstream_lineage"]),
            "affected_processes": self._extract_affected_processes(downstream["downstream_lineage"]),
            "risk_level": self._assess_risk_level(downstream["downstream_lineage"]),
            "recommendations": self._generate_recommendations(downstream["downstream_lineage"]),
            "analysis_timestamp": datetime.utcnow().isoformat()
        }
        
        return impact_analysis
        
    def get_lineage_summary(self) -> Dict[str, Any]:
        """
        Obtém resumo da linhagem do sistema
        
        Returns:
            Dict com estatísticas da linhagem
        """
        table_nodes = [n for n in self.nodes.values() if n.type == "table"]
        process_nodes = [n for n in self.nodes.values() if n.type == "process"]
        column_nodes = [n for n in self.nodes.values() if n.type == "column"]
        
        return {
            "total_nodes": len(self.nodes),
            "total_edges": len(self.edges),
            "table_count": len(table_nodes),
            "process_count": len(process_nodes),
            "column_count": len(column_nodes),
            "lineage_types": self._count_lineage_types(),
            "most_connected_tables": self._get_most_connected_tables(),
            "orphaned_tables": self._get_orphaned_tables(),
            "summary_generated_at": datetime.utcnow().isoformat()
        }
        
    def _create_or_get_node(self, name: str, node_type: str, 
                          metadata: Dict[str, Any] = None) -> LineageNode:
        """Cria ou obtém um nó existente"""
        node_id = f"{node_type}_{name}".replace(".", "_").replace(" ", "_")
        
        if node_id not in self.nodes:
            node = LineageNode(
                id=node_id,
                name=name,
                type=node_type,
                metadata=metadata or {}
            )
            self.nodes[node_id] = node
            
        return self.nodes[node_id]
        
    def _get_node_by_name(self, name: str) -> Optional[LineageNode]:
        """Obtém nó pelo nome"""
        for node in self.nodes.values():
            if node.name == name:
                return node
        return None
        
    def _update_lineage_graph(self, edge: LineageEdge):
        """Atualiza o grafo de linhagem"""
        if edge.source_id not in self.lineage_graph:
            self.lineage_graph[edge.source_id] = {"upstream": [], "downstream": []}
        if edge.target_id not in self.lineage_graph:
            self.lineage_graph[edge.target_id] = {"upstream": [], "downstream": []}
            
        self.lineage_graph[edge.source_id]["downstream"].append(edge.target_id)
        self.lineage_graph[edge.target_id]["upstream"].append(edge.source_id)
        
    def _build_upstream_tree(self, node_id: str, max_depth: int, 
                           current_depth: int = 0, visited: Set[str] = None) -> List[Dict[str, Any]]:
        """Constrói árvore upstream recursivamente"""
        if visited is None:
            visited = set()
            
        if current_depth >= max_depth or node_id in visited:
            return []
            
        visited.add(node_id)
        upstream_nodes = []
        
        if node_id in self.lineage_graph:
            for upstream_id in self.lineage_graph[node_id]["upstream"]:
                upstream_node = self.nodes.get(upstream_id)
                if upstream_node:
                    upstream_tree = self._build_upstream_tree(
                        upstream_id, max_depth, current_depth + 1, visited.copy()
                    )
                    
                    upstream_nodes.append({
                        "id": upstream_node.id,
                        "name": upstream_node.name,
                        "type": upstream_node.type,
                        "depth": current_depth + 1,
                        "upstream": upstream_tree
                    })
                    
        return upstream_nodes
        
    def _build_downstream_tree(self, node_id: str, max_depth: int,
                             current_depth: int = 0, visited: Set[str] = None) -> List[Dict[str, Any]]:
        """Constrói árvore downstream recursivamente"""
        if visited is None:
            visited = set()
            
        if current_depth >= max_depth or node_id in visited:
            return []
            
        visited.add(node_id)
        downstream_nodes = []
        
        if node_id in self.lineage_graph:
            for downstream_id in self.lineage_graph[node_id]["downstream"]:
                downstream_node = self.nodes.get(downstream_id)
                if downstream_node:
                    downstream_tree = self._build_downstream_tree(
                        downstream_id, max_depth, current_depth + 1, visited.copy()
                    )
                    
                    downstream_nodes.append({
                        "id": downstream_node.id,
                        "name": downstream_node.name,
                        "type": downstream_node.type,
                        "depth": current_depth + 1,
                        "downstream": downstream_tree
                    })
                    
        return downstream_nodes
        
    def _calculate_impact_scope(self, downstream_tree: List[Dict[str, Any]]) -> str:
        """Calcula o escopo do impacto"""
        total_affected = self._count_total_nodes(downstream_tree)
        
        if total_affected == 0:
            return "none"
        elif total_affected <= 5:
            return "low"
        elif total_affected <= 15:
            return "medium"
        else:
            return "high"
            
    def _count_total_nodes(self, tree: List[Dict[str, Any]]) -> int:
        """Conta total de nós na árvore"""
        count = len(tree)
        for node in tree:
            count += self._count_total_nodes(node.get("downstream", []))
        return count
        
    def _extract_affected_tables(self, downstream_tree: List[Dict[str, Any]]) -> List[str]:
        """Extrai tabelas afetadas"""
        tables = []
        for node in downstream_tree:
            if node["type"] == "table":
                tables.append(node["name"])
            tables.extend(self._extract_affected_tables(node.get("downstream", [])))
        return list(set(tables))
        
    def _extract_affected_processes(self, downstream_tree: List[Dict[str, Any]]) -> List[str]:
        """Extrai processos afetados"""
        processes = []
        for node in downstream_tree:
            if node["type"] == "process":
                processes.append(node["name"])
            processes.extend(self._extract_affected_processes(node.get("downstream", [])))
        return list(set(processes))
        
    def _assess_risk_level(self, downstream_tree: List[Dict[str, Any]]) -> str:
        """Avalia nível de risco"""
        scope = self._calculate_impact_scope(downstream_tree)
        processes = self._extract_affected_processes(downstream_tree)
        
        if scope == "high" or len(processes) > 5:
            return "high"
        elif scope == "medium" or len(processes) > 2:
            return "medium"
        else:
            return "low"
            
    def _generate_recommendations(self, downstream_tree: List[Dict[str, Any]]) -> List[str]:
        """Gera recomendações baseadas no impacto"""
        recommendations = []
        
        affected_tables = self._extract_affected_tables(downstream_tree)
        affected_processes = self._extract_affected_processes(downstream_tree)
        
        if len(affected_tables) > 10:
            recommendations.append("Considere implementar mudanças em fases")
            recommendations.append("Execute testes abrangentes antes da implementação")
            
        if len(affected_processes) > 5:
            recommendations.append("Coordene com equipes responsáveis pelos processos afetados")
            recommendations.append("Implemente monitoramento adicional durante a mudança")
            
        if not recommendations:
            recommendations.append("Impacto limitado - proceda com cautela padrão")
            
        return recommendations
        
    def _count_lineage_types(self) -> Dict[str, int]:
        """Conta tipos de linhagem"""
        counts = {}
        for edge in self.edges:
            lineage_type = edge.lineage_type.value
            counts[lineage_type] = counts.get(lineage_type, 0) + 1
        return counts
        
    def _get_most_connected_tables(self, limit: int = 5) -> List[Dict[str, Any]]:
        """Obtém tabelas mais conectadas"""
        table_connections = {}
        
        for node_id, connections in self.lineage_graph.items():
            node = self.nodes.get(node_id)
            if node and node.type == "table":
                total_connections = len(connections["upstream"]) + len(connections["downstream"])
                table_connections[node.name] = total_connections
                
        sorted_tables = sorted(table_connections.items(), key=lambda x: x[1], reverse=True)
        
        return [
            {"table": table, "connections": count}
            for table, count in sorted_tables[:limit]
        ]
        
    def _get_orphaned_tables(self) -> List[str]:
        """Obtém tabelas órfãs (sem conexões)"""
        orphaned = []
        
        for node in self.nodes.values():
            if node.type == "table":
                connections = self.lineage_graph.get(node.id, {"upstream": [], "downstream": []})
                if not connections["upstream"] and not connections["downstream"]:
                    orphaned.append(node.name)
                    
        return orphaned
