"""
Serviço de Grafo de Linhagem - Lógica de Negócio
Sistema de Governança de Dados V5.0
"""

import logging
from typing import Dict, List, Optional, Set, Tuple, Any
from uuid import UUID
from collections import defaultdict, deque
from dataclasses import dataclass

from ..entities.lineage_node import LineageNode, LineageRelationship, NodeType, LineageRelationType

logger = logging.getLogger(__name__)

@dataclass
class LineagePath:
    """Representa um caminho na linhagem"""
    nodes: List[UUID]
    relationships: List[UUID]
    total_strength: float
    path_length: int
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": [str(n) for n in self.nodes],
            "relationships": [str(r) for r in self.relationships],
            "total_strength": self.total_strength,
            "path_length": self.path_length
        }

@dataclass
class ImpactAnalysis:
    """Resultado de análise de impacto"""
    source_node_id: UUID
    impacted_nodes: List[UUID]
    impact_paths: List[LineagePath]
    impact_score: float
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_node_id": str(self.source_node_id),
            "impacted_nodes": [str(n) for n in self.impacted_nodes],
            "impact_paths": [path.to_dict() for path in self.impact_paths],
            "impact_score": self.impact_score
        }

class LineageGraphService:
    """
    Serviço para operações de grafo de linhagem de dados
    
    Responsável por:
    - Construção e manutenção do grafo de linhagem
    - Análise de impacto
    - Descoberta de caminhos
    - Detecção de ciclos
    - Cálculo de métricas
    """
    
    def __init__(self):
        self.nodes: Dict[UUID, LineageNode] = {}
        self.relationships: Dict[UUID, LineageRelationship] = {}
        self.adjacency_list: Dict[UUID, List[UUID]] = defaultdict(list)
        self.reverse_adjacency_list: Dict[UUID, List[UUID]] = defaultdict(list)
    
    def add_node(self, node: LineageNode) -> None:
        """Adiciona um nó ao grafo"""
        try:
            self.nodes[node.id] = node
            
            # Inicializar listas de adjacência se necessário
            if node.id not in self.adjacency_list:
                self.adjacency_list[node.id] = []
            if node.id not in self.reverse_adjacency_list:
                self.reverse_adjacency_list[node.id] = []
            
            logger.info(f"Nó adicionado ao grafo: {node.name} ({node.id})")
            
        except Exception as e:
            logger.error(f"Erro ao adicionar nó: {e}")
            raise
    
    def add_relationship(self, relationship: LineageRelationship) -> None:
        """Adiciona um relacionamento ao grafo"""
        try:
            # Verificar se os nós existem
            if relationship.source_node_id not in self.nodes:
                raise ValueError(f"Nó fonte não encontrado: {relationship.source_node_id}")
            
            if relationship.target_node_id not in self.nodes:
                raise ValueError(f"Nó destino não encontrado: {relationship.target_node_id}")
            
            # Verificar ciclos antes de adicionar
            if self._would_create_cycle(relationship.source_node_id, relationship.target_node_id):
                raise ValueError("Relacionamento criaria um ciclo no grafo")
            
            self.relationships[relationship.id] = relationship
            
            # Atualizar listas de adjacência
            self.adjacency_list[relationship.source_node_id].append(relationship.target_node_id)
            self.reverse_adjacency_list[relationship.target_node_id].append(relationship.source_node_id)
            
            # Atualizar nós
            source_node = self.nodes[relationship.source_node_id]
            target_node = self.nodes[relationship.target_node_id]
            
            source_node.add_child(relationship.target_node_id)
            target_node.add_parent(relationship.source_node_id)
            
            logger.info(f"Relacionamento adicionado: {relationship.source_node_id} -> {relationship.target_node_id}")
            
        except Exception as e:
            logger.error(f"Erro ao adicionar relacionamento: {e}")
            raise
    
    def remove_node(self, node_id: UUID) -> None:
        """Remove um nó e todos os seus relacionamentos"""
        try:
            if node_id not in self.nodes:
                raise ValueError(f"Nó não encontrado: {node_id}")
            
            # Remover todos os relacionamentos conectados
            relationships_to_remove = []
            for rel_id, rel in self.relationships.items():
                if rel.source_node_id == node_id or rel.target_node_id == node_id:
                    relationships_to_remove.append(rel_id)
            
            for rel_id in relationships_to_remove:
                self.remove_relationship(rel_id)
            
            # Remover o nó
            del self.nodes[node_id]
            del self.adjacency_list[node_id]
            del self.reverse_adjacency_list[node_id]
            
            logger.info(f"Nó removido: {node_id}")
            
        except Exception as e:
            logger.error(f"Erro ao remover nó: {e}")
            raise
    
    def remove_relationship(self, relationship_id: UUID) -> None:
        """Remove um relacionamento do grafo"""
        try:
            if relationship_id not in self.relationships:
                raise ValueError(f"Relacionamento não encontrado: {relationship_id}")
            
            relationship = self.relationships[relationship_id]
            
            # Atualizar listas de adjacência
            self.adjacency_list[relationship.source_node_id].remove(relationship.target_node_id)
            self.reverse_adjacency_list[relationship.target_node_id].remove(relationship.source_node_id)
            
            # Atualizar nós
            source_node = self.nodes[relationship.source_node_id]
            target_node = self.nodes[relationship.target_node_id]
            
            source_node.remove_child(relationship.target_node_id)
            target_node.remove_parent(relationship.source_node_id)
            
            # Remover relacionamento
            del self.relationships[relationship_id]
            
            logger.info(f"Relacionamento removido: {relationship_id}")
            
        except Exception as e:
            logger.error(f"Erro ao remover relacionamento: {e}")
            raise
    
    def find_paths(self, source_id: UUID, target_id: UUID, max_depth: int = 10) -> List[LineagePath]:
        """Encontra todos os caminhos entre dois nós"""
        try:
            if source_id not in self.nodes or target_id not in self.nodes:
                return []
            
            paths = []
            visited = set()
            current_path = []
            current_relationships = []
            
            def dfs(current_id: UUID, depth: int):
                if depth > max_depth:
                    return
                
                if current_id == target_id and len(current_path) > 1:
                    # Calcular força total do caminho
                    total_strength = 1.0
                    for rel_id in current_relationships:
                        if rel_id in self.relationships:
                            total_strength *= self.relationships[rel_id].strength
                    
                    path = LineagePath(
                        nodes=current_path.copy(),
                        relationships=current_relationships.copy(),
                        total_strength=total_strength,
                        path_length=len(current_path) - 1
                    )
                    paths.append(path)
                    return
                
                if current_id in visited:
                    return
                
                visited.add(current_id)
                current_path.append(current_id)
                
                # Explorar vizinhos
                for neighbor_id in self.adjacency_list.get(current_id, []):
                    # Encontrar relacionamento
                    rel_id = self._find_relationship(current_id, neighbor_id)
                    if rel_id:
                        current_relationships.append(rel_id)
                        dfs(neighbor_id, depth + 1)
                        current_relationships.pop()
                
                current_path.pop()
                visited.remove(current_id)
            
            dfs(source_id, 0)
            
            # Ordenar por força total (descendente)
            paths.sort(key=lambda p: p.total_strength, reverse=True)
            
            return paths
            
        except Exception as e:
            logger.error(f"Erro ao encontrar caminhos: {e}")
            return []
    
    def analyze_impact(self, source_id: UUID, max_depth: int = 5) -> ImpactAnalysis:
        """Analisa o impacto de mudanças em um nó"""
        try:
            if source_id not in self.nodes:
                raise ValueError(f"Nó não encontrado: {source_id}")
            
            impacted_nodes = set()
            impact_paths = []
            
            # BFS para encontrar todos os nós impactados
            queue = deque([(source_id, 0, [source_id], [])])
            visited = set()
            
            while queue:
                current_id, depth, path, relationships = queue.popleft()
                
                if depth > max_depth:
                    continue
                
                if current_id in visited:
                    continue
                
                visited.add(current_id)
                
                if current_id != source_id:
                    impacted_nodes.add(current_id)
                    
                    # Calcular força do caminho
                    total_strength = 1.0
                    for rel_id in relationships:
                        if rel_id in self.relationships:
                            total_strength *= self.relationships[rel_id].strength
                    
                    impact_path = LineagePath(
                        nodes=path.copy(),
                        relationships=relationships.copy(),
                        total_strength=total_strength,
                        path_length=len(path) - 1
                    )
                    impact_paths.append(impact_path)
                
                # Adicionar vizinhos à fila
                for neighbor_id in self.adjacency_list.get(current_id, []):
                    if neighbor_id not in visited:
                        rel_id = self._find_relationship(current_id, neighbor_id)
                        if rel_id:
                            new_path = path + [neighbor_id]
                            new_relationships = relationships + [rel_id]
                            queue.append((neighbor_id, depth + 1, new_path, new_relationships))
            
            # Calcular score de impacto
            impact_score = len(impacted_nodes) / max(len(self.nodes) - 1, 1)
            
            return ImpactAnalysis(
                source_node_id=source_id,
                impacted_nodes=list(impacted_nodes),
                impact_paths=impact_paths,
                impact_score=impact_score
            )
            
        except Exception as e:
            logger.error(f"Erro na análise de impacto: {e}")
            raise
    
    def get_upstream_nodes(self, node_id: UUID, max_depth: int = 10) -> List[UUID]:
        """Obtém todos os nós upstream (fontes)"""
        try:
            if node_id not in self.nodes:
                return []
            
            upstream = set()
            queue = deque([(node_id, 0)])
            visited = set()
            
            while queue:
                current_id, depth = queue.popleft()
                
                if depth > max_depth or current_id in visited:
                    continue
                
                visited.add(current_id)
                
                if current_id != node_id:
                    upstream.add(current_id)
                
                # Adicionar pais
                for parent_id in self.reverse_adjacency_list.get(current_id, []):
                    if parent_id not in visited:
                        queue.append((parent_id, depth + 1))
            
            return list(upstream)
            
        except Exception as e:
            logger.error(f"Erro ao obter nós upstream: {e}")
            return []
    
    def get_downstream_nodes(self, node_id: UUID, max_depth: int = 10) -> List[UUID]:
        """Obtém todos os nós downstream (destinos)"""
        try:
            if node_id not in self.nodes:
                return []
            
            downstream = set()
            queue = deque([(node_id, 0)])
            visited = set()
            
            while queue:
                current_id, depth = queue.popleft()
                
                if depth > max_depth or current_id in visited:
                    continue
                
                visited.add(current_id)
                
                if current_id != node_id:
                    downstream.add(current_id)
                
                # Adicionar filhos
                for child_id in self.adjacency_list.get(current_id, []):
                    if child_id not in visited:
                        queue.append((child_id, depth + 1))
            
            return list(downstream)
            
        except Exception as e:
            logger.error(f"Erro ao obter nós downstream: {e}")
            return []
    
    def detect_cycles(self) -> List[List[UUID]]:
        """Detecta ciclos no grafo"""
        try:
            cycles = []
            visited = set()
            rec_stack = set()
            
            def dfs(node_id: UUID, path: List[UUID]) -> bool:
                if node_id in rec_stack:
                    # Encontrou ciclo
                    cycle_start = path.index(node_id)
                    cycle = path[cycle_start:] + [node_id]
                    cycles.append(cycle)
                    return True
                
                if node_id in visited:
                    return False
                
                visited.add(node_id)
                rec_stack.add(node_id)
                path.append(node_id)
                
                for neighbor_id in self.adjacency_list.get(node_id, []):
                    if dfs(neighbor_id, path):
                        return True
                
                path.pop()
                rec_stack.remove(node_id)
                return False
            
            for node_id in self.nodes:
                if node_id not in visited:
                    dfs(node_id, [])
            
            return cycles
            
        except Exception as e:
            logger.error(f"Erro na detecção de ciclos: {e}")
            return []
    
    def get_graph_metrics(self) -> Dict[str, Any]:
        """Calcula métricas do grafo"""
        try:
            total_nodes = len(self.nodes)
            total_relationships = len(self.relationships)
            
            # Contar tipos de nós
            node_types = defaultdict(int)
            for node in self.nodes.values():
                node_types[node.node_type.value] += 1
            
            # Contar nós fonte e destino
            source_nodes = sum(1 for node in self.nodes.values() if node.is_source())
            sink_nodes = sum(1 for node in self.nodes.values() if node.is_sink())
            intermediate_nodes = sum(1 for node in self.nodes.values() if node.is_intermediate())
            
            # Calcular densidade do grafo
            max_edges = total_nodes * (total_nodes - 1)
            density = total_relationships / max_edges if max_edges > 0 else 0
            
            # Detectar ciclos
            cycles = self.detect_cycles()
            
            return {
                "total_nodes": total_nodes,
                "total_relationships": total_relationships,
                "node_types": dict(node_types),
                "source_nodes": source_nodes,
                "sink_nodes": sink_nodes,
                "intermediate_nodes": intermediate_nodes,
                "graph_density": density,
                "has_cycles": len(cycles) > 0,
                "cycle_count": len(cycles),
                "average_node_degree": total_relationships * 2 / total_nodes if total_nodes > 0 else 0
            }
            
        except Exception as e:
            logger.error(f"Erro ao calcular métricas: {e}")
            return {}
    
    def _would_create_cycle(self, source_id: UUID, target_id: UUID) -> bool:
        """Verifica se adicionar um relacionamento criaria um ciclo"""
        try:
            # Se target pode alcançar source, então adicionar source->target criaria ciclo
            paths = self.find_paths(target_id, source_id, max_depth=20)
            return len(paths) > 0
            
        except Exception as e:
            logger.error(f"Erro na verificação de ciclo: {e}")
            return False
    
    def _find_relationship(self, source_id: UUID, target_id: UUID) -> Optional[UUID]:
        """Encontra o ID do relacionamento entre dois nós"""
        for rel_id, rel in self.relationships.items():
            if rel.source_node_id == source_id and rel.target_node_id == target_id:
                return rel_id
        return None
    
    def clear(self) -> None:
        """Limpa todo o grafo"""
        self.nodes.clear()
        self.relationships.clear()
        self.adjacency_list.clear()
        self.reverse_adjacency_list.clear()
        logger.info("Grafo de linhagem limpo")

