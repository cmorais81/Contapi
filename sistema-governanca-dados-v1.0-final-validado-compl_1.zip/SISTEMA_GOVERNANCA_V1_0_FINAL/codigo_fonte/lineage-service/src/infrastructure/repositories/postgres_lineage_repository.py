"""
Repository PostgreSQL para Linhagem de Dados
Sistema de Governança de Dados V5.0
"""

import logging
from typing import Dict, List, Optional, Any
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import text, and_, or_
from datetime import datetime

from ...domain.entities.lineage_node import LineageNode, LineageRelationship, NodeType, LineageRelationType
from ....shared.database import get_db_session

logger = logging.getLogger(__name__)

class PostgresLineageRepository:
    """
    Repository para operações de linhagem no PostgreSQL
    
    Responsável por:
    - Persistência de nós e relacionamentos
    - Consultas de linhagem
    - Operações de grafo no banco
    """
    
    def __init__(self):
        self.session_factory = get_db_session
    
    # =====================================================
    # OPERAÇÕES DE NÓS
    # =====================================================
    
    def save_node(self, node: LineageNode) -> LineageNode:
        """Salva um nó de linhagem"""
        try:
            with self.session_factory() as session:
                # Verificar se já existe
                existing = self._get_node_by_id(session, node.id)
                
                if existing:
                    # Atualizar
                    update_sql = text("""
                        UPDATE data_entities 
                        SET name = :name,
                            description = :description,
                            entity_type = :entity_type,
                            source_system = :source_system,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE id = :id
                    """)
                    
                    session.execute(update_sql, {
                        'id': node.id,
                        'name': node.name,
                        'description': node.description,
                        'entity_type': node.node_type.value,
                        'source_system': node.source_system
                    })
                else:
                    # Inserir novo
                    insert_sql = text("""
                        INSERT INTO data_entities 
                        (id, name, description, entity_type, source_system, schema_definition, created_at, updated_at)
                        VALUES (:id, :name, :description, :entity_type, :source_system, :metadata, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    """)
                    
                    session.execute(insert_sql, {
                        'id': node.id,
                        'name': node.name,
                        'description': node.description,
                        'entity_type': node.node_type.value,
                        'source_system': node.source_system,
                        'metadata': node.metadata
                    })
                
                session.commit()
                logger.info(f"Nó salvo: {node.name} ({node.id})")
                return node
                
        except Exception as e:
            logger.error(f"Erro ao salvar nó: {e}")
            raise
    
    def get_node_by_id(self, node_id: UUID) -> Optional[LineageNode]:
        """Busca um nó por ID"""
        try:
            with self.session_factory() as session:
                return self._get_node_by_id(session, node_id)
                
        except Exception as e:
            logger.error(f"Erro ao buscar nó: {e}")
            return None
    
    def _get_node_by_id(self, session: Session, node_id: UUID) -> Optional[LineageNode]:
        """Busca um nó por ID (método interno)"""
        sql = text("""
            SELECT id, name, description, entity_type, source_system, 
                   schema_definition, created_at, updated_at
            FROM data_entities 
            WHERE id = :id
        """)
        
        result = session.execute(sql, {'id': node_id}).fetchone()
        
        if result:
            return LineageNode(
                id=result.id,
                name=result.name,
                description=result.description or "",
                node_type=NodeType(result.entity_type),
                source_system=result.source_system or "",
                metadata=result.schema_definition or {},
                created_at=result.created_at,
                updated_at=result.updated_at
            )
        
        return None
    
    def get_nodes_by_type(self, node_type: NodeType) -> List[LineageNode]:
        """Busca nós por tipo"""
        try:
            with self.session_factory() as session:
                sql = text("""
                    SELECT id, name, description, entity_type, source_system, 
                           schema_definition, created_at, updated_at
                    FROM data_entities 
                    WHERE entity_type = :node_type
                    ORDER BY name
                """)
                
                results = session.execute(sql, {'node_type': node_type.value}).fetchall()
                
                nodes = []
                for result in results:
                    node = LineageNode(
                        id=result.id,
                        name=result.name,
                        description=result.description or "",
                        node_type=NodeType(result.entity_type),
                        source_system=result.source_system or "",
                        metadata=result.schema_definition or {},
                        created_at=result.created_at,
                        updated_at=result.updated_at
                    )
                    nodes.append(node)
                
                return nodes
                
        except Exception as e:
            logger.error(f"Erro ao buscar nós por tipo: {e}")
            return []
    
    def delete_node(self, node_id: UUID) -> bool:
        """Remove um nó"""
        try:
            with self.session_factory() as session:
                # Primeiro remover relacionamentos
                delete_relationships_sql = text("""
                    DELETE FROM data_lineage 
                    WHERE source_entity_id = :node_id OR target_entity_id = :node_id
                """)
                session.execute(delete_relationships_sql, {'node_id': node_id})
                
                # Remover nó
                delete_node_sql = text("""
                    DELETE FROM data_entities WHERE id = :node_id
                """)
                result = session.execute(delete_node_sql, {'node_id': node_id})
                
                session.commit()
                
                success = result.rowcount > 0
                if success:
                    logger.info(f"Nó removido: {node_id}")
                
                return success
                
        except Exception as e:
            logger.error(f"Erro ao remover nó: {e}")
            return False
    
    # =====================================================
    # OPERAÇÕES DE RELACIONAMENTOS
    # =====================================================
    
    def save_relationship(self, relationship: LineageRelationship) -> LineageRelationship:
        """Salva um relacionamento de linhagem"""
        try:
            with self.session_factory() as session:
                # Verificar se já existe
                existing = self._get_relationship_by_id(session, relationship.id)
                
                if existing:
                    # Atualizar
                    update_sql = text("""
                        UPDATE data_lineage 
                        SET lineage_type = :lineage_type,
                            relationship_strength = :strength,
                            metadata = :metadata,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE id = :id
                    """)
                    
                    session.execute(update_sql, {
                        'id': relationship.id,
                        'lineage_type': relationship.relationship_type.value,
                        'strength': relationship.strength,
                        'metadata': {
                            'transformation_logic': relationship.transformation_logic,
                            'column_mappings': relationship.column_mappings,
                            **relationship.metadata
                        }
                    })
                else:
                    # Inserir novo
                    insert_sql = text("""
                        INSERT INTO data_lineage 
                        (id, source_entity_id, target_entity_id, transformation_id, 
                         lineage_type, relationship_strength, metadata, created_at, updated_at)
                        VALUES (:id, :source_id, :target_id, :transformation_id, 
                                :lineage_type, :strength, :metadata, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    """)
                    
                    session.execute(insert_sql, {
                        'id': relationship.id,
                        'source_id': relationship.source_node_id,
                        'target_id': relationship.target_node_id,
                        'transformation_id': relationship.transformation_id,
                        'lineage_type': relationship.relationship_type.value,
                        'strength': relationship.strength,
                        'metadata': {
                            'transformation_logic': relationship.transformation_logic,
                            'column_mappings': relationship.column_mappings,
                            **relationship.metadata
                        }
                    })
                
                session.commit()
                logger.info(f"Relacionamento salvo: {relationship.source_node_id} -> {relationship.target_node_id}")
                return relationship
                
        except Exception as e:
            logger.error(f"Erro ao salvar relacionamento: {e}")
            raise
    
    def get_relationship_by_id(self, relationship_id: UUID) -> Optional[LineageRelationship]:
        """Busca um relacionamento por ID"""
        try:
            with self.session_factory() as session:
                return self._get_relationship_by_id(session, relationship_id)
                
        except Exception as e:
            logger.error(f"Erro ao buscar relacionamento: {e}")
            return None
    
    def _get_relationship_by_id(self, session: Session, relationship_id: UUID) -> Optional[LineageRelationship]:
        """Busca um relacionamento por ID (método interno)"""
        sql = text("""
            SELECT id, source_entity_id, target_entity_id, transformation_id,
                   lineage_type, relationship_strength, metadata, created_at, updated_at
            FROM data_lineage 
            WHERE id = :id
        """)
        
        result = session.execute(sql, {'id': relationship_id}).fetchone()
        
        if result:
            metadata = result.metadata or {}
            
            return LineageRelationship(
                id=result.id,
                source_node_id=result.source_entity_id,
                target_node_id=result.target_entity_id,
                transformation_id=result.transformation_id,
                relationship_type=LineageRelationType(result.lineage_type),
                strength=result.relationship_strength,
                transformation_logic=metadata.get('transformation_logic', ''),
                column_mappings=metadata.get('column_mappings', {}),
                metadata={k: v for k, v in metadata.items() 
                         if k not in ['transformation_logic', 'column_mappings']},
                created_at=result.created_at,
                updated_at=result.updated_at
            )
        
        return None
    
    def get_relationships_by_source(self, source_id: UUID) -> List[LineageRelationship]:
        """Busca relacionamentos por nó fonte"""
        try:
            with self.session_factory() as session:
                sql = text("""
                    SELECT id, source_entity_id, target_entity_id, transformation_id,
                           lineage_type, relationship_strength, metadata, created_at, updated_at
                    FROM data_lineage 
                    WHERE source_entity_id = :source_id
                    ORDER BY created_at
                """)
                
                results = session.execute(sql, {'source_id': source_id}).fetchall()
                
                relationships = []
                for result in results:
                    metadata = result.metadata or {}
                    
                    relationship = LineageRelationship(
                        id=result.id,
                        source_node_id=result.source_entity_id,
                        target_node_id=result.target_entity_id,
                        transformation_id=result.transformation_id,
                        relationship_type=LineageRelationType(result.lineage_type),
                        strength=result.relationship_strength,
                        transformation_logic=metadata.get('transformation_logic', ''),
                        column_mappings=metadata.get('column_mappings', {}),
                        metadata={k: v for k, v in metadata.items() 
                                 if k not in ['transformation_logic', 'column_mappings']},
                        created_at=result.created_at,
                        updated_at=result.updated_at
                    )
                    relationships.append(relationship)
                
                return relationships
                
        except Exception as e:
            logger.error(f"Erro ao buscar relacionamentos por fonte: {e}")
            return []
    
    def get_relationships_by_target(self, target_id: UUID) -> List[LineageRelationship]:
        """Busca relacionamentos por nó destino"""
        try:
            with self.session_factory() as session:
                sql = text("""
                    SELECT id, source_entity_id, target_entity_id, transformation_id,
                           lineage_type, relationship_strength, metadata, created_at, updated_at
                    FROM data_lineage 
                    WHERE target_entity_id = :target_id
                    ORDER BY created_at
                """)
                
                results = session.execute(sql, {'target_id': target_id}).fetchall()
                
                relationships = []
                for result in results:
                    metadata = result.metadata or {}
                    
                    relationship = LineageRelationship(
                        id=result.id,
                        source_node_id=result.source_entity_id,
                        target_node_id=result.target_entity_id,
                        transformation_id=result.transformation_id,
                        relationship_type=LineageRelationType(result.lineage_type),
                        strength=result.relationship_strength,
                        transformation_logic=metadata.get('transformation_logic', ''),
                        column_mappings=metadata.get('column_mappings', {}),
                        metadata={k: v for k, v in metadata.items() 
                                 if k not in ['transformation_logic', 'column_mappings']},
                        created_at=result.created_at,
                        updated_at=result.updated_at
                    )
                    relationships.append(relationship)
                
                return relationships
                
        except Exception as e:
            logger.error(f"Erro ao buscar relacionamentos por destino: {e}")
            return []
    
    def delete_relationship(self, relationship_id: UUID) -> bool:
        """Remove um relacionamento"""
        try:
            with self.session_factory() as session:
                sql = text("DELETE FROM data_lineage WHERE id = :id")
                result = session.execute(sql, {'id': relationship_id})
                
                session.commit()
                
                success = result.rowcount > 0
                if success:
                    logger.info(f"Relacionamento removido: {relationship_id}")
                
                return success
                
        except Exception as e:
            logger.error(f"Erro ao remover relacionamento: {e}")
            return False
    
    # =====================================================
    # CONSULTAS DE LINHAGEM
    # =====================================================
    
    def get_upstream_nodes(self, node_id: UUID, max_depth: int = 10) -> List[UUID]:
        """Busca nós upstream (recursivo via SQL)"""
        try:
            with self.session_factory() as session:
                sql = text("""
                    WITH RECURSIVE upstream AS (
                        -- Caso base: nó inicial
                        SELECT target_entity_id as node_id, 0 as depth
                        FROM data_lineage 
                        WHERE target_entity_id = :node_id
                        
                        UNION ALL
                        
                        -- Caso recursivo: buscar pais
                        SELECT dl.source_entity_id as node_id, u.depth + 1
                        FROM data_lineage dl
                        INNER JOIN upstream u ON dl.target_entity_id = u.node_id
                        WHERE u.depth < :max_depth
                    )
                    SELECT DISTINCT node_id 
                    FROM upstream 
                    WHERE node_id != :node_id
                    ORDER BY node_id
                """)
                
                results = session.execute(sql, {
                    'node_id': node_id,
                    'max_depth': max_depth
                }).fetchall()
                
                return [result.node_id for result in results]
                
        except Exception as e:
            logger.error(f"Erro ao buscar nós upstream: {e}")
            return []
    
    def get_downstream_nodes(self, node_id: UUID, max_depth: int = 10) -> List[UUID]:
        """Busca nós downstream (recursivo via SQL)"""
        try:
            with self.session_factory() as session:
                sql = text("""
                    WITH RECURSIVE downstream AS (
                        -- Caso base: nó inicial
                        SELECT source_entity_id as node_id, 0 as depth
                        FROM data_lineage 
                        WHERE source_entity_id = :node_id
                        
                        UNION ALL
                        
                        -- Caso recursivo: buscar filhos
                        SELECT dl.target_entity_id as node_id, d.depth + 1
                        FROM data_lineage dl
                        INNER JOIN downstream d ON dl.source_entity_id = d.node_id
                        WHERE d.depth < :max_depth
                    )
                    SELECT DISTINCT node_id 
                    FROM downstream 
                    WHERE node_id != :node_id
                    ORDER BY node_id
                """)
                
                results = session.execute(sql, {
                    'node_id': node_id,
                    'max_depth': max_depth
                }).fetchall()
                
                return [result.node_id for result in results]
                
        except Exception as e:
            logger.error(f"Erro ao buscar nós downstream: {e}")
            return []
    
    def get_lineage_graph(self, center_node_id: UUID, depth: int = 3) -> Dict[str, Any]:
        """Busca grafo de linhagem centrado em um nó"""
        try:
            with self.session_factory() as session:
                # Buscar nós upstream e downstream
                upstream_sql = text("""
                    WITH RECURSIVE upstream AS (
                        SELECT :center_id as node_id, 0 as depth, 'center' as direction
                        
                        UNION ALL
                        
                        SELECT dl.source_entity_id as node_id, u.depth + 1, 'upstream' as direction
                        FROM data_lineage dl
                        INNER JOIN upstream u ON dl.target_entity_id = u.node_id
                        WHERE u.depth < :depth
                    )
                    SELECT DISTINCT node_id, direction, depth FROM upstream
                """)
                
                downstream_sql = text("""
                    WITH RECURSIVE downstream AS (
                        SELECT :center_id as node_id, 0 as depth, 'center' as direction
                        
                        UNION ALL
                        
                        SELECT dl.target_entity_id as node_id, d.depth + 1, 'downstream' as direction
                        FROM data_lineage dl
                        INNER JOIN downstream d ON dl.source_entity_id = d.node_id
                        WHERE d.depth < :depth
                    )
                    SELECT DISTINCT node_id, direction, depth FROM downstream
                """)
                
                # Executar consultas
                upstream_results = session.execute(upstream_sql, {
                    'center_id': center_node_id,
                    'depth': depth
                }).fetchall()
                
                downstream_results = session.execute(downstream_sql, {
                    'center_id': center_node_id,
                    'depth': depth
                }).fetchall()
                
                # Combinar resultados
                all_node_ids = set()
                node_info = {}
                
                for result in upstream_results + downstream_results:
                    all_node_ids.add(result.node_id)
                    if result.node_id not in node_info:
                        node_info[result.node_id] = {
                            'direction': result.direction,
                            'depth': result.depth
                        }
                
                # Buscar detalhes dos nós
                if all_node_ids:
                    nodes_sql = text("""
                        SELECT id, name, description, entity_type, source_system
                        FROM data_entities 
                        WHERE id = ANY(:node_ids)
                    """)
                    
                    node_results = session.execute(nodes_sql, {
                        'node_ids': list(all_node_ids)
                    }).fetchall()
                    
                    nodes = {}
                    for node in node_results:
                        nodes[str(node.id)] = {
                            'id': str(node.id),
                            'name': node.name,
                            'description': node.description,
                            'type': node.entity_type,
                            'source_system': node.source_system,
                            **node_info.get(node.id, {})
                        }
                    
                    # Buscar relacionamentos
                    relationships_sql = text("""
                        SELECT id, source_entity_id, target_entity_id, lineage_type, relationship_strength
                        FROM data_lineage 
                        WHERE source_entity_id = ANY(:node_ids) 
                           OR target_entity_id = ANY(:node_ids)
                    """)
                    
                    rel_results = session.execute(relationships_sql, {
                        'node_ids': list(all_node_ids)
                    }).fetchall()
                    
                    relationships = []
                    for rel in rel_results:
                        relationships.append({
                            'id': str(rel.id),
                            'source': str(rel.source_entity_id),
                            'target': str(rel.target_entity_id),
                            'type': rel.lineage_type,
                            'strength': rel.relationship_strength
                        })
                    
                    return {
                        'center_node': str(center_node_id),
                        'nodes': nodes,
                        'relationships': relationships,
                        'depth': depth,
                        'total_nodes': len(nodes),
                        'total_relationships': len(relationships)
                    }
                
                return {
                    'center_node': str(center_node_id),
                    'nodes': {},
                    'relationships': [],
                    'depth': depth,
                    'total_nodes': 0,
                    'total_relationships': 0
                }
                
        except Exception as e:
            logger.error(f"Erro ao buscar grafo de linhagem: {e}")
            return {}
    
    def get_lineage_statistics(self) -> Dict[str, Any]:
        """Busca estatísticas de linhagem"""
        try:
            with self.session_factory() as session:
                stats_sql = text("""
                    SELECT 
                        (SELECT COUNT(*) FROM data_entities) as total_nodes,
                        (SELECT COUNT(*) FROM data_lineage) as total_relationships,
                        (SELECT COUNT(*) FROM data_entities WHERE entity_type = 'source') as source_nodes,
                        (SELECT COUNT(*) FROM data_entities WHERE entity_type = 'target') as target_nodes,
                        (SELECT COUNT(DISTINCT lineage_type) FROM data_lineage) as relationship_types,
                        (SELECT AVG(relationship_strength) FROM data_lineage) as avg_relationship_strength
                """)
                
                result = session.execute(stats_sql).fetchone()
                
                return {
                    'total_nodes': result.total_nodes or 0,
                    'total_relationships': result.total_relationships or 0,
                    'source_nodes': result.source_nodes or 0,
                    'target_nodes': result.target_nodes or 0,
                    'relationship_types': result.relationship_types or 0,
                    'avg_relationship_strength': float(result.avg_relationship_strength or 0)
                }
                
        except Exception as e:
            logger.error(f"Erro ao buscar estatísticas: {e}")
            return {}

