"""
Controller para Lineage Service
Sistema de Governança de Dados V5.0
"""

import logging
from typing import Dict, Any, Optional
from uuid import UUID
from fastapi import APIRouter, HTTPException, Query, Path
from pydantic import BaseModel, Field

from ...application.use_cases.lineage_discovery_use_case import (
    LineageDiscoveryUseCase,
    LineageDiscoveryRequest,
    ImpactAnalysisRequest,
    PathDiscoveryRequest
)

logger = logging.getLogger(__name__)

# =====================================================
# MODELOS DE REQUEST/RESPONSE
# =====================================================

class LineageDiscoveryRequestModel(BaseModel):
    """Modelo de request para descoberta de linhagem"""
    entity_id: str = Field(..., description="ID da entidade para descobrir linhagem")
    depth: int = Field(3, ge=1, le=10, description="Profundidade da busca")
    include_upstream: bool = Field(True, description="Incluir nós upstream")
    include_downstream: bool = Field(True, description="Incluir nós downstream")
    min_strength: float = Field(0.0, ge=0.0, le=1.0, description="Força mínima dos relacionamentos")

class ImpactAnalysisRequestModel(BaseModel):
    """Modelo de request para análise de impacto"""
    source_entity_id: str = Field(..., description="ID da entidade fonte")
    max_depth: int = Field(5, ge=1, le=10, description="Profundidade máxima da análise")
    impact_threshold: float = Field(0.1, ge=0.0, le=1.0, description="Threshold mínimo de impacto")

class PathDiscoveryRequestModel(BaseModel):
    """Modelo de request para descoberta de caminhos"""
    source_entity_id: str = Field(..., description="ID da entidade fonte")
    target_entity_id: str = Field(..., description="ID da entidade destino")
    max_paths: int = Field(10, ge=1, le=50, description="Número máximo de caminhos")
    max_depth: int = Field(10, ge=1, le=20, description="Profundidade máxima da busca")

class LineageResponseModel(BaseModel):
    """Modelo de response padrão"""
    success: bool = Field(..., description="Indica se a operação foi bem-sucedida")
    data: Dict[str, Any] = Field(..., description="Dados da resposta")
    message: str = Field("", description="Mensagem adicional")
    execution_time_ms: Optional[float] = Field(None, description="Tempo de execução em milissegundos")

# =====================================================
# CONTROLLER
# =====================================================

class LineageController:
    """
    Controller para operações de linhagem de dados
    
    Endpoints:
    - GET /lineage/{entity_id} - Descobrir linhagem de uma entidade
    - POST /lineage/discover - Descobrir linhagem com parâmetros avançados
    - POST /lineage/impact - Análise de impacto
    - POST /lineage/paths - Descoberta de caminhos
    - GET /lineage/statistics - Estatísticas de linhagem
    """
    
    def __init__(self):
        self.use_case = LineageDiscoveryUseCase()
        self.router = APIRouter(prefix="/api/v1/lineage", tags=["Lineage"])
        self._setup_routes()
    
    def _setup_routes(self):
        """Configura as rotas do controller"""
        
        @self.router.get("/{entity_id}")
        async def get_entity_lineage(
            entity_id: str = Path(..., description="ID da entidade"),
            depth: int = Query(3, ge=1, le=10, description="Profundidade da busca"),
            include_upstream: bool = Query(True, description="Incluir nós upstream"),
            include_downstream: bool = Query(True, description="Incluir nós downstream"),
            min_strength: float = Query(0.0, ge=0.0, le=1.0, description="Força mínima")
        ) -> LineageResponseModel:
            """
            Descobre a linhagem de uma entidade específica
            
            Retorna o grafo de linhagem centrado na entidade especificada,
            incluindo nós upstream (fontes) e downstream (destinos).
            """
            try:
                import time
                start_time = time.time()
                
                logger.info(f"Descobrindo linhagem para entidade: {entity_id}")
                
                # Validar UUID
                try:
                    entity_uuid = UUID(entity_id)
                except ValueError:
                    raise HTTPException(
                        status_code=400,
                        detail="ID da entidade deve ser um UUID válido"
                    )
                
                # Criar request
                request = LineageDiscoveryRequest(
                    entity_id=entity_uuid,
                    depth=depth,
                    include_upstream=include_upstream,
                    include_downstream=include_downstream,
                    min_strength=min_strength
                )
                
                # Executar descoberta
                result = self.use_case.discover_lineage(request)
                
                execution_time = (time.time() - start_time) * 1000
                
                return LineageResponseModel(
                    success=True,
                    data=result.__dict__,
                    message=f"Linhagem descoberta com sucesso. {result.upstream_count} upstream, {result.downstream_count} downstream",
                    execution_time_ms=execution_time
                )
                
            except ValueError as e:
                logger.error(f"Erro de validação: {e}")
                raise HTTPException(status_code=400, detail=str(e))
            except Exception as e:
                logger.error(f"Erro na descoberta de linhagem: {e}")
                raise HTTPException(status_code=500, detail="Erro interno do servidor")
        
        @self.router.post("/discover")
        async def discover_lineage_advanced(
            request: LineageDiscoveryRequestModel
        ) -> LineageResponseModel:
            """
            Descoberta avançada de linhagem com parâmetros customizados
            
            Permite controle fino sobre os parâmetros de descoberta,
            incluindo filtros por força de relacionamento.
            """
            try:
                import time
                start_time = time.time()
                
                logger.info(f"Descoberta avançada para: {request.entity_id}")
                
                # Validar UUID
                try:
                    entity_uuid = UUID(request.entity_id)
                except ValueError:
                    raise HTTPException(
                        status_code=400,
                        detail="ID da entidade deve ser um UUID válido"
                    )
                
                # Criar request interno
                use_case_request = LineageDiscoveryRequest(
                    entity_id=entity_uuid,
                    depth=request.depth,
                    include_upstream=request.include_upstream,
                    include_downstream=request.include_downstream,
                    min_strength=request.min_strength
                )
                
                # Executar descoberta
                result = self.use_case.discover_lineage(use_case_request)
                
                execution_time = (time.time() - start_time) * 1000
                
                return LineageResponseModel(
                    success=True,
                    data=result.__dict__,
                    message="Descoberta avançada concluída com sucesso",
                    execution_time_ms=execution_time
                )
                
            except ValueError as e:
                logger.error(f"Erro de validação: {e}")
                raise HTTPException(status_code=400, detail=str(e))
            except Exception as e:
                logger.error(f"Erro na descoberta avançada: {e}")
                raise HTTPException(status_code=500, detail="Erro interno do servidor")
        
        @self.router.post("/impact")
        async def analyze_impact(
            request: ImpactAnalysisRequestModel
        ) -> LineageResponseModel:
            """
            Analisa o impacto de mudanças em uma entidade
            
            Identifica todas as entidades que seriam afetadas por
            mudanças na entidade fonte, incluindo análise de criticidade.
            """
            try:
                import time
                start_time = time.time()
                
                logger.info(f"Análise de impacto para: {request.source_entity_id}")
                
                # Validar UUID
                try:
                    entity_uuid = UUID(request.source_entity_id)
                except ValueError:
                    raise HTTPException(
                        status_code=400,
                        detail="ID da entidade deve ser um UUID válido"
                    )
                
                # Criar request interno
                use_case_request = ImpactAnalysisRequest(
                    source_entity_id=entity_uuid,
                    max_depth=request.max_depth,
                    impact_threshold=request.impact_threshold
                )
                
                # Executar análise
                result = self.use_case.analyze_impact(use_case_request)
                
                execution_time = (time.time() - start_time) * 1000
                
                return LineageResponseModel(
                    success=True,
                    data=result,
                    message=f"Análise de impacto concluída. {result['impact_summary']['total_impacted_nodes']} nós impactados",
                    execution_time_ms=execution_time
                )
                
            except ValueError as e:
                logger.error(f"Erro de validação: {e}")
                raise HTTPException(status_code=400, detail=str(e))
            except Exception as e:
                logger.error(f"Erro na análise de impacto: {e}")
                raise HTTPException(status_code=500, detail="Erro interno do servidor")
        
        @self.router.post("/paths")
        async def discover_paths(
            request: PathDiscoveryRequestModel
        ) -> LineageResponseModel:
            """
            Descobre caminhos entre duas entidades
            
            Encontra todos os caminhos possíveis entre uma entidade fonte
            e uma entidade destino, ordenados por força de relacionamento.
            """
            try:
                import time
                start_time = time.time()
                
                logger.info(f"Descoberta de caminhos: {request.source_entity_id} -> {request.target_entity_id}")
                
                # Validar UUIDs
                try:
                    source_uuid = UUID(request.source_entity_id)
                    target_uuid = UUID(request.target_entity_id)
                except ValueError:
                    raise HTTPException(
                        status_code=400,
                        detail="IDs das entidades devem ser UUIDs válidos"
                    )
                
                if source_uuid == target_uuid:
                    raise HTTPException(
                        status_code=400,
                        detail="Entidade fonte e destino não podem ser iguais"
                    )
                
                # Criar request interno
                use_case_request = PathDiscoveryRequest(
                    source_entity_id=source_uuid,
                    target_entity_id=target_uuid,
                    max_paths=request.max_paths,
                    max_depth=request.max_depth
                )
                
                # Executar descoberta
                result = self.use_case.discover_paths(use_case_request)
                
                execution_time = (time.time() - start_time) * 1000
                
                return LineageResponseModel(
                    success=True,
                    data=result,
                    message=f"Descoberta de caminhos concluída. {result['path_summary']['total_paths_found']} caminhos encontrados",
                    execution_time_ms=execution_time
                )
                
            except ValueError as e:
                logger.error(f"Erro de validação: {e}")
                raise HTTPException(status_code=400, detail=str(e))
            except Exception as e:
                logger.error(f"Erro na descoberta de caminhos: {e}")
                raise HTTPException(status_code=500, detail="Erro interno do servidor")
        
        @self.router.get("/statistics")
        async def get_lineage_statistics() -> LineageResponseModel:
            """
            Obtém estatísticas gerais de linhagem
            
            Retorna métricas sobre o grafo de linhagem, incluindo
            número de nós, relacionamentos, densidade e qualidade.
            """
            try:
                import time
                start_time = time.time()
                
                logger.info("Obtendo estatísticas de linhagem")
                
                # Executar consulta
                result = self.use_case.get_lineage_statistics()
                
                execution_time = (time.time() - start_time) * 1000
                
                return LineageResponseModel(
                    success=True,
                    data=result,
                    message="Estatísticas obtidas com sucesso",
                    execution_time_ms=execution_time
                )
                
            except Exception as e:
                logger.error(f"Erro ao obter estatísticas: {e}")
                raise HTTPException(status_code=500, detail="Erro interno do servidor")
        
        @self.router.get("/health")
        async def health_check() -> Dict[str, Any]:
            """
            Verifica a saúde do serviço de linhagem
            """
            try:
                # Testar conexão com banco
                stats = self.use_case.get_lineage_statistics()
                
                return {
                    "status": "healthy",
                    "service": "Lineage Service",
                    "version": "5.0",
                    "database_connection": "ok",
                    "total_nodes": stats.get("total_nodes", 0),
                    "total_relationships": stats.get("total_relationships", 0)
                }
                
            except Exception as e:
                logger.error(f"Health check falhou: {e}")
                return {
                    "status": "unhealthy",
                    "service": "Lineage Service",
                    "error": str(e)
                }

# Instância global do controller
lineage_controller = LineageController()

