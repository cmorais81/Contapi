"""
Lineage Service - Microserviço de Linhagem de Dados
Sistema de Governança de Dados V5.0

Responsável por:
- Rastreamento de linhagem de dados
- Análise de impacto
- Descoberta de caminhos
- Visualização de grafos de linhagem
"""

import logging
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import sys
import os

# Adicionar path do projeto
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from presentation.controllers.lineage_controller import lineage_controller
from shared.database import get_db_health

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# =====================================================
# CONFIGURAÇÃO DA APLICAÇÃO
# =====================================================

app = FastAPI(
    title="Lineage Service",
    description="Microserviço para rastreamento e análise de linhagem de dados",
    version="5.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# ROTAS PRINCIPAIS
# =====================================================

@app.get("/")
async def root():
    """Endpoint raiz do serviço"""
    return {
        "service": "Lineage Service",
        "version": "5.0.0",
        "description": "Microserviço de linhagem de dados com PostgreSQL",
        "status": "running",
        "features": [
            "Descoberta de linhagem",
            "Análise de impacto",
            "Descoberta de caminhos",
            "Estatísticas de grafo",
            "Persistência PostgreSQL"
        ],
        "endpoints": {
            "docs": "/docs",
            "health": "/health",
            "lineage": "/api/v1/lineage"
        }
    }

@app.get("/health")
async def health_check():
    """Endpoint de health check"""
    try:
        # Verificar saúde do banco de dados
        db_health = get_db_health()
        
        # Verificar saúde do serviço de linhagem
        lineage_health = await lineage_controller.router.url_path_for("health_check")
        
        if db_health.get("status") == "healthy":
            return {
                "status": "healthy",
                "service": "Lineage Service",
                "version": "5.0.0",
                "timestamp": "2025-07-29T04:00:00Z",
                "database": db_health,
                "components": {
                    "lineage_discovery": "operational",
                    "impact_analysis": "operational",
                    "path_discovery": "operational",
                    "graph_service": "operational",
                    "postgresql_repository": "operational"
                }
            }
        else:
            return JSONResponse(
                status_code=503,
                content={
                    "status": "unhealthy",
                    "service": "Lineage Service",
                    "error": "Database connection failed",
                    "database": db_health
                }
            )
            
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "service": "Lineage Service",
                "error": str(e)
            }
        )

# =====================================================
# INCLUIR ROUTERS
# =====================================================

# Incluir router do controller de linhagem
app.include_router(lineage_controller.router)

# =====================================================
# TRATAMENTO DE ERROS
# =====================================================

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Handler para exceções HTTP"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "status_code": exc.status_code,
            "service": "Lineage Service"
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    """Handler para exceções gerais"""
    logger.error(f"Unhandled exception: {exc}")
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "status_code": 500,
            "service": "Lineage Service"
        }
    )

# =====================================================
# EVENTOS DE STARTUP/SHUTDOWN
# =====================================================

@app.on_event("startup")
async def startup_event():
    """Evento de inicialização"""
    logger.info("=== Lineage Service Starting ===")
    logger.info("Version: 5.0.0")
    logger.info("Features: Linhagem, Impacto, Caminhos, PostgreSQL")
    
    try:
        # Verificar conexão com banco
        db_health = get_db_health()
        if db_health.get("status") == "healthy":
            logger.info("✅ PostgreSQL connection: OK")
            logger.info(f"✅ Database tables: {len(db_health.get('tables', {}))}")
        else:
            logger.error("❌ PostgreSQL connection: FAILED")
            
    except Exception as e:
        logger.error(f"❌ Startup error: {e}")

@app.on_event("shutdown")
async def shutdown_event():
    """Evento de encerramento"""
    logger.info("=== Lineage Service Shutting Down ===")
    
    try:
        # Fechar conexões se necessário
        from shared.database import db_connection
        db_connection.close()
        logger.info("✅ Database connections closed")
        
    except Exception as e:
        logger.error(f"❌ Shutdown error: {e}")

# =====================================================
# EXECUÇÃO PRINCIPAL
# =====================================================

if __name__ == "__main__":
    logger.info("Starting Lineage Service...")
    
    # Configurações do servidor
    config = {
        "host": "0.0.0.0",
        "port": 8011,
        "log_level": "info",
        "reload": False
    }
    
    logger.info(f"Server config: {config}")
    
    try:
        uvicorn.run(
            "main:app",
            **config
        )
    except Exception as e:
        logger.error(f"Failed to start server: {e}")
        sys.exit(1)

