"""
Casos de uso para Lineage Service
Autor: carlos.morais@f1rst.com.br
"""

from typing import List, Optional, Dict, Any
from datetime import datetime
from ..domain.entities.lineage import Lineage, LineageNode, LineageEdge, LineageType, LineageDirection

class LineageUseCases:
    """Casos de uso para gestão de linhagem"""
    
    def __init__(self, lineage_repository):
        self.lineage_repository = lineage_repository
    
    async def trace_lineage(self, asset_id: str, direction: LineageDirection, depth: int = 5) -> Lineage:
        """Rastreia linhagem de um asset"""
        try:
            # Busca linhagem existente
            existing_lineage = await self.lineage_repository.get_by_asset_id(asset_id)
            
            if existing_lineage and existing_lineage.depth >= depth:
                return existing_lineage
            
            # Constrói nova linhagem
            nodes = await self._discover_nodes(asset_id, direction, depth)
            edges = await self._discover_edges(nodes)
            
            lineage = Lineage(
                id=f"lineage_{asset_id}_{datetime.now().isoformat()}",
                asset_id=asset_id,
                nodes=nodes,
                edges=edges,
                direction=direction,
                depth=depth,
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
            
            await self.lineage_repository.save(lineage)
            return lineage
            
        except Exception as e:
            raise Exception(f"Erro ao rastrear linhagem: {str(e)}")
    
    async def analyze_impact(self, asset_id: str, change_type: str) -> Dict[str, Any]:
        """Analisa impacto de mudanças"""
        try:
            downstream_lineage = await self.trace_lineage(
                asset_id, 
                LineageDirection.DOWNSTREAM, 
                depth=10
            )
            
            impacted_assets = []
            for node in downstream_lineage.get_downstream_nodes():
                impact_score = self._calculate_node_impact(node, change_type)
                impacted_assets.append({
                    "asset_id": node.id,
                    "asset_name": node.name,
                    "impact_score": impact_score,
                    "risk_level": self._get_risk_level(impact_score)
                })
            
            return {
                "total_impacted": len(impacted_assets),
                "high_risk_count": len([a for a in impacted_assets if a["risk_level"] == "HIGH"]),
                "impacted_assets": sorted(impacted_assets, key=lambda x: x["impact_score"], reverse=True)
            }
            
        except Exception as e:
            raise Exception(f"Erro ao analisar impacto: {str(e)}")
    
    async def get_data_flow(self, source_id: str, target_id: str) -> List[LineageNode]:
        """Obtém fluxo de dados entre dois pontos"""
        try:
            # Implementa algoritmo de busca de caminho
            source_lineage = await self.trace_lineage(source_id, LineageDirection.DOWNSTREAM)
            
            path = self._find_path(source_lineage, source_id, target_id)
            return path
            
        except Exception as e:
            raise Exception(f"Erro ao obter fluxo de dados: {str(e)}")
    
    async def _discover_nodes(self, asset_id: str, direction: LineageDirection, depth: int) -> List[LineageNode]:
        """Descobre nós na linhagem"""
        # Implementação simplificada - em produção integraria com sistemas reais
        nodes = [
            LineageNode(
                id=asset_id,
                name=f"Asset {asset_id}",
                type=LineageType.DATASET,
                source_system="governance_system",
                metadata={"discovered": True},
                created_at=datetime.now(),
                updated_at=datetime.now()
            )
        ]
        
        # Simula descoberta de nós relacionados
        for i in range(min(depth, 3)):
            related_id = f"{asset_id}_related_{i}"
            nodes.append(
                LineageNode(
                    id=related_id,
                    name=f"Related Asset {i}",
                    type=LineageType.TRANSFORMATION,
                    source_system="external_system",
                    metadata={"level": i},
                    created_at=datetime.now(),
                    updated_at=datetime.now()
                )
            )
        
        return nodes
    
    async def _discover_edges(self, nodes: List[LineageNode]) -> List[LineageEdge]:
        """Descobre arestas entre nós"""
        edges = []
        
        for i in range(len(nodes) - 1):
            edge = LineageEdge(
                id=f"edge_{nodes[i].id}_{nodes[i+1].id}",
                source_node_id=nodes[i].id,
                target_node_id=nodes[i+1].id,
                transformation_logic="SELECT * FROM source",
                confidence_score=0.9,
                created_at=datetime.now()
            )
            edges.append(edge)
        
        return edges
    
    def _calculate_node_impact(self, node: LineageNode, change_type: str) -> float:
        """Calcula impacto em um nó específico"""
        base_score = 0.5
        
        # Ajusta score baseado no tipo de mudança
        if change_type == "schema_change":
            base_score += 0.3
        elif change_type == "data_quality":
            base_score += 0.2
        elif change_type == "access_change":
            base_score += 0.1
        
        # Ajusta baseado no tipo de nó
        if node.type == LineageType.DATASET:
            base_score += 0.2
        elif node.type == LineageType.TRANSFORMATION:
            base_score += 0.3
        
        return min(base_score, 1.0)
    
    def _get_risk_level(self, impact_score: float) -> str:
        """Determina nível de risco baseado no score"""
        if impact_score >= 0.8:
            return "HIGH"
        elif impact_score >= 0.5:
            return "MEDIUM"
        else:
            return "LOW"
    
    def _find_path(self, lineage: Lineage, source_id: str, target_id: str) -> List[LineageNode]:
        """Encontra caminho entre dois nós"""
        # Implementação simplificada de busca de caminho
        path = []
        
        # Encontra nó fonte
        source_node = next((node for node in lineage.nodes if node.id == source_id), None)
        if source_node:
            path.append(source_node)
        
        # Encontra nó destino
        target_node = next((node for node in lineage.nodes if node.id == target_id), None)
        if target_node and target_node != source_node:
            path.append(target_node)
        
        return path
