"""
Use Case: Descoberta de Linhagem de Dados
Sistema de Governança de Dados V5.0
"""

import logging
from typing import Dict, List, Optional, Any
from uuid import UUID
from dataclasses import dataclass

from ...domain.entities.lineage_node import LineageNode, LineageRelationship, NodeType, LineageRelationType
from ...domain.services.lineage_graph_service import LineageGraphService, ImpactAnalysis, LineagePath
from ...infrastructure.repositories.postgres_lineage_repository import PostgresLineageRepository

logger = logging.getLogger(__name__)

@dataclass
class LineageDiscoveryRequest:
    """Request para descoberta de linhagem"""
    entity_id: UUID
    depth: int = 3
    include_upstream: bool = True
    include_downstream: bool = True
    min_strength: float = 0.0

@dataclass
class LineageDiscoveryResponse:
    """Response da descoberta de linhagem"""
    center_entity: Dict[str, Any]
    lineage_graph: Dict[str, Any]
    upstream_count: int
    downstream_count: int
    total_paths: int
    max_depth_reached: int

@dataclass
class ImpactAnalysisRequest:
    """Request para análise de impacto"""
    source_entity_id: UUID
    max_depth: int = 5
    impact_threshold: float = 0.1

@dataclass
class PathDiscoveryRequest:
    """Request para descoberta de caminhos"""
    source_entity_id: UUID
    target_entity_id: UUID
    max_paths: int = 10
    max_depth: int = 10

class LineageDiscoveryUseCase:
    """
    Use Case para descoberta e análise de linhagem de dados
    
    Responsável por:
    - Descobrir linhagem de entidades
    - Análise de impacto
    - Descoberta de caminhos
    - Construção de grafos de linhagem
    """
    
    def __init__(self):
        self.repository = PostgresLineageRepository()
        self.graph_service = LineageGraphService()
    
    def discover_lineage(self, request: LineageDiscoveryRequest) -> LineageDiscoveryResponse:
        """
        Descobre a linhagem completa de uma entidade
        """
        try:
            logger.info(f"Iniciando descoberta de linhagem para entidade: {request.entity_id}")
            
            # Buscar entidade central
            center_node = self.repository.get_node_by_id(request.entity_id)
            if not center_node:
                raise ValueError(f"Entidade não encontrada: {request.entity_id}")
            
            # Buscar grafo de linhagem do banco
            lineage_graph = self.repository.get_lineage_graph(
                request.entity_id, 
                request.depth
            )
            
            # Construir grafo em memória para análises
            self._build_in_memory_graph(lineage_graph)
            
            # Contar nós upstream e downstream
            upstream_nodes = []
            downstream_nodes = []
            
            if request.include_upstream:
                upstream_nodes = self.repository.get_upstream_nodes(
                    request.entity_id, 
                    request.depth
                )
            
            if request.include_downstream:
                downstream_nodes = self.repository.get_downstream_nodes(
                    request.entity_id, 
                    request.depth
                )
            
            # Calcular métricas
            total_paths = 0
            max_depth_reached = 0
            
            for node_id in upstream_nodes + downstream_nodes:
                paths = self.graph_service.find_paths(
                    request.entity_id, 
                    UUID(str(node_id)), 
                    request.depth
                )
                total_paths += len(paths)
                
                if paths:
                    max_depth_reached = max(max_depth_reached, max(p.path_length for p in paths))
            
            # Filtrar por força mínima se especificado
            if request.min_strength > 0.0:
                lineage_graph = self._filter_by_strength(lineage_graph, request.min_strength)
            
            response = LineageDiscoveryResponse(
                center_entity=center_node.to_dict(),
                lineage_graph=lineage_graph,
                upstream_count=len(upstream_nodes),
                downstream_count=len(downstream_nodes),
                total_paths=total_paths,
                max_depth_reached=max_depth_reached
            )
            
            logger.info(f"Linhagem descoberta: {len(upstream_nodes)} upstream, {len(downstream_nodes)} downstream")
            return response
            
        except Exception as e:
            logger.error(f"Erro na descoberta de linhagem: {e}")
            raise
    
    def analyze_impact(self, request: ImpactAnalysisRequest) -> Dict[str, Any]:
        """
        Analisa o impacto de mudanças em uma entidade
        """
        try:
            logger.info(f"Iniciando análise de impacto para: {request.source_entity_id}")
            
            # Verificar se entidade existe
            source_node = self.repository.get_node_by_id(request.source_entity_id)
            if not source_node:
                raise ValueError(f"Entidade não encontrada: {request.source_entity_id}")
            
            # Buscar nós downstream (impactados)
            impacted_node_ids = self.repository.get_downstream_nodes(
                request.source_entity_id,
                request.max_depth
            )
            
            # Construir grafo em memória para análise detalhada
            lineage_graph = self.repository.get_lineage_graph(
                request.source_entity_id,
                request.max_depth
            )
            self._build_in_memory_graph(lineage_graph)
            
            # Executar análise de impacto
            impact_analysis = self.graph_service.analyze_impact(
                request.source_entity_id,
                request.max_depth
            )
            
            # Buscar detalhes dos nós impactados
            impacted_nodes = []
            for node_id in impact_analysis.impacted_nodes:
                node = self.repository.get_node_by_id(node_id)
                if node:
                    impacted_nodes.append(node.to_dict())
            
            # Filtrar por threshold de impacto
            significant_paths = [
                path for path in impact_analysis.impact_paths
                if path.total_strength >= request.impact_threshold
            ]
            
            # Categorizar impacto por força
            impact_categories = {
                'critical': [p for p in significant_paths if p.total_strength >= 0.8],
                'high': [p for p in significant_paths if 0.6 <= p.total_strength < 0.8],
                'medium': [p for p in significant_paths if 0.4 <= p.total_strength < 0.6],
                'low': [p for p in significant_paths if 0.2 <= p.total_strength < 0.4]
            }
            
            result = {
                'source_entity': source_node.to_dict(),
                'impact_summary': {
                    'total_impacted_nodes': len(impacted_nodes),
                    'impact_score': impact_analysis.impact_score,
                    'significant_paths': len(significant_paths),
                    'max_depth_analyzed': request.max_depth
                },
                'impacted_nodes': impacted_nodes,
                'impact_paths': [path.to_dict() for path in significant_paths],
                'impact_categories': {
                    category: [path.to_dict() for path in paths]
                    for category, paths in impact_categories.items()
                },
                'recommendations': self._generate_impact_recommendations(impact_analysis)
            }
            
            logger.info(f"Análise de impacto concluída: {len(impacted_nodes)} nós impactados")
            return result
            
        except Exception as e:
            logger.error(f"Erro na análise de impacto: {e}")
            raise
    
    def discover_paths(self, request: PathDiscoveryRequest) -> Dict[str, Any]:
        """
        Descobre caminhos entre duas entidades
        """
        try:
            logger.info(f"Descobrindo caminhos: {request.source_entity_id} -> {request.target_entity_id}")
            
            # Verificar se entidades existem
            source_node = self.repository.get_node_by_id(request.source_entity_id)
            target_node = self.repository.get_node_by_id(request.target_entity_id)
            
            if not source_node:
                raise ValueError(f"Entidade fonte não encontrada: {request.source_entity_id}")
            if not target_node:
                raise ValueError(f"Entidade destino não encontrada: {request.target_entity_id}")
            
            # Construir grafo em memória
            lineage_graph = self.repository.get_lineage_graph(
                request.source_entity_id,
                request.max_depth
            )
            self._build_in_memory_graph(lineage_graph)
            
            # Encontrar caminhos
            paths = self.graph_service.find_paths(
                request.source_entity_id,
                request.target_entity_id,
                request.max_depth
            )
            
            # Limitar número de caminhos
            paths = paths[:request.max_paths]
            
            # Enriquecer caminhos com detalhes dos nós
            enriched_paths = []
            for path in paths:
                enriched_path = {
                    'path_id': f"path_{len(enriched_paths)}",
                    'total_strength': path.total_strength,
                    'path_length': path.path_length,
                    'nodes': [],
                    'relationships': []
                }
                
                # Adicionar detalhes dos nós
                for node_id in path.nodes:
                    node = self.repository.get_node_by_id(node_id)
                    if node:
                        enriched_path['nodes'].append(node.to_dict())
                
                # Adicionar detalhes dos relacionamentos
                for rel_id in path.relationships:
                    rel = self.repository.get_relationship_by_id(rel_id)
                    if rel:
                        enriched_path['relationships'].append(rel.to_dict())
                
                enriched_paths.append(enriched_path)
            
            # Calcular estatísticas
            if paths:
                avg_strength = sum(p.total_strength for p in paths) / len(paths)
                avg_length = sum(p.path_length for p in paths) / len(paths)
                strongest_path = max(paths, key=lambda p: p.total_strength)
                shortest_path = min(paths, key=lambda p: p.path_length)
            else:
                avg_strength = 0.0
                avg_length = 0.0
                strongest_path = None
                shortest_path = None
            
            result = {
                'source_entity': source_node.to_dict(),
                'target_entity': target_node.to_dict(),
                'path_summary': {
                    'total_paths_found': len(paths),
                    'paths_returned': len(enriched_paths),
                    'average_strength': avg_strength,
                    'average_length': avg_length,
                    'max_depth_searched': request.max_depth
                },
                'paths': enriched_paths,
                'strongest_path': strongest_path.to_dict() if strongest_path else None,
                'shortest_path': shortest_path.to_dict() if shortest_path else None,
                'path_exists': len(paths) > 0
            }
            
            logger.info(f"Descoberta de caminhos concluída: {len(paths)} caminhos encontrados")
            return result
            
        except Exception as e:
            logger.error(f"Erro na descoberta de caminhos: {e}")
            raise
    
    def get_lineage_statistics(self) -> Dict[str, Any]:
        """
        Obtém estatísticas gerais de linhagem
        """
        try:
            # Estatísticas do banco
            db_stats = self.repository.get_lineage_statistics()
            
            # Construir grafo em memória para métricas avançadas
            # (limitado para performance)
            sample_graph = self.repository.get_lineage_graph(
                list(self.repository.get_nodes_by_type(NodeType.SOURCE))[0].id if 
                self.repository.get_nodes_by_type(NodeType.SOURCE) else None,
                depth=2
            )
            
            if sample_graph.get('nodes'):
                self._build_in_memory_graph(sample_graph)
                graph_metrics = self.graph_service.get_graph_metrics()
            else:
                graph_metrics = {}
            
            # Combinar estatísticas
            combined_stats = {
                **db_stats,
                **graph_metrics,
                'data_quality': {
                    'nodes_with_description': 0,  # Calcular se necessário
                    'relationships_with_metadata': 0,  # Calcular se necessário
                    'avg_node_connectivity': db_stats.get('total_relationships', 0) / max(db_stats.get('total_nodes', 1), 1)
                }
            }
            
            return combined_stats
            
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas: {e}")
            return {}
    
    def _build_in_memory_graph(self, lineage_graph: Dict[str, Any]) -> None:
        """Constrói grafo em memória a partir dos dados do banco"""
        try:
            # Limpar grafo atual
            self.graph_service.clear()
            
            # Adicionar nós
            for node_data in lineage_graph.get('nodes', {}).values():
                node = LineageNode(
                    id=UUID(node_data['id']),
                    name=node_data['name'],
                    description=node_data.get('description', ''),
                    node_type=NodeType(node_data['type']),
                    source_system=node_data.get('source_system', '')
                )
                self.graph_service.add_node(node)
            
            # Adicionar relacionamentos
            for rel_data in lineage_graph.get('relationships', []):
                relationship = LineageRelationship(
                    id=UUID(rel_data['id']),
                    source_node_id=UUID(rel_data['source']),
                    target_node_id=UUID(rel_data['target']),
                    relationship_type=LineageRelationType(rel_data['type']),
                    strength=rel_data['strength']
                )
                self.graph_service.add_relationship(relationship)
            
        except Exception as e:
            logger.error(f"Erro ao construir grafo em memória: {e}")
            raise
    
    def _filter_by_strength(self, lineage_graph: Dict[str, Any], min_strength: float) -> Dict[str, Any]:
        """Filtra grafo por força mínima dos relacionamentos"""
        filtered_relationships = [
            rel for rel in lineage_graph.get('relationships', [])
            if rel['strength'] >= min_strength
        ]
        
        # Manter apenas nós que têm relacionamentos válidos
        valid_node_ids = set()
        for rel in filtered_relationships:
            valid_node_ids.add(rel['source'])
            valid_node_ids.add(rel['target'])
        
        filtered_nodes = {
            node_id: node_data 
            for node_id, node_data in lineage_graph.get('nodes', {}).items()
            if node_id in valid_node_ids
        }
        
        return {
            **lineage_graph,
            'nodes': filtered_nodes,
            'relationships': filtered_relationships,
            'total_nodes': len(filtered_nodes),
            'total_relationships': len(filtered_relationships)
        }
    
    def _generate_impact_recommendations(self, impact_analysis: ImpactAnalysis) -> List[str]:
        """Gera recomendações baseadas na análise de impacto"""
        recommendations = []
        
        if impact_analysis.impact_score > 0.7:
            recommendations.append("Alto impacto detectado. Considere comunicação prévia às equipes afetadas.")
        
        if len(impact_analysis.impacted_nodes) > 10:
            recommendations.append("Muitos nós impactados. Considere implementação em fases.")
        
        critical_paths = [p for p in impact_analysis.impact_paths if p.total_strength > 0.8]
        if critical_paths:
            recommendations.append(f"{len(critical_paths)} caminhos críticos identificados. Validação rigorosa recomendada.")
        
        if not recommendations:
            recommendations.append("Impacto baixo detectado. Mudança pode ser implementada com segurança.")
        
        return recommendations

