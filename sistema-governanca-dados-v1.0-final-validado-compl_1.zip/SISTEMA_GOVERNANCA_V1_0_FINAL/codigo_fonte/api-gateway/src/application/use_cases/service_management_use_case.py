"""
Service Management Use Case - Application Layer
Responsabilidade única: Gestão de registro e descoberta de microserviços
"""

from typing import Dict, Any, Optional, List
import asyncio
import httpx
from datetime import datetime, timedelta

from ...domain.entities.service_registry import (
    ServiceRegistry, 
    ServiceDefinition, 
    ServiceInstance,
    LoadBalancingStrategy
)
from ...domain.services.circuit_breaker_service import CircuitBreakerService
from ...domain.services.rate_limiting_service import RateLimitingService, RateLimitStrategy
from ....shared.exceptions.domain_exceptions import (
    ServiceNotFoundException, 
    ServiceAlreadyExistsException,
    InvalidServiceConfigurationException
)


class ServiceManagementUseCase:
    """
    Use Case para gestão de serviços no registry.
    
    Aplica SRP: Responsabilidade única de gerenciar registro, descoberta
    e configuração de microserviços.
    """
    
    def __init__(
        self,
        service_registry: ServiceRegistry,
        circuit_breaker_service: CircuitBreakerService,
        rate_limiting_service: RateLimitingService,
        config: Dict[str, Any]
    ):
        self.service_registry = service_registry
        self.circuit_breaker_service = circuit_breaker_service
        self.rate_limiting_service = rate_limiting_service
        self.config = config
        self.http_client = httpx.AsyncClient(timeout=5.0)
    
    async def register_service(
        self,
        service_name: str,
        instances: List[Dict[str, Any]],
        load_balancing_strategy: str = "round_robin",
        circuit_breaker_config: Optional[Dict[str, Any]] = None,
        rate_limit_config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Registra um novo serviço no registry.
        
        Args:
            service_name: Nome único do serviço
            instances: Lista de instâncias do serviço
            load_balancing_strategy: Estratégia de load balancing
            circuit_breaker_config: Configuração do circuit breaker
            rate_limit_config: Configuração de rate limiting
            
        Returns:
            Dict com detalhes do serviço registrado
            
        Raises:
            ServiceAlreadyExistsException: Se serviço já existe
            InvalidServiceConfigurationException: Se configuração inválida
        """
        # Validar se serviço já existe
        if self.service_registry.get_service(service_name):
            raise ServiceAlreadyExistsException(f"Service already exists: {service_name}")
        
        # Validar configuração
        self._validate_service_config(service_name, instances, load_balancing_strategy)
        
        # Criar instâncias
        service_instances = []
        for instance_config in instances:
            instance = ServiceInstance(
                instance_id=instance_config.get('instance_id', f"{service_name}-{len(service_instances)}"),
                base_url=instance_config['base_url'],
                weight=instance_config.get('weight', 1),
                metadata=instance_config.get('metadata', {})
            )
            service_instances.append(instance)
        
        # Criar definição do serviço
        try:
            lb_strategy = LoadBalancingStrategy(load_balancing_strategy.upper())
        except ValueError:
            raise InvalidServiceConfigurationException(f"Invalid load balancing strategy: {load_balancing_strategy}")
        
        service_definition = ServiceDefinition(
            service_name=service_name,
            load_balancing_strategy=lb_strategy,
            instances=service_instances
        )
        
        # Registrar no registry
        self.service_registry.register_service(service_definition)
        
        # Configurar circuit breaker
        if circuit_breaker_config:
            self.circuit_breaker_service.get_or_create_breaker(
                service_name,
                failure_threshold=circuit_breaker_config.get('failure_threshold', 5),
                success_threshold=circuit_breaker_config.get('success_threshold', 3),
                timeout_seconds=circuit_breaker_config.get('timeout_seconds', 60),
                window_size_minutes=circuit_breaker_config.get('window_size_minutes', 5)
            )
        
        # Configurar rate limiting
        if rate_limit_config:
            strategy = RateLimitStrategy(rate_limit_config.get('strategy', 'sliding_window').upper())
            
            self.rate_limiting_service.get_or_create_limiter(
                f"global:{service_name}",
                max_requests=rate_limit_config.get('max_requests', 1000),
                window_size_seconds=rate_limit_config.get('window_size_seconds', 60),
                strategy=strategy,
                burst_allowance=rate_limit_config.get('burst_allowance', 100),
                refill_rate=rate_limit_config.get('refill_rate', 10)
            )
        
        # Executar health check inicial
        await self._initial_health_check(service_definition)
        
        return {
            "service_name": service_name,
            "instances_count": len(service_instances),
            "load_balancing_strategy": load_balancing_strategy,
            "circuit_breaker_configured": circuit_breaker_config is not None,
            "rate_limiting_configured": rate_limit_config is not None,
            "registration_time": datetime.now().isoformat()
        }
    
    async def unregister_service(self, service_name: str) -> Dict[str, Any]:
        """
        Remove um serviço do registry.
        
        Args:
            service_name: Nome do serviço
            
        Returns:
            Dict com confirmação da remoção
            
        Raises:
            ServiceNotFoundException: Se serviço não existe
        """
        service_definition = self.service_registry.get_service(service_name)
        
        if not service_definition:
            raise ServiceNotFoundException(f"Service not found: {service_name}")
        
        # Remover do registry
        self.service_registry.unregister_service(service_name)
        
        # Limpar circuit breaker
        self.circuit_breaker_service.reset_breaker(service_name)
        
        # Limpar rate limiters
        self.rate_limiting_service.reset_limiter(f"global:{service_name}")
        
        return {
            "service_name": service_name,
            "unregistration_time": datetime.now().isoformat(),
            "instances_removed": len(service_definition.instances)
        }
    
    async def add_service_instance(
        self,
        service_name: str,
        instance_config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Adiciona uma nova instância a um serviço existente.
        
        Args:
            service_name: Nome do serviço
            instance_config: Configuração da nova instância
            
        Returns:
            Dict com detalhes da instância adicionada
            
        Raises:
            ServiceNotFoundException: Se serviço não existe
        """
        service_definition = self.service_registry.get_service(service_name)
        
        if not service_definition:
            raise ServiceNotFoundException(f"Service not found: {service_name}")
        
        # Criar nova instância
        instance = ServiceInstance(
            instance_id=instance_config.get('instance_id', f"{service_name}-{len(service_definition.instances)}"),
            base_url=instance_config['base_url'],
            weight=instance_config.get('weight', 1),
            metadata=instance_config.get('metadata', {})
        )
        
        # Adicionar ao serviço
        service_definition.add_instance(instance)
        
        # Health check inicial
        await self._health_check_instance(instance)
        
        return {
            "service_name": service_name,
            "instance_id": instance.instance_id,
            "base_url": instance.base_url,
            "weight": instance.weight,
            "added_time": datetime.now().isoformat()
        }
    
    async def remove_service_instance(
        self,
        service_name: str,
        instance_id: str
    ) -> Dict[str, Any]:
        """
        Remove uma instância de um serviço.
        
        Args:
            service_name: Nome do serviço
            instance_id: ID da instância
            
        Returns:
            Dict com confirmação da remoção
            
        Raises:
            ServiceNotFoundException: Se serviço ou instância não existe
        """
        service_definition = self.service_registry.get_service(service_name)
        
        if not service_definition:
            raise ServiceNotFoundException(f"Service not found: {service_name}")
        
        # Encontrar instância
        instance = None
        for inst in service_definition.instances:
            if inst.instance_id == instance_id:
                instance = inst
                break
        
        if not instance:
            raise ServiceNotFoundException(f"Instance not found: {instance_id}")
        
        # Remover instância
        service_definition.remove_instance(instance_id)
        
        return {
            "service_name": service_name,
            "instance_id": instance_id,
            "removed_time": datetime.now().isoformat()
        }
    
    async def update_service_configuration(
        self,
        service_name: str,
        load_balancing_strategy: Optional[str] = None,
        circuit_breaker_config: Optional[Dict[str, Any]] = None,
        rate_limit_config: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Atualiza configuração de um serviço.
        
        Args:
            service_name: Nome do serviço
            load_balancing_strategy: Nova estratégia de load balancing
            circuit_breaker_config: Nova configuração do circuit breaker
            rate_limit_config: Nova configuração de rate limiting
            
        Returns:
            Dict com configuração atualizada
            
        Raises:
            ServiceNotFoundException: Se serviço não existe
        """
        service_definition = self.service_registry.get_service(service_name)
        
        if not service_definition:
            raise ServiceNotFoundException(f"Service not found: {service_name}")
        
        updates = {}
        
        # Atualizar load balancing strategy
        if load_balancing_strategy:
            try:
                lb_strategy = LoadBalancingStrategy(load_balancing_strategy.upper())
                service_definition.load_balancing_strategy = lb_strategy
                updates['load_balancing_strategy'] = load_balancing_strategy
            except ValueError:
                raise InvalidServiceConfigurationException(f"Invalid load balancing strategy: {load_balancing_strategy}")
        
        # Atualizar circuit breaker
        if circuit_breaker_config:
            self.circuit_breaker_service.get_or_create_breaker(
                service_name,
                failure_threshold=circuit_breaker_config.get('failure_threshold', 5),
                success_threshold=circuit_breaker_config.get('success_threshold', 3),
                timeout_seconds=circuit_breaker_config.get('timeout_seconds', 60),
                window_size_minutes=circuit_breaker_config.get('window_size_minutes', 5)
            )
            updates['circuit_breaker_updated'] = True
        
        # Atualizar rate limiting
        if rate_limit_config:
            strategy = RateLimitStrategy(rate_limit_config.get('strategy', 'sliding_window').upper())
            
            self.rate_limiting_service.get_or_create_limiter(
                f"global:{service_name}",
                max_requests=rate_limit_config.get('max_requests', 1000),
                window_size_seconds=rate_limit_config.get('window_size_seconds', 60),
                strategy=strategy,
                burst_allowance=rate_limit_config.get('burst_allowance', 100),
                refill_rate=rate_limit_config.get('refill_rate', 10)
            )
            updates['rate_limiting_updated'] = True
        
        return {
            "service_name": service_name,
            "updates": updates,
            "updated_time": datetime.now().isoformat()
        }
    
    async def discover_services(self) -> Dict[str, Any]:
        """
        Lista todos os serviços registrados.
        
        Returns:
            Dict com lista de serviços e suas configurações
        """
        services = []
        
        for service_name, service_def in self.service_registry.services.items():
            services.append({
                "service_name": service_name,
                "load_balancing_strategy": service_def.load_balancing_strategy.value,
                "instances_count": len(service_def.instances),
                "healthy_instances": len([i for i in service_def.instances if i.is_healthy()]),
                "availability_percentage": service_def.get_availability_percentage(),
                "average_response_time_ms": service_def.get_average_response_time(),
                "instances": [
                    {
                        "instance_id": inst.instance_id,
                        "base_url": inst.base_url,
                        "weight": inst.weight,
                        "is_healthy": inst.is_healthy(),
                        "last_health_check": inst.last_health_check.isoformat() if inst.last_health_check else None,
                        "response_time_ms": inst.response_time_ms
                    }
                    for inst in service_def.instances
                ]
            })
        
        return {
            "total_services": len(services),
            "services": services,
            "discovery_time": datetime.now().isoformat()
        }
    
    async def get_service_details(self, service_name: str) -> Dict[str, Any]:
        """
        Obtém detalhes completos de um serviço.
        
        Args:
            service_name: Nome do serviço
            
        Returns:
            Dict com detalhes completos do serviço
            
        Raises:
            ServiceNotFoundException: Se serviço não existe
        """
        service_definition = self.service_registry.get_service(service_name)
        
        if not service_definition:
            raise ServiceNotFoundException(f"Service not found: {service_name}")
        
        return {
            "service_name": service_name,
            "load_balancing_strategy": service_definition.load_balancing_strategy.value,
            "instances_count": len(service_definition.instances),
            "healthy_instances": len([i for i in service_definition.instances if i.is_healthy()]),
            "availability_percentage": service_definition.get_availability_percentage(),
            "average_response_time_ms": service_definition.get_average_response_time(),
            "circuit_breaker": self.circuit_breaker_service.get_breaker_status(service_name),
            "rate_limiting": self.rate_limiting_service.get_limiter_status(f"global:{service_name}"),
            "instances": [
                {
                    "instance_id": inst.instance_id,
                    "base_url": inst.base_url,
                    "weight": inst.weight,
                    "is_healthy": inst.is_healthy(),
                    "last_health_check": inst.last_health_check.isoformat() if inst.last_health_check else None,
                    "response_time_ms": inst.response_time_ms,
                    "success_rate": inst.get_success_rate(),
                    "metadata": inst.metadata
                }
                for inst in service_definition.instances
            ]
        }
    
    def _validate_service_config(
        self,
        service_name: str,
        instances: List[Dict[str, Any]],
        load_balancing_strategy: str
    ):
        """
        Valida configuração do serviço.
        
        Args:
            service_name: Nome do serviço
            instances: Lista de instâncias
            load_balancing_strategy: Estratégia de load balancing
            
        Raises:
            InvalidServiceConfigurationException: Se configuração inválida
        """
        if not service_name or not service_name.strip():
            raise InvalidServiceConfigurationException("Service name cannot be empty")
        
        if not instances:
            raise InvalidServiceConfigurationException("At least one instance is required")
        
        for instance in instances:
            if 'base_url' not in instance:
                raise InvalidServiceConfigurationException("Instance base_url is required")
            
            if not instance['base_url'].startswith(('http://', 'https://')):
                raise InvalidServiceConfigurationException("Instance base_url must start with http:// or https://")
        
        valid_strategies = [strategy.value.lower() for strategy in LoadBalancingStrategy]
        if load_balancing_strategy.lower() not in valid_strategies:
            raise InvalidServiceConfigurationException(f"Invalid load balancing strategy. Valid options: {valid_strategies}")
    
    async def _initial_health_check(self, service_definition: ServiceDefinition):
        """
        Executa health check inicial em todas as instâncias.
        
        Args:
            service_definition: Definição do serviço
        """
        tasks = []
        for instance in service_definition.instances:
            tasks.append(self._health_check_instance(instance))
        
        await asyncio.gather(*tasks, return_exceptions=True)
    
    async def _health_check_instance(self, instance: ServiceInstance):
        """
        Executa health check em uma instância.
        
        Args:
            instance: Instância do serviço
        """
        try:
            start_time = datetime.now()
            
            response = await self.http_client.get(
                f"{instance.base_url}/health",
                timeout=5.0
            )
            
            response_time = (datetime.now() - start_time).total_seconds() * 1000
            
            if response.status_code == 200:
                instance.mark_healthy(response_time)
            else:
                instance.mark_unhealthy(f"HTTP {response.status_code}")
                
        except Exception as e:
            instance.mark_unhealthy(str(e))
    
    async def close(self):
        """
        Fecha recursos do use case.
        """
        await self.http_client.aclose()

