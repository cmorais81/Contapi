"""
Gateway Routing Use Case - Application Layer
Responsabilidade única: Roteamento inteligente de requests para microserviços
"""

from typing import Dict, Any, Optional, List
import asyncio
import httpx
from datetime import datetime, timedelta

from ...domain.entities.service_registry import ServiceRegistry, ServiceDefinition, ServiceInstance
from ...domain.services.circuit_breaker_service import CircuitBreakerService
from ...domain.services.rate_limiting_service import RateLimitingService
from ....shared.exceptions.domain_exceptions import (
    ServiceNotFoundException, 
    ServiceUnavailableException,
    RateLimitExceededException,
    CircuitBreakerOpenException
)


class GatewayRoutingUseCase:
    """
    Use Case para roteamento inteligente de requests.
    
    Aplica SRP: Responsabilidade única de rotear requests para microserviços
    com resiliência, rate limiting e load balancing.
    """
    
    def __init__(
        self,
        service_registry: ServiceRegistry,
        circuit_breaker_service: CircuitBreakerService,
        rate_limiting_service: RateLimitingService,
        config: Dict[str, Any]
    ):
        self.service_registry = service_registry
        self.circuit_breaker_service = circuit_breaker_service
        self.rate_limiting_service = rate_limiting_service
        self.config = config
        self.http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(
                connect=config.get('connect_timeout', 5.0),
                read=config.get('read_timeout', 30.0),
                write=config.get('write_timeout', 30.0),
                pool=config.get('pool_timeout', 5.0)
            ),
            limits=httpx.Limits(
                max_keepalive_connections=config.get('max_keepalive', 20),
                max_connections=config.get('max_connections', 100)
            )
        )
    
    async def route_request(
        self,
        path: str,
        method: str,
        headers: Dict[str, str],
        body: Optional[bytes] = None,
        query_params: Optional[Dict[str, str]] = None,
        client_id: Optional[str] = None,
        client_ip: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Roteia request para o microserviço apropriado.
        
        Args:
            path: Caminho da requisição (ex: /audit/events)
            method: Método HTTP (GET, POST, etc.)
            headers: Headers da requisição
            body: Corpo da requisição (opcional)
            query_params: Parâmetros de query (opcional)
            client_id: ID do cliente para rate limiting (opcional)
            client_ip: IP do cliente para rate limiting (opcional)
            
        Returns:
            Dict com response do microserviço
            
        Raises:
            ServiceNotFoundException: Serviço não encontrado
            ServiceUnavailableException: Serviço indisponível
            RateLimitExceededException: Rate limit excedido
            CircuitBreakerOpenException: Circuit breaker aberto
        """
        # 1. Descobrir serviço pelo path
        service_name = self._extract_service_name(path)
        service_definition = self.service_registry.get_service(service_name)
        
        if not service_definition:
            raise ServiceNotFoundException(f"Service not found for path: {path}")
        
        # 2. Verificar rate limiting
        await self._check_rate_limiting(service_name, client_id, client_ip)
        
        # 3. Selecionar instância com load balancing
        instance = self._select_instance(service_definition)
        
        if not instance:
            raise ServiceUnavailableException(f"No healthy instances available for service: {service_name}")
        
        # 4. Executar request com circuit breaker
        try:
            response = await self._execute_with_circuit_breaker(
                service_name,
                instance,
                path,
                method,
                headers,
                body,
                query_params
            )
            
            # 5. Atualizar métricas de sucesso
            await self._update_success_metrics(instance)
            
            return response
            
        except Exception as e:
            # 6. Atualizar métricas de falha
            await self._update_failure_metrics(instance)
            raise
    
    async def health_check_service(self, service_name: str) -> Dict[str, Any]:
        """
        Executa health check em um serviço específico.
        
        Args:
            service_name: Nome do serviço
            
        Returns:
            Dict com status de saúde do serviço
        """
        service_definition = self.service_registry.get_service(service_name)
        
        if not service_definition:
            raise ServiceNotFoundException(f"Service not found: {service_name}")
        
        health_results = []
        
        for instance in service_definition.instances:
            try:
                start_time = datetime.now()
                
                response = await self.http_client.get(
                    f"{instance.base_url}/health",
                    timeout=5.0
                )
                
                response_time = (datetime.now() - start_time).total_seconds() * 1000
                
                if response.status_code == 200:
                    instance.mark_healthy(response_time)
                    health_results.append({
                        "instance_id": instance.instance_id,
                        "status": "healthy",
                        "response_time_ms": response_time,
                        "details": response.json() if response.content else {}
                    })
                else:
                    instance.mark_unhealthy(f"HTTP {response.status_code}")
                    health_results.append({
                        "instance_id": instance.instance_id,
                        "status": "unhealthy",
                        "response_time_ms": response_time,
                        "error": f"HTTP {response.status_code}"
                    })
                    
            except Exception as e:
                instance.mark_unhealthy(str(e))
                health_results.append({
                    "instance_id": instance.instance_id,
                    "status": "unhealthy",
                    "error": str(e)
                })
        
        return {
            "service_name": service_name,
            "overall_health": service_definition.get_availability_percentage(),
            "instances": health_results,
            "healthy_instances": len([r for r in health_results if r["status"] == "healthy"]),
            "total_instances": len(health_results)
        }
    
    async def get_service_metrics(self, service_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Obtém métricas de serviços.
        
        Args:
            service_name: Nome do serviço específico (opcional)
            
        Returns:
            Dict com métricas dos serviços
        """
        if service_name:
            service_definition = self.service_registry.get_service(service_name)
            if not service_definition:
                raise ServiceNotFoundException(f"Service not found: {service_name}")
            
            return {
                "service_name": service_name,
                "availability_percentage": service_definition.get_availability_percentage(),
                "average_response_time_ms": service_definition.get_average_response_time(),
                "total_instances": len(service_definition.instances),
                "healthy_instances": len([i for i in service_definition.instances if i.is_healthy()]),
                "load_balancing_strategy": service_definition.load_balancing_strategy.value,
                "circuit_breaker": self.circuit_breaker_service.get_breaker_status(service_name),
                "rate_limiting": self.rate_limiting_service.get_limiter_status(service_name)
            }
        else:
            # Métricas de todos os serviços
            services_metrics = []
            
            for service_name, service_def in self.service_registry.services.items():
                services_metrics.append({
                    "service_name": service_name,
                    "availability_percentage": service_def.get_availability_percentage(),
                    "average_response_time_ms": service_def.get_average_response_time(),
                    "total_instances": len(service_def.instances),
                    "healthy_instances": len([i for i in service_def.instances if i.is_healthy()])
                })
            
            return {
                "total_services": len(self.service_registry.services),
                "services": services_metrics,
                "circuit_breakers": self.circuit_breaker_service.get_service_summary(),
                "rate_limiters": self.rate_limiting_service.get_service_summary()
            }
    
    def _extract_service_name(self, path: str) -> str:
        """
        Extrai nome do serviço do path.
        
        Args:
            path: Caminho da requisição
            
        Returns:
            Nome do serviço
        """
        # Remove leading slash e pega primeiro segmento
        path_segments = path.lstrip('/').split('/')
        
        if not path_segments or not path_segments[0]:
            raise ServiceNotFoundException("Invalid path: cannot extract service name")
        
        # Mapear paths para nomes de serviços
        service_mapping = {
            'audit': 'audit-service',
            'contracts': 'contract-service',
            'discovery': 'auto-discovery-service',
            'analytics': 'analytics-service',
            'catalog': 'catalog-service',
            'identity': 'identity-service',
            'quality': 'quality-service',
            'notifications': 'notification-service',
            'governance': 'governance-service',
            'workflows': 'workflow-service'
        }
        
        service_key = path_segments[0].lower()
        return service_mapping.get(service_key, service_key)
    
    async def _check_rate_limiting(
        self,
        service_name: str,
        client_id: Optional[str],
        client_ip: Optional[str]
    ):
        """
        Verifica rate limiting para o request.
        
        Args:
            service_name: Nome do serviço
            client_id: ID do cliente
            client_ip: IP do cliente
            
        Raises:
            RateLimitExceededException: Se rate limit for excedido
        """
        # Rate limiting global
        global_key = f"global:{service_name}"
        if not await self.rate_limiting_service.allow_request(global_key):
            raise RateLimitExceededException(f"Global rate limit exceeded for service: {service_name}")
        
        # Rate limiting por cliente
        if client_id:
            client_key = f"client:{client_id}:{service_name}"
            if not await self.rate_limiting_service.allow_request(client_key):
                raise RateLimitExceededException(f"Client rate limit exceeded for client: {client_id}")
        
        # Rate limiting por IP
        if client_ip:
            ip_key = f"ip:{client_ip}:{service_name}"
            if not await self.rate_limiting_service.allow_request(ip_key):
                raise RateLimitExceededException(f"IP rate limit exceeded for IP: {client_ip}")
    
    def _select_instance(self, service_definition: ServiceDefinition) -> Optional[ServiceInstance]:
        """
        Seleciona instância usando load balancing.
        
        Args:
            service_definition: Definição do serviço
            
        Returns:
            Instância selecionada ou None se nenhuma disponível
        """
        return service_definition.get_next_instance()
    
    async def _execute_with_circuit_breaker(
        self,
        service_name: str,
        instance: ServiceInstance,
        path: str,
        method: str,
        headers: Dict[str, str],
        body: Optional[bytes],
        query_params: Optional[Dict[str, str]]
    ) -> Dict[str, Any]:
        """
        Executa request com circuit breaker.
        
        Args:
            service_name: Nome do serviço
            instance: Instância do serviço
            path: Caminho da requisição
            method: Método HTTP
            headers: Headers da requisição
            body: Corpo da requisição
            query_params: Parâmetros de query
            
        Returns:
            Response do microserviço
            
        Raises:
            CircuitBreakerOpenException: Se circuit breaker estiver aberto
        """
        async def make_request():
            # Construir URL completa
            url = f"{instance.base_url}{path}"
            
            # Preparar headers
            request_headers = {**headers}
            request_headers.pop('host', None)  # Remove host header
            
            # Fazer request
            response = await self.http_client.request(
                method=method,
                url=url,
                headers=request_headers,
                content=body,
                params=query_params
            )
            
            # Converter response para dict
            return {
                "status_code": response.status_code,
                "headers": dict(response.headers),
                "body": response.content,
                "json": response.json() if response.headers.get('content-type', '').startswith('application/json') else None
            }
        
        # Executar com circuit breaker
        return await self.circuit_breaker_service.execute(service_name, make_request)
    
    async def _update_success_metrics(self, instance: ServiceInstance):
        """
        Atualiza métricas de sucesso da instância.
        
        Args:
            instance: Instância do serviço
        """
        # Métricas já são atualizadas no circuit breaker
        # Aqui podemos adicionar métricas específicas do gateway
        pass
    
    async def _update_failure_metrics(self, instance: ServiceInstance):
        """
        Atualiza métricas de falha da instância.
        
        Args:
            instance: Instância do serviço
        """
        # Métricas já são atualizadas no circuit breaker
        # Aqui podemos adicionar métricas específicas do gateway
        pass
    
    async def close(self):
        """
        Fecha recursos do use case.
        """
        await self.http_client.aclose()

