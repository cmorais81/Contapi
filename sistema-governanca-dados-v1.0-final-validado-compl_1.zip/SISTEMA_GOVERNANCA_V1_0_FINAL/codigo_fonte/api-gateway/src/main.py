# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
API Gateway V4.1 - Governança de Dados
Ponto único de entrada para todos os microserviços
Resolve problemas de fragmentação da V4.0
"""

import asyncio
import json
import logging
import os
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from uuid import uuid4

import httpx
from fastapi import FastAPI, HTTPException, Depends, Query, Path, Body, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Service URLs
SERVICES = {
    "contract": "http://localhost:8001",
    "identity": "http://localhost:8002", 
    "quality": "http://localhost:8003",
    "catalog": "http://localhost:8004",
    "analytics": "http://localhost:8005",
    "workflow": "http://localhost:8006",
    "governance": "http://localhost:8007"
}

# Initialize FastAPI app
app = FastAPI(
    title="API Gateway V4.1 - Governança de Dados",
    description="Ponto único de entrada para microserviços de governança",
    version="4.1.0",
    contact={
        "name": " ",
        "email": "@example.com"
    }
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# HTTP client for service communication
http_client = httpx.AsyncClient(timeout=30.0)

# Cache simples em memória
cache = {}
CACHE_TTL = 300  # 5 minutos

# Models
class ServiceHealth(BaseModel):
    service: str
    status: str
    response_time: float
    last_check: datetime

class ConsolidatedMetrics(BaseModel):
    summary: Dict[str, Any]
    distributions: Dict[str, Any]
    health_score: Dict[str, Any]
    timestamp: datetime

class SimpleContractRequest(BaseModel):
    name: str
    description: str
    data_owner: str
    classification: str = "internal"

# Utility functions
async def call_service(service: str, endpoint: str, method: str = "GET", data: Dict = None) -> Dict:
    """Call a microservice with error handling and caching"""
    cache_key = f"{service}_{endpoint}_{method}"
    
    # Check cache for GET requests
    if method == "GET" and cache_key in cache:
        cached_data, timestamp = cache[cache_key]
        if time.time() - timestamp < CACHE_TTL:
            return cached_data
    
    try:
        url = f"{SERVICES[service]}{endpoint}"
        
        if method == "GET":
            response = await http_client.get(url)
        elif method == "POST":
            response = await http_client.post(url, json=data)
        elif method == "PUT":
            response = await http_client.put(url, json=data)
        elif method == "DELETE":
            response = await http_client.delete(url)
        else:
            raise ValueError(f"Unsupported method: {method}")
        
        if response.status_code == 200:
            result = response.json()
            
            # Cache GET responses
            if method == "GET":
                cache[cache_key] = (result, time.time())
            
            return result
        else:
            logger.error(f"Service {service} returned {response.status_code}: {response.text}")
            return {"error": f"Service {service} error", "status_code": response.status_code}
    
    except Exception as e:
        logger.error(f"Error calling service {service}: {str(e)}")
        return {"error": f"Service {service} unavailable", "details": str(e)}

async def check_service_health(service: str) -> ServiceHealth:
    """Check health of a specific service"""
    start_time = time.time()
    
    try:
        response = await http_client.get(f"{SERVICES[service]}/health", timeout=5.0)
        response_time = time.time() - start_time
        
        if response.status_code == 200:
            return ServiceHealth(
                service=service,
                status="healthy",
                response_time=response_time,
                last_check=datetime.utcnow()
            )
        else:
            return ServiceHealth(
                service=service,
                status="unhealthy",
                response_time=response_time,
                last_check=datetime.utcnow()
            )
    except Exception as e:
        response_time = time.time() - start_time
        return ServiceHealth(
            service=service,
            status="unavailable",
            response_time=response_time,
            last_check=datetime.utcnow()
        )

# API Gateway Endpoints

@app.get("/")
async def root():
    """API Gateway information"""
    return {
        "name": "API Gateway V4.1 - Governança de Dados",
        "version": "4.1.0",
        "description": "Ponto único de entrada para microserviços",
        "services": list(SERVICES.keys()),
        "features": [
            "Dashboard executivo consolidado",
            "Compliance assessment detalhado", 
            "Validação holística",
            "Auditoria centralizada",
            "Interface simplificada"
        ],
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/health")
async def health_check():
    """Health check do gateway e todos os serviços"""
    gateway_health = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "cache_size": len(cache)
    }
    
    # Check all services
    service_health = {}
    tasks = [check_service_health(service) for service in SERVICES.keys()]
    health_results = await asyncio.gather(*tasks, return_exceptions=True)
    
    for i, service in enumerate(SERVICES.keys()):
        if isinstance(health_results[i], Exception):
            service_health[service] = {
                "status": "error",
                "error": str(health_results[i])
            }
        else:
            service_health[service] = health_results[i].dict()
    
    return {
        "gateway": gateway_health,
        "services": service_health,
        "overall_status": "healthy" if all(
            h.get("status") == "healthy" for h in service_health.values()
        ) else "degraded"
    }

# SOLUÇÃO 1: DASHBOARD EXECUTIVO CONSOLIDADO
@app.get("/api/v1/metrics/summary")
async def consolidated_dashboard():
    """
    Dashboard executivo consolidado - SOLUÇÃO PARA PROBLEMA 1
    Agrega dados de todos os microserviços em um único endpoint
    Compatível 100% com V3.2
    """
    try:
        # Buscar dados de todos os serviços em paralelo
        tasks = [
            call_service("contract", "/api/v1/contracts/metrics"),
            call_service("identity", "/api/v1/users/metrics"),
            call_service("quality", "/api/v1/quality/metrics"),
            call_service("catalog", "/api/v1/entities/metrics"),
            call_service("analytics", "/api/v1/analytics/dashboard"),
            call_service("governance", "/api/v1/dashboard")
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Extract data with fallbacks
        contract_data = results[0] if not isinstance(results[0], Exception) else {}
        identity_data = results[1] if not isinstance(results[1], Exception) else {}
        quality_data = results[2] if not isinstance(results[2], Exception) else {}
        catalog_data = results[3] if not isinstance(results[3], Exception) else {}
        analytics_data = results[4] if not isinstance(results[4], Exception) else {}
        governance_data = results[5] if not isinstance(results[5], Exception) else {}
        
        # Consolidate metrics (formato compatível com V3.2)
        consolidated = {
            "summary": {
                "total_contracts": contract_data.get("total_contracts", 0),
                "active_contracts": contract_data.get("active_contracts", 0),
                "active_users": identity_data.get("active_users", 0),
                "total_entities": catalog_data.get("total_entities", 0),
                "active_quality_rules": quality_data.get("active_rules", 0),
                "today_activities": analytics_data.get("today_activities", 0)
            },
            "distributions": {
                "contract_status": contract_data.get("status_distribution", {}),
                "data_classification": contract_data.get("classification_distribution", {})
            },
            "health_score": {
                "governance_score": governance_data.get("governance_score", 0),
                "quality_coverage": quality_data.get("coverage_percentage", 0),
                "user_engagement": analytics_data.get("user_engagement", 0)
            },
            "timestamp": datetime.utcnow().isoformat()
        }
        
        return consolidated
        
    except Exception as e:
        logger.error(f"Error in consolidated dashboard: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Dashboard aggregation failed: {str(e)}")

# SOLUÇÃO 5: INTERFACE SIMPLIFICADA
@app.get("/api/v1/simple/contracts")
async def simple_list_contracts():
    """Interface simplificada para listar contratos - compatível com V3.2"""
    contracts = await call_service("contract", "/api/v1/contracts")
    
    if "error" in contracts:
        raise HTTPException(status_code=503, detail="Contract service unavailable")
    
    # Simplificar resposta
    return [
        {
            "id": c.get("id"),
            "name": c.get("name"),
            "status": c.get("status"),
            "data_owner": c.get("data_owner"),
            "created_at": c.get("created_at")
        }
        for c in contracts
    ]

@app.post("/api/v1/simple/contracts")
async def simple_create_contract(request: SimpleContractRequest):
    """Interface simplificada para criar contratos"""
    # Enriquecer com defaults inteligentes
    full_request = {
        "name": request.name,
        "description": request.description,
        "data_owner": request.data_owner,
        "data_classification": request.classification,
        "status": "draft",
        "version": "1.0",
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat()
    }
    
    result = await call_service("contract", "/api/v1/contracts", "POST", full_request)
    
    if "error" in result:
        raise HTTPException(status_code=503, detail="Contract service unavailable")
    
    return result

@app.get("/api/v1/simple/dashboard")
async def simple_dashboard():
    """Dashboard simplificado para usuários básicos"""
    try:
        # Buscar dados essenciais
        contracts = await call_service("contract", "/api/v1/contracts/metrics")
        quality = await call_service("quality", "/api/v1/quality/metrics")
        governance = await call_service("governance", "/api/v1/dashboard")
        
        return {
            "contracts": {
                "total": contracts.get("total_contracts", 0),
                "active": contracts.get("active_contracts", 0)
            },
            "quality_score": quality.get("overall_score", 0),
            "compliance_status": governance.get("compliance_status", "unknown"),
            "recent_activities": governance.get("recent_activities", [])[:5],
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error in simple dashboard: {str(e)}")
        raise HTTPException(status_code=500, detail="Dashboard unavailable")

# Proxy endpoints para compatibilidade
@app.get("/api/v1/contracts")
async def proxy_contracts():
    """Proxy para contract service"""
    result = await call_service("contract", "/api/v1/contracts")
    if "error" in result:
        raise HTTPException(status_code=503, detail="Contract service unavailable")
    return result

@app.post("/api/v1/contracts")
async def proxy_create_contract(request: dict):
    """Proxy para criação de contratos"""
    result = await call_service("contract", "/api/v1/contracts", "POST", request)
    if "error" in result:
        raise HTTPException(status_code=503, detail="Contract service unavailable")
    return result

@app.post("/api/v1/pii/detect")
async def proxy_pii_detect(request: dict):
    """Proxy para detecção de PII"""
    result = await call_service("contract", "/api/v1/pii/detect", "POST", request)
    if "error" in result:
        raise HTTPException(status_code=503, detail="PII detection service unavailable")
    return result

@app.get("/api/v1/users")
async def proxy_users():
    """Proxy para identity service"""
    result = await call_service("identity", "/api/v1/users")
    if "error" in result:
        raise HTTPException(status_code=503, detail="Identity service unavailable")
    return result

# Startup event
@app.on_event("startup")
async def startup_event():
    logger.info("Starting API Gateway V4.1")
    logger.info("Checking service connectivity...")
    
    # Check all services
    for service_name in SERVICES.keys():
        health = await check_service_health(service_name)
        logger.info(f"Service {service_name}: {health.status}")
    
    logger.info("API Gateway V4.1 started successfully")

# Shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Shutting down API Gateway V4.1")
    await http_client.aclose()

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8100))
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=port,
        reload=False,
        log_level="info"
    )

