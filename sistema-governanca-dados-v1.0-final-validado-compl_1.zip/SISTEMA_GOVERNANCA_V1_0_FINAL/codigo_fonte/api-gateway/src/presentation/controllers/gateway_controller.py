"""
Gateway Controller - Presentation Layer
Controller principal do API Gateway com roteamento inteligente e gestão de serviços
"""

from typing import Dict, Any, Optional, List
import json
from datetime import datetime
from fastapi import FastAPI, Request, Response, HTTPException, Depends, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

from ...application.use_cases.gateway_routing_use_case import GatewayRoutingUseCase
from ...application.use_cases.service_management_use_case import ServiceManagementUseCase
from ....shared.exceptions.domain_exceptions import (
    ServiceNotFoundException,
    ServiceUnavailableException,
    RateLimitExceededException,
    CircuitBreakerOpenException,
    ServiceAlreadyExistsException,
    InvalidServiceConfigurationException
)


# DTOs para requests
class ServiceInstanceRequest(BaseModel):
    """DTO para configuração de instância de serviço."""
    instance_id: Optional[str] = None
    base_url: str = Field(..., description="URL base da instância")
    weight: int = Field(default=1, ge=1, le=100, description="Peso para load balancing")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadados da instância")


class CircuitBreakerConfigRequest(BaseModel):
    """DTO para configuração de circuit breaker."""
    failure_threshold: int = Field(default=5, ge=1, description="Limite de falhas")
    success_threshold: int = Field(default=3, ge=1, description="Limite de sucessos para recuperação")
    timeout_seconds: int = Field(default=60, ge=1, description="Timeout em segundos")
    window_size_minutes: int = Field(default=5, ge=1, description="Janela de tempo em minutos")


class RateLimitConfigRequest(BaseModel):
    """DTO para configuração de rate limiting."""
    strategy: str = Field(default="sliding_window", description="Estratégia de rate limiting")
    max_requests: int = Field(default=1000, ge=1, description="Máximo de requests")
    window_size_seconds: int = Field(default=60, ge=1, description="Janela de tempo em segundos")
    burst_allowance: Optional[int] = Field(default=100, ge=0, description="Allowance para burst")
    refill_rate: Optional[int] = Field(default=10, ge=1, description="Taxa de refill")


class ServiceRegistrationRequest(BaseModel):
    """DTO para registro de serviço."""
    service_name: str = Field(..., description="Nome único do serviço")
    instances: List[ServiceInstanceRequest] = Field(..., description="Lista de instâncias")
    load_balancing_strategy: str = Field(default="round_robin", description="Estratégia de load balancing")
    circuit_breaker_config: Optional[CircuitBreakerConfigRequest] = None
    rate_limit_config: Optional[RateLimitConfigRequest] = None


class ServiceUpdateRequest(BaseModel):
    """DTO para atualização de serviço."""
    load_balancing_strategy: Optional[str] = None
    circuit_breaker_config: Optional[CircuitBreakerConfigRequest] = None
    rate_limit_config: Optional[RateLimitConfigRequest] = None


class GatewayController:
    """
    Controller principal do API Gateway.
    
    Responsabilidades:
    - Roteamento inteligente de requests
    - Gestão de registro de serviços
    - Monitoramento e métricas
    - Health checks
    """
    
    def __init__(
        self,
        gateway_routing_use_case: GatewayRoutingUseCase,
        service_management_use_case: ServiceManagementUseCase,
        config: Dict[str, Any]
    ):
        self.gateway_routing_use_case = gateway_routing_use_case
        self.service_management_use_case = service_management_use_case
        self.config = config
        self.app = self._create_app()
    
    def _create_app(self) -> FastAPI:
        """
        Cria aplicação FastAPI com middleware e rotas.
        
        Returns:
            Aplicação FastAPI configurada
        """
        app = FastAPI(
            title="API Gateway",
            description="Gateway inteligente para microserviços de governança de dados",
            version="1.0.0",
            docs_url="/docs",
            redoc_url="/redoc"
        )
        
        # Middleware
        app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        
        app.add_middleware(GZipMiddleware, minimum_size=1000)
        
        # Exception handlers
        self._setup_exception_handlers(app)
        
        # Middleware customizado
        app.middleware("http")(self._request_middleware)
        
        # Rotas de gestão de serviços
        self._setup_service_management_routes(app)
        
        # Rotas de monitoramento
        self._setup_monitoring_routes(app)
        
        # Rota catch-all para roteamento
        app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"])(
            self._route_request
        )
        
        return app
    
    def _setup_exception_handlers(self, app: FastAPI):
        """
        Configura handlers de exceção.
        
        Args:
            app: Aplicação FastAPI
        """
        @app.exception_handler(ServiceNotFoundException)
        async def service_not_found_handler(request: Request, exc: ServiceNotFoundException):
            return JSONResponse(
                status_code=404,
                content={
                    "error": "Service Not Found",
                    "message": str(exc),
                    "timestamp": datetime.now().isoformat(),
                    "path": str(request.url.path)
                }
            )
        
        @app.exception_handler(ServiceUnavailableException)
        async def service_unavailable_handler(request: Request, exc: ServiceUnavailableException):
            return JSONResponse(
                status_code=503,
                content={
                    "error": "Service Unavailable",
                    "message": str(exc),
                    "timestamp": datetime.now().isoformat(),
                    "path": str(request.url.path)
                }
            )
        
        @app.exception_handler(RateLimitExceededException)
        async def rate_limit_handler(request: Request, exc: RateLimitExceededException):
            return JSONResponse(
                status_code=429,
                content={
                    "error": "Rate Limit Exceeded",
                    "message": str(exc),
                    "timestamp": datetime.now().isoformat(),
                    "path": str(request.url.path)
                },
                headers={"Retry-After": "60"}
            )
        
        @app.exception_handler(CircuitBreakerOpenException)
        async def circuit_breaker_handler(request: Request, exc: CircuitBreakerOpenException):
            return JSONResponse(
                status_code=503,
                content={
                    "error": "Circuit Breaker Open",
                    "message": str(exc),
                    "timestamp": datetime.now().isoformat(),
                    "path": str(request.url.path)
                },
                headers={"Retry-After": "60"}
            )
        
        @app.exception_handler(ServiceAlreadyExistsException)
        async def service_exists_handler(request: Request, exc: ServiceAlreadyExistsException):
            return JSONResponse(
                status_code=409,
                content={
                    "error": "Service Already Exists",
                    "message": str(exc),
                    "timestamp": datetime.now().isoformat(),
                    "path": str(request.url.path)
                }
            )
        
        @app.exception_handler(InvalidServiceConfigurationException)
        async def invalid_config_handler(request: Request, exc: InvalidServiceConfigurationException):
            return JSONResponse(
                status_code=400,
                content={
                    "error": "Invalid Service Configuration",
                    "message": str(exc),
                    "timestamp": datetime.now().isoformat(),
                    "path": str(request.url.path)
                }
            )
    
    async def _request_middleware(self, request: Request, call_next):
        """
        Middleware para logging e métricas de requests.
        
        Args:
            request: Request HTTP
            call_next: Próximo middleware/handler
            
        Returns:
            Response HTTP
        """
        start_time = datetime.now()
        
        # Adicionar headers de correlação
        correlation_id = request.headers.get("X-Correlation-ID", f"gw-{int(start_time.timestamp() * 1000)}")
        
        # Processar request
        response = await call_next(request)
        
        # Calcular tempo de processamento
        process_time = (datetime.now() - start_time).total_seconds()
        
        # Adicionar headers de response
        response.headers["X-Correlation-ID"] = correlation_id
        response.headers["X-Process-Time"] = str(process_time)
        response.headers["X-Gateway-Version"] = "1.0.0"
        
        # Log do request (em produção, usar logger estruturado)
        print(f"[{start_time.isoformat()}] {request.method} {request.url.path} - {response.status_code} - {process_time:.3f}s")
        
        return response
    
    def _setup_service_management_routes(self, app: FastAPI):
        """
        Configura rotas de gestão de serviços.
        
        Args:
            app: Aplicação FastAPI
        """
        @app.post("/admin/services", tags=["Service Management"])
        async def register_service(request: ServiceRegistrationRequest):
            """Registra um novo serviço no gateway."""
            circuit_breaker_config = None
            if request.circuit_breaker_config:
                circuit_breaker_config = request.circuit_breaker_config.dict()
            
            rate_limit_config = None
            if request.rate_limit_config:
                rate_limit_config = request.rate_limit_config.dict()
            
            instances = [instance.dict() for instance in request.instances]
            
            result = await self.service_management_use_case.register_service(
                service_name=request.service_name,
                instances=instances,
                load_balancing_strategy=request.load_balancing_strategy,
                circuit_breaker_config=circuit_breaker_config,
                rate_limit_config=rate_limit_config
            )
            
            return result
        
        @app.delete("/admin/services/{service_name}", tags=["Service Management"])
        async def unregister_service(service_name: str):
            """Remove um serviço do gateway."""
            result = await self.service_management_use_case.unregister_service(service_name)
            return result
        
        @app.post("/admin/services/{service_name}/instances", tags=["Service Management"])
        async def add_service_instance(service_name: str, instance: ServiceInstanceRequest):
            """Adiciona uma nova instância a um serviço."""
            result = await self.service_management_use_case.add_service_instance(
                service_name=service_name,
                instance_config=instance.dict()
            )
            return result
        
        @app.delete("/admin/services/{service_name}/instances/{instance_id}", tags=["Service Management"])
        async def remove_service_instance(service_name: str, instance_id: str):
            """Remove uma instância de um serviço."""
            result = await self.service_management_use_case.remove_service_instance(
                service_name=service_name,
                instance_id=instance_id
            )
            return result
        
        @app.put("/admin/services/{service_name}", tags=["Service Management"])
        async def update_service_configuration(service_name: str, update_request: ServiceUpdateRequest):
            """Atualiza configuração de um serviço."""
            circuit_breaker_config = None
            if update_request.circuit_breaker_config:
                circuit_breaker_config = update_request.circuit_breaker_config.dict()
            
            rate_limit_config = None
            if update_request.rate_limit_config:
                rate_limit_config = update_request.rate_limit_config.dict()
            
            result = await self.service_management_use_case.update_service_configuration(
                service_name=service_name,
                load_balancing_strategy=update_request.load_balancing_strategy,
                circuit_breaker_config=circuit_breaker_config,
                rate_limit_config=rate_limit_config
            )
            return result
        
        @app.get("/admin/services", tags=["Service Management"])
        async def discover_services():
            """Lista todos os serviços registrados."""
            result = await self.service_management_use_case.discover_services()
            return result
        
        @app.get("/admin/services/{service_name}", tags=["Service Management"])
        async def get_service_details(service_name: str):
            """Obtém detalhes completos de um serviço."""
            result = await self.service_management_use_case.get_service_details(service_name)
            return result
    
    def _setup_monitoring_routes(self, app: FastAPI):
        """
        Configura rotas de monitoramento.
        
        Args:
            app: Aplicação FastAPI
        """
        @app.get("/health", tags=["Monitoring"])
        async def health_check():
            """Health check do gateway."""
            return {
                "status": "healthy",
                "timestamp": datetime.now().isoformat(),
                "version": "1.0.0",
                "uptime_seconds": (datetime.now() - datetime.now()).total_seconds()
            }
        
        @app.get("/admin/health/{service_name}", tags=["Monitoring"])
        async def service_health_check(service_name: str):
            """Health check de um serviço específico."""
            result = await self.gateway_routing_use_case.health_check_service(service_name)
            return result
        
        @app.get("/admin/metrics", tags=["Monitoring"])
        async def get_gateway_metrics():
            """Métricas gerais do gateway."""
            result = await self.gateway_routing_use_case.get_service_metrics()
            return result
        
        @app.get("/admin/metrics/{service_name}", tags=["Monitoring"])
        async def get_service_metrics(service_name: str):
            """Métricas de um serviço específico."""
            result = await self.gateway_routing_use_case.get_service_metrics(service_name)
            return result
    
    async def _route_request(self, request: Request) -> Response:
        """
        Rota catch-all para roteamento de requests.
        
        Args:
            request: Request HTTP
            
        Returns:
            Response do microserviço
        """
        # Extrair informações do request
        path = request.url.path
        method = request.method
        headers = dict(request.headers)
        query_params = dict(request.query_params) if request.query_params else None
        
        # Ler body se presente
        body = None
        if method in ["POST", "PUT", "PATCH"]:
            body = await request.body()
        
        # Extrair informações do cliente
        client_ip = request.client.host if request.client else None
        client_id = headers.get("X-Client-ID")
        
        # Rotear request
        result = await self.gateway_routing_use_case.route_request(
            path=path,
            method=method,
            headers=headers,
            body=body,
            query_params=query_params,
            client_id=client_id,
            client_ip=client_ip
        )
        
        # Construir response
        response_headers = result.get("headers", {})
        response_body = result.get("body", b"")
        status_code = result.get("status_code", 200)
        
        # Filtrar headers problemáticos
        filtered_headers = {}
        for key, value in response_headers.items():
            if key.lower() not in ["content-length", "transfer-encoding", "connection"]:
                filtered_headers[key] = value
        
        return Response(
            content=response_body,
            status_code=status_code,
            headers=filtered_headers
        )
    
    def run(self, host: str = "0.0.0.0", port: int = 8000):
        """
        Executa o servidor do gateway.
        
        Args:
            host: Host para bind
            port: Porta para bind
        """
        uvicorn.run(
            self.app,
            host=host,
            port=port,
            log_level="info",
            access_log=True
        )
    
    async def close(self):
        """
        Fecha recursos do controller.
        """
        await self.gateway_routing_use_case.close()
        await self.service_management_use_case.close()

