"""
API Gateway - Ponto único de entrada para todos os microserviços
Versão: 5.0 - Clean Architecture com SOLID principles
"""

import asyncio
from typing import Dict, Any
from datetime import datetime

from .domain.entities.service_registry import ServiceRegistry, ServiceDefinition, ServiceInstance, LoadBalancingStrategy
from .domain.services.circuit_breaker_service import CircuitBreakerService
from .domain.services.rate_limiting_service import RateLimitingService, RateLimitStrategy
from .application.use_cases.gateway_routing_use_case import GatewayRoutingUseCase
from .application.use_cases.service_management_use_case import ServiceManagementUseCase
from .presentation.controllers.gateway_controller import GatewayController
from ..shared.config.security_config import ApplicationConfig


class APIGatewayApplication:
    """
    Aplicação principal do API Gateway.
    
    Aplica Clean Architecture com dependency injection e SOLID principles.
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.app_config = ApplicationConfig(config)
        
        # Inicializar componentes seguindo dependency injection
        self.service_registry = self._create_service_registry()
        self.circuit_breaker_service = CircuitBreakerService()
        self.rate_limiting_service = RateLimitingService()
        
        # Use Cases (Application Layer)
        self.gateway_routing_use_case = GatewayRoutingUseCase(
            service_registry=self.service_registry,
            circuit_breaker_service=self.circuit_breaker_service,
            rate_limiting_service=self.rate_limiting_service,
            config=config
        )
        
        self.service_management_use_case = ServiceManagementUseCase(
            service_registry=self.service_registry,
            circuit_breaker_service=self.circuit_breaker_service,
            rate_limiting_service=self.rate_limiting_service,
            config=config
        )
        
        # Controller (Presentation Layer)
        self.gateway_controller = GatewayController(
            gateway_routing_use_case=self.gateway_routing_use_case,
            service_management_use_case=self.service_management_use_case,
            config=config
        )
    
    def _create_service_registry(self) -> ServiceRegistry:
        """
        Cria e configura o service registry com os 10 microserviços.
        
        Returns:
            ServiceRegistry configurado
        """
        registry = ServiceRegistry()
        
        # Configuração dos 10 microserviços implementados
        microservices_config = [
            {
                "name": "audit-service",
                "instances": [{"base_url": "http://localhost:8001", "weight": 1}],
                "load_balancing": LoadBalancingStrategy.ROUND_ROBIN
            },
            {
                "name": "contract-service",
                "instances": [{"base_url": "http://localhost:8002", "weight": 1}],
                "load_balancing": LoadBalancingStrategy.HEALTH_BASED
            },
            {
                "name": "auto-discovery-service",
                "instances": [{"base_url": "http://localhost:8003", "weight": 1}],
                "load_balancing": LoadBalancingStrategy.ROUND_ROBIN
            },
            {
                "name": "analytics-service",
                "instances": [{"base_url": "http://localhost:8004", "weight": 1}],
                "load_balancing": LoadBalancingStrategy.LEAST_CONNECTIONS
            },
            {
                "name": "catalog-service",
                "instances": [{"base_url": "http://localhost:8005", "weight": 1}],
                "load_balancing": LoadBalancingStrategy.ROUND_ROBIN
            },
            {
                "name": "identity-service",
                "instances": [{"base_url": "http://localhost:8006", "weight": 1}],
                "load_balancing": LoadBalancingStrategy.HEALTH_BASED
            },
            {
                "name": "quality-service",
                "instances": [{"base_url": "http://localhost:8007", "weight": 1}],
                "load_balancing": LoadBalancingStrategy.WEIGHTED_ROUND_ROBIN
            },
            {
                "name": "notification-service",
                "instances": [{"base_url": "http://localhost:8008", "weight": 1}],
                "load_balancing": LoadBalancingStrategy.ROUND_ROBIN
            },
            {
                "name": "governance-service",
                "instances": [{"base_url": "http://localhost:8009", "weight": 1}],
                "load_balancing": LoadBalancingStrategy.HEALTH_BASED
            },
            {
                "name": "workflow-service",
                "instances": [{"base_url": "http://localhost:8010", "weight": 1}],
                "load_balancing": LoadBalancingStrategy.LEAST_CONNECTIONS
            }
        ]
        
        # Registrar cada microserviço
        for service_config in microservices_config:
            instances = []
            for i, instance_config in enumerate(service_config["instances"]):
                instance = ServiceInstance(
                    instance_id=f"{service_config['name']}-{i+1}",
                    base_url=instance_config["base_url"],
                    weight=instance_config["weight"],
                    metadata={"environment": "development", "version": "1.0.0"}
                )
                instances.append(instance)
            
            service_definition = ServiceDefinition(
                service_name=service_config["name"],
                load_balancing_strategy=service_config["load_balancing"],
                instances=instances
            )
            
            registry.register_service(service_definition)
        
        return registry
    
    async def initialize(self):
        """
        Inicializa a aplicação executando health checks iniciais.
        """
        print("🚀 Inicializando API Gateway...")
        
        # Executar health check inicial em todos os serviços
        print("🔍 Executando health checks iniciais...")
        
        for service_name in self.service_registry.services.keys():
            try:
                health_result = await self.gateway_routing_use_case.health_check_service(service_name)
                healthy_count = health_result.get("healthy_instances", 0)
                total_count = health_result.get("total_instances", 0)
                
                print(f"   ✅ {service_name}: {healthy_count}/{total_count} instâncias saudáveis")
                
            except Exception as e:
                print(f"   ❌ {service_name}: Erro no health check - {str(e)}")
        
        print("🎯 API Gateway inicializado com sucesso!")
        print(f"📊 Total de serviços registrados: {len(self.service_registry.services)}")
        print("🌐 Servidor disponível em: http://localhost:8000")
        print("📚 Documentação disponível em: http://localhost:8000/docs")
    
    def run(self, host: str = "0.0.0.0", port: int = 8000):
        """
        Executa o API Gateway.
        
        Args:
            host: Host para bind
            port: Porta para bind
        """
        # Executar inicialização
        asyncio.run(self.initialize())
        
        # Iniciar servidor
        self.gateway_controller.run(host=host, port=port)
    
    async def close(self):
        """
        Fecha recursos da aplicação.
        """
        await self.gateway_controller.close()


def create_app(config: Dict[str, Any] = None) -> APIGatewayApplication:
    """
    Factory function para criar aplicação do API Gateway.
    
    Args:
        config: Configuração da aplicação
        
    Returns:
        Instância da aplicação configurada
    """
    if config is None:
        config = {
            # Configurações de timeout
            "connect_timeout": 5.0,
            "read_timeout": 30.0,
            "write_timeout": 30.0,
            "pool_timeout": 5.0,
            
            # Configurações de conexão
            "max_keepalive": 20,
            "max_connections": 100,
            
            # Configurações de rate limiting padrão
            "default_rate_limit": {
                "max_requests": 1000,
                "window_size_seconds": 60,
                "strategy": "sliding_window"
            },
            
            # Configurações de circuit breaker padrão
            "default_circuit_breaker": {
                "failure_threshold": 5,
                "success_threshold": 3,
                "timeout_seconds": 60,
                "window_size_minutes": 5
            },
            
            # Configurações de logging
            "log_level": "info",
            "enable_access_log": True,
            
            # Configurações de segurança
            "enable_cors": True,
            "enable_gzip": True,
            "gzip_minimum_size": 1000
        }
    
    return APIGatewayApplication(config)


if __name__ == "__main__":
    # Criar e executar aplicação
    app = create_app()
    app.run()

