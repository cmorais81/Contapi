# Autor: carlos.morais@f1rst.com.br
"""
Entidade Data Source para Auto Discovery Service
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Any, Optional
from uuid import UUID, uuid4
from enum import Enum


class DataSourceType(Enum):
    """Tipos de fonte de dados"""
    DATABASE = "database"
    FILE_SYSTEM = "file_system"
    API = "api"
    CLOUD_STORAGE = "cloud_storage"
    STREAMING = "streaming"
    DATA_LAKE = "data_lake"
    DATA_WAREHOUSE = "data_warehouse"
    NOSQL = "nosql"
    MESSAGE_QUEUE = "message_queue"
    WEB_SERVICE = "web_service"


class DataSourceStatus(Enum):
    """Status da fonte de dados"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    DISCOVERING = "discovering"
    ERROR = "error"
    PENDING = "pending"
    ARCHIVED = "archived"


class ConnectionStatus(Enum):
    """Status da conexão"""
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    TESTING = "testing"
    FAILED = "failed"
    TIMEOUT = "timeout"


@dataclass
class ConnectionConfig:
    """Configuração de conexão"""
    host: Optional[str] = None
    port: Optional[int] = None
    database: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None  # Deve ser criptografado
    connection_string: Optional[str] = None
    ssl_enabled: bool = False
    timeout_seconds: int = 30
    pool_size: int = 5
    max_overflow: int = 10
    additional_params: Dict[str, Any] = field(default_factory=dict)
    
    def get_safe_config(self) -> Dict[str, Any]:
        """Retorna configuração sem informações sensíveis"""
        return {
            "host": self.host,
            "port": self.port,
            "database": self.database,
            "username": self.username,
            "ssl_enabled": self.ssl_enabled,
            "timeout_seconds": self.timeout_seconds,
            "pool_size": self.pool_size,
            "max_overflow": self.max_overflow
        }


@dataclass
class DiscoveryMetrics:
    """Métricas de descoberta"""
    total_tables: int = 0
    total_views: int = 0
    total_columns: int = 0
    total_indexes: int = 0
    total_foreign_keys: int = 0
    total_procedures: int = 0
    total_functions: int = 0
    discovery_duration_seconds: float = 0.0
    last_discovery_at: Optional[datetime] = None
    success_rate: float = 0.0
    error_count: int = 0
    
    def calculate_success_rate(self, total_attempts: int) -> float:
        """Calcula taxa de sucesso"""
        if total_attempts == 0:
            return 0.0
        return ((total_attempts - self.error_count) / total_attempts) * 100.0


@dataclass
class DataSource:
    """
    Entidade que representa uma fonte de dados para descoberta automática
    
    Responsabilidades:
    - Armazenar informações de conexão e configuração
    - Manter histórico de descobertas
    - Controlar status e métricas
    - Validar configurações de conexão
    """
    
    id: UUID = field(default_factory=uuid4)
    name: str = ""
    description: str = ""
    source_type: DataSourceType = DataSourceType.DATABASE
    status: DataSourceStatus = DataSourceStatus.PENDING
    connection_status: ConnectionStatus = ConnectionStatus.DISCONNECTED
    
    # Configuração de conexão
    connection_config: ConnectionConfig = field(default_factory=ConnectionConfig)
    
    # Metadados
    tags: List[str] = field(default_factory=list)
    owner: str = ""
    team: str = ""
    environment: str = "development"  # development, staging, production
    
    # Descoberta automática
    auto_discovery_enabled: bool = True
    discovery_schedule: str = "daily"  # cron expression or predefined
    last_discovery_at: Optional[datetime] = None
    next_discovery_at: Optional[datetime] = None
    discovery_metrics: DiscoveryMetrics = field(default_factory=DiscoveryMetrics)
    
    # Configurações específicas
    discovery_config: Dict[str, Any] = field(default_factory=dict)
    schema_patterns: List[str] = field(default_factory=list)  # Padrões de schema a incluir
    table_patterns: List[str] = field(default_factory=list)   # Padrões de tabela a incluir
    exclude_patterns: List[str] = field(default_factory=list) # Padrões a excluir
    
    # Auditoria
    created_by: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_by: str = ""
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    # Histórico
    discovery_history: List[Dict[str, Any]] = field(default_factory=list)
    error_history: List[Dict[str, Any]] = field(default_factory=list)
    
    def __post_init__(self):
        """Validações pós-inicialização"""
        if not self.name:
            raise ValueError("Nome da fonte de dados é obrigatório")
        
        if not self.owner:
            raise ValueError("Proprietário da fonte de dados é obrigatório")
        
        self._validate_connection_config()
    
    def _validate_connection_config(self):
        """Valida configuração de conexão"""
        if self.source_type == DataSourceType.DATABASE:
            if not self.connection_config.connection_string:
                if not all([
                    self.connection_config.host,
                    self.connection_config.database,
                    self.connection_config.username
                ]):
                    raise ValueError(
                        "Para banco de dados, é necessário connection_string ou "
                        "host, database e username"
                    )
        
        elif self.source_type == DataSourceType.API:
            if not self.connection_config.host:
                raise ValueError("Para API, host é obrigatório")
        
        elif self.source_type == DataSourceType.FILE_SYSTEM:
            if not self.discovery_config.get("base_path"):
                raise ValueError("Para sistema de arquivos, base_path é obrigatório")
    
    def update_status(self, new_status: DataSourceStatus, updated_by: str = "system"):
        """Atualiza status da fonte de dados"""
        old_status = self.status
        self.status = new_status
        self.updated_by = updated_by
        self.updated_at = datetime.utcnow()
        
        # Adicionar ao histórico
        self.discovery_history.append({
            "timestamp": self.updated_at.isoformat(),
            "event": "status_change",
            "old_status": old_status.value,
            "new_status": new_status.value,
            "updated_by": updated_by
        })
    
    def update_connection_status(self, new_status: ConnectionStatus):
        """Atualiza status da conexão"""
        self.connection_status = new_status
        self.updated_at = datetime.utcnow()
    
    def add_discovery_result(self, result: Dict[str, Any]):
        """Adiciona resultado de descoberta ao histórico"""
        discovery_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "result": result,
            "success": result.get("success", False),
            "error_message": result.get("error_message"),
            "metrics": result.get("metrics", {})
        }
        
        self.discovery_history.append(discovery_entry)
        
        # Manter apenas os últimos 100 registros
        if len(self.discovery_history) > 100:
            self.discovery_history = self.discovery_history[-100:]
        
        # Atualizar métricas
        if result.get("success"):
            self.last_discovery_at = datetime.utcnow()
            metrics = result.get("metrics", {})
            self.discovery_metrics.total_tables = metrics.get("total_tables", 0)
            self.discovery_metrics.total_views = metrics.get("total_views", 0)
            self.discovery_metrics.total_columns = metrics.get("total_columns", 0)
            self.discovery_metrics.total_indexes = metrics.get("total_indexes", 0)
            self.discovery_metrics.total_foreign_keys = metrics.get("total_foreign_keys", 0)
            self.discovery_metrics.discovery_duration_seconds = metrics.get("duration_seconds", 0.0)
            self.discovery_metrics.last_discovery_at = self.last_discovery_at
        else:
            self.discovery_metrics.error_count += 1
            self.add_error(result.get("error_message", "Erro desconhecido"))
    
    def add_error(self, error_message: str, error_details: Dict[str, Any] = None):
        """Adiciona erro ao histórico"""
        error_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "message": error_message,
            "details": error_details or {}
        }
        
        self.error_history.append(error_entry)
        
        # Manter apenas os últimos 50 erros
        if len(self.error_history) > 50:
            self.error_history = self.error_history[-50:]
    
    def is_discovery_due(self) -> bool:
        """Verifica se é hora de executar descoberta"""
        if not self.auto_discovery_enabled:
            return False
        
        if not self.last_discovery_at:
            return True
        
        if self.next_discovery_at:
            return datetime.utcnow() >= self.next_discovery_at
        
        # Fallback baseado no schedule
        if self.discovery_schedule == "hourly":
            return (datetime.utcnow() - self.last_discovery_at).total_seconds() >= 3600
        elif self.discovery_schedule == "daily":
            return (datetime.utcnow() - self.last_discovery_at).total_seconds() >= 86400
        elif self.discovery_schedule == "weekly":
            return (datetime.utcnow() - self.last_discovery_at).total_seconds() >= 604800
        
        return False
    
    def get_connection_string(self) -> str:
        """Retorna string de conexão formatada"""
        if self.connection_config.connection_string:
            return self.connection_config.connection_string
        
        if self.source_type == DataSourceType.DATABASE:
            # Construir connection string baseada nos parâmetros
            if self.connection_config.host and self.connection_config.database:
                return (
                    f"postgresql://{self.connection_config.username}:"
                    f"{self.connection_config.password}@"
                    f"{self.connection_config.host}:"
                    f"{self.connection_config.port or 5432}/"
                    f"{self.connection_config.database}"
                )
        
        return ""
    
    def get_discovery_patterns(self) -> Dict[str, List[str]]:
        """Retorna padrões de descoberta configurados"""
        return {
            "schema_patterns": self.schema_patterns or ["*"],
            "table_patterns": self.table_patterns or ["*"],
            "exclude_patterns": self.exclude_patterns or []
        }
    
    def calculate_health_score(self) -> float:
        """Calcula score de saúde da fonte de dados"""
        score = 100.0
        
        # Penalizar por status inativo
        if self.status == DataSourceStatus.INACTIVE:
            score -= 30.0
        elif self.status == DataSourceStatus.ERROR:
            score -= 50.0
        
        # Penalizar por problemas de conexão
        if self.connection_status == ConnectionStatus.FAILED:
            score -= 40.0
        elif self.connection_status == ConnectionStatus.DISCONNECTED:
            score -= 20.0
        
        # Penalizar por descobertas antigas
        if self.last_discovery_at:
            days_since_discovery = (datetime.utcnow() - self.last_discovery_at).days
            if days_since_discovery > 7:
                score -= min(30.0, days_since_discovery * 2)
        else:
            score -= 25.0  # Nunca foi descoberto
        
        # Penalizar por muitos erros
        if len(self.error_history) > 10:
            score -= min(20.0, len(self.error_history) - 10)
        
        return max(0.0, score)
    
    def get_summary(self) -> Dict[str, Any]:
        """Retorna resumo da fonte de dados"""
        return {
            "id": str(self.id),
            "name": self.name,
            "source_type": self.source_type.value,
            "status": self.status.value,
            "connection_status": self.connection_status.value,
            "environment": self.environment,
            "owner": self.owner,
            "team": self.team,
            "auto_discovery_enabled": self.auto_discovery_enabled,
            "last_discovery_at": self.last_discovery_at.isoformat() if self.last_discovery_at else None,
            "health_score": self.calculate_health_score(),
            "metrics": {
                "total_tables": self.discovery_metrics.total_tables,
                "total_views": self.discovery_metrics.total_views,
                "total_columns": self.discovery_metrics.total_columns,
                "error_count": self.discovery_metrics.error_count,
                "success_rate": self.discovery_metrics.calculate_success_rate(
                    len(self.discovery_history)
                )
            },
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat()
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário (serialização completa)"""
        return {
            "id": str(self.id),
            "name": self.name,
            "description": self.description,
            "source_type": self.source_type.value,
            "status": self.status.value,
            "connection_status": self.connection_status.value,
            "connection_config": self.connection_config.get_safe_config(),
            "tags": self.tags,
            "owner": self.owner,
            "team": self.team,
            "environment": self.environment,
            "auto_discovery_enabled": self.auto_discovery_enabled,
            "discovery_schedule": self.discovery_schedule,
            "last_discovery_at": self.last_discovery_at.isoformat() if self.last_discovery_at else None,
            "next_discovery_at": self.next_discovery_at.isoformat() if self.next_discovery_at else None,
            "discovery_config": self.discovery_config,
            "schema_patterns": self.schema_patterns,
            "table_patterns": self.table_patterns,
            "exclude_patterns": self.exclude_patterns,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat(),
            "updated_by": self.updated_by,
            "updated_at": self.updated_at.isoformat(),
            "discovery_metrics": {
                "total_tables": self.discovery_metrics.total_tables,
                "total_views": self.discovery_metrics.total_views,
                "total_columns": self.discovery_metrics.total_columns,
                "total_indexes": self.discovery_metrics.total_indexes,
                "total_foreign_keys": self.discovery_metrics.total_foreign_keys,
                "total_procedures": self.discovery_metrics.total_procedures,
                "total_functions": self.discovery_metrics.total_functions,
                "discovery_duration_seconds": self.discovery_metrics.discovery_duration_seconds,
                "last_discovery_at": self.discovery_metrics.last_discovery_at.isoformat() if self.discovery_metrics.last_discovery_at else None,
                "success_rate": self.discovery_metrics.calculate_success_rate(len(self.discovery_history)),
                "error_count": self.discovery_metrics.error_count
            },
            "health_score": self.calculate_health_score()
        }

