# Autor: carlos.morais@f1rst.com.br
"""
Entidade Discovered Schema para Auto Discovery Service
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Any, Optional
from uuid import UUID, uuid4
from enum import Enum


class SchemaElementType(Enum):
    """Tipos de elementos de schema"""
    TABLE = "table"
    VIEW = "view"
    MATERIALIZED_VIEW = "materialized_view"
    INDEX = "index"
    PROCEDURE = "procedure"
    FUNCTION = "function"
    TRIGGER = "trigger"
    SEQUENCE = "sequence"
    CONSTRAINT = "constraint"
    FOREIGN_KEY = "foreign_key"


class DataType(Enum):
    """Tipos de dados suportados"""
    STRING = "string"
    INTEGER = "integer"
    BIGINT = "bigint"
    DECIMAL = "decimal"
    FLOAT = "float"
    DOUBLE = "double"
    BOOLEAN = "boolean"
    DATE = "date"
    DATETIME = "datetime"
    TIMESTAMP = "timestamp"
    TIME = "time"
    JSON = "json"
    JSONB = "jsonb"
    XML = "xml"
    BINARY = "binary"
    UUID = "uuid"
    ARRAY = "array"
    ENUM = "enum"
    GEOMETRY = "geometry"
    UNKNOWN = "unknown"


class ColumnConstraintType(Enum):
    """Tipos de constraints de coluna"""
    PRIMARY_KEY = "primary_key"
    FOREIGN_KEY = "foreign_key"
    UNIQUE = "unique"
    NOT_NULL = "not_null"
    CHECK = "check"
    DEFAULT = "default"
    INDEX = "index"


@dataclass
class ColumnConstraint:
    """Constraint de coluna"""
    constraint_type: ColumnConstraintType
    name: str = ""
    definition: str = ""
    referenced_table: Optional[str] = None
    referenced_column: Optional[str] = None
    check_condition: Optional[str] = None
    default_value: Optional[str] = None


@dataclass
class DiscoveredColumn:
    """
    Coluna descoberta em uma tabela/view
    """
    name: str
    data_type: DataType
    original_type: str  # Tipo original do banco
    max_length: Optional[int] = None
    precision: Optional[int] = None
    scale: Optional[int] = None
    is_nullable: bool = True
    is_primary_key: bool = False
    is_foreign_key: bool = False
    is_unique: bool = False
    is_indexed: bool = False
    
    # Constraints
    constraints: List[ColumnConstraint] = field(default_factory=list)
    
    # Metadados adicionais
    comment: str = ""
    default_value: Optional[str] = None
    auto_increment: bool = False
    
    # Estatísticas (se disponíveis)
    distinct_count: Optional[int] = None
    null_count: Optional[int] = None
    min_value: Optional[str] = None
    max_value: Optional[str] = None
    avg_length: Optional[float] = None
    
    # Classificação automática
    inferred_classification: Optional[str] = None  # PII, SENSITIVE, etc.
    confidence_score: float = 0.0
    
    def __post_init__(self):
        """Validações pós-inicialização"""
        if not self.name:
            raise ValueError("Nome da coluna é obrigatório")
        
        # Inferir classificação baseada no nome
        self._infer_classification()
    
    def _infer_classification(self):
        """Infere classificação da coluna baseada no nome e tipo"""
        name_lower = self.name.lower()
        
        # Dados pessoais identificáveis (PII)
        pii_patterns = [
            'email', 'cpf', 'cnpj', 'rg', 'passport', 'ssn',
            'phone', 'telefone', 'celular', 'address', 'endereco',
            'name', 'nome', 'surname', 'sobrenome', 'birth', 'nascimento'
        ]
        
        # Dados sensíveis
        sensitive_patterns = [
            'password', 'senha', 'token', 'secret', 'key',
            'salary', 'salario', 'income', 'renda', 'credit',
            'medical', 'health', 'saude'
        ]
        
        # Dados financeiros
        financial_patterns = [
            'account', 'conta', 'balance', 'saldo', 'amount',
            'valor', 'price', 'preco', 'cost', 'custo'
        ]
        
        if any(pattern in name_lower for pattern in pii_patterns):
            self.inferred_classification = "PII"
            self.confidence_score = 0.8
        elif any(pattern in name_lower for pattern in sensitive_patterns):
            self.inferred_classification = "SENSITIVE"
            self.confidence_score = 0.9
        elif any(pattern in name_lower for pattern in financial_patterns):
            self.inferred_classification = "FINANCIAL"
            self.confidence_score = 0.7
        else:
            self.inferred_classification = "PUBLIC"
            self.confidence_score = 0.6
    
    def add_constraint(self, constraint: ColumnConstraint):
        """Adiciona constraint à coluna"""
        self.constraints.append(constraint)
        
        # Atualizar flags baseadas na constraint
        if constraint.constraint_type == ColumnConstraintType.PRIMARY_KEY:
            self.is_primary_key = True
            self.is_nullable = False
        elif constraint.constraint_type == ColumnConstraintType.FOREIGN_KEY:
            self.is_foreign_key = True
        elif constraint.constraint_type == ColumnConstraintType.UNIQUE:
            self.is_unique = True
        elif constraint.constraint_type == ColumnConstraintType.NOT_NULL:
            self.is_nullable = False
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            "name": self.name,
            "data_type": self.data_type.value,
            "original_type": self.original_type,
            "max_length": self.max_length,
            "precision": self.precision,
            "scale": self.scale,
            "is_nullable": self.is_nullable,
            "is_primary_key": self.is_primary_key,
            "is_foreign_key": self.is_foreign_key,
            "is_unique": self.is_unique,
            "is_indexed": self.is_indexed,
            "comment": self.comment,
            "default_value": self.default_value,
            "auto_increment": self.auto_increment,
            "constraints": [
                {
                    "type": c.constraint_type.value,
                    "name": c.name,
                    "definition": c.definition,
                    "referenced_table": c.referenced_table,
                    "referenced_column": c.referenced_column
                }
                for c in self.constraints
            ],
            "statistics": {
                "distinct_count": self.distinct_count,
                "null_count": self.null_count,
                "min_value": self.min_value,
                "max_value": self.max_value,
                "avg_length": self.avg_length
            },
            "classification": {
                "inferred_classification": self.inferred_classification,
                "confidence_score": self.confidence_score
            }
        }


@dataclass
class DiscoveredIndex:
    """Índice descoberto"""
    name: str
    table_name: str
    columns: List[str]
    is_unique: bool = False
    is_primary: bool = False
    index_type: str = "btree"
    definition: str = ""
    size_bytes: Optional[int] = None


@dataclass
class DiscoveredTable:
    """
    Tabela/View descoberta
    """
    name: str
    schema_name: str = "public"
    element_type: SchemaElementType = SchemaElementType.TABLE
    columns: List[DiscoveredColumn] = field(default_factory=list)
    indexes: List[DiscoveredIndex] = field(default_factory=list)
    
    # Metadados
    comment: str = ""
    owner: str = ""
    
    # Estatísticas
    row_count: Optional[int] = None
    size_bytes: Optional[int] = None
    last_analyzed: Optional[datetime] = None
    
    # Relacionamentos
    foreign_keys: List[Dict[str, Any]] = field(default_factory=list)
    referenced_by: List[Dict[str, Any]] = field(default_factory=list)
    
    # Classificação
    inferred_purpose: Optional[str] = None  # TRANSACTIONAL, ANALYTICAL, LOOKUP, etc.
    business_domain: Optional[str] = None   # CUSTOMER, PRODUCT, ORDER, etc.
    
    def __post_init__(self):
        """Validações pós-inicialização"""
        if not self.name:
            raise ValueError("Nome da tabela é obrigatório")
        
        self._infer_purpose()
        self._infer_business_domain()
    
    def _infer_purpose(self):
        """Infere propósito da tabela"""
        name_lower = self.name.lower()
        
        # Tabelas de lookup/dimensão
        if any(pattern in name_lower for pattern in ['dim_', 'lookup_', 'ref_', 'master_']):
            self.inferred_purpose = "LOOKUP"
        # Tabelas de fato/transacional
        elif any(pattern in name_lower for pattern in ['fact_', 'trans_', 'order_', 'sale_']):
            self.inferred_purpose = "TRANSACTIONAL"
        # Tabelas de log/auditoria
        elif any(pattern in name_lower for pattern in ['log_', 'audit_', 'history_']):
            self.inferred_purpose = "AUDIT"
        # Tabelas de configuração
        elif any(pattern in name_lower for pattern in ['config_', 'setting_', 'param_']):
            self.inferred_purpose = "CONFIGURATION"
        else:
            self.inferred_purpose = "OPERATIONAL"
    
    def _infer_business_domain(self):
        """Infere domínio de negócio da tabela"""
        name_lower = self.name.lower()
        
        # Domínios comuns
        if any(pattern in name_lower for pattern in ['customer', 'client', 'user', 'person']):
            self.business_domain = "CUSTOMER"
        elif any(pattern in name_lower for pattern in ['product', 'item', 'catalog']):
            self.business_domain = "PRODUCT"
        elif any(pattern in name_lower for pattern in ['order', 'sale', 'purchase', 'transaction']):
            self.business_domain = "SALES"
        elif any(pattern in name_lower for pattern in ['employee', 'staff', 'hr']):
            self.business_domain = "HR"
        elif any(pattern in name_lower for pattern in ['finance', 'accounting', 'payment']):
            self.business_domain = "FINANCE"
        elif any(pattern in name_lower for pattern in ['inventory', 'stock', 'warehouse']):
            self.business_domain = "INVENTORY"
        else:
            self.business_domain = "GENERAL"
    
    def add_column(self, column: DiscoveredColumn):
        """Adiciona coluna à tabela"""
        self.columns.append(column)
    
    def add_index(self, index: DiscoveredIndex):
        """Adiciona índice à tabela"""
        self.indexes.append(index)
    
    def get_primary_key_columns(self) -> List[str]:
        """Retorna colunas da chave primária"""
        return [col.name for col in self.columns if col.is_primary_key]
    
    def get_foreign_key_columns(self) -> List[str]:
        """Retorna colunas de chave estrangeira"""
        return [col.name for col in self.columns if col.is_foreign_key]
    
    def get_columns_by_classification(self, classification: str) -> List[DiscoveredColumn]:
        """Retorna colunas por classificação"""
        return [col for col in self.columns if col.inferred_classification == classification]
    
    def calculate_complexity_score(self) -> float:
        """Calcula score de complexidade da tabela"""
        score = 0.0
        
        # Número de colunas
        score += len(self.columns) * 0.5
        
        # Número de índices
        score += len(self.indexes) * 1.0
        
        # Número de foreign keys
        score += len(self.foreign_keys) * 2.0
        
        # Número de constraints
        constraint_count = sum(len(col.constraints) for col in self.columns)
        score += constraint_count * 0.5
        
        return score
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            "name": self.name,
            "schema_name": self.schema_name,
            "element_type": self.element_type.value,
            "comment": self.comment,
            "owner": self.owner,
            "columns": [col.to_dict() for col in self.columns],
            "indexes": [
                {
                    "name": idx.name,
                    "columns": idx.columns,
                    "is_unique": idx.is_unique,
                    "is_primary": idx.is_primary,
                    "index_type": idx.index_type,
                    "definition": idx.definition,
                    "size_bytes": idx.size_bytes
                }
                for idx in self.indexes
            ],
            "statistics": {
                "row_count": self.row_count,
                "size_bytes": self.size_bytes,
                "last_analyzed": self.last_analyzed.isoformat() if self.last_analyzed else None,
                "complexity_score": self.calculate_complexity_score()
            },
            "relationships": {
                "foreign_keys": self.foreign_keys,
                "referenced_by": self.referenced_by
            },
            "classification": {
                "inferred_purpose": self.inferred_purpose,
                "business_domain": self.business_domain
            }
        }


@dataclass
class DiscoveredSchema:
    """
    Schema completo descoberto de uma fonte de dados
    
    Responsabilidades:
    - Armazenar estrutura completa descoberta
    - Manter metadados de descoberta
    - Calcular métricas e estatísticas
    - Comparar com versões anteriores
    """
    
    id: UUID = field(default_factory=uuid4)
    data_source_id: UUID = field(default_factory=uuid4)
    schema_name: str = ""
    database_name: str = ""
    
    # Elementos descobertos
    tables: List[DiscoveredTable] = field(default_factory=list)
    views: List[DiscoveredTable] = field(default_factory=list)
    procedures: List[Dict[str, Any]] = field(default_factory=list)
    functions: List[Dict[str, Any]] = field(default_factory=list)
    
    # Metadados de descoberta
    discovery_timestamp: datetime = field(default_factory=datetime.utcnow)
    discovery_duration_seconds: float = 0.0
    discovery_method: str = "automatic"
    discovery_version: str = "1.0.0"
    
    # Configuração usada
    discovery_config: Dict[str, Any] = field(default_factory=dict)
    patterns_used: Dict[str, List[str]] = field(default_factory=dict)
    
    # Estatísticas gerais
    total_elements: int = 0
    total_columns: int = 0
    total_indexes: int = 0
    total_constraints: int = 0
    
    # Classificações
    classification_summary: Dict[str, int] = field(default_factory=dict)
    domain_summary: Dict[str, int] = field(default_factory=dict)
    
    # Comparação com versão anterior
    previous_schema_id: Optional[UUID] = None
    changes_detected: List[Dict[str, Any]] = field(default_factory=list)
    
    # Qualidade da descoberta
    discovery_quality_score: float = 0.0
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Cálculos pós-inicialização"""
        self._calculate_statistics()
        self._calculate_quality_score()
    
    def _calculate_statistics(self):
        """Calcula estatísticas do schema"""
        all_tables = self.tables + self.views
        
        self.total_elements = len(all_tables) + len(self.procedures) + len(self.functions)
        self.total_columns = sum(len(table.columns) for table in all_tables)
        self.total_indexes = sum(len(table.indexes) for table in all_tables)
        self.total_constraints = sum(
            sum(len(col.constraints) for col in table.columns)
            for table in all_tables
        )
        
        # Resumo de classificações
        self.classification_summary = {}
        self.domain_summary = {}
        
        for table in all_tables:
            # Classificação por propósito
            purpose = table.inferred_purpose or "UNKNOWN"
            self.classification_summary[purpose] = self.classification_summary.get(purpose, 0) + 1
            
            # Classificação por domínio
            domain = table.business_domain or "UNKNOWN"
            self.domain_summary[domain] = self.domain_summary.get(domain, 0) + 1
    
    def _calculate_quality_score(self):
        """Calcula score de qualidade da descoberta"""
        score = 100.0
        
        # Penalizar por elementos sem metadados
        elements_without_comments = sum(
            1 for table in (self.tables + self.views)
            if not table.comment
        )
        if elements_without_comments > 0:
            score -= min(20.0, elements_without_comments * 2)
        
        # Penalizar por colunas sem classificação
        unclassified_columns = sum(
            1 for table in (self.tables + self.views)
            for col in table.columns
            if not col.inferred_classification or col.confidence_score < 0.5
        )
        if unclassified_columns > 0:
            score -= min(15.0, unclassified_columns * 0.5)
        
        # Penalizar por erros
        score -= len(self.errors) * 5.0
        
        # Penalizar por warnings
        score -= len(self.warnings) * 1.0
        
        self.discovery_quality_score = max(0.0, score)
    
    def add_table(self, table: DiscoveredTable):
        """Adiciona tabela ao schema"""
        if table.element_type == SchemaElementType.VIEW:
            self.views.append(table)
        else:
            self.tables.append(table)
        
        self._calculate_statistics()
    
    def add_warning(self, message: str):
        """Adiciona warning"""
        self.warnings.append(message)
        self._calculate_quality_score()
    
    def add_error(self, message: str):
        """Adiciona erro"""
        self.errors.append(message)
        self._calculate_quality_score()
    
    def find_table(self, table_name: str, schema_name: str = None) -> Optional[DiscoveredTable]:
        """Encontra tabela por nome"""
        for table in self.tables + self.views:
            if table.name == table_name:
                if schema_name is None or table.schema_name == schema_name:
                    return table
        return None
    
    def get_tables_by_domain(self, domain: str) -> List[DiscoveredTable]:
        """Retorna tabelas por domínio de negócio"""
        return [
            table for table in self.tables + self.views
            if table.business_domain == domain
        ]
    
    def get_pii_columns(self) -> List[Dict[str, Any]]:
        """Retorna todas as colunas com dados pessoais"""
        pii_columns = []
        
        for table in self.tables + self.views:
            for column in table.get_columns_by_classification("PII"):
                pii_columns.append({
                    "table_name": table.name,
                    "schema_name": table.schema_name,
                    "column_name": column.name,
                    "data_type": column.data_type.value,
                    "confidence_score": column.confidence_score
                })
        
        return pii_columns
    
    def compare_with_previous(self, previous_schema: 'DiscoveredSchema'):
        """Compara com schema anterior e detecta mudanças"""
        self.previous_schema_id = previous_schema.id
        self.changes_detected = []
        
        # Comparar tabelas
        current_tables = {t.name: t for t in self.tables}
        previous_tables = {t.name: t for t in previous_schema.tables}
        
        # Tabelas adicionadas
        for table_name in current_tables.keys() - previous_tables.keys():
            self.changes_detected.append({
                "type": "table_added",
                "table_name": table_name,
                "timestamp": self.discovery_timestamp.isoformat()
            })
        
        # Tabelas removidas
        for table_name in previous_tables.keys() - current_tables.keys():
            self.changes_detected.append({
                "type": "table_removed",
                "table_name": table_name,
                "timestamp": self.discovery_timestamp.isoformat()
            })
        
        # Tabelas modificadas
        for table_name in current_tables.keys() & previous_tables.keys():
            current_table = current_tables[table_name]
            previous_table = previous_tables[table_name]
            
            # Comparar colunas
            current_columns = {c.name: c for c in current_table.columns}
            previous_columns = {c.name: c for c in previous_table.columns}
            
            # Colunas adicionadas
            for col_name in current_columns.keys() - previous_columns.keys():
                self.changes_detected.append({
                    "type": "column_added",
                    "table_name": table_name,
                    "column_name": col_name,
                    "timestamp": self.discovery_timestamp.isoformat()
                })
            
            # Colunas removidas
            for col_name in previous_columns.keys() - current_columns.keys():
                self.changes_detected.append({
                    "type": "column_removed",
                    "table_name": table_name,
                    "column_name": col_name,
                    "timestamp": self.discovery_timestamp.isoformat()
                })
    
    def generate_summary_report(self) -> Dict[str, Any]:
        """Gera relatório resumido da descoberta"""
        return {
            "schema_id": str(self.id),
            "data_source_id": str(self.data_source_id),
            "schema_name": self.schema_name,
            "database_name": self.database_name,
            "discovery_timestamp": self.discovery_timestamp.isoformat(),
            "discovery_duration_seconds": self.discovery_duration_seconds,
            "discovery_quality_score": self.discovery_quality_score,
            "statistics": {
                "total_elements": self.total_elements,
                "total_tables": len(self.tables),
                "total_views": len(self.views),
                "total_procedures": len(self.procedures),
                "total_functions": len(self.functions),
                "total_columns": self.total_columns,
                "total_indexes": self.total_indexes,
                "total_constraints": self.total_constraints
            },
            "classification_summary": self.classification_summary,
            "domain_summary": self.domain_summary,
            "data_privacy": {
                "pii_columns_count": len(self.get_pii_columns()),
                "sensitive_tables": len([
                    t for t in self.tables + self.views
                    if any(col.inferred_classification in ["PII", "SENSITIVE"] for col in t.columns)
                ])
            },
            "changes": {
                "previous_schema_id": str(self.previous_schema_id) if self.previous_schema_id else None,
                "changes_count": len(self.changes_detected),
                "changes_summary": {
                    change_type: len([c for c in self.changes_detected if c["type"] == change_type])
                    for change_type in set(c["type"] for c in self.changes_detected)
                }
            },
            "quality": {
                "warnings_count": len(self.warnings),
                "errors_count": len(self.errors),
                "top_warnings": self.warnings[:5],
                "top_errors": self.errors[:5]
            }
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário (serialização completa)"""
        return {
            "id": str(self.id),
            "data_source_id": str(self.data_source_id),
            "schema_name": self.schema_name,
            "database_name": self.database_name,
            "discovery_timestamp": self.discovery_timestamp.isoformat(),
            "discovery_duration_seconds": self.discovery_duration_seconds,
            "discovery_method": self.discovery_method,
            "discovery_version": self.discovery_version,
            "discovery_config": self.discovery_config,
            "patterns_used": self.patterns_used,
            "tables": [table.to_dict() for table in self.tables],
            "views": [view.to_dict() for view in self.views],
            "procedures": self.procedures,
            "functions": self.functions,
            "statistics": {
                "total_elements": self.total_elements,
                "total_columns": self.total_columns,
                "total_indexes": self.total_indexes,
                "total_constraints": self.total_constraints
            },
            "classification_summary": self.classification_summary,
            "domain_summary": self.domain_summary,
            "previous_schema_id": str(self.previous_schema_id) if self.previous_schema_id else None,
            "changes_detected": self.changes_detected,
            "discovery_quality_score": self.discovery_quality_score,
            "warnings": self.warnings,
            "errors": self.errors
        }

