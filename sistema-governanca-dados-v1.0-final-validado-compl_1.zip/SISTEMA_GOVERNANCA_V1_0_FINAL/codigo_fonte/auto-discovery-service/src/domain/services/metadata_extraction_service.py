"""
Serviço de extração de metadados
Autor: carlos.morais@f1rst.com.br
"""

from typing import Dict, Any, List
from datetime import datetime
import logging
import hashlib
import json

logger = logging.getLogger(__name__)

class MetadataExtractionService:
    """Serviço para extração automática de metadados"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        
    def extract_table_metadata(self, table_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extrai metadados completos de uma tabela
        
        Args:
            table_info: Informações básicas da tabela
            
        Returns:
            Dict com metadados extraídos
        """
        metadata = {
            "table_name": table_info["name"],
            "extraction_timestamp": datetime.utcnow().isoformat(),
            "technical_metadata": self._extract_technical_metadata(table_info),
            "business_metadata": self._extract_business_metadata(table_info),
            "quality_metadata": self._extract_quality_metadata(table_info),
            "lineage_metadata": self._extract_lineage_metadata(table_info),
            "security_metadata": self._extract_security_metadata(table_info)
        }
        
        # Gerar hash único para versionamento
        metadata["metadata_hash"] = self._generate_metadata_hash(metadata)
        
        return metadata
        
    def _extract_technical_metadata(self, table_info: Dict[str, Any]) -> Dict[str, Any]:
        """Extrai metadados técnicos"""
        return {
            "column_count": len(table_info.get("columns", [])),
            "primary_key_columns": table_info.get("primary_keys", []),
            "foreign_key_count": len(table_info.get("foreign_keys", [])),
            "index_count": len(table_info.get("indexes", [])),
            "estimated_size": table_info.get("estimated_rows", "unknown"),
            "data_types": [col["type"] for col in table_info.get("columns", [])],
            "nullable_columns": [
                col["name"] for col in table_info.get("columns", [])
                if col.get("nullable", True)
            ]
        }
        
    def _extract_business_metadata(self, table_info: Dict[str, Any]) -> Dict[str, Any]:
        """Extrai metadados de negócio"""
        table_name = table_info["name"]
        
        # Inferir contexto de negócio baseado no nome da tabela
        business_context = self._infer_business_context(table_name)
        
        return {
            "business_domain": business_context["domain"],
            "business_process": business_context["process"],
            "data_owner": business_context["owner"],
            "business_rules": self._extract_business_rules(table_info),
            "glossary_terms": self._extract_glossary_terms(table_info),
            "business_criticality": self._assess_business_criticality(table_info)
        }
        
    def _extract_quality_metadata(self, table_info: Dict[str, Any]) -> Dict[str, Any]:
        """Extrai metadados de qualidade"""
        return {
            "completeness_score": self._calculate_completeness(table_info),
            "uniqueness_constraints": self._identify_uniqueness_constraints(table_info),
            "referential_integrity": self._check_referential_integrity(table_info),
            "data_freshness": self._assess_data_freshness(table_info),
            "quality_rules": self._generate_quality_rules(table_info)
        }
        
    def _extract_lineage_metadata(self, table_info: Dict[str, Any]) -> Dict[str, Any]:
        """Extrai metadados de linhagem"""
        return {
            "upstream_dependencies": self._identify_upstream_tables(table_info),
            "downstream_consumers": self._identify_downstream_tables(table_info),
            "transformation_logic": self._extract_transformation_logic(table_info),
            "data_flow_patterns": self._analyze_data_flow_patterns(table_info)
        }
        
    def _extract_security_metadata(self, table_info: Dict[str, Any]) -> Dict[str, Any]:
        """Extrai metadados de segurança"""
        return {
            "data_classification": table_info.get("data_classification", "public"),
            "pii_columns": self._identify_pii_columns(table_info),
            "access_patterns": self._analyze_access_patterns(table_info),
            "encryption_requirements": self._assess_encryption_needs(table_info),
            "retention_policy": self._determine_retention_policy(table_info)
        }
        
    def _infer_business_context(self, table_name: str) -> Dict[str, str]:
        """Infere contexto de negócio baseado no nome da tabela"""
        domain_mapping = {
            "customer": "Customer Management",
            "product": "Product Management",
            "order": "Order Management",
            "payment": "Financial",
            "user": "User Management",
            "contract": "Contract Management",
            "quality": "Data Quality",
            "audit": "Audit & Compliance"
        }
        
        table_lower = table_name.lower()
        for key, domain in domain_mapping.items():
            if key in table_lower:
                return {
                    "domain": domain,
                    "process": f"{domain} Process",
                    "owner": f"{domain} Team"
                }
                
        return {
            "domain": "General",
            "process": "General Process",
            "owner": "Data Team"
        }
        
    def _generate_metadata_hash(self, metadata: Dict[str, Any]) -> str:
        """Gera hash único para os metadados"""
        metadata_str = json.dumps(metadata, sort_keys=True, default=str)
        return hashlib.md5(metadata_str.encode()).hexdigest()
        
    def _calculate_completeness(self, table_info: Dict[str, Any]) -> float:
        """Calcula score de completude"""
        columns = table_info.get("columns", [])
        if not columns:
            return 0.0
            
        nullable_count = sum(1 for col in columns if col.get("nullable", True))
        return 1.0 - (nullable_count / len(columns))
        
    def _identify_pii_columns(self, table_info: Dict[str, Any]) -> List[str]:
        """Identifica colunas com dados pessoais"""
        pii_patterns = [
            "cpf", "cnpj", "email", "phone", "telefone", "rg", "passport",
            "credit_card", "cartao", "ssn", "birth_date", "nascimento"
        ]
        
        pii_columns = []
        for column in table_info.get("columns", []):
            column_name = column["name"].lower()
            if any(pattern in column_name for pattern in pii_patterns):
                pii_columns.append(column["name"])
                
        return pii_columns
        
    # Métodos auxiliares simplificados
    def _extract_business_rules(self, table_info: Dict[str, Any]) -> List[str]:
        return ["Business rules to be defined"]
        
    def _extract_glossary_terms(self, table_info: Dict[str, Any]) -> List[str]:
        return ["Glossary terms to be defined"]
        
    def _assess_business_criticality(self, table_info: Dict[str, Any]) -> str:
        return "medium"
        
    def _identify_uniqueness_constraints(self, table_info: Dict[str, Any]) -> List[str]:
        return table_info.get("primary_keys", [])
        
    def _check_referential_integrity(self, table_info: Dict[str, Any]) -> bool:
        return len(table_info.get("foreign_keys", [])) > 0
        
    def _assess_data_freshness(self, table_info: Dict[str, Any]) -> str:
        return "unknown"
        
    def _generate_quality_rules(self, table_info: Dict[str, Any]) -> List[str]:
        return ["Quality rules to be defined"]
        
    def _identify_upstream_tables(self, table_info: Dict[str, Any]) -> List[str]:
        return [fk["referred_table"] for fk in table_info.get("foreign_keys", [])]
        
    def _identify_downstream_tables(self, table_info: Dict[str, Any]) -> List[str]:
        return ["Downstream analysis required"]
        
    def _extract_transformation_logic(self, table_info: Dict[str, Any]) -> str:
        return "Transformation logic to be analyzed"
        
    def _analyze_data_flow_patterns(self, table_info: Dict[str, Any]) -> List[str]:
        return ["Data flow patterns to be analyzed"]
        
    def _analyze_access_patterns(self, table_info: Dict[str, Any]) -> Dict[str, Any]:
        return {"analysis": "Access patterns to be analyzed"}
        
    def _assess_encryption_needs(self, table_info: Dict[str, Any]) -> bool:
        return len(self._identify_pii_columns(table_info)) > 0
        
    def _determine_retention_policy(self, table_info: Dict[str, Any]) -> str:
        if self._identify_pii_columns(table_info):
            return "7 years (LGPD compliance)"
        return "Standard retention policy"
