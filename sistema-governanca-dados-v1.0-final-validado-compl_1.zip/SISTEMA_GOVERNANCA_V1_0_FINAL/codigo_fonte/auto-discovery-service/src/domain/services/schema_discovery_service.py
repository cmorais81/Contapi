"""
Serviço de descoberta automática de schemas
Autor: carlos.morais@f1rst.com.br
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
import logging
from sqlalchemy import inspect, MetaData, create_engine
from sqlalchemy.exc import SQLAlchemyError

logger = logging.getLogger(__name__)

class SchemaDiscoveryService:
    """Serviço para descoberta automática de schemas de banco de dados"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.discovered_schemas = {}
        
    def discover_database_schema(self, connection_string: str) -> Dict[str, Any]:
        """
        Descobre automaticamente o schema de um banco de dados
        
        Args:
            connection_string: String de conexão com o banco
            
        Returns:
            Dict com informações do schema descoberto
        """
        try:
            engine = create_engine(connection_string)
            inspector = inspect(engine)
            
            schema_info = {
                "database_type": engine.dialect.name,
                "discovery_timestamp": datetime.utcnow().isoformat(),
                "tables": [],
                "views": [],
                "indexes": [],
                "foreign_keys": []
            }
            
            # Descobrir tabelas
            for table_name in inspector.get_table_names():
                table_info = self._analyze_table(inspector, table_name)
                schema_info["tables"].append(table_info)
                
            # Descobrir views
            for view_name in inspector.get_view_names():
                view_info = self._analyze_view(inspector, view_name)
                schema_info["views"].append(view_info)
                
            logger.info(f"Schema descoberto: {len(schema_info['tables'])} tabelas, {len(schema_info['views'])} views")
            return schema_info
            
        except SQLAlchemyError as e:
            logger.error(f"Erro ao descobrir schema: {e}")
            raise
            
    def _analyze_table(self, inspector, table_name: str) -> Dict[str, Any]:
        """Analisa uma tabela específica"""
        columns = inspector.get_columns(table_name)
        primary_keys = inspector.get_pk_constraint(table_name)
        foreign_keys = inspector.get_foreign_keys(table_name)
        indexes = inspector.get_indexes(table_name)
        
        return {
            "name": table_name,
            "type": "table",
            "columns": [
                {
                    "name": col["name"],
                    "type": str(col["type"]),
                    "nullable": col["nullable"],
                    "default": col.get("default"),
                    "autoincrement": col.get("autoincrement", False)
                }
                for col in columns
            ],
            "primary_keys": primary_keys.get("constrained_columns", []),
            "foreign_keys": [
                {
                    "constrained_columns": fk["constrained_columns"],
                    "referred_table": fk["referred_table"],
                    "referred_columns": fk["referred_columns"]
                }
                for fk in foreign_keys
            ],
            "indexes": [
                {
                    "name": idx["name"],
                    "columns": idx["column_names"],
                    "unique": idx["unique"]
                }
                for idx in indexes
            ],
            "estimated_rows": self._estimate_table_size(table_name),
            "data_classification": self._classify_data_sensitivity(columns)
        }
        
    def _analyze_view(self, inspector, view_name: str) -> Dict[str, Any]:
        """Analisa uma view específica"""
        columns = inspector.get_columns(view_name)
        
        return {
            "name": view_name,
            "type": "view",
            "columns": [
                {
                    "name": col["name"],
                    "type": str(col["type"]),
                    "nullable": col["nullable"]
                }
                for col in columns
            ],
            "data_classification": self._classify_data_sensitivity(columns)
        }
        
    def _estimate_table_size(self, table_name: str) -> str:
        """Estima o tamanho da tabela"""
        # Implementação simplificada - em produção usaria estatísticas reais
        return "unknown"
        
    def _classify_data_sensitivity(self, columns: List[Dict]) -> str:
        """Classifica a sensibilidade dos dados baseado nos nomes das colunas"""
        sensitive_patterns = [
            "cpf", "cnpj", "email", "phone", "telefone", "password", "senha",
            "credit_card", "cartao", "ssn", "rg", "passport", "passaporte"
        ]
        
        for column in columns:
            column_name = column["name"].lower()
            if any(pattern in column_name for pattern in sensitive_patterns):
                return "sensitive"
                
        return "public"
        
    def discover_api_endpoints(self, base_url: str) -> Dict[str, Any]:
        """
        Descobre endpoints de APIs automaticamente
        
        Args:
            base_url: URL base da API
            
        Returns:
            Dict com informações dos endpoints descobertos
        """
        # Implementação para descoberta de APIs via OpenAPI/Swagger
        endpoints_info = {
            "base_url": base_url,
            "discovery_timestamp": datetime.utcnow().isoformat(),
            "endpoints": [],
            "schemas": []
        }
        
        # Aqui seria implementada a lógica de descoberta via OpenAPI
        logger.info(f"Descoberta de API iniciada para: {base_url}")
        
        return endpoints_info
        
    def discover_file_schemas(self, file_path: str) -> Dict[str, Any]:
        """
        Descobre schemas de arquivos (CSV, JSON, Parquet, etc.)
        
        Args:
            file_path: Caminho para o arquivo
            
        Returns:
            Dict com informações do schema do arquivo
        """
        file_extension = Path(file_path).suffix.lower()
        
        schema_info = {
            "file_path": file_path,
            "file_type": file_extension,
            "discovery_timestamp": datetime.utcnow().isoformat(),
            "schema": {},
            "sample_data": []
        }
        
        if file_extension == ".csv":
            schema_info.update(self._discover_csv_schema(file_path))
        elif file_extension == ".json":
            schema_info.update(self._discover_json_schema(file_path))
        elif file_extension == ".parquet":
            schema_info.update(self._discover_parquet_schema(file_path))
            
        return schema_info
        
    def _discover_csv_schema(self, file_path: str) -> Dict[str, Any]:
        """Descobre schema de arquivo CSV"""
        try:
            import pandas as pd
            df = pd.read_csv(file_path, nrows=1000)  # Amostra
            
            return {
                "columns": [
                    {
                        "name": col,
                        "type": str(df[col].dtype),
                        "null_count": int(df[col].isnull().sum()),
                        "unique_count": int(df[col].nunique())
                    }
                    for col in df.columns
                ],
                "row_count": len(df),
                "sample_data": df.head(5).to_dict("records")
            }
        except Exception as e:
            logger.error(f"Erro ao analisar CSV {file_path}: {e}")
            return {"error": str(e)}
            
    def _discover_json_schema(self, file_path: str) -> Dict[str, Any]:
        """Descobre schema de arquivo JSON"""
        try:
            import json
            with open(file_path, 'r') as f:
                data = json.load(f)
                
            return {
                "schema": self._infer_json_schema(data),
                "sample_data": data if isinstance(data, list) else [data]
            }
        except Exception as e:
            logger.error(f"Erro ao analisar JSON {file_path}: {e}")
            return {"error": str(e)}
            
    def _discover_parquet_schema(self, file_path: str) -> Dict[str, Any]:
        """Descobre schema de arquivo Parquet"""
        try:
            import pandas as pd
            df = pd.read_parquet(file_path)
            
            return {
                "columns": [
                    {
                        "name": col,
                        "type": str(df[col].dtype),
                        "null_count": int(df[col].isnull().sum()),
                        "unique_count": int(df[col].nunique())
                    }
                    for col in df.columns
                ],
                "row_count": len(df),
                "sample_data": df.head(5).to_dict("records")
            }
        except Exception as e:
            logger.error(f"Erro ao analisar Parquet {file_path}: {e}")
            return {"error": str(e)}
            
    def _infer_json_schema(self, data: Any) -> Dict[str, Any]:
        """Infere schema de dados JSON"""
        if isinstance(data, dict):
            return {
                "type": "object",
                "properties": {
                    key: self._infer_json_schema(value)
                    for key, value in data.items()
                }
            }
        elif isinstance(data, list):
            if data:
                return {
                    "type": "array",
                    "items": self._infer_json_schema(data[0])
                }
            else:
                return {"type": "array", "items": {}}
        elif isinstance(data, str):
            return {"type": "string"}
        elif isinstance(data, int):
            return {"type": "integer"}
        elif isinstance(data, float):
            return {"type": "number"}
        elif isinstance(data, bool):
            return {"type": "boolean"}
        else:
            return {"type": "null"}
