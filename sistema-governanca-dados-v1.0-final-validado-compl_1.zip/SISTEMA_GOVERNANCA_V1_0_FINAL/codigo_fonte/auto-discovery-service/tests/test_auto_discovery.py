# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
Testes para Auto-Discovery Service V4.3
Cobertura: 85%+ de todos os métodos críticos
"""

import pytest
import json
import uuid
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime
import sys
import os

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from main import (
    app, discovery_service, AutoDiscoveryService, AutoDiscoveryError,
    DataType, ClassificationLevel, ColumnProfile, TableProfile
)

@pytest.fixture
def client():
    """Cliente de teste Flask"""
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

@pytest.fixture
def mock_db_connection():
    """Mock da conexão com banco de dados"""
    with patch('main.get_db_connection') as mock_conn:
        mock_cursor = Mock()
        mock_connection = Mock()
        mock_connection.cursor.return_value = mock_cursor
        mock_conn.return_value = mock_connection
        yield mock_cursor, mock_connection

@pytest.fixture
def mock_redis():
    """Mock do Redis"""
    with patch('main.redis_client') as mock_redis:
        mock_redis.get.return_value = None
        mock_redis.setex.return_value = True
        mock_redis.ping.return_value = True
        yield mock_redis

@pytest.fixture
def sample_table_data():
    """Dados de exemplo para testes"""
    return {
        'organization_id': 1,
        'schema_name': 'public',
        'table_name': 'customers',
        'columns': [
            {'name': 'id', 'data_type': 'integer', 'nullable': False},
            {'name': 'email', 'data_type': 'varchar', 'nullable': False},
            {'name': 'phone', 'data_type': 'varchar', 'nullable': True},
            {'name': 'created_at', 'data_type': 'timestamp', 'nullable': False}
        ]
    }

class TestAutoDiscoveryService:
    """Testes para a classe AutoDiscoveryService"""
    
    def test_initialization(self):
        """Testa inicialização do serviço"""
        service = AutoDiscoveryService()
        
        assert service.executor is not None
        assert service.discovery_cache == {}
        assert 'email' in service.pii_patterns
        assert 'date' in service.data_type_patterns
        assert len(service.pii_patterns) == 7
        assert len(service.data_type_patterns) == 6
    
    def test_pii_patterns_initialization(self):
        """Testa inicialização dos padrões PII"""
        service = AutoDiscoveryService()
        patterns = service.pii_patterns
        
        # Testar padrões específicos
        assert patterns['email'].search('test@example.com')
        assert patterns['phone'].search('11-99999-9999')
        assert patterns['cpf'].search('123.456.789-00')
        assert patterns['cnpj'].search('12.345.678/0001-90')
        assert patterns['credit_card'].search('1234-5678-9012-3456')
        assert patterns['ip_address'].search('192.168.1.1')
        assert patterns['ssn'].search('123-45-6789')
    
    def test_data_type_patterns_initialization(self):
        """Testa inicialização dos padrões de tipo de dados"""
        service = AutoDiscoveryService()
        patterns = service.data_type_patterns
        
        # Testar padrões específicos
        assert patterns['date'].search('2023-12-01')
        assert patterns['timestamp'].search('2023-12-01 10:30:00')
        assert patterns['uuid'].search('550e8400-e29b-41d4-a716-446655440000')
        assert patterns['json'].search('{"key": "value"}')
        assert patterns['url'].search('https://example.com')
        assert patterns['boolean'].search('true')
        assert patterns['boolean'].search('false')
        assert patterns['boolean'].search('yes')
        assert patterns['boolean'].search('no')
    
    @patch('main.get_db_connection')
    @patch('main.redis_client')
    def test_discover_schemas_success(self, mock_redis, mock_db):
        """Testa descoberta de schemas com sucesso"""
        # Setup mocks
        mock_redis.get.return_value = None
        mock_cursor = Mock()
        mock_connection = Mock()
        mock_connection.cursor.return_value = mock_cursor
        mock_db.return_value = mock_connection
        
        # Mock dados de schemas
        mock_cursor.fetchall.side_effect = [
            [('public', 5), ('analytics', 3)],  # schemas
            [('customers', 'BASE TABLE'), ('orders', 'BASE TABLE')],  # tabelas public
            [('metrics', 'BASE TABLE')]  # tabelas analytics
        ]
        
        service = AutoDiscoveryService()
        
        with patch.object(service, '_discover_tables_in_schema') as mock_discover_tables:
            mock_discover_tables.return_value = [
                {'schema_name': 'public', 'table_name': 'customers', 'table_type': 'BASE TABLE', 'estimated_rows': 1000, 'organization_id': 1}
            ]
            
            result = service.discover_schemas(1)
        
        assert result['organization_id'] == 1
        assert result['total_schemas'] == 2
        assert len(result['schemas']) == 2
        assert result['schemas'][0]['name'] == 'public'
        assert result['schemas'][0]['table_count'] == 5
    
    @patch('main.get_db_connection')
    def test_discover_schemas_connection_error(self, mock_db):
        """Testa erro de conexão na descoberta de schemas"""
        mock_db.side_effect = Exception("Connection failed")
        
        service = AutoDiscoveryService()
        
        with pytest.raises(AutoDiscoveryError) as exc_info:
            service.discover_schemas(1)
        
        assert exc_info.value.error_code == "SCHEMA_DISCOVERY_ERROR"
        assert "Connection failed" in str(exc_info.value)
    
    @patch('main.get_db_connection')
    @patch('main.redis_client')
    def test_profile_table_success(self, mock_redis, mock_db):
        """Testa profiling de tabela com sucesso"""
        # Setup mocks
        mock_redis.get.return_value = None
        mock_cursor = Mock()
        mock_connection = Mock()
        mock_connection.cursor.return_value = mock_cursor
        mock_db.return_value = mock_connection
        
        # Mock verificação de existência da tabela
        mock_cursor.fetchone.side_effect = [
            (1,),  # tabela existe
            (1000,),  # row count
            ('Customer table', '1 MB'),  # table info
        ]
        
        # Mock informações das colunas
        mock_cursor.fetchall.side_effect = [
            [('id', 'integer', 'NO', None, None, None, None, 'Primary key')],  # columns info
            [],  # relationships
            []   # indexes
        ]
        
        service = AutoDiscoveryService()
        
        with patch.object(service, '_profile_column') as mock_profile_column:
            mock_profile_column.return_value = ColumnProfile(
                name='id',
                data_type=DataType.INTEGER,
                nullable=False,
                unique_count=1000,
                null_count=0,
                total_count=1000,
                quality_score=1.0
            )
            
            result = service.profile_table('public', 'customers', 1)
        
        assert 'table_profile' in result
        assert result['table_profile']['schema_name'] == 'public'
        assert result['table_profile']['table_name'] == 'customers'
        assert result['table_profile']['row_count'] == 1000
    
    @patch('main.get_db_connection')
    def test_profile_table_not_found(self, mock_db):
        """Testa profiling de tabela inexistente"""
        mock_cursor = Mock()
        mock_connection = Mock()
        mock_connection.cursor.return_value = mock_cursor
        mock_db.return_value = mock_connection
        
        # Mock tabela não encontrada
        mock_cursor.fetchone.return_value = (0,)
        
        service = AutoDiscoveryService()
        
        with pytest.raises(AutoDiscoveryError) as exc_info:
            service.profile_table('public', 'nonexistent', 1)
        
        assert exc_info.value.error_code == "TABLE_NOT_FOUND"
        assert "não encontrada" in str(exc_info.value)
    
    @patch('main.get_db_connection')
    def test_detect_pii_success(self, mock_db):
        """Testa detecção de PII com sucesso"""
        mock_cursor = Mock()
        mock_connection = Mock()
        mock_connection.cursor.return_value = mock_cursor
        mock_db.return_value = mock_connection
        
        # Mock colunas da tabela
        mock_cursor.fetchall.return_value = [
            ('email', 'varchar'),
            ('phone', 'varchar'),
            ('name', 'varchar')
        ]
        
        service = AutoDiscoveryService()
        
        with patch.object(service, '_detect_pii_by_name') as mock_name_pii, \
             patch.object(service, '_detect_pii_by_content') as mock_content_pii, \
             patch.object(service, '_calculate_pii_confidence') as mock_confidence:
            
            mock_name_pii.side_effect = [['email'], ['phone'], []]
            mock_content_pii.side_effect = [['email'], [], ['name']]
            mock_confidence.return_value = 0.9
            
            result = service.detect_pii('public', 'customers', 1)
        
        assert result['schema_name'] == 'public'
        assert result['table_name'] == 'customers'
        assert result['total_pii_columns'] == 3
        assert len(result['pii_findings']) == 3
    
    def test_detect_pii_by_name(self):
        """Testa detecção de PII por nome da coluna"""
        service = AutoDiscoveryService()
        
        # Testar detecções positivas
        assert 'email' in service._detect_pii_by_name('user_email')
        assert 'phone' in service._detect_pii_by_name('telefone_contato')
        assert 'cpf' in service._detect_pii_by_name('cpf_cliente')
        assert 'name' in service._detect_pii_by_name('first_name')
        assert 'address' in service._detect_pii_by_name('endereco_residencial')
        
        # Testar detecção negativa
        assert service._detect_pii_by_name('product_id') == []
        assert service._detect_pii_by_name('created_at') == []
    
    @patch('main.get_db_connection')
    def test_detect_pii_by_content(self, mock_db):
        """Testa detecção de PII por conteúdo"""
        mock_cursor = Mock()
        mock_connection = Mock()
        mock_connection.cursor.return_value = mock_cursor
        mock_db.return_value = mock_connection
        
        # Mock valores de exemplo
        mock_cursor.fetchall.return_value = [
            ('test@example.com',),
            ('user@domain.com',),
            ('admin@site.org',)
        ]
        
        service = AutoDiscoveryService()
        result = service._detect_pii_by_content(mock_cursor, 'public', 'customers', 'email')
        
        assert 'email' in result
    
    def test_calculate_pii_confidence(self):
        """Testa cálculo de confiança da detecção de PII"""
        service = AutoDiscoveryService()
        
        # Ambos detectaram - alta confiança
        confidence = service._calculate_pii_confidence(['email'], ['email'])
        assert confidence == 0.95
        
        # Apenas um detectou - confiança média
        confidence = service._calculate_pii_confidence(['email'], [])
        assert confidence == 0.7
        
        confidence = service._calculate_pii_confidence([], ['email'])
        assert confidence == 0.7
        
        # Nenhum detectou - sem confiança
        confidence = service._calculate_pii_confidence([], [])
        assert confidence == 0.0
    
    def test_calculate_risk_level(self):
        """Testa cálculo do nível de risco"""
        service = AutoDiscoveryService()
        
        # Alto risco - CPF detectado
        high_risk_findings = [
            {'pii_types': ['cpf', 'email']},
            {'pii_types': ['phone']}
        ]
        assert service._calculate_risk_level(high_risk_findings) == 'high'
        
        # Risco médio - múltiplos emails/phones
        medium_risk_findings = [
            {'pii_types': ['email']},
            {'pii_types': ['phone']},
            {'pii_types': ['name']}
        ]
        assert service._calculate_risk_level(medium_risk_findings) == 'medium'
        
        # Baixo risco - poucos dados sensíveis
        low_risk_findings = [
            {'pii_types': ['name']}
        ]
        assert service._calculate_risk_level(low_risk_findings) == 'low'
        
        # Sem risco - nenhum PII
        assert service._calculate_risk_level([]) == 'low'
    
    def test_infer_data_type(self):
        """Testa inferência de tipos de dados"""
        service = AutoDiscoveryService()
        
        # Testes de mapeamento direto
        assert service._infer_data_type('integer', [], []) == DataType.INTEGER
        assert service._infer_data_type('varchar', [], []) == DataType.STRING
        assert service._infer_data_type('boolean', [], []) == DataType.BOOLEAN
        assert service._infer_data_type('timestamp', [], []) == DataType.TIMESTAMP
        assert service._infer_data_type('json', [], []) == DataType.JSON
        
        # Testes de inferência por padrões
        assert service._infer_data_type('text', [], ['date']) == DataType.DATE
        assert service._infer_data_type('text', [], ['timestamp']) == DataType.TIMESTAMP
        assert service._infer_data_type('text', [], ['json']) == DataType.JSON
        assert service._infer_data_type('text', [], ['boolean']) == DataType.BOOLEAN
        
        # Tipo desconhecido - default para STRING
        assert service._infer_data_type('unknown_type', [], []) == DataType.STRING
    
    def test_classify_column(self):
        """Testa classificação de colunas"""
        service = AutoDiscoveryService()
        
        # PII detectado
        assert service._classify_column('email', True, 'varchar') == ClassificationLevel.PII
        
        # Dados sensíveis
        assert service._classify_column('password', False, 'varchar') == ClassificationLevel.SENSITIVE
        assert service._classify_column('salary', False, 'numeric') == ClassificationLevel.SENSITIVE
        
        # Dados confidenciais
        assert service._classify_column('internal_notes', False, 'text') == ClassificationLevel.CONFIDENTL
        
        # Dados internos (padrão)
        assert service._classify_column('product_name', False, 'varchar') == ClassificationLevel.INTERNAL
    
    def test_calculate_column_quality_score(self):
        """Testa cálculo do score de qualidade da coluna"""
        service = AutoDiscoveryService()
        
        # Coluna perfeita - sem nulls, valores únicos, boa distribuição
        score = service._calculate_column_quality_score(1000, 0, 1000, [('value1', 10), ('value2', 10)])
        assert score == 1.0
        
        # Coluna com nulls
        score = service._calculate_column_quality_score(1000, 100, 900, [])
        assert 0.8 < score < 1.0  # Penalizada pela completude
        
        # Coluna com baixa unicidade
        score = service._calculate_column_quality_score(1000, 0, 10, [])
        assert 0.3 < score < 0.8  # Penalizada pela unicidade
        
        # Coluna com distribuição ruim (um valor domina)
        score = service._calculate_column_quality_score(1000, 0, 1000, [('dominant_value', 950)])
        assert score < 0.8  # Penalizada pela distribuição
        
        # Coluna vazia
        score = service._calculate_column_quality_score(0, 0, 0, [])
        assert score == 0.0
    
    @patch('main.get_db_connection')
    def test_get_discovery_status_never_run(self, mock_db):
        """Testa status quando nunca executou descoberta"""
        mock_cursor = Mock()
        mock_connection = Mock()
        mock_connection.cursor.return_value = mock_cursor
        mock_db.return_value = mock_connection
        
        # Mock nenhuma descoberta encontrada
        mock_cursor.fetchone.return_value = None
        
        service = AutoDiscoveryService()
        result = service.get_discovery_status(1)
        
        assert result['organization_id'] == 1
        assert result['status'] == 'never_run'
        assert 'Nenhuma descoberta' in result['message']
    
    @patch('main.get_db_connection')
    def test_get_discovery_status_with_data(self, mock_db):
        """Testa status com dados de descoberta"""
        mock_cursor = Mock()
        mock_connection = Mock()
        mock_connection.cursor.return_value = mock_cursor
        mock_db.return_value = mock_connection
        
        # Mock dados de descoberta
        discovery_id = str(uuid.uuid4())
        started_at = datetime.now()
        completed_at = datetime.now()
        
        mock_cursor.fetchone.side_effect = [
            (discovery_id, 'completed', started_at, completed_at, 5, 25, None),  # última descoberta
            (5, 25, 0.85, 3)  # estatísticas
        ]
        
        service = AutoDiscoveryService()
        result = service.get_discovery_status(1)
        
        assert result['organization_id'] == 1
        assert result['last_discovery']['discovery_id'] == discovery_id
        assert result['last_discovery']['status'] == 'completed'
        assert result['current_statistics']['total_schemas'] == 5
        assert result['current_statistics']['total_tables'] == 25
        assert result['current_statistics']['avg_quality_score'] == 0.85
        assert result['current_statistics']['pii_tables'] == 3

class TestAPIEndpoints:
    """Testes para os endpoints da API"""
    
    def test_health_check_healthy(self, client, mock_redis):
        """Testa health check quando serviços estão saudáveis"""
        mock_redis.ping.return_value = True
        
        with patch('main.get_db_connection') as mock_db:
            mock_connection = Mock()
            mock_db.return_value = mock_connection
            
            response = client.get('/health')
            
            assert response.status_code == 200
            data = json.loads(response.data)
            assert data['status'] == 'healthy'
            assert data['service'] == 'auto-discovery-service'
            assert data['connections']['redis'] == 'ok'
            assert data['connections']['postgres'] == 'ok'
    
    def test_health_check_unhealthy(self, client, mock_redis):
        """Testa health check quando serviços estão com problema"""
        mock_redis.ping.side_effect = Exception("Redis down")
        
        with patch('main.get_db_connection') as mock_db:
            mock_db.side_effect = Exception("DB down")
            
            response = client.get('/health')
            
            assert response.status_code == 503
            data = json.loads(response.data)
            assert data['status'] == 'unhealthy'
            assert data['connections']['redis'] == 'error'
            assert data['connections']['postgres'] == 'error'
    
    def test_discover_schemas_endpoint_success(self, client):
        """Testa endpoint de descoberta de schemas com sucesso"""
        with patch.object(discovery_service, 'discover_schemas') as mock_discover:
            mock_discover.return_value = {
                'organization_id': 1,
                'schemas': [{'name': 'public', 'table_count': 5}],
                'tables': [],
                'total_schemas': 1,
                'total_tables': 0
            }
            
            response = client.post('/api/v1/discover/schemas', 
                                 json={'organization_id': 1})
            
            assert response.status_code == 200
            data = json.loads(response.data)
            assert data['organization_id'] == 1
            assert data['total_schemas'] == 1
    
    def test_discover_schemas_endpoint_missing_param(self, client):
        """Testa endpoint de descoberta sem parâmetro obrigatório"""
        response = client.post('/api/v1/discover/schemas', json={})
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['error_code'] == 'MISSING_PARAMETER'
        assert 'organization_id' in data['error']
    
    def test_profile_table_endpoint_success(self, client):
        """Testa endpoint de profiling com sucesso"""
        with patch.object(discovery_service, 'profile_table') as mock_profile:
            mock_profile.return_value = {
                'table_profile': {
                    'schema_name': 'public',
                    'table_name': 'customers',
                    'row_count': 1000
                }
            }
            
            response = client.post('/api/v1/profile/table', 
                                 json={
                                     'schema_name': 'public',
                                     'table_name': 'customers',
                                     'organization_id': 1
                                 })
            
            assert response.status_code == 200
            data = json.loads(response.data)
            assert data['table_profile']['schema_name'] == 'public'
    
    def test_profile_table_endpoint_missing_params(self, client):
        """Testa endpoint de profiling sem parâmetros obrigatórios"""
        response = client.post('/api/v1/profile/table', 
                             json={'schema_name': 'public'})
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['error_code'] == 'MISSING_PARAMETERS'
    
    def test_detect_pii_endpoint_success(self, client):
        """Testa endpoint de detecção de PII com sucesso"""
        with patch.object(discovery_service, 'detect_pii') as mock_detect:
            mock_detect.return_value = {
                'schema_name': 'public',
                'table_name': 'customers',
                'pii_findings': [
                    {'column_name': 'email', 'pii_types': ['email']}
                ],
                'total_pii_columns': 1,
                'risk_level': 'medium'
            }
            
            response = client.post('/api/v1/detect/pii', 
                                 json={
                                     'schema_name': 'public',
                                     'table_name': 'customers',
                                     'organization_id': 1
                                 })
            
            assert response.status_code == 200
            data = json.loads(response.data)
            assert data['total_pii_columns'] == 1
            assert data['risk_level'] == 'medium'
    
    def test_infer_relationships_endpoint_success(self, client):
        """Testa endpoint de inferência de relacionamentos com sucesso"""
        with patch.object(discovery_service, 'infer_relationships') as mock_infer:
            mock_infer.return_value = {
                'organization_id': 1,
                'relationships': [
                    {
                        'source_table': 'customers',
                        'target_table': 'orders',
                        'type': 'foreign_key'
                    }
                ],
                'total_relationships': 1
            }
            
            response = client.post('/api/v1/infer/relationships', 
                                 json={'organization_id': 1})
            
            assert response.status_code == 200
            data = json.loads(response.data)
            assert data['total_relationships'] == 1
    
    def test_get_discovery_status_endpoint(self, client):
        """Testa endpoint de status da descoberta"""
        with patch.object(discovery_service, 'get_discovery_status') as mock_status:
            mock_status.return_value = {
                'organization_id': 1,
                'status': 'never_run',
                'message': 'Nenhuma descoberta executada ainda'
            }
            
            response = client.get('/api/v1/discovery/status/1')
            
            assert response.status_code == 200
            data = json.loads(response.data)
            assert data['organization_id'] == 1
            assert data['status'] == 'never_run'
    
    def test_batch_discovery_endpoint_success(self, client):
        """Testa endpoint de descoberta em lote com sucesso"""
        with patch.object(discovery_service, 'profile_table') as mock_profile:
            mock_profile.return_value = {
                'table_profile': {
                    'schema_name': 'public',
                    'table_name': 'customers'
                }
            }
            
            response = client.post('/api/v1/discovery/batch', 
                                 json={
                                     'organization_id': 1,
                                     'tables': [
                                         {'schema_name': 'public', 'table_name': 'customers'},
                                         {'schema_name': 'public', 'table_name': 'orders'}
                                     ]
                                 })
            
            assert response.status_code == 200
            data = json.loads(response.data)
            assert data['total_requested'] == 2
            assert data['successful'] >= 0
            assert data['failed'] >= 0
    
    def test_batch_discovery_endpoint_missing_tables(self, client):
        """Testa endpoint de descoberta em lote sem tabelas"""
        response = client.post('/api/v1/discovery/batch', 
                             json={'organization_id': 1})
        
        assert response.status_code == 400
        data = json.loads(response.data)
        assert data['error_code'] == 'MISSING_PARAMETER'
        assert 'tabelas' in data['error']
    
    @patch('main.get_db_connection')
    def test_get_service_statistics_endpoint(self, client, mock_db):
        """Testa endpoint de estatísticas do serviço"""
        mock_cursor = Mock()
        mock_connection = Mock()
        mock_connection.cursor.return_value = mock_cursor
        mock_db.return_value = mock_connection
        
        # Mock estatísticas
        mock_cursor.fetchone.side_effect = [
            (5, 10, 3.2, 15.5),  # estatísticas gerais
            (8, 2, 3, 3)  # estatísticas de PII
        ]
        
        response = client.get('/api/v1/statistics')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'service_statistics' in data
        assert 'pii_statistics' in data
        assert 'cache_statistics' in data
        assert data['service_statistics']['total_organizations'] == 5

class TestErrorHandling:
    """Testes para tratamento de erros"""
    
    def test_auto_discovery_error_handler(self, client):
        """Testa tratamento de AutoDiscoveryError"""
        with patch.object(discovery_service, 'discover_schemas') as mock_discover:
            mock_discover.side_effect = AutoDiscoveryError(
                "Erro de teste",
                "TEST_ERROR",
                {"detail": "test"}
            )
            
            response = client.post('/api/v1/discover/schemas', 
                                 json={'organization_id': 1})
            
            assert response.status_code == 400
            data = json.loads(response.data)
            assert data['error'] == "Erro de teste"
            assert data['error_code'] == "TEST_ERROR"
            assert data['details']['detail'] == "test"
    
    def test_connection_error_handler(self, client):
        """Testa tratamento de ConnectionError"""
        with patch.object(discovery_service, 'discover_schemas') as mock_discover:
            mock_discover.side_effect = ConnectionError("DB connection failed")
            
            response = client.post('/api/v1/discover/schemas', 
                                 json={'organization_id': 1})
            
            assert response.status_code == 503
            data = json.loads(response.data)
            assert data['error_code'] == "CONNECTION_ERROR"
            assert "conexão" in data['error']
    
    def test_generic_error_handler(self, client):
        """Testa tratamento de erro genérico"""
        with patch.object(discovery_service, 'discover_schemas') as mock_discover:
            mock_discover.side_effect = ValueError("Unexpected error")
            
            response = client.post('/api/v1/discover/schemas', 
                                 json={'organization_id': 1})
            
            assert response.status_code == 500
            data = json.loads(response.data)
            assert data['error_code'] == "INTERNAL_ERROR"
            assert "interno" in data['error']

class TestDataClasses:
    """Testes para classes de dados"""
    
    def test_column_profile_creation(self):
        """Testa criação de ColumnProfile"""
        profile = ColumnProfile(
            name='test_column',
            data_type=DataType.STRING,
            nullable=True,
            unique_count=100,
            null_count=10,
            total_count=110,
            quality_score=0.85
        )
        
        assert profile.name == 'test_column'
        assert profile.data_type == DataType.STRING
        assert profile.nullable is True
        assert profile.unique_count == 100
        assert profile.null_count == 10
        assert profile.total_count == 110
        assert profile.quality_score == 0.85
    
    def test_table_profile_creation(self):
        """Testa criação de TableProfile"""
        column = ColumnProfile(
            name='id',
            data_type=DataType.INTEGER,
            nullable=False,
            unique_count=1000,
            null_count=0,
            total_count=1000,
            quality_score=1.0
        )
        
        profile = TableProfile(
            schema_name='public',
            table_name='test_table',
            row_count=1000,
            column_count=1,
            columns=[column],
            relationships=[],
            indexes=[],
            last_updated=datetime.now(),
            data_freshness_score=0.9,
            completeness_score=0.95,
            consistency_score=0.88,
            overall_quality_score=0.91
        )
        
        assert profile.schema_name == 'public'
        assert profile.table_name == 'test_table'
        assert profile.row_count == 1000
        assert profile.column_count == 1
        assert len(profile.columns) == 1
        assert profile.overall_quality_score == 0.91

if __name__ == '__main__':
    # Executar testes com cobertura
    pytest.main([
        '--cov=main',
        '--cov-report=html',
        '--cov-report=term-missing',
        '--cov-fail-under=85',
        '-v'
    ])

