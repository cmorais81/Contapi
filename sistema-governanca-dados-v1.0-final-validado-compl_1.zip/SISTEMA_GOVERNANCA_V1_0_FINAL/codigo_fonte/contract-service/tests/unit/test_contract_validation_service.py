# Autor: carlos.morais@f1rst.com.br
"""
Testes Unitários para Contract Validation Service
"""

import pytest
import asyncio
from datetime import datetime, timedelta
from uuid import UUID, uuid4
from unittest.mock import Mock, AsyncMock, patch

from src.domain.entities.contract import Contract, ContractStatus
from src.domain.services.contract_validation_service import (
    ContractValidationService, ValidationError, ValidationSeverity
)
from src.domain.services.contract_layout_service import (
    ContractLayoutService, LayoutValidationResult
)
from src.application.use_cases.create_contract_with_validation import (
    CreateContractWithValidationUseCase, ContractValidationException
)


class TestContractValidationService:
    """Testes para ContractValidationService"""
    
    @pytest.fixture
    def validation_service(self):
        """Instância do serviço de validação"""
        return ContractValidationService()
    
    @pytest.fixture
    def sample_contract(self):
        """Contrato de exemplo para testes"""
        return Contract(
            id=uuid4(),
            title="Contrato de Dados de Clientes",
            description="Contrato para dados de clientes do CRM",
            version="1.0.0",
            dataset_name="customer_data",
            schema_definition={
                "fields": [
                    {
                        "name": "customer_id",
                        "type": "string",
                        "constraints": {
                            "nullable": False,
                            "unique": True,
                            "max_length": 50
                        }
                    },
                    {
                        "name": "email",
                        "type": "string",
                        "constraints": {
                            "nullable": False,
                            "pattern": r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
                        }
                    },
                    {
                        "name": "created_at",
                        "type": "datetime",
                        "constraints": {
                            "nullable": False
                        }
                    }
                ],
                "primary_key": "customer_id",
                "format": "json"
            },
            data_classification="CONFIDENTIAL",
            status=ContractStatus.DRAFT,
            created_by="user123",
            created_at=datetime.utcnow()
        )
    
    @pytest.fixture
    def invalid_contract(self):
        """Contrato inválido para testes"""
        return Contract(
            id=uuid4(),
            title="",  # Título vazio - inválido
            description="",  # Descrição vazia - inválida
            version="invalid_version",  # Versão inválida
            dataset_name="",  # Nome do dataset vazio - inválido
            schema_definition={
                "fields": []  # Sem campos - inválido
            },
            data_classification="INVALID_CLASSIFICATION",  # Classificação inválida
            status=ContractStatus.DRAFT,
            created_by="",  # Criador vazio - inválido
            created_at=datetime.utcnow()
        )
    
    def test_validate_contract_valid(self, validation_service, sample_contract):
        """Testa validação de contrato válido"""
        # Act
        errors = validation_service.validate_contract(sample_contract)
        
        # Assert
        assert len(errors) == 0
    
    def test_validate_contract_invalid_title(self, validation_service, sample_contract):
        """Testa validação com título inválido"""
        # Arrange
        sample_contract.title = ""
        
        # Act
        errors = validation_service.validate_contract(sample_contract)
        
        # Assert
        assert len(errors) > 0
        title_errors = [e for e in errors if e.field == "title"]
        assert len(title_errors) > 0
        assert title_errors[0].severity == ValidationSeverity.ERROR
        assert "título" in title_errors[0].message.lower()
    
    def test_validate_contract_invalid_version(self, validation_service, sample_contract):
        """Testa validação com versão inválida"""
        # Arrange
        sample_contract.version = "invalid.version"
        
        # Act
        errors = validation_service.validate_contract(sample_contract)
        
        # Assert
        assert len(errors) > 0
        version_errors = [e for e in errors if e.field == "version"]
        assert len(version_errors) > 0
        assert version_errors[0].severity == ValidationSeverity.ERROR
        assert "versão" in version_errors[0].message.lower()
    
    def test_validate_contract_invalid_dataset_name(self, validation_service, sample_contract):
        """Testa validação com nome de dataset inválido"""
        # Arrange
        sample_contract.dataset_name = "Invalid Dataset Name!"  # Caracteres especiais
        
        # Act
        errors = validation_service.validate_contract(sample_contract)
        
        # Assert
        assert len(errors) > 0
        dataset_errors = [e for e in errors if e.field == "dataset_name"]
        assert len(dataset_errors) > 0
        assert dataset_errors[0].severity == ValidationSeverity.ERROR
    
    def test_validate_contract_invalid_data_classification(self, validation_service, sample_contract):
        """Testa validação com classificação de dados inválida"""
        # Arrange
        sample_contract.data_classification = "INVALID_CLASSIFICATION"
        
        # Act
        errors = validation_service.validate_contract(sample_contract)
        
        # Assert
        assert len(errors) > 0
        classification_errors = [e for e in errors if e.field == "data_classification"]
        assert len(classification_errors) > 0
        assert classification_errors[0].severity == ValidationSeverity.ERROR
    
    def test_validate_schema_definition_valid(self, validation_service, sample_contract):
        """Testa validação de schema válido"""
        # Act
        errors = validation_service._validate_schema_definition(sample_contract.schema_definition)
        
        # Assert
        assert len(errors) == 0
    
    def test_validate_schema_definition_no_fields(self, validation_service):
        """Testa validação de schema sem campos"""
        # Arrange
        invalid_schema = {
            "fields": [],
            "format": "json"
        }
        
        # Act
        errors = validation_service._validate_schema_definition(invalid_schema)
        
        # Assert
        assert len(errors) > 0
        field_errors = [e for e in errors if "campos" in e.message.lower()]
        assert len(field_errors) > 0
    
    def test_validate_schema_definition_invalid_field_type(self, validation_service):
        """Testa validação de schema com tipo de campo inválido"""
        # Arrange
        invalid_schema = {
            "fields": [
                {
                    "name": "test_field",
                    "type": "invalid_type",  # Tipo inválido
                    "constraints": {}
                }
            ],
            "format": "json"
        }
        
        # Act
        errors = validation_service._validate_schema_definition(invalid_schema)
        
        # Assert
        assert len(errors) > 0
        type_errors = [e for e in errors if "tipo" in e.message.lower()]
        assert len(type_errors) > 0
    
    def test_validate_schema_definition_missing_primary_key(self, validation_service):
        """Testa validação de schema sem chave primária"""
        # Arrange
        schema_without_pk = {
            "fields": [
                {
                    "name": "test_field",
                    "type": "string",
                    "constraints": {}
                }
            ],
            "format": "json"
            # Sem primary_key
        }
        
        # Act
        errors = validation_service._validate_schema_definition(schema_without_pk)
        
        # Assert
        assert len(errors) > 0
        pk_errors = [e for e in errors if "chave primária" in e.message.lower()]
        assert len(pk_errors) > 0
        assert pk_errors[0].severity == ValidationSeverity.WARNING
    
    def test_validate_field_constraints_valid(self, validation_service):
        """Testa validação de constraints válidas"""
        # Arrange
        field = {
            "name": "email",
            "type": "string",
            "constraints": {
                "nullable": False,
                "max_length": 255,
                "pattern": r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
            }
        }
        
        # Act
        errors = validation_service._validate_field_constraints(field)
        
        # Assert
        assert len(errors) == 0
    
    def test_validate_field_constraints_invalid_pattern(self, validation_service):
        """Testa validação de constraint com padrão inválido"""
        # Arrange
        field = {
            "name": "email",
            "type": "string",
            "constraints": {
                "pattern": "[invalid_regex"  # Regex inválido
            }
        }
        
        # Act
        errors = validation_service._validate_field_constraints(field)
        
        # Assert
        assert len(errors) > 0
        pattern_errors = [e for e in errors if "padrão" in e.message.lower()]
        assert len(pattern_errors) > 0
    
    def test_validate_field_constraints_conflicting_constraints(self, validation_service):
        """Testa validação de constraints conflitantes"""
        # Arrange
        field = {
            "name": "test_field",
            "type": "string",
            "constraints": {
                "min_length": 10,
                "max_length": 5  # max_length menor que min_length
            }
        }
        
        # Act
        errors = validation_service._validate_field_constraints(field)
        
        # Assert
        assert len(errors) > 0
        conflict_errors = [e for e in errors if "conflito" in e.message.lower()]
        assert len(conflict_errors) > 0
    
    def test_validate_business_rules_lgpd_compliance(self, validation_service, sample_contract):
        """Testa validação de regras de negócio para compliance LGPD"""
        # Arrange
        sample_contract.data_classification = "PERSONAL"
        sample_contract.lgpd_compliance = {
            "legal_basis": "consent",
            "data_subject_rights": True,
            "retention_period": "2_years"
        }
        
        # Act
        errors = validation_service._validate_business_rules(sample_contract)
        
        # Assert
        # Não deve haver erros para contrato com compliance LGPD adequada
        lgpd_errors = [e for e in errors if "lgpd" in e.message.lower()]
        assert len(lgpd_errors) == 0
    
    def test_validate_business_rules_missing_lgpd_for_personal_data(self, validation_service, sample_contract):
        """Testa validação de regras LGPD ausentes para dados pessoais"""
        # Arrange
        sample_contract.data_classification = "PERSONAL"
        sample_contract.lgpd_compliance = None  # Sem compliance LGPD
        
        # Act
        errors = validation_service._validate_business_rules(sample_contract)
        
        # Assert
        assert len(errors) > 0
        lgpd_errors = [e for e in errors if "lgpd" in e.message.lower()]
        assert len(lgpd_errors) > 0
        assert lgpd_errors[0].severity == ValidationSeverity.ERROR
    
    def test_validate_quality_requirements_valid(self, validation_service, sample_contract):
        """Testa validação de requisitos de qualidade válidos"""
        # Arrange
        sample_contract.quality_requirements = {
            "completeness_threshold": 95.0,
            "accuracy_threshold": 98.0,
            "consistency_rules": ["email_format", "phone_format"],
            "freshness_requirement": "daily"
        }
        
        # Act
        errors = validation_service._validate_quality_requirements(sample_contract.quality_requirements)
        
        # Assert
        assert len(errors) == 0
    
    def test_validate_quality_requirements_invalid_thresholds(self, validation_service):
        """Testa validação de requisitos de qualidade com thresholds inválidos"""
        # Arrange
        invalid_quality_requirements = {
            "completeness_threshold": 150.0,  # Acima de 100%
            "accuracy_threshold": -10.0,  # Negativo
            "consistency_rules": [],
            "freshness_requirement": "invalid_frequency"
        }
        
        # Act
        errors = validation_service._validate_quality_requirements(invalid_quality_requirements)
        
        # Assert
        assert len(errors) > 0
        threshold_errors = [e for e in errors if "threshold" in e.message.lower()]
        assert len(threshold_errors) >= 2  # Pelo menos 2 erros de threshold
    
    def test_validate_sla_requirements_valid(self, validation_service, sample_contract):
        """Testa validação de requisitos SLA válidos"""
        # Arrange
        sample_contract.sla_requirements = {
            "availability": 99.9,
            "response_time_ms": 500,
            "throughput_rps": 1000,
            "data_freshness_hours": 1
        }
        
        # Act
        errors = validation_service._validate_sla_requirements(sample_contract.sla_requirements)
        
        # Assert
        assert len(errors) == 0
    
    def test_validate_sla_requirements_unrealistic_values(self, validation_service):
        """Testa validação de SLA com valores irreais"""
        # Arrange
        unrealistic_sla = {
            "availability": 100.1,  # Acima de 100%
            "response_time_ms": -100,  # Negativo
            "throughput_rps": 0,  # Zero
            "data_freshness_hours": -5  # Negativo
        }
        
        # Act
        errors = validation_service._validate_sla_requirements(unrealistic_sla)
        
        # Assert
        assert len(errors) > 0
        unrealistic_errors = [e for e in errors if any(word in e.message.lower() for word in ["inválido", "negativo", "zero"])]
        assert len(unrealistic_errors) >= 3
    
    def test_check_performance_implications_large_dataset(self, validation_service, sample_contract):
        """Testa verificação de implicações de performance para dataset grande"""
        # Arrange
        # Simular schema com muitos campos
        large_schema = {
            "fields": [
                {
                    "name": f"field_{i}",
                    "type": "string",
                    "constraints": {"max_length": 1000}
                }
                for i in range(100)  # 100 campos
            ],
            "primary_key": "field_0",
            "format": "json"
        }
        sample_contract.schema_definition = large_schema
        
        # Act
        warnings = validation_service._check_performance_implications(sample_contract)
        
        # Assert
        assert len(warnings) > 0
        performance_warnings = [w for w in warnings if "performance" in w.message.lower()]
        assert len(performance_warnings) > 0
        assert performance_warnings[0].severity == ValidationSeverity.WARNING
    
    def test_check_performance_implications_complex_constraints(self, validation_service, sample_contract):
        """Testa verificação de performance para constraints complexas"""
        # Arrange
        complex_schema = {
            "fields": [
                {
                    "name": "complex_field",
                    "type": "string",
                    "constraints": {
                        "pattern": r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$",  # Regex complexo
                        "unique": True,
                        "max_length": 10000
                    }
                }
            ],
            "primary_key": "complex_field",
            "format": "json"
        }
        sample_contract.schema_definition = complex_schema
        
        # Act
        warnings = validation_service._check_performance_implications(sample_contract)
        
        # Assert
        assert len(warnings) > 0
        regex_warnings = [w for w in warnings if "regex" in w.message.lower() or "padrão" in w.message.lower()]
        assert len(regex_warnings) > 0
    
    def test_suggest_optimizations_no_indexes(self, validation_service, sample_contract):
        """Testa sugestões de otimização para schema sem índices"""
        # Act
        suggestions = validation_service._suggest_optimizations(sample_contract)
        
        # Assert
        assert len(suggestions) > 0
        index_suggestions = [s for s in suggestions if "índice" in s.message.lower()]
        assert len(index_suggestions) > 0
    
    def test_suggest_optimizations_large_text_fields(self, validation_service, sample_contract):
        """Testa sugestões para campos de texto grandes"""
        # Arrange
        large_text_schema = {
            "fields": [
                {
                    "name": "large_text",
                    "type": "string",
                    "constraints": {
                        "max_length": 100000  # Campo muito grande
                    }
                }
            ],
            "primary_key": "large_text",
            "format": "json"
        }
        sample_contract.schema_definition = large_text_schema
        
        # Act
        suggestions = validation_service._suggest_optimizations(sample_contract)
        
        # Assert
        assert len(suggestions) > 0
        text_suggestions = [s for s in suggestions if "texto" in s.message.lower()]
        assert len(text_suggestions) > 0
    
    def test_validate_version_format_valid(self, validation_service):
        """Testa validação de formato de versão válido"""
        # Arrange
        valid_versions = ["1.0.0", "2.1.3", "10.20.30", "0.0.1"]
        
        for version in valid_versions:
            # Act
            is_valid = validation_service._validate_version_format(version)
            
            # Assert
            assert is_valid is True, f"Versão {version} deveria ser válida"
    
    def test_validate_version_format_invalid(self, validation_service):
        """Testa validação de formato de versão inválido"""
        # Arrange
        invalid_versions = ["1.0", "v1.0.0", "1.0.0-beta", "invalid", "1.0.0.0"]
        
        for version in invalid_versions:
            # Act
            is_valid = validation_service._validate_version_format(version)
            
            # Assert
            assert is_valid is False, f"Versão {version} deveria ser inválida"
    
    def test_validate_dataset_name_format_valid(self, validation_service):
        """Testa validação de nome de dataset válido"""
        # Arrange
        valid_names = ["customer_data", "sales_2023", "user_profiles", "product_catalog"]
        
        for name in valid_names:
            # Act
            is_valid = validation_service._validate_dataset_name_format(name)
            
            # Assert
            assert is_valid is True, f"Nome {name} deveria ser válido"
    
    def test_validate_dataset_name_format_invalid(self, validation_service):
        """Testa validação de nome de dataset inválido"""
        # Arrange
        invalid_names = ["Customer Data", "sales-2023", "user@profiles", "123invalid", ""]
        
        for name in invalid_names:
            # Act
            is_valid = validation_service._validate_dataset_name_format(name)
            
            # Assert
            assert is_valid is False, f"Nome {name} deveria ser inválido"
    
    def test_validate_data_classification_valid(self, validation_service):
        """Testa validação de classificação de dados válida"""
        # Arrange
        valid_classifications = ["PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED", "PERSONAL", "SENSITIVE"]
        
        for classification in valid_classifications:
            # Act
            is_valid = validation_service._validate_data_classification(classification)
            
            # Assert
            assert is_valid is True, f"Classificação {classification} deveria ser válida"
    
    def test_validate_data_classification_invalid(self, validation_service):
        """Testa validação de classificação de dados inválida"""
        # Arrange
        invalid_classifications = ["INVALID", "secret", "Public", "", "UNKNOWN"]
        
        for classification in invalid_classifications:
            # Act
            is_valid = validation_service._validate_data_classification(classification)
            
            # Assert
            assert is_valid is False, f"Classificação {classification} deveria ser inválida"
    
    def test_calculate_validation_score_perfect_contract(self, validation_service, sample_contract):
        """Testa cálculo de score para contrato perfeito"""
        # Act
        errors = validation_service.validate_contract(sample_contract)
        score = validation_service._calculate_validation_score(errors)
        
        # Assert
        assert score == 100.0  # Score perfeito para contrato sem erros
    
    def test_calculate_validation_score_with_errors(self, validation_service, invalid_contract):
        """Testa cálculo de score para contrato com erros"""
        # Act
        errors = validation_service.validate_contract(invalid_contract)
        score = validation_service._calculate_validation_score(errors)
        
        # Assert
        assert score < 100.0  # Score reduzido devido aos erros
        assert score >= 0.0   # Score não pode ser negativo
    
    def test_generate_validation_report(self, validation_service, sample_contract):
        """Testa geração de relatório de validação"""
        # Act
        errors = validation_service.validate_contract(sample_contract)
        report = validation_service.generate_validation_report(sample_contract, errors)
        
        # Assert
        assert "contract_id" in report
        assert "validation_timestamp" in report
        assert "validation_score" in report
        assert "total_errors" in report
        assert "errors_by_severity" in report
        assert "errors_by_category" in report
        assert "recommendations" in report
        
        assert report["contract_id"] == str(sample_contract.id)
        assert isinstance(report["validation_score"], float)
        assert isinstance(report["total_errors"], int)
        assert isinstance(report["recommendations"], list)


class TestContractLayoutService:
    """Testes para ContractLayoutService"""
    
    @pytest.fixture
    def layout_service(self):
        """Instância do serviço de layout"""
        return ContractLayoutService()
    
    @pytest.fixture
    def sample_contract(self):
        """Contrato de exemplo para testes de layout"""
        return Contract(
            id=uuid4(),
            title="Contrato de Layout",
            description="Teste de layout",
            version="1.0.0",
            dataset_name="layout_test",
            schema_definition={
                "fields": [
                    {
                        "name": "id",
                        "type": "string",
                        "constraints": {"nullable": False, "unique": True}
                    },
                    {
                        "name": "name",
                        "type": "string",
                        "constraints": {"nullable": False, "max_length": 100}
                    }
                ],
                "primary_key": "id",
                "format": "json"
            },
            data_classification="INTERNAL",
            status=ContractStatus.DRAFT,
            created_by="user123",
            created_at=datetime.utcnow()
        )
    
    def test_validate_layout_valid_contract(self, layout_service, sample_contract):
        """Testa validação de layout para contrato válido"""
        # Act
        result = layout_service.validate_layout(sample_contract)
        
        # Assert
        assert isinstance(result, LayoutValidationResult)
        assert result.is_valid is True
        assert len(result.errors) == 0
        assert result.layout_hash is not None
    
    def test_validate_layout_missing_primary_key(self, layout_service, sample_contract):
        """Testa validação de layout sem chave primária"""
        # Arrange
        sample_contract.schema_definition["primary_key"] = None
        
        # Act
        result = layout_service.validate_layout(sample_contract)
        
        # Assert
        assert result.is_valid is False
        assert len(result.errors) > 0
        pk_errors = [e for e in result.errors if "primary_key" in str(e)]
        assert len(pk_errors) > 0
    
    def test_check_compatibility_compatible_contracts(self, layout_service, sample_contract):
        """Testa verificação de compatibilidade entre contratos compatíveis"""
        # Arrange
        old_contract = sample_contract
        new_contract = Contract(
            id=uuid4(),
            title="Contrato Atualizado",
            description="Versão atualizada",
            version="1.1.0",
            dataset_name="layout_test",
            schema_definition={
                "fields": [
                    {
                        "name": "id",
                        "type": "string",
                        "constraints": {"nullable": False, "unique": True}
                    },
                    {
                        "name": "name",
                        "type": "string",
                        "constraints": {"nullable": False, "max_length": 100}
                    },
                    {
                        "name": "email",  # Campo adicionado - compatível
                        "type": "string",
                        "constraints": {"nullable": True, "max_length": 255}
                    }
                ],
                "primary_key": "id",
                "format": "json"
            },
            data_classification="INTERNAL",
            status=ContractStatus.DRAFT,
            created_by="user123",
            created_at=datetime.utcnow()
        )
        
        # Act
        result = layout_service.check_compatibility(old_contract, new_contract)
        
        # Assert
        assert isinstance(result, LayoutValidationResult)
        assert result.is_valid is True
        assert result.compatibility_score >= 80.0  # Alta compatibilidade
    
    def test_check_compatibility_breaking_changes(self, layout_service, sample_contract):
        """Testa verificação de compatibilidade com breaking changes"""
        # Arrange
        old_contract = sample_contract
        new_contract = Contract(
            id=uuid4(),
            title="Contrato com Breaking Changes",
            description="Versão com mudanças incompatíveis",
            version="2.0.0",
            dataset_name="layout_test",
            schema_definition={
                "fields": [
                    {
                        "name": "id",
                        "type": "integer",  # Tipo alterado - breaking change
                        "constraints": {"nullable": False, "unique": True}
                    }
                    # Campo "name" removido - breaking change
                ],
                "primary_key": "id",
                "format": "json"
            },
            data_classification="INTERNAL",
            status=ContractStatus.DRAFT,
            created_by="user123",
            created_at=datetime.utcnow()
        )
        
        # Act
        result = layout_service.check_compatibility(old_contract, new_contract)
        
        # Assert
        assert result.is_valid is False
        assert len(result.errors) > 0
        assert result.compatibility_score < 50.0  # Baixa compatibilidade
        
        # Verificar se breaking changes foram detectados
        breaking_errors = [e for e in result.errors if "breaking" in str(e).lower()]
        assert len(breaking_errors) > 0
    
    def test_generate_layout_hash_consistent(self, layout_service, sample_contract):
        """Testa se hash de layout é consistente"""
        # Act
        hash1 = layout_service._generate_layout_hash(sample_contract.schema_definition)
        hash2 = layout_service._generate_layout_hash(sample_contract.schema_definition)
        
        # Assert
        assert hash1 == hash2
        assert len(hash1) > 0
    
    def test_generate_layout_hash_different_schemas(self, layout_service, sample_contract):
        """Testa se schemas diferentes geram hashes diferentes"""
        # Arrange
        schema1 = sample_contract.schema_definition
        schema2 = {
            "fields": [
                {
                    "name": "different_field",
                    "type": "integer",
                    "constraints": {"nullable": False}
                }
            ],
            "primary_key": "different_field",
            "format": "json"
        }
        
        # Act
        hash1 = layout_service._generate_layout_hash(schema1)
        hash2 = layout_service._generate_layout_hash(schema2)
        
        # Assert
        assert hash1 != hash2


class TestCreateContractWithValidationUseCase:
    """Testes para CreateContractWithValidationUseCase"""
    
    @pytest.fixture
    def mock_contract_repository(self):
        """Mock do repositório de contratos"""
        repository = Mock()
        repository.save = AsyncMock()
        repository.find_by_id = AsyncMock()
        repository.find_by_dataset_name = AsyncMock()
        return repository
    
    @pytest.fixture
    def mock_validation_service(self):
        """Mock do serviço de validação"""
        service = Mock(spec=ContractValidationService)
        service.validate_contract = Mock(return_value=[])
        return service
    
    @pytest.fixture
    def mock_layout_service(self):
        """Mock do serviço de layout"""
        service = Mock(spec=ContractLayoutService)
        service.validate_layout = Mock(return_value=LayoutValidationResult(
            is_valid=True,
            errors=[],
            warnings=[],
            suggestions=[],
            layout_hash="test_hash",
            compatibility_score=100.0
        ))
        return service
    
    @pytest.fixture
    def mock_audit_service(self):
        """Mock do serviço de auditoria"""
        service = Mock()
        service.create_audit_event = AsyncMock()
        return service
    
    @pytest.fixture
    def use_case(self, mock_contract_repository, mock_validation_service, 
                 mock_layout_service, mock_audit_service):
        """Instância do use case"""
        return CreateContractWithValidationUseCase(
            contract_repository=mock_contract_repository,
            validation_service=mock_validation_service,
            layout_service=mock_layout_service,
            audit_service=mock_audit_service,
            notification_service=Mock()
        )
    
    @pytest.fixture
    def valid_contract_request(self):
        """Request válido para criação de contrato"""
        from src.application.dtos.contract_dtos import CreateContractRequest
        return CreateContractRequest(
            title="Contrato de Teste",
            description="Descrição do contrato de teste",
            version="1.0.0",
            dataset_name="test_dataset",
            schema_definition={
                "fields": [
                    {
                        "name": "id",
                        "type": "string",
                        "constraints": {"nullable": False, "unique": True}
                    }
                ],
                "primary_key": "id",
                "format": "json"
            },
            data_classification="INTERNAL"
        )
    
    @pytest.mark.asyncio
    async def test_execute_success(self, use_case, valid_contract_request, 
                                   mock_contract_repository, mock_audit_service):
        """Testa execução bem-sucedida do use case"""
        # Arrange
        user_id = "user123"
        mock_contract_repository.save.return_value = True
        mock_contract_repository.find_by_dataset_name.return_value = None
        
        # Act
        result = await use_case.execute(valid_contract_request, user_id)
        
        # Assert
        assert result is not None
        assert result.contract_id is not None
        assert result.validation_summary.is_valid is True
        assert result.validation_summary.validation_score == 100.0
        
        # Verificar se repositório foi chamado
        mock_contract_repository.save.assert_called_once()
        
        # Verificar se auditoria foi criada
        mock_audit_service.create_audit_event.assert_called()
    
    @pytest.mark.asyncio
    async def test_execute_validation_failure(self, use_case, valid_contract_request,
                                              mock_validation_service):
        """Testa execução com falha na validação"""
        # Arrange
        user_id = "user123"
        validation_errors = [
            ValidationError(
                field="title",
                message="Título inválido",
                severity=ValidationSeverity.ERROR,
                code="INVALID_TITLE"
            )
        ]
        mock_validation_service.validate_contract.return_value = validation_errors
        
        # Act & Assert
        with pytest.raises(ContractValidationException) as exc_info:
            await use_case.execute(valid_contract_request, user_id)
        
        assert len(exc_info.value.validation_errors) == 1
        assert exc_info.value.validation_errors[0].field == "title"
    
    @pytest.mark.asyncio
    async def test_execute_layout_validation_failure(self, use_case, valid_contract_request,
                                                     mock_layout_service):
        """Testa execução com falha na validação de layout"""
        # Arrange
        user_id = "user123"
        layout_result = LayoutValidationResult(
            is_valid=False,
            errors=[{"field": "schema", "message": "Schema inválido"}],
            warnings=[],
            suggestions=[],
            layout_hash="test_hash",
            compatibility_score=0.0
        )
        mock_layout_service.validate_layout.return_value = layout_result
        
        # Act & Assert
        with pytest.raises(Exception):  # Layout validation exception
            await use_case.execute(valid_contract_request, user_id)
    
    @pytest.mark.asyncio
    async def test_execute_duplicate_dataset_name(self, use_case, valid_contract_request,
                                                  mock_contract_repository):
        """Testa execução com nome de dataset duplicado"""
        # Arrange
        user_id = "user123"
        existing_contract = Contract(
            id=uuid4(),
            title="Contrato Existente",
            dataset_name="test_dataset",
            status=ContractStatus.ACTIVE
        )
        mock_contract_repository.find_by_dataset_name.return_value = existing_contract
        
        # Act & Assert
        with pytest.raises(ValueError, match="Dataset name já existe"):
            await use_case.execute(valid_contract_request, user_id)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

