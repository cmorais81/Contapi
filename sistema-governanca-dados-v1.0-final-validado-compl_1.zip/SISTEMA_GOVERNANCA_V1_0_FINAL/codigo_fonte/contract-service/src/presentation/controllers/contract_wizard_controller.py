"""
Contract Wizard Controller - Controller do Wizard de Contratos
Sistema de Governança de Dados V5.0

Responsável por:
- Wizard passo-a-passo para criação de contratos
- Templates e sugestões inteligentes
- Geração automática de layouts
- Interface amigável sem necessidade de codificação
"""

from fastapi import APIRouter, HTTPException, Query, Path, Depends
from fastapi.responses import HTMLResponse, Response
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import sys
import os

# Adicionar path do projeto
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))

from domain.services.contract_template_service import ContractTemplateService
from domain.services.contract_layout_generator import ContractLayoutGenerator

# Inicializar serviços
template_service = ContractTemplateService()
layout_generator = ContractLayoutGenerator()

# Router
wizard_router = APIRouter(prefix="/api/v1/wizard", tags=["Contract Wizard"])

# =====================================================
# MODELOS PYDANTIC
# =====================================================

class WizardStepRequest(BaseModel):
    step: int = Field(..., ge=1, le=5, description="Passo do wizard (1-5)")
    data: Dict[str, Any] = Field(..., description="Dados do passo atual")

class TemplateSelectionRequest(BaseModel):
    category: Optional[str] = Field(None, description="Categoria do template")
    template_id: Optional[str] = Field(None, description="ID do template específico")

class CustomFieldRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    type: str = Field(..., pattern="^(string|integer|decimal|boolean|date|datetime|json)$")
    description: Optional[str] = Field(None, max_length=500)
    required: bool = Field(False)
    pii: bool = Field(False)
    sensitive: bool = Field(False)

class ContractGenerationRequest(BaseModel):
    template_id: str = Field(..., description="ID do template")
    contract_metadata: Dict[str, Any] = Field(..., description="Metadados do contrato")
    custom_fields: Optional[List[CustomFieldRequest]] = Field(None, description="Campos customizados")
    custom_sla: Optional[Dict[str, Any]] = Field(None, description="SLA customizado")
    layout_id: str = Field("professional", description="ID do layout")
    theme_id: str = Field("corporate_blue", description="ID do tema")
    generate_formats: List[str] = Field(["html"], description="Formatos para gerar")

class LayoutPreviewRequest(BaseModel):
    contract_data: Dict[str, Any] = Field(..., description="Dados do contrato")
    layout_id: str = Field("professional", description="ID do layout")
    theme_id: str = Field("corporate_blue", description="ID do tema")

# =====================================================
# ENDPOINTS DO WIZARD
# =====================================================

@wizard_router.get("/")
async def wizard_home():
    """Página inicial do wizard"""
    return {
        "message": "Contract Wizard - Sistema de Criação de Contratos",
        "version": "5.0.0",
        "description": "Wizard passo-a-passo para criação de contratos sem necessidade de codificação",
        "steps": [
            {"step": 1, "title": "Seleção de Template", "description": "Escolha o tipo de dados"},
            {"step": 2, "title": "Configuração Básica", "description": "Defina informações gerais"},
            {"step": 3, "title": "Estrutura de Dados", "description": "Configure campos e schema"},
            {"step": 4, "title": "SLA e Compliance", "description": "Defina níveis de serviço"},
            {"step": 5, "title": "Layout e Geração", "description": "Escolha layout e gere contrato"}
        ],
        "features": [
            "Templates predefinidos",
            "Sugestões inteligentes",
            "Validação automática",
            "Múltiplos formatos de saída",
            "Interface sem código"
        ]
    }

@wizard_router.get("/step1/templates")
async def get_available_templates(category: Optional[str] = Query(None, description="Filtrar por categoria")):
    """Passo 1: Obter templates disponíveis"""
    try:
        if category:
            templates = template_service.get_templates_by_category(category)
        else:
            templates = template_service.get_available_templates()
        
        # Adicionar informações extras para o wizard
        for template in templates:
            template_detail = template_service.get_template_by_id(template.get('id', ''))
            if template_detail:
                template['field_count'] = (
                    len(template_detail['schema_template'].get('required_fields', [])) +
                    len(template_detail['schema_template'].get('optional_fields', []))
                )
                template['tables'] = template_detail['schema_template'].get('tables', [])
        
        return {
            "step": 1,
            "title": "Seleção de Template",
            "description": "Escolha o template que melhor se adequa ao seu tipo de dados",
            "templates": templates,
            "categories": ["finance", "customer", "sales", "hr", "analytics"],
            "next_step": "/api/v1/wizard/step2/configure"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao obter templates: {str(e)}")

@wizard_router.post("/step2/configure")
async def configure_contract_basics(request: TemplateSelectionRequest):
    """Passo 2: Configurar informações básicas do contrato"""
    try:
        template_id = request.template_id
        if not template_id:
            raise HTTPException(status_code=400, detail="Template ID é obrigatório")
        
        template = template_service.get_template_by_id(template_id)
        if not template:
            raise HTTPException(status_code=404, detail="Template não encontrado")
        
        # Sugestões baseadas no template
        suggestions = {
            "contract_name": f"Contrato {template['name']}",
            "description": template['description'],
            "data_classification": template['data_classification'],
            "compliance_requirements": template['compliance_requirements'],
            "owner_email_placeholder": "proprietario@empresa.com"
        }
        
        return {
            "step": 2,
            "title": "Configuração Básica",
            "description": "Defina as informações gerais do contrato",
            "template_info": {
                "id": template_id,
                "name": template['name'],
                "category": template['category']
            },
            "suggestions": suggestions,
            "required_fields": [
                {"name": "contract_name", "label": "Nome do Contrato", "type": "text", "required": True},
                {"name": "description", "label": "Descrição", "type": "textarea", "required": True},
                {"name": "owner_email", "label": "Email do Proprietário", "type": "email", "required": True},
                {"name": "data_classification", "label": "Classificação", "type": "select", 
                 "options": ["public", "internal", "confidential", "restricted"], "required": True}
            ],
            "next_step": "/api/v1/wizard/step3/schema"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro na configuração: {str(e)}")

@wizard_router.post("/step3/schema")
async def configure_data_schema(request: WizardStepRequest):
    """Passo 3: Configurar estrutura de dados"""
    try:
        if request.step != 3:
            raise HTTPException(status_code=400, detail="Passo inválido")
        
        template_id = request.data.get('template_id')
        if not template_id:
            raise HTTPException(status_code=400, detail="Template ID é obrigatório")
        
        template = template_service.get_template_by_id(template_id)
        if not template:
            raise HTTPException(status_code=404, detail="Template não encontrado")
        
        schema_template = template['schema_template']
        
        # Sugestões de campos baseadas na categoria
        category = template['category']
        field_suggestions = template_service.get_field_suggestions(category)
        
        return {
            "step": 3,
            "title": "Estrutura de Dados",
            "description": "Configure os campos e estrutura dos dados",
            "template_schema": {
                "tables": schema_template.get('tables', []),
                "required_fields": schema_template.get('required_fields', []),
                "optional_fields": schema_template.get('optional_fields', [])
            },
            "field_suggestions": field_suggestions,
            "field_types": [
                {"value": "string", "label": "Texto"},
                {"value": "integer", "label": "Número Inteiro"},
                {"value": "decimal", "label": "Número Decimal"},
                {"value": "boolean", "label": "Verdadeiro/Falso"},
                {"value": "date", "label": "Data"},
                {"value": "datetime", "label": "Data e Hora"},
                {"value": "json", "label": "JSON/Objeto"}
            ],
            "pii_detection": {
                "enabled": True,
                "description": "Campos marcados como PII serão automaticamente identificados"
            },
            "validation_rules": {
                "max_fields": 100,
                "required_field_limit": 50,
                "naming_pattern": "^[a-z][a-z0-9_]*$"
            },
            "next_step": "/api/v1/wizard/step4/sla"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro na configuração do schema: {str(e)}")

@wizard_router.post("/step4/sla")
async def configure_sla_compliance(request: WizardStepRequest):
    """Passo 4: Configurar SLA e compliance"""
    try:
        if request.step != 4:
            raise HTTPException(status_code=400, detail="Passo inválido")
        
        template_id = request.data.get('template_id')
        if not template_id:
            raise HTTPException(status_code=400, detail="Template ID é obrigatório")
        
        # Obter SLA template
        sla_template = template_service.sla_templates.get(template_id, {})
        
        # Sugestões de melhoria
        current_sla = request.data.get('sla_requirements', {})
        sla_suggestions = template_service.suggest_sla_improvements(current_sla, template_id)
        
        return {
            "step": 4,
            "title": "SLA e Compliance",
            "description": "Defina níveis de serviço e requisitos de conformidade",
            "sla_template": sla_template,
            "sla_suggestions": sla_suggestions,
            "sla_metrics": [
                {"name": "availability", "label": "Disponibilidade", "unit": "%", "example": "99.9%"},
                {"name": "response_time", "label": "Tempo de Resposta", "unit": "ms", "example": "< 100ms"},
                {"name": "data_freshness", "label": "Atualização dos Dados", "unit": "min", "example": "< 5min"},
                {"name": "backup_frequency", "label": "Frequência de Backup", "unit": "period", "example": "daily"},
                {"name": "retention_period", "label": "Período de Retenção", "unit": "time", "example": "7 years"},
                {"name": "recovery_time", "label": "Tempo de Recuperação", "unit": "hours", "example": "< 4h"},
                {"name": "accuracy", "label": "Precisão dos Dados", "unit": "%", "example": "99.99%"}
            ],
            "compliance_frameworks": [
                {"id": "LGPD", "name": "Lei Geral de Proteção de Dados", "description": "Regulamentação brasileira"},
                {"id": "GDPR", "name": "General Data Protection Regulation", "description": "Regulamentação europeia"},
                {"id": "SOX", "name": "Sarbanes-Oxley Act", "description": "Controles financeiros"},
                {"id": "HIPAA", "name": "Health Insurance Portability", "description": "Dados de saúde"},
                {"id": "PCI-DSS", "name": "Payment Card Industry", "description": "Dados de pagamento"}
            ],
            "next_step": "/api/v1/wizard/step5/generate"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro na configuração de SLA: {str(e)}")

@wizard_router.post("/step5/generate")
async def generate_contract_final(request: ContractGenerationRequest):
    """Passo 5: Gerar contrato final"""
    try:
        # Converter custom fields para formato interno
        custom_fields_internal = []
        if request.custom_fields:
            for field in request.custom_fields:
                custom_fields_internal.append({
                    "name": field.name,
                    "type": field.type,
                    "description": field.description,
                    "required": field.required,
                    "pii": field.pii,
                    "sensitive": field.sensitive
                })
        
        # Gerar contrato usando template service
        contract_data = template_service.generate_contract_from_template(
            template_id=request.template_id,
            custom_fields=custom_fields_internal,
            custom_sla=request.custom_sla,
            contract_metadata=request.contract_metadata
        )
        
        # Validar schema
        validation_result = template_service.validate_contract_schema(
            contract_data['schema_definition']
        )
        
        # Gerar layouts nos formatos solicitados
        generated_formats = {}
        
        if "html" in request.generate_formats:
            html_content = layout_generator.generate_html_layout(
                contract_data, request.layout_id, request.theme_id
            )
            generated_formats["html"] = {
                "content": html_content,
                "filename": f"contrato_{contract_data.get('name', 'sem_titulo').replace(' ', '_').lower()}.html"
            }
        
        if "pdf" in request.generate_formats:
            pdf_content = layout_generator.generate_pdf_layout(
                contract_data, request.layout_id, request.theme_id
            )
            generated_formats["pdf"] = {
                "content": pdf_content.decode('utf-8'),  # Para demo, em produção seria binário
                "filename": f"contrato_{contract_data.get('name', 'sem_titulo').replace(' ', '_').lower()}.pdf"
            }
        
        if "word" in request.generate_formats:
            word_content = layout_generator.generate_word_layout(
                contract_data, request.layout_id
            )
            generated_formats["word"] = {
                "content": word_content.decode('utf-8'),  # Para demo, em produção seria binário
                "filename": f"contrato_{contract_data.get('name', 'sem_titulo').replace(' ', '_').lower()}.docx"
            }
        
        # Preview do layout
        layout_preview = layout_generator.preview_layout(
            contract_data, request.layout_id, request.theme_id
        )
        
        return {
            "step": 5,
            "title": "Contrato Gerado",
            "description": "Seu contrato foi gerado com sucesso",
            "contract_data": contract_data,
            "validation_result": validation_result,
            "layout_preview": layout_preview,
            "generated_formats": generated_formats,
            "download_links": {
                format_type: f"/api/v1/wizard/download/{format_type}/{contract_data.get('name', 'contrato').replace(' ', '_').lower()}"
                for format_type in generated_formats.keys()
            },
            "next_actions": [
                {"action": "save_to_database", "label": "Salvar no Banco de Dados", "endpoint": "/api/v1/contracts"},
                {"action": "send_for_approval", "label": "Enviar para Aprovação", "endpoint": "/api/v1/contracts/approval"},
                {"action": "create_new", "label": "Criar Novo Contrato", "endpoint": "/api/v1/wizard/"}
            ]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro na geração do contrato: {str(e)}")

# =====================================================
# ENDPOINTS AUXILIARES
# =====================================================

@wizard_router.get("/templates/{template_id}")
async def get_template_details(template_id: str = Path(..., description="ID do template")):
    """Obter detalhes de um template específico"""
    try:
        template = template_service.get_template_by_id(template_id)
        if not template:
            raise HTTPException(status_code=404, detail="Template não encontrado")
        
        return {
            "template": template,
            "field_count": {
                "required": len(template['schema_template'].get('required_fields', [])),
                "optional": len(template['schema_template'].get('optional_fields', []))
            },
            "estimated_complexity": "low" if len(template['schema_template'].get('required_fields', [])) < 10 else "medium"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao obter template: {str(e)}")

@wizard_router.get("/field-suggestions")
async def get_field_suggestions(
    category: str = Query(..., description="Categoria do template"),
    partial_name: str = Query("", description="Nome parcial para busca")
):
    """Obter sugestões de campos"""
    try:
        suggestions = template_service.get_field_suggestions(category, partial_name)
        
        return {
            "category": category,
            "partial_name": partial_name,
            "suggestions": suggestions,
            "total_suggestions": len(suggestions)
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao obter sugestões: {str(e)}")

@wizard_router.post("/validate-schema")
async def validate_contract_schema(schema_definition: Dict[str, Any]):
    """Validar schema do contrato"""
    try:
        validation_result = template_service.validate_contract_schema(schema_definition)
        
        return {
            "validation_result": validation_result,
            "is_valid": validation_result["valid"],
            "error_count": len(validation_result["errors"]),
            "warning_count": len(validation_result["warnings"]),
            "suggestion_count": len(validation_result["suggestions"])
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro na validação: {str(e)}")

@wizard_router.get("/layouts")
async def get_available_layouts():
    """Obter layouts disponíveis"""
    try:
        layouts = layout_generator.get_available_layouts()
        themes = layout_generator.get_available_themes()
        
        return {
            "layouts": layouts,
            "themes": themes,
            "default_layout": "professional",
            "default_theme": "corporate_blue"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao obter layouts: {str(e)}")

@wizard_router.post("/preview-layout")
async def preview_contract_layout(request: LayoutPreviewRequest):
    """Gerar preview do layout"""
    try:
        preview = layout_generator.preview_layout(
            request.contract_data,
            request.layout_id,
            request.theme_id
        )
        
        return {
            "preview": preview,
            "layout_id": request.layout_id,
            "theme_id": request.theme_id
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no preview: {str(e)}")

@wizard_router.get("/download/{format_type}/{filename}")
async def download_contract(
    format_type: str = Path(..., description="Formato do arquivo"),
    filename: str = Path(..., description="Nome do arquivo")
):
    """Download do contrato gerado"""
    try:
        # Em implementação real, buscar arquivo do storage
        content = f"Arquivo {format_type.upper()} - {filename}"
        
        media_types = {
            "html": "text/html",
            "pdf": "application/pdf",
            "word": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        }
        
        media_type = media_types.get(format_type, "text/plain")
        
        return Response(
            content=content,
            media_type=media_type,
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no download: {str(e)}")

@wizard_router.get("/help")
async def get_wizard_help():
    """Obter ajuda do wizard"""
    return {
        "wizard_guide": {
            "title": "Guia do Wizard de Contratos",
            "description": "Sistema intuitivo para criação de contratos sem necessidade de codificação",
            "steps_guide": [
                {
                    "step": 1,
                    "title": "Seleção de Template",
                    "tips": [
                        "Escolha o template que melhor representa seu tipo de dados",
                        "Templates incluem campos e validações predefinidas",
                        "Você pode personalizar qualquer template posteriormente"
                    ]
                },
                {
                    "step": 2,
                    "title": "Configuração Básica",
                    "tips": [
                        "Use nomes descritivos para facilitar identificação",
                        "A classificação de dados afeta as sugestões de compliance",
                        "O email do proprietário será usado para notificações"
                    ]
                },
                {
                    "step": 3,
                    "title": "Estrutura de Dados",
                    "tips": [
                        "Campos obrigatórios garantem qualidade dos dados",
                        "Marque campos PII para compliance automático",
                        "Use sugestões inteligentes para acelerar configuração"
                    ]
                },
                {
                    "step": 4,
                    "title": "SLA e Compliance",
                    "tips": [
                        "SLAs realistas evitam problemas futuros",
                        "Compliance é automaticamente sugerido baseado nos dados",
                        "Métricas podem ser ajustadas conforme necessidade"
                    ]
                },
                {
                    "step": 5,
                    "title": "Geração Final",
                    "tips": [
                        "Múltiplos formatos facilitam distribuição",
                        "Preview permite ajustes antes da finalização",
                        "Contratos podem ser salvos e editados posteriormente"
                    ]
                }
            ]
        },
        "faq": [
            {
                "question": "Posso modificar um template existente?",
                "answer": "Sim, todos os templates podem ser personalizados com campos adicionais e SLAs específicos."
            },
            {
                "question": "Como funciona a detecção automática de PII?",
                "answer": "O sistema analisa nomes e tipos de campos para identificar automaticamente informações pessoais."
            },
            {
                "question": "Posso criar meus próprios templates?",
                "answer": "Atualmente, você pode personalizar templates existentes. Criação de templates personalizados será adicionada em versões futuras."
            },
            {
                "question": "Os contratos gerados são válidos legalmente?",
                "answer": "Os contratos são documentos técnicos. Para validade legal, consulte departamento jurídico."
            }
        ],
        "best_practices": [
            "Use nomes descritivos e consistentes para campos",
            "Sempre marque campos PII adequadamente",
            "Defina SLAs realistas baseados na infraestrutura",
            "Revise compliance requirements com equipe jurídica",
            "Mantenha documentação atualizada"
        ]
    }

