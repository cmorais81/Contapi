"""
Contract Use Cases - Casos de uso para contratos
Segue Dependency Inversion Principle - depende de abstrações
"""

from typing import List, Optional, Dict, Any
from datetime import datetime
from uuid import uuid4

from ..services.contract_service import ContractService
from ...domain.entities.contract import Contract, ContractStatus, DataClassification
from ...domain.repositories.contract_repository import ContractRepository, ContractQueryRepository
from ...domain.services.contract_validation_service import ContractValidationService, ValidationResult


class CreateContractUseCase:
    """
    Caso de uso para criar contrato
    Responsabilidade única: orquestrar criação de contratos
    """
    
    def __init__(self, 
                 repository: ContractRepository,
                 validation_service: ContractValidationService,
                 contract_service: ContractService):
        self._repository = repository
        self._validation_service = validation_service
        self._contract_service = contract_service
    
    async def execute(self, contract_data: Dict[str, Any]) -> Dict[str, Any]:
        """Executa criação de contrato"""
        try:
            # Criar entidade
            contract = Contract(
                name=contract_data['name'],
                data_classification=DataClassification(contract_data['data_classification']),
                owner_email=contract_data['owner_email'],
                description=contract_data.get('description'),
                template_id=contract_data.get('template_id'),
                schema_definition=contract_data.get('schema_definition'),
                sla_requirements=contract_data.get('sla_requirements'),
                compliance_requirements=contract_data.get('compliance_requirements', [])
            )
            
            # Validar contrato
            validation_result = self._validation_service.validate_contract(contract)
            if not validation_result.is_valid:
                return {
                    'success': False,
                    'errors': validation_result.errors,
                    'warnings': validation_result.warnings
                }
            
            # Detectar PII se schema fornecido
            if contract.schema_definition:
                pii_fields = await self._contract_service.detect_pii_fields(contract.schema_definition)
                for field in pii_fields:
                    contract.add_pii_field(field)
            
            # Salvar contrato
            saved_contract = await self._repository.save(contract)
            
            return {
                'success': True,
                'contract': saved_contract.to_dict(),
                'warnings': validation_result.warnings
            }
            
        except Exception as e:
            return {
                'success': False,
                'errors': [f"Erro interno: {str(e)}"]
            }


class UpdateContractUseCase:
    """Caso de uso para atualizar contrato"""
    
    def __init__(self, 
                 repository: ContractRepository,
                 validation_service: ContractValidationService,
                 contract_service: ContractService):
        self._repository = repository
        self._validation_service = validation_service
        self._contract_service = contract_service
    
    async def execute(self, contract_id: str, update_data: Dict[str, Any]) -> Dict[str, Any]:
        """Executa atualização de contrato"""
        try:
            # Buscar contrato existente
            existing_contract = await self._repository.find_by_id(contract_id)
            if not existing_contract:
                return {
                    'success': False,
                    'errors': ['Contrato não encontrado']
                }
            
            # Aplicar atualizações
            if 'name' in update_data:
                existing_contract.name = update_data['name']
            
            if 'description' in update_data:
                existing_contract.description = update_data['description']
            
            if 'data_classification' in update_data:
                existing_contract.data_classification = DataClassification(update_data['data_classification'])
            
            if 'schema_definition' in update_data:
                # Validar compatibilidade de schema
                compatibility_result = self._validation_service.validate_schema_compatibility(
                    existing_contract.schema_definition,
                    update_data['schema_definition']
                )
                
                if not compatibility_result.is_valid:
                    return {
                        'success': False,
                        'errors': compatibility_result.errors,
                        'warnings': compatibility_result.warnings
                    }
                
                existing_contract.schema_definition = update_data['schema_definition']
                
                # Re-detectar PII
                pii_fields = await self._contract_service.detect_pii_fields(update_data['schema_definition'])
                existing_contract.pii_fields = pii_fields
            
            if 'compliance_requirements' in update_data:
                existing_contract.compliance_requirements = update_data['compliance_requirements']
            
            # Atualizar timestamp
            existing_contract.data_atualizacao = datetime.now()
            
            # Validar contrato atualizado
            validation_result = self._validation_service.validate_contract(existing_contract)
            if not validation_result.is_valid:
                return {
                    'success': False,
                    'errors': validation_result.errors,
                    'warnings': validation_result.warnings
                }
            
            # Salvar alterações
            updated_contract = await self._repository.update(existing_contract)
            
            return {
                'success': True,
                'contract': updated_contract.to_dict(),
                'warnings': validation_result.warnings
            }
            
        except Exception as e:
            return {
                'success': False,
                'errors': [f"Erro interno: {str(e)}"]
            }


class ActivateContractUseCase:
    """Caso de uso para ativar contrato"""
    
    def __init__(self, 
                 repository: ContractRepository,
                 validation_service: ContractValidationService):
        self._repository = repository
        self._validation_service = validation_service
    
    async def execute(self, contract_id: str) -> Dict[str, Any]:
        """Executa ativação de contrato"""
        try:
            # Buscar contrato
            contract = await self._repository.find_by_id(contract_id)
            if not contract:
                return {
                    'success': False,
                    'errors': ['Contrato não encontrado']
                }
            
            # Validar para ativação
            validation_result = self._validation_service.validate_for_activation(contract)
            if not validation_result.is_valid:
                return {
                    'success': False,
                    'errors': validation_result.errors,
                    'warnings': validation_result.warnings
                }
            
            # Ativar contrato
            contract.update_status(ContractStatus.ACTIVE)
            updated_contract = await self._repository.update(contract)
            
            return {
                'success': True,
                'contract': updated_contract.to_dict(),
                'warnings': validation_result.warnings
            }
            
        except Exception as e:
            return {
                'success': False,
                'errors': [f"Erro interno: {str(e)}"]
            }


class GetContractUseCase:
    """Caso de uso para buscar contrato"""
    
    def __init__(self, repository: ContractRepository):
        self._repository = repository
    
    async def execute(self, contract_id: str) -> Dict[str, Any]:
        """Executa busca de contrato"""
        try:
            contract = await self._repository.find_by_id(contract_id)
            if not contract:
                return {
                    'success': False,
                    'errors': ['Contrato não encontrado']
                }
            
            return {
                'success': True,
                'contract': contract.to_dict()
            }
            
        except Exception as e:
            return {
                'success': False,
                'errors': [f"Erro interno: {str(e)}"]
            }


class ListContractsUseCase:
    """Caso de uso para listar contratos"""
    
    def __init__(self, 
                 repository: ContractRepository,
                 query_repository: ContractQueryRepository):
        self._repository = repository
        self._query_repository = query_repository
    
    async def execute(self, 
                     limit: int = 100, 
                     offset: int = 0,
                     filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Executa listagem de contratos"""
        try:
            if filters:
                contracts = await self._repository.search("", filters)
            else:
                contracts = await self._repository.find_all(limit, offset)
            
            total_count = await self._repository.count()
            
            return {
                'success': True,
                'contracts': [contract.to_dict() for contract in contracts],
                'total': total_count,
                'limit': limit,
                'offset': offset
            }
            
        except Exception as e:
            return {
                'success': False,
                'errors': [f"Erro interno: {str(e)}"]
            }


class DeleteContractUseCase:
    """Caso de uso para deletar contrato"""
    
    def __init__(self, repository: ContractRepository):
        self._repository = repository
    
    async def execute(self, contract_id: str) -> Dict[str, Any]:
        """Executa deleção de contrato"""
        try:
            # Verificar se existe
            exists = await self._repository.exists(contract_id)
            if not exists:
                return {
                    'success': False,
                    'errors': ['Contrato não encontrado']
                }
            
            # Deletar
            deleted = await self._repository.delete(contract_id)
            
            return {
                'success': deleted,
                'message': 'Contrato deletado com sucesso' if deleted else 'Falha ao deletar contrato'
            }
            
        except Exception as e:
            return {
                'success': False,
                'errors': [f"Erro interno: {str(e)}"]
            }


class GetContractStatisticsUseCase:
    """Caso de uso para estatísticas de contratos"""
    
    def __init__(self, query_repository: ContractQueryRepository):
        self._query_repository = query_repository
    
    async def execute(self) -> Dict[str, Any]:
        """Executa busca de estatísticas"""
        try:
            statistics = await self._query_repository.get_statistics()
            
            return {
                'success': True,
                'statistics': statistics
            }
            
        except Exception as e:
            return {
                'success': False,
                'errors': [f"Erro interno: {str(e)}"]
            }

