# Autor: carlos.morais@f1rst.com.br
"""
Use Case: Criar Contrato com Validação Automática de Layout Ativo
"""

from datetime import datetime
from typing import List, Dict, Any, Optional
from uuid import UUID

from ...domain.entities.contract import Contract
from ...domain.services.contract_validation_service import ContractValidationService, ValidationError
from ...domain.services.contract_layout_service import ContractLayoutService, LayoutValidationResult
from ...domain.value_objects.contract_status import ContractStatus
from ..dtos.contract_dtos import CreateContractRequest, ContractResponse


class ContractValidationException(Exception):
    """Exceção para erros de validação de contrato"""
    
    def __init__(self, message: str, validation_errors: List[ValidationError]):
        super().__init__(message)
        self.validation_errors = validation_errors
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "message": str(self),
            "validation_errors": [error.to_dict() for error in self.validation_errors],
            "timestamp": datetime.utcnow().isoformat()
        }


class LayoutValidationException(Exception):
    """Exceção para erros de validação de layout"""
    
    def __init__(self, message: str, layout_result: LayoutValidationResult):
        super().__init__(message)
        self.layout_result = layout_result
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "message": str(self),
            "layout_validation": self.layout_result.to_dict(),
            "timestamp": datetime.utcnow().isoformat()
        }


class CreateContractWithValidationUseCase:
    """
    Use Case para criar contrato com validação automática completa
    
    Responsabilidades:
    - Validar dados de entrada
    - Executar validação completa do contrato
    - Validar layout ativo
    - Verificar regras de negócio
    - Persistir contrato se válido
    - Gerar eventos de auditoria
    """
    
    def __init__(
        self,
        contract_repository,
        contract_validation_service: ContractValidationService,
        contract_layout_service: ContractLayoutService,
        audit_service,
        notification_service
    ):
        """
        Inicializa o use case
        
        Args:
            contract_repository: Repositório de contratos
            contract_validation_service: Serviço de validação
            contract_layout_service: Serviço de layout
            audit_service: Serviço de auditoria
            notification_service: Serviço de notificação
        """
        self._contract_repository = contract_repository
        self._validation_service = contract_validation_service
        self._layout_service = contract_layout_service
        self._audit_service = audit_service
        self._notification_service = notification_service
    
    async def execute(self, request: CreateContractRequest, user_id: str) -> ContractResponse:
        """
        Executa a criação do contrato com validação automática
        
        Args:
            request: Dados da requisição
            user_id: ID do usuário criador
            
        Returns:
            ContractResponse: Contrato criado
            
        Raises:
            ContractValidationException: Se houver erros de validação
            LayoutValidationException: Se houver erros de layout
            Exception: Se ocorrer erro na persistência
        """
        try:
            # 1. Criar entidade Contract a partir da requisição
            contract = self._create_contract_from_request(request, user_id)
            
            # 2. Executar validação completa do contrato
            validation_errors = await self._validate_contract(contract)
            
            # 3. Executar validação de layout ativo
            layout_result = await self._validate_layout(contract)
            
            # 4. Verificar se há erros críticos
            self._check_critical_errors(validation_errors, layout_result)
            
            # 5. Persistir contrato
            saved_contract = await self._save_contract(contract)
            
            # 6. Gerar eventos de auditoria
            await self._create_audit_events(saved_contract, user_id, validation_errors, layout_result)
            
            # 7. Enviar notificações se necessário
            await self._send_notifications(saved_contract, validation_errors, layout_result)
            
            # 8. Retornar resposta
            return ContractResponse.from_entity(saved_contract, validation_errors, layout_result)
            
        except (ContractValidationException, LayoutValidationException):
            # Re-raise validation exceptions
            raise
        except Exception as e:
            # Log erro e criar evento de auditoria
            await self._handle_creation_error(request, user_id, str(e))
            raise Exception(f"Erro ao criar contrato: {str(e)}")
    
    def _create_contract_from_request(self, request: CreateContractRequest, user_id: str) -> Contract:
        """
        Cria entidade Contract a partir da requisição
        
        Args:
            request: Dados da requisição
            user_id: ID do usuário
            
        Returns:
            Contract: Entidade criada
        """
        contract = Contract(
            title=request.title,
            description=request.description,
            version=request.version or "1.0.0",
            status=ContractStatus.DRAFT,
            owner_id=UUID(user_id),
            organization_id=request.organization_id,
            steward_id=request.steward_id,
            dataset_id=request.dataset_id,
            dataset_name=request.dataset_name,
            schema_definition=request.schema_definition,
            data_classification=request.data_classification,
            effective_date=request.effective_date,
            expiration_date=request.expiration_date,
            sla_requirements=request.sla_requirements,
            quality_requirements=request.quality_requirements,
            lgpd_compliance=request.lgpd_compliance,
            tags=request.tags or [],
            metadata=request.metadata or {}
        )
        
        return contract
    
    async def _validate_contract(self, contract: Contract) -> List[ValidationError]:
        """
        Executa validação completa do contrato
        
        Args:
            contract: Contrato a ser validado
            
        Returns:
            List[ValidationError]: Lista de erros encontrados
        """
        return self._validation_service.validate_contract(contract)
    
    async def _validate_layout(self, contract: Contract) -> LayoutValidationResult:
        """
        Executa validação de layout ativo
        
        Args:
            contract: Contrato a ser validado
            
        Returns:
            LayoutValidationResult: Resultado da validação de layout
        """
        return self._layout_service.validate_layout(contract)
    
    def _check_critical_errors(self, validation_errors: List[ValidationError], layout_result: LayoutValidationResult):
        """
        Verifica se há erros críticos que impedem a criação
        
        Args:
            validation_errors: Erros de validação
            layout_result: Resultado da validação de layout
            
        Raises:
            ContractValidationException: Se houver erros críticos de validação
            LayoutValidationException: Se houver erros críticos de layout
        """
        # Verificar erros críticos de validação
        critical_validation_errors = [error for error in validation_errors if error.severity == "error"]
        
        if critical_validation_errors:
            raise ContractValidationException(
                f"Contrato possui {len(critical_validation_errors)} erro(s) crítico(s) de validação",
                critical_validation_errors
            )
        
        # Verificar erros críticos de layout
        if not layout_result.is_valid:
            raise LayoutValidationException(
                f"Layout do contrato é inválido: {len(layout_result.errors)} erro(s) encontrado(s)",
                layout_result
            )
    
    async def _save_contract(self, contract: Contract) -> Contract:
        """
        Persiste o contrato no repositório
        
        Args:
            contract: Contrato a ser persistido
            
        Returns:
            Contract: Contrato persistido
            
        Raises:
            Exception: Se ocorrer erro na persistência
        """
        try:
            return await self._contract_repository.create(contract)
        except Exception as e:
            raise Exception(f"Erro ao persistir contrato: {str(e)}")
    
    async def _create_audit_events(
        self,
        contract: Contract,
        user_id: str,
        validation_errors: List[ValidationError],
        layout_result: LayoutValidationResult
    ):
        """
        Cria eventos de auditoria para a criação do contrato
        
        Args:
            contract: Contrato criado
            user_id: ID do usuário
            validation_errors: Erros de validação
            layout_result: Resultado da validação de layout
        """
        try:
            # Evento principal de criação
            await self._audit_service.create_contract_created_event(
                contract_id=str(contract.id),
                user_id=user_id,
                contract_title=contract.title,
                dataset_name=contract.dataset_name,
                data_classification=contract.data_classification.value,
                validation_score=self._calculate_validation_score(validation_errors, layout_result)
            )
            
            # Eventos de validação se houver warnings
            warnings = [error for error in validation_errors if error.severity == "warning"]
            if warnings:
                await self._audit_service.create_validation_warning_event(
                    contract_id=str(contract.id),
                    user_id=user_id,
                    warning_count=len(warnings),
                    warnings=[error.to_dict() for error in warnings]
                )
            
            # Eventos de layout se houver sugestões
            if layout_result.suggestions:
                await self._audit_service.create_layout_suggestion_event(
                    contract_id=str(contract.id),
                    user_id=user_id,
                    suggestion_count=len(layout_result.suggestions),
                    suggestions=layout_result.suggestions
                )
                
        except Exception as e:
            # Log erro mas não falha a criação do contrato
            print(f"Erro ao criar eventos de auditoria: {e}")
    
    async def _send_notifications(
        self,
        contract: Contract,
        validation_errors: List[ValidationError],
        layout_result: LayoutValidationResult
    ):
        """
        Envia notificações sobre a criação do contrato
        
        Args:
            contract: Contrato criado
            validation_errors: Erros de validação
            layout_result: Resultado da validação de layout
        """
        try:
            # Notificar steward se definido
            if contract.steward_id:
                await self._notification_service.notify_contract_created(
                    recipient_id=str(contract.steward_id),
                    contract_id=str(contract.id),
                    contract_title=contract.title,
                    has_warnings=len([e for e in validation_errors if e.severity == "warning"]) > 0,
                    has_suggestions=len(layout_result.suggestions) > 0
                )
            
            # Notificar owner
            await self._notification_service.notify_contract_created(
                recipient_id=str(contract.owner_id),
                contract_id=str(contract.id),
                contract_title=contract.title,
                has_warnings=len([e for e in validation_errors if e.severity == "warning"]) > 0,
                has_suggestions=len(layout_result.suggestions) > 0
            )
            
        except Exception as e:
            # Log erro mas não falha a criação do contrato
            print(f"Erro ao enviar notificações: {e}")
    
    async def _handle_creation_error(self, request: CreateContractRequest, user_id: str, error_message: str):
        """
        Trata erros durante a criação do contrato
        
        Args:
            request: Requisição original
            user_id: ID do usuário
            error_message: Mensagem de erro
        """
        try:
            await self._audit_service.create_contract_creation_failed_event(
                user_id=user_id,
                contract_title=request.title,
                dataset_name=request.dataset_name,
                error_message=error_message
            )
        except Exception:
            # Se falhar ao criar evento de auditoria, apenas log
            print(f"Erro ao criar evento de auditoria para falha: {error_message}")
    
    def _calculate_validation_score(self, validation_errors: List[ValidationError], layout_result: LayoutValidationResult) -> float:
        """
        Calcula score de validação baseado nos erros e warnings
        
        Args:
            validation_errors: Erros de validação
            layout_result: Resultado da validação de layout
            
        Returns:
            float: Score de 0 a 100
        """
        score = 100.0
        
        # Penalizar por erros de validação
        for error in validation_errors:
            if error.severity == "error":
                score -= 20
            elif error.severity == "warning":
                score -= 5
            elif error.severity == "info":
                score -= 1
        
        # Penalizar por erros de layout
        score -= len(layout_result.errors) * 15
        score -= len(layout_result.warnings) * 3
        
        # Usar score de compatibilidade do layout se disponível
        if layout_result.compatibility_score > 0:
            score = (score + layout_result.compatibility_score) / 2
        
        return max(0.0, min(100.0, score))


class UpdateContractWithValidationUseCase:
    """
    Use Case para atualizar contrato com validação automática
    """
    
    def __init__(
        self,
        contract_repository,
        contract_validation_service: ContractValidationService,
        contract_layout_service: ContractLayoutService,
        audit_service,
        notification_service
    ):
        """Inicializa o use case de atualização"""
        self._contract_repository = contract_repository
        self._validation_service = contract_validation_service
        self._layout_service = contract_layout_service
        self._audit_service = audit_service
        self._notification_service = notification_service
    
    async def execute(self, contract_id: UUID, request: CreateContractRequest, user_id: str) -> ContractResponse:
        """
        Executa a atualização do contrato com validação automática
        
        Args:
            contract_id: ID do contrato a ser atualizado
            request: Dados da atualização
            user_id: ID do usuário
            
        Returns:
            ContractResponse: Contrato atualizado
            
        Raises:
            ContractValidationException: Se houver erros de validação
            LayoutValidationException: Se houver erros de layout
            Exception: Se contrato não for encontrado ou erro na persistência
        """
        try:
            # 1. Buscar contrato existente
            existing_contract = await self._contract_repository.get_by_id(contract_id)
            if not existing_contract:
                raise Exception(f"Contrato {contract_id} não encontrado")
            
            # 2. Criar nova versão do contrato
            updated_contract = self._update_contract_from_request(existing_contract, request, user_id)
            
            # 3. Executar validação completa
            validation_errors = await self._validate_contract(updated_contract)
            
            # 4. Executar validação de layout ativo
            layout_result = await self._validate_layout(updated_contract)
            
            # 5. Verificar compatibilidade com versão anterior
            compatibility_result = await self._check_compatibility(existing_contract, updated_contract)
            
            # 6. Verificar se há erros críticos
            self._check_critical_errors(validation_errors, layout_result, compatibility_result)
            
            # 7. Persistir contrato atualizado
            saved_contract = await self._save_updated_contract(updated_contract)
            
            # 8. Gerar eventos de auditoria
            await self._create_update_audit_events(
                existing_contract, saved_contract, user_id, 
                validation_errors, layout_result, compatibility_result
            )
            
            # 9. Enviar notificações
            await self._send_update_notifications(
                saved_contract, validation_errors, layout_result, compatibility_result
            )
            
            return ContractResponse.from_entity(saved_contract, validation_errors, layout_result)
            
        except (ContractValidationException, LayoutValidationException):
            raise
        except Exception as e:
            await self._handle_update_error(contract_id, request, user_id, str(e))
            raise Exception(f"Erro ao atualizar contrato: {str(e)}")
    
    def _update_contract_from_request(self, existing_contract: Contract, request: CreateContractRequest, user_id: str) -> Contract:
        """Atualiza contrato existente com dados da requisição"""
        # Criar nova versão incrementando a versão
        version_parts = existing_contract.version.split('.')
        version_parts[-1] = str(int(version_parts[-1]) + 1)
        new_version = '.'.join(version_parts)
        
        # Atualizar campos
        existing_contract.title = request.title
        existing_contract.description = request.description
        existing_contract.version = new_version
        existing_contract.dataset_name = request.dataset_name
        existing_contract.schema_definition = request.schema_definition
        existing_contract.data_classification = request.data_classification
        existing_contract.effective_date = request.effective_date
        existing_contract.expiration_date = request.expiration_date
        existing_contract.sla_requirements = request.sla_requirements
        existing_contract.quality_requirements = request.quality_requirements
        existing_contract.lgpd_compliance = request.lgpd_compliance
        existing_contract.tags = request.tags or existing_contract.tags
        existing_contract.metadata = request.metadata or existing_contract.metadata
        existing_contract.updated_at = datetime.utcnow()
        
        return existing_contract
    
    async def _validate_contract(self, contract: Contract) -> List[ValidationError]:
        """Executa validação completa do contrato"""
        return self._validation_service.validate_contract(contract)
    
    async def _validate_layout(self, contract: Contract) -> LayoutValidationResult:
        """Executa validação de layout ativo"""
        return self._layout_service.validate_layout(contract)
    
    async def _check_compatibility(self, old_contract: Contract, new_contract: Contract) -> LayoutValidationResult:
        """Verifica compatibilidade entre versões"""
        return self._layout_service.check_compatibility(old_contract, new_contract)
    
    def _check_critical_errors(
        self, 
        validation_errors: List[ValidationError], 
        layout_result: LayoutValidationResult,
        compatibility_result: LayoutValidationResult
    ):
        """Verifica erros críticos incluindo compatibilidade"""
        # Verificar erros de validação
        critical_validation_errors = [error for error in validation_errors if error.severity == "error"]
        if critical_validation_errors:
            raise ContractValidationException(
                f"Contrato possui {len(critical_validation_errors)} erro(s) crítico(s) de validação",
                critical_validation_errors
            )
        
        # Verificar erros de layout
        if not layout_result.is_valid:
            raise LayoutValidationException(
                f"Layout do contrato é inválido: {len(layout_result.errors)} erro(s) encontrado(s)",
                layout_result
            )
        
        # Verificar breaking changes
        breaking_changes = [error for error in compatibility_result.errors if "breaking" in error.get("message", "").lower()]
        if breaking_changes:
            raise LayoutValidationException(
                f"Atualização contém {len(breaking_changes)} breaking change(s)",
                compatibility_result
            )
    
    async def _save_updated_contract(self, contract: Contract) -> Contract:
        """Persiste contrato atualizado"""
        try:
            return await self._contract_repository.update(contract)
        except Exception as e:
            raise Exception(f"Erro ao persistir contrato atualizado: {str(e)}")
    
    async def _create_update_audit_events(
        self,
        old_contract: Contract,
        new_contract: Contract,
        user_id: str,
        validation_errors: List[ValidationError],
        layout_result: LayoutValidationResult,
        compatibility_result: LayoutValidationResult
    ):
        """Cria eventos de auditoria para atualização"""
        try:
            await self._audit_service.create_contract_updated_event(
                contract_id=str(new_contract.id),
                user_id=user_id,
                old_version=old_contract.version,
                new_version=new_contract.version,
                compatibility_score=compatibility_result.compatibility_score,
                has_breaking_changes=len([e for e in compatibility_result.errors if "breaking" in e.get("message", "").lower()]) > 0
            )
        except Exception as e:
            print(f"Erro ao criar eventos de auditoria para atualização: {e}")
    
    async def _send_update_notifications(
        self,
        contract: Contract,
        validation_errors: List[ValidationError],
        layout_result: LayoutValidationResult,
        compatibility_result: LayoutValidationResult
    ):
        """Envia notificações sobre atualização"""
        try:
            # Notificar stakeholders sobre a atualização
            if contract.steward_id:
                await self._notification_service.notify_contract_updated(
                    recipient_id=str(contract.steward_id),
                    contract_id=str(contract.id),
                    contract_title=contract.title,
                    new_version=contract.version,
                    has_breaking_changes=len([e for e in compatibility_result.errors if "breaking" in e.get("message", "").lower()]) > 0
                )
        except Exception as e:
            print(f"Erro ao enviar notificações de atualização: {e}")
    
    async def _handle_update_error(self, contract_id: UUID, request: CreateContractRequest, user_id: str, error_message: str):
        """Trata erros durante atualização"""
        try:
            await self._audit_service.create_contract_update_failed_event(
                contract_id=str(contract_id),
                user_id=user_id,
                error_message=error_message
            )
        except Exception:
            print(f"Erro ao criar evento de auditoria para falha na atualização: {error_message}")

