# Autor: carlos.morais@f1rst.com.br
"""
Data Transfer Objects (DTOs) for Contract Service
"""

from typing import List, Optional, Dict, Any
from datetime import datetime
from uuid import UUID
from pydantic import BaseModel, Field, validator
from enum import Enum


class ContractStatusDTO(str, Enum):
    """Contract status enumeration for DTOs"""
    DRAFT = "draft"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"


class DataClassificationDTO(str, Enum):
    """Data classification enumeration for DTOs"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTL = "confidential"
    RESTRICTED = "restricted"


class PIITypeDTO(str, Enum):
    """PII type enumeration for DTOs"""
    EML = "email"
    PHONE = "phone"
    CPF = "cpf"
    CNPJ = "cnpj"
    NAME = "name"
    ADDRESS = "address"
    CREDIT_CARD = "credit_card"
    BANK_ACCOUNT = "bank_account"
    IP_ADDRESS = "ip_address"


class SchemaFieldDTO(BaseModel):
    """Schema field definition DTO"""
    name: str = Field(..., description="Field name")
    type: str = Field(..., description="Field data type")
    required: bool = Field(default=False, description="Whether field is required")
    description: Optional[str] = Field(None, description="Field description")
    pii: bool = Field(default=False, description="Whether field contains PII")
    pii_type: Optional[PIITypeDTO] = Field(None, description="Type of PII if applicable")
    constraints: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Field constraints")
    
    @validator('name')
    def validate_name(cls, v):
        if not v or not v.strip():
            raise ValueError('Field name cannot be empty')
        return v.strip().lower()


class SchemaDefinitionDTO(BaseModel):
    """Schema definition DTO"""
    fields: List[SchemaFieldDTO] = Field(..., description="List of schema fields")
    version: str = Field(default="1.0.0", description="Schema version")
    description: Optional[str] = Field(None, description="Schema description")
    
    @validator('fields')
    def validate_fields(cls, v):
        if not v:
            raise ValueError('Schema must have at least one field')
        
        # Check for duplicate field names
        field_names = [field.name for field in v]
        if len(field_names) != len(set(field_names)):
            raise ValueError('Duplicate field names are not allowed')
        
        return v


class LGPDComplianceDTO(BaseModel):
    """LGPD compliance information DTO"""
    status: str = Field(..., description="Compliance status")
    score: float = Field(ge=0.0, le=1.0, description="Compliance score (0-1)")
    last_assessment: Optional[datetime] = Field(None, description="Last assessment date")
    requirements_met: List[str] = Field(default_factory=list, description="Met requirements")
    requirements_pending: List[str] = Field(default_factory=list, description="Pending requirements")


class QualityMetricsDTO(BaseModel):
    """Quality metrics DTO"""
    overall_score: float = Field(ge=0.0, le=1.0, description="Overall quality score")
    completeness_rate: float = Field(ge=0.0, le=1.0, description="Data completeness rate")
    accuracy_rate: float = Field(ge=0.0, le=1.0, description="Data accuracy rate")
    consistency_rate: float = Field(ge=0.0, le=1.0, description="Data consistency rate")
    last_check: Optional[datetime] = Field(None, description="Last quality check date")


class UsageStatisticsDTO(BaseModel):
    """Usage statistics DTO"""
    access_count: int = Field(ge=0, description="Number of times accessed")
    last_accessed: Optional[datetime] = Field(None, description="Last access date")
    unique_users: int = Field(ge=0, description="Number of unique users")
    avg_daily_usage: float = Field(ge=0.0, description="Average daily usage")


# Request DTOs
class CreateContractRequestDTO(BaseModel):
    """Request DTO for creating a contract"""
    name: str = Field(..., min_length=1, max_length=255, description="Contract name")
    title: str = Field(..., min_length=1, max_length=500, description="Contract title")
    description: Optional[str] = Field(None, max_length=2000, description="Contract description")
    schema_definition: SchemaDefinitionDTO = Field(..., description="Schema definition")
    data_classification: DataClassificationDTO = Field(default=DataClassificationDTO.INTERNAL, description="Data classification")
    owner_id: UUID = Field(..., description="Contract owner ID")
    organization_id: UUID = Field(..., description="Organization ID")
    documentation_url: Optional[str] = Field(None, description="Documentation URL")
    tags: List[str] = Field(default_factory=list, description="Contract tags")
    
    @validator('name')
    def validate_name(cls, v):
        if not v or not v.strip():
            raise ValueError('Contract name cannot be empty')
        # Convert to snake_case
        return v.strip().lower().replace(' ', '_').replace('-', '_')
    
    @validator('tags')
    def validate_tags(cls, v):
        if v:
            # Remove duplicates and empty tags
            return list(set([tag.strip() for tag in v if tag.strip()]))
        return []


class UpdateContractRequestDTO(BaseModel):
    """Request DTO for updating a contract"""
    title: Optional[str] = Field(None, min_length=1, max_length=500, description="Contract title")
    description: Optional[str] = Field(None, max_length=2000, description="Contract description")
    schema_definition: Optional[SchemaDefinitionDTO] = Field(None, description="Schema definition")
    data_classification: Optional[DataClassificationDTO] = Field(None, description="Data classification")
    documentation_url: Optional[str] = Field(None, description="Documentation URL")
    tags: Optional[List[str]] = Field(None, description="Contract tags")
    
    @validator('tags')
    def validate_tags(cls, v):
        if v is not None:
            # Remove duplicates and empty tags
            return list(set([tag.strip() for tag in v if tag.strip()]))
        return v


class ApproveContractRequestDTO(BaseModel):
    """Request DTO for approving a contract"""
    approved_by: UUID = Field(..., description="Approver user ID")
    approval_notes: Optional[str] = Field(None, max_length=1000, description="Approval notes")
    conditions: Optional[List[str]] = Field(default_factory=list, description="Approval conditions")


class RejectContractRequestDTO(BaseModel):
    """Request DTO for rejecting a contract"""
    rejected_by: UUID = Field(..., description="Rejector user ID")
    rejection_reason: str = Field(..., min_length=1, max_length=1000, description="Rejection reason")
    suggestions: Optional[List[str]] = Field(default_factory=list, description="Improvement suggestions")


class PIIDetectionRequestDTO(BaseModel):
    """Request DTO for PII detection"""
    text: str = Field(..., min_length=1, description="Text to analyze for PII")
    confidence_threshold: float = Field(default=0.8, ge=0.0, le=1.0, description="Confidence threshold")
    pii_types: Optional[List[PIITypeDTO]] = Field(None, description="Specific PII types to detect")


class ContractSearchRequestDTO(BaseModel):
    """Request DTO for contract search"""
    search_term: Optional[str] = Field(None, description="Search term")
    organization_id: UUID = Field(..., description="Organization ID")
    status: Optional[ContractStatusDTO] = Field(None, description="Contract status filter")
    contains_pii: Optional[bool] = Field(None, description="Filter by PII presence")
    owner_id: Optional[UUID] = Field(None, description="Owner ID filter")
    data_classification: Optional[DataClassificationDTO] = Field(None, description="Data classification filter")
    tags: Optional[List[str]] = Field(None, description="Tags filter")
    limit: int = Field(default=50, ge=1, le=100, description="Maximum results")
    offset: int = Field(default=0, ge=0, description="Results offset")


# Response DTOs
class ContractResponseDTO(BaseModel):
    """Response DTO for contract data"""
    id: UUID = Field(..., description="Contract ID")
    name: str = Field(..., description="Contract name")
    title: str = Field(..., description="Contract title")
    description: Optional[str] = Field(None, description="Contract description")
    version: str = Field(..., description="Contract version")
    status: ContractStatusDTO = Field(..., description="Contract status")
    is_active: bool = Field(..., description="Whether contract is active")
    schema_definition: SchemaDefinitionDTO = Field(..., description="Schema definition")
    schema_hash: Optional[str] = Field(None, description="Schema hash")
    data_classification: DataClassificationDTO = Field(..., description="Data classification")
    contains_pii: bool = Field(..., description="Whether contract contains PII")
    pii_fields: List[str] = Field(default_factory=list, description="List of PII field names")
    owner_id: UUID = Field(..., description="Contract owner ID")
    organization_id: UUID = Field(..., description="Organization ID")
    approval_status: Optional[str] = Field(None, description="Approval status")
    approved_by: Optional[UUID] = Field(None, description="Approver ID")
    approved_at: Optional[datetime] = Field(None, description="Approval date")
    lgpd_compliance: Optional[LGPDComplianceDTO] = Field(None, description="LGPD compliance info")
    quality_metrics: Optional[QualityMetricsDTO] = Field(None, description="Quality metrics")
    usage_statistics: Optional[UsageStatisticsDTO] = Field(None, description="Usage statistics")
    documentation_url: Optional[str] = Field(None, description="Documentation URL")
    tags: List[str] = Field(default_factory=list, description="Contract tags")
    created_at: datetime = Field(..., description="Creation date")
    updated_at: datetime = Field(..., description="Last update date")
    created_by: UUID = Field(..., description="Creator ID")
    updated_by: UUID = Field(..., description="Last updater ID")

    class Config:
        from_attributes = True


class ContractListResponseDTO(BaseModel):
    """Response DTO for contract list"""
    contracts: List[ContractResponseDTO] = Field(..., description="List of contracts")
    total: int = Field(..., description="Total number of contracts")
    page: int = Field(..., description="Current page")
    page_size: int = Field(..., description="Page size")
    has_next: bool = Field(..., description="Whether there are more pages")


class PIIDetectionResultDTO(BaseModel):
    """Response DTO for PII detection result"""
    type: PIITypeDTO = Field(..., description="Type of PII detected")
    value: str = Field(..., description="Detected PII value")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Detection confidence")
    start: int = Field(..., ge=0, description="Start position in text")
    end: int = Field(..., ge=0, description="End position in text")
    masked_value: Optional[str] = Field(None, description="Masked version of the value")


class PIIDetectionResponseDTO(BaseModel):
    """Response DTO for PII detection"""
    text: str = Field(..., description="Original text")
    pii_detected: List[PIIDetectionResultDTO] = Field(..., description="Detected PII items")
    total_pii_found: int = Field(..., description="Total number of PII items found")
    contains_pii: bool = Field(..., description="Whether text contains PII")
    analysis_timestamp: datetime = Field(..., description="Analysis timestamp")
    confidence_threshold: float = Field(..., description="Confidence threshold used")


class ContractStatisticsDTO(BaseModel):
    """Response DTO for contract statistics"""
    total_contracts: int = Field(..., description="Total number of contracts")
    active_contracts: int = Field(..., description="Number of active contracts")
    draft_contracts: int = Field(..., description="Number of draft contracts")
    contracts_with_pii: int = Field(..., description="Number of contracts with PII")
    average_compliance_score: float = Field(..., description="Average LGPD compliance score")
    average_quality_score: float = Field(..., description="Average quality score")
    contracts_by_classification: Dict[str, int] = Field(..., description="Contracts grouped by classification")
    contracts_by_status: Dict[str, int] = Field(..., description="Contracts grouped by status")


class ContractApprovalResponseDTO(BaseModel):
    """Response DTO for contract approval"""
    contract_id: UUID = Field(..., description="Contract ID")
    status: str = Field(..., description="New status")
    approved_by: UUID = Field(..., description="Approver ID")
    approved_at: datetime = Field(..., description="Approval timestamp")
    approval_notes: Optional[str] = Field(None, description="Approval notes")
    message: str = Field(..., description="Success message")


class ErrorResponseDTO(BaseModel):
    """Response DTO for errors"""
    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional error details")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Error timestamp")
    request_id: Optional[str] = Field(None, description="Request ID for tracking")


class HealthCheckResponseDTO(BaseModel):
    """Response DTO for health check"""
    status: str = Field(..., description="Service status")
    service: str = Field(..., description="Service name")
    version: str = Field(..., description="Service version")
    timestamp: datetime = Field(..., description="Health check timestamp")
    database: str = Field(..., description="Database status")
    dependencies: Dict[str, str] = Field(default_factory=dict, description="Dependencies status")

