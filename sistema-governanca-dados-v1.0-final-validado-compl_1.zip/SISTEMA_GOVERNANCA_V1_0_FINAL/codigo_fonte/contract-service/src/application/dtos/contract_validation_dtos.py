# Autor: carlos.morais@f1rst.com.br
"""
DTOs para Validação de Contratos
"""

from datetime import datetime
from typing import List, Dict, Any, Optional
from uuid import UUID
from pydantic import BaseModel, Field

from ...domain.services.contract_validation_service import ValidationError
from ...domain.services.contract_layout_service import LayoutValidationResult


class ValidationErrorDTO(BaseModel):
    """DTO para erro de validação"""
    field: str
    message: str
    severity: str = Field(..., regex="^(error|warning|info)$")
    code: Optional[str] = None
    timestamp: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class LayoutValidationDTO(BaseModel):
    """DTO para resultado de validação de layout"""
    is_valid: bool
    errors: List[Dict[str, Any]]
    warnings: List[Dict[str, Any]]
    suggestions: List[Dict[str, Any]]
    layout_hash: Optional[str] = None
    compatibility_score: float = 0.0
    validation_timestamp: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class ContractValidationSummaryDTO(BaseModel):
    """DTO para resumo de validação de contrato"""
    is_valid: bool
    validation_score: float = Field(..., ge=0.0, le=100.0)
    total_errors: int = Field(..., ge=0)
    total_warnings: int = Field(..., ge=0)
    total_suggestions: int = Field(..., ge=0)
    has_breaking_changes: bool = False
    compatibility_score: Optional[float] = None
    
    class Config:
        schema_extra = {
            "example": {
                "is_valid": True,
                "validation_score": 85.5,
                "total_errors": 0,
                "total_warnings": 2,
                "total_suggestions": 3,
                "has_breaking_changes": False,
                "compatibility_score": 92.0
            }
        }


class ContractValidationResponseDTO(BaseModel):
    """DTO para resposta completa de validação"""
    contract_id: Optional[UUID] = None
    validation_summary: ContractValidationSummaryDTO
    validation_errors: List[ValidationErrorDTO]
    layout_validation: LayoutValidationDTO
    compatibility_result: Optional[LayoutValidationDTO] = None
    recommendations: List[str] = []
    correlation_id: Optional[str] = None
    timestamp: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class ValidationOnlyRequestDTO(BaseModel):
    """DTO para requisição de validação sem persistência"""
    title: str = Field(..., min_length=1, max_length=255)
    description: str = Field(..., min_length=1, max_length=2000)
    version: str = Field(default="1.0.0", regex=r"^\d+\.\d+\.\d+$")
    dataset_name: str = Field(..., min_length=1, max_length=100)
    schema_definition: Dict[str, Any]
    data_classification: str
    effective_date: Optional[datetime] = None
    expiration_date: Optional[datetime] = None
    sla_requirements: Optional[Dict[str, Any]] = None
    quality_requirements: Optional[Dict[str, Any]] = None
    lgpd_compliance: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = []
    metadata: Optional[Dict[str, Any]] = {}
    
    class Config:
        schema_extra = {
            "example": {
                "title": "Contrato de Dados de Clientes",
                "description": "Contrato para dados de clientes do sistema CRM",
                "version": "1.0.0",
                "dataset_name": "customer_data",
                "schema_definition": {
                    "fields": [
                        {
                            "name": "customer_id",
                            "type": "string",
                            "constraints": {
                                "nullable": False,
                                "unique": True,
                                "max_length": 50
                            }
                        },
                        {
                            "name": "email",
                            "type": "string",
                            "constraints": {
                                "nullable": False,
                                "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
                            }
                        }
                    ],
                    "primary_key": "customer_id",
                    "format": "json"
                },
                "data_classification": "CONFIDENTIAL"
            }
        }


class CompatibilityCheckRequestDTO(BaseModel):
    """DTO para requisição de verificação de compatibilidade"""
    old_contract: ValidationOnlyRequestDTO
    new_contract: ValidationOnlyRequestDTO
    
    class Config:
        schema_extra = {
            "example": {
                "old_contract": {
                    "title": "Contrato v1.0.0",
                    "schema_definition": {
                        "fields": [
                            {"name": "id", "type": "string"},
                            {"name": "name", "type": "string"}
                        ]
                    }
                },
                "new_contract": {
                    "title": "Contrato v1.1.0",
                    "schema_definition": {
                        "fields": [
                            {"name": "id", "type": "string"},
                            {"name": "name", "type": "string"},
                            {"name": "email", "type": "string"}
                        ]
                    }
                }
            }
        }


class CompatibilityCheckResponseDTO(BaseModel):
    """DTO para resposta de verificação de compatibilidade"""
    is_compatible: bool
    compatibility_score: float = Field(..., ge=0.0, le=100.0)
    breaking_changes: List[Dict[str, Any]]
    compatibility_result: LayoutValidationDTO
    recommendations: List[str]
    migration_suggestions: List[str] = []
    correlation_id: Optional[str] = None
    timestamp: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class ValidationHistoryEventDTO(BaseModel):
    """DTO para evento de histórico de validação"""
    event_id: UUID
    event_type: str
    contract_id: UUID
    user_id: str
    validation_score: Optional[float] = None
    error_count: int = 0
    warning_count: int = 0
    suggestion_count: int = 0
    has_breaking_changes: bool = False
    event_timestamp: datetime
    details: Optional[Dict[str, Any]] = None
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class ValidationHistoryResponseDTO(BaseModel):
    """DTO para resposta de histórico de validação"""
    contract_id: UUID
    validation_events: List[ValidationHistoryEventDTO]
    total_validations: int
    average_score: Optional[float] = None
    trend_analysis: Optional[Dict[str, Any]] = None
    timestamp: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class ValidationMetricsDTO(BaseModel):
    """DTO para métricas de validação"""
    period_start: datetime
    period_end: datetime
    total_validations: int = 0
    successful_validations: int = 0
    failed_validations: int = 0
    average_validation_score: float = 0.0
    total_errors: int = 0
    total_warnings: int = 0
    total_suggestions: int = 0
    breaking_changes_detected: int = 0
    most_common_errors: List[Dict[str, Any]] = []
    validation_trends: Dict[str, Any] = {}
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class ValidationMetricsResponseDTO(BaseModel):
    """DTO para resposta de métricas de validação"""
    period: Dict[str, str]
    metrics: ValidationMetricsDTO
    insights: List[str] = []
    recommendations: List[str] = []
    timestamp: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class LayoutOptimizationSuggestionDTO(BaseModel):
    """DTO para sugestão de otimização de layout"""
    type: str = Field(..., regex="^(index|partitioning|optimization|normalization)$")
    message: str
    field: Optional[str] = None
    action: str
    priority: str = Field(..., regex="^(high|medium|low)$")
    estimated_impact: Optional[str] = None
    implementation_effort: Optional[str] = None
    
    class Config:
        schema_extra = {
            "example": {
                "type": "index",
                "message": "Criar índice único para campo 'email'",
                "field": "email",
                "action": "create_unique_index",
                "priority": "high",
                "estimated_impact": "Melhoria significativa na performance de consultas",
                "implementation_effort": "Baixo"
            }
        }


class LayoutOptimizationResponseDTO(BaseModel):
    """DTO para resposta de otimização de layout"""
    contract_id: Optional[UUID] = None
    layout_hash: str
    optimization_suggestions: List[LayoutOptimizationSuggestionDTO]
    performance_score: float = Field(..., ge=0.0, le=100.0)
    complexity_score: float = Field(..., ge=0.0, le=100.0)
    maintainability_score: float = Field(..., ge=0.0, le=100.0)
    overall_score: float = Field(..., ge=0.0, le=100.0)
    timestamp: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


# Funções utilitárias para conversão

def validation_error_to_dto(error: ValidationError) -> ValidationErrorDTO:
    """Converte ValidationError para DTO"""
    return ValidationErrorDTO(
        field=error.field,
        message=error.message,
        severity=error.severity,
        code=error.code,
        timestamp=error.timestamp
    )


def layout_result_to_dto(result: LayoutValidationResult) -> LayoutValidationDTO:
    """Converte LayoutValidationResult para DTO"""
    return LayoutValidationDTO(
        is_valid=result.is_valid,
        errors=result.errors,
        warnings=result.warnings,
        suggestions=result.suggestions,
        layout_hash=result.layout_hash,
        compatibility_score=result.compatibility_score,
        validation_timestamp=datetime.utcnow()
    )


def create_validation_summary(
    validation_errors: List[ValidationError],
    layout_result: LayoutValidationResult,
    compatibility_result: Optional[LayoutValidationResult] = None
) -> ContractValidationSummaryDTO:
    """Cria resumo de validação"""
    
    error_count = len([e for e in validation_errors if e.severity == "error"]) + len(layout_result.errors)
    warning_count = len([e for e in validation_errors if e.severity == "warning"]) + len(layout_result.warnings)
    suggestion_count = len([e for e in validation_errors if e.severity == "info"]) + len(layout_result.suggestions)
    
    # Calcular score de validação
    validation_score = 100.0
    validation_score -= error_count * 20
    validation_score -= warning_count * 5
    validation_score -= suggestion_count * 1
    validation_score = max(0.0, min(100.0, validation_score))
    
    # Verificar breaking changes
    has_breaking_changes = False
    if compatibility_result:
        breaking_changes = [
            error for error in compatibility_result.errors 
            if "breaking" in error.get("message", "").lower()
        ]
        has_breaking_changes = len(breaking_changes) > 0
    
    return ContractValidationSummaryDTO(
        is_valid=error_count == 0,
        validation_score=validation_score,
        total_errors=error_count,
        total_warnings=warning_count,
        total_suggestions=suggestion_count,
        has_breaking_changes=has_breaking_changes,
        compatibility_score=compatibility_result.compatibility_score if compatibility_result else None
    )

