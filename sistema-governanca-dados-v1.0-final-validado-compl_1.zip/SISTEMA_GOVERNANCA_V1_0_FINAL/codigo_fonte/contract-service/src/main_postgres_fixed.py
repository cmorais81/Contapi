# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
Contract Service V4.1 - PostgreSQL Version
Microserviço para gerenciamento de contratos de dados
Integração completa com PostgreSQL
"""

import os
import sys
import logging
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from uuid import uuid4, UUID

# Add shared directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'shared'))

from fastapi import FastAPI, HTTPException, Depends, Query, Path, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

# Import database functions
try:
    from database import execute_query, execute_command, execute_insert_returning, health_check
    POSTGRES_AVLABLE = True
except ImportError as e:
    print(f"PostgreSQL not available: {e}")
    POSTGRES_AVLABLE = False

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# =====================================================
# PYDANTIC MODELS
# =====================================================

class ContractCreate(BaseModel):
    title: str = Field(..., description="Contract title")
    description: Optional[str] = Field(None, description="Contract description")
    version: str = Field(default="1.0.0", description="Contract version")
    dataset_id: Optional[str] = Field(None, description="Dataset ID")
    owner_id: Optional[str] = Field(None, description="Owner ID")
    steward_id: Optional[str] = Field(None, description="Steward ID")
    schema_json: Optional[Dict] = Field(None, description="Schema definition")
    quality_requirements: Optional[Dict] = Field(None, description="Quality requirements")
    sla_requirements: Optional[Dict] = Field(None, description="SLA requirements")
    retention_policy: Optional[Dict] = Field(None, description="Retention policy")

class ContractUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    version: Optional[str] = None
    status: Optional[str] = None
    schema_json: Optional[Dict] = None
    quality_requirements: Optional[Dict] = None
    sla_requirements: Optional[Dict] = None
    retention_policy: Optional[Dict] = None

class PIIDetectionRequest(BaseModel):
    text: str = Field(..., description="Text to analyze for PII")

class ComplianceAssessmentRequest(BaseModel):
    contract_id: str = Field(..., description="Contract ID to assess")
    framework: str = Field(default="LGPD", description="Compliance framework")

# =====================================================
# DATABASE OPERATIONS
# =====================================================

def get_contracts() -> List[Dict[str, Any]]:
    """Get all contracts from database"""
    if not POSTGRES_AVLABLE:
        return []
    
    try:
        contracts = execute_query("""
            SELECT id, title, description, version, status, 
                   dataset_id, owner_id, steward_id, created_at, updated_at
            FROM contracts 
            ORDER BY created_at DESC
        """)
        return contracts or []
    except Exception as e:
        logger.error(f"Error getting contracts: {e}")
        return []

def get_contract_by_id(contract_id: str) -> Optional[Dict[str, Any]]:
    """Get contract by ID"""
    if not POSTGRES_AVLABLE:
        return None
    
    try:
        contracts = execute_query("""
            SELECT id, title, description, version, status, 
                   dataset_id, owner_id, steward_id, schema_json,
                   quality_requirements, sla_requirements, retention_policy,
                   created_at, updated_at
            FROM contracts 
            WHERE id = %s
        """, (contract_id,))
        return contracts[0] if contracts else None
    except Exception as e:
        logger.error(f"Error getting contract {contract_id}: {e}")
        return None

def create_contract(contract_data: ContractCreate) -> Dict[str, Any]:
    """Create new contract"""
    if not POSTGRES_AVLABLE:
        raise HTTPException(status_code=500, detail="Database not available")
    
    try:
        contract_id = str(uuid4())
        
        result = execute_insert_returning("""
            INSERT INTO contracts (
                id, title, description, version, status,
                dataset_id, owner_id, steward_id, schema_json,
                quality_requirements, sla_requirements, retention_policy
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
            ) RETURNING id, title, description, version, status, created_at
        """, (
            contract_id,
            contract_data.title,
            contract_data.description,
            contract_data.version,
            'draft',
            contract_data.dataset_id,
            contract_data.owner_id,
            contract_data.steward_id,
            json.dumps(contract_data.schema_json) if contract_data.schema_json else None,
            json.dumps(contract_data.quality_requirements) if contract_data.quality_requirements else None,
            json.dumps(contract_data.sla_requirements) if contract_data.sla_requirements else None,
            json.dumps(contract_data.retention_policy) if contract_data.retention_policy else None
        ))
        
        return result[0] if result else {}
    except Exception as e:
        logger.error(f"Error creating contract: {e}")
        raise HTTPException(status_code=500, detail="Database error")

def update_contract(contract_id: str, contract_data: ContractUpdate) -> Optional[Dict[str, Any]]:
    """Update contract"""
    if not POSTGRES_AVLABLE:
        raise HTTPException(status_code=500, detail="Database not available")
    
    try:
        # Build dynamic update query
        update_fields = []
        params = []
        
        if contract_data.title is not None:
            update_fields.append("title = %s")
            params.append(contract_data.title)
        if contract_data.description is not None:
            update_fields.append("description = %s")
            params.append(contract_data.description)
        if contract_data.version is not None:
            update_fields.append("version = %s")
            params.append(contract_data.version)
        if contract_data.status is not None:
            update_fields.append("status = %s")
            params.append(contract_data.status)
        if contract_data.schema_json is not None:
            update_fields.append("schema_json = %s")
            params.append(json.dumps(contract_data.schema_json))
        if contract_data.quality_requirements is not None:
            update_fields.append("quality_requirements = %s")
            params.append(json.dumps(contract_data.quality_requirements))
        if contract_data.sla_requirements is not None:
            update_fields.append("sla_requirements = %s")
            params.append(json.dumps(contract_data.sla_requirements))
        if contract_data.retention_policy is not None:
            update_fields.append("retention_policy = %s")
            params.append(json.dumps(contract_data.retention_policy))
        
        if not update_fields:
            return get_contract_by_id(contract_id)
        
        update_fields.append("updated_at = CURRENT_TIMESTAMP")
        params.append(contract_id)
        
        query = f"""
            UPDATE contracts 
            SET {', '.join(update_fields)}
            WHERE id = %s
            RETURNING id, title, description, version, status, updated_at
        """
        
        result = execute_insert_returning(query, params)
        return result[0] if result else None
    except Exception as e:
        logger.error(f"Error updating contract {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Database error")

def delete_contract(contract_id: str) -> bool:
    """Delete contract"""
    if not POSTGRES_AVLABLE:
        raise HTTPException(status_code=500, detail="Database not available")
    
    try:
        execute_command("DELETE FROM contracts WHERE id = %s", (contract_id,))
        return True
    except Exception as e:
        logger.error(f"Error deleting contract {contract_id}: {e}")
        raise HTTPException(status_code=500, detail="Database error")

# =====================================================
# PII DETECTION FUNCTIONS
# =====================================================

def detect_pii(text: str) -> Dict[str, Any]:
    """Detect PII in text"""
    import re
    
    pii_patterns = {
        'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
        'cpf': r'\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b',
        'phone': r'\b\(?[0-9]{2}\)?\s?[0-9]{4,5}-?[0-9]{4}\b',
        'credit_card': r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
        'ip_address': r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b'
    }
    
    detected_pii = []
    for pii_type, pattern in pii_patterns.items():
        matches = re.findall(pattern, text, re.IGNORECASE)
        for match in matches:
            detected_pii.append({
                'type': pii_type,
                'value': match,
                'confidence': 0.95,
                'position': text.find(match)
            })
    
    risk_level = 'low'
    if len(detected_pii) > 2:
        risk_level = 'high'
    elif len(detected_pii) > 0:
        risk_level = 'medium'
    
    return {
        'pii_detected': detected_pii,
        'total_pii_found': len(detected_pii),
        'risk_level': risk_level,
        'recommendations': [
            'Implement data masking for PII fields',
            'Apply encryption for sensitive data',
            'Review data access permissions'
        ] if detected_pii else []
    }

# =====================================================
# COMPLNCE FUNCTIONS
# =====================================================

def assess_compliance(contract_id: str, framework: str = "LGPD") -> Dict[str, Any]:
    """Assess compliance for contract"""
    contract = get_contract_by_id(contract_id)
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")
    
    compliance_frameworks = {
        'LGPD': {
            'name': 'Lei Geral de Proteção de Dados',
            'articles': ['Art. 6º', 'Art. 7º', 'Art. 9º', 'Art. 11º'],
            'requirements': ['Consent', 'Purpose limitation', 'Data minimization', 'Transparency']
        },
        'GDPR': {
            'name': 'General Data Protection Regulation',
            'articles': ['Art. 5', 'Art. 6', 'Art. 7', 'Art. 25'],
            'requirements': ['Lawfulness', 'Purpose limitation', 'Data minimization', 'Privacy by design']
        }
    }
    
    framework_info = compliance_frameworks.get(framework, compliance_frameworks['LGPD'])
    
    # Mock compliance assessment
    compliance_score = 75  # Based on contract analysis
    
    return {
        'contract_id': contract_id,
        'framework': framework,
        'framework_name': framework_info['name'],
        'compliance_score': compliance_score,
        'status': 'compliant' if compliance_score >= 70 else 'non_compliant',
        'articles_covered': framework_info['articles'],
        'requirements_met': framework_info['requirements'][:3],  # Mock: 3 of 4 met
        'recommendations': [
            'Implement explicit consent mechanism',
            'Add data retention policy',
            'Enhance data subject rights'
        ],
        'assessed_at': datetime.now().isoformat()
    }

# =====================================================
# FASTAPI APPLICATION
# =====================================================

app = FastAPI(
    title="Contract Service V4.1",
    description="Microserviço para gerenciamento de contratos de dados com PostgreSQL",
    version="4.1.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# HEALTH CHECK
# =====================================================

@app.get("/health")
async def health_check_endpoint():
    """Health check endpoint"""
    db_health = None
    if POSTGRES_AVLABLE:
        try:
            db_health = health_check()
        except Exception as e:
            logger.error(f"Database health check failed: {e}")
            db_health = {"status": "unhealthy", "error": str(e)}
    
    contracts_count = len(get_contracts()) if POSTGRES_AVLABLE else 0
    
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "version": "4.1.0",
        "service": "contract-service",
        "port": 8001,
        "database": db_health,
        "data_counts": {
            "contracts": contracts_count
        },
        "features": {
            "contracts_management": True,
            "pii_detection": True,
            "compliance_assessment": True,
            "audit_trail": True,
            "postgresql_persistence": POSTGRES_AVLABLE
        }
    }

# =====================================================
# CONTRACT ENDPOINTS
# =====================================================

@app.get("/api/v1/contracts")
async def list_contracts():
    """List all contracts"""
    return get_contracts()

@app.get("/api/v1/contracts/{contract_id}")
async def get_contract(contract_id: str = Path(..., description="Contract ID")):
    """Get contract by ID"""
    contract = get_contract_by_id(contract_id)
    if not contract:
        raise HTTPException(status_code=404, detail="Contract not found")
    return contract

@app.post("/api/v1/contracts")
async def create_contract_endpoint(contract: ContractCreate):
    """Create new contract"""
    return create_contract(contract)

@app.put("/api/v1/contracts/{contract_id}")
async def update_contract_endpoint(
    contract_id: str = Path(..., description="Contract ID"),
    contract: ContractUpdate = Body(...)
):
    """Update contract"""
    updated_contract = update_contract(contract_id, contract)
    if not updated_contract:
        raise HTTPException(status_code=404, detail="Contract not found")
    return updated_contract

@app.delete("/api/v1/contracts/{contract_id}")
async def delete_contract_endpoint(contract_id: str = Path(..., description="Contract ID")):
    """Delete contract"""
    if not delete_contract(contract_id):
        raise HTTPException(status_code=404, detail="Contract not found")
    return {"message": "Contract deleted successfully"}

# =====================================================
# PII DETECTION ENDPOINTS
# =====================================================

@app.post("/api/v1/pii/detect")
async def detect_pii_endpoint(request: PIIDetectionRequest):
    """Detect PII in text"""
    return detect_pii(request.text)

# =====================================================
# COMPLNCE ENDPOINTS
# =====================================================

@app.post("/api/v1/compliance/assess")
async def assess_compliance_endpoint(request: ComplianceAssessmentRequest):
    """Assess compliance for contract"""
    return assess_compliance(request.contract_id, request.framework)

# =====================================================
# AUDIT ENDPOINTS
# =====================================================

@app.get("/api/v1/audit/logs")
async def get_audit_logs():
    """Get audit logs for contracts"""
    # Mock audit logs
    return [
        {
            "id": str(uuid4()),
            "action": "contract_created",
            "contract_id": str(uuid4()),
            "user_id": "system",
            "timestamp": datetime.now().isoformat(),
            "details": {"message": "Contract created successfully"}
        },
        {
            "id": str(uuid4()),
            "action": "pii_detected",
            "contract_id": str(uuid4()),
            "user_id": "system",
            "timestamp": (datetime.now() - timedelta(hours=1)).isoformat(),
            "details": {"pii_count": 2, "risk_level": "medium"}
        }
    ]

# =====================================================
# STARTUP/SHUTDOWN EVENTS
# =====================================================

@app.on_event("startup")
async def startup_event():
    """Application startup"""
    logger.info("Starting Contract Service V4.1 with PostgreSQL")
    if POSTGRES_AVLABLE:
        try:
            # Test database connection
            health_check()
            logger.info("PostgreSQL connection established successfully")
        except Exception as e:
            logger.error(f"PostgreSQL connection failed: {e}")
    else:
        logger.warning("PostgreSQL not available, running in limited mode")
    logger.info("Contract Service started successfully")

@app.on_event("shutdown")
async def shutdown_event():
    """Application shutdown"""
    logger.info("Shutting down Contract Service V4.1")

# =====================================================
# MN EXECUTION
# =====================================================

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8001))
    uvicorn.run(
        "main_postgres_fixed:app",
        host="0.0.0.0",
        port=port,
        reload=False,
        log_level="info"
    )

