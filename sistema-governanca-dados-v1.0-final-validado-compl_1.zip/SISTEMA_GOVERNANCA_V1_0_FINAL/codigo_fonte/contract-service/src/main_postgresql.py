"""
Contract Service - Microserviço de Contratos de Dados
Sistema de Governança de Dados V5.0 - PostgreSQL

Responsável por:
- Gestão de contratos de dados
- Validação de schemas
- Detecção de PII
- Compliance assessment
- Auditoria de contratos
"""

import logging
import uvicorn
from fastapi import FastAPI, HTTPException, Query, Path, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from datetime import datetime
from uuid import uuid4, UUID
import re
import sys
import os
import json

# Adicionar path do projeto
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from shared.database import get_db_session, get_db_health
from sqlalchemy import text

# Importar wizard controller
from presentation.controllers.contract_wizard_controller import wizard_router

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# =====================================================
# MODELOS PYDANTIC
# =====================================================

class ContractCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: str = Field("", max_length=1000)
    version: str = Field("1.0.0", pattern=r"^\d+\.\d+\.\d+$")
    status: str = Field("draft", pattern="^(draft|active|deprecated|archived)$")
    data_classification: str = Field("internal", pattern="^(public|internal|confidential|restricted)$")
    owner_email: str = Field(..., pattern=r"^[^@]+@[^@]+\.[^@]+$")
    schema_definition: Optional[Dict[str, Any]] = Field(None)
    sla_requirements: Optional[Dict[str, Any]] = Field(None)

class ContractUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = Field(None, max_length=1000)
    version: Optional[str] = Field(None, pattern=r"^\d+\.\d+\.\d+$")
    status: Optional[str] = Field(None, pattern="^(draft|active|deprecated|archived)$")
    data_classification: Optional[str] = Field(None, pattern="^(public|internal|confidential|restricted)$")
    owner_email: Optional[str] = Field(None, pattern=r"^[^@]+@[^@]+\.[^@]+$")
    schema_definition: Optional[Dict[str, Any]] = Field(None)
    sla_requirements: Optional[Dict[str, Any]] = Field(None)

class ContractResponse(BaseModel):
    id: str
    name: str
    description: str
    version: str
    status: str
    data_classification: str
    owner_email: str
    schema_definition: Optional[Dict[str, Any]]
    sla_requirements: Optional[Dict[str, Any]]
    created_at: datetime
    updated_at: datetime

class PIIDetectionRequest(BaseModel):
    text: str = Field(..., description="Texto para análise de PII")
    context: Optional[str] = Field(None, description="Contexto adicional")

class PIIDetectionResponse(BaseModel):
    has_pii: bool
    pii_types: List[str]
    confidence_score: float
    detected_entities: List[Dict[str, Any]]

class ComplianceAssessmentRequest(BaseModel):
    contract_id: str = Field(..., description="ID do contrato")
    framework: str = Field(..., description="Framework de compliance (LGPD, GDPR, SOX)")

class ComplianceAssessmentResponse(BaseModel):
    contract_id: str
    framework: str
    compliance_score: float
    status: str
    findings: List[Dict[str, Any]]
    recommendations: List[str]

# =====================================================
# POSTGRESQL DATABASE FUNCTIONS
# =====================================================

def log_audit(action: str, resource_id: str = None, details: str = None):
    """Log audit trail to PostgreSQL"""
    try:
        with get_db_session() as session:
            audit_sql = text("""
                INSERT INTO audit_events (event_type, resource_type, resource_id, action, details, created_at)
                VALUES (:event_type, :resource_type, :resource_id, :action, :details, CURRENT_TIMESTAMP)
            """)
            
            session.execute(audit_sql, {
                'event_type': 'contract_operation',
                'resource_type': 'contracts',
                'resource_id': resource_id,
                'action': action,
                'details': details
            })
            session.commit()
            
    except Exception as e:
        logger.error(f"Error logging audit: {e}")

def init_sample_data():
    """Initialize sample contracts in PostgreSQL"""
    try:
        with get_db_session() as session:
            # Verificar se já existem contratos
            count_sql = text("SELECT COUNT(*) FROM contracts")
            result = session.execute(count_sql)
            count = result.fetchone()[0]
            
            if count > 0:
                logger.info(f"Contracts already exist in database: {count}")
                return
            
            sample_contracts = [
                {
                    "name": "Contrato de Dados de Vendas",
                    "description": "Contrato para dados de vendas e faturamento",
                    "version": "1.0.0",
                    "status": "active",
                    "data_classification": "confidential",
                    "owner_email": "vendas@empresa.com",
                    "schema_definition": {
                        "tables": ["vendas", "clientes"],
                        "fields": ["id", "nome", "email", "valor_venda"]
                    },
                    "sla_requirements": {
                        "availability": "99.9%",
                        "response_time": "< 100ms"
                    }
                },
                {
                    "name": "Contrato de Dados de Clientes",
                    "description": "Contrato para informações de clientes",
                    "version": "2.1.0",
                    "status": "active",
                    "data_classification": "internal",
                    "owner_email": "dados@empresa.com",
                    "schema_definition": {
                        "tables": ["clientes", "enderecos"],
                        "fields": ["id", "nome", "cpf", "endereco"]
                    },
                    "sla_requirements": {
                        "availability": "99.5%",
                        "response_time": "< 200ms"
                    }
                },
                {
                    "name": "Contrato de Dados de Marketing",
                    "description": "Contrato para campanhas e métricas",
                    "version": "1.5.0",
                    "status": "draft",
                    "data_classification": "internal",
                    "owner_email": "marketing@empresa.com",
                    "schema_definition": {
                        "tables": ["campanhas", "metricas"],
                        "fields": ["id", "nome_campanha", "clicks", "conversoes"]
                    },
                    "sla_requirements": {
                        "availability": "99.0%",
                        "response_time": "< 500ms"
                    }
                }
            ]
            
            insert_sql = text("""
                INSERT INTO contracts (name, description, version, status, data_classification, 
                                     owner_email, schema_definition, sla_requirements)
                VALUES (:name, :description, :version, :status, :data_classification,
                        :owner_email, :schema_definition, :sla_requirements)
            """)
            
            for contract in sample_contracts:
                # Converter dicts para JSON strings
                contract_data = contract.copy()
                if 'schema_definition' in contract_data:
                    contract_data['schema_definition'] = json.dumps(contract_data['schema_definition'])
                if 'sla_requirements' in contract_data:
                    contract_data['sla_requirements'] = json.dumps(contract_data['sla_requirements'])
                
                session.execute(insert_sql, contract_data)
            
            session.commit()
            logger.info(f"Initialized {len(sample_contracts)} sample contracts in PostgreSQL")
            
    except Exception as e:
        logger.error(f"Error initializing sample data: {e}")

def get_contract_from_db(contract_id: str) -> Optional[Dict[str, Any]]:
    """Busca contrato no PostgreSQL"""
    try:
        with get_db_session() as session:
            sql = text("""
                SELECT id, name, description, version, status, data_classification,
                       owner_email, schema_definition, sla_requirements, created_at, updated_at
                FROM contracts WHERE id = :contract_id
            """)
            
            result = session.execute(sql, {'contract_id': contract_id}).fetchone()
            
            if result:
                return {
                    'id': str(result.id),
                    'name': result.name,
                    'description': result.description,
                    'version': result.version,
                    'status': result.status,
                    'data_classification': result.data_classification,
                    'owner_email': result.owner_email,
                    'schema_definition': result.schema_definition,
                    'sla_requirements': result.sla_requirements,
                    'created_at': result.created_at,
                    'updated_at': result.updated_at
                }
            
            return None
            
    except Exception as e:
        logger.error(f"Error getting contract: {e}")
        return None

def save_contract_to_db(contract_data: Dict[str, Any]) -> str:
    """Salva contrato no PostgreSQL"""
    try:
        with get_db_session() as session:
            contract_id = str(uuid4())
            
            insert_sql = text("""
                INSERT INTO contracts (id, name, description, version, status, data_classification,
                                     owner_email, schema_definition, sla_requirements)
                VALUES (:id, :name, :description, :version, :status, :data_classification,
                        :owner_email, :schema_definition, :sla_requirements)
            """)
            
            session.execute(insert_sql, {
                'id': contract_id,
                **contract_data
            })
            
            session.commit()
            
            log_audit("CREATE", contract_id, f"Contract created: {contract_data['name']}")
            
            return contract_id
            
    except Exception as e:
        logger.error(f"Error saving contract: {e}")
        raise HTTPException(status_code=500, detail="Database error")

def update_contract_in_db(contract_id: str, update_data: Dict[str, Any]) -> bool:
    """Atualiza contrato no PostgreSQL"""
    try:
        with get_db_session() as session:
            # Construir SQL dinâmico baseado nos campos fornecidos
            set_clauses = []
            params = {'contract_id': contract_id}
            
            for field, value in update_data.items():
                if value is not None:
                    set_clauses.append(f"{field} = :{field}")
                    params[field] = value
            
            if not set_clauses:
                return True  # Nada para atualizar
            
            set_clauses.append("updated_at = CURRENT_TIMESTAMP")
            
            update_sql = text(f"""
                UPDATE contracts 
                SET {', '.join(set_clauses)}
                WHERE id = :contract_id
            """)
            
            result = session.execute(update_sql, params)
            session.commit()
            
            if result.rowcount > 0:
                log_audit("UPDATE", contract_id, f"Contract updated")
                return True
            
            return False
            
    except Exception as e:
        logger.error(f"Error updating contract: {e}")
        raise HTTPException(status_code=500, detail="Database error")

def delete_contract_from_db(contract_id: str) -> bool:
    """Remove contrato do PostgreSQL"""
    try:
        with get_db_session() as session:
            delete_sql = text("DELETE FROM contracts WHERE id = :contract_id")
            result = session.execute(delete_sql, {'contract_id': contract_id})
            session.commit()
            
            if result.rowcount > 0:
                log_audit("DELETE", contract_id, "Contract deleted")
                return True
            
            return False
            
    except Exception as e:
        logger.error(f"Error deleting contract: {e}")
        raise HTTPException(status_code=500, detail="Database error")

def list_contracts_from_db(status: Optional[str] = None, owner: Optional[str] = None) -> List[Dict[str, Any]]:
    """Lista contratos do PostgreSQL"""
    try:
        with get_db_session() as session:
            where_clauses = []
            params = {}
            
            if status:
                where_clauses.append("status = :status")
                params['status'] = status
            
            if owner:
                where_clauses.append("owner_email = :owner")
                params['owner'] = owner
            
            where_clause = ""
            if where_clauses:
                where_clause = "WHERE " + " AND ".join(where_clauses)
            
            sql = text(f"""
                SELECT id, name, description, version, status, data_classification,
                       owner_email, schema_definition, sla_requirements, created_at, updated_at
                FROM contracts {where_clause}
                ORDER BY created_at DESC
            """)
            
            results = session.execute(sql, params).fetchall()
            
            contracts = []
            for result in results:
                contracts.append({
                    'id': str(result.id),
                    'name': result.name,
                    'description': result.description,
                    'version': result.version,
                    'status': result.status,
                    'data_classification': result.data_classification,
                    'owner_email': result.owner_email,
                    'schema_definition': result.schema_definition,
                    'sla_requirements': result.sla_requirements,
                    'created_at': result.created_at,
                    'updated_at': result.updated_at
                })
            
            return contracts
            
    except Exception as e:
        logger.error(f"Error listing contracts: {e}")
        return []

# =====================================================
# BUSINESS LOGIC FUNCTIONS
# =====================================================

def detect_pii(text: str, context: str = None) -> PIIDetectionResponse:
    """Detecta informações pessoais identificáveis (PII)"""
    try:
        pii_patterns = {
            'cpf': r'\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b',
            'cnpj': r'\b\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}\b',
            'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            'telefone': r'\b(?:\+55\s?)?(?:\(\d{2}\)\s?)?\d{4,5}-?\d{4}\b',
            'rg': r'\b\d{1,2}\.?\d{3}\.?\d{3}-?[0-9X]\b',
            'cartao_credito': r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
            'cep': r'\b\d{5}-?\d{3}\b'
        }
        
        detected_entities = []
        pii_types = []
        total_confidence = 0.0
        
        for pii_type, pattern in pii_patterns.items():
            matches = re.finditer(pattern, text, re.IGNORECASE)
            for match in matches:
                confidence = 0.9 if pii_type in ['cpf', 'cnpj', 'email'] else 0.7
                
                detected_entities.append({
                    'type': pii_type,
                    'value': match.group(),
                    'start': match.start(),
                    'end': match.end(),
                    'confidence': confidence
                })
                
                if pii_type not in pii_types:
                    pii_types.append(pii_type)
                    total_confidence += confidence
        
        has_pii = len(detected_entities) > 0
        avg_confidence = total_confidence / len(pii_types) if pii_types else 0.0
        
        return PIIDetectionResponse(
            has_pii=has_pii,
            pii_types=pii_types,
            confidence_score=min(avg_confidence, 1.0),
            detected_entities=detected_entities
        )
        
    except Exception as e:
        logger.error(f"Error in PII detection: {e}")
        return PIIDetectionResponse(
            has_pii=False,
            pii_types=[],
            confidence_score=0.0,
            detected_entities=[]
        )

def assess_compliance(contract_id: str, framework: str) -> ComplianceAssessmentResponse:
    """Avalia compliance de um contrato"""
    try:
        contract = get_contract_from_db(contract_id)
        if not contract:
            raise HTTPException(status_code=404, detail="Contract not found")
        
        findings = []
        recommendations = []
        score = 1.0
        
        # Verificações específicas por framework
        if framework.upper() == "LGPD":
            # Verificar classificação de dados
            if contract.get('data_classification') in ['public', 'internal']:
                findings.append({
                    'type': 'warning',
                    'message': 'Dados podem conter informações pessoais sem classificação adequada',
                    'severity': 'medium'
                })
                score -= 0.2
                recommendations.append('Revisar classificação de dados pessoais')
            
            # Verificar se há definição de retenção
            schema_def = contract.get('schema_definition', {})
            if not schema_def.get('retention_policy'):
                findings.append({
                    'type': 'violation',
                    'message': 'Política de retenção não definida',
                    'severity': 'high'
                })
                score -= 0.3
                recommendations.append('Definir política de retenção de dados')
        
        elif framework.upper() == "GDPR":
            # Verificações similares ao LGPD
            if contract.get('data_classification') == 'public':
                findings.append({
                    'type': 'info',
                    'message': 'Dados públicos - baixo risco GDPR',
                    'severity': 'low'
                })
            else:
                score -= 0.1
                recommendations.append('Implementar controles de privacidade GDPR')
        
        elif framework.upper() == "SOX":
            # Verificações de controles financeiros
            if 'financeiro' in contract.get('description', '').lower():
                if contract.get('data_classification') != 'confidential':
                    findings.append({
                        'type': 'violation',
                        'message': 'Dados financeiros devem ser confidenciais',
                        'severity': 'critical'
                    })
                    score -= 0.5
                    recommendations.append('Classificar dados financeiros como confidenciais')
        
        # Determinar status
        if score >= 0.9:
            status = "compliant"
        elif score >= 0.7:
            status = "partially_compliant"
        else:
            status = "non_compliant"
        
        return ComplianceAssessmentResponse(
            contract_id=contract_id,
            framework=framework,
            compliance_score=max(score, 0.0),
            status=status,
            findings=findings,
            recommendations=recommendations
        )
        
    except Exception as e:
        logger.error(f"Error in compliance assessment: {e}")
        raise HTTPException(status_code=500, detail="Compliance assessment failed")

# =====================================================
# CONFIGURAÇÃO DA APLICAÇÃO
# =====================================================

app = FastAPI(
    title="Contract Service",
    description="Microserviço para gestão de contratos de dados - V5.0 com PostgreSQL",
    version="5.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Incluir routers
app.include_router(wizard_router)

# =====================================================
# ENDPOINTS
# =====================================================

@app.get("/")
async def root():
    """Endpoint raiz"""
    return {
        "service": "Contract Service",
        "version": "5.0.0",
        "description": "Microserviço de contratos de dados com PostgreSQL",
        "status": "running",
        "database": "PostgreSQL",
        "features": [
            "Gestão de contratos",
            "Detecção de PII",
            "Assessment de compliance",
            "Auditoria completa",
            "Persistência real"
        ]
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        db_health = get_db_health()
        
        if db_health.get("status") == "healthy":
            return {
                "status": "healthy",
                "service": "Contract Service",
                "version": "5.0.0",
                "database": db_health,
                "timestamp": datetime.utcnow().isoformat()
            }
        else:
            return JSONResponse(
                status_code=503,
                content={
                    "status": "unhealthy",
                    "service": "Contract Service",
                    "database": db_health
                }
            )
    except Exception as e:
        return JSONResponse(
            status_code=503,
            content={
                "status": "unhealthy",
                "error": str(e)
            }
        )

@app.get("/api/v1/contracts", response_model=List[ContractResponse])
async def list_contracts(
    status: Optional[str] = Query(None, description="Filtrar por status"),
    owner: Optional[str] = Query(None, description="Filtrar por owner")
):
    """Lista todos os contratos"""
    try:
        contracts = list_contracts_from_db(status, owner)
        log_audit("LIST", None, f"Listed {len(contracts)} contracts")
        return contracts
    except Exception as e:
        logger.error(f"Error listing contracts: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/v1/contracts", response_model=ContractResponse)
async def create_contract(contract: ContractCreate):
    """Cria um novo contrato"""
    try:
        contract_data = contract.dict()
        contract_id = save_contract_to_db(contract_data)
        
        # Buscar contrato criado
        created_contract = get_contract_from_db(contract_id)
        if not created_contract:
            raise HTTPException(status_code=500, detail="Failed to create contract")
        
        return created_contract
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating contract: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.get("/api/v1/contracts/{contract_id}", response_model=ContractResponse)
async def get_contract(contract_id: str = Path(..., description="ID do contrato")):
    """Busca um contrato específico"""
    try:
        contract = get_contract_from_db(contract_id)
        if not contract:
            raise HTTPException(status_code=404, detail="Contract not found")
        
        log_audit("READ", contract_id, "Contract accessed")
        return contract
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting contract: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.put("/api/v1/contracts/{contract_id}", response_model=ContractResponse)
async def update_contract(
    contract_id: str = Path(..., description="ID do contrato"),
    contract_update: ContractUpdate = None
):
    """Atualiza um contrato"""
    try:
        # Verificar se contrato existe
        existing_contract = get_contract_from_db(contract_id)
        if not existing_contract:
            raise HTTPException(status_code=404, detail="Contract not found")
        
        # Atualizar apenas campos fornecidos
        update_data = {k: v for k, v in contract_update.dict().items() if v is not None}
        
        if update_data:
            success = update_contract_in_db(contract_id, update_data)
            if not success:
                raise HTTPException(status_code=500, detail="Failed to update contract")
        
        # Retornar contrato atualizado
        updated_contract = get_contract_from_db(contract_id)
        return updated_contract
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating contract: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.delete("/api/v1/contracts/{contract_id}")
async def delete_contract(contract_id: str = Path(..., description="ID do contrato")):
    """Remove um contrato"""
    try:
        # Verificar se contrato existe
        existing_contract = get_contract_from_db(contract_id)
        if not existing_contract:
            raise HTTPException(status_code=404, detail="Contract not found")
        
        success = delete_contract_from_db(contract_id)
        if not success:
            raise HTTPException(status_code=500, detail="Failed to delete contract")
        
        return {"message": "Contract deleted successfully", "contract_id": contract_id}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting contract: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@app.post("/api/v1/pii/detect", response_model=PIIDetectionResponse)
async def detect_pii_endpoint(request: PIIDetectionRequest):
    """Detecta PII em texto"""
    try:
        result = detect_pii(request.text, request.context)
        log_audit("PII_DETECTION", None, f"PII detection performed, found: {result.has_pii}")
        return result
    except Exception as e:
        logger.error(f"Error in PII detection: {e}")
        raise HTTPException(status_code=500, detail="PII detection failed")

@app.post("/api/v1/compliance/assess", response_model=ComplianceAssessmentResponse)
async def assess_compliance_endpoint(request: ComplianceAssessmentRequest):
    """Avalia compliance de um contrato"""
    try:
        result = assess_compliance(request.contract_id, request.framework)
        log_audit("COMPLIANCE_ASSESSMENT", request.contract_id, 
                 f"Compliance assessment for {request.framework}")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in compliance assessment: {e}")
        raise HTTPException(status_code=500, detail="Compliance assessment failed")

@app.get("/api/v1/contracts/{contract_id}/audit")
async def get_contract_audit(contract_id: str = Path(..., description="ID do contrato")):
    """Busca logs de auditoria de um contrato"""
    try:
        with get_db_session() as session:
            audit_sql = text("""
                SELECT id, event_type, action, details, created_at
                FROM audit_events 
                WHERE resource_id = :contract_id
                ORDER BY created_at DESC
                LIMIT 50
            """)
            
            results = session.execute(audit_sql, {'contract_id': contract_id}).fetchall()
            
            audit_logs = []
            for result in results:
                audit_logs.append({
                    'id': str(result.id),
                    'event_type': result.event_type,
                    'action': result.action,
                    'details': result.details,
                    'created_at': result.created_at
                })
            
            return {
                'contract_id': contract_id,
                'audit_logs': audit_logs,
                'total_events': len(audit_logs)
            }
            
    except Exception as e:
        logger.error(f"Error getting audit logs: {e}")
        raise HTTPException(status_code=500, detail="Failed to get audit logs")

# =====================================================
# EVENTOS DE STARTUP/SHUTDOWN
# =====================================================

@app.on_event("startup")
async def startup_event():
    """Inicialização da aplicação"""
    logger.info("=== Contract Service Starting ===")
    logger.info("Version: 5.0.0 - PostgreSQL")
    
    try:
        # Verificar conexão com banco
        db_health = get_db_health()
        if db_health.get("status") == "healthy":
            logger.info("✅ PostgreSQL connection: OK")
            
            # Inicializar dados de exemplo
            init_sample_data()
            
        else:
            logger.error("❌ PostgreSQL connection: FAILED")
            
    except Exception as e:
        logger.error(f"❌ Startup error: {e}")

@app.on_event("shutdown")
async def shutdown_event():
    """Encerramento da aplicação"""
    logger.info("=== Contract Service Shutting Down ===")

# =====================================================
# EXECUÇÃO PRINCIPAL
# =====================================================

if __name__ == "__main__":
    logger.info("Starting Contract Service with PostgreSQL...")
    
    try:
        uvicorn.run(
            "main_postgresql:app",
            host="0.0.0.0",
            port=8001,
            log_level="info",
            reload=False
        )
    except Exception as e:
        logger.error(f"Failed to start server: {e}")
        sys.exit(1)

