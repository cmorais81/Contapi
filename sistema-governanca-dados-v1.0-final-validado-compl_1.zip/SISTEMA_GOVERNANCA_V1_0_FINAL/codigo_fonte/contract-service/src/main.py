# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
Contract Service - Microserviço de Contratos de Dados
Versão: 4.0.1 - Corrigida com base na V3.2
Data: 27 de Janeiro de 2025
"""

import json
import logging
import os
import re
from datetime import datetime
from typing import Dict, List, Optional, Any
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Query, Path, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'config'))

try:
    from settings import get_settings
    settings = get_settings()
except ImportError:
    print("⚠️ Configurações centralizadas não encontradas, usando valores padrão")
    settings = None


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Contract Service",
    description="Microserviço para gestão de contratos de dados - V4.0 Corrigido",
    version="4.0.1",
    contact={
        "name": " ",
        "email": "@example.com"
    }
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# PYDANTIC MODELS
# =====================================================

class ContractBase(BaseModel):
    name: str = Field(..., description="Nome do contrato")
    description: Optional[str] = Field(None, description="Descrição do contrato")
    version: str = Field("1.0.0", description="Versão do contrato")
    status: str = Field("draft", description="Status do contrato")
    data_classification: str = Field("internal", description="Classificação dos dados")
    owner_email: Optional[str] = Field(None, description="Email do proprietário")

class ContractCreate(ContractBase):
    pass

class ContractUpdate(ContractBase):
    pass

class ContractResponse(ContractBase):
    id: str
    created_at: datetime
    updated_at: datetime

# =====================================================
# POSTGRESQL DATABASE CONNECTION
# =====================================================

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from shared.database import get_db_session, execute_sql
from sqlalchemy import text

def log_audit(action: str, resource_id: str = None, details: str = None):
    """Log audit trail to PostgreSQL"""
    try:
        with get_db_session() as session:
            audit_sql = text("""
                INSERT INTO audit_events (event_type, resource_type, resource_id, action, details, created_at)
                VALUES (:event_type, :resource_type, :resource_id, :action, :details, CURRENT_TIMESTAMP)
            """)
            
            session.execute(audit_sql, {
                'event_type': 'contract_operation',
                'resource_type': 'contracts',
                'resource_id': resource_id,
                'action': action,
                'details': details
            })
            session.commit()
            
    except Exception as e:
        logger.error(f"Error logging audit: {e}")

def init_sample_data():
    """Initialize sample contracts in PostgreSQL"""
    try:
        with get_db_session() as session:
            # Verificar se já existem contratos
            count_sql = text("SELECT COUNT(*) FROM contracts")
            result = session.execute(count_sql)
            count = result.fetchone()[0]
            
            if count > 0:
                logger.info(f"Contracts already exist in database: {count}")
                return
            
            sample_contracts = [
                {
                    "name": "Contrato de Dados de Vendas",
                    "description": "Contrato para dados de vendas e faturamento",
                    "version": "1.0.0",
                    "status": "active",
                    "data_classification": "confidential",
                    "owner_email": "vendas@empresa.com"
                },
        {
            "id": str(uuid4()),
            "name": "Contrato de Dados de Clientes",
            "description": "Contrato para dados pessoais de clientes",
            "version": "2.1.0",
            "status": "active",
            "data_classification": "restricted",
            "owner_email": "privacidade@empresa.com",
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "Contrato de Dados de Marketing",
            "description": "Contrato para dados de campanhas de marketing",
            "version": "1.5.0",
            "status": "draft",
            "data_classification": "internal",
            "owner_email": "marketing@empresa.com",
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
    ]
    
    for contract in sample_contracts:
        contracts_db[contract["id"]] = contract
    
    logger.info(f"Initialized {len(sample_contracts)} sample contracts")

# =====================================================
# API ENDPOINTS
# =====================================================

@app.get("/", tags=["System"])
async def root():
    """Root endpoint with service information"""
    return {
        "service": "Contract Service",
        "version": "4.0.1",
        "status": "running",
        "description": "Microserviço para gestão de contratos de dados - Corrigido",
        "corrections_applied": [
            "Dependências estabilizadas",
            "Error handling robusto",
            "Logs estruturados",
            "In-memory database funcional"
        ],
        "endpoints": {
            "health": "/health",
            "docs": "/docs",
            "contracts": "/api/v1/contracts",
            "pii": "/api/v1/pii/detect",
            "compliance": "/api/v1/compliance/assess"
        }
    }

@app.get("/health", tags=["System"])
async def health_check():
    """Health check endpoint"""
    try:
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "version": "4.0.1",
            "service": "contract-service",
            "port": 8001,
            "corrections_applied": True,
            "data_counts": {
                "contracts": len(contracts_db),
                "audit_logs": len(audit_logs)
            },
            "features": {
                "contracts_management": True,
                "pii_detection": True,
                "compliance_assessment": True,
                "audit_trail": True
            }
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "status": "unhealthy",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

@app.get("/api/v1/contracts", response_model=List[ContractResponse], tags=["Contracts"])
async def list_contracts(
    status: Optional[str] = Query(None, description="Filtrar por status"),
    classification: Optional[str] = Query(None, description="Filtrar por classificação"),
    limit: int = Query(100, description="Limite de resultados")
):
    """Listar todos os contratos de dados"""
    try:
        contracts = list(contracts_db.values())
        
        # Apply filters
        if status:
            contracts = [c for c in contracts if c["status"] == status]
        
        if classification:
            contracts = [c for c in contracts if c["data_classification"] == classification]
        
        # Apply limit
        contracts = contracts[:limit]
        
        # Convert datetime objects to ISO format
        for contract in contracts:
            contract["created_at"] = contract["created_at"].isoformat()
            contract["updated_at"] = contract["updated_at"].isoformat()
        
        log_audit("list", details=f"Listed {len(contracts)} contracts")
        return contracts
        
    except Exception as e:
        logger.error(f"Error listing contracts: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing contracts: {str(e)}")

@app.get("/api/v1/contracts/{contract_id}", response_model=ContractResponse, tags=["Contracts"])
async def get_contract(contract_id: str = Path(..., description="ID do contrato")):
    """Buscar contrato específico por ID"""
    try:
        if contract_id not in contracts_db:
            raise HTTPException(status_code=404, detail="Contract not found")
        
        contract = contracts_db[contract_id].copy()
        contract["created_at"] = contract["created_at"].isoformat()
        contract["updated_at"] = contract["updated_at"].isoformat()
        
        log_audit("get", resource_id=contract_id)
        return contract
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting contract: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting contract: {str(e)}")

@app.post("/api/v1/contracts", response_model=ContractResponse, tags=["Contracts"])
async def create_contract(contract: ContractCreate):
    """Criar novo contrato de dados"""
    try:
        contract_id = str(uuid4())
        now = datetime.utcnow()
        
        new_contract = {
            "id": contract_id,
            "name": contract.name,
            "description": contract.description,
            "version": contract.version,
            "status": contract.status,
            "data_classification": contract.data_classification,
            "owner_email": contract.owner_email,
            "created_at": now,
            "updated_at": now
        }
        
        contracts_db[contract_id] = new_contract
        
        log_audit("create", resource_id=contract_id, details=f"Created contract: {contract.name}")
        
        # Convert datetime for response
        response_contract = new_contract.copy()
        response_contract["created_at"] = response_contract["created_at"].isoformat()
        response_contract["updated_at"] = response_contract["updated_at"].isoformat()
        
        return response_contract
        
    except Exception as e:
        logger.error(f"Error creating contract: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating contract: {str(e)}")

@app.put("/api/v1/contracts/{contract_id}", response_model=ContractResponse, tags=["Contracts"])
async def update_contract(contract_id: str, contract: ContractUpdate):
    """Atualizar contrato existente"""
    try:
        if contract_id not in contracts_db:
            raise HTTPException(status_code=404, detail="Contract not found")
        
        existing_contract = contracts_db[contract_id]
        
        # Update fields
        existing_contract.update({
            "name": contract.name,
            "description": contract.description,
            "version": contract.version,
            "status": contract.status,
            "data_classification": contract.data_classification,
            "owner_email": contract.owner_email,
            "updated_at": datetime.utcnow()
        })
        
        log_audit("update", resource_id=contract_id, details=f"Updated contract: {contract.name}")
        
        # Convert datetime for response
        response_contract = existing_contract.copy()
        response_contract["created_at"] = response_contract["created_at"].isoformat()
        response_contract["updated_at"] = response_contract["updated_at"].isoformat()
        
        return response_contract
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating contract: {e}")
        raise HTTPException(status_code=500, detail=f"Error updating contract: {str(e)}")

@app.delete("/api/v1/contracts/{contract_id}", tags=["Contracts"])
async def delete_contract(contract_id: str):
    """Deletar contrato"""
    try:
        if contract_id not in contracts_db:
            raise HTTPException(status_code=404, detail="Contract not found")
        
        contract_name = contracts_db[contract_id]["name"]
        del contracts_db[contract_id]
        
        log_audit("delete", resource_id=contract_id, details=f"Deleted contract: {contract_name}")
        
        return {"message": "Contract deleted successfully", "id": contract_id}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting contract: {e}")
        raise HTTPException(status_code=500, detail=f"Error deleting contract: {str(e)}")

@app.post("/api/v1/pii/detect", tags=["Privacy"])
async def detect_pii(data: Dict[str, Any] = Body(..., description="Dados para análise de PII")):
    """Detectar informações pessoais identificáveis (PII) nos dados"""
    try:
        pii_patterns = {
            "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            "cpf": r'\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b',
            "phone": r'\b(?:\+55\s?)?(?:\(\d{2}\)\s?)?\d{4,5}-?\d{4}\b',
            "credit_card": r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',
            "ip_address": r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
        }
        
        detected_pii = []
        
        def scan_value(key, value, path=""):
            if isinstance(value, str):
                for pii_type, pattern in pii_patterns.items():
                    matches = re.findall(pattern, value)
                    for match in matches:
                        detected_pii.append({
                            "type": pii_type,
                            "field": f"{path}.{key}" if path else key,
                            "value": match,
                            "confidence": 0.95,
                            "recommendation": f"Mask or encrypt {pii_type} data"
                        })
            elif isinstance(value, dict):
                for sub_key, sub_value in value.items():
                    scan_value(sub_key, sub_value, f"{path}.{key}" if path else key)
            elif isinstance(value, list):
                for i, item in enumerate(value):
                    scan_value(f"[{i}]", item, f"{path}.{key}" if path else key)
        
        for key, value in data.items():
            scan_value(key, value)
        
        log_audit("pii_detection", details=f"Detected {len(detected_pii)} PII items")
        
        return {
            "total_pii_found": len(detected_pii),
            "pii_items": detected_pii,
            "risk_level": "high" if len(detected_pii) > 5 else "medium" if len(detected_pii) > 0 else "low",
            "recommendations": [
                "Implement data masking for PII fields",
                "Apply encryption for sensitive data",
                "Review data access permissions",
                "Consider data anonymization techniques"
            ] if detected_pii else ["No PII detected - data appears safe"],
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error detecting PII: {e}")
        raise HTTPException(status_code=500, detail=f"Error detecting PII: {str(e)}")

@app.post("/api/v1/compliance/assess", tags=["Compliance"])
async def assess_compliance(data: Dict[str, Any] = Body(..., description="Dados para avaliação de compliance")):
    """Avaliar compliance LGPD/GDPR dos dados"""
    try:
        compliance_checks = []
        
        # Check for PII data
        pii_patterns = {
            "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            "cpf": r'\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b',
            "phone": r'\b(?:\+55\s?)?(?:\(\d{2}\)\s?)?\d{4,5}-?\d{4}\b'
        }
        
        pii_found = []
        
        def scan_for_pii(obj, path=""):
            if isinstance(obj, str):
                for pii_type, pattern in pii_patterns.items():
                    if re.search(pattern, obj):
                        pii_found.append({"type": pii_type, "field": path})
            elif isinstance(obj, dict):
                for key, value in obj.items():
                    field_path = f"{path}.{key}" if path else key
                    scan_for_pii(value, field_path)
            elif isinstance(obj, list):
                for i, item in enumerate(obj):
                    scan_for_pii(item, f"{path}[{i}]")
        
        scan_for_pii(data)
        
        # LGPD Compliance Checks
        compliance_checks.append({
            "regulation": "LGPD",
            "article": "Art. 6º - Finalidade",
            "check": "Data purpose definition",
            "status": "requires_review",
            "message": "Verify that data collection has a specific, legitimate purpose",
            "score": 0.7
        })
        
        if pii_found:
            compliance_checks.append({
                "regulation": "LGPD",
                "article": "Art. 46 - Segurança",
                "check": "PII protection",
                "status": "failed",
                "message": f"PII data detected ({len(pii_found)} items) - requires encryption/masking",
                "score": 0.3
            })
        else:
            compliance_checks.append({
                "regulation": "LGPD",
                "article": "Art. 46 - Segurança",
                "check": "PII protection",
                "status": "passed",
                "message": "No PII data detected",
                "score": 1.0
            })
        
        # Calculate overall compliance score
        total_score = sum(check["score"] for check in compliance_checks)
        max_score = len(compliance_checks)
        overall_score = (total_score / max_score) * 100 if max_score > 0 else 100
        
        log_audit("compliance_assessment", details=f"Assessed {len(compliance_checks)} compliance checks")
        
        return {
            "overall_score": round(overall_score, 2),
            "compliance_level": "compliant" if overall_score >= 80 else "partially_compliant" if overall_score >= 60 else "non_compliant",
            "total_checks": len(compliance_checks),
            "pii_detected": len(pii_found),
            "pii_items": pii_found,
            "compliance_checks": compliance_checks,
            "regulations_covered": ["LGPD", "GDPR"],
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error assessing compliance: {e}")
        raise HTTPException(status_code=500, detail=f"Error assessing compliance: {str(e)}")

@app.get("/api/v1/audit/logs", tags=["Audit"])
async def list_audit_logs(limit: int = Query(100, description="Limite de resultados")):
    """Listar logs de auditoria"""
    try:
        logs = audit_logs[-limit:] if limit < len(audit_logs) else audit_logs
        return logs
    except Exception as e:
        logger.error(f"Error listing audit logs: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing audit logs: {str(e)}")

# Initialize sample data on startup
@app.on_event("startup")
async def startup_event():
    """Initialize service on startup"""
    logger.info("Starting Contract Service V4.0.1 - Corrigido")
    init_sample_data()
    logger.info("Contract Service started successfully")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8001)

