# Autor: carlos.morais@f1rst.com.br
"""
Contract Service Models
Uses the central shared database models
"""

import sys
import os

# Add shared modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'shared'))

from shared.database.models.central_models import (
    Base,
    Contract,
    ContractVersion,
    ContractApproval,
    PIIClassification,
    MaskingPolicy,
    QualityMetric,
    ComplianceAssessment,
    User,
    Dataset,
    Organization
)

# Aliases for backward compatibility
ContractModel = Contract
ContractVersionModel = ContractVersion
ContractApprovalModel = ContractApproval
PIIClassificationModel = PIIClassification
MaskingPolicyModel = MaskingPolicy
QualityMetricModel = QualityMetric
ComplianceAssessmentModel = ComplianceAssessment
UserModel = User
DatasetModel = Dataset
OrganizationModel = Organization

# Re-export everything
__all__ = [
    'Base',
    'Contract',
    'ContractModel',
    'ContractVersion',
    'ContractVersionModel',
    'ContractApproval',
    'ContractApprovalModel',
    'PIIClassification',
    'PIIClassificationModel',
    'MaskingPolicy',
    'MaskingPolicyModel',
    'QualityMetric',
    'QualityMetricModel',
    'ComplianceAssessment',
    'ComplianceAssessmentModel',
    'User',
    'UserModel',
    'Dataset',
    'DatasetModel',
    'Organization',
    'OrganizationModel'
]

