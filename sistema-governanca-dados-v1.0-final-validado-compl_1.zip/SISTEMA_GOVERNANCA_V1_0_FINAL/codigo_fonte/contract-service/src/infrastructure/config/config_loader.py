"""
Configuration Loader - Carregador de configurações YAML
Segue Single Responsibility Principle - responsável apenas por carregar configs
"""

import os
import yaml
from typing import Dict, Any, Optional
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class ConfigLoader:
    """
    Carregador de configurações YAML
    Responsabilidade única: carregar e validar configurações
    """
    
    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or self._find_config_file()
        self._config_cache: Optional[Dict[str, Any]] = None
    
    def _find_config_file(self) -> str:
        """Encontra arquivo de configuração"""
        possible_paths = [
            "config.yml",
            "config.yaml",
            "../config.yml",
            "../config.yaml",
            "../../config.yml",
            "../../config.yaml"
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                return path
        
        # Se não encontrar, usar caminho padrão
        return "config.yml"
    
    def load_config(self) -> Dict[str, Any]:
        """
        Carrega configurações do arquivo YAML
        """
        if self._config_cache is not None:
            return self._config_cache
        
        try:
            if not os.path.exists(self.config_path):
                logger.warning(f"Arquivo de configuração não encontrado: {self.config_path}")
                return self._get_default_config()
            
            with open(self.config_path, 'r', encoding='utf-8') as file:
                config = yaml.safe_load(file)
            
            # Expandir variáveis de ambiente
            config = self._expand_environment_variables(config)
            
            # Validar configuração
            self._validate_config(config)
            
            self._config_cache = config
            logger.info(f"Configuração carregada de: {self.config_path}")
            
            return config
            
        except Exception as e:
            logger.error(f"Erro ao carregar configuração: {e}")
            return self._get_default_config()
    
    def _expand_environment_variables(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Expande variáveis de ambiente nas configurações
        """
        def expand_value(value):
            if isinstance(value, str):
                # Procurar padrões ${VAR:default}
                import re
                pattern = r'\$\{([^:}]+):?([^}]*)\}'
                
                def replace_var(match):
                    var_name = match.group(1)
                    default_value = match.group(2) if match.group(2) else ""
                    return os.getenv(var_name, default_value)
                
                return re.sub(pattern, replace_var, value)
            
            elif isinstance(value, dict):
                return {k: expand_value(v) for k, v in value.items()}
            
            elif isinstance(value, list):
                return [expand_value(item) for item in value]
            
            return value
        
        return expand_value(config)
    
    def _validate_config(self, config: Dict[str, Any]) -> None:
        """
        Valida configuração carregada
        """
        required_sections = ['service', 'database']
        
        for section in required_sections:
            if section not in config:
                raise ValueError(f"Seção obrigatória '{section}' não encontrada na configuração")
        
        # Validar configurações específicas
        service_config = config.get('service', {})
        if 'port' not in service_config:
            raise ValueError("Porta do serviço não configurada")
        
        database_config = config.get('database', {})
        if 'host' not in database_config:
            raise ValueError("Host do banco de dados não configurado")
    
    def _get_default_config(self) -> Dict[str, Any]:
        """
        Retorna configuração padrão quando arquivo não existe
        """
        return {
            'service': {
                'name': 'contract-service',
                'version': '1.0.0',
                'port': 8001,
                'host': '0.0.0.0'
            },
            'database': {
                'type': 'postgresql',
                'host': 'localhost',
                'port': 5432,
                'name': 'governance_db',
                'username': 'postgres',
                'password': 'postgres'
            },
            'logging': {
                'level': 'INFO',
                'console': True
            },
            'security': {
                'cors': {
                    'allow_origins': ['*']
                }
            }
        }
    
    def get_section(self, section_name: str) -> Dict[str, Any]:
        """
        Retorna seção específica da configuração
        """
        config = self.load_config()
        return config.get(section_name, {})
    
    def get_value(self, key_path: str, default: Any = None) -> Any:
        """
        Retorna valor usando caminho com pontos (ex: 'database.host')
        """
        config = self.load_config()
        keys = key_path.split('.')
        
        value = config
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        
        return value
    
    def reload_config(self) -> Dict[str, Any]:
        """
        Recarrega configuração do arquivo
        """
        self._config_cache = None
        return self.load_config()


class DatabaseConfig:
    """
    Configuração específica do banco de dados
    """
    
    def __init__(self, config_loader: ConfigLoader):
        self.config_loader = config_loader
        self._db_config = None
    
    @property
    def database_url(self) -> str:
        """Constrói URL de conexão do banco"""
        db_config = self.config_loader.get_section('database')
        
        db_type = db_config.get('type', 'postgresql')
        username = db_config.get('username', 'postgres')
        password = db_config.get('password', 'postgres')
        host = db_config.get('host', 'localhost')
        port = db_config.get('port', 5432)
        name = db_config.get('name', 'governance_db')
        
        return f"{db_type}://{username}:{password}@{host}:{port}/{name}"
    
    @property
    def pool_settings(self) -> Dict[str, Any]:
        """Configurações do pool de conexões"""
        db_config = self.config_loader.get_section('database')
        
        return {
            'pool_size': db_config.get('pool_size', 10),
            'max_overflow': db_config.get('max_overflow', 20),
            'pool_timeout': db_config.get('pool_timeout', 30),
            'pool_recycle': db_config.get('pool_recycle', 3600),
            'echo': db_config.get('echo', False)
        }


class ServiceConfig:
    """
    Configuração específica do serviço
    """
    
    def __init__(self, config_loader: ConfigLoader):
        self.config_loader = config_loader
    
    @property
    def service_info(self) -> Dict[str, Any]:
        """Informações do serviço"""
        return self.config_loader.get_section('service')
    
    @property
    def port(self) -> int:
        """Porta do serviço"""
        return self.config_loader.get_value('service.port', 8001)
    
    @property
    def host(self) -> str:
        """Host do serviço"""
        return self.config_loader.get_value('service.host', '0.0.0.0')
    
    @property
    def debug(self) -> bool:
        """Modo debug"""
        return self.config_loader.get_value('development.debug', False)


# Instância global do carregador de configuração
config_loader = ConfigLoader()
database_config = DatabaseConfig(config_loader)
service_config = ServiceConfig(config_loader)


def get_config() -> Dict[str, Any]:
    """Função utilitária para obter configuração completa"""
    return config_loader.load_config()


def get_database_url() -> str:
    """Função utilitária para obter URL do banco"""
    return database_config.database_url


def get_service_port() -> int:
    """Função utilitária para obter porta do serviço"""
    return service_config.port

