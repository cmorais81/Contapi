# Autor: carlos.morais@f1rst.com.br
"""
Contract Service Database Configuration
Uses the central shared database
"""

import sys
import os

# Add shared modules to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'shared'))

from shared.database.central_database import (
    get_db,
    get_db_session,
    check_db_connection,
    init_db,
    get_raw_connection,
    execute_sql_file,
    get_db_stats,
    health_check,
    DatabaseUtils,
    Base,
    engine,
    SessionLocal
)

# Re-export everything for backward compatibility
__all__ = [
    'get_db',
    'get_db_session', 
    'check_db_connection',
    'init_db',
    'get_raw_connection',
    'execute_sql_file',
    'get_db_stats',
    'health_check',
    'DatabaseUtils',
    'Base',
    'engine',
    'SessionLocal'
]

