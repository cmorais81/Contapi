"""
Conexão com banco de dados PostgreSQL
Autor: carlos.morais@f1rst.com.br
"""

from sqlalchemy import create_engine, MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import QueuePool
import os
import sys

# Adiciona o diretório config ao path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'config'))

try:
    from settings import get_settings
    settings = get_settings()
    DATABASE_URL = settings.database.url
except ImportError:
    # Fallback para configuração manual
    DATABASE_URL = os.getenv(
        "DATABASE_URL", 
        "postgresql://governance_user:governance_pass@localhost:5432/governance_db"
    )

# Configuração do SQLAlchemy
engine = create_engine(
    DATABASE_URL,
    poolclass=QueuePool,
    pool_size=20,
    max_overflow=30,
    pool_pre_ping=True,
    echo=False
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
metadata = MetaData()

def get_database():
    """Dependency para obter sessão do banco"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_database():
    """Inicializa o banco de dados"""
    try:
        Base.metadata.create_all(bind=engine)
        print("✅ Banco de dados inicializado com sucesso")
        return True
    except Exception as e:
        print(f"❌ Erro ao inicializar banco: {str(e)}")
        return False

def test_connection():
    """Testa conexão com banco de dados"""
    try:
        with engine.connect() as connection:
            result = connection.execute("SELECT 1")
            print("✅ Conexão com banco de dados OK")
            return True
    except Exception as e:
        print(f"❌ Erro de conexão: {str(e)}")
        return False
