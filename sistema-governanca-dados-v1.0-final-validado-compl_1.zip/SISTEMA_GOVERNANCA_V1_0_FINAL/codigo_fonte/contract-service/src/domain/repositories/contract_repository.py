"""
Contract Repository Interface - Interface seguindo ISP
Interface Segregation Principle - interface específica para contratos
"""

from abc import ABC, abstractmethod
from typing import List, Optional, Dict, Any
from ..entities.contract import Contract, ContractStatus, DataClassification


class ContractRepository(ABC):
    """
    Interface do repositório de contratos
    Responsabilidade única: definir operações de persistência para contratos
    """
    
    @abstractmethod
    async def save(self, contract: Contract) -> Contract:
        """Salva um contrato"""
        pass
    
    @abstractmethod
    async def find_by_id(self, contract_id: str) -> Optional[Contract]:
        """Busca contrato por ID"""
        pass
    
    @abstractmethod
    async def find_all(self, 
                      limit: int = 100, 
                      offset: int = 0) -> List[Contract]:
        """Lista todos os contratos com paginação"""
        pass
    
    @abstractmethod
    async def find_by_owner(self, owner_email: str) -> List[Contract]:
        """Busca contratos por proprietário"""
        pass
    
    @abstractmethod
    async def find_by_status(self, status: ContractStatus) -> List[Contract]:
        """Busca contratos por status"""
        pass
    
    @abstractmethod
    async def find_by_classification(self, 
                                   classification: DataClassification) -> List[Contract]:
        """Busca contratos por classificação"""
        pass
    
    @abstractmethod
    async def update(self, contract: Contract) -> Contract:
        """Atualiza um contrato"""
        pass
    
    @abstractmethod
    async def delete(self, contract_id: str) -> bool:
        """Remove um contrato"""
        pass
    
    @abstractmethod
    async def exists(self, contract_id: str) -> bool:
        """Verifica se contrato existe"""
        pass
    
    @abstractmethod
    async def count(self) -> int:
        """Conta total de contratos"""
        pass
    
    @abstractmethod
    async def search(self, 
                    query: str, 
                    filters: Optional[Dict[str, Any]] = None) -> List[Contract]:
        """Busca contratos com filtros"""
        pass


class ContractQueryRepository(ABC):
    """
    Interface específica para consultas complexas
    Segregação de responsabilidade para queries avançadas
    """
    
    @abstractmethod
    async def find_with_pii(self) -> List[Contract]:
        """Busca contratos que possuem campos PII"""
        pass
    
    @abstractmethod
    async def find_by_compliance_framework(self, framework: str) -> List[Contract]:
        """Busca contratos por framework de compliance"""
        pass
    
    @abstractmethod
    async def find_expiring_soon(self, days: int = 30) -> List[Contract]:
        """Busca contratos que expiram em breve"""
        pass
    
    @abstractmethod
    async def get_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas dos contratos"""
        pass
    
    @abstractmethod
    async def find_by_template(self, template_id: str) -> List[Contract]:
        """Busca contratos por template"""
        pass

