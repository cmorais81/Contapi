# Autor: carlos.morais@f1rst.com.br
"""
Contract Status Value Object
Represents the lifecycle status of a contract
"""

from enum import Enum
from dataclasses import dataclass
from typing import List, Optional


class ContractStatus(Enum):
    """Contract lifecycle status"""
    DRAFT = "draft"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    EXPIRED = "expired"
    TERMINATED = "terminated"
    
    def __str__(self) -> str:
        return self.value
    
    @classmethod
    def from_string(cls, value: str) -> 'ContractStatus':
        """Create status from string value"""
        for status in cls:
            if status.value == value.lower():
                return status
        raise ValueError(f"Invalid contract status: {value}")
    
    def can_transition_to(self, new_status: 'ContractStatus') -> bool:
        """Check if transition to new status is allowed"""
        valid_transitions = {
            ContractStatus.DRAFT: [
                ContractStatus.PENDING_APPROVAL,
                ContractStatus.TERMINATED
            ],
            ContractStatus.PENDING_APPROVAL: [
                ContractStatus.APPROVED,
                ContractStatus.DRAFT,
                ContractStatus.TERMINATED
            ],
            ContractStatus.APPROVED: [
                ContractStatus.ACTIVE,
                ContractStatus.TERMINATED
            ],
            ContractStatus.ACTIVE: [
                ContractStatus.SUSPENDED,
                ContractStatus.EXPIRED,
                ContractStatus.TERMINATED
            ],
            ContractStatus.SUSPENDED: [
                ContractStatus.ACTIVE,
                ContractStatus.EXPIRED,
                ContractStatus.TERMINATED
            ],
            ContractStatus.EXPIRED: [
                ContractStatus.TERMINATED
            ],
            ContractStatus.TERMINATED: []
        }
        
        return new_status in valid_transitions.get(self, [])
    
    def is_editable(self) -> bool:
        """Check if contract can be edited in this status"""
        return self in [ContractStatus.DRAFT]
    
    def is_active_state(self) -> bool:
        """Check if this is an active operational state"""
        return self == ContractStatus.ACTIVE
    
    def requires_approval(self) -> bool:
        """Check if this status requires approval"""
        return self == ContractStatus.PENDING_APPROVAL


@dataclass(frozen=True)
class StatusTransition:
    """Represents a status transition with metadata"""
    from_status: ContractStatus
    to_status: ContractStatus
    reason: Optional[str] = None
    requires_approval: bool = False
    
    def __post_init__(self):
        if not self.from_status.can_transition_to(self.to_status):
            raise ValueError(
                f"Invalid transition from {self.from_status} to {self.to_status}"
            )
    
    def is_valid(self) -> bool:
        """Validate the transition"""
        return self.from_status.can_transition_to(self.to_status)

