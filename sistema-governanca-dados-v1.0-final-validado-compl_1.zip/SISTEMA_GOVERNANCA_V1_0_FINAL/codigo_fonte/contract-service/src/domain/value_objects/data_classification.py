# Autor: carlos.morais@f1rst.com.br
"""
Data Classification Value Object
Represents data sensitivity and access levels
"""

from enum import Enum
from dataclasses import dataclass
from typing import List, Dict, Any


class DataClassification(Enum):
    """Data classification levels"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTL = "confidential"
    RESTRICTED = "restricted"
    TOP_SECRET = "top_secret"
    
    def __str__(self) -> str:
        return self.value
    
    @classmethod
    def from_string(cls, value: str) -> 'DataClassification':
        """Create classification from string value"""
        for classification in cls:
            if classification.value == value.lower():
                return classification
        raise ValueError(f"Invalid data classification: {value}")
    
    def get_security_level(self) -> int:
        """Get numeric security level (higher = more secure)"""
        levels = {
            DataClassification.PUBLIC: 1,
            DataClassification.INTERNAL: 2,
            DataClassification.CONFIDENTL: 3,
            DataClassification.RESTRICTED: 4,
            DataClassification.TOP_SECRET: 5
        }
        return levels[self]
    
    def get_access_requirements(self) -> Dict[str, Any]:
        """Get access control requirements for this classification"""
        requirements = {
            DataClassification.PUBLIC: {
                "authentication_required": False,
                "authorization_required": False,
                "encryption_required": False,
                "audit_logging": False,
                "retention_period_days": 365
            },
            DataClassification.INTERNAL: {
                "authentication_required": True,
                "authorization_required": True,
                "encryption_required": False,
                "audit_logging": True,
                "retention_period_days": 2555  # 7 years
            },
            DataClassification.CONFIDENTL: {
                "authentication_required": True,
                "authorization_required": True,
                "encryption_required": True,
                "audit_logging": True,
                "retention_period_days": 2555,
                "masking_required": True
            },
            DataClassification.RESTRICTED: {
                "authentication_required": True,
                "authorization_required": True,
                "encryption_required": True,
                "audit_logging": True,
                "retention_period_days": 3650,  # 10 years
                "masking_required": True,
                "approval_required": True
            },
            DataClassification.TOP_SECRET: {
                "authentication_required": True,
                "authorization_required": True,
                "encryption_required": True,
                "audit_logging": True,
                "retention_period_days": 7300,  # 20 years
                "masking_required": True,
                "approval_required": True,
                "multi_factor_auth": True,
                "access_logging": True
            }
        }
        return requirements[self]
    
    def get_compliance_frameworks(self) -> List[str]:
        """Get applicable compliance frameworks"""
        frameworks = {
            DataClassification.PUBLIC: [],
            DataClassification.INTERNAL: ["ISO27001"],
            DataClassification.CONFIDENTL: ["ISO27001", "LGPD"],
            DataClassification.RESTRICTED: ["ISO27001", "LGPD", "GDPR"],
            DataClassification.TOP_SECRET: ["ISO27001", "LGPD", "GDPR", "SOX", "HIPAA"]
        }
        return frameworks[self]
    
    def requires_encryption(self) -> bool:
        """Check if encryption is required"""
        return self.get_security_level() >= 3
    
    def requires_masking(self) -> bool:
        """Check if data masking is required"""
        return self.get_security_level() >= 3
    
    def requires_approval(self) -> bool:
        """Check if access requires approval"""
        return self.get_security_level() >= 4


@dataclass(frozen=True)
class ClassificationRule:
    """Rule for automatic data classification"""
    pattern: str
    classification: DataClassification
    confidence: float
    field_types: List[str]
    
    def __post_init__(self):
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("Confidence must be between 0.0 and 1.0")
    
    def matches(self, field_name: str, field_type: str, sample_data: str = "") -> bool:
        """Check if this rule matches the given field"""
        import re
        
        # Check field type
        if self.field_types and field_type not in self.field_types:
            return False
        
        # Check pattern match
        return bool(re.search(self.pattern, field_name, re.IGNORECASE))


# Predefined classification rules
DEFAULT_CLASSIFICATION_RULES = [
    ClassificationRule(
        pattern=r"(email|e_mail|mail)",
        classification=DataClassification.CONFIDENTL,
        confidence=0.9,
        field_types=["string", "text"]
    ),
    ClassificationRule(
        pattern=r"(phone|telefone|celular)",
        classification=DataClassification.CONFIDENTL,
        confidence=0.9,
        field_types=["string", "text"]
    ),
    ClassificationRule(
        pattern=r"(cpf|cnpj|rg|passport)",
        classification=DataClassification.RESTRICTED,
        confidence=0.95,
        field_types=["string", "text"]
    ),
    ClassificationRule(
        pattern=r"(password|senha|secret)",
        classification=DataClassification.TOP_SECRET,
        confidence=1.0,
        field_types=["string", "text"]
    ),
    ClassificationRule(
        pattern=r"(salary|salario|income|renda)",
        classification=DataClassification.CONFIDENTL,
        confidence=0.8,
        field_types=["number", "decimal", "float"]
    ),
    ClassificationRule(
        pattern=r"(address|endereco|street|rua)",
        classification=DataClassification.CONFIDENTL,
        confidence=0.8,
        field_types=["string", "text"]
    ),
    ClassificationRule(
        pattern=r"(birth|nascimento|age|idade)",
        classification=DataClassification.CONFIDENTL,
        confidence=0.9,
        field_types=["date", "datetime", "number"]
    )
]

