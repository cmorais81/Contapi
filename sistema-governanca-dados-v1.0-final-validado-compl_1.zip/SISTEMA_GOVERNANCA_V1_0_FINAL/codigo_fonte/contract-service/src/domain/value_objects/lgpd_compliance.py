# Autor: carlos.morais@f1rst.com.br
"""
LGPD Compliance Value Object
Specific compliance rules and requirements for Brazilian LGPD
"""

from enum import Enum
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta


class LGPDLegalBasis(Enum):
    """LGPD Legal basis for data processing (Art. 7º)"""
    CONSENT = "consent"  # Consentimento
    CONTRACT = "contract"  # Execução de contrato
    LEGAL_OBLIGATION = "legal_obligation"  # Cumprimento de obrigação legal
    VITAL_INTERESTS = "vital_interests"  # Proteção da vida
    PUBLIC_INTEREST = "public_interest"  # Execução de políticas públicas
    LEGITIMATE_INTEREST = "legitimate_interest"  # Interesse legítimo
    CREDIT_PROTECTION = "credit_protection"  # Proteção ao crédito
    HEALTH_PROTECTION = "health_protection"  # Tutela da saúde (Art. 11º)
    FRAUD_PREVENTION = "fraud_prevention"  # Prevenção à fraude
    SECURITY = "security"  # Proteção e segurança


class LGPDDataCategory(Enum):
    """LGPD Data categories"""
    PERSONAL_DATA = "personal_data"  # Dados pessoais
    SENSITIVE_DATA = "sensitive_data"  # Dados pessoais sensíveis
    ANONYMIZED_DATA = "anonymized_data"  # Dados anonimizados
    PSEUDONYMIZED_DATA = "pseudonymized_data"  # Dados pseudonimizados


class LGPDDataSubjectRights(Enum):
    """LGPD Data subject rights (Art. 18º)"""
    ACCESS = "access"  # Confirmação e acesso
    CORRECTION = "correction"  # Correção
    ANONYMIZATION = "anonymization"  # Anonimização
    BLOCKING = "blocking"  # Bloqueio
    ELIMINATION = "elimination"  # Eliminação
    PORTABILITY = "portability"  # Portabilidade
    INFORMATION = "information"  # Informação sobre compartilhamento
    CONSENT_WITHDRAWAL = "consent_withdrawal"  # Revogação do consentimento


@dataclass(frozen=True)
class LGPDRequirement:
    """LGPD compliance requirement"""
    article: str
    description: str
    applies_to_categories: List[LGPDDataCategory]
    mandatory: bool
    penalty_risk: str  # low, medium, high
    
    def is_applicable(self, data_category: LGPDDataCategory) -> bool:
        """Check if requirement applies to data category"""
        return data_category in self.applies_to_categories


@dataclass
class LGPDComplianceAssessment:
    """LGPD compliance assessment result"""
    overall_score: float
    legal_basis_defined: bool
    consent_mechanism: bool
    data_minimization: bool
    purpose_limitation: bool
    retention_policy: bool
    security_measures: bool
    data_subject_rights: bool
    privacy_notice: bool
    dpo_appointed: bool
    impact_assessment: bool
    
    # Detailed findings
    findings: List[str]
    recommendations: List[str]
    non_compliance_risks: List[str]
    
    # Assessment metadata
    assessed_at: datetime
    assessor: str
    next_review_date: datetime
    
    def get_compliance_status(self) -> str:
        """Get overall compliance status"""
        if self.overall_score >= 0.9:
            return "compliant"
        elif self.overall_score >= 0.7:
            return "partially_compliant"
        else:
            return "non_compliant"
    
    def get_priority_actions(self) -> List[str]:
        """Get priority actions for compliance"""
        actions = []
        
        if not self.legal_basis_defined:
            actions.append("Definir base legal para tratamento de dados (Art. 7º)")
        
        if not self.consent_mechanism and self.legal_basis_defined:
            actions.append("Implementar mecanismo de consentimento (Art. 8º)")
        
        if not self.data_minimization:
            actions.append("Implementar princípio da minimização (Art. 6º, III)")
        
        if not self.retention_policy:
            actions.append("Definir política de retenção de dados (Art. 15º)")
        
        if not self.security_measures:
            actions.append("Implementar medidas de segurança (Art. 46º)")
        
        if not self.privacy_notice:
            actions.append("Criar aviso de privacidade (Art. 9º)")
        
        return actions


class LGPDComplianceService:
    """Service for LGPD compliance assessment and validation"""
    
    def __init__(self):
        self.requirements = self._initialize_lgpd_requirements()
    
    def assess_contract_compliance(self, contract_data: Dict[str, Any]) -> LGPDComplianceAssessment:
        """Assess LGPD compliance for a contract"""
        
        # Extract relevant data
        data_classification = contract_data.get('data_classification', 'internal')
        pii_fields = contract_data.get('pii_fields', [])
        legal_basis = contract_data.get('legal_basis')
        retention_period = contract_data.get('retention_period_days', 0)
        security_measures = contract_data.get('security_measures', {})
        
        # Assess each requirement
        legal_basis_defined = bool(legal_basis)
        consent_mechanism = self._check_consent_mechanism(contract_data)
        data_minimization = self._check_data_minimization(contract_data)
        purpose_limitation = self._check_purpose_limitation(contract_data)
        retention_policy = retention_period > 0
        security_measures_adequate = self._check_security_measures(security_measures, pii_fields)
        data_subject_rights = self._check_data_subject_rights(contract_data)
        privacy_notice = contract_data.get('privacy_notice_url') is not None
        dpo_appointed = contract_data.get('dpo_contact') is not None
        impact_assessment = self._check_impact_assessment_needed(pii_fields)
        
        # Calculate score
        checks = [
            legal_basis_defined, consent_mechanism, data_minimization,
            purpose_limitation, retention_policy, security_measures_adequate,
            data_subject_rights, privacy_notice, dpo_appointed, impact_assessment
        ]
        score = sum(checks) / len(checks)
        
        # Generate findings and recommendations
        findings = self._generate_findings(contract_data, checks)
        recommendations = self._generate_recommendations(contract_data, checks)
        risks = self._assess_non_compliance_risks(contract_data, checks)
        
        return LGPDComplianceAssessment(
            overall_score=score,
            legal_basis_defined=legal_basis_defined,
            consent_mechanism=consent_mechanism,
            data_minimization=data_minimization,
            purpose_limitation=purpose_limitation,
            retention_policy=retention_policy,
            security_measures=security_measures_adequate,
            data_subject_rights=data_subject_rights,
            privacy_notice=privacy_notice,
            dpo_appointed=dpo_appointed,
            impact_assessment=impact_assessment,
            findings=findings,
            recommendations=recommendations,
            non_compliance_risks=risks,
            assessed_at=datetime.utcnow(),
            assessor="system",
            next_review_date=datetime.utcnow() + timedelta(days=90)
        )
    
    def get_required_legal_basis(self, data_types: List[str], processing_purpose: str) -> List[LGPDLegalBasis]:
        """Get recommended legal basis for data processing"""
        recommendations = []
        
        # Check for sensitive data
        sensitive_indicators = ['health', 'biometric', 'genetic', 'religious', 'political']
        has_sensitive = any(indicator in ' '.join(data_types).lower() for indicator in sensitive_indicators)
        
        if has_sensitive:
            recommendations.append(LGPDLegalBasis.CONSENT)
            recommendations.append(LGPDLegalBasis.HEALTH_PROTECTION)
        
        # Check processing purpose
        purpose_lower = processing_purpose.lower()
        
        if 'contrato' in purpose_lower or 'contract' in purpose_lower:
            recommendations.append(LGPDLegalBasis.CONTRACT)
        
        if 'consentimento' in purpose_lower or 'consent' in purpose_lower:
            recommendations.append(LGPDLegalBasis.CONSENT)
        
        if 'legal' in purpose_lower or 'obrigação' in purpose_lower:
            recommendations.append(LGPDLegalBasis.LEGAL_OBLIGATION)
        
        if 'fraude' in purpose_lower or 'fraud' in purpose_lower:
            recommendations.append(LGPDLegalBasis.FRAUD_PREVENTION)
        
        if 'segurança' in purpose_lower or 'security' in purpose_lower:
            recommendations.append(LGPDLegalBasis.SECURITY)
        
        # Default to legitimate interest if no specific basis found
        if not recommendations:
            recommendations.append(LGPDLegalBasis.LEGITIMATE_INTEREST)
        
        return list(set(recommendations))
    
    def get_retention_recommendations(self, data_category: LGPDDataCategory, legal_basis: LGPDLegalBasis) -> int:
        """Get recommended retention period in days"""
        
        # Base retention periods by category
        base_periods = {
            LGPDDataCategory.PERSONAL_DATA: 1825,  # 5 years
            LGPDDataCategory.SENSITIVE_DATA: 1095,  # 3 years
            LGPDDataCategory.ANONYMIZED_DATA: -1,   # No limit
            LGPDDataCategory.PSEUDONYMIZED_DATA: 2555  # 7 years
        }
        
        # Adjustments by legal basis
        adjustments = {
            LGPDLegalBasis.CONSENT: 0.8,  # Shorter retention
            LGPDLegalBasis.CONTRACT: 1.0,  # Standard
            LGPDLegalBasis.LEGAL_OBLIGATION: 1.5,  # Longer retention
            LGPDLegalBasis.LEGITIMATE_INTEREST: 0.9,
            LGPDLegalBasis.FRAUD_PREVENTION: 1.2
        }
        
        base_period = base_periods.get(data_category, 1825)
        if base_period == -1:
            return -1
        
        adjustment = adjustments.get(legal_basis, 1.0)
        return int(base_period * adjustment)
    
    def _check_consent_mechanism(self, contract_data: Dict[str, Any]) -> bool:
        """Check if consent mechanism is properly implemented"""
        legal_basis = contract_data.get('legal_basis')
        if legal_basis != LGPDLegalBasis.CONSENT.value:
            return True  # Not required if not using consent
        
        return bool(contract_data.get('consent_mechanism'))
    
    def _check_data_minimization(self, contract_data: Dict[str, Any]) -> bool:
        """Check data minimization principle"""
        schema_fields = contract_data.get('schema_definition', {}).get('fields', [])
        purpose = contract_data.get('processing_purpose', '')
        
        # Simple check: ensure purpose is defined and fields are reasonable
        return bool(purpose) and len(schema_fields) <= 50  # Arbitrary limit
    
    def _check_purpose_limitation(self, contract_data: Dict[str, Any]) -> bool:
        """Check purpose limitation principle"""
        return bool(contract_data.get('processing_purpose'))
    
    def _check_security_measures(self, security_measures: Dict[str, Any], pii_fields: List[str]) -> bool:
        """Check if security measures are adequate"""
        if not pii_fields:
            return True  # No PII, basic security sufficient
        
        required_measures = ['encryption', 'access_control', 'audit_logging']
        implemented_measures = security_measures.keys()
        
        return all(measure in implemented_measures for measure in required_measures)
    
    def _check_data_subject_rights(self, contract_data: Dict[str, Any]) -> bool:
        """Check if data subject rights are implemented"""
        return bool(contract_data.get('data_subject_rights_mechanism'))
    
    def _check_impact_assessment_needed(self, pii_fields: List[str]) -> bool:
        """Check if DP is needed and implemented"""
        # DP required for high-risk processing
        sensitive_fields = ['health', 'biometric', 'genetic', 'racial', 'political']
        has_sensitive = any(field for field in pii_fields 
                          if any(sensitive in field.lower() for sensitive in sensitive_fields))
        
        return not has_sensitive or len(pii_fields) < 10  # Simplified logic
    
    def _generate_findings(self, contract_data: Dict[str, Any], checks: List[bool]) -> List[str]:
        """Generate compliance findings"""
        findings = []
        
        if not checks[0]:  # legal_basis_defined
            findings.append("Base legal não definida para tratamento de dados")
        
        if not checks[1]:  # consent_mechanism
            findings.append("Mecanismo de consentimento não implementado")
        
        if not checks[4]:  # retention_policy
            findings.append("Política de retenção de dados não definida")
        
        if not checks[5]:  # security_measures
            findings.append("Medidas de segurança insuficientes para dados pessoais")
        
        return findings
    
    def _generate_recommendations(self, contract_data: Dict[str, Any], checks: List[bool]) -> List[str]:
        """Generate compliance recommendations"""
        recommendations = []
        
        if not checks[0]:
            recommendations.append("Definir base legal conforme Art. 7º da LGPD")
        
        if not checks[7]:  # privacy_notice
            recommendations.append("Criar aviso de privacidade conforme Art. 9º da LGPD")
        
        if not checks[8]:  # dpo_appointed
            recommendations.append("Considerar nomeação de Encarregado de Dados (DPO)")
        
        recommendations.append("Implementar mecanismo para exercício de direitos do titular")
        recommendations.append("Realizar treinamento em LGPD para equipe")
        
        return recommendations
    
    def _assess_non_compliance_risks(self, contract_data: Dict[str, Any], checks: List[bool]) -> List[str]:
        """Assess non-compliance risks"""
        risks = []
        
        if not checks[0]:  # legal_basis
            risks.append("Risco de multa por tratamento sem base legal (Art. 52º)")
        
        if not checks[5]:  # security_measures
            risks.append("Risco de vazamento de dados e multa por segurança inadequada")
        
        if not checks[6]:  # data_subject_rights
            risks.append("Risco de reclamações à ANPD por não atendimento de direitos")
        
        return risks
    
    def _initialize_lgpd_requirements(self) -> List[LGPDRequirement]:
        """Initialize LGPD compliance requirements"""
        return [
            LGPDRequirement(
                article="Art. 7º",
                description="Base legal para tratamento de dados pessoais",
                applies_to_categories=[LGPDDataCategory.PERSONAL_DATA, LGPDDataCategory.SENSITIVE_DATA],
                mandatory=True,
                penalty_risk="high"
            ),
            LGPDRequirement(
                article="Art. 8º",
                description="Consentimento livre, informado e inequívoco",
                applies_to_categories=[LGPDDataCategory.PERSONAL_DATA, LGPDDataCategory.SENSITIVE_DATA],
                mandatory=True,
                penalty_risk="high"
            ),
            LGPDRequirement(
                article="Art. 9º",
                description="Informações claras sobre tratamento",
                applies_to_categories=[LGPDDataCategory.PERSONAL_DATA, LGPDDataCategory.SENSITIVE_DATA],
                mandatory=True,
                penalty_risk="medium"
            ),
            LGPDRequirement(
                article="Art. 15º",
                description="Término do tratamento de dados",
                applies_to_categories=[LGPDDataCategory.PERSONAL_DATA, LGPDDataCategory.SENSITIVE_DATA],
                mandatory=True,
                penalty_risk="medium"
            ),
            LGPDRequirement(
                article="Art. 46º",
                description="Medidas de segurança técnicas e administrativas",
                applies_to_categories=[LGPDDataCategory.PERSONAL_DATA, LGPDDataCategory.SENSITIVE_DATA],
                mandatory=True,
                penalty_risk="high"
            )
        ]

