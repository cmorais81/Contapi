# Autor: carlos.morais@f1rst.com.br
"""
Contract Domain Events
Events raised by the Contract aggregate
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Dict, Any, List
from uuid import UUID


@dataclass(frozen=True)
class DomainEvent:
    """Base domain event"""
    event_id: UUID
    occurred_at: datetime
    event_version: str = "1.0"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert event to dictionary"""
        return {
            "event_id": str(self.event_id),
            "event_type": self.__class__.__name__,
            "event_version": self.event_version,
            "occurred_at": self.occurred_at.isoformat(),
            "data": self._get_event_data()
        }
    
    def _get_event_data(self) -> Dict[str, Any]:
        """Get event-specific data"""
        data = {}
        for key, value in self.__dict__.items():
            if key not in ['event_id', 'occurred_at', 'event_version']:
                if isinstance(value, UUID):
                    data[key] = str(value)
                elif isinstance(value, datetime):
                    data[key] = value.isoformat()
                else:
                    data[key] = value
        return data


@dataclass(frozen=True)
class ContractCreated:
    """Event raised when a contract is created"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    title: str
    owner_id: UUID
    dataset_id: UUID
    created_by: UUID
    event_version: str = "1.0"


@dataclass(frozen=True)
class ContractUpdated(DomainEvent):
    """Event raised when a contract is updated"""
    contract_id: UUID
    updated_fields: List[str]
    old_values: Dict[str, Any]
    new_values: Dict[str, Any]
    updated_by: UUID
    occurred_at: datetime


@dataclass(frozen=True)
class ContractApprovalRequested(DomainEvent):
    """Event raised when contract approval is requested"""
    contract_id: UUID
    approver_id: UUID
    requested_by: UUID
    occurred_at: datetime


@dataclass(frozen=True)
class ContractApproved(DomainEvent):
    """Event raised when a contract is approved"""
    contract_id: UUID
    approved_by: UUID
    comments: Optional[str]
    occurred_at: datetime


@dataclass(frozen=True)
class ContractRejected(DomainEvent):
    """Event raised when a contract is rejected"""
    contract_id: UUID
    rejected_by: UUID
    reason: str
    occurred_at: datetime


@dataclass(frozen=True)
class ContractActivated(DomainEvent):
    """Event raised when a contract is activated"""
    contract_id: UUID
    activated_by: UUID
    effective_date: datetime
    occurred_at: datetime


@dataclass(frozen=True)
class ContractSuspended(DomainEvent):
    """Event raised when a contract is suspended"""
    contract_id: UUID
    suspended_by: UUID
    reason: str
    occurred_at: datetime


@dataclass(frozen=True)
class ContractExpired(DomainEvent):
    """Event raised when a contract expires"""
    contract_id: UUID
    expired_at: datetime
    occurred_at: datetime


@dataclass(frozen=True)
class ContractTerminated(DomainEvent):
    """Event raised when a contract is terminated"""
    contract_id: UUID
    terminated_by: UUID
    reason: str
    occurred_at: datetime


@dataclass(frozen=True)
class SchemaValidationFailed(DomainEvent):
    """Event raised when schema validation fails"""
    contract_id: UUID
    validation_errors: List[str]
    schema_hash: str
    occurred_at: datetime


@dataclass(frozen=True)
class PIIDetected(DomainEvent):
    """Event raised when PII is detected in contract schema"""
    contract_id: UUID
    field_name: str
    pii_type: str
    confidence_score: float
    detection_method: str
    occurred_at: datetime


@dataclass(frozen=True)
class MaskingRuleApplied(DomainEvent):
    """Event raised when masking rule is applied"""
    contract_id: UUID
    field_name: str
    masking_strategy: str
    rule_id: UUID
    applied_by: UUID
    occurred_at: datetime


@dataclass(frozen=True)
class ComplianceAssessmentCompleted(DomainEvent):
    """Event raised when compliance assessment is completed"""
    contract_id: UUID
    framework: str
    score: float
    status: str
    assessed_by: UUID
    occurred_at: datetime


@dataclass(frozen=True)
class QualityMetricCalculated(DomainEvent):
    """Event raised when quality metric is calculated"""
    contract_id: UUID
    metric_type: str
    score: float
    measurement_period: str
    occurred_at: datetime

