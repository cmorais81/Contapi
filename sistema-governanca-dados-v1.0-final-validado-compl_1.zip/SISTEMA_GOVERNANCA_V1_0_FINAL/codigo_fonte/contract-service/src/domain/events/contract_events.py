# Autor: carlos.morais@f1rst.com.br
"""
Contract Domain Events
Events raised by the Contract aggregate
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Dict, Any, List
from uuid import UUID


@dataclass(frozen=True)
class ContractCreated:
    """Event raised when a contract is created"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    title: str
    owner_id: UUID
    dataset_id: UUID
    created_by: UUID
    event_version: str = "1.0"


@dataclass(frozen=True)
class ContractUpdated:
    """Event raised when a contract is updated"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    updated_fields: List[str]
    old_values: Dict[str, Any]
    new_values: Dict[str, Any]
    updated_by: UUID
    event_version: str = "1.0"


@dataclass(frozen=True)
class ContractApprovalRequested:
    """Event raised when contract approval is requested"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    requested_by: UUID
    approval_level: int
    event_version: str = "1.0"


@dataclass(frozen=True)
class ContractApproved:
    """Event raised when a contract is approved"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    approved_by: UUID
    approval_level: int
    event_version: str = "1.0"


@dataclass(frozen=True)
class ContractRejected:
    """Event raised when a contract is rejected"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    rejected_by: UUID
    rejection_reason: str
    event_version: str = "1.0"


@dataclass(frozen=True)
class ContractActivated:
    """Event raised when a contract is activated"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    activated_by: UUID
    event_version: str = "1.0"


@dataclass(frozen=True)
class ContractDeactivated:
    """Event raised when a contract is deactivated"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    deactivated_by: UUID
    deactivation_reason: str
    event_version: str = "1.0"


@dataclass(frozen=True)
class ContractExpired:
    """Event raised when a contract expires"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    expiry_date: datetime
    event_version: str = "1.0"


@dataclass(frozen=True)
class PIIDetected:
    """Event raised when PII is detected in contract data"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    pii_fields: List[str]
    confidence_scores: Dict[str, float]
    detection_method: str
    event_version: str = "1.0"


@dataclass(frozen=True)
class SchemaValidated:
    """Event raised when contract schema is validated"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    schema_hash: str
    validation_result: bool
    validation_errors: List[str]
    event_version: str = "1.0"


@dataclass(frozen=True)
class ContractDeleted:
    """Event raised when a contract is deleted"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    deleted_by: UUID
    deletion_reason: str
    event_version: str = "1.0"


@dataclass(frozen=True)
class LGPDComplianceAssessed:
    """Event raised when LGPD compliance is assessed"""
    event_id: UUID
    occurred_at: datetime
    contract_id: UUID
    compliance_score: float
    compliance_issues: List[str]
    assessment_method: str
    event_version: str = "1.0"

