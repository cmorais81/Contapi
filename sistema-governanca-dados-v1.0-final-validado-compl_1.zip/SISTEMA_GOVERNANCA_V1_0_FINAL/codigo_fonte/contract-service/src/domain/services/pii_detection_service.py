# Autor: carlos.morais@f1rst.com.br
"""
PII Detection Service
Domain service for detecting personally identifiable information
"""

import re
from dataclasses import dataclass
from typing import List, Dict, Any, Optional, Tuple
from enum import Enum


class PIIType(Enum):
    """Types of PII that can be detected"""
    EML_ADDRESS = "email_address"
    PHONE_NUMBER = "phone_number"
    CPF = "cpf"
    CNPJ = "cnpj"
    RG = "rg"
    PASSPORT_NUMBER = "passport_number"
    CREDIT_CARD = "credit_card"
    BANK_ACCOUNT = "bank_account"
    IP_ADDRESS = "ip_address"
    FULL_NAME = "full_name"
    DATE_OF_BIRTH = "date_of_birth"
    ADDRESS = "address"
    BIOMETRIC_DATA = "biometric_data"
    HEALTH_RECORD = "health_record"
    FINANCL_DATA = "financial_data"
    CUSTOM = "custom"


class PIICategory(Enum):
    """Categories of PII"""
    PERSONAL_IDENTIFIER = "personal_identifier"
    CONTACT_INFORMATION = "contact_information"
    FINANCL_INFORMATION = "financial_information"
    HEALTH_INFORMATION = "health_information"
    BIOMETRIC_INFORMATION = "biometric_information"
    LOCATION_DATA = "location_data"
    BEHAVIORAL_DATA = "behavioral_data"
    DEMOGRAPHIC_DATA = "demographic_data"
    PROFESSIONAL_INFORMATION = "professional_information"
    SENSITIVE_PERSONAL_DATA = "sensitive_personal_data"


class PIISensitivityLevel(Enum):
    """Sensitivity levels for PII"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class PIIDetectionResult:
    """Result of PII detection"""
    field_name: str
    field_path: str
    pii_type: PIIType
    pii_category: PIICategory
    sensitivity_level: PIISensitivityLevel
    confidence_score: float
    detection_method: str
    sample_values: List[str]
    pattern_matched: Optional[str] = None
    
    def requires_masking(self) -> bool:
        """Check if this PII requires masking"""
        return self.sensitivity_level in [PIISensitivityLevel.HIGH, PIISensitivityLevel.CRITICAL]
    
    def get_regulatory_requirements(self) -> List[str]:
        """Get applicable regulatory requirements"""
        requirements = []
        
        if self.pii_category in [PIICategory.PERSONAL_IDENTIFIER, PIICategory.CONTACT_INFORMATION]:
            requirements.extend(["LGPD", "GDPR"])
        
        if self.pii_category == PIICategory.HEALTH_INFORMATION:
            requirements.extend(["LGPD", "GDPR", "HIPAA"])
        
        if self.pii_category == PIICategory.FINANCL_INFORMATION:
            requirements.extend(["LGPD", "GDPR", "PCI_DSS"])
        
        if self.sensitivity_level == PIISensitivityLevel.CRITICAL:
            requirements.append("SOX")
        
        return list(set(requirements))


@dataclass
class PIIDetectionRule:
    """Rule for detecting PII"""
    name: str
    pii_type: PIIType
    pii_category: PIICategory
    sensitivity_level: PIISensitivityLevel
    field_name_patterns: List[str]
    value_patterns: List[str]
    field_types: List[str]
    confidence_base: float
    
    def matches_field_name(self, field_name: str) -> bool:
        """Check if field name matches any pattern"""
        for pattern in self.field_name_patterns:
            if re.search(pattern, field_name, re.IGNORECASE):
                return True
        return False
    
    def matches_value(self, value: str) -> bool:
        """Check if value matches any pattern"""
        for pattern in self.value_patterns:
            if re.search(pattern, value):
                return True
        return False
    
    def calculate_confidence(self, field_name: str, sample_values: List[str]) -> float:
        """Calculate confidence score"""
        confidence = 0.0
        
        # Field name match
        if self.matches_field_name(field_name):
            confidence += self.confidence_base * 0.6
        
        # Value pattern matches
        if sample_values:
            matching_values = sum(1 for value in sample_values if self.matches_value(value))
            value_confidence = (matching_values / len(sample_values)) * self.confidence_base * 0.4
            confidence += value_confidence
        
        return min(confidence, 1.0)


class PIIDetectionService:
    """Service for detecting PII in data schemas and samples"""
    
    def __init__(self):
        self.detection_rules = self._initialize_detection_rules()
    
    def detect_pii_in_schema(self, schema_definition: Dict[str, Any], sample_data: Optional[Dict[str, List[str]]] = None) -> List[PIIDetectionResult]:
        """Detect PII in schema definition"""
        results = []
        
        fields = schema_definition.get('fields', [])
        for field in fields:
            field_name = field.get('name', '')
            field_type = field.get('type', '')
            field_path = f"$.{field_name}"
            
            # Get sample values for this field
            sample_values = sample_data.get(field_name, []) if sample_data else []
            
            # Apply detection rules
            for rule in self.detection_rules:
                if field_type in rule.field_types or not rule.field_types:
                    confidence = rule.calculate_confidence(field_name, sample_values)
                    
                    if confidence > 0.5:  # Threshold for detection
                        result = PIIDetectionResult(
                            field_name=field_name,
                            field_path=field_path,
                            pii_type=rule.pii_type,
                            pii_category=rule.pii_category,
                            sensitivity_level=rule.sensitivity_level,
                            confidence_score=confidence,
                            detection_method="pattern_matching",
                            sample_values=sample_values[:5],  # Limit sample size
                            pattern_matched=rule.name
                        )
                        results.append(result)
                        break  # Use first matching rule
        
        return results
    
    def detect_pii_in_field(self, field_name: str, field_type: str, sample_values: List[str]) -> Optional[PIIDetectionResult]:
        """Detect PII in a specific field"""
        for rule in self.detection_rules:
            if field_type in rule.field_types or not rule.field_types:
                confidence = rule.calculate_confidence(field_name, sample_values)
                
                if confidence > 0.5:
                    return PIIDetectionResult(
                        field_name=field_name,
                        field_path=f"$.{field_name}",
                        pii_type=rule.pii_type,
                        pii_category=rule.pii_category,
                        sensitivity_level=rule.sensitivity_level,
                        confidence_score=confidence,
                        detection_method="pattern_matching",
                        sample_values=sample_values[:5],
                        pattern_matched=rule.name
                    )
        
        return None
    
    def validate_pii_classification(self, field_name: str, pii_type: PIIType, sample_values: List[str]) -> bool:
        """Validate manual PII classification"""
        for rule in self.detection_rules:
            if rule.pii_type == pii_type:
                confidence = rule.calculate_confidence(field_name, sample_values)
                return confidence > 0.3  # Lower threshold for validation
        
        return False
    
    def get_masking_recommendations(self, pii_results: List[PIIDetectionResult]) -> Dict[str, str]:
        """Get masking strategy recommendations for detected PII"""
        recommendations = {}
        
        for result in pii_results:
            if result.pii_type == PIIType.EML_ADDRESS:
                recommendations[result.field_name] = "partial_mask"
            elif result.pii_type in [PIIType.CPF, PIIType.CNPJ, PIIType.RG]:
                recommendations[result.field_name] = "hash"
            elif result.pii_type == PIIType.PHONE_NUMBER:
                recommendations[result.field_name] = "partial_mask"
            elif result.pii_type == PIIType.CREDIT_CARD:
                recommendations[result.field_name] = "tokenize"
            elif result.pii_type == PIIType.FULL_NAME:
                recommendations[result.field_name] = "synthetic"
            elif result.sensitivity_level == PIISensitivityLevel.CRITICAL:
                recommendations[result.field_name] = "encrypt"
            else:
                recommendations[result.field_name] = "partial_mask"
        
        return recommendations
    
    def _initialize_detection_rules(self) -> List[PIIDetectionRule]:
        """Initialize PII detection rules"""
        return [
            # Email addresses
            PIIDetectionRule(
                name="email_detection",
                pii_type=PIIType.EML_ADDRESS,
                pii_category=PIICategory.CONTACT_INFORMATION,
                sensitivity_level=PIISensitivityLevel.MEDIUM,
                field_name_patterns=[r"email", r"e_mail", r"mail", r"correio"],
                value_patterns=[r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"],
                field_types=["string", "text", "varchar"],
                confidence_base=0.9
            ),
            
            # Phone numbers
            PIIDetectionRule(
                name="phone_detection",
                pii_type=PIIType.PHONE_NUMBER,
                pii_category=PIICategory.CONTACT_INFORMATION,
                sensitivity_level=PIISensitivityLevel.MEDIUM,
                field_name_patterns=[r"phone", r"telefone", r"celular", r"fone", r"tel"],
                value_patterns=[r"\+?55\s?\(?[1-9]{2}\)?\s?[0-9]{4,5}-?[0-9]{4}", r"\([0-9]{2}\)\s?[0-9]{4,5}-?[0-9]{4}"],
                field_types=["string", "text", "varchar"],
                confidence_base=0.9
            ),
            
            # CPF
            PIIDetectionRule(
                name="cpf_detection",
                pii_type=PIIType.CPF,
                pii_category=PIICategory.PERSONAL_IDENTIFIER,
                sensitivity_level=PIISensitivityLevel.HIGH,
                field_name_patterns=[r"cpf", r"documento", r"doc_pessoa"],
                value_patterns=[r"[0-9]{3}\.?[0-9]{3}\.?[0-9]{3}-?[0-9]{2}"],
                field_types=["string", "text", "varchar"],
                confidence_base=0.95
            ),
            
            # CNPJ
            PIIDetectionRule(
                name="cnpj_detection",
                pii_type=PIIType.CNPJ,
                pii_category=PIICategory.PERSONAL_IDENTIFIER,
                sensitivity_level=PIISensitivityLevel.HIGH,
                field_name_patterns=[r"cnpj", r"doc_empresa", r"empresa_doc"],
                value_patterns=[r"[0-9]{2}\.?[0-9]{3}\.?[0-9]{3}/?[0-9]{4}-?[0-9]{2}"],
                field_types=["string", "text", "varchar"],
                confidence_base=0.95
            ),
            
            # Full names
            PIIDetectionRule(
                name="name_detection",
                pii_type=PIIType.FULL_NAME,
                pii_category=PIICategory.PERSONAL_IDENTIFIER,
                sensitivity_level=PIISensitivityLevel.MEDIUM,
                field_name_patterns=[r"name", r"nome", r"full_name", r"nome_completo", r"customer_name"],
                value_patterns=[r"[A-Z][a-z]+\s+[A-Z][a-z]+"],
                field_types=["string", "text", "varchar"],
                confidence_base=0.8
            ),
            
            # Addresses
            PIIDetectionRule(
                name="address_detection",
                pii_type=PIIType.ADDRESS,
                pii_category=PIICategory.LOCATION_DATA,
                sensitivity_level=PIISensitivityLevel.MEDIUM,
                field_name_patterns=[r"address", r"endereco", r"street", r"rua", r"logradouro"],
                value_patterns=[r"(rua|av|avenida|travessa|alameda)"],
                field_types=["string", "text", "varchar"],
                confidence_base=0.8
            ),
            
            # Date of birth
            PIIDetectionRule(
                name="birth_date_detection",
                pii_type=PIIType.DATE_OF_BIRTH,
                pii_category=PIICategory.DEMOGRAPHIC_DATA,
                sensitivity_level=PIISensitivityLevel.HIGH,
                field_name_patterns=[r"birth", r"nascimento", r"data_nasc", r"birthday", r"age", r"idade"],
                value_patterns=[r"[0-9]{1,2}/[0-9]{1,2}/[0-9]{4}", r"[0-9]{4}-[0-9]{2}-[0-9]{2}"],
                field_types=["string", "text", "varchar", "date", "datetime"],
                confidence_base=0.9
            ),
            
            # Financial data
            PIIDetectionRule(
                name="financial_detection",
                pii_type=PIIType.FINANCL_DATA,
                pii_category=PIICategory.FINANCL_INFORMATION,
                sensitivity_level=PIISensitivityLevel.HIGH,
                field_name_patterns=[r"salary", r"salario", r"income", r"renda", r"revenue", r"receita"],
                value_patterns=[],
                field_types=["decimal", "float", "number", "money"],
                confidence_base=0.8
            ),
            
            # IP addresses
            PIIDetectionRule(
                name="ip_detection",
                pii_type=PIIType.IP_ADDRESS,
                pii_category=PIICategory.BEHAVIORAL_DATA,
                sensitivity_level=PIISensitivityLevel.LOW,
                field_name_patterns=[r"ip", r"ip_address", r"endereco_ip"],
                value_patterns=[r"[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}"],
                field_types=["string", "text", "varchar"],
                confidence_base=0.95
            )
        ]

