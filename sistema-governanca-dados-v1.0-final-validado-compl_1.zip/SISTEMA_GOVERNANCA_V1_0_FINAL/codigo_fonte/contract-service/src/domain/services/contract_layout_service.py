# Autor: carlos.morais@f1rst.com.br
"""
Serviço de Layout de Contratos de Dados
"""

from datetime import datetime
from typing import List, Dict, Any, Optional, Set, Tuple
from uuid import UUID
import json
import hashlib

from ..entities.contract import Contract
from ..value_objects.data_classification import DataClassification


class LayoutValidationResult:
    """Resultado da validação de layout"""
    
    def __init__(self):
        self.is_valid = True
        self.errors = []
        self.warnings = []
        self.suggestions = []
        self.layout_hash = None
        self.compatibility_score = 0.0
    
    def add_error(self, message: str, field: str = None, code: str = None):
        """Adiciona um erro"""
        self.is_valid = False
        self.errors.append({
            "message": message,
            "field": field,
            "code": code,
            "timestamp": datetime.utcnow().isoformat()
        })
    
    def add_warning(self, message: str, field: str = None, code: str = None):
        """Adiciona um aviso"""
        self.warnings.append({
            "message": message,
            "field": field,
            "code": code,
            "timestamp": datetime.utcnow().isoformat()
        })
    
    def add_suggestion(self, message: str, field: str = None, action: str = None):
        """Adiciona uma sugestão"""
        self.suggestions.append({
            "message": message,
            "field": field,
            "action": action,
            "timestamp": datetime.utcnow().isoformat()
        })
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            "is_valid": self.is_valid,
            "errors": self.errors,
            "warnings": self.warnings,
            "suggestions": self.suggestions,
            "layout_hash": self.layout_hash,
            "compatibility_score": self.compatibility_score,
            "validation_timestamp": datetime.utcnow().isoformat()
        }


class ContractLayoutService:
    """
    Serviço de domínio para gerenciar layouts de contratos
    
    Responsabilidades:
    - Validar estrutura de layouts
    - Verificar compatibilidade entre versões
    - Detectar mudanças breaking
    - Sugerir otimizações de layout
    - Gerenciar evolução de schemas
    """
    
    def __init__(self):
        """Inicializa o serviço de layout"""
        self._supported_types = {
            'string', 'integer', 'float', 'boolean', 'date', 
            'datetime', 'timestamp', 'decimal', 'json', 'array'
        }
        
        self._type_compatibility = {
            'string': {'string'},
            'integer': {'integer', 'float', 'decimal'},
            'float': {'float', 'decimal'},
            'boolean': {'boolean', 'string'},
            'date': {'date', 'string'},
            'datetime': {'datetime', 'timestamp', 'string'},
            'timestamp': {'timestamp', 'datetime', 'string'},
            'decimal': {'decimal', 'float'},
            'json': {'json', 'string'},
            'array': {'array', 'string'}
        }
    
    def validate_layout(self, contract: Contract) -> LayoutValidationResult:
        """
        Valida o layout de um contrato
        
        Args:
            contract: Contrato a ser validado
            
        Returns:
            LayoutValidationResult: Resultado da validação
        """
        result = LayoutValidationResult()
        
        if not contract.schema_definition:
            result.add_error("Schema definition é obrigatório", "schema_definition", "MISSING_SCHEMA")
            return result
        
        schema = contract.schema_definition
        
        # Validar estrutura básica
        self._validate_basic_structure(schema, result)
        
        # Validar campos
        self._validate_fields(schema, result)
        
        # Validar chave primária
        self._validate_primary_key_layout(schema, result)
        
        # Validar índices
        self._validate_indexes(schema, result)
        
        # Validar particionamento
        self._validate_partitioning(schema, result)
        
        # Calcular hash do layout
        result.layout_hash = self._calculate_layout_hash(schema)
        
        # Sugerir otimizações
        self._suggest_optimizations(schema, result)
        
        return result
    
    def check_compatibility(self, old_contract: Contract, new_contract: Contract) -> LayoutValidationResult:
        """
        Verifica compatibilidade entre duas versões de contrato
        
        Args:
            old_contract: Versão anterior do contrato
            new_contract: Nova versão do contrato
            
        Returns:
            LayoutValidationResult: Resultado da verificação de compatibilidade
        """
        result = LayoutValidationResult()
        
        if not old_contract.schema_definition or not new_contract.schema_definition:
            result.add_error("Ambos os contratos devem ter schema definition", code="MISSING_SCHEMAS")
            return result
        
        old_schema = old_contract.schema_definition
        new_schema = new_contract.schema_definition
        
        # Verificar mudanças breaking
        self._check_breaking_changes(old_schema, new_schema, result)
        
        # Verificar mudanças de campos
        self._check_field_changes(old_schema, new_schema, result)
        
        # Verificar mudanças de chave primária
        self._check_primary_key_changes(old_schema, new_schema, result)
        
        # Verificar mudanças de formato
        self._check_format_changes(old_schema, new_schema, result)
        
        # Calcular score de compatibilidade
        result.compatibility_score = self._calculate_compatibility_score(old_schema, new_schema)
        
        return result
    
    def suggest_layout_improvements(self, contract: Contract) -> List[Dict[str, Any]]:
        """
        Sugere melhorias no layout do contrato
        
        Args:
            contract: Contrato a ser analisado
            
        Returns:
            List[Dict]: Lista de sugestões de melhoria
        """
        suggestions = []
        
        if not contract.schema_definition:
            return suggestions
        
        schema = contract.schema_definition
        fields = schema.get('fields', [])
        
        # Sugerir índices
        suggestions.extend(self._suggest_indexes(fields))
        
        # Sugerir particionamento
        suggestions.extend(self._suggest_partitioning(fields))
        
        # Sugerir otimizações de tipo
        suggestions.extend(self._suggest_type_optimizations(fields))
        
        # Sugerir normalização
        suggestions.extend(self._suggest_normalization(fields))
        
        return suggestions
    
    def _validate_basic_structure(self, schema: Dict[str, Any], result: LayoutValidationResult):
        """Valida estrutura básica do schema"""
        required_keys = {'fields', 'format'}
        
        for key in required_keys:
            if key not in schema:
                result.add_error(f"Campo '{key}' é obrigatório no schema", key, f"MISSING_{key.upper()}")
        
        # Validar formato
        if 'format' in schema:
            format_type = schema['format']
            valid_formats = {'json', 'avro', 'parquet', 'csv', 'xml', 'protobuf'}
            
            if format_type not in valid_formats:
                result.add_error(
                    f"Formato '{format_type}' não é suportado", 
                    "format", 
                    "UNSUPPORTED_FORMAT"
                )
    
    def _validate_fields(self, schema: Dict[str, Any], result: LayoutValidationResult):
        """Valida campos do schema"""
        fields = schema.get('fields', [])
        
        if not fields:
            result.add_error("Schema deve ter pelo menos um campo", "fields", "NO_FIELDS")
            return
        
        field_names = set()
        
        for i, field in enumerate(fields):
            field_name = field.get('name', f'field_{i}')
            
            # Verificar nome único
            if field_name in field_names:
                result.add_error(f"Campo '{field_name}' está duplicado", f"fields[{i}].name", "DUPLICATE_FIELD")
            else:
                field_names.add(field_name)
            
            # Validar tipo
            field_type = field.get('type')
            if field_type not in self._supported_types:
                result.add_error(
                    f"Tipo '{field_type}' não é suportado para campo '{field_name}'",
                    f"fields[{i}].type",
                    "UNSUPPORTED_TYPE"
                )
            
            # Validar constraints
            self._validate_field_constraints(field, i, result)
            
            # Verificar performance
            self._check_field_performance(field, i, result)
    
    def _validate_field_constraints(self, field: Dict[str, Any], index: int, result: LayoutValidationResult):
        """Valida constraints de campo"""
        constraints = field.get('constraints', {})
        field_name = field.get('name', f'field_{index}')
        field_type = field.get('type')
        
        # Max length para strings
        if field_type == 'string' and 'max_length' in constraints:
            max_length = constraints['max_length']
            if not isinstance(max_length, int) or max_length <= 0:
                result.add_error(
                    f"max_length deve ser um inteiro positivo para campo '{field_name}'",
                    f"fields[{index}].constraints.max_length",
                    "INVALID_MAX_LENGTH"
                )
            elif max_length > 65535:
                result.add_warning(
                    f"max_length muito alto ({max_length}) para campo '{field_name}' pode impactar performance",
                    f"fields[{index}].constraints.max_length",
                    "HIGH_MAX_LENGTH"
                )
        
        # Precision para decimais
        if field_type == 'decimal' and 'precision' in constraints:
            precision = constraints['precision']
            if not isinstance(precision, int) or precision <= 0:
                result.add_error(
                    f"precision deve ser um inteiro positivo para campo '{field_name}'",
                    f"fields[{index}].constraints.precision",
                    "INVALID_PRECISION"
                )
        
        # Scale para decimais
        if field_type == 'decimal' and 'scale' in constraints:
            scale = constraints['scale']
            precision = constraints.get('precision', 0)
            if not isinstance(scale, int) or scale < 0:
                result.add_error(
                    f"scale deve ser um inteiro não-negativo para campo '{field_name}'",
                    f"fields[{index}].constraints.scale",
                    "INVALID_SCALE"
                )
            elif scale > precision:
                result.add_error(
                    f"scale ({scale}) não pode ser maior que precision ({precision}) para campo '{field_name}'",
                    f"fields[{index}].constraints.scale",
                    "SCALE_GREATER_THAN_PRECISION"
                )
    
    def _validate_primary_key_layout(self, schema: Dict[str, Any], result: LayoutValidationResult):
        """Valida chave primária do layout"""
        if 'primary_key' not in schema:
            result.add_warning("Schema sem chave primária pode impactar performance", "primary_key", "NO_PRIMARY_KEY")
            return
        
        primary_key = schema['primary_key']
        fields = schema.get('fields', [])
        field_names = {field.get('name') for field in fields}
        
        if isinstance(primary_key, str):
            if primary_key not in field_names:
                result.add_error(
                    f"Campo da chave primária '{primary_key}' não existe",
                    "primary_key",
                    "PRIMARY_KEY_FIELD_NOT_FOUND"
                )
        elif isinstance(primary_key, list):
            if len(primary_key) > 5:
                result.add_warning(
                    f"Chave primária composta com {len(primary_key)} campos pode impactar performance",
                    "primary_key",
                    "COMPLEX_PRIMARY_KEY"
                )
            
            for pk_field in primary_key:
                if pk_field not in field_names:
                    result.add_error(
                        f"Campo da chave primária '{pk_field}' não existe",
                        "primary_key",
                        "PRIMARY_KEY_FIELD_NOT_FOUND"
                    )
    
    def _validate_indexes(self, schema: Dict[str, Any], result: LayoutValidationResult):
        """Valida índices do schema"""
        indexes = schema.get('indexes', [])
        fields = schema.get('fields', [])
        field_names = {field.get('name') for field in fields}
        
        for i, index in enumerate(indexes):
            index_fields = index.get('fields', [])
            
            if not index_fields:
                result.add_error(f"Índice {i} deve ter pelo menos um campo", f"indexes[{i}].fields", "EMPTY_INDEX")
                continue
            
            # Verificar se campos existem
            for field_name in index_fields:
                if field_name not in field_names:
                    result.add_error(
                        f"Campo '{field_name}' do índice {i} não existe",
                        f"indexes[{i}].fields",
                        "INDEX_FIELD_NOT_FOUND"
                    )
            
            # Verificar performance do índice
            if len(index_fields) > 10:
                result.add_warning(
                    f"Índice {i} com {len(index_fields)} campos pode impactar performance",
                    f"indexes[{i}].fields",
                    "COMPLEX_INDEX"
                )
    
    def _validate_partitioning(self, schema: Dict[str, Any], result: LayoutValidationResult):
        """Valida particionamento do schema"""
        partitioning = schema.get('partitioning')
        
        if not partitioning:
            return
        
        partition_type = partitioning.get('type')
        partition_fields = partitioning.get('fields', [])
        
        valid_partition_types = {'range', 'hash', 'list'}
        
        if partition_type not in valid_partition_types:
            result.add_error(
                f"Tipo de particionamento '{partition_type}' não é suportado",
                "partitioning.type",
                "UNSUPPORTED_PARTITION_TYPE"
            )
        
        if not partition_fields:
            result.add_error(
                "Particionamento deve especificar pelo menos um campo",
                "partitioning.fields",
                "NO_PARTITION_FIELDS"
            )
        
        # Verificar se campos de particionamento existem
        fields = schema.get('fields', [])
        field_names = {field.get('name') for field in fields}
        
        for field_name in partition_fields:
            if field_name not in field_names:
                result.add_error(
                    f"Campo de particionamento '{field_name}' não existe",
                    "partitioning.fields",
                    "PARTITION_FIELD_NOT_FOUND"
                )
    
    def _check_breaking_changes(self, old_schema: Dict[str, Any], new_schema: Dict[str, Any], result: LayoutValidationResult):
        """Verifica mudanças breaking entre schemas"""
        old_fields = {field.get('name'): field for field in old_schema.get('fields', [])}
        new_fields = {field.get('name'): field for field in new_schema.get('fields', [])}
        
        # Campos removidos
        removed_fields = set(old_fields.keys()) - set(new_fields.keys())
        for field_name in removed_fields:
            result.add_error(
                f"Campo '{field_name}' foi removido (breaking change)",
                f"fields.{field_name}",
                "FIELD_REMOVED"
            )
        
        # Mudanças de tipo incompatíveis
        for field_name in set(old_fields.keys()) & set(new_fields.keys()):
            old_field = old_fields[field_name]
            new_field = new_fields[field_name]
            
            old_type = old_field.get('type')
            new_type = new_field.get('type')
            
            if old_type != new_type:
                if not self._is_type_compatible(old_type, new_type):
                    result.add_error(
                        f"Mudança de tipo incompatível para campo '{field_name}': {old_type} -> {new_type}",
                        f"fields.{field_name}.type",
                        "INCOMPATIBLE_TYPE_CHANGE"
                    )
        
        # Mudanças na chave primária
        old_pk = old_schema.get('primary_key')
        new_pk = new_schema.get('primary_key')
        
        if old_pk != new_pk:
            result.add_error(
                "Mudança na chave primária é uma breaking change",
                "primary_key",
                "PRIMARY_KEY_CHANGED"
            )
    
    def _check_field_changes(self, old_schema: Dict[str, Any], new_schema: Dict[str, Any], result: LayoutValidationResult):
        """Verifica mudanças em campos"""
        old_fields = {field.get('name'): field for field in old_schema.get('fields', [])}
        new_fields = {field.get('name'): field for field in new_schema.get('fields', [])}
        
        # Novos campos
        new_field_names = set(new_fields.keys()) - set(old_fields.keys())
        for field_name in new_field_names:
            new_field = new_fields[field_name]
            constraints = new_field.get('constraints', {})
            
            if not constraints.get('nullable', True):
                result.add_warning(
                    f"Novo campo obrigatório '{field_name}' pode causar problemas de compatibilidade",
                    f"fields.{field_name}",
                    "NEW_REQUIRED_FIELD"
                )
        
        # Mudanças em constraints
        for field_name in set(old_fields.keys()) & set(new_fields.keys()):
            old_field = old_fields[field_name]
            new_field = new_fields[field_name]
            
            old_constraints = old_field.get('constraints', {})
            new_constraints = new_field.get('constraints', {})
            
            # Nullable -> Not nullable
            if old_constraints.get('nullable', True) and not new_constraints.get('nullable', True):
                result.add_warning(
                    f"Campo '{field_name}' mudou de nullable para not nullable",
                    f"fields.{field_name}.constraints.nullable",
                    "NULLABLE_TO_NOT_NULL"
                )
            
            # Redução de max_length
            old_max_length = old_constraints.get('max_length')
            new_max_length = new_constraints.get('max_length')
            
            if old_max_length and new_max_length and new_max_length < old_max_length:
                result.add_warning(
                    f"Redução de max_length para campo '{field_name}': {old_max_length} -> {new_max_length}",
                    f"fields.{field_name}.constraints.max_length",
                    "MAX_LENGTH_REDUCED"
                )
    
    def _check_primary_key_changes(self, old_schema: Dict[str, Any], new_schema: Dict[str, Any], result: LayoutValidationResult):
        """Verifica mudanças na chave primária"""
        old_pk = old_schema.get('primary_key')
        new_pk = new_schema.get('primary_key')
        
        if old_pk and not new_pk:
            result.add_error(
                "Remoção da chave primária é uma breaking change",
                "primary_key",
                "PRIMARY_KEY_REMOVED"
            )
        elif not old_pk and new_pk:
            result.add_warning(
                "Adição de chave primária pode impactar dados existentes",
                "primary_key",
                "PRIMARY_KEY_ADDED"
            )
    
    def _check_format_changes(self, old_schema: Dict[str, Any], new_schema: Dict[str, Any], result: LayoutValidationResult):
        """Verifica mudanças de formato"""
        old_format = old_schema.get('format')
        new_format = new_schema.get('format')
        
        if old_format != new_format:
            result.add_warning(
                f"Mudança de formato: {old_format} -> {new_format}",
                "format",
                "FORMAT_CHANGED"
            )
    
    def _calculate_layout_hash(self, schema: Dict[str, Any]) -> str:
        """Calcula hash do layout"""
        # Criar representação determinística do schema
        schema_str = json.dumps(schema, sort_keys=True, separators=(',', ':'))
        return hashlib.sha256(schema_str.encode('utf-8')).hexdigest()
    
    def _calculate_compatibility_score(self, old_schema: Dict[str, Any], new_schema: Dict[str, Any]) -> float:
        """Calcula score de compatibilidade entre schemas"""
        score = 100.0
        
        old_fields = {field.get('name'): field for field in old_schema.get('fields', [])}
        new_fields = {field.get('name'): field for field in new_schema.get('fields', [])}
        
        # Penalizar campos removidos
        removed_fields = len(set(old_fields.keys()) - set(new_fields.keys()))
        score -= removed_fields * 20
        
        # Penalizar mudanças de tipo
        type_changes = 0
        for field_name in set(old_fields.keys()) & set(new_fields.keys()):
            old_type = old_fields[field_name].get('type')
            new_type = new_fields[field_name].get('type')
            
            if old_type != new_type:
                if self._is_type_compatible(old_type, new_type):
                    score -= 5  # Mudança compatível
                else:
                    score -= 15  # Mudança incompatível
        
        # Penalizar mudança de chave primária
        if old_schema.get('primary_key') != new_schema.get('primary_key'):
            score -= 25
        
        return max(0.0, score)
    
    def _is_type_compatible(self, old_type: str, new_type: str) -> bool:
        """Verifica se mudança de tipo é compatível"""
        if old_type == new_type:
            return True
        
        compatible_types = self._type_compatibility.get(old_type, set())
        return new_type in compatible_types
    
    def _check_field_performance(self, field: Dict[str, Any], index: int, result: LayoutValidationResult):
        """Verifica aspectos de performance do campo"""
        field_name = field.get('name', f'field_{index}')
        field_type = field.get('type')
        constraints = field.get('constraints', {})
        
        # Strings muito grandes
        if field_type == 'string':
            max_length = constraints.get('max_length')
            if max_length and max_length > 10000:
                result.add_warning(
                    f"Campo '{field_name}' com max_length muito alto pode impactar performance",
                    f"fields[{index}].constraints.max_length",
                    "HIGH_STRING_LENGTH"
                )
        
        # Arrays sem limite
        if field_type == 'array':
            if 'max_items' not in constraints:
                result.add_suggestion(
                    f"Considere adicionar max_items para campo array '{field_name}'",
                    f"fields[{index}].constraints.max_items",
                    "add_max_items"
                )
    
    def _suggest_optimizations(self, schema: Dict[str, Any], result: LayoutValidationResult):
        """Sugere otimizações para o schema"""
        fields = schema.get('fields', [])
        
        # Sugerir índices para campos únicos
        for field in fields:
            constraints = field.get('constraints', {})
            if constraints.get('unique', False):
                field_name = field.get('name')
                result.add_suggestion(
                    f"Considere criar índice para campo único '{field_name}'",
                    f"indexes",
                    "add_unique_index"
                )
        
        # Sugerir particionamento para schemas grandes
        if len(fields) > 50:
            result.add_suggestion(
                "Schema com muitos campos pode se beneficiar de particionamento",
                "partitioning",
                "add_partitioning"
            )
    
    def _suggest_indexes(self, fields: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Sugere índices baseado nos campos"""
        suggestions = []
        
        for field in fields:
            field_name = field.get('name')
            constraints = field.get('constraints', {})
            
            # Índice para campos únicos
            if constraints.get('unique', False):
                suggestions.append({
                    "type": "index",
                    "message": f"Criar índice único para campo '{field_name}'",
                    "field": field_name,
                    "action": "create_unique_index",
                    "priority": "high"
                })
            
            # Índice para campos frequentemente consultados
            if field_name.endswith('_id') or field_name in ['email', 'username', 'code']:
                suggestions.append({
                    "type": "index",
                    "message": f"Considere criar índice para campo '{field_name}' (frequentemente consultado)",
                    "field": field_name,
                    "action": "create_index",
                    "priority": "medium"
                })
        
        return suggestions
    
    def _suggest_partitioning(self, fields: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Sugere particionamento baseado nos campos"""
        suggestions = []
        
        # Procurar campos de data para particionamento temporal
        date_fields = [field for field in fields if field.get('type') in ['date', 'datetime', 'timestamp']]
        
        for field in date_fields:
            field_name = field.get('name')
            if 'created' in field_name or 'date' in field_name:
                suggestions.append({
                    "type": "partitioning",
                    "message": f"Considere particionamento temporal por '{field_name}'",
                    "field": field_name,
                    "action": "add_temporal_partitioning",
                    "priority": "medium"
                })
        
        return suggestions
    
    def _suggest_type_optimizations(self, fields: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Sugere otimizações de tipo"""
        suggestions = []
        
        for field in fields:
            field_name = field.get('name')
            field_type = field.get('type')
            constraints = field.get('constraints', {})
            
            # String com max_length pequeno pode ser otimizada
            if field_type == 'string':
                max_length = constraints.get('max_length')
                if max_length and max_length <= 10:
                    suggestions.append({
                        "type": "optimization",
                        "message": f"Campo '{field_name}' com max_length pequeno pode usar tipo mais eficiente",
                        "field": field_name,
                        "action": "optimize_string_type",
                        "priority": "low"
                    })
        
        return suggestions
    
    def _suggest_normalization(self, fields: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Sugere normalização do schema"""
        suggestions = []
        
        # Detectar possíveis campos que deveriam ser normalizados
        json_fields = [field for field in fields if field.get('type') == 'json']
        
        for field in json_fields:
            field_name = field.get('name')
            suggestions.append({
                "type": "normalization",
                "message": f"Campo JSON '{field_name}' pode se beneficiar de normalização",
                "field": field_name,
                "action": "normalize_json_field",
                "priority": "low"
            })
        
        return suggestions

