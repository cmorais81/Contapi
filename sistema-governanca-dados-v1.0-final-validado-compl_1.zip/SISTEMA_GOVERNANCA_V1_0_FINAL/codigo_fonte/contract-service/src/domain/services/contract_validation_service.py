"""
Contract Validation Service - Serviço de validação de contratos
Segue Single Responsibility Principle - responsável apenas por validações
"""

import re
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from ..entities.contract import Contract, DataClassification


@dataclass
class ValidationResult:
    """Resultado de uma validação"""
    is_valid: bool
    errors: List[str]
    warnings: List[str]
    
    def add_error(self, message: str) -> None:
        """Adiciona erro de validação"""
        self.errors.append(message)
        self.is_valid = False
    
    def add_warning(self, message: str) -> None:
        """Adiciona aviso de validação"""
        self.warnings.append(message)


class ContractValidationService:
    """
    Serviço de validação de contratos
    Responsabilidade única: validar regras de negócio para contratos
    """
    
    def __init__(self):
        self.email_pattern = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
        self.version_pattern = re.compile(r'^\d+\.\d+\.\d+$')
    
    def validate_contract(self, contract: Contract) -> ValidationResult:
        """
        Valida um contrato completo
        """
        result = ValidationResult(is_valid=True, errors=[], warnings=[])
        
        # Validações obrigatórias
        self._validate_basic_fields(contract, result)
        self._validate_email_format(contract, result)
        self._validate_version_format(contract, result)
        self._validate_classification_rules(contract, result)
        self._validate_schema_definition(contract, result)
        self._validate_compliance_requirements(contract, result)
        
        return result
    
    def _validate_basic_fields(self, contract: Contract, result: ValidationResult) -> None:
        """Valida campos básicos obrigatórios"""
        if not contract.name or not contract.name.strip():
            result.add_error("Nome do contrato é obrigatório")
        elif len(contract.name.strip()) < 3:
            result.add_error("Nome do contrato deve ter pelo menos 3 caracteres")
        elif len(contract.name) > 255:
            result.add_error("Nome do contrato não pode exceder 255 caracteres")
        
        if not contract.owner_email:
            result.add_error("Email do proprietário é obrigatório")
        
        if contract.description and len(contract.description) > 1000:
            result.add_warning("Descrição muito longa, considere resumir")
    
    def _validate_email_format(self, contract: Contract, result: ValidationResult) -> None:
        """Valida formato do email"""
        if contract.owner_email and not self.email_pattern.match(contract.owner_email):
            result.add_error("Formato de email inválido")
    
    def _validate_version_format(self, contract: Contract, result: ValidationResult) -> None:
        """Valida formato da versão"""
        if not self.version_pattern.match(contract.version):
            result.add_error("Versão deve seguir formato semântico (x.y.z)")
    
    def _validate_classification_rules(self, contract: Contract, result: ValidationResult) -> None:
        """Valida regras de classificação de dados"""
        if contract.data_classification == DataClassification.RESTRICTED:
            if not contract.compliance_requirements:
                result.add_warning("Dados restritos devem ter requisitos de compliance")
            
            if contract.has_pii() and 'LGPD' not in (contract.compliance_requirements or []):
                result.add_warning("Dados restritos com PII devem incluir compliance LGPD")
        
        if contract.data_classification == DataClassification.PUBLIC:
            if contract.has_pii():
                result.add_error("Dados públicos não podem conter informações pessoais (PII)")
    
    def _validate_schema_definition(self, contract: Contract, result: ValidationResult) -> None:
        """Valida definição do schema"""
        if contract.schema_definition:
            if not isinstance(contract.schema_definition, dict):
                result.add_error("Definição do schema deve ser um objeto JSON válido")
            
            elif 'fields' not in contract.schema_definition:
                result.add_warning("Schema deveria incluir definição de campos")
            
            else:
                fields = contract.schema_definition.get('fields', [])
                if not isinstance(fields, list):
                    result.add_error("Campos do schema devem ser uma lista")
                elif len(fields) == 0:
                    result.add_warning("Schema não possui campos definidos")
                else:
                    self._validate_schema_fields(fields, result)
    
    def _validate_schema_fields(self, fields: List[Dict[str, Any]], result: ValidationResult) -> None:
        """Valida campos do schema"""
        field_names = set()
        
        for i, field in enumerate(fields):
            if not isinstance(field, dict):
                result.add_error(f"Campo {i} deve ser um objeto")
                continue
            
            # Validar nome do campo
            field_name = field.get('name')
            if not field_name:
                result.add_error(f"Campo {i} deve ter um nome")
            elif field_name in field_names:
                result.add_error(f"Campo '{field_name}' está duplicado")
            else:
                field_names.add(field_name)
            
            # Validar tipo do campo
            if 'type' not in field:
                result.add_error(f"Campo '{field_name}' deve ter um tipo definido")
            
            # Validar campos PII
            if field.get('is_pii', False):
                if not field.get('description'):
                    result.add_warning(f"Campo PII '{field_name}' deveria ter descrição")
    
    def _validate_compliance_requirements(self, contract: Contract, result: ValidationResult) -> None:
        """Valida requisitos de compliance"""
        if contract.compliance_requirements:
            valid_frameworks = {'LGPD', 'GDPR', 'SOX', 'HIPAA', 'PCI-DSS'}
            
            for framework in contract.compliance_requirements:
                if framework not in valid_frameworks:
                    result.add_warning(f"Framework de compliance '{framework}' não é reconhecido")
        
        # Verificar se dados sensíveis têm compliance adequado
        if contract.has_pii():
            if not contract.compliance_requirements or 'LGPD' not in contract.compliance_requirements:
                result.add_warning("Contratos com PII deveriam incluir compliance LGPD")
    
    def validate_for_activation(self, contract: Contract) -> ValidationResult:
        """
        Validação específica para ativação de contrato
        """
        result = self.validate_contract(contract)
        
        # Validações adicionais para ativação
        if not contract.schema_definition:
            result.add_error("Contrato deve ter schema definido para ser ativado")
        
        if contract.has_pii() and not contract.compliance_requirements:
            result.add_error("Contratos com PII devem ter requisitos de compliance para ativação")
        
        if contract.data_classification == DataClassification.RESTRICTED:
            if not contract.sla_requirements:
                result.add_warning("Dados restritos deveriam ter SLA definido")
        
        return result
    
    def validate_schema_compatibility(self, 
                                    old_schema: Optional[Dict[str, Any]], 
                                    new_schema: Dict[str, Any]) -> ValidationResult:
        """
        Valida compatibilidade entre versões de schema
        """
        result = ValidationResult(is_valid=True, errors=[], warnings=[])
        
        if not old_schema:
            return result  # Primeiro schema, sempre válido
        
        old_fields = {f['name']: f for f in old_schema.get('fields', [])}
        new_fields = {f['name']: f for f in new_schema.get('fields', [])}
        
        # Verificar campos removidos
        removed_fields = set(old_fields.keys()) - set(new_fields.keys())
        if removed_fields:
            result.add_error(f"Campos removidos quebram compatibilidade: {', '.join(removed_fields)}")
        
        # Verificar mudanças de tipo
        for field_name in old_fields.keys() & new_fields.keys():
            old_type = old_fields[field_name].get('type')
            new_type = new_fields[field_name].get('type')
            
            if old_type != new_type:
                result.add_warning(f"Campo '{field_name}' mudou de tipo: {old_type} -> {new_type}")
        
        return result

