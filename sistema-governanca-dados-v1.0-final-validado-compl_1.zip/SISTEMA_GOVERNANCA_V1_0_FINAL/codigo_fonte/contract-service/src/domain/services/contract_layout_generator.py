"""
Contract Layout Generator - Gerador de Layouts de Contrato
Sistema de Governança de Dados V5.0

Responsável por:
- Geração automática de layouts em múltiplos formatos
- Templates visuais profissionais
- Exportação para PDF, Word, HTML
- Personalização de marca e estilo
"""

from typing import Dict, List, Any, Optional
from datetime import datetime
import json
import base64
from io import BytesIO


class ContractLayoutGenerator:
    """Gerador de layouts profissionais para contratos"""
    
    def __init__(self):
        self.layout_templates = self._initialize_layout_templates()
        self.style_themes = self._initialize_style_themes()
    
    def _initialize_layout_templates(self) -> Dict[str, Dict[str, Any]]:
        """Inicializa templates de layout"""
        return {
            "professional": {
                "name": "Profissional",
                "description": "Layout corporativo formal",
                "sections": [
                    {"id": "header", "title": "Cabeçalho", "required": True},
                    {"id": "parties", "title": "Partes Envolvidas", "required": True},
                    {"id": "purpose", "title": "Objetivo do Contrato", "required": True},
                    {"id": "data_scope", "title": "Escopo dos Dados", "required": True},
                    {"id": "schema", "title": "Estrutura dos Dados", "required": True},
                    {"id": "sla", "title": "Níveis de Serviço", "required": True},
                    {"id": "compliance", "title": "Conformidade", "required": True},
                    {"id": "responsibilities", "title": "Responsabilidades", "required": True},
                    {"id": "terms", "title": "Termos e Condições", "required": True},
                    {"id": "signatures", "title": "Assinaturas", "required": True}
                ]
            },
            "technical": {
                "name": "Técnico",
                "description": "Layout focado em aspectos técnicos",
                "sections": [
                    {"id": "header", "title": "Cabeçalho", "required": True},
                    {"id": "overview", "title": "Visão Geral", "required": True},
                    {"id": "data_model", "title": "Modelo de Dados", "required": True},
                    {"id": "api_specs", "title": "Especificações da API", "required": False},
                    {"id": "quality_rules", "title": "Regras de Qualidade", "required": True},
                    {"id": "security", "title": "Segurança", "required": True},
                    {"id": "monitoring", "title": "Monitoramento", "required": True},
                    {"id": "integration", "title": "Integração", "required": False},
                    {"id": "appendix", "title": "Anexos Técnicos", "required": False}
                ]
            },
            "executive": {
                "name": "Executivo",
                "description": "Layout resumido para executivos",
                "sections": [
                    {"id": "header", "title": "Cabeçalho", "required": True},
                    {"id": "executive_summary", "title": "Resumo Executivo", "required": True},
                    {"id": "business_value", "title": "Valor de Negócio", "required": True},
                    {"id": "key_metrics", "title": "Métricas Principais", "required": True},
                    {"id": "risks", "title": "Riscos e Mitigações", "required": True},
                    {"id": "timeline", "title": "Cronograma", "required": False},
                    {"id": "approvals", "title": "Aprovações", "required": True}
                ]
            },
            "compliance": {
                "name": "Conformidade",
                "description": "Layout focado em compliance",
                "sections": [
                    {"id": "header", "title": "Cabeçalho", "required": True},
                    {"id": "regulatory_context", "title": "Contexto Regulatório", "required": True},
                    {"id": "data_classification", "title": "Classificação dos Dados", "required": True},
                    {"id": "pii_handling", "title": "Tratamento de PII", "required": True},
                    {"id": "consent_management", "title": "Gestão de Consentimento", "required": True},
                    {"id": "retention_policy", "title": "Política de Retenção", "required": True},
                    {"id": "audit_trail", "title": "Trilha de Auditoria", "required": True},
                    {"id": "incident_response", "title": "Resposta a Incidentes", "required": True},
                    {"id": "compliance_validation", "title": "Validação de Conformidade", "required": True}
                ]
            }
        }
    
    def _initialize_style_themes(self) -> Dict[str, Dict[str, Any]]:
        """Inicializa temas de estilo"""
        return {
            "corporate_blue": {
                "name": "Azul Corporativo",
                "primary_color": "#1E3A8A",
                "secondary_color": "#3B82F6",
                "accent_color": "#60A5FA",
                "text_color": "#1F2937",
                "background_color": "#FFFFFF",
                "font_family": "Arial, sans-serif",
                "header_font_size": "24px",
                "body_font_size": "12px"
            },
            "professional_gray": {
                "name": "Cinza Profissional",
                "primary_color": "#374151",
                "secondary_color": "#6B7280",
                "accent_color": "#9CA3AF",
                "text_color": "#111827",
                "background_color": "#FFFFFF",
                "font_family": "Times New Roman, serif",
                "header_font_size": "22px",
                "body_font_size": "11px"
            },
            "modern_green": {
                "name": "Verde Moderno",
                "primary_color": "#059669",
                "secondary_color": "#10B981",
                "accent_color": "#34D399",
                "text_color": "#064E3B",
                "background_color": "#FFFFFF",
                "font_family": "Helvetica, sans-serif",
                "header_font_size": "26px",
                "body_font_size": "12px"
            }
        }
    
    def get_available_layouts(self) -> List[Dict[str, Any]]:
        """Retorna layouts disponíveis"""
        layouts = []
        for layout_id, layout in self.layout_templates.items():
            layouts.append({
                "id": layout_id,
                "name": layout["name"],
                "description": layout["description"],
                "sections_count": len(layout["sections"])
            })
        return layouts
    
    def get_available_themes(self) -> List[Dict[str, Any]]:
        """Retorna temas de estilo disponíveis"""
        themes = []
        for theme_id, theme in self.style_themes.items():
            themes.append({
                "id": theme_id,
                "name": theme["name"],
                "primary_color": theme["primary_color"],
                "preview": {
                    "primary_color": theme["primary_color"],
                    "secondary_color": theme["secondary_color"],
                    "font_family": theme["font_family"]
                }
            })
        return themes
    
    def generate_html_layout(
        self,
        contract_data: Dict[str, Any],
        layout_id: str = "professional",
        theme_id: str = "corporate_blue",
        custom_branding: Optional[Dict[str, Any]] = None
    ) -> str:
        """Gera layout HTML do contrato"""
        
        layout_template = self.layout_templates.get(layout_id)
        if not layout_template:
            raise ValueError(f"Layout {layout_id} não encontrado")
        
        theme = self.style_themes.get(theme_id)
        if not theme:
            raise ValueError(f"Tema {theme_id} não encontrado")
        
        # Aplicar branding customizado se fornecido
        if custom_branding:
            theme = {**theme, **custom_branding}
        
        # Gerar CSS
        css_styles = self._generate_css_styles(theme)
        
        # Gerar HTML
        html_content = f"""
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contrato de Dados - {contract_data.get('name', 'Sem Título')}</title>
    <style>
        {css_styles}
    </style>
</head>
<body>
    <div class="contract-container">
        {self._generate_html_sections(contract_data, layout_template, theme)}
    </div>
</body>
</html>
        """
        
        return html_content.strip()
    
    def _generate_css_styles(self, theme: Dict[str, Any]) -> str:
        """Gera estilos CSS baseado no tema"""
        return f"""
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: {theme['font_family']};
            font-size: {theme['body_font_size']};
            color: {theme['text_color']};
            background-color: {theme['background_color']};
            line-height: 1.6;
        }}
        
        .contract-container {{
            max-width: 210mm;
            margin: 0 auto;
            padding: 20mm;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }}
        
        .header {{
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid {theme['primary_color']};
        }}
        
        .header h1 {{
            font-size: {theme['header_font_size']};
            color: {theme['primary_color']};
            margin-bottom: 10px;
            font-weight: bold;
        }}
        
        .header .subtitle {{
            font-size: 14px;
            color: {theme['secondary_color']};
            font-style: italic;
        }}
        
        .section {{
            margin-bottom: 25px;
            page-break-inside: avoid;
        }}
        
        .section-title {{
            font-size: 16px;
            font-weight: bold;
            color: {theme['primary_color']};
            margin-bottom: 10px;
            padding: 8px 0;
            border-bottom: 2px solid {theme['accent_color']};
        }}
        
        .section-content {{
            margin-left: 10px;
        }}
        
        .field-group {{
            margin-bottom: 15px;
        }}
        
        .field-label {{
            font-weight: bold;
            color: {theme['secondary_color']};
            margin-bottom: 5px;
        }}
        
        .field-value {{
            margin-left: 15px;
            padding: 5px;
            background-color: #F9FAFB;
            border-left: 3px solid {theme['accent_color']};
        }}
        
        .table {{
            width: 100%;
            border-collapse: collapse;
            margin: 10px 0;
        }}
        
        .table th {{
            background-color: {theme['primary_color']};
            color: white;
            padding: 10px;
            text-align: left;
            font-weight: bold;
        }}
        
        .table td {{
            padding: 8px 10px;
            border-bottom: 1px solid #E5E7EB;
        }}
        
        .table tr:nth-child(even) {{
            background-color: #F9FAFB;
        }}
        
        .highlight {{
            background-color: {theme['accent_color']}20;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
        }}
        
        .pii-warning {{
            background-color: #FEF3C7;
            border: 1px solid #F59E0B;
            padding: 10px;
            border-radius: 5px;
            margin: 10px 0;
        }}
        
        .compliance-badge {{
            display: inline-block;
            background-color: {theme['secondary_color']};
            color: white;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 10px;
            margin: 2px;
        }}
        
        .signature-section {{
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
        }}
        
        .signature-box {{
            width: 45%;
            text-align: center;
            border-top: 1px solid {theme['text_color']};
            padding-top: 10px;
        }}
        
        .footer {{
            margin-top: 30px;
            text-align: center;
            font-size: 10px;
            color: {theme['secondary_color']};
            border-top: 1px solid {theme['accent_color']};
            padding-top: 15px;
        }}
        
        @media print {{
            .contract-container {{
                box-shadow: none;
                margin: 0;
                padding: 15mm;
            }}
        }}
        """
    
    def _generate_html_sections(
        self, 
        contract_data: Dict[str, Any], 
        layout_template: Dict[str, Any],
        theme: Dict[str, Any]
    ) -> str:
        """Gera seções HTML do contrato"""
        
        sections_html = []
        
        for section in layout_template["sections"]:
            section_id = section["id"]
            section_title = section["title"]
            
            section_html = f'<div class="section" id="{section_id}">'
            section_html += f'<h2 class="section-title">{section_title}</h2>'
            section_html += '<div class="section-content">'
            
            # Gerar conteúdo específico da seção
            if section_id == "header":
                section_html += self._generate_header_section(contract_data)
            elif section_id == "parties":
                section_html += self._generate_parties_section(contract_data)
            elif section_id == "purpose":
                section_html += self._generate_purpose_section(contract_data)
            elif section_id == "data_scope":
                section_html += self._generate_data_scope_section(contract_data)
            elif section_id == "schema":
                section_html += self._generate_schema_section(contract_data)
            elif section_id == "sla":
                section_html += self._generate_sla_section(contract_data)
            elif section_id == "compliance":
                section_html += self._generate_compliance_section(contract_data)
            elif section_id == "responsibilities":
                section_html += self._generate_responsibilities_section(contract_data)
            elif section_id == "terms":
                section_html += self._generate_terms_section(contract_data)
            elif section_id == "signatures":
                section_html += self._generate_signatures_section(contract_data)
            else:
                section_html += f'<p>Seção {section_title} em desenvolvimento.</p>'
            
            section_html += '</div></div>'
            sections_html.append(section_html)
        
        # Adicionar footer
        footer_html = self._generate_footer(contract_data)
        sections_html.append(footer_html)
        
        return '\\n'.join(sections_html)
    
    def _generate_header_section(self, contract_data: Dict[str, Any]) -> str:
        """Gera seção de cabeçalho"""
        contract_name = contract_data.get('name', 'Contrato de Dados')
        version = contract_data.get('version', '1.0.0')
        generated_date = datetime.now().strftime('%d/%m/%Y')
        
        return f"""
        <div class="header">
            <h1>{contract_name}</h1>
            <div class="subtitle">Versão {version} - Gerado em {generated_date}</div>
        </div>
        """
    
    def _generate_parties_section(self, contract_data: Dict[str, Any]) -> str:
        """Gera seção de partes envolvidas"""
        owner_email = contract_data.get('owner_email', 'Não especificado')
        
        return f"""
        <div class="field-group">
            <div class="field-label">Proprietário dos Dados:</div>
            <div class="field-value">{owner_email}</div>
        </div>
        <div class="field-group">
            <div class="field-label">Consumidores dos Dados:</div>
            <div class="field-value">A serem definidos conforme necessidade</div>
        </div>
        """
    
    def _generate_purpose_section(self, contract_data: Dict[str, Any]) -> str:
        """Gera seção de objetivo"""
        description = contract_data.get('description', 'Não especificado')
        
        return f"""
        <div class="field-group">
            <div class="field-label">Descrição:</div>
            <div class="field-value">{description}</div>
        </div>
        """
    
    def _generate_data_scope_section(self, contract_data: Dict[str, Any]) -> str:
        """Gera seção de escopo dos dados"""
        classification = contract_data.get('data_classification', 'Não especificado')
        template_name = contract_data.get('template_name', 'Personalizado')
        
        return f"""
        <div class="field-group">
            <div class="field-label">Classificação dos Dados:</div>
            <div class="field-value">{classification.title()}</div>
        </div>
        <div class="field-group">
            <div class="field-label">Tipo de Contrato:</div>
            <div class="field-value">{template_name}</div>
        </div>
        """
    
    def _generate_schema_section(self, contract_data: Dict[str, Any]) -> str:
        """Gera seção de estrutura dos dados"""
        schema_def = contract_data.get('schema_definition', {})
        
        html = ""
        
        # Tabelas
        tables = schema_def.get('tables', [])
        if tables:
            html += f"""
            <div class="field-group">
                <div class="field-label">Tabelas:</div>
                <div class="field-value">{', '.join(tables)}</div>
            </div>
            """
        
        # Campos obrigatórios
        required_fields = schema_def.get('required_fields', [])
        if required_fields:
            html += '<div class="field-group">'
            html += '<div class="field-label">Campos Obrigatórios:</div>'
            html += '<table class="table">'
            html += '<tr><th>Campo</th><th>Tipo</th><th>Descrição</th><th>PII</th></tr>'
            
            for field in required_fields:
                pii_indicator = "✓" if field.get('pii', False) else ""
                html += f"""
                <tr>
                    <td>{field.get('name', '')}</td>
                    <td>{field.get('type', '')}</td>
                    <td>{field.get('description', '')}</td>
                    <td>{pii_indicator}</td>
                </tr>
                """
            
            html += '</table></div>'
        
        # Campos opcionais
        optional_fields = schema_def.get('optional_fields', [])
        if optional_fields:
            html += '<div class="field-group">'
            html += '<div class="field-label">Campos Opcionais:</div>'
            html += '<table class="table">'
            html += '<tr><th>Campo</th><th>Tipo</th><th>Descrição</th><th>PII</th></tr>'
            
            for field in optional_fields:
                pii_indicator = "✓" if field.get('pii', False) else ""
                html += f"""
                <tr>
                    <td>{field.get('name', '')}</td>
                    <td>{field.get('type', '')}</td>
                    <td>{field.get('description', '')}</td>
                    <td>{pii_indicator}</td>
                </tr>
                """
            
            html += '</table></div>'
        
        # Aviso sobre PII
        pii_fields = contract_data.get('pii_fields', [])
        if pii_fields:
            html += f"""
            <div class="pii-warning">
                <strong>⚠️ Atenção:</strong> Este contrato contém campos com informações pessoais (PII): 
                {', '.join(pii_fields)}. Certifique-se de seguir as regulamentações de privacidade aplicáveis.
            </div>
            """
        
        return html
    
    def _generate_sla_section(self, contract_data: Dict[str, Any]) -> str:
        """Gera seção de SLA"""
        sla_requirements = contract_data.get('sla_requirements', {})
        
        if not sla_requirements:
            return '<p>SLA não especificado.</p>'
        
        html = '<table class="table">'
        html += '<tr><th>Métrica</th><th>Valor</th></tr>'
        
        for metric, value in sla_requirements.items():
            metric_name = metric.replace('_', ' ').title()
            html += f'<tr><td>{metric_name}</td><td>{value}</td></tr>'
        
        html += '</table>'
        
        return html
    
    def _generate_compliance_section(self, contract_data: Dict[str, Any]) -> str:
        """Gera seção de compliance"""
        compliance_reqs = contract_data.get('compliance_requirements', [])
        
        if not compliance_reqs:
            return '<p>Requisitos de compliance não especificados.</p>'
        
        html = '<div class="field-group">'
        html += '<div class="field-label">Regulamentações Aplicáveis:</div>'
        html += '<div class="field-value">'
        
        for req in compliance_reqs:
            html += f'<span class="compliance-badge">{req}</span>'
        
        html += '</div></div>'
        
        return html
    
    def _generate_responsibilities_section(self, contract_data: Dict[str, Any]) -> str:
        """Gera seção de responsabilidades"""
        return """
        <div class="field-group">
            <div class="field-label">Proprietário dos Dados:</div>
            <div class="field-value">
                • Garantir qualidade e integridade dos dados<br>
                • Manter conformidade com regulamentações<br>
                • Definir políticas de acesso e uso
            </div>
        </div>
        <div class="field-group">
            <div class="field-label">Consumidores dos Dados:</div>
            <div class="field-value">
                • Usar dados apenas para fins autorizados<br>
                • Respeitar políticas de privacidade<br>
                • Reportar problemas de qualidade
            </div>
        </div>
        """
    
    def _generate_terms_section(self, contract_data: Dict[str, Any]) -> str:
        """Gera seção de termos e condições"""
        return """
        <div class="highlight">
            <p><strong>1. Uso dos Dados:</strong> Os dados devem ser utilizados exclusivamente para os fins especificados neste contrato.</p>
            <p><strong>2. Privacidade:</strong> Todas as informações pessoais devem ser tratadas conforme LGPD e regulamentações aplicáveis.</p>
            <p><strong>3. Segurança:</strong> Medidas adequadas de segurança devem ser implementadas para proteger os dados.</p>
            <p><strong>4. Auditoria:</strong> O acesso e uso dos dados podem ser auditados a qualquer momento.</p>
            <p><strong>5. Vigência:</strong> Este contrato permanece válido até revisão ou cancelamento formal.</p>
        </div>
        """
    
    def _generate_signatures_section(self, contract_data: Dict[str, Any]) -> str:
        """Gera seção de assinaturas"""
        return """
        <div class="signature-section">
            <div class="signature-box">
                <div>Proprietário dos Dados</div>
                <div style="margin-top: 20px;">_________________________</div>
                <div>Nome e Data</div>
            </div>
            <div class="signature-box">
                <div>Consumidor dos Dados</div>
                <div style="margin-top: 20px;">_________________________</div>
                <div>Nome e Data</div>
            </div>
        </div>
        """
    
    def _generate_footer(self, contract_data: Dict[str, Any]) -> str:
        """Gera rodapé do documento"""
        contract_id = contract_data.get('id', 'N/A')
        generated_at = contract_data.get('generated_at', datetime.now().isoformat())
        
        return f"""
        <div class="footer">
            <p>Documento gerado automaticamente pelo Sistema de Governança de Dados</p>
            <p>ID do Contrato: {contract_id} | Gerado em: {generated_at}</p>
            <p>Este documento é válido apenas com assinaturas digitais ou físicas das partes envolvidas</p>
        </div>
        """
    
    def generate_pdf_layout(
        self,
        contract_data: Dict[str, Any],
        layout_id: str = "professional",
        theme_id: str = "corporate_blue"
    ) -> bytes:
        """Gera layout PDF do contrato"""
        # Primeiro gerar HTML
        html_content = self.generate_html_layout(contract_data, layout_id, theme_id)
        
        # Simular conversão para PDF (em implementação real, usar biblioteca como weasyprint)
        pdf_placeholder = f"""
        PDF PLACEHOLDER - Contrato: {contract_data.get('name', 'Sem Título')}
        Layout: {layout_id}
        Tema: {theme_id}
        Gerado em: {datetime.now().isoformat()}
        
        [Em implementação real, este seria um PDF binário gerado a partir do HTML]
        """
        
        return pdf_placeholder.encode('utf-8')
    
    def generate_word_layout(
        self,
        contract_data: Dict[str, Any],
        layout_id: str = "professional"
    ) -> bytes:
        """Gera layout Word do contrato"""
        # Simular geração de documento Word
        word_placeholder = f"""
        WORD PLACEHOLDER - Contrato: {contract_data.get('name', 'Sem Título')}
        Layout: {layout_id}
        Gerado em: {datetime.now().isoformat()}
        
        [Em implementação real, este seria um documento Word binário]
        """
        
        return word_placeholder.encode('utf-8')
    
    def preview_layout(
        self,
        contract_data: Dict[str, Any],
        layout_id: str = "professional",
        theme_id: str = "corporate_blue"
    ) -> Dict[str, Any]:
        """Gera preview do layout"""
        
        layout_template = self.layout_templates.get(layout_id)
        theme = self.style_themes.get(theme_id)
        
        if not layout_template or not theme:
            raise ValueError("Layout ou tema não encontrado")
        
        # Gerar preview simplificado
        preview = {
            "layout_info": {
                "id": layout_id,
                "name": layout_template["name"],
                "description": layout_template["description"],
                "sections": layout_template["sections"]
            },
            "theme_info": {
                "id": theme_id,
                "name": theme["name"],
                "colors": {
                    "primary": theme["primary_color"],
                    "secondary": theme["secondary_color"],
                    "accent": theme["accent_color"]
                }
            },
            "contract_summary": {
                "name": contract_data.get('name', 'Sem Título'),
                "description": contract_data.get('description', 'Sem Descrição'),
                "classification": contract_data.get('data_classification', 'Não especificado'),
                "pii_fields_count": len(contract_data.get('pii_fields', [])),
                "compliance_requirements": contract_data.get('compliance_requirements', [])
            },
            "estimated_pages": self._estimate_pages(contract_data, layout_template),
            "generation_timestamp": datetime.now().isoformat()
        }
        
        return preview
    
    def _estimate_pages(self, contract_data: Dict[str, Any], layout_template: Dict[str, Any]) -> int:
        """Estima número de páginas do documento"""
        base_pages = 2  # Páginas base
        
        # Adicionar páginas baseado no conteúdo
        schema_def = contract_data.get('schema_definition', {})
        required_fields = len(schema_def.get('required_fields', []))
        optional_fields = len(schema_def.get('optional_fields', []))
        
        # Estimar páginas adicionais baseado no número de campos
        additional_pages = (required_fields + optional_fields) // 20
        
        return base_pages + additional_pages

