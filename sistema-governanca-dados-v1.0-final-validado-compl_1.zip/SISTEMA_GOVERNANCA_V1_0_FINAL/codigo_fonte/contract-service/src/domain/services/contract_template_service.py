"""
Contract Template Service - Serviço de Templates de Contrato
Sistema de Governança de Dados V5.0

Responsável por:
- Gestão de templates predefinidos
- Geração automática de schemas
- Sugestões inteligentes de SLA
- Validação de estruturas
"""

from typing import Dict, List, Any, Optional
from datetime import datetime
import json
import re


class ContractTemplateService:
    """Serviço para gestão de templates de contrato"""
    
    def __init__(self):
        self.templates = self._initialize_templates()
        self.sla_templates = self._initialize_sla_templates()
    
    def _initialize_templates(self) -> Dict[str, Dict[str, Any]]:
        """Inicializa templates predefinidos"""
        return {
            "financial_data": {
                "name": "Dados Financeiros",
                "description": "Template para dados financeiros e transacionais",
                "category": "finance",
                "schema_template": {
                    "tables": ["transactions", "accounts", "customers"],
                    "required_fields": [
                        {"name": "transaction_id", "type": "string", "required": True, "description": "ID único da transação"},
                        {"name": "customer_id", "type": "string", "required": True, "description": "ID do cliente"},
                        {"name": "account_id", "type": "string", "required": True, "description": "ID da conta"},
                        {"name": "amount", "type": "decimal", "required": True, "description": "Valor da transação"},
                        {"name": "currency", "type": "string", "required": True, "default": "BRL", "description": "Moeda"},
                        {"name": "transaction_date", "type": "datetime", "required": True, "description": "Data da transação"},
                        {"name": "transaction_type", "type": "string", "required": True, "description": "Tipo de transação"}
                    ],
                    "optional_fields": [
                        {"name": "description", "type": "string", "description": "Descrição da transação"},
                        {"name": "merchant_id", "type": "string", "description": "ID do comerciante"},
                        {"name": "category", "type": "string", "description": "Categoria da transação"}
                    ]
                },
                "compliance_requirements": ["SOX", "PCI-DSS", "LGPD"],
                "data_classification": "confidential"
            },
            
            "customer_data": {
                "name": "Dados de Clientes",
                "description": "Template para dados pessoais e de clientes",
                "category": "customer",
                "schema_template": {
                    "tables": ["customers", "addresses", "contacts"],
                    "required_fields": [
                        {"name": "customer_id", "type": "string", "required": True, "description": "ID único do cliente"},
                        {"name": "full_name", "type": "string", "required": True, "description": "Nome completo", "pii": True},
                        {"name": "email", "type": "string", "required": True, "description": "Email principal", "pii": True},
                        {"name": "phone", "type": "string", "required": False, "description": "Telefone", "pii": True},
                        {"name": "created_at", "type": "datetime", "required": True, "description": "Data de criação"},
                        {"name": "status", "type": "string", "required": True, "description": "Status do cliente"}
                    ],
                    "optional_fields": [
                        {"name": "cpf", "type": "string", "description": "CPF do cliente", "pii": True, "sensitive": True},
                        {"name": "birth_date", "type": "date", "description": "Data de nascimento", "pii": True},
                        {"name": "address", "type": "string", "description": "Endereço", "pii": True},
                        {"name": "city", "type": "string", "description": "Cidade"},
                        {"name": "state", "type": "string", "description": "Estado"},
                        {"name": "zip_code", "type": "string", "description": "CEP"}
                    ]
                },
                "compliance_requirements": ["LGPD", "GDPR"],
                "data_classification": "restricted"
            },
            
            "sales_data": {
                "name": "Dados de Vendas",
                "description": "Template para dados de vendas e faturamento",
                "category": "sales",
                "schema_template": {
                    "tables": ["sales", "products", "customers"],
                    "required_fields": [
                        {"name": "sale_id", "type": "string", "required": True, "description": "ID único da venda"},
                        {"name": "customer_id", "type": "string", "required": True, "description": "ID do cliente"},
                        {"name": "product_id", "type": "string", "required": True, "description": "ID do produto"},
                        {"name": "quantity", "type": "integer", "required": True, "description": "Quantidade vendida"},
                        {"name": "unit_price", "type": "decimal", "required": True, "description": "Preço unitário"},
                        {"name": "total_amount", "type": "decimal", "required": True, "description": "Valor total"},
                        {"name": "sale_date", "type": "datetime", "required": True, "description": "Data da venda"}
                    ],
                    "optional_fields": [
                        {"name": "discount", "type": "decimal", "description": "Desconto aplicado"},
                        {"name": "tax_amount", "type": "decimal", "description": "Valor do imposto"},
                        {"name": "salesperson_id", "type": "string", "description": "ID do vendedor"},
                        {"name": "commission", "type": "decimal", "description": "Comissão"}
                    ]
                },
                "compliance_requirements": ["SOX", "LGPD"],
                "data_classification": "internal"
            },
            
            "hr_data": {
                "name": "Dados de RH",
                "description": "Template para dados de recursos humanos",
                "category": "hr",
                "schema_template": {
                    "tables": ["employees", "departments", "positions"],
                    "required_fields": [
                        {"name": "employee_id", "type": "string", "required": True, "description": "ID único do funcionário"},
                        {"name": "full_name", "type": "string", "required": True, "description": "Nome completo", "pii": True},
                        {"name": "email", "type": "string", "required": True, "description": "Email corporativo", "pii": True},
                        {"name": "department_id", "type": "string", "required": True, "description": "ID do departamento"},
                        {"name": "position_id", "type": "string", "required": True, "description": "ID do cargo"},
                        {"name": "hire_date", "type": "date", "required": True, "description": "Data de contratação"},
                        {"name": "status", "type": "string", "required": True, "description": "Status do funcionário"}
                    ],
                    "optional_fields": [
                        {"name": "cpf", "type": "string", "description": "CPF", "pii": True, "sensitive": True},
                        {"name": "salary", "type": "decimal", "description": "Salário", "sensitive": True},
                        {"name": "manager_id", "type": "string", "description": "ID do gestor"},
                        {"name": "phone", "type": "string", "description": "Telefone", "pii": True}
                    ]
                },
                "compliance_requirements": ["LGPD", "CLT"],
                "data_classification": "restricted"
            },
            
            "analytics_data": {
                "name": "Dados de Analytics",
                "description": "Template para dados de análise e métricas",
                "category": "analytics",
                "schema_template": {
                    "tables": ["events", "metrics", "dimensions"],
                    "required_fields": [
                        {"name": "event_id", "type": "string", "required": True, "description": "ID único do evento"},
                        {"name": "event_type", "type": "string", "required": True, "description": "Tipo do evento"},
                        {"name": "timestamp", "type": "datetime", "required": True, "description": "Timestamp do evento"},
                        {"name": "user_id", "type": "string", "required": False, "description": "ID do usuário"},
                        {"name": "session_id", "type": "string", "required": False, "description": "ID da sessão"}
                    ],
                    "optional_fields": [
                        {"name": "properties", "type": "json", "description": "Propriedades do evento"},
                        {"name": "page_url", "type": "string", "description": "URL da página"},
                        {"name": "referrer", "type": "string", "description": "Referrer"},
                        {"name": "device_type", "type": "string", "description": "Tipo de dispositivo"}
                    ]
                },
                "compliance_requirements": ["LGPD", "GDPR"],
                "data_classification": "internal"
            }
        }
    
    def _initialize_sla_templates(self) -> Dict[str, Dict[str, Any]]:
        """Inicializa templates de SLA"""
        return {
            "financial_data": {
                "availability": "99.9%",
                "response_time": "< 100ms",
                "data_freshness": "< 5min",
                "backup_frequency": "daily",
                "retention_period": "7 years",
                "recovery_time": "< 4h",
                "accuracy": "99.99%"
            },
            "customer_data": {
                "availability": "99.5%",
                "response_time": "< 200ms",
                "data_freshness": "< 15min",
                "backup_frequency": "daily",
                "retention_period": "5 years",
                "recovery_time": "< 8h",
                "accuracy": "99.9%"
            },
            "sales_data": {
                "availability": "99.0%",
                "response_time": "< 500ms",
                "data_freshness": "< 1h",
                "backup_frequency": "daily",
                "retention_period": "3 years",
                "recovery_time": "< 12h",
                "accuracy": "99.5%"
            },
            "hr_data": {
                "availability": "99.0%",
                "response_time": "< 1s",
                "data_freshness": "< 1h",
                "backup_frequency": "daily",
                "retention_period": "10 years",
                "recovery_time": "< 24h",
                "accuracy": "99.9%"
            },
            "analytics_data": {
                "availability": "95.0%",
                "response_time": "< 2s",
                "data_freshness": "< 4h",
                "backup_frequency": "weekly",
                "retention_period": "2 years",
                "recovery_time": "< 48h",
                "accuracy": "95.0%"
            }
        }
    
    def get_available_templates(self) -> List[Dict[str, Any]]:
        """Retorna lista de templates disponíveis"""
        templates_list = []
        for template_id, template in self.templates.items():
            templates_list.append({
                "id": template_id,
                "name": template["name"],
                "description": template["description"],
                "category": template["category"],
                "compliance_requirements": template["compliance_requirements"],
                "data_classification": template["data_classification"]
            })
        return templates_list
    
    def get_template_by_id(self, template_id: str) -> Optional[Dict[str, Any]]:
        """Retorna template específico por ID"""
        return self.templates.get(template_id)
    
    def get_templates_by_category(self, category: str) -> List[Dict[str, Any]]:
        """Retorna templates por categoria"""
        filtered_templates = []
        for template_id, template in self.templates.items():
            if template["category"] == category:
                filtered_templates.append({
                    "id": template_id,
                    **template
                })
        return filtered_templates
    
    def generate_contract_from_template(
        self, 
        template_id: str, 
        custom_fields: Optional[List[Dict[str, Any]]] = None,
        custom_sla: Optional[Dict[str, Any]] = None,
        contract_metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Gera contrato baseado em template"""
        
        template = self.get_template_by_id(template_id)
        if not template:
            raise ValueError(f"Template {template_id} não encontrado")
        
        # Metadados do contrato
        metadata = contract_metadata or {}
        contract_name = metadata.get("name", f"Contrato {template['name']}")
        contract_description = metadata.get("description", template["description"])
        
        # Schema base do template
        schema_definition = template["schema_template"].copy()
        
        # Adicionar campos customizados se fornecidos
        if custom_fields:
            if "custom_fields" not in schema_definition:
                schema_definition["custom_fields"] = []
            schema_definition["custom_fields"].extend(custom_fields)
        
        # SLA baseado no template
        sla_requirements = self.sla_templates.get(template_id, {}).copy()
        
        # Sobrescrever com SLA customizado se fornecido
        if custom_sla:
            sla_requirements.update(custom_sla)
        
        # Detectar PII automaticamente
        pii_fields = self._detect_pii_fields(schema_definition)
        
        # Gerar contrato final
        contract = {
            "name": contract_name,
            "description": contract_description,
            "version": "1.0.0",
            "status": "draft",
            "data_classification": template["data_classification"],
            "owner_email": metadata.get("owner_email", ""),
            "template_id": template_id,
            "template_name": template["name"],
            "schema_definition": schema_definition,
            "sla_requirements": sla_requirements,
            "compliance_requirements": template["compliance_requirements"],
            "pii_fields": pii_fields,
            "generated_at": datetime.utcnow().isoformat(),
            "generated_by": "template_service"
        }
        
        return contract
    
    def _detect_pii_fields(self, schema_definition: Dict[str, Any]) -> List[str]:
        """Detecta campos que contêm PII"""
        pii_fields = []
        
        # Verificar campos obrigatórios
        for field in schema_definition.get("required_fields", []):
            if field.get("pii", False):
                pii_fields.append(field["name"])
        
        # Verificar campos opcionais
        for field in schema_definition.get("optional_fields", []):
            if field.get("pii", False):
                pii_fields.append(field["name"])
        
        # Verificar campos customizados
        for field in schema_definition.get("custom_fields", []):
            if field.get("pii", False):
                pii_fields.append(field["name"])
        
        return pii_fields
    
    def validate_contract_schema(self, schema_definition: Dict[str, Any]) -> Dict[str, Any]:
        """Valida schema do contrato"""
        validation_result = {
            "valid": True,
            "errors": [],
            "warnings": [],
            "suggestions": []
        }
        
        # Verificar se há campos obrigatórios
        required_fields = schema_definition.get("required_fields", [])
        if not required_fields:
            validation_result["warnings"].append("Nenhum campo obrigatório definido")
        
        # Verificar duplicação de nomes de campos
        all_fields = []
        for field_list in ["required_fields", "optional_fields", "custom_fields"]:
            for field in schema_definition.get(field_list, []):
                field_name = field.get("name")
                if field_name in all_fields:
                    validation_result["errors"].append(f"Campo duplicado: {field_name}")
                    validation_result["valid"] = False
                else:
                    all_fields.append(field_name)
        
        # Verificar tipos de dados válidos
        valid_types = ["string", "integer", "decimal", "boolean", "date", "datetime", "json"]
        for field_list in ["required_fields", "optional_fields", "custom_fields"]:
            for field in schema_definition.get(field_list, []):
                field_type = field.get("type")
                if field_type and field_type not in valid_types:
                    validation_result["errors"].append(f"Tipo inválido '{field_type}' para campo '{field.get('name')}'")
                    validation_result["valid"] = False
        
        # Sugestões de melhoria
        if len(all_fields) > 50:
            validation_result["suggestions"].append("Considere dividir em múltiplas tabelas (>50 campos)")
        
        # Verificar se há campos PII sem classificação adequada
        pii_fields = self._detect_pii_fields(schema_definition)
        if pii_fields:
            validation_result["suggestions"].append(f"Campos PII detectados: {', '.join(pii_fields)}. Verifique classificação de dados.")
        
        return validation_result
    
    def suggest_sla_improvements(self, current_sla: Dict[str, Any], template_id: str) -> List[str]:
        """Sugere melhorias no SLA baseado no template"""
        suggestions = []
        template_sla = self.sla_templates.get(template_id, {})
        
        # Verificar métricas essenciais
        essential_metrics = ["availability", "response_time", "data_freshness", "backup_frequency"]
        for metric in essential_metrics:
            if metric not in current_sla:
                template_value = template_sla.get(metric, "N/A")
                suggestions.append(f"Adicionar métrica '{metric}' (sugestão: {template_value})")
        
        # Verificar valores realistas
        if "availability" in current_sla:
            availability = current_sla["availability"]
            if isinstance(availability, str) and "%" in availability:
                try:
                    value = float(availability.replace("%", ""))
                    if value > 99.99:
                        suggestions.append("Disponibilidade >99.99% pode ser muito ambiciosa")
                    elif value < 90:
                        suggestions.append("Disponibilidade <90% pode ser insuficiente")
                except ValueError:
                    suggestions.append("Formato de disponibilidade inválido (use: '99.9%')")
        
        return suggestions
    
    def get_field_suggestions(self, category: str, partial_name: str = "") -> List[Dict[str, Any]]:
        """Retorna sugestões de campos baseado na categoria"""
        suggestions = []
        
        # Buscar em todos os templates da categoria
        for template_id, template in self.templates.items():
            if template["category"] == category:
                # Campos obrigatórios
                for field in template["schema_template"].get("required_fields", []):
                    if partial_name.lower() in field["name"].lower():
                        suggestions.append({
                            "name": field["name"],
                            "type": field["type"],
                            "description": field["description"],
                            "required": True,
                            "template_source": template["name"],
                            "pii": field.get("pii", False),
                            "sensitive": field.get("sensitive", False)
                        })
                
                # Campos opcionais
                for field in template["schema_template"].get("optional_fields", []):
                    if partial_name.lower() in field["name"].lower():
                        suggestions.append({
                            "name": field["name"],
                            "type": field["type"],
                            "description": field["description"],
                            "required": False,
                            "template_source": template["name"],
                            "pii": field.get("pii", False),
                            "sensitive": field.get("sensitive", False)
                        })
        
        # Remover duplicatas
        unique_suggestions = []
        seen_names = set()
        for suggestion in suggestions:
            if suggestion["name"] not in seen_names:
                unique_suggestions.append(suggestion)
                seen_names.add(suggestion["name"])
        
        return unique_suggestions[:10]  # Limitar a 10 sugestões

