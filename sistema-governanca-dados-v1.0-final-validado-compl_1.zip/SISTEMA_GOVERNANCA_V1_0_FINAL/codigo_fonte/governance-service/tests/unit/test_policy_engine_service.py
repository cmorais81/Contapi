# Autor: carlos.morais@f1rst.com.br
"""
Testes Unitários para Policy Engine Service
"""

import pytest
import asyncio
from datetime import datetime, timedelta
from uuid import UUID, uuid4
from unittest.mock import Mock, AsyncMock, patch
from typing import List, Dict, Any

from src.domain.entities.governance_policy import (
    GovernancePolicy, PolicyCategory, PolicyEnforcement, PolicyStatus
)
from src.domain.services.policy_engine_service import (
    PolicyEngineService, PolicyEvaluationResult, PolicyViolation,
    ComplianceDashboard, PolicyRecommendation, RemediationAction
)


class TestPolicyEngineService:
    """Testes para PolicyEngineService"""
    
    @pytest.fixture
    def policy_engine(self):
        """Instância do policy engine"""
        return PolicyEngineService()
    
    @pytest.fixture
    def sample_policies(self):
        """Políticas de exemplo para testes"""
        return [
            GovernancePolicy(
                id=uuid4(),
                name="Data Classification Policy",
                category=PolicyCategory.DATA_CLASSIFICATION,
                enforcement=PolicyEnforcement.PREVENTIVE,
                description="Todos os dados devem ser classificados",
                rules={
                    "required_classification": True,
                    "valid_classifications": ["PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED"],
                    "default_classification": "INTERNAL"
                },
                scope={
                    "applies_to": ["datasets", "contracts"],
                    "exceptions": []
                },
                status=PolicyStatus.ACTIVE,
                created_by="admin",
                created_at=datetime.utcnow()
            ),
            GovernancePolicy(
                id=uuid4(),
                name="LGPD Compliance Policy",
                category=PolicyCategory.PRIVACY_PROTECTION,
                enforcement=PolicyEnforcement.DETECTIVE,
                description="Conformidade com LGPD para dados pessoais",
                rules={
                    "personal_data_requires_consent": True,
                    "retention_period_required": True,
                    "data_subject_rights": ["access", "rectification", "erasure", "portability"],
                    "legal_basis_required": True
                },
                scope={
                    "applies_to": ["personal_data"],
                    "data_classifications": ["PERSONAL", "SENSITIVE"]
                },
                status=PolicyStatus.ACTIVE,
                created_by="compliance_officer",
                created_at=datetime.utcnow()
            ),
            GovernancePolicy(
                id=uuid4(),
                name="Access Control Policy",
                category=PolicyCategory.ACCESS_CONTROL,
                enforcement=PolicyEnforcement.PREVENTIVE,
                description="Controle de acesso baseado em roles",
                rules={
                    "rbac_required": True,
                    "minimum_access_principle": True,
                    "access_review_frequency": "quarterly",
                    "privileged_access_approval": True
                },
                scope={
                    "applies_to": ["all_resources"],
                    "user_roles": ["data_analyst", "data_scientist", "admin"]
                },
                status=PolicyStatus.ACTIVE,
                created_by="security_admin",
                created_at=datetime.utcnow()
            )
        ]
    
    @pytest.fixture
    def sample_context(self):
        """Contexto de exemplo para avaliação de políticas"""
        return {
            "resource_type": "dataset",
            "resource_id": "customer_data_v1",
            "data_classification": "CONFIDENTIAL",
            "user_id": "analyst001",
            "user_role": "data_analyst",
            "action": "read",
            "timestamp": datetime.utcnow().isoformat(),
            "metadata": {
                "contains_personal_data": True,
                "data_subjects": ["customers"],
                "retention_period": "7_years",
                "legal_basis": "contract"
            }
        }
    
    @pytest.fixture
    def non_compliant_context(self):
        """Contexto não conforme para testes"""
        return {
            "resource_type": "dataset",
            "resource_id": "unclassified_data",
            "data_classification": None,  # Violação: sem classificação
            "user_id": "external_user",
            "user_role": "guest",  # Violação: role não autorizado
            "action": "write",
            "timestamp": datetime.utcnow().isoformat(),
            "metadata": {
                "contains_personal_data": True,
                "legal_basis": None  # Violação: sem base legal para dados pessoais
            }
        }
    
    @pytest.mark.asyncio
    async def test_evaluate_policies_compliant_context(self, policy_engine, sample_policies, sample_context):
        """Testa avaliação de políticas com contexto conforme"""
        # Act
        result = await policy_engine.evaluate_policies(sample_policies, sample_context)
        
        # Assert
        assert isinstance(result, PolicyEvaluationResult)
        assert result.context_id is not None
        assert result.total_policies == len(sample_policies)
        assert result.policies_evaluated == len(sample_policies)
        assert result.overall_compliance_score >= 80.0  # Alto compliance
        assert len(result.violations) == 0  # Sem violações
        assert result.is_compliant is True
    
    @pytest.mark.asyncio
    async def test_evaluate_policies_non_compliant_context(self, policy_engine, sample_policies, non_compliant_context):
        """Testa avaliação de políticas com contexto não conforme"""
        # Act
        result = await policy_engine.evaluate_policies(sample_policies, non_compliant_context)
        
        # Assert
        assert isinstance(result, PolicyEvaluationResult)
        assert result.overall_compliance_score < 50.0  # Baixo compliance
        assert len(result.violations) > 0  # Deve ter violações
        assert result.is_compliant is False
        
        # Verificar tipos de violações
        violation_categories = [v.policy_category for v in result.violations]
        assert PolicyCategory.DATA_CLASSIFICATION in violation_categories
        assert PolicyCategory.PRIVACY_PROTECTION in violation_categories
    
    @pytest.mark.asyncio
    async def test_evaluate_data_classification_policy_compliant(self, policy_engine, sample_context):
        """Testa avaliação de política de classificação de dados (conforme)"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Classification Policy",
            category=PolicyCategory.DATA_CLASSIFICATION,
            enforcement=PolicyEnforcement.PREVENTIVE,
            rules={
                "required_classification": True,
                "valid_classifications": ["PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED"]
            }
        )
        
        # Act
        violations = await policy_engine._evaluate_data_classification_policy(policy, sample_context)
        
        # Assert
        assert len(violations) == 0  # Sem violações
    
    @pytest.mark.asyncio
    async def test_evaluate_data_classification_policy_missing_classification(self, policy_engine):
        """Testa avaliação de política de classificação com classificação ausente"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Classification Policy",
            category=PolicyCategory.DATA_CLASSIFICATION,
            enforcement=PolicyEnforcement.PREVENTIVE,
            rules={"required_classification": True}
        )
        
        context = {
            "resource_type": "dataset",
            "data_classification": None  # Classificação ausente
        }
        
        # Act
        violations = await policy_engine._evaluate_data_classification_policy(policy, context)
        
        # Assert
        assert len(violations) > 0
        assert violations[0].violation_type == "missing_classification"
        assert violations[0].severity == "high"
    
    @pytest.mark.asyncio
    async def test_evaluate_access_control_policy_authorized_user(self, policy_engine, sample_context):
        """Testa avaliação de política de controle de acesso (usuário autorizado)"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Access Control Policy",
            category=PolicyCategory.ACCESS_CONTROL,
            enforcement=PolicyEnforcement.PREVENTIVE,
            rules={
                "authorized_roles": ["data_analyst", "data_scientist", "admin"],
                "rbac_required": True
            }
        )
        
        # Act
        violations = await policy_engine._evaluate_access_control_policy(policy, sample_context)
        
        # Assert
        assert len(violations) == 0  # Sem violações
    
    @pytest.mark.asyncio
    async def test_evaluate_access_control_policy_unauthorized_user(self, policy_engine):
        """Testa avaliação de política de controle de acesso (usuário não autorizado)"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Access Control Policy",
            category=PolicyCategory.ACCESS_CONTROL,
            enforcement=PolicyEnforcement.PREVENTIVE,
            rules={
                "authorized_roles": ["admin"],
                "rbac_required": True
            }
        )
        
        context = {
            "user_role": "guest",  # Role não autorizado
            "action": "write"
        }
        
        # Act
        violations = await policy_engine._evaluate_access_control_policy(policy, context)
        
        # Assert
        assert len(violations) > 0
        assert violations[0].violation_type == "unauthorized_access"
        assert violations[0].severity == "critical"
    
    @pytest.mark.asyncio
    async def test_evaluate_privacy_protection_policy_compliant(self, policy_engine, sample_context):
        """Testa avaliação de política de proteção de privacidade (conforme)"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Privacy Policy",
            category=PolicyCategory.PRIVACY_PROTECTION,
            enforcement=PolicyEnforcement.DETECTIVE,
            rules={
                "personal_data_requires_consent": True,
                "legal_basis_required": True,
                "retention_period_required": True
            }
        )
        
        # Act
        violations = await policy_engine._evaluate_privacy_protection_policy(policy, sample_context)
        
        # Assert
        assert len(violations) == 0  # Sem violações
    
    @pytest.mark.asyncio
    async def test_evaluate_privacy_protection_policy_missing_legal_basis(self, policy_engine):
        """Testa avaliação de política de privacidade sem base legal"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Privacy Policy",
            category=PolicyCategory.PRIVACY_PROTECTION,
            enforcement=PolicyEnforcement.DETECTIVE,
            rules={
                "personal_data_requires_consent": True,
                "legal_basis_required": True
            }
        )
        
        context = {
            "metadata": {
                "contains_personal_data": True,
                "legal_basis": None  # Base legal ausente
            }
        }
        
        # Act
        violations = await policy_engine._evaluate_privacy_protection_policy(policy, context)
        
        # Assert
        assert len(violations) > 0
        assert violations[0].violation_type == "missing_legal_basis"
        assert violations[0].severity == "high"
    
    @pytest.mark.asyncio
    async def test_evaluate_data_retention_policy_compliant(self, policy_engine):
        """Testa avaliação de política de retenção de dados (conforme)"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Retention Policy",
            category=PolicyCategory.DATA_RETENTION,
            enforcement=PolicyEnforcement.CORRECTIVE,
            rules={
                "max_retention_period": "7_years",
                "retention_period_required": True,
                "auto_purge_enabled": True
            }
        )
        
        context = {
            "metadata": {
                "retention_period": "5_years",  # Dentro do limite
                "created_at": "2020-01-01T00:00:00Z"
            }
        }
        
        # Act
        violations = await policy_engine._evaluate_data_retention_policy(policy, context)
        
        # Assert
        assert len(violations) == 0  # Sem violações
    
    @pytest.mark.asyncio
    async def test_evaluate_data_retention_policy_exceeded_period(self, policy_engine):
        """Testa avaliação de política de retenção com período excedido"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Retention Policy",
            category=PolicyCategory.DATA_RETENTION,
            enforcement=PolicyEnforcement.CORRECTIVE,
            rules={
                "max_retention_period": "2_years",
                "retention_period_required": True
            }
        )
        
        # Data de 3 anos atrás
        old_date = (datetime.utcnow() - timedelta(days=3*365)).isoformat()
        context = {
            "metadata": {
                "retention_period": "5_years",  # Excede o limite
                "created_at": old_date
            }
        }
        
        # Act
        violations = await policy_engine._evaluate_data_retention_policy(policy, context)
        
        # Assert
        assert len(violations) > 0
        assert violations[0].violation_type == "retention_period_exceeded"
    
    @pytest.mark.asyncio
    async def test_evaluate_audit_logging_policy_compliant(self, policy_engine, sample_context):
        """Testa avaliação de política de auditoria (conforme)"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Audit Policy",
            category=PolicyCategory.AUDIT_LOGGING,
            enforcement=PolicyEnforcement.DETECTIVE,
            rules={
                "audit_required": True,
                "log_retention_days": 365,
                "sensitive_actions_logged": True
            }
        )
        
        # Act
        violations = await policy_engine._evaluate_audit_logging_policy(policy, sample_context)
        
        # Assert
        assert len(violations) == 0  # Sem violações (contexto tem auditoria)
    
    @pytest.mark.asyncio
    async def test_evaluate_data_quality_policy_compliant(self, policy_engine):
        """Testa avaliação de política de qualidade de dados (conforme)"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Quality Policy",
            category=PolicyCategory.DATA_QUALITY,
            enforcement=PolicyEnforcement.PREVENTIVE,
            rules={
                "min_quality_score": 85.0,
                "completeness_threshold": 95.0,
                "accuracy_threshold": 98.0
            }
        )
        
        context = {
            "quality_metrics": {
                "overall_score": 92.0,  # Acima do mínimo
                "completeness": 97.0,   # Acima do threshold
                "accuracy": 99.0        # Acima do threshold
            }
        }
        
        # Act
        violations = await policy_engine._evaluate_data_quality_policy(policy, context)
        
        # Assert
        assert len(violations) == 0  # Sem violações
    
    @pytest.mark.asyncio
    async def test_evaluate_data_quality_policy_below_threshold(self, policy_engine):
        """Testa avaliação de política de qualidade abaixo do threshold"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Quality Policy",
            category=PolicyCategory.DATA_QUALITY,
            enforcement=PolicyEnforcement.PREVENTIVE,
            rules={
                "min_quality_score": 85.0,
                "completeness_threshold": 95.0
            }
        )
        
        context = {
            "quality_metrics": {
                "overall_score": 70.0,  # Abaixo do mínimo
                "completeness": 80.0    # Abaixo do threshold
            }
        }
        
        # Act
        violations = await policy_engine._evaluate_data_quality_policy(policy, context)
        
        # Assert
        assert len(violations) > 0
        assert any(v.violation_type == "quality_below_threshold" for v in violations)
    
    @pytest.mark.asyncio
    async def test_calculate_compliance_score_perfect_compliance(self, policy_engine, sample_policies):
        """Testa cálculo de score de compliance perfeito"""
        # Arrange
        violations = []  # Sem violações
        
        # Act
        score = policy_engine._calculate_compliance_score(sample_policies, violations)
        
        # Assert
        assert score == 100.0
    
    @pytest.mark.asyncio
    async def test_calculate_compliance_score_with_violations(self, policy_engine, sample_policies):
        """Testa cálculo de score de compliance com violações"""
        # Arrange
        violations = [
            PolicyViolation(
                policy_id=sample_policies[0].id,
                policy_category=PolicyCategory.DATA_CLASSIFICATION,
                violation_type="missing_classification",
                severity="high",
                message="Classificação de dados ausente"
            ),
            PolicyViolation(
                policy_id=sample_policies[1].id,
                policy_category=PolicyCategory.PRIVACY_PROTECTION,
                violation_type="missing_legal_basis",
                severity="medium",
                message="Base legal ausente"
            )
        ]
        
        # Act
        score = policy_engine._calculate_compliance_score(sample_policies, violations)
        
        # Assert
        assert score < 100.0  # Score reduzido devido às violações
        assert score >= 0.0   # Score não pode ser negativo
    
    @pytest.mark.asyncio
    async def test_generate_compliance_dashboard(self, policy_engine, sample_policies, sample_context):
        """Testa geração de dashboard de compliance"""
        # Arrange
        evaluation_result = await policy_engine.evaluate_policies(sample_policies, sample_context)
        
        # Act
        dashboard = policy_engine.generate_compliance_dashboard([evaluation_result])
        
        # Assert
        assert isinstance(dashboard, ComplianceDashboard)
        assert dashboard.total_evaluations == 1
        assert dashboard.overall_compliance_score >= 0.0
        assert dashboard.overall_compliance_score <= 100.0
        assert len(dashboard.compliance_by_category) > 0
        assert len(dashboard.violations_by_severity) >= 0
        assert len(dashboard.trends) >= 0
        assert dashboard.generated_at is not None
    
    @pytest.mark.asyncio
    async def test_generate_remediation_suggestions_for_violations(self, policy_engine):
        """Testa geração de sugestões de remediação para violações"""
        # Arrange
        violations = [
            PolicyViolation(
                policy_id=uuid4(),
                policy_category=PolicyCategory.DATA_CLASSIFICATION,
                violation_type="missing_classification",
                severity="high",
                message="Dados sem classificação"
            ),
            PolicyViolation(
                policy_id=uuid4(),
                policy_category=PolicyCategory.ACCESS_CONTROL,
                violation_type="unauthorized_access",
                severity="critical",
                message="Acesso não autorizado"
            )
        ]
        
        # Act
        suggestions = policy_engine._generate_remediation_suggestions(violations)
        
        # Assert
        assert len(suggestions) > 0
        assert all(isinstance(s, PolicyRecommendation) for s in suggestions)
        
        # Verificar se há sugestões específicas para cada tipo de violação
        classification_suggestions = [s for s in suggestions if "classificação" in s.description.lower()]
        access_suggestions = [s for s in suggestions if "acesso" in s.description.lower()]
        
        assert len(classification_suggestions) > 0
        assert len(access_suggestions) > 0
    
    @pytest.mark.asyncio
    async def test_auto_remediation_corrective_enforcement(self, policy_engine):
        """Testa remediação automática para enforcement corrective"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Auto Remediation Policy",
            category=PolicyCategory.DATA_RETENTION,
            enforcement=PolicyEnforcement.CORRECTIVE,
            rules={
                "auto_remediation_enabled": True,
                "max_retention_period": "1_year"
            }
        )
        
        violation = PolicyViolation(
            policy_id=policy.id,
            policy_category=PolicyCategory.DATA_RETENTION,
            violation_type="retention_period_exceeded",
            severity="medium",
            message="Período de retenção excedido"
        )
        
        # Act
        remediation_actions = await policy_engine._execute_auto_remediation(policy, violation)
        
        # Assert
        assert len(remediation_actions) > 0
        assert all(isinstance(action, RemediationAction) for action in remediation_actions)
        
        # Verificar se ação de purge foi criada
        purge_actions = [a for a in remediation_actions if a.action_type == "data_purge"]
        assert len(purge_actions) > 0
    
    @pytest.mark.asyncio
    async def test_filter_applicable_policies(self, policy_engine, sample_policies):
        """Testa filtro de políticas aplicáveis ao contexto"""
        # Arrange
        context = {
            "resource_type": "dataset",
            "data_classification": "CONFIDENTIAL"
        }
        
        # Act
        applicable_policies = policy_engine._filter_applicable_policies(sample_policies, context)
        
        # Assert
        assert len(applicable_policies) > 0
        assert len(applicable_policies) <= len(sample_policies)
        
        # Verificar se todas as políticas aplicáveis são relevantes
        for policy in applicable_policies:
            scope = policy.scope or {}
            applies_to = scope.get("applies_to", [])
            
            # Se a política tem escopo definido, deve ser aplicável
            if applies_to:
                assert any(
                    resource_type in applies_to or "all_resources" in applies_to
                    for resource_type in ["datasets", "all_resources"]
                )
    
    @pytest.mark.asyncio
    async def test_policy_evaluation_with_exceptions(self, policy_engine):
        """Testa avaliação de política com exceções definidas"""
        # Arrange
        policy = GovernancePolicy(
            id=uuid4(),
            name="Policy with Exceptions",
            category=PolicyCategory.DATA_CLASSIFICATION,
            enforcement=PolicyEnforcement.PREVENTIVE,
            rules={"required_classification": True},
            scope={
                "applies_to": ["datasets"],
                "exceptions": ["test_dataset", "temp_data"]
            }
        )
        
        context = {
            "resource_type": "dataset",
            "resource_id": "test_dataset",  # Está nas exceções
            "data_classification": None
        }
        
        # Act
        violations = await policy_engine._evaluate_data_classification_policy(policy, context)
        
        # Assert
        assert len(violations) == 0  # Sem violações devido à exceção
    
    @pytest.mark.asyncio
    async def test_policy_evaluation_performance_large_context(self, policy_engine, sample_policies):
        """Testa performance da avaliação com contexto grande"""
        # Arrange
        large_context = {
            "resource_type": "dataset",
            "data_classification": "CONFIDENTIAL",
            "user_id": "analyst001",
            "user_role": "data_analyst",
            "action": "read",
            "metadata": {
                f"field_{i}": f"value_{i}" for i in range(1000)  # 1000 campos de metadata
            }
        }
        
        # Act
        start_time = datetime.utcnow()
        result = await policy_engine.evaluate_policies(sample_policies, large_context)
        end_time = datetime.utcnow()
        
        # Assert
        execution_time = (end_time - start_time).total_seconds()
        assert execution_time < 5.0  # Deve executar em menos de 5 segundos
        assert isinstance(result, PolicyEvaluationResult)
    
    @pytest.mark.asyncio
    async def test_error_handling_invalid_policy_configuration(self, policy_engine):
        """Testa tratamento de erro com configuração de política inválida"""
        # Arrange
        invalid_policy = GovernancePolicy(
            id=uuid4(),
            name="Invalid Policy",
            category=PolicyCategory.DATA_CLASSIFICATION,
            enforcement=PolicyEnforcement.PREVENTIVE,
            rules=None  # Regras inválidas
        )
        
        context = {"resource_type": "dataset"}
        
        # Act & Assert
        with pytest.raises(ValueError, match="Política com configuração inválida"):
            await policy_engine.evaluate_policies([invalid_policy], context)
    
    @pytest.mark.asyncio
    async def test_error_handling_empty_context(self, policy_engine, sample_policies):
        """Testa tratamento de erro com contexto vazio"""
        # Act & Assert
        with pytest.raises(ValueError, match="Contexto não pode estar vazio"):
            await policy_engine.evaluate_policies(sample_policies, {})
    
    @pytest.mark.asyncio
    async def test_policy_versioning_support(self, policy_engine):
        """Testa suporte a versionamento de políticas"""
        # Arrange
        policy_v1 = GovernancePolicy(
            id=uuid4(),
            name="Versioned Policy",
            version="1.0.0",
            category=PolicyCategory.DATA_CLASSIFICATION,
            enforcement=PolicyEnforcement.PREVENTIVE,
            rules={"required_classification": True}
        )
        
        policy_v2 = GovernancePolicy(
            id=uuid4(),
            name="Versioned Policy",
            version="2.0.0",
            category=PolicyCategory.DATA_CLASSIFICATION,
            enforcement=PolicyEnforcement.PREVENTIVE,
            rules={
                "required_classification": True,
                "additional_metadata_required": True  # Nova regra
            }
        )
        
        context = {
            "resource_type": "dataset",
            "data_classification": "CONFIDENTIAL"
        }
        
        # Act
        result_v1 = await policy_engine.evaluate_policies([policy_v1], context)
        result_v2 = await policy_engine.evaluate_policies([policy_v2], context)
        
        # Assert
        assert result_v1.overall_compliance_score >= result_v2.overall_compliance_score
        # V2 pode ter score menor devido à regra adicional
    
    @pytest.mark.asyncio
    async def test_policy_inheritance_and_override(self, policy_engine):
        """Testa herança e override de políticas"""
        # Arrange
        base_policy = GovernancePolicy(
            id=uuid4(),
            name="Base Policy",
            category=PolicyCategory.DATA_CLASSIFICATION,
            enforcement=PolicyEnforcement.ADVISORY,
            rules={"required_classification": True},
            scope={"applies_to": ["all_resources"]}
        )
        
        override_policy = GovernancePolicy(
            id=uuid4(),
            name="Override Policy",
            category=PolicyCategory.DATA_CLASSIFICATION,
            enforcement=PolicyEnforcement.PREVENTIVE,  # Enforcement mais restritivo
            rules={"required_classification": True},
            scope={"applies_to": ["sensitive_datasets"]},
            parent_policy_id=base_policy.id
        )
        
        context = {
            "resource_type": "dataset",
            "resource_category": "sensitive_datasets",
            "data_classification": None
        }
        
        # Act
        result = await policy_engine.evaluate_policies([base_policy, override_policy], context)
        
        # Assert
        # Override policy deve ter precedência
        assert any(
            v.policy_id == override_policy.id 
            for v in result.violations
        )


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

