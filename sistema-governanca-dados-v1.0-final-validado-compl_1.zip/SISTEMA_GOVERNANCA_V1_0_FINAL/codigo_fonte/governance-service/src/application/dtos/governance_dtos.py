# Autor: carlos.morais@f1rst.com.br
"""
Governance Service DTOs
Data Transfer Objects for governance policies and compliance operations
"""

import json
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Union
from uuid import UUID
from enum import Enum
from pydantic import BaseModel, Field, validator, root_validator


# ============================================================================
# ENUMS
# ============================================================================

class PolicyType(str, Enum):
    """Policy types"""
    DATA_ACCESS = "data_access"
    DATA_RETENTION = "data_retention"
    DATA_CLASSIFICATION = "data_classification"
    PII_PROTECTION = "pii_protection"
    LGPD_COMPLNCE = "lgpd_compliance"
    DATA_QUALITY = "data_quality"
    DATA_LINEAGE = "data_lineage"
    AUDIT_LOGGING = "audit_logging"
    CUSTOM_POLICY = "custom_policy"


class PolicyStatus(str, Enum):
    """Policy status"""
    DRAFT = "draft"
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEPRECATED = "deprecated"
    UNDER_REVIEW = "under_review"


class ComplianceStatus(str, Enum):
    """Compliance status"""
    COMPLNT = "compliant"
    NON_COMPLNT = "non_compliant"
    PARTLLY_COMPLNT = "partially_compliant"
    UNDER_REVIEW = "under_review"
    EXEMPTED = "exempted"


class ViolationSeverity(str, Enum):
    """Violation severity levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ActionType(str, Enum):
    """Action types for policy enforcement"""
    ALLOW = "allow"
    DENY = "deny"
    WARN = "warn"
    LOG = "log"
    MASK = "mask"
    ENCRYPT = "encrypt"
    QUARANTINE = "quarantine"


class LGPDLegalBasis(str, Enum):
    """LGPD legal basis"""
    CONSENT = "consent"
    CONTRACT = "contract"
    LEGAL_OBLIGATION = "legal_obligation"
    VITAL_INTERESTS = "vital_interests"
    PUBLIC_TASK = "public_task"
    LEGITIMATE_INTERESTS = "legitimate_interests"


class DataSubjectRights(str, Enum):
    """LGPD data subject rights"""
    ACCESS = "access"
    RECTIFICATION = "rectification"
    ERASURE = "erasure"
    PORTABILITY = "portability"
    OBJECTION = "objection"
    RESTRICTION = "restriction"
    AUTOMATED_DECISION = "automated_decision"


class RetentionPeriodUnit(str, Enum):
    """Retention period units"""
    DAYS = "days"
    MONTHS = "months"
    YEARS = "years"


class AuditEventType(str, Enum):
    """Audit event types"""
    POLICY_CREATED = "policy_created"
    POLICY_UPDATED = "policy_updated"
    POLICY_ACTIVATED = "policy_activated"
    POLICY_DEACTIVATED = "policy_deactivated"
    VIOLATION_DETECTED = "violation_detected"
    COMPLNCE_CHECK = "compliance_check"
    DATA_ACCESS = "data_access"
    DATA_EXPORT = "data_export"
    DATA_DELETION = "data_deletion"


# ============================================================================
# SUPPORTING DTOs
# ============================================================================

class PolicyRuleDTO(BaseModel):
    """Policy rule configuration"""
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    condition: str = Field(..., min_length=1)  # JSONPath or OPA Rego expression
    action: ActionType
    parameters: Optional[Dict[str, Any]] = None
    enabled: bool = True
    priority: int = Field(1, ge=1, le=100)


class LGPDComplianceConfigDTO(BaseModel):
    """LGPD compliance configuration"""
    legal_basis: LGPDLegalBasis
    purpose: str = Field(..., min_length=1, max_length=500)
    data_categories: List[str] = Field(..., min_items=1)
    retention_period: int = Field(..., ge=1)
    retention_unit: RetentionPeriodUnit
    consent_required: bool = False
    automated_processing: bool = False
    cross_border_transfer: bool = False
    data_subject_rights: List[DataSubjectRights] = Field(default_factory=list)


class RetentionPolicyDTO(BaseModel):
    """Data retention policy configuration"""
    retention_period: int = Field(..., ge=1)
    retention_unit: RetentionPeriodUnit
    auto_delete: bool = False
    archive_before_delete: bool = True
    notification_before_delete: bool = True
    notification_days: int = Field(30, ge=1, le=365)
    exceptions: Optional[List[str]] = None


class AccessControlDTO(BaseModel):
    """Access control configuration"""
    allowed_roles: List[str] = Field(..., min_items=1)
    denied_roles: Optional[List[str]] = None
    allowed_users: Optional[List[UUID]] = None
    denied_users: Optional[List[UUID]] = None
    time_restrictions: Optional[Dict[str, Any]] = None
    ip_restrictions: Optional[List[str]] = None
    conditions: Optional[List[str]] = None


class DataClassificationDTO(BaseModel):
    """Data classification configuration"""
    classification_level: str = Field(..., regex="^(public|internal|confidential|restricted|pii|sensitive)$")
    sensitivity_score: float = Field(..., ge=0.0, le=10.0)
    handling_requirements: List[str] = Field(default_factory=list)
    encryption_required: bool = False
    masking_required: bool = False
    audit_required: bool = True


class PolicyViolationDTO(BaseModel):
    """Policy violation details"""
    violation_id: UUID
    policy_id: UUID
    policy_name: str
    resource_id: Optional[UUID] = None
    resource_type: Optional[str] = None
    user_id: Optional[UUID] = None
    severity: ViolationSeverity
    description: str
    details: Optional[Dict[str, Any]] = None
    detected_at: datetime
    resolved_at: Optional[datetime] = None
    resolution_notes: Optional[str] = None


class ComplianceAssessmentDTO(BaseModel):
    """Compliance assessment result"""
    assessment_id: UUID
    policy_id: UUID
    resource_id: UUID
    status: ComplianceStatus
    score: float = Field(ge=0.0, le=100.0)
    findings: List[str] = Field(default_factory=list)
    recommendations: List[str] = Field(default_factory=list)
    assessed_at: datetime
    next_assessment: Optional[datetime] = None


class AuditLogEntryDTO(BaseModel):
    """Audit log entry"""
    log_id: UUID
    event_type: AuditEventType
    user_id: Optional[UUID] = None
    resource_id: Optional[UUID] = None
    resource_type: Optional[str] = None
    policy_id: Optional[UUID] = None
    action: str
    result: str
    details: Optional[Dict[str, Any]] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    timestamp: datetime


# ============================================================================
# REQUEST DTOs
# ============================================================================

class CreateGovernancePolicyRequest(BaseModel):
    """Create governance policy request"""
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    policy_type: PolicyType
    organization_id: UUID
    rules: List[PolicyRuleDTO] = Field(..., min_items=1, max_items=50)
    lgpd_config: Optional[LGPDComplianceConfigDTO] = None
    retention_config: Optional[RetentionPolicyDTO] = None
    access_control: Optional[AccessControlDTO] = None
    classification_config: Optional[DataClassificationDTO] = None
    applies_to: List[str] = Field(..., min_items=1)  # Resource types or patterns
    tags: Optional[List[str]] = Field(None, max_items=20)
    enabled: bool = True
    effective_date: Optional[datetime] = None
    expiry_date: Optional[datetime] = None

    @validator('rules')
    def validate_rules(cls, v):
        """Validate policy rules"""
        rule_names = [rule.name for rule in v]
        if len(rule_names) != len(set(rule_names)):
            raise ValueError("Rule names must be unique within policy")
        return v

    @root_validator
    def validate_lgpd_config(cls, values):
        """Validate LGPD configuration"""
        policy_type = values.get('policy_type')
        lgpd_config = values.get('lgpd_config')
        
        if policy_type == PolicyType.LGPD_COMPLNCE and not lgpd_config:
            raise ValueError("LGPD configuration is required for LGPD compliance policies")
        
        return values


class UpdateGovernancePolicyRequest(BaseModel):
    """Update governance policy request"""
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    rules: Optional[List[PolicyRuleDTO]] = Field(None, min_items=1, max_items=50)
    lgpd_config: Optional[LGPDComplianceConfigDTO] = None
    retention_config: Optional[RetentionPolicyDTO] = None
    access_control: Optional[AccessControlDTO] = None
    classification_config: Optional[DataClassificationDTO] = None
    applies_to: Optional[List[str]] = None
    tags: Optional[List[str]] = Field(None, max_items=20)
    enabled: Optional[bool] = None
    effective_date: Optional[datetime] = None
    expiry_date: Optional[datetime] = None

    @validator('rules')
    def validate_rules(cls, v):
        """Validate policy rules"""
        if v is not None:
            rule_names = [rule.name for rule in v]
            if len(rule_names) != len(set(rule_names)):
                raise ValueError("Rule names must be unique within policy")
        return v


class PolicySearchRequest(BaseModel):
    """Policy search request"""
    query: Optional[str] = Field(None, min_length=1, max_length=200)
    policy_type: Optional[PolicyType] = None
    status: Optional[PolicyStatus] = None
    organization_id: Optional[UUID] = None
    created_by: Optional[UUID] = None
    tags: Optional[List[str]] = None
    enabled: Optional[bool] = None
    applies_to: Optional[str] = None
    created_after: Optional[datetime] = None
    created_before: Optional[datetime] = None


class PolicyFilterRequest(BaseModel):
    """Policy filter request"""
    organization_id: Optional[UUID] = None
    policy_type: Optional[PolicyType] = None
    status: Optional[PolicyStatus] = None
    created_by: Optional[UUID] = None
    enabled: Optional[bool] = None
    has_violations: Optional[bool] = None
    effective_after: Optional[datetime] = None
    effective_before: Optional[datetime] = None
    expires_after: Optional[datetime] = None
    expires_before: Optional[datetime] = None


class ComplianceCheckRequest(BaseModel):
    """Compliance check request"""
    resource_id: UUID
    resource_type: str = Field(..., min_length=1, max_length=100)
    policy_ids: Optional[List[UUID]] = None  # If None, check all applicable policies
    context: Optional[Dict[str, Any]] = None


class ViolationReportRequest(BaseModel):
    """Violation report request"""
    policy_id: UUID
    resource_id: Optional[UUID] = None
    resource_type: Optional[str] = None
    user_id: Optional[UUID] = None
    severity: ViolationSeverity
    description: str = Field(..., min_length=1, max_length=1000)
    details: Optional[Dict[str, Any]] = None


class ViolationResolutionRequest(BaseModel):
    """Violation resolution request"""
    resolution_notes: str = Field(..., min_length=1, max_length=1000)
    resolved_by: UUID


class AuditLogRequest(BaseModel):
    """Audit log request"""
    event_type: AuditEventType
    user_id: Optional[UUID] = None
    resource_id: Optional[UUID] = None
    resource_type: Optional[str] = None
    policy_id: Optional[UUID] = None
    action: str = Field(..., min_length=1, max_length=200)
    result: str = Field(..., min_length=1, max_length=200)
    details: Optional[Dict[str, Any]] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None


class AuditLogFilterRequest(BaseModel):
    """Audit log filter request"""
    organization_id: Optional[UUID] = None
    event_type: Optional[AuditEventType] = None
    user_id: Optional[UUID] = None
    resource_id: Optional[UUID] = None
    resource_type: Optional[str] = None
    policy_id: Optional[UUID] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None


# ============================================================================
# RESPONSE DTOs
# ============================================================================

class GovernancePolicyResponse(BaseModel):
    """Governance policy response"""
    id: UUID
    name: str
    description: Optional[str]
    policy_type: PolicyType
    status: PolicyStatus
    organization_id: UUID
    organization_name: str
    created_by: UUID
    created_by_name: str
    rules: List[PolicyRuleDTO]
    lgpd_config: Optional[LGPDComplianceConfigDTO]
    retention_config: Optional[RetentionPolicyDTO]
    access_control: Optional[AccessControlDTO]
    classification_config: Optional[DataClassificationDTO]
    applies_to: List[str]
    tags: Optional[List[str]]
    enabled: bool
    effective_date: Optional[datetime]
    expiry_date: Optional[datetime]
    violation_count: int
    last_violation: Optional[datetime]
    compliance_score: float = Field(ge=0.0, le=100.0)
    created_at: datetime
    updated_at: datetime


class GovernancePolicyListResponse(BaseModel):
    """Governance policy list response"""
    policies: List[GovernancePolicyResponse]
    total: int
    limit: int
    offset: int
    has_more: bool


class ComplianceCheckResponse(BaseModel):
    """Compliance check response"""
    resource_id: UUID
    resource_type: str
    overall_status: ComplianceStatus
    overall_score: float = Field(ge=0.0, le=100.0)
    assessments: List[ComplianceAssessmentDTO]
    violations: List[PolicyViolationDTO]
    recommendations: List[str]
    checked_at: datetime


class PolicyViolationResponse(BaseModel):
    """Policy violation response"""
    violation: PolicyViolationDTO
    policy: GovernancePolicyResponse


class PolicyViolationListResponse(BaseModel):
    """Policy violation list response"""
    violations: List[PolicyViolationResponse]
    total: int
    limit: int
    offset: int
    has_more: bool


class GovernanceStatisticsResponse(BaseModel):
    """Governance statistics response"""
    organization_id: UUID
    total_policies: int
    active_policies: int
    total_violations: int
    open_violations: int
    resolved_violations: int
    compliance_score: float = Field(ge=0.0, le=100.0)
    policies_by_type: Dict[str, int]
    policies_by_status: Dict[str, int]
    violations_by_severity: Dict[str, int]
    violations_by_policy: List[Dict[str, Any]]
    recent_violations: List[Dict[str, Any]]
    compliance_trends: List[Dict[str, Any]]


class LGPDComplianceReportResponse(BaseModel):
    """LGPD compliance report response"""
    organization_id: UUID
    overall_compliance_score: float = Field(ge=0.0, le=100.0)
    total_data_subjects: int
    consent_coverage: float = Field(ge=0.0, le=100.0)
    data_retention_compliance: float = Field(ge=0.0, le=100.0)
    data_subject_requests: Dict[str, int]
    privacy_impact_assessments: int
    data_breaches: int
    compliance_by_legal_basis: Dict[str, float]
    recommendations: List[str]
    generated_at: datetime


class AuditLogResponse(BaseModel):
    """Audit log response"""
    log_entry: AuditLogEntryDTO


class AuditLogListResponse(BaseModel):
    """Audit log list response"""
    logs: List[AuditLogEntryDTO]
    total: int
    limit: int
    offset: int
    has_more: bool


class PolicyValidationResponse(BaseModel):
    """Policy validation response"""
    is_valid: bool
    errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    suggestions: List[str] = Field(default_factory=list)


class GovernanceDashboardResponse(BaseModel):
    """Governance dashboard response"""
    organization_id: UUID
    compliance_overview: Dict[str, Any]
    policy_summary: Dict[str, Any]
    violation_summary: Dict[str, Any]
    recent_activities: List[Dict[str, Any]]
    compliance_trends: List[Dict[str, Any]]
    top_violations: List[Dict[str, Any]]
    generated_at: datetime


# ============================================================================
# UTILITY DTOs
# ============================================================================

class PolicySummaryResponse(BaseModel):
    """Policy summary response"""
    id: UUID
    name: str
    policy_type: PolicyType
    status: PolicyStatus
    compliance_score: float
    violation_count: int
    enabled: bool


class ViolationSummaryResponse(BaseModel):
    """Violation summary response"""
    violation_id: UUID
    policy_name: str
    severity: ViolationSeverity
    description: str
    detected_at: datetime
    resolved: bool


class ComplianceMetricsResponse(BaseModel):
    """Compliance metrics response"""
    organization_id: UUID
    policy_id: Optional[UUID] = None
    compliance_score: float = Field(ge=0.0, le=100.0)
    total_checks: int
    passed_checks: int
    failed_checks: int
    last_check: Optional[datetime] = None
    trend: str = Field(regex="^(improving|declining|stable)$")


class GovernanceHealthResponse(BaseModel):
    """Governance health response"""
    organization_id: UUID
    health_score: float = Field(ge=0.0, le=100.0)
    policy_coverage: float = Field(ge=0.0, le=100.0)
    compliance_rate: float = Field(ge=0.0, le=100.0)
    violation_rate: float = Field(ge=0.0, le=100.0)
    issues: List[str] = Field(default_factory=list)
    recommendations: List[str] = Field(default_factory=list)
    last_assessment: datetime

