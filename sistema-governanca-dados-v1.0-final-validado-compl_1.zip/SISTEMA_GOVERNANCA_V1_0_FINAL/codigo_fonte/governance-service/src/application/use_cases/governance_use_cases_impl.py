# Autor: carlos.morais@f1rst.com.br
"""
Governance Service Use Cases Implementation
Complete implementation of all governance operations
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from uuid import UUID, uuid4

from ..dtos.governance_dtos import (
    # Request DTOs
    CreateGovernancePolicyRequest, UpdateGovernancePolicyRequest,
    PolicyFilterRequest, PolicySearchRequest, ComplianceAssessmentRequest,
    PolicyViolationRequest, AuditLogRequest,
    
    # Response DTOs
    GovernancePolicyResponse, GovernancePolicyListResponse,
    ComplianceAssessmentResponse, PolicyViolationResponse,
    GovernanceStatisticsResponse, AuditLogResponse, AuditLogListResponse,
    
    # Supporting DTOs
    PolicyRuleDTO, LGPDComplianceConfigDTO, RetentionPolicyDTO,
    AccessControlDTO, DataClassificationDTO, PolicyViolationDTO,
    ComplianceAssessmentDTO, AuditLogEntryDTO,
    
    # Enums
    PolicyType, PolicyStatus, ComplianceStatus, ViolationSeverity,
    ActionType, LGPDLegalBasis, DataSubjectRights, RetentionPeriodUnit,
    AuditEventType
)

from ...domain.entities.governance_policy import GovernancePolicy
from ...domain.repositories.governance_repository import GovernancePolicyRepository
from ...infrastructure.repositories.governance_repository_impl import GovernancePolicyRepositoryImpl

logger = logging.getLogger(__name__)


class GovernanceUseCases:
    """Use cases for governance operations"""
    
    def __init__(self, repository: GovernancePolicyRepository = None):
        self.repository = repository or GovernancePolicyRepositoryImpl()
    
    async def create_policy(self, request: CreateGovernancePolicyRequest, user_id: UUID) -> GovernancePolicyResponse:
        """Create a new governance policy"""
        try:
            logger.info(f"Creating governance policy: {request.name}")
            
            # Check if policy name already exists in organization
            existing = await self.repository.find_policy_by_name(request.name, request.organization_id)
            if existing:
                raise ValueError(f"Policy with name '{request.name}' already exists in this organization")
            
            # Create policy entity
            policy = GovernancePolicy(
                id=uuid4(),
                organization_id=request.organization_id,
                name=request.name,
                description=request.description,
                policy_type=request.policy_type,
                status=PolicyStatus.DRAFT,
                rules=request.rules or [],
                lgpd_config=request.lgpd_config,
                retention_policy=request.retention_policy,
                access_control=request.access_control,
                data_classification=request.data_classification,
                effective_date=request.effective_date,
                expiry_date=request.expiry_date,
                tags=request.tags or [],
                applies_to=request.applies_to or [],
                created_by=user_id,
                enabled=True,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            # Save policy
            saved_policy = await self.repository.save_policy(policy)
            
            # Log audit event
            await self._log_audit_event(
                AuditEventType.POLICY_CREATED,
                user_id,
                request.organization_id,
                policy_id=saved_policy.id,
                details={"policy_name": request.name, "policy_type": request.policy_type.value}
            )
            
            logger.info(f"Governance policy created successfully: {saved_policy.id}")
            return self._map_policy_to_response(saved_policy)
            
        except Exception as e:
            logger.error(f"Error creating governance policy: {e}")
            raise
    
    async def update_policy(self, policy_id: UUID, request: UpdateGovernancePolicyRequest, user_id: UUID) -> GovernancePolicyResponse:
        """Update an existing governance policy"""
        try:
            logger.info(f"Updating governance policy: {policy_id}")
            
            # Get existing policy
            policy = await self.repository.find_policy_by_id(policy_id)
            if not policy:
                raise ValueError(f"Policy not found: {policy_id}")
            
            # Check if name is being changed and if it conflicts
            if request.name and request.name != policy.name:
                existing = await self.repository.find_policy_by_name(request.name, policy.organization_id)
                if existing and existing.id != policy_id:
                    raise ValueError(f"Policy with name '{request.name}' already exists in this organization")
            
            # Update fields
            if request.name:
                policy.name = request.name
            if request.description is not None:
                policy.description = request.description
            if request.policy_type:
                policy.policy_type = request.policy_type
            if request.status:
                policy.status = request.status
            if request.rules is not None:
                policy.rules = request.rules
            if request.lgpd_config is not None:
                policy.lgpd_config = request.lgpd_config
            if request.retention_policy is not None:
                policy.retention_policy = request.retention_policy
            if request.access_control is not None:
                policy.access_control = request.access_control
            if request.data_classification is not None:
                policy.data_classification = request.data_classification
            if request.effective_date is not None:
                policy.effective_date = request.effective_date
            if request.expiry_date is not None:
                policy.expiry_date = request.expiry_date
            if request.tags is not None:
                policy.tags = request.tags
            if request.applies_to is not None:
                policy.applies_to = request.applies_to
            if request.enabled is not None:
                policy.enabled = request.enabled
            
            policy.updated_at = datetime.utcnow()
            
            # Save updated policy
            updated_policy = await self.repository.save_policy(policy)
            
            # Log audit event
            await self._log_audit_event(
                AuditEventType.POLICY_UPDATED,
                user_id,
                policy.organization_id,
                policy_id=policy_id,
                details={"changes": request.dict(exclude_unset=True)}
            )
            
            logger.info(f"Governance policy updated successfully: {policy_id}")
            return self._map_policy_to_response(updated_policy)
            
        except Exception as e:
            logger.error(f"Error updating governance policy: {e}")
            raise
    
    async def get_policy(self, policy_id: UUID) -> GovernancePolicyResponse:
        """Get a specific governance policy"""
        try:
            logger.info(f"Getting governance policy: {policy_id}")
            
            policy = await self.repository.find_policy_by_id(policy_id)
            if not policy:
                raise ValueError(f"Policy not found: {policy_id}")
            
            return self._map_policy_to_response(policy)
            
        except Exception as e:
            logger.error(f"Error getting governance policy: {e}")
            raise
    
    async def list_policies(self, organization_id: UUID, page: int = 1, size: int = 20) -> GovernancePolicyListResponse:
        """List governance policies with pagination"""
        try:
            logger.info(f"Listing governance policies for organization: {organization_id}")
            
            policies, total = await self.repository.find_policies_by_organization(
                organization_id, page, size
            )
            
            policy_responses = [self._map_policy_to_response(policy) for policy in policies]
            
            return GovernancePolicyListResponse(
                policies=policy_responses,
                total=total,
                page=page,
                size=size,
                pages=(total + size - 1) // size
            )
            
        except Exception as e:
            logger.error(f"Error listing governance policies: {e}")
            raise
    
    async def search_policies(self, request: PolicySearchRequest) -> GovernancePolicyListResponse:
        """Search governance policies with text query"""
        try:
            logger.info(f"Searching governance policies: {request.query}")
            
            policies, total = await self.repository.search_policies(
                request.organization_id,
                request.query,
                request.page,
                request.size
            )
            
            policy_responses = [self._map_policy_to_response(policy) for policy in policies]
            
            return GovernancePolicyListResponse(
                policies=policy_responses,
                total=total,
                page=request.page,
                size=request.size,
                pages=(total + request.size - 1) // request.size
            )
            
        except Exception as e:
            logger.error(f"Error searching governance policies: {e}")
            raise
    
    async def filter_policies(self, request: PolicyFilterRequest) -> GovernancePolicyListResponse:
        """Filter governance policies with advanced criteria"""
        try:
            logger.info(f"Filtering governance policies with {len(request.dict(exclude_unset=True))} criteria")
            
            policies, total = await self.repository.filter_policies(request)
            
            policy_responses = [self._map_policy_to_response(policy) for policy in policies]
            
            return GovernancePolicyListResponse(
                policies=policy_responses,
                total=total,
                page=request.page,
                size=request.size,
                pages=(total + request.size - 1) // request.size
            )
            
        except Exception as e:
            logger.error(f"Error filtering governance policies: {e}")
            raise
    
    async def delete_policy(self, policy_id: UUID, user_id: UUID) -> bool:
        """Delete a governance policy (soft delete)"""
        try:
            logger.info(f"Deleting governance policy: {policy_id}")
            
            # Get policy to verify it exists
            policy = await self.repository.find_policy_by_id(policy_id)
            if not policy:
                raise ValueError(f"Policy not found: {policy_id}")
            
            # Perform soft delete
            success = await self.repository.delete_policy(policy_id)
            
            if success:
                # Log audit event
                await self._log_audit_event(
                    AuditEventType.POLICY_DELETED,
                    user_id,
                    policy.organization_id,
                    policy_id=policy_id,
                    details={"policy_name": policy.name}
                )
                
                logger.info(f"Governance policy deleted successfully: {policy_id}")
            
            return success
            
        except Exception as e:
            logger.error(f"Error deleting governance policy: {e}")
            raise
    
    async def assess_compliance(self, request: ComplianceAssessmentRequest, user_id: UUID) -> ComplianceAssessmentResponse:
        """Assess compliance for a resource against policies"""
        try:
            logger.info(f"Assessing compliance for resource: {request.resource_id}")
            
            # Get active policies for the organization
            active_policies = await self.repository.find_active_policies(request.organization_id)
            
            # Filter policies that apply to this resource
            applicable_policies = [
                policy for policy in active_policies
                if not policy.applies_to or request.resource_type in policy.applies_to
            ]
            
            # Assess compliance against each policy
            assessments = []
            overall_score = 0.0
            total_weight = 0.0
            
            for policy in applicable_policies:
                assessment = await self._assess_policy_compliance(policy, request)
                assessments.append(assessment)
                
                # Weight by policy criticality (LGPD policies have higher weight)
                weight = 2.0 if policy.policy_type == PolicyType.LGPD_COMPLNCE else 1.0
                overall_score += assessment.compliance_score * weight
                total_weight += weight
            
            # Calculate overall compliance score
            final_score = overall_score / total_weight if total_weight > 0 else 100.0
            
            # Determine overall status
            if final_score >= 90:
                overall_status = ComplianceStatus.COMPLNT
            elif final_score >= 70:
                overall_status = ComplianceStatus.PARTLLY_COMPLNT
            else:
                overall_status = ComplianceStatus.NON_COMPLNT
            
            # Log audit event
            await self._log_audit_event(
                AuditEventType.COMPLNCE_ASSESSED,
                user_id,
                request.organization_id,
                resource_id=request.resource_id,
                details={
                    "resource_type": request.resource_type,
                    "compliance_score": final_score,
                    "policies_assessed": len(applicable_policies)
                }
            )
            
            return ComplianceAssessmentResponse(
                resource_id=request.resource_id,
                resource_type=request.resource_type,
                organization_id=request.organization_id,
                overall_compliance_score=final_score,
                overall_status=overall_status,
                policy_assessments=assessments,
                assessment_date=datetime.utcnow(),
                recommendations=self._generate_compliance_recommendations(assessments)
            )
            
        except Exception as e:
            logger.error(f"Error assessing compliance: {e}")
            raise
    
    async def report_violation(self, request: PolicyViolationRequest, user_id: UUID) -> PolicyViolationResponse:
        """Report a policy violation"""
        try:
            logger.info(f"Reporting policy violation for policy: {request.policy_id}")
            
            # Verify policy exists
            policy = await self.repository.find_policy_by_id(request.policy_id)
            if not policy:
                raise ValueError(f"Policy not found: {request.policy_id}")
            
            # Create violation record
            violation = PolicyViolationDTO(
                id=uuid4(),
                policy_id=request.policy_id,
                resource_id=request.resource_id,
                resource_type=request.resource_type,
                violation_type=request.violation_type,
                severity=request.severity,
                description=request.description,
                detected_at=datetime.utcnow(),
                reported_by=user_id,
                status="open",
                resolution_notes=None,
                resolved_at=None,
                resolved_by=None
            )
            
            # Save violation
            saved_violation = await self.repository.save_violation(violation)
            
            # Log audit event
            await self._log_audit_event(
                AuditEventType.VIOLATION_REPORTED,
                user_id,
                policy.organization_id,
                policy_id=request.policy_id,
                resource_id=request.resource_id,
                details={
                    "violation_type": request.violation_type,
                    "severity": request.severity.value,
                    "resource_type": request.resource_type
                }
            )
            
            logger.info(f"Policy violation reported successfully: {saved_violation.id}")
            return PolicyViolationResponse(**saved_violation.dict())
            
        except Exception as e:
            logger.error(f"Error reporting policy violation: {e}")
            raise
    
    async def resolve_violation(self, violation_id: UUID, resolution_notes: str, user_id: UUID) -> PolicyViolationResponse:
        """Resolve a policy violation"""
        try:
            logger.info(f"Resolving policy violation: {violation_id}")
            
            # Get violation
            violation = await self.repository.find_violation_by_id(violation_id)
            if not violation:
                raise ValueError(f"Violation not found: {violation_id}")
            
            # Resolve violation
            resolved_violation = await self.repository.resolve_violation(
                violation_id, resolution_notes, user_id
            )
            
            # Log audit event
            await self._log_audit_event(
                AuditEventType.VIOLATION_RESOLVED,
                user_id,
                violation.organization_id,
                policy_id=violation.policy_id,
                resource_id=violation.resource_id,
                details={
                    "violation_id": str(violation_id),
                    "resolution_notes": resolution_notes
                }
            )
            
            logger.info(f"Policy violation resolved successfully: {violation_id}")
            return PolicyViolationResponse(**resolved_violation.dict())
            
        except Exception as e:
            logger.error(f"Error resolving policy violation: {e}")
            raise
    
    async def get_statistics(self, organization_id: UUID) -> GovernanceStatisticsResponse:
        """Get governance statistics for an organization"""
        try:
            logger.info(f"Getting governance statistics for organization: {organization_id}")
            
            stats = await self.repository.get_policy_statistics(organization_id)
            compliance_metrics = await self.repository.get_compliance_metrics(organization_id)
            
            return GovernanceStatisticsResponse(
                organization_id=organization_id,
                total_policies=stats.get('total_policies', 0),
                active_policies=stats.get('active_policies', 0),
                total_violations=stats.get('total_violations', 0),
                recent_violations=stats.get('recent_violations', 0),
                average_compliance_score=compliance_metrics.get('average_score', 0.0),
                policies_by_type=stats.get('policies_by_type', {}),
                policies_by_status=stats.get('policies_by_status', {}),
                violations_by_severity=compliance_metrics.get('violations_by_severity', {}),
                compliance_trend=compliance_metrics.get('trend', []),
                generated_at=datetime.utcnow()
            )
            
        except Exception as e:
            logger.error(f"Error getting governance statistics: {e}")
            raise
    
    async def get_audit_logs(self, request: AuditLogRequest) -> AuditLogListResponse:
        """Get audit logs with filtering"""
        try:
            logger.info(f"Getting audit logs for organization: {request.organization_id}")
            
            logs, total = await self.repository.find_audit_logs(request)
            
            log_responses = [
                AuditLogResponse(
                    id=log.id,
                    organization_id=log.organization_id,
                    event_type=log.event_type,
                    user_id=log.user_id,
                    user_name=log.user_name,
                    resource_type=log.resource_type,
                    resource_id=log.resource_id,
                    policy_id=log.policy_id,
                    ip_address=log.ip_address,
                    user_agent=log.user_agent,
                    details=log.details,
                    timestamp=log.timestamp
                )
                for log in logs
            ]
            
            return AuditLogListResponse(
                logs=log_responses,
                total=total,
                page=request.page,
                size=request.size,
                pages=(total + request.size - 1) // request.size
            )
            
        except Exception as e:
            logger.error(f"Error getting audit logs: {e}")
            raise
    
    # Helper methods
    
    def _map_policy_to_response(self, policy: GovernancePolicy) -> GovernancePolicyResponse:
        """Map policy entity to response DTO"""
        return GovernancePolicyResponse(
            id=policy.id,
            organization_id=policy.organization_id,
            organization_name=getattr(policy, 'organization_name', None),
            name=policy.name,
            description=policy.description,
            policy_type=policy.policy_type,
            status=policy.status,
            rules=policy.rules,
            lgpd_config=policy.lgpd_config,
            retention_policy=policy.retention_policy,
            access_control=policy.access_control,
            data_classification=policy.data_classification,
            effective_date=policy.effective_date,
            expiry_date=policy.expiry_date,
            tags=policy.tags,
            applies_to=policy.applies_to,
            created_by=policy.created_by,
            created_by_name=getattr(policy, 'created_by_name', None),
            enabled=policy.enabled,
            violation_count=getattr(policy, 'violation_count', 0),
            last_violation_date=getattr(policy, 'last_violation_date', None),
            created_at=policy.created_at,
            updated_at=policy.updated_at
        )
    
    async def _assess_policy_compliance(self, policy: GovernancePolicy, request: ComplianceAssessmentRequest) -> ComplianceAssessmentDTO:
        """Assess compliance for a single policy"""
        # This is a simplified compliance assessment
        # In a real implementation, this would involve complex rule evaluation
        
        score = 100.0
        violations = []
        
        # Basic compliance checks based on policy type
        if policy.policy_type == PolicyType.LGPD_COMPLNCE:
            # LGPD-specific compliance checks
            if not request.metadata.get('has_consent', False):
                score -= 30
                violations.append("Missing user consent for data processing")
            
            if not request.metadata.get('has_privacy_notice', False):
                score -= 20
                violations.append("Missing privacy notice")
            
            if request.metadata.get('contains_sensitive_data', False) and not request.metadata.get('has_encryption', False):
                score -= 25
                violations.append("Sensitive data not encrypted")
        
        elif policy.policy_type == PolicyType.DATA_RETENTION:
            # Data retention compliance checks
            retention_days = policy.retention_policy.period_value if policy.retention_policy else 365
            data_age_days = request.metadata.get('data_age_days', 0)
            
            if data_age_days > retention_days:
                score -= 50
                violations.append(f"Data exceeds retention period ({retention_days} days)")
        
        elif policy.policy_type == PolicyType.DATA_ACCESS:
            # Access control compliance checks
            if not request.metadata.get('has_access_controls', False):
                score -= 40
                violations.append("Missing access controls")
        
        # Determine status
        if score >= 90:
            status = ComplianceStatus.COMPLNT
        elif score >= 70:
            status = ComplianceStatus.PARTLLY_COMPLNT
        else:
            status = ComplianceStatus.NON_COMPLNT
        
        return ComplianceAssessmentDTO(
            policy_id=policy.id,
            policy_name=policy.name,
            policy_type=policy.policy_type,
            compliance_score=max(0.0, score),
            status=status,
            violations=violations,
            recommendations=self._generate_policy_recommendations(policy, violations),
            assessed_at=datetime.utcnow()
        )
    
    def _generate_compliance_recommendations(self, assessments: List[ComplianceAssessmentDTO]) -> List[str]:
        """Generate compliance recommendations based on assessments"""
        recommendations = []
        
        # Collect all violations
        all_violations = []
        for assessment in assessments:
            all_violations.extend(assessment.violations)
        
        # Generate recommendations based on common violations
        violation_counts = {}
        for violation in all_violations:
            violation_counts[violation] = violation_counts.get(violation, 0) + 1
        
        # Sort by frequency and generate recommendations
        for violation, count in sorted(violation_counts.items(), key=lambda x: x[1], reverse=True):
            if "consent" in violation.lower():
                recommendations.append("Implement consent management system for LGPD compliance")
            elif "encryption" in violation.lower():
                recommendations.append("Enable encryption for sensitive data fields")
            elif "access control" in violation.lower():
                recommendations.append("Configure role-based access controls")
            elif "retention" in violation.lower():
                recommendations.append("Implement automated data retention policies")
            elif "privacy notice" in violation.lower():
                recommendations.append("Add privacy notices to data collection points")
        
        return recommendations[:5]  # Return top 5 recommendations
    
    def _generate_policy_recommendations(self, policy: GovernancePolicy, violations: List[str]) -> List[str]:
        """Generate recommendations for a specific policy"""
        recommendations = []
        
        for violation in violations:
            if "consent" in violation.lower():
                recommendations.append("Add consent collection mechanism")
            elif "encryption" in violation.lower():
                recommendations.append("Enable field-level encryption")
            elif "access" in violation.lower():
                recommendations.append("Configure access restrictions")
            elif "retention" in violation.lower():
                recommendations.append("Set up automated data purging")
        
        return recommendations
    
    async def _log_audit_event(self, event_type: AuditEventType, user_id: UUID, organization_id: UUID, 
                              resource_type: str = None, resource_id: UUID = None, 
                              policy_id: UUID = None, details: Dict[str, Any] = None):
        """Log an audit event"""
        try:
            audit_entry = AuditLogEntryDTO(
                id=uuid4(),
                organization_id=organization_id,
                event_type=event_type,
                user_id=user_id,
                resource_type=resource_type,
                resource_id=resource_id,
                policy_id=policy_id,
                ip_address="127.0.0.1",  # In real implementation, get from request context
                user_agent="Governance Service",  # In real implementation, get from request context
                details=details or {},
                timestamp=datetime.utcnow()
            )
            
            await self.repository.save_audit_log(audit_entry)
            
        except Exception as e:
            logger.error(f"Error logging audit event: {e}")
            # Don't raise exception for audit logging failures

