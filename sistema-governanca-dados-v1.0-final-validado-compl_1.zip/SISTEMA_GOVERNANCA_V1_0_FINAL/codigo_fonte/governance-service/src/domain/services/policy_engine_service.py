# Autor: carlos.morais@f1rst.com.br
"""
Policy Engine Service - Engine Avançado de Políticas de Governança
"""

import asyncio
import json
import re
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Set, Tuple, Union
from uuid import UUID
from enum import Enum
from dataclasses import dataclass

from ..entities.governance_policy import GovernancePolicy, PolicyCategory, EnforcementLevel
from ..value_objects.policy_type import PolicyType, PolicyScope
from ..value_objects.compliance_status import ComplianceStatus


class PolicyEvaluationResult(Enum):
    """Resultado da avaliação de política"""
    COMPLIANT = "compliant"
    NON_COMPLIANT = "non_compliant"
    WARNING = "warning"
    ERROR = "error"
    NOT_APPLICABLE = "not_applicable"


class ActionType(Enum):
    """Tipos de ação que podem ser avaliadas"""
    DATA_ACCESS = "data_access"
    DATA_MODIFICATION = "data_modification"
    DATA_EXPORT = "data_export"
    DATA_DELETION = "data_deletion"
    SCHEMA_CHANGE = "schema_change"
    CONTRACT_CREATION = "contract_creation"
    CONTRACT_MODIFICATION = "contract_modification"
    USER_ACCESS = "user_access"
    SYSTEM_INTEGRATION = "system_integration"


@dataclass
class PolicyEvaluationContext:
    """Contexto para avaliação de políticas"""
    action_type: ActionType
    user_id: str
    user_roles: List[str]
    resource_id: Optional[str] = None
    resource_type: Optional[str] = None
    data_classification: Optional[str] = None
    dataset_id: Optional[UUID] = None
    contract_id: Optional[UUID] = None
    request_metadata: Dict[str, Any] = None
    timestamp: datetime = None
    source_system: Optional[str] = None
    target_system: Optional[str] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.utcnow()
        if self.request_metadata is None:
            self.request_metadata = {}


@dataclass
class PolicyViolation:
    """Violação de política detectada"""
    policy_id: UUID
    policy_name: str
    policy_category: PolicyCategory
    enforcement_level: EnforcementLevel
    violation_type: str
    severity: str
    message: str
    details: Dict[str, Any]
    context: PolicyEvaluationContext
    timestamp: datetime
    remediation_suggestions: List[str] = None
    
    def __post_init__(self):
        if self.remediation_suggestions is None:
            self.remediation_suggestions = []
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            "policy_id": str(self.policy_id),
            "policy_name": self.policy_name,
            "policy_category": self.policy_category.value,
            "enforcement_level": self.enforcement_level.value,
            "violation_type": self.violation_type,
            "severity": self.severity,
            "message": self.message,
            "details": self.details,
            "timestamp": self.timestamp.isoformat(),
            "remediation_suggestions": self.remediation_suggestions,
            "context": {
                "action_type": self.context.action_type.value,
                "user_id": self.context.user_id,
                "resource_id": self.context.resource_id,
                "data_classification": self.context.data_classification
            }
        }


@dataclass
class PolicyEvaluationReport:
    """Relatório de avaliação de políticas"""
    evaluation_id: UUID
    context: PolicyEvaluationContext
    policies_evaluated: int
    compliant_policies: int
    violations: List[PolicyViolation]
    warnings: List[PolicyViolation]
    overall_compliance: bool
    compliance_score: float
    execution_time_ms: float
    timestamp: datetime
    recommendations: List[str] = None
    
    def __post_init__(self):
        if self.recommendations is None:
            self.recommendations = []
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            "evaluation_id": str(self.evaluation_id),
            "policies_evaluated": self.policies_evaluated,
            "compliant_policies": self.compliant_policies,
            "violations_count": len(self.violations),
            "warnings_count": len(self.warnings),
            "overall_compliance": self.overall_compliance,
            "compliance_score": self.compliance_score,
            "execution_time_ms": self.execution_time_ms,
            "timestamp": self.timestamp.isoformat(),
            "violations": [v.to_dict() for v in self.violations],
            "warnings": [w.to_dict() for w in self.warnings],
            "recommendations": self.recommendations,
            "context": {
                "action_type": self.context.action_type.value,
                "user_id": self.context.user_id,
                "user_roles": self.context.user_roles,
                "resource_type": self.context.resource_type,
                "data_classification": self.context.data_classification
            }
        }


class PolicyEngineService:
    """
    Engine Avançado de Políticas de Governança
    
    Responsabilidades:
    - Avaliar políticas de governança em tempo real
    - Detectar violações e não conformidades
    - Aplicar diferentes níveis de enforcement
    - Gerar relatórios de compliance
    - Sugerir remediações automáticas
    - Gerenciar políticas dinâmicas
    """
    
    def __init__(self):
        """Inicializa o policy engine"""
        self._policy_evaluators = {
            PolicyCategory.DATA_CLASSIFICATION: self._evaluate_data_classification_policy,
            PolicyCategory.ACCESS_CONTROL: self._evaluate_access_control_policy,
            PolicyCategory.DATA_RETENTION: self._evaluate_data_retention_policy,
            PolicyCategory.DATA_QUALITY: self._evaluate_data_quality_policy,
            PolicyCategory.PRIVACY_PROTECTION: self._evaluate_privacy_protection_policy,
            PolicyCategory.AUDIT_LOGGING: self._evaluate_audit_logging_policy,
            PolicyCategory.DATA_LINEAGE: self._evaluate_data_lineage_policy,
            PolicyCategory.MASKING_ANONYMIZATION: self._evaluate_masking_policy,
            PolicyCategory.CROSS_BORDER_TRANSFER: self._evaluate_cross_border_policy,
            PolicyCategory.CONSENT_MANAGEMENT: self._evaluate_consent_policy
        }
        
        self._enforcement_handlers = {
            EnforcementLevel.ADVISORY: self._handle_advisory_enforcement,
            EnforcementLevel.PREVENTIVE: self._handle_preventive_enforcement,
            EnforcementLevel.DETECTIVE: self._handle_detective_enforcement,
            EnforcementLevel.CORRECTIVE: self._handle_corrective_enforcement
        }
        
        self._evaluation_cache = {}
        self._policy_cache = {}
    
    async def evaluate_policies(
        self,
        policies: List[GovernancePolicy],
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationReport:
        """
        Avalia um conjunto de políticas contra um contexto
        
        Args:
            policies: Lista de políticas a serem avaliadas
            context: Contexto da avaliação
            
        Returns:
            PolicyEvaluationReport: Relatório da avaliação
        """
        start_time = datetime.utcnow()
        evaluation_id = UUID()
        
        violations = []
        warnings = []
        compliant_count = 0
        
        # Filtrar políticas aplicáveis
        applicable_policies = self._filter_applicable_policies(policies, context)
        
        # Avaliar cada política
        for policy in applicable_policies:
            try:
                result = await self._evaluate_single_policy(policy, context)
                
                if result == PolicyEvaluationResult.COMPLIANT:
                    compliant_count += 1
                elif result == PolicyEvaluationResult.NON_COMPLIANT:
                    violation = self._create_violation(policy, context, "non_compliant")
                    violations.append(violation)
                elif result == PolicyEvaluationResult.WARNING:
                    warning = self._create_violation(policy, context, "warning")
                    warnings.append(warning)
                
            except Exception as e:
                # Criar violação de erro
                error_violation = PolicyViolation(
                    policy_id=policy.id,
                    policy_name=policy.name,
                    policy_category=policy.category,
                    enforcement_level=policy.enforcement_level,
                    violation_type="evaluation_error",
                    severity="high",
                    message=f"Erro na avaliação da política: {str(e)}",
                    details={"error": str(e)},
                    context=context,
                    timestamp=datetime.utcnow()
                )
                violations.append(error_violation)
        
        # Calcular métricas
        total_policies = len(applicable_policies)
        compliance_score = (compliant_count / total_policies * 100) if total_policies > 0 else 100.0
        overall_compliance = len(violations) == 0
        execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000
        
        # Gerar recomendações
        recommendations = self._generate_recommendations(violations, warnings, context)
        
        # Criar relatório
        report = PolicyEvaluationReport(
            evaluation_id=evaluation_id,
            context=context,
            policies_evaluated=total_policies,
            compliant_policies=compliant_count,
            violations=violations,
            warnings=warnings,
            overall_compliance=overall_compliance,
            compliance_score=compliance_score,
            execution_time_ms=execution_time,
            timestamp=datetime.utcnow(),
            recommendations=recommendations
        )
        
        # Aplicar enforcement
        await self._apply_enforcement(violations, context)
        
        return report
    
    def _filter_applicable_policies(
        self,
        policies: List[GovernancePolicy],
        context: PolicyEvaluationContext
    ) -> List[GovernancePolicy]:
        """Filtra políticas aplicáveis ao contexto"""
        applicable = []
        
        for policy in policies:
            if not policy.is_active:
                continue
            
            # Verificar escopo da política
            if not self._is_policy_applicable(policy, context):
                continue
            
            # Verificar se a política se aplica ao tipo de ação
            if not self._action_matches_policy(policy, context.action_type):
                continue
            
            applicable.append(policy)
        
        return applicable
    
    def _is_policy_applicable(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> bool:
        """Verifica se uma política é aplicável ao contexto"""
        # Verificar escopo por usuário
        if policy.scope.user_groups and context.user_roles:
            if not any(role in policy.scope.user_groups for role in context.user_roles):
                return False
        
        # Verificar escopo por classificação de dados
        if policy.scope.data_classifications and context.data_classification:
            if context.data_classification not in policy.scope.data_classifications:
                return False
        
        # Verificar escopo por tipo de recurso
        if policy.scope.resource_types and context.resource_type:
            if context.resource_type not in policy.scope.resource_types:
                return False
        
        # Verificar período de vigência
        now = datetime.utcnow()
        if policy.effective_date and now < policy.effective_date:
            return False
        
        if policy.expiration_date and now > policy.expiration_date:
            return False
        
        return True
    
    def _action_matches_policy(
        self,
        policy: GovernancePolicy,
        action_type: ActionType
    ) -> bool:
        """Verifica se o tipo de ação corresponde à política"""
        # Mapeamento de categorias de política para tipos de ação
        category_action_mapping = {
            PolicyCategory.DATA_CLASSIFICATION: [
                ActionType.DATA_ACCESS, ActionType.DATA_MODIFICATION,
                ActionType.CONTRACT_CREATION, ActionType.CONTRACT_MODIFICATION
            ],
            PolicyCategory.ACCESS_CONTROL: [
                ActionType.DATA_ACCESS, ActionType.USER_ACCESS,
                ActionType.SYSTEM_INTEGRATION
            ],
            PolicyCategory.DATA_RETENTION: [
                ActionType.DATA_DELETION, ActionType.DATA_MODIFICATION
            ],
            PolicyCategory.DATA_QUALITY: [
                ActionType.DATA_MODIFICATION, ActionType.CONTRACT_CREATION,
                ActionType.CONTRACT_MODIFICATION
            ],
            PolicyCategory.PRIVACY_PROTECTION: [
                ActionType.DATA_ACCESS, ActionType.DATA_EXPORT,
                ActionType.DATA_MODIFICATION
            ],
            PolicyCategory.AUDIT_LOGGING: [
                ActionType.DATA_ACCESS, ActionType.DATA_MODIFICATION,
                ActionType.DATA_DELETION, ActionType.DATA_EXPORT
            ],
            PolicyCategory.DATA_LINEAGE: [
                ActionType.DATA_MODIFICATION, ActionType.SCHEMA_CHANGE,
                ActionType.SYSTEM_INTEGRATION
            ],
            PolicyCategory.MASKING_ANONYMIZATION: [
                ActionType.DATA_ACCESS, ActionType.DATA_EXPORT
            ],
            PolicyCategory.CROSS_BORDER_TRANSFER: [
                ActionType.DATA_EXPORT, ActionType.SYSTEM_INTEGRATION
            ],
            PolicyCategory.CONSENT_MANAGEMENT: [
                ActionType.DATA_ACCESS, ActionType.DATA_MODIFICATION,
                ActionType.DATA_EXPORT
            ]
        }
        
        applicable_actions = category_action_mapping.get(policy.category, [])
        return action_type in applicable_actions
    
    async def _evaluate_single_policy(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationResult:
        """Avalia uma única política"""
        evaluator = self._policy_evaluators.get(policy.category)
        if not evaluator:
            return PolicyEvaluationResult.NOT_APPLICABLE
        
        return await evaluator(policy, context)
    
    async def _evaluate_data_classification_policy(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationResult:
        """Avalia política de classificação de dados"""
        config = policy.configuration
        
        # Verificar se dados têm classificação adequada
        if not context.data_classification:
            return PolicyEvaluationResult.NON_COMPLIANT
        
        # Verificar classificações permitidas
        allowed_classifications = config.get("allowed_classifications", [])
        if allowed_classifications and context.data_classification not in allowed_classifications:
            return PolicyEvaluationResult.NON_COMPLIANT
        
        # Verificar regras específicas por ação
        if context.action_type == ActionType.DATA_EXPORT:
            export_restrictions = config.get("export_restrictions", {})
            restricted_classifications = export_restrictions.get("restricted_classifications", [])
            if context.data_classification in restricted_classifications:
                return PolicyEvaluationResult.NON_COMPLIANT
        
        return PolicyEvaluationResult.COMPLIANT
    
    async def _evaluate_access_control_policy(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationResult:
        """Avalia política de controle de acesso"""
        config = policy.configuration
        
        # Verificar roles obrigatórios
        required_roles = config.get("required_roles", [])
        if required_roles:
            if not any(role in context.user_roles for role in required_roles):
                return PolicyEvaluationResult.NON_COMPLIANT
        
        # Verificar roles proibidos
        forbidden_roles = config.get("forbidden_roles", [])
        if forbidden_roles:
            if any(role in context.user_roles for role in forbidden_roles):
                return PolicyEvaluationResult.NON_COMPLIANT
        
        # Verificar horário de acesso
        access_hours = config.get("access_hours")
        if access_hours:
            current_hour = context.timestamp.hour
            start_hour = access_hours.get("start", 0)
            end_hour = access_hours.get("end", 23)
            
            if not (start_hour <= current_hour <= end_hour):
                return PolicyEvaluationResult.NON_COMPLIANT
        
        # Verificar classificação vs roles
        classification_access = config.get("classification_access", {})
        if context.data_classification and classification_access:
            required_roles_for_classification = classification_access.get(context.data_classification, [])
            if required_roles_for_classification:
                if not any(role in context.user_roles for role in required_roles_for_classification):
                    return PolicyEvaluationResult.NON_COMPLIANT
        
        return PolicyEvaluationResult.COMPLIANT
    
    async def _evaluate_data_retention_policy(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationResult:
        """Avalia política de retenção de dados"""
        config = policy.configuration
        
        # Para ações de deleção, verificar se está dentro do período de retenção
        if context.action_type == ActionType.DATA_DELETION:
            retention_period_days = config.get("retention_period_days")
            if retention_period_days:
                # Simular verificação de idade dos dados
                # Em produção, isso consultaria metadados reais
                data_age_days = 365  # Placeholder
                
                if data_age_days < retention_period_days:
                    return PolicyEvaluationResult.NON_COMPLIANT
        
        # Verificar políticas de arquivamento
        archival_rules = config.get("archival_rules", {})
        if archival_rules and context.data_classification:
            classification_retention = archival_rules.get(context.data_classification)
            if classification_retention:
                # Verificar regras específicas de arquivamento
                pass
        
        return PolicyEvaluationResult.COMPLIANT
    
    async def _evaluate_data_quality_policy(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationResult:
        """Avalia política de qualidade de dados"""
        config = policy.configuration
        
        # Verificar score mínimo de qualidade
        min_quality_score = config.get("min_quality_score", 80.0)
        
        # Em produção, isso consultaria o quality service
        current_quality_score = 85.0  # Placeholder
        
        if current_quality_score < min_quality_score:
            return PolicyEvaluationResult.NON_COMPLIANT
        
        # Verificar regras obrigatórias
        required_quality_rules = config.get("required_quality_rules", [])
        if required_quality_rules:
            # Verificar se todas as regras obrigatórias estão ativas
            # Em produção, isso consultaria o quality service
            pass
        
        return PolicyEvaluationResult.COMPLIANT
    
    async def _evaluate_privacy_protection_policy(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationResult:
        """Avalia política de proteção de privacidade"""
        config = policy.configuration
        
        # Verificar se dados pessoais requerem consentimento
        if context.action_type in [ActionType.DATA_ACCESS, ActionType.DATA_EXPORT]:
            requires_consent = config.get("requires_consent", False)
            if requires_consent:
                # Em produção, verificaria sistema de consentimento
                has_consent = True  # Placeholder
                if not has_consent:
                    return PolicyEvaluationResult.NON_COMPLIANT
        
        # Verificar mascaramento obrigatório
        masking_required = config.get("masking_required", False)
        if masking_required and context.action_type == ActionType.DATA_ACCESS:
            # Verificar se dados estão mascarados
            is_masked = False  # Placeholder
            if not is_masked:
                return PolicyEvaluationResult.WARNING
        
        return PolicyEvaluationResult.COMPLIANT
    
    async def _evaluate_audit_logging_policy(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationResult:
        """Avalia política de auditoria"""
        config = policy.configuration
        
        # Verificar se ação requer auditoria
        auditable_actions = config.get("auditable_actions", [])
        if auditable_actions and context.action_type.value in auditable_actions:
            # Verificar se auditoria está habilitada
            audit_enabled = True  # Placeholder - verificaria sistema de auditoria
            if not audit_enabled:
                return PolicyEvaluationResult.NON_COMPLIANT
        
        return PolicyEvaluationResult.COMPLIANT
    
    async def _evaluate_data_lineage_policy(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationResult:
        """Avalia política de linhagem de dados"""
        config = policy.configuration
        
        # Verificar se linhagem é obrigatória para a ação
        if context.action_type in [ActionType.DATA_MODIFICATION, ActionType.SCHEMA_CHANGE]:
            lineage_required = config.get("lineage_required", True)
            if lineage_required:
                # Verificar se linhagem está sendo capturada
                lineage_captured = True  # Placeholder
                if not lineage_captured:
                    return PolicyEvaluationResult.WARNING
        
        return PolicyEvaluationResult.COMPLIANT
    
    async def _evaluate_masking_policy(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationResult:
        """Avalia política de mascaramento"""
        config = policy.configuration
        
        # Verificar se mascaramento é obrigatório
        if context.action_type == ActionType.DATA_ACCESS:
            masking_rules = config.get("masking_rules", {})
            if context.data_classification in masking_rules:
                required_masking = masking_rules[context.data_classification]
                # Verificar se mascaramento está aplicado
                is_masked = False  # Placeholder
                if required_masking and not is_masked:
                    return PolicyEvaluationResult.NON_COMPLIANT
        
        return PolicyEvaluationResult.COMPLIANT
    
    async def _evaluate_cross_border_policy(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationResult:
        """Avalia política de transferência internacional"""
        config = policy.configuration
        
        if context.action_type == ActionType.DATA_EXPORT:
            # Verificar países permitidos
            allowed_countries = config.get("allowed_countries", [])
            target_country = context.request_metadata.get("target_country")
            
            if allowed_countries and target_country:
                if target_country not in allowed_countries:
                    return PolicyEvaluationResult.NON_COMPLIANT
            
            # Verificar adequação LGPD/GDPR
            requires_adequacy = config.get("requires_adequacy", True)
            if requires_adequacy and target_country:
                # Verificar se país tem decisão de adequação
                has_adequacy = target_country in ["US", "CA", "UK"]  # Placeholder
                if not has_adequacy:
                    return PolicyEvaluationResult.WARNING
        
        return PolicyEvaluationResult.COMPLIANT
    
    async def _evaluate_consent_policy(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> PolicyEvaluationResult:
        """Avalia política de consentimento"""
        config = policy.configuration
        
        # Verificar se ação requer consentimento
        consent_required_actions = config.get("consent_required_actions", [])
        if context.action_type.value in consent_required_actions:
            # Verificar consentimento válido
            has_valid_consent = True  # Placeholder
            if not has_valid_consent:
                return PolicyEvaluationResult.NON_COMPLIANT
        
        return PolicyEvaluationResult.COMPLIANT
    
    def _create_violation(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext,
        violation_type: str
    ) -> PolicyViolation:
        """Cria uma violação de política"""
        severity_mapping = {
            EnforcementLevel.ADVISORY: "low",
            EnforcementLevel.DETECTIVE: "medium",
            EnforcementLevel.PREVENTIVE: "high",
            EnforcementLevel.CORRECTIVE: "high"
        }
        
        severity = severity_mapping.get(policy.enforcement_level, "medium")
        
        # Gerar mensagem específica
        message = self._generate_violation_message(policy, context, violation_type)
        
        # Gerar sugestões de remediação
        remediation = self._generate_remediation_suggestions(policy, context)
        
        return PolicyViolation(
            policy_id=policy.id,
            policy_name=policy.name,
            policy_category=policy.category,
            enforcement_level=policy.enforcement_level,
            violation_type=violation_type,
            severity=severity,
            message=message,
            details={
                "policy_description": policy.description,
                "action_type": context.action_type.value,
                "user_roles": context.user_roles,
                "data_classification": context.data_classification
            },
            context=context,
            timestamp=datetime.utcnow(),
            remediation_suggestions=remediation
        )
    
    def _generate_violation_message(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext,
        violation_type: str
    ) -> str:
        """Gera mensagem específica para a violação"""
        messages = {
            PolicyCategory.DATA_CLASSIFICATION: f"Classificação de dados inadequada para ação {context.action_type.value}",
            PolicyCategory.ACCESS_CONTROL: f"Usuário não possui permissões necessárias para {context.action_type.value}",
            PolicyCategory.DATA_RETENTION: f"Ação {context.action_type.value} viola política de retenção",
            PolicyCategory.DATA_QUALITY: f"Qualidade dos dados abaixo do mínimo exigido",
            PolicyCategory.PRIVACY_PROTECTION: f"Ação {context.action_type.value} requer proteções adicionais de privacidade",
            PolicyCategory.AUDIT_LOGGING: f"Ação {context.action_type.value} requer auditoria habilitada",
            PolicyCategory.DATA_LINEAGE: f"Linhagem de dados obrigatória para {context.action_type.value}",
            PolicyCategory.MASKING_ANONYMIZATION: f"Mascaramento obrigatório para dados {context.data_classification}",
            PolicyCategory.CROSS_BORDER_TRANSFER: f"Transferência internacional não permitida",
            PolicyCategory.CONSENT_MANAGEMENT: f"Consentimento válido necessário para {context.action_type.value}"
        }
        
        return messages.get(policy.category, f"Violação da política {policy.name}")
    
    def _generate_remediation_suggestions(
        self,
        policy: GovernancePolicy,
        context: PolicyEvaluationContext
    ) -> List[str]:
        """Gera sugestões de remediação"""
        suggestions = []
        
        if policy.category == PolicyCategory.ACCESS_CONTROL:
            suggestions.extend([
                "Solicitar permissões adicionais ao administrador",
                "Verificar se usuário possui roles necessários",
                "Aguardar horário permitido para acesso"
            ])
        elif policy.category == PolicyCategory.DATA_CLASSIFICATION:
            suggestions.extend([
                "Reclassificar dados conforme política",
                "Aplicar controles adicionais de segurança",
                "Revisar necessidade de acesso aos dados"
            ])
        elif policy.category == PolicyCategory.PRIVACY_PROTECTION:
            suggestions.extend([
                "Obter consentimento do titular dos dados",
                "Aplicar mascaramento aos dados sensíveis",
                "Implementar controles de anonimização"
            ])
        
        return suggestions
    
    async def _apply_enforcement(
        self,
        violations: List[PolicyViolation],
        context: PolicyEvaluationContext
    ):
        """Aplica enforcement baseado nas violações"""
        for violation in violations:
            handler = self._enforcement_handlers.get(violation.enforcement_level)
            if handler:
                await handler(violation, context)
    
    async def _handle_advisory_enforcement(
        self,
        violation: PolicyViolation,
        context: PolicyEvaluationContext
    ):
        """Trata enforcement advisory (apenas aviso)"""
        # Log da violação
        print(f"ADVISORY: {violation.message}")
    
    async def _handle_preventive_enforcement(
        self,
        violation: PolicyViolation,
        context: PolicyEvaluationContext
    ):
        """Trata enforcement preventivo (bloqueia ação)"""
        # Em produção, isso bloquearia a ação
        print(f"PREVENTIVE: Ação bloqueada - {violation.message}")
        raise Exception(f"Ação bloqueada por política: {violation.message}")
    
    async def _handle_detective_enforcement(
        self,
        violation: PolicyViolation,
        context: PolicyEvaluationContext
    ):
        """Trata enforcement detectivo (detecta e alerta)"""
        # Gerar alerta
        print(f"DETECTIVE: Violação detectada - {violation.message}")
        # Em produção, enviaria notificação/alerta
    
    async def _handle_corrective_enforcement(
        self,
        violation: PolicyViolation,
        context: PolicyEvaluationContext
    ):
        """Trata enforcement corretivo (auto-remediação)"""
        # Aplicar correção automática
        print(f"CORRECTIVE: Aplicando correção automática - {violation.message}")
        # Em produção, executaria ações corretivas
    
    def _generate_recommendations(
        self,
        violations: List[PolicyViolation],
        warnings: List[PolicyViolation],
        context: PolicyEvaluationContext
    ) -> List[str]:
        """Gera recomendações baseadas nas violações"""
        recommendations = []
        
        if violations:
            critical_violations = [v for v in violations if v.severity == "high"]
            if critical_violations:
                recommendations.append(f"URGENTE: {len(critical_violations)} violação(ões) crítica(s) detectada(s)")
            
            access_violations = [v for v in violations if v.policy_category == PolicyCategory.ACCESS_CONTROL]
            if access_violations:
                recommendations.append("Revisar permissões de usuário e roles atribuídos")
            
            privacy_violations = [v for v in violations if v.policy_category == PolicyCategory.PRIVACY_PROTECTION]
            if privacy_violations:
                recommendations.append("Implementar controles adicionais de privacidade")
        
        if warnings:
            recommendations.append(f"Revisar {len(warnings)} aviso(s) de compliance")
        
        # Recomendações específicas por contexto
        if context.data_classification in ["CONFIDENTIAL", "RESTRICTED"]:
            recommendations.append("Considerar controles adicionais para dados sensíveis")
        
        return recommendations
    
    def generate_compliance_dashboard(
        self,
        reports: List[PolicyEvaluationReport],
        time_period: timedelta = timedelta(days=30)
    ) -> Dict[str, Any]:
        """
        Gera dashboard de compliance
        
        Args:
            reports: Lista de relatórios de avaliação
            time_period: Período de análise
            
        Returns:
            Dict: Dashboard de compliance
        """
        cutoff_date = datetime.utcnow() - time_period
        recent_reports = [r for r in reports if r.timestamp >= cutoff_date]
        
        if not recent_reports:
            return {"message": "Nenhum relatório encontrado no período"}
        
        # Métricas gerais
        total_evaluations = len(recent_reports)
        total_violations = sum(len(r.violations) for r in recent_reports)
        total_warnings = sum(len(r.warnings) for r in recent_reports)
        avg_compliance_score = sum(r.compliance_score for r in recent_reports) / total_evaluations
        
        # Violações por categoria
        violations_by_category = {}
        for report in recent_reports:
            for violation in report.violations:
                category = violation.policy_category.value
                violations_by_category[category] = violations_by_category.get(category, 0) + 1
        
        # Violações por usuário
        violations_by_user = {}
        for report in recent_reports:
            user_id = report.context.user_id
            user_violations = len(report.violations)
            violations_by_user[user_id] = violations_by_user.get(user_id, 0) + user_violations
        
        # Tendências
        compliance_trend = []
        for report in sorted(recent_reports, key=lambda x: x.timestamp):
            compliance_trend.append({
                "date": report.timestamp.date().isoformat(),
                "compliance_score": report.compliance_score,
                "violations_count": len(report.violations)
            })
        
        return {
            "period": {
                "start_date": cutoff_date.isoformat(),
                "end_date": datetime.utcnow().isoformat()
            },
            "summary": {
                "total_evaluations": total_evaluations,
                "total_violations": total_violations,
                "total_warnings": total_warnings,
                "average_compliance_score": round(avg_compliance_score, 2),
                "compliance_rate": round((total_evaluations - len([r for r in recent_reports if r.violations])) / total_evaluations * 100, 2)
            },
            "violations_by_category": violations_by_category,
            "top_violating_users": sorted(violations_by_user.items(), key=lambda x: x[1], reverse=True)[:10],
            "compliance_trend": compliance_trend,
            "recommendations": self._generate_dashboard_recommendations(recent_reports)
        }
    
    def _generate_dashboard_recommendations(
        self,
        reports: List[PolicyEvaluationReport]
    ) -> List[str]:
        """Gera recomendações para o dashboard"""
        recommendations = []
        
        # Analisar padrões de violação
        all_violations = []
        for report in reports:
            all_violations.extend(report.violations)
        
        if all_violations:
            # Categoria mais violada
            category_counts = {}
            for violation in all_violations:
                category = violation.policy_category.value
                category_counts[category] = category_counts.get(category, 0) + 1
            
            most_violated_category = max(category_counts.items(), key=lambda x: x[1])
            recommendations.append(f"Foco em políticas de {most_violated_category[0]} ({most_violated_category[1]} violações)")
            
            # Usuários problemáticos
            user_violations = {}
            for violation in all_violations:
                user_id = violation.context.user_id
                user_violations[user_id] = user_violations.get(user_id, 0) + 1
            
            if user_violations:
                top_violator = max(user_violations.items(), key=lambda x: x[1])
                if top_violator[1] > 5:
                    recommendations.append(f"Treinamento adicional necessário para usuário {top_violator[0]}")
        
        return recommendations

