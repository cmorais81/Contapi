# Autor: carlos.morais@f1rst.com.br
"""
Governance Repository Implementation
SQLAlchemy implementation for governance policies and compliance operations
"""

import json
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, desc, asc, text
from sqlalchemy.exc import SQLAlchemyError

# Import shared models
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'shared'))
from database.models.central_models import (
    GovernancePolicyModel, PolicyViolationModel, ComplianceAssessmentModel,
    AuditLogModel, OrganizationModel, UserModel
)

# Import domain entities
from ...domain.entities.governance_policy import GovernancePolicy
from ...domain.repositories.governance_repository import GovernancePolicyRepository

# Import DTOs
from ...application.dtos.governance_dtos import (
    PolicyType, PolicyStatus, ComplianceStatus, ViolationSeverity,
    AuditEventType, PolicySearchRequest, PolicyFilterRequest,
    AuditLogFilterRequest
)


class GovernanceRepositoryImpl(GovernancePolicyRepository):
    """SQLAlchemy implementation of governance repository"""
    
    def __init__(self, db_session: Session):
        self.db_session = db_session
    
    # ========================================================================
    # CRUD Operations
    # ========================================================================
    
    def save_policy(self, policy: GovernancePolicy) -> GovernancePolicy:
        """Save governance policy"""
        try:
            # Check if policy exists
            existing = self.db_session.query(GovernancePolicyModel).filter(
                GovernancePolicyModel.id == policy.id
            ).first()
            
            if existing:
                # Update existing policy
                self._update_policy_model(existing, policy)
            else:
                # Create new policy
                policy_model = self._create_policy_model(policy)
                self.db_session.add(policy_model)
            
            self.db_session.commit()
            
            # Return updated policy
            return self.find_policy_by_id(policy.id)
            
        except SQLAlchemyError as e:
            self.db_session.rollback()
            raise Exception(f"Error saving policy: {str(e)}")
    
    def find_policy_by_id(self, policy_id: UUID) -> Optional[GovernancePolicy]:
        """Find policy by ID"""
        try:
            policy_model = self.db_session.query(GovernancePolicyModel).filter(
                and_(
                    GovernancePolicyModel.id == policy_id,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).first()
            
            if not policy_model:
                return None
            
            return self._model_to_entity(policy_model)
            
        except SQLAlchemyError as e:
            raise Exception(f"Error finding policy: {str(e)}")
    
    def find_policy_by_name(self, name: str, organization_id: UUID) -> Optional[GovernancePolicy]:
        """Find policy by name and organization"""
        try:
            policy_model = self.db_session.query(GovernancePolicyModel).filter(
                and_(
                    GovernancePolicyModel.name == name,
                    GovernancePolicyModel.organization_id == organization_id,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).first()
            
            if not policy_model:
                return None
            
            return self._model_to_entity(policy_model)
            
        except SQLAlchemyError as e:
            raise Exception(f"Error finding policy by name: {str(e)}")
    
    def delete_policy(self, policy_id: UUID) -> bool:
        """Soft delete policy"""
        try:
            policy_model = self.db_session.query(GovernancePolicyModel).filter(
                and_(
                    GovernancePolicyModel.id == policy_id,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).first()
            
            if not policy_model:
                return False
            
            policy_model.deleted_at = datetime.utcnow()
            self.db_session.commit()
            return True
            
        except SQLAlchemyError as e:
            self.db_session.rollback()
            raise Exception(f"Error deleting policy: {str(e)}")
    
    # ========================================================================
    # Search and Filter Operations
    # ========================================================================
    
    def find_policies_by_organization(
        self, 
        organization_id: UUID, 
        limit: int = 100, 
        offset: int = 0
    ) -> Tuple[List[GovernancePolicy], int]:
        """Find policies by organization"""
        try:
            query = self.db_session.query(GovernancePolicyModel).filter(
                and_(
                    GovernancePolicyModel.organization_id == organization_id,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).order_by(desc(GovernancePolicyModel.created_at))
            
            total = query.count()
            policies = query.limit(limit).offset(offset).all()
            
            return [self._model_to_entity(p) for p in policies], total
            
        except SQLAlchemyError as e:
            raise Exception(f"Error finding policies by organization: {str(e)}")
    
    def search_policies(
        self, 
        request: PolicySearchRequest, 
        limit: int = 100, 
        offset: int = 0
    ) -> Tuple[List[GovernancePolicy], int]:
        """Search policies"""
        try:
            query = self.db_session.query(GovernancePolicyModel).filter(
                GovernancePolicyModel.deleted_at.is_(None)
            )
            
            # Text search
            if request.query:
                search_term = f"%{request.query}%"
                query = query.filter(
                    or_(
                        GovernancePolicyModel.name.ilike(search_term),
                        GovernancePolicyModel.description.ilike(search_term),
                        GovernancePolicyModel.tags.op('?|')(request.query.split())
                    )
                )
            
            # Filters
            if request.policy_type:
                query = query.filter(GovernancePolicyModel.policy_type == request.policy_type.value)
            
            if request.status:
                query = query.filter(GovernancePolicyModel.status == request.status.value)
            
            if request.organization_id:
                query = query.filter(GovernancePolicyModel.organization_id == request.organization_id)
            
            if request.created_by:
                query = query.filter(GovernancePolicyModel.created_by == request.created_by)
            
            if request.enabled is not None:
                query = query.filter(GovernancePolicyModel.enabled == request.enabled)
            
            if request.applies_to:
                query = query.filter(GovernancePolicyModel.applies_to.op('@>')(json.dumps([request.applies_to])))
            
            if request.tags:
                query = query.filter(GovernancePolicyModel.tags.op('?|')(request.tags))
            
            if request.created_after:
                query = query.filter(GovernancePolicyModel.created_at >= request.created_after)
            
            if request.created_before:
                query = query.filter(GovernancePolicyModel.created_at <= request.created_before)
            
            query = query.order_by(desc(GovernancePolicyModel.created_at))
            
            total = query.count()
            policies = query.limit(limit).offset(offset).all()
            
            return [self._model_to_entity(p) for p in policies], total
            
        except SQLAlchemyError as e:
            raise Exception(f"Error searching policies: {str(e)}")
    
    def filter_policies(
        self, 
        request: PolicyFilterRequest, 
        limit: int = 100, 
        offset: int = 0
    ) -> Tuple[List[GovernancePolicy], int]:
        """Filter policies"""
        try:
            query = self.db_session.query(GovernancePolicyModel).filter(
                GovernancePolicyModel.deleted_at.is_(None)
            )
            
            # Apply filters
            if request.organization_id:
                query = query.filter(GovernancePolicyModel.organization_id == request.organization_id)
            
            if request.policy_type:
                query = query.filter(GovernancePolicyModel.policy_type == request.policy_type.value)
            
            if request.status:
                query = query.filter(GovernancePolicyModel.status == request.status.value)
            
            if request.created_by:
                query = query.filter(GovernancePolicyModel.created_by == request.created_by)
            
            if request.enabled is not None:
                query = query.filter(GovernancePolicyModel.enabled == request.enabled)
            
            if request.has_violations is not None:
                if request.has_violations:
                    query = query.filter(GovernancePolicyModel.violation_count > 0)
                else:
                    query = query.filter(GovernancePolicyModel.violation_count == 0)
            
            if request.effective_after:
                query = query.filter(
                    or_(
                        GovernancePolicyModel.effective_date.is_(None),
                        GovernancePolicyModel.effective_date >= request.effective_after
                    )
                )
            
            if request.effective_before:
                query = query.filter(
                    or_(
                        GovernancePolicyModel.effective_date.is_(None),
                        GovernancePolicyModel.effective_date <= request.effective_before
                    )
                )
            
            if request.expires_after:
                query = query.filter(
                    or_(
                        GovernancePolicyModel.expiry_date.is_(None),
                        GovernancePolicyModel.expiry_date >= request.expires_after
                    )
                )
            
            if request.expires_before:
                query = query.filter(
                    or_(
                        GovernancePolicyModel.expiry_date.is_(None),
                        GovernancePolicyModel.expiry_date <= request.expires_before
                    )
                )
            
            query = query.order_by(desc(GovernancePolicyModel.updated_at))
            
            total = query.count()
            policies = query.limit(limit).offset(offset).all()
            
            return [self._model_to_entity(p) for p in policies], total
            
        except SQLAlchemyError as e:
            raise Exception(f"Error filtering policies: {str(e)}")
    
    # ========================================================================
    # Specialized Queries
    # ========================================================================
    
    def find_active_policies(self, organization_id: UUID) -> List[GovernancePolicy]:
        """Find active policies for organization"""
        try:
            now = datetime.utcnow()
            
            policies = self.db_session.query(GovernancePolicyModel).filter(
                and_(
                    GovernancePolicyModel.organization_id == organization_id,
                    GovernancePolicyModel.enabled == True,
                    GovernancePolicyModel.status == PolicyStatus.ACTIVE.value,
                    GovernancePolicyModel.deleted_at.is_(None),
                    or_(
                        GovernancePolicyModel.effective_date.is_(None),
                        GovernancePolicyModel.effective_date <= now
                    ),
                    or_(
                        GovernancePolicyModel.expiry_date.is_(None),
                        GovernancePolicyModel.expiry_date > now
                    )
                )
            ).order_by(GovernancePolicyModel.name).all()
            
            return [self._model_to_entity(p) for p in policies]
            
        except SQLAlchemyError as e:
            raise Exception(f"Error finding active policies: {str(e)}")
    
    def find_policies_by_type(self, policy_type: PolicyType, organization_id: UUID) -> List[GovernancePolicy]:
        """Find policies by type"""
        try:
            policies = self.db_session.query(GovernancePolicyModel).filter(
                and_(
                    GovernancePolicyModel.policy_type == policy_type.value,
                    GovernancePolicyModel.organization_id == organization_id,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).order_by(GovernancePolicyModel.name).all()
            
            return [self._model_to_entity(p) for p in policies]
            
        except SQLAlchemyError as e:
            raise Exception(f"Error finding policies by type: {str(e)}")
    
    def find_policies_with_violations(self, organization_id: UUID) -> List[GovernancePolicy]:
        """Find policies with violations"""
        try:
            policies = self.db_session.query(GovernancePolicyModel).filter(
                and_(
                    GovernancePolicyModel.organization_id == organization_id,
                    GovernancePolicyModel.violation_count > 0,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).order_by(desc(GovernancePolicyModel.violation_count)).all()
            
            return [self._model_to_entity(p) for p in policies]
            
        except SQLAlchemyError as e:
            raise Exception(f"Error finding policies with violations: {str(e)}")
    
    def find_expiring_policies(self, days: int = 30) -> List[GovernancePolicy]:
        """Find policies expiring in N days"""
        try:
            expiry_date = datetime.utcnow() + timedelta(days=days)
            
            policies = self.db_session.query(GovernancePolicyModel).filter(
                and_(
                    GovernancePolicyModel.expiry_date.is_not(None),
                    GovernancePolicyModel.expiry_date <= expiry_date,
                    GovernancePolicyModel.expiry_date > datetime.utcnow(),
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).order_by(GovernancePolicyModel.expiry_date).all()
            
            return [self._model_to_entity(p) for p in policies]
            
        except SQLAlchemyError as e:
            raise Exception(f"Error finding expiring policies: {str(e)}")
    
    # ========================================================================
    # Statistics and Analytics
    # ========================================================================
    
    def get_policy_statistics(self, organization_id: UUID) -> Dict[str, Any]:
        """Get policy statistics for organization"""
        try:
            # Basic counts
            total_policies = self.db_session.query(GovernancePolicyModel).filter(
                and_(
                    GovernancePolicyModel.organization_id == organization_id,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).count()
            
            active_policies = self.db_session.query(GovernancePolicyModel).filter(
                and_(
                    GovernancePolicyModel.organization_id == organization_id,
                    GovernancePolicyModel.enabled == True,
                    GovernancePolicyModel.status == PolicyStatus.ACTIVE.value,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).count()
            
            # Violation counts
            total_violations = self.db_session.query(func.sum(GovernancePolicyModel.violation_count)).filter(
                and_(
                    GovernancePolicyModel.organization_id == organization_id,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).scalar() or 0
            
            # Recent violations
            recent_violations = self.db_session.query(PolicyViolationModel).filter(
                and_(
                    PolicyViolationModel.detected_at >= datetime.utcnow() - timedelta(days=30),
                    PolicyViolationModel.resolved_at.is_(None)
                )
            ).count()
            
            # Compliance score (average)
            avg_compliance = self.db_session.query(func.avg(GovernancePolicyModel.compliance_score)).filter(
                and_(
                    GovernancePolicyModel.organization_id == organization_id,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).scalar() or 0.0
            
            # Policies by type
            policies_by_type = {}
            type_counts = self.db_session.query(
                GovernancePolicyModel.policy_type,
                func.count(GovernancePolicyModel.id)
            ).filter(
                and_(
                    GovernancePolicyModel.organization_id == organization_id,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).group_by(GovernancePolicyModel.policy_type).all()
            
            for policy_type, count in type_counts:
                policies_by_type[policy_type] = count
            
            # Policies by status
            policies_by_status = {}
            status_counts = self.db_session.query(
                GovernancePolicyModel.status,
                func.count(GovernancePolicyModel.id)
            ).filter(
                and_(
                    GovernancePolicyModel.organization_id == organization_id,
                    GovernancePolicyModel.deleted_at.is_(None)
                )
            ).group_by(GovernancePolicyModel.status).all()
            
            for status, count in status_counts:
                policies_by_status[status] = count
            
            return {
                "total_policies": total_policies,
                "active_policies": active_policies,
                "total_violations": int(total_violations),
                "recent_violations": recent_violations,
                "compliance_score": round(float(avg_compliance), 2),
                "policies_by_type": policies_by_type,
                "policies_by_status": policies_by_status
            }
            
        except SQLAlchemyError as e:
            raise Exception(f"Error getting policy statistics: {str(e)}")
    
    def get_compliance_metrics(self, organization_id: UUID, policy_id: Optional[UUID] = None) -> Dict[str, Any]:
        """Get compliance metrics"""
        try:
            query = self.db_session.query(ComplianceAssessmentModel)
            
            if policy_id:
                query = query.filter(ComplianceAssessmentModel.policy_id == policy_id)
            else:
                # Join with policies to filter by organization
                query = query.join(GovernancePolicyModel).filter(
                    GovernancePolicyModel.organization_id == organization_id
                )
            
            assessments = query.all()
            
            if not assessments:
                return {
                    "total_assessments": 0,
                    "compliance_score": 0.0,
                    "compliant_count": 0,
                    "non_compliant_count": 0,
                    "partially_compliant_count": 0
                }
            
            # Calculate metrics
            total_assessments = len(assessments)
            avg_score = sum(a.score for a in assessments) / total_assessments
            
            compliant_count = sum(1 for a in assessments if a.status == ComplianceStatus.COMPLNT.value)
            non_compliant_count = sum(1 for a in assessments if a.status == ComplianceStatus.NON_COMPLNT.value)
            partially_compliant_count = sum(1 for a in assessments if a.status == ComplianceStatus.PARTLLY_COMPLNT.value)
            
            return {
                "total_assessments": total_assessments,
                "compliance_score": round(avg_score, 2),
                "compliant_count": compliant_count,
                "non_compliant_count": non_compliant_count,
                "partially_compliant_count": partially_compliant_count
            }
            
        except SQLAlchemyError as e:
            raise Exception(f"Error getting compliance metrics: {str(e)}")
    
    # ========================================================================
    # Violation Management
    # ========================================================================
    
    def save_violation(self, violation_data: Dict[str, Any]) -> UUID:
        """Save policy violation"""
        try:
            violation = PolicyViolationModel(
                policy_id=violation_data["policy_id"],
                resource_id=violation_data.get("resource_id"),
                resource_type=violation_data.get("resource_type"),
                user_id=violation_data.get("user_id"),
                severity=violation_data["severity"],
                description=violation_data["description"],
                details=violation_data.get("details", {}),
                detected_at=datetime.utcnow()
            )
            
            self.db_session.add(violation)
            self.db_session.commit()
            
            # Update policy violation count
            self._update_policy_violation_count(violation_data["policy_id"])
            
            return violation.id
            
        except SQLAlchemyError as e:
            self.db_session.rollback()
            raise Exception(f"Error saving violation: {str(e)}")
    
    def resolve_violation(self, violation_id: UUID, resolution_notes: str, resolved_by: UUID) -> bool:
        """Resolve policy violation"""
        try:
            violation = self.db_session.query(PolicyViolationModel).filter(
                PolicyViolationModel.id == violation_id
            ).first()
            
            if not violation:
                return False
            
            violation.resolved_at = datetime.utcnow()
            violation.resolution_notes = resolution_notes
            violation.resolved_by = resolved_by
            
            self.db_session.commit()
            
            # Update policy violation count
            self._update_policy_violation_count(violation.policy_id)
            
            return True
            
        except SQLAlchemyError as e:
            self.db_session.rollback()
            raise Exception(f"Error resolving violation: {str(e)}")
    
    def find_violations_by_policy(self, policy_id: UUID) -> List[Dict[str, Any]]:
        """Find violations by policy"""
        try:
            violations = self.db_session.query(PolicyViolationModel).filter(
                PolicyViolationModel.policy_id == policy_id
            ).order_by(desc(PolicyViolationModel.detected_at)).all()
            
            return [self._violation_model_to_dict(v) for v in violations]
            
        except SQLAlchemyError as e:
            raise Exception(f"Error finding violations by policy: {str(e)}")
    
    # ========================================================================
    # Audit Logging
    # ========================================================================
    
    def save_audit_log(self, log_data: Dict[str, Any]) -> UUID:
        """Save audit log entry"""
        try:
            audit_log = AuditLogModel(
                event_type=log_data["event_type"],
                user_id=log_data.get("user_id"),
                resource_id=log_data.get("resource_id"),
                resource_type=log_data.get("resource_type"),
                policy_id=log_data.get("policy_id"),
                action=log_data["action"],
                result=log_data["result"],
                details=log_data.get("details", {}),
                ip_address=log_data.get("ip_address"),
                user_agent=log_data.get("user_agent"),
                timestamp=datetime.utcnow()
            )
            
            self.db_session.add(audit_log)
            self.db_session.commit()
            
            return audit_log.id
            
        except SQLAlchemyError as e:
            self.db_session.rollback()
            raise Exception(f"Error saving audit log: {str(e)}")
    
    def find_audit_logs(
        self, 
        request: AuditLogFilterRequest, 
        limit: int = 100, 
        offset: int = 0
    ) -> Tuple[List[Dict[str, Any]], int]:
        """Find audit logs with filters"""
        try:
            query = self.db_session.query(AuditLogModel)
            
            # Apply filters
            if request.event_type:
                query = query.filter(AuditLogModel.event_type == request.event_type.value)
            
            if request.user_id:
                query = query.filter(AuditLogModel.user_id == request.user_id)
            
            if request.resource_id:
                query = query.filter(AuditLogModel.resource_id == request.resource_id)
            
            if request.resource_type:
                query = query.filter(AuditLogModel.resource_type == request.resource_type)
            
            if request.policy_id:
                query = query.filter(AuditLogModel.policy_id == request.policy_id)
            
            if request.start_date:
                query = query.filter(AuditLogModel.timestamp >= request.start_date)
            
            if request.end_date:
                query = query.filter(AuditLogModel.timestamp <= request.end_date)
            
            # Organization filter (through policy relationship)
            if request.organization_id:
                query = query.join(GovernancePolicyModel, isouter=True).filter(
                    or_(
                        GovernancePolicyModel.organization_id == request.organization_id,
                        AuditLogModel.policy_id.is_(None)
                    )
                )
            
            query = query.order_by(desc(AuditLogModel.timestamp))
            
            total = query.count()
            logs = query.limit(limit).offset(offset).all()
            
            return [self._audit_log_model_to_dict(log) for log in logs], total
            
        except SQLAlchemyError as e:
            raise Exception(f"Error finding audit logs: {str(e)}")
    
    # ========================================================================
    # Helper Methods
    # ========================================================================
    
    def _create_policy_model(self, policy: GovernancePolicy) -> GovernancePolicyModel:
        """Create policy model from entity"""
        return GovernancePolicyModel(
            id=policy.id,
            name=policy.name,
            description=policy.description,
            policy_type=policy.policy_type.value,
            status=policy.status.value,
            organization_id=policy.organization_id,
            created_by=policy.created_by,
            rules=json.dumps([rule.dict() for rule in policy.rules]),
            lgpd_config=json.dumps(policy.lgpd_config.dict()) if policy.lgpd_config else None,
            retention_config=json.dumps(policy.retention_config.dict()) if policy.retention_config else None,
            access_control=json.dumps(policy.access_control.dict()) if policy.access_control else None,
            classification_config=json.dumps(policy.classification_config.dict()) if policy.classification_config else None,
            applies_to=json.dumps(policy.applies_to),
            tags=policy.tags,
            enabled=policy.enabled,
            effective_date=policy.effective_date,
            expiry_date=policy.expiry_date,
            violation_count=0,
            compliance_score=100.0,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow()
        )
    
    def _update_policy_model(self, model: GovernancePolicyModel, policy: GovernancePolicy):
        """Update policy model from entity"""
        model.name = policy.name
        model.description = policy.description
        model.policy_type = policy.policy_type.value
        model.status = policy.status.value
        model.rules = json.dumps([rule.dict() for rule in policy.rules])
        model.lgpd_config = json.dumps(policy.lgpd_config.dict()) if policy.lgpd_config else None
        model.retention_config = json.dumps(policy.retention_config.dict()) if policy.retention_config else None
        model.access_control = json.dumps(policy.access_control.dict()) if policy.access_control else None
        model.classification_config = json.dumps(policy.classification_config.dict()) if policy.classification_config else None
        model.applies_to = json.dumps(policy.applies_to)
        model.tags = policy.tags
        model.enabled = policy.enabled
        model.effective_date = policy.effective_date
        model.expiry_date = policy.expiry_date
        model.updated_at = datetime.utcnow()
    
    def _model_to_entity(self, model: GovernancePolicyModel) -> GovernancePolicy:
        """Convert model to entity"""
        # Get organization and user names
        org_name = ""
        user_name = ""
        
        if model.organization:
            org_name = model.organization.name
        
        if model.creator:
            user_name = f"{model.creator.first_name} {model.creator.last_name}".strip()
        
        # Parse JSON fields
        rules = json.loads(model.rules) if model.rules else []
        lgpd_config = json.loads(model.lgpd_config) if model.lgpd_config else None
        retention_config = json.loads(model.retention_config) if model.retention_config else None
        access_control = json.loads(model.access_control) if model.access_control else None
        classification_config = json.loads(model.classification_config) if model.classification_config else None
        applies_to = json.loads(model.applies_to) if model.applies_to else []
        
        return GovernancePolicy(
            id=model.id,
            name=model.name,
            description=model.description,
            policy_type=PolicyType(model.policy_type),
            status=PolicyStatus(model.status),
            organization_id=model.organization_id,
            organization_name=org_name,
            created_by=model.created_by,
            created_by_name=user_name,
            rules=rules,
            lgpd_config=lgpd_config,
            retention_config=retention_config,
            access_control=access_control,
            classification_config=classification_config,
            applies_to=applies_to,
            tags=model.tags,
            enabled=model.enabled,
            effective_date=model.effective_date,
            expiry_date=model.expiry_date,
            violation_count=model.violation_count or 0,
            last_violation=model.last_violation,
            compliance_score=model.compliance_score or 100.0,
            created_at=model.created_at,
            updated_at=model.updated_at
        )
    
    def _update_policy_violation_count(self, policy_id: UUID):
        """Update policy violation count"""
        try:
            # Count open violations
            open_violations = self.db_session.query(PolicyViolationModel).filter(
                and_(
                    PolicyViolationModel.policy_id == policy_id,
                    PolicyViolationModel.resolved_at.is_(None)
                )
            ).count()
            
            # Get last violation date
            last_violation = self.db_session.query(func.max(PolicyViolationModel.detected_at)).filter(
                PolicyViolationModel.policy_id == policy_id
            ).scalar()
            
            # Update policy
            policy = self.db_session.query(GovernancePolicyModel).filter(
                GovernancePolicyModel.id == policy_id
            ).first()
            
            if policy:
                policy.violation_count = open_violations
                policy.last_violation = last_violation
                self.db_session.commit()
                
        except SQLAlchemyError as e:
            self.db_session.rollback()
            # Don't raise exception for this helper method
            pass
    
    def _violation_model_to_dict(self, model: PolicyViolationModel) -> Dict[str, Any]:
        """Convert violation model to dict"""
        return {
            "id": model.id,
            "policy_id": model.policy_id,
            "resource_id": model.resource_id,
            "resource_type": model.resource_type,
            "user_id": model.user_id,
            "severity": model.severity,
            "description": model.description,
            "details": model.details or {},
            "detected_at": model.detected_at,
            "resolved_at": model.resolved_at,
            "resolution_notes": model.resolution_notes,
            "resolved_by": model.resolved_by
        }
    
    def _audit_log_model_to_dict(self, model: AuditLogModel) -> Dict[str, Any]:
        """Convert audit log model to dict"""
        return {
            "id": model.id,
            "event_type": model.event_type,
            "user_id": model.user_id,
            "resource_id": model.resource_id,
            "resource_type": model.resource_type,
            "policy_id": model.policy_id,
            "action": model.action,
            "result": model.result,
            "details": model.details or {},
            "ip_address": model.ip_address,
            "user_agent": model.user_agent,
            "timestamp": model.timestamp
        }

