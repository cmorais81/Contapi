# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
Governance Service - Microserviço de Políticas de Governança
Versão: 4.0.1 - Corrigida com base na V3.2
Data: 27 de Janeiro de 2025
"""

import logging
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from uuid import uuid4
from enum import Enum

from fastapi import FastAPI, HTTPException, Query, Path, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'config'))

try:
    from settings import get_settings
    settings = get_settings()
except ImportError:
    print("⚠️ Configurações centralizadas não encontradas, usando valores padrão")
    settings = None


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Governance Service",
    description="Microserviço para políticas de governança de dados - V4.0 Corrigido",
    version="4.0.1",
    contact={
        "name": " ",
        "email": "@example.com"
    }
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# ENUMS
# =====================================================

class PolicyStatus(str, Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    INACTIVE = "inactive"
    ARCHIVED = "archived"

class PolicyType(str, Enum):
    DATA_CLASSIFICATION = "data_classification"
    ACCESS_CONTROL = "access_control"
    RETENTION = "retention"
    PRIVACY = "privacy"
    QUALITY = "quality"
    SECURITY = "security"
    COMPLNCE = "compliance"

class ComplianceFramework(str, Enum):
    LGPD = "lgpd"
    GDPR = "gdpr"
    SOX = "sox"
    HIPAA = "hipaa"
    PCI_DSS = "pci_dss"
    ISO27001 = "iso27001"

class ViolationSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

# =====================================================
# PYDANTIC MODELS
# =====================================================

class PolicyBase(BaseModel):
    name: str = Field(..., description="Nome da política")
    description: Optional[str] = Field(None, description="Descrição da política")
    policy_type: PolicyType = Field(..., description="Tipo da política")
    compliance_frameworks: List[ComplianceFramework] = Field(default_factory=list, description="Frameworks de compliance")
    rules: List[Dict[str, Any]] = Field(default_factory=list, description="Regras da política")
    enforcement_level: str = Field("warning", description="Nível de enforcement")

class PolicyCreate(PolicyBase):
    pass

class PolicyUpdate(PolicyBase):
    status: Optional[PolicyStatus] = Field(None, description="Status da política")

class PolicyResponse(PolicyBase):
    id: str
    status: PolicyStatus
    created_at: datetime
    updated_at: datetime
    created_by: str
    version: int
    last_reviewed: Optional[datetime]

class ViolationBase(BaseModel):
    policy_id: str = Field(..., description="ID da política violada")
    resource_type: str = Field(..., description="Tipo do recurso")
    resource_id: str = Field(..., description="ID do recurso")
    severity: ViolationSeverity = Field(..., description="Severidade da violação")
    description: str = Field(..., description="Descrição da violação")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados adicionais")

class ViolationCreate(ViolationBase):
    pass

class ViolationResponse(ViolationBase):
    id: str
    status: str
    detected_at: datetime
    resolved_at: Optional[datetime]
    resolution_notes: Optional[str]

class ComplianceAssessmentRequest(BaseModel):
    frameworks: List[ComplianceFramework] = Field(..., description="Frameworks para avaliação")
    scope: Optional[str] = Field(None, description="Escopo da avaliação")
    include_recommendations: bool = Field(True, description="Incluir recomendações")

class DataClassificationRequest(BaseModel):
    data_sample: Dict[str, Any] = Field(..., description="Amostra de dados para classificação")
    context: Optional[str] = Field(None, description="Contexto dos dados")

# =====================================================
# IN-MEMORY DATABASE (Simulação)
# =====================================================

policies_db = {}
violations_db = {}
assessments_db = {}
audit_logs = []

def log_audit(action: str, resource_id: str = None, details: str = None):
    """Log audit trail"""
    try:
        audit_logs.append({
            "id": str(uuid4()),
            "action": action,
            "resource_type": "governance",
            "resource_id": resource_id,
            "details": details,
            "created_at": datetime.utcnow().isoformat()
        })
    except Exception as e:
        logger.error(f"Error logging audit: {e}")

def init_sample_data():
    """Initialize sample policies and violations"""
    # Sample policies
    sample_policies = [
        {
            "id": str(uuid4()),
            "name": "PII Data Protection Policy",
            "description": "Política para proteção de dados pessoais identificáveis",
            "policy_type": PolicyType.PRIVACY,
            "compliance_frameworks": [ComplianceFramework.LGPD, ComplianceFramework.GDPR],
            "rules": [
                {
                    "rule_id": "pii_001",
                    "description": "Dados PII devem ser mascarados em ambientes não-produtivos",
                    "condition": "environment != 'production' AND contains_pii = true",
                    "action": "mask_data",
                    "severity": "high"
                },
                {
                    "rule_id": "pii_002",
                    "description": "Acesso a dados PII requer aprovação do Data Owner",
                    "condition": "data_classification = 'pii'",
                    "action": "require_approval",
                    "severity": "medium"
                }
            ],
            "enforcement_level": "blocking",
            "status": PolicyStatus.ACTIVE,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "created_by": "privacy_team",
            "version": 2,
            "last_reviewed": datetime.utcnow() - timedelta(days=30)
        },
        {
            "id": str(uuid4()),
            "name": "Data Retention Policy",
            "description": "Política de retenção e expurgo de dados",
            "policy_type": PolicyType.RETENTION,
            "compliance_frameworks": [ComplianceFramework.LGPD, ComplianceFramework.SOX],
            "rules": [
                {
                    "rule_id": "ret_001",
                    "description": "Dados de clientes devem ser mantidos por no máximo 7 anos",
                    "condition": "data_type = 'customer_data'",
                    "action": "delete_after_7_years",
                    "severity": "medium"
                },
                {
                    "rule_id": "ret_002",
                    "description": "Logs de auditoria devem ser mantidos por 10 anos",
                    "condition": "data_type = 'audit_logs'",
                    "action": "retain_10_years",
                    "severity": "high"
                }
            ],
            "enforcement_level": "warning",
            "status": PolicyStatus.ACTIVE,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "created_by": "compliance_team",
            "version": 1,
            "last_reviewed": datetime.utcnow() - timedelta(days=15)
        },
        {
            "id": str(uuid4()),
            "name": "Data Quality Standards",
            "description": "Padrões mínimos de qualidade de dados",
            "policy_type": PolicyType.QUALITY,
            "compliance_frameworks": [ComplianceFramework.ISO27001],
            "rules": [
                {
                    "rule_id": "qual_001",
                    "description": "Completude mínima de 95% para campos obrigatórios",
                    "condition": "field_type = 'required'",
                    "action": "validate_completeness_95",
                    "severity": "medium"
                },
                {
                    "rule_id": "qual_002",
                    "description": "Emails devem ter formato válido",
                    "condition": "field_type = 'email'",
                    "action": "validate_email_format",
                    "severity": "low"
                }
            ],
            "enforcement_level": "warning",
            "status": PolicyStatus.ACTIVE,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "created_by": "data_quality_team",
            "version": 3,
            "last_reviewed": datetime.utcnow() - timedelta(days=7)
        },
        {
            "id": str(uuid4()),
            "name": "Access Control Policy",
            "description": "Política de controle de acesso a dados sensíveis",
            "policy_type": PolicyType.ACCESS_CONTROL,
            "compliance_frameworks": [ComplianceFramework.SOX, ComplianceFramework.ISO27001],
            "rules": [
                {
                    "rule_id": "acc_001",
                    "description": "Acesso a dados financeiros requer role específico",
                    "condition": "data_classification = 'financial'",
                    "action": "require_financial_role",
                    "severity": "high"
                },
                {
                    "rule_id": "acc_002",
                    "description": "Acesso deve ser revisado trimestralmente",
                    "condition": "access_granted = true",
                    "action": "quarterly_review",
                    "severity": "medium"
                }
            ],
            "enforcement_level": "blocking",
            "status": PolicyStatus.ACTIVE,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "created_by": "security_team",
            "version": 1,
            "last_reviewed": datetime.utcnow() - timedelta(days=45)
        }
    ]
    
    for policy in sample_policies:
        policies_db[policy["id"]] = policy
    
    # Sample violations
    pii_policy = sample_policies[0]
    quality_policy = sample_policies[2]
    
    sample_violations = [
        {
            "id": str(uuid4()),
            "policy_id": pii_policy["id"],
            "resource_type": "table",
            "resource_id": "customers",
            "severity": ViolationSeverity.HIGH,
            "description": "Dados PII detectados em ambiente de desenvolvimento sem mascaramento",
            "metadata": {
                "table": "customers",
                "columns": ["email", "cpf", "phone"],
                "environment": "development",
                "detection_method": "automated_scan"
            },
            "status": "open",
            "detected_at": datetime.utcnow() - timedelta(hours=2),
            "resolved_at": None,
            "resolution_notes": None
        },
        {
            "id": str(uuid4()),
            "policy_id": quality_policy["id"],
            "resource_type": "dataset",
            "resource_id": "sales_data",
            "severity": ViolationSeverity.MEDIUM,
            "description": "Completude abaixo do limite mínimo (89%) para campo obrigatório",
            "metadata": {
                "dataset": "sales_data",
                "field": "customer_email",
                "completeness_score": 89.3,
                "threshold": 95.0,
                "missing_records": 1247
            },
            "status": "in_progress",
            "detected_at": datetime.utcnow() - timedelta(days=1),
            "resolved_at": None,
            "resolution_notes": "Equipe de qualidade investigando origem dos dados faltantes"
        },
        {
            "id": str(uuid4()),
            "policy_id": quality_policy["id"],
            "resource_type": "field",
            "resource_id": "user_emails",
            "severity": ViolationSeverity.LOW,
            "description": "Formato de email inválido detectado em 23 registros",
            "metadata": {
                "field": "user_emails",
                "invalid_count": 23,
                "total_records": 15420,
                "error_rate": 0.15,
                "examples": ["invalid@", "test.email", "user@domain"]
            },
            "status": "resolved",
            "detected_at": datetime.utcnow() - timedelta(days=3),
            "resolved_at": datetime.utcnow() - timedelta(days=1),
            "resolution_notes": "Registros corrigidos automaticamente via script de limpeza"
        }
    ]
    
    for violation in sample_violations:
        violations_db[violation["id"]] = violation
    
    logger.info(f"Initialized {len(sample_policies)} policies and {len(sample_violations)} violations")

def classify_data(data_sample: Dict[str, Any], context: str = None) -> Dict[str, Any]:
    """Classify data based on content and context"""
    classification = {
        "overall_classification": "public",
        "confidence_score": 0.0,
        "detected_types": [],
        "recommendations": [],
        "compliance_impact": []
    }
    
    pii_patterns = {
        "email": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
        "cpf": r"\d{3}\.\d{3}\.\d{3}-\d{2}",
        "phone": r"\(\d{2}\)\s\d{4,5}-\d{4}",
        "credit_card": r"\d{4}\s\d{4}\s\d{4}\s\d{4}"
    }
    
    sensitive_keywords = ["salary", "income", "medical", "health", "financial", "bank", "account"]
    
    detected_pii = []
    max_classification_level = 0
    
    # Analyze each field
    for field_name, field_value in data_sample.items():
        field_str = str(field_value).lower()
        field_classification = "public"
        
        # Check for PII patterns
        for pii_type, pattern in pii_patterns.items():
            import re
            if re.search(pattern, str(field_value)):
                detected_pii.append({
                    "field": field_name,
                    "type": pii_type,
                    "confidence": 0.9
                })
                field_classification = "pii"
                max_classification_level = max(max_classification_level, 3)
        
        # Check for sensitive keywords
        if any(keyword in field_name.lower() or keyword in field_str for keyword in sensitive_keywords):
            field_classification = "sensitive"
            max_classification_level = max(max_classification_level, 2)
        
        # Check field names for common PII indicators
        pii_field_names = ["email", "cpf", "ssn", "phone", "address", "name", "birth"]
        if any(indicator in field_name.lower() for indicator in pii_field_names):
            field_classification = "pii"
            max_classification_level = max(max_classification_level, 3)
    
    # Determine overall classification
    if max_classification_level >= 3:
        classification["overall_classification"] = "pii"
        classification["confidence_score"] = 0.85
    elif max_classification_level >= 2:
        classification["overall_classification"] = "sensitive"
        classification["confidence_score"] = 0.75
    elif max_classification_level >= 1:
        classification["overall_classification"] = "internal"
        classification["confidence_score"] = 0.65
    else:
        classification["overall_classification"] = "public"
        classification["confidence_score"] = 0.90
    
    classification["detected_types"] = detected_pii
    
    # Generate recommendations
    if detected_pii:
        classification["recommendations"].extend([
            "Implementar mascaramento de dados em ambientes não-produtivos",
            "Configurar controles de acesso restritivos",
            "Implementar criptografia em repouso e em trânsito",
            "Configurar auditoria de acesso"
        ])
        classification["compliance_impact"].extend([
            "LGPD: Dados pessoais identificados - requer consentimento e proteção adequada",
            "GDPR: PII detectado - aplicar princípios de minimização e proteção"
        ])
    
    if classification["overall_classification"] in ["sensitive", "pii"]:
        classification["recommendations"].append("Revisar políticas de retenção de dados")
        classification["recommendations"].append("Implementar monitoramento de acesso")
    
    return classification

def assess_compliance(frameworks: List[ComplianceFramework], scope: str = None) -> Dict[str, Any]:
    """Assess compliance against specified frameworks"""
    assessment = {
        "overall_score": 0.0,
        "framework_scores": {},
        "violations_summary": {},
        "recommendations": [],
        "action_items": []
    }
    
    # Count violations by framework
    framework_violations = {framework: [] for framework in frameworks}
    
    for violation in violations_db.values():
        if violation["status"] != "resolved":
            policy = policies_db.get(violation["policy_id"])
            if policy:
                for framework in frameworks:
                    if framework in policy["compliance_frameworks"]:
                        framework_violations[framework].append(violation)
    
    # Calculate scores for each framework
    total_score = 0
    for framework in frameworks:
        violations = framework_violations[framework]
        
        # Simple scoring: start with 100, deduct points for violations
        score = 100.0
        for violation in violations:
            if violation["severity"] == ViolationSeverity.CRITICAL:
                score -= 25
            elif violation["severity"] == ViolationSeverity.HIGH:
                score -= 15
            elif violation["severity"] == ViolationSeverity.MEDIUM:
                score -= 10
            elif violation["severity"] == ViolationSeverity.LOW:
                score -= 5
        
        score = max(0, score)  # Don't go below 0
        assessment["framework_scores"][framework] = score
        total_score += score
        
        # Violations summary
        assessment["violations_summary"][framework] = {
            "total": len(violations),
            "critical": len([v for v in violations if v["severity"] == ViolationSeverity.CRITICAL]),
            "high": len([v for v in violations if v["severity"] == ViolationSeverity.HIGH]),
            "medium": len([v for v in violations if v["severity"] == ViolationSeverity.MEDIUM]),
            "low": len([v for v in violations if v["severity"] == ViolationSeverity.LOW])
        }
    
    # Overall score
    assessment["overall_score"] = total_score / len(frameworks) if frameworks else 0
    
    # Generate recommendations based on score
    if assessment["overall_score"] < 70:
        assessment["recommendations"].extend([
            "Implementar programa de governança de dados mais rigoroso",
            "Aumentar frequência de auditorias de compliance",
            "Treinar equipes sobre políticas de dados",
            "Implementar controles automatizados de compliance"
        ])
        assessment["action_items"].extend([
            "Resolver violações críticas e de alta severidade imediatamente",
            "Revisar e atualizar políticas de dados",
            "Implementar monitoramento contínuo de compliance"
        ])
    elif assessment["overall_score"] < 85:
        assessment["recommendations"].extend([
            "Melhorar processos de monitoramento de dados",
            "Implementar alertas automáticos para violações",
            "Revisar políticas de acesso a dados"
        ])
        assessment["action_items"].extend([
            "Resolver violações pendentes",
            "Implementar controles preventivos adicionais"
        ])
    else:
        assessment["recommendations"].extend([
            "Manter práticas atuais de governança",
            "Considerar certificações de compliance",
            "Implementar melhorias contínuas"
        ])
    
    return assessment

# =====================================================
# API ENDPOINTS
# =====================================================

@app.get("/", tags=["System"])
async def root():
    """Root endpoint with service information"""
    return {
        "service": "Governance Service",
        "version": "4.0.1",
        "status": "running",
        "description": "Microserviço para políticas de governança de dados - Corrigido",
        "corrections_applied": [
            "Dependências estabilizadas",
            "Error handling robusto",
            "Logs estruturados",
            "In-memory database funcional"
        ],
        "endpoints": {
            "health": "/health",
            "docs": "/docs",
            "policies": "/api/v1/policies",
            "violations": "/api/v1/violations",
            "compliance": "/api/v1/compliance",
            "classification": "/api/v1/classification"
        }
    }

@app.get("/health", tags=["System"])
async def health_check():
    """Health check endpoint"""
    try:
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "version": "4.0.1",
            "service": "governance-service",
            "port": 8007,
            "corrections_applied": True,
            "data_counts": {
                "policies": len(policies_db),
                "violations": len(violations_db),
                "assessments": len(assessments_db),
                "audit_logs": len(audit_logs)
            },
            "features": {
                "policy_management": True,
                "violation_tracking": True,
                "compliance_assessment": True,
                "data_classification": True,
                "framework_support": True,
                "audit_trail": True
            }
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "status": "unhealthy",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

@app.get("/api/v1/policies", response_model=List[PolicyResponse], tags=["Policies"])
async def list_policies(
    policy_type: Optional[PolicyType] = Query(None, description="Filtrar por tipo"),
    status: Optional[PolicyStatus] = Query(None, description="Filtrar por status"),
    framework: Optional[ComplianceFramework] = Query(None, description="Filtrar por framework"),
    limit: int = Query(100, description="Limite de resultados")
):
    """Listar todas as políticas"""
    try:
        policies = list(policies_db.values())
        
        # Apply filters
        if policy_type:
            policies = [p for p in policies if p["policy_type"] == policy_type]
        
        if status:
            policies = [p for p in policies if p["status"] == status]
            
        if framework:
            policies = [p for p in policies if framework in p["compliance_frameworks"]]
        
        # Apply limit
        policies = policies[:limit]
        
        # Convert datetime objects to ISO format
        for policy in policies:
            policy["created_at"] = policy["created_at"].isoformat()
            policy["updated_at"] = policy["updated_at"].isoformat()
            if policy["last_reviewed"]:
                policy["last_reviewed"] = policy["last_reviewed"].isoformat()
        
        log_audit("list_policies", details=f"Listed {len(policies)} policies")
        return policies
        
    except Exception as e:
        logger.error(f"Error listing policies: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing policies: {str(e)}")

@app.get("/api/v1/policies/{policy_id}", response_model=PolicyResponse, tags=["Policies"])
async def get_policy(policy_id: str = Path(..., description="ID da política")):
    """Buscar política específica por ID"""
    try:
        if policy_id not in policies_db:
            raise HTTPException(status_code=404, detail="Policy not found")
        
        policy = policies_db[policy_id].copy()
        policy["created_at"] = policy["created_at"].isoformat()
        policy["updated_at"] = policy["updated_at"].isoformat()
        if policy["last_reviewed"]:
            policy["last_reviewed"] = policy["last_reviewed"].isoformat()
        
        log_audit("get_policy", resource_id=policy_id)
        return policy
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting policy: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting policy: {str(e)}")

@app.post("/api/v1/policies", response_model=PolicyResponse, tags=["Policies"])
async def create_policy(policy: PolicyCreate):
    """Criar nova política"""
    try:
        policy_id = str(uuid4())
        now = datetime.utcnow()
        
        new_policy = {
            "id": policy_id,
            "name": policy.name,
            "description": policy.description,
            "policy_type": policy.policy_type,
            "compliance_frameworks": policy.compliance_frameworks,
            "rules": policy.rules,
            "enforcement_level": policy.enforcement_level,
            "status": PolicyStatus.DRAFT,
            "created_at": now,
            "updated_at": now,
            "created_by": "current_user",  # In real implementation, get from auth
            "version": 1,
            "last_reviewed": None
        }
        
        policies_db[policy_id] = new_policy
        
        log_audit("create_policy", resource_id=policy_id, details=f"Created policy: {policy.name}")
        
        # Convert datetime for response
        response_policy = new_policy.copy()
        response_policy["created_at"] = response_policy["created_at"].isoformat()
        response_policy["updated_at"] = response_policy["updated_at"].isoformat()
        
        return response_policy
        
    except Exception as e:
        logger.error(f"Error creating policy: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating policy: {str(e)}")

@app.put("/api/v1/policies/{policy_id}", response_model=PolicyResponse, tags=["Policies"])
async def update_policy(policy_id: str, policy: PolicyUpdate):
    """Atualizar política existente"""
    try:
        if policy_id not in policies_db:
            raise HTTPException(status_code=404, detail="Policy not found")
        
        existing_policy = policies_db[policy_id]
        
        # Update fields
        existing_policy.update({
            "name": policy.name,
            "description": policy.description,
            "policy_type": policy.policy_type,
            "compliance_frameworks": policy.compliance_frameworks,
            "rules": policy.rules,
            "enforcement_level": policy.enforcement_level,
            "updated_at": datetime.utcnow(),
            "version": existing_policy["version"] + 1
        })
        
        if policy.status:
            existing_policy["status"] = policy.status
        
        log_audit("update_policy", resource_id=policy_id, details=f"Updated policy: {policy.name}")
        
        # Convert datetime for response
        response_policy = existing_policy.copy()
        response_policy["created_at"] = response_policy["created_at"].isoformat()
        response_policy["updated_at"] = response_policy["updated_at"].isoformat()
        if response_policy["last_reviewed"]:
            response_policy["last_reviewed"] = response_policy["last_reviewed"].isoformat()
        
        return response_policy
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating policy: {e}")
        raise HTTPException(status_code=500, detail=f"Error updating policy: {str(e)}")

@app.get("/api/v1/violations", response_model=List[ViolationResponse], tags=["Violations"])
async def list_violations(
    policy_id: Optional[str] = Query(None, description="Filtrar por política"),
    severity: Optional[ViolationSeverity] = Query(None, description="Filtrar por severidade"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    resource_type: Optional[str] = Query(None, description="Filtrar por tipo de recurso"),
    limit: int = Query(100, description="Limite de resultados")
):
    """Listar todas as violações"""
    try:
        violations = list(violations_db.values())
        
        # Apply filters
        if policy_id:
            violations = [v for v in violations if v["policy_id"] == policy_id]
        
        if severity:
            violations = [v for v in violations if v["severity"] == severity]
            
        if status:
            violations = [v for v in violations if v["status"] == status]
            
        if resource_type:
            violations = [v for v in violations if v["resource_type"] == resource_type]
        
        # Sort by detected_at (newest first)
        violations.sort(key=lambda x: x["detected_at"], reverse=True)
        
        # Apply limit
        violations = violations[:limit]
        
        # Convert datetime objects to ISO format
        for violation in violations:
            violation["detected_at"] = violation["detected_at"].isoformat()
            if violation["resolved_at"]:
                violation["resolved_at"] = violation["resolved_at"].isoformat()
        
        log_audit("list_violations", details=f"Listed {len(violations)} violations")
        return violations
        
    except Exception as e:
        logger.error(f"Error listing violations: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing violations: {str(e)}")

@app.post("/api/v1/violations", response_model=ViolationResponse, tags=["Violations"])
async def create_violation(violation: ViolationCreate):
    """Registrar nova violação"""
    try:
        if violation.policy_id not in policies_db:
            raise HTTPException(status_code=404, detail="Policy not found")
        
        violation_id = str(uuid4())
        now = datetime.utcnow()
        
        new_violation = {
            "id": violation_id,
            "policy_id": violation.policy_id,
            "resource_type": violation.resource_type,
            "resource_id": violation.resource_id,
            "severity": violation.severity,
            "description": violation.description,
            "metadata": violation.metadata or {},
            "status": "open",
            "detected_at": now,
            "resolved_at": None,
            "resolution_notes": None
        }
        
        violations_db[violation_id] = new_violation
        
        log_audit("create_violation", resource_id=violation_id, 
                 details=f"Violation detected: {violation.description}")
        
        # Convert datetime for response
        response_violation = new_violation.copy()
        response_violation["detected_at"] = response_violation["detected_at"].isoformat()
        
        return response_violation
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating violation: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating violation: {str(e)}")

@app.put("/api/v1/violations/{violation_id}/resolve", tags=["Violations"])
async def resolve_violation(violation_id: str, resolution_notes: str = Body(..., embed=True)):
    """Resolver violação"""
    try:
        if violation_id not in violations_db:
            raise HTTPException(status_code=404, detail="Violation not found")
        
        violation = violations_db[violation_id]
        violation["status"] = "resolved"
        violation["resolved_at"] = datetime.utcnow()
        violation["resolution_notes"] = resolution_notes
        
        log_audit("resolve_violation", resource_id=violation_id, 
                 details=f"Violation resolved: {resolution_notes}")
        
        return {
            "violation_id": violation_id,
            "status": "resolved",
            "resolved_at": violation["resolved_at"].isoformat(),
            "resolution_notes": resolution_notes
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error resolving violation: {e}")
        raise HTTPException(status_code=500, detail=f"Error resolving violation: {str(e)}")

@app.post("/api/v1/compliance/assess", tags=["Compliance"])
async def assess_compliance_endpoint(request: ComplianceAssessmentRequest):
    """Realizar avaliação de compliance"""
    try:
        assessment = assess_compliance(request.frameworks, request.scope)
        
        # Store assessment
        assessment_id = str(uuid4())
        assessment_record = {
            "id": assessment_id,
            "frameworks": request.frameworks,
            "scope": request.scope,
            "assessment": assessment,
            "created_at": datetime.utcnow()
        }
        assessments_db[assessment_id] = assessment_record
        
        log_audit("assess_compliance", resource_id=assessment_id, 
                 details=f"Compliance assessment for frameworks: {request.frameworks}")
        
        result = {
            "assessment_id": assessment_id,
            "frameworks": request.frameworks,
            "scope": request.scope,
            "assessment": assessment,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        if request.include_recommendations:
            result["recommendations"] = assessment["recommendations"]
            result["action_items"] = assessment["action_items"]
        
        return result
        
    except Exception as e:
        logger.error(f"Error assessing compliance: {e}")
        raise HTTPException(status_code=500, detail=f"Error assessing compliance: {str(e)}")

@app.post("/api/v1/classification/classify", tags=["Classification"])
async def classify_data_endpoint(request: DataClassificationRequest):
    """Classificar dados automaticamente"""
    try:
        classification = classify_data(request.data_sample, request.context)
        
        log_audit("classify_data", details=f"Data classified as: {classification['overall_classification']}")
        
        return {
            "data_sample": request.data_sample,
            "context": request.context,
            "classification": classification,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error classifying data: {e}")
        raise HTTPException(status_code=500, detail=f"Error classifying data: {str(e)}")

@app.get("/api/v1/frameworks", tags=["Frameworks"])
async def list_compliance_frameworks():
    """Listar frameworks de compliance suportados"""
    try:
        frameworks = []
        for framework in ComplianceFramework:
            framework_info = {
                "code": framework.value,
                "name": framework.value.upper(),
                "description": f"Framework de compliance {framework.value.upper()}"
            }
            
            # Add specific descriptions
            if framework == ComplianceFramework.LGPD:
                framework_info["description"] = "Lei Geral de Proteção de Dados (Brasil)"
                framework_info["region"] = "Brasil"
            elif framework == ComplianceFramework.GDPR:
                framework_info["description"] = "General Data Protection Regulation (União Europeia)"
                framework_info["region"] = "União Europeia"
            elif framework == ComplianceFramework.SOX:
                framework_info["description"] = "Sarbanes-Oxley Act (Estados Unidos)"
                framework_info["region"] = "Estados Unidos"
            elif framework == ComplianceFramework.HIPAA:
                framework_info["description"] = "Health Insurance Portability and Accountability Act"
                framework_info["region"] = "Estados Unidos"
            elif framework == ComplianceFramework.PCI_DSS:
                framework_info["description"] = "Payment Card Industry Data Security Standard"
                framework_info["region"] = "Global"
            elif framework == ComplianceFramework.ISO27001:
                framework_info["description"] = "ISO/IEC 27001 Information Security Management"
                framework_info["region"] = "Global"
            
            frameworks.append(framework_info)
        
        return {
            "frameworks": frameworks,
            "total_count": len(frameworks)
        }
        
    except Exception as e:
        logger.error(f"Error listing frameworks: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing frameworks: {str(e)}")

@app.get("/api/v1/dashboard", tags=["Dashboard"])
async def get_governance_dashboard():
    """Obter dashboard de governança"""
    try:
        # Calculate statistics
        total_policies = len(policies_db)
        active_policies = len([p for p in policies_db.values() if p["status"] == PolicyStatus.ACTIVE])
        total_violations = len(violations_db)
        open_violations = len([v for v in violations_db.values() if v["status"] == "open"])
        
        # Violations by severity
        violation_severity_counts = {}
        for violation in violations_db.values():
            if violation["status"] != "resolved":
                severity = violation["severity"]
                violation_severity_counts[severity] = violation_severity_counts.get(severity, 0) + 1
        
        # Policy types breakdown
        policy_type_counts = {}
        for policy in policies_db.values():
            if policy["status"] == PolicyStatus.ACTIVE:
                policy_type = policy["policy_type"]
                policy_type_counts[policy_type] = policy_type_counts.get(policy_type, 0) + 1
        
        # Compliance frameworks usage
        framework_counts = {}
        for policy in policies_db.values():
            if policy["status"] == PolicyStatus.ACTIVE:
                for framework in policy["compliance_frameworks"]:
                    framework_counts[framework] = framework_counts.get(framework, 0) + 1
        
        # Recent activity (last 7 days)
        recent_cutoff = datetime.utcnow() - timedelta(days=7)
        recent_violations = len([v for v in violations_db.values() if v["detected_at"] >= recent_cutoff])
        recent_resolutions = len([v for v in violations_db.values() 
                                if v["resolved_at"] and v["resolved_at"] >= recent_cutoff])
        
        # Calculate overall governance score
        if total_violations > 0:
            resolution_rate = len([v for v in violations_db.values() if v["status"] == "resolved"]) / total_violations
            governance_score = min(100, max(0, (resolution_rate * 100) - (open_violations * 2)))
        else:
            governance_score = 95  # High score if no violations
        
        return {
            "summary": {
                "total_policies": total_policies,
                "active_policies": active_policies,
                "total_violations": total_violations,
                "open_violations": open_violations,
                "governance_score": round(governance_score, 1),
                "recent_violations_7d": recent_violations,
                "recent_resolutions_7d": recent_resolutions
            },
            "violation_severity_breakdown": violation_severity_counts,
            "policy_type_breakdown": policy_type_counts,
            "framework_usage": framework_counts,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting governance dashboard: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting governance dashboard: {str(e)}")

@app.get("/api/v1/audit/logs", tags=["Audit"])
async def list_audit_logs(limit: int = Query(100, description="Limite de resultados")):
    """Listar logs de auditoria"""
    try:
        logs = audit_logs[-limit:] if limit < len(audit_logs) else audit_logs
        return logs
    except Exception as e:
        logger.error(f"Error listing audit logs: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing audit logs: {str(e)}")

# Initialize sample data on startup
@app.on_event("startup")
async def startup_event():
    """Initialize service on startup"""
    logger.info("Starting Governance Service V4.0.1 - Corrigido")
    init_sample_data()
    logger.info("Governance Service started successfully")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8007)

