# Autor: carlos.morais@f1rst.com.br
"""
Shared modules for Microservices V4.1
"""

