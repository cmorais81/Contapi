# Autor: carlos.morais@f1rst.com.br
"""
Central Database Models
SQLAlchemy models for the shared central database
Based on the working monolithic solution schema
"""

from datetime import datetime
from typing import Optional, List, Dict, Any
from uuid import UUID, uuid4
from sqlalchemy import (
    Column, String, Text, Integer, Float, Boolean, DateTime, 
    ForeignKey, JSON, BigInteger, Index
)
from sqlalchemy.dialects.postgresql import UUID as PG_UUID, INET, JSONB, TIMESTAMPTZ
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, backref
from sqlalchemy.sql import func

Base = declarative_base()


class Organization(Base):
    """Organization model"""
    __tablename__ = 'organizations'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(Text, nullable=False)
    description = Column(Text)
    domain = Column(Text)
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    updated_at = Column(TIMESTAMPTZ, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relationships
    users = relationship("User", back_populates="organization")
    datasets = relationship("Dataset", back_populates="organization")
    contracts = relationship("Contract", back_populates="organization")
    analytics_reports = relationship("AnalyticsReport", back_populates="organization")
    governance_policies = relationship("GovernancePolicy", back_populates="organization")


class User(Base):
    """User model for Identity Service"""
    __tablename__ = 'users'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    organization_id = Column(PG_UUID(as_uuid=True), ForeignKey('organizations.id'))
    name = Column(Text, nullable=False)
    email = Column(Text, unique=True, nullable=False)
    password_hash = Column(Text)
    role = Column(Text, default='user')
    permissions = Column(JSONB, default=list)
    department = Column(Text)
    is_active = Column(Boolean, default=True)
    last_login = Column(TIMESTAMPTZ)
    failed_login_attempts = Column(Integer, default=0)
    account_locked_until = Column(TIMESTAMPTZ)
    two_factor_enabled = Column(Boolean, default=False)
    session_token = Column(Text)
    session_expires_at = Column(TIMESTAMPTZ)
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    updated_at = Column(TIMESTAMPTZ, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relationships
    organization = relationship("Organization", back_populates="users")
    owned_datasets = relationship("Dataset", foreign_keys="Dataset.owner_id", back_populates="owner")
    stewarded_datasets = relationship("Dataset", foreign_keys="Dataset.steward_id", back_populates="steward")
    owned_contracts = relationship("Contract", foreign_keys="Contract.owner_id", back_populates="owner")
    stewarded_contracts = relationship("Contract", foreign_keys="Contract.steward_id", back_populates="steward")
    created_contracts = relationship("Contract", foreign_keys="Contract.created_by", back_populates="creator")
    updated_contracts = relationship("Contract", foreign_keys="Contract.updated_by", back_populates="updater")
    access_logs = relationship("AccessLog", back_populates="user")
    
    # Indexes
    __table_args__ = (
        Index('idx_users_organization_id', 'organization_id'),
        Index('idx_users_email', 'email'),
        Index('idx_users_role', 'role'),
        Index('idx_users_is_active', 'is_active'),
    )


class Dataset(Base):
    """Dataset model for Catalog Service"""
    __tablename__ = 'datasets'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(Text, nullable=False)
    title = Column(Text)
    description = Column(Text)
    source_system = Column(Text)
    database_name = Column(Text)
    schema_name = Column(Text)
    table_name = Column(Text)
    owner_id = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    steward_id = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    classification = Column(Text, default='internal')
    status = Column(Text, default='active')
    tags = Column(JSONB, default=list)
    metadata = Column(JSONB, default=dict)
    schema_definition = Column(JSONB)
    row_count = Column(BigInteger, default=0)
    size_bytes = Column(BigInteger, default=0)
    last_updated = Column(TIMESTAMPTZ)
    popularity_score = Column(Float, default=0.0)
    quality_score = Column(Float, default=0.0)
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    updated_at = Column(TIMESTAMPTZ, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relationships
    organization = relationship("Organization", back_populates="datasets")
    owner = relationship("User", foreign_keys=[owner_id], back_populates="owned_datasets")
    steward = relationship("User", foreign_keys=[steward_id], back_populates="stewarded_datasets")
    contracts = relationship("Contract", back_populates="dataset")
    quality_metrics = relationship("QualityMetric", back_populates="dataset")
    data_catalog_entries = relationship("DataCatalog", back_populates="dataset")
    
    # Indexes
    __table_args__ = (
        Index('idx_datasets_owner_id', 'owner_id'),
        Index('idx_datasets_steward_id', 'steward_id'),
        Index('idx_datasets_status', 'status'),
        Index('idx_datasets_classification', 'classification'),
    )


class Contract(Base):
    """Contract model for Contract Service - main entity"""
    __tablename__ = 'contracts'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(Text, nullable=False)
    title = Column(Text, nullable=False)
    description = Column(Text)
    version = Column(Text, default='1.0.0')
    status = Column(Text, default='draft')
    is_active = Column(Boolean, default=False)
    dataset_id = Column(PG_UUID(as_uuid=True), ForeignKey('datasets.id'))
    owner_id = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    steward_id = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    organization_id = Column(PG_UUID(as_uuid=True), ForeignKey('organizations.id'))
    schema_definition = Column(JSONB)
    schema_hash = Column(Text)
    data_classification = Column(Text, default='internal')
    contains_pii = Column(Boolean, default=False)
    pii_fields = Column(JSONB, default=list)
    quality_requirements = Column(JSONB, default=dict)
    sla_requirements = Column(JSONB, default=dict)
    retention_policy = Column(JSONB, default=dict)
    approval_status = Column(Text)
    approved_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    approved_at = Column(TIMESTAMPTZ)
    expires_at = Column(TIMESTAMPTZ)
    lgpd_compliance_status = Column(Text, default='unknown')
    lgpd_compliance_score = Column(Float, default=0.0)
    last_compliance_check = Column(TIMESTAMPTZ)
    quality_score = Column(Float, default=0.0)
    completeness_rate = Column(Float, default=0.0)
    accuracy_rate = Column(Float, default=0.0)
    consistency_rate = Column(Float, default=0.0)
    last_quality_check = Column(TIMESTAMPTZ)
    usage_count = Column(Integer, default=0)
    last_used_at = Column(TIMESTAMPTZ)
    documentation_url = Column(Text)
    tags = Column(JSONB, default=list)
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    updated_at = Column(TIMESTAMPTZ, default=func.current_timestamp(), onupdate=func.current_timestamp())
    created_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    updated_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    deleted_at = Column(TIMESTAMPTZ)
    
    # Relationships
    organization = relationship("Organization", back_populates="contracts")
    dataset = relationship("Dataset", back_populates="contracts")
    owner = relationship("User", foreign_keys=[owner_id], back_populates="owned_contracts")
    steward = relationship("User", foreign_keys=[steward_id], back_populates="stewarded_contracts")
    creator = relationship("User", foreign_keys=[created_by], back_populates="created_contracts")
    updater = relationship("User", foreign_keys=[updated_by], back_populates="updated_contracts")
    approver = relationship("User", foreign_keys=[approved_by])
    versions = relationship("ContractVersion", back_populates="contract")
    approvals = relationship("ContractApproval", back_populates="contract")
    pii_classifications = relationship("PIIClassification", back_populates="contract")
    quality_metrics = relationship("QualityMetric", back_populates="contract")
    compliance_assessments = relationship("ComplianceAssessment", back_populates="contract")
    
    # Indexes
    __table_args__ = (
        Index('idx_contracts_organization_id', 'organization_id'),
        Index('idx_contracts_owner_id', 'owner_id'),
        Index('idx_contracts_status', 'status'),
        Index('idx_contracts_contains_pii', 'contains_pii'),
        Index('idx_contracts_name', 'name'),
        Index('idx_contracts_created_at', 'created_at'),
        Index('idx_contracts_deleted_at', 'deleted_at'),
    )


class ContractVersion(Base):
    """Contract version model"""
    __tablename__ = 'contract_versions'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('contracts.id', ondelete='CASCADE'))
    version = Column(Text, nullable=False)
    changes_summary = Column(Text)
    schema_definition = Column(JSONB)
    schema_hash = Column(Text)
    created_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    is_current = Column(Boolean, default=False)
    
    # Relationships
    contract = relationship("Contract", back_populates="versions")
    creator = relationship("User")


class ContractApproval(Base):
    """Contract approval model"""
    __tablename__ = 'contract_approvals'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('contracts.id', ondelete='CASCADE'))
    version = Column(Text)
    approver_id = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    status = Column(Text, default='pending')
    approval_type = Column(Text, default='standard')
    comments = Column(Text)
    conditions = Column(JSONB, default=list)
    requested_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    responded_at = Column(TIMESTAMPTZ)
    expires_at = Column(TIMESTAMPTZ)
    
    # Relationships
    contract = relationship("Contract", back_populates="approvals")
    approver = relationship("User")


class PIIClassification(Base):
    """PII classification model"""
    __tablename__ = 'pii_classifications'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('contracts.id', ondelete='CASCADE'))
    field_name = Column(Text, nullable=False)
    pii_type = Column(Text, nullable=False)
    sensitivity_level = Column(Text, default='medium')
    confidence_score = Column(Float, default=0.0)
    detection_method = Column(Text)
    masking_strategy = Column(Text)
    retention_period = Column(Text)
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    updated_at = Column(TIMESTAMPTZ, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relationships
    contract = relationship("Contract", back_populates="pii_classifications")
    
    # Indexes
    __table_args__ = (
        Index('idx_pii_classifications_contract_id', 'contract_id'),
        Index('idx_pii_classifications_pii_type', 'pii_type'),
    )


class MaskingPolicy(Base):
    """Masking policy model"""
    __tablename__ = 'masking_policies'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(Text, nullable=False)
    description = Column(Text)
    pii_type = Column(Text, nullable=False)
    masking_strategy = Column(Text, nullable=False)
    configuration = Column(JSONB, default=dict)
    is_active = Column(Boolean, default=True)
    created_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    updated_at = Column(TIMESTAMPTZ, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relationships
    creator = relationship("User")


class QualityRule(Base):
    """Quality rule model for Quality Service"""
    __tablename__ = 'quality_rules'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(Text, nullable=False)
    description = Column(Text)
    rule_type = Column(Text, nullable=False)
    category = Column(Text)
    severity = Column(Text, default='medium')
    sql_expression = Column(Text)
    python_code = Column(Text)
    threshold_value = Column(Float)
    threshold_operator = Column(Text)
    is_active = Column(Boolean, default=True)
    schedule_cron = Column(Text)
    retry_count = Column(Integer, default=3)
    timeout_seconds = Column(Integer, default=300)
    created_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    updated_at = Column(TIMESTAMPTZ, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relationships
    creator = relationship("User")
    quality_metrics = relationship("QualityMetric", back_populates="rule")


class QualityMetric(Base):
    """Quality metric model"""
    __tablename__ = 'quality_metrics'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('contracts.id'))
    dataset_id = Column(PG_UUID(as_uuid=True), ForeignKey('datasets.id'))
    rule_id = Column(PG_UUID(as_uuid=True), ForeignKey('quality_rules.id'))
    metric_name = Column(Text, nullable=False)
    metric_value = Column(Float)
    threshold_value = Column(Float)
    status = Column(Text, default='unknown')
    execution_time = Column(TIMESTAMPTZ, default=func.current_timestamp())
    execution_duration_ms = Column(Integer)
    error_message = Column(Text)
    details = Column(JSONB, default=dict)
    
    # Relationships
    contract = relationship("Contract", back_populates="quality_metrics")
    dataset = relationship("Dataset", back_populates="quality_metrics")
    rule = relationship("QualityRule", back_populates="quality_metrics")
    
    # Indexes
    __table_args__ = (
        Index('idx_quality_metrics_contract_id', 'contract_id'),
        Index('idx_quality_metrics_dataset_id', 'dataset_id'),
        Index('idx_quality_metrics_execution_time', 'execution_time'),
    )


class DataLineage(Base):
    """Data lineage model"""
    __tablename__ = 'data_lineage'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    source_dataset_id = Column(PG_UUID(as_uuid=True), ForeignKey('datasets.id'))
    target_dataset_id = Column(PG_UUID(as_uuid=True), ForeignKey('datasets.id'))
    transformation_type = Column(Text)
    transformation_logic = Column(Text)
    confidence_score = Column(Float, default=1.0)
    created_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    
    # Relationships
    source_dataset = relationship("Dataset", foreign_keys=[source_dataset_id])
    target_dataset = relationship("Dataset", foreign_keys=[target_dataset_id])
    creator = relationship("User")


class AccessLog(Base):
    """Access log model"""
    __tablename__ = 'access_logs'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('contracts.id'))
    dataset_id = Column(PG_UUID(as_uuid=True), ForeignKey('datasets.id'))
    action = Column(Text, nullable=False)
    resource_type = Column(Text)
    resource_id = Column(PG_UUID(as_uuid=True))
    ip_address = Column(INET)
    user_agent = Column(Text)
    status_code = Column(Integer)
    response_time_ms = Column(Integer)
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    
    # Relationships
    user = relationship("User", back_populates="access_logs")
    contract = relationship("Contract")
    dataset = relationship("Dataset")
    
    # Indexes
    __table_args__ = (
        Index('idx_access_logs_user_id', 'user_id'),
        Index('idx_access_logs_contract_id', 'contract_id'),
        Index('idx_access_logs_created_at', 'created_at'),
    )


class AnalyticsReport(Base):
    """Analytics report model for Analytics Service"""
    __tablename__ = 'analytics_reports'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(Text, nullable=False)
    description = Column(Text)
    report_type = Column(Text, nullable=False)
    organization_id = Column(PG_UUID(as_uuid=True), ForeignKey('organizations.id'))
    parameters = Column(JSONB, default=dict)
    schedule_cron = Column(Text)
    output_format = Column(Text, default='json')
    recipients = Column(JSONB, default=list)
    is_active = Column(Boolean, default=True)
    last_execution = Column(TIMESTAMPTZ)
    next_execution = Column(TIMESTAMPTZ)
    created_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    updated_at = Column(TIMESTAMPTZ, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relationships
    organization = relationship("Organization", back_populates="analytics_reports")
    creator = relationship("User")


class GovernancePolicy(Base):
    """Governance policy model for Governance Service"""
    __tablename__ = 'governance_policies'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(Text, nullable=False)
    description = Column(Text)
    policy_type = Column(Text, nullable=False)
    category = Column(Text)
    scope = Column(Text, default='organization')
    rules = Column(JSONB, default=list)
    enforcement_level = Column(Text, default='warning')
    is_active = Column(Boolean, default=True)
    effective_date = Column(TIMESTAMPTZ, default=func.current_timestamp())
    expiry_date = Column(TIMESTAMPTZ)
    organization_id = Column(PG_UUID(as_uuid=True), ForeignKey('organizations.id'))
    created_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    updated_at = Column(TIMESTAMPTZ, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relationships
    organization = relationship("Organization", back_populates="governance_policies")
    creator = relationship("User")


class ComplianceAssessment(Base):
    """Compliance assessment model"""
    __tablename__ = 'compliance_assessments'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('contracts.id'))
    framework = Column(Text, nullable=False)
    status = Column(Text, default='pending')
    score = Column(Float, default=0.0)
    requirements_met = Column(JSONB, default=list)
    requirements_pending = Column(JSONB, default=list)
    recommendations = Column(JSONB, default=list)
    assessed_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    assessed_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    next_assessment = Column(TIMESTAMPTZ)
    
    # Relationships
    contract = relationship("Contract", back_populates="compliance_assessments")
    assessor = relationship("User")


class WorkflowTask(Base):
    """Workflow task model for Workflow Service"""
    __tablename__ = 'workflow_tasks'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    name = Column(Text, nullable=False)
    description = Column(Text)
    task_type = Column(Text, nullable=False)
    configuration = Column(JSONB, default=dict)
    dependencies = Column(JSONB, default=list)
    retry_policy = Column(JSONB, default=dict)
    timeout_seconds = Column(Integer, default=300)
    is_active = Column(Boolean, default=True)
    created_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    updated_at = Column(TIMESTAMPTZ, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relationships
    creator = relationship("User")


class WorkflowExecution(Base):
    """Workflow execution model"""
    __tablename__ = 'workflow_executions'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    workflow_name = Column(Text, nullable=False)
    workflow_type = Column(Text, nullable=False)
    status = Column(Text, default='pending')
    input_parameters = Column(JSONB, default=dict)
    output_results = Column(JSONB, default=dict)
    started_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    completed_at = Column(TIMESTAMPTZ)
    error_message = Column(Text)
    execution_context = Column(JSONB, default=dict)
    triggered_by = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    
    # Relationships
    trigger_user = relationship("User")


class DataCatalog(Base):
    """Data catalog model for enhanced Catalog Service"""
    __tablename__ = 'data_catalog'
    
    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid4)
    dataset_id = Column(PG_UUID(as_uuid=True), ForeignKey('datasets.id'))
    business_term = Column(Text)
    technical_term = Column(Text)
    definition = Column(Text)
    data_type = Column(Text)
    format = Column(Text)
    example_values = Column(JSONB, default=list)
    business_rules = Column(Text)
    data_source = Column(Text)
    update_frequency = Column(Text)
    data_owner = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    data_steward = Column(PG_UUID(as_uuid=True), ForeignKey('users.id'))
    created_at = Column(TIMESTAMPTZ, default=func.current_timestamp())
    updated_at = Column(TIMESTAMPTZ, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relationships
    dataset = relationship("Dataset", back_populates="data_catalog_entries")
    owner = relationship("User", foreign_keys=[data_owner])
    steward = relationship("User", foreign_keys=[data_steward])


# Export all models
__all__ = [
    'Base',
    'Organization',
    'User', 
    'Dataset',
    'Contract',
    'ContractVersion',
    'ContractApproval',
    'PIIClassification',
    'MaskingPolicy',
    'QualityRule',
    'QualityMetric',
    'DataLineage',
    'AccessLog',
    'AnalyticsReport',
    'GovernancePolicy',
    'ComplianceAssessment',
    'WorkflowTask',
    'WorkflowExecution',
    'DataCatalog'
]

