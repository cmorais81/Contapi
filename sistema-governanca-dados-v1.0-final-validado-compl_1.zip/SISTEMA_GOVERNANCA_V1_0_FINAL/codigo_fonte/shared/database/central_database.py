# Autor: carlos.morais@f1rst.com.br
"""
Central Database Configuration
Shared database connection for all microservices
"""

import os
import logging
from typing import Generator, Optional
from contextlib import contextmanager
from sqlalchemy import create_engine, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import QueuePool
import psycopg2

logger = logging.getLogger(__name__)

# Database configuration from environment variables
DATABASE_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'port': os.getenv('DB_PORT', '5432'),
    'database': os.getenv('DB_NAME', 'governance_production'),
    'user': os.getenv('DB_USER', 'governance_user'),
    'password': os.getenv('DB_PASSWORD', 'governance_pass_2024')
}

# SQLAlchemy configuration
DATABASE_URL = f"postgresql://{DATABASE_CONFIG['user']}:{DATABASE_CONFIG['password']}@{DATABASE_CONFIG['host']}:{DATABASE_CONFIG['port']}/{DATABASE_CONFIG['database']}"

# Create SQLAlchemy engine with connection pooling
engine = create_engine(
    DATABASE_URL,
    poolclass=QueuePool,
    pool_size=10,
    max_overflow=20,
    pool_pre_ping=True,
    pool_recycle=3600,
    echo=os.getenv('DB_ECHO', 'false').lower() == 'true'
)

# Create session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class for SQLAlchemy models
Base = declarative_base()


def get_db() -> Generator[Session, None, None]:
    """
    Dependency to get database session
    """
    db = SessionLocal()
    try:
        yield db
    except Exception as e:
        logger.error(f"Database session error: {e}")
        db.rollback()
        raise
    finally:
        db.close()


@contextmanager
def get_db_session():
    """
    Context manager for database session
    """
    db = SessionLocal()
    try:
        yield db
        db.commit()
    except Exception as e:
        logger.error(f"Database transaction error: {e}")
        db.rollback()
        raise
    finally:
        db.close()


def check_db_connection() -> bool:
    """
    Check if database connection is working
    """
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
        logger.info("Database connection successful")
        return True
    except Exception as e:
        logger.error(f"Database connection failed: {e}")
        return False


def init_db():
    """
    Initialize database tables
    """
    try:
        # Import all models to ensure they are registered with Base
        from .models import *
        
        # Create all tables
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
        
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        raise


def get_raw_connection():
    """
    Get raw psycopg2 connection for direct SQL operations
    """
    try:
        conn = psycopg2.connect(
            host=DATABASE_CONFIG['host'],
            port=DATABASE_CONFIG['port'],
            database=DATABASE_CONFIG['database'],
            user=DATABASE_CONFIG['user'],
            password=DATABASE_CONFIG['password']
        )
        conn.autocommit = True
        return conn
    except Exception as e:
        logger.error(f"Raw database connection error: {e}")
        raise


def execute_sql_file(file_path: str) -> bool:
    """
    Execute SQL file directly
    """
    try:
        with get_raw_connection() as conn:
            with open(file_path, 'r', encoding='utf-8') as file:
                sql_content = file.read()
            
            with conn.cursor() as cursor:
                cursor.execute(sql_content)
            
        logger.info(f"SQL file executed successfully: {file_path}")
        return True
        
    except Exception as e:
        logger.error(f"Error executing SQL file {file_path}: {e}")
        return False


def get_db_stats() -> dict:
    """
    Get database statistics
    """
    try:
        with get_db_session() as db:
            stats = {}
            
            # Get table counts
            tables = [
                'organizations', 'users', 'datasets', 'contracts',
                'contract_versions', 'contract_approvals', 'pii_classifications',
                'quality_rules', 'quality_metrics', 'access_logs',
                'analytics_reports', 'governance_policies', 'workflow_executions'
            ]
            
            for table in tables:
                try:
                    result = db.execute(text(f"SELECT COUNT(*) FROM {table}"))
                    count = result.scalar()
                    stats[f"{table}_count"] = count
                except Exception as e:
                    logger.warning(f"Could not get count for table {table}: {e}")
                    stats[f"{table}_count"] = 0
            
            # Get database size
            try:
                result = db.execute(text("""
                    SELECT pg_size_pretty(pg_database_size(current_database())) as size
                """))
                stats['database_size'] = result.scalar()
            except Exception as e:
                logger.warning(f"Could not get database size: {e}")
                stats['database_size'] = 'unknown'
            
            # Get connection count
            try:
                result = db.execute(text("""
                    SELECT count(*) FROM pg_stat_activity 
                    WHERE datname = current_database()
                """))
                stats['active_connections'] = result.scalar()
            except Exception as e:
                logger.warning(f"Could not get connection count: {e}")
                stats['active_connections'] = 0
            
            return stats
            
    except Exception as e:
        logger.error(f"Error getting database stats: {e}")
        return {}


def health_check() -> dict:
    """
    Comprehensive database health check
    """
    health = {
        'status': 'unknown',
        'connection': False,
        'tables_accessible': False,
        'sample_data': False,
        'performance': {}
    }
    
    try:
        # Test basic connection
        if check_db_connection():
            health['connection'] = True
            health['status'] = 'connected'
        else:
            return health
        
        # Test table access
        with get_db_session() as db:
            # Test reading from main tables
            try:
                db.execute(text("SELECT COUNT(*) FROM organizations LIMIT 1"))
                db.execute(text("SELECT COUNT(*) FROM users LIMIT 1"))
                db.execute(text("SELECT COUNT(*) FROM contracts LIMIT 1"))
                health['tables_accessible'] = True
            except Exception as e:
                logger.error(f"Table access test failed: {e}")
                return health
            
            # Test sample data
            try:
                result = db.execute(text("SELECT COUNT(*) FROM contracts WHERE status = 'active'"))
                active_contracts = result.scalar()
                if active_contracts > 0:
                    health['sample_data'] = True
            except Exception as e:
                logger.error(f"Sample data test failed: {e}")
            
            # Performance test
            try:
                import time
                start_time = time.time()
                db.execute(text("""
                    SELECT c.id, c.name, u.name as owner_name 
                    FROM contracts c 
                    JOIN users u ON c.owner_id = u.id 
                    LIMIT 10
                """))
                query_time = (time.time() - start_time) * 1000
                health['performance']['query_time_ms'] = round(query_time, 2)
            except Exception as e:
                logger.error(f"Performance test failed: {e}")
        
        # Overall status
        if health['connection'] and health['tables_accessible']:
            health['status'] = 'healthy'
        elif health['connection']:
            health['status'] = 'degraded'
        else:
            health['status'] = 'unhealthy'
        
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        health['status'] = 'error'
        health['error'] = str(e)
    
    return health


# Database utilities
class DatabaseUtils:
    """Utility class for common database operations"""
    
    @staticmethod
    def get_organization_by_id(org_id: str) -> Optional[dict]:
        """Get organization by ID"""
        try:
            with get_db_session() as db:
                result = db.execute(text("""
                    SELECT id, name, description, domain, created_at, updated_at
                    FROM organizations 
                    WHERE id = :org_id
                """), {"org_id": org_id})
                
                row = result.fetchone()
                if row:
                    return {
                        'id': str(row.id),
                        'name': row.name,
                        'description': row.description,
                        'domain': row.domain,
                        'created_at': row.created_at.isoformat() if row.created_at else None,
                        'updated_at': row.updated_at.isoformat() if row.updated_at else None
                    }
                return None
        except Exception as e:
            logger.error(f"Error getting organization {org_id}: {e}")
            return None
    
    @staticmethod
    def get_user_by_id(user_id: str) -> Optional[dict]:
        """Get user by ID"""
        try:
            with get_db_session() as db:
                result = db.execute(text("""
                    SELECT u.id, u.name, u.email, u.role, u.department, u.is_active,
                           o.name as organization_name
                    FROM users u
                    LEFT JOIN organizations o ON u.organization_id = o.id
                    WHERE u.id = :user_id
                """), {"user_id": user_id})
                
                row = result.fetchone()
                if row:
                    return {
                        'id': str(row.id),
                        'name': row.name,
                        'email': row.email,
                        'role': row.role,
                        'department': row.department,
                        'is_active': row.is_active,
                        'organization_name': row.organization_name
                    }
                return None
        except Exception as e:
            logger.error(f"Error getting user {user_id}: {e}")
            return None
    
    @staticmethod
    def log_access(user_id: str, action: str, resource_type: str, resource_id: str = None, 
                   ip_address: str = None, status_code: int = 200) -> bool:
        """Log user access"""
        try:
            with get_db_session() as db:
                db.execute(text("""
                    INSERT INTO access_logs (user_id, action, resource_type, resource_id, 
                                           ip_address, status_code, created_at)
                    VALUES (:user_id, :action, :resource_type, :resource_id, 
                            :ip_address, :status_code, CURRENT_TIMESTAMP)
                """), {
                    "user_id": user_id,
                    "action": action,
                    "resource_type": resource_type,
                    "resource_id": resource_id,
                    "ip_address": ip_address,
                    "status_code": status_code
                })
            return True
        except Exception as e:
            logger.error(f"Error logging access: {e}")
            return False


# Export main components
__all__ = [
    'get_db',
    'get_db_session', 
    'check_db_connection',
    'init_db',
    'get_raw_connection',
    'execute_sql_file',
    'get_db_stats',
    'health_check',
    'DatabaseUtils',
    'Base',
    'engine',
    'SessionLocal'
]

