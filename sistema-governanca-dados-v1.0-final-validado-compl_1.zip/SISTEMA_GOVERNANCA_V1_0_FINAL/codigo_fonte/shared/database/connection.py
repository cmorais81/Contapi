"""
Módulo de Conexão com PostgreSQL
Sistema de Governança de Dados V5.0
"""

import os
import logging
from typing import Optional
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.pool import QueuePool
import psycopg2
from contextlib import contextmanager

# Configure logging
logger = logging.getLogger(__name__)

# Base para modelos SQLAlchemy
Base = declarative_base()

class DatabaseConnection:
    """Gerenciador de conexão com PostgreSQL"""
    
    def __init__(self):
        self.engine = None
        self.SessionLocal = None
        self._initialize_connection()
    
    def _initialize_connection(self):
        """Inicializa a conexão com o banco de dados"""
        try:
            # Configurações do banco
            db_config = {
                'host': os.getenv('DB_HOST', 'localhost'),
                'port': os.getenv('DB_PORT', '5432'),
                'database': os.getenv('DB_NAME', 'governance_db'),
                'username': os.getenv('DB_USER', 'governance_user'),
                'password': os.getenv('DB_PASSWORD', 'governance_pass')
            }
            
            # String de conexão
            connection_string = (
                f"postgresql://{db_config['username']}:{db_config['password']}"
                f"@{db_config['host']}:{db_config['port']}/{db_config['database']}"
            )
            
            # Criar engine com pool de conexões
            self.engine = create_engine(
                connection_string,
                poolclass=QueuePool,
                pool_size=10,
                max_overflow=20,
                pool_pre_ping=True,
                echo=False  # Set to True for SQL debugging
            )
            
            # Criar session factory
            self.SessionLocal = sessionmaker(
                autocommit=False,
                autoflush=False,
                bind=self.engine
            )
            
            # Testar conexão
            self._test_connection()
            
            logger.info("Conexão com PostgreSQL estabelecida com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao conectar com PostgreSQL: {e}")
            raise
    
    def _test_connection(self):
        """Testa a conexão com o banco de dados"""
        try:
            with self.engine.connect() as connection:
                result = connection.execute(text("SELECT 1"))
                result.fetchone()
            logger.info("Teste de conexão PostgreSQL: OK")
        except Exception as e:
            logger.error(f"Teste de conexão falhou: {e}")
            raise
    
    @contextmanager
    def get_session(self) -> Session:
        """Context manager para sessões do banco de dados"""
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Erro na sessão do banco: {e}")
            raise
        finally:
            session.close()
    
    def get_session_direct(self) -> Session:
        """Retorna uma sessão direta (deve ser fechada manualmente)"""
        return self.SessionLocal()
    
    def health_check(self) -> dict:
        """Verifica a saúde da conexão com o banco"""
        try:
            with self.get_session() as session:
                result = session.execute(text("SELECT version()"))
                version = result.fetchone()[0]
                
                # Verificar algumas tabelas principais
                tables_check = {}
                main_tables = [
                    'contracts', 'users', 'quality_rules', 
                    'data_entities', 'data_lineage', 'audit_events'
                ]
                
                for table in main_tables:
                    try:
                        count_result = session.execute(text(f"SELECT COUNT(*) FROM {table}"))
                        count = count_result.fetchone()[0]
                        tables_check[table] = count
                    except Exception as e:
                        tables_check[table] = f"Error: {str(e)}"
                
                return {
                    "status": "healthy",
                    "database": "PostgreSQL",
                    "version": version,
                    "tables": tables_check,
                    "connection_pool": {
                        "size": self.engine.pool.size(),
                        "checked_in": self.engine.pool.checkedin(),
                        "checked_out": self.engine.pool.checkedout()
                    }
                }
                
        except Exception as e:
            logger.error(f"Health check falhou: {e}")
            return {
                "status": "unhealthy",
                "error": str(e)
            }
    
    def execute_raw_sql(self, sql: str, params: dict = None) -> list:
        """Executa SQL bruto e retorna resultados"""
        try:
            with self.get_session() as session:
                result = session.execute(text(sql), params or {})
                return result.fetchall()
        except Exception as e:
            logger.error(f"Erro ao executar SQL: {e}")
            raise
    
    def close(self):
        """Fecha todas as conexões"""
        if self.engine:
            self.engine.dispose()
            logger.info("Conexões PostgreSQL fechadas")

# Instância global da conexão
db_connection = DatabaseConnection()

# Funções de conveniência
def get_db_session():
    """Função de conveniência para obter sessão"""
    return db_connection.get_session()

def get_db_health():
    """Função de conveniência para health check"""
    return db_connection.health_check()

def execute_sql(sql: str, params: dict = None):
    """Função de conveniência para executar SQL"""
    return db_connection.execute_raw_sql(sql, params)

# Dependency para FastAPI
def get_database():
    """Dependency para injeção de dependência no FastAPI"""
    session = db_connection.get_session_direct()
    try:
        yield session
    finally:
        session.close()

