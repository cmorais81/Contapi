# Autor: carlos.morais@f1rst.com.br
"""
PostgreSQL Connection Manager for Microservices V4.1
Shared database connection with connection pooling and error handling
"""

import os
import logging
from typing import Optional, Dict, Any, List
from contextlib import contextmanager
import psycopg2
from psycopg2 import pool, sql
from psycopg2.extras import RealDictCursor
import json
from datetime import datetime, date

logger = logging.getLogger(__name__)

class PostgreSQLManager:
    """PostgreSQL connection manager with pooling"""
    
    def __init__(self):
        self.connection_pool: Optional[psycopg2.pool.ThreadedConnectionPool] = None
        self._initialize_pool()
    
    def _initialize_pool(self):
        """Initialize connection pool"""
        try:
            # Database configuration
            db_config = {
                'host': os.getenv('POSTGRES_HOST', 'localhost'),
                'port': int(os.getenv('POSTGRES_PORT', 5432)),
                'database': os.getenv('POSTGRES_DB', 'governance_production'),
                'user': os.getenv('POSTGRES_USER', 'postgres')
            }
            
            # Only add password if it's not empty
            password = os.getenv('POSTGRES_PASSWORD', '')
            if password:
                db_config['password'] = password
            
            # Create connection pool
            self.connection_pool = psycopg2.pool.ThreadedConnectionPool(
                minconn=1,
                maxconn=20,
                **db_config
            )
            
            logger.info("PostgreSQL connection pool initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize PostgreSQL connection pool: {e}")
            raise
    
    @contextmanager
    def get_connection(self):
        """Get connection from pool"""
        connection = None
        try:
            connection = self.connection_pool.getconn()
            yield connection
        except Exception as e:
            if connection:
                connection.rollback()
            logger.error(f"Database connection error: {e}")
            raise
        finally:
            if connection:
                self.connection_pool.putconn(connection)
    
    def execute_query(self, query: str, params: tuple = None) -> List[Dict[str, Any]]:
        """Execute SELECT query and return results"""
        try:
            with self.get_connection() as conn:
                with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                    cursor.execute(query, params)
                    results = cursor.fetchall()
                    
                    # Convert to list of dicts with JSON serialization
                    return [self._serialize_row(dict(row)) for row in results]
                    
        except Exception as e:
            logger.error(f"Query execution error: {e}")
            raise
    
    def execute_command(self, command: str, params: tuple = None) -> int:
        """Execute INSERT/UPDATE/DELETE command and return affected rows"""
        try:
            with self.get_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(command, params)
                    affected_rows = cursor.rowcount
                    conn.commit()
                    return affected_rows
                    
        except Exception as e:
            logger.error(f"Command execution error: {e}")
            raise
    
    def execute_insert_returning(self, command: str, params: tuple = None) -> Dict[str, Any]:
        """Execute INSERT with RETURNING clause"""
        try:
            with self.get_connection() as conn:
                with conn.cursor(cursor_factory=RealDictCursor) as cursor:
                    cursor.execute(command, params)
                    result = cursor.fetchone()
                    conn.commit()
                    
                    return self._serialize_row(dict(result)) if result else {}
                    
        except Exception as e:
            logger.error(f"Insert with returning error: {e}")
            raise
    
    def _serialize_row(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Serialize row data for JSON compatibility"""
        serialized = {}
        
        for key, value in row.items():
            if isinstance(value, datetime):
                serialized[key] = value.isoformat()
            elif isinstance(value, date):
                serialized[key] = value.isoformat()
            elif isinstance(value, (dict, list)):
                serialized[key] = value  # Already JSON serializable
            else:
                serialized[key] = value
                
        return serialized
    
    def health_check(self) -> Dict[str, Any]:
        """Check database health"""
        try:
            result = self.execute_query("SELECT 1 as health_check")
            
            # Get connection stats
            pool_stats = {
                'total_connections': self.connection_pool.maxconn,
                'available_connections': len(self.connection_pool._pool),
                'used_connections': self.connection_pool.maxconn - len(self.connection_pool._pool)
            }
            
            return {
                'status': 'healthy',
                'database': 'connected',
                'pool_stats': pool_stats,
                'timestamp': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                'status': 'unhealthy',
                'database': 'disconnected',
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    def get_table_stats(self) -> Dict[str, Any]:
        """Get database table statistics"""
        try:
            # Get table row counts
            tables_query = """
                SELECT 
                    schemaname,
                    tablename,
                    n_tup_ins as inserts,
                    n_tup_upd as updates,
                    n_tup_del as deletes,
                    n_live_tup as live_rows
                FROM pg_stat_user_tables
                ORDER BY tablename;
            """
            
            tables = self.execute_query(tables_query)
            
            # Get database size
            size_query = """
                SELECT pg_size_pretty(pg_database_size(current_database())) as database_size;
            """
            
            size_result = self.execute_query(size_query)
            database_size = size_result[0]['database_size'] if size_result else 'Unknown'
            
            return {
                'database_size': database_size,
                'total_tables': len(tables),
                'tables': tables,
                'timestamp': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error getting table stats: {e}")
            return {
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            }
    
    def close_pool(self):
        """Close connection pool"""
        if self.connection_pool:
            self.connection_pool.closeall()
            logger.info("PostgreSQL connection pool closed")

# Global instance
postgres_manager = PostgreSQLManager()

# Helper functions for microservices
def get_db_manager() -> PostgreSQLManager:
    """Get database manager instance"""
    return postgres_manager

def execute_query(query: str, params: tuple = None) -> List[Dict[str, Any]]:
    """Execute query using global manager"""
    return postgres_manager.execute_query(query, params)

def execute_command(command: str, params: tuple = None) -> int:
    """Execute command using global manager"""
    return postgres_manager.execute_command(command, params)

def execute_insert_returning(command: str, params: tuple = None) -> Dict[str, Any]:
    """Execute insert with returning using global manager"""
    return postgres_manager.execute_insert_returning(command, params)

def health_check() -> Dict[str, Any]:
    """Database health check"""
    return postgres_manager.health_check()

def get_table_stats() -> Dict[str, Any]:
    """Get table statistics"""
    return postgres_manager.get_table_stats()

