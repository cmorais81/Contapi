"""
Módulo de Database Compartilhado
Sistema de Governança de Dados V5.0
"""

from .connection import (
    db_connection,
    get_db_session,
    get_db_health,
    execute_sql,
    get_database,
    Base
)

__all__ = [
    'db_connection',
    'get_db_session', 
    'get_db_health',
    'execute_sql',
    'get_database',
    'Base'
]

