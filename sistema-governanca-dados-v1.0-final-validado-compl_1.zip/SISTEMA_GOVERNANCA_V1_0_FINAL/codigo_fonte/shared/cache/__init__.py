# Autor: carlos.morais@f1rst.com.br
"""
Cache module with Redis integration
"""

from .redis_manager import (
    redis_manager,
    get_redis_health,
    cache_get,
    cache_set,
    cache_delete,
    is_redis_available,
    cache_result,
    rate_limit
)

__all__ = [
    'redis_manager',
    'get_redis_health',
    'cache_get',
    'cache_set',
    'cache_delete',
    'is_redis_available',
    'cache_result',
    'rate_limit'
]

