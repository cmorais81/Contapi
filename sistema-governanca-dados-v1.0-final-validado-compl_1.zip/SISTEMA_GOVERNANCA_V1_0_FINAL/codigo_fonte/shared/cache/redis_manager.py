# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
Redis Manager - Shared Cache Layer
Gerenciador compartilhado para cache Redis entre microserviços
"""

import json
import logging
import os
import time
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union
from functools import wraps

import redis

# Configure logging
logger = logging.getLogger(__name__)

class RedisManager:
    """Redis connection and operations manager"""
    
    def __init__(self):
        """Initialize Redis connection"""
        self.redis_client = None
        self._initialize_connection()
    
    def _initialize_connection(self):
        """Initialize Redis connection"""
        try:
            # Redis configuration
            redis_config = {
                'host': os.getenv('REDIS_HOST', 'localhost'),
                'port': int(os.getenv('REDIS_PORT', 6379)),
                'db': int(os.getenv('REDIS_DB', 0)),
                'decode_responses': True,
                'socket_connect_timeout': 5,
                'socket_timeout': 5,
                'retry_on_timeout': True,
                'health_check_interval': 30
            }
            
            # Add password if provided
            password = os.getenv('REDIS_PASSWORD', '')
            if password:
                redis_config['password'] = password
            
            # Create Redis connection
            self.redis_client = redis.Redis(**redis_config)
            
            # Test connection
            self.redis_client.ping()
            logger.info("Redis connection established successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize Redis connection: {e}")
            self.redis_client = None
    
    def is_available(self) -> bool:
        """Check if Redis is available"""
        if not self.redis_client:
            return False
        try:
            self.redis_client.ping()
            return True
        except Exception:
            return False
    
    def health_check(self) -> Dict[str, Any]:
        """Perform Redis health check"""
        if not self.is_available():
            return {
                "status": "unhealthy",
                "error": "Redis connection not available",
                "timestamp": datetime.now().isoformat()
            }
        
        try:
            # Get Redis info
            info = self.redis_client.info()
            
            return {
                "status": "healthy",
                "version": info.get('redis_version', 'unknown'),
                "connected_clients": info.get('connected_clients', 0),
                "used_memory_human": info.get('used_memory_human', '0B'),
                "keyspace": {
                    db: info.get(f'db{db}', {}) 
                    for db in range(16) 
                    if f'db{db}' in info
                },
                "timestamp": datetime.now().isoformat()
            }
        except Exception as e:
            return {
                "status": "unhealthy",
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    # =====================================================
    # BASIC OPERATIONS
    # =====================================================
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from Redis"""
        if not self.is_available():
            return None
        
        try:
            value = self.redis_client.get(key)
            if value is None:
                return None
            
            # Try to parse as JSON, fallback to string
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value
        except Exception as e:
            logger.error(f"Redis GET error for key {key}: {e}")
            return None
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set value in Redis with optional TTL"""
        if not self.is_available():
            return False
        
        try:
            # Serialize value to JSON if not string
            if not isinstance(value, str):
                value = json.dumps(value, default=str)
            
            # Set with TTL if provided
            if ttl:
                return self.redis_client.setex(key, ttl, value)
            else:
                return self.redis_client.set(key, value)
        except Exception as e:
            logger.error(f"Redis SET error for key {key}: {e}")
            return False
    
    def delete(self, key: str) -> bool:
        """Delete key from Redis"""
        if not self.is_available():
            return False
        
        try:
            return bool(self.redis_client.delete(key))
        except Exception as e:
            logger.error(f"Redis DELETE error for key {key}: {e}")
            return False
    
    def exists(self, key: str) -> bool:
        """Check if key exists in Redis"""
        if not self.is_available():
            return False
        
        try:
            return bool(self.redis_client.exists(key))
        except Exception as e:
            logger.error(f"Redis EXISTS error for key {key}: {e}")
            return False
    
    def expire(self, key: str, ttl: int) -> bool:
        """Set TTL for existing key"""
        if not self.is_available():
            return False
        
        try:
            return bool(self.redis_client.expire(key, ttl))
        except Exception as e:
            logger.error(f"Redis EXPIRE error for key {key}: {e}")
            return False
    
    def ttl(self, key: str) -> int:
        """Get TTL for key (-1 = no expiry, -2 = not exists)"""
        if not self.is_available():
            return -2
        
        try:
            return self.redis_client.ttl(key)
        except Exception as e:
            logger.error(f"Redis TTL error for key {key}: {e}")
            return -2
    
    # =====================================================
    # ADVANCED OPERATIONS
    # =====================================================
    
    def get_pattern(self, pattern: str) -> Dict[str, Any]:
        """Get all keys matching pattern"""
        if not self.is_available():
            return {}
        
        try:
            keys = self.redis_client.keys(pattern)
            result = {}
            for key in keys:
                result[key] = self.get(key)
            return result
        except Exception as e:
            logger.error(f"Redis GET_PATTERN error for pattern {pattern}: {e}")
            return {}
    
    def delete_pattern(self, pattern: str) -> int:
        """Delete all keys matching pattern"""
        if not self.is_available():
            return 0
        
        try:
            keys = self.redis_client.keys(pattern)
            if keys:
                return self.redis_client.delete(*keys)
            return 0
        except Exception as e:
            logger.error(f"Redis DELETE_PATTERN error for pattern {pattern}: {e}")
            return 0
    
    def increment(self, key: str, amount: int = 1) -> Optional[int]:
        """Increment counter"""
        if not self.is_available():
            return None
        
        try:
            return self.redis_client.incrby(key, amount)
        except Exception as e:
            logger.error(f"Redis INCREMENT error for key {key}: {e}")
            return None
    
    def decrement(self, key: str, amount: int = 1) -> Optional[int]:
        """Decrement counter"""
        if not self.is_available():
            return None
        
        try:
            return self.redis_client.decrby(key, amount)
        except Exception as e:
            logger.error(f"Redis DECREMENT error for key {key}: {e}")
            return None
    
    # =====================================================
    # SPECLIZED OPERATIONS
    # =====================================================
    
    def cache_response(self, key: str, data: Any, ttl: int = 300) -> bool:
        """Cache API response with metadata"""
        cache_data = {
            'data': data,
            'cached_at': datetime.now().isoformat(),
            'ttl': ttl
        }
        return self.set(key, cache_data, ttl)
    
    def get_cached_response(self, key: str) -> Optional[Dict[str, Any]]:
        """Get cached API response with metadata"""
        cached = self.get(key)
        if cached and isinstance(cached, dict) and 'data' in cached:
            return cached
        return None
    
    def rate_limit_check(self, key: str, limit: int, window: int = 60) -> Dict[str, Any]:
        """Check rate limit for key"""
        try:
            current = self.redis_client.get(key)
            if current is None:
                # First request
                self.redis_client.setex(key, window, 1)
                return {
                    'allowed': True,
                    'count': 1,
                    'limit': limit,
                    'remaining': limit - 1,
                    'reset_at': (datetime.now() + timedelta(seconds=window)).isoformat()
                }
            
            count = int(current)
            if count >= limit:
                # Rate limit exceeded
                ttl = self.redis_client.ttl(key)
                return {
                    'allowed': False,
                    'count': count,
                    'limit': limit,
                    'remaining': 0,
                    'reset_at': (datetime.now() + timedelta(seconds=ttl)).isoformat()
                }
            
            # Increment counter
            new_count = self.redis_client.incr(key)
            ttl = self.redis_client.ttl(key)
            
            return {
                'allowed': True,
                'count': new_count,
                'limit': limit,
                'remaining': limit - new_count,
                'reset_at': (datetime.now() + timedelta(seconds=ttl)).isoformat()
            }
            
        except Exception as e:
            logger.error(f"Rate limit check error for key {key}: {e}")
            # Allow request on error
            return {
                'allowed': True,
                'count': 0,
                'limit': limit,
                'remaining': limit,
                'error': str(e)
            }
    
    def circuit_breaker_state(self, service: str) -> Dict[str, Any]:
        """Get circuit breaker state for service"""
        key = f"circuit_breaker:{service}"
        state = self.get(key)
        
        if not state:
            # Initialize circuit breaker
            default_state = {
                'state': 'closed',  # closed, open, half_open
                'failure_count': 0,
                'last_failure': None,
                'last_success': datetime.now().isoformat(),
                'next_attempt': None
            }
            self.set(key, default_state, 3600)  # 1 hour TTL
            return default_state
        
        return state
    
    def circuit_breaker_record_success(self, service: str) -> bool:
        """Record successful call for circuit breaker"""
        key = f"circuit_breaker:{service}"
        state = self.circuit_breaker_state(service)
        
        state.update({
            'state': 'closed',
            'failure_count': 0,
            'last_success': datetime.now().isoformat(),
            'next_attempt': None
        })
        
        return self.set(key, state, 3600)
    
    def circuit_breaker_record_failure(self, service: str, threshold: int = 5, timeout: int = 60) -> Dict[str, Any]:
        """Record failed call for circuit breaker"""
        key = f"circuit_breaker:{service}"
        state = self.circuit_breaker_state(service)
        
        state['failure_count'] += 1
        state['last_failure'] = datetime.now().isoformat()
        
        if state['failure_count'] >= threshold:
            state['state'] = 'open'
            state['next_attempt'] = (datetime.now() + timedelta(seconds=timeout)).isoformat()
        
        self.set(key, state, 3600)
        return state

# =====================================================
# DECORATORS
# =====================================================

def cache_result(ttl: int = 300, key_prefix: str = "cache"):
    """Decorator to cache function results"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Generate cache key
            key_parts = [key_prefix, func.__name__]
            if args:
                key_parts.extend([str(arg) for arg in args])
            if kwargs:
                key_parts.extend([f"{k}:{v}" for k, v in sorted(kwargs.items())])
            
            cache_key = ":".join(key_parts)
            
            # Try to get from cache
            cached = redis_manager.get_cached_response(cache_key)
            if cached:
                logger.info(f"Cache HIT for {cache_key}")
                return cached['data']
            
            # Execute function and cache result
            logger.info(f"Cache MISS for {cache_key}")
            result = func(*args, **kwargs)
            redis_manager.cache_response(cache_key, result, ttl)
            
            return result
        return wrapper
    return decorator

def rate_limit(limit: int = 100, window: int = 60, key_func=None):
    """Decorator for rate limiting"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Generate rate limit key
            if key_func:
                rate_key = key_func(*args, **kwargs)
            else:
                rate_key = f"rate_limit:{func.__name__}"
            
            # Check rate limit
            rate_check = redis_manager.rate_limit_check(rate_key, limit, window)
            
            if not rate_check['allowed']:
                from fastapi import HTTPException
                raise HTTPException(
                    status_code=429,
                    detail={
                        "error": "Rate limit exceeded",
                        "limit": limit,
                        "window": window,
                        "reset_at": rate_check.get('reset_at')
                    }
                )
            
            return func(*args, **kwargs)
        return wrapper
    return decorator

# =====================================================
# GLOBAL INSTANCE
# =====================================================

# Create global Redis manager instance
redis_manager = RedisManager()

# Export commonly used functions
def get_redis_health() -> Dict[str, Any]:
    """Get Redis health status"""
    return redis_manager.health_check()

def cache_get(key: str) -> Optional[Any]:
    """Get value from cache"""
    return redis_manager.get(key)

def cache_set(key: str, value: Any, ttl: Optional[int] = None) -> bool:
    """Set value in cache"""
    return redis_manager.set(key, value, ttl)

def cache_delete(key: str) -> bool:
    """Delete key from cache"""
    return redis_manager.delete(key)

def is_redis_available() -> bool:
    """Check if Redis is available"""
    return redis_manager.is_available()

