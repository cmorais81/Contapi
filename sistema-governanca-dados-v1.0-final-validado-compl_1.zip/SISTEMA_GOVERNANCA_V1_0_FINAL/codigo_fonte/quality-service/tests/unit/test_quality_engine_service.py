# Autor: carlos.morais@f1rst.com.br
"""
Testes Unitários para Quality Engine Service
"""

import pytest
import asyncio
from datetime import datetime, timedelta
from uuid import UUID, uuid4
from unittest.mock import Mock, AsyncMock, patch
from typing import List, Dict, Any

from src.domain.entities.quality_rule import QualityRule, QualityRuleType, QualityRuleSeverity
from src.domain.services.quality_engine_service import (
    QualityEngineService, QualityExecutionMode, QualityExecutionResult,
    QualityReport, QualityMetrics, QualityRecommendation
)


class TestQualityEngineService:
    """Testes para QualityEngineService"""
    
    @pytest.fixture
    def quality_engine(self):
        """Instância do engine de qualidade"""
        return QualityEngineService()
    
    @pytest.fixture
    def sample_quality_rules(self):
        """Regras de qualidade de exemplo"""
        return [
            QualityRule(
                id=uuid4(),
                name="Completeness Check",
                rule_type=QualityRuleType.COMPLETENESS,
                severity=QualityRuleSeverity.HIGH,
                description="Verifica se campos obrigatórios estão preenchidos",
                configuration={
                    "required_fields": ["customer_id", "email", "name"],
                    "threshold": 95.0
                },
                weight=1.0,
                is_active=True
            ),
            QualityRule(
                id=uuid4(),
                name="Email Format Validation",
                rule_type=QualityRuleType.ACCURACY,
                severity=QualityRuleSeverity.MEDIUM,
                description="Valida formato de email",
                configuration={
                    "field": "email",
                    "pattern": r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
                },
                weight=0.8,
                is_active=True
            ),
            QualityRule(
                id=uuid4(),
                name="Uniqueness Check",
                rule_type=QualityRuleType.UNIQUENESS,
                severity=QualityRuleSeverity.CRITICAL,
                description="Verifica duplicatas",
                configuration={
                    "unique_fields": ["customer_id", "email"],
                    "threshold": 100.0
                },
                weight=1.2,
                is_active=True
            )
        ]
    
    @pytest.fixture
    def sample_dataset(self):
        """Dataset de exemplo para testes"""
        return [
            {
                "customer_id": "CUST001",
                "email": "john.doe@example.com",
                "name": "John Doe",
                "phone": "+1234567890",
                "created_at": "2023-01-15T10:30:00Z"
            },
            {
                "customer_id": "CUST002",
                "email": "jane.smith@example.com",
                "name": "Jane Smith",
                "phone": "+1234567891",
                "created_at": "2023-01-16T11:45:00Z"
            },
            {
                "customer_id": "CUST003",
                "email": "invalid-email",  # Email inválido
                "name": "",  # Nome vazio
                "phone": "+1234567892",
                "created_at": "2023-01-17T09:15:00Z"
            },
            {
                "customer_id": "CUST004",
                "email": "bob.wilson@example.com",
                "name": "Bob Wilson",
                "phone": None,  # Campo nulo
                "created_at": "2023-01-18T14:20:00Z"
            },
            {
                "customer_id": "CUST001",  # ID duplicado
                "email": "duplicate@example.com",
                "name": "Duplicate User",
                "phone": "+1234567893",
                "created_at": "2023-01-19T16:30:00Z"
            }
        ]
    
    @pytest.fixture
    def invalid_dataset(self):
        """Dataset com muitos problemas de qualidade"""
        return [
            {
                "customer_id": "",  # ID vazio
                "email": "not-an-email",  # Email inválido
                "name": None,  # Nome nulo
                "phone": "invalid-phone",
                "created_at": "invalid-date"
            },
            {
                "customer_id": None,  # ID nulo
                "email": "",  # Email vazio
                "name": "",  # Nome vazio
                "phone": "",
                "created_at": ""
            }
        ]
    
    @pytest.mark.asyncio
    async def test_execute_quality_rules_synchronous_mode(self, quality_engine, sample_quality_rules, sample_dataset):
        """Testa execução síncrona de regras de qualidade"""
        # Act
        result = await quality_engine.execute_quality_rules(
            rules=sample_quality_rules,
            dataset=sample_dataset,
            execution_mode=QualityExecutionMode.SYNCHRONOUS
        )
        
        # Assert
        assert isinstance(result, QualityExecutionResult)
        assert result.execution_id is not None
        assert result.total_rules == len(sample_quality_rules)
        assert result.total_records == len(sample_dataset)
        assert result.execution_mode == QualityExecutionMode.SYNCHRONOUS
        assert result.overall_score >= 0.0
        assert result.overall_score <= 100.0
        assert len(result.rule_results) == len(sample_quality_rules)
        assert result.execution_time_ms > 0
    
    @pytest.mark.asyncio
    async def test_execute_quality_rules_asynchronous_mode(self, quality_engine, sample_quality_rules, sample_dataset):
        """Testa execução assíncrona de regras de qualidade"""
        # Act
        result = await quality_engine.execute_quality_rules(
            rules=sample_quality_rules,
            dataset=sample_dataset,
            execution_mode=QualityExecutionMode.ASYNCHRONOUS
        )
        
        # Assert
        assert isinstance(result, QualityExecutionResult)
        assert result.execution_mode == QualityExecutionMode.ASYNCHRONOUS
        assert result.total_rules == len(sample_quality_rules)
        assert len(result.rule_results) == len(sample_quality_rules)
        
        # Verificar se execução paralela foi mais rápida (simulada)
        assert result.execution_time_ms >= 0
    
    @pytest.mark.asyncio
    async def test_execute_quality_rules_batch_mode(self, quality_engine, sample_quality_rules, sample_dataset):
        """Testa execução em modo batch"""
        # Act
        result = await quality_engine.execute_quality_rules(
            rules=sample_quality_rules,
            dataset=sample_dataset,
            execution_mode=QualityExecutionMode.BATCH,
            batch_size=2
        )
        
        # Assert
        assert isinstance(result, QualityExecutionResult)
        assert result.execution_mode == QualityExecutionMode.BATCH
        assert result.total_records == len(sample_dataset)
        assert "batch_size" in result.execution_metadata
        assert result.execution_metadata["batch_size"] == 2
    
    @pytest.mark.asyncio
    async def test_execute_quality_rules_streaming_mode(self, quality_engine, sample_quality_rules, sample_dataset):
        """Testa execução em modo streaming"""
        # Act
        result = await quality_engine.execute_quality_rules(
            rules=sample_quality_rules,
            dataset=sample_dataset,
            execution_mode=QualityExecutionMode.STREAMING,
            chunk_size=3
        )
        
        # Assert
        assert isinstance(result, QualityExecutionResult)
        assert result.execution_mode == QualityExecutionMode.STREAMING
        assert "chunk_size" in result.execution_metadata
        assert result.execution_metadata["chunk_size"] == 3
        assert "chunks_processed" in result.execution_metadata
    
    @pytest.mark.asyncio
    async def test_execute_completeness_rule(self, quality_engine, sample_dataset):
        """Testa execução de regra de completeness"""
        # Arrange
        completeness_rule = QualityRule(
            id=uuid4(),
            name="Completeness Test",
            rule_type=QualityRuleType.COMPLETENESS,
            severity=QualityRuleSeverity.HIGH,
            configuration={
                "required_fields": ["customer_id", "email", "name"],
                "threshold": 80.0
            },
            weight=1.0,
            is_active=True
        )
        
        # Act
        rule_result = await quality_engine._execute_completeness_rule(completeness_rule, sample_dataset)
        
        # Assert
        assert rule_result.rule_id == completeness_rule.id
        assert rule_result.rule_type == QualityRuleType.COMPLETENESS
        assert rule_result.score >= 0.0
        assert rule_result.score <= 100.0
        assert rule_result.total_records == len(sample_dataset)
        assert rule_result.failed_records >= 0
        assert len(rule_result.issues) >= 0
    
    @pytest.mark.asyncio
    async def test_execute_accuracy_rule(self, quality_engine, sample_dataset):
        """Testa execução de regra de accuracy"""
        # Arrange
        accuracy_rule = QualityRule(
            id=uuid4(),
            name="Email Accuracy Test",
            rule_type=QualityRuleType.ACCURACY,
            severity=QualityRuleSeverity.MEDIUM,
            configuration={
                "field": "email",
                "pattern": r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
                "threshold": 90.0
            },
            weight=1.0,
            is_active=True
        )
        
        # Act
        rule_result = await quality_engine._execute_accuracy_rule(accuracy_rule, sample_dataset)
        
        # Assert
        assert rule_result.rule_id == accuracy_rule.id
        assert rule_result.rule_type == QualityRuleType.ACCURACY
        assert rule_result.score >= 0.0
        assert rule_result.score <= 100.0
        
        # Verificar se detectou email inválido
        assert rule_result.failed_records > 0
        assert len(rule_result.issues) > 0
        
        # Verificar se issue contém informação sobre email inválido
        email_issues = [issue for issue in rule_result.issues if "email" in issue.get("field", "")]
        assert len(email_issues) > 0
    
    @pytest.mark.asyncio
    async def test_execute_uniqueness_rule(self, quality_engine, sample_dataset):
        """Testa execução de regra de uniqueness"""
        # Arrange
        uniqueness_rule = QualityRule(
            id=uuid4(),
            name="Uniqueness Test",
            rule_type=QualityRuleType.UNIQUENESS,
            severity=QualityRuleSeverity.CRITICAL,
            configuration={
                "unique_fields": ["customer_id"],
                "threshold": 100.0
            },
            weight=1.0,
            is_active=True
        )
        
        # Act
        rule_result = await quality_engine._execute_uniqueness_rule(uniqueness_rule, sample_dataset)
        
        # Assert
        assert rule_result.rule_id == uniqueness_rule.id
        assert rule_result.rule_type == QualityRuleType.UNIQUENESS
        
        # Verificar se detectou duplicata (CUST001 aparece duas vezes)
        assert rule_result.failed_records > 0
        assert len(rule_result.issues) > 0
        
        # Verificar se issue contém informação sobre duplicata
        duplicate_issues = [issue for issue in rule_result.issues if "duplicate" in issue.get("message", "").lower()]
        assert len(duplicate_issues) > 0
    
    @pytest.mark.asyncio
    async def test_execute_consistency_rule(self, quality_engine, sample_dataset):
        """Testa execução de regra de consistency"""
        # Arrange
        consistency_rule = QualityRule(
            id=uuid4(),
            name="Consistency Test",
            rule_type=QualityRuleType.CONSISTENCY,
            severity=QualityRuleSeverity.MEDIUM,
            configuration={
                "field_relationships": [
                    {
                        "field1": "customer_id",
                        "field2": "email",
                        "relationship": "both_present_or_both_null"
                    }
                ],
                "threshold": 95.0
            },
            weight=1.0,
            is_active=True
        )
        
        # Act
        rule_result = await quality_engine._execute_consistency_rule(consistency_rule, sample_dataset)
        
        # Assert
        assert rule_result.rule_id == consistency_rule.id
        assert rule_result.rule_type == QualityRuleType.CONSISTENCY
        assert rule_result.score >= 0.0
        assert rule_result.score <= 100.0
    
    @pytest.mark.asyncio
    async def test_execute_validity_rule(self, quality_engine, sample_dataset):
        """Testa execução de regra de validity"""
        # Arrange
        validity_rule = QualityRule(
            id=uuid4(),
            name="Phone Validity Test",
            rule_type=QualityRuleType.VALIDITY,
            severity=QualityRuleSeverity.LOW,
            configuration={
                "field": "phone",
                "valid_values": None,
                "valid_range": None,
                "pattern": r"^\+\d{10,15}$",
                "threshold": 80.0
            },
            weight=1.0,
            is_active=True
        )
        
        # Act
        rule_result = await quality_engine._execute_validity_rule(validity_rule, sample_dataset)
        
        # Assert
        assert rule_result.rule_id == validity_rule.id
        assert rule_result.rule_type == QualityRuleType.VALIDITY
        assert rule_result.score >= 0.0
        assert rule_result.score <= 100.0
    
    @pytest.mark.asyncio
    async def test_execute_timeliness_rule(self, quality_engine, sample_dataset):
        """Testa execução de regra de timeliness"""
        # Arrange
        timeliness_rule = QualityRule(
            id=uuid4(),
            name="Timeliness Test",
            rule_type=QualityRuleType.TIMELINESS,
            severity=QualityRuleSeverity.MEDIUM,
            configuration={
                "timestamp_field": "created_at",
                "max_age_days": 30,
                "threshold": 90.0
            },
            weight=1.0,
            is_active=True
        )
        
        # Act
        rule_result = await quality_engine._execute_timeliness_rule(timeliness_rule, sample_dataset)
        
        # Assert
        assert rule_result.rule_id == timeliness_rule.id
        assert rule_result.rule_type == QualityRuleType.TIMELINESS
        assert rule_result.score >= 0.0
        assert rule_result.score <= 100.0
    
    @pytest.mark.asyncio
    async def test_execute_conformity_rule(self, quality_engine, sample_dataset):
        """Testa execução de regra de conformity"""
        # Arrange
        conformity_rule = QualityRule(
            id=uuid4(),
            name="Conformity Test",
            rule_type=QualityRuleType.CONFORMITY,
            severity=QualityRuleSeverity.HIGH,
            configuration={
                "standards": [
                    {
                        "field": "customer_id",
                        "format": "CUST\\d{3}",
                        "description": "Customer ID format"
                    }
                ],
                "threshold": 95.0
            },
            weight=1.0,
            is_active=True
        )
        
        # Act
        rule_result = await quality_engine._execute_conformity_rule(conformity_rule, sample_dataset)
        
        # Assert
        assert rule_result.rule_id == conformity_rule.id
        assert rule_result.rule_type == QualityRuleType.CONFORMITY
        assert rule_result.score >= 0.0
        assert rule_result.score <= 100.0
    
    @pytest.mark.asyncio
    async def test_execute_integrity_rule(self, quality_engine, sample_dataset):
        """Testa execução de regra de integrity"""
        # Arrange
        integrity_rule = QualityRule(
            id=uuid4(),
            name="Integrity Test",
            rule_type=QualityRuleType.INTEGRITY,
            severity=QualityRuleSeverity.CRITICAL,
            configuration={
                "referential_integrity": [
                    {
                        "field": "customer_id",
                        "reference_table": "customers",
                        "reference_field": "id"
                    }
                ],
                "threshold": 100.0
            },
            weight=1.0,
            is_active=True
        )
        
        # Act
        rule_result = await quality_engine._execute_integrity_rule(integrity_rule, sample_dataset)
        
        # Assert
        assert rule_result.rule_id == integrity_rule.id
        assert rule_result.rule_type == QualityRuleType.INTEGRITY
        assert rule_result.score >= 0.0
        assert rule_result.score <= 100.0
    
    @pytest.mark.asyncio
    async def test_execute_custom_rule(self, quality_engine, sample_dataset):
        """Testa execução de regra customizada"""
        # Arrange
        custom_rule = QualityRule(
            id=uuid4(),
            name="Custom Business Rule",
            rule_type=QualityRuleType.CUSTOM,
            severity=QualityRuleSeverity.MEDIUM,
            configuration={
                "custom_logic": "len(record.get('name', '')) >= 2",
                "description": "Nome deve ter pelo menos 2 caracteres",
                "threshold": 90.0
            },
            weight=1.0,
            is_active=True
        )
        
        # Act
        rule_result = await quality_engine._execute_custom_rule(custom_rule, sample_dataset)
        
        # Assert
        assert rule_result.rule_id == custom_rule.id
        assert rule_result.rule_type == QualityRuleType.CUSTOM
        assert rule_result.score >= 0.0
        assert rule_result.score <= 100.0
    
    @pytest.mark.asyncio
    async def test_calculate_overall_score_weighted(self, quality_engine, sample_quality_rules):
        """Testa cálculo de score geral ponderado"""
        # Arrange
        rule_results = [
            Mock(rule_id=rule.id, score=85.0, weight=rule.weight, severity=rule.severity)
            for rule in sample_quality_rules
        ]
        
        # Act
        overall_score = quality_engine._calculate_overall_score(rule_results)
        
        # Assert
        assert isinstance(overall_score, float)
        assert overall_score >= 0.0
        assert overall_score <= 100.0
    
    @pytest.mark.asyncio
    async def test_calculate_overall_score_empty_results(self, quality_engine):
        """Testa cálculo de score com resultados vazios"""
        # Act
        overall_score = quality_engine._calculate_overall_score([])
        
        # Assert
        assert overall_score == 0.0
    
    @pytest.mark.asyncio
    async def test_generate_quality_report(self, quality_engine, sample_quality_rules, sample_dataset):
        """Testa geração de relatório de qualidade"""
        # Arrange
        execution_result = await quality_engine.execute_quality_rules(
            rules=sample_quality_rules,
            dataset=sample_dataset,
            execution_mode=QualityExecutionMode.SYNCHRONOUS
        )
        
        # Act
        report = quality_engine.generate_quality_report(execution_result)
        
        # Assert
        assert isinstance(report, QualityReport)
        assert report.execution_id == execution_result.execution_id
        assert report.overall_score == execution_result.overall_score
        assert report.total_rules == execution_result.total_rules
        assert report.total_records == execution_result.total_records
        assert len(report.rule_summaries) == len(sample_quality_rules)
        assert len(report.issues_by_severity) > 0
        assert len(report.recommendations) >= 0
        assert report.generated_at is not None
    
    @pytest.mark.asyncio
    async def test_generate_recommendations_low_score(self, quality_engine, invalid_dataset):
        """Testa geração de recomendações para dataset com baixo score"""
        # Arrange
        rules = [
            QualityRule(
                id=uuid4(),
                name="Completeness Check",
                rule_type=QualityRuleType.COMPLETENESS,
                severity=QualityRuleSeverity.HIGH,
                configuration={"required_fields": ["customer_id", "email", "name"], "threshold": 95.0},
                weight=1.0,
                is_active=True
            )
        ]
        
        execution_result = await quality_engine.execute_quality_rules(
            rules=rules,
            dataset=invalid_dataset,
            execution_mode=QualityExecutionMode.SYNCHRONOUS
        )
        
        # Act
        recommendations = quality_engine._generate_recommendations(execution_result)
        
        # Assert
        assert len(recommendations) > 0
        assert all(isinstance(rec, QualityRecommendation) for rec in recommendations)
        
        # Verificar se há recomendações para problemas de completeness
        completeness_recs = [rec for rec in recommendations if "completeness" in rec.description.lower()]
        assert len(completeness_recs) > 0
    
    @pytest.mark.asyncio
    async def test_cache_execution_results(self, quality_engine, sample_quality_rules, sample_dataset):
        """Testa cache de resultados de execução"""
        # Arrange
        cache_key = "test_cache_key"
        
        # Act - Primeira execução
        result1 = await quality_engine.execute_quality_rules(
            rules=sample_quality_rules,
            dataset=sample_dataset,
            execution_mode=QualityExecutionMode.SYNCHRONOUS,
            cache_key=cache_key
        )
        
        # Act - Segunda execução (deve usar cache)
        result2 = await quality_engine.execute_quality_rules(
            rules=sample_quality_rules,
            dataset=sample_dataset,
            execution_mode=QualityExecutionMode.SYNCHRONOUS,
            cache_key=cache_key
        )
        
        # Assert
        assert result1.execution_id != result2.execution_id  # IDs diferentes
        assert result1.overall_score == result2.overall_score  # Scores iguais (cache)
        assert result2.from_cache is True  # Indicador de cache
    
    @pytest.mark.asyncio
    async def test_filter_active_rules(self, quality_engine):
        """Testa filtro de regras ativas"""
        # Arrange
        rules = [
            QualityRule(id=uuid4(), name="Active Rule 1", is_active=True),
            QualityRule(id=uuid4(), name="Inactive Rule", is_active=False),
            QualityRule(id=uuid4(), name="Active Rule 2", is_active=True)
        ]
        
        # Act
        active_rules = quality_engine._filter_active_rules(rules)
        
        # Assert
        assert len(active_rules) == 2
        assert all(rule.is_active for rule in active_rules)
    
    @pytest.mark.asyncio
    async def test_validate_rule_configuration_valid(self, quality_engine):
        """Testa validação de configuração de regra válida"""
        # Arrange
        valid_rule = QualityRule(
            id=uuid4(),
            name="Valid Rule",
            rule_type=QualityRuleType.COMPLETENESS,
            configuration={
                "required_fields": ["field1", "field2"],
                "threshold": 95.0
            }
        )
        
        # Act
        is_valid = quality_engine._validate_rule_configuration(valid_rule)
        
        # Assert
        assert is_valid is True
    
    @pytest.mark.asyncio
    async def test_validate_rule_configuration_invalid(self, quality_engine):
        """Testa validação de configuração de regra inválida"""
        # Arrange
        invalid_rule = QualityRule(
            id=uuid4(),
            name="Invalid Rule",
            rule_type=QualityRuleType.COMPLETENESS,
            configuration={
                "threshold": 150.0  # Threshold inválido (> 100)
            }
        )
        
        # Act
        is_valid = quality_engine._validate_rule_configuration(invalid_rule)
        
        # Assert
        assert is_valid is False
    
    @pytest.mark.asyncio
    async def test_performance_large_dataset(self, quality_engine, sample_quality_rules):
        """Testa performance com dataset grande"""
        # Arrange
        large_dataset = [
            {
                "customer_id": f"CUST{i:06d}",
                "email": f"user{i}@example.com",
                "name": f"User {i}",
                "phone": f"+123456{i:04d}",
                "created_at": "2023-01-15T10:30:00Z"
            }
            for i in range(10000)  # 10k registros
        ]
        
        # Act
        start_time = datetime.utcnow()
        result = await quality_engine.execute_quality_rules(
            rules=sample_quality_rules,
            dataset=large_dataset,
            execution_mode=QualityExecutionMode.ASYNCHRONOUS
        )
        end_time = datetime.utcnow()
        
        # Assert
        execution_time = (end_time - start_time).total_seconds()
        assert execution_time < 30.0  # Deve executar em menos de 30 segundos
        assert result.total_records == 10000
        assert result.overall_score >= 0.0
    
    @pytest.mark.asyncio
    async def test_error_handling_invalid_dataset(self, quality_engine, sample_quality_rules):
        """Testa tratamento de erro com dataset inválido"""
        # Arrange
        invalid_dataset = "not_a_list"  # Dataset inválido
        
        # Act & Assert
        with pytest.raises(ValueError, match="Dataset deve ser uma lista"):
            await quality_engine.execute_quality_rules(
                rules=sample_quality_rules,
                dataset=invalid_dataset,
                execution_mode=QualityExecutionMode.SYNCHRONOUS
            )
    
    @pytest.mark.asyncio
    async def test_error_handling_empty_rules(self, quality_engine, sample_dataset):
        """Testa tratamento de erro com lista de regras vazia"""
        # Act & Assert
        with pytest.raises(ValueError, match="Lista de regras não pode estar vazia"):
            await quality_engine.execute_quality_rules(
                rules=[],
                dataset=sample_dataset,
                execution_mode=QualityExecutionMode.SYNCHRONOUS
            )
    
    @pytest.mark.asyncio
    async def test_metrics_calculation(self, quality_engine, sample_quality_rules, sample_dataset):
        """Testa cálculo de métricas de qualidade"""
        # Act
        result = await quality_engine.execute_quality_rules(
            rules=sample_quality_rules,
            dataset=sample_dataset,
            execution_mode=QualityExecutionMode.SYNCHRONOUS
        )
        
        metrics = quality_engine._calculate_quality_metrics(result)
        
        # Assert
        assert isinstance(metrics, QualityMetrics)
        assert metrics.total_records == len(sample_dataset)
        assert metrics.total_rules == len(sample_quality_rules)
        assert metrics.overall_score == result.overall_score
        assert metrics.records_with_issues >= 0
        assert metrics.records_with_issues <= len(sample_dataset)
        assert metrics.average_rule_score >= 0.0
        assert metrics.average_rule_score <= 100.0
        assert len(metrics.scores_by_rule_type) > 0
        assert len(metrics.issues_by_severity) >= 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

