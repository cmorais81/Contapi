# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
Quality Service - Microserviço de Qualidade de Dados
Versão: 4.0.1 - Corrigida com base na V3.2
Data: 27 de Janeiro de 2025
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Query, Path, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'config'))

try:
    from settings import get_settings
    settings = get_settings()
except ImportError:
    print("⚠️ Configurações centralizadas não encontradas, usando valores padrão")
    settings = None


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Quality Service",
    description="Microserviço para gestão de qualidade de dados - V4.0 Corrigido",
    version="4.0.1",
    contact={
        "name": " ",
        "email": "@example.com"
    }
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# PYDANTIC MODELS
# =====================================================

class QualityRuleBase(BaseModel):
    name: str = Field(..., description="Nome da regra")
    description: Optional[str] = Field(None, description="Descrição da regra")
    rule_type: str = Field("completeness", description="Tipo da regra")
    threshold: float = Field(0.95, description="Limite da regra")
    is_active: bool = Field(True, description="Regra ativa")

class QualityRuleCreate(QualityRuleBase):
    pass

class QualityRuleUpdate(QualityRuleBase):
    pass

class QualityRuleResponse(QualityRuleBase):
    id: str
    created_at: datetime
    updated_at: datetime

class ValidationRequest(BaseModel):
    data: Dict[str, Any] = Field(..., description="Dados para validação")
    rules: Optional[List[str]] = Field(None, description="IDs das regras específicas")

# =====================================================
# IN-MEMORY DATABASE (Simulação)
# =====================================================

quality_rules_db = {}
validation_results_db = {}
audit_logs = []

def log_audit(action: str, resource_id: str = None, details: str = None):
    """Log audit trail"""
    try:
        audit_logs.append({
            "id": str(uuid4()),
            "action": action,
            "resource_type": "quality_rules",
            "resource_id": resource_id,
            "details": details,
            "created_at": datetime.utcnow().isoformat()
        })
    except Exception as e:
        logger.error(f"Error logging audit: {e}")

def init_sample_data():
    """Initialize sample quality rules"""
    sample_rules = [
        {
            "id": str(uuid4()),
            "name": "Completude de Email",
            "description": "Verifica se o campo email está preenchido",
            "rule_type": "completeness",
            "threshold": 0.95,
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "Formato de CPF",
            "description": "Verifica se o CPF está no formato correto",
            "rule_type": "format",
            "threshold": 1.0,
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        },
        {
            "id": str(uuid4()),
            "name": "Unicidade de Email",
            "description": "Verifica se não há emails duplicados",
            "rule_type": "uniqueness",
            "threshold": 1.0,
            "is_active": True,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        }
    ]
    
    for rule in sample_rules:
        quality_rules_db[rule["id"]] = rule
    
    logger.info(f"Initialized {len(sample_rules)} sample quality rules")

def validate_data_quality(data: Dict[str, Any], rules: List[str] = None) -> Dict[str, Any]:
    """Validate data quality based on rules"""
    results = {
        "overall_score": 0.0,
        "passed_rules": 0,
        "failed_rules": 0,
        "rule_results": [],
        "recommendations": []
    }
    
    # Get rules to apply
    rules_to_apply = []
    if rules:
        rules_to_apply = [quality_rules_db[rule_id] for rule_id in rules if rule_id in quality_rules_db]
    else:
        rules_to_apply = [rule for rule in quality_rules_db.values() if rule["is_active"]]
    
    if not rules_to_apply:
        return {
            "overall_score": 100.0,
            "passed_rules": 0,
            "failed_rules": 0,
            "rule_results": [],
            "recommendations": ["No quality rules to apply"]
        }
    
    total_score = 0
    
    for rule in rules_to_apply:
        rule_result = {
            "rule_id": rule["id"],
            "rule_name": rule["name"],
            "rule_type": rule["rule_type"],
            "threshold": rule["threshold"],
            "score": 0.0,
            "passed": False,
            "message": "",
            "recommendations": []
        }
        
        # Apply rule based on type
        if rule["rule_type"] == "completeness":
            # Check completeness
            total_fields = len(data)
            filled_fields = sum(1 for value in data.values() if value is not None and str(value).strip() != "")
            score = filled_fields / total_fields if total_fields > 0 else 1.0
            
            rule_result["score"] = score
            rule_result["passed"] = score >= rule["threshold"]
            rule_result["message"] = f"Completeness: {score:.2%} ({filled_fields}/{total_fields} fields filled)"
            
            if not rule_result["passed"]:
                rule_result["recommendations"].append("Fill missing required fields")
                
        elif rule["rule_type"] == "format":
            # Check format (simplified - checking for email format)
            valid_formats = 0
            total_formats = 0
            
            for key, value in data.items():
                if "email" in key.lower() and value:
                    total_formats += 1
                    if "@" in str(value) and "." in str(value):
                        valid_formats += 1
                elif "cpf" in key.lower() and value:
                    total_formats += 1
                    cpf_str = str(value).replace(".", "").replace("-", "")
                    if len(cpf_str) == 11 and cpf_str.isdigit():
                        valid_formats += 1
            
            score = valid_formats / total_formats if total_formats > 0 else 1.0
            rule_result["score"] = score
            rule_result["passed"] = score >= rule["threshold"]
            rule_result["message"] = f"Format validation: {score:.2%} ({valid_formats}/{total_formats} valid formats)"
            
            if not rule_result["passed"]:
                rule_result["recommendations"].append("Fix format issues in data fields")
                
        elif rule["rule_type"] == "uniqueness":
            # Check uniqueness (simplified)
            values = list(data.values())
            unique_values = len(set(str(v) for v in values if v is not None))
            total_values = len([v for v in values if v is not None])
            
            score = unique_values / total_values if total_values > 0 else 1.0
            rule_result["score"] = score
            rule_result["passed"] = score >= rule["threshold"]
            rule_result["message"] = f"Uniqueness: {score:.2%} ({unique_values}/{total_values} unique values)"
            
            if not rule_result["passed"]:
                rule_result["recommendations"].append("Remove duplicate values")
        
        else:
            # Default rule
            rule_result["score"] = 1.0
            rule_result["passed"] = True
            rule_result["message"] = "Rule type not implemented"
        
        results["rule_results"].append(rule_result)
        total_score += rule_result["score"]
        
        if rule_result["passed"]:
            results["passed_rules"] += 1
        else:
            results["failed_rules"] += 1
            results["recommendations"].extend(rule_result["recommendations"])
    
    # Calculate overall score
    results["overall_score"] = (total_score / len(rules_to_apply)) * 100 if rules_to_apply else 100.0
    
    # Add general recommendations
    if results["overall_score"] < 80:
        results["recommendations"].append("Consider implementing data quality monitoring")
    if results["failed_rules"] > 0:
        results["recommendations"].append("Review and fix failed quality rules")
    
    return results

# =====================================================
# API ENDPOINTS
# =====================================================

@app.get("/", tags=["System"])
async def root():
    """Root endpoint with service information"""
    return {
        "service": "Quality Service",
        "version": "4.0.1",
        "status": "running",
        "description": "Microserviço para gestão de qualidade de dados - Corrigido",
        "corrections_applied": [
            "Dependências estabilizadas",
            "Error handling robusto",
            "Logs estruturados",
            "In-memory database funcional"
        ],
        "endpoints": {
            "health": "/health",
            "docs": "/docs",
            "rules": "/api/v1/quality/rules",
            "validate": "/api/v1/quality/validate"
        }
    }

@app.get("/health", tags=["System"])
async def health_check():
    """Health check endpoint"""
    try:
        return {
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "version": "4.0.1",
            "service": "quality-service",
            "port": 8003,
            "corrections_applied": True,
            "data_counts": {
                "quality_rules": len(quality_rules_db),
                "validation_results": len(validation_results_db),
                "audit_logs": len(audit_logs)
            },
            "features": {
                "quality_rules_management": True,
                "data_validation": True,
                "audit_trail": True
            }
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=500,
            content={
                "status": "unhealthy",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }
        )

@app.get("/api/v1/quality/rules", response_model=List[QualityRuleResponse], tags=["Quality Rules"])
async def list_quality_rules(
    rule_type: Optional[str] = Query(None, description="Filtrar por tipo de regra"),
    is_active: Optional[bool] = Query(None, description="Filtrar por status ativo"),
    limit: int = Query(100, description="Limite de resultados")
):
    """Listar todas as regras de qualidade"""
    try:
        rules = list(quality_rules_db.values())
        
        # Apply filters
        if rule_type:
            rules = [r for r in rules if r["rule_type"] == rule_type]
        
        if is_active is not None:
            rules = [r for r in rules if r["is_active"] == is_active]
        
        # Apply limit
        rules = rules[:limit]
        
        # Convert datetime objects to ISO format
        for rule in rules:
            rule["created_at"] = rule["created_at"].isoformat()
            rule["updated_at"] = rule["updated_at"].isoformat()
        
        log_audit("list", details=f"Listed {len(rules)} quality rules")
        return rules
        
    except Exception as e:
        logger.error(f"Error listing quality rules: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing quality rules: {str(e)}")

@app.get("/api/v1/quality/rules/{rule_id}", response_model=QualityRuleResponse, tags=["Quality Rules"])
async def get_quality_rule(rule_id: str = Path(..., description="ID da regra")):
    """Buscar regra específica por ID"""
    try:
        if rule_id not in quality_rules_db:
            raise HTTPException(status_code=404, detail="Quality rule not found")
        
        rule = quality_rules_db[rule_id].copy()
        rule["created_at"] = rule["created_at"].isoformat()
        rule["updated_at"] = rule["updated_at"].isoformat()
        
        log_audit("get", resource_id=rule_id)
        return rule
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting quality rule: {e}")
        raise HTTPException(status_code=500, detail=f"Error getting quality rule: {str(e)}")

@app.post("/api/v1/quality/rules", response_model=QualityRuleResponse, tags=["Quality Rules"])
async def create_quality_rule(rule: QualityRuleCreate):
    """Criar nova regra de qualidade"""
    try:
        rule_id = str(uuid4())
        now = datetime.utcnow()
        
        new_rule = {
            "id": rule_id,
            "name": rule.name,
            "description": rule.description,
            "rule_type": rule.rule_type,
            "threshold": rule.threshold,
            "is_active": rule.is_active,
            "created_at": now,
            "updated_at": now
        }
        
        quality_rules_db[rule_id] = new_rule
        
        log_audit("create", resource_id=rule_id, details=f"Created quality rule: {rule.name}")
        
        # Convert datetime for response
        response_rule = new_rule.copy()
        response_rule["created_at"] = response_rule["created_at"].isoformat()
        response_rule["updated_at"] = response_rule["updated_at"].isoformat()
        
        return response_rule
        
    except Exception as e:
        logger.error(f"Error creating quality rule: {e}")
        raise HTTPException(status_code=500, detail=f"Error creating quality rule: {str(e)}")

@app.put("/api/v1/quality/rules/{rule_id}", response_model=QualityRuleResponse, tags=["Quality Rules"])
async def update_quality_rule(rule_id: str, rule: QualityRuleUpdate):
    """Atualizar regra existente"""
    try:
        if rule_id not in quality_rules_db:
            raise HTTPException(status_code=404, detail="Quality rule not found")
        
        existing_rule = quality_rules_db[rule_id]
        
        # Update fields
        existing_rule.update({
            "name": rule.name,
            "description": rule.description,
            "rule_type": rule.rule_type,
            "threshold": rule.threshold,
            "is_active": rule.is_active,
            "updated_at": datetime.utcnow()
        })
        
        log_audit("update", resource_id=rule_id, details=f"Updated quality rule: {rule.name}")
        
        # Convert datetime for response
        response_rule = existing_rule.copy()
        response_rule["created_at"] = response_rule["created_at"].isoformat()
        response_rule["updated_at"] = response_rule["updated_at"].isoformat()
        
        return response_rule
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating quality rule: {e}")
        raise HTTPException(status_code=500, detail=f"Error updating quality rule: {str(e)}")

@app.delete("/api/v1/quality/rules/{rule_id}", tags=["Quality Rules"])
async def delete_quality_rule(rule_id: str):
    """Deletar regra de qualidade"""
    try:
        if rule_id not in quality_rules_db:
            raise HTTPException(status_code=404, detail="Quality rule not found")
        
        rule_name = quality_rules_db[rule_id]["name"]
        del quality_rules_db[rule_id]
        
        log_audit("delete", resource_id=rule_id, details=f"Deleted quality rule: {rule_name}")
        
        return {"message": "Quality rule deleted successfully", "id": rule_id}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting quality rule: {e}")
        raise HTTPException(status_code=500, detail=f"Error deleting quality rule: {str(e)}")

@app.post("/api/v1/quality/validate", tags=["Quality Validation"])
async def validate_data(request: ValidationRequest):
    """Validar qualidade dos dados"""
    try:
        validation_id = str(uuid4())
        
        # Perform validation
        results = validate_data_quality(request.data, request.rules)
        
        # Store results
        validation_result = {
            "id": validation_id,
            "data": request.data,
            "rules_applied": request.rules or "all_active",
            "results": results,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        validation_results_db[validation_id] = validation_result
        
        log_audit("validate", resource_id=validation_id, 
                 details=f"Validated data - Score: {results['overall_score']:.1f}%")
        
        return {
            "validation_id": validation_id,
            "overall_score": results["overall_score"],
            "quality_level": "excellent" if results["overall_score"] >= 90 else 
                           "good" if results["overall_score"] >= 70 else
                           "fair" if results["overall_score"] >= 50 else "poor",
            "passed_rules": results["passed_rules"],
            "failed_rules": results["failed_rules"],
            "total_rules": results["passed_rules"] + results["failed_rules"],
            "rule_results": results["rule_results"],
            "recommendations": results["recommendations"],
            "timestamp": validation_result["timestamp"]
        }
        
    except Exception as e:
        logger.error(f"Error validating data: {e}")
        raise HTTPException(status_code=500, detail=f"Error validating data: {str(e)}")

@app.get("/api/v1/quality/types", tags=["Quality Rules"])
async def list_rule_types():
    """Listar tipos de regras disponíveis"""
    try:
        rule_types = [
            {
                "type": "completeness",
                "description": "Verifica se os campos obrigatórios estão preenchidos",
                "example": "Verificar se email não está vazio"
            },
            {
                "type": "format",
                "description": "Verifica se os dados estão no formato correto",
                "example": "Verificar formato de email ou CPF"
            },
            {
                "type": "uniqueness",
                "description": "Verifica se não há valores duplicados",
                "example": "Verificar se emails são únicos"
            },
            {
                "type": "range",
                "description": "Verifica se valores estão dentro de um intervalo",
                "example": "Verificar se idade está entre 0 e 120"
            },
            {
                "type": "consistency",
                "description": "Verifica consistência entre campos relacionados",
                "example": "Verificar se data de nascimento é consistente com idade"
            }
        ]
        
        return {
            "available_types": rule_types,
            "total_types": len(rule_types)
        }
        
    except Exception as e:
        logger.error(f"Error listing rule types: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing rule types: {str(e)}")

@app.get("/api/v1/audit/logs", tags=["Audit"])
async def list_audit_logs(limit: int = Query(100, description="Limite de resultados")):
    """Listar logs de auditoria"""
    try:
        logs = audit_logs[-limit:] if limit < len(audit_logs) else audit_logs
        return logs
    except Exception as e:
        logger.error(f"Error listing audit logs: {e}")
        raise HTTPException(status_code=500, detail=f"Error listing audit logs: {str(e)}")

# Initialize sample data on startup
@app.on_event("startup")
async def startup_event():
    """Initialize service on startup"""
    logger.info("Starting Quality Service V4.0.1 - Corrigido")
    init_sample_data()
    logger.info("Quality Service started successfully")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8003)

