# Autor: carlos.morais@f1rst.com.br
"""
Quality Rule Domain Entity
Core business entity for data quality rules and validation
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Union
from uuid import UUID, uuid4
from enum import Enum
import json

from ..value_objects.quality_metric import QualityMetric, QualityThreshold
from ..value_objects.rule_severity import RuleSeverity
from ..events.quality_events import (
    QualityRuleCreated, QualityRuleUpdated, QualityRuleActivated,
    QualityRuleDeactivated, QualityRuleExecuted, QualityViolationDetected
)


class RuleType(Enum):
    """Types of quality rules"""
    COMPLETENESS = "completeness"
    ACCURACY = "accuracy"
    CONSISTENCY = "consistency"
    VALIDITY = "validity"
    UNIQUENESS = "uniqueness"
    TIMELINESS = "timeliness"
    CONFORMITY = "conformity"
    INTEGRITY = "integrity"
    CUSTOM = "custom"


class RuleStatus(Enum):
    """Quality rule status"""
    DRAFT = "draft"
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEPRECATED = "deprecated"
    FLED = "failed"


@dataclass
class QualityRule:
    """
    Quality Rule aggregate root for data quality validation
    """
    # Identity
    id: UUID = field(default_factory=uuid4)
    name: str = ""
    description: Optional[str] = None
    rule_type: RuleType = field(default=RuleType.COMPLETENESS)
    
    # Rule definition
    rule_expression: str = ""  # SQL-like expression or Python code
    rule_language: str = "sql"  # sql, python, spark_sql
    target_table: str = ""
    target_columns: List[str] = field(default_factory=list)
    
    # Thresholds and metrics
    quality_metric: QualityMetric = field(default=QualityMetric.COMPLETENESS_RATE)
    threshold: QualityThreshold = field(default_factory=lambda: QualityThreshold(min_value=0.95))
    severity: RuleSeverity = field(default=RuleSeverity.MEDIUM)
    
    # Execution configuration
    execution_schedule: Optional[str] = None  # Cron expression
    execution_timeout_minutes: int = 30
    retry_attempts: int = 3
    
    # Status and lifecycle
    status: RuleStatus = field(default=RuleStatus.DRAFT)
    is_active: bool = False
    
    # Ownership and organization
    owner_id: UUID = field(default_factory=uuid4)
    organization_id: UUID = field(default_factory=uuid4)
    contract_id: Optional[UUID] = None
    dataset_id: Optional[UUID] = None
    
    # Execution history
    last_execution_at: Optional[datetime] = None
    last_execution_status: Optional[str] = None
    last_execution_result: Optional[Dict[str, Any]] = None
    execution_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    
    # Alerting
    alert_on_failure: bool = True
    alert_recipients: List[str] = field(default_factory=list)
    escalation_rules: Dict[str, Any] = field(default_factory=dict)
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    business_impact: Optional[str] = None
    remediation_guidance: Optional[str] = None
    
    # Audit fields
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    created_by: UUID = field(default_factory=uuid4)
    updated_by: UUID = field(default_factory=uuid4)
    deleted_at: Optional[datetime] = None
    
    # Domain events
    _domain_events: List[Any] = field(default_factory=list, init=False)
    
    def __post_init__(self):
        """Post-initialization validation and setup"""
        if not self.name:
            raise ValueError("Quality rule name is required")
        
        if not self.rule_expression:
            raise ValueError("Rule expression is required")
        
        if not self.target_table:
            raise ValueError("Target table is required")
        
        # Set default alert recipients
        if not self.alert_recipients:
            self.alert_recipients = []
    
    def create(self, created_by: UUID) -> None:
        """Create a new quality rule"""
        if self.status != RuleStatus.DRAFT:
            raise ValueError("Can only create rules in draft status")
        
        self.created_by = created_by
        self.updated_by = created_by
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(QualityRuleCreated(
            rule_id=self.id,
            name=self.name,
            rule_type=self.rule_type.value,
            target_table=self.target_table,
            owner_id=self.owner_id,
            created_by=created_by,
            occurred_at=datetime.utcnow()
        ))
    
    def update(self, updated_by: UUID, **kwargs) -> None:
        """Update quality rule fields"""
        if self.status == RuleStatus.ACTIVE and self._has_breaking_changes(kwargs):
            raise ValueError("Cannot make breaking changes to active rule")
        
        old_values = {}
        for key, value in kwargs.items():
            if hasattr(self, key):
                old_values[key] = getattr(self, key)
                setattr(self, key, value)
        
        self.updated_by = updated_by
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(QualityRuleUpdated(
            rule_id=self.id,
            updated_fields=list(kwargs.keys()),
            old_values=old_values,
            new_values=kwargs,
            updated_by=updated_by,
            occurred_at=datetime.utcnow()
        ))
    
    def activate(self, activated_by: UUID) -> None:
        """Activate quality rule"""
        if self.status == RuleStatus.ACTIVE:
            return  # Already active
        
        # Validate rule before activation
        if not self._validate_rule():
            raise ValueError("Rule validation failed, cannot activate")
        
        self.status = RuleStatus.ACTIVE
        self.is_active = True
        self.updated_by = activated_by
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(QualityRuleActivated(
            rule_id=self.id,
            activated_by=activated_by,
            occurred_at=datetime.utcnow()
        ))
    
    def deactivate(self, deactivated_by: UUID, reason: str) -> None:
        """Deactivate quality rule"""
        if self.status == RuleStatus.INACTIVE:
            return  # Already inactive
        
        self.status = RuleStatus.INACTIVE
        self.is_active = False
        self.updated_by = deactivated_by
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(QualityRuleDeactivated(
            rule_id=self.id,
            deactivated_by=deactivated_by,
            reason=reason,
            occurred_at=datetime.utcnow()
        ))
    
    def execute(self, execution_context: Dict[str, Any]) -> 'QualityRuleExecution':
        """Execute quality rule and return result"""
        if not self.is_active:
            raise ValueError("Cannot execute inactive rule")
        
        execution_id = uuid4()
        started_at = datetime.utcnow()
        
        try:
            # Simulate rule execution (in real implementation, this would call the actual engine)
            result = self._simulate_execution(execution_context)
            
            # Update execution statistics
            self.execution_count += 1
            self.last_execution_at = started_at
            self.last_execution_status = "success" if result.passed else "failed"
            self.last_execution_result = result.to_dict()
            
            if result.passed:
                self.success_count += 1
            else:
                self.failure_count += 1
                
                # Raise violation event if rule failed
                self._add_domain_event(QualityViolationDetected(
                    rule_id=self.id,
                    execution_id=execution_id,
                    metric_value=result.metric_value,
                    threshold_value=result.threshold_value,
                    severity=self.severity.value,
                    occurred_at=started_at
                ))
            
            # Raise execution event
            self._add_domain_event(QualityRuleExecuted(
                rule_id=self.id,
                execution_id=execution_id,
                status="success" if result.passed else "failed",
                metric_value=result.metric_value,
                execution_time_ms=result.execution_time_ms,
                occurred_at=started_at
            ))
            
            return result
            
        except Exception as e:
            # Handle execution failure
            self.execution_count += 1
            self.failure_count += 1
            self.last_execution_at = started_at
            self.last_execution_status = "error"
            self.last_execution_result = {"error": str(e)}
            
            # Create failed execution result
            result = QualityRuleExecution(
                execution_id=execution_id,
                rule_id=self.id,
                started_at=started_at,
                completed_at=datetime.utcnow(),
                status="error",
                error_message=str(e)
            )
            
            return result
    
    def get_success_rate(self) -> float:
        """Calculate rule success rate"""
        if self.execution_count == 0:
            return 0.0
        return self.success_count / self.execution_count
    
    def is_healthy(self) -> bool:
        """Check if rule is healthy (good success rate)"""
        return self.get_success_rate() >= 0.8
    
    def needs_attention(self) -> bool:
        """Check if rule needs attention"""
        # Rule needs attention if:
        # 1. Success rate is low
        # 2. No recent executions
        # 3. Multiple consecutive failures
        
        if self.get_success_rate() < 0.5:
            return True
        
        if self.last_execution_at:
            days_since_execution = (datetime.utcnow() - self.last_execution_at).days
            if days_since_execution > 7:  # No execution in a week
                return True
        
        return False
    
    def get_next_execution_time(self) -> Optional[datetime]:
        """Get next scheduled execution time"""
        if not self.execution_schedule or not self.is_active:
            return None
        
        # Simple implementation - in real system would use proper cron parser
        # For now, assume daily execution
        if self.last_execution_at:
            return self.last_execution_at + timedelta(days=1)
        else:
            return datetime.utcnow() + timedelta(hours=1)
    
    def add_alert_recipient(self, email: str) -> None:
        """Add alert recipient"""
        if email not in self.alert_recipients:
            self.alert_recipients.append(email)
            self.updated_at = datetime.utcnow()
    
    def remove_alert_recipient(self, email: str) -> None:
        """Remove alert recipient"""
        if email in self.alert_recipients:
            self.alert_recipients.remove(email)
            self.updated_at = datetime.utcnow()
    
    def add_tag(self, tag: str) -> None:
        """Add tag to rule"""
        if tag not in self.tags:
            self.tags.append(tag)
            self.updated_at = datetime.utcnow()
    
    def remove_tag(self, tag: str) -> None:
        """Remove tag from rule"""
        if tag in self.tags:
            self.tags.remove(tag)
            self.updated_at = datetime.utcnow()
    
    def get_domain_events(self) -> List[Any]:
        """Get and clear domain events"""
        events = self._domain_events.copy()
        self._domain_events.clear()
        return events
    
    def _add_domain_event(self, event: Any) -> None:
        """Add a domain event"""
        self._domain_events.append(event)
    
    def _validate_rule(self) -> bool:
        """Validate rule configuration"""
        # Basic validation
        if not self.rule_expression or not self.target_table:
            return False
        
        # Validate rule expression syntax (simplified)
        if self.rule_language == "sql":
            # Basic SQL validation
            forbidden_keywords = ["DROP", "DELETE", "TRUNCATE", "ALTER"]
            expression_upper = self.rule_expression.upper()
            if any(keyword in expression_upper for keyword in forbidden_keywords):
                return False
        
        return True
    
    def _has_breaking_changes(self, changes: Dict[str, Any]) -> bool:
        """Check if changes are breaking for active rule"""
        breaking_fields = ['rule_expression', 'target_table', 'target_columns', 'quality_metric']
        return any(field in changes for field in breaking_fields)
    
    def _simulate_execution(self, context: Dict[str, Any]) -> 'QualityRuleExecution':
        """Simulate rule execution (placeholder for actual implementation)"""
        import random
        
        execution_id = uuid4()
        started_at = datetime.utcnow()
        
        # Simulate execution time
        execution_time_ms = random.randint(100, 5000)
        
        # Simulate metric calculation
        if self.quality_metric == QualityMetric.COMPLETENESS_RATE:
            metric_value = random.uniform(0.85, 1.0)
        elif self.quality_metric == QualityMetric.ACCURACY_RATE:
            metric_value = random.uniform(0.90, 1.0)
        elif self.quality_metric == QualityMetric.UNIQUENESS_RATE:
            metric_value = random.uniform(0.95, 1.0)
        else:
            metric_value = random.uniform(0.80, 1.0)
        
        # Check against threshold
        passed = self.threshold.is_within_threshold(metric_value)
        
        return QualityRuleExecution(
            execution_id=execution_id,
            rule_id=self.id,
            started_at=started_at,
            completed_at=datetime.utcnow(),
            status="success",
            metric_value=metric_value,
            threshold_value=self.threshold.min_value or self.threshold.max_value,
            passed=passed,
            execution_time_ms=execution_time_ms,
            records_processed=context.get('record_count', 1000),
            records_failed=0 if passed else int(context.get('record_count', 1000) * (1 - metric_value))
        )


@dataclass
class QualityRuleExecution:
    """Represents a quality rule execution result"""
    execution_id: UUID = field(default_factory=uuid4)
    rule_id: UUID = field(default_factory=uuid4)
    
    # Timing
    started_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    execution_time_ms: int = 0
    
    # Status
    status: str = "running"  # running, success, failed, error
    error_message: Optional[str] = None
    
    # Results
    metric_value: Optional[float] = None
    threshold_value: Optional[float] = None
    passed: bool = False
    
    # Data processed
    records_processed: int = 0
    records_failed: int = 0
    records_passed: int = 0
    
    # Additional metadata
    execution_context: Dict[str, Any] = field(default_factory=dict)
    detailed_results: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert execution to dictionary"""
        return {
            'execution_id': str(self.execution_id),
            'rule_id': str(self.rule_id),
            'started_at': self.started_at.isoformat(),
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'execution_time_ms': self.execution_time_ms,
            'status': self.status,
            'error_message': self.error_message,
            'metric_value': self.metric_value,
            'threshold_value': self.threshold_value,
            'passed': self.passed,
            'records_processed': self.records_processed,
            'records_failed': self.records_failed,
            'records_passed': self.records_passed
        }
    
    def get_success_rate(self) -> float:
        """Get success rate for this execution"""
        if self.records_processed == 0:
            return 0.0
        return self.records_passed / self.records_processed
    
    def is_completed(self) -> bool:
        """Check if execution is completed"""
        return self.status in ['success', 'failed', 'error']
    
    def is_successful(self) -> bool:
        """Check if execution was successful"""
        return self.status == 'success' and self.passed


@dataclass
class QualityRuleTemplate:
    """Template for creating quality rules"""
    id: UUID = field(default_factory=uuid4)
    name: str = ""
    description: str = ""
    rule_type: RuleType = field(default=RuleType.COMPLETENESS)
    
    # Template definition
    rule_expression_template: str = ""
    parameter_definitions: List[Dict[str, Any]] = field(default_factory=list)
    
    # Default values
    default_threshold: QualityThreshold = field(default_factory=lambda: QualityThreshold(min_value=0.95))
    default_severity: RuleSeverity = field(default=RuleSeverity.MEDIUM)
    
    # Metadata
    category: str = "general"
    tags: List[str] = field(default_factory=list)
    use_cases: List[str] = field(default_factory=list)
    
    # Audit
    created_at: datetime = field(default_factory=datetime.utcnow)
    created_by: UUID = field(default_factory=uuid4)
    
    def create_rule(self, parameters: Dict[str, Any], owner_id: UUID) -> QualityRule:
        """Create a quality rule from this template"""
        # Replace parameters in template
        rule_expression = self.rule_expression_template
        for param_name, param_value in parameters.items():
            rule_expression = rule_expression.replace(f"{{{param_name}}}", str(param_value))
        
        return QualityRule(
            name=parameters.get('name', self.name),
            description=parameters.get('description', self.description),
            rule_type=self.rule_type,
            rule_expression=rule_expression,
            target_table=parameters.get('target_table', ''),
            target_columns=parameters.get('target_columns', []),
            threshold=parameters.get('threshold', self.default_threshold),
            severity=parameters.get('severity', self.default_severity),
            owner_id=owner_id,
            organization_id=parameters.get('organization_id', uuid4()),
            tags=self.tags.copy()
        )

