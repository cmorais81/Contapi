# Autor: carlos.morais@f1rst.com.br
"""
Quality Engine Service - Engine de Regras de Qualidade Configurável
"""

import asyncio
import json
import re
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Set, Tuple, Union
from uuid import UUID
from enum import Enum
from dataclasses import dataclass

from ..entities.quality_rule import QualityRule, RuleType, RuleStatus
from ..value_objects.quality_metric import QualityMetric, QualityThreshold
from ..value_objects.rule_severity import RuleSeverity


class ExecutionMode(Enum):
    """Modos de execução do engine"""
    SYNCHRONOUS = "synchronous"
    ASYNCHRONOUS = "asynchronous"
    BATCH = "batch"
    STREAMING = "streaming"


class ValidationResult(Enum):
    """Resultado da validação"""
    PASSED = "passed"
    FAILED = "failed"
    WARNING = "warning"
    SKIPPED = "skipped"
    ERROR = "error"


@dataclass
class QualityCheckResult:
    """Resultado de uma verificação de qualidade"""
    rule_id: UUID
    rule_name: str
    rule_type: RuleType
    severity: RuleSeverity
    result: ValidationResult
    score: float
    threshold: float
    actual_value: Any
    expected_value: Any
    message: str
    details: Dict[str, Any]
    execution_time_ms: float
    timestamp: datetime
    dataset_id: Optional[UUID] = None
    field_name: Optional[str] = None
    record_count: int = 0
    violation_count: int = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            "rule_id": str(self.rule_id),
            "rule_name": self.rule_name,
            "rule_type": self.rule_type.value,
            "severity": self.severity.value,
            "result": self.result.value,
            "score": self.score,
            "threshold": self.threshold,
            "actual_value": self.actual_value,
            "expected_value": self.expected_value,
            "message": self.message,
            "details": self.details,
            "execution_time_ms": self.execution_time_ms,
            "timestamp": self.timestamp.isoformat(),
            "dataset_id": str(self.dataset_id) if self.dataset_id else None,
            "field_name": self.field_name,
            "record_count": self.record_count,
            "violation_count": self.violation_count
        }


@dataclass
class QualityExecutionContext:
    """Contexto de execução das regras de qualidade"""
    dataset_id: UUID
    dataset_name: str
    schema_definition: Dict[str, Any]
    data_sample: Optional[List[Dict[str, Any]]] = None
    execution_mode: ExecutionMode = ExecutionMode.SYNCHRONOUS
    max_execution_time_seconds: int = 300
    max_sample_size: int = 10000
    parallel_execution: bool = True
    cache_results: bool = True
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class QualityEngineService:
    """
    Engine de Qualidade de Dados Configurável
    
    Responsabilidades:
    - Executar regras de qualidade configuráveis
    - Suportar múltiplos tipos de validação
    - Gerenciar execução síncrona e assíncrona
    - Calcular métricas de qualidade
    - Detectar violações e anomalias
    - Gerar relatórios de qualidade
    """
    
    def __init__(self):
        """Inicializa o engine de qualidade"""
        self._rule_executors = {
            RuleType.COMPLETENESS: self._execute_completeness_rule,
            RuleType.ACCURACY: self._execute_accuracy_rule,
            RuleType.CONSISTENCY: self._execute_consistency_rule,
            RuleType.VALIDITY: self._execute_validity_rule,
            RuleType.UNIQUENESS: self._execute_uniqueness_rule,
            RuleType.TIMELINESS: self._execute_timeliness_rule,
            RuleType.CONFORMITY: self._execute_conformity_rule,
            RuleType.INTEGRITY: self._execute_integrity_rule,
            RuleType.CUSTOM: self._execute_custom_rule
        }
        
        self._execution_cache = {}
        self._metrics_cache = {}
    
    async def execute_quality_rules(
        self,
        rules: List[QualityRule],
        context: QualityExecutionContext
    ) -> List[QualityCheckResult]:
        """
        Executa um conjunto de regras de qualidade
        
        Args:
            rules: Lista de regras a serem executadas
            context: Contexto de execução
            
        Returns:
            List[QualityCheckResult]: Resultados das verificações
        """
        results = []
        
        # Filtrar regras ativas
        active_rules = [rule for rule in rules if rule.status == RuleStatus.ACTIVE]
        
        if not active_rules:
            return results
        
        # Executar regras baseado no modo
        if context.execution_mode == ExecutionMode.SYNCHRONOUS:
            results = await self._execute_synchronous(active_rules, context)
        elif context.execution_mode == ExecutionMode.ASYNCHRONOUS:
            results = await self._execute_asynchronous(active_rules, context)
        elif context.execution_mode == ExecutionMode.BATCH:
            results = await self._execute_batch(active_rules, context)
        elif context.execution_mode == ExecutionMode.STREAMING:
            results = await self._execute_streaming(active_rules, context)
        
        # Cache dos resultados se habilitado
        if context.cache_results:
            self._cache_results(results, context)
        
        return results
    
    async def _execute_synchronous(
        self,
        rules: List[QualityRule],
        context: QualityExecutionContext
    ) -> List[QualityCheckResult]:
        """Executa regras de forma síncrona"""
        results = []
        
        for rule in rules:
            try:
                start_time = datetime.utcnow()
                result = await self._execute_single_rule(rule, context)
                execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000
                result.execution_time_ms = execution_time
                results.append(result)
                
            except Exception as e:
                # Criar resultado de erro
                error_result = QualityCheckResult(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    rule_type=rule.rule_type,
                    severity=rule.severity,
                    result=ValidationResult.ERROR,
                    score=0.0,
                    threshold=0.0,
                    actual_value=None,
                    expected_value=None,
                    message=f"Erro na execução da regra: {str(e)}",
                    details={"error": str(e), "rule_config": rule.configuration},
                    execution_time_ms=0.0,
                    timestamp=datetime.utcnow(),
                    dataset_id=context.dataset_id
                )
                results.append(error_result)
        
        return results
    
    async def _execute_asynchronous(
        self,
        rules: List[QualityRule],
        context: QualityExecutionContext
    ) -> List[QualityCheckResult]:
        """Executa regras de forma assíncrona"""
        if context.parallel_execution:
            # Executar regras em paralelo
            tasks = [self._execute_single_rule_with_timing(rule, context) for rule in rules]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Processar resultados e exceções
            processed_results = []
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    error_result = self._create_error_result(rules[i], str(result), context)
                    processed_results.append(error_result)
                else:
                    processed_results.append(result)
            
            return processed_results
        else:
            # Executar sequencialmente mas de forma assíncrona
            return await self._execute_synchronous(rules, context)
    
    async def _execute_batch(
        self,
        rules: List[QualityRule],
        context: QualityExecutionContext
    ) -> List[QualityCheckResult]:
        """Executa regras em lotes"""
        batch_size = 5  # Configurável
        results = []
        
        for i in range(0, len(rules), batch_size):
            batch = rules[i:i + batch_size]
            batch_results = await self._execute_asynchronous(batch, context)
            results.extend(batch_results)
            
            # Pequena pausa entre lotes para não sobrecarregar
            await asyncio.sleep(0.1)
        
        return results
    
    async def _execute_streaming(
        self,
        rules: List[QualityRule],
        context: QualityExecutionContext
    ) -> List[QualityCheckResult]:
        """Executa regras em modo streaming"""
        # Para modo streaming, executamos as regras em pequenos chunks dos dados
        results = []
        
        if not context.data_sample:
            # Se não há dados de amostra, executa como batch
            return await self._execute_batch(rules, context)
        
        chunk_size = 1000  # Configurável
        data_chunks = [
            context.data_sample[i:i + chunk_size] 
            for i in range(0, len(context.data_sample), chunk_size)
        ]
        
        for chunk in data_chunks:
            # Criar contexto para o chunk
            chunk_context = QualityExecutionContext(
                dataset_id=context.dataset_id,
                dataset_name=context.dataset_name,
                schema_definition=context.schema_definition,
                data_sample=chunk,
                execution_mode=ExecutionMode.SYNCHRONOUS,
                metadata=context.metadata
            )
            
            chunk_results = await self._execute_synchronous(rules, chunk_context)
            results.extend(chunk_results)
        
        # Agregar resultados por regra
        return self._aggregate_streaming_results(results)
    
    async def _execute_single_rule_with_timing(
        self,
        rule: QualityRule,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """Executa uma regra com medição de tempo"""
        start_time = datetime.utcnow()
        try:
            result = await self._execute_single_rule(rule, context)
            execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000
            result.execution_time_ms = execution_time
            return result
        except Exception as e:
            execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000
            error_result = self._create_error_result(rule, str(e), context)
            error_result.execution_time_ms = execution_time
            return error_result
    
    async def _execute_single_rule(
        self,
        rule: QualityRule,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """
        Executa uma única regra de qualidade
        
        Args:
            rule: Regra a ser executada
            context: Contexto de execução
            
        Returns:
            QualityCheckResult: Resultado da verificação
        """
        # Verificar se há executor para o tipo de regra
        executor = self._rule_executors.get(rule.rule_type)
        if not executor:
            raise ValueError(f"Executor não encontrado para tipo de regra: {rule.rule_type}")
        
        # Executar a regra
        return await executor(rule, context)
    
    async def _execute_completeness_rule(
        self,
        rule: QualityRule,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """Executa regra de completude"""
        config = rule.configuration
        field_name = config.get("field_name")
        threshold = config.get("threshold", 95.0)
        
        if not context.data_sample:
            # Simular verificação baseada no schema
            actual_completeness = 85.0  # Placeholder
        else:
            # Calcular completeness real
            total_records = len(context.data_sample)
            if total_records == 0:
                actual_completeness = 0.0
            else:
                non_null_records = sum(
                    1 for record in context.data_sample 
                    if record.get(field_name) is not None and record.get(field_name) != ""
                )
                actual_completeness = (non_null_records / total_records) * 100
        
        # Determinar resultado
        if actual_completeness >= threshold:
            result = ValidationResult.PASSED
            message = f"Completeness OK: {actual_completeness:.1f}% >= {threshold}%"
        else:
            result = ValidationResult.FAILED
            message = f"Completeness baixa: {actual_completeness:.1f}% < {threshold}%"
        
        return QualityCheckResult(
            rule_id=rule.id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            severity=rule.severity,
            result=result,
            score=actual_completeness,
            threshold=threshold,
            actual_value=actual_completeness,
            expected_value=threshold,
            message=message,
            details={
                "field_name": field_name,
                "total_records": len(context.data_sample) if context.data_sample else 0,
                "non_null_records": int((actual_completeness / 100) * len(context.data_sample)) if context.data_sample else 0
            },
            execution_time_ms=0.0,
            timestamp=datetime.utcnow(),
            dataset_id=context.dataset_id,
            field_name=field_name,
            record_count=len(context.data_sample) if context.data_sample else 0,
            violation_count=0 if result == ValidationResult.PASSED else 1
        )
    
    async def _execute_accuracy_rule(
        self,
        rule: QualityRule,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """Executa regra de acurácia"""
        config = rule.configuration
        field_name = config.get("field_name")
        accuracy_type = config.get("accuracy_type", "format")  # format, range, reference
        threshold = config.get("threshold", 95.0)
        
        if accuracy_type == "format":
            pattern = config.get("pattern")
            if pattern and context.data_sample:
                total_records = len(context.data_sample)
                valid_records = sum(
                    1 for record in context.data_sample
                    if record.get(field_name) and re.match(pattern, str(record.get(field_name)))
                )
                actual_accuracy = (valid_records / total_records) * 100 if total_records > 0 else 0
            else:
                actual_accuracy = 90.0  # Placeholder
        else:
            actual_accuracy = 88.0  # Placeholder para outros tipos
        
        result = ValidationResult.PASSED if actual_accuracy >= threshold else ValidationResult.FAILED
        message = f"Accuracy: {actual_accuracy:.1f}% ({'OK' if result == ValidationResult.PASSED else 'BAIXA'})"
        
        return QualityCheckResult(
            rule_id=rule.id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            severity=rule.severity,
            result=result,
            score=actual_accuracy,
            threshold=threshold,
            actual_value=actual_accuracy,
            expected_value=threshold,
            message=message,
            details={
                "field_name": field_name,
                "accuracy_type": accuracy_type,
                "pattern": config.get("pattern")
            },
            execution_time_ms=0.0,
            timestamp=datetime.utcnow(),
            dataset_id=context.dataset_id,
            field_name=field_name,
            record_count=len(context.data_sample) if context.data_sample else 0,
            violation_count=0 if result == ValidationResult.PASSED else 1
        )
    
    async def _execute_consistency_rule(
        self,
        rule: QualityRule,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """Executa regra de consistência"""
        config = rule.configuration
        fields = config.get("fields", [])
        consistency_type = config.get("consistency_type", "cross_field")
        threshold = config.get("threshold", 95.0)
        
        # Simular verificação de consistência
        actual_consistency = 92.0  # Placeholder
        
        result = ValidationResult.PASSED if actual_consistency >= threshold else ValidationResult.FAILED
        message = f"Consistency: {actual_consistency:.1f}% ({'OK' if result == ValidationResult.PASSED else 'INCONSISTENTE'})"
        
        return QualityCheckResult(
            rule_id=rule.id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            severity=rule.severity,
            result=result,
            score=actual_consistency,
            threshold=threshold,
            actual_value=actual_consistency,
            expected_value=threshold,
            message=message,
            details={
                "fields": fields,
                "consistency_type": consistency_type
            },
            execution_time_ms=0.0,
            timestamp=datetime.utcnow(),
            dataset_id=context.dataset_id,
            record_count=len(context.data_sample) if context.data_sample else 0,
            violation_count=0 if result == ValidationResult.PASSED else 1
        )
    
    async def _execute_validity_rule(
        self,
        rule: QualityRule,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """Executa regra de validade"""
        config = rule.configuration
        field_name = config.get("field_name")
        valid_values = config.get("valid_values", [])
        threshold = config.get("threshold", 100.0)
        
        if valid_values and context.data_sample:
            total_records = len(context.data_sample)
            valid_records = sum(
                1 for record in context.data_sample
                if record.get(field_name) in valid_values
            )
            actual_validity = (valid_records / total_records) * 100 if total_records > 0 else 0
        else:
            actual_validity = 95.0  # Placeholder
        
        result = ValidationResult.PASSED if actual_validity >= threshold else ValidationResult.FAILED
        message = f"Validity: {actual_validity:.1f}% ({'OK' if result == ValidationResult.PASSED else 'INVÁLIDA'})"
        
        return QualityCheckResult(
            rule_id=rule.id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            severity=rule.severity,
            result=result,
            score=actual_validity,
            threshold=threshold,
            actual_value=actual_validity,
            expected_value=threshold,
            message=message,
            details={
                "field_name": field_name,
                "valid_values": valid_values
            },
            execution_time_ms=0.0,
            timestamp=datetime.utcnow(),
            dataset_id=context.dataset_id,
            field_name=field_name,
            record_count=len(context.data_sample) if context.data_sample else 0,
            violation_count=0 if result == ValidationResult.PASSED else 1
        )
    
    async def _execute_uniqueness_rule(
        self,
        rule: QualityRule,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """Executa regra de unicidade"""
        config = rule.configuration
        field_name = config.get("field_name")
        threshold = config.get("threshold", 100.0)
        
        if context.data_sample:
            total_records = len(context.data_sample)
            field_values = [record.get(field_name) for record in context.data_sample if record.get(field_name)]
            unique_values = len(set(field_values))
            actual_uniqueness = (unique_values / len(field_values)) * 100 if field_values else 0
        else:
            actual_uniqueness = 98.0  # Placeholder
        
        result = ValidationResult.PASSED if actual_uniqueness >= threshold else ValidationResult.FAILED
        message = f"Uniqueness: {actual_uniqueness:.1f}% ({'OK' if result == ValidationResult.PASSED else 'DUPLICATAS'})"
        
        return QualityCheckResult(
            rule_id=rule.id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            severity=rule.severity,
            result=result,
            score=actual_uniqueness,
            threshold=threshold,
            actual_value=actual_uniqueness,
            expected_value=threshold,
            message=message,
            details={
                "field_name": field_name,
                "total_values": len(context.data_sample) if context.data_sample else 0,
                "unique_values": int((actual_uniqueness / 100) * len(context.data_sample)) if context.data_sample else 0
            },
            execution_time_ms=0.0,
            timestamp=datetime.utcnow(),
            dataset_id=context.dataset_id,
            field_name=field_name,
            record_count=len(context.data_sample) if context.data_sample else 0,
            violation_count=0 if result == ValidationResult.PASSED else 1
        )
    
    async def _execute_timeliness_rule(
        self,
        rule: QualityRule,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """Executa regra de pontualidade"""
        config = rule.configuration
        field_name = config.get("field_name")
        max_age_hours = config.get("max_age_hours", 24)
        threshold = config.get("threshold", 95.0)
        
        # Simular verificação de pontualidade
        actual_timeliness = 87.0  # Placeholder
        
        result = ValidationResult.PASSED if actual_timeliness >= threshold else ValidationResult.FAILED
        message = f"Timeliness: {actual_timeliness:.1f}% ({'OK' if result == ValidationResult.PASSED else 'ATRASADO'})"
        
        return QualityCheckResult(
            rule_id=rule.id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            severity=rule.severity,
            result=result,
            score=actual_timeliness,
            threshold=threshold,
            actual_value=actual_timeliness,
            expected_value=threshold,
            message=message,
            details={
                "field_name": field_name,
                "max_age_hours": max_age_hours
            },
            execution_time_ms=0.0,
            timestamp=datetime.utcnow(),
            dataset_id=context.dataset_id,
            field_name=field_name,
            record_count=len(context.data_sample) if context.data_sample else 0,
            violation_count=0 if result == ValidationResult.PASSED else 1
        )
    
    async def _execute_conformity_rule(
        self,
        rule: QualityRule,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """Executa regra de conformidade"""
        config = rule.configuration
        standard = config.get("standard")
        threshold = config.get("threshold", 100.0)
        
        # Simular verificação de conformidade
        actual_conformity = 94.0  # Placeholder
        
        result = ValidationResult.PASSED if actual_conformity >= threshold else ValidationResult.FAILED
        message = f"Conformity ({standard}): {actual_conformity:.1f}% ({'OK' if result == ValidationResult.PASSED else 'NÃO CONFORME'})"
        
        return QualityCheckResult(
            rule_id=rule.id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            severity=rule.severity,
            result=result,
            score=actual_conformity,
            threshold=threshold,
            actual_value=actual_conformity,
            expected_value=threshold,
            message=message,
            details={
                "standard": standard
            },
            execution_time_ms=0.0,
            timestamp=datetime.utcnow(),
            dataset_id=context.dataset_id,
            record_count=len(context.data_sample) if context.data_sample else 0,
            violation_count=0 if result == ValidationResult.PASSED else 1
        )
    
    async def _execute_integrity_rule(
        self,
        rule: QualityRule,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """Executa regra de integridade"""
        config = rule.configuration
        integrity_type = config.get("integrity_type", "referential")
        threshold = config.get("threshold", 100.0)
        
        # Simular verificação de integridade
        actual_integrity = 96.0  # Placeholder
        
        result = ValidationResult.PASSED if actual_integrity >= threshold else ValidationResult.FAILED
        message = f"Integrity ({integrity_type}): {actual_integrity:.1f}% ({'OK' if result == ValidationResult.PASSED else 'VIOLAÇÃO'})"
        
        return QualityCheckResult(
            rule_id=rule.id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            severity=rule.severity,
            result=result,
            score=actual_integrity,
            threshold=threshold,
            actual_value=actual_integrity,
            expected_value=threshold,
            message=message,
            details={
                "integrity_type": integrity_type
            },
            execution_time_ms=0.0,
            timestamp=datetime.utcnow(),
            dataset_id=context.dataset_id,
            record_count=len(context.data_sample) if context.data_sample else 0,
            violation_count=0 if result == ValidationResult.PASSED else 1
        )
    
    async def _execute_custom_rule(
        self,
        rule: QualityRule,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """Executa regra customizada"""
        config = rule.configuration
        custom_logic = config.get("custom_logic")
        threshold = config.get("threshold", 95.0)
        
        # Para regras customizadas, seria necessário um interpretador
        # Por enquanto, simular execução
        actual_score = 89.0  # Placeholder
        
        result = ValidationResult.PASSED if actual_score >= threshold else ValidationResult.FAILED
        message = f"Custom Rule: {actual_score:.1f}% ({'OK' if result == ValidationResult.PASSED else 'FALHOU'})"
        
        return QualityCheckResult(
            rule_id=rule.id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            severity=rule.severity,
            result=result,
            score=actual_score,
            threshold=threshold,
            actual_value=actual_score,
            expected_value=threshold,
            message=message,
            details={
                "custom_logic": custom_logic
            },
            execution_time_ms=0.0,
            timestamp=datetime.utcnow(),
            dataset_id=context.dataset_id,
            record_count=len(context.data_sample) if context.data_sample else 0,
            violation_count=0 if result == ValidationResult.PASSED else 1
        )
    
    def _create_error_result(
        self,
        rule: QualityRule,
        error_message: str,
        context: QualityExecutionContext
    ) -> QualityCheckResult:
        """Cria resultado de erro"""
        return QualityCheckResult(
            rule_id=rule.id,
            rule_name=rule.name,
            rule_type=rule.rule_type,
            severity=rule.severity,
            result=ValidationResult.ERROR,
            score=0.0,
            threshold=0.0,
            actual_value=None,
            expected_value=None,
            message=f"Erro na execução: {error_message}",
            details={"error": error_message},
            execution_time_ms=0.0,
            timestamp=datetime.utcnow(),
            dataset_id=context.dataset_id
        )
    
    def _aggregate_streaming_results(
        self,
        results: List[QualityCheckResult]
    ) -> List[QualityCheckResult]:
        """Agrega resultados de execução streaming"""
        # Agrupar por rule_id
        grouped_results = {}
        for result in results:
            rule_id = result.rule_id
            if rule_id not in grouped_results:
                grouped_results[rule_id] = []
            grouped_results[rule_id].append(result)
        
        # Agregar resultados por regra
        aggregated = []
        for rule_id, rule_results in grouped_results.items():
            if not rule_results:
                continue
            
            # Usar o primeiro resultado como base
            base_result = rule_results[0]
            
            # Calcular métricas agregadas
            total_score = sum(r.score for r in rule_results)
            avg_score = total_score / len(rule_results)
            
            total_records = sum(r.record_count for r in rule_results)
            total_violations = sum(r.violation_count for r in rule_results)
            
            # Determinar resultado final
            failed_count = sum(1 for r in rule_results if r.result == ValidationResult.FAILED)
            final_result = ValidationResult.FAILED if failed_count > 0 else ValidationResult.PASSED
            
            # Criar resultado agregado
            aggregated_result = QualityCheckResult(
                rule_id=base_result.rule_id,
                rule_name=base_result.rule_name,
                rule_type=base_result.rule_type,
                severity=base_result.severity,
                result=final_result,
                score=avg_score,
                threshold=base_result.threshold,
                actual_value=avg_score,
                expected_value=base_result.expected_value,
                message=f"Resultado agregado: {avg_score:.1f}% (streaming)",
                details={
                    "aggregated": True,
                    "chunk_count": len(rule_results),
                    "failed_chunks": failed_count
                },
                execution_time_ms=sum(r.execution_time_ms for r in rule_results),
                timestamp=datetime.utcnow(),
                dataset_id=base_result.dataset_id,
                field_name=base_result.field_name,
                record_count=total_records,
                violation_count=total_violations
            )
            
            aggregated.append(aggregated_result)
        
        return aggregated
    
    def _cache_results(
        self,
        results: List[QualityCheckResult],
        context: QualityExecutionContext
    ):
        """Cache dos resultados de execução"""
        cache_key = f"{context.dataset_id}_{datetime.utcnow().strftime('%Y%m%d_%H')}"
        self._execution_cache[cache_key] = {
            "results": results,
            "timestamp": datetime.utcnow(),
            "context": context
        }
        
        # Limpar cache antigo (manter apenas últimas 24 horas)
        cutoff_time = datetime.utcnow() - timedelta(hours=24)
        keys_to_remove = [
            key for key, value in self._execution_cache.items()
            if value["timestamp"] < cutoff_time
        ]
        for key in keys_to_remove:
            del self._execution_cache[key]
    
    def calculate_overall_quality_score(
        self,
        results: List[QualityCheckResult]
    ) -> float:
        """
        Calcula score geral de qualidade
        
        Args:
            results: Resultados das verificações
            
        Returns:
            float: Score de 0 a 100
        """
        if not results:
            return 0.0
        
        # Calcular score ponderado por severidade
        total_weight = 0
        weighted_score = 0
        
        severity_weights = {
            RuleSeverity.CRITICAL: 4.0,
            RuleSeverity.HIGH: 3.0,
            RuleSeverity.MEDIUM: 2.0,
            RuleSeverity.LOW: 1.0,
            RuleSeverity.INFO: 0.5
        }
        
        for result in results:
            weight = severity_weights.get(result.severity, 1.0)
            total_weight += weight
            
            # Score baseado no resultado
            if result.result == ValidationResult.PASSED:
                weighted_score += result.score * weight
            elif result.result == ValidationResult.WARNING:
                weighted_score += result.score * weight * 0.8
            elif result.result == ValidationResult.FAILED:
                weighted_score += result.score * weight * 0.5
            # ERROR e SKIPPED não contribuem para o score
        
        return weighted_score / total_weight if total_weight > 0 else 0.0
    
    def generate_quality_report(
        self,
        results: List[QualityCheckResult],
        context: QualityExecutionContext
    ) -> Dict[str, Any]:
        """
        Gera relatório de qualidade
        
        Args:
            results: Resultados das verificações
            context: Contexto de execução
            
        Returns:
            Dict: Relatório de qualidade
        """
        overall_score = self.calculate_overall_quality_score(results)
        
        # Estatísticas por resultado
        result_stats = {
            "passed": len([r for r in results if r.result == ValidationResult.PASSED]),
            "failed": len([r for r in results if r.result == ValidationResult.FAILED]),
            "warning": len([r for r in results if r.result == ValidationResult.WARNING]),
            "error": len([r for r in results if r.result == ValidationResult.ERROR]),
            "skipped": len([r for r in results if r.result == ValidationResult.SKIPPED])
        }
        
        # Estatísticas por tipo de regra
        rule_type_stats = {}
        for rule_type in RuleType:
            type_results = [r for r in results if r.rule_type == rule_type]
            if type_results:
                rule_type_stats[rule_type.value] = {
                    "count": len(type_results),
                    "avg_score": sum(r.score for r in type_results) / len(type_results),
                    "passed": len([r for r in type_results if r.result == ValidationResult.PASSED])
                }
        
        # Violações críticas
        critical_violations = [
            r for r in results 
            if r.severity == RuleSeverity.CRITICAL and r.result == ValidationResult.FAILED
        ]
        
        # Recomendações
        recommendations = self._generate_recommendations(results)
        
        return {
            "dataset_id": str(context.dataset_id),
            "dataset_name": context.dataset_name,
            "execution_timestamp": datetime.utcnow().isoformat(),
            "execution_mode": context.execution_mode.value,
            "overall_quality_score": overall_score,
            "total_rules_executed": len(results),
            "result_statistics": result_stats,
            "rule_type_statistics": rule_type_stats,
            "critical_violations": [v.to_dict() for v in critical_violations],
            "recommendations": recommendations,
            "execution_summary": {
                "total_execution_time_ms": sum(r.execution_time_ms for r in results),
                "avg_execution_time_ms": sum(r.execution_time_ms for r in results) / len(results) if results else 0,
                "total_records_processed": sum(r.record_count for r in results),
                "total_violations_detected": sum(r.violation_count for r in results)
            }
        }
    
    def _generate_recommendations(
        self,
        results: List[QualityCheckResult]
    ) -> List[str]:
        """Gera recomendações baseadas nos resultados"""
        recommendations = []
        
        # Verificar regras falhadas
        failed_results = [r for r in results if r.result == ValidationResult.FAILED]
        
        if failed_results:
            critical_failed = [r for r in failed_results if r.severity == RuleSeverity.CRITICAL]
            if critical_failed:
                recommendations.append(f"URGENTE: {len(critical_failed)} regra(s) crítica(s) falharam. Ação imediata necessária.")
            
            completeness_failed = [r for r in failed_results if r.rule_type == RuleType.COMPLETENESS]
            if completeness_failed:
                recommendations.append("Melhorar processos de coleta de dados para reduzir valores nulos.")
            
            accuracy_failed = [r for r in failed_results if r.rule_type == RuleType.ACCURACY]
            if accuracy_failed:
                recommendations.append("Implementar validações de entrada mais rigorosas.")
            
            uniqueness_failed = [r for r in failed_results if r.rule_type == RuleType.UNIQUENESS]
            if uniqueness_failed:
                recommendations.append("Revisar processos de deduplicação de dados.")
        
        # Verificar performance
        slow_rules = [r for r in results if r.execution_time_ms > 5000]  # > 5 segundos
        if slow_rules:
            recommendations.append(f"{len(slow_rules)} regra(s) com execução lenta. Considere otimização.")
        
        return recommendations

