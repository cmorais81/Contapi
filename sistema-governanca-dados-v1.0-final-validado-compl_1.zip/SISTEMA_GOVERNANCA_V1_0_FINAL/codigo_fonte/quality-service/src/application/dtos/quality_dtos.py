# Autor: carlos.morais@f1rst.com.br
"""
Quality DTOs for Quality Service
Data Transfer Objects for data quality management operations
"""

from datetime import datetime
from typing import List, Optional, Dict, Any, Union
from uuid import UUID
from pydantic import BaseModel, Field, validator
from enum import Enum


class QualityRuleType(str, Enum):
    """Quality rule types"""
    COMPLETENESS = "completeness"
    UNIQUENESS = "uniqueness"
    VALIDITY = "validity"
    CONSISTENCY = "consistency"
    ACCURACY = "accuracy"
    TIMELINESS = "timeliness"
    INTEGRITY = "integrity"
    CONFORMITY = "conformity"
    CUSTOM = "custom"


class QualityRuleStatus(str, Enum):
    """Quality rule status"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    DRAFT = "draft"
    DEPRECATED = "deprecated"


class ExecutionStatus(str, Enum):
    """Execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FLED = "failed"
    CANCELLED = "cancelled"


class Severity(str, Enum):
    """Quality issue severity"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ValidationEngine(str, Enum):
    """Validation engine types"""
    SQL = "sql"
    PYTHON = "python"
    SPARK = "spark"
    GREAT_EXPECTATIONS = "great_expectations"
    CUSTOM = "custom"


# Request DTOs
class CreateQualityRuleRequest(BaseModel):
    """Request to create a new quality rule"""
    name: str = Field(..., min_length=2, max_length=200, description="Rule name")
    description: Optional[str] = Field(None, max_length=1000, description="Rule description")
    rule_type: QualityRuleType = Field(..., description="Type of quality rule")
    dataset_id: UUID = Field(..., description="Target dataset ID")
    field_name: Optional[str] = Field(None, max_length=100, description="Target field name")
    validation_logic: str = Field(..., description="Validation logic (SQL, Python, etc.)")
    validation_engine: ValidationEngine = Field(..., description="Validation engine")
    threshold_value: Optional[float] = Field(None, ge=0, le=100, description="Threshold percentage")
    severity: Severity = Field(..., description="Issue severity")
    is_blocking: bool = Field(False, description="Whether failures block data processing")
    schedule_cron: Optional[str] = Field(None, description="Cron expression for scheduling")
    tags: List[str] = Field(default_factory=list, description="Rule tags")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    
    @validator('validation_logic')
    def validate_logic(cls, v):
        """Validate logic is not empty"""
        if not v.strip():
            raise ValueError('Validation logic cannot be empty')
        return v.strip()
    
    @validator('schedule_cron')
    def validate_cron(cls, v):
        """Basic cron validation"""
        if v and len(v.split()) not in [5, 6]:
            raise ValueError('Invalid cron expression format')
        return v


class UpdateQualityRuleRequest(BaseModel):
    """Request to update quality rule"""
    name: Optional[str] = Field(None, min_length=2, max_length=200)
    description: Optional[str] = Field(None, max_length=1000)
    validation_logic: Optional[str] = None
    threshold_value: Optional[float] = Field(None, ge=0, le=100)
    severity: Optional[Severity] = None
    is_blocking: Optional[bool] = None
    schedule_cron: Optional[str] = None
    status: Optional[QualityRuleStatus] = None
    tags: Optional[List[str]] = None
    metadata: Optional[Dict[str, Any]] = None


class ExecuteQualityRuleRequest(BaseModel):
    """Request to execute quality rule"""
    rule_id: UUID = Field(..., description="Quality rule ID")
    dataset_version: Optional[str] = Field(None, description="Specific dataset version")
    execution_context: Dict[str, Any] = Field(default_factory=dict, description="Execution context")
    notify_on_failure: bool = Field(True, description="Send notifications on failure")


class BulkExecuteQualityRulesRequest(BaseModel):
    """Request to execute multiple quality rules"""
    rule_ids: List[UUID] = Field(..., max_items=100, description="Quality rule IDs")
    dataset_id: Optional[UUID] = Field(None, description="Filter by dataset")
    execution_context: Dict[str, Any] = Field(default_factory=dict)
    notify_on_failure: bool = Field(True)


class QualityRuleSearchRequest(BaseModel):
    """Request to search quality rules"""
    search_term: str = Field(..., min_length=2, description="Search term")
    dataset_id: Optional[UUID] = None
    rule_type: Optional[QualityRuleType] = None
    status: Optional[QualityRuleStatus] = None
    severity: Optional[Severity] = None
    limit: int = Field(100, ge=1, le=1000)
    offset: int = Field(0, ge=0)


# Response DTOs
class QualityRuleResponse(BaseModel):
    """Quality rule information response"""
    id: UUID
    name: str
    description: Optional[str] = None
    rule_type: QualityRuleType
    status: QualityRuleStatus
    dataset_id: UUID
    dataset_name: Optional[str] = None
    field_name: Optional[str] = None
    validation_logic: str
    validation_engine: ValidationEngine
    threshold_value: Optional[float] = None
    severity: Severity
    is_blocking: bool
    schedule_cron: Optional[str] = None
    tags: List[str]
    metadata: Dict[str, Any]
    created_by: UUID
    created_by_name: Optional[str] = None
    last_execution_at: Optional[datetime] = None
    last_execution_status: Optional[ExecutionStatus] = None
    last_execution_score: Optional[float] = None
    execution_count: int = 0
    failure_count: int = 0
    created_at: datetime
    updated_at: datetime
    
    class Config:
        use_enum_values = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class QualityRuleListResponse(BaseModel):
    """List of quality rules response"""
    rules: List[QualityRuleResponse]
    total: int
    limit: int
    offset: int
    has_more: bool


class QualityRuleExecutionResponse(BaseModel):
    """Quality rule execution result"""
    id: UUID
    rule_id: UUID
    rule_name: str
    dataset_id: UUID
    dataset_name: Optional[str] = None
    execution_status: ExecutionStatus
    quality_score: Optional[float] = None  # 0-100
    records_processed: Optional[int] = None
    records_passed: Optional[int] = None
    records_failed: Optional[int] = None
    execution_time_ms: Optional[int] = None
    error_message: Optional[str] = None
    execution_details: Dict[str, Any] = Field(default_factory=dict)
    started_at: datetime
    completed_at: Optional[datetime] = None
    created_by: UUID
    
    class Config:
        use_enum_values = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class QualityRuleExecutionListResponse(BaseModel):
    """List of quality rule executions"""
    executions: List[QualityRuleExecutionResponse]
    total: int
    limit: int
    offset: int


class QualityMetricResponse(BaseModel):
    """Quality metric response"""
    id: UUID
    dataset_id: UUID
    dataset_name: Optional[str] = None
    metric_name: str
    metric_value: float
    metric_type: str
    dimension: Optional[str] = None  # completeness, accuracy, etc.
    field_name: Optional[str] = None
    measurement_date: datetime
    created_at: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class QualityMetricListResponse(BaseModel):
    """List of quality metrics"""
    metrics: List[QualityMetricResponse]
    total: int
    limit: int
    offset: int


class DatasetQualityOverviewResponse(BaseModel):
    """Dataset quality overview"""
    dataset_id: UUID
    dataset_name: str
    overall_quality_score: float  # 0-100
    total_rules: int
    active_rules: int
    passing_rules: int
    failing_rules: int
    last_assessment_date: Optional[datetime] = None
    quality_dimensions: Dict[str, float]  # dimension -> score
    trend: str  # "improving", "stable", "declining"
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class QualityDashboardResponse(BaseModel):
    """Quality dashboard data"""
    organization_id: UUID
    total_datasets: int
    datasets_with_rules: int
    total_quality_rules: int
    active_quality_rules: int
    recent_executions: int  # last 24h
    average_quality_score: float
    quality_score_distribution: Dict[str, int]  # score_range -> count
    top_failing_rules: List[Dict[str, Any]]
    quality_trends: Dict[str, List[float]]  # dimension -> [scores over time]
    
    class Config:
        json_encoders = {
            UUID: lambda v: str(v)
        }


# Template DTOs
class QualityRuleTemplateResponse(BaseModel):
    """Quality rule template"""
    id: UUID
    name: str
    description: str
    rule_type: QualityRuleType
    validation_logic_template: str
    validation_engine: ValidationEngine
    default_threshold: Optional[float] = None
    default_severity: Severity
    parameters: List[Dict[str, Any]]  # template parameters
    usage_count: int = 0
    created_at: datetime
    
    class Config:
        use_enum_values = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class CreateRuleFromTemplateRequest(BaseModel):
    """Request to create rule from template"""
    template_id: UUID
    name: str = Field(..., min_length=2, max_length=200)
    dataset_id: UUID
    field_name: Optional[str] = None
    parameter_values: Dict[str, Any] = Field(default_factory=dict)
    threshold_value: Optional[float] = None
    severity: Optional[Severity] = None
    schedule_cron: Optional[str] = None


# Validation DTOs
class ValidationResultResponse(BaseModel):
    """Validation result details"""
    rule_id: UUID
    rule_name: str
    field_name: Optional[str] = None
    validation_passed: bool
    quality_score: float
    total_records: int
    valid_records: int
    invalid_records: int
    null_records: int
    validation_errors: List[Dict[str, Any]]
    sample_invalid_values: List[Any]
    execution_time_ms: int
    
    class Config:
        json_encoders = {
            UUID: lambda v: str(v)
        }


# Alert DTOs
class QualityAlertResponse(BaseModel):
    """Quality alert response"""
    id: UUID
    rule_id: UUID
    rule_name: str
    dataset_id: UUID
    dataset_name: str
    alert_type: str  # "threshold_breach", "execution_failure", etc.
    severity: Severity
    message: str
    quality_score: Optional[float] = None
    threshold_value: Optional[float] = None
    is_resolved: bool = False
    resolved_at: Optional[datetime] = None
    resolved_by: Optional[UUID] = None
    created_at: datetime
    
    class Config:
        use_enum_values = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class QualityAlertListResponse(BaseModel):
    """List of quality alerts"""
    alerts: List[QualityAlertResponse]
    total: int
    unresolved_count: int
    critical_count: int
    limit: int
    offset: int


# Statistics DTOs
class QualityStatisticsResponse(BaseModel):
    """Quality statistics response"""
    organization_id: UUID
    dataset_id: Optional[UUID] = None
    time_period: str  # "24h", "7d", "30d"
    total_executions: int
    successful_executions: int
    failed_executions: int
    average_quality_score: float
    quality_score_trend: List[float]
    execution_frequency: Dict[str, int]  # hour/day -> count
    most_failing_rules: List[Dict[str, Any]]
    quality_improvement: float  # percentage change
    
    class Config:
        json_encoders = {
            UUID: lambda v: str(v)
        }


# Batch Operations DTOs
class BulkQualityRuleOperationRequest(BaseModel):
    """Request for bulk operations on quality rules"""
    rule_ids: List[UUID] = Field(..., max_items=100)
    operation: str = Field(..., description="Operation: activate, deactivate, delete")
    parameters: Dict[str, Any] = Field(default_factory=dict)


class BulkQualityRuleOperationResponse(BaseModel):
    """Response for bulk operations"""
    successful: List[UUID]
    failed: List[Dict[str, Any]]  # {"rule_id": UUID, "error": str}
    total_processed: int
    success_count: int
    failure_count: int


# Filter DTOs
class QualityRuleFilterRequest(BaseModel):
    """Request to filter quality rules"""
    dataset_id: Optional[UUID] = None
    rule_type: Optional[QualityRuleType] = None
    status: Optional[QualityRuleStatus] = None
    severity: Optional[Severity] = None
    validation_engine: Optional[ValidationEngine] = None
    created_by: Optional[UUID] = None
    created_after: Optional[datetime] = None
    created_before: Optional[datetime] = None
    last_execution_after: Optional[datetime] = None
    last_execution_before: Optional[datetime] = None
    has_failures: Optional[bool] = None
    is_blocking: Optional[bool] = None
    tags: Optional[List[str]] = None
    limit: int = Field(100, ge=1, le=1000)
    offset: int = Field(0, ge=0)
    sort_by: str = Field("created_at", description="Sort field")
    sort_order: str = Field("desc", description="Sort order: asc, desc")


# Execution History DTOs
class QualityExecutionHistoryRequest(BaseModel):
    """Request for execution history"""
    rule_id: Optional[UUID] = None
    dataset_id: Optional[UUID] = None
    status: Optional[ExecutionStatus] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    limit: int = Field(100, ge=1, le=1000)
    offset: int = Field(0, ge=0)


# Notification DTOs
class QualityNotificationRequest(BaseModel):
    """Request to configure quality notifications"""
    rule_id: UUID
    notification_type: str = Field(..., description="email, slack, webhook")
    recipients: List[str] = Field(..., description="Email addresses, Slack channels, etc.")
    conditions: Dict[str, Any] = Field(default_factory=dict, description="Notification conditions")
    is_enabled: bool = Field(True)


class QualityNotificationResponse(BaseModel):
    """Quality notification configuration"""
    id: UUID
    rule_id: UUID
    rule_name: str
    notification_type: str
    recipients: List[str]
    conditions: Dict[str, Any]
    is_enabled: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


# Data Profiling DTOs
class DataProfilingRequest(BaseModel):
    """Request for data profiling"""
    dataset_id: UUID
    fields: Optional[List[str]] = None  # If None, profile all fields
    sample_size: Optional[int] = Field(None, ge=1000, le=1000000)
    include_patterns: bool = Field(True)
    include_distributions: bool = Field(True)


class DataProfilingResponse(BaseModel):
    """Data profiling results"""
    dataset_id: UUID
    dataset_name: str
    total_records: int
    profiled_fields: List[Dict[str, Any]]
    data_quality_issues: List[Dict[str, Any]]
    suggested_rules: List[Dict[str, Any]]
    profiling_date: datetime
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }

