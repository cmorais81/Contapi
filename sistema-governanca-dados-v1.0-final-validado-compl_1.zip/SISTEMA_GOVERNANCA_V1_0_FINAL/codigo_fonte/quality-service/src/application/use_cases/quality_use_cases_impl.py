# Autor: carlos.morais@f1rst.com.br
"""
Quality Use Cases Implementation
Business logic for data quality management operations
"""

import asyncio
import json
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from uuid import UUID, uuid4

from ...domain.entities.quality_rule import QualityRule as QualityRuleEntity
from ...domain.repositories.quality_repository import QualityRepository
from ...domain.value_objects.quality_rule_type import QualityRuleType
from ...domain.value_objects.quality_rule_status import QualityRuleStatus
from ...domain.value_objects.execution_status import ExecutionStatus
from ...domain.value_objects.severity import Severity
from ...domain.value_objects.validation_engine import ValidationEngine
from ...domain.services.quality_validation_service import QualityValidationService
from ...domain.services.quality_execution_service import QualityExecutionService
from ..dtos.quality_dtos import (
    CreateQualityRuleRequest, UpdateQualityRuleRequest, ExecuteQualityRuleRequest,
    BulkExecuteQualityRulesRequest, QualityRuleSearchRequest, QualityRuleFilterRequest,
    QualityRuleResponse, QualityRuleListResponse, QualityRuleExecutionResponse,
    QualityRuleExecutionListResponse, QualityMetricResponse, QualityMetricListResponse,
    DatasetQualityOverviewResponse, QualityDashboardResponse, QualityStatisticsResponse,
    ValidationResultResponse, QualityAlertResponse, QualityAlertListResponse,
    BulkQualityRuleOperationRequest, BulkQualityRuleOperationResponse,
    DataProfilingRequest, DataProfilingResponse, QualityRuleTemplateResponse,
    CreateRuleFromTemplateRequest, QualityNotificationRequest, QualityNotificationResponse
)


class QualityUseCasesImpl:
    """Implementation of quality use cases"""
    
    def __init__(self, quality_repository: QualityRepository):
        self.quality_repository = quality_repository
        self.validation_service = QualityValidationService()
        self.execution_service = QualityExecutionService()
    
    async def create_quality_rule(self, request: CreateQualityRuleRequest) -> QualityRuleResponse:
        """Create a new quality rule"""
        try:
            # Check if rule name already exists for dataset
            if self.quality_repository.exists_by_name(request.name, request.dataset_id):
                raise ValueError("Rule name already exists for this dataset")
            
            # Validate the validation logic
            validation_result = await self.validation_service.validate_logic(
                request.validation_logic,
                request.validation_engine
            )
            if not validation_result.is_valid:
                raise ValueError(f"Invalid validation logic: {validation_result.error_message}")
            
            # Create quality rule entity
            quality_rule = QualityRuleEntity(
                id=uuid4(),
                name=request.name,
                description=request.description,
                rule_type=QualityRuleType(request.rule_type.value),
                status=QualityRuleStatus.DRAFT,
                dataset_id=request.dataset_id,
                field_name=request.field_name,
                validation_logic=request.validation_logic,
                validation_engine=ValidationEngine(request.validation_engine.value),
                threshold_value=request.threshold_value,
                severity=Severity(request.severity.value),
                is_blocking=request.is_blocking,
                schedule_cron=request.schedule_cron,
                tags=request.tags,
                metadata=request.metadata,
                created_by=uuid4(),  # Should come from authenticated user
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow()
            )
            
            # Save quality rule
            saved_rule = self.quality_repository.save(quality_rule)
            
            # Convert to response DTO
            return self._entity_to_response(saved_rule)
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to create quality rule: {str(e)}")
    
    async def get_quality_rule(self, rule_id: UUID) -> Optional[QualityRuleResponse]:
        """Get quality rule by ID"""
        try:
            rule = self.quality_repository.find_by_id(rule_id)
            if not rule:
                return None
            
            return self._entity_to_response(rule)
            
        except Exception as e:
            raise RuntimeError(f"Failed to get quality rule: {str(e)}")
    
    async def update_quality_rule(self, rule_id: UUID, request: UpdateQualityRuleRequest) -> Optional[QualityRuleResponse]:
        """Update quality rule"""
        try:
            rule = self.quality_repository.find_by_id(rule_id)
            if not rule:
                return None
            
            # Update fields
            if request.name is not None:
                # Check if new name conflicts
                if (request.name != rule.name and 
                    self.quality_repository.exists_by_name(request.name, rule.dataset_id, rule.id)):
                    raise ValueError("Rule name already exists for this dataset")
                rule.name = request.name
            
            if request.description is not None:
                rule.description = request.description
            
            if request.validation_logic is not None:
                # Validate new logic
                validation_result = await self.validation_service.validate_logic(
                    request.validation_logic,
                    rule.validation_engine
                )
                if not validation_result.is_valid:
                    raise ValueError(f"Invalid validation logic: {validation_result.error_message}")
                rule.validation_logic = request.validation_logic
            
            if request.threshold_value is not None:
                rule.threshold_value = request.threshold_value
            
            if request.severity is not None:
                rule.severity = Severity(request.severity.value)
            
            if request.is_blocking is not None:
                rule.is_blocking = request.is_blocking
            
            if request.schedule_cron is not None:
                rule.schedule_cron = request.schedule_cron
            
            if request.status is not None:
                rule.status = QualityRuleStatus(request.status.value)
            
            if request.tags is not None:
                rule.tags = request.tags
            
            if request.metadata is not None:
                rule.metadata = request.metadata
            
            rule.updated_at = datetime.utcnow()
            
            # Save updated rule
            updated_rule = self.quality_repository.save(rule)
            
            return self._entity_to_response(updated_rule)
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to update quality rule: {str(e)}")
    
    async def delete_quality_rule(self, rule_id: UUID) -> bool:
        """Delete quality rule"""
        try:
            return self.quality_repository.delete(rule_id)
        except Exception as e:
            raise RuntimeError(f"Failed to delete quality rule: {str(e)}")
    
    async def list_quality_rules(self, dataset_id: Optional[UUID] = None,
                                rule_type: Optional[str] = None,
                                status: Optional[str] = None,
                                limit: int = 100, offset: int = 0) -> QualityRuleListResponse:
        """List quality rules with filters"""
        try:
            filters = {}
            if dataset_id:
                filters['dataset_id'] = dataset_id
            if rule_type:
                filters['rule_type'] = rule_type
            if status:
                filters['status'] = status
            
            rules = self.quality_repository.find_with_filters(filters, limit, offset)
            
            # Get total count (simplified)
            total = len(rules)
            
            return QualityRuleListResponse(
                rules=[self._entity_to_response(rule) for rule in rules],
                total=total,
                limit=limit,
                offset=offset,
                has_more=total > offset + limit
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to list quality rules: {str(e)}")
    
    async def search_quality_rules(self, request: QualityRuleSearchRequest) -> QualityRuleListResponse:
        """Search quality rules by text"""
        try:
            rules = self.quality_repository.search_rules(
                request.search_term,
                request.dataset_id,
                request.limit,
                request.offset
            )
            
            total = len(rules)
            
            return QualityRuleListResponse(
                rules=[self._entity_to_response(rule) for rule in rules],
                total=total,
                limit=request.limit,
                offset=request.offset,
                has_more=total > request.offset + request.limit
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to search quality rules: {str(e)}")
    
    async def execute_quality_rule(self, request: ExecuteQualityRuleRequest) -> QualityRuleExecutionResponse:
        """Execute a quality rule"""
        try:
            rule = self.quality_repository.find_by_id(request.rule_id)
            if not rule:
                raise ValueError("Quality rule not found")
            
            if rule.status != QualityRuleStatus.ACTIVE:
                raise ValueError("Quality rule is not active")
            
            # Execute the rule
            execution_result = await self.execution_service.execute_rule(
                rule,
                request.dataset_version,
                request.execution_context
            )
            
            # Create execution response
            return QualityRuleExecutionResponse(
                id=execution_result.execution_id,
                rule_id=rule.id,
                rule_name=rule.name,
                dataset_id=rule.dataset_id,
                dataset_name=rule.dataset_name,
                execution_status=ExecutionStatus(execution_result.status),
                quality_score=execution_result.quality_score,
                records_processed=execution_result.records_processed,
                records_passed=execution_result.records_passed,
                records_failed=execution_result.records_failed,
                execution_time_ms=execution_result.execution_time_ms,
                error_message=execution_result.error_message,
                execution_details=execution_result.details,
                started_at=execution_result.started_at,
                completed_at=execution_result.completed_at,
                created_by=uuid4()  # Should come from authenticated user
            )
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to execute quality rule: {str(e)}")
    
    async def bulk_execute_quality_rules(self, request: BulkExecuteQualityRulesRequest) -> List[QualityRuleExecutionResponse]:
        """Execute multiple quality rules"""
        try:
            results = []
            
            for rule_id in request.rule_ids:
                try:
                    execution_request = ExecuteQualityRuleRequest(
                        rule_id=rule_id,
                        execution_context=request.execution_context,
                        notify_on_failure=request.notify_on_failure
                    )
                    
                    result = await self.execute_quality_rule(execution_request)
                    results.append(result)
                    
                except Exception as e:
                    # Create failed execution response
                    results.append(QualityRuleExecutionResponse(
                        id=uuid4(),
                        rule_id=rule_id,
                        rule_name="Unknown",
                        dataset_id=request.dataset_id or uuid4(),
                        execution_status=ExecutionStatus.FLED,
                        error_message=str(e),
                        started_at=datetime.utcnow(),
                        created_by=uuid4()
                    ))
            
            return results
            
        except Exception as e:
            raise RuntimeError(f"Failed to bulk execute quality rules: {str(e)}")
    
    async def get_dataset_quality_overview(self, dataset_id: UUID) -> DatasetQualityOverviewResponse:
        """Get quality overview for a dataset"""
        try:
            overview = self.quality_repository.get_dataset_quality_overview(dataset_id)
            
            # Calculate quality dimensions (simplified)
            quality_dimensions = {
                "completeness": overview.get('overall_quality_score', 0) * 0.9,
                "accuracy": overview.get('overall_quality_score', 0) * 0.95,
                "consistency": overview.get('overall_quality_score', 0) * 0.85,
                "validity": overview.get('overall_quality_score', 0) * 0.92
            }
            
            # Determine trend (simplified)
            trend = "stable"
            if overview.get('overall_quality_score', 0) > 85:
                trend = "improving"
            elif overview.get('overall_quality_score', 0) < 70:
                trend = "declining"
            
            return DatasetQualityOverviewResponse(
                dataset_id=dataset_id,
                dataset_name=overview.get('dataset_name', 'Unknown'),
                overall_quality_score=overview.get('overall_quality_score', 0),
                total_rules=overview.get('total_rules', 0),
                active_rules=overview.get('active_rules', 0),
                passing_rules=overview.get('passing_rules', 0),
                failing_rules=overview.get('failing_rules', 0),
                last_assessment_date=overview.get('last_assessment_date'),
                quality_dimensions=quality_dimensions,
                trend=trend
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to get dataset quality overview: {str(e)}")
    
    async def get_quality_dashboard(self, organization_id: UUID) -> QualityDashboardResponse:
        """Get quality dashboard data"""
        try:
            # Get statistics (simplified implementation)
            total_datasets = 10  # Should query actual data
            datasets_with_rules = 8
            total_quality_rules = 45
            active_quality_rules = 38
            recent_executions = 156
            average_quality_score = 87.5
            
            quality_score_distribution = {
                "90-100": 15,
                "80-89": 18,
                "70-79": 8,
                "60-69": 3,
                "0-59": 1
            }
            
            top_failing_rules = [
                {"rule_name": "Email Format Validation", "failure_rate": 15.2, "dataset": "Customer Data"},
                {"rule_name": "Phone Number Completeness", "failure_rate": 12.8, "dataset": "Contact Info"},
                {"rule_name": "Date Range Validation", "failure_rate": 8.5, "dataset": "Transaction Data"}
            ]
            
            quality_trends = {
                "completeness": [85.2, 86.1, 87.3, 88.0, 87.8],
                "accuracy": [92.1, 91.8, 92.5, 93.2, 92.9],
                "consistency": [78.5, 79.2, 80.1, 81.3, 82.0],
                "validity": [89.7, 90.2, 89.8, 90.5, 91.1]
            }
            
            return QualityDashboardResponse(
                organization_id=organization_id,
                total_datasets=total_datasets,
                datasets_with_rules=datasets_with_rules,
                total_quality_rules=total_quality_rules,
                active_quality_rules=active_quality_rules,
                recent_executions=recent_executions,
                average_quality_score=average_quality_score,
                quality_score_distribution=quality_score_distribution,
                top_failing_rules=top_failing_rules,
                quality_trends=quality_trends
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to get quality dashboard: {str(e)}")
    
    async def get_quality_statistics(self, organization_id: UUID, 
                                   dataset_id: Optional[UUID] = None,
                                   time_period: str = "30d") -> QualityStatisticsResponse:
        """Get quality statistics"""
        try:
            # Parse time period
            if time_period == "24h":
                hours = 24
            elif time_period == "7d":
                hours = 24 * 7
            elif time_period == "30d":
                hours = 24 * 30
            else:
                hours = 24 * 30
            
            # Get statistics (simplified implementation)
            total_executions = 1250
            successful_executions = 1180
            failed_executions = 70
            average_quality_score = 88.3
            
            quality_score_trend = [85.2, 86.8, 87.1, 88.0, 88.3]
            
            execution_frequency = {
                "00-06": 45, "06-12": 320, "12-18": 485, "18-24": 400
            }
            
            most_failing_rules = [
                {"rule_name": "Email Validation", "failure_count": 25, "dataset": "Customer Data"},
                {"rule_name": "Phone Completeness", "failure_count": 18, "dataset": "Contact Info"},
                {"rule_name": "Date Range Check", "failure_count": 12, "dataset": "Transaction Data"}
            ]
            
            quality_improvement = 3.2  # 3.2% improvement
            
            return QualityStatisticsResponse(
                organization_id=organization_id,
                dataset_id=dataset_id,
                time_period=time_period,
                total_executions=total_executions,
                successful_executions=successful_executions,
                failed_executions=failed_executions,
                average_quality_score=average_quality_score,
                quality_score_trend=quality_score_trend,
                execution_frequency=execution_frequency,
                most_failing_rules=most_failing_rules,
                quality_improvement=quality_improvement
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to get quality statistics: {str(e)}")
    
    async def validate_data_quality(self, dataset_id: UUID, field_name: Optional[str] = None) -> ValidationResultResponse:
        """Validate data quality for dataset or field"""
        try:
            # Get active rules for dataset
            rules = self.quality_repository.find_active_rules(dataset_id)
            
            if field_name:
                rules = [rule for rule in rules if rule.field_name == field_name]
            
            if not rules:
                raise ValueError("No active quality rules found for validation")
            
            # Execute validation (simplified)
            total_records = 10000
            valid_records = 8750
            invalid_records = 1250
            null_records = 0
            
            quality_score = (valid_records / total_records) * 100
            
            validation_errors = [
                {"error_type": "format_error", "count": 850, "percentage": 8.5},
                {"error_type": "range_error", "count": 400, "percentage": 4.0}
            ]
            
            sample_invalid_values = [
                "invalid@email", "123-456-789", "2025-13-45", None, ""
            ]
            
            return ValidationResultResponse(
                rule_id=rules[0].id,
                rule_name=rules[0].name,
                field_name=field_name,
                validation_passed=quality_score >= (rules[0].threshold_value or 80),
                quality_score=quality_score,
                total_records=total_records,
                valid_records=valid_records,
                invalid_records=invalid_records,
                null_records=null_records,
                validation_errors=validation_errors,
                sample_invalid_values=sample_invalid_values,
                execution_time_ms=1250
            )
            
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"Failed to validate data quality: {str(e)}")
    
    async def profile_dataset(self, request: DataProfilingRequest) -> DataProfilingResponse:
        """Profile dataset for quality assessment"""
        try:
            # Simulate data profiling (in real implementation, this would analyze actual data)
            profiled_fields = [
                {
                    "field_name": "email",
                    "data_type": "string",
                    "null_count": 125,
                    "null_percentage": 1.25,
                    "unique_count": 9875,
                    "unique_percentage": 98.75,
                    "patterns": ["email_format", "domain_variety"],
                    "quality_score": 92.5
                },
                {
                    "field_name": "phone",
                    "data_type": "string",
                    "null_count": 450,
                    "null_percentage": 4.5,
                    "unique_count": 9550,
                    "unique_percentage": 95.5,
                    "patterns": ["phone_format", "country_codes"],
                    "quality_score": 88.2
                }
            ]
            
            data_quality_issues = [
                {"issue_type": "missing_values", "field": "phone", "severity": "medium", "count": 450},
                {"issue_type": "invalid_format", "field": "email", "severity": "low", "count": 125}
            ]
            
            suggested_rules = [
                {
                    "rule_type": "completeness",
                    "field": "phone",
                    "threshold": 95.0,
                    "description": "Phone field should be at least 95% complete"
                },
                {
                    "rule_type": "validity",
                    "field": "email",
                    "threshold": 98.0,
                    "description": "Email field should have valid format"
                }
            ]
            
            return DataProfilingResponse(
                dataset_id=request.dataset_id,
                dataset_name="Sample Dataset",
                total_records=10000,
                profiled_fields=profiled_fields,
                data_quality_issues=data_quality_issues,
                suggested_rules=suggested_rules,
                profiling_date=datetime.utcnow()
            )
            
        except Exception as e:
            raise RuntimeError(f"Failed to profile dataset: {str(e)}")
    
    def _entity_to_response(self, rule: QualityRuleEntity) -> QualityRuleResponse:
        """Convert quality rule entity to response DTO"""
        # Get execution statistics
        stats = self.quality_repository.get_execution_statistics(rule.id)
        
        return QualityRuleResponse(
            id=rule.id,
            name=rule.name,
            description=rule.description,
            rule_type=rule.rule_type,
            status=rule.status,
            dataset_id=rule.dataset_id,
            dataset_name=rule.dataset_name,
            field_name=rule.field_name,
            validation_logic=rule.validation_logic,
            validation_engine=rule.validation_engine,
            threshold_value=rule.threshold_value,
            severity=rule.severity,
            is_blocking=rule.is_blocking,
            schedule_cron=rule.schedule_cron,
            tags=rule.tags,
            metadata=rule.metadata,
            created_by=rule.created_by,
            created_by_name=rule.created_by_name,
            last_execution_at=stats.get('latest_execution_date'),
            last_execution_status=ExecutionStatus(stats['latest_execution_status']) if stats.get('latest_execution_status') else None,
            last_execution_score=stats.get('latest_quality_score'),
            execution_count=stats.get('total_executions', 0),
            failure_count=stats.get('failed_executions', 0),
            created_at=rule.created_at,
            updated_at=rule.updated_at
        )

