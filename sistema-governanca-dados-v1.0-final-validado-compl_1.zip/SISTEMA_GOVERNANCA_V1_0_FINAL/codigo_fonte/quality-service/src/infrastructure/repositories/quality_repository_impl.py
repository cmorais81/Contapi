# Autor: carlos.morais@f1rst.com.br
"""
Quality Repository Implementation
SQLAlchemy implementation for quality rule data access
"""

from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from uuid import UUID, uuid4
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, func, desc, asc, text
from sqlalchemy.exc import IntegrityError

from ..models import QualityRule, QualityRuleExecution, QualityMetric, Dataset, User
from ...domain.repositories.quality_repository import QualityRepository
from ...domain.entities.quality_rule import QualityRule as QualityRuleEntity
from ...domain.value_objects.quality_rule_type import QualityRuleType
from ...domain.value_objects.quality_rule_status import QualityRuleStatus
from ...domain.value_objects.execution_status import ExecutionStatus
from ...domain.value_objects.severity import Severity


class QualityRepositoryImpl(QualityRepository):
    """SQLAlchemy implementation of quality repository"""
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    def save(self, quality_rule: QualityRuleEntity) -> QualityRuleEntity:
        """Save quality rule entity to database"""
        try:
            # Check if rule exists
            existing_rule = self.db.query(QualityRule).filter(QualityRule.id == quality_rule.id).first()
            
            if existing_rule:
                # Update existing rule
                self._update_rule_model(existing_rule, quality_rule)
            else:
                # Create new rule
                rule_model = self._create_rule_model(quality_rule)
                self.db.add(rule_model)
            
            self.db.commit()
            
            # Reload and return updated entity
            return self.find_by_id(quality_rule.id)
            
        except IntegrityError as e:
            self.db.rollback()
            if "name" in str(e):
                raise ValueError("Rule name already exists for this dataset")
            raise ValueError(f"Database integrity error: {str(e)}")
        except Exception as e:
            self.db.rollback()
            raise RuntimeError(f"Failed to save quality rule: {str(e)}")
    
    def find_by_id(self, rule_id: UUID) -> Optional[QualityRuleEntity]:
        """Find quality rule by ID"""
        try:
            rule_model = (
                self.db.query(QualityRule)
                .options(
                    joinedload(QualityRule.dataset),
                    joinedload(QualityRule.created_by_user)
                )
                .filter(QualityRule.id == rule_id)
                .first()
            )
            
            if not rule_model:
                return None
            
            return self._model_to_entity(rule_model)
            
        except Exception as e:
            raise RuntimeError(f"Failed to find quality rule by ID: {str(e)}")
    
    def find_by_name(self, name: str, dataset_id: UUID) -> Optional[QualityRuleEntity]:
        """Find quality rule by name and dataset"""
        try:
            rule_model = (
                self.db.query(QualityRule)
                .options(
                    joinedload(QualityRule.dataset),
                    joinedload(QualityRule.created_by_user)
                )
                .filter(
                    and_(
                        QualityRule.name == name,
                        QualityRule.dataset_id == dataset_id
                    )
                )
                .first()
            )
            
            if not rule_model:
                return None
            
            return self._model_to_entity(rule_model)
            
        except Exception as e:
            raise RuntimeError(f"Failed to find quality rule by name: {str(e)}")
    
    def find_by_dataset(self, dataset_id: UUID, status: Optional[QualityRuleStatus] = None) -> List[QualityRuleEntity]:
        """Find quality rules by dataset"""
        try:
            query = (
                self.db.query(QualityRule)
                .options(
                    joinedload(QualityRule.dataset),
                    joinedload(QualityRule.created_by_user)
                )
                .filter(QualityRule.dataset_id == dataset_id)
            )
            
            if status:
                query = query.filter(QualityRule.status == status.value)
            
            rule_models = query.order_by(QualityRule.name).all()
            return [self._model_to_entity(model) for model in rule_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find quality rules by dataset: {str(e)}")
    
    def find_by_type(self, rule_type: QualityRuleType, dataset_id: Optional[UUID] = None) -> List[QualityRuleEntity]:
        """Find quality rules by type"""
        try:
            query = (
                self.db.query(QualityRule)
                .options(
                    joinedload(QualityRule.dataset),
                    joinedload(QualityRule.created_by_user)
                )
                .filter(QualityRule.rule_type == rule_type.value)
            )
            
            if dataset_id:
                query = query.filter(QualityRule.dataset_id == dataset_id)
            
            rule_models = query.order_by(QualityRule.name).all()
            return [self._model_to_entity(model) for model in rule_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find quality rules by type: {str(e)}")
    
    def find_active_rules(self, dataset_id: Optional[UUID] = None) -> List[QualityRuleEntity]:
        """Find active quality rules"""
        try:
            query = (
                self.db.query(QualityRule)
                .options(
                    joinedload(QualityRule.dataset),
                    joinedload(QualityRule.created_by_user)
                )
                .filter(QualityRule.status == QualityRuleStatus.ACTIVE.value)
            )
            
            if dataset_id:
                query = query.filter(QualityRule.dataset_id == dataset_id)
            
            rule_models = query.order_by(QualityRule.name).all()
            return [self._model_to_entity(model) for model in rule_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find active quality rules: {str(e)}")
    
    def find_failing_rules(self, dataset_id: Optional[UUID] = None, threshold: float = 80.0) -> List[QualityRuleEntity]:
        """Find rules with quality score below threshold"""
        try:
            # Subquery to get latest execution for each rule
            latest_execution = (
                self.db.query(
                    QualityRuleExecution.rule_id,
                    func.max(QualityRuleExecution.started_at).label('latest_execution')
                )
                .group_by(QualityRuleExecution.rule_id)
                .subquery()
            )
            
            query = (
                self.db.query(QualityRule)
                .options(
                    joinedload(QualityRule.dataset),
                    joinedload(QualityRule.created_by_user)
                )
                .join(
                    QualityRuleExecution,
                    QualityRule.id == QualityRuleExecution.rule_id
                )
                .join(
                    latest_execution,
                    and_(
                        QualityRuleExecution.rule_id == latest_execution.c.rule_id,
                        QualityRuleExecution.started_at == latest_execution.c.latest_execution
                    )
                )
                .filter(
                    and_(
                        QualityRuleExecution.quality_score < threshold,
                        QualityRuleExecution.execution_status == ExecutionStatus.COMPLETED.value
                    )
                )
            )
            
            if dataset_id:
                query = query.filter(QualityRule.dataset_id == dataset_id)
            
            rule_models = query.order_by(QualityRuleExecution.quality_score).all()
            return [self._model_to_entity(model) for model in rule_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find failing quality rules: {str(e)}")
    
    def find_scheduled_rules(self) -> List[QualityRuleEntity]:
        """Find rules that have scheduling configured"""
        try:
            rule_models = (
                self.db.query(QualityRule)
                .options(
                    joinedload(QualityRule.dataset),
                    joinedload(QualityRule.created_by_user)
                )
                .filter(
                    and_(
                        QualityRule.schedule_cron.isnot(None),
                        QualityRule.status == QualityRuleStatus.ACTIVE.value
                    )
                )
                .order_by(QualityRule.name)
                .all()
            )
            
            return [self._model_to_entity(model) for model in rule_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find scheduled quality rules: {str(e)}")
    
    def search_rules(self, search_term: str, dataset_id: Optional[UUID] = None, 
                    limit: int = 100, offset: int = 0) -> List[QualityRuleEntity]:
        """Search quality rules by name or description"""
        try:
            search_pattern = f"%{search_term.lower()}%"
            
            query = (
                self.db.query(QualityRule)
                .options(
                    joinedload(QualityRule.dataset),
                    joinedload(QualityRule.created_by_user)
                )
                .filter(
                    or_(
                        func.lower(QualityRule.name).like(search_pattern),
                        func.lower(QualityRule.description).like(search_pattern),
                        func.lower(QualityRule.field_name).like(search_pattern)
                    )
                )
            )
            
            if dataset_id:
                query = query.filter(QualityRule.dataset_id == dataset_id)
            
            rule_models = (
                query.order_by(QualityRule.name)
                .limit(limit)
                .offset(offset)
                .all()
            )
            
            return [self._model_to_entity(model) for model in rule_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to search quality rules: {str(e)}")
    
    def find_with_filters(self, filters: Dict[str, Any], limit: int = 100, offset: int = 0) -> List[QualityRuleEntity]:
        """Find quality rules with multiple filters"""
        try:
            query = (
                self.db.query(QualityRule)
                .options(
                    joinedload(QualityRule.dataset),
                    joinedload(QualityRule.created_by_user)
                )
            )
            
            # Apply filters
            if filters.get('dataset_id'):
                query = query.filter(QualityRule.dataset_id == filters['dataset_id'])
            
            if filters.get('rule_type'):
                query = query.filter(QualityRule.rule_type == filters['rule_type'])
            
            if filters.get('status'):
                query = query.filter(QualityRule.status == filters['status'])
            
            if filters.get('severity'):
                query = query.filter(QualityRule.severity == filters['severity'])
            
            if filters.get('validation_engine'):
                query = query.filter(QualityRule.validation_engine == filters['validation_engine'])
            
            if filters.get('created_by'):
                query = query.filter(QualityRule.created_by == filters['created_by'])
            
            if filters.get('created_after'):
                query = query.filter(QualityRule.created_at >= filters['created_after'])
            
            if filters.get('created_before'):
                query = query.filter(QualityRule.created_at <= filters['created_before'])
            
            if filters.get('is_blocking') is not None:
                query = query.filter(QualityRule.is_blocking == filters['is_blocking'])
            
            if filters.get('tags'):
                # PostgreSQL array contains operation
                for tag in filters['tags']:
                    query = query.filter(QualityRule.tags.contains([tag]))
            
            # Sorting
            sort_by = filters.get('sort_by', 'created_at')
            sort_order = filters.get('sort_order', 'desc')
            
            if hasattr(QualityRule, sort_by):
                sort_column = getattr(QualityRule, sort_by)
                if sort_order.lower() == 'asc':
                    query = query.order_by(asc(sort_column))
                else:
                    query = query.order_by(desc(sort_column))
            
            rule_models = query.limit(limit).offset(offset).all()
            return [self._model_to_entity(model) for model in rule_models]
            
        except Exception as e:
            raise RuntimeError(f"Failed to find quality rules with filters: {str(e)}")
    
    def count_by_dataset(self, dataset_id: UUID) -> int:
        """Count quality rules for dataset"""
        try:
            return (
                self.db.query(func.count(QualityRule.id))
                .filter(QualityRule.dataset_id == dataset_id)
                .scalar()
            )
        except Exception as e:
            raise RuntimeError(f"Failed to count quality rules: {str(e)}")
    
    def count_by_status(self, dataset_id: Optional[UUID] = None) -> Dict[str, int]:
        """Count quality rules by status"""
        try:
            query = (
                self.db.query(QualityRule.status, func.count(QualityRule.id))
                .group_by(QualityRule.status)
            )
            
            if dataset_id:
                query = query.filter(QualityRule.dataset_id == dataset_id)
            
            results = query.all()
            return {status: count for status, count in results}
            
        except Exception as e:
            raise RuntimeError(f"Failed to count quality rules by status: {str(e)}")
    
    def count_by_type(self, dataset_id: Optional[UUID] = None) -> Dict[str, int]:
        """Count quality rules by type"""
        try:
            query = (
                self.db.query(QualityRule.rule_type, func.count(QualityRule.id))
                .group_by(QualityRule.rule_type)
            )
            
            if dataset_id:
                query = query.filter(QualityRule.dataset_id == dataset_id)
            
            results = query.all()
            return {rule_type: count for rule_type, count in results}
            
        except Exception as e:
            raise RuntimeError(f"Failed to count quality rules by type: {str(e)}")
    
    def get_execution_statistics(self, rule_id: UUID, days: int = 30) -> Dict[str, Any]:
        """Get execution statistics for a rule"""
        try:
            since = datetime.utcnow() - timedelta(days=days)
            
            # Total executions
            total_executions = (
                self.db.query(func.count(QualityRuleExecution.id))
                .filter(
                    and_(
                        QualityRuleExecution.rule_id == rule_id,
                        QualityRuleExecution.started_at >= since
                    )
                )
                .scalar()
            )
            
            # Successful executions
            successful_executions = (
                self.db.query(func.count(QualityRuleExecution.id))
                .filter(
                    and_(
                        QualityRuleExecution.rule_id == rule_id,
                        QualityRuleExecution.started_at >= since,
                        QualityRuleExecution.execution_status == ExecutionStatus.COMPLETED.value
                    )
                )
                .scalar()
            )
            
            # Average quality score
            avg_quality_score = (
                self.db.query(func.avg(QualityRuleExecution.quality_score))
                .filter(
                    and_(
                        QualityRuleExecution.rule_id == rule_id,
                        QualityRuleExecution.started_at >= since,
                        QualityRuleExecution.execution_status == ExecutionStatus.COMPLETED.value,
                        QualityRuleExecution.quality_score.isnot(None)
                    )
                )
                .scalar()
            )
            
            # Latest execution
            latest_execution = (
                self.db.query(QualityRuleExecution)
                .filter(QualityRuleExecution.rule_id == rule_id)
                .order_by(desc(QualityRuleExecution.started_at))
                .first()
            )
            
            return {
                'total_executions': total_executions or 0,
                'successful_executions': successful_executions or 0,
                'failed_executions': (total_executions or 0) - (successful_executions or 0),
                'success_rate': (successful_executions / total_executions * 100) if total_executions > 0 else 0,
                'average_quality_score': float(avg_quality_score) if avg_quality_score else None,
                'latest_execution_date': latest_execution.started_at if latest_execution else None,
                'latest_execution_status': latest_execution.execution_status if latest_execution else None,
                'latest_quality_score': latest_execution.quality_score if latest_execution else None
            }
            
        except Exception as e:
            raise RuntimeError(f"Failed to get execution statistics: {str(e)}")
    
    def get_dataset_quality_overview(self, dataset_id: UUID) -> Dict[str, Any]:
        """Get quality overview for a dataset"""
        try:
            # Total rules
            total_rules = self.count_by_dataset(dataset_id)
            
            # Active rules
            active_rules = (
                self.db.query(func.count(QualityRule.id))
                .filter(
                    and_(
                        QualityRule.dataset_id == dataset_id,
                        QualityRule.status == QualityRuleStatus.ACTIVE.value
                    )
                )
                .scalar()
            )
            
            # Latest executions for each rule
            latest_executions = (
                self.db.query(QualityRuleExecution)
                .join(QualityRule, QualityRule.id == QualityRuleExecution.rule_id)
                .filter(QualityRule.dataset_id == dataset_id)
                .order_by(desc(QualityRuleExecution.started_at))
                .limit(100)  # Get recent executions
                .all()
            )
            
            # Calculate quality metrics
            quality_scores = [
                exec.quality_score for exec in latest_executions 
                if exec.quality_score is not None and exec.execution_status == ExecutionStatus.COMPLETED.value
            ]
            
            overall_quality_score = sum(quality_scores) / len(quality_scores) if quality_scores else 0
            
            # Passing/failing rules
            passing_rules = len([score for score in quality_scores if score >= 80])
            failing_rules = len([score for score in quality_scores if score < 80])
            
            return {
                'dataset_id': dataset_id,
                'total_rules': total_rules,
                'active_rules': active_rules,
                'overall_quality_score': overall_quality_score,
                'passing_rules': passing_rules,
                'failing_rules': failing_rules,
                'last_assessment_date': latest_executions[0].started_at if latest_executions else None
            }
            
        except Exception as e:
            raise RuntimeError(f"Failed to get dataset quality overview: {str(e)}")
    
    def delete(self, rule_id: UUID) -> bool:
        """Delete quality rule"""
        try:
            rule_model = self.db.query(QualityRule).filter(QualityRule.id == rule_id).first()
            if not rule_model:
                return False
            
            # Soft delete - update status
            rule_model.status = QualityRuleStatus.DEPRECATED.value
            rule_model.updated_at = datetime.utcnow()
            
            self.db.commit()
            return True
            
        except Exception as e:
            self.db.rollback()
            raise RuntimeError(f"Failed to delete quality rule: {str(e)}")
    
    def exists_by_name(self, name: str, dataset_id: UUID, exclude_rule_id: Optional[UUID] = None) -> bool:
        """Check if rule name already exists for dataset"""
        try:
            query = self.db.query(QualityRule).filter(
                and_(
                    QualityRule.name == name,
                    QualityRule.dataset_id == dataset_id
                )
            )
            
            if exclude_rule_id:
                query = query.filter(QualityRule.id != exclude_rule_id)
            
            return query.first() is not None
            
        except Exception as e:
            raise RuntimeError(f"Failed to check rule name existence: {str(e)}")
    
    def _create_rule_model(self, rule: QualityRuleEntity) -> QualityRule:
        """Create SQLAlchemy model from entity"""
        return QualityRule(
            id=rule.id,
            name=rule.name,
            description=rule.description,
            rule_type=rule.rule_type.value,
            status=rule.status.value,
            dataset_id=rule.dataset_id,
            field_name=rule.field_name,
            validation_logic=rule.validation_logic,
            validation_engine=rule.validation_engine.value,
            threshold_value=rule.threshold_value,
            severity=rule.severity.value,
            is_blocking=rule.is_blocking,
            schedule_cron=rule.schedule_cron,
            tags=rule.tags,
            metadata=rule.metadata,
            created_by=rule.created_by,
            created_at=rule.created_at,
            updated_at=rule.updated_at
        )
    
    def _update_rule_model(self, rule_model: QualityRule, rule: QualityRuleEntity):
        """Update SQLAlchemy model from entity"""
        rule_model.name = rule.name
        rule_model.description = rule.description
        rule_model.rule_type = rule.rule_type.value
        rule_model.status = rule.status.value
        rule_model.field_name = rule.field_name
        rule_model.validation_logic = rule.validation_logic
        rule_model.validation_engine = rule.validation_engine.value
        rule_model.threshold_value = rule.threshold_value
        rule_model.severity = rule.severity.value
        rule_model.is_blocking = rule.is_blocking
        rule_model.schedule_cron = rule.schedule_cron
        rule_model.tags = rule.tags
        rule_model.metadata = rule.metadata
        rule_model.updated_at = rule.updated_at
    
    def _model_to_entity(self, rule_model: QualityRule) -> QualityRuleEntity:
        """Convert SQLAlchemy model to entity"""
        return QualityRuleEntity(
            id=rule_model.id,
            name=rule_model.name,
            description=rule_model.description,
            rule_type=QualityRuleType(rule_model.rule_type),
            status=QualityRuleStatus(rule_model.status),
            dataset_id=rule_model.dataset_id,
            dataset_name=rule_model.dataset.name if rule_model.dataset else None,
            field_name=rule_model.field_name,
            validation_logic=rule_model.validation_logic,
            validation_engine=rule_model.validation_engine,
            threshold_value=rule_model.threshold_value,
            severity=Severity(rule_model.severity),
            is_blocking=rule_model.is_blocking,
            schedule_cron=rule_model.schedule_cron,
            tags=rule_model.tags or [],
            metadata=rule_model.metadata or {},
            created_by=rule_model.created_by,
            created_by_name=rule_model.created_by_user.name if rule_model.created_by_user else None,
            created_at=rule_model.created_at,
            updated_at=rule_model.updated_at
        )

