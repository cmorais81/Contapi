"""
Entidade Notification para sistema de notificações
Autor: carlos.morais@f1rst.com.br
"""

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional, Dict, Any
from enum import Enum

class NotificationType(Enum):
    """Tipos de notificação"""
    EMAIL = "email"
    SMS = "sms"
    SLACK = "slack"
    WEBHOOK = "webhook"
    IN_APP = "in_app"

class NotificationPriority(Enum):
    """Prioridade da notificação"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class NotificationStatus(Enum):
    """Status da notificação"""
    PENDING = "pending"
    SENT = "sent"
    DELIVERED = "delivered"
    FAILED = "failed"
    RETRYING = "retrying"

@dataclass
class NotificationTemplate:
    """Template de notificação"""
    id: str
    name: str
    type: NotificationType
    subject_template: str
    body_template: str
    variables: List[str]
    created_at: datetime
    updated_at: datetime

@dataclass
class NotificationRecipient:
    """Destinatário da notificação"""
    id: str
    name: str
    email: Optional[str] = None
    phone: Optional[str] = None
    slack_user_id: Optional[str] = None
    webhook_url: Optional[str] = None
    preferences: Dict[str, Any] = None

@dataclass
class Notification:
    """Entidade principal de notificação"""
    id: str
    template_id: str
    recipient: NotificationRecipient
    type: NotificationType
    priority: NotificationPriority
    status: NotificationStatus
    subject: str
    content: str
    metadata: Dict[str, Any]
    scheduled_at: Optional[datetime]
    sent_at: Optional[datetime]
    delivered_at: Optional[datetime]
    retry_count: int
    max_retries: int
    error_message: Optional[str]
    created_at: datetime
    updated_at: datetime
    
    def can_retry(self) -> bool:
        """Verifica se pode tentar reenviar"""
        return (self.status == NotificationStatus.FAILED and 
                self.retry_count < self.max_retries)
    
    def mark_as_sent(self):
        """Marca como enviada"""
        self.status = NotificationStatus.SENT
        self.sent_at = datetime.now()
        self.updated_at = datetime.now()
    
    def mark_as_delivered(self):
        """Marca como entregue"""
        self.status = NotificationStatus.DELIVERED
        self.delivered_at = datetime.now()
        self.updated_at = datetime.now()
    
    def mark_as_failed(self, error_message: str):
        """Marca como falha"""
        self.status = NotificationStatus.FAILED
        self.error_message = error_message
        self.retry_count += 1
        self.updated_at = datetime.now()
