# Autor: carlos.morais@f1rst.com.br
from dotenv import load_dotenv
import os
from datetime import datetime
import json
import asyncio
from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'config'))

try:
    from settings import get_settings
    settings = get_settings()
except ImportError:
    print("⚠️ Configurações centralizadas não encontradas, usando valores padrão")
    settings = None


# Carregar configurações
load_dotenv()

app = FastAPI(
    title="Notification Service V4.5",
    description="Sistema de notificações e alertas - Sistema de Governança de Dados de Dados",
    version="4.5.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS Configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Estado do serviço
service_state = {
    "status": "healthy",
    "started_at": datetime.now().isoformat(),
    "requests_count": 0,
    "last_activity": datetime.now().isoformat()
}

@app.middleware("http")
async def update_activity(request: Request, call_next):
    """Middleware para atualizar atividade do serviço"""
    service_state["requests_count"] += 1
    service_state["last_activity"] = datetime.now().isoformat()
    
    response = await call_next(request)
    return response

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "notification-service",
        "version": "4.5.0",
        "port": 8014,
        "timestamp": datetime.now().isoformat(),
        "uptime_seconds": (datetime.now() - datetime.fromisoformat(service_state["started_at"].replace('Z', '+00:00').replace('+00:00', ''))).total_seconds(),
        "requests_count": service_state["requests_count"]
    }

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Welcome to Notification Service",
        "description": "Sistema de notificações e alertas",
        "version": "4.5.0",
        "status": "operational",
        "endpoints": [
            "/health",
            "/docs",
            "/redoc",
            "/status",
            "/info"
        ]
    }

@app.get("/status")
async def get_status():
    """Status detalhado do serviço"""
    return {
        "service": "notification-service",
        "status": service_state["status"],
        "version": "4.5.0",
        "started_at": service_state["started_at"],
        "last_activity": service_state["last_activity"],
        "requests_count": service_state["requests_count"],
        "memory_usage": "N/A",
        "cpu_usage": "N/A"
    }

@app.get("/info")
async def get_info():
    """Informações do serviço"""
    return {
        "name": "Notification Service",
        "description": "Sistema de notificações e alertas",
        "version": "4.5.0",
        "port": 8014,
        "framework": "FastAPI",
        "python_version": "3.11+",
        "features": [
            "Health Check",
            "Status Monitoring", 
            "CORS Support",
            "OpenAPI Documentation",
            "Request Tracking"
        ]
    }

# Endpoints específicos do serviço (placeholder)
@app.get("/api/v1/ping")
async def ping():
    """Endpoint de ping"""
    return {
        "message": "pong",
        "service": "notification-service",
        "timestamp": datetime.now().isoformat()
    }

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8014))
    print(f"🚀 Iniciando {config['title']} na porta {port}")
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=port,
        log_level="info"
    )
