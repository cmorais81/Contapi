-- Schema para Sistema de Governança de Dados com Linhagem
-- Versão: 5.0 - PostgreSQL Real
-- Data: 29 de Julho de 2025

-- =====================================================
-- TABELAS PRINCIPAIS DE GOVERNANÇA
-- =====================================================

-- Contratos de Dados
CREATE TABLE IF NOT EXISTS contracts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    version VARCHAR(50) NOT NULL DEFAULT '1.0.0',
    status VARCHAR(50) NOT NULL DEFAULT 'draft',
    data_classification VARCHAR(50) NOT NULL DEFAULT 'internal',
    owner_email VARCHAR(255),
    schema_definition JSONB,
    sla_requirements JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Usuários e Identidades
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    role VARCHAR(100) NOT NULL,
    department VARCHAR(255),
    is_active BOOLEAN DEFAULT true,
    permissions JSONB,
    last_login TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Regras de Qualidade
CREATE TABLE IF NOT EXISTS quality_rules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    rule_type VARCHAR(100) NOT NULL,
    threshold DECIMAL(5,4) NOT NULL DEFAULT 0.95,
    configuration JSONB,
    is_active BOOLEAN DEFAULT true,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Entidades de Dados (Datasets)
CREATE TABLE IF NOT EXISTS data_entities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    entity_type VARCHAR(100) NOT NULL,
    source_system VARCHAR(255),
    schema_definition JSONB,
    classification VARCHAR(50),
    owner_id UUID REFERENCES users(id),
    contract_id UUID REFERENCES contracts(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Colunas/Campos das Entidades
CREATE TABLE IF NOT EXISTS data_columns (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_id UUID NOT NULL REFERENCES data_entities(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    data_type VARCHAR(100) NOT NULL,
    is_nullable BOOLEAN DEFAULT true,
    is_pii BOOLEAN DEFAULT false,
    description TEXT,
    classification VARCHAR(50),
    quality_rules UUID[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- TABELAS DE LINHAGEM DE DADOS
-- =====================================================

-- Fontes de Dados
CREATE TABLE IF NOT EXISTS data_sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    source_type VARCHAR(100) NOT NULL, -- database, file, api, stream
    connection_string TEXT,
    configuration JSONB,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Transformações/Processos
CREATE TABLE IF NOT EXISTS data_transformations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    transformation_type VARCHAR(100) NOT NULL, -- etl, elt, stream, manual
    description TEXT,
    code_repository VARCHAR(500),
    configuration JSONB,
    owner_id UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Linhagem de Dados (Relacionamentos)
CREATE TABLE IF NOT EXISTS data_lineage (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_entity_id UUID REFERENCES data_entities(id),
    target_entity_id UUID REFERENCES data_entities(id),
    transformation_id UUID REFERENCES data_transformations(id),
    lineage_type VARCHAR(100) NOT NULL, -- direct, derived, aggregated
    relationship_strength DECIMAL(3,2) DEFAULT 1.0, -- 0.0 to 1.0
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Execuções de Transformação
CREATE TABLE IF NOT EXISTS transformation_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transformation_id UUID NOT NULL REFERENCES data_transformations(id),
    execution_status VARCHAR(50) NOT NULL, -- running, completed, failed
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE,
    records_processed BIGINT DEFAULT 0,
    records_failed BIGINT DEFAULT 0,
    execution_log TEXT,
    metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- TABELAS DE AUDITORIA E COMPLIANCE
-- =====================================================

-- Eventos de Auditoria
CREATE TABLE IF NOT EXISTS audit_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_type VARCHAR(100) NOT NULL,
    resource_type VARCHAR(100) NOT NULL,
    resource_id UUID,
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    details JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Verificações de Compliance
CREATE TABLE IF NOT EXISTS compliance_checks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    framework VARCHAR(100) NOT NULL, -- LGPD, GDPR, SOX, etc
    check_type VARCHAR(100) NOT NULL,
    entity_id UUID REFERENCES data_entities(id),
    status VARCHAR(50) NOT NULL, -- compliant, non_compliant, pending
    score DECIMAL(5,4),
    findings JSONB,
    checked_by UUID REFERENCES users(id),
    checked_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Políticas de Governança
CREATE TABLE IF NOT EXISTS governance_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    policy_type VARCHAR(100) NOT NULL,
    scope VARCHAR(100) NOT NULL, -- global, entity, column
    rules JSONB NOT NULL,
    enforcement_level VARCHAR(50) DEFAULT 'warning', -- blocking, warning, info
    is_active BOOLEAN DEFAULT true,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Violações de Políticas
CREATE TABLE IF NOT EXISTS policy_violations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_id UUID NOT NULL REFERENCES governance_policies(id),
    entity_id UUID REFERENCES data_entities(id),
    violation_type VARCHAR(100) NOT NULL,
    severity VARCHAR(50) NOT NULL, -- critical, high, medium, low
    description TEXT,
    status VARCHAR(50) DEFAULT 'open', -- open, acknowledged, resolved
    detected_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP WITH TIME ZONE,
    resolved_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- TABELAS DE WORKFLOWS E PROCESSOS
-- =====================================================

-- Definições de Workflow
CREATE TABLE IF NOT EXISTS workflow_definitions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    workflow_type VARCHAR(100) NOT NULL,
    bpmn_definition JSONB,
    is_active BOOLEAN DEFAULT true,
    version VARCHAR(50) DEFAULT '1.0.0',
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Instâncias de Workflow
CREATE TABLE IF NOT EXISTS workflow_instances (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    definition_id UUID NOT NULL REFERENCES workflow_definitions(id),
    status VARCHAR(50) NOT NULL, -- running, completed, failed, cancelled
    started_by UUID REFERENCES users(id),
    context JSONB,
    start_time TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    end_time TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tarefas de Workflow
CREATE TABLE IF NOT EXISTS workflow_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    instance_id UUID NOT NULL REFERENCES workflow_instances(id),
    task_name VARCHAR(255) NOT NULL,
    task_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL, -- pending, running, completed, failed
    assigned_to UUID REFERENCES users(id),
    input_data JSONB,
    output_data JSONB,
    start_time TIMESTAMP WITH TIME ZONE,
    end_time TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- TABELAS DE NOTIFICAÇÕES
-- =====================================================

-- Notificações
CREATE TABLE IF NOT EXISTS notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipient_id UUID NOT NULL REFERENCES users(id),
    notification_type VARCHAR(100) NOT NULL,
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    priority VARCHAR(50) DEFAULT 'medium', -- low, medium, high, critical
    channel VARCHAR(50) NOT NULL, -- email, slack, teams, in_app
    status VARCHAR(50) DEFAULT 'pending', -- pending, sent, delivered, failed
    metadata JSONB,
    sent_at TIMESTAMP WITH TIME ZONE,
    delivered_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- =====================================================
-- ÍNDICES PARA PERFORMANCE
-- =====================================================

-- Índices para consultas frequentes
CREATE INDEX IF NOT EXISTS idx_contracts_status ON contracts(status);
CREATE INDEX IF NOT EXISTS idx_contracts_owner ON contracts(owner_email);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_data_entities_owner ON data_entities(owner_id);
CREATE INDEX IF NOT EXISTS idx_data_entities_contract ON data_entities(contract_id);
CREATE INDEX IF NOT EXISTS idx_data_lineage_source ON data_lineage(source_entity_id);
CREATE INDEX IF NOT EXISTS idx_data_lineage_target ON data_lineage(target_entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_user ON audit_events(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_resource ON audit_events(resource_type, resource_id);
CREATE INDEX IF NOT EXISTS idx_audit_events_created ON audit_events(created_at);
CREATE INDEX IF NOT EXISTS idx_compliance_checks_entity ON compliance_checks(entity_id);
CREATE INDEX IF NOT EXISTS idx_policy_violations_policy ON policy_violations(policy_id);
CREATE INDEX IF NOT EXISTS idx_workflow_instances_definition ON workflow_instances(definition_id);
CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_id);
CREATE INDEX IF NOT EXISTS idx_notifications_status ON notifications(status);

-- =====================================================
-- TRIGGERS PARA AUDITORIA AUTOMÁTICA
-- =====================================================

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para updated_at
CREATE TRIGGER update_contracts_updated_at BEFORE UPDATE ON contracts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_quality_rules_updated_at BEFORE UPDATE ON quality_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_entities_updated_at BEFORE UPDATE ON data_entities FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_columns_updated_at BEFORE UPDATE ON data_columns FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_sources_updated_at BEFORE UPDATE ON data_sources FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_transformations_updated_at BEFORE UPDATE ON data_transformations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_governance_policies_updated_at BEFORE UPDATE ON governance_policies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_workflow_definitions_updated_at BEFORE UPDATE ON workflow_definitions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- DADOS INICIAIS DE EXEMPLO
-- =====================================================

-- Inserir usuário administrador padrão
INSERT INTO users (name, email, role, department, permissions) VALUES 
('Administrador Sistema', 'admin@governance.com', 'admin', 'TI', '{"all": true}')
ON CONFLICT (email) DO NOTHING;

-- Inserir usuários de exemplo
INSERT INTO users (name, email, role, department, permissions) VALUES 
('Ana Silva', 'ana.silva@empresa.com', 'data_owner', 'Vendas', '{"read": true, "write": true}'),
('Carlos Santos', 'carlos.santos@empresa.com', 'data_steward', 'TI', '{"read": true, "write": true, "admin": true}'),
('Maria Oliveira', 'maria.oliveira@empresa.com', 'analyst', 'Marketing', '{"read": true}')
ON CONFLICT (email) DO NOTHING;

-- Inserir regras de qualidade padrão
INSERT INTO quality_rules (name, description, rule_type, threshold, configuration) VALUES 
('Completude de Email', 'Verifica se o campo email está preenchido', 'completeness', 0.95, '{"field": "email", "required": true}'),
('Formato de CPF', 'Verifica se o CPF está no formato correto', 'format', 1.0, '{"field": "cpf", "pattern": "\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}"}'),
('Unicidade de Email', 'Verifica se não há emails duplicados', 'uniqueness', 1.0, '{"field": "email", "scope": "global"}')
ON CONFLICT DO NOTHING;

-- Inserir políticas de governança padrão
INSERT INTO governance_policies (name, description, policy_type, scope, rules) VALUES 
('Proteção de PII', 'Dados pessoais devem ser classificados e protegidos', 'privacy', 'column', '{"pii_detection": true, "encryption_required": true}'),
('Retenção de Dados', 'Dados devem ter política de retenção definida', 'retention', 'entity', '{"max_retention_days": 2555, "auto_purge": true}'),
('Qualidade Mínima', 'Dados devem atender qualidade mínima de 90%', 'quality', 'entity', '{"min_quality_score": 0.9}')
ON CONFLICT DO NOTHING;

