# Autor: carlos.morais@f1rst.com.br
"""
Testes Unitários para AuditEventService
"""

import pytest
import asyncio
from datetime import datetime, timedelta
from uuid import UUID, uuid4
from unittest.mock import Mock, AsyncMock, patch

from src.domain.entities.audit_event import AuditEvent, AuditEventType, AuditSeverity
from src.domain.services.audit_event_service import AuditEventService
from src.domain.repositories.audit_event_repository import AuditEventRepository


class TestAuditEventService:
    """Testes para AuditEventService"""
    
    @pytest.fixture
    def mock_repository(self):
        """Mock do repositório de eventos de auditoria"""
        repository = Mock(spec=AuditEventRepository)
        repository.save = AsyncMock()
        repository.find_by_id = AsyncMock()
        repository.find_by_criteria = AsyncMock()
        repository.count_by_criteria = AsyncMock()
        return repository
    
    @pytest.fixture
    def audit_service(self, mock_repository):
        """Instância do serviço de auditoria"""
        return AuditEventService(mock_repository)
    
    @pytest.fixture
    def sample_audit_event(self):
        """Evento de auditoria de exemplo"""
        return AuditEvent(
            id=uuid4(),
            event_type=AuditEventType.DATA_ACCESS,
            severity=AuditSeverity.INFO,
            user_id="user123",
            resource_id="resource456",
            action="read",
            description="Usuário acessou dados do contrato",
            metadata={
                "contract_id": "contract789",
                "ip_address": "192.168.1.100",
                "user_agent": "Mozilla/5.0"
            },
            timestamp=datetime.utcnow()
        )
    
    @pytest.mark.asyncio
    async def test_create_audit_event_success(self, audit_service, mock_repository):
        """Testa criação bem-sucedida de evento de auditoria"""
        # Arrange
        event_data = {
            "event_type": AuditEventType.DATA_ACCESS,
            "severity": AuditSeverity.INFO,
            "user_id": "user123",
            "resource_id": "resource456",
            "action": "read",
            "description": "Teste de acesso",
            "metadata": {"test": "data"}
        }
        
        mock_repository.save.return_value = True
        
        # Act
        result = await audit_service.create_audit_event(**event_data)
        
        # Assert
        assert result is not None
        assert isinstance(result, AuditEvent)
        assert result.event_type == AuditEventType.DATA_ACCESS
        assert result.user_id == "user123"
        assert result.resource_id == "resource456"
        assert result.action == "read"
        assert result.metadata["test"] == "data"
        
        # Verificar se o repositório foi chamado
        mock_repository.save.assert_called_once()
        saved_event = mock_repository.save.call_args[0][0]
        assert isinstance(saved_event, AuditEvent)
    
    @pytest.mark.asyncio
    async def test_create_audit_event_with_correlation_id(self, audit_service, mock_repository):
        """Testa criação de evento com correlation_id"""
        # Arrange
        correlation_id = str(uuid4())
        event_data = {
            "event_type": AuditEventType.SYSTEM_ERROR,
            "severity": AuditSeverity.HIGH,
            "user_id": "system",
            "action": "error_occurred",
            "description": "Erro no sistema",
            "correlation_id": correlation_id
        }
        
        mock_repository.save.return_value = True
        
        # Act
        result = await audit_service.create_audit_event(**event_data)
        
        # Assert
        assert result.correlation_id == correlation_id
        mock_repository.save.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_create_audit_event_repository_failure(self, audit_service, mock_repository):
        """Testa falha na criação quando repositório falha"""
        # Arrange
        event_data = {
            "event_type": AuditEventType.DATA_ACCESS,
            "severity": AuditSeverity.INFO,
            "user_id": "user123",
            "action": "read",
            "description": "Teste"
        }
        
        mock_repository.save.side_effect = Exception("Database error")
        
        # Act & Assert
        with pytest.raises(Exception, match="Database error"):
            await audit_service.create_audit_event(**event_data)
    
    @pytest.mark.asyncio
    async def test_create_bulk_audit_events_success(self, audit_service, mock_repository):
        """Testa criação em lote de eventos de auditoria"""
        # Arrange
        events_data = [
            {
                "event_type": AuditEventType.DATA_ACCESS,
                "severity": AuditSeverity.INFO,
                "user_id": f"user{i}",
                "action": "read",
                "description": f"Teste {i}"
            }
            for i in range(3)
        ]
        
        mock_repository.save_bulk = AsyncMock(return_value=True)
        
        # Act
        result = await audit_service.create_bulk_audit_events(events_data)
        
        # Assert
        assert len(result) == 3
        assert all(isinstance(event, AuditEvent) for event in result)
        assert all(event.user_id == f"user{i}" for i, event in enumerate(result))
        
        mock_repository.save_bulk.assert_called_once()
        saved_events = mock_repository.save_bulk.call_args[0][0]
        assert len(saved_events) == 3
    
    @pytest.mark.asyncio
    async def test_create_bulk_audit_events_empty_list(self, audit_service, mock_repository):
        """Testa criação em lote com lista vazia"""
        # Act
        result = await audit_service.create_bulk_audit_events([])
        
        # Assert
        assert result == []
        mock_repository.save_bulk.assert_not_called()
    
    @pytest.mark.asyncio
    async def test_get_audit_event_by_id_found(self, audit_service, mock_repository, sample_audit_event):
        """Testa busca de evento por ID quando encontrado"""
        # Arrange
        event_id = sample_audit_event.id
        mock_repository.find_by_id.return_value = sample_audit_event
        
        # Act
        result = await audit_service.get_audit_event_by_id(event_id)
        
        # Assert
        assert result == sample_audit_event
        mock_repository.find_by_id.assert_called_once_with(event_id)
    
    @pytest.mark.asyncio
    async def test_get_audit_event_by_id_not_found(self, audit_service, mock_repository):
        """Testa busca de evento por ID quando não encontrado"""
        # Arrange
        event_id = uuid4()
        mock_repository.find_by_id.return_value = None
        
        # Act
        result = await audit_service.get_audit_event_by_id(event_id)
        
        # Assert
        assert result is None
        mock_repository.find_by_id.assert_called_once_with(event_id)
    
    @pytest.mark.asyncio
    async def test_search_audit_events_with_filters(self, audit_service, mock_repository):
        """Testa busca de eventos com filtros"""
        # Arrange
        filters = {
            "user_id": "user123",
            "event_type": AuditEventType.DATA_ACCESS,
            "start_date": datetime.utcnow() - timedelta(days=1),
            "end_date": datetime.utcnow()
        }
        
        expected_events = [
            AuditEvent(
                event_type=AuditEventType.DATA_ACCESS,
                user_id="user123",
                action="read",
                description="Test event"
            )
        ]
        
        mock_repository.find_by_criteria.return_value = expected_events
        
        # Act
        result = await audit_service.search_audit_events(filters)
        
        # Assert
        assert result == expected_events
        mock_repository.find_by_criteria.assert_called_once()
        call_args = mock_repository.find_by_criteria.call_args[0][0]
        assert call_args["user_id"] == "user123"
        assert call_args["event_type"] == AuditEventType.DATA_ACCESS
    
    @pytest.mark.asyncio
    async def test_search_audit_events_with_pagination(self, audit_service, mock_repository):
        """Testa busca de eventos com paginação"""
        # Arrange
        filters = {"user_id": "user123"}
        page = 2
        page_size = 10
        
        expected_events = [AuditEvent(user_id="user123", action="test") for _ in range(5)]
        mock_repository.find_by_criteria.return_value = expected_events
        
        # Act
        result = await audit_service.search_audit_events(filters, page=page, page_size=page_size)
        
        # Assert
        assert result == expected_events
        mock_repository.find_by_criteria.assert_called_once()
        call_args = mock_repository.find_by_criteria.call_args
        assert call_args[1]["offset"] == 10  # (page - 1) * page_size
        assert call_args[1]["limit"] == 10
    
    @pytest.mark.asyncio
    async def test_count_audit_events(self, audit_service, mock_repository):
        """Testa contagem de eventos de auditoria"""
        # Arrange
        filters = {"user_id": "user123"}
        expected_count = 42
        mock_repository.count_by_criteria.return_value = expected_count
        
        # Act
        result = await audit_service.count_audit_events(filters)
        
        # Assert
        assert result == expected_count
        mock_repository.count_by_criteria.assert_called_once_with(filters)
    
    @pytest.mark.asyncio
    async def test_get_audit_statistics_by_user(self, audit_service, mock_repository):
        """Testa obtenção de estatísticas por usuário"""
        # Arrange
        user_id = "user123"
        start_date = datetime.utcnow() - timedelta(days=30)
        end_date = datetime.utcnow()
        
        mock_events = [
            AuditEvent(
                event_type=AuditEventType.DATA_ACCESS,
                severity=AuditSeverity.INFO,
                user_id=user_id,
                action="read"
            ),
            AuditEvent(
                event_type=AuditEventType.DATA_MODIFICATION,
                severity=AuditSeverity.MEDIUM,
                user_id=user_id,
                action="update"
            ),
            AuditEvent(
                event_type=AuditEventType.DATA_ACCESS,
                severity=AuditSeverity.INFO,
                user_id=user_id,
                action="read"
            )
        ]
        
        mock_repository.find_by_criteria.return_value = mock_events
        
        # Act
        result = await audit_service.get_audit_statistics_by_user(user_id, start_date, end_date)
        
        # Assert
        assert result["user_id"] == user_id
        assert result["total_events"] == 3
        assert result["events_by_type"][AuditEventType.DATA_ACCESS.value] == 2
        assert result["events_by_type"][AuditEventType.DATA_MODIFICATION.value] == 1
        assert result["events_by_severity"][AuditSeverity.INFO.value] == 2
        assert result["events_by_severity"][AuditSeverity.MEDIUM.value] == 1
        assert result["period"]["start_date"] == start_date.isoformat()
        assert result["period"]["end_date"] == end_date.isoformat()
    
    @pytest.mark.asyncio
    async def test_get_audit_statistics_by_resource(self, audit_service, mock_repository):
        """Testa obtenção de estatísticas por recurso"""
        # Arrange
        resource_id = "resource456"
        start_date = datetime.utcnow() - timedelta(days=7)
        end_date = datetime.utcnow()
        
        mock_events = [
            AuditEvent(
                event_type=AuditEventType.DATA_ACCESS,
                user_id="user1",
                resource_id=resource_id,
                action="read"
            ),
            AuditEvent(
                event_type=AuditEventType.DATA_ACCESS,
                user_id="user2",
                resource_id=resource_id,
                action="read"
            )
        ]
        
        mock_repository.find_by_criteria.return_value = mock_events
        
        # Act
        result = await audit_service.get_audit_statistics_by_resource(resource_id, start_date, end_date)
        
        # Assert
        assert result["resource_id"] == resource_id
        assert result["total_events"] == 2
        assert result["unique_users"] == 2
        assert "user1" in result["users"]
        assert "user2" in result["users"]
        assert result["events_by_action"]["read"] == 2
    
    @pytest.mark.asyncio
    async def test_validate_audit_event_data_valid(self, audit_service):
        """Testa validação de dados válidos de evento"""
        # Arrange
        valid_data = {
            "event_type": AuditEventType.DATA_ACCESS,
            "severity": AuditSeverity.INFO,
            "user_id": "user123",
            "action": "read",
            "description": "Valid event"
        }
        
        # Act
        result = audit_service._validate_audit_event_data(valid_data)
        
        # Assert
        assert result is True
    
    @pytest.mark.asyncio
    async def test_validate_audit_event_data_missing_required(self, audit_service):
        """Testa validação com campos obrigatórios ausentes"""
        # Arrange
        invalid_data = {
            "event_type": AuditEventType.DATA_ACCESS,
            # Faltando severity, user_id, action, description
        }
        
        # Act & Assert
        with pytest.raises(ValueError, match="Campo obrigatório ausente"):
            audit_service._validate_audit_event_data(invalid_data)
    
    @pytest.mark.asyncio
    async def test_validate_audit_event_data_invalid_types(self, audit_service):
        """Testa validação com tipos inválidos"""
        # Arrange
        invalid_data = {
            "event_type": "invalid_type",  # Deve ser AuditEventType
            "severity": AuditSeverity.INFO,
            "user_id": "user123",
            "action": "read",
            "description": "Test"
        }
        
        # Act & Assert
        with pytest.raises(ValueError, match="Tipo inválido"):
            audit_service._validate_audit_event_data(invalid_data)
    
    @pytest.mark.asyncio
    async def test_enrich_audit_event_metadata(self, audit_service):
        """Testa enriquecimento de metadados do evento"""
        # Arrange
        event = AuditEvent(
            event_type=AuditEventType.DATA_ACCESS,
            user_id="user123",
            action="read",
            description="Test event"
        )
        
        additional_metadata = {
            "ip_address": "192.168.1.100",
            "user_agent": "Mozilla/5.0"
        }
        
        # Act
        enriched_event = audit_service._enrich_audit_event_metadata(event, additional_metadata)
        
        # Assert
        assert enriched_event.metadata["ip_address"] == "192.168.1.100"
        assert enriched_event.metadata["user_agent"] == "Mozilla/5.0"
        assert "enriched_at" in enriched_event.metadata
        assert "service_version" in enriched_event.metadata
    
    @pytest.mark.asyncio
    async def test_generate_correlation_id(self, audit_service):
        """Testa geração de correlation_id"""
        # Act
        correlation_id = audit_service._generate_correlation_id()
        
        # Assert
        assert correlation_id is not None
        assert len(correlation_id) > 0
        assert isinstance(correlation_id, str)
        
        # Verificar que IDs diferentes são gerados
        another_id = audit_service._generate_correlation_id()
        assert correlation_id != another_id
    
    @pytest.mark.asyncio
    async def test_calculate_event_risk_score_high_risk(self, audit_service):
        """Testa cálculo de score de risco para evento de alto risco"""
        # Arrange
        high_risk_event = AuditEvent(
            event_type=AuditEventType.SECURITY_VIOLATION,
            severity=AuditSeverity.CRITICAL,
            user_id="user123",
            action="unauthorized_access",
            description="Tentativa de acesso não autorizado"
        )
        
        # Act
        risk_score = audit_service._calculate_event_risk_score(high_risk_event)
        
        # Assert
        assert risk_score >= 80  # Alto risco
        assert risk_score <= 100
    
    @pytest.mark.asyncio
    async def test_calculate_event_risk_score_low_risk(self, audit_service):
        """Testa cálculo de score de risco para evento de baixo risco"""
        # Arrange
        low_risk_event = AuditEvent(
            event_type=AuditEventType.DATA_ACCESS,
            severity=AuditSeverity.INFO,
            user_id="user123",
            action="read",
            description="Leitura normal de dados"
        )
        
        # Act
        risk_score = audit_service._calculate_event_risk_score(low_risk_event)
        
        # Assert
        assert risk_score >= 0
        assert risk_score <= 30  # Baixo risco
    
    @pytest.mark.asyncio
    async def test_should_trigger_alert_critical_event(self, audit_service):
        """Testa se evento crítico deve disparar alerta"""
        # Arrange
        critical_event = AuditEvent(
            event_type=AuditEventType.SECURITY_VIOLATION,
            severity=AuditSeverity.CRITICAL,
            user_id="user123",
            action="data_breach",
            description="Possível violação de dados"
        )
        
        # Act
        should_alert = audit_service._should_trigger_alert(critical_event)
        
        # Assert
        assert should_alert is True
    
    @pytest.mark.asyncio
    async def test_should_trigger_alert_normal_event(self, audit_service):
        """Testa se evento normal não deve disparar alerta"""
        # Arrange
        normal_event = AuditEvent(
            event_type=AuditEventType.DATA_ACCESS,
            severity=AuditSeverity.INFO,
            user_id="user123",
            action="read",
            description="Acesso normal aos dados"
        )
        
        # Act
        should_alert = audit_service._should_trigger_alert(normal_event)
        
        # Assert
        assert should_alert is False
    
    @pytest.mark.asyncio
    async def test_performance_with_large_bulk_insert(self, audit_service, mock_repository):
        """Testa performance com inserção em lote grande"""
        # Arrange
        large_events_data = [
            {
                "event_type": AuditEventType.DATA_ACCESS,
                "severity": AuditSeverity.INFO,
                "user_id": f"user{i}",
                "action": "read",
                "description": f"Evento {i}"
            }
            for i in range(1000)  # 1000 eventos
        ]
        
        mock_repository.save_bulk = AsyncMock(return_value=True)
        
        # Act
        start_time = datetime.utcnow()
        result = await audit_service.create_bulk_audit_events(large_events_data)
        end_time = datetime.utcnow()
        
        # Assert
        assert len(result) == 1000
        execution_time = (end_time - start_time).total_seconds()
        assert execution_time < 5.0  # Deve executar em menos de 5 segundos
        
        mock_repository.save_bulk.assert_called_once()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

