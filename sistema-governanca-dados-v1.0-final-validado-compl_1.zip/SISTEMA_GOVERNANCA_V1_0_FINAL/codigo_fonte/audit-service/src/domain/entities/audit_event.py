# Autor: carlos.morais@f1rst.com.br
"""
Entidade AuditEvent - Representa um evento de auditoria no sistema
"""

from datetime import datetime
from enum import Enum
from typing import Dict, Any, Optional
from uuid import uuid4, UUID

from pydantic import BaseModel, Field, validator


class AuditEventType(str, Enum):
    """Tipos de eventos de auditoria"""
    USER_LOGIN = "user_login"
    USER_LOGOUT = "user_logout"
    DATA_ACCESS = "data_access"
    DATA_MODIFICATION = "data_modification"
    CONTRACT_CREATED = "contract_created"
    CONTRACT_UPDATED = "contract_updated"
    CONTRACT_DELETED = "contract_deleted"
    QUALITY_CHECK = "quality_check"
    POLICY_VIOLATION = "policy_violation"
    SYSTEM_ERROR = "system_error"
    CONFIGURATION_CHANGE = "configuration_change"
    BACKUP_CREATED = "backup_created"
    SECURITY_INCIDENT = "security_incident"


class AuditSeverity(str, Enum):
    """Níveis de severidade dos eventos de auditoria"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class AuditStatus(str, Enum):
    """Status do evento de auditoria"""
    PENDING = "pending"
    PROCESSED = "processed"
    ARCHIVED = "archived"
    FAILED = "failed"


class AuditEvent(BaseModel):
    """
    Entidade que representa um evento de auditoria
    
    Responsabilidades:
    - Armazenar informações do evento de auditoria
    - Validar dados do evento
    - Calcular hash de integridade
    - Gerenciar metadados do evento
    """
    
    # Identificação
    id: UUID = Field(default_factory=uuid4, description="ID único do evento")
    correlation_id: Optional[str] = Field(None, description="ID de correlação da requisição")
    
    # Informações do evento
    event_type: AuditEventType = Field(..., description="Tipo do evento de auditoria")
    severity: AuditSeverity = Field(default=AuditSeverity.MEDIUM, description="Severidade do evento")
    status: AuditStatus = Field(default=AuditStatus.PENDING, description="Status do processamento")
    
    # Contexto
    service_name: str = Field(..., description="Nome do serviço que gerou o evento")
    user_id: Optional[str] = Field(None, description="ID do usuário responsável")
    session_id: Optional[str] = Field(None, description="ID da sessão")
    ip_address: Optional[str] = Field(None, description="Endereço IP de origem")
    user_agent: Optional[str] = Field(None, description="User agent do cliente")
    
    # Dados do evento
    resource_type: Optional[str] = Field(None, description="Tipo de recurso afetado")
    resource_id: Optional[str] = Field(None, description="ID do recurso afetado")
    action: str = Field(..., description="Ação realizada")
    description: str = Field(..., description="Descrição detalhada do evento")
    
    # Dados adicionais
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadados adicionais")
    before_state: Optional[Dict[str, Any]] = Field(None, description="Estado anterior (para modificações)")
    after_state: Optional[Dict[str, Any]] = Field(None, description="Estado posterior (para modificações)")
    
    # Timestamps
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Timestamp do evento")
    processed_at: Optional[datetime] = Field(None, description="Timestamp do processamento")
    
    # Integridade
    checksum: Optional[str] = Field(None, description="Hash de integridade do evento")
    
    class Config:
        """Configuração do modelo"""
        use_enum_values = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }
    
    @validator('user_id')
    def validate_user_id(cls, v):
        """Valida o ID do usuário"""
        if v and len(v.strip()) == 0:
            raise ValueError("User ID não pode ser vazio")
        return v
    
    @validator('service_name')
    def validate_service_name(cls, v):
        """Valida o nome do serviço"""
        if not v or len(v.strip()) == 0:
            raise ValueError("Nome do serviço é obrigatório")
        return v.strip().lower()
    
    @validator('action')
    def validate_action(cls, v):
        """Valida a ação"""
        if not v or len(v.strip()) == 0:
            raise ValueError("Ação é obrigatória")
        return v.strip()
    
    @validator('description')
    def validate_description(cls, v):
        """Valida a descrição"""
        if not v or len(v.strip()) == 0:
            raise ValueError("Descrição é obrigatória")
        if len(v) > 1000:
            raise ValueError("Descrição não pode exceder 1000 caracteres")
        return v.strip()
    
    def calculate_checksum(self) -> str:
        """
        Calcula o hash de integridade do evento
        
        Returns:
            str: Hash SHA-256 do evento
        """
        import hashlib
        import json
        
        # Dados para o hash (excluindo campos de controle)
        data = {
            'id': str(self.id),
            'event_type': self.event_type,
            'service_name': self.service_name,
            'user_id': self.user_id,
            'action': self.action,
            'description': self.description,
            'timestamp': self.timestamp.isoformat(),
            'metadata': self.metadata,
            'before_state': self.before_state,
            'after_state': self.after_state
        }
        
        # Serializar de forma determinística
        json_str = json.dumps(data, sort_keys=True, separators=(',', ':'))
        
        # Calcular hash
        return hashlib.sha256(json_str.encode('utf-8')).hexdigest()
    
    def mark_as_processed(self) -> None:
        """Marca o evento como processado"""
        self.status = AuditStatus.PROCESSED
        self.processed_at = datetime.utcnow()
        self.checksum = self.calculate_checksum()
    
    def mark_as_failed(self) -> None:
        """Marca o evento como falhou no processamento"""
        self.status = AuditStatus.FAILED
        self.processed_at = datetime.utcnow()
    
    def is_critical(self) -> bool:
        """Verifica se o evento é crítico"""
        return self.severity == AuditSeverity.CRITICAL
    
    def is_security_related(self) -> bool:
        """Verifica se o evento é relacionado à segurança"""
        security_events = {
            AuditEventType.USER_LOGIN,
            AuditEventType.USER_LOGOUT,
            AuditEventType.POLICY_VIOLATION,
            AuditEventType.SECURITY_INCIDENT
        }
        return self.event_type in security_events
    
    def add_metadata(self, key: str, value: Any) -> None:
        """Adiciona metadados ao evento"""
        if not self.metadata:
            self.metadata = {}
        self.metadata[key] = value
    
    def get_metadata(self, key: str, default: Any = None) -> Any:
        """Obtém metadados do evento"""
        return self.metadata.get(key, default) if self.metadata else default
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o evento para dicionário"""
        return self.dict()
    
    def __str__(self) -> str:
        """Representação string do evento"""
        return f"AuditEvent(id={self.id}, type={self.event_type}, service={self.service_name}, action={self.action})"
    
    def __repr__(self) -> str:
        """Representação detalhada do evento"""
        return (f"AuditEvent(id={self.id}, type={self.event_type}, severity={self.severity}, "
                f"service={self.service_name}, user={self.user_id}, action={self.action}, "
                f"timestamp={self.timestamp})")

