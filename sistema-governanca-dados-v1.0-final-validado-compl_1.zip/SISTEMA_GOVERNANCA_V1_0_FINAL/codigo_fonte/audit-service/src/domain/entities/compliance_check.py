# Autor: carlos.morais@f1rst.com.br
"""
Entidade ComplianceCheck - Representa uma verificação de compliance
"""

from datetime import datetime
from enum import Enum
from typing import Dict, Any, Optional, List
from uuid import uuid4, UUID

from pydantic import BaseModel, Field, validator


class ComplianceFramework(str, Enum):
    """Frameworks de compliance suportados"""
    LGPD = "lgpd"
    GDPR = "gdpr"
    SOX = "sox"
    ISO27001 = "iso27001"
    PCI_DSS = "pci_dss"
    HIPAA = "hipaa"
    CUSTOM = "custom"


class ComplianceStatus(str, Enum):
    """Status da verificação de compliance"""
    COMPLIANT = "compliant"
    NON_COMPLIANT = "non_compliant"
    PARTIALLY_COMPLIANT = "partially_compliant"
    PENDING = "pending"
    ERROR = "error"


class ComplianceSeverity(str, Enum):
    """Severidade da violação de compliance"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class ComplianceRule(BaseModel):
    """Regra de compliance"""
    id: str = Field(..., description="ID da regra")
    name: str = Field(..., description="Nome da regra")
    description: str = Field(..., description="Descrição da regra")
    framework: ComplianceFramework = Field(..., description="Framework de compliance")
    severity: ComplianceSeverity = Field(..., description="Severidade da regra")
    enabled: bool = Field(default=True, description="Se a regra está ativa")


class ComplianceViolation(BaseModel):
    """Violação de compliance"""
    rule_id: str = Field(..., description="ID da regra violada")
    rule_name: str = Field(..., description="Nome da regra violada")
    description: str = Field(..., description="Descrição da violação")
    severity: ComplianceSeverity = Field(..., description="Severidade da violação")
    resource_type: str = Field(..., description="Tipo de recurso afetado")
    resource_id: str = Field(..., description="ID do recurso afetado")
    details: Dict[str, Any] = Field(default_factory=dict, description="Detalhes da violação")
    remediation_steps: List[str] = Field(default_factory=list, description="Passos para correção")


class ComplianceCheck(BaseModel):
    """
    Entidade que representa uma verificação de compliance
    
    Responsabilidades:
    - Armazenar informações da verificação de compliance
    - Gerenciar regras e violações
    - Calcular score de compliance
    - Gerar relatórios de compliance
    """
    
    # Identificação
    id: UUID = Field(default_factory=uuid4, description="ID único da verificação")
    correlation_id: Optional[str] = Field(None, description="ID de correlação")
    
    # Informações da verificação
    framework: ComplianceFramework = Field(..., description="Framework de compliance")
    check_name: str = Field(..., description="Nome da verificação")
    description: str = Field(..., description="Descrição da verificação")
    
    # Status e resultado
    status: ComplianceStatus = Field(default=ComplianceStatus.PENDING, description="Status da verificação")
    overall_score: float = Field(default=0.0, description="Score geral de compliance (0-100)")
    
    # Contexto
    resource_type: str = Field(..., description="Tipo de recurso verificado")
    resource_id: str = Field(..., description="ID do recurso verificado")
    service_name: str = Field(..., description="Nome do serviço responsável")
    
    # Regras e violações
    rules_checked: List[ComplianceRule] = Field(default_factory=list, description="Regras verificadas")
    violations: List[ComplianceViolation] = Field(default_factory=list, description="Violações encontradas")
    
    # Metadados
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Metadados adicionais")
    
    # Timestamps
    started_at: datetime = Field(default_factory=datetime.utcnow, description="Início da verificação")
    completed_at: Optional[datetime] = Field(None, description="Fim da verificação")
    next_check_at: Optional[datetime] = Field(None, description="Próxima verificação agendada")
    
    # Auditoria
    created_by: Optional[str] = Field(None, description="Usuário que criou a verificação")
    automated: bool = Field(default=True, description="Se foi uma verificação automática")
    
    class Config:
        """Configuração do modelo"""
        use_enum_values = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }
    
    @validator('check_name')
    def validate_check_name(cls, v):
        """Valida o nome da verificação"""
        if not v or len(v.strip()) == 0:
            raise ValueError("Nome da verificação é obrigatório")
        return v.strip()
    
    @validator('resource_type')
    def validate_resource_type(cls, v):
        """Valida o tipo de recurso"""
        if not v or len(v.strip()) == 0:
            raise ValueError("Tipo de recurso é obrigatório")
        return v.strip().lower()
    
    @validator('overall_score')
    def validate_score(cls, v):
        """Valida o score de compliance"""
        if v < 0 or v > 100:
            raise ValueError("Score deve estar entre 0 e 100")
        return v
    
    def add_rule(self, rule: ComplianceRule) -> None:
        """Adiciona uma regra à verificação"""
        if not self.rules_checked:
            self.rules_checked = []
        self.rules_checked.append(rule)
    
    def add_violation(self, violation: ComplianceViolation) -> None:
        """Adiciona uma violação à verificação"""
        if not self.violations:
            self.violations = []
        self.violations.append(violation)
        
        # Recalcular status baseado nas violações
        self._update_status()
    
    def _update_status(self) -> None:
        """Atualiza o status baseado nas violações"""
        if not self.violations:
            self.status = ComplianceStatus.COMPLIANT
        else:
            # Verificar se há violações críticas
            critical_violations = [v for v in self.violations if v.severity == ComplianceSeverity.CRITICAL]
            high_violations = [v for v in self.violations if v.severity == ComplianceSeverity.HIGH]
            
            if critical_violations:
                self.status = ComplianceStatus.NON_COMPLIANT
            elif high_violations:
                self.status = ComplianceStatus.PARTIALLY_COMPLIANT
            else:
                self.status = ComplianceStatus.PARTIALLY_COMPLIANT
    
    def calculate_score(self) -> float:
        """
        Calcula o score de compliance baseado nas violações
        
        Returns:
            float: Score de compliance (0-100)
        """
        if not self.rules_checked:
            return 0.0
        
        total_rules = len(self.rules_checked)
        if total_rules == 0:
            return 100.0
        
        # Calcular peso das violações
        violation_weight = 0.0
        for violation in self.violations:
            if violation.severity == ComplianceSeverity.CRITICAL:
                violation_weight += 1.0
            elif violation.severity == ComplianceSeverity.HIGH:
                violation_weight += 0.7
            elif violation.severity == ComplianceSeverity.MEDIUM:
                violation_weight += 0.4
            else:  # LOW
                violation_weight += 0.1
        
        # Calcular score (máximo de violações = total de regras)
        max_weight = total_rules
        score = max(0.0, (max_weight - violation_weight) / max_weight * 100)
        
        self.overall_score = round(score, 2)
        return self.overall_score
    
    def complete_check(self) -> None:
        """Marca a verificação como completa"""
        self.completed_at = datetime.utcnow()
        self.calculate_score()
        
        if self.status == ComplianceStatus.PENDING:
            self._update_status()
    
    def mark_as_error(self, error_message: str) -> None:
        """Marca a verificação como erro"""
        self.status = ComplianceStatus.ERROR
        self.completed_at = datetime.utcnow()
        self.add_metadata("error_message", error_message)
    
    def get_violations_by_severity(self, severity: ComplianceSeverity) -> List[ComplianceViolation]:
        """Obtém violações por severidade"""
        return [v for v in self.violations if v.severity == severity]
    
    def get_critical_violations(self) -> List[ComplianceViolation]:
        """Obtém violações críticas"""
        return self.get_violations_by_severity(ComplianceSeverity.CRITICAL)
    
    def has_violations(self) -> bool:
        """Verifica se há violações"""
        return len(self.violations) > 0
    
    def is_compliant(self) -> bool:
        """Verifica se está em compliance"""
        return self.status == ComplianceStatus.COMPLIANT
    
    def get_duration_seconds(self) -> Optional[float]:
        """Obtém a duração da verificação em segundos"""
        if self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None
    
    def add_metadata(self, key: str, value: Any) -> None:
        """Adiciona metadados à verificação"""
        if not self.metadata:
            self.metadata = {}
        self.metadata[key] = value
    
    def get_metadata(self, key: str, default: Any = None) -> Any:
        """Obtém metadados da verificação"""
        return self.metadata.get(key, default) if self.metadata else default
    
    def to_summary(self) -> Dict[str, Any]:
        """Gera um resumo da verificação"""
        return {
            "id": str(self.id),
            "framework": self.framework,
            "check_name": self.check_name,
            "status": self.status,
            "overall_score": self.overall_score,
            "total_rules": len(self.rules_checked),
            "total_violations": len(self.violations),
            "critical_violations": len(self.get_critical_violations()),
            "resource_type": self.resource_type,
            "resource_id": self.resource_id,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "duration_seconds": self.get_duration_seconds()
        }
    
    def __str__(self) -> str:
        """Representação string da verificação"""
        return f"ComplianceCheck(id={self.id}, framework={self.framework}, status={self.status}, score={self.overall_score})"
    
    def __repr__(self) -> str:
        """Representação detalhada da verificação"""
        return (f"ComplianceCheck(id={self.id}, framework={self.framework}, "
                f"check_name={self.check_name}, status={self.status}, "
                f"score={self.overall_score}, violations={len(self.violations)})")

