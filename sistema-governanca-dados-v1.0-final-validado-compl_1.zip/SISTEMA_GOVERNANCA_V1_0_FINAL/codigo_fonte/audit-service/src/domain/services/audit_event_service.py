# Autor: carlos.morais@f1rst.com.br
"""
Serviço de Domínio para Eventos de Auditoria
"""

from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from uuid import UUID

from ..entities.audit_event import AuditEvent, AuditEventType, AuditSeverity, AuditStatus


class AuditEventService:
    """
    Serviço de domínio para gerenciar eventos de auditoria
    
    Responsabilidades:
    - Criar eventos de auditoria padronizados
    - Validar regras de negócio de auditoria
    - Calcular métricas de auditoria
    - Aplicar políticas de retenção
    """
    
    def __init__(self):
        """Inicializa o serviço de eventos de auditoria"""
        self._retention_policies = {
            AuditEventType.USER_LOGIN: timedelta(days=90),
            AuditEventType.USER_LOGOUT: timedelta(days=90),
            AuditEventType.DATA_ACCESS: timedelta(days=365),
            AuditEventType.DATA_MODIFICATION: timedelta(days=2555),  # 7 anos
            AuditEventType.CONTRACT_CREATED: timedelta(days=2555),
            AuditEventType.CONTRACT_UPDATED: timedelta(days=2555),
            AuditEventType.CONTRACT_DELETED: timedelta(days=2555),
            AuditEventType.QUALITY_CHECK: timedelta(days=365),
            AuditEventType.POLICY_VIOLATION: timedelta(days=2555),
            AuditEventType.SYSTEM_ERROR: timedelta(days=90),
            AuditEventType.CONFIGURATION_CHANGE: timedelta(days=365),
            AuditEventType.BACKUP_CREATED: timedelta(days=90),
            AuditEventType.SECURITY_INCIDENT: timedelta(days=2555)
        }
    
    def create_user_login_event(
        self,
        user_id: str,
        session_id: str,
        ip_address: str,
        user_agent: str,
        correlation_id: Optional[str] = None,
        success: bool = True
    ) -> AuditEvent:
        """
        Cria evento de login de usuário
        
        Args:
            user_id: ID do usuário
            session_id: ID da sessão
            ip_address: Endereço IP
            user_agent: User agent do navegador
            correlation_id: ID de correlação
            success: Se o login foi bem-sucedido
            
        Returns:
            AuditEvent: Evento de auditoria criado
        """
        severity = AuditSeverity.LOW if success else AuditSeverity.MEDIUM
        action = "login_success" if success else "login_failed"
        description = f"Usuário {user_id} {'logou com sucesso' if success else 'falhou no login'}"
        
        event = AuditEvent(
            correlation_id=correlation_id,
            event_type=AuditEventType.USER_LOGIN,
            severity=severity,
            service_name="identity-service",
            user_id=user_id,
            session_id=session_id,
            ip_address=ip_address,
            user_agent=user_agent,
            resource_type="user_session",
            resource_id=session_id,
            action=action,
            description=description
        )
        
        event.add_metadata("login_success", success)
        event.add_metadata("authentication_method", "password")
        
        return event
    
    def create_data_access_event(
        self,
        user_id: str,
        resource_type: str,
        resource_id: str,
        action: str,
        service_name: str,
        correlation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> AuditEvent:
        """
        Cria evento de acesso a dados
        
        Args:
            user_id: ID do usuário
            resource_type: Tipo de recurso acessado
            resource_id: ID do recurso
            action: Ação realizada
            service_name: Nome do serviço
            correlation_id: ID de correlação
            metadata: Metadados adicionais
            
        Returns:
            AuditEvent: Evento de auditoria criado
        """
        description = f"Usuário {user_id} acessou {resource_type} {resource_id} via {action}"
        
        event = AuditEvent(
            correlation_id=correlation_id,
            event_type=AuditEventType.DATA_ACCESS,
            severity=AuditSeverity.LOW,
            service_name=service_name,
            user_id=user_id,
            resource_type=resource_type,
            resource_id=resource_id,
            action=action,
            description=description
        )
        
        if metadata:
            for key, value in metadata.items():
                event.add_metadata(key, value)
        
        return event
    
    def create_data_modification_event(
        self,
        user_id: str,
        resource_type: str,
        resource_id: str,
        action: str,
        service_name: str,
        before_state: Optional[Dict[str, Any]] = None,
        after_state: Optional[Dict[str, Any]] = None,
        correlation_id: Optional[str] = None
    ) -> AuditEvent:
        """
        Cria evento de modificação de dados
        
        Args:
            user_id: ID do usuário
            resource_type: Tipo de recurso modificado
            resource_id: ID do recurso
            action: Ação realizada
            service_name: Nome do serviço
            before_state: Estado anterior
            after_state: Estado posterior
            correlation_id: ID de correlação
            
        Returns:
            AuditEvent: Evento de auditoria criado
        """
        description = f"Usuário {user_id} modificou {resource_type} {resource_id} via {action}"
        
        event = AuditEvent(
            correlation_id=correlation_id,
            event_type=AuditEventType.DATA_MODIFICATION,
            severity=AuditSeverity.MEDIUM,
            service_name=service_name,
            user_id=user_id,
            resource_type=resource_type,
            resource_id=resource_id,
            action=action,
            description=description,
            before_state=before_state,
            after_state=after_state
        )
        
        # Adicionar metadados sobre as mudanças
        if before_state and after_state:
            changes = self._calculate_changes(before_state, after_state)
            event.add_metadata("fields_changed", list(changes.keys()))
            event.add_metadata("change_count", len(changes))
        
        return event
    
    def create_policy_violation_event(
        self,
        user_id: Optional[str],
        policy_name: str,
        violation_details: str,
        resource_type: str,
        resource_id: str,
        service_name: str,
        severity: AuditSeverity = AuditSeverity.HIGH,
        correlation_id: Optional[str] = None
    ) -> AuditEvent:
        """
        Cria evento de violação de política
        
        Args:
            user_id: ID do usuário (pode ser None para violações automáticas)
            policy_name: Nome da política violada
            violation_details: Detalhes da violação
            resource_type: Tipo de recurso afetado
            resource_id: ID do recurso
            service_name: Nome do serviço
            severity: Severidade da violação
            correlation_id: ID de correlação
            
        Returns:
            AuditEvent: Evento de auditoria criado
        """
        description = f"Violação da política '{policy_name}': {violation_details}"
        
        event = AuditEvent(
            correlation_id=correlation_id,
            event_type=AuditEventType.POLICY_VIOLATION,
            severity=severity,
            service_name=service_name,
            user_id=user_id,
            resource_type=resource_type,
            resource_id=resource_id,
            action="policy_violation",
            description=description
        )
        
        event.add_metadata("policy_name", policy_name)
        event.add_metadata("violation_details", violation_details)
        event.add_metadata("requires_action", severity in [AuditSeverity.HIGH, AuditSeverity.CRITICAL])
        
        return event
    
    def create_system_error_event(
        self,
        service_name: str,
        error_type: str,
        error_message: str,
        stack_trace: Optional[str] = None,
        correlation_id: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> AuditEvent:
        """
        Cria evento de erro do sistema
        
        Args:
            service_name: Nome do serviço
            error_type: Tipo do erro
            error_message: Mensagem de erro
            stack_trace: Stack trace do erro
            correlation_id: ID de correlação
            user_id: ID do usuário (se aplicável)
            
        Returns:
            AuditEvent: Evento de auditoria criado
        """
        description = f"Erro no sistema: {error_type} - {error_message}"
        
        event = AuditEvent(
            correlation_id=correlation_id,
            event_type=AuditEventType.SYSTEM_ERROR,
            severity=AuditSeverity.MEDIUM,
            service_name=service_name,
            user_id=user_id,
            resource_type="system",
            resource_id=service_name,
            action="system_error",
            description=description
        )
        
        event.add_metadata("error_type", error_type)
        event.add_metadata("error_message", error_message)
        if stack_trace:
            event.add_metadata("stack_trace", stack_trace)
        
        return event
    
    def validate_event(self, event: AuditEvent) -> List[str]:
        """
        Valida um evento de auditoria
        
        Args:
            event: Evento a ser validado
            
        Returns:
            List[str]: Lista de erros de validação (vazia se válido)
        """
        errors = []
        
        # Validações básicas
        if not event.service_name:
            errors.append("Nome do serviço é obrigatório")
        
        if not event.action:
            errors.append("Ação é obrigatória")
        
        if not event.description:
            errors.append("Descrição é obrigatória")
        
        # Validações específicas por tipo
        if event.event_type == AuditEventType.USER_LOGIN:
            if not event.user_id:
                errors.append("User ID é obrigatório para eventos de login")
            if not event.session_id:
                errors.append("Session ID é obrigatório para eventos de login")
        
        if event.event_type == AuditEventType.DATA_MODIFICATION:
            if not event.resource_type:
                errors.append("Tipo de recurso é obrigatório para modificações")
            if not event.resource_id:
                errors.append("ID do recurso é obrigatório para modificações")
        
        if event.event_type == AuditEventType.POLICY_VIOLATION:
            if not event.get_metadata("policy_name"):
                errors.append("Nome da política é obrigatório para violações")
        
        return errors
    
    def should_retain_event(self, event: AuditEvent, current_date: datetime) -> bool:
        """
        Verifica se um evento deve ser mantido baseado na política de retenção
        
        Args:
            event: Evento de auditoria
            current_date: Data atual
            
        Returns:
            bool: True se deve ser mantido, False caso contrário
        """
        retention_period = self._retention_policies.get(event.event_type, timedelta(days=365))
        expiry_date = event.timestamp + retention_period
        
        return current_date <= expiry_date
    
    def calculate_retention_date(self, event: AuditEvent) -> datetime:
        """
        Calcula a data de expiração de um evento
        
        Args:
            event: Evento de auditoria
            
        Returns:
            datetime: Data de expiração
        """
        retention_period = self._retention_policies.get(event.event_type, timedelta(days=365))
        return event.timestamp + retention_period
    
    def _calculate_changes(self, before: Dict[str, Any], after: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        """
        Calcula as mudanças entre dois estados
        
        Args:
            before: Estado anterior
            after: Estado posterior
            
        Returns:
            Dict: Dicionário com as mudanças
        """
        changes = {}
        
        # Verificar campos modificados
        all_keys = set(before.keys()) | set(after.keys())
        
        for key in all_keys:
            before_value = before.get(key)
            after_value = after.get(key)
            
            if before_value != after_value:
                changes[key] = {
                    "before": before_value,
                    "after": after_value
                }
        
        return changes
    
    def get_retention_policy(self, event_type: AuditEventType) -> timedelta:
        """
        Obtém a política de retenção para um tipo de evento
        
        Args:
            event_type: Tipo do evento
            
        Returns:
            timedelta: Período de retenção
        """
        return self._retention_policies.get(event_type, timedelta(days=365))

