# Autor: carlos.morais@f1rst.com.br
"""
Serviço de Domínio para Compliance
"""

from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from uuid import UUID

from ..entities.compliance_check import (
    ComplianceCheck, ComplianceFramework, ComplianceRule, 
    ComplianceViolation, ComplianceSeverity, ComplianceStatus
)


class ComplianceService:
    """
    Serviço de domínio para gerenciar compliance
    
    Responsabilidades:
    - Executar verificações de compliance
    - Gerenciar regras de compliance
    - Calcular scores de compliance
    - Gerar relatórios de compliance
    """
    
    def __init__(self):
        """Inicializa o serviço de compliance"""
        self._framework_rules = self._initialize_framework_rules()
    
    def _initialize_framework_rules(self) -> Dict[ComplianceFramework, List[ComplianceRule]]:
        """Inicializa as regras padrão dos frameworks"""
        return {
            ComplianceFramework.LGPD: self._get_lgpd_rules(),
            ComplianceFramework.GDPR: self._get_gdpr_rules(),
            ComplianceFramework.SOX: self._get_sox_rules(),
            ComplianceFramework.ISO27001: self._get_iso27001_rules(),
            ComplianceFramework.PCI_DSS: self._get_pci_dss_rules()
        }
    
    def create_compliance_check(
        self,
        framework: ComplianceFramework,
        resource_type: str,
        resource_id: str,
        service_name: str,
        check_name: Optional[str] = None,
        description: Optional[str] = None,
        created_by: Optional[str] = None,
        automated: bool = True
    ) -> ComplianceCheck:
        """
        Cria uma nova verificação de compliance
        
        Args:
            framework: Framework de compliance
            resource_type: Tipo de recurso
            resource_id: ID do recurso
            service_name: Nome do serviço
            check_name: Nome da verificação
            description: Descrição da verificação
            created_by: Usuário que criou
            automated: Se é automática
            
        Returns:
            ComplianceCheck: Verificação criada
        """
        if not check_name:
            check_name = f"{framework.value.upper()} Compliance Check"
        
        if not description:
            description = f"Verificação de compliance {framework.value.upper()} para {resource_type}"
        
        check = ComplianceCheck(
            framework=framework,
            check_name=check_name,
            description=description,
            resource_type=resource_type,
            resource_id=resource_id,
            service_name=service_name,
            created_by=created_by,
            automated=automated
        )
        
        # Adicionar regras do framework
        rules = self._framework_rules.get(framework, [])
        for rule in rules:
            check.add_rule(rule)
        
        return check
    
    def execute_compliance_check(
        self,
        check: ComplianceCheck,
        resource_data: Dict[str, Any]
    ) -> ComplianceCheck:
        """
        Executa uma verificação de compliance
        
        Args:
            check: Verificação a ser executada
            resource_data: Dados do recurso para verificação
            
        Returns:
            ComplianceCheck: Verificação executada
        """
        try:
            # Executar cada regra
            for rule in check.rules_checked:
                violations = self._check_rule(rule, resource_data, check.resource_type, check.resource_id)
                for violation in violations:
                    check.add_violation(violation)
            
            # Completar a verificação
            check.complete_check()
            
        except Exception as e:
            check.mark_as_error(str(e))
        
        return check
    
    def _check_rule(
        self,
        rule: ComplianceRule,
        resource_data: Dict[str, Any],
        resource_type: str,
        resource_id: str
    ) -> List[ComplianceViolation]:
        """
        Verifica uma regra específica
        
        Args:
            rule: Regra a ser verificada
            resource_data: Dados do recurso
            resource_type: Tipo do recurso
            resource_id: ID do recurso
            
        Returns:
            List[ComplianceViolation]: Lista de violações encontradas
        """
        violations = []
        
        # Implementar verificações específicas baseadas no ID da regra
        if rule.framework == ComplianceFramework.LGPD:
            violations.extend(self._check_lgpd_rule(rule, resource_data, resource_type, resource_id))
        elif rule.framework == ComplianceFramework.GDPR:
            violations.extend(self._check_gdpr_rule(rule, resource_data, resource_type, resource_id))
        elif rule.framework == ComplianceFramework.SOX:
            violations.extend(self._check_sox_rule(rule, resource_data, resource_type, resource_id))
        elif rule.framework == ComplianceFramework.ISO27001:
            violations.extend(self._check_iso27001_rule(rule, resource_data, resource_type, resource_id))
        elif rule.framework == ComplianceFramework.PCI_DSS:
            violations.extend(self._check_pci_dss_rule(rule, resource_data, resource_type, resource_id))
        
        return violations
    
    def _check_lgpd_rule(
        self,
        rule: ComplianceRule,
        resource_data: Dict[str, Any],
        resource_type: str,
        resource_id: str
    ) -> List[ComplianceViolation]:
        """Verifica regras LGPD"""
        violations = []
        
        if rule.id == "lgpd_001":  # Consentimento para dados pessoais
            if self._has_personal_data(resource_data) and not resource_data.get("consent_obtained"):
                violations.append(ComplianceViolation(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    description="Dados pessoais sem consentimento explícito",
                    severity=rule.severity,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    details={"missing_consent": True},
                    remediation_steps=[
                        "Obter consentimento explícito do titular",
                        "Documentar a base legal para o tratamento",
                        "Implementar mecanismo de revogação de consentimento"
                    ]
                ))
        
        elif rule.id == "lgpd_002":  # Finalidade específica
            if not resource_data.get("processing_purpose"):
                violations.append(ComplianceViolation(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    description="Finalidade do tratamento não especificada",
                    severity=rule.severity,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    details={"missing_purpose": True},
                    remediation_steps=[
                        "Definir finalidade específica para o tratamento",
                        "Documentar a finalidade no contrato de dados",
                        "Comunicar a finalidade aos titulares"
                    ]
                ))
        
        elif rule.id == "lgpd_003":  # Minimização de dados
            if self._has_excessive_data_collection(resource_data):
                violations.append(ComplianceViolation(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    description="Coleta excessiva de dados pessoais",
                    severity=rule.severity,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    details={"excessive_collection": True},
                    remediation_steps=[
                        "Revisar dados coletados",
                        "Remover dados desnecessários",
                        "Implementar coleta mínima necessária"
                    ]
                ))
        
        return violations
    
    def _check_gdpr_rule(
        self,
        rule: ComplianceRule,
        resource_data: Dict[str, Any],
        resource_type: str,
        resource_id: str
    ) -> List[ComplianceViolation]:
        """Verifica regras GDPR"""
        violations = []
        
        if rule.id == "gdpr_001":  # Lawful basis
            if self._has_personal_data(resource_data) and not resource_data.get("lawful_basis"):
                violations.append(ComplianceViolation(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    description="Base legal não definida para processamento de dados pessoais",
                    severity=rule.severity,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    details={"missing_lawful_basis": True},
                    remediation_steps=[
                        "Definir base legal apropriada (Art. 6 GDPR)",
                        "Documentar a base legal",
                        "Comunicar aos titulares dos dados"
                    ]
                ))
        
        elif rule.id == "gdpr_002":  # Data retention
            if not resource_data.get("retention_period"):
                violations.append(ComplianceViolation(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    description="Período de retenção não definido",
                    severity=rule.severity,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    details={"missing_retention_period": True},
                    remediation_steps=[
                        "Definir período de retenção apropriado",
                        "Implementar políticas de exclusão automática",
                        "Documentar justificativa para o período"
                    ]
                ))
        
        return violations
    
    def _check_sox_rule(
        self,
        rule: ComplianceRule,
        resource_data: Dict[str, Any],
        resource_type: str,
        resource_id: str
    ) -> List[ComplianceViolation]:
        """Verifica regras SOX"""
        violations = []
        
        if rule.id == "sox_001":  # Audit trail
            if not resource_data.get("audit_trail_enabled"):
                violations.append(ComplianceViolation(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    description="Trilha de auditoria não habilitada",
                    severity=rule.severity,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    details={"missing_audit_trail": True},
                    remediation_steps=[
                        "Habilitar trilha de auditoria",
                        "Configurar logs detalhados",
                        "Implementar monitoramento contínuo"
                    ]
                ))
        
        return violations
    
    def _check_iso27001_rule(
        self,
        rule: ComplianceRule,
        resource_data: Dict[str, Any],
        resource_type: str,
        resource_id: str
    ) -> List[ComplianceViolation]:
        """Verifica regras ISO 27001"""
        violations = []
        
        if rule.id == "iso27001_001":  # Access control
            if not resource_data.get("access_control_implemented"):
                violations.append(ComplianceViolation(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    description="Controle de acesso não implementado",
                    severity=rule.severity,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    details={"missing_access_control": True},
                    remediation_steps=[
                        "Implementar controle de acesso baseado em roles",
                        "Configurar autenticação forte",
                        "Revisar permissões regularmente"
                    ]
                ))
        
        return violations
    
    def _check_pci_dss_rule(
        self,
        rule: ComplianceRule,
        resource_data: Dict[str, Any],
        resource_type: str,
        resource_id: str
    ) -> List[ComplianceViolation]:
        """Verifica regras PCI DSS"""
        violations = []
        
        if rule.id == "pci_dss_001":  # Encryption
            if self._has_payment_data(resource_data) and not resource_data.get("encryption_enabled"):
                violations.append(ComplianceViolation(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    description="Dados de pagamento não criptografados",
                    severity=rule.severity,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    details={"missing_encryption": True},
                    remediation_steps=[
                        "Implementar criptografia forte",
                        "Usar algoritmos aprovados",
                        "Gerenciar chaves adequadamente"
                    ]
                ))
        
        return violations
    
    def _has_personal_data(self, resource_data: Dict[str, Any]) -> bool:
        """Verifica se há dados pessoais"""
        personal_data_indicators = [
            "email", "cpf", "rg", "phone", "address", "name", 
            "birth_date", "personal_id", "social_security"
        ]
        
        data_fields = resource_data.get("fields", [])
        if isinstance(data_fields, list):
            return any(field.lower() in personal_data_indicators for field in data_fields)
        
        return any(key in personal_data_indicators for key in resource_data.keys())
    
    def _has_payment_data(self, resource_data: Dict[str, Any]) -> bool:
        """Verifica se há dados de pagamento"""
        payment_data_indicators = [
            "credit_card", "card_number", "cvv", "expiry_date",
            "bank_account", "payment_info", "financial_data"
        ]
        
        data_fields = resource_data.get("fields", [])
        if isinstance(data_fields, list):
            return any(field.lower() in payment_data_indicators for field in data_fields)
        
        return any(key in payment_data_indicators for key in resource_data.keys())
    
    def _has_excessive_data_collection(self, resource_data: Dict[str, Any]) -> bool:
        """Verifica se há coleta excessiva de dados"""
        # Lógica simplificada - em produção seria mais complexa
        data_fields = resource_data.get("fields", [])
        if isinstance(data_fields, list):
            return len(data_fields) > 20  # Threshold arbitrário
        
        return len(resource_data.keys()) > 20
    
    def _get_lgpd_rules(self) -> List[ComplianceRule]:
        """Retorna regras LGPD"""
        return [
            ComplianceRule(
                id="lgpd_001",
                name="Consentimento para Dados Pessoais",
                description="Verificar se há consentimento explícito para tratamento de dados pessoais",
                framework=ComplianceFramework.LGPD,
                severity=ComplianceSeverity.HIGH
            ),
            ComplianceRule(
                id="lgpd_002",
                name="Finalidade Específica",
                description="Verificar se a finalidade do tratamento está especificada",
                framework=ComplianceFramework.LGPD,
                severity=ComplianceSeverity.MEDIUM
            ),
            ComplianceRule(
                id="lgpd_003",
                name="Minimização de Dados",
                description="Verificar se há coleta excessiva de dados pessoais",
                framework=ComplianceFramework.LGPD,
                severity=ComplianceSeverity.MEDIUM
            )
        ]
    
    def _get_gdpr_rules(self) -> List[ComplianceRule]:
        """Retorna regras GDPR"""
        return [
            ComplianceRule(
                id="gdpr_001",
                name="Base Legal",
                description="Verificar se há base legal para processamento de dados pessoais",
                framework=ComplianceFramework.GDPR,
                severity=ComplianceSeverity.HIGH
            ),
            ComplianceRule(
                id="gdpr_002",
                name="Retenção de Dados",
                description="Verificar se o período de retenção está definido",
                framework=ComplianceFramework.GDPR,
                severity=ComplianceSeverity.MEDIUM
            )
        ]
    
    def _get_sox_rules(self) -> List[ComplianceRule]:
        """Retorna regras SOX"""
        return [
            ComplianceRule(
                id="sox_001",
                name="Trilha de Auditoria",
                description="Verificar se a trilha de auditoria está habilitada",
                framework=ComplianceFramework.SOX,
                severity=ComplianceSeverity.HIGH
            )
        ]
    
    def _get_iso27001_rules(self) -> List[ComplianceRule]:
        """Retorna regras ISO 27001"""
        return [
            ComplianceRule(
                id="iso27001_001",
                name="Controle de Acesso",
                description="Verificar se o controle de acesso está implementado",
                framework=ComplianceFramework.ISO27001,
                severity=ComplianceSeverity.HIGH
            )
        ]
    
    def _get_pci_dss_rules(self) -> List[ComplianceRule]:
        """Retorna regras PCI DSS"""
        return [
            ComplianceRule(
                id="pci_dss_001",
                name="Criptografia de Dados",
                description="Verificar se dados de pagamento estão criptografados",
                framework=ComplianceFramework.PCI_DSS,
                severity=ComplianceSeverity.CRITICAL
            )
        ]
    
    def generate_compliance_report(
        self,
        checks: List[ComplianceCheck],
        framework: Optional[ComplianceFramework] = None
    ) -> Dict[str, Any]:
        """
        Gera relatório de compliance
        
        Args:
            checks: Lista de verificações
            framework: Framework específico (opcional)
            
        Returns:
            Dict: Relatório de compliance
        """
        if framework:
            checks = [c for c in checks if c.framework == framework]
        
        total_checks = len(checks)
        compliant_checks = len([c for c in checks if c.is_compliant()])
        
        # Calcular score geral
        if total_checks > 0:
            overall_score = sum(c.overall_score for c in checks) / total_checks
        else:
            overall_score = 0.0
        
        # Agrupar violações por severidade
        all_violations = []
        for check in checks:
            all_violations.extend(check.violations)
        
        violations_by_severity = {
            ComplianceSeverity.CRITICAL: len([v for v in all_violations if v.severity == ComplianceSeverity.CRITICAL]),
            ComplianceSeverity.HIGH: len([v for v in all_violations if v.severity == ComplianceSeverity.HIGH]),
            ComplianceSeverity.MEDIUM: len([v for v in all_violations if v.severity == ComplianceSeverity.MEDIUM]),
            ComplianceSeverity.LOW: len([v for v in all_violations if v.severity == ComplianceSeverity.LOW])
        }
        
        return {
            "report_generated_at": datetime.utcnow().isoformat(),
            "framework": framework.value if framework else "all",
            "summary": {
                "total_checks": total_checks,
                "compliant_checks": compliant_checks,
                "non_compliant_checks": total_checks - compliant_checks,
                "overall_score": round(overall_score, 2),
                "compliance_percentage": round((compliant_checks / total_checks * 100) if total_checks > 0 else 0, 2)
            },
            "violations": {
                "total_violations": len(all_violations),
                "by_severity": violations_by_severity
            },
            "checks": [check.to_summary() for check in checks]
        }

