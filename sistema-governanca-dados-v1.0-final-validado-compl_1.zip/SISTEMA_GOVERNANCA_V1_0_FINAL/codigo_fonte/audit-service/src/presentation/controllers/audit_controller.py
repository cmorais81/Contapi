# Autor: carlos.morais@f1rst.com.br
"""
Controller FastAPI para Eventos de Auditoria
"""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from ...application.use_cases.create_audit_event import CreateAuditEventUseCase, CreateBulkAuditEventsUseCase
from ...application.dtos.audit_dtos import (
    CreateAuditEventRequest, AuditEventResponse, AuditEventListResponse,
    AuditEventFilters, AuditMetricsResponse
)
from ...domain.entities.audit_event import AuditEventType, AuditSeverity, AuditStatus
from ..middleware.auth_middleware import get_current_user
from ..middleware.correlation_middleware import get_correlation_id


class AuditController:
    """
    Controller para endpoints de auditoria
    
    Responsabilidades:
    - Expor endpoints REST para eventos de auditoria
    - Validar dados de entrada
    - Gerenciar respostas HTTP
    - Aplicar middleware de autenticação e correlação
    """
    
    def __init__(self):
        """Inicializa o controller"""
        self.router = APIRouter(prefix="/api/v1/audit", tags=["Auditoria"])
        self._setup_routes()
    
    def _setup_routes(self):
        """Configura as rotas do controller"""
        
        @self.router.post(
            "/events",
            response_model=AuditEventResponse,
            status_code=status.HTTP_201_CREATED,
            summary="Criar evento de auditoria",
            description="Cria um novo evento de auditoria no sistema"
        )
        async def create_audit_event(
            request: CreateAuditEventRequest,
            current_user: dict = Depends(get_current_user),
            correlation_id: str = Depends(get_correlation_id),
            create_use_case: CreateAuditEventUseCase = Depends(self._get_create_use_case)
        ):
            """
            Cria um novo evento de auditoria
            
            Args:
                request: Dados do evento
                current_user: Usuário autenticado
                correlation_id: ID de correlação da requisição
                create_use_case: Use case para criação
                
            Returns:
                AuditEventResponse: Evento criado
            """
            try:
                # Adicionar correlation_id se não fornecido
                if not request.correlation_id:
                    request.correlation_id = correlation_id
                
                # Executar use case
                response = await create_use_case.execute(request)
                
                return response
                
            except ValueError as e:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=str(e)
                )
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Erro interno: {str(e)}"
                )
        
        @self.router.post(
            "/events/bulk",
            response_model=List[AuditEventResponse],
            status_code=status.HTTP_201_CREATED,
            summary="Criar múltiplos eventos de auditoria",
            description="Cria múltiplos eventos de auditoria em lote"
        )
        async def create_bulk_audit_events(
            requests: List[CreateAuditEventRequest],
            current_user: dict = Depends(get_current_user),
            correlation_id: str = Depends(get_correlation_id),
            bulk_use_case: CreateBulkAuditEventsUseCase = Depends(self._get_bulk_use_case)
        ):
            """
            Cria múltiplos eventos de auditoria em lote
            
            Args:
                requests: Lista de eventos
                current_user: Usuário autenticado
                correlation_id: ID de correlação
                bulk_use_case: Use case para criação em lote
                
            Returns:
                List[AuditEventResponse]: Eventos criados
            """
            try:
                # Adicionar correlation_id se não fornecido
                for request in requests:
                    if not request.correlation_id:
                        request.correlation_id = correlation_id
                
                # Executar use case
                responses = await bulk_use_case.execute(requests)
                
                return responses
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Erro interno: {str(e)}"
                )
        
        @self.router.get(
            "/events/{event_id}",
            response_model=AuditEventResponse,
            summary="Obter evento de auditoria",
            description="Obtém um evento de auditoria específico por ID"
        )
        async def get_audit_event(
            event_id: UUID,
            current_user: dict = Depends(get_current_user),
            audit_repository = Depends(self._get_audit_repository)
        ):
            """
            Obtém evento de auditoria por ID
            
            Args:
                event_id: ID do evento
                current_user: Usuário autenticado
                audit_repository: Repositório de auditoria
                
            Returns:
                AuditEventResponse: Evento encontrado
            """
            try:
                event = await audit_repository.get_by_id(event_id)
                
                if not event:
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=f"Evento {event_id} não encontrado"
                    )
                
                return AuditEventResponse.from_entity(event)
                
            except HTTPException:
                raise
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Erro interno: {str(e)}"
                )
        
        @self.router.get(
            "/events",
            response_model=AuditEventListResponse,
            summary="Listar eventos de auditoria",
            description="Lista eventos de auditoria com filtros e paginação"
        )
        async def list_audit_events(
            event_type: Optional[AuditEventType] = Query(None, description="Tipo do evento"),
            severity: Optional[AuditSeverity] = Query(None, description="Severidade"),
            status: Optional[AuditStatus] = Query(None, description="Status"),
            service_name: Optional[str] = Query(None, description="Nome do serviço"),
            user_id: Optional[str] = Query(None, description="ID do usuário"),
            resource_type: Optional[str] = Query(None, description="Tipo do recurso"),
            resource_id: Optional[str] = Query(None, description="ID do recurso"),
            start_date: Optional[datetime] = Query(None, description="Data inicial"),
            end_date: Optional[datetime] = Query(None, description="Data final"),
            correlation_id: Optional[str] = Query(None, description="ID de correlação"),
            page: int = Query(1, ge=1, description="Página"),
            page_size: int = Query(50, ge=1, le=1000, description="Tamanho da página"),
            order_by: str = Query("timestamp", description="Campo para ordenação"),
            order_direction: str = Query("desc", regex="^(asc|desc)$", description="Direção da ordenação"),
            current_user: dict = Depends(get_current_user),
            audit_repository = Depends(self._get_audit_repository)
        ):
            """
            Lista eventos de auditoria com filtros
            
            Args:
                Vários filtros de busca
                current_user: Usuário autenticado
                audit_repository: Repositório de auditoria
                
            Returns:
                AuditEventListResponse: Lista paginada de eventos
            """
            try:
                # Buscar eventos
                events = await audit_repository.list_with_filters(
                    event_type=event_type,
                    severity=severity,
                    status=status,
                    service_name=service_name,
                    user_id=user_id,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    start_date=start_date,
                    end_date=end_date,
                    correlation_id=correlation_id,
                    page=page,
                    page_size=page_size,
                    order_by=order_by,
                    order_direction=order_direction
                )
                
                # Contar total
                total = await audit_repository.count_with_filters(
                    event_type=event_type,
                    severity=severity,
                    status=status,
                    service_name=service_name,
                    user_id=user_id,
                    resource_type=resource_type,
                    resource_id=resource_id,
                    start_date=start_date,
                    end_date=end_date,
                    correlation_id=correlation_id
                )
                
                # Converter para DTOs
                event_responses = [AuditEventResponse.from_entity(event) for event in events]
                
                # Calcular total de páginas
                total_pages = (total + page_size - 1) // page_size
                
                return AuditEventListResponse(
                    events=event_responses,
                    total=total,
                    page=page,
                    page_size=page_size,
                    total_pages=total_pages
                )
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Erro interno: {str(e)}"
                )
        
        @self.router.get(
            "/metrics",
            response_model=AuditMetricsResponse,
            summary="Obter métricas de auditoria",
            description="Obtém métricas agregadas de auditoria para um período"
        )
        async def get_audit_metrics(
            start_date: datetime = Query(..., description="Data inicial"),
            end_date: datetime = Query(..., description="Data final"),
            current_user: dict = Depends(get_current_user),
            audit_repository = Depends(self._get_audit_repository),
            compliance_repository = Depends(self._get_compliance_repository)
        ):
            """
            Obtém métricas de auditoria
            
            Args:
                start_date: Data inicial
                end_date: Data final
                current_user: Usuário autenticado
                audit_repository: Repositório de auditoria
                compliance_repository: Repositório de compliance
                
            Returns:
                AuditMetricsResponse: Métricas calculadas
            """
            try:
                # Validar período
                if start_date >= end_date:
                    raise HTTPException(
                        status_code=status.HTTP_400_BAD_REQUEST,
                        detail="Data inicial deve ser anterior à data final"
                    )
                
                # Obter métricas de auditoria
                audit_metrics = await audit_repository.get_metrics(start_date, end_date)
                
                # Obter métricas de compliance
                compliance_metrics = await compliance_repository.get_metrics(start_date, end_date)
                
                return AuditMetricsResponse(
                    period_start=start_date,
                    period_end=end_date,
                    total_events=audit_metrics["total_events"],
                    events_by_type=audit_metrics["events_by_type"],
                    events_by_severity=audit_metrics["events_by_severity"],
                    events_by_service=audit_metrics["events_by_service"],
                    top_users=audit_metrics["top_users"],
                    compliance_score=compliance_metrics.get("average_score", 0.0),
                    critical_violations=compliance_metrics.get("critical_violations", 0)
                )
                
            except HTTPException:
                raise
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Erro interno: {str(e)}"
                )
        
        @self.router.delete(
            "/events/cleanup",
            summary="Limpar eventos expirados",
            description="Remove eventos de auditoria expirados baseado na política de retenção"
        )
        async def cleanup_expired_events(
            retention_date: datetime = Query(..., description="Data limite para retenção"),
            current_user: dict = Depends(get_current_user),
            audit_repository = Depends(self._get_audit_repository)
        ):
            """
            Remove eventos expirados
            
            Args:
                retention_date: Data limite
                current_user: Usuário autenticado
                audit_repository: Repositório de auditoria
                
            Returns:
                Dict: Resultado da limpeza
            """
            try:
                # Verificar permissões (apenas admins)
                if not current_user.get("is_admin", False):
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Operação permitida apenas para administradores"
                    )
                
                # Executar limpeza
                deleted_count = await audit_repository.delete_expired_events(retention_date)
                
                return {
                    "message": "Limpeza executada com sucesso",
                    "deleted_events": deleted_count,
                    "retention_date": retention_date.isoformat()
                }
                
            except HTTPException:
                raise
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Erro interno: {str(e)}"
                )
        
        @self.router.get(
            "/health",
            summary="Health check",
            description="Verifica a saúde do serviço de auditoria"
        )
        async def health_check():
            """
            Health check do serviço
            
            Returns:
                Dict: Status do serviço
            """
            return {
                "status": "healthy",
                "service": "audit-service",
                "timestamp": datetime.utcnow().isoformat(),
                "version": "1.2.0"
            }
    
    def _get_create_use_case(self) -> CreateAuditEventUseCase:
        """Dependency injection para CreateAuditEventUseCase"""
        # Em produção, isso seria injetado via container DI
        from ...infrastructure.repositories.postgres_audit_repository import PostgresAuditRepository
        from ...domain.services.audit_event_service import AuditEventService
        
        # Placeholder - em produção seria injetado
        audit_repository = None  # PostgresAuditRepository(session)
        audit_event_service = AuditEventService()
        
        return CreateAuditEventUseCase(audit_event_service, audit_repository)
    
    def _get_bulk_use_case(self) -> CreateBulkAuditEventsUseCase:
        """Dependency injection para CreateBulkAuditEventsUseCase"""
        create_use_case = self._get_create_use_case()
        return CreateBulkAuditEventsUseCase(create_use_case)
    
    def _get_audit_repository(self):
        """Dependency injection para audit repository"""
        # Em produção, isso seria injetado via container DI
        return None  # PostgresAuditRepository(session)
    
    def _get_compliance_repository(self):
        """Dependency injection para compliance repository"""
        # Em produção, isso seria injetado via container DI
        return None  # PostgresComplianceRepository(session)


# Instância global do controller
audit_controller = AuditController()

# Router para ser incluído na aplicação principal
router = audit_controller.router

