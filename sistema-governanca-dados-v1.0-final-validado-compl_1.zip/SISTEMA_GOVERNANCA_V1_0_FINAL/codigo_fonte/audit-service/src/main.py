# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
Audit Service V4.1 - Auditoria Centralizada
Resolve o problema de auditoria distribuída dos microserviços
Coleta, correlaciona e unifica logs de todos os serviços
"""

import asyncio
import json
import logging
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from uuid import uuid4

import httpx
from fastapi import FastAPI, HTTPException, Depends, Query, Path
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', 'config'))

try:
    from settings import get_settings
    settings = get_settings()
except ImportError:
    print("⚠️ Configurações centralizadas não encontradas, usando valores padrão")
    settings = None


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Service URLs
SERVICES = {
    "contract": "http://localhost:8001",
    "identity": "http://localhost:8002",
    "quality": "http://localhost:8003", 
    "catalog": "http://localhost:8004",
    "analytics": "http://localhost:8005",
    "workflow": "http://localhost:8006",
    "governance": "http://localhost:8007"
}

# Initialize FastAPI app
app = FastAPI(
    title="Audit Service V4.1 - Auditoria Centralizada",
    description="Coleta e correlaciona logs de todos os microserviços",
    version="4.1.0",
    contact={
        "name": " ",
        "email": "@example.com"
    }
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# HTTP client
http_client = httpx.AsyncClient(timeout=30.0)

# In-memory audit storage (em produção seria um banco)
audit_logs = []
correlated_operations = []

# Models
class AuditEvent(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    timestamp: datetime
    service: str
    user_id: Optional[str] = None
    action: str
    resource_type: str
    resource_id: Optional[str] = None
    details: Dict[str, Any] = {}
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    correlation_id: Optional[str] = None

class CorrelatedOperation(BaseModel):
    operation_id: str
    operation_type: str
    start_time: datetime
    end_time: Optional[datetime] = None
    events: List[AuditEvent]
    user_id: Optional[str] = None
    status: str = "in_progress"  # in_progress, completed, failed
    duration_ms: Optional[int] = None

class AuditQuery(BaseModel):
    resource_id: Optional[str] = None
    user_id: Optional[str] = None
    service: Optional[str] = None
    action: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    limit: int = 100

class AnomalyDetection(BaseModel):
    anomaly_type: str
    severity: str
    description: str
    events: List[str]  # Event IDs
    detected_at: datetime

# Utility functions
async def collect_service_logs(service: str, start_date: Optional[datetime] = None, 
                              end_date: Optional[datetime] = None) -> List[Dict]:
    """Coleta logs de um microserviço específico"""
    try:
        params = {}
        if start_date:
            params["start_date"] = start_date.isoformat()
        if end_date:
            params["end_date"] = end_date.isoformat()
        
        response = await http_client.get(
            f"{SERVICES[service]}/api/v1/audit/logs",
            params=params
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            logger.warning(f"Service {service} audit logs unavailable: {response.status_code}")
            return []
    
    except Exception as e:
        logger.error(f"Error collecting logs from {service}: {str(e)}")
        return []

def correlate_events(events: List[AuditEvent]) -> List[CorrelatedOperation]:
    """Correlaciona eventos relacionados em operações"""
    operations = {}
    
    for event in events:
        # Estratégias de correlação
        correlation_key = None
        
        # 1. Por correlation_id explícito
        if event.correlation_id:
            correlation_key = event.correlation_id
        
        # 2. Por resource_id + user_id + janela temporal
        elif event.resource_id and event.user_id:
            time_window = event.timestamp.replace(second=0, microsecond=0)
            correlation_key = f"{event.resource_id}_{event.user_id}_{time_window}"
        
        # 3. Por padrões de ação (create -> validate -> approve)
        elif event.action in ["create_contract", "validate_contract", "approve_contract"]:
            if event.resource_id:
                correlation_key = f"contract_workflow_{event.resource_id}"
        
        if correlation_key:
            if correlation_key not in operations:
                operations[correlation_key] = CorrelatedOperation(
                    operation_id=correlation_key,
                    operation_type=determine_operation_type(event),
                    start_time=event.timestamp,
                    events=[],
                    user_id=event.user_id
                )
            
            operations[correlation_key].events.append(event)
            
            # Atualizar timestamps
            if event.timestamp < operations[correlation_key].start_time:
                operations[correlation_key].start_time = event.timestamp
            
            if (operations[correlation_key].end_time is None or 
                event.timestamp > operations[correlation_key].end_time):
                operations[correlation_key].end_time = event.timestamp
    
    # Calcular durações e status
    for operation in operations.values():
        if operation.end_time:
            duration = (operation.end_time - operation.start_time).total_seconds() * 1000
            operation.duration_ms = int(duration)
            
            # Determinar status baseado nos eventos
            if any("error" in e.action.lower() or "fail" in e.action.lower() for e in operation.events):
                operation.status = "failed"
            elif any("complete" in e.action.lower() or "approve" in e.action.lower() for e in operation.events):
                operation.status = "completed"
    
    return list(operations.values())

def determine_operation_type(event: AuditEvent) -> str:
    """Determina o tipo de operação baseado no evento"""
    if "contract" in event.action.lower():
        return "contract_management"
    elif "quality" in event.action.lower():
        return "quality_validation"
    elif "user" in event.action.lower():
        return "user_management"
    elif "compliance" in event.action.lower():
        return "compliance_assessment"
    else:
        return "general_operation"

def detect_anomalies(events: List[AuditEvent]) -> List[AnomalyDetection]:
    """Detecta anomalias nos eventos de auditoria"""
    anomalies = []
    
    # 1. Múltiplas tentativas de login falhadas
    failed_logins = [e for e in events if "login" in e.action.lower() and "fail" in e.action.lower()]
    user_failures = {}
    
    for event in failed_logins:
        if event.user_id:
            user_failures[event.user_id] = user_failures.get(event.user_id, 0) + 1
    
    for user_id, count in user_failures.items():
        if count >= 5:
            anomalies.append(AnomalyDetection(
                anomaly_type="suspicious_login_attempts",
                severity="high",
                description=f"User {user_id} had {count} failed login attempts",
                events=[e.id for e in failed_logins if e.user_id == user_id],
                detected_at=datetime.utcnow()
            ))
    
    # 2. Atividade fora do horário comercial
    business_hours = range(8, 18)  # 8h às 18h
    after_hours = [e for e in events if e.timestamp.hour not in business_hours]
    
    if len(after_hours) > 10:  # Mais de 10 eventos fora do horário
        anomalies.append(AnomalyDetection(
            anomaly_type="after_hours_activity",
            severity="medium",
            description=f"{len(after_hours)} events detected outside business hours",
            events=[e.id for e in after_hours[:10]],  # Primeiros 10
            detected_at=datetime.utcnow()
        ))
    
    # 3. Operações de alta frequência
    user_activity = {}
    for event in events:
        if event.user_id:
            user_activity[event.user_id] = user_activity.get(event.user_id, 0) + 1
    
    for user_id, count in user_activity.items():
        if count > 100:  # Mais de 100 operações
            anomalies.append(AnomalyDetection(
                anomaly_type="high_frequency_operations",
                severity="medium",
                description=f"User {user_id} performed {count} operations",
                events=[e.id for e in events if e.user_id == user_id][:10],
                detected_at=datetime.utcnow()
            ))
    
    return anomalies

def create_unified_timeline(operations: List[CorrelatedOperation]) -> List[Dict]:
    """Cria timeline unificada das operações"""
    timeline = []
    
    for operation in operations:
        timeline.append({
            "timestamp": operation.start_time,
            "type": "operation_start",
            "operation_id": operation.operation_id,
            "operation_type": operation.operation_type,
            "user_id": operation.user_id,
            "events_count": len(operation.events),
            "status": operation.status
        })
        
        if operation.end_time:
            timeline.append({
                "timestamp": operation.end_time,
                "type": "operation_end",
                "operation_id": operation.operation_id,
                "operation_type": operation.operation_type,
                "duration_ms": operation.duration_ms,
                "status": operation.status
            })
    
    # Ordenar por timestamp
    timeline.sort(key=lambda x: x["timestamp"])
    
    return timeline

# API Endpoints

@app.get("/")
async def root():
    """Audit Service information"""
    return {
        "name": "Audit Service V4.1 - Auditoria Centralizada",
        "version": "4.1.0",
        "description": "Coleta e correlaciona logs de todos os microserviços",
        "services_monitored": list(SERVICES.keys()),
        "features": [
            "Coleta distribuída de logs",
            "Correlação automática de eventos",
            "Detecção de anomalias",
            "Timeline unificada",
            "Rastreamento de operações"
        ],
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/health")
async def health_check():
    """Health check do audit service"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "audit_logs_count": len(audit_logs),
        "correlated_operations_count": len(correlated_operations),
        "services_monitored": len(SERVICES)
    }

# SOLUÇÃO 4: AUDITOR CENTRALIZADA
@app.get("/api/v1/audit/logs/consolidated")
async def consolidated_audit_logs(
    resource_id: Optional[str] = Query(None, description="Filter by resource ID"),
    user_id: Optional[str] = Query(None, description="Filter by user ID"),
    service: Optional[str] = Query(None, description="Filter by service"),
    start_date: Optional[datetime] = Query(None, description="Start date filter"),
    end_date: Optional[datetime] = Query(None, description="End date filter"),
    limit: int = Query(100, description="Maximum number of events")
):
    """
    Auditoria centralizada - SOLUÇÃO PARA PROBLEMA 4
    Coleta logs de todos os microserviços e correlaciona eventos
    Compatível 100% com V3.2 mas com funcionalidades avançadas
    """
    try:
        # Coletar logs de todos os serviços em paralelo
        tasks = [
            collect_service_logs(service_name, start_date, end_date)
            for service_name in SERVICES.keys()
        ]
        
        all_service_logs = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Consolidar todos os logs
        all_events = []
        
        for i, service_name in enumerate(SERVICES.keys()):
            if not isinstance(all_service_logs[i], Exception):
                service_logs = all_service_logs[i]
                
                # Converter para AuditEvent
                for log in service_logs:
                    event = AuditEvent(
                        timestamp=datetime.fromisoformat(log.get("timestamp", datetime.utcnow().isoformat())),
                        service=service_name,
                        user_id=log.get("user_id"),
                        action=log.get("action", "unknown"),
                        resource_type=log.get("resource_type", "unknown"),
                        resource_id=log.get("resource_id"),
                        details=log.get("details", {}),
                        ip_address=log.get("ip_address"),
                        user_agent=log.get("user_agent"),
                        correlation_id=log.get("correlation_id")
                    )
                    all_events.append(event)
        
        # Aplicar filtros
        filtered_events = all_events
        
        if resource_id:
            filtered_events = [e for e in filtered_events if e.resource_id == resource_id]
        
        if user_id:
            filtered_events = [e for e in filtered_events if e.user_id == user_id]
        
        if service:
            filtered_events = [e for e in filtered_events if e.service == service]
        
        # Ordenar por timestamp (mais recente primeiro)
        filtered_events.sort(key=lambda x: x.timestamp, reverse=True)
        
        # Aplicar limite
        filtered_events = filtered_events[:limit]
        
        # Correlacionar eventos
        correlated_ops = correlate_events(filtered_events)
        
        # Criar timeline unificada
        timeline = create_unified_timeline(correlated_ops)
        
        # Detectar anomalias
        anomalies = detect_anomalies(filtered_events)
        
        # Análise de atividade por usuário
        user_activity = {}
        for event in filtered_events:
            if event.user_id:
                if event.user_id not in user_activity:
                    user_activity[event.user_id] = {
                        "total_events": 0,
                        "services_used": set(),
                        "actions": set(),
                        "first_activity": event.timestamp,
                        "last_activity": event.timestamp
                    }
                
                user_activity[event.user_id]["total_events"] += 1
                user_activity[event.user_id]["services_used"].add(event.service)
                user_activity[event.user_id]["actions"].add(event.action)
                
                if event.timestamp < user_activity[event.user_id]["first_activity"]:
                    user_activity[event.user_id]["first_activity"] = event.timestamp
                if event.timestamp > user_activity[event.user_id]["last_activity"]:
                    user_activity[event.user_id]["last_activity"] = event.timestamp
        
        # Converter sets para lists para JSON
        for user_data in user_activity.values():
            user_data["services_used"] = list(user_data["services_used"])
            user_data["actions"] = list(user_data["actions"])
        
        # Rastreamento de recursos
        resource_history = {}
        if resource_id:
            resource_events = [e for e in filtered_events if e.resource_id == resource_id]
            resource_history = {
                "resource_id": resource_id,
                "total_events": len(resource_events),
                "timeline": [
                    {
                        "timestamp": e.timestamp,
                        "service": e.service,
                        "action": e.action,
                        "user_id": e.user_id,
                        "details": e.details
                    }
                    for e in sorted(resource_events, key=lambda x: x.timestamp)
                ]
            }
        
        return {
            "total_events": len(filtered_events),
            "correlated_operations": len(correlated_ops),
            "timeline": timeline[:20],  # Primeiros 20 eventos da timeline
            "events_by_service": {
                service: len([e for e in filtered_events if e.service == service])
                for service in SERVICES.keys()
            },
            "user_activity": user_activity,
            "resource_history": resource_history,
            "anomalies": [a.dict() for a in anomalies],
            "operations": [op.dict() for op in correlated_ops[:10]],  # Primeiras 10 operações
            "events": [e.dict() for e in filtered_events[:50]],  # Primeiros 50 eventos
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error in consolidated audit logs: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Audit consolidation failed: {str(e)}")

@app.get("/api/v1/audit/operations/{operation_id}")
async def get_operation_details(operation_id: str):
    """Detalhes de uma operação correlacionada específica"""
    # Buscar operação
    operation = next((op for op in correlated_operations if op.operation_id == operation_id), None)
    
    if not operation:
        raise HTTPException(status_code=404, detail="Operation not found")
    
    return operation.dict()

@app.get("/api/v1/audit/anomalies")
async def get_anomalies(
    severity: Optional[str] = Query(None, description="Filter by severity"),
    limit: int = Query(50, description="Maximum number of anomalies")
):
    """Lista anomalias detectadas"""
    # Coletar logs recentes para análise
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(hours=24)  # Últimas 24 horas
    
    # Simular coleta de logs (em produção seria do banco)
    recent_events = []
    
    anomalies = detect_anomalies(recent_events)
    
    if severity:
        anomalies = [a for a in anomalies if a.severity == severity]
    
    return {
        "total_anomalies": len(anomalies),
        "anomalies": [a.dict() for a in anomalies[:limit]],
        "analysis_period": {
            "start": start_date.isoformat(),
            "end": end_date.isoformat()
        },
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/api/v1/audit/timeline")
async def get_audit_timeline(
    hours: int = Query(24, description="Hours to look back"),
    limit: int = Query(100, description="Maximum timeline events")
):
    """Timeline unificada de eventos"""
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(hours=hours)
    
    # Coletar logs do período
    tasks = [
        collect_service_logs(service_name, start_date, end_date)
        for service_name in SERVICES.keys()
    ]
    
    all_service_logs = await asyncio.gather(*tasks, return_exceptions=True)
    
    # Processar eventos
    all_events = []
    for i, service_name in enumerate(SERVICES.keys()):
        if not isinstance(all_service_logs[i], Exception):
            service_logs = all_service_logs[i]
            for log in service_logs:
                event = AuditEvent(
                    timestamp=datetime.fromisoformat(log.get("timestamp", datetime.utcnow().isoformat())),
                    service=service_name,
                    user_id=log.get("user_id"),
                    action=log.get("action", "unknown"),
                    resource_type=log.get("resource_type", "unknown"),
                    resource_id=log.get("resource_id"),
                    details=log.get("details", {})
                )
                all_events.append(event)
    
    # Correlacionar e criar timeline
    operations = correlate_events(all_events)
    timeline = create_unified_timeline(operations)
    
    return {
        "timeline": timeline[:limit],
        "period": {
            "start": start_date.isoformat(),
            "end": end_date.isoformat(),
            "hours": hours
        },
        "total_operations": len(operations),
        "total_events": len(all_events),
        "timestamp": datetime.utcnow().isoformat()
    }

# Startup event
@app.on_event("startup")
async def startup_event():
    logger.info("Starting Audit Service V4.1")
    logger.info("Checking service connectivity...")
    
    # Verificar conectividade com todos os serviços
    for service_name in SERVICES.keys():
        try:
            response = await http_client.get(f"{SERVICES[service_name]}/health", timeout=5.0)
            if response.status_code == 200:
                logger.info(f"Service {service_name}: connected")
            else:
                logger.warning(f"Service {service_name}: unhealthy ({response.status_code})")
        except Exception as e:
            logger.warning(f"Service {service_name}: unavailable ({str(e)})")
    
    logger.info("Audit Service V4.1 started successfully")

# Shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Shutting down Audit Service V4.1")
    await http_client.aclose()

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8009,
        reload=False,
        log_level="info"
    )

