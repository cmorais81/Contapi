# Autor: carlos.morais@f1rst.com.br
"""
Repositório PostgreSQL para Eventos de Auditoria
"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import UUID

import asyncpg
from sqlalchemy import select, insert, update, delete, and_, or_, desc, asc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ...domain.entities.audit_event import AuditEvent, AuditEventType, AuditSeverity, AuditStatus
from ..database.models import AuditEventModel


class PostgresAuditRepository:
    """
    Repositório PostgreSQL para eventos de auditoria
    
    Responsabilidades:
    - Persistir eventos de auditoria
    - Consultar eventos com filtros
    - Gerenciar retenção de dados
    - Otimizar consultas para performance
    """
    
    def __init__(self, session: AsyncSession):
        """
        Inicializa o repositório
        
        Args:
            session: Sessão do SQLAlchemy
        """
        self._session = session
    
    async def create(self, event: AuditEvent) -> AuditEvent:
        """
        Cria um novo evento de auditoria
        
        Args:
            event: Evento a ser criado
            
        Returns:
            AuditEvent: Evento criado
            
        Raises:
            Exception: Se ocorrer erro na persistência
        """
        try:
            # Converter entidade para modelo
            model = self._entity_to_model(event)
            
            # Inserir no banco
            self._session.add(model)
            await self._session.commit()
            await self._session.refresh(model)
            
            # Converter modelo para entidade
            return self._model_to_entity(model)
            
        except Exception as e:
            await self._session.rollback()
            raise Exception(f"Erro ao criar evento de auditoria: {str(e)}")
    
    async def update(self, event: AuditEvent) -> AuditEvent:
        """
        Atualiza um evento de auditoria
        
        Args:
            event: Evento a ser atualizado
            
        Returns:
            AuditEvent: Evento atualizado
            
        Raises:
            Exception: Se ocorrer erro na atualização
        """
        try:
            # Buscar modelo existente
            stmt = select(AuditEventModel).where(AuditEventModel.id == event.id)
            result = await self._session.execute(stmt)
            model = result.scalar_one_or_none()
            
            if not model:
                raise ValueError(f"Evento {event.id} não encontrado")
            
            # Atualizar campos
            self._update_model_from_entity(model, event)
            
            # Salvar alterações
            await self._session.commit()
            await self._session.refresh(model)
            
            return self._model_to_entity(model)
            
        except Exception as e:
            await self._session.rollback()
            raise Exception(f"Erro ao atualizar evento de auditoria: {str(e)}")
    
    async def get_by_id(self, event_id: UUID) -> Optional[AuditEvent]:
        """
        Obtém evento por ID
        
        Args:
            event_id: ID do evento
            
        Returns:
            Optional[AuditEvent]: Evento encontrado ou None
        """
        try:
            stmt = select(AuditEventModel).where(AuditEventModel.id == event_id)
            result = await self._session.execute(stmt)
            model = result.scalar_one_or_none()
            
            return self._model_to_entity(model) if model else None
            
        except Exception as e:
            raise Exception(f"Erro ao buscar evento {event_id}: {str(e)}")
    
    async def list_with_filters(
        self,
        event_type: Optional[AuditEventType] = None,
        severity: Optional[AuditSeverity] = None,
        status: Optional[AuditStatus] = None,
        service_name: Optional[str] = None,
        user_id: Optional[str] = None,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        correlation_id: Optional[str] = None,
        page: int = 1,
        page_size: int = 50,
        order_by: str = "timestamp",
        order_direction: str = "desc"
    ) -> List[AuditEvent]:
        """
        Lista eventos com filtros
        
        Args:
            event_type: Tipo do evento
            severity: Severidade
            status: Status
            service_name: Nome do serviço
            user_id: ID do usuário
            resource_type: Tipo do recurso
            resource_id: ID do recurso
            start_date: Data inicial
            end_date: Data final
            correlation_id: ID de correlação
            page: Página
            page_size: Tamanho da página
            order_by: Campo para ordenação
            order_direction: Direção da ordenação
            
        Returns:
            List[AuditEvent]: Lista de eventos
        """
        try:
            # Construir query base
            stmt = select(AuditEventModel)
            
            # Aplicar filtros
            conditions = []
            
            if event_type:
                conditions.append(AuditEventModel.event_type == event_type.value)
            
            if severity:
                conditions.append(AuditEventModel.severity == severity.value)
            
            if status:
                conditions.append(AuditEventModel.status == status.value)
            
            if service_name:
                conditions.append(AuditEventModel.service_name == service_name)
            
            if user_id:
                conditions.append(AuditEventModel.user_id == user_id)
            
            if resource_type:
                conditions.append(AuditEventModel.resource_type == resource_type)
            
            if resource_id:
                conditions.append(AuditEventModel.resource_id == resource_id)
            
            if correlation_id:
                conditions.append(AuditEventModel.correlation_id == correlation_id)
            
            if start_date:
                conditions.append(AuditEventModel.timestamp >= start_date)
            
            if end_date:
                conditions.append(AuditEventModel.timestamp <= end_date)
            
            # Aplicar condições
            if conditions:
                stmt = stmt.where(and_(*conditions))
            
            # Aplicar ordenação
            order_column = getattr(AuditEventModel, order_by, AuditEventModel.timestamp)
            if order_direction.lower() == "desc":
                stmt = stmt.order_by(desc(order_column))
            else:
                stmt = stmt.order_by(asc(order_column))
            
            # Aplicar paginação
            offset = (page - 1) * page_size
            stmt = stmt.offset(offset).limit(page_size)
            
            # Executar query
            result = await self._session.execute(stmt)
            models = result.scalars().all()
            
            # Converter para entidades
            return [self._model_to_entity(model) for model in models]
            
        except Exception as e:
            raise Exception(f"Erro ao listar eventos de auditoria: {str(e)}")
    
    async def count_with_filters(
        self,
        event_type: Optional[AuditEventType] = None,
        severity: Optional[AuditSeverity] = None,
        status: Optional[AuditStatus] = None,
        service_name: Optional[str] = None,
        user_id: Optional[str] = None,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        correlation_id: Optional[str] = None
    ) -> int:
        """
        Conta eventos com filtros
        
        Args:
            Mesmos filtros do list_with_filters
            
        Returns:
            int: Número de eventos
        """
        try:
            from sqlalchemy import func
            
            # Construir query de contagem
            stmt = select(func.count(AuditEventModel.id))
            
            # Aplicar mesmos filtros do list_with_filters
            conditions = []
            
            if event_type:
                conditions.append(AuditEventModel.event_type == event_type.value)
            
            if severity:
                conditions.append(AuditEventModel.severity == severity.value)
            
            if status:
                conditions.append(AuditEventModel.status == status.value)
            
            if service_name:
                conditions.append(AuditEventModel.service_name == service_name)
            
            if user_id:
                conditions.append(AuditEventModel.user_id == user_id)
            
            if resource_type:
                conditions.append(AuditEventModel.resource_type == resource_type)
            
            if resource_id:
                conditions.append(AuditEventModel.resource_id == resource_id)
            
            if correlation_id:
                conditions.append(AuditEventModel.correlation_id == correlation_id)
            
            if start_date:
                conditions.append(AuditEventModel.timestamp >= start_date)
            
            if end_date:
                conditions.append(AuditEventModel.timestamp <= end_date)
            
            # Aplicar condições
            if conditions:
                stmt = stmt.where(and_(*conditions))
            
            # Executar query
            result = await self._session.execute(stmt)
            return result.scalar()
            
        except Exception as e:
            raise Exception(f"Erro ao contar eventos de auditoria: {str(e)}")
    
    async def delete_expired_events(self, retention_date: datetime) -> int:
        """
        Remove eventos expirados baseado na política de retenção
        
        Args:
            retention_date: Data limite para retenção
            
        Returns:
            int: Número de eventos removidos
        """
        try:
            # Buscar eventos expirados
            stmt = select(AuditEventModel).where(AuditEventModel.timestamp < retention_date)
            result = await self._session.execute(stmt)
            expired_events = result.scalars().all()
            
            count = len(expired_events)
            
            if count > 0:
                # Remover eventos
                delete_stmt = delete(AuditEventModel).where(AuditEventModel.timestamp < retention_date)
                await self._session.execute(delete_stmt)
                await self._session.commit()
            
            return count
            
        except Exception as e:
            await self._session.rollback()
            raise Exception(f"Erro ao remover eventos expirados: {str(e)}")
    
    async def get_metrics(
        self,
        start_date: datetime,
        end_date: datetime
    ) -> Dict[str, Any]:
        """
        Obtém métricas de auditoria para um período
        
        Args:
            start_date: Data inicial
            end_date: Data final
            
        Returns:
            Dict: Métricas calculadas
        """
        try:
            from sqlalchemy import func
            
            # Total de eventos
            total_stmt = select(func.count(AuditEventModel.id)).where(
                and_(
                    AuditEventModel.timestamp >= start_date,
                    AuditEventModel.timestamp <= end_date
                )
            )
            total_result = await self._session.execute(total_stmt)
            total_events = total_result.scalar()
            
            # Eventos por tipo
            type_stmt = select(
                AuditEventModel.event_type,
                func.count(AuditEventModel.id)
            ).where(
                and_(
                    AuditEventModel.timestamp >= start_date,
                    AuditEventModel.timestamp <= end_date
                )
            ).group_by(AuditEventModel.event_type)
            
            type_result = await self._session.execute(type_stmt)
            events_by_type = {row[0]: row[1] for row in type_result}
            
            # Eventos por severidade
            severity_stmt = select(
                AuditEventModel.severity,
                func.count(AuditEventModel.id)
            ).where(
                and_(
                    AuditEventModel.timestamp >= start_date,
                    AuditEventModel.timestamp <= end_date
                )
            ).group_by(AuditEventModel.severity)
            
            severity_result = await self._session.execute(severity_stmt)
            events_by_severity = {row[0]: row[1] for row in severity_result}
            
            # Eventos por serviço
            service_stmt = select(
                AuditEventModel.service_name,
                func.count(AuditEventModel.id)
            ).where(
                and_(
                    AuditEventModel.timestamp >= start_date,
                    AuditEventModel.timestamp <= end_date
                )
            ).group_by(AuditEventModel.service_name)
            
            service_result = await self._session.execute(service_stmt)
            events_by_service = {row[0]: row[1] for row in service_result}
            
            # Top usuários
            user_stmt = select(
                AuditEventModel.user_id,
                func.count(AuditEventModel.id)
            ).where(
                and_(
                    AuditEventModel.timestamp >= start_date,
                    AuditEventModel.timestamp <= end_date,
                    AuditEventModel.user_id.isnot(None)
                )
            ).group_by(AuditEventModel.user_id).order_by(desc(func.count(AuditEventModel.id))).limit(10)
            
            user_result = await self._session.execute(user_stmt)
            top_users = [{"user_id": row[0], "event_count": row[1]} for row in user_result]
            
            return {
                "total_events": total_events,
                "events_by_type": events_by_type,
                "events_by_severity": events_by_severity,
                "events_by_service": events_by_service,
                "top_users": top_users
            }
            
        except Exception as e:
            raise Exception(f"Erro ao calcular métricas de auditoria: {str(e)}")
    
    def _entity_to_model(self, event: AuditEvent) -> AuditEventModel:
        """
        Converte entidade para modelo SQLAlchemy
        
        Args:
            event: Entidade de evento
            
        Returns:
            AuditEventModel: Modelo SQLAlchemy
        """
        return AuditEventModel(
            id=event.id,
            correlation_id=event.correlation_id,
            event_type=event.event_type.value,
            severity=event.severity.value,
            status=event.status.value,
            service_name=event.service_name,
            user_id=event.user_id,
            session_id=event.session_id,
            ip_address=event.ip_address,
            user_agent=event.user_agent,
            resource_type=event.resource_type,
            resource_id=event.resource_id,
            action=event.action,
            description=event.description,
            metadata=event.metadata,
            before_state=event.before_state,
            after_state=event.after_state,
            timestamp=event.timestamp,
            processed_at=event.processed_at,
            checksum=event.checksum
        )
    
    def _model_to_entity(self, model: AuditEventModel) -> AuditEvent:
        """
        Converte modelo SQLAlchemy para entidade
        
        Args:
            model: Modelo SQLAlchemy
            
        Returns:
            AuditEvent: Entidade de evento
        """
        return AuditEvent(
            id=model.id,
            correlation_id=model.correlation_id,
            event_type=AuditEventType(model.event_type),
            severity=AuditSeverity(model.severity),
            status=AuditStatus(model.status),
            service_name=model.service_name,
            user_id=model.user_id,
            session_id=model.session_id,
            ip_address=model.ip_address,
            user_agent=model.user_agent,
            resource_type=model.resource_type,
            resource_id=model.resource_id,
            action=model.action,
            description=model.description,
            metadata=model.metadata or {},
            before_state=model.before_state,
            after_state=model.after_state,
            timestamp=model.timestamp,
            processed_at=model.processed_at,
            checksum=model.checksum
        )
    
    def _update_model_from_entity(self, model: AuditEventModel, event: AuditEvent) -> None:
        """
        Atualiza modelo com dados da entidade
        
        Args:
            model: Modelo a ser atualizado
            event: Entidade com novos dados
        """
        model.correlation_id = event.correlation_id
        model.event_type = event.event_type.value
        model.severity = event.severity.value
        model.status = event.status.value
        model.service_name = event.service_name
        model.user_id = event.user_id
        model.session_id = event.session_id
        model.ip_address = event.ip_address
        model.user_agent = event.user_agent
        model.resource_type = event.resource_type
        model.resource_id = event.resource_id
        model.action = event.action
        model.description = event.description
        model.metadata = event.metadata
        model.before_state = event.before_state
        model.after_state = event.after_state
        model.processed_at = event.processed_at
        model.checksum = event.checksum

