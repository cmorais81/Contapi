# Autor: carlos.morais@f1rst.com.br
"""
Modelos SQLAlchemy para o Audit Service
"""

from datetime import datetime
from typing import Dict, Any, Optional
from uuid import UUID, uuid4

from sqlalchemy import Column, String, DateTime, Text, JSON, Enum as SQLEnum, Boolean, Float, Integer
from sqlalchemy.dialects.postgresql import UUID as PostgresUUID
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

Base = declarative_base()


class AuditEventModel(Base):
    """
    Modelo SQLAlchemy para eventos de auditoria
    """
    __tablename__ = "audit_events"
    
    # Identificação
    id = Column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    correlation_id = Column(String(255), nullable=True, index=True)
    
    # Informações do evento
    event_type = Column(String(50), nullable=False, index=True)
    severity = Column(String(20), nullable=False, index=True)
    status = Column(String(20), nullable=False, default="pending", index=True)
    
    # Contexto
    service_name = Column(String(100), nullable=False, index=True)
    user_id = Column(String(255), nullable=True, index=True)
    session_id = Column(String(255), nullable=True, index=True)
    ip_address = Column(String(45), nullable=True)  # IPv6 support
    user_agent = Column(Text, nullable=True)
    
    # Dados do evento
    resource_type = Column(String(100), nullable=True, index=True)
    resource_id = Column(String(255), nullable=True, index=True)
    action = Column(String(100), nullable=False, index=True)
    description = Column(Text, nullable=False)
    
    # Dados adicionais (JSON)
    metadata = Column(JSON, nullable=True)
    before_state = Column(JSON, nullable=True)
    after_state = Column(JSON, nullable=True)
    
    # Timestamps
    timestamp = Column(DateTime(timezone=True), nullable=False, default=func.now(), index=True)
    processed_at = Column(DateTime(timezone=True), nullable=True)
    
    # Integridade
    checksum = Column(String(64), nullable=True)  # SHA-256
    
    # Auditoria do modelo
    created_at = Column(DateTime(timezone=True), nullable=False, default=func.now())
    updated_at = Column(DateTime(timezone=True), nullable=False, default=func.now(), onupdate=func.now())
    
    def __repr__(self):
        return f"<AuditEvent(id={self.id}, type={self.event_type}, service={self.service_name})>"


class ComplianceCheckModel(Base):
    """
    Modelo SQLAlchemy para verificações de compliance
    """
    __tablename__ = "compliance_checks"
    
    # Identificação
    id = Column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    correlation_id = Column(String(255), nullable=True, index=True)
    
    # Informações da verificação
    framework = Column(String(50), nullable=False, index=True)
    check_name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # Status e resultado
    status = Column(String(30), nullable=False, default="pending", index=True)
    overall_score = Column(Float, nullable=False, default=0.0)
    
    # Contexto
    resource_type = Column(String(100), nullable=False, index=True)
    resource_id = Column(String(255), nullable=False, index=True)
    service_name = Column(String(100), nullable=False, index=True)
    
    # Dados da verificação (JSON)
    rules_checked = Column(JSON, nullable=True)
    violations = Column(JSON, nullable=True)
    metadata = Column(JSON, nullable=True)
    
    # Timestamps
    started_at = Column(DateTime(timezone=True), nullable=False, default=func.now(), index=True)
    completed_at = Column(DateTime(timezone=True), nullable=True)
    next_check_at = Column(DateTime(timezone=True), nullable=True, index=True)
    
    # Auditoria
    created_by = Column(String(255), nullable=True)
    automated = Column(Boolean, nullable=False, default=True)
    
    # Auditoria do modelo
    created_at = Column(DateTime(timezone=True), nullable=False, default=func.now())
    updated_at = Column(DateTime(timezone=True), nullable=False, default=func.now(), onupdate=func.now())
    
    def __repr__(self):
        return f"<ComplianceCheck(id={self.id}, framework={self.framework}, status={self.status})>"


class AuditMetricsModel(Base):
    """
    Modelo SQLAlchemy para métricas agregadas de auditoria
    """
    __tablename__ = "audit_metrics"
    
    # Identificação
    id = Column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Período das métricas
    period_start = Column(DateTime(timezone=True), nullable=False, index=True)
    period_end = Column(DateTime(timezone=True), nullable=False, index=True)
    period_type = Column(String(20), nullable=False)  # hourly, daily, weekly, monthly
    
    # Métricas agregadas
    total_events = Column(Integer, nullable=False, default=0)
    events_by_type = Column(JSON, nullable=True)
    events_by_severity = Column(JSON, nullable=True)
    events_by_service = Column(JSON, nullable=True)
    top_users = Column(JSON, nullable=True)
    
    # Métricas de compliance
    total_compliance_checks = Column(Integer, nullable=False, default=0)
    average_compliance_score = Column(Float, nullable=False, default=0.0)
    total_violations = Column(Integer, nullable=False, default=0)
    critical_violations = Column(Integer, nullable=False, default=0)
    
    # Timestamps
    calculated_at = Column(DateTime(timezone=True), nullable=False, default=func.now())
    
    # Auditoria do modelo
    created_at = Column(DateTime(timezone=True), nullable=False, default=func.now())
    updated_at = Column(DateTime(timezone=True), nullable=False, default=func.now(), onupdate=func.now())
    
    def __repr__(self):
        return f"<AuditMetrics(period={self.period_start} to {self.period_end}, type={self.period_type})>"


class AuditRetentionPolicyModel(Base):
    """
    Modelo SQLAlchemy para políticas de retenção de auditoria
    """
    __tablename__ = "audit_retention_policies"
    
    # Identificação
    id = Column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Configuração da política
    event_type = Column(String(50), nullable=False, unique=True, index=True)
    retention_days = Column(Integer, nullable=False)
    enabled = Column(Boolean, nullable=False, default=True)
    
    # Configurações adicionais
    archive_before_delete = Column(Boolean, nullable=False, default=False)
    archive_location = Column(String(500), nullable=True)
    
    # Metadados
    description = Column(Text, nullable=True)
    created_by = Column(String(255), nullable=True)
    
    # Timestamps
    last_applied = Column(DateTime(timezone=True), nullable=True)
    
    # Auditoria do modelo
    created_at = Column(DateTime(timezone=True), nullable=False, default=func.now())
    updated_at = Column(DateTime(timezone=True), nullable=False, default=func.now(), onupdate=func.now())
    
    def __repr__(self):
        return f"<AuditRetentionPolicy(event_type={self.event_type}, retention_days={self.retention_days})>"


class ComplianceScheduleModel(Base):
    """
    Modelo SQLAlchemy para agendamentos de verificações de compliance
    """
    __tablename__ = "compliance_schedules"
    
    # Identificação
    id = Column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Configuração do agendamento
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    cron_expression = Column(String(100), nullable=False)
    enabled = Column(Boolean, nullable=False, default=True)
    
    # Configuração da verificação
    framework = Column(String(50), nullable=False, index=True)
    resource_type = Column(String(100), nullable=False)
    resource_id = Column(String(255), nullable=True)  # Null para verificações gerais
    service_name = Column(String(100), nullable=False)
    
    # Dados da tarefa (JSON)
    task_data = Column(JSON, nullable=False)
    
    # Controle de execução
    last_run = Column(DateTime(timezone=True), nullable=True)
    next_run = Column(DateTime(timezone=True), nullable=True, index=True)
    run_count = Column(Integer, nullable=False, default=0)
    failure_count = Column(Integer, nullable=False, default=0)
    last_error = Column(Text, nullable=True)
    
    # Auditoria
    created_by = Column(String(255), nullable=True)
    
    # Auditoria do modelo
    created_at = Column(DateTime(timezone=True), nullable=False, default=func.now())
    updated_at = Column(DateTime(timezone=True), nullable=False, default=func.now(), onupdate=func.now())
    
    def __repr__(self):
        return f"<ComplianceSchedule(id={self.id}, name={self.name}, framework={self.framework})>"


class AuditConfigurationModel(Base):
    """
    Modelo SQLAlchemy para configurações do serviço de auditoria
    """
    __tablename__ = "audit_configurations"
    
    # Identificação
    id = Column(PostgresUUID(as_uuid=True), primary_key=True, default=uuid4)
    
    # Configuração
    key = Column(String(100), nullable=False, unique=True, index=True)
    value = Column(JSON, nullable=False)
    data_type = Column(String(20), nullable=False)  # string, integer, boolean, json
    
    # Metadados
    description = Column(Text, nullable=True)
    category = Column(String(50), nullable=True, index=True)
    is_sensitive = Column(Boolean, nullable=False, default=False)
    
    # Controle
    created_by = Column(String(255), nullable=True)
    last_modified_by = Column(String(255), nullable=True)
    
    # Auditoria do modelo
    created_at = Column(DateTime(timezone=True), nullable=False, default=func.now())
    updated_at = Column(DateTime(timezone=True), nullable=False, default=func.now(), onupdate=func.now())
    
    def __repr__(self):
        return f"<AuditConfiguration(key={self.key}, category={self.category})>"


# Índices adicionais para otimização de consultas
from sqlalchemy import Index

# Índices compostos para consultas frequentes
Index('idx_audit_events_service_type_timestamp', 
      AuditEventModel.service_name, 
      AuditEventModel.event_type, 
      AuditEventModel.timestamp)

Index('idx_audit_events_user_timestamp', 
      AuditEventModel.user_id, 
      AuditEventModel.timestamp)

Index('idx_audit_events_resource_timestamp', 
      AuditEventModel.resource_type, 
      AuditEventModel.resource_id, 
      AuditEventModel.timestamp)

Index('idx_compliance_checks_framework_status', 
      ComplianceCheckModel.framework, 
      ComplianceCheckModel.status)

Index('idx_compliance_checks_resource_started', 
      ComplianceCheckModel.resource_type, 
      ComplianceCheckModel.resource_id, 
      ComplianceCheckModel.started_at)

Index('idx_audit_metrics_period_type', 
      AuditMetricsModel.period_start, 
      AuditMetricsModel.period_end, 
      AuditMetricsModel.period_type)

