# Autor: carlos.morais@f1rst.com.br
"""
Use Case: Executar Verificação de Compliance
"""

from typing import List, Dict, Any, Optional
from uuid import UUID

from ...domain.entities.compliance_check import ComplianceCheck, ComplianceFramework
from ...domain.services.compliance_service import ComplianceService
from ..dtos.audit_dtos import CreateComplianceCheckRequest, ComplianceCheckResponse, ComplianceReportRequest, ComplianceReportResponse


class ExecuteComplianceCheckUseCase:
    """
    Use Case para executar verificações de compliance
    
    Responsabilidades:
    - Criar verificação de compliance
    - Executar verificação usando serviço de domínio
    - Persistir resultados
    - Retornar resposta padronizada
    """
    
    def __init__(self, compliance_service: ComplianceService, compliance_repository, audit_repository):
        """
        Inicializa o use case
        
        Args:
            compliance_service: Serviço de domínio para compliance
            compliance_repository: Repositório de compliance
            audit_repository: Repositório de auditoria
        """
        self._compliance_service = compliance_service
        self._compliance_repository = compliance_repository
        self._audit_repository = audit_repository
    
    async def execute(self, request: CreateComplianceCheckRequest) -> ComplianceCheckResponse:
        """
        Executa a verificação de compliance
        
        Args:
            request: Dados da requisição
            
        Returns:
            ComplianceCheckResponse: Resposta com o resultado da verificação
            
        Raises:
            ValueError: Se os dados são inválidos
            Exception: Se ocorrer erro na execução
        """
        # Validar dados de entrada
        self._validate_request(request)
        
        # Criar verificação de compliance
        check = self._compliance_service.create_compliance_check(
            framework=request.framework,
            resource_type=request.resource_type,
            resource_id=request.resource_id,
            service_name=request.service_name,
            check_name=request.check_name,
            description=request.description,
            created_by=request.created_by,
            automated=request.automated
        )
        
        # Persistir verificação inicial
        try:
            saved_check = await self._compliance_repository.create(check)
            
            # Executar verificação
            executed_check = self._compliance_service.execute_compliance_check(
                saved_check, 
                request.resource_data
            )
            
            # Atualizar com resultados
            updated_check = await self._compliance_repository.update(executed_check)
            
            # Criar evento de auditoria para a verificação
            await self._create_audit_event(updated_check)
            
            return ComplianceCheckResponse.from_entity(updated_check)
            
        except Exception as e:
            # Marcar verificação como erro se já foi criada
            if 'saved_check' in locals():
                saved_check.mark_as_error(str(e))
                await self._compliance_repository.update(saved_check)
            
            raise Exception(f"Erro ao executar verificação de compliance: {str(e)}")
    
    def _validate_request(self, request: CreateComplianceCheckRequest) -> None:
        """
        Valida os dados da requisição
        
        Args:
            request: Dados da requisição
            
        Raises:
            ValueError: Se os dados são inválidos
        """
        if not request.resource_type:
            raise ValueError("Tipo do recurso é obrigatório")
        
        if not request.resource_id:
            raise ValueError("ID do recurso é obrigatório")
        
        if not request.service_name:
            raise ValueError("Nome do serviço é obrigatório")
        
        if not request.resource_data:
            raise ValueError("Dados do recurso são obrigatórios para verificação")
        
        # Validar framework
        if request.framework not in ComplianceFramework:
            raise ValueError(f"Framework {request.framework} não é suportado")
    
    async def _create_audit_event(self, check: ComplianceCheck) -> None:
        """
        Cria evento de auditoria para a verificação de compliance
        
        Args:
            check: Verificação de compliance executada
        """
        from ...domain.entities.audit_event import AuditEvent, AuditEventType, AuditSeverity
        
        # Determinar severidade baseada no resultado
        if check.has_violations():
            critical_violations = check.get_critical_violations()
            severity = AuditSeverity.CRITICAL if critical_violations else AuditSeverity.HIGH
        else:
            severity = AuditSeverity.LOW
        
        # Criar evento
        event = AuditEvent(
            correlation_id=str(check.id),
            event_type=AuditEventType.QUALITY_CHECK,  # Usar como proxy para compliance
            severity=severity,
            service_name="audit-service",
            user_id=check.created_by,
            resource_type=check.resource_type,
            resource_id=check.resource_id,
            action="compliance_check",
            description=f"Verificação de compliance {check.framework.value} executada: {check.status.value}"
        )
        
        # Adicionar metadados
        event.add_metadata("framework", check.framework.value)
        event.add_metadata("check_name", check.check_name)
        event.add_metadata("overall_score", check.overall_score)
        event.add_metadata("total_violations", len(check.violations))
        event.add_metadata("critical_violations", len(check.get_critical_violations()))
        
        # Persistir evento
        await self._audit_repository.create(event)


class GetComplianceCheckUseCase:
    """
    Use Case para obter verificação de compliance
    """
    
    def __init__(self, compliance_repository):
        """
        Inicializa o use case
        
        Args:
            compliance_repository: Repositório de compliance
        """
        self._compliance_repository = compliance_repository
    
    async def execute(self, check_id: UUID) -> ComplianceCheckResponse:
        """
        Obtém verificação de compliance por ID
        
        Args:
            check_id: ID da verificação
            
        Returns:
            ComplianceCheckResponse: Dados da verificação
            
        Raises:
            ValueError: Se a verificação não for encontrada
        """
        check = await self._compliance_repository.get_by_id(check_id)
        if not check:
            raise ValueError(f"Verificação de compliance {check_id} não encontrada")
        
        return ComplianceCheckResponse.from_entity(check)


class ListComplianceChecksUseCase:
    """
    Use Case para listar verificações de compliance
    """
    
    def __init__(self, compliance_repository):
        """
        Inicializa o use case
        
        Args:
            compliance_repository: Repositório de compliance
        """
        self._compliance_repository = compliance_repository
    
    async def execute(
        self,
        framework: Optional[ComplianceFramework] = None,
        resource_type: Optional[str] = None,
        service_name: Optional[str] = None,
        page: int = 1,
        page_size: int = 50
    ) -> List[ComplianceCheckResponse]:
        """
        Lista verificações de compliance com filtros
        
        Args:
            framework: Framework específico
            resource_type: Tipo de recurso
            service_name: Nome do serviço
            page: Página
            page_size: Tamanho da página
            
        Returns:
            List[ComplianceCheckResponse]: Lista de verificações
        """
        checks = await self._compliance_repository.list_with_filters(
            framework=framework,
            resource_type=resource_type,
            service_name=service_name,
            page=page,
            page_size=page_size
        )
        
        return [ComplianceCheckResponse.from_entity(check) for check in checks]


class GenerateComplianceReportUseCase:
    """
    Use Case para gerar relatório de compliance
    """
    
    def __init__(self, compliance_service: ComplianceService, compliance_repository):
        """
        Inicializa o use case
        
        Args:
            compliance_service: Serviço de domínio para compliance
            compliance_repository: Repositório de compliance
        """
        self._compliance_service = compliance_service
        self._compliance_repository = compliance_repository
    
    async def execute(self, request: ComplianceReportRequest) -> ComplianceReportResponse:
        """
        Gera relatório de compliance
        
        Args:
            request: Parâmetros do relatório
            
        Returns:
            ComplianceReportResponse: Relatório gerado
        """
        from uuid import uuid4
        from datetime import datetime
        
        # Obter verificações baseadas nos filtros
        checks = await self._compliance_repository.list_for_report(
            framework=request.framework,
            start_date=request.start_date,
            end_date=request.end_date,
            resource_types=request.resource_types,
            services=request.services
        )
        
        # Gerar relatório usando serviço de domínio
        report_data = self._compliance_service.generate_compliance_report(
            checks=checks,
            framework=request.framework
        )
        
        # Adicionar recomendações se solicitado
        recommendations = None
        if request.include_recommendations:
            recommendations = self._generate_recommendations(checks)
        
        # Criar resposta
        response = ComplianceReportResponse(
            report_id=uuid4(),
            generated_at=datetime.utcnow(),
            framework=request.framework.value if request.framework else None,
            period_start=request.start_date,
            period_end=request.end_date,
            summary=report_data["summary"],
            violations=report_data["violations"],
            checks=report_data["checks"],
            recommendations=recommendations
        )
        
        return response
    
    def _generate_recommendations(self, checks: List[ComplianceCheck]) -> List[str]:
        """
        Gera recomendações baseadas nas verificações
        
        Args:
            checks: Lista de verificações
            
        Returns:
            List[str]: Lista de recomendações
        """
        recommendations = []
        
        # Analisar violações mais comuns
        violation_counts = {}
        for check in checks:
            for violation in check.violations:
                rule_id = violation.rule_id
                violation_counts[rule_id] = violation_counts.get(rule_id, 0) + 1
        
        # Gerar recomendações para violações mais frequentes
        sorted_violations = sorted(violation_counts.items(), key=lambda x: x[1], reverse=True)
        
        for rule_id, count in sorted_violations[:5]:  # Top 5 violações
            if rule_id.startswith("lgpd_"):
                recommendations.append(f"Implementar controles LGPD para regra {rule_id} (violada {count} vezes)")
            elif rule_id.startswith("gdpr_"):
                recommendations.append(f"Implementar controles GDPR para regra {rule_id} (violada {count} vezes)")
            elif rule_id.startswith("sox_"):
                recommendations.append(f"Implementar controles SOX para regra {rule_id} (violada {count} vezes)")
        
        # Recomendações gerais baseadas no score
        total_checks = len(checks)
        if total_checks > 0:
            avg_score = sum(check.overall_score for check in checks) / total_checks
            
            if avg_score < 70:
                recommendations.append("Score de compliance baixo - revisar políticas e implementar controles adicionais")
            elif avg_score < 85:
                recommendations.append("Score de compliance médio - focar nas violações de alta severidade")
        
        return recommendations


class ScheduleComplianceCheckUseCase:
    """
    Use Case para agendar verificações de compliance
    """
    
    def __init__(self, compliance_repository, scheduler_service):
        """
        Inicializa o use case
        
        Args:
            compliance_repository: Repositório de compliance
            scheduler_service: Serviço de agendamento
        """
        self._compliance_repository = compliance_repository
        self._scheduler_service = scheduler_service
    
    async def execute(
        self,
        request: CreateComplianceCheckRequest,
        schedule_cron: str,
        enabled: bool = True
    ) -> Dict[str, Any]:
        """
        Agenda verificação de compliance recorrente
        
        Args:
            request: Dados da verificação
            schedule_cron: Expressão cron para agendamento
            enabled: Se o agendamento está ativo
            
        Returns:
            Dict: Informações do agendamento criado
        """
        from uuid import uuid4
        
        # Validar expressão cron
        if not self._scheduler_service.validate_cron(schedule_cron):
            raise ValueError("Expressão cron inválida")
        
        # Criar agendamento
        schedule_id = uuid4()
        schedule_data = {
            "id": str(schedule_id),
            "name": f"Compliance Check - {request.framework.value}",
            "description": f"Verificação automática de compliance para {request.resource_type}",
            "cron_expression": schedule_cron,
            "enabled": enabled,
            "task_type": "compliance_check",
            "task_data": request.dict(),
            "created_at": datetime.utcnow().isoformat()
        }
        
        # Persistir agendamento
        await self._scheduler_service.create_schedule(schedule_data)
        
        return {
            "schedule_id": str(schedule_id),
            "cron_expression": schedule_cron,
            "enabled": enabled,
            "next_run": self._scheduler_service.get_next_run_time(schedule_cron)
        }

