# Autor: carlos.morais@f1rst.com.br
"""
Use Case: Criar Evento de Auditoria
"""

from typing import Dict, Any, Optional
from uuid import UUID

from ...domain.entities.audit_event import AuditEvent, AuditEventType, AuditSeverity
from ...domain.services.audit_event_service import AuditEventService
from ..dtos.audit_dtos import CreateAuditEventRequest, AuditEventResponse


class CreateAuditEventUseCase:
    """
    Use Case para criar eventos de auditoria
    
    Responsabilidades:
    - Validar dados de entrada
    - Criar evento de auditoria usando o serviço de domínio
    - Persistir o evento
    - Retornar resposta padronizada
    """
    
    def __init__(self, audit_event_service: AuditEventService, audit_repository):
        """
        Inicializa o use case
        
        Args:
            audit_event_service: Serviço de domínio para eventos
            audit_repository: Repositório de auditoria
        """
        self._audit_event_service = audit_event_service
        self._audit_repository = audit_repository
    
    async def execute(self, request: CreateAuditEventRequest) -> AuditEventResponse:
        """
        Executa a criação do evento de auditoria
        
        Args:
            request: Dados da requisição
            
        Returns:
            AuditEventResponse: Resposta com o evento criado
            
        Raises:
            ValueError: Se os dados são inválidos
            Exception: Se ocorrer erro na persistência
        """
        # Validar dados de entrada
        self._validate_request(request)
        
        # Criar evento baseado no tipo
        event = self._create_event_by_type(request)
        
        # Validar evento criado
        validation_errors = self._audit_event_service.validate_event(event)
        if validation_errors:
            raise ValueError(f"Evento inválido: {', '.join(validation_errors)}")
        
        # Calcular checksum de integridade
        event.checksum = event.calculate_checksum()
        
        # Persistir evento
        try:
            saved_event = await self._audit_repository.create(event)
            
            # Marcar como processado
            saved_event.mark_as_processed()
            await self._audit_repository.update(saved_event)
            
            return AuditEventResponse.from_entity(saved_event)
            
        except Exception as e:
            # Marcar como falhou
            event.mark_as_failed()
            await self._audit_repository.update(event)
            raise Exception(f"Erro ao persistir evento de auditoria: {str(e)}")
    
    def _validate_request(self, request: CreateAuditEventRequest) -> None:
        """
        Valida os dados da requisição
        
        Args:
            request: Dados da requisição
            
        Raises:
            ValueError: Se os dados são inválidos
        """
        if not request.service_name:
            raise ValueError("Nome do serviço é obrigatório")
        
        if not request.action:
            raise ValueError("Ação é obrigatória")
        
        if not request.description:
            raise ValueError("Descrição é obrigatória")
        
        if not request.event_type:
            raise ValueError("Tipo do evento é obrigatório")
        
        # Validações específicas por tipo de evento
        if request.event_type == AuditEventType.USER_LOGIN:
            if not request.user_id:
                raise ValueError("User ID é obrigatório para eventos de login")
        
        if request.event_type == AuditEventType.DATA_MODIFICATION:
            if not request.resource_type or not request.resource_id:
                raise ValueError("Tipo e ID do recurso são obrigatórios para modificações")
        
        if request.event_type == AuditEventType.POLICY_VIOLATION:
            if not request.metadata or not request.metadata.get("policy_name"):
                raise ValueError("Nome da política é obrigatório para violações")
    
    def _create_event_by_type(self, request: CreateAuditEventRequest) -> AuditEvent:
        """
        Cria evento baseado no tipo
        
        Args:
            request: Dados da requisição
            
        Returns:
            AuditEvent: Evento criado
        """
        if request.event_type == AuditEventType.USER_LOGIN:
            return self._audit_event_service.create_user_login_event(
                user_id=request.user_id,
                session_id=request.session_id or "",
                ip_address=request.ip_address or "",
                user_agent=request.user_agent or "",
                correlation_id=request.correlation_id,
                success=request.metadata.get("login_success", True) if request.metadata else True
            )
        
        elif request.event_type == AuditEventType.DATA_ACCESS:
            return self._audit_event_service.create_data_access_event(
                user_id=request.user_id,
                resource_type=request.resource_type,
                resource_id=request.resource_id,
                action=request.action,
                service_name=request.service_name,
                correlation_id=request.correlation_id,
                metadata=request.metadata
            )
        
        elif request.event_type == AuditEventType.DATA_MODIFICATION:
            return self._audit_event_service.create_data_modification_event(
                user_id=request.user_id,
                resource_type=request.resource_type,
                resource_id=request.resource_id,
                action=request.action,
                service_name=request.service_name,
                before_state=request.before_state,
                after_state=request.after_state,
                correlation_id=request.correlation_id
            )
        
        elif request.event_type == AuditEventType.POLICY_VIOLATION:
            policy_name = request.metadata.get("policy_name", "") if request.metadata else ""
            violation_details = request.metadata.get("violation_details", request.description) if request.metadata else request.description
            
            return self._audit_event_service.create_policy_violation_event(
                user_id=request.user_id,
                policy_name=policy_name,
                violation_details=violation_details,
                resource_type=request.resource_type,
                resource_id=request.resource_id,
                service_name=request.service_name,
                severity=request.severity or AuditSeverity.HIGH,
                correlation_id=request.correlation_id
            )
        
        elif request.event_type == AuditEventType.SYSTEM_ERROR:
            error_type = request.metadata.get("error_type", "unknown") if request.metadata else "unknown"
            stack_trace = request.metadata.get("stack_trace") if request.metadata else None
            
            return self._audit_event_service.create_system_error_event(
                service_name=request.service_name,
                error_type=error_type,
                error_message=request.description,
                stack_trace=stack_trace,
                correlation_id=request.correlation_id,
                user_id=request.user_id
            )
        
        else:
            # Evento genérico
            event = AuditEvent(
                correlation_id=request.correlation_id,
                event_type=request.event_type,
                severity=request.severity or AuditSeverity.MEDIUM,
                service_name=request.service_name,
                user_id=request.user_id,
                session_id=request.session_id,
                ip_address=request.ip_address,
                user_agent=request.user_agent,
                resource_type=request.resource_type,
                resource_id=request.resource_id,
                action=request.action,
                description=request.description,
                metadata=request.metadata or {},
                before_state=request.before_state,
                after_state=request.after_state
            )
            
            return event


class CreateBulkAuditEventsUseCase:
    """
    Use Case para criar múltiplos eventos de auditoria em lote
    """
    
    def __init__(self, create_audit_event_use_case: CreateAuditEventUseCase):
        """
        Inicializa o use case
        
        Args:
            create_audit_event_use_case: Use case para criar evento individual
        """
        self._create_audit_event_use_case = create_audit_event_use_case
    
    async def execute(self, requests: list[CreateAuditEventRequest]) -> list[AuditEventResponse]:
        """
        Executa a criação de múltiplos eventos
        
        Args:
            requests: Lista de requisições
            
        Returns:
            list[AuditEventResponse]: Lista de respostas
        """
        responses = []
        errors = []
        
        for i, request in enumerate(requests):
            try:
                response = await self._create_audit_event_use_case.execute(request)
                responses.append(response)
            except Exception as e:
                errors.append(f"Evento {i}: {str(e)}")
                # Continuar processando os outros eventos
                continue
        
        if errors:
            # Log dos erros mas não falha completamente
            print(f"Erros no processamento em lote: {errors}")
        
        return responses

