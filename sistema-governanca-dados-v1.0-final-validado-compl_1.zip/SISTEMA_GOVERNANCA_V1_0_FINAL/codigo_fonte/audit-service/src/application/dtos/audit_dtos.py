# Autor: carlos.morais@f1rst.com.br
"""
DTOs para o Audit Service
"""

from datetime import datetime
from typing import Dict, Any, Optional, List
from uuid import UUID

from pydantic import BaseModel, Field, validator

from ...domain.entities.audit_event import AuditEvent, AuditEventType, AuditSeverity, AuditStatus
from ...domain.entities.compliance_check import ComplianceCheck, ComplianceFramework, ComplianceStatus


class CreateAuditEventRequest(BaseModel):
    """DTO para criação de evento de auditoria"""
    
    # Campos obrigatórios
    event_type: AuditEventType = Field(..., description="Tipo do evento")
    service_name: str = Field(..., description="Nome do serviço")
    action: str = Field(..., description="Ação realizada")
    description: str = Field(..., description="Descrição do evento")
    
    # Campos opcionais
    correlation_id: Optional[str] = Field(None, description="ID de correlação")
    severity: Optional[AuditSeverity] = Field(AuditSeverity.MEDIUM, description="Severidade")
    user_id: Optional[str] = Field(None, description="ID do usuário")
    session_id: Optional[str] = Field(None, description="ID da sessão")
    ip_address: Optional[str] = Field(None, description="Endereço IP")
    user_agent: Optional[str] = Field(None, description="User agent")
    resource_type: Optional[str] = Field(None, description="Tipo do recurso")
    resource_id: Optional[str] = Field(None, description="ID do recurso")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Metadados")
    before_state: Optional[Dict[str, Any]] = Field(None, description="Estado anterior")
    after_state: Optional[Dict[str, Any]] = Field(None, description="Estado posterior")
    
    class Config:
        use_enum_values = True
    
    @validator('service_name')
    def validate_service_name(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError("Nome do serviço não pode ser vazio")
        return v.strip().lower()
    
    @validator('action')
    def validate_action(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError("Ação não pode ser vazia")
        return v.strip()
    
    @validator('description')
    def validate_description(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError("Descrição não pode ser vazia")
        if len(v) > 1000:
            raise ValueError("Descrição não pode exceder 1000 caracteres")
        return v.strip()


class AuditEventResponse(BaseModel):
    """DTO para resposta de evento de auditoria"""
    
    id: UUID = Field(..., description="ID do evento")
    correlation_id: Optional[str] = Field(None, description="ID de correlação")
    event_type: AuditEventType = Field(..., description="Tipo do evento")
    severity: AuditSeverity = Field(..., description="Severidade")
    status: AuditStatus = Field(..., description="Status")
    service_name: str = Field(..., description="Nome do serviço")
    user_id: Optional[str] = Field(None, description="ID do usuário")
    resource_type: Optional[str] = Field(None, description="Tipo do recurso")
    resource_id: Optional[str] = Field(None, description="ID do recurso")
    action: str = Field(..., description="Ação")
    description: str = Field(..., description="Descrição")
    timestamp: datetime = Field(..., description="Timestamp")
    processed_at: Optional[datetime] = Field(None, description="Processado em")
    checksum: Optional[str] = Field(None, description="Checksum de integridade")
    
    class Config:
        use_enum_values = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }
    
    @classmethod
    def from_entity(cls, event: AuditEvent) -> "AuditEventResponse":
        """Cria DTO a partir da entidade"""
        return cls(
            id=event.id,
            correlation_id=event.correlation_id,
            event_type=event.event_type,
            severity=event.severity,
            status=event.status,
            service_name=event.service_name,
            user_id=event.user_id,
            resource_type=event.resource_type,
            resource_id=event.resource_id,
            action=event.action,
            description=event.description,
            timestamp=event.timestamp,
            processed_at=event.processed_at,
            checksum=event.checksum
        )


class AuditEventListResponse(BaseModel):
    """DTO para lista de eventos de auditoria"""
    
    events: List[AuditEventResponse] = Field(..., description="Lista de eventos")
    total: int = Field(..., description="Total de eventos")
    page: int = Field(..., description="Página atual")
    page_size: int = Field(..., description="Tamanho da página")
    total_pages: int = Field(..., description="Total de páginas")


class AuditEventFilters(BaseModel):
    """DTO para filtros de busca de eventos"""
    
    event_type: Optional[AuditEventType] = Field(None, description="Tipo do evento")
    severity: Optional[AuditSeverity] = Field(None, description="Severidade")
    status: Optional[AuditStatus] = Field(None, description="Status")
    service_name: Optional[str] = Field(None, description="Nome do serviço")
    user_id: Optional[str] = Field(None, description="ID do usuário")
    resource_type: Optional[str] = Field(None, description="Tipo do recurso")
    resource_id: Optional[str] = Field(None, description="ID do recurso")
    start_date: Optional[datetime] = Field(None, description="Data inicial")
    end_date: Optional[datetime] = Field(None, description="Data final")
    correlation_id: Optional[str] = Field(None, description="ID de correlação")
    
    class Config:
        use_enum_values = True


class CreateComplianceCheckRequest(BaseModel):
    """DTO para criação de verificação de compliance"""
    
    framework: ComplianceFramework = Field(..., description="Framework de compliance")
    resource_type: str = Field(..., description="Tipo do recurso")
    resource_id: str = Field(..., description="ID do recurso")
    service_name: str = Field(..., description="Nome do serviço")
    check_name: Optional[str] = Field(None, description="Nome da verificação")
    description: Optional[str] = Field(None, description="Descrição")
    resource_data: Dict[str, Any] = Field(..., description="Dados do recurso para verificação")
    created_by: Optional[str] = Field(None, description="Criado por")
    automated: bool = Field(True, description="Verificação automática")
    
    class Config:
        use_enum_values = True
    
    @validator('resource_type')
    def validate_resource_type(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError("Tipo do recurso não pode ser vazio")
        return v.strip().lower()
    
    @validator('service_name')
    def validate_service_name(cls, v):
        if not v or len(v.strip()) == 0:
            raise ValueError("Nome do serviço não pode ser vazio")
        return v.strip().lower()


class ComplianceCheckResponse(BaseModel):
    """DTO para resposta de verificação de compliance"""
    
    id: UUID = Field(..., description="ID da verificação")
    framework: ComplianceFramework = Field(..., description="Framework")
    check_name: str = Field(..., description="Nome da verificação")
    description: str = Field(..., description="Descrição")
    status: ComplianceStatus = Field(..., description="Status")
    overall_score: float = Field(..., description="Score geral")
    resource_type: str = Field(..., description="Tipo do recurso")
    resource_id: str = Field(..., description="ID do recurso")
    service_name: str = Field(..., description="Nome do serviço")
    total_rules: int = Field(..., description="Total de regras")
    total_violations: int = Field(..., description="Total de violações")
    critical_violations: int = Field(..., description="Violações críticas")
    started_at: datetime = Field(..., description="Iniciado em")
    completed_at: Optional[datetime] = Field(None, description="Completado em")
    duration_seconds: Optional[float] = Field(None, description="Duração em segundos")
    
    class Config:
        use_enum_values = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }
    
    @classmethod
    def from_entity(cls, check: ComplianceCheck) -> "ComplianceCheckResponse":
        """Cria DTO a partir da entidade"""
        return cls(
            id=check.id,
            framework=check.framework,
            check_name=check.check_name,
            description=check.description,
            status=check.status,
            overall_score=check.overall_score,
            resource_type=check.resource_type,
            resource_id=check.resource_id,
            service_name=check.service_name,
            total_rules=len(check.rules_checked),
            total_violations=len(check.violations),
            critical_violations=len(check.get_critical_violations()),
            started_at=check.started_at,
            completed_at=check.completed_at,
            duration_seconds=check.get_duration_seconds()
        )


class ComplianceViolationResponse(BaseModel):
    """DTO para violação de compliance"""
    
    rule_id: str = Field(..., description="ID da regra")
    rule_name: str = Field(..., description="Nome da regra")
    description: str = Field(..., description="Descrição da violação")
    severity: str = Field(..., description="Severidade")
    resource_type: str = Field(..., description="Tipo do recurso")
    resource_id: str = Field(..., description="ID do recurso")
    details: Dict[str, Any] = Field(..., description="Detalhes")
    remediation_steps: List[str] = Field(..., description="Passos para correção")


class ComplianceReportRequest(BaseModel):
    """DTO para solicitação de relatório de compliance"""
    
    framework: Optional[ComplianceFramework] = Field(None, description="Framework específico")
    start_date: Optional[datetime] = Field(None, description="Data inicial")
    end_date: Optional[datetime] = Field(None, description="Data final")
    resource_types: Optional[List[str]] = Field(None, description="Tipos de recursos")
    services: Optional[List[str]] = Field(None, description="Serviços específicos")
    include_violations: bool = Field(True, description="Incluir violações")
    include_recommendations: bool = Field(True, description="Incluir recomendações")
    
    class Config:
        use_enum_values = True


class ComplianceReportResponse(BaseModel):
    """DTO para relatório de compliance"""
    
    report_id: UUID = Field(..., description="ID do relatório")
    generated_at: datetime = Field(..., description="Gerado em")
    framework: Optional[str] = Field(None, description="Framework")
    period_start: Optional[datetime] = Field(None, description="Início do período")
    period_end: Optional[datetime] = Field(None, description="Fim do período")
    summary: Dict[str, Any] = Field(..., description="Resumo")
    violations: Dict[str, Any] = Field(..., description="Violações")
    checks: List[Dict[str, Any]] = Field(..., description="Verificações")
    recommendations: Optional[List[str]] = Field(None, description="Recomendações")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }


class AuditMetricsResponse(BaseModel):
    """DTO para métricas de auditoria"""
    
    period_start: datetime = Field(..., description="Início do período")
    period_end: datetime = Field(..., description="Fim do período")
    total_events: int = Field(..., description="Total de eventos")
    events_by_type: Dict[str, int] = Field(..., description="Eventos por tipo")
    events_by_severity: Dict[str, int] = Field(..., description="Eventos por severidade")
    events_by_service: Dict[str, int] = Field(..., description="Eventos por serviço")
    top_users: List[Dict[str, Any]] = Field(..., description="Usuários mais ativos")
    compliance_score: float = Field(..., description="Score de compliance")
    critical_violations: int = Field(..., description="Violações críticas")
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

