# Autor: carlos.morais@f1rst.com.br
"""
Main refatorado do Audit Service seguindo Clean Architecture
"""

import asyncio
import logging
import os
import sys
from contextlib import asynccontextmanager
from datetime import datetime
from typing import Dict, Any

import uvicorn
import yaml
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker

# Adicionar src ao path para imports
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from presentation.controllers.audit_controller import router as audit_router
from presentation.controllers.compliance_controller import router as compliance_router
from infrastructure.database.models import Base


class AuditServiceApp:
    """
    Aplicação principal do Audit Service refatorado
    
    Responsabilidades:
    - Configurar FastAPI
    - Gerenciar dependências
    - Configurar middleware
    - Gerenciar ciclo de vida da aplicação
    """
    
    def __init__(self):
        """Inicializa a aplicação"""
        self.config = self._load_config()
        self.engine = None
        self.session_factory = None
        self.app = None
        
        # Configurar logging
        self._setup_logging()
        
        # Criar aplicação FastAPI
        self._create_app()
    
    def _load_config(self) -> Dict[str, Any]:
        """
        Carrega configuração do arquivo YAML
        
        Returns:
            Dict: Configuração carregada
        """
        config_path = os.path.join(os.path.dirname(__file__), 'config.yml')
        
        try:
            with open(config_path, 'r', encoding='utf-8') as file:
                config = yaml.safe_load(file)
                
            # Sobrescrever com variáveis de ambiente se existirem
            config = self._override_with_env(config)
            
            return config
            
        except FileNotFoundError:
            logging.warning(f"Arquivo de configuração {config_path} não encontrado, usando configuração padrão")
            return self._get_default_config()
        except Exception as e:
            logging.error(f"Erro ao carregar configuração: {e}")
            return self._get_default_config()
    
    def _override_with_env(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Sobrescreve configuração com variáveis de ambiente
        
        Args:
            config: Configuração base
            
        Returns:
            Dict: Configuração atualizada
        """
        # Database
        if os.getenv('DATABASE_URL'):
            config['database']['url'] = os.getenv('DATABASE_URL')
        
        if os.getenv('DATABASE_HOST'):
            config['database']['host'] = os.getenv('DATABASE_HOST')
        
        if os.getenv('DATABASE_PORT'):
            config['database']['port'] = int(os.getenv('DATABASE_PORT'))
        
        if os.getenv('DATABASE_NAME'):
            config['database']['name'] = os.getenv('DATABASE_NAME')
        
        if os.getenv('DATABASE_USER'):
            config['database']['user'] = os.getenv('DATABASE_USER')
        
        if os.getenv('DATABASE_PASSWORD'):
            config['database']['password'] = os.getenv('DATABASE_PASSWORD')
        
        # Service
        if os.getenv('SERVICE_PORT'):
            config['service']['port'] = int(os.getenv('SERVICE_PORT'))
        
        if os.getenv('SERVICE_HOST'):
            config['service']['host'] = os.getenv('SERVICE_HOST')
        
        # Logging
        if os.getenv('LOG_LEVEL'):
            config['logging']['level'] = os.getenv('LOG_LEVEL')
        
        return config
    
    def _get_default_config(self) -> Dict[str, Any]:
        """
        Retorna configuração padrão
        
        Returns:
            Dict: Configuração padrão
        """
        return {
            'service': {
                'name': 'audit-service',
                'version': '1.2.0',
                'port': 8009,
                'host': '0.0.0.0',
                'description': 'Serviço de Auditoria e Compliance'
            },
            'database': {
                'host': 'localhost',
                'port': 5432,
                'name': 'audit_db',
                'user': 'audit_user',
                'password': 'audit_pass',
                'pool_size': 10,
                'max_overflow': 20
            },
            'logging': {
                'level': 'INFO',
                'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            },
            'security': {
                'require_authentication': True,
                'allowed_origins': ['*'],
                'allowed_methods': ['GET', 'POST', 'PUT', 'DELETE'],
                'allowed_headers': ['*']
            },
            'performance': {
                'max_concurrent_requests': 150,
                'request_timeout_seconds': 30
            }
        }
    
    def _setup_logging(self):
        """Configura logging da aplicação"""
        log_config = self.config.get('logging', {})
        
        logging.basicConfig(
            level=getattr(logging, log_config.get('level', 'INFO')),
            format=log_config.get('format', '%(asctime)s - %(name)s - %(levelname)s - %(message)s'),
            handlers=[
                logging.StreamHandler(sys.stdout),
                logging.FileHandler(
                    log_config.get('file_path', '/var/log/audit-service/audit.log'),
                    mode='a'
                ) if log_config.get('file_path') else logging.NullHandler()
            ]
        )
        
        # Configurar loggers específicos
        logging.getLogger('sqlalchemy.engine').setLevel(logging.WARNING)
        logging.getLogger('uvicorn.access').setLevel(logging.INFO)
    
    @asynccontextmanager
    async def lifespan(self, app: FastAPI):
        """
        Gerencia o ciclo de vida da aplicação
        
        Args:
            app: Instância do FastAPI
        """
        # Startup
        logging.info("Iniciando Audit Service...")
        
        try:
            # Configurar banco de dados
            await self._setup_database()
            
            # Configurar dependências
            self._setup_dependencies()
            
            logging.info(f"Audit Service iniciado na porta {self.config['service']['port']}")
            
            yield
            
        except Exception as e:
            logging.error(f"Erro durante inicialização: {e}")
            raise
        finally:
            # Shutdown
            logging.info("Finalizando Audit Service...")
            
            if self.engine:
                await self.engine.dispose()
            
            logging.info("Audit Service finalizado")
    
    def _create_app(self):
        """Cria e configura a aplicação FastAPI"""
        self.app = FastAPI(
            title=self.config['service']['name'],
            description=self.config['service']['description'],
            version=self.config['service']['version'],
            lifespan=self.lifespan,
            docs_url="/docs",
            redoc_url="/redoc",
            openapi_url="/openapi.json"
        )
        
        # Configurar middleware
        self._setup_middleware()
        
        # Configurar rotas
        self._setup_routes()
        
        # Configurar handlers de erro
        self._setup_error_handlers()
    
    def _setup_middleware(self):
        """Configura middleware da aplicação"""
        security_config = self.config.get('security', {})
        
        # CORS
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=security_config.get('allowed_origins', ['*']),
            allow_credentials=True,
            allow_methods=security_config.get('allowed_methods', ['*']),
            allow_headers=security_config.get('allowed_headers', ['*'])
        )
        
        # Trusted Host
        self.app.add_middleware(
            TrustedHostMiddleware,
            allowed_hosts=["*"]  # Em produção, configurar hosts específicos
        )
        
        # Middleware de correlação
        @self.app.middleware("http")
        async def correlation_middleware(request: Request, call_next):
            """Adiciona correlation ID às requisições"""
            import uuid
            
            correlation_id = request.headers.get("X-Correlation-ID", str(uuid.uuid4()))
            request.state.correlation_id = correlation_id
            
            response = await call_next(request)
            response.headers["X-Correlation-ID"] = correlation_id
            
            return response
        
        # Middleware de logging
        @self.app.middleware("http")
        async def logging_middleware(request: Request, call_next):
            """Log de requisições"""
            start_time = datetime.utcnow()
            
            response = await call_next(request)
            
            duration = (datetime.utcnow() - start_time).total_seconds()
            
            logging.info(
                f"{request.method} {request.url.path} - "
                f"Status: {response.status_code} - "
                f"Duration: {duration:.3f}s - "
                f"Correlation: {getattr(request.state, 'correlation_id', 'N/A')}"
            )
            
            return response
    
    def _setup_routes(self):
        """Configura rotas da aplicação"""
        # Incluir routers dos controllers
        self.app.include_router(audit_router)
        self.app.include_router(compliance_router)
        
        # Rota raiz
        @self.app.get("/")
        async def root():
            """Endpoint raiz"""
            return {
                "service": self.config['service']['name'],
                "version": self.config['service']['version'],
                "description": self.config['service']['description'],
                "status": "running",
                "timestamp": datetime.utcnow().isoformat()
            }
        
        # Health check
        @self.app.get("/health")
        async def health_check():
            """Health check detalhado"""
            try:
                # Verificar conexão com banco
                db_status = "healthy"
                if self.engine:
                    async with self.engine.begin() as conn:
                        await conn.execute("SELECT 1")
                else:
                    db_status = "not_configured"
                
                return {
                    "status": "healthy",
                    "service": self.config['service']['name'],
                    "version": self.config['service']['version'],
                    "timestamp": datetime.utcnow().isoformat(),
                    "components": {
                        "database": db_status,
                        "application": "healthy"
                    }
                }
                
            except Exception as e:
                return JSONResponse(
                    status_code=503,
                    content={
                        "status": "unhealthy",
                        "service": self.config['service']['name'],
                        "timestamp": datetime.utcnow().isoformat(),
                        "error": str(e)
                    }
                )
    
    def _setup_error_handlers(self):
        """Configura handlers de erro"""
        
        @self.app.exception_handler(Exception)
        async def global_exception_handler(request: Request, exc: Exception):
            """Handler global de exceções"""
            correlation_id = getattr(request.state, 'correlation_id', 'N/A')
            
            logging.error(
                f"Erro não tratado: {str(exc)} - "
                f"Path: {request.url.path} - "
                f"Correlation: {correlation_id}",
                exc_info=True
            )
            
            return JSONResponse(
                status_code=500,
                content={
                    "error": "Erro interno do servidor",
                    "correlation_id": correlation_id,
                    "timestamp": datetime.utcnow().isoformat()
                }
            )
    
    async def _setup_database(self):
        """Configura conexão com banco de dados"""
        db_config = self.config.get('database', {})
        
        # Construir URL de conexão
        if 'url' in db_config:
            database_url = db_config['url']
        else:
            database_url = (
                f"postgresql+asyncpg://{db_config['user']}:{db_config['password']}"
                f"@{db_config['host']}:{db_config['port']}/{db_config['name']}"
            )
        
        # Criar engine
        self.engine = create_async_engine(
            database_url,
            pool_size=db_config.get('pool_size', 10),
            max_overflow=db_config.get('max_overflow', 20),
            echo=False  # Em desenvolvimento, pode ser True
        )
        
        # Criar session factory
        self.session_factory = async_sessionmaker(
            self.engine,
            class_=AsyncSession,
            expire_on_commit=False
        )
        
        # Criar tabelas se não existirem
        async with self.engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        
        logging.info("Banco de dados configurado com sucesso")
    
    def _setup_dependencies(self):
        """Configura injeção de dependências"""
        # Em produção, usar um container DI como dependency-injector
        # Por enquanto, configuração manual
        
        def get_db_session():
            """Dependency para sessão do banco"""
            return self.session_factory()
        
        # Registrar dependências no app
        self.app.dependency_overrides = {
            # Adicionar overrides conforme necessário
        }
    
    def run(self):
        """Executa a aplicação"""
        service_config = self.config['service']
        
        uvicorn.run(
            self.app,
            host=service_config['host'],
            port=service_config['port'],
            log_level=self.config['logging']['level'].lower(),
            access_log=True,
            reload=False  # Em desenvolvimento, pode ser True
        )


# Função para criar aplicação (para uso com ASGI servers)
def create_app() -> FastAPI:
    """
    Factory function para criar aplicação
    
    Returns:
        FastAPI: Aplicação configurada
    """
    app_instance = AuditServiceApp()
    return app_instance.app


# Ponto de entrada principal
if __name__ == "__main__":
    app_instance = AuditServiceApp()
    app_instance.run()

