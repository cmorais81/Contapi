#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Utilitários simples para leitura de arquivos COBOL.
"""

import os
from typing import Dict, Optional


def read_cobol_file(file_path: str) -> str:
    """Lê arquivo COBOL."""
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except UnicodeDecodeError:
        # Tentar com encoding alternativo
        with open(file_path, 'r', encoding='latin-1') as f:
            return f.read()


def read_copybook_files(copybooks_file: str) -> Dict[str, str]:
    """Lê arquivo de copybooks."""
    
    if not copybooks_file or not os.path.exists(copybooks_file):
        return {}
    
    copybooks = {}
    
    try:
        with open(copybooks_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        current_copybook = None
        current_content = []
        
        for line in lines:
            line = line.strip()
            
            if not line:
                continue
            
            # Se linha não começa com espaço, é nome de copybook
            if not line.startswith(' ') and not line.startswith('\t'):
                # Salvar copybook anterior se existir
                if current_copybook and current_content:
                    copybooks[current_copybook] = '\n'.join(current_content)
                
                # Iniciar novo copybook
                current_copybook = line
                current_content = []
            else:
                # Adicionar linha ao conteúdo atual
                if current_copybook:
                    current_content.append(line)
        
        # Salvar último copybook
        if current_copybook and current_content:
            copybooks[current_copybook] = '\n'.join(current_content)
    
    except Exception as e:
        print(f"Erro ao ler copybooks: {e}")
        return {}
    
    return copybooks
