"""
Sistema de Análise COBOL v15.0 - Universal Structure Analyzer
Analisador universal de estruturas COBOL que funciona com qualquer programa.
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass


@dataclass
class COBOLField:
    """Representa um campo COBOL com todas suas propriedades."""
    name: str
    level: int
    pic_clause: str
    position: Optional[Tuple[int, int]] = None
    data_type: str = "unknown"
    size: int = 0
    occurs: Optional[int] = None
    redefines: Optional[str] = None
    values: List[str] = None
    description: str = ""
    
    def __post_init__(self):
        if self.values is None:
            self.values = []


@dataclass
class COBOLFile:
    """Representa um arquivo COBOL com seus campos e propriedades."""
    name: str
    type: str  # "input", "output", "work"
    organization: str = "sequential"
    fields: List[COBOLField] = None
    record_size: int = 0
    description: str = ""
    
    def __post_init__(self):
        if self.fields is None:
            self.fields = []


class UniversalStructureAnalyzer:
    """
    Analisador universal de estruturas COBOL.
    Funciona com qualquer programa COBOL, não apenas LH*.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Padrões universais COBOL
        self.fd_pattern = re.compile(r'^\s*FD\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.select_pattern = re.compile(r'^\s*SELECT\s+([A-Z0-9\-]+)\s+ASSIGN\s+TO\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.level_pattern = re.compile(r'^\s*(\d{2})\s+([A-Z0-9\-]+)(?:\s+(.+))?', re.IGNORECASE)
        self.pic_pattern = re.compile(r'PIC\s+([X9VS\(\)\-\+\.]+)', re.IGNORECASE)
        self.occurs_pattern = re.compile(r'OCCURS\s+(\d+)', re.IGNORECASE)
        self.redefines_pattern = re.compile(r'REDEFINES\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.value_pattern = re.compile(r'VALUE\s+(?:IS\s+)?["\']?([^"\'\.]+)["\']?', re.IGNORECASE)
        self.usage_pattern = re.compile(r'USAGE\s+(?:IS\s+)?([A-Z\-]+)', re.IGNORECASE)
        
        # Padrões para identificar tipos de arquivo
        self.input_indicators = ['INPUT', 'READ', 'ENTRADA', 'LEITURA', 'ARQENT', 'ENT']
        self.output_indicators = ['OUTPUT', 'WRITE', 'SAIDA', 'GRAVACAO', 'ARQSAI', 'SAI']
        self.work_indicators = ['WORK', 'TEMP', 'WORKING', 'TRABALHO', 'WRK', 'TMP']
        
    def analyze(self, program_lines: List[str], program_name: str = "UNKNOWN") -> Dict[str, Any]:
        """
        Analisa estruturas de qualquer programa COBOL.
        
        Args:
            program_lines: Linhas do programa COBOL
            program_name: Nome do programa (opcional)
            
        Returns:
            Dict com análise completa das estruturas
        """
        self.logger.info(f"Analisando estruturas universais do programa {program_name}")
        
        try:
            # Análise das seções
            sections = self._identify_sections(program_lines)
            
            # Análise de arquivos
            files = self._analyze_files(program_lines)
            
            # Análise de campos da WORKING-STORAGE
            working_storage_fields = self._analyze_working_storage(program_lines)
            
            # Análise de copybooks
            copybooks = self._identify_copybooks(program_lines)
            
            # Análise de variáveis e constantes
            variables = self._analyze_variables(program_lines)
            
            # Análise de estruturas de dados complexas
            data_structures = self._analyze_data_structures(program_lines)
            
            result = {
                'program_name': program_name,
                'sections': sections,
                'files': files,
                'working_storage_fields': working_storage_fields,
                'copybooks': copybooks,
                'variables': variables,
                'data_structures': data_structures,
                'statistics': {
                    'total_files': len(files),
                    'total_fields': len(working_storage_fields),
                    'total_copybooks': len(copybooks),
                    'total_variables': len(variables)
                }
            }
            
            self.logger.info(f"Análise concluída: {len(files)} arquivos, {len(working_storage_fields)} campos")
            return result
            
        except Exception as e:
            self.logger.error(f"Erro na análise universal: {str(e)}")
            return {
                'program_name': program_name,
                'error': str(e),
                'sections': {},
                'files': [],
                'working_storage_fields': [],
                'copybooks': [],
                'variables': [],
                'data_structures': []
            }
    
    def _identify_sections(self, lines: List[str]) -> Dict[str, Dict[str, Any]]:
        """Identifica todas as seções do programa COBOL."""
        sections = {}
        current_section = None
        
        section_patterns = {
            'IDENTIFICATION': re.compile(r'^\s*IDENTIFICATION\s+DIVISION', re.IGNORECASE),
            'ENVIRONMENT': re.compile(r'^\s*ENVIRONMENT\s+DIVISION', re.IGNORECASE),
            'DATA': re.compile(r'^\s*DATA\s+DIVISION', re.IGNORECASE),
            'PROCEDURE': re.compile(r'^\s*PROCEDURE\s+DIVISION', re.IGNORECASE),
            'FILE': re.compile(r'^\s*FILE\s+SECTION', re.IGNORECASE),
            'WORKING-STORAGE': re.compile(r'^\s*WORKING-STORAGE\s+SECTION', re.IGNORECASE),
            'LINKAGE': re.compile(r'^\s*LINKAGE\s+SECTION', re.IGNORECASE)
        }
        
        for i, line in enumerate(lines):
            for section_name, pattern in section_patterns.items():
                if pattern.match(line):
                    if current_section:
                        sections[current_section]['end_line'] = i - 1
                    
                    current_section = section_name
                    sections[section_name] = {
                        'start_line': i,
                        'end_line': len(lines) - 1,
                        'content_lines': []
                    }
                    break
            
            if current_section:
                sections[current_section]['content_lines'].append(line)
        
        return sections
    
    def _analyze_files(self, lines: List[str]) -> List[COBOLFile]:
        """Analisa todos os arquivos definidos no programa."""
        files = []
        current_fd = None
        
        for line in lines:
            # Procura definições SELECT
            select_match = self.select_pattern.match(line)
            if select_match:
                file_name = select_match.group(1)
                assign_name = select_match.group(2)
                
                # Determina tipo do arquivo baseado no nome
                file_type = self._determine_file_type(file_name, assign_name)
                
                cobol_file = COBOLFile(
                    name=file_name,
                    type=file_type,
                    description=f"Arquivo {file_type} - {assign_name}"
                )
                files.append(cobol_file)
            
            # Procura definições FD
            fd_match = self.fd_pattern.match(line)
            if fd_match:
                file_name = fd_match.group(1)
                current_fd = file_name
                
                # Encontra o arquivo correspondente ou cria novo
                existing_file = next((f for f in files if f.name == file_name), None)
                if not existing_file:
                    file_type = self._determine_file_type(file_name, "")
                    cobol_file = COBOLFile(
                        name=file_name,
                        type=file_type,
                        description=f"Arquivo {file_type}"
                    )
                    files.append(cobol_file)
            
            # Analisa campos do arquivo atual
            if current_fd:
                field = self._parse_field_definition(line)
                if field and field.level == 1:
                    # Encontra o arquivo e adiciona o campo
                    for file_obj in files:
                        if file_obj.name == current_fd:
                            file_obj.fields.append(field)
                            break
                    current_fd = None  # Reset após encontrar o registro principal
        
        return files
    
    def _determine_file_type(self, file_name: str, assign_name: str) -> str:
        """Determina o tipo do arquivo baseado no nome."""
        name_upper = (file_name + " " + assign_name).upper()
        
        for indicator in self.input_indicators:
            if indicator in name_upper:
                return "input"
        
        for indicator in self.output_indicators:
            if indicator in name_upper:
                return "output"
        
        for indicator in self.work_indicators:
            if indicator in name_upper:
                return "work"
        
        # Heurísticas baseadas em padrões comuns
        if any(x in name_upper for x in ['E1', 'E2', 'E3', 'E4', 'E5', 'ENT', 'IN']):
            return "input"
        elif any(x in name_upper for x in ['S1', 'S2', 'S3', 'SAI', 'OUT']):
            return "output"
        else:
            return "unknown"
    
    def _analyze_working_storage(self, lines: List[str]) -> List[COBOLField]:
        """Analisa todos os campos da WORKING-STORAGE SECTION."""
        fields = []
        in_working_storage = False
        
        for line in lines:
            if re.match(r'^\s*WORKING-STORAGE\s+SECTION', line, re.IGNORECASE):
                in_working_storage = True
                continue
            elif re.match(r'^\s*\w+\s+SECTION', line, re.IGNORECASE):
                in_working_storage = False
                continue
            
            if in_working_storage:
                field = self._parse_field_definition(line)
                if field:
                    fields.append(field)
        
        return fields
    
    def _parse_field_definition(self, line: str) -> Optional[COBOLField]:
        """Analisa uma linha e extrai definição de campo COBOL."""
        level_match = self.level_pattern.match(line)
        if not level_match:
            return None
        
        level = int(level_match.group(1))
        name = level_match.group(2)
        rest_of_line = level_match.group(3) or ""
        
        # Extrai PIC clause
        pic_match = self.pic_pattern.search(rest_of_line)
        pic_clause = pic_match.group(1) if pic_match else ""
        
        # Extrai OCCURS
        occurs_match = self.occurs_pattern.search(rest_of_line)
        occurs = int(occurs_match.group(1)) if occurs_match else None
        
        # Extrai REDEFINES
        redefines_match = self.redefines_pattern.search(rest_of_line)
        redefines = redefines_match.group(1) if redefines_match else None
        
        # Extrai VALUE
        value_match = self.value_pattern.search(rest_of_line)
        values = [value_match.group(1)] if value_match else []
        
        # Determina tipo de dados e tamanho
        data_type, size = self._analyze_pic_clause(pic_clause)
        
        field = COBOLField(
            name=name,
            level=level,
            pic_clause=pic_clause,
            data_type=data_type,
            size=size,
            occurs=occurs,
            redefines=redefines,
            values=values,
            description=self._generate_field_description(name, pic_clause, values)
        )
        
        return field
    
    def _analyze_pic_clause(self, pic_clause: str) -> Tuple[str, int]:
        """Analisa PIC clause e determina tipo e tamanho."""
        if not pic_clause:
            return "group", 0
        
        pic_upper = pic_clause.upper()
        
        # Analisa padrões comuns
        if 'X' in pic_upper:
            # Alfanumérico
            size_match = re.search(r'X\((\d+)\)', pic_upper)
            if size_match:
                return "alphanumeric", int(size_match.group(1))
            else:
                return "alphanumeric", pic_upper.count('X')
        
        elif '9' in pic_upper:
            # Numérico
            size_match = re.search(r'9\((\d+)\)', pic_upper)
            if size_match:
                size = int(size_match.group(1))
            else:
                size = pic_upper.count('9')
            
            if 'V' in pic_upper or '.' in pic_upper:
                return "decimal", size
            else:
                return "numeric", size
        
        elif 'S' in pic_upper:
            return "signed_numeric", len(pic_clause)
        
        else:
            return "unknown", len(pic_clause)
    
    def _generate_field_description(self, name: str, pic_clause: str, values: List[str]) -> str:
        """Gera descrição inteligente do campo baseado no nome e características."""
        description_parts = []
        
        # Análise do nome
        name_lower = name.lower().replace('-', '_')
        
        if 'contador' in name_lower or 'count' in name_lower or name_lower.startswith('ws_cont'):
            description_parts.append("Contador")
        elif 'indice' in name_lower or 'index' in name_lower or 'idx' in name_lower:
            description_parts.append("Índice")
        elif 'flag' in name_lower or 'sw' in name_lower:
            description_parts.append("Flag/Switch")
        elif 'data' in name_lower or 'date' in name_lower:
            description_parts.append("Data")
        elif 'valor' in name_lower or 'value' in name_lower or 'vlr' in name_lower:
            description_parts.append("Valor")
        elif 'nome' in name_lower or 'name' in name_lower:
            description_parts.append("Nome")
        elif 'codigo' in name_lower or 'code' in name_lower or 'cod' in name_lower:
            description_parts.append("Código")
        elif 'tipo' in name_lower or 'type' in name_lower:
            description_parts.append("Tipo")
        elif 'status' in name_lower or 'situacao' in name_lower:
            description_parts.append("Status/Situação")
        
        # Análise do PIC
        if pic_clause:
            if 'X' in pic_clause.upper():
                description_parts.append("alfanumérico")
            elif '9' in pic_clause.upper():
                if 'V' in pic_clause.upper():
                    description_parts.append("decimal")
                else:
                    description_parts.append("numérico")
        
        # Análise dos valores
        if values:
            if len(values) == 1:
                description_parts.append(f"valor padrão: {values[0]}")
            else:
                description_parts.append(f"valores possíveis: {', '.join(values)}")
        
        if description_parts:
            return " - ".join(description_parts).capitalize()
        else:
            return f"Campo {name}"
    
    def _identify_copybooks(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Identifica todos os copybooks utilizados."""
        copybooks = []
        copy_pattern = re.compile(r'^\s*COPY\s+([A-Z0-9\-]+)', re.IGNORECASE)
        
        for i, line in enumerate(lines):
            match = copy_pattern.match(line)
            if match:
                copybook_name = match.group(1)
                copybooks.append({
                    'name': copybook_name,
                    'line': i + 1,
                    'context': 'unknown',
                    'description': f"Copybook {copybook_name}"
                })
        
        return copybooks
    
    def _analyze_variables(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Analisa variáveis e constantes importantes."""
        variables = []
        
        # Procura por constantes e variáveis importantes
        constant_patterns = [
            (r'^\s*\d+\s+([A-Z0-9\-]+)\s+VALUE\s+(\d+)', 'numeric_constant'),
            (r'^\s*\d+\s+([A-Z0-9\-]+)\s+VALUE\s+["\']([^"\']+)["\']', 'string_constant'),
            (r'^\s*77\s+([A-Z0-9\-]+)', 'independent_item'),
            (r'^\s*88\s+([A-Z0-9\-]+)\s+VALUE\s+([^\.]+)', 'condition_name')
        ]
        
        for i, line in enumerate(lines):
            for pattern, var_type in constant_patterns:
                match = re.match(pattern, line, re.IGNORECASE)
                if match:
                    var_name = match.group(1)
                    var_value = match.group(2) if len(match.groups()) > 1 else ""
                    
                    variables.append({
                        'name': var_name,
                        'type': var_type,
                        'value': var_value,
                        'line': i + 1,
                        'description': self._generate_variable_description(var_name, var_type, var_value)
                    })
        
        return variables
    
    def _generate_variable_description(self, name: str, var_type: str, value: str) -> str:
        """Gera descrição para variável baseada no tipo e valor."""
        type_descriptions = {
            'numeric_constant': 'Constante numérica',
            'string_constant': 'Constante de texto',
            'independent_item': 'Item independente',
            'condition_name': 'Nome de condição'
        }
        
        base_desc = type_descriptions.get(var_type, 'Variável')
        
        if value:
            return f"{base_desc} - valor: {value}"
        else:
            return f"{base_desc} - {name}"
    
    def _analyze_data_structures(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Analisa estruturas de dados complexas (grupos, tabelas, etc.)."""
        structures = []
        current_structure = None
        
        for i, line in enumerate(lines):
            level_match = self.level_pattern.match(line)
            if level_match:
                level = int(level_match.group(1))
                name = level_match.group(2)
                rest = level_match.group(3) or ""
                
                # Identifica início de estrutura (nível 01 sem PIC)
                if level == 1 and not self.pic_pattern.search(rest):
                    if current_structure:
                        structures.append(current_structure)
                    
                    current_structure = {
                        'name': name,
                        'type': 'group',
                        'level': level,
                        'line': i + 1,
                        'fields': [],
                        'description': f"Estrutura de dados {name}"
                    }
                
                # Adiciona campo à estrutura atual
                elif current_structure and level > 1:
                    field_info = {
                        'name': name,
                        'level': level,
                        'line': i + 1,
                        'pic': self.pic_pattern.search(rest).group(1) if self.pic_pattern.search(rest) else "",
                        'occurs': self.occurs_pattern.search(rest).group(1) if self.occurs_pattern.search(rest) else None
                    }
                    current_structure['fields'].append(field_info)
        
        if current_structure:
            structures.append(current_structure)
        
        return structures
