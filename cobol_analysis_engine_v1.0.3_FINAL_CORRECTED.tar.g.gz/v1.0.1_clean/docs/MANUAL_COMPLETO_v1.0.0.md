# Manual Completo - Sistema de Análise COBOL v1.0.1

**Versão:** 1.0.0  
**Data:** Setembro 2025  
**Sistema:** Análise Multi-IA com Script Unificado  

## Visão Geral

O Sistema de Análise COBOL v1.0.1 é uma ferramenta avançada que combina análise Multi-IA orquestrada com funcionalidade tradicional em um único script principal. O sistema oferece análise colaborativa com 4 IAs especializadas, validação cruzada automática e garantia científica de clareza na documentação.

## Características Principais

### Script Principal Unificado
- **Um único script** (`main.py`) que integra todas as funcionalidades
- **Detecção automática** do melhor modo de análise
- **Interface consistente** para todos os tipos de análise
- **Compatibilidade total** com versões anteriores

### Modos de Análise Disponíveis

#### 1. Modo Multi-IA (Recomendado)
- **4 IAs especializadas** trabalhando em paralelo
- **Validação cruzada** automática entre resultados
- **Resolução de conflitos** inteligente
- **Garantia de clareza** na documentação

#### 2. Modo Tradicional
- **Análise estrutural** clássica
- **Extração de lógica** de negócio
- **Documentação funcional** padrão
- **Compatibilidade** com versões anteriores

#### 3. Modo Automático
- **Detecção inteligente** do melhor modo
- **Fallback automático** se Multi-IA indisponível
- **Configuração transparente** para o usuário

## Instalação

### Requisitos do Sistema
- **Python 3.11+** (recomendado)
- **Sistema operacional:** Linux, macOS, Windows
- **Memória:** Mínimo 4GB RAM
- **Espaço em disco:** 100MB livres

### Instalação Rápida

```bash
# 1. Extrair o pacote
tar -xzf cobol_analysis_engine_v1.0.1.tar.gz
cd implementation_v1/

# 2. Instalar dependências
pip install -r requirements.txt

# 3. Verificar instalação
python main.py --help
```

### Instalação com Ambiente Virtual (Recomendado)

```bash
# 1. Criar ambiente virtual
python3.11 -m venv venv

# 2. Ativar ambiente
source venv/bin/activate  # Linux/macOS
# ou
venv\Scripts\activate     # Windows

# 3. Instalar dependências
pip install -r requirements.txt

# 4. Testar instalação
python main.py --help
```

## Uso do Sistema

### Sintaxe Básica

```bash
python main.py [arquivos_entrada] [opções]
```

### Exemplos Práticos

#### Análise Multi-IA (Recomendado)

```bash
# Análise completa Multi-IA
python main.py programa.cbl --mode multi_ai --audience technical

# Com copybooks
python main.py programa.cbl --copybooks books.txt --mode multi_ai

# Para audiência executiva
python main.py sistema.cbl --mode multi_ai --audience executive --output exec_results/

# Para implementação
python main.py legacy.cbl --mode multi_ai --audience implementation --output migration/
```

#### Análise Tradicional

```bash
# Análise tradicional simples
python main.py programa.cbl --mode traditional

# Com múltiplos arquivos
python main.py fontes.txt books.txt --mode traditional --output traditional_results/

# Análise verbosa
python main.py programa.cbl --mode traditional --verbose
```

#### Modo Automático

```bash
# Detecção automática do melhor modo
python main.py programa.cbl --copybooks books.txt

# Com configuração personalizada
python main.py programa.cbl --config config/custom.yaml

# Múltiplos programas
python main.py lista_programas.txt --output resultados/
```

#### Demonstração Rápida

```bash
# Modo demonstração (máximo 3 programas)
python main.py programa.cbl --demo

# Demonstração silenciosa
python main.py programa.cbl --demo --quiet
```

### Opções de Linha de Comando

#### Argumentos Obrigatórios
- `input_files`: Arquivo(s) COBOL ou arquivo com lista de programas

#### Opções Principais
- `--copybooks, -b`: Arquivo de copybooks
- `--output, -o`: Diretório de saída (padrão: analysis_results)
- `--mode, -m`: Modo de análise (auto, multi_ai, traditional)

#### Opções Multi-IA
- `--audience`: Audiência alvo (executive, technical, business, implementation)

#### Opções de Configuração
- `--config, -c`: Arquivo de configuração personalizado
- `--demo`: Modo demonstração (limita a 3 programas)
- `--verbose, -v`: Logging detalhado
- `--quiet, -q`: Saída mínima

## Configuração do Sistema

### Arquivo de Configuração Principal

O sistema usa `config/config.yaml` para configuração:

```yaml
# Configuração de Análise
analysis:
  mode: auto                    # auto, multi_ai, traditional
  max_programs: 50             # Limite de programas por execução
  timeout: 300                 # Timeout em segundos

# Configuração Multi-IA
multi_ai:
  enabled: true                # Habilitar Multi-IA
  parallel_execution: true     # Execução paralela
  cross_validation: true       # Validação cruzada
  clarity_validation: true     # Validação de clareza

# IAs Especializadas
specialized_ais:
  structural_ai:
    provider: openai           # Provedor para análise estrutural
    model: gpt-4              # Modelo específico
    temperature: 0.1          # Temperatura de geração
  business_ai:
    provider: luzia           # Provedor para análise de negócio
    model: claude-3-5-sonnet  # Modelo específico
    temperature: 0.2
  technical_ai:
    provider: copilot         # Provedor para análise técnica
    model: gpt-4
    temperature: 0.1
  quality_ai:
    provider: enhanced_mock   # Provedor para análise de qualidade
    model: mock-model
    temperature: 0.1

# Validação Cruzada
cross_validation:
  consensus_threshold: 0.75    # Threshold para consenso
  conflict_threshold: 0.3      # Threshold para conflito
  min_agreement_ratio: 0.6     # Razão mínima de concordância

# Garantia de Clareza
clarity:
  minimum_score: 0.8          # Score mínimo de clareza
  target_audiences:           # Audiências suportadas
    - technical
    - business
    - executive
    - implementation

# Análise Tradicional
traditional:
  enabled: true               # Habilitar modo tradicional
  fallback: true             # Usar como fallback

# Configuração de Saída
output:
  format: markdown           # Formato padrão (markdown, json, html)
  include_metrics: true      # Incluir métricas nos resultados
  save_technical_data: true  # Salvar dados técnicos

# Logging
logging:
  level: INFO               # Nível de log (DEBUG, INFO, WARNING, ERROR)
  file: cobol_analysis.log  # Arquivo de log
```

### Configurações por Audiência

#### Audiência Executiva
- **Foco:** ROI, impacto no negócio, cronogramas
- **Linguagem:** Não técnica, orientada a resultados
- **Métricas:** Custo, tempo, risco

#### Audiência Técnica
- **Foco:** Implementação, arquitetura, detalhes técnicos
- **Linguagem:** Técnica especializada
- **Métricas:** Complexidade, performance, qualidade

#### Audiência de Negócio
- **Foco:** Processos, regras de negócio, compliance
- **Linguagem:** Orientada a processos
- **Métricas:** Eficiência, conformidade, impacto

#### Audiência de Implementação
- **Foco:** Migração, modernização, passos práticos
- **Linguagem:** Orientada a ação
- **Métricas:** Viabilidade, esforço, cronograma

## Provedores de Análise

### Provedores Suportados

#### OpenAI GPT-4 (Recomendado para Estrutural)
```yaml
providers:
  openai:
    type: openai
    api_key: ${OPENAI_API_KEY}
    model: gpt-4
    temperature: 0.1
    max_tokens: 4000
```

#### GitHub Copilot (Recomendado para Técnico)
```yaml
providers:
  copilot:
    type: copilot
    api_key: ${COPILOT_API_KEY}
    model: gpt-4
    temperature: 0.1
```

#### LuzIA (Recomendado para Negócio)
```yaml
providers:
  luzia:
    type: luzia
    api_url: ${LUZIA_API_URL}
    api_key: ${LUZIA_API_KEY}
    model: claude-3-5-sonnet
    temperature: 0.2
```

#### Enhanced Mock (Para Testes)
```yaml
providers:
  enhanced_mock:
    type: enhanced_mock
    enabled: true
    simulate_delay: false
```

### Configuração de Fallback

O sistema suporta fallback automático entre provedores:

```yaml
fallback_chain:
  - openai
  - copilot
  - enhanced_mock
```

## Resultados da Análise

### Estrutura de Saída

```
analysis_results/
├── PROGRAMA_MULTI_AI_ANALYSIS.md      # Documentação principal
├── PROGRAMA_technical_data.json       # Dados técnicos
├── consolidated_report.md             # Relatório consolidado
└── logs/
    └── analysis.log                   # Logs detalhados
```

### Documentação Gerada

#### Análise Multi-IA
- **Resumo Executivo**: Síntese adaptada por audiência
- **Análise por Domínio**: Resultados das 4 IAs especializadas
- **Relatório de Validação**: Métricas de consenso e confiança
- **Recomendações**: Próximos passos baseados em consenso
- **Guia de Implementação**: Orientações práticas

#### Análise Tradicional
- **Análise Estrutural**: Divisões, seções, organização
- **Lógica de Negócio**: Regras e processos identificados
- **Documentação Funcional**: Especificações para reimplementação

### Métricas de Qualidade

#### Multi-IA
- **Confiança da Validação**: 0-100% (baseada em consenso)
- **Score de Clareza**: 0-100% (5 métricas integradas)
- **Padrões Atendidos**: Certificação profissional
- **Tempo de Execução**: Performance otimizada

#### Tradicional
- **Taxa de Sucesso**: Programas analisados com sucesso
- **Qualidade da Análise**: Avaliação padrão
- **Tempo de Execução**: Performance de referência

## Extração de Conteúdo Real

### Funcionalidade Principal

O sistema **automaticamente extrai** informações valiosas dos arquivos fontes.txt e BOOKS.txt:

#### Arquivos Suportados
- **fontes.txt**: Múltiplos programas COBOL com documentação interna
- **BOOKS.txt**: Copybooks com estruturas de dados
- **Arquivos .cbl/.cob**: Programas individuais

#### Informações Extraídas

**Dos Programas:**
- Objetivos e descrições detalhadas
- Autores e datas de criação
- Histórico completo de versões
- Arquivos de entrada/saída mapeados
- Comentários técnicos dos desenvolvedores
- Regras de negócio específicas

**Dos Copybooks:**
- Estruturas de dados complexas
- Tabelas e campos com PIC clauses
- Relacionamentos entre entidades
- Comentários de versão e evolução

#### Exemplo de Extração

```bash
# O sistema automaticamente extrai e usa o conteúdo real
python main.py examples/fontes.txt examples/BOOKS.txt --verbose
```

**Saída:**
```
Extraindo conteúdo real dos arquivos...
Conteúdo extraído: 5 programas, 11 copybooks
Programas encontrados: LHAN0542, LHAN0705, LHAN0706, LHBR0700, MZAN6056
Copybooks encontrados: LHCP3402, LHCP0402, TB-ANEXO-01, ...
```

### Documentação Híbrida

O sistema combina **conteúdo real extraído** com **análise Multi-IA** para gerar documentação excepcionalmente rica:

#### Modo Híbrido Automático
```bash
# Extração + Multi-IA (quando disponível)
python main.py examples/fontes.txt examples/BOOKS.txt --mode multi_ai --audience technical
```

#### Benefícios da Abordagem Híbrida
- **Base sólida**: Informações reais dos desenvolvedores originais
- **Enriquecimento IA**: Análise inteligente e insights adicionais
- **Validação cruzada**: Confirmação entre conteúdo real e análise IA
- **Documentação completa**: Histórico + análise + recomendações

## Casos de Uso

### 1. Modernização de Sistemas Legacy

```bash
# Análise completa para modernização com conteúdo real
python main.py examples/fontes.txt examples/BOOKS.txt --mode multi_ai --audience implementation --output modernization/
```

**Resultado:**
- Documentação técnica baseada em conteúdo real
- Histórico completo de evolução dos sistemas
- Guia de migração com contexto histórico
- Identificação de riscos baseada em experiência real
- Estimativas fundamentadas em dados reais

### 2. Auditoria de Código

```bash
# Análise focada em qualidade
python main.py programa.cbl --mode multi_ai --audience technical --output auditoria/
```

**Resultado:**
- Análise técnica profunda
- Identificação de problemas de qualidade
- Recomendações de melhoria
- Métricas de manutenibilidade

### 3. Relatório Executivo

```bash
# Relatório para gestores
python main.py sistema.cbl --mode multi_ai --audience executive --output relatorio_executivo/
```

**Resultado:**
- Resumo executivo não técnico
- Análise de impacto no negócio
- Estimativas de ROI
- Cronograma de alto nível

### 4. Análise de Regras de Negócio

```bash
# Foco em processos comerciais
python main.py programa.cbl --mode multi_ai --audience business --output regras_negocio/
```

**Resultado:**
- Mapeamento de processos de negócio
- Identificação de regras críticas
- Análise de compliance
- Impacto em operações

### 5. Análise em Lote

```bash
# Múltiplos programas
python main.py lista_programas.txt --mode multi_ai --output analise_lote/
```

**Resultado:**
- Análise de múltiplos programas
- Relatório consolidado
- Métricas agregadas
- Priorização por complexidade

## Solução de Problemas

### Problemas Comuns

#### Erro: "Multi-IA não disponível"

**Causa:** Dependências Multi-IA não instaladas ou configuradas

**Solução:**
```bash
# Verificar instalação
pip install -r requirements.txt

# Verificar configuração
python -c "import yaml; print(yaml.safe_load(open('config/config.yaml')))"

# Usar modo tradicional como alternativa
python main.py programa.cbl --mode traditional
```

#### Erro: "Nenhum programa COBOL encontrado"

**Causa:** Arquivos de entrada não encontrados ou formato incorreto

**Solução:**
```bash
# Verificar se arquivo existe
ls -la programa.cbl

# Verificar formato do arquivo de lista
cat lista_programas.txt

# Usar caminho absoluto
python main.py /caminho/completo/programa.cbl
```

#### Baixa Confiança na Validação Multi-IA

**Causa:** Conflitos entre IAs ou configuração inadequada

**Solução:**
```bash
# Ajustar thresholds no config.yaml
cross_validation:
  consensus_threshold: 0.6  # Reduzir de 0.75
  conflict_threshold: 0.4   # Aumentar de 0.3

# Verificar provedores configurados
# Usar modo verboso para diagnóstico
python main.py programa.cbl --mode multi_ai --verbose
```

#### Score de Clareza Baixo

**Causa:** Documentação não atende padrões de clareza

**Solução:**
```bash
# Ajustar padrões no config.yaml
clarity:
  minimum_score: 0.7  # Reduzir de 0.8

# Usar audiência apropriada
python main.py programa.cbl --audience technical  # Para desenvolvedores
python main.py programa.cbl --audience executive  # Para gestores

# Habilitar refinamento automático (padrão)
```

#### Erro de Configuração de Provedor

**Causa:** Chaves de API não configuradas ou inválidas

**Solução:**
```bash
# Configurar variáveis de ambiente
export OPENAI_API_KEY="sua_chave_aqui"
export COPILOT_API_KEY="sua_chave_aqui"

# Usar provedor mock para testes
python main.py programa.cbl --mode multi_ai  # Usa enhanced_mock automaticamente

# Verificar configuração
python -c "
import os
print('OpenAI:', 'OPENAI_API_KEY' in os.environ)
print('Copilot:', 'COPILOT_API_KEY' in os.environ)
"
```

### Logs e Depuração

#### Habilitar Logging Detalhado

```bash
# Logging verboso
python main.py programa.cbl --verbose

# Logging mínimo
python main.py programa.cbl --quiet

# Verificar logs
tail -f cobol_analysis.log
```

#### Analisar Dados Técnicos

```bash
# Verificar dados técnicos salvos
cat analysis_results/PROGRAMA_technical_data.json | python -m json.tool

# Verificar métricas de performance
grep "execution_time" analysis_results/*.json
```

## Desenvolvimento e Extensão

### Estrutura do Código

```
implementation_v1/
├── main.py                    # Script principal unificado
├── main_demo.py              # Script de demonstração
├── config/
│   ├── config.yaml           # Configuração principal
│   └── prompts.yaml          # Templates de prompts
├── src/
│   ├── core/                 # Componentes Multi-IA
│   │   ├── multi_ai_orchestrator.py
│   │   ├── cross_validator.py
│   │   └── clarity_engine.py
│   ├── providers/            # Provedores de análise
│   ├── analyzers/            # Analisadores especializados
│   ├── generators/           # Geradores de documentação
│   └── utils/                # Utilitários
├── examples/                 # Arquivos de exemplo
└── docs/                     # Documentação completa
```

### Executar Testes

```bash
# Testes da implementação Multi-IA
python test_multi_ai_implementation.py

# Teste do script unificado
python main.py examples/LHAN0542_TESTE.cbl --demo --verbose
```

### Adicionar Novos Provedores

1. **Criar classe do provedor** em `src/providers/`
2. **Implementar interface** `BaseProvider`
3. **Adicionar configuração** em `config.yaml`
4. **Testar integração** com Multi-IA

### Personalizar Análise

1. **Modificar prompts** em `config/prompts.yaml`
2. **Ajustar thresholds** em `config/config.yaml`
3. **Criar analisadores** especializados
4. **Implementar métricas** personalizadas

## Compatibilidade

### Versões COBOL Suportadas
- **COBOL-85**: Suporte completo
- **COBOL-2002**: Suporte completo
- **COBOL-2014**: Suporte completo
- **Dialetos mainframe**: IBM, Micro Focus, outros

### Sistemas Operacionais
- **Linux**: Testado e validado
- **macOS**: Intel + Apple Silicon
- **Windows**: Compatível (Python 3.11+)

### Versões Python
- **Python 3.11+**: Recomendado
- **Python 3.10+**: Compatível
- **Python 3.9**: Limitado (não recomendado)

## Licença e Suporte

### Licença
Sistema de Análise COBOL v1.0.1  
Todos os direitos reservados.

### Suporte Técnico
- **Documentação**: Consultar `docs/`
- **Logs**: Verificar `cobol_analysis.log`
- **Configuração**: Revisar `config/config.yaml`
- **Testes**: Executar suite de validação

### Atualizações
- **Versão atual**: 1.0.0
- **Compatibilidade**: Mantida com versões anteriores
- **Migração**: Automática via script unificado

---

**Sistema de Análise COBOL v1.0.1**  
*Script Unificado com Análise Multi-IA e Garantia de Clareza*  
*Manual Completo - Setembro 2025*
