#!/usr/bin/env python3
"""
Teste de Integração Híbrida - Sistema de Análise COBOL v1.0.0
Testa a integração entre extração de conteúdo real e documentação híbrida.
"""

import sys
import os
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from extractors.content_extractor import COBOLContentExtractor
from generators.hybrid_documentation_generator import HybridDocumentationGenerator

def test_content_extraction():
    """Testa extração de conteúdo dos arquivos."""
    
    print("=== Teste de Extração de Conteúdo ===")
    
    extractor = COBOLContentExtractor()
    
    # Testar extração
    input_files = ['examples/fontes.txt']
    copybooks_file = 'examples/BOOKS.txt'
    
    extracted_content = extractor.extract_from_files(input_files, copybooks_file)
    
    print(f"Programas extraídos: {len(extracted_content['programs'])}")
    print(f"Copybooks extraídos: {len(extracted_content['copybooks'])}")
    print(f"Resumo: {extracted_content['summary']}")
    
    # Mostrar primeiro programa
    if extracted_content['programs']:
        first_program = extracted_content['programs'][0]
        print(f"\nPrimeiro programa: {first_program['name']}")
        print(f"Objetivo: {first_program.get('objective', 'N/A')}")
        print(f"Autor: {first_program.get('author', 'N/A')}")
        print(f"Arquivos: {len(first_program.get('files', []))}")
        print(f"Histórico: {len(first_program.get('version_history', []))}")
    
    return extracted_content

def test_hybrid_documentation(extracted_content):
    """Testa geração de documentação híbrida."""
    
    print("\n=== Teste de Documentação Híbrida ===")
    
    generator = HybridDocumentationGenerator()
    
    # Testar diferentes audiências
    audiences = ['executive', 'technical', 'business', 'implementation']
    
    for audience in audiences:
        print(f"\nGerando documentação para audiência: {audience}")
        
        documentation = generator.generate_documentation(
            extracted_content, audience, 'markdown'
        )
        
        # Salvar documentação
        output_file = f"test_results/DOCUMENTACAO_{audience.upper()}.md"
        os.makedirs('test_results', exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(documentation)
        
        print(f"Documentação salva: {output_file}")
        print(f"Tamanho: {len(documentation)} caracteres")
        print(f"Linhas: {documentation.count(chr(10))} linhas")

def test_ai_enrichment(extracted_content):
    """Testa enriquecimento com análise IA simulada."""
    
    print("\n=== Teste de Enriquecimento IA ===")
    
    extractor = COBOLContentExtractor()
    
    # Simular análise IA
    mock_ai_analysis = {
        'success': True,
        'confidence_level': 0.85,
        'parallel_results': {
            'structural': {'success': True, 'analysis': 'Estrutura bem definida'},
            'business': {'success': True, 'analysis': 'Regras de negócio claras'},
            'technical': {'success': True, 'analysis': 'Implementação robusta'},
            'quality': {'success': True, 'analysis': 'Qualidade alta'}
        }
    }
    
    # Enriquecer conteúdo
    enriched_content = extractor.enrich_with_ai_analysis(extracted_content, mock_ai_analysis)
    
    print(f"Enriquecimento IA: {enriched_content['ai_enhancement']}")
    
    # Gerar documentação enriquecida
    generator = HybridDocumentationGenerator()
    enriched_doc = generator.generate_documentation(
        enriched_content, 'technical', 'markdown'
    )
    
    # Salvar documentação enriquecida
    output_file = "test_results/DOCUMENTACAO_ENRIQUECIDA.md"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(enriched_doc)
    
    print(f"Documentação enriquecida salva: {output_file}")
    print(f"Tamanho: {len(enriched_doc)} caracteres")
    
    return enriched_content

def main():
    """Função principal de teste."""
    
    print("Sistema de Análise COBOL v1.0.0 - Teste de Integração Híbrida")
    print("=" * 70)
    
    try:
        # Teste 1: Extração de conteúdo
        extracted_content = test_content_extraction()
        
        # Teste 2: Documentação híbrida
        test_hybrid_documentation(extracted_content)
        
        # Teste 3: Enriquecimento IA
        enriched_content = test_ai_enrichment(extracted_content)
        
        print("\n=== Resumo dos Testes ===")
        print("✅ Extração de conteúdo: SUCESSO")
        print("✅ Documentação híbrida: SUCESSO")
        print("✅ Enriquecimento IA: SUCESSO")
        print("\n🎉 Todos os testes passaram!")
        print("\nArquivos gerados em test_results/:")
        
        # Listar arquivos gerados
        if os.path.exists('test_results'):
            for file in os.listdir('test_results'):
                file_path = os.path.join('test_results', file)
                size = os.path.getsize(file_path)
                print(f"  - {file} ({size:,} bytes)")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Erro durante os testes: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
