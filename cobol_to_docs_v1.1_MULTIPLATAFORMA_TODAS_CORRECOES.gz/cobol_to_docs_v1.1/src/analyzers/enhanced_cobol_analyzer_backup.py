"""
COBOL AI Engine v3.0.0 - Enhanced COBOL Code Analyzer
Analisador aprimorado de código COBOL com foco em análise profunda de comentários e lógica de negócio.
"""

import re
import logging
from typing import Dict, List, Any, Tuple, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict


@dataclass
class EnhancedComment:
    """Comentário analisado com contexto aprimorado."""
    text: str
    line_number: int
    category: str  # 'business', 'technical', 'regulatory', 'historical'
    confidence: float  # 0.0 a 1.0
    keywords: List[str]
    entities: List[str]  # entidades de negócio identificadas
    regulatory_refs: List[str]
    business_impact: str
    change_history: Optional[Dict[str, str]] = None


@dataclass
class LogicFlow:
    """Fluxo lógico identificado no código."""
    name: str
    start_line: int
    end_line: int
    type: str  # 'validation', 'calculation', 'transformation', 'control'
    description: str
    business_purpose: str
    complexity_score: int
    dependencies: List[str]
    data_flow: Dict[str, List[str]]


@dataclass
class BusinessEntity:
    """Entidade de negócio identificada."""
    name: str
    type: str  # 'account', 'customer', 'product', 'operation', 'limit'
    attributes: List[str]
    operations: List[str]
    relationships: List[str]
    regulatory_context: List[str]


@dataclass
class EnhancedCobolAnalysis:
    """Resultado aprimorado da análise COBOL."""
    program_name: str
    analysis_timestamp: datetime
    enhanced_comments: List[EnhancedComment]
    logic_flows: List[LogicFlow]
    business_entities: List[BusinessEntity]
    regulatory_compliance: Dict[str, Any]
    modernization_opportunities: List[Dict[str, Any]]
    quality_metrics: Dict[str, float]
    risk_assessment: Dict[str, Any]


class EnhancedCOBOLAnalyzer:
    """
    Analisador aprimorado de código COBOL com foco em análise profunda
    de comentários e extração de lógica de negócio.
    """
    
    def __init__(self, provider_manager=None, prompt_manager=None):
        self.logger = logging.getLogger(__name__)
        self.provider_manager = provider_manager
        self.prompt_manager = prompt_manager
        
        # Padrões aprimorados para análise de comentários
        self.comment_patterns = {
            'business': {
                'keywords': [
                    'OBJETIVO', 'FUNCIONALIDADE', 'REGRA', 'VALIDAÇÃO', 'CONTROLE',
                    'OPERAÇÃO', 'PRODUTO', 'CLIENTE', 'CONTA', 'LIMITE', 'TAXA',
                    'PROCESSO', 'FLUXO', 'NEGÓCIO', 'BUSINESS', 'REQUIREMENT'
                ],
                'confidence_boost': 0.3
            },
            'regulatory': {
                'keywords': [
                    'LEI', 'CIRCULAR', 'RESOLUÇÃO', 'INSTRUÇÃO', 'NORMATIVO',
                    'BACEN', 'CVM', 'SUSEP', 'PRONAMPE', 'FGI', 'PEAC',
                    'COMPLIANCE', 'AUDITORIA', 'REGULAMENTAÇÃO', 'NORMA'
                ],
                'confidence_boost': 0.4
            },
            'technical': {
                'keywords': [
                    'ARQUIVO', 'CAMPO', 'VARIÁVEL', 'PROCEDURE', 'FUNCTION',
                    'ROTINA', 'MÓDULO', 'SISTEMA', 'PROGRAMA', 'COPYBOOK',
                    'PERFORMANCE', 'OTIMIZAÇÃO', 'BUG', 'FIX', 'CORREÇÃO'
                ],
                'confidence_boost': 0.2
            },
            'historical': {
                'keywords': [
                    'VERSÃO', 'DATA', 'AUTOR', 'ALTERAÇÃO', 'MODIFICAÇÃO',
                    'INCLUSÃO', 'EXCLUSÃO', 'MANUTENÇÃO', 'PROJETO', 'SPRINT'
                ],
                'confidence_boost': 0.1
            }
        }
        
        # Padrões para identificação de entidades de negócio
        self.business_entity_patterns = {
            'account': r'CONTA[S]?[-_\s]*\d*|ACCOUNT[S]?[-_\s]*\d*',
            'customer': r'CLIENTE[S]?[-_\s]*\d*|CUSTOMER[S]?[-_\s]*\d*',
            'product': r'PRODUTO[S]?[-_\s]*\d*|PRODUCT[S]?[-_\s]*\d*',
            'operation': r'OPERAÇÃO|OPERACAO|OPERATION[S]?[-_\s]*\d*',
            'limit': r'LIMITE[S]?[-_\s]*\d*|LIMIT[S]?[-_\s]*\d*',
            'rate': r'TAXA[S]?[-_\s]*\d*|RATE[S]?[-_\s]*\d*',
            'balance': r'SALDO[S]?[-_\s]*\d*|BALANCE[S]?[-_\s]*\d*',
            'transaction': r'TRANSAÇÃO|TRANSACAO|TRANSACTION[S]?[-_\s]*\d*'
        }
        
        # Padrões para análise de fluxo lógico
        self.logic_patterns = {
            'validation': {
                'start': r'IF\s+.*\s+(EQUAL|NOT\s+EQUAL|GREATER|LESS|NUMERIC|ALPHABETIC)',
                'keywords': ['VALIDATE', 'CHECK', 'VERIFY', 'CONTROL']
            },
            'calculation': {
                'start': r'(COMPUTE|ADD|SUBTRACT|MULTIPLY|DIVIDE)',
                'keywords': ['CALCULATE', 'SUM', 'TOTAL', 'AMOUNT']
            },
            'transformation': {
                'start': r'MOVE\s+.*\s+TO',
                'keywords': ['TRANSFORM', 'CONVERT', 'FORMAT']
            },
            'control': {
                'start': r'(PERFORM|CALL|GO\s+TO)',
                'keywords': ['CONTROL', 'FLOW', 'EXECUTE']
            }
        }
        
        # Padrões regulatórios específicos do setor financeiro
        self.regulatory_patterns = {
            'bacen': {
                'patterns': [r'BACEN', r'BANCO\s+CENTRAL', r'BC\s+\d+'],
                'context': 'Regulamentação do Banco Central'
            },
            'circular': {
                'patterns': [r'CIRCULAR\s+\d+', r'CIRC\s+\d+'],
                'context': 'Circular normativa'
            },
            'resolucao': {
                'patterns': [r'RESOLUÇÃO\s+\d+', r'RES\s+\d+'],
                'context': 'Resolução regulatória'
            },
            'pronampe': {
                'patterns': [r'PRONAMPE', r'PROGRAMA\s+NACIONAL'],
                'context': 'Programa Nacional de Apoio às Microempresas'
            },
            'fgi': {
                'patterns': [r'FGI', r'FUNDO\s+GARANTIDOR'],
                'context': 'Fundo Garantidor para Investimentos'
            }
        }
    
    def analyze_program_enhanced(self, code: str, program_name: str) -> EnhancedCobolAnalysis:
        """
        Realiza análise aprimorada do programa COBOL com foco em comentários e lógica.
        """
        self.logger.info(f"Iniciando análise aprimorada do programa {program_name}")
        
        lines = code.split('\n')
        
        # Análise aprimorada de comentários
        enhanced_comments = self._analyze_comments_enhanced(lines)
        
        # Análise de fluxos lógicos
        logic_flows = self._analyze_logic_flows(lines)
        
        # Identificação de entidades de negócio
        business_entities = self._identify_business_entities(lines, enhanced_comments)
        
        # Análise de conformidade regulatória
        regulatory_compliance = self._analyze_regulatory_compliance(enhanced_comments, lines)
        
        # Identificação de oportunidades de modernização
        modernization_opportunities = self._identify_modernization_opportunities(lines, logic_flows)
        
        # Cálculo de métricas de qualidade
        quality_metrics = self._calculate_quality_metrics(lines, enhanced_comments, logic_flows)
        
        # Avaliação de riscos
        risk_assessment = self._assess_risks(enhanced_comments, logic_flows, regulatory_compliance)
        
        result = EnhancedCobolAnalysis(
            program_name=program_name,
            analysis_timestamp=datetime.now(),
            enhanced_comments=enhanced_comments,
            logic_flows=logic_flows,
            business_entities=business_entities,
            regulatory_compliance=regulatory_compliance,
            modernization_opportunities=modernization_opportunities,
            quality_metrics=quality_metrics,
            risk_assessment=risk_assessment
        )
        
        self.logger.info(f"Análise aprimorada concluída: {len(enhanced_comments)} comentários analisados, "
                        f"{len(logic_flows)} fluxos lógicos identificados")
        
        return result
    
    def _analyze_comments_enhanced(self, lines: List[str]) -> List[EnhancedComment]:
        """Análise aprimorada de comentários com categorização e extração de entidades."""
        enhanced_comments = []
        
        for i, line in enumerate(lines):
            if self._is_comment_line(line):
                comment_text = self._extract_comment_text(line)
                
                # Categorizar comentário
                category, confidence = self._categorize_comment(comment_text)
                
                # Extrair palavras-chave
                keywords = self._extract_keywords(comment_text)
                
                # Identificar entidades de negócio
                entities = self._extract_business_entities_from_text(comment_text)
                
                # Extrair referências regulatórias
                regulatory_refs = self._extract_regulatory_references(comment_text)
                
                # Avaliar impacto de negócio
                business_impact = self._assess_business_impact(comment_text, category)
                
                # Analisar histórico de mudanças
                change_history = self._analyze_change_history(comment_text)
                
                enhanced_comment = EnhancedComment(
                    text=comment_text,
                    line_number=i + 1,
                    category=category,
                    confidence=confidence,
                    keywords=keywords,
                    entities=entities,
                    regulatory_refs=regulatory_refs,
                    business_impact=business_impact,
                    change_history=change_history
                )
                
                enhanced_comments.append(enhanced_comment)
        
        return enhanced_comments
    
    def _analyze_logic_flows(self, lines: List[str]) -> List[LogicFlow]:
        """Análise de fluxos lógicos do programa."""
        logic_flows = []
        current_flow = None
        
        for i, line in enumerate(lines):
            line_clean = line.strip().upper()
            
            # Detectar início de fluxo lógico
            for flow_type, patterns in self.logic_patterns.items():
                if re.search(patterns['start'], line_clean):
                    if current_flow:
                        # Finalizar fluxo anterior
                        current_flow.end_line = i
                        logic_flows.append(current_flow)
                    
                    # Iniciar novo fluxo
                    current_flow = self._create_logic_flow(line, i, flow_type, lines)
            
            # Detectar fim de fluxo (END-IF, END-PERFORM, etc.)
            if current_flow and re.search(r'END-(IF|PERFORM|EVALUATE)', line_clean):
                current_flow.end_line = i + 1
                logic_flows.append(current_flow)
                current_flow = None
        
        # Finalizar último fluxo se necessário
        if current_flow:
            current_flow.end_line = len(lines)
            logic_flows.append(current_flow)
        
        return logic_flows
    
    def _identify_business_entities(self, lines: List[str], comments: List[EnhancedComment]) -> List[BusinessEntity]:
        """Identifica entidades de negócio no código e comentários."""
        entities_found = defaultdict(lambda: {
            'attributes': set(),
            'operations': set(),
            'relationships': set(),
            'regulatory_context': set()
        })
        
        # Analisar código
        for line in lines:
            line_upper = line.upper()
            
            for entity_type, pattern in self.business_entity_patterns.items():
                matches = re.findall(pattern, line_upper)
                for match in matches:
                    entity_name = match.strip()
                    if entity_name:
                        # Extrair atributos e operações do contexto
                        context = self._extract_entity_context(line, lines)
                        entities_found[entity_name]['attributes'].update(context['attributes'])
                        entities_found[entity_name]['operations'].update(context['operations'])
        
        # Analisar comentários
        for comment in comments:
            for entity_name in comment.entities:
                entities_found[entity_name]['regulatory_context'].update(comment.regulatory_refs)
        
        # Converter para lista de BusinessEntity
        business_entities = []
        for entity_name, data in entities_found.items():
            entity = BusinessEntity(
                name=entity_name,
                type=self._determine_entity_type(entity_name),
                attributes=list(data['attributes'])[:10],  # Limitar a 10
                operations=list(data['operations'])[:10],
                relationships=list(data['relationships'])[:5],
                regulatory_context=list(data['regulatory_context'])
            )
            business_entities.append(entity)
        
        return business_entities
    
    def _analyze_regulatory_compliance(self, comments: List[EnhancedComment], lines: List[str]) -> Dict[str, Any]:
        """Análise de conformidade regulatória."""
        compliance_data = {
            'regulatory_references': [],
            'compliance_level': 'unknown',
            'risk_areas': [],
            'recommendations': []
        }
        
        # Coletar todas as referências regulatórias
        all_refs = []
        for comment in comments:
            all_refs.extend(comment.regulatory_refs)
        
        compliance_data['regulatory_references'] = list(set(all_refs))
        
        # Avaliar nível de conformidade
        if len(all_refs) > 10:
            compliance_data['compliance_level'] = 'high'
        elif len(all_refs) > 5:
            compliance_data['compliance_level'] = 'medium'
        elif len(all_refs) > 0:
            compliance_data['compliance_level'] = 'low'
        else:
            compliance_data['compliance_level'] = 'none'
        
        # Identificar áreas de risco
        risk_keywords = ['RISCO', 'CRÍTICO', 'IMPORTANTE', 'ATENÇÃO', 'CUIDADO']
        for comment in comments:
            if any(keyword in comment.text.upper() for keyword in risk_keywords):
                compliance_data['risk_areas'].append({
                    'line': comment.line_number,
                    'description': comment.text[:100],
                    'category': comment.category
                })
        
        return compliance_data
    
    def _identify_modernization_opportunities(self, lines: List[str], logic_flows: List[LogicFlow]) -> List[Dict[str, Any]]:
        """Identifica oportunidades de modernização."""
        opportunities = []
        
        # Detectar padrões antigos
        legacy_patterns = {
            'goto_statements': r'GO\s+TO\s+[A-Z0-9-]+',
            'alter_statements': r'ALTER\s+[A-Z0-9-]+',
            'old_file_handling': r'(OPEN|CLOSE)\s+(INPUT|OUTPUT)',
            'sequential_processing': r'READ\s+[A-Z0-9-]+\s+NEXT',
            'fixed_length_records': r'RECORD\s+CONTAINS\s+\d+\s+CHARACTERS'
        }
        
        for pattern_name, pattern in legacy_patterns.items():
            count = sum(1 for line in lines if re.search(pattern, line.upper()))
            if count > 0:
                opportunities.append({
                    'type': 'legacy_pattern',
                    'pattern': pattern_name,
                    'occurrences': count,
                    'recommendation': self._get_modernization_recommendation(pattern_name),
                    'priority': self._get_modernization_priority(pattern_name)
                })
        
        # Analisar complexidade dos fluxos
        complex_flows = [flow for flow in logic_flows if flow.complexity_score > 7]
        if complex_flows:
            opportunities.append({
                'type': 'complexity_reduction',
                'description': f'{len(complex_flows)} fluxos com alta complexidade identificados',
                'recommendation': 'Considerar refatoração para reduzir complexidade',
                'priority': 'medium'
            })
        
        return opportunities
    
    def _calculate_quality_metrics(self, lines: List[str], comments: List[EnhancedComment], 
                                 logic_flows: List[LogicFlow]) -> Dict[str, float]:
        """Calcula métricas de qualidade do código."""
        total_lines = len(lines)
        code_lines = sum(1 for line in lines if line.strip() and not self._is_comment_line(line))
        comment_lines = len(comments)
        
        metrics = {
            'comment_ratio': comment_lines / total_lines if total_lines > 0 else 0,
            'business_comment_ratio': len([c for c in comments if c.category == 'business']) / comment_lines if comment_lines > 0 else 0,
            'regulatory_coverage': len([c for c in comments if c.regulatory_refs]) / comment_lines if comment_lines > 0 else 0,
            'average_flow_complexity': sum(flow.complexity_score for flow in logic_flows) / len(logic_flows) if logic_flows else 0,
            'maintainability_index': self._calculate_maintainability_index(code_lines, comment_lines, logic_flows)
        }
        
        return metrics
    
    def _assess_risks(self, comments: List[EnhancedComment], logic_flows: List[LogicFlow], 
                     regulatory_compliance: Dict[str, Any]) -> Dict[str, Any]:
        """Avalia riscos do programa."""
        risks = {
            'overall_risk_level': 'low',
            'risk_factors': [],
            'mitigation_recommendations': []
        }
        
        risk_score = 0
        
        # Avaliar riscos baseados em comentários
        high_risk_comments = [c for c in comments if 'CRÍTICO' in c.text.upper() or 'RISCO' in c.text.upper()]
        if high_risk_comments:
            risk_score += len(high_risk_comments) * 2
            risks['risk_factors'].append(f'{len(high_risk_comments)} comentários indicam áreas críticas')
        
        # Avaliar riscos de complexidade
        complex_flows = [f for f in logic_flows if f.complexity_score > 8]
        if complex_flows:
            risk_score += len(complex_flows)
            risks['risk_factors'].append(f'{len(complex_flows)} fluxos com alta complexidade')
        
        # Avaliar riscos regulatórios
        if regulatory_compliance['compliance_level'] == 'none':
            risk_score += 5
            risks['risk_factors'].append('Ausência de referências regulatórias')
        
        # Determinar nível de risco geral
        if risk_score > 10:
            risks['overall_risk_level'] = 'high'
        elif risk_score > 5:
            risks['overall_risk_level'] = 'medium'
        
        return risks
    
    # Métodos auxiliares
    def _is_comment_line(self, line: str) -> bool:
        """Verifica se a linha é um comentário."""
        stripped = line.strip()
        # Verificar comentários COBOL padrão
        if stripped.startswith('*') or stripped.startswith('C') or stripped.startswith('//'):
            return True
        # Verificar comentários com prefixo (ex: V*, VRESPON*, etc.)
        if len(line) > 7 and line[6] == '*':
            return True
        # Verificar linhas que começam com V seguido de *
        if stripped.startswith('V*') or stripped.startswith('V ') and '*' in line[:10]:
            return True
        return False
    
    def _extract_comment_text(self, line: str) -> str:
        """Extrai o texto do comentário."""
        stripped = line.strip()
        if stripped.startswith('*'):
            return stripped[1:].strip()
        elif stripped.startswith('C'):
            return stripped[1:].strip()
        elif stripped.startswith('//'):
            return stripped[2:].strip()
        elif len(line) > 7 and line[6] == '*':
            # Comentário com prefixo (ex: V*, VRESPON*)
            return line[7:].strip()
        elif stripped.startswith('V*'):
            return stripped[2:].strip()
        elif stripped.startswith('V ') and '*' in line[:10]:
            # Encontrar posição do * e extrair texto após ele
            star_pos = line.find('*')
            if star_pos != -1:
                return line[star_pos+1:].strip()
        return stripped
    
    def _categorize_comment(self, text: str) -> Tuple[str, float]:
        """Categoriza um comentário e retorna a confiança."""
        text_upper = text.upper()
        scores = {}
        
        for category, data in self.comment_patterns.items():
            score = 0
            for keyword in data['keywords']:
                if keyword in text_upper:
                    score += 1
            
            if score > 0:
                scores[category] = score * data['confidence_boost']
        
        if not scores:
            return 'technical', 0.1
        
        best_category = max(scores, key=scores.get)
        confidence = min(scores[best_category], 1.0)
        
        return best_category, confidence
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Extrai palavras-chave relevantes do texto."""
        text_upper = text.upper()
        keywords = []
        
        for category_data in self.comment_patterns.values():
            for keyword in category_data['keywords']:
                if keyword in text_upper:
                    keywords.append(keyword)
        
        return list(set(keywords))
    
    def _extract_business_entities_from_text(self, text: str) -> List[str]:
        """Extrai entidades de negócio do texto."""
        entities = []
        text_upper = text.upper()
        
        for entity_type, pattern in self.business_entity_patterns.items():
            matches = re.findall(pattern, text_upper)
            entities.extend(matches)
        
        return list(set(entities))
    
    def _extract_regulatory_references(self, text: str) -> List[str]:
        """Extrai referências regulatórias do texto."""
        references = []
        text_upper = text.upper()
        
        for reg_type, data in self.regulatory_patterns.items():
            for pattern in data['patterns']:
                matches = re.findall(pattern, text_upper)
                references.extend(matches)
        
        return list(set(references))
    
    def _assess_business_impact(self, text: str, category: str) -> str:
        """Avalia o impacto de negócio do comentário."""
        text_upper = text.upper()
        
        if category == 'regulatory':
            return 'alto - conformidade regulatória'
        elif category == 'business':
            if any(word in text_upper for word in ['CRÍTICO', 'IMPORTANTE', 'ESSENCIAL']):
                return 'alto - funcionalidade crítica'
            else:
                return 'médio - funcionalidade de negócio'
        elif category == 'technical':
            return 'baixo - aspecto técnico'
        else:
            return 'baixo - informativo'
    
    def _analyze_change_history(self, text: str) -> Optional[Dict[str, str]]:
        """Analisa histórico de mudanças no comentário."""
        text_upper = text.upper()
        
        # Padrões para identificar mudanças
        date_pattern = r'\d{2}/\d{2}/\d{2,4}'
        version_pattern = r'V\d+|\d+\.\d+'
        author_pattern = r'[A-Z]{2,}\s*[A-Z]*'
        
        date_match = re.search(date_pattern, text)
        version_match = re.search(version_pattern, text_upper)
        
        if date_match or version_match:
            return {
                'date': date_match.group() if date_match else 'não identificada',
                'version': version_match.group() if version_match else 'não identificada',
                'type': 'modificação' if 'ALTERAÇÃO' in text_upper else 'inclusão'
            }
        
        return None
    
    def _create_logic_flow(self, line: str, line_number: int, flow_type: str, lines: List[str]) -> LogicFlow:
        """Cria um objeto LogicFlow."""
        return LogicFlow(
            name=f"{flow_type}_{line_number}",
            start_line=line_number + 1,
            end_line=line_number + 1,  # Será atualizado posteriormente
            type=flow_type,
            description=line.strip()[:100],
            business_purpose=self._infer_business_purpose(line, flow_type),
            complexity_score=self._calculate_flow_complexity(line),
            dependencies=[],
            data_flow={}
        )
    
    def _infer_business_purpose(self, line: str, flow_type: str) -> str:
        """Infere o propósito de negócio de um fluxo lógico."""
        line_upper = line.upper()
        
        if flow_type == 'validation':
            if any(word in line_upper for word in ['CONTA', 'CLIENTE', 'PRODUTO']):
                return 'validação de dados de negócio'
            else:
                return 'validação técnica'
        elif flow_type == 'calculation':
            if any(word in line_upper for word in ['VALOR', 'TAXA', 'SALDO', 'LIMITE']):
                return 'cálculo financeiro'
            else:
                return 'processamento numérico'
        elif flow_type == 'transformation':
            return 'transformação de dados'
        else:
            return 'controle de fluxo'
    
    def _calculate_flow_complexity(self, line: str) -> int:
        """Calcula a complexidade de um fluxo lógico."""
        complexity = 1
        line_upper = line.upper()
        
        # Aumentar complexidade baseado em operadores
        if 'AND' in line_upper:
            complexity += line_upper.count('AND')
        if 'OR' in line_upper:
            complexity += line_upper.count('OR') * 2
        if 'NOT' in line_upper:
            complexity += line_upper.count('NOT')
        
        return min(complexity, 10)  # Limitar a 10
    
    def _extract_entity_context(self, line: str, lines: List[str]) -> Dict[str, List[str]]:
        """Extrai contexto de uma entidade de negócio."""
        return {
            'attributes': [],
            'operations': []
        }
    
    def _determine_entity_type(self, entity_name: str) -> str:
        """Determina o tipo de uma entidade de negócio."""
        entity_upper = entity_name.upper()
        
        for entity_type, pattern in self.business_entity_patterns.items():
            if re.search(pattern, entity_upper):
                return entity_type
        
        return 'unknown'
    
    def _get_modernization_recommendation(self, pattern_name: str) -> str:
        """Retorna recomendação de modernização para um padrão."""
        recommendations = {
            'goto_statements': 'Substituir por estruturas de controle estruturadas (IF-ELSE, PERFORM)',
            'alter_statements': 'Remover ALTER e usar lógica estruturada',
            'old_file_handling': 'Considerar uso de SQL ou APIs modernas',
            'sequential_processing': 'Avaliar processamento em lote ou paralelo',
            'fixed_length_records': 'Migrar para formatos flexíveis (JSON, XML)'
        }
        return recommendations.get(pattern_name, 'Revisar para padrões modernos')
    
    def _get_modernization_priority(self, pattern_name: str) -> str:
        """Retorna prioridade de modernização."""
        priorities = {
            'goto_statements': 'high',
            'alter_statements': 'high',
            'old_file_handling': 'medium',
            'sequential_processing': 'low',
            'fixed_length_records': 'low'
        }
        return priorities.get(pattern_name, 'medium')
    
    def _calculate_maintainability_index(self, code_lines: int, comment_lines: int, 
                                       logic_flows: List[LogicFlow]) -> float:
        """Calcula índice de manutenibilidade."""
        if code_lines == 0:
            return 0.0
        
        comment_ratio = comment_lines / code_lines
        avg_complexity = sum(flow.complexity_score for flow in logic_flows) / len(logic_flows) if logic_flows else 1
        
        # Fórmula simplificada de manutenibilidade
        maintainability = (comment_ratio * 30) + (10 / avg_complexity) + 60
        
        return min(max(maintainability, 0), 100)  # Limitar entre 0 e 100
