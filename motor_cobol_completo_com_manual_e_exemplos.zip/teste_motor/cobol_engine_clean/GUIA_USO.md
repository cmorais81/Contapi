# Motor de Documentação COBOL - Guia de Uso

## Início Rápido

### 1. Análise de Arquivo Único

Analisar um programa COBOL individual:

```bash
python cobol_engine.py analyze programa.cbl --output ./resultados
```

**Exemplo de Saída:**
```
Analisando arquivo: programa.cbl
Analisadores: security_analyzer, performance_analyzer
Formato de saída: json

           Resultados da Análise           
┏━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━┓
┃ Métrica           ┃ Valor          ┃
┡━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━┩
│ Status            │ Sucesso        │
│ ID do Programa    │ SAMPLE-PROGRAM │
│ Pontuação Segurança│ 93/100        │
│ Pontuação Performance│ 100/100     │
└───────────────────┴────────────────┘

Análise completa!
Resultados salvos em: ./resultados/programa_analysis.json
```

### 2. Análise em Lote (Arquivo ZIP)

Analisar múltiplos programas COBOL de um arquivo ZIP:

```bash
python cobol_engine.py batch portfolio.zip --output ./resultados_lote
```

**Exemplo de Saída:**
```
Fonte: portfolio.zip
Analisadores: security_analyzer, performance_analyzer
Processamento paralelo: Ativo

             Resultados da Análise em Lote              
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━┓
┃ Métrica                   ┃ Valor             ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━┩
│ Total de Arquivos         │ 25                │
│ Processados com Sucesso   │ 24                │
│ Falharam                  │ 1                 │
│ Taxa de Sucesso           │ 96.0%             │
│ Pontuação Média Segurança │ 87.3/100          │
│ Pontuação Média Performance│ 78.9/100         │
└───────────────────────────┴───────────────────┘

Análise em lote completa!
Resultados salvos em: ./resultados_lote
```

### 3. Análise de Diretório

Analisar todos os arquivos COBOL em um diretório:

```bash
python cobol_engine.py batch /caminho/para/arquivos/cobol --output ./resultados_diretorio
```

## Referência de Comandos

### Comando analyze

```bash
python cobol_engine.py analyze <arquivo> [opções]
```

**Opções:**
- `--output, -o`: Diretório de saída (padrão: ./output)
- `--format, -f`: Formato de saída (json, yaml, markdown)
- `--analyzers, -a`: Analisadores específicos para executar

**Exemplos:**
```bash
# Análise básica
python cobol_engine.py analyze programa.cbl

# Diretório de saída e formato customizados
python cobol_engine.py analyze programa.cbl --output ./meus_resultados --format markdown

# Executar apenas análise de segurança
python cobol_engine.py analyze programa.cbl --analyzers security_analyzer

# Executar múltiplos analisadores específicos
python cobol_engine.py analyze programa.cbl --analyzers security_analyzer performance_analyzer
```

### Comando batch

```bash
python cobol_engine.py batch <fonte> --output <diretório> [opções]
```

**Opções:**
- `--output, -o`: Diretório de saída (obrigatório)
- `--format, -f`: Formato de saída para arquivos individuais (json, yaml, markdown)
- `--analyzers, -a`: Analisadores específicos para executar
- `--parallel`: Habilitar processamento paralelo (padrão: True)
- `--max-workers`: Número máximo de workers paralelos (padrão: 4)

**Exemplos:**
```bash
# Análise em lote básica
python cobol_engine.py batch portfolio.zip --output ./resultados

# Processamento sequencial (para recursos limitados)
python cobol_engine.py batch portfolio.zip --output ./resultados --parallel false

# Processamento paralelo de alta performance
python cobol_engine.py batch portfolio_grande.zip --output ./resultados --max-workers 8

# Análise focada em segurança
python cobol_engine.py batch portfolio.zip --output ./auditoria_seguranca --analyzers security_analyzer

# Formato customizado para arquivos individuais
python cobol_engine.py batch portfolio.zip --output ./resultados --format yaml
```

### Comando info

```bash
python cobol_engine.py info [opções]
```

**Opções:**
- `--analyzers`: Mostrar analisadores disponíveis
- `--formatters`: Mostrar formatadores disponíveis

**Exemplos:**
```bash
# Mostrar todas as informações
python cobol_engine.py info

# Mostrar apenas analisadores
python cobol_engine.py info --analyzers

# Mostrar apenas formatadores
python cobol_engine.py info --formatters
```

## Formatos de Saída

### Formato JSON

Formato de dados estruturado ideal para integração com outras ferramentas:

```json
{
  "analyzer_name": "engine",
  "program_id": "SAMPLE-PROGRAM",
  "success": true,
  "execution_time": 0.15,
  "data": {
    "program_info": {
      "program_id": "SAMPLE-PROGRAM",
      "lines_of_code": 75,
      "variables_count": 5,
      "total_complexity": 8
    },
    "analyzer_results": {
      "security_analyzer": {
        "security_score": 93,
        "issues": [],
        "compliance_status": "COMPLIANT"
      },
      "performance_analyzer": {
        "performance_score": 100,
        "complexity": "LOW",
        "optimizations": []
      }
    }
  }
}
```

### Formato YAML

Formato estruturado legível para humanos:

```yaml
analyzer_name: engine
program_id: SAMPLE-PROGRAM
success: true
execution_time: 0.15
data:
  program_info:
    program_id: SAMPLE-PROGRAM
    lines_of_code: 75
    variables_count: 5
    total_complexity: 8
  analyzer_results:
    security_analyzer:
      security_score: 93
      compliance_status: COMPLIANT
    performance_analyzer:
      performance_score: 100
      complexity: LOW
```

### Formato Markdown

Formato pronto para documentação:

```markdown
# Relatório de Análise - SAMPLE-PROGRAM

## Informações Básicas
- **ID do Programa**: SAMPLE-PROGRAM
- **Sucesso**: Sim
- **Linhas de Código**: 75
- **Variáveis**: 5
- **Complexidade**: 8

## Resultados da Análise

### Análise de Segurança
- **Pontuação de Segurança**: 93/100
- **Status de Compliance**: COMPLIANT
- **Problemas Encontrados**: 0

### Análise de Performance
- **Pontuação de Performance**: 100/100
- **Complexidade**: LOW
- **Otimizações**: Nenhuma necessária
```

## Resultados do Processamento em Lote

### Arquivos Individuais

Cada arquivo COBOL recebe seu próprio arquivo de análise:
- `programa1_analysis.json`
- `programa2_analysis.json`
- `programa3_analysis.json`

### Relatório Consolidado

Um relatório resumo em formato Markdown:
- `consolidated_report.md`

**Exemplo de Relatório Consolidado:**
```markdown
# Relatório de Análise em Lote

## Estatísticas Resumidas
- **Total de Arquivos**: 25
- **Processados com Sucesso**: 24
- **Falharam**: 1
- **Taxa de Sucesso**: 96.0%
- **Total de Linhas de Código**: 12,500
- **Velocidade de Processamento**: 450.2 arquivos/min

## Métricas Consolidadas
### Análise de Segurança
- **Pontuação Média**: 87.3/100
- **Melhor Pontuação**: 98/100
- **Pior Pontuação**: 65/100

### Análise de Performance
- **Pontuação Média**: 78.9/100
- **Melhor Pontuação**: 95/100
- **Pior Pontuação**: 45/100

## Resultados por Arquivo
| Arquivo | Status | ID do Programa | Linhas | Segurança | Performance |
|---------|--------|----------------|--------|-----------|-------------|
| payroll.cbl | Sucesso | PAYROLL-CALC | 450 | 92/100 | 85/100 |
| customer.cbl | Sucesso | CUST-MGMT | 320 | 88/100 | 78/100 |
| inventory.cbl | Falhou | - | - | - | - |
```

## Casos de Uso

### 1. Auditoria de Segurança

Focar na análise de segurança para compliance:

```bash
# Análise apenas de segurança
python cobol_engine.py batch sistema.zip \
  --output ./auditoria_seguranca \
  --analyzers security_analyzer \
  --format markdown

# Revisar resultados
cat ./auditoria_seguranca/consolidated_report.md
```

### 2. Otimização de Performance

Identificar gargalos de performance:

```bash
# Análise focada em performance
python cobol_engine.py batch jobs_criticos.zip \
  --output ./revisao_performance \
  --analyzers performance_analyzer \
  --max-workers 8

# Encontrar programas com baixa pontuação de performance
grep -l "performance_score.*[0-4][0-9]" ./revisao_performance/*.json
```

### 3. Avaliação de Qualidade de Código

Revisão abrangente de qualidade:

```bash
# Análise completa com todos os analisadores
python cobol_engine.py batch sistema_legado.zip \
  --output ./avaliacao_qualidade \
  --format yaml

# Gerar estatísticas resumidas
python -c "
import json, glob
scores = []
for f in glob.glob('./avaliacao_qualidade/*.json'):
    with open(f) as file:
        data = json.load(file)
        if 'analyzer_results' in data['data']:
            sec = data['data']['analyzer_results'].get('security_analyzer', {}).get('security_score', 0)
            perf = data['data']['analyzer_results'].get('performance_analyzer', {}).get('performance_score', 0)
            scores.append((sec, perf))

if scores:
    avg_sec = sum(s[0] for s in scores) / len(scores)
    avg_perf = sum(s[1] for s in scores) / len(scores)
    print(f'Pontuação Média de Segurança: {avg_sec:.1f}/100')
    print(f'Pontuação Média de Performance: {avg_perf:.1f}/100')
"
```

### 4. Geração de Documentação

Criar documentação abrangente:

```bash
# Gerar documentação markdown para todos os programas
python cobol_engine.py batch fonte_documentacao.zip \
  --output ./docs_programas \
  --format markdown

# Combinar toda a documentação
cat ./docs_programas/*.md > documentacao_completa_sistema.md
```

## Dicas e Melhores Práticas

### Otimização de Performance

1. **Usar processamento paralelo** para portfolios grandes:
   ```bash
   --parallel --max-workers 8
   ```

2. **Limitar analisadores** para processamento mais rápido:
   ```bash
   --analyzers security_analyzer  # Apenas segurança
   ```

3. **Processar em lotes** para sistemas muito grandes:
   ```bash
   # Dividir ZIP grande em menores
   python cobol_engine.py batch parte1.zip --output ./resultados1
   python cobol_engine.py batch parte2.zip --output ./resultados2
   ```

### Gerenciamento de Recursos

1. **Monitorar uso de memória** com portfolios grandes
2. **Usar processamento sequencial** em recursos limitados:
   ```bash
   --parallel false
   ```
3. **Ajustar número de workers** baseado nos cores de CPU disponíveis

### Organização de Saída

1. **Usar diretórios de saída descritivos**:
   ```bash
   --output ./auditoria_seguranca_2024_q3
   ```

2. **Separar diferentes tipos de análise**:
   ```bash
   # Auditoria de segurança
   python cobol_engine.py batch sistema.zip --output ./seguranca --analyzers security_analyzer
   
   # Revisão de performance
   python cobol_engine.py batch sistema.zip --output ./performance --analyzers performance_analyzer
   ```

3. **Arquivar resultados** para comparação histórica:
   ```bash
   tar -czf analise_$(date +%Y%m%d).tar.gz ./resultados/
   ```

## Solução de Problemas

### Problemas Comuns

1. **Erros de arquivo não encontrado**:
   - Verificar se os caminhos dos arquivos estão corretos
   - Verificar permissões de arquivo
   - Garantir que arquivos COBOL tenham extensões corretas (.cbl, .cob, .cobol, .txt)

2. **Erros de memória com portfolios grandes**:
   - Reduzir `--max-workers`
   - Usar `--parallel false`
   - Processar em lotes menores

3. **Erros de parsing**:
   - Verificar sintaxe COBOL
   - Verificar codificação do arquivo (UTF-8 recomendado)
   - Revisar mensagens de erro na saída

### Obtendo Ajuda

```bash
# Mostrar ajuda do comando
python cobol_engine.py --help
python cobol_engine.py analyze --help
python cobol_engine.py batch --help

# Mostrar informações do motor
python cobol_engine.py info

# Executar com saída verbosa (se disponível)
python cobol_engine.py analyze programa.cbl --verbose
```

## Exemplos de Integração

### Pipeline CI/CD

```yaml
# .github/workflows/analise-cobol.yml
name: Análise COBOL
on: [push, pull_request]

jobs:
  analyze:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Configurar Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.11'
      - name: Instalar dependências
        run: pip install -r requirements.txt
      - name: Analisar código COBOL
        run: |
          python cobol_engine.py batch ./src_cobol --output ./analise
          # Falhar se pontuação de segurança for muito baixa
          python -c "
          import json, sys
          with open('./analise/consolidated_report.md') as f:
              content = f.read()
              if 'Pontuação Média de Segurança: ' in content:
                  score = float(content.split('Pontuação Média de Segurança: ')[1].split('/')[0])
                  if score < 80:
                      print(f'Pontuação de segurança {score} abaixo do limite')
                      sys.exit(1)
          "
```

### Relatório Automatizado

```bash
#!/bin/bash
# analise_semanal.sh

DATA=$(date +%Y%m%d)
DIR_SAIDA="./analise_$DATA"

# Executar análise
python cobol_engine.py batch codigo_producao.zip --output "$DIR_SAIDA"

# Gerar email de resumo
{
    echo "Relatório Semanal de Análise COBOL - $DATA"
    echo "=========================================="
    echo ""
    cat "$DIR_SAIDA/consolidated_report.md"
} | mail -s "Relatório de Análise COBOL $DATA" equipe@empresa.com

# Arquivar resultados
tar -czf "analise_$DATA.tar.gz" "$DIR_SAIDA"
```

Este guia cobre os padrões de uso essenciais para o Motor de Documentação COBOL. Para recursos avançados e customização, consulte o README.md principal e a documentação do código fonte.

