# Analysis Report - SISTEMA-FINANCEIRO

## Basic Information

- **Program ID**: SISTEMA-FINANCEIRO
- **Analyzer**: engine
- **Success**: ✅
- **Execution Time**: 0.00s

## Program Information

- **File Path**: portfolio_teste/sistema_financeiro.cbl
- **Author**: EQUIPE-DESENVOLVIMENTO.
- **Date Written**: 15/11/2024.
- **Lines of Code**: 126
- **Variables**: 6
- **Sections**: 3
- **Paragraphs**: 3
- **Total Complexity**: 0

## Analysis Results

### Security Analyzer

- **Security Score**: 86/100
- **Issues Found**: 2
- **Compliance Status**: NEEDS_REVIEW

### Performance Analyzer

- **Performance Score**: 93/100
- **Complexity**: LOW
- **Issues Found**: 2
