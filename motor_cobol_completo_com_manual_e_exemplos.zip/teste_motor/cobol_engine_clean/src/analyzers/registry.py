"""
Analyzer registry following Registry pattern and Dependency Inversion.
"""

from typing import Dict, List, Optional
from ..interfaces.analyzer import IAnalyzer
from .security import SecurityAnalyzer
from .performance import PerformanceAnalyzer


class AnalyzerRegistry:
    """
    Registry for analyzers following Registry pattern.
    Following Open/Closed Principle - open for extension, closed for modification.
    """
    
    def __init__(self):
        self._analyzers: Dict[str, IAnalyzer] = {}
        self._register_default_analyzers()
    
    def _register_default_analyzers(self):
        """Register default analyzers."""
        self.register_analyzer(SecurityAnalyzer())
        self.register_analyzer(PerformanceAnalyzer())
    
    def register_analyzer(self, analyzer: IAnalyzer):
        """
        Register an analyzer.
        
        Args:
            analyzer: Analyzer instance to register
        """
        self._analyzers[analyzer.name] = analyzer
    
    def get_analyzer(self, name: str) -> Optional[IAnalyzer]:
        """
        Get analyzer by name.
        
        Args:
            name: Analyzer name
            
        Returns:
            Analyzer instance or None if not found
        """
        return self._analyzers.get(name)
    
    def get_analyzer_names(self) -> List[str]:
        """
        Get list of available analyzer names.
        
        Returns:
            List of analyzer names
        """
        return list(self._analyzers.keys())
    
    def get_all_analyzers(self) -> Dict[str, IAnalyzer]:
        """
        Get all registered analyzers.
        
        Returns:
            Dictionary of analyzer name -> analyzer instance
        """
        return self._analyzers.copy()
    
    def unregister_analyzer(self, name: str) -> bool:
        """
        Unregister an analyzer.
        
        Args:
            name: Analyzer name to unregister
            
        Returns:
            True if analyzer was found and removed
        """
        if name in self._analyzers:
            del self._analyzers[name]
            return True
        return False

