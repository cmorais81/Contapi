"""
Security analyzer following SOLID principles.
"""

import re
from typing import Dict, Any, List
from ..interfaces.analyzer import ISecurityAnalyzer
from ..core.models import CobolProgram, AnalysisResult
from ..utils.exceptions import AnalyzerError


class SecurityAnalyzer(ISecurityAnalyzer):
    """
    Security analyzer implementation.
    Following Single Responsibility Principle - only security analysis.
    """
    
    def __init__(self):
        self._config = {
            'check_input_validation': True,
            'check_file_operations': True,
            'check_data_exposure': True,
            'check_error_handling': True,
            'severity_weights': {
                'CRITICAL': 10,
                'HIGH': 7,
                'MEDIUM': 4,
                'LOW': 1
            }
        }
        self._setup_patterns()
    
    def _setup_patterns(self):
        """Setup security check patterns."""
        self.patterns = {
            'accept_statement': re.compile(r'ACCEPT\s+([A-Z0-9\-]+)', re.IGNORECASE),
            'display_statement': re.compile(r'DISPLAY\s+(.+)', re.IGNORECASE),
            'file_operations': re.compile(r'(OPEN|READ|WRITE|CLOSE)\s+', re.IGNORECASE),
            'move_statement': re.compile(r'MOVE\s+(.+?)\s+TO\s+(.+)', re.IGNORECASE),
            'if_statement': re.compile(r'IF\s+', re.IGNORECASE),
            'error_handling': re.compile(r'(AT\s+END|INVALID\s+KEY|FILE\s+STATUS)', re.IGNORECASE)
        }
    
    @property
    def name(self) -> str:
        return "security_analyzer"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    def analyze(self, program: CobolProgram) -> AnalysisResult:
        """Analyze program for security issues."""
        result = AnalysisResult(
            analyzer_name=self.name,
            program_id=program.program_id,
            success=True
        )
        
        try:
            # Perform security checks
            issues = []
            
            if self._config['check_input_validation']:
                issues.extend(self._check_input_validation(program))
            
            if self._config['check_file_operations']:
                issues.extend(self._check_file_operations(program))
            
            if self._config['check_data_exposure']:
                issues.extend(self._check_data_exposure(program))
            
            if self._config['check_error_handling']:
                issues.extend(self._check_error_handling(program))
            
            # Calculate security score
            security_score = self._calculate_security_score(issues, program)
            
            # Determine compliance status
            compliance_status = self._determine_compliance_status(security_score, issues)
            
            # Store results
            result.data = {
                'security_score': security_score,
                'issues': issues,
                'compliance_status': compliance_status,
                'total_issues': len(issues),
                'critical_issues': len([i for i in issues if i['severity'] == 'CRITICAL']),
                'high_issues': len([i for i in issues if i['severity'] == 'HIGH']),
                'medium_issues': len([i for i in issues if i['severity'] == 'MEDIUM']),
                'low_issues': len([i for i in issues if i['severity'] == 'LOW']),
                'recommendations': self._generate_recommendations(issues)
            }
            
        except Exception as e:
            result.success = False
            result.add_error(f"Security analysis failed: {e}")
        
        return result
    
    def get_security_score(self, program: CobolProgram) -> int:
        """Get security score (0-100)."""
        result = self.analyze(program)
        return result.data.get('security_score', 0) if result.success else 0
    
    def get_vulnerabilities(self, program: CobolProgram) -> list:
        """Get list of security vulnerabilities."""
        result = self.analyze(program)
        return result.data.get('issues', []) if result.success else []
    
    def get_configuration(self) -> Dict[str, Any]:
        """Get analyzer configuration."""
        return self._config.copy()
    
    def set_configuration(self, config: Dict[str, Any]) -> None:
        """Set analyzer configuration."""
        self._config.update(config)
    
    def _check_input_validation(self, program: CobolProgram) -> List[Dict[str, Any]]:
        """Check for input validation issues."""
        issues = []
        
        # Read file content for statement analysis
        if program.file_path and program.file_path != "unknown":
            try:
                with open(program.file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    lines = content.split('\n')
            except:
                return issues
        else:
            return issues
        
        # Check ACCEPT statements without validation
        for line_num, line in enumerate(lines, 1):
            if self.patterns['accept_statement'].search(line):
                # Check if next few lines have validation
                has_validation = False
                for check_line in lines[line_num:line_num+3]:
                    if self.patterns['if_statement'].search(check_line):
                        has_validation = True
                        break
                
                if not has_validation:
                    issues.append({
                        'type': 'INPUT_VALIDATION',
                        'severity': 'MEDIUM',
                        'line': line_num,
                        'description': 'ACCEPT statement without input validation',
                        'recommendation': 'Add validation after ACCEPT statement'
                    })
        
        return issues
    
    def _check_file_operations(self, program: CobolProgram) -> List[Dict[str, Any]]:
        """Check for file operation security issues."""
        issues = []
        
        # Check for missing FILE STATUS handling
        for file_def in program.files:
            if not file_def.file_status:
                issues.append({
                    'type': 'FILE_SECURITY',
                    'severity': 'HIGH',
                    'description': f'File {file_def.name} lacks FILE STATUS handling',
                    'recommendation': 'Add FILE STATUS clause for error handling'
                })
        
        return issues
    
    def _check_data_exposure(self, program: CobolProgram) -> List[Dict[str, Any]]:
        """Check for data exposure issues."""
        issues = []
        
        # Check for sensitive data in DISPLAY statements
        if program.file_path and program.file_path != "unknown":
            try:
                with open(program.file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    lines = content.split('\n')
            except:
                return issues
        else:
            return issues
        
        sensitive_keywords = ['PASSWORD', 'SSN', 'CREDIT', 'ACCOUNT', 'PIN']
        
        for line_num, line in enumerate(lines, 1):
            display_match = self.patterns['display_statement'].search(line)
            if display_match:
                display_content = display_match.group(1).upper()
                for keyword in sensitive_keywords:
                    if keyword in display_content:
                        issues.append({
                            'type': 'DATA_EXPOSURE',
                            'severity': 'HIGH',
                            'line': line_num,
                            'description': f'Potential sensitive data exposure in DISPLAY: {keyword}',
                            'recommendation': 'Avoid displaying sensitive information'
                        })
        
        return issues
    
    def _check_error_handling(self, program: CobolProgram) -> List[Dict[str, Any]]:
        """Check for error handling issues."""
        issues = []
        
        if program.file_path and program.file_path != "unknown":
            try:
                with open(program.file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    lines = content.split('\n')
            except:
                return issues
        else:
            return issues
        
        file_ops = 0
        error_handlers = 0
        
        for line in lines:
            if self.patterns['file_operations'].search(line):
                file_ops += 1
            if self.patterns['error_handling'].search(line):
                error_handlers += 1
        
        if file_ops > 0 and error_handlers == 0:
            issues.append({
                'type': 'ERROR_HANDLING',
                'severity': 'HIGH',
                'description': 'File operations without error handling',
                'recommendation': 'Add AT END, INVALID KEY, or FILE STATUS checks'
            })
        
        return issues
    
    def _calculate_security_score(self, issues: List[Dict[str, Any]], program: CobolProgram) -> int:
        """Calculate security score based on issues."""
        base_score = 100
        
        # Deduct points based on severity
        for issue in issues:
            severity = issue['severity']
            weight = self._config['severity_weights'].get(severity, 1)
            base_score -= weight
        
        # Ensure score is between 0 and 100
        return max(0, min(100, base_score))
    
    def _determine_compliance_status(self, score: int, issues: List[Dict[str, Any]]) -> str:
        """Determine compliance status."""
        critical_issues = [i for i in issues if i['severity'] == 'CRITICAL']
        high_issues = [i for i in issues if i['severity'] == 'HIGH']
        
        if critical_issues:
            return "NON_COMPLIANT"
        elif high_issues or score < 70:
            return "NEEDS_REVIEW"
        elif score >= 90:
            return "COMPLIANT"
        else:
            return "ACCEPTABLE"
    
    def _generate_recommendations(self, issues: List[Dict[str, Any]]) -> List[str]:
        """Generate security recommendations."""
        recommendations = []
        
        issue_types = set(issue['type'] for issue in issues)
        
        if 'INPUT_VALIDATION' in issue_types:
            recommendations.append("Implement input validation for all ACCEPT statements")
        
        if 'FILE_SECURITY' in issue_types:
            recommendations.append("Add FILE STATUS handling for all file operations")
        
        if 'DATA_EXPOSURE' in issue_types:
            recommendations.append("Review DISPLAY statements for sensitive data exposure")
        
        if 'ERROR_HANDLING' in issue_types:
            recommendations.append("Implement comprehensive error handling for file operations")
        
        if not recommendations:
            recommendations.append("Security analysis passed - maintain current security practices")
        
        return recommendations

