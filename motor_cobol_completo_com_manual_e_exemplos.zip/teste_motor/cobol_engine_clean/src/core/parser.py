"""
COBOL Parser implementation following SOLID principles.
"""

import os
import re
from typing import List, Optional, Dict, Any
from ..interfaces.parser import IParser, ICopyBookResolver
from .models import CobolProgram, CobolVariable, CobolSection, CobolParagraph, FileDefinition
from ..utils.exceptions import ParseError, FileNotFoundError


class CopyBookResolver(ICopyBookResolver):
    """
    COPY book resolver implementation.
    Following Single Responsibility Principle.
    """
    
    def __init__(self, default_paths: List[str] = None):
        self.default_paths = default_paths or []
    
    def resolve_copy_book(self, copy_name: str, search_paths: list) -> Optional[str]:
        """Resolve COPY book to file path."""
        all_paths = search_paths + self.default_paths
        
        # Common COPY book extensions
        extensions = ['', '.cpy', '.copy', '.cbl', '.cob']
        
        for path in all_paths:
            for ext in extensions:
                copy_file = os.path.join(path, f"{copy_name}{ext}")
                if os.path.exists(copy_file):
                    return copy_file
        
        return None
    
    def get_copy_book_content(self, copy_path: str) -> str:
        """Get COPY book content."""
        try:
            with open(copy_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except IOError as e:
            raise FileNotFoundError(f"Cannot read COPY book: {copy_path}") from e


class CobolParser(IParser):
    """
    Main COBOL parser implementation.
    Following Single Responsibility Principle - only parsing logic.
    """
    
    def __init__(self, copy_book_resolver: ICopyBookResolver = None):
        self.copy_book_resolver = copy_book_resolver or CopyBookResolver()
        self._setup_patterns()
    
    def _setup_patterns(self):
        """Setup regex patterns for parsing."""
        self.patterns = {
            'program_id': re.compile(r'PROGRAM-ID\.\s+([A-Z0-9\-]+)', re.IGNORECASE),
            'author': re.compile(r'AUTHOR\.\s+(.+)', re.IGNORECASE),
            'date_written': re.compile(r'DATE-WRITTEN\.\s+(.+)', re.IGNORECASE),
            'variable': re.compile(r'^\s*(\d{2})\s+([A-Z0-9\-]+)(?:\s+PIC\s+([X9V\(\)\.]+))?(?:\s+VALUE\s+(.+?))?\.?\s*$', re.IGNORECASE),
            'section': re.compile(r'^\s*([A-Z0-9\-]+)\s+SECTION\.', re.IGNORECASE),
            'paragraph': re.compile(r'^\s*([A-Z0-9\-]+)\.(?!\s*$)', re.IGNORECASE),
            'file_select': re.compile(r'SELECT\s+([A-Z0-9\-]+)\s+ASSIGN\s+TO\s+(.+)', re.IGNORECASE),
            'copy_statement': re.compile(r'COPY\s+([A-Z0-9\-]+)', re.IGNORECASE)
        }
    
    def parse_file(self, file_path: str) -> CobolProgram:
        """Parse a COBOL file."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"COBOL file not found: {file_path}")
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except IOError as e:
            raise ParseError(f"Cannot read file {file_path}: {e}") from e
        
        return self.parse_content(content, file_path)
    
    def parse_content(self, content: str, file_path: Optional[str] = None) -> CobolProgram:
        """Parse COBOL content from string."""
        lines = content.split('\n')
        
        # Create program object
        program = CobolProgram(
            program_id=self._extract_program_id(content),
            file_path=file_path or "unknown",
            lines_of_code=len([line for line in lines if line.strip() and not line.strip().startswith('*')])
        )
        
        # Extract basic information
        program.author = self._extract_author(content)
        program.date_written = self._extract_date_written(content)
        
        # Parse different sections
        self._parse_variables(lines, program)
        self._parse_sections_and_paragraphs(lines, program)
        self._parse_file_definitions(lines, program)
        self._parse_copy_books(lines, program)
        
        return program
    
    def validate_syntax(self, content: str) -> bool:
        """Validate COBOL syntax."""
        try:
            # Basic validation - check for required divisions
            required_divisions = ['IDENTIFICATION DIVISION', 'PROCEDURE DIVISION']
            content_upper = content.upper()
            
            for division in required_divisions:
                if division not in content_upper:
                    return False
            
            # Check for PROGRAM-ID
            if not self.patterns['program_id'].search(content):
                return False
            
            return True
        except Exception:
            return False
    
    def _extract_program_id(self, content: str) -> str:
        """Extract program ID."""
        match = self.patterns['program_id'].search(content)
        return match.group(1) if match else "UNKNOWN"
    
    def _extract_author(self, content: str) -> Optional[str]:
        """Extract author."""
        match = self.patterns['author'].search(content)
        return match.group(1).strip() if match else None
    
    def _extract_date_written(self, content: str) -> Optional[str]:
        """Extract date written."""
        match = self.patterns['date_written'].search(content)
        return match.group(1).strip() if match else None
    
    def _parse_variables(self, lines: List[str], program: CobolProgram):
        """Parse variable definitions."""
        in_working_storage = False
        parent_stack = []
        
        for line_num, line in enumerate(lines, 1):
            line_clean = line.strip()
            
            # Check for WORKING-STORAGE SECTION
            if 'WORKING-STORAGE SECTION' in line.upper():
                in_working_storage = True
                continue
            
            # Exit working storage on next section
            if in_working_storage and 'SECTION' in line.upper() and 'WORKING-STORAGE' not in line.upper():
                in_working_storage = False
                continue
            
            if not in_working_storage:
                continue
            
            # Parse variable definition
            match = self.patterns['variable'].match(line)
            if match:
                level = int(match.group(1))
                name = match.group(2)
                picture = match.group(3)
                value = match.group(4)
                
                # Handle parent-child relationships
                parent = None
                if level > 1:
                    # Find parent at appropriate level
                    while parent_stack and parent_stack[-1][1] >= level:
                        parent_stack.pop()
                    
                    if parent_stack:
                        parent = parent_stack[-1][0]
                
                # Create variable
                variable = CobolVariable(
                    name=name,
                    level=level,
                    picture=picture,
                    value=value,
                    parent=parent
                )
                
                program.add_variable(variable)
                
                # Update parent stack
                parent_stack.append((name, level))
                
                # Update parent's children
                if parent:
                    parent_var = program.get_variable_by_name(parent)
                    if parent_var:
                        parent_var.children.append(name)
    
    def _parse_sections_and_paragraphs(self, lines: List[str], program: CobolProgram):
        """Parse sections and paragraphs."""
        current_section = None
        current_paragraph = None
        
        for line_num, line in enumerate(lines, 1):
            line_clean = line.strip()
            
            # Check for section
            section_match = self.patterns['section'].match(line)
            if section_match:
                section_name = section_match.group(1)
                current_section = CobolSection(
                    name=section_name,
                    line_start=line_num,
                    line_end=line_num  # Will be updated
                )
                program.add_section(current_section)
                continue
            
            # Check for paragraph
            paragraph_match = self.patterns['paragraph'].match(line)
            if paragraph_match and not line_clean.endswith('SECTION.'):
                paragraph_name = paragraph_match.group(1)
                
                # Close previous paragraph
                if current_paragraph:
                    current_paragraph.line_end = line_num - 1
                
                current_paragraph = CobolParagraph(
                    name=paragraph_name,
                    line_start=line_num,
                    line_end=line_num  # Will be updated
                )
                
                program.add_paragraph(current_paragraph)
                
                if current_section:
                    current_section.add_paragraph(current_paragraph)
                
                continue
            
            # Add statements to current paragraph
            if current_paragraph and line_clean and not line_clean.startswith('*'):
                current_paragraph.add_statement(line_clean)
        
        # Close last paragraph
        if current_paragraph:
            current_paragraph.line_end = len(lines)
        
        # Update section end lines
        for section in program.sections:
            if section.paragraphs:
                section.line_end = section.paragraphs[-1].line_end
        
        # Calculate complexity for all paragraphs
        for paragraph in program.paragraphs:
            paragraph.calculate_complexity()
    
    def _parse_file_definitions(self, lines: List[str], program: CobolProgram):
        """Parse file definitions."""
        for line in lines:
            match = self.patterns['file_select'].search(line)
            if match:
                file_def = FileDefinition(
                    name=match.group(1),
                    organization="SEQUENTIAL",  # Default
                    access_mode="SEQUENTIAL"    # Default
                )
                program.files.append(file_def)
    
    def _parse_copy_books(self, lines: List[str], program: CobolProgram):
        """Parse COPY book statements."""
        for line in lines:
            match = self.patterns['copy_statement'].search(line)
            if match:
                copy_name = match.group(1)
                program.copy_books.append(copy_name)

