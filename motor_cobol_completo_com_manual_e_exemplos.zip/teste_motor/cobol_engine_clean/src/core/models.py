"""
Core data models for COBOL programs.
Following Single Responsibility Principle (SRP).
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from enum import Enum


class DataType(Enum):
    """COBOL data types."""
    NUMERIC = "numeric"
    ALPHABETIC = "alphabetic"
    ALPHANUMERIC = "alphanumeric"
    PACKED = "packed"
    BINARY = "binary"
    DISPLAY = "display"


class VariableUsage(Enum):
    """Variable usage patterns."""
    INPUT = "input"
    OUTPUT = "output"
    WORKING = "working"
    INTERMEDIATE = "intermediate"
    CONSTANT = "constant"


@dataclass
class CobolVariable:
    """Represents a COBOL variable with all its properties."""
    name: str
    level: int
    picture: Optional[str] = None
    value: Optional[str] = None
    usage: Optional[str] = None
    occurs: Optional[str] = None
    redefines: Optional[str] = None
    parent: Optional[str] = None
    children: List[str] = field(default_factory=list)
    data_type: Optional[DataType] = None
    usage_pattern: Optional[VariableUsage] = None
    
    def __post_init__(self):
        """Post-initialization processing."""
        if self.picture:
            self.data_type = self._infer_data_type()
    
    def _infer_data_type(self) -> DataType:
        """Infer data type from picture clause."""
        if not self.picture:
            return DataType.ALPHANUMERIC
            
        pic = self.picture.upper()
        if '9' in pic and 'X' not in pic and 'A' not in pic:
            return DataType.NUMERIC
        elif 'A' in pic and '9' not in pic and 'X' not in pic:
            return DataType.ALPHABETIC
        else:
            return DataType.ALPHANUMERIC
    
    def is_group_item(self) -> bool:
        """Check if this is a group item."""
        return len(self.children) > 0
    
    def is_elementary_item(self) -> bool:
        """Check if this is an elementary item."""
        return not self.is_group_item()


@dataclass
class CobolParagraph:
    """Represents a COBOL paragraph."""
    name: str
    line_start: int
    line_end: int
    statements: List[str] = field(default_factory=list)
    complexity: int = 0
    
    def add_statement(self, statement: str):
        """Add a statement to this paragraph."""
        self.statements.append(statement)
    
    def calculate_complexity(self) -> int:
        """Calculate cyclomatic complexity."""
        decision_keywords = ['IF', 'EVALUATE', 'PERFORM', 'UNTIL', 'WHILE']
        complexity = 1  # Base complexity
        
        for statement in self.statements:
            for keyword in decision_keywords:
                complexity += statement.upper().count(keyword)
        
        self.complexity = complexity
        return complexity


@dataclass
class CobolSection:
    """Represents a COBOL section."""
    name: str
    line_start: int
    line_end: int
    paragraphs: List[CobolParagraph] = field(default_factory=list)
    
    def add_paragraph(self, paragraph: CobolParagraph):
        """Add a paragraph to this section."""
        self.paragraphs.append(paragraph)
    
    def get_total_complexity(self) -> int:
        """Get total complexity of all paragraphs."""
        return sum(p.complexity for p in self.paragraphs)


@dataclass
class FileDefinition:
    """Represents a COBOL file definition."""
    name: str
    organization: str
    access_mode: str
    record_key: Optional[str] = None
    file_status: Optional[str] = None
    operations: List[str] = field(default_factory=list)


@dataclass
class CobolProgram:
    """
    Main model representing a complete COBOL program.
    Follows Single Responsibility Principle.
    """
    program_id: str
    file_path: str
    author: Optional[str] = None
    date_written: Optional[str] = None
    variables: List[CobolVariable] = field(default_factory=list)
    sections: List[CobolSection] = field(default_factory=list)
    paragraphs: List[CobolParagraph] = field(default_factory=list)
    files: List[FileDefinition] = field(default_factory=list)
    copy_books: List[str] = field(default_factory=list)
    lines_of_code: int = 0
    
    def add_variable(self, variable: CobolVariable):
        """Add a variable to the program."""
        self.variables.append(variable)
    
    def add_section(self, section: CobolSection):
        """Add a section to the program."""
        self.sections.append(section)
    
    def add_paragraph(self, paragraph: CobolParagraph):
        """Add a paragraph to the program."""
        self.paragraphs.append(paragraph)
    
    def get_variable_by_name(self, name: str) -> Optional[CobolVariable]:
        """Get variable by name."""
        for var in self.variables:
            if var.name == name:
                return var
        return None
    
    def get_total_complexity(self) -> int:
        """Get total cyclomatic complexity."""
        return sum(section.get_total_complexity() for section in self.sections)
    
    def get_variables_by_level(self, level: int) -> List[CobolVariable]:
        """Get all variables at a specific level."""
        return [var for var in self.variables if var.level == level]
    
    def get_group_variables(self) -> List[CobolVariable]:
        """Get all group variables."""
        return [var for var in self.variables if var.is_group_item()]
    
    def get_elementary_variables(self) -> List[CobolVariable]:
        """Get all elementary variables."""
        return [var for var in self.variables if var.is_elementary_item()]


@dataclass
class AnalysisResult:
    """
    Generic analysis result container.
    Follows Open/Closed Principle - extensible for different analysis types.
    """
    analyzer_name: str
    program_id: str
    success: bool
    data: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    execution_time: float = 0.0
    
    def add_error(self, error: str):
        """Add an error message."""
        self.errors.append(error)
        self.success = False
    
    def add_warning(self, warning: str):
        """Add a warning message."""
        self.warnings.append(warning)
    
    def has_errors(self) -> bool:
        """Check if analysis has errors."""
        return len(self.errors) > 0
    
    def has_warnings(self) -> bool:
        """Check if analysis has warnings."""
        return len(self.warnings) > 0


@dataclass
class BatchResult:
    """
    Result container for batch processing.
    """
    total_files: int
    processed_files: int
    failed_files: int
    total_lines: int
    processing_time: float
    results: Dict[str, AnalysisResult] = field(default_factory=dict)
    consolidated_metrics: Dict[str, Any] = field(default_factory=dict)
    
    def add_result(self, file_path: str, result: AnalysisResult):
        """Add a file analysis result."""
        self.results[file_path] = result
        if result.success:
            self.processed_files += 1
        else:
            self.failed_files += 1
    
    def get_success_rate(self) -> float:
        """Get processing success rate."""
        if self.total_files == 0:
            return 0.0
        return (self.processed_files / self.total_files) * 100
    
    def get_files_per_minute(self) -> float:
        """Get processing speed in files per minute."""
        if self.processing_time == 0:
            return 0.0
        return (self.processed_files / self.processing_time) * 60

