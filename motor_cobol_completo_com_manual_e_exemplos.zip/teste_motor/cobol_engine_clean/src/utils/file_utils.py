"""
File utilities following Single Responsibility Principle.
"""

import os
import zipfile
import tempfile
import shutil
from typing import List
from ..interfaces.processor import IFileExtractor
from .exceptions import FileNotFoundError, EngineError


class FileExtractor(IFileExtractor):
    """
    File extractor implementation.
    Following Single Responsibility Principle - only file extraction.
    """
    
    COBOL_EXTENSIONS = {'.cbl', '.cob', '.cobol', '.txt'}
    
    def extract_cobol_files(self, source_path: str) -> List[str]:
        """
        Extract COBOL files from source.
        
        Args:
            source_path: Path to ZIP file or directory
            
        Returns:
            List of COBOL file paths
        """
        if not os.path.exists(source_path):
            raise FileNotFoundError(f"Source path not found: {source_path}")
        
        if source_path.lower().endswith('.zip'):
            return self._extract_from_zip(source_path)
        elif os.path.isdir(source_path):
            return self._extract_from_directory(source_path)
        else:
            # Single file
            if self.is_cobol_file(source_path):
                return [source_path]
            else:
                return []
    
    def is_cobol_file(self, file_path: str) -> bool:
        """
        Check if file is a COBOL file.
        
        Args:
            file_path: Path to file
            
        Returns:
            True if file is COBOL
        """
        if not os.path.isfile(file_path):
            return False
        
        # Check extension
        _, ext = os.path.splitext(file_path.lower())
        return ext in self.COBOL_EXTENSIONS
    
    def _extract_from_zip(self, zip_path: str) -> List[str]:
        """Extract COBOL files from ZIP."""
        cobol_files = []
        
        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                    zip_ref.extractall(temp_dir)
                
                # Find COBOL files in extracted directory
                temp_files = self._extract_from_directory(temp_dir, recursive=True)
                
                # Copy files to permanent location
                for temp_file in temp_files:
                    # Create permanent copy
                    rel_path = os.path.relpath(temp_file, temp_dir)
                    perm_dir = os.path.join(tempfile.gettempdir(), 'cobol_engine_extracted')
                    os.makedirs(perm_dir, exist_ok=True)
                    
                    perm_file = os.path.join(perm_dir, rel_path.replace(os.sep, '_'))
                    shutil.copy2(temp_file, perm_file)
                    cobol_files.append(perm_file)
                
        except zipfile.BadZipFile:
            raise EngineError(f"Invalid ZIP file: {zip_path}")
        except Exception as e:
            raise EngineError(f"Error extracting ZIP: {e}")
        
        return cobol_files
    
    def _extract_from_directory(self, directory_path: str, recursive: bool = True) -> List[str]:
        """Extract COBOL files from directory."""
        cobol_files = []
        
        if recursive:
            for root, dirs, files in os.walk(directory_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    if self.is_cobol_file(file_path):
                        cobol_files.append(file_path)
        else:
            for file in os.listdir(directory_path):
                file_path = os.path.join(directory_path, file)
                if self.is_cobol_file(file_path):
                    cobol_files.append(file_path)
        
        return sorted(cobol_files)


class FileManager:
    """
    File management utilities.
    Following Single Responsibility Principle.
    """
    
    @staticmethod
    def ensure_directory(directory_path: str):
        """Ensure directory exists."""
        os.makedirs(directory_path, exist_ok=True)
    
    @staticmethod
    def get_safe_filename(filename: str) -> str:
        """Get safe filename by removing invalid characters."""
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            filename = filename.replace(char, '_')
        return filename
    
    @staticmethod
    def get_file_size(file_path: str) -> int:
        """Get file size in bytes."""
        return os.path.getsize(file_path)
    
    @staticmethod
    def cleanup_temp_files(pattern: str = "cobol_engine_*"):
        """Cleanup temporary files."""
        temp_dir = tempfile.gettempdir()
        for item in os.listdir(temp_dir):
            if item.startswith(pattern.replace('*', '')):
                item_path = os.path.join(temp_dir, item)
                try:
                    if os.path.isdir(item_path):
                        shutil.rmtree(item_path)
                    else:
                        os.remove(item_path)
                except Exception:
                    pass  # Ignore cleanup errors

