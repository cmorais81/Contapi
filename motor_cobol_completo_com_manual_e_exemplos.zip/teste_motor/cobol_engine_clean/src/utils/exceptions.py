"""
Custom exceptions for COBOL Documentation Engine.
"""


class EngineError(Exception):
    """Base exception for engine errors."""
    pass


class ParseError(EngineError):
    """Exception raised when parsing fails."""
    pass


class FileNotFoundError(EngineError):
    """Exception raised when file is not found."""
    pass


class AnalyzerError(EngineError):
    """Exception raised when analyzer fails."""
    pass


class FormatterError(EngineError):
    """Exception raised when formatting fails."""
    pass


class ConfigurationError(EngineError):
    """Exception raised when configuration is invalid."""
    pass

