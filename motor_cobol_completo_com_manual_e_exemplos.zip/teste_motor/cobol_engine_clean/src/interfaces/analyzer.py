"""
Analyzer interface following Interface Segregation Principle.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any
from ..core.models import CobolProgram, AnalysisResult


class IAnalyzer(ABC):
    """
    Interface for all analyzers.
    Following Interface Segregation Principle - small, focused interface.
    """
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Get analyzer name."""
        pass
    
    @property
    @abstractmethod
    def version(self) -> str:
        """Get analyzer version."""
        pass
    
    @abstractmethod
    def analyze(self, program: CobolProgram) -> AnalysisResult:
        """
        Analyze a COBOL program.
        
        Args:
            program: The COBOL program to analyze
            
        Returns:
            AnalysisResult with analysis data
        """
        pass
    
    @abstractmethod
    def get_configuration(self) -> Dict[str, Any]:
        """Get analyzer configuration."""
        pass
    
    @abstractmethod
    def set_configuration(self, config: Dict[str, Any]) -> None:
        """Set analyzer configuration."""
        pass


class ISecurityAnalyzer(IAnalyzer):
    """Interface for security-specific analysis."""
    
    @abstractmethod
    def get_security_score(self, program: CobolProgram) -> int:
        """Get security score (0-100)."""
        pass
    
    @abstractmethod
    def get_vulnerabilities(self, program: CobolProgram) -> list:
        """Get list of security vulnerabilities."""
        pass


class IPerformanceAnalyzer(IAnalyzer):
    """Interface for performance-specific analysis."""
    
    @abstractmethod
    def get_performance_score(self, program: CobolProgram) -> int:
        """Get performance score (0-100)."""
        pass
    
    @abstractmethod
    def get_bottlenecks(self, program: CobolProgram) -> list:
        """Get list of performance bottlenecks."""
        pass


class IMigrationAnalyzer(IAnalyzer):
    """Interface for migration-specific analysis."""
    
    @abstractmethod
    def get_migration_readiness(self, program: CobolProgram) -> int:
        """Get migration readiness score (0-100)."""
        pass
    
    @abstractmethod
    def get_migration_strategy(self, program: CobolProgram) -> str:
        """Get recommended migration strategy."""
        pass

