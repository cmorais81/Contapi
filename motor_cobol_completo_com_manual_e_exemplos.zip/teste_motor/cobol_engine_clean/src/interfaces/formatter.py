"""
Formatter interface following Interface Segregation Principle.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any
from ..core.models import AnalysisResult, BatchResult


class IFormatter(ABC):
    """
    Interface for output formatters.
    Following Single Responsibility Principle - only formatting responsibility.
    """
    
    @property
    @abstractmethod
    def format_name(self) -> str:
        """Get format name (e.g., 'json', 'yaml', 'markdown')."""
        pass
    
    @property
    @abstractmethod
    def file_extension(self) -> str:
        """Get file extension for this format."""
        pass
    
    @abstractmethod
    def format_single_result(self, result: AnalysisResult) -> str:
        """
        Format a single analysis result.
        
        Args:
            result: Analysis result to format
            
        Returns:
            Formatted string
        """
        pass
    
    @abstractmethod
    def format_batch_result(self, batch_result: BatchResult) -> str:
        """
        Format a batch processing result.
        
        Args:
            batch_result: Batch result to format
            
        Returns:
            Formatted string
        """
        pass


class IReportGenerator(ABC):
    """Interface for report generation."""
    
    @abstractmethod
    def generate_summary_report(self, results: Dict[str, AnalysisResult]) -> str:
        """Generate summary report from multiple results."""
        pass
    
    @abstractmethod
    def generate_detailed_report(self, result: AnalysisResult) -> str:
        """Generate detailed report from single result."""
        pass

