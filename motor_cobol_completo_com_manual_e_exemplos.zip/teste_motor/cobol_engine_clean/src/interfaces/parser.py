"""
Parser interface following Interface Segregation Principle.
"""

from abc import ABC, abstractmethod
from typing import Optional
from ..core.models import CobolProgram


class IParser(ABC):
    """
    Interface for COBOL parsers.
    Following Single Responsibility Principle - only parsing responsibility.
    """
    
    @abstractmethod
    def parse_file(self, file_path: str) -> CobolProgram:
        """
        Parse a COBOL file.
        
        Args:
            file_path: Path to the COBOL file
            
        Returns:
            CobolProgram object
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ParseError: If parsing fails
        """
        pass
    
    @abstractmethod
    def parse_content(self, content: str, program_id: Optional[str] = None) -> CobolProgram:
        """
        Parse COBOL content from string.
        
        Args:
            content: COBOL source code
            program_id: Optional program ID
            
        Returns:
            CobolProgram object
        """
        pass
    
    @abstractmethod
    def validate_syntax(self, content: str) -> bool:
        """
        Validate COBOL syntax.
        
        Args:
            content: COBOL source code
            
        Returns:
            True if syntax is valid
        """
        pass


class ICopyBookResolver(ABC):
    """Interface for COPY book resolution."""
    
    @abstractmethod
    def resolve_copy_book(self, copy_name: str, search_paths: list) -> Optional[str]:
        """
        Resolve COPY book to file path.
        
        Args:
            copy_name: Name of the COPY book
            search_paths: List of directories to search
            
        Returns:
            Path to COPY book file or None if not found
        """
        pass
    
    @abstractmethod
    def get_copy_book_content(self, copy_path: str) -> str:
        """
        Get COPY book content.
        
        Args:
            copy_path: Path to COPY book file
            
        Returns:
            COPY book content
        """
        pass

