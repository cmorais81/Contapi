# Motor de Documentação COBOL

Ferramenta moderna e extensível para análise e documentação de programas COBOL seguindo princípios SOLID e arquitetura limpa.

## Características

### Análise Abrangente
- **Parser COBOL**: Análise avançada com suporte a COPY books, estruturas hierárquicas e definições de arquivo
- **Análise de Segurança**: Detecção de vulnerabilidades, verificação de compliance e pontuação de segurança
- **Análise de Performance**: Métricas de complexidade, identificação de gargalos e recomendações de otimização
- **Processamento em Lote**: Análise de portfolios completos via arquivos ZIP ou diretórios

### Arquitetura Limpa
- **Princípios SOLID**: Responsabilidade Única, Aberto/Fechado, Substituição de Liskov, Segregação de Interface, Inversão de Dependência
- **Design Extensível**: Sistema de analisadores baseado em plugins
- **Múltiplos Formatos**: Saída em JSON, YAML e Markdown
- **Segurança de Tipos**: Type hints completos e tratamento robusto de erros

### Alta Performance
- **Processamento Paralelo**: Análise em lote multi-threaded
- **Eficiência de Memória**: Otimizado para grandes bases de código
- **Parsing Rápido**: Análise COBOL eficiente baseada em regex

## Início Rápido

### Instalação

```bash
# Instalar do código fonte
git clone https://github.com/motor-cobol/motor-documentacao-cobol.git
cd motor-documentacao-cobol
pip install -e .

# Ou instalar com dependências de desenvolvimento
pip install -e ".[dev]"
```

### Uso Básico

```bash
# Analisar um arquivo COBOL único
python cobol_engine.py analyze programa.cbl --output ./resultados

# Análise em lote de arquivo ZIP
python cobol_engine.py batch portfolio.zip --output ./analise

# Análise em lote com analisadores específicos
python cobol_engine.py batch portfolio.zip --output ./analise --analyzers security_analyzer performance_analyzer

# Mostrar analisadores e formatadores disponíveis
python cobol_engine.py info
```

### API Python

```python
from src.core.engine import DocumentationEngine

# Inicializar motor
engine = DocumentationEngine()

# Analisar arquivo único
result = engine.analyze_single_file(
    "programa.cbl", 
    analyzers=["security_analyzer", "performance_analyzer"]
)

# Análise em lote
batch_result = engine.analyze_batch(
    "portfolio.zip",
    analyzers=["security_analyzer"],
    parallel=True,
    max_workers=4
)

# Salvar resultados
engine.save_result(result, "analise.json", "json")
engine.save_batch_result(batch_result, "./saida", "json")
```

## Arquitetura

### Componentes Principais

```
src/
├── core/                   # Lógica de negócio central
│   ├── models.py          # Modelos de dados
│   ├── parser.py          # Parser COBOL
│   └── engine.py          # Motor principal
├── interfaces/            # Contratos (ISP)
│   ├── analyzer.py        # Interfaces de analisadores
│   ├── parser.py          # Interfaces de parser
│   ├── formatter.py       # Interfaces de formatadores
│   └── processor.py       # Interfaces de processadores
├── analyzers/             # Implementações de análise
│   ├── registry.py        # Registro de analisadores
│   ├── security.py        # Analisador de segurança
│   └── performance.py     # Analisador de performance
├── utils/                 # Utilitários
│   ├── exceptions.py      # Exceções customizadas
│   ├── file_utils.py      # Operações de arquivo
│   └── formatters.py      # Formatadores de saída
└── cli.py                 # Interface de linha de comando
```

### Princípios de Design

#### Princípio da Responsabilidade Única (SRP)
- Cada classe tem uma razão para mudar
- `CobolParser` apenas trata parsing
- `SecurityAnalyzer` apenas trata análise de segurança
- `FileExtractor` apenas trata extração de arquivos

#### Princípio Aberto/Fechado (OCP)
- Extensível através de interfaces
- Adicionar novos analisadores implementando `IAnalyzer`
- Adicionar novos formatadores implementando `IFormatter`

#### Princípio da Substituição de Liskov (LSP)
- Todas as implementações de analisadores são intercambiáveis
- Todas as implementações de formatadores são intercambiáveis

#### Princípio da Segregação de Interface (ISP)
- Interfaces pequenas e focadas
- `ISecurityAnalyzer` estende `IAnalyzer` com métodos específicos de segurança
- `IPerformanceAnalyzer` estende `IAnalyzer` com métodos específicos de performance

#### Princípio da Inversão de Dependência (DIP)
- Módulos de alto nível dependem de abstrações
- `DocumentationEngine` depende das interfaces `IParser`, `IAnalyzer`
- Implementações concretas injetadas via construtor

## Analisadores

### Analisador de Segurança

Analisa programas COBOL para vulnerabilidades de segurança:

- **Validação de Entrada**: Detecta statements ACCEPT sem validação
- **Segurança de Arquivos**: Verifica tratamento de FILE STATUS ausente
- **Exposição de Dados**: Identifica dados sensíveis potenciais em statements DISPLAY
- **Tratamento de Erros**: Valida tratamento de erros para operações de arquivo

**Saída**: Pontuação de segurança (0-100), lista de vulnerabilidades, status de compliance

### Analisador de Performance

Analisa programas COBOL para problemas de performance:

- **Análise de Complexidade**: Calcula complexidade ciclomática
- **Análise de Loops**: Detecta loops aninhados e padrões ineficientes
- **Operações de Arquivo**: Identifica padrões de acesso a arquivo ineficientes
- **Movimentação de Dados**: Analisa eficiência do fluxo de dados

**Saída**: Pontuação de performance (0-100), lista de gargalos, recomendações de otimização

## Formatos de Saída

### Formato JSON
```json
{
  "analyzer_name": "engine",
  "program_id": "PAYROLL-CALC",
  "success": true,
  "execution_time": 0.15,
  "data": {
    "program_info": {
      "lines_of_code": 150,
      "variables_count": 25,
      "total_complexity": 12
    },
    "analyzer_results": {
      "security_analyzer": {
        "security_score": 85,
        "issues": [],
        "compliance_status": "COMPLIANT"
      }
    }
  }
}
```

### Formato Markdown
```markdown
# Relatório de Análise - PAYROLL-CALC

## Informações Básicas
- **ID do Programa**: PAYROLL-CALC
- **Sucesso**: Sim
- **Linhas de Código**: 150
- **Pontuação de Segurança**: 85/100

## Resultados da Análise
### Análise de Segurança
- **Pontuação de Segurança**: 85/100
- **Problemas Encontrados**: 3
- **Status de Compliance**: COMPLIANT
```

## Processamento em Lote

Processar múltiplos arquivos COBOL eficientemente:

```bash
# Processar arquivo ZIP
python cobol_engine.py batch portfolio.zip --output ./resultados --parallel --max-workers 8

# Processar diretório
python cobol_engine.py batch /caminho/para/arquivos/cobol --output ./resultados

# Analisadores customizados
python cobol_engine.py batch portfolio.zip --output ./resultados --analyzers security_analyzer
```

### Saída em Lote

- **Análise Individual**: Arquivo JSON/YAML/Markdown por programa
- **Relatório Consolidado**: Resumo em Markdown com estatísticas
- **Métricas**: Taxa de sucesso, velocidade de processamento, pontuações de qualidade

## Estendendo o Motor

### Adicionando Novo Analisador

```python
from src.interfaces.analyzer import IAnalyzer
from src.core.models import CobolProgram, AnalysisResult

class AnalisadorCustomizado(IAnalyzer):
    @property
    def name(self) -> str:
        return "analisador_customizado"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    def analyze(self, program: CobolProgram) -> AnalysisResult:
        # Sua lógica de análise aqui
        result = AnalysisResult(
            analyzer_name=self.name,
            program_id=program.program_id,
            success=True
        )
        # Adicionar dados de análise
        result.data['metrica_customizada'] = 42
        return result
    
    def get_configuration(self) -> Dict[str, Any]:
        return {}
    
    def set_configuration(self, config: Dict[str, Any]) -> None:
        pass

# Registrar o analisador
engine = DocumentationEngine()
engine.analyzer_registry.register_analyzer(AnalisadorCustomizado())
```

## Configuração

### Variáveis de Ambiente

```bash
# Opcional: integração com IA
export OPENAI_API_KEY="sua-chave-api"
export OPENAI_API_BASE="https://api.openai.com/v1"

# Opcional: caminhos customizados de COPY book
export COBOL_COPY_PATHS="/caminho/para/copybooks:/outro/caminho"
```

### Arquivo de Configuração

Criar `config.yaml`:

```yaml
analyzers:
  security_analyzer:
    check_input_validation: true
    check_file_operations: true
    severity_weights:
      CRITICAL: 10
      HIGH: 7
      MEDIUM: 4
      LOW: 1

  performance_analyzer:
    check_complexity: true
    complexity_thresholds:
      low: 10
      medium: 20
      high: 30

output:
  default_format: "json"
  include_source_code: false

processing:
  max_workers: 4
  timeout_seconds: 300
```

## Testes

```bash
# Executar todos os testes
pytest

# Executar com cobertura
pytest --cov=src --cov-report=html

# Executar teste específico
pytest tests/test_parser.py

# Executar com saída verbosa
pytest -v
```

## Performance

### Benchmarks

| Tamanho do Portfolio | Arquivos | Linhas de Código | Tempo de Processamento | Velocidade |
|----------------------|----------|------------------|------------------------|------------|
| Pequeno              | 10       | 5,000            | 2.3s                   | 260 arq/min |
| Médio                | 50       | 25,000           | 8.7s                   | 345 arq/min |
| Grande               | 200      | 100,000          | 28.4s                  | 422 arq/min |
| Empresarial          | 1000     | 500,000          | 142.1s                 | 422 arq/min |

### Uso de Memória

- **Parser**: ~10MB por 1000 linhas de COBOL
- **Analisadores**: ~5MB por programa
- **Processamento em Lote**: ~50MB base + (arquivos × 15MB)

## Contribuindo

1. Fazer fork do repositório
2. Criar branch de feature (`git checkout -b feature/funcionalidade-incrivel`)
3. Seguir princípios SOLID e adicionar testes
4. Garantir qualidade do código (`black`, `flake8`, `mypy`)
5. Commit das mudanças (`git commit -m 'Adicionar funcionalidade incrível'`)
6. Push para branch (`git push origin feature/funcionalidade-incrivel`)
7. Abrir Pull Request

### Qualidade do Código

```bash
# Formatar código
black src/ tests/

# Lint do código
flake8 src/ tests/

# Verificação de tipos
mypy src/

# Executar todas as verificações de qualidade
make quality
```

## Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo [LICENSE](LICENSE) para detalhes.

## Suporte

- **Documentação**: [docs/](docs/)
- **Issues**: [GitHub Issues](https://github.com/motor-cobol/motor-documentacao-cobol/issues)
- **Discussões**: [GitHub Discussions](https://github.com/motor-cobol/motor-documentacao-cobol/discussions)

## Roadmap

### Versão 2.1
- Analisador de migração
- Geração de documentação com IA
- Interface web
- Integração com banco de dados

### Versão 2.2
- Gráficos de dependência visual
- Métricas de qualidade de código
- Integração com pipelines CI/CD
- Opções de deploy em nuvem

### Versão 3.0
- Suporte multi-linguagem (PL/I, RPG)
- Análise em tempo real
- Visualização avançada
- Recursos empresariais

