#!/usr/bin/env python3
"""
Ponto de entrada principal para o Motor de Documentação COBOL.
"""

import sys
import os

# Adicionar src ao caminho do Python
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.cli import CobolCLI

def main():
    """Ponto de entrada principal."""
    cli = CobolCLI()
    cli.run()

if __name__ == "__main__":
    main()

