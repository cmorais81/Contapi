# Guia de Integração AWS Bedrock

## Visão Geral

O Motor de Documentação COBOL agora suporta AWS Bedrock, permitindo usar modelos de IA da Amazon para análise avançada de código COBOL. Esta integração oferece uma alternativa ao OpenAI com modelos como Claude 3, Llama 2 e Titan.

## Vantagens do AWS Bedrock

### 1. Modelos Avançados
- **Claude 3 Sonnet**: Excelente para análise de código e raciocínio complexo
- **Claude 3 Haiku**: Rápido e econômico para análises simples
- **Llama 2**: Modelo open source da Meta
- **Amazon Titan**: Modelos próprios da Amazon com boa relação custo-benefício

### 2. Segurança Empresarial
- Dados não são usados para treinamento
- Controle total sobre dados e modelos
- Compliance com regulamentações empresariais
- Integração com IAM e VPC

### 3. Escalabilidade
- Sem limites de rate limiting restritivos
- Escalabilidade automática
- Disponibilidade em múltiplas regiões
- SLA empresarial

## Configuração

### Pré-requisitos

1. **Conta AWS** com acesso ao Bedrock
2. **Credenciais AWS** configuradas
3. **Permissões IAM** adequadas
4. **Região suportada** (us-east-1, us-west-2, etc.)

### Instalação de Dependências

```bash
# Instalar dependências AWS
pip install boto3 botocore

# Ou descomente no requirements.txt
# boto3>=1.34.0
# botocore>=1.34.0
```

### Configuração de Credenciais

#### Opção 1: AWS CLI (Recomendado)
```bash
# Configurar credenciais padrão
aws configure

# Ou criar perfil específico
aws configure --profile cobol-engine
```

#### Opção 2: Variáveis de Ambiente
```bash
export AWS_ACCESS_KEY_ID=sua_access_key
export AWS_SECRET_ACCESS_KEY=sua_secret_key
export AWS_DEFAULT_REGION=us-east-1
```

#### Opção 3: IAM Role (Para EC2/ECS)
```bash
# Não precisa configurar nada
# A instância EC2 usa a role automaticamente
```

### Configuração do Motor

1. **Copiar arquivo de configuração:**
```bash
cp .env.bedrock.example .env
```

2. **Editar configurações:**
```bash
# Habilitar Bedrock
ENABLE_BEDROCK=true

# Configurar região
AWS_BEDROCK_REGION=us-east-1

# Escolher modelo
AWS_BEDROCK_MODEL=anthropic.claude-3-sonnet-20240229-v1:0
```

## Modelos Disponíveis

### Anthropic Claude (Recomendado)

#### Claude 3 Sonnet
- **ID**: `anthropic.claude-3-sonnet-20240229-v1:0`
- **Características**: Equilibrado entre qualidade e velocidade
- **Melhor para**: Análise detalhada de código, documentação técnica
- **Custo**: Médio
- **Contexto**: 200K tokens

#### Claude 3 Haiku
- **ID**: `anthropic.claude-3-haiku-20240307-v1:0`
- **Características**: Rápido e econômico
- **Melhor para**: Análises rápidas, resumos
- **Custo**: Baixo
- **Contexto**: 200K tokens

#### Claude 2.1
- **ID**: `anthropic.claude-v2:1`
- **Características**: Versão anterior, ainda muito capaz
- **Melhor para**: Análise geral
- **Custo**: Médio
- **Contexto**: 200K tokens

### Meta Llama

#### Llama 2 70B Chat
- **ID**: `meta.llama2-70b-chat-v1`
- **Características**: Modelo open source, muito capaz
- **Melhor para**: Análise técnica, código
- **Custo**: Médio
- **Contexto**: 4K tokens

#### Llama 2 13B Chat
- **ID**: `meta.llama2-13b-chat-v1`
- **Características**: Menor e mais rápido
- **Melhor para**: Análises simples
- **Custo**: Baixo
- **Contexto**: 4K tokens

### Amazon Titan

#### Titan Text Express
- **ID**: `amazon.titan-text-express-v1`
- **Características**: Contexto longo, econômico
- **Melhor para**: Análise de programas grandes
- **Custo**: Baixo
- **Contexto**: 8K tokens

#### Titan Text Lite
- **ID**: `amazon.titan-text-lite-v1`
- **Características**: Muito econômico
- **Melhor para**: Análises básicas
- **Custo**: Muito baixo
- **Contexto**: 4K tokens

## Uso Prático

### Análise Básica com Bedrock
```bash
# Configurar Bedrock
export ENABLE_BEDROCK=true
export AWS_BEDROCK_MODEL=anthropic.claude-3-sonnet-20240229-v1:0

# Analisar arquivo único
python cobol_engine.py analyze programa.cbl --analyzers bedrock_analyzer
```

### Análise Completa
```bash
# Usar Bedrock junto com outros analisadores
python cobol_engine.py analyze programa.cbl \
  --analyzers security_analyzer performance_analyzer bedrock_analyzer \
  --format markdown
```

### Análise em Lote
```bash
# Processar múltiplos arquivos
python cobol_engine.py batch portfolio.zip \
  --analyzers bedrock_analyzer \
  --output ./analise_bedrock
```

### Arquivo TXT com Múltiplos Programas
```bash
# Processar arquivo TXT
python cobol_engine.py txt fontes.txt \
  --analyzers bedrock_analyzer \
  --format markdown
```

## Configurações Avançadas

### Otimização de Custos

```bash
# Usar modelo mais econômico
AWS_BEDROCK_MODEL=anthropic.claude-3-haiku-20240307-v1:0

# Habilitar cache (padrão: true)
BEDROCK_ENABLE_CACHE=true

# Limitar requisições por hora
BEDROCK_RATE_LIMIT=50
```

### Configuração de Performance

```bash
# Ajustar timeout
BEDROCK_TIMEOUT=120

# Configurar temperatura (criatividade)
BEDROCK_TEMPERATURE=0.1

# Limitar tokens de resposta
BEDROCK_MAX_TOKENS=3000
```

### Configuração por Região

```bash
# Região principal (mais modelos)
AWS_BEDROCK_REGION=us-east-1

# Região alternativa
AWS_BEDROCK_REGION=us-west-2

# Região europeia
AWS_BEDROCK_REGION=eu-west-1
```

## Permissões IAM

### Política Mínima Necessária
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:ListFoundationModels"
            ],
            "Resource": "*"
        }
    ]
}
```

### Política Completa (Recomendada)
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "bedrock:InvokeModel",
                "bedrock:ListFoundationModels",
                "bedrock:GetFoundationModel",
                "bedrock:ListModelCustomizationJobs"
            ],
            "Resource": "*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents"
            ],
            "Resource": "arn:aws:logs:*:*:*"
        }
    ]
}
```

## Resultados da Análise

### Estrutura da Resposta Bedrock
```json
{
    "proposito": "Descrição do propósito do programa",
    "funcionalidade": "Explicação detalhada da funcionalidade",
    "analise_tecnica": {
        "estruturas_dados": ["Lista de estruturas"],
        "operacoes_arquivo": ["Lista de operações"],
        "logica_principal": "Descrição da lógica",
        "complexidade": "baixa/média/alta"
    },
    "qualidade_codigo": {
        "pontuacao": 85,
        "boas_praticas": ["Lista de boas práticas"],
        "problemas": ["Lista de problemas"],
        "sugestoes": ["Lista de sugestões"]
    },
    "seguranca": {
        "pontuacao": 90,
        "vulnerabilidades": ["Lista de vulnerabilidades"],
        "validacoes": ["Validações presentes"],
        "recomendacoes": ["Recomendações de segurança"]
    },
    "modernizacao": {
        "dificuldade": 7,
        "tecnologias_recomendadas": ["Java", "Spring Boot"],
        "estrategia": "Descrição da estratégia",
        "riscos": ["Lista de riscos"],
        "beneficios": ["Lista de benefícios"]
    },
    "documentacao_negocio": {
        "regras_negocio": ["Lista de regras"],
        "fluxos_processo": ["Lista de fluxos"],
        "dependencias": ["Lista de dependências"],
        "impacto_sistema": "Descrição do impacto"
    }
}
```

### Exemplo de Análise Gerada
```markdown
## Análise Bedrock - Claude 3 Sonnet

### Propósito do Programa
Sistema de cadastro de clientes com operações CRUD completas, 
incluindo validação de dados e controle de integridade.

### Funcionalidade Principal
O programa implementa um sistema de gestão de clientes com:
- Inclusão de novos clientes
- Consulta por ID
- Alteração de dados existentes
- Exclusão com confirmação

### Análise Técnica
- **Complexidade**: Média
- **Estruturas de Dados**: Arquivo indexado com chave primária
- **Operações de Arquivo**: READ, WRITE, REWRITE, DELETE
- **Validação**: Controle de FILE STATUS

### Qualidade do Código: 85/100
- ✅ Estrutura bem organizada
- ✅ Tratamento de erros adequado
- ⚠️ Falta validação de CPF
- ⚠️ Ausência de log de auditoria

### Modernização (Dificuldade: 6/10)
- **Tecnologias Recomendadas**: Java Spring Boot, PostgreSQL
- **Estratégia**: Migração incremental por módulos
- **Benefícios**: Interface web, APIs REST, escalabilidade
```

## Troubleshooting

### Problemas Comuns

#### 1. Credenciais não encontradas
```bash
# Erro: NoCredentialsError
# Solução: Configurar AWS CLI
aws configure
```

#### 2. Região não suportada
```bash
# Erro: Model not available in region
# Solução: Usar região suportada
export AWS_BEDROCK_REGION=us-east-1
```

#### 3. Modelo não encontrado
```bash
# Erro: ValidationException
# Solução: Verificar ID do modelo
export AWS_BEDROCK_MODEL=anthropic.claude-3-sonnet-20240229-v1:0
```

#### 4. Permissões insuficientes
```bash
# Erro: AccessDeniedException
# Solução: Adicionar permissões IAM
# bedrock:InvokeModel, bedrock:ListFoundationModels
```

### Logs e Debug

```bash
# Habilitar logs detalhados
export AWS_LOG_LEVEL=DEBUG

# Verificar conectividade
aws bedrock list-foundation-models --region us-east-1

# Testar modelo específico
aws bedrock-runtime invoke-model \
  --model-id anthropic.claude-3-sonnet-20240229-v1:0 \
  --body '{"anthropic_version":"bedrock-2023-05-31","max_tokens":100,"messages":[{"role":"user","content":"Hello"}]}' \
  --cli-binary-format raw-in-base64-out \
  response.json
```

## Comparação com OpenAI

| Aspecto | AWS Bedrock | OpenAI |
|---------|-------------|---------|
| **Modelos** | Claude, Llama, Titan | GPT-3.5, GPT-4 |
| **Privacidade** | Dados não usados para treino | Dados podem ser usados |
| **Compliance** | SOC, HIPAA, FedRAMP | SOC 2 |
| **Escalabilidade** | Sem limites rígidos | Rate limits restritivos |
| **Custo** | Variável por modelo | Fixo por token |
| **Latência** | Baixa (AWS) | Variável |
| **Disponibilidade** | SLA 99.9% | SLA 99.9% |

## Recomendações de Uso

### Para Análise Rápida
- **Modelo**: Claude 3 Haiku
- **Configuração**: Baixa temperatura, poucos tokens
- **Caso de uso**: Validação rápida, resumos

### Para Análise Detalhada
- **Modelo**: Claude 3 Sonnet
- **Configuração**: Temperatura média, mais tokens
- **Caso de uso**: Documentação completa, modernização

### Para Análise Econômica
- **Modelo**: Amazon Titan Express
- **Configuração**: Cache habilitado, rate limiting
- **Caso de uso**: Processamento em lote, análise básica

### Para Análise Técnica
- **Modelo**: Llama 2 70B
- **Configuração**: Baixa temperatura, contexto técnico
- **Caso de uso**: Análise de código, arquitetura

## Próximos Passos

1. **Configurar credenciais AWS**
2. **Escolher modelo apropriado**
3. **Testar com programa simples**
4. **Configurar para produção**
5. **Monitorar custos e performance**

## Suporte

Para problemas específicos do Bedrock:
- Documentação AWS: https://docs.aws.amazon.com/bedrock/
- Console AWS: https://console.aws.amazon.com/bedrock/
- Suporte AWS: Através do console AWS

Para problemas do Motor COBOL:
- Verificar logs do aplicativo
- Validar configuração no arquivo .env
- Testar conectividade com AWS CLI

