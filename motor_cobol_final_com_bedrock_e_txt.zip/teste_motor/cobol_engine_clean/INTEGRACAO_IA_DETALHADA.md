# Integração com Inteligência Artificial - Guia Detalhado

## Visão Geral

O Motor de Documentação COBOL oferece integração avançada com serviços de IA para gerar documentação contextual, análises de negócio e estratégias de modernização. Este guia detalha como configurar e usar essas funcionalidades.

## Provedores de IA Suportados

### 1. OpenAI (GPT-4, GPT-3.5-turbo)
- **Modelo Recomendado**: GPT-4 para melhor qualidade
- **Custo**: Aproximadamente $0.03 por 1K tokens
- **Limite de Tokens**: 8K (GPT-4), 4K (GPT-3.5)

### 2. Azure OpenAI
- **Vantagens**: Compliance empresarial, dados não usados para treinamento
- **Modelos**: GPT-4, GPT-3.5-turbo
- **Integração**: Via Azure Cognitive Services

### 3. Anthropic Claude (Futuro)
- **Status**: Planejado para versão 2.1
- **Vantagens**: Contexto maior (100K tokens)

## Configuração Passo a Passo

### OpenAI Standard

#### 1. Criar Conta e Obter API Key
```bash
# 1. Acesse https://platform.openai.com
# 2. Crie conta ou faça login
# 3. Navegue para "API Keys"
# 4. Clique "Create new secret key"
# 5. Copie a chave (sk-...)
```

#### 2. Configurar Variáveis de Ambiente
```bash
# Linux/macOS
export OPENAI_API_KEY="sk-sua_chave_aqui"
export OPENAI_API_BASE="https://api.openai.com/v1"
export OPENAI_MODEL="gpt-4"

# Windows
set OPENAI_API_KEY=sk-sua_chave_aqui
set OPENAI_API_BASE=https://api.openai.com/v1
set OPENAI_MODEL=gpt-4
```

#### 3. Criar Arquivo .env (Recomendado)
```bash
# .env
OPENAI_API_KEY=sk-sua_chave_aqui
OPENAI_API_BASE=https://api.openai.com/v1
OPENAI_MODEL=gpt-4
OPENAI_MAX_TOKENS=4000
OPENAI_TEMPERATURE=0.1
OPENAI_TIMEOUT=30
```

### Azure OpenAI

#### 1. Configurar Recurso Azure
```bash
# Criar recurso no Azure Portal
# 1. Portal Azure > Create Resource > Azure OpenAI
# 2. Configurar região e pricing tier
# 3. Deploy modelo (GPT-4 ou GPT-3.5-turbo)
# 4. Obter endpoint e chave
```

#### 2. Configurar Variáveis Azure
```bash
export OPENAI_API_TYPE="azure"
export OPENAI_API_BASE="https://seu-recurso.openai.azure.com/"
export OPENAI_API_VERSION="2023-05-15"
export OPENAI_API_KEY="sua_chave_azure"
export OPENAI_DEPLOYMENT_NAME="gpt-4"
```

#### 3. Arquivo de Configuração Azure
```yaml
# config_azure.yaml
ai_integration:
  provider: "azure_openai"
  api_base: "https://seu-recurso.openai.azure.com/"
  api_version: "2023-05-15"
  deployment_name: "gpt-4"
  api_key: "sua_chave_azure"
  max_tokens: 4000
  temperature: 0.1
```

## Funcionalidades de IA

### 1. Análise de Negócio

#### Prompt Especializado
```
Analise este programa COBOL do ponto de vista de negócio:

1. Identifique as principais regras de negócio
2. Descreva os processos implementados
3. Identifique entradas e saídas críticas
4. Sugira melhorias de processo

Código COBOL:
{codigo_cobol}

Forneça análise estruturada em português brasileiro.
```

#### Exemplo de Uso
```bash
python cobol_engine.py analyze sistema_financeiro.cbl \
  --ai-analysis business \
  --output ./analise_negocio
```

#### Resultado Esperado
```markdown
## Análise de Negócio - SISTEMA-FINANCEIRO

### Regras de Negócio Identificadas
1. **Cálculo de Juros Compostos**: Taxa de 1.25% ao mês
2. **Validação de Saldo**: Não permite saldo negativo
3. **Status de Conta**: Apenas contas ativas podem ser movimentadas

### Processos Implementados
- **Processamento de Transações**: Débitos, créditos e transferências
- **Validação de Dados**: CPF, email e telefone obrigatórios
- **Geração de Relatórios**: Extratos e balancetes mensais

### Entradas Críticas
- Arquivo de transações (TRANSACOES.DAT)
- Arquivo de contas (CONTAS.DAT)
- Parâmetros de configuração

### Saídas Críticas
- Relatório de processamento
- Log de erros
- Arquivo de contas atualizado

### Melhorias Sugeridas
1. Implementar auditoria de transações
2. Adicionar notificações automáticas
3. Criar dashboard de monitoramento
```

### 2. Análise de Segurança

#### Prompt Especializado
```
Analise este código COBOL para vulnerabilidades de segurança:

1. Identifique problemas de validação de entrada
2. Verifique tratamento de erros
3. Analise exposição de dados sensíveis
4. Sugira correções específicas

Código COBOL:
{codigo_cobol}

Foque em riscos de segurança reais e práticos.
```

#### Exemplo de Uso
```bash
python cobol_engine.py analyze gestao_clientes.cbl \
  --ai-analysis security \
  --output ./auditoria_seguranca_ia
```

### 3. Estratégia de Modernização

#### Prompt Especializado
```
Analise este programa COBOL para modernização:

1. Avalie complexidade de migração
2. Sugira arquitetura moderna equivalente
3. Identifique dependências críticas
4. Estime esforço e riscos
5. Proponha plano de migração faseado

Código COBOL:
{codigo_cobol}

Considere tecnologias modernas como Java, Python, microserviços.
```

#### Exemplo de Uso
```bash
python cobol_engine.py analyze processamento_lote.cbl \
  --ai-analysis modernization \
  --output ./plano_modernizacao_ia
```

#### Resultado Esperado
```markdown
## Estratégia de Modernização - PROCESSAMENTO-LOTE

### Avaliação de Complexidade
- **Complexidade**: Alta
- **Linhas de Código**: 311
- **Dependências**: 4 arquivos externos
- **Lógica de Negócio**: Complexa (processamento financeiro)

### Arquitetura Moderna Sugerida

#### Microserviços Propostos
1. **Transaction Service**: Processamento de transações
2. **Account Service**: Gestão de contas
3. **Audit Service**: Log e auditoria
4. **Notification Service**: Alertas e notificações

#### Stack Tecnológico
- **Backend**: Spring Boot (Java) ou FastAPI (Python)
- **Banco de Dados**: PostgreSQL com Redis para cache
- **Mensageria**: Apache Kafka para processamento assíncrono
- **Monitoramento**: Prometheus + Grafana

### Plano de Migração Faseado

#### Fase 1: Preparação (2-3 meses)
- Análise detalhada de dependências
- Setup de ambiente de desenvolvimento
- Criação de testes de regressão

#### Fase 2: Wrapper Services (3-4 meses)
- Criar APIs REST que chamam COBOL existente
- Implementar camada de abstração
- Migrar dados para PostgreSQL

#### Fase 3: Reescrita Gradual (4-6 meses)
- Reimplementar lógica de negócio em Java/Python
- Manter compatibilidade com sistemas existentes
- Testes paralelos de validação

#### Fase 4: Cutover (1-2 meses)
- Migração final dos dados
- Descomissionamento do COBOL
- Monitoramento intensivo

### Estimativas
- **Tempo Total**: 10-15 meses
- **Equipe**: 5-7 desenvolvedores
- **Custo Estimado**: $800K - $1.2M
- **ROI Esperado**: 18-24 meses
```

## Configuração Avançada

### Arquivo de Configuração Completo

```yaml
# config_ai.yaml
ai_integration:
  # Provedor de IA
  provider: "openai"  # ou "azure_openai"
  
  # Configurações OpenAI
  openai:
    api_key: "${OPENAI_API_KEY}"
    api_base: "https://api.openai.com/v1"
    model: "gpt-4"
    max_tokens: 4000
    temperature: 0.1
    timeout: 30
    
  # Configurações Azure OpenAI
  azure_openai:
    api_key: "${AZURE_OPENAI_KEY}"
    api_base: "${AZURE_OPENAI_ENDPOINT}"
    api_version: "2023-05-15"
    deployment_name: "gpt-4"
    
  # Rate limiting
  rate_limiting:
    requests_per_minute: 60
    requests_per_hour: 1000
    retry_attempts: 3
    retry_delay: 1
    
  # Cache de respostas
  cache:
    enabled: true
    ttl_hours: 24
    max_size_mb: 100
    
  # Prompts customizados
  prompts:
    business_analysis: |
      Você é um analista de negócios especializado em sistemas COBOL.
      Analise o código fornecido e identifique:
      1. Regras de negócio principais
      2. Processos implementados
      3. Entradas e saídas críticas
      4. Oportunidades de melhoria
      
      Código COBOL:
      {codigo_cobol}
      
      Responda em português brasileiro com formato estruturado.
      
    security_analysis: |
      Você é um especialista em segurança de aplicações.
      Analise este código COBOL para vulnerabilidades:
      1. Validação de entrada inadequada
      2. Tratamento de erros insuficiente
      3. Exposição de dados sensíveis
      4. Problemas de autorização
      
      Código COBOL:
      {codigo_cobol}
      
      Forneça recomendações específicas e práticas.
      
    modernization_strategy: |
      Você é um arquiteto de software especializado em modernização.
      Analise este programa COBOL e sugira:
      1. Arquitetura moderna equivalente
      2. Stack tecnológico recomendado
      3. Plano de migração faseado
      4. Estimativas de esforço e custo
      
      Código COBOL:
      {codigo_cobol}
      
      Considere melhores práticas de arquitetura moderna.
```

### Uso com Configuração Customizada

```bash
# Usar arquivo de configuração específico
python cobol_engine.py analyze programa.cbl \
  --config config_ai.yaml \
  --ai-analysis business \
  --output ./analise_customizada
```

## Otimização de Custos

### Estratégias de Redução de Custos

#### 1. Cache Inteligente
```python
# Implementação de cache para evitar chamadas repetidas
import hashlib
import json
import os

def get_cache_key(codigo_cobol, tipo_analise):
    content = f"{codigo_cobol}_{tipo_analise}"
    return hashlib.md5(content.encode()).hexdigest()

def cache_response(key, response):
    cache_dir = "./cache_ia"
    os.makedirs(cache_dir, exist_ok=True)
    with open(f"{cache_dir}/{key}.json", "w") as f:
        json.dump(response, f)

def get_cached_response(key):
    cache_file = f"./cache_ia/{key}.json"
    if os.path.exists(cache_file):
        with open(cache_file, "r") as f:
            return json.load(f)
    return None
```

#### 2. Processamento em Lote
```bash
# Processar múltiplos arquivos em uma única chamada
python cobol_engine.py batch portfolio.zip \
  --ai-analysis business \
  --batch-size 5 \
  --output ./analise_lote_ia
```

#### 3. Modelos Mais Econômicos
```yaml
# Usar GPT-3.5-turbo para análises simples
ai_integration:
  model_selection:
    business_analysis: "gpt-3.5-turbo"  # Mais barato
    security_analysis: "gpt-4"          # Mais preciso
    modernization: "gpt-4"              # Mais complexo
```

### Monitoramento de Custos

#### Script de Monitoramento
```python
#!/usr/bin/env python3
# monitor_custos_ia.py

import json
import glob
from datetime import datetime, timedelta

def calcular_custos_ia():
    # Preços por 1K tokens (valores aproximados)
    precos = {
        "gpt-4": {"input": 0.03, "output": 0.06},
        "gpt-3.5-turbo": {"input": 0.001, "output": 0.002}
    }
    
    custo_total = 0
    uso_por_modelo = {}
    
    # Analisar logs de uso
    for log_file in glob.glob("./logs/ai_usage_*.json"):
        with open(log_file, "r") as f:
            logs = json.load(f)
            
        for log in logs:
            modelo = log["model"]
            tokens_input = log["tokens_input"]
            tokens_output = log["tokens_output"]
            
            if modelo not in uso_por_modelo:
                uso_por_modelo[modelo] = {"input": 0, "output": 0, "custo": 0}
            
            uso_por_modelo[modelo]["input"] += tokens_input
            uso_por_modelo[modelo]["output"] += tokens_output
            
            custo_input = (tokens_input / 1000) * precos[modelo]["input"]
            custo_output = (tokens_output / 1000) * precos[modelo]["output"]
            custo_chamada = custo_input + custo_output
            
            uso_por_modelo[modelo]["custo"] += custo_chamada
            custo_total += custo_chamada
    
    # Relatório
    print("=== RELATÓRIO DE CUSTOS IA ===")
    print(f"Período: {datetime.now().strftime('%d/%m/%Y')}")
    print(f"Custo Total: ${custo_total:.2f}")
    print()
    
    for modelo, dados in uso_por_modelo.items():
        print(f"Modelo: {modelo}")
        print(f"  Tokens Input: {dados['input']:,}")
        print(f"  Tokens Output: {dados['output']:,}")
        print(f"  Custo: ${dados['custo']:.2f}")
        print()

if __name__ == "__main__":
    calcular_custos_ia()
```

## Casos de Uso Avançados

### 1. Análise Comparativa de Portfolios

```bash
# Analisar múltiplos portfolios e comparar
python cobol_engine.py batch portfolio_v1.zip \
  --ai-analysis business \
  --output ./analise_v1

python cobol_engine.py batch portfolio_v2.zip \
  --ai-analysis business \
  --output ./analise_v2

# Script de comparação
python comparar_portfolios.py ./analise_v1 ./analise_v2
```

### 2. Geração de Documentação Técnica

```bash
# Gerar documentação completa com IA
python cobol_engine.py batch sistema_completo.zip \
  --ai-analysis documentation \
  --format markdown \
  --output ./documentacao_tecnica
```

### 3. Análise de Impacto de Mudanças

```bash
# Analisar impacto de modificações
python cobol_engine.py analyze programa_modificado.cbl \
  --ai-analysis impact \
  --baseline programa_original.cbl \
  --output ./analise_impacto
```

## Integração com Pipelines CI/CD

### GitHub Actions

```yaml
# .github/workflows/cobol-ai-analysis.yml
name: Análise COBOL com IA

on:
  push:
    paths:
      - '**/*.cbl'
      - '**/*.cob'

jobs:
  analyze:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup Python
      uses: actions/setup-python@v2
      with:
        python-version: '3.11'
        
    - name: Install dependencies
      run: |
        pip install -r requirements.txt
        
    - name: Analyze COBOL with AI
      env:
        OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
      run: |
        python cobol_engine.py batch ./cobol_src \
          --ai-analysis security \
          --output ./ai_analysis \
          --format json
          
    - name: Upload results
      uses: actions/upload-artifact@v2
      with:
        name: ai-analysis-results
        path: ./ai_analysis/
        
    - name: Comment PR
      if: github.event_name == 'pull_request'
      uses: actions/github-script@v6
      with:
        script: |
          const fs = require('fs');
          const report = fs.readFileSync('./ai_analysis/consolidated_report.md', 'utf8');
          
          github.rest.issues.createComment({
            issue_number: context.issue.number,
            owner: context.repo.owner,
            repo: context.repo.repo,
            body: `## Análise IA do Código COBOL\n\n${report}`
          });
```

### Jenkins Pipeline

```groovy
// Jenkinsfile
pipeline {
    agent any
    
    environment {
        OPENAI_API_KEY = credentials('openai-api-key')
    }
    
    stages {
        stage('Checkout') {
            steps {
                checkout scm
            }
        }
        
        stage('Setup') {
            steps {
                sh 'pip install -r requirements.txt'
            }
        }
        
        stage('AI Analysis') {
            steps {
                sh '''
                    python cobol_engine.py batch ./src/cobol \
                      --ai-analysis business security modernization \
                      --output ./ai_results \
                      --format markdown
                '''
            }
        }
        
        stage('Publish Results') {
            steps {
                publishHTML([
                    allowMissing: false,
                    alwaysLinkToLastBuild: true,
                    keepAll: true,
                    reportDir: 'ai_results',
                    reportFiles: 'consolidated_report.md',
                    reportName: 'AI Analysis Report'
                ])
            }
        }
    }
    
    post {
        always {
            archiveArtifacts artifacts: 'ai_results/**/*', fingerprint: true
        }
    }
}
```

## Solução de Problemas

### Problemas Comuns

#### 1. Erro de Autenticação
```
Error: Invalid API key provided
```

**Soluções:**
```bash
# Verificar chave
echo $OPENAI_API_KEY

# Testar conectividade
curl -H "Authorization: Bearer $OPENAI_API_KEY" \
  https://api.openai.com/v1/models

# Verificar permissões da chave
```

#### 2. Limite de Rate Exceeded
```
Error: Rate limit exceeded
```

**Soluções:**
```bash
# Reduzir frequência de chamadas
python cobol_engine.py batch portfolio.zip \
  --ai-rate-limit 30 \
  --ai-delay 2

# Usar cache para evitar chamadas repetidas
python cobol_engine.py batch portfolio.zip \
  --ai-cache-enabled
```

#### 3. Timeout de API
```
Error: Request timeout
```

**Soluções:**
```bash
# Aumentar timeout
export OPENAI_TIMEOUT=60

# Dividir análise em lotes menores
python cobol_engine.py batch portfolio.zip \
  --ai-batch-size 3
```

### Debugging

#### Logs Detalhados
```bash
# Habilitar logs de IA
export AI_DEBUG=true
export LOG_LEVEL=DEBUG

python cobol_engine.py analyze programa.cbl \
  --ai-analysis business \
  --verbose
```

#### Teste de Conectividade
```python
#!/usr/bin/env python3
# test_ai_connection.py

import os
import openai

def test_openai_connection():
    openai.api_key = os.getenv("OPENAI_API_KEY")
    
    try:
        response = openai.Model.list()
        print("✅ Conexão com OpenAI OK")
        print(f"Modelos disponíveis: {len(response['data'])}")
        
        # Teste de chat
        test_response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": "Hello"}],
            max_tokens=10
        )
        print("✅ Teste de chat OK")
        
    except Exception as e:
        print(f"❌ Erro: {e}")

if __name__ == "__main__":
    test_openai_connection()
```

## Melhores Práticas

### 1. Segurança
- Nunca commitar chaves de API no código
- Usar variáveis de ambiente ou secrets management
- Implementar rotação regular de chaves
- Monitorar uso para detectar anomalias

### 2. Performance
- Usar cache para evitar chamadas repetidas
- Implementar rate limiting adequado
- Processar em lotes quando possível
- Escolher modelo apropriado para cada tipo de análise

### 3. Qualidade
- Validar respostas da IA antes de usar
- Implementar fallbacks para falhas de API
- Manter prompts versionados e testados
- Coletar feedback para melhorar prompts

### 4. Custos
- Monitorar uso e custos regularmente
- Usar modelos mais baratos quando apropriado
- Implementar limites de gasto
- Otimizar prompts para reduzir tokens

Esta integração com IA transforma o Motor de Documentação COBOL em uma ferramenta ainda mais poderosa, oferecendo insights contextuais e estratégicos que vão além da análise técnica tradicional.

