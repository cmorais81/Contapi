# Suporte a Arquivos TXT com Múltiplos Programas COBOL

## Visão Geral

O Motor de Documentação COBOL agora suporta o processamento de arquivos TXT que contêm múltiplos programas COBOL, similar ao formato mostrado na imagem fornecida. Esta funcionalidade permite analisar arquivos como `fontes.txt` e `books.txt` que são comuns em ambientes mainframe.

## Funcionalidades Implementadas

### 1. Processador de Arquivos TXT (`CobolTxtProcessor`)

**Características:**
- Detecção automática de múltiplos programas em um único arquivo
- Separação inteligente baseada em padrões COBOL
- Suporte a diferentes formatos de numeração de linha
- Identificação de copybooks e layouts
- Validação de conteúdo COBOL

**Padrões de Separação Suportados:**
- `IDENTIFICATION DIVISION`
- `ID DIVISION`
- `PROGRAM-ID`
- Comentários com asteriscos indicando novos programas
- Numeração de linha sequencial (colunas 1-6)

### 2. Validador de Arquivos TXT (`TxtFileValidator`)

**Funcionalidades:**
- Verificação se arquivo contém código COBOL válido
- Análise de qualidade do código extraído
- Detecção de estruturas COBOL essenciais
- Cálculo de score de confiança

### 3. Interface de Linha de Comando

**Novo Comando:**
```bash
python cobol_engine.py txt <arquivo.txt> [opções]
```

**Opções Disponíveis:**
- `--output`: Diretório de saída (padrão: ./txt_analysis)
- `--format`: Formato de saída (json, yaml, markdown)
- `--analyzers`: Analisadores específicos a usar
- `--keep-temp`: Manter arquivos temporários para debug
- `--summary-only`: Gerar apenas resumo sem análise individual

## Tipos de Arquivo Suportados

### 1. Arquivos de Programas (`fontes.txt`)
- Múltiplos programas COBOL completos
- Separação automática por divisões
- Extração de PROGRAM-ID quando disponível
- Numeração automática para programas sem ID

### 2. Arquivos de Copybooks (`books.txt`)
- Layouts e estruturas de dados
- Copybooks complementares
- Definições de registros
- Estruturas hierárquicas

### 3. Arquivos Únicos
- Programa COBOL único em formato TXT
- Detecção automática de tipo
- Processamento como arquivo individual

## Processo de Análise

### Etapa 1: Identificação do Tipo
```
Arquivo TXT → Análise de Conteúdo → Classificação
                                  ├── Múltiplos Programas
                                  ├── Copybooks/Layouts  
                                  └── Programa Único
```

### Etapa 2: Extração de Programas
```
Conteúdo → Separação por Padrões → Programas Individuais
                                 ├── PROGRAM-ID identificado
                                 ├── Contagem de linhas
                                 ├── Posição no arquivo
                                 └── Tipo (program/copybook)
```

### Etapa 3: Criação de Arquivos Temporários
```
Programas Extraídos → Arquivos .cbl Temporários → Análise Individual
                                                 ├── Parser COBOL
                                                 ├── Analisadores
                                                 └── Formatadores
```

### Etapa 4: Consolidação de Resultados
```
Análises Individuais → Relatório Consolidado → Métricas Agregadas
                                             ├── Estatísticas gerais
                                             ├── Pontuações médias
                                             └── Tabela de resultados
```

## Exemplo de Uso

### Comando Básico
```bash
python cobol_engine.py txt fontes.txt --output ./analise_fontes
```

### Análise Completa com Todos os Plugins
```bash
python cobol_engine.py txt fontes.txt \
  --output ./analise_completa \
  --format markdown \
  --analyzers security_analyzer performance_analyzer functional_analyzer
```

### Apenas Resumo (Sem Análise Individual)
```bash
python cobol_engine.py txt fontes.txt \
  --output ./resumo \
  --summary-only \
  --format yaml
```

### Manter Arquivos Temporários para Debug
```bash
python cobol_engine.py txt fontes.txt \
  --output ./debug \
  --keep-temp
```

## Resultados Gerados

### 1. Análises Individuais
- Um arquivo de análise para cada programa extraído
- Formato: `{PROGRAM-ID}_analysis.{extensão}`
- Conteúdo: Análise completa com todos os analisadores

### 2. Relatório Consolidado
- Arquivo: `txt_consolidated_report.md`
- Resumo executivo com estatísticas gerais
- Métricas agregadas de segurança e performance
- Tabela com resultados de todos os programas

### 3. Resumo de Extração (Opcional)
- Arquivo: `txt_summary.{formato}`
- Estatísticas de extração
- Lista de programas identificados
- Distribuição por tipo

## Exemplo de Resultado

### Arquivo de Entrada: `fontes.txt` (622 linhas)
```
Programas encontrados: 3
- CADCLI01: Sistema de Cadastro de Clientes (154 linhas)
- ESTOQUE01: Sistema de Controle de Estoque (239 linhas)  
- RELVEND01: Relatório de Vendas Mensais (225 linhas)
```

### Métricas Consolidadas
```
Pontuação Média de Segurança: 94.0/100
Pontuação Média de Performance: 99.3/100
Velocidade de Processamento: 28.474 programas/min
Taxa de Sucesso: 100%
```

## Tratamento de Erros

### Codificação de Arquivos
- Tentativa automática de múltiplas codificações
- Suporte a UTF-8, Latin-1, CP1252, ISO-8859-1
- Tratamento gracioso de caracteres especiais

### Validação de Conteúdo
- Verificação se arquivo contém código COBOL
- Aviso para arquivos com baixa confiança
- Continuação do processamento com alertas

### Limpeza de Recursos
- Remoção automática de arquivos temporários
- Opção para manter arquivos para debug
- Tratamento de exceções com cleanup garantido

## Benefícios

### 1. Compatibilidade com Formatos Legacy
- Suporte a arquivos TXT tradicionais de mainframe
- Processamento de múltiplos programas em arquivo único
- Manutenção da estrutura original

### 2. Eficiência de Processamento
- Análise paralela de programas extraídos
- Relatórios consolidados automáticos
- Métricas agregadas para gestão

### 3. Flexibilidade de Uso
- Múltiplos formatos de saída
- Análise seletiva por tipo
- Configuração de analisadores

### 4. Integração Completa
- Uso dos mesmos analisadores do motor principal
- Formatação consistente com outras funcionalidades
- Interface unificada de linha de comando

## Limitações Conhecidas

### 1. Dependência de Padrões
- Requer estrutura COBOL reconhecível
- Pode ter dificuldade com formatos muito customizados
- Separação baseada em heurísticas

### 2. Numeração de Linha
- Suporte limitado a formatos específicos
- Pode não reconhecer numerações customizadas
- Requer validação manual em casos complexos

### 3. Copybooks Complexos
- Detecção de copybooks pode ser imprecisa
- Relacionamentos entre copybooks não mapeados
- Análise individual limitada para layouts

## Próximas Melhorias

### 1. Detecção Aprimorada
- Algoritmos mais sofisticados de separação
- Suporte a mais formatos de numeração
- Detecção de relacionamentos entre programas

### 2. Análise de Copybooks
- Parser específico para layouts
- Mapeamento de relacionamentos
- Validação de consistência

### 3. Interface Gráfica
- Visualização de programas extraídos
- Editor para correção manual
- Preview antes da análise

### 4. Integração com Mainframe
- Suporte a datasets MVS
- Conectores para sistemas z/OS
- Processamento de bibliotecas PDS

## Conclusão

O suporte a arquivos TXT com múltiplos programas COBOL expande significativamente as capacidades do Motor de Documentação COBOL, permitindo o processamento eficiente de arquivos legacy comuns em ambientes mainframe. A funcionalidade mantém a qualidade e consistência das análises enquanto oferece flexibilidade para diferentes formatos de entrada.

Esta implementação segue os princípios SOLID estabelecidos no projeto, garantindo extensibilidade e manutenibilidade para futuras melhorias.

