"""
Interface de Linha de Comando para o Motor de Documentação COBOL.
Seguindo o Princípio da Responsabilidade Única e arquitetura limpa.
"""

import os
import sys
import argparse
import time
from typing import List
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from .core.engine import DocumentationEngine
from .utils.exceptions import EngineError, FileNotFoundError
from .utils.file_utils import FileManager


class CobolCLI:
    """
    Interface de Linha de Comando para o Motor de Documentação COBOL.
    Seguindo o Princípio da Responsabilidade Única.
    """
    
    def __init__(self):
        self.console = Console()
        self.engine = DocumentationEngine()
    
    def run(self, args: List[str] = None):
        """Executar a CLI com argumentos fornecidos."""
        parser = self._create_parser()
        parsed_args = parser.parse_args(args)
        
        try:
            if parsed_args.command == 'analyze':
                self._handle_analyze(parsed_args)
            elif parsed_args.command == 'batch':
                self._handle_batch(parsed_args)
            elif parsed_args.command == 'txt':
                self._handle_txt(parsed_args)
            elif parsed_args.command == 'info':
                self._handle_info(parsed_args)
            else:
                parser.print_help()
                
        except KeyboardInterrupt:
            self.console.print("\n[yellow]Operação cancelada pelo usuário[/yellow]")
            sys.exit(1)
        except Exception as e:
            self.console.print(f"[red]Erro: {e}[/red]")
            sys.exit(1)
    
    def _create_parser(self) -> argparse.ArgumentParser:
        """Criar parser de argumentos."""
        parser = argparse.ArgumentParser(
            description="Motor de Documentação COBOL - Analisar e documentar programas COBOL",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Exemplos:
  # Analisar arquivo único
  motor-cobol analyze programa.cbl --output ./resultados
  
  # Análise em lote de arquivo ZIP
  motor-cobol batch portfolio.zip --output ./analise --analyzers security_analyzer performance_analyzer
  
  # Obter informações do motor
  motor-cobol info
            """
        )
        
        subparsers = parser.add_subparsers(dest='command', help='Comandos disponíveis')
        
        # Comando analyze
        analyze_parser = subparsers.add_parser('analyze', help='Analisar um arquivo COBOL único')
        analyze_parser.add_argument('file', help='Arquivo COBOL para analisar')
        analyze_parser.add_argument('--output', '-o', help='Diretório de saída', default='./output')
        analyze_parser.add_argument('--format', '-f', choices=['json', 'yaml', 'markdown'], 
                                   default='json', help='Formato de saída')
        analyze_parser.add_argument('--analyzers', '-a', nargs='*', 
                                   help='Analisadores para executar (padrão: todos disponíveis)')
        
        # Comando batch
        batch_parser = subparsers.add_parser('batch', help='Análise em lote de múltiplos arquivos COBOL')
        batch_parser.add_argument('source', help='Arquivo ZIP ou diretório contendo arquivos COBOL')
        batch_parser.add_argument('--output', '-o', required=True, help='Diretório de saída')
        batch_parser.add_argument('--format', '-f', choices=['json', 'yaml', 'markdown'], 
                                 default='json', help='Formato de saída para arquivos individuais')
        batch_parser.add_argument('--analyzers', '-a', nargs='*', 
                                 help='Analisadores para executar (padrão: todos disponíveis)')
        batch_parser.add_argument('--parallel', action='store_true', default=True,
                                 help='Habilitar processamento paralelo (padrão: True)')
        batch_parser.add_argument('--max-workers', type=int, default=4,
                                 help='Número máximo de workers paralelos (padrão: 4)')
        
        # Comando info
        info_parser = subparsers.add_parser('info', help='Mostrar informações do motor')
        info_parser.add_argument('--analyzers', action='store_true', 
                                help='Mostrar analisadores disponíveis')
        info_parser.add_argument('--formatters', action='store_true', 
                                help='Mostrar formatadores disponíveis')
        
        # Comando TXT
        txt_parser = subparsers.add_parser(
            'txt',
            help='Processar arquivo TXT com múltiplos programas COBOL'
        )
        txt_parser.add_argument('input_file', help='Arquivo TXT de entrada')
        txt_parser.add_argument('--output', '-o', default='./txt_analysis', 
                               help='Diretório de saída (padrão: ./txt_analysis)')
        txt_parser.add_argument('--format', '-f', choices=['json', 'yaml', 'markdown'], 
                               default='markdown', help='Formato de saída')
        txt_parser.add_argument('--analyzers', nargs='*', 
                               help='Analisadores específicos a usar')
        txt_parser.add_argument('--keep-temp', action='store_true',
                               help='Manter arquivos temporários para debug')
        txt_parser.add_argument('--summary-only', action='store_true',
                               help='Gerar apenas resumo, sem análise individual')
        
        return parser
    
    def _handle_analyze(self, args):
        """Tratar análise de arquivo único."""
        if not os.path.exists(args.file):
            raise FileNotFoundError(f"Arquivo não encontrado: {args.file}")
        
        # Preparar analisadores
        analyzers = args.analyzers or self.engine.get_available_analyzers()
        
        self.console.print(f"[blue]Analisando arquivo:[/blue] {args.file}")
        self.console.print(f"[blue]Analisadores:[/blue] {', '.join(analyzers)}")
        self.console.print(f"[blue]Formato de saída:[/blue] {args.format}")
        
        # Analisar com progresso
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console
        ) as progress:
            task = progress.add_task("Analisando...", total=None)
            
            start_time = time.time()
            result = self.engine.analyze_single_file(args.file, analyzers)
            execution_time = time.time() - start_time
            
            progress.update(task, completed=True)
        
        # Exibir resultados
        self._display_single_result(result, execution_time)
        
        # Salvar resultados
        FileManager.ensure_directory(args.output)
        
        file_name = os.path.basename(args.file)
        base_name = os.path.splitext(file_name)[0]
        
        formatter = self.engine.formatter_registry.get_formatter(args.format)
        output_file = os.path.join(args.output, f"{base_name}_analysis{formatter.file_extension}")
        
        self.engine.save_result(result, output_file, args.format)
        
        self.console.print(f"\n[green]Análise completa![/green]")
        self.console.print(f"[blue]Resultados salvos em:[/blue] {output_file}")
    
    def _handle_batch(self, args):
        """Tratar análise em lote."""
        if not os.path.exists(args.source):
            raise FileNotFoundError(f"Fonte não encontrada: {args.source}")
        
        # Preparar analisadores
        analyzers = args.analyzers or self.engine.get_available_analyzers()
        
        self.console.print(f"[blue]Fonte:[/blue] {args.source}")
        self.console.print(f"[blue]Analisadores:[/blue] {', '.join(analyzers)}")
        self.console.print(f"[blue]Processamento paralelo:[/blue] {args.parallel}")
        self.console.print(f"[blue]Máximo de workers:[/blue] {args.max_workers}")
        
        # Analisar com progresso
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=self.console
        ) as progress:
            task = progress.add_task("Processando lote...", total=None)
            
            start_time = time.time()
            batch_result = self.engine.analyze_batch(
                args.source, 
                analyzers, 
                parallel=args.parallel,
                max_workers=args.max_workers
            )
            execution_time = time.time() - start_time
            
            progress.update(task, completed=True)
        
        # Exibir resultados
        self._display_batch_result(batch_result, execution_time)
        
        # Salvar resultados
        FileManager.ensure_directory(args.output)
        self.engine.save_batch_result(batch_result, args.output, args.format)
        
        self.console.print(f"\n[green]Análise em lote completa![/green]")
        self.console.print(f"[blue]Resultados salvos em:[/blue] {args.output}")
    
    def _handle_info(self, args):
        """Tratar comando info."""
        self.console.print(Panel.fit(
            "[bold blue]Motor de Documentação COBOL[/bold blue]\n"
            "Versão: 2.0.0\n"
            "Ferramenta moderna para análise e documentação de programas COBOL",
            title="Informações do Motor"
        ))
        
        if args.analyzers or not (args.analyzers or args.formatters):
            self._show_analyzers()
        
        if args.formatters or not (args.analyzers or args.formatters):
            self._show_formatters()
    
    def _show_analyzers(self):
        """Mostrar analisadores disponíveis."""
        analyzers = self.engine.get_available_analyzers()
        
        table = Table(title="Analisadores Disponíveis")
        table.add_column("Nome", style="cyan")
        table.add_column("Descrição", style="white")
        
        analyzer_descriptions = {
            'security_analyzer': 'Analisa vulnerabilidades de segurança e compliance',
            'performance_analyzer': 'Analisa problemas de performance e oportunidades de otimização'
        }
        
        for analyzer_name in analyzers:
            description = analyzer_descriptions.get(analyzer_name, 'Nenhuma descrição disponível')
            table.add_row(analyzer_name, description)
        
        self.console.print(table)
    
    def _show_formatters(self):
        """Mostrar formatadores disponíveis."""
        formatters = self.engine.get_available_formatters()
        
        table = Table(title="Formatadores Disponíveis")
        table.add_column("Nome", style="cyan")
        table.add_column("Extensão", style="yellow")
        table.add_column("Descrição", style="white")
        
        formatter_descriptions = {
            'json': 'JavaScript Object Notation - formato de dados estruturado',
            'yaml': 'YAML Ain\'t Markup Language - formato de dados legível para humanos',
            'markdown': 'Markdown - texto formatado para documentação'
        }
        
        for formatter_name in formatters:
            formatter = self.engine.formatter_registry.get_formatter(formatter_name)
            extension = formatter.file_extension if formatter else 'N/A'
            description = formatter_descriptions.get(formatter_name, 'Nenhuma descrição disponível')
            table.add_row(formatter_name, extension, description)
        
        self.console.print(table)
    
    def _handle_txt(self, args):
        """Tratar processamento de arquivo TXT com múltiplos programas COBOL."""
        from src.utils.txt_processor import CobolTxtProcessor, TxtFileValidator
        
        if not os.path.exists(args.input_file):
            raise FileNotFoundError(f"Arquivo não encontrado: {args.input_file}")
        
        # Validar se é arquivo COBOL TXT
        if not TxtFileValidator.is_cobol_txt_file(args.input_file):
            self.console.print("[yellow]Aviso: Arquivo pode não conter código COBOL válido[/yellow]")
        
        self.console.print(f"[blue]Processando arquivo TXT:[/blue] {args.input_file}")
        
        # Processar arquivo TXT
        processor = CobolTxtProcessor()
        
        try:
            programs = processor.process_txt_file(args.input_file)
            
            if not programs:
                self.console.print("[red]Nenhum programa COBOL encontrado no arquivo[/red]")
                return
            
            # Mostrar resumo
            summary = processor.get_program_summary(programs)
            self.console.print(f"[green]Programas encontrados:[/green] {summary['total_programs']}")
            self.console.print(f"[green]Total de linhas:[/green] {summary['total_lines']:,}")
            
            # Criar diretório de saída
            os.makedirs(args.output, exist_ok=True)
            
            if args.summary_only:
                # Gerar apenas resumo
                summary_file = os.path.join(args.output, f"txt_summary.{args.format}")
                
                if args.format == 'json':
                    import json
                    with open(summary_file, 'w', encoding='utf-8') as f:
                        json.dump(summary, f, indent=2, ensure_ascii=False)
                elif args.format == 'yaml':
                    import yaml
                    with open(summary_file, 'w', encoding='utf-8') as f:
                        yaml.dump(summary, f, default_flow_style=False, allow_unicode=True)
                else:  # markdown
                    with open(summary_file, 'w', encoding='utf-8') as f:
                        f.write(self._format_txt_summary_markdown(summary, args.input_file))
                
                self.console.print(f"[green]Resumo salvo em:[/green] {summary_file}")
                return
            
            # Criar arquivos temporários
            temp_files = processor.create_temp_files(programs)
            
            try:
                # Preparar analisadores
                analyzers = args.analyzers or self.engine.get_available_analyzers()
                
                # Processar cada programa
                results = {}
                total_time = 0
                
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    BarColumn(),
                    TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                    console=self.console
                ) as progress:
                    task = progress.add_task("Analisando programas...", total=len(temp_files))
                    
                    for i, (temp_file, program_info) in enumerate(zip(temp_files, programs)):
                        progress.update(task, description=f"Analisando {program_info['program_id']}...")
                        
                        start_time = time.time()
                        result = self.engine.analyze_single_file(temp_file, analyzers)
                        execution_time = time.time() - start_time
                        total_time += execution_time
                        
                        result.execution_time = execution_time
                        results[program_info['program_id']] = result
                        
                        # Salvar resultado individual
                        formatter = self.engine.formatter_registry.get_formatter(args.format)
                        if formatter:
                            output_file = os.path.join(
                                args.output, 
                                f"{program_info['program_id']}_analysis{formatter.file_extension}"
                            )
                            
                            formatted_result = formatter.format_single_result(result)
                            with open(output_file, 'w', encoding='utf-8') as f:
                                f.write(formatted_result)
                        
                        progress.advance(task)
                
                # Gerar relatório consolidado
                consolidated_file = os.path.join(args.output, f"txt_consolidated_report.md")
                with open(consolidated_file, 'w', encoding='utf-8') as f:
                    f.write(self._format_txt_consolidated_report(
                        results, programs, summary, args.input_file, total_time
                    ))
                
                self.console.print(f"\n[green]Análise completa![/green]")
                self.console.print(f"[green]Resultados salvos em:[/green] {args.output}")
                self.console.print(f"[green]Relatório consolidado:[/green] {consolidated_file}")
                
            finally:
                # Limpar arquivos temporários
                if not args.keep_temp:
                    processor.cleanup_temp_files(temp_files)
                else:
                    self.console.print(f"[yellow]Arquivos temporários mantidos para debug[/yellow]")
        
        except Exception as e:
            self.console.print(f"[red]Erro ao processar arquivo TXT: {e}[/red]")
            raise
    
    def _format_txt_summary_markdown(self, summary: dict, source_file: str) -> str:
        """Formatar resumo de arquivo TXT em Markdown."""
        lines = [
            f"# Resumo de Análise - {os.path.basename(source_file)}",
            "",
            "## Estatísticas Gerais",
            "",
            f"- **Arquivo Fonte**: {source_file}",
            f"- **Total de Programas**: {summary['total_programs']}",
            f"- **Total de Linhas**: {summary['total_lines']:,}",
            f"- **Média de Linhas por Programa**: {summary['average_lines']:.1f}",
            "",
            "## Programas Identificados",
            "",
            "| ID do Programa | Linhas | Tipo |",
            "|----------------|--------|------|"
        ]
        
        for prog in summary['programs']:
            lines.append(f"| {prog['id']} | {prog['lines']:,} | {prog['type']} |")
        
        lines.extend([
            "",
            "## Distribuição por Tipo",
            ""
        ])
        
        for prog_type, count in summary['program_types'].items():
            lines.append(f"- **{prog_type.title()}**: {count} programa(s)")
        
        lines.extend([
            "",
            "---",
            "",
            f"*Resumo gerado pelo Motor de Documentação COBOL*"
        ])
        
        return "\n".join(lines)
    
    def _format_txt_consolidated_report(self, results: dict, programs: list, 
                                      summary: dict, source_file: str, total_time: float) -> str:
        """Formatar relatório consolidado de arquivo TXT."""
        lines = [
            f"# Relatório Consolidado - {os.path.basename(source_file)}",
            "",
            "## Resumo Executivo",
            "",
            f"- **Arquivo Fonte**: {source_file}",
            f"- **Programas Processados**: {len(results)}",
            f"- **Total de Linhas**: {summary['total_lines']:,}",
            f"- **Tempo Total de Análise**: {total_time:.2f}s",
            f"- **Velocidade**: {len(results) / total_time * 60:.1f} programas/min",
            ""
        ]
        
        # Calcular métricas consolidadas
        successful_results = [r for r in results.values() if r.success]
        
        if successful_results:
            # Métricas de segurança
            security_scores = []
            performance_scores = []
            
            for result in successful_results:
                if 'analyzer_results' in result.data:
                    analyzer_results = result.data['analyzer_results']
                    
                    if 'security_analyzer' in analyzer_results:
                        score = analyzer_results['security_analyzer'].get('security_score', 0)
                        security_scores.append(score)
                    
                    if 'performance_analyzer' in analyzer_results:
                        score = analyzer_results['performance_analyzer'].get('performance_score', 0)
                        performance_scores.append(score)
            
            if security_scores:
                lines.extend([
                    "## Métricas de Segurança",
                    "",
                    f"- **Pontuação Média**: {sum(security_scores) / len(security_scores):.1f}/100",
                    f"- **Melhor Pontuação**: {max(security_scores)}/100",
                    f"- **Pior Pontuação**: {min(security_scores)}/100",
                    f"- **Programas Analisados**: {len(security_scores)}",
                    ""
                ])
            
            if performance_scores:
                lines.extend([
                    "## Métricas de Performance",
                    "",
                    f"- **Pontuação Média**: {sum(performance_scores) / len(performance_scores):.1f}/100",
                    f"- **Melhor Pontuação**: {max(performance_scores)}/100",
                    f"- **Pior Pontuação**: {min(performance_scores)}/100",
                    f"- **Programas Analisados**: {len(performance_scores)}",
                    ""
                ])
        
        # Tabela de resultados
        lines.extend([
            "## Resultados por Programa",
            "",
            "| Programa | Status | Linhas | Tempo | Segurança | Performance |",
            "|----------|--------|--------|-------|-----------|-------------|"
        ])
        
        for program_info in programs:
            program_id = program_info['program_id']
            result = results.get(program_id)
            
            if result:
                status = "✅ Sucesso" if result.success else "❌ Falhou"
                lines_count = program_info['lines_count']
                time_str = f"{result.execution_time:.2f}s"
                
                security_score = "N/A"
                performance_score = "N/A"
                
                if result.success and 'analyzer_results' in result.data:
                    analyzer_results = result.data['analyzer_results']
                    
                    if 'security_analyzer' in analyzer_results:
                        score = analyzer_results['security_analyzer'].get('security_score', 0)
                        security_score = f"{score}/100"
                    
                    if 'performance_analyzer' in analyzer_results:
                        score = analyzer_results['performance_analyzer'].get('performance_score', 0)
                        performance_score = f"{score}/100"
                
                lines.append(f"| {program_id} | {status} | {lines_count:,} | {time_str} | {security_score} | {performance_score} |")
            else:
                lines.append(f"| {program_id} | ❌ Não processado | {program_info['lines_count']:,} | N/A | N/A | N/A |")
        
        lines.extend([
            "",
            "---",
            "",
            f"*Relatório gerado pelo Motor de Documentação COBOL*"
        ])
        
        return "\n".join(lines)
    
    def _display_single_result(self, result, execution_time: float):
        """Exibir resultado de análise única."""
        status = "Sucesso" if result.success else "Falhou"
        
        table = Table(title="Resultados da Análise")
        table.add_column("Métrica", style="cyan")
        table.add_column("Valor", style="white")
        
        table.add_row("Status", status)
        table.add_row("ID do Programa", result.program_id)
        table.add_row("Tempo de Execução", f"{execution_time:.2f}s")
        
        if result.success and 'program_info' in result.data:
            info = result.data['program_info']
            table.add_row("Linhas de Código", f"{info.get('lines_of_code', 0):,}")
            table.add_row("Variáveis", str(info.get('variables_count', 0)))
            table.add_row("Complexidade", str(info.get('total_complexity', 0)))
        
        # Mostrar resultados dos analisadores
        if result.success and 'analyzer_results' in result.data:
            for analyzer_name, analyzer_data in result.data['analyzer_results'].items():
                if analyzer_name == 'security_analyzer':
                    score = analyzer_data.get('security_score', 0)
                    table.add_row("Pontuação de Segurança", f"{score}/100")
                elif analyzer_name == 'performance_analyzer':
                    score = analyzer_data.get('performance_score', 0)
                    table.add_row("Pontuação de Performance", f"{score}/100")
        
        self.console.print(table)
        
        # Mostrar erros e avisos
        if result.errors:
            self.console.print("\n[red]Erros:[/red]")
            for error in result.errors:
                self.console.print(f"  • {error}")
        
        if result.warnings:
            self.console.print("\n[yellow]Avisos:[/yellow]")
            for warning in result.warnings:
                self.console.print(f"  • {warning}")
    
    def _display_batch_result(self, batch_result, execution_time: float):
        """Exibir resultado de análise em lote."""
        table = Table(title="Resultados da Análise em Lote")
        table.add_column("Métrica", style="cyan")
        table.add_column("Valor", style="white")
        
        table.add_row("Total de Arquivos", str(batch_result.total_files))
        table.add_row("Processados com Sucesso", str(batch_result.processed_files))
        table.add_row("Falharam", str(batch_result.failed_files))
        table.add_row("Taxa de Sucesso", f"{batch_result.get_success_rate():.1f}%")
        table.add_row("Total de Linhas de Código", f"{batch_result.total_lines:,}")
        table.add_row("Tempo de Processamento", f"{execution_time:.2f}s")
        table.add_row("Velocidade de Processamento", f"{batch_result.get_files_per_minute():.1f} arquivos/min")
        
        # Mostrar métricas consolidadas
        if batch_result.consolidated_metrics:
            metrics = batch_result.consolidated_metrics
            
            if 'average_security_score' in metrics:
                table.add_row("Pontuação Média de Segurança", f"{metrics['average_security_score']:.1f}/100")
            
            if 'average_performance_score' in metrics:
                table.add_row("Pontuação Média de Performance", f"{metrics['average_performance_score']:.1f}/100")
            
            table.add_row("Complexidade Média", f"{metrics.get('average_complexity', 0):.1f}")
        
        self.console.print(table)


def main():
    """Ponto de entrada principal."""
    cli = CobolCLI()
    cli.run()


if __name__ == "__main__":
    main()

