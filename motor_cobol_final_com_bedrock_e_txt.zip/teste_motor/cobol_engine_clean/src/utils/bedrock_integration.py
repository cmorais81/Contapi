"""
Integração com AWS Bedrock para análise de código COBOL
Suporte a modelos Claude, Llama e outros disponíveis no Bedrock
"""

import json
import boto3
import time
from typing import Dict, List, Any, Optional
from botocore.exceptions import ClientError, NoCredentialsError
from ..core.models import CobolProgram, AnalysisResult
from ..interfaces.analyzer import IAnalyzer


class BedrockClient:
    """
    Cliente para interação com AWS Bedrock
    """
    
    def __init__(self, 
                 region_name: str = 'us-east-1',
                 aws_access_key_id: Optional[str] = None,
                 aws_secret_access_key: Optional[str] = None,
                 aws_session_token: Optional[str] = None):
        """
        Inicializar cliente Bedrock
        
        Args:
            region_name: Região AWS (padrão: us-east-1)
            aws_access_key_id: Chave de acesso AWS (opcional, usa credenciais padrão)
            aws_secret_access_key: Chave secreta AWS (opcional)
            aws_session_token: Token de sessão AWS (opcional)
        """
        self.region_name = region_name
        
        # Configurar credenciais se fornecidas
        session_kwargs = {}
        if aws_access_key_id:
            session_kwargs['aws_access_key_id'] = aws_access_key_id
        if aws_secret_access_key:
            session_kwargs['aws_secret_access_key'] = aws_secret_access_key
        if aws_session_token:
            session_kwargs['aws_session_token'] = aws_session_token
        
        try:
            if session_kwargs:
                session = boto3.Session(**session_kwargs)
                self.bedrock_client = session.client('bedrock-runtime', region_name=region_name)
            else:
                self.bedrock_client = boto3.client('bedrock-runtime', region_name=region_name)
            
            # Testar conexão
            self._test_connection()
            
        except NoCredentialsError:
            raise Exception("Credenciais AWS não encontradas. Configure AWS CLI ou forneça credenciais.")
        except Exception as e:
            raise Exception(f"Erro ao conectar com AWS Bedrock: {e}")
    
    def _test_connection(self):
        """Testar conexão com Bedrock"""
        try:
            # Tentar listar modelos disponíveis
            bedrock_client = boto3.client('bedrock', region_name=self.region_name)
            bedrock_client.list_foundation_models()
        except Exception as e:
            print(f"Aviso: Não foi possível testar conexão com Bedrock: {e}")
    
    def invoke_model(self, 
                    model_id: str, 
                    prompt: str, 
                    max_tokens: int = 4000,
                    temperature: float = 0.1) -> str:
        """
        Invocar modelo no Bedrock
        
        Args:
            model_id: ID do modelo (ex: anthropic.claude-3-sonnet-20240229-v1:0)
            prompt: Prompt para o modelo
            max_tokens: Máximo de tokens na resposta
            temperature: Temperatura para geração (0.0 a 1.0)
            
        Returns:
            Resposta do modelo
        """
        try:
            # Preparar payload baseado no modelo
            if 'claude' in model_id.lower():
                body = {
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                    "messages": [
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ]
                }
            elif 'llama' in model_id.lower():
                body = {
                    "prompt": prompt,
                    "max_gen_len": max_tokens,
                    "temperature": temperature,
                    "top_p": 0.9
                }
            elif 'titan' in model_id.lower():
                body = {
                    "inputText": prompt,
                    "textGenerationConfig": {
                        "maxTokenCount": max_tokens,
                        "temperature": temperature,
                        "topP": 0.9
                    }
                }
            else:
                # Formato genérico
                body = {
                    "prompt": prompt,
                    "max_tokens": max_tokens,
                    "temperature": temperature
                }
            
            # Invocar modelo
            response = self.bedrock_client.invoke_model(
                modelId=model_id,
                body=json.dumps(body),
                contentType='application/json',
                accept='application/json'
            )
            
            # Processar resposta
            response_body = json.loads(response['body'].read())
            
            # Extrair texto baseado no modelo
            if 'claude' in model_id.lower():
                return response_body['content'][0]['text']
            elif 'llama' in model_id.lower():
                return response_body['generation']
            elif 'titan' in model_id.lower():
                return response_body['results'][0]['outputText']
            else:
                # Tentar formatos comuns
                if 'text' in response_body:
                    return response_body['text']
                elif 'generation' in response_body:
                    return response_body['generation']
                elif 'output' in response_body:
                    return response_body['output']
                else:
                    return str(response_body)
                    
        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            raise Exception(f"Erro do Bedrock ({error_code}): {error_message}")
        except Exception as e:
            raise Exception(f"Erro ao invocar modelo: {e}")


class BedrockAnalyzer(IAnalyzer):
    """
    Analisador que usa AWS Bedrock para análise de código COBOL
    """
    
    def __init__(self, 
                 model_id: str = "anthropic.claude-3-sonnet-20240229-v1:0",
                 region_name: str = "us-east-1",
                 aws_access_key_id: Optional[str] = None,
                 aws_secret_access_key: Optional[str] = None):
        """
        Inicializar analisador Bedrock
        
        Args:
            model_id: ID do modelo Bedrock a usar
            region_name: Região AWS
            aws_access_key_id: Chave de acesso AWS (opcional)
            aws_secret_access_key: Chave secreta AWS (opcional)
        """
        self._name = "bedrock_analyzer"
        self.description = "Analisador de código COBOL usando AWS Bedrock"
        self.version = "1.0.0"
        self.model_id = model_id
        
        # Inicializar cliente Bedrock
        self.bedrock_client = BedrockClient(
            region_name=region_name,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key
        )
        
        # Configurações do modelo
        self.max_tokens = 4000
        self.temperature = 0.1
        
        # Cache para evitar análises repetidas
        self._cache = {}
    
    def analyze(self, program: CobolProgram) -> AnalysisResult:
        """
        Analisar programa COBOL usando Bedrock
        
        Args:
            program: Programa COBOL para analisar
            
        Returns:
            Resultado da análise
        """
        try:
            # Verificar cache
            cache_key = f"{program.program_id}_{hash(program.content)}"
            if cache_key in self._cache:
                cached_result = self._cache[cache_key]
                return AnalysisResult(
                    analyzer_name=self._name,
                    program_id=program.program_id,
                    success=True,
                    data=cached_result
                )
            
            # Preparar prompt especializado
            prompt = self._create_analysis_prompt(program)
            
            # Invocar modelo Bedrock
            start_time = time.time()
            response = self.bedrock_client.invoke_model(
                model_id=self.model_id,
                prompt=prompt,
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            execution_time = time.time() - start_time
            
            # Processar resposta
            analysis_data = self._parse_response(response, program)
            analysis_data['execution_time'] = execution_time
            analysis_data['model_used'] = self.model_id
            
            # Salvar no cache
            self._cache[cache_key] = analysis_data
            
            return AnalysisResult(
                analyzer_name=self._name,
                program_id=program.program_id,
                success=True,
                data=analysis_data,
                execution_time=execution_time
            )
            
        except Exception as e:
            result = AnalysisResult(
                analyzer_name=self._name,
                program_id=program.program_id,
                success=False
            )
            result.add_error(f"Erro na análise Bedrock: {str(e)}")
            return result
    
    def _create_analysis_prompt(self, program: CobolProgram) -> str:
        """
        Criar prompt especializado para análise COBOL
        """
        prompt = f"""
Você é um especialista em análise de código COBOL com décadas de experiência em sistemas mainframe e modernização de aplicações legacy.

Analise o seguinte programa COBOL e forneça uma análise detalhada em português brasileiro:

PROGRAMA: {program.program_id}
AUTOR: {program.author or 'Não especificado'}
DATA: {program.date_written or 'Não especificada'}

CÓDIGO:
```cobol
{program.content}
```

Por favor, forneça uma análise estruturada cobrindo:

1. **PROPÓSITO E FUNCIONALIDADE**
   - O que este programa faz?
   - Qual é o objetivo de negócio?
   - Que processos ele automatiza?

2. **ANÁLISE TÉCNICA**
   - Estruturas de dados utilizadas
   - Operações de arquivo (se houver)
   - Lógica de negócio principal
   - Complexidade do código

3. **QUALIDADE DO CÓDIGO**
   - Boas práticas seguidas
   - Problemas identificados
   - Sugestões de melhoria
   - Manutenibilidade

4. **ANÁLISE DE SEGURANÇA**
   - Vulnerabilidades potenciais
   - Validação de dados
   - Tratamento de erros
   - Pontos de atenção

5. **MODERNIZAÇÃO**
   - Dificuldade de migração (1-10)
   - Tecnologias recomendadas
   - Estratégia de modernização
   - Riscos e benefícios

6. **DOCUMENTAÇÃO DE NEGÓCIO**
   - Regras de negócio identificadas
   - Fluxos de processo
   - Dependências externas
   - Impacto no sistema

Formate a resposta como JSON válido com a seguinte estrutura:
{{
    "proposito": "descrição do propósito",
    "funcionalidade": "explicação detalhada da funcionalidade",
    "analise_tecnica": {{
        "estruturas_dados": ["lista de estruturas"],
        "operacoes_arquivo": ["lista de operações"],
        "logica_principal": "descrição da lógica",
        "complexidade": "baixa/média/alta"
    }},
    "qualidade_codigo": {{
        "pontuacao": 85,
        "boas_praticas": ["lista de boas práticas"],
        "problemas": ["lista de problemas"],
        "sugestoes": ["lista de sugestões"]
    }},
    "seguranca": {{
        "pontuacao": 90,
        "vulnerabilidades": ["lista de vulnerabilidades"],
        "validacoes": ["validações presentes"],
        "recomendacoes": ["recomendações de segurança"]
    }},
    "modernizacao": {{
        "dificuldade": 7,
        "tecnologias_recomendadas": ["Java", "Spring Boot"],
        "estrategia": "descrição da estratégia",
        "riscos": ["lista de riscos"],
        "beneficios": ["lista de benefícios"]
    }},
    "documentacao_negocio": {{
        "regras_negocio": ["lista de regras"],
        "fluxos_processo": ["lista de fluxos"],
        "dependencias": ["lista de dependências"],
        "impacto_sistema": "descrição do impacto"
    }}
}}

Seja específico e técnico, mas mantenha a linguagem acessível para diferentes audiências (técnica e de negócio).
"""
        return prompt
    
    def _parse_response(self, response: str, program: CobolProgram) -> Dict[str, Any]:
        """
        Processar resposta do modelo
        """
        try:
            # Tentar extrair JSON da resposta
            json_start = response.find('{')
            json_end = response.rfind('}') + 1
            
            if json_start >= 0 and json_end > json_start:
                json_str = response[json_start:json_end]
                analysis_data = json.loads(json_str)
            else:
                # Se não encontrar JSON, criar estrutura básica
                analysis_data = {
                    "proposito": "Análise não estruturada disponível",
                    "funcionalidade": response[:500] + "..." if len(response) > 500 else response,
                    "analise_tecnica": {
                        "complexidade": "não determinada"
                    },
                    "qualidade_codigo": {
                        "pontuacao": 50
                    },
                    "seguranca": {
                        "pontuacao": 50
                    },
                    "modernizacao": {
                        "dificuldade": 5
                    },
                    "documentacao_negocio": {
                        "regras_negocio": []
                    },
                    "resposta_completa": response
                }
            
            # Adicionar metadados
            analysis_data['bedrock_analysis'] = True
            analysis_data['model_id'] = self.model_id
            analysis_data['response_length'] = len(response)
            
            return analysis_data
            
        except json.JSONDecodeError as e:
            # Se falhar ao parsear JSON, retornar resposta como texto
            return {
                "proposito": "Erro ao processar análise estruturada",
                "funcionalidade": "Análise disponível em formato de texto",
                "resposta_completa": response,
                "erro_parsing": str(e),
                "bedrock_analysis": True,
                "model_id": self.model_id
            }
    
    def get_name(self) -> str:
        return self._name
    
    def get_description(self) -> str:
        return self.description
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def version(self) -> str:
        return self.version


class BedrockModelManager:
    """
    Gerenciador de modelos disponíveis no Bedrock
    """
    
    # Modelos suportados e suas características
    SUPPORTED_MODELS = {
        "anthropic.claude-3-sonnet-20240229-v1:0": {
            "name": "Claude 3 Sonnet",
            "provider": "Anthropic",
            "max_tokens": 4096,
            "strengths": ["Análise de código", "Raciocínio complexo", "Português"],
            "cost_tier": "medium"
        },
        "anthropic.claude-3-haiku-20240307-v1:0": {
            "name": "Claude 3 Haiku",
            "provider": "Anthropic", 
            "max_tokens": 4096,
            "strengths": ["Velocidade", "Eficiência", "Análise rápida"],
            "cost_tier": "low"
        },
        "anthropic.claude-v2:1": {
            "name": "Claude 2.1",
            "provider": "Anthropic",
            "max_tokens": 4096,
            "strengths": ["Análise detalhada", "Contexto longo"],
            "cost_tier": "medium"
        },
        "meta.llama2-70b-chat-v1": {
            "name": "Llama 2 70B Chat",
            "provider": "Meta",
            "max_tokens": 2048,
            "strengths": ["Open source", "Análise técnica"],
            "cost_tier": "medium"
        },
        "amazon.titan-text-express-v1": {
            "name": "Titan Text Express",
            "provider": "Amazon",
            "max_tokens": 8192,
            "strengths": ["Contexto longo", "Custo baixo"],
            "cost_tier": "low"
        }
    }
    
    @classmethod
    def get_available_models(cls) -> Dict[str, Dict[str, Any]]:
        """Retornar modelos disponíveis"""
        return cls.SUPPORTED_MODELS
    
    @classmethod
    def get_recommended_model(cls, use_case: str = "general") -> str:
        """
        Recomendar modelo baseado no caso de uso
        
        Args:
            use_case: Caso de uso (general, fast, detailed, cost_effective)
            
        Returns:
            ID do modelo recomendado
        """
        if use_case == "fast":
            return "anthropic.claude-3-haiku-20240307-v1:0"
        elif use_case == "detailed":
            return "anthropic.claude-3-sonnet-20240229-v1:0"
        elif use_case == "cost_effective":
            return "amazon.titan-text-express-v1"
        else:
            return "anthropic.claude-3-sonnet-20240229-v1:0"
    
    @classmethod
    def validate_model(cls, model_id: str) -> bool:
        """Validar se modelo é suportado"""
        return model_id in cls.SUPPORTED_MODELS
    
    @classmethod
    def get_model_info(cls, model_id: str) -> Optional[Dict[str, Any]]:
        """Obter informações do modelo"""
        return cls.SUPPORTED_MODELS.get(model_id)


def create_bedrock_analyzer(config: Dict[str, Any]) -> BedrockAnalyzer:
    """
    Factory function para criar analisador Bedrock
    
    Args:
        config: Configuração com credenciais e parâmetros
        
    Returns:
        Instância do BedrockAnalyzer
    """
    model_id = config.get('model_id', BedrockModelManager.get_recommended_model())
    region_name = config.get('region_name', 'us-east-1')
    
    # Validar modelo
    if not BedrockModelManager.validate_model(model_id):
        raise ValueError(f"Modelo não suportado: {model_id}")
    
    return BedrockAnalyzer(
        model_id=model_id,
        region_name=region_name,
        aws_access_key_id=config.get('aws_access_key_id'),
        aws_secret_access_key=config.get('aws_secret_access_key')
    )

