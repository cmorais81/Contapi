"""
Formatador específico para análise funcional
"""

from typing import Dict, Any


class FunctionalFormatter:
    """
    Formatador para resultados de análise funcional
    """
    
    @staticmethod
    def format_markdown(data: Dict[str, Any]) -> str:
        """
        Formata resultado da análise funcional em Markdown
        """
        md_content = []
        
        # Seção de Análise Funcional
        md_content.append("## Análise Funcional")
        md_content.append("")
        
        # Propósito do Sistema
        if 'system_purpose' in data:
            md_content.append("### Propósito do Sistema")
            md_content.append(f"**Objetivo Principal**: {data['system_purpose']}")
            md_content.append("")
        
        # Descrição Funcional
        if 'functional_description' in data:
            md_content.append("### O Que o Programa Faz")
            md_content.append(data['functional_description'])
            md_content.append("")
        
        # Tipo de Programa
        if 'program_type' in data:
            prog_type = data['program_type']
            md_content.append("### Classificação do Programa")
            md_content.append(f"- **Tipo Principal**: {prog_type['primary_type'].title()}")
            md_content.append(f"- **Confiança**: {prog_type['confidence']:.1%}")
            
            if prog_type.get('all_types'):
                md_content.append("- **Características Identificadas**:")
                for ptype, info in prog_type['all_types'].items():
                    md_content.append(f"  - {ptype.title()}: {info['score']} ocorrências")
            md_content.append("")
        
        # Operações Principais
        if 'main_operations' in data and data['main_operations']:
            md_content.append("### Operações Principais")
            for op in data['main_operations'][:5]:  # Top 5
                md_content.append(f"- **{op['operation'].title()}**: {op['frequency']} ocorrências")
                if op.get('examples'):
                    examples = ', '.join(op['examples'][:3])
                    md_content.append(f"  - Exemplos: {examples}")
            md_content.append("")
        
        # Entidades de Negócio
        if 'business_entities' in data and data['business_entities']:
            md_content.append("### Entidades de Negócio")
            for entity in data['business_entities'][:5]:
                md_content.append(f"- **{entity['entity'].title()}**: {entity['frequency']} referências")
            md_content.append("")
        
        # Regras de Negócio
        if 'business_rules' in data and data['business_rules']:
            md_content.append("### Regras de Negócio Identificadas")
            for rule in data['business_rules']:
                md_content.append(f"- **{rule['rule']}**: {rule['occurrences']} ocorrência(s)")
            md_content.append("")
        
        # Análise de Arquivos
        if 'file_analysis' in data:
            file_analysis = data['file_analysis']
            md_content.append("### Análise de Arquivos")
            md_content.append(f"- **Total de Arquivos**: {file_analysis['total_files']}")
            
            if file_analysis['input_files']:
                md_content.append(f"- **Arquivos de Entrada**: {len(file_analysis['input_files'])}")
                for file_info in file_analysis['input_files']:
                    md_content.append(f"  - {file_info['name']} ({file_info['organization']})")
            
            if file_analysis['output_files']:
                md_content.append(f"- **Arquivos de Saída**: {len(file_analysis['output_files'])}")
                for file_info in file_analysis['output_files']:
                    md_content.append(f"  - {file_info['name']} ({file_info['organization']})")
            
            if file_analysis['database_files']:
                md_content.append(f"- **Arquivos de Banco**: {len(file_analysis['database_files'])}")
                for file_info in file_analysis['database_files']:
                    md_content.append(f"  - {file_info['name']} (Acesso: {file_info['access_mode']})")
            
            md_content.append("")
        
        # Fluxo de Processamento
        if 'process_flow' in data:
            flow = data['process_flow']
            md_content.append("### Fluxo de Processamento")
            md_content.append(f"- **Padrão Principal**: {flow['main_pattern']}")
            md_content.append(f"- **Complexidade de Fluxo**: {flow['complexity']}")
            
            if flow.get('estimated_steps'):
                md_content.append("- **Etapas do Processamento**:")
                for step in flow['estimated_steps']:
                    md_content.append(f"  1. {step}")
            md_content.append("")
        
        # Análise de Complexidade
        if 'complexity_assessment' in data:
            complexity = data['complexity_assessment']
            md_content.append("### Avaliação de Complexidade")
            md_content.append(f"- **Nível**: {complexity['level']}")
            md_content.append(f"- **Pontuação**: {complexity['score']:.1f}")
            
            metrics = complexity['metrics']
            md_content.append("- **Métricas Detalhadas**:")
            md_content.append(f"  - Linhas de código: {metrics['lines_of_code']}")
            md_content.append(f"  - Variáveis: {metrics['variables']}")
            md_content.append(f"  - Estruturas condicionais: {metrics['conditional_statements']}")
            md_content.append(f"  - Loops: {metrics['loops']}")
            md_content.append(f"  - Cálculos: {metrics['calculations']}")
            md_content.append("")
        
        # Pontos de Integração
        if 'integration_points' in data and data['integration_points']:
            md_content.append("### Pontos de Integração")
            for integration in data['integration_points']:
                md_content.append(f"- **{integration['type']}**: {integration['count']} ocorrência(s)")
                if integration.get('examples'):
                    examples = ', '.join(integration['examples'])
                    md_content.append(f"  - Exemplos: {examples}")
            md_content.append("")
        
        # Fluxo de Dados
        if 'data_flow' in data:
            data_flow = data['data_flow']
            md_content.append("### Análise de Fluxo de Dados")
            md_content.append(f"- **Padrão de Fluxo**: {data_flow['pattern']}")
            md_content.append(f"- **Operações de Entrada**: {data_flow['input_operations']}")
            md_content.append(f"- **Operações de Saída**: {data_flow['output_operations']}")
            md_content.append(f"- **Movimentações de Dados**: {data_flow['data_movements']}")
            md_content.append(f"- **Transformações**: {data_flow['transformations']}")
            md_content.append("")
        
        return "\n".join(md_content)
    
    @staticmethod
    def format_json(data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Formata resultado da análise funcional em JSON
        """
        return {
            "functional_analysis": data
        }
    
    @staticmethod
    def format_yaml(data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Formata resultado da análise funcional em YAML
        """
        return {
            "functional_analysis": data
        }

