"""
Formatters following SOLID principles.
"""

import json
import yaml
from typing import Dict, Any
from ..interfaces.formatter import IFormatter, IReportGenerator
from ..core.models import AnalysisResult, BatchResult
from .exceptions import FormatterError


class JsonFormatter(IFormatter):
    """JSON formatter implementation."""
    
    @property
    def format_name(self) -> str:
        return "json"
    
    @property
    def file_extension(self) -> str:
        return ".json"
    
    def format_single_result(self, result: AnalysisResult) -> str:
        """Format single result as JSON."""
        try:
            data = {
                'analyzer_name': result.analyzer_name,
                'program_id': result.program_id,
                'success': result.success,
                'execution_time': result.execution_time,
                'data': result.data,
                'errors': result.errors,
                'warnings': result.warnings
            }
            return json.dumps(data, indent=2, ensure_ascii=False, default=str)
        except Exception as e:
            raise FormatterError(f"JSON formatting failed: {e}")
    
    def format_batch_result(self, batch_result: BatchResult) -> str:
        """Format batch result as JSON."""
        try:
            data = {
                'total_files': batch_result.total_files,
                'processed_files': batch_result.processed_files,
                'failed_files': batch_result.failed_files,
                'total_lines': batch_result.total_lines,
                'processing_time': batch_result.processing_time,
                'success_rate': batch_result.get_success_rate(),
                'files_per_minute': batch_result.get_files_per_minute(),
                'consolidated_metrics': batch_result.consolidated_metrics,
                'results': {
                    path: {
                        'success': result.success,
                        'program_id': result.program_id,
                        'execution_time': result.execution_time,
                        'errors': result.errors,
                        'warnings': result.warnings
                    }
                    for path, result in batch_result.results.items()
                }
            }
            return json.dumps(data, indent=2, ensure_ascii=False, default=str)
        except Exception as e:
            raise FormatterError(f"JSON batch formatting failed: {e}")


class YamlFormatter(IFormatter):
    """YAML formatter implementation."""
    
    @property
    def format_name(self) -> str:
        return "yaml"
    
    @property
    def file_extension(self) -> str:
        return ".yaml"
    
    def format_single_result(self, result: AnalysisResult) -> str:
        """Format single result as YAML."""
        try:
            data = {
                'analyzer_name': result.analyzer_name,
                'program_id': result.program_id,
                'success': result.success,
                'execution_time': result.execution_time,
                'data': result.data,
                'errors': result.errors,
                'warnings': result.warnings
            }
            return yaml.dump(data, default_flow_style=False, allow_unicode=True)
        except Exception as e:
            raise FormatterError(f"YAML formatting failed: {e}")
    
    def format_batch_result(self, batch_result: BatchResult) -> str:
        """Format batch result as YAML."""
        try:
            data = {
                'summary': {
                    'total_files': batch_result.total_files,
                    'processed_files': batch_result.processed_files,
                    'failed_files': batch_result.failed_files,
                    'total_lines': batch_result.total_lines,
                    'processing_time': batch_result.processing_time,
                    'success_rate': batch_result.get_success_rate(),
                    'files_per_minute': batch_result.get_files_per_minute()
                },
                'consolidated_metrics': batch_result.consolidated_metrics,
                'file_results': {
                    path: {
                        'success': result.success,
                        'program_id': result.program_id,
                        'execution_time': result.execution_time
                    }
                    for path, result in batch_result.results.items()
                }
            }
            return yaml.dump(data, default_flow_style=False, allow_unicode=True)
        except Exception as e:
            raise FormatterError(f"YAML batch formatting failed: {e}")


class MarkdownFormatter(IFormatter, IReportGenerator):
    """Markdown formatter implementation."""
    
    @property
    def format_name(self) -> str:
        return "markdown"
    
    @property
    def file_extension(self) -> str:
        return ".md"
    
    def format_single_result(self, result: AnalysisResult) -> str:
        """Format single result as Markdown."""
        try:
            lines = []
            lines.append(f"# Analysis Report - {result.program_id}")
            lines.append("")
            
            # Basic information
            lines.append("## Basic Information")
            lines.append("")
            lines.append(f"- **Program ID**: {result.program_id}")
            lines.append(f"- **Analyzer**: {result.analyzer_name}")
            lines.append(f"- **Success**: {'✅' if result.success else '❌'}")
            lines.append(f"- **Execution Time**: {result.execution_time:.2f}s")
            lines.append("")
            
            # Program info
            if 'program_info' in result.data:
                info = result.data['program_info']
                lines.append("## Program Information")
                lines.append("")
                lines.append(f"- **File Path**: {info.get('file_path', 'N/A')}")
                lines.append(f"- **Author**: {info.get('author', 'N/A')}")
                lines.append(f"- **Date Written**: {info.get('date_written', 'N/A')}")
                lines.append(f"- **Lines of Code**: {info.get('lines_of_code', 0):,}")
                lines.append(f"- **Variables**: {info.get('variables_count', 0)}")
                lines.append(f"- **Sections**: {info.get('sections_count', 0)}")
                lines.append(f"- **Paragraphs**: {info.get('paragraphs_count', 0)}")
                lines.append(f"- **Total Complexity**: {info.get('total_complexity', 0)}")
                lines.append("")
            
            # Analyzer results
            if 'analyzer_results' in result.data:
                lines.append("## Analysis Results")
                lines.append("")
                
                for analyzer_name, analyzer_data in result.data['analyzer_results'].items():
                    lines.append(f"### {analyzer_name.replace('_', ' ').title()}")
                    lines.append("")
                    
                    # Security analyzer
                    if analyzer_name == 'security_analyzer':
                        score = analyzer_data.get('security_score', 0)
                        lines.append(f"- **Security Score**: {score}/100")
                        lines.append(f"- **Issues Found**: {len(analyzer_data.get('issues', []))}")
                        lines.append(f"- **Compliance Status**: {analyzer_data.get('compliance_status', 'Unknown')}")
                    
                    # Performance analyzer
                    elif analyzer_name == 'performance_analyzer':
                        score = analyzer_data.get('performance_score', 0)
                        lines.append(f"- **Performance Score**: {score}/100")
                        lines.append(f"- **Complexity**: {analyzer_data.get('complexity', 'Unknown')}")
                        lines.append(f"- **Issues Found**: {len(analyzer_data.get('issues', []))}")
                    
                    # Functional analyzer
                    elif analyzer_name == 'functional_analyzer':
                        from .functional_formatter import FunctionalFormatter
                        functional_content = FunctionalFormatter.format_markdown(analyzer_data)
                        lines.append(functional_content)
                    
                    lines.append("")
            
            # Errors and warnings
            if result.errors:
                lines.append("## Errors")
                lines.append("")
                for error in result.errors:
                    lines.append(f"- ❌ {error}")
                lines.append("")
            
            if result.warnings:
                lines.append("## Warnings")
                lines.append("")
                for warning in result.warnings:
                    lines.append(f"- ⚠️ {warning}")
                lines.append("")
            
            return "\n".join(lines)
            
        except Exception as e:
            raise FormatterError(f"Markdown formatting failed: {e}")
    
    def format_batch_result(self, batch_result: BatchResult) -> str:
        """Format batch result as Markdown."""
        try:
            lines = []
            lines.append("# Batch Analysis Report")
            lines.append("")
            
            # Summary statistics
            lines.append("## Summary Statistics")
            lines.append("")
            lines.append(f"- **Total Files**: {batch_result.total_files}")
            lines.append(f"- **Processed Successfully**: {batch_result.processed_files}")
            lines.append(f"- **Failed**: {batch_result.failed_files}")
            lines.append(f"- **Success Rate**: {batch_result.get_success_rate():.1f}%")
            lines.append(f"- **Total Lines of Code**: {batch_result.total_lines:,}")
            lines.append(f"- **Processing Time**: {batch_result.processing_time:.2f}s")
            lines.append(f"- **Processing Speed**: {batch_result.get_files_per_minute():.1f} files/min")
            lines.append("")
            
            # Consolidated metrics
            if batch_result.consolidated_metrics:
                metrics = batch_result.consolidated_metrics
                lines.append("## Consolidated Metrics")
                lines.append("")
                
                if 'average_security_score' in metrics:
                    lines.append("### Security Analysis")
                    lines.append("")
                    lines.append(f"- **Average Security Score**: {metrics['average_security_score']:.1f}/100")
                    lines.append(f"- **Best Score**: {metrics['max_security_score']}/100")
                    lines.append(f"- **Worst Score**: {metrics['min_security_score']}/100")
                    lines.append(f"- **Programs Analyzed**: {metrics['security_analysis_count']}")
                    lines.append("")
                
                if 'average_performance_score' in metrics:
                    lines.append("### Performance Analysis")
                    lines.append("")
                    lines.append(f"- **Average Performance Score**: {metrics['average_performance_score']:.1f}/100")
                    lines.append(f"- **Best Score**: {metrics['max_performance_score']}/100")
                    lines.append(f"- **Worst Score**: {metrics['min_performance_score']}/100")
                    lines.append(f"- **Programs Analyzed**: {metrics['performance_analysis_count']}")
                    lines.append("")
                
                lines.append("### Code Metrics")
                lines.append("")
                lines.append(f"- **Total Complexity**: {metrics.get('total_complexity', 0)}")
                lines.append(f"- **Average Complexity**: {metrics.get('average_complexity', 0):.1f}")
                lines.append(f"- **Total Variables**: {metrics.get('total_variables', 0)}")
                lines.append(f"- **Average Variables**: {metrics.get('average_variables', 0):.1f}")
                lines.append("")
            
            # File results table
            lines.append("## File Results")
            lines.append("")
            lines.append("| File | Status | Program ID | Lines | Time |")
            lines.append("|------|--------|------------|-------|------|")
            
            for file_path, result in batch_result.results.items():
                file_name = file_path.split('/')[-1] if '/' in file_path else file_path
                status = "✅ Success" if result.success else "❌ Failed"
                program_id = result.program_id
                
                lines_count = 0
                if result.success and 'program_info' in result.data:
                    lines_count = result.data['program_info'].get('lines_of_code', 0)
                
                time_str = f"{result.execution_time:.2f}s"
                
                lines.append(f"| {file_name} | {status} | {program_id} | {lines_count} | {time_str} |")
            
            lines.append("")
            
            # Recommendations
            lines.append("## Recommendations")
            lines.append("")
            
            if batch_result.failed_files > 0:
                lines.append(f"- **Quality**: {batch_result.failed_files} files failed processing. Review syntax and structure.")
            
            if batch_result.consolidated_metrics:
                metrics = batch_result.consolidated_metrics
                
                if 'average_security_score' in metrics and metrics['average_security_score'] < 80:
                    lines.append("- **Security**: Portfolio shows security vulnerabilities. Review security analysis results.")
                
                if 'average_performance_score' in metrics and metrics['average_performance_score'] < 80:
                    lines.append("- **Performance**: Performance optimization opportunities identified. Review complexity and bottlenecks.")
            
            lines.append("")
            lines.append("---")
            lines.append("")
            lines.append(f"*Report generated by COBOL Documentation Engine*")
            
            return "\n".join(lines)
            
        except Exception as e:
            raise FormatterError(f"Markdown batch formatting failed: {e}")
    
    def generate_summary_report(self, results: Dict[str, AnalysisResult]) -> str:
        """Generate summary report from multiple results."""
        # Create a mock batch result for formatting
        batch_result = BatchResult(
            total_files=len(results),
            processed_files=sum(1 for r in results.values() if r.success),
            failed_files=sum(1 for r in results.values() if not r.success),
            total_lines=0,
            processing_time=sum(r.execution_time for r in results.values())
        )
        
        for path, result in results.items():
            batch_result.add_result(path, result)
        
        return self.format_batch_result(batch_result)
    
    def generate_detailed_report(self, result: AnalysisResult) -> str:
        """Generate detailed report from single result."""
        return self.format_single_result(result)


class FormatterRegistry:
    """
    Registry for formatters following Registry pattern.
    """
    
    def __init__(self):
        self._formatters: Dict[str, IFormatter] = {}
        self._register_default_formatters()
    
    def _register_default_formatters(self):
        """Register default formatters."""
        self.register_formatter(JsonFormatter())
        self.register_formatter(YamlFormatter())
        self.register_formatter(MarkdownFormatter())
    
    def register_formatter(self, formatter: IFormatter):
        """Register a formatter."""
        self._formatters[formatter.format_name] = formatter
    
    def get_formatter(self, format_name: str) -> IFormatter:
        """Get formatter by name."""
        return self._formatters.get(format_name)
    
    def get_formatter_names(self) -> list:
        """Get list of available formatter names."""
        return list(self._formatters.keys())

