"""
Processador para arquivos TXT contendo múltiplos programas COBOL
"""

import re
import tempfile
import os
from typing import List, Dict, Tuple, Optional
from pathlib import Path


class CobolTxtProcessor:
    """
    Processador para arquivos TXT que contêm múltiplos programas COBOL
    """
    
    def __init__(self):
        self.program_separators = [
            r'^\s*IDENTIFICATION\s+DIVISION\s*\.',
            r'^\s*ID\s+DIVISION\s*\.',
            r'^\s*PROGRAM-ID\s*\.',
            r'^\s*\*{5,}.*PROGRAMA.*\*{5,}',
            r'^\s*\*{5,}.*PROGRAM.*\*{5,}',
            r'^\s*/\*.*PROGRAMA.*\*/',
            r'^\s*\d{6}\s+IDENTIFICATION\s+DIVISION',
            r'^\s*\d{6}\s+ID\s+DIVISION'
        ]
        
        self.copybook_patterns = [
            r'^\s*COPY\s+',
            r'^\s*\d{6}\s+COPY\s+',
            r'^\s*01\s+[A-Z0-9-]+',
            r'^\s*\d{6}\s+01\s+[A-Z0-9-]+',
            r'^\s*\*.*COPYBOOK.*',
            r'^\s*\*.*LAYOUT.*',
            r'^\s*\*.*BOOK.*'
        ]

    def process_txt_file(self, file_path: str) -> List[Dict[str, str]]:
        """
        Processa arquivo TXT e extrai programas COBOL individuais
        
        Args:
            file_path: Caminho para o arquivo TXT
            
        Returns:
            Lista de dicionários com informações dos programas extraídos
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except UnicodeDecodeError:
            # Tentar outras codificações comuns
            encodings = ['latin-1', 'cp1252', 'iso-8859-1']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    break
                except UnicodeDecodeError:
                    continue
            else:
                raise Exception(f"Não foi possível decodificar o arquivo {file_path}")
        
        # Determinar tipo de arquivo
        file_type = self._identify_file_type(content)
        
        if file_type == 'programs':
            return self._extract_programs(content, file_path)
        elif file_type == 'copybooks':
            return self._extract_copybooks(content, file_path)
        else:
            # Arquivo único
            return self._extract_single_program(content, file_path)

    def _identify_file_type(self, content: str) -> str:
        """
        Identifica o tipo de arquivo baseado no conteúdo
        """
        lines = content.split('\n')
        
        # Contar ocorrências de padrões
        program_count = 0
        copybook_count = 0
        
        for line in lines[:100]:  # Analisar primeiras 100 linhas
            line_upper = line.upper()
            
            # Verificar padrões de programa
            for pattern in self.program_separators:
                if re.search(pattern, line_upper):
                    program_count += 1
                    break
            
            # Verificar padrões de copybook
            for pattern in self.copybook_patterns:
                if re.search(pattern, line_upper):
                    copybook_count += 1
                    break
        
        if program_count >= 2:
            return 'programs'
        elif copybook_count > program_count:
            return 'copybooks'
        else:
            return 'single'

    def _extract_programs(self, content: str, source_file: str) -> List[Dict[str, str]]:
        """
        Extrai múltiplos programas de um arquivo TXT
        """
        programs = []
        lines = content.split('\n')
        current_program = []
        current_program_id = None
        program_counter = 1
        
        for i, line in enumerate(lines):
            line_upper = line.upper()
            
            # Verificar se é início de novo programa
            is_new_program = False
            for pattern in self.program_separators:
                if re.search(pattern, line_upper):
                    is_new_program = True
                    break
            
            if is_new_program and current_program:
                # Salvar programa anterior
                program_id = current_program_id or f"PROGRAMA-{program_counter:02d}"
                programs.append({
                    'program_id': program_id,
                    'content': '\n'.join(current_program),
                    'source_file': source_file,
                    'start_line': i - len(current_program) + 1,
                    'end_line': i,
                    'lines_count': len(current_program)
                })
                current_program = []
                program_counter += 1
            
            current_program.append(line)
            
            # Extrair PROGRAM-ID se encontrado
            if 'PROGRAM-ID' in line_upper:
                match = re.search(r'PROGRAM-ID\s*\.\s*([A-Z0-9-]+)', line_upper)
                if match:
                    current_program_id = match.group(1)
        
        # Adicionar último programa
        if current_program:
            program_id = current_program_id or f"PROGRAMA-{program_counter:02d}"
            programs.append({
                'program_id': program_id,
                'content': '\n'.join(current_program),
                'source_file': source_file,
                'start_line': len(lines) - len(current_program) + 1,
                'end_line': len(lines),
                'lines_count': len(current_program)
            })
        
        return programs

    def _extract_copybooks(self, content: str, source_file: str) -> List[Dict[str, str]]:
        """
        Extrai copybooks/layouts de um arquivo TXT
        """
        copybooks = []
        lines = content.split('\n')
        current_copybook = []
        current_copybook_name = None
        copybook_counter = 1
        
        for i, line in enumerate(lines):
            line_upper = line.upper()
            
            # Verificar se é início de novo copybook
            is_new_copybook = False
            
            # Padrão de comentário indicando novo copybook
            if re.search(r'^\s*\*.*(?:COPYBOOK|LAYOUT|BOOK).*', line_upper):
                is_new_copybook = True
                # Extrair nome do copybook do comentário
                match = re.search(r'(?:COPYBOOK|LAYOUT|BOOK)\s*:?\s*([A-Z0-9-]+)', line_upper)
                if match:
                    current_copybook_name = match.group(1)
            
            # Padrão de 01 level indicando nova estrutura
            elif re.search(r'^\s*(?:\d{6}\s+)?01\s+([A-Z0-9-]+)', line):
                if current_copybook and len(current_copybook) > 5:  # Só considera novo se já tem conteúdo
                    is_new_copybook = True
                match = re.search(r'^\s*(?:\d{6}\s+)?01\s+([A-Z0-9-]+)', line)
                if match:
                    current_copybook_name = match.group(1)
            
            if is_new_copybook and current_copybook:
                # Salvar copybook anterior
                copybook_name = current_copybook_name or f"COPYBOOK-{copybook_counter:02d}"
                copybooks.append({
                    'program_id': copybook_name,
                    'content': '\n'.join(current_copybook),
                    'source_file': source_file,
                    'start_line': i - len(current_copybook) + 1,
                    'end_line': i,
                    'lines_count': len(current_copybook),
                    'type': 'copybook'
                })
                current_copybook = []
                copybook_counter += 1
            
            current_copybook.append(line)
        
        # Adicionar último copybook
        if current_copybook:
            copybook_name = current_copybook_name or f"COPYBOOK-{copybook_counter:02d}"
            copybooks.append({
                'program_id': copybook_name,
                'content': '\n'.join(current_copybook),
                'source_file': source_file,
                'start_line': len(lines) - len(current_copybook) + 1,
                'end_line': len(lines),
                'lines_count': len(current_copybook),
                'type': 'copybook'
            })
        
        return copybooks

    def _extract_single_program(self, content: str, source_file: str) -> List[Dict[str, str]]:
        """
        Trata arquivo como programa único
        """
        # Extrair PROGRAM-ID se existir
        program_id = "PROGRAMA-UNICO"
        lines = content.split('\n')
        
        for line in lines[:50]:  # Procurar nas primeiras 50 linhas
            line_upper = line.upper()
            if 'PROGRAM-ID' in line_upper:
                match = re.search(r'PROGRAM-ID\s*\.\s*([A-Z0-9-]+)', line_upper)
                if match:
                    program_id = match.group(1)
                    break
        
        return [{
            'program_id': program_id,
            'content': content,
            'source_file': source_file,
            'start_line': 1,
            'end_line': len(lines),
            'lines_count': len(lines)
        }]

    def create_temp_files(self, programs: List[Dict[str, str]]) -> List[str]:
        """
        Cria arquivos temporários para cada programa extraído
        
        Args:
            programs: Lista de programas extraídos
            
        Returns:
            Lista de caminhos para arquivos temporários criados
        """
        temp_files = []
        
        for program in programs:
            # Criar arquivo temporário
            temp_fd, temp_path = tempfile.mkstemp(
                suffix='.cbl',
                prefix=f"{program['program_id']}_",
                text=True
            )
            
            try:
                with os.fdopen(temp_fd, 'w', encoding='utf-8') as temp_file:
                    temp_file.write(program['content'])
                
                temp_files.append(temp_path)
                
            except Exception as e:
                os.close(temp_fd)
                if os.path.exists(temp_path):
                    os.unlink(temp_path)
                raise Exception(f"Erro ao criar arquivo temporário: {e}")
        
        return temp_files

    def cleanup_temp_files(self, temp_files: List[str]):
        """
        Remove arquivos temporários criados
        """
        for temp_file in temp_files:
            try:
                if os.path.exists(temp_file):
                    os.unlink(temp_file)
            except Exception:
                pass  # Ignorar erros de limpeza

    def get_program_summary(self, programs: List[Dict[str, str]]) -> Dict[str, any]:
        """
        Gera resumo dos programas extraídos
        """
        total_lines = sum(prog['lines_count'] for prog in programs)
        
        # Classificar por tipo
        program_types = {}
        for prog in programs:
            prog_type = prog.get('type', 'program')
            if prog_type not in program_types:
                program_types[prog_type] = 0
            program_types[prog_type] += 1
        
        return {
            'total_programs': len(programs),
            'total_lines': total_lines,
            'average_lines': total_lines / len(programs) if programs else 0,
            'program_types': program_types,
            'programs': [
                {
                    'id': prog['program_id'],
                    'lines': prog['lines_count'],
                    'type': prog.get('type', 'program')
                }
                for prog in programs
            ]
        }


class TxtFileValidator:
    """
    Validador para arquivos TXT com código COBOL
    """
    
    @staticmethod
    def is_cobol_txt_file(file_path: str) -> bool:
        """
        Verifica se arquivo TXT contém código COBOL
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(2000)  # Ler primeiros 2KB
        except:
            return False
        
        content_upper = content.upper()
        
        # Padrões que indicam código COBOL
        cobol_indicators = [
            'IDENTIFICATION DIVISION',
            'ID DIVISION',
            'PROGRAM-ID',
            'ENVIRONMENT DIVISION',
            'DATA DIVISION',
            'PROCEDURE DIVISION',
            'WORKING-STORAGE SECTION',
            'FILE SECTION',
            'LINKAGE SECTION',
            'PERFORM',
            'MOVE',
            'ACCEPT',
            'DISPLAY',
            'COMPUTE',
            'IF',
            'ELSE',
            'END-IF',
            'EVALUATE',
            'WHEN',
            'END-EVALUATE'
        ]
        
        # Contar ocorrências
        matches = sum(1 for indicator in cobol_indicators if indicator in content_upper)
        
        # Considerar COBOL se encontrar pelo menos 3 indicadores
        return matches >= 3
    
    @staticmethod
    def validate_extracted_program(content: str) -> Dict[str, any]:
        """
        Valida se programa extraído é válido
        """
        lines = content.split('\n')
        non_empty_lines = [line for line in lines if line.strip()]
        
        # Verificações básicas
        has_identification = any('IDENTIFICATION' in line.upper() or 'ID DIVISION' in line.upper() 
                               for line in lines[:20])
        has_program_id = any('PROGRAM-ID' in line.upper() for line in lines[:30])
        has_procedure = any('PROCEDURE DIVISION' in line.upper() for line in lines)
        
        # Calcular score de qualidade
        quality_score = 0
        if has_identification:
            quality_score += 30
        if has_program_id:
            quality_score += 30
        if has_procedure:
            quality_score += 40
        
        return {
            'is_valid': quality_score >= 60,
            'quality_score': quality_score,
            'total_lines': len(lines),
            'non_empty_lines': len(non_empty_lines),
            'has_identification': has_identification,
            'has_program_id': has_program_id,
            'has_procedure': has_procedure,
            'warnings': []
        }

