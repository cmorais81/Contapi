"""
Interfaces module following Interface Segregation Principle (ISP).
Defines contracts for different components.
"""

from .analyzer import IAnalyzer
from .parser import IParser
from .formatter import IFormatter
from .processor import IProcessor

__all__ = [
    'IAnalyzer',
    'IParser', 
    'IFormatter',
    'IProcessor'
]

