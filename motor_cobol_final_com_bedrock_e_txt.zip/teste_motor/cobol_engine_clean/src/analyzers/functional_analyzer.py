"""
Analisador Funcional - Explica o que o programa COBOL faz e para que serve
"""

import re
from typing import Dict, List, Any, Optional
from ..interfaces.analyzer import IAnalyzer
from ..core.models import CobolProgram, AnalysisResult


class FunctionalAnalyzer(IAnalyzer):
    """
    Analisador que identifica a funcionalidade e propósito do programa COBOL
    """
    
    def __init__(self):
        self._name = "functional_analyzer"
        self.description = "Analisa a funcionalidade e propósito do programa COBOL"
        
        # Padrões para identificar tipos de programa
        self.program_patterns = {
            'financial': [
                r'juros|taxa|financ|banco|conta|saldo|credito|debito|emprestimo',
                r'pagamento|cobranca|fatura|parcela|amortizacao|capitalizacao'
            ],
            'customer': [
                r'cliente|customer|cadastro|pessoa|cpf|cnpj|endereco|telefone',
                r'contato|email|dados.pessoais|registro.cliente'
            ],
            'inventory': [
                r'estoque|produto|item|mercadoria|almoxarifado|deposito',
                r'entrada|saida|movimentacao|inventario|lote|serial'
            ],
            'payroll': [
                r'folha|salario|funcionario|empregado|desconto|beneficio',
                r'inss|irrf|fgts|vale|adiantamento|ferias|decimo'
            ],
            'accounting': [
                r'contabil|razao|diario|balancete|balanco|plano.contas',
                r'debito|credito|lancamento|partida|demonstrativo'
            ],
            'reporting': [
                r'relatorio|report|listagem|impressao|consulta|extrato',
                r'demonstrativo|resumo|totalizacao|estatistica'
            ],
            'batch': [
                r'lote|batch|processamento|job|noturno|diario|mensal',
                r'carga|importacao|exportacao|interface|integracao'
            ],
            'maintenance': [
                r'manutencao|atualizacao|correcao|ajuste|reorganizacao',
                r'backup|restore|reindex|rebuild|cleanup'
            ]
        }
        
        # Padrões para identificar operações
        self.operation_patterns = {
            'create': [r'incluir|inserir|criar|adicionar|gravar|write'],
            'read': [r'consultar|ler|buscar|pesquisar|localizar|read'],
            'update': [r'alterar|atualizar|modificar|corrigir|rewrite'],
            'delete': [r'excluir|deletar|remover|eliminar|delete'],
            'calculate': [r'calcular|computar|somar|totalizar|compute'],
            'validate': [r'validar|verificar|checar|conferir|criticar'],
            'process': [r'processar|executar|rodar|efetuar|realizar'],
            'generate': [r'gerar|produzir|criar|emitir|formar'],
            'import': [r'importar|carregar|ler|receber|input'],
            'export': [r'exportar|gravar|escrever|enviar|output']
        }
        
        # Padrões para identificar entidades de negócio
        self.entity_patterns = {
            'account': [r'conta|account|saldo|limite'],
            'customer': [r'cliente|customer|pessoa|titular'],
            'transaction': [r'transacao|movimento|operacao|lancamento'],
            'product': [r'produto|item|mercadoria|servico'],
            'employee': [r'funcionario|empregado|colaborador|pessoa'],
            'invoice': [r'fatura|nota|documento|titulo'],
            'payment': [r'pagamento|recebimento|quitacao|liquidacao'],
            'report': [r'relatorio|listagem|demonstrativo|extrato']
        }

    def analyze(self, program: CobolProgram) -> AnalysisResult:
        """
        Analisa a funcionalidade do programa COBOL
        """
        try:
            # Análise do conteúdo do programa
            content = program.content.lower()
            
            # Identificar tipo de programa
            program_type = self._identify_program_type(content)
            
            # Identificar operações principais
            main_operations = self._identify_operations(content)
            
            # Identificar entidades de negócio
            business_entities = self._identify_entities(content)
            
            # Analisar estrutura de arquivos
            file_analysis = self._analyze_files(program)
            
            # Analisar fluxo de processamento
            process_flow = self._analyze_process_flow(program)
            
            # Identificar regras de negócio
            business_rules = self._identify_business_rules(content)
            
            # Gerar descrição funcional
            functional_description = self._generate_functional_description(
                program_type, main_operations, business_entities, file_analysis
            )
            
            # Gerar descrição técnica
            technical_description = self._generate_technical_description(
                program, file_analysis, process_flow
            )
            
            # Identificar propósito do sistema
            system_purpose = self._identify_system_purpose(
                program_type, main_operations, business_entities
            )
            
            result_data = {
                'program_type': program_type,
                'system_purpose': system_purpose,
                'functional_description': functional_description,
                'technical_description': technical_description,
                'main_operations': main_operations,
                'business_entities': business_entities,
                'business_rules': business_rules,
                'file_analysis': file_analysis,
                'process_flow': process_flow,
                'complexity_assessment': self._assess_complexity(program),
                'integration_points': self._identify_integration_points(content),
                'data_flow': self._analyze_data_flow(program)
            }
            
            return AnalysisResult(
                analyzer_name=self._name,
                program_id=program.program_id,
                success=True,
                data=result_data
            )
            
        except Exception as e:
            result = AnalysisResult(
                analyzer_name=self._name,
                program_id=program.program_id,
                success=False
            )
            result.add_error(str(e))
            return result

    def _identify_program_type(self, content: str) -> Dict[str, Any]:
        """Identifica o tipo de programa baseado no conteúdo"""
        scores = {}
        
        for prog_type, patterns in self.program_patterns.items():
            score = 0
            matches = []
            
            for pattern in patterns:
                found = re.findall(pattern, content)
                score += len(found)
                matches.extend(found)
            
            if score > 0:
                scores[prog_type] = {
                    'score': score,
                    'matches': list(set(matches))
                }
        
        # Determinar tipo principal
        if scores:
            primary_type = max(scores.keys(), key=lambda k: scores[k]['score'])
            confidence = min(scores[primary_type]['score'] / 10.0, 1.0)
        else:
            primary_type = 'generic'
            confidence = 0.0
        
        return {
            'primary_type': primary_type,
            'confidence': confidence,
            'all_types': scores
        }

    def _identify_operations(self, content: str) -> List[Dict[str, Any]]:
        """Identifica as operações principais do programa"""
        operations = []
        
        for operation, patterns in self.operation_patterns.items():
            matches = []
            for pattern in patterns:
                found = re.findall(pattern, content)
                matches.extend(found)
            
            if matches:
                operations.append({
                    'operation': operation,
                    'frequency': len(matches),
                    'examples': list(set(matches))[:5]  # Máximo 5 exemplos
                })
        
        # Ordenar por frequência
        operations.sort(key=lambda x: x['frequency'], reverse=True)
        return operations

    def _identify_entities(self, content: str) -> List[Dict[str, Any]]:
        """Identifica entidades de negócio no programa"""
        entities = []
        
        for entity, patterns in self.entity_patterns.items():
            matches = []
            for pattern in patterns:
                found = re.findall(pattern, content)
                matches.extend(found)
            
            if matches:
                entities.append({
                    'entity': entity,
                    'frequency': len(matches),
                    'examples': list(set(matches))[:3]
                })
        
        entities.sort(key=lambda x: x['frequency'], reverse=True)
        return entities

    def _analyze_files(self, program: CobolProgram) -> Dict[str, Any]:
        """Analisa os arquivos utilizados pelo programa"""
        file_analysis = {
            'input_files': [],
            'output_files': [],
            'database_files': [],
            'temporary_files': [],
            'total_files': len(program.files)
        }
        
        for file_info in program.files:
            file_data = {
                'name': file_info.name,
                'organization': file_info.organization,
                'access_mode': file_info.access_mode,
                'operations': file_info.operations
            }
            
            # Classificar tipo de arquivo baseado nas operações
            if 'READ' in file_info.operations and 'WRITE' not in file_info.operations:
                file_analysis['input_files'].append(file_data)
            elif 'WRITE' in file_info.operations and 'READ' not in file_info.operations:
                file_analysis['output_files'].append(file_data)
            elif file_info.organization == 'INDEXED':
                file_analysis['database_files'].append(file_data)
            else:
                file_analysis['temporary_files'].append(file_data)
        
        return file_analysis

    def _analyze_process_flow(self, program: CobolProgram) -> Dict[str, Any]:
        """Analisa o fluxo de processamento do programa"""
        content = program.content.lower()
        
        # Identificar padrões de processamento
        patterns = {
            'sequential': len(re.findall(r'perform\s+until|read.*at\s+end', content)),
            'conditional': len(re.findall(r'if\s+|evaluate\s+', content)),
            'iterative': len(re.findall(r'perform\s+\d+\s+times|perform\s+varying', content)),
            'file_processing': len(re.findall(r'open\s+|close\s+|read\s+|write\s+', content)),
            'calculation': len(re.findall(r'compute\s+|add\s+|subtract\s+|multiply\s+|divide\s+', content))
        }
        
        # Determinar padrão principal
        main_pattern = max(patterns.keys(), key=lambda k: patterns[k]) if any(patterns.values()) else 'simple'
        
        return {
            'main_pattern': main_pattern,
            'patterns': patterns,
            'complexity': sum(patterns.values()),
            'estimated_steps': self._estimate_process_steps(content)
        }

    def _estimate_process_steps(self, content: str) -> List[str]:
        """Estima os passos principais do processamento"""
        steps = []
        
        # Padrões comuns de processamento
        if re.search(r'open\s+.*input', content):
            steps.append("Abertura de arquivos de entrada")
        
        if re.search(r'perform\s+.*inicializ', content):
            steps.append("Inicialização de variáveis e contadores")
        
        if re.search(r'read\s+.*at\s+end', content):
            steps.append("Leitura e processamento de registros")
        
        if re.search(r'validar|verificar|checar', content):
            steps.append("Validação de dados")
        
        if re.search(r'calcular|computar|somar', content):
            steps.append("Cálculos e processamento de dados")
        
        if re.search(r'write\s+|display\s+', content):
            steps.append("Geração de saídas e relatórios")
        
        if re.search(r'close\s+', content):
            steps.append("Finalização e fechamento de arquivos")
        
        return steps if steps else ["Processamento genérico de dados"]

    def _identify_business_rules(self, content: str) -> List[Dict[str, str]]:
        """Identifica regras de negócio no código"""
        rules = []
        
        # Padrões de regras de negócio
        rule_patterns = [
            (r'if\s+.*saldo.*<.*', 'Validação de saldo mínimo'),
            (r'if\s+.*idade.*>=.*18', 'Validação de maioridade'),
            (r'if\s+.*cpf.*=.*zero', 'Validação de CPF'),
            (r'if\s+.*status.*=.*[\'"]a[\'"]', 'Verificação de status ativo'),
            (r'compute\s+.*juros.*=.*', 'Cálculo de juros'),
            (r'compute\s+.*desconto.*=.*', 'Cálculo de desconto'),
            (r'if\s+.*limite.*<.*valor', 'Verificação de limite'),
            (r'if\s+.*data.*>.*hoje', 'Validação de data futura')
        ]
        
        for pattern, description in rule_patterns:
            matches = re.findall(pattern, content)
            if matches:
                rules.append({
                    'rule': description,
                    'occurrences': len(matches),
                    'examples': matches[:2]
                })
        
        return rules

    def _generate_functional_description(self, program_type: Dict, operations: List, 
                                       entities: List, files: Dict) -> str:
        """Gera descrição funcional do programa"""
        type_descriptions = {
            'financial': 'sistema financeiro que gerencia operações bancárias e cálculos monetários',
            'customer': 'sistema de gestão de clientes que mantém cadastros e informações pessoais',
            'inventory': 'sistema de controle de estoque que gerencia produtos e movimentações',
            'payroll': 'sistema de folha de pagamento que processa salários e benefícios',
            'accounting': 'sistema contábil que registra lançamentos e gera demonstrativos',
            'reporting': 'sistema de relatórios que gera listagens e consultas',
            'batch': 'sistema de processamento em lote que executa operações em massa',
            'maintenance': 'sistema de manutenção que realiza operações de limpeza e reorganização',
            'generic': 'sistema de processamento de dados'
        }
        
        primary_type = program_type['primary_type']
        base_description = type_descriptions.get(primary_type, 'sistema de processamento')
        
        # Adicionar operações principais
        if operations:
            main_ops = [op['operation'] for op in operations[:3]]
            ops_text = ', '.join(main_ops)
            base_description += f" com foco em operações de {ops_text}"
        
        # Adicionar entidades principais
        if entities:
            main_entities = [ent['entity'] for ent in entities[:2]]
            entities_text = ' e '.join(main_entities)
            base_description += f", trabalhando principalmente com {entities_text}"
        
        # Adicionar informações sobre arquivos
        total_files = files['total_files']
        if total_files > 0:
            base_description += f". O programa utiliza {total_files} arquivo(s)"
            
            if files['input_files']:
                base_description += f", incluindo {len(files['input_files'])} arquivo(s) de entrada"
            
            if files['output_files']:
                base_description += f" e {len(files['output_files'])} arquivo(s) de saída"
        
        return base_description + "."

    def _generate_technical_description(self, program: CobolProgram, files: Dict, 
                                      process_flow: Dict) -> str:
        """Gera descrição técnica do programa"""
        description = f"Programa COBOL com {program.lines_of_code} linhas de código"
        
        # Informações sobre estrutura
        if program.variables_count > 0:
            description += f", utilizando {program.variables_count} variáveis"
        
        if program.sections_count > 0:
            description += f" e {program.sections_count} seções"
        
        # Informações sobre complexidade
        complexity = process_flow['complexity']
        if complexity > 20:
            description += ". Apresenta alta complexidade de processamento"
        elif complexity > 10:
            description += ". Apresenta complexidade média de processamento"
        else:
            description += ". Apresenta baixa complexidade de processamento"
        
        # Padrão de processamento
        main_pattern = process_flow['main_pattern']
        pattern_descriptions = {
            'sequential': 'processamento sequencial de registros',
            'conditional': 'lógica condicional complexa',
            'iterative': 'processamento iterativo com loops',
            'file_processing': 'operações intensivas de arquivo',
            'calculation': 'cálculos matemáticos complexos'
        }
        
        if main_pattern in pattern_descriptions:
            description += f" com {pattern_descriptions[main_pattern]}"
        
        return description + "."

    def _identify_system_purpose(self, program_type: Dict, operations: List, 
                                entities: List) -> str:
        """Identifica o propósito do sistema"""
        purposes = {
            'financial': 'Automatizar operações financeiras e cálculos bancários',
            'customer': 'Gerenciar informações e relacionamento com clientes',
            'inventory': 'Controlar estoque e movimentação de produtos',
            'payroll': 'Processar folha de pagamento e benefícios de funcionários',
            'accounting': 'Registrar e controlar movimentações contábeis',
            'reporting': 'Gerar relatórios gerenciais e operacionais',
            'batch': 'Executar processamentos em lote de grande volume',
            'maintenance': 'Manter integridade e organização dos dados'
        }
        
        primary_type = program_type['primary_type']
        base_purpose = purposes.get(primary_type, 'Processar dados corporativos')
        
        # Refinar baseado nas operações
        if operations:
            main_operation = operations[0]['operation']
            if main_operation == 'calculate':
                base_purpose += ' com foco em cálculos precisos'
            elif main_operation == 'validate':
                base_purpose += ' garantindo qualidade e integridade dos dados'
            elif main_operation == 'generate':
                base_purpose += ' produzindo informações e documentos'
        
        return base_purpose

    def _assess_complexity(self, program: CobolProgram) -> Dict[str, Any]:
        """Avalia a complexidade do programa"""
        content = program.content.lower()
        
        # Métricas de complexidade
        metrics = {
            'lines_of_code': program.lines_of_code,
            'variables': program.variables_count,
            'sections': program.sections_count,
            'paragraphs': program.paragraphs_count,
            'files': len(program.files),
            'conditional_statements': len(re.findall(r'if\s+|evaluate\s+', content)),
            'loops': len(re.findall(r'perform\s+until|perform\s+varying', content)),
            'calculations': len(re.findall(r'compute\s+|add\s+|subtract\s+', content))
        }
        
        # Calcular score de complexidade
        complexity_score = (
            metrics['lines_of_code'] * 0.1 +
            metrics['variables'] * 2 +
            metrics['conditional_statements'] * 3 +
            metrics['loops'] * 4 +
            metrics['files'] * 5
        )
        
        # Classificar complexidade
        if complexity_score < 50:
            level = 'Baixa'
        elif complexity_score < 150:
            level = 'Média'
        elif complexity_score < 300:
            level = 'Alta'
        else:
            level = 'Muito Alta'
        
        return {
            'level': level,
            'score': complexity_score,
            'metrics': metrics
        }

    def _identify_integration_points(self, content: str) -> List[Dict[str, str]]:
        """Identifica pontos de integração com outros sistemas"""
        integrations = []
        
        # Padrões de integração
        integration_patterns = [
            (r'call\s+[\'"]([^\'"]+)[\'"]', 'Chamada de programa externo'),
            (r'copy\s+([a-zA-Z0-9-]+)', 'Inclusão de copybook'),
            (r'exec\s+sql', 'Integração com banco de dados SQL'),
            (r'exec\s+cics', 'Integração com CICS'),
            (r'ftp|http|tcp', 'Comunicação de rede'),
            (r'jcl|job|step', 'Integração com JCL/Batch')
        ]
        
        for pattern, description in integration_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                integrations.append({
                    'type': description,
                    'count': len(matches),
                    'examples': list(set(matches))[:3]
                })
        
        return integrations

    def _analyze_data_flow(self, program: CobolProgram) -> Dict[str, Any]:
        """Analisa o fluxo de dados no programa"""
        content = program.content.lower()
        
        # Identificar padrões de fluxo de dados
        input_operations = len(re.findall(r'accept\s+|read\s+', content))
        output_operations = len(re.findall(r'display\s+|write\s+', content))
        data_movements = len(re.findall(r'move\s+.*to\s+', content))
        transformations = len(re.findall(r'compute\s+|string\s+|unstring\s+', content))
        
        # Determinar padrão de fluxo
        if input_operations > output_operations * 2:
            flow_pattern = 'Input-intensive'
        elif output_operations > input_operations * 2:
            flow_pattern = 'Output-intensive'
        elif transformations > (input_operations + output_operations):
            flow_pattern = 'Transformation-intensive'
        else:
            flow_pattern = 'Balanced'
        
        return {
            'pattern': flow_pattern,
            'input_operations': input_operations,
            'output_operations': output_operations,
            'data_movements': data_movements,
            'transformations': transformations,
            'data_complexity': data_movements + transformations
        }

    def get_name(self) -> str:
        return self._name

    def get_description(self) -> str:
        return self.description
    
    @property
    def name(self) -> str:
        return self._name
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    def get_configuration(self) -> Dict[str, Any]:
        return {}
    
    def set_configuration(self, config: Dict[str, Any]) -> None:
        pass

