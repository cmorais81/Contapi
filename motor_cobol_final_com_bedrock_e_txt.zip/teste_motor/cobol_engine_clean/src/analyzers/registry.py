"""
Analyzer registry following Registry pattern and Dependency Inversion.
"""

import os
from typing import Dict, List, Optional
from ..interfaces.analyzer import IAnalyzer
from .security import SecurityAnalyzer
from .performance import PerformanceAnalyzer
from .functional_analyzer import FunctionalAnalyzer


class AnalyzerRegistry:
    """
    Registry for analyzers following Registry pattern.
    Following Open/Closed Principle - open for extension, closed for modification.
    """
    
    def __init__(self):
        self._analyzers: Dict[str, IAnalyzer] = {}
        self._register_default_analyzers()
    
    def _register_default_analyzers(self):
        """Register default analyzers."""
        self.register_analyzer(SecurityAnalyzer())
        self.register_analyzer(PerformanceAnalyzer())
        self.register_analyzer(FunctionalAnalyzer())
        
        # Registrar analisador Bedrock se configurado
        self._register_bedrock_analyzer()
    
    def _register_bedrock_analyzer(self):
        """Registrar analisador Bedrock se credenciais AWS estiverem disponíveis"""
        try:
            # Verificar se credenciais AWS estão disponíveis
            aws_access_key = os.getenv('AWS_ACCESS_KEY_ID')
            aws_secret_key = os.getenv('AWS_SECRET_ACCESS_KEY')
            bedrock_region = os.getenv('AWS_BEDROCK_REGION', 'us-east-1')
            bedrock_model = os.getenv('AWS_BEDROCK_MODEL', 'anthropic.claude-3-sonnet-20240229-v1:0')
            
            # Verificar se Bedrock está habilitado
            bedrock_enabled = os.getenv('ENABLE_BEDROCK', 'false').lower() == 'true'
            
            if bedrock_enabled and (aws_access_key or self._has_aws_credentials()):
                from ..utils.bedrock_integration import BedrockAnalyzer
                
                bedrock_analyzer = BedrockAnalyzer(
                    model_id=bedrock_model,
                    region_name=bedrock_region,
                    aws_access_key_id=aws_access_key,
                    aws_secret_access_key=aws_secret_key
                )
                
                self.register_analyzer(bedrock_analyzer)
                print(f"Analisador Bedrock registrado com modelo: {bedrock_model}")
                
        except Exception as e:
            # Falha silenciosa - Bedrock é opcional
            print(f"Aviso: Não foi possível registrar analisador Bedrock: {e}")
    
    def _has_aws_credentials(self) -> bool:
        """Verificar se credenciais AWS estão disponíveis via perfil padrão"""
        try:
            import boto3
            session = boto3.Session()
            credentials = session.get_credentials()
            return credentials is not None
        except:
            return False
    
    def register_analyzer(self, analyzer: IAnalyzer):
        """
        Register an analyzer.
        
        Args:
            analyzer: Analyzer instance to register
        """
        self._analyzers[analyzer.name] = analyzer
    
    def get_analyzer(self, name: str) -> Optional[IAnalyzer]:
        """
        Get analyzer by name.
        
        Args:
            name: Analyzer name
            
        Returns:
            Analyzer instance or None if not found
        """
        return self._analyzers.get(name)
    
    def get_analyzer_names(self) -> List[str]:
        """
        Get list of available analyzer names.
        
        Returns:
            List of analyzer names
        """
        return list(self._analyzers.keys())
    
    def get_all_analyzers(self) -> Dict[str, IAnalyzer]:
        """
        Get all registered analyzers.
        
        Returns:
            Dictionary of analyzer name -> analyzer instance
        """
        return self._analyzers.copy()
    
    def unregister_analyzer(self, name: str) -> bool:
        """
        Unregister an analyzer.
        
        Args:
            name: Analyzer name to unregister
            
        Returns:
            True if analyzer was found and removed
        """
        if name in self._analyzers:
            del self._analyzers[name]
            return True
        return False

