# Autor: carlos.morais@f1rst.com.br
#!/usr/bin/env python3
"""
API Gateway V4.1 - Hybrid Architecture (PostgreSQL + Redis)
Gateway principal com cache distribuído e agregação de dados
"""

import os
import sys
import logging
import json
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from concurrent.futures import ThreadPoolExecutor, as_completed

# Add shared directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'shared'))

from fastapi import FastAPI, HTTPException, Depends, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import uvicorn
import httpx

# Import shared modules
try:
    from database import execute_query, health_check as db_health_check
    from cache import redis_manager, cache_result, rate_limit, get_redis_health
    POSTGRES_AVLABLE = True
    REDIS_AVLABLE = redis_manager.is_available()
except ImportError as e:
    print(f"Shared modules not available: {e}")
    POSTGRES_AVLABLE = False
    REDIS_AVLABLE = False

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# =====================================================
# MICROSERVICES CONFIGURATION
# =====================================================

MICROSERVICES = {
    'contract-service': {'url': 'http://localhost:8001', 'timeout': 5},
    'identity-service': {'url': 'http://localhost:8002', 'timeout': 5},
    'quality-service': {'url': 'http://localhost:8003', 'timeout': 5},
    'catalog-service': {'url': 'http://localhost:8004', 'timeout': 5},
    'analytics-service': {'url': 'http://localhost:8005', 'timeout': 5},
    'workflow-service': {'url': 'http://localhost:8006', 'timeout': 5},
    'governance-service': {'url': 'http://localhost:8007', 'timeout': 5},
    'orchestration-service': {'url': 'http://localhost:8008', 'timeout': 5},
    'audit-service': {'url': 'http://localhost:8009', 'timeout': 5}
}

# =====================================================
# PYDANTIC MODELS
# =====================================================

class ServiceHealth(BaseModel):
    """Classe ServiceHealth."""
    service: str
    status: str
    response_time_ms: float
    url: str
    error: Optional[str] = None

class DashboardMetrics(BaseModel):
    governance_score: float
    total_contracts: int
    active_users: int
    quality_score: float
    compliance_score: float
    total_entities: int
    active_workflows: int
    recent_activities: List[Dict[str, Any]]

# =====================================================
# SERVICE COMMUNICATION
# =====================================================

async def call_service(service_name: str, endpoint: str, method: str = "GET", data: Optional[Dict] = None) -> Dict[str, Any]:
    """Executa operação call_service."""
    """Call microservice endpoint with circuit breaker"""
    if service_name not in MICROSERVICES:
        raise HTTPException(status_code=404, detail=f"Service {service_name} not found")
    
    service_config = MICROSERVICES[service_name]
    url = f"{service_config['url']}{endpoint}"
    timeout = service_config['timeout']
    
    # Check circuit breaker state
    if REDIS_AVLABLE:
        circuit_state = redis_manager.circuit_breaker_state(service_name)
        if circuit_state['state'] == 'open':
            # Circuit is open, check if we can try again
            if circuit_state.get('next_attempt'):
                next_attempt = datetime.fromisoformat(circuit_state['next_attempt'])
                if datetime.now() < next_attempt:
                    raise HTTPException(
                        status_code=503, 
                        detail=f"Service {service_name} is temporarily unavailable (circuit breaker open)"
                    )
                else:
                    # Try to transition to half-open
                    circuit_state['state'] = 'half_open'
                    redis_manager.set(f"circuit_breaker:{service_name}", circuit_state, 3600)
    
    start_time = datetime.now()
    
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            if method.upper() == "GET":
                response = await client.get(url)
            elif method.upper() == "POST":
                response = await client.post(url, json=data)
            elif method.upper() == "PUT":
                response = await client.put(url, json=data)
            elif method.upper() == "DELETE":
                response = await client.delete(url)
            else:
                raise HTTPException(status_code=400, detail=f"Unsupported method: {method}")
            
            response_time = (datetime.now() - start_time).total_seconds() * 1000
            
            if response.status_code >= 400:
                # Record failure in circuit breaker
                if REDIS_AVLABLE:
                    redis_manager.circuit_breaker_record_failure(service_name)
                
                raise HTTPException(
                    status_code=response.status_code,
                    detail=f"Service {service_name} error: {response.text}"
                )
            
            # Record success in circuit breaker
            if REDIS_AVLABLE:
                redis_manager.circuit_breaker_record_success(service_name)
            
            result = response.json() if response.content else {}
            result['_meta'] = {
                'service': service_name,
                'response_time_ms': response_time,
                'cached': False
            }
            
            return result
            
    except httpx.TimeoutException:
        if REDIS_AVLABLE:
            redis_manager.circuit_breaker_record_failure(service_name)
        raise HTTPException(status_code=504, detail=f"Service {service_name} timeout")
    except httpx.RequestError as e:
        if REDIS_AVLABLE:
            redis_manager.circuit_breaker_record_failure(service_name)
        raise HTTPException(status_code=503, detail=f"Service {service_name} connection error: {str(e)}")

async def get_service_health(service_name: str) -> ServiceHealth:
    """Get health status of a microservice"""
    start_time = datetime.now()
    
    try:
        result = await call_service(service_name, "/health")
        response_time = (datetime.now() - start_time).total_seconds() * 1000
        
        return ServiceHealth(
            service=service_name,
            status="healthy",
            response_time_ms=response_time,
            url=MICROSERVICES[service_name]['url']
        )
    except Exception as e:
        response_time = (datetime.now() - start_time).total_seconds() * 1000
        
        return ServiceHealth(
            service=service_name,
            status="unhealthy",
            response_time_ms=response_time,
            url=MICROSERVICES[service_name]['url'],
            error=str(e)
        )

# =====================================================
# DASHBOARD AGGREGATION
# =====================================================

# @cache_result(ttl=300, key_prefix="dashboard")  # Cache for 5 minutes
async def get_dashboard_metrics() -> DashboardMetrics:
    """Aggregate dashboard metrics from all services"""
    logger.info("Aggregating dashboard metrics from all services")
    
    # Default metrics
    metrics = {
        'governance_score': 0.0,
        'total_contracts': 0,
        'active_users': 0,
        'quality_score': 0.0,
        'compliance_score': 0.0,
        'total_entities': 0,
        'active_workflows': 0,
        'recent_activities': []
    }
    
    try:
        # Collect data from services in parallel
        tasks = []
        
        # Contract Service - contracts count
        tasks.append(('contracts', call_service('contract-service', '/api/v1/contracts')))
        
        # Identity Service - users count
        tasks.append(('users', call_service('identity-service', '/api/v1/users')))
        
        # Quality Service - quality score
        tasks.append(('quality', call_service('quality-service', '/api/v1/rules')))
        
        # Catalog Service - entities count
        tasks.append(('entities', call_service('catalog-service', '/api/v1/entities')))
        
        # Workflow Service - active workflows
        tasks.append(('workflows', call_service('workflow-service', '/api/v1/workflows')))
        
        # Analytics Service - metrics summary
        tasks.append(('analytics', call_service('analytics-service', '/api/v1/metrics/summary')))
        
        # Execute all requests concurrently
        results = {}
        for name, task in tasks:
            try:
                result = await task
                results[name] = result
                logger.info(f"✅ {name}: {len(result) if isinstance(result, list) else 'OK'}")
            except Exception as e:
                logger.error(f"❌ {name}: {str(e)}")
                results[name] = None
        
        # Process results
        if results.get('contracts'):
            metrics['total_contracts'] = len(results['contracts'])
        
        if results.get('users'):
            metrics['active_users'] = len([u for u in results['users'] if u.get('active', True)])
        
        if results.get('quality'):
            quality_rules = results['quality']
            if quality_rules:
                active_rules = [r for r in quality_rules if r.get('active', True)]
                metrics['quality_score'] = len(active_rules) / len(quality_rules) * 100 if quality_rules else 0
        
        if results.get('entities'):
            metrics['total_entities'] = len(results['entities'])
        
        if results.get('workflows'):
            workflows = results['workflows']
            metrics['active_workflows'] = len([w for w in workflows if w.get('status') == 'active'])
        
        if results.get('analytics'):
            analytics = results['analytics']
            if isinstance(analytics, dict):
                metrics['governance_score'] = analytics.get('governance_score', 0)
                metrics['compliance_score'] = analytics.get('compliance_score', 0)
        
        # Calculate overall governance score
        if not metrics['governance_score']:
            scores = [
                metrics['quality_score'],
                metrics['compliance_score'],
                (metrics['total_contracts'] / 10) * 100 if metrics['total_contracts'] else 0,  # Normalize to 100
                (metrics['active_users'] / 5) * 100 if metrics['active_users'] else 0  # Normalize to 100
            ]
            metrics['governance_score'] = sum(scores) / len(scores)
        
        # Recent activities (mock for now)
        metrics['recent_activities'] = [
            {
                'id': '1',
                'type': 'contract_created',
                'description': 'New data contract created',
                'timestamp': (datetime.now() - timedelta(minutes=30)).isoformat(),
                'user': 'data_owner'
            },
            {
                'id': '2',
                'type': 'quality_check',
                'description': 'Quality validation completed',
                'timestamp': (datetime.now() - timedelta(hours=1)).isoformat(),
                'user': 'system'
            },
            {
                'id': '3',
                'type': 'compliance_review',
                'description': 'LGPD compliance assessment',
                'timestamp': (datetime.now() - timedelta(hours=2)).isoformat(),
                'user': 'compliance_officer'
            }
        ]
        
        logger.info(f"Dashboard metrics aggregated successfully: {metrics}")
        return DashboardMetrics(**metrics)
        
    except Exception as e:
        logger.error(f"Error aggregating dashboard metrics: {e}")
        # Return default metrics on error
        return DashboardMetrics(**metrics)

# =====================================================
# FASTAPI APPLICATION
# =====================================================

app = FastAPI(
    title="API Gateway V4.1 - Hybrid Architecture",
    description="Gateway principal com cache Redis e agregação PostgreSQL",
    version="4.1.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# RATE LIMITING MIDDLEWARE
# =====================================================

@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    """Global rate limiting middleware"""
    if not REDIS_AVLABLE:
        return await call_next(request)
    
    # Extract client identifier (IP for now, could be user ID from JWT)
    client_id = request.client.host if request.client else "unknown"
    rate_key = f"rate_limit:global:{client_id}"
    
    # Check rate limit (100 requests per minute)
    rate_check = redis_manager.rate_limit_check(rate_key, 100, 60)
    
    if not rate_check['allowed']:
        return JSONResponse(
            status_code=429,
            content={
                "error": "Rate limit exceeded",
                "limit": 100,
                "window": 60,
                "reset_at": rate_check.get('reset_at'),
                "remaining": rate_check.get('remaining', 0)
            }
        )
    
    response = await call_next(request)
    
    # Add rate limit headers
    response.headers["X-RateLimit-Limit"] = str(100)
    response.headers["X-RateLimit-Remaining"] = str(rate_check.get('remaining', 0))
    response.headers["X-RateLimit-Reset"] = rate_check.get('reset_at', '')
    
    return response

# =====================================================
# HEALTH CHECK
# =====================================================

@app.get("/health")
async def health_check():
    """Comprehensive health check"""
    # Check all services health
    health_tasks = [get_service_health(service) for service in MICROSERVICES.keys()]
    services_health = await asyncio.gather(*health_tasks, return_exceptions=True)
    
    # Process results
    healthy_services = 0
    service_statuses = []
    
    for i, health in enumerate(services_health):
        service_name = list(MICROSERVICES.keys())[i]
        if isinstance(health, ServiceHealth):
            service_statuses.append(health.dict())
            if health.status == "healthy":
                healthy_services += 1
        else:
            service_statuses.append({
                "service": service_name,
                "status": "error",
                "error": str(health),
                "response_time_ms": 0,
                "url": MICROSERVICES[service_name]['url']
            })
    
    # Database health
    db_health = None
    if POSTGRES_AVLABLE:
        try:
            db_health = db_health_check()
        except Exception as e:
            db_health = {"status": "unhealthy", "error": str(e)}
    
    # Redis health
    redis_health = None
    if REDIS_AVLABLE:
        redis_health = get_redis_health()
    
    # Overall status
    overall_status = "healthy" if healthy_services >= len(MICROSERVICES) * 0.7 else "degraded"
    
    return {
        "status": overall_status,
        "timestamp": datetime.now().isoformat(),
        "version": "4.1.0",
        "service": "api-gateway",
        "port": 8100,
        "architecture": "hybrid",
        "services": {
            "total": len(MICROSERVICES),
            "healthy": healthy_services,
            "unhealthy": len(MICROSERVICES) - healthy_services,
            "details": service_statuses
        },
        "infrastructure": {
            "postgresql": db_health,
            "redis": redis_health
        },
        "features": {
            "service_discovery": True,
            "circuit_breaker": REDIS_AVLABLE,
            "rate_limiting": REDIS_AVLABLE,
            "response_caching": REDIS_AVLABLE,
            "load_balancing": True,
            "health_monitoring": True
        }
    }

# =====================================================
# DASHBOARD ENDPOINTS
# =====================================================

@app.get("/api/v1/dashboard")
async def get_dashboard():
    """Get consolidated dashboard metrics with Redis cache"""
    cache_key = "dashboard:metrics"
    
    # Try to get from cache first
    if REDIS_AVLABLE:
        cached_data = redis_manager.get_cached_response(cache_key)
        if cached_data:
            logger.info("Dashboard metrics served from cache")
            return cached_data['data']
    
    # Generate fresh data
    logger.info("Generating fresh dashboard metrics")
    metrics = await get_dashboard_metrics()
    
    # Cache the result
    if REDIS_AVLABLE:
        redis_manager.cache_response(cache_key, metrics.dict(), 300)  # 5 minutes TTL
    
    return metrics

@app.get("/api/v1/metrics/summary")
async def get_metrics_summary():
    """Get metrics summary (cached)"""
    return await get_dashboard()

# =====================================================
# SERVICE PROXY ENDPOINTS
# =====================================================

@app.get("/api/v1/services/{service_name}/health")
async def get_service_health_endpoint(service_name: str):
    """Get specific service health"""
    return await get_service_health(service_name)

@app.api_route("/api/v1/services/{service_name}/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def proxy_service_request(service_name: str, path: str, request: Request):
    """Proxy requests to microservices"""
    method = request.method
    
    # Get request body for POST/PUT
    data = None
    if method in ["POST", "PUT"]:
        try:
            data = await request.json()
        except Exception as e:
        logger.error(f"Erro inesperado: {e}")
            data = None
    
    # Call service
    result = await call_service(service_name, f"/{path}", method, data)
    
    return result

# =====================================================
# SIMPLIFIED ENDPOINTS (V3.2 COMPATIBILITY)
# =====================================================

@app.get("/api/v1/simple/dashboard")
async def simple_dashboard():
    """Simplified dashboard for basic users"""
    metrics = await get_dashboard_metrics()
    
    return {
        "governance_health": "good" if metrics.governance_score >= 70 else "needs_attention",
        "total_contracts": metrics.total_contracts,
        "active_users": metrics.active_users,
        "quality_status": "good" if metrics.quality_score >= 80 else "needs_improvement",
        "recent_activity_count": len(metrics.recent_activities),
        "last_updated": datetime.now().isoformat()
    }

@app.get("/api/v1/simple/contracts")
async def simple_contracts():
    """Simplified contracts endpoint"""
    contracts = await call_service('contract-service', '/api/v1/contracts')
    
    return [
        {
            "id": contract.get("id"),
            "name": contract.get("title", contract.get("name")),
            "status": contract.get("status", "unknown"),
            "created": contract.get("created_at", "")
        }
        for contract in contracts
    ]

# =====================================================
# STARTUP/SHUTDOWN EVENTS
# =====================================================

@app.on_event("startup")
async def startup_event():
    """Application startup"""
    logger.info("Starting API Gateway V4.1 with Hybrid Architecture")
    
    # Test infrastructure
    if POSTGRES_AVLABLE:
        logger.info("✅ PostgreSQL integration available")
    else:
        logger.warning("⚠️ PostgreSQL integration not available")
    
    if REDIS_AVLABLE:
        logger.info("✅ Redis cache integration available")
    else:
        logger.warning("⚠️ Redis cache integration not available")
    
    logger.info("API Gateway started successfully")

@app.on_event("shutdown")
async def shutdown_event():
    """Application shutdown"""
    logger.info("Shutting down API Gateway V4.1")

# =====================================================
# MN EXECUTION
# =====================================================

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8100))
    uvicorn.run(
        "main_hybrid:app",
        host="0.0.0.0",
        port=port,
        reload=False,
        log_level="info"
    )

