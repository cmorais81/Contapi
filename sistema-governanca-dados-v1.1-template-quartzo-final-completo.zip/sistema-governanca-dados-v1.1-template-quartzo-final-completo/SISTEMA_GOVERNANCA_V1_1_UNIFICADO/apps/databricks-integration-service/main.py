#!/usr/bin/env python3
"""
Databricks Integration Service
Microserviço responsável pela integração com Databricks Unity Catalog,
Data Classification e Lakehouse Monitoring
"""

import os
import asyncio
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import httpx
import asyncpg
from redis import Redis

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Models Pydantic para API
class DatabricksConfig(BaseModel):
    """Configuração do Databricks"""
    host: str = Field(..., description="Databricks workspace URL")
    token: str = Field(..., description="Personal access token")
    workspace_id: str = Field(..., description="Workspace ID")
    catalog_name: str = Field(..., description="Default catalog name")

class TableClassification(BaseModel):
    """Classificação de tabela"""
    table_name: str = Field(..., description="Nome completo da tabela (catalog.schema.table)")
    column_name: str = Field(..., description="Nome da coluna")
    classification_type: str = Field(..., description="Tipo de classificação (email, phone, etc)")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Nível de confiança")
    rationale: str = Field(..., description="Justificativa da classificação")
    scan_timestamp: datetime = Field(default_factory=datetime.now)

class QualityRule(BaseModel):
    """Regra de qualidade de dados"""
    rule_type: str = Field(..., description="Tipo da regra (not_null, unique, format, etc)")
    column: str = Field(..., description="Coluna alvo")
    parameters: Optional[Dict[str, Any]] = Field(default=None, description="Parâmetros da regra")
    threshold: Optional[float] = Field(default=None, description="Limite de aceitação")

class QualityMonitor(BaseModel):
    """Monitor de qualidade"""
    table_name: str = Field(..., description="Nome da tabela")
    rules: List[QualityRule] = Field(..., description="Regras de qualidade")
    schedule: Optional[str] = Field(default="daily", description="Frequência de execução")
    alert_threshold: Optional[float] = Field(default=0.95, description="Limite para alertas")

class SyncRequest(BaseModel):
    """Requisição de sincronização"""
    catalog_name: str = Field(..., description="Nome do catálogo")
    schema_name: Optional[str] = Field(default=None, description="Nome do schema (opcional)")
    table_name: Optional[str] = Field(default=None, description="Nome da tabela (opcional)")
    sync_type: str = Field(..., description="Tipo de sincronização (classifications, metadata, all)")

# Mock do cliente Databricks para desenvolvimento
class MockDatabricksClient:
    """Cliente mock do Databricks para desenvolvimento e testes"""
    
    def __init__(self, config: DatabricksConfig):
        self.config = config
        self.logger = logging.getLogger(f"{__name__}.MockDatabricksClient")
        self.logger.info(f"Initialized mock Databricks client for {config.host}")
    
    async def list_catalogs(self) -> List[Dict[str, Any]]:
        """Lista catálogos disponíveis"""
        await asyncio.sleep(0.1)  # Simula latência de rede
        return [
            {"name": "main", "comment": "Main catalog", "owner": "admin"},
            {"name": self.config.catalog_name, "comment": "Governance catalog", "owner": "governance_team"},
            {"name": "samples", "comment": "Sample datasets", "owner": "admin"}
        ]
    
    async def list_schemas(self, catalog_name: str) -> List[Dict[str, Any]]:
        """Lista schemas de um catálogo"""
        await asyncio.sleep(0.1)
        return [
            {"name": "default", "comment": "Default schema", "catalog_name": catalog_name},
            {"name": "bronze", "comment": "Raw data layer", "catalog_name": catalog_name},
            {"name": "silver", "comment": "Cleaned data layer", "catalog_name": catalog_name},
            {"name": "gold", "comment": "Business data layer", "catalog_name": catalog_name}
        ]
    
    async def list_tables(self, catalog_name: str, schema_name: str) -> List[Dict[str, Any]]:
        """Lista tabelas de um schema"""
        await asyncio.sleep(0.1)
        return [
            {
                "name": "customers",
                "catalog_name": catalog_name,
                "schema_name": schema_name,
                "table_type": "MANAGED",
                "comment": "Customer master data"
            },
            {
                "name": "orders", 
                "catalog_name": catalog_name,
                "schema_name": schema_name,
                "table_type": "MANAGED",
                "comment": "Order transactions"
            },
            {
                "name": "products",
                "catalog_name": catalog_name,
                "schema_name": schema_name,
                "table_type": "MANAGED", 
                "comment": "Product catalog"
            }
        ]
    
    async def get_table_info(self, catalog_name: str, schema_name: str, table_name: str) -> Dict[str, Any]:
        """Obtém informações detalhadas de uma tabela"""
        await asyncio.sleep(0.1)
        
        # Simula diferentes estruturas baseadas no nome da tabela
        if table_name == "customers":
            columns = [
                {"name": "customer_id", "type_name": "STRING", "comment": "Unique customer identifier"},
                {"name": "first_name", "type_name": "STRING", "comment": "Customer first name"},
                {"name": "last_name", "type_name": "STRING", "comment": "Customer last name"},
                {"name": "email", "type_name": "STRING", "comment": "Customer email address"},
                {"name": "phone", "type_name": "STRING", "comment": "Customer phone number"},
                {"name": "birth_date", "type_name": "DATE", "comment": "Customer birth date"},
                {"name": "created_at", "type_name": "TIMESTAMP", "comment": "Record creation timestamp"},
                {"name": "updated_at", "type_name": "TIMESTAMP", "comment": "Record update timestamp"}
            ]
        elif table_name == "orders":
            columns = [
                {"name": "order_id", "type_name": "STRING", "comment": "Unique order identifier"},
                {"name": "customer_id", "type_name": "STRING", "comment": "Customer identifier"},
                {"name": "order_date", "type_name": "TIMESTAMP", "comment": "Order placement date"},
                {"name": "total_amount", "type_name": "DECIMAL(10,2)", "comment": "Total order amount"},
                {"name": "status", "type_name": "STRING", "comment": "Order status"},
                {"name": "shipping_address", "type_name": "STRING", "comment": "Shipping address"}
            ]
        else:
            columns = [
                {"name": "id", "type_name": "STRING", "comment": "Primary key"},
                {"name": "name", "type_name": "STRING", "comment": "Name field"},
                {"name": "created_at", "type_name": "TIMESTAMP", "comment": "Creation timestamp"}
            ]
        
        return {
            "catalog_name": catalog_name,
            "schema_name": schema_name,
            "table_name": table_name,
            "table_type": "MANAGED",
            "columns": columns,
            "owner": "governance_team",
            "comment": f"Table {table_name} in {catalog_name}.{schema_name}",
            "created_at": "2024-01-01T00:00:00Z",
            "updated_at": datetime.now().isoformat()
        }
    
    async def get_table_classifications(self, catalog_name: str, schema_name: str, table_name: str) -> List[Dict[str, Any]]:
        """Obtém classificações de dados de uma tabela"""
        await asyncio.sleep(0.2)  # Classificação demora mais
        
        classifications = []
        table_full_name = f"{catalog_name}.{schema_name}.{table_name}"
        
        # Simula classificações baseadas no nome da tabela
        if table_name == "customers":
            classifications = [
                {
                    "table_name": table_full_name,
                    "column_name": "email",
                    "classification_type": "email_address",
                    "confidence": 0.95,
                    "rationale": "Detected email pattern in column values",
                    "scan_timestamp": datetime.now().isoformat()
                },
                {
                    "table_name": table_full_name,
                    "column_name": "phone",
                    "classification_type": "phone_number", 
                    "confidence": 0.88,
                    "rationale": "Detected phone number pattern in column values",
                    "scan_timestamp": datetime.now().isoformat()
                },
                {
                    "table_name": table_full_name,
                    "column_name": "birth_date",
                    "classification_type": "date_of_birth",
                    "confidence": 0.92,
                    "rationale": "Column name and date format suggest birth date",
                    "scan_timestamp": datetime.now().isoformat()
                }
            ]
        elif table_name == "orders":
            classifications = [
                {
                    "table_name": table_full_name,
                    "column_name": "shipping_address",
                    "classification_type": "address",
                    "confidence": 0.85,
                    "rationale": "Column contains address-like patterns",
                    "scan_timestamp": datetime.now().isoformat()
                }
            ]
        
        return classifications
    
    async def create_quality_monitor(self, table_name: str, rules: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Cria monitor de qualidade para uma tabela"""
        await asyncio.sleep(0.3)
        
        monitor_id = f"monitor_{table_name.replace('.', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        return {
            "monitor_id": monitor_id,
            "table_name": table_name,
            "rules": rules,
            "status": "ACTIVE",
            "schedule": "daily",
            "created_at": datetime.now().isoformat(),
            "next_run": datetime.now().isoformat()
        }
    
    async def get_quality_metrics(self, monitor_id: str) -> Dict[str, Any]:
        """Obtém métricas de qualidade de um monitor"""
        await asyncio.sleep(0.2)
        
        return {
            "monitor_id": monitor_id,
            "last_run": datetime.now().isoformat(),
            "status": "SUCCESS",
            "metrics": {
                "total_records": 10000,
                "valid_records": 9850,
                "invalid_records": 150,
                "quality_score": 0.985,
                "rule_results": [
                    {"rule": "not_null", "column": "customer_id", "pass_rate": 1.0},
                    {"rule": "unique", "column": "email", "pass_rate": 0.98},
                    {"rule": "format", "column": "email", "pass_rate": 0.99}
                ]
            }
        }

class DatabricksIntegrationService:
    """Serviço principal de integração com Databricks"""
    
    def __init__(self):
        self.config = self._load_config()
        self.client = MockDatabricksClient(self.config)
        self.db_pool = None
        self.redis_client = None
        self.logger = logging.getLogger(f"{__name__}.DatabricksIntegrationService")
    
    def _load_config(self) -> DatabricksConfig:
        """Carrega configuração do Databricks"""
        return DatabricksConfig(
            host=os.getenv("DATABRICKS_HOST", "https://mock-workspace.cloud.databricks.com"),
            token=os.getenv("DATABRICKS_TOKEN", "mock-token"),
            workspace_id=os.getenv("DATABRICKS_WORKSPACE_ID", "mock-workspace-123"),
            catalog_name=os.getenv("DATABRICKS_CATALOG_NAME", "governance_catalog")
        )
    
    async def initialize(self):
        """Inicializa conexões com banco de dados e cache"""
        try:
            # Conexão com PostgreSQL
            self.db_pool = await asyncpg.create_pool(
                host=os.getenv("DB_HOST", "localhost"),
                port=int(os.getenv("DB_PORT", "5432")),
                user=os.getenv("DB_USER", "governance_user"),
                password=os.getenv("DB_PASSWORD", "governance_pass"),
                database=os.getenv("DB_NAME", "governance_db"),
                min_size=2,
                max_size=10
            )
            
            # Conexão com Redis
            self.redis_client = Redis(
                host=os.getenv("REDIS_HOST", "localhost"),
                port=int(os.getenv("REDIS_PORT", "6379")),
                decode_responses=True
            )
            
            self.logger.info("Database and cache connections initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize connections: {e}")
            raise
    
    async def cleanup(self):
        """Limpa recursos"""
        if self.db_pool:
            await self.db_pool.close()
        if self.redis_client:
            self.redis_client.close()
    
    async def sync_catalog_metadata(self, catalog_name: str) -> Dict[str, Any]:
        """Sincroniza metadados de um catálogo"""
        self.logger.info(f"Starting metadata sync for catalog: {catalog_name}")
        
        try:
            # Busca schemas do catálogo
            schemas = await self.client.list_schemas(catalog_name)
            synced_tables = 0
            synced_classifications = 0
            
            for schema in schemas:
                schema_name = schema["name"]
                
                # Busca tabelas do schema
                tables = await self.client.list_tables(catalog_name, schema_name)
                
                for table in tables:
                    table_name = table["name"]
                    
                    # Sincroniza metadados da tabela
                    table_info = await self.client.get_table_info(catalog_name, schema_name, table_name)
                    await self._store_table_metadata(table_info)
                    synced_tables += 1
                    
                    # Sincroniza classificações
                    classifications = await self.client.get_table_classifications(catalog_name, schema_name, table_name)
                    for classification in classifications:
                        await self._store_classification(classification)
                        synced_classifications += 1
            
            result = {
                "catalog_name": catalog_name,
                "synced_schemas": len(schemas),
                "synced_tables": synced_tables,
                "synced_classifications": synced_classifications,
                "sync_timestamp": datetime.now().isoformat(),
                "status": "SUCCESS"
            }
            
            # Cache do resultado
            cache_key = f"sync_result:{catalog_name}"
            self.redis_client.setex(cache_key, 3600, str(result))  # Cache por 1 hora
            
            self.logger.info(f"Metadata sync completed: {result}")
            return result
            
        except Exception as e:
            self.logger.error(f"Metadata sync failed for catalog {catalog_name}: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Sync failed: {str(e)}"
            )
    
    async def _store_table_metadata(self, table_info: Dict[str, Any]):
        """Armazena metadados de tabela no banco"""
        async with self.db_pool.acquire() as conn:
            # Insere ou atualiza metadados da tabela
            await conn.execute("""
                INSERT INTO databricks_tables (
                    catalog_name, schema_name, table_name, table_type,
                    owner, comment, columns_info, created_at, updated_at
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
                ON CONFLICT (catalog_name, schema_name, table_name) 
                DO UPDATE SET
                    table_type = EXCLUDED.table_type,
                    owner = EXCLUDED.owner,
                    comment = EXCLUDED.comment,
                    columns_info = EXCLUDED.columns_info,
                    updated_at = EXCLUDED.updated_at
            """, 
                table_info["catalog_name"],
                table_info["schema_name"], 
                table_info["table_name"],
                table_info["table_type"],
                table_info.get("owner"),
                table_info.get("comment"),
                str(table_info["columns"]),  # JSON como string
                datetime.now(),
                datetime.now()
            )
    
    async def _store_classification(self, classification: Dict[str, Any]):
        """Armazena classificação no banco"""
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO databricks_classifications (
                    table_name, column_name, classification_type, 
                    confidence, rationale, scan_timestamp, created_at
                ) VALUES ($1, $2, $3, $4, $5, $6, $7)
                ON CONFLICT (table_name, column_name, classification_type)
                DO UPDATE SET
                    confidence = EXCLUDED.confidence,
                    rationale = EXCLUDED.rationale,
                    scan_timestamp = EXCLUDED.scan_timestamp,
                    created_at = EXCLUDED.created_at
            """,
                classification["table_name"],
                classification["column_name"],
                classification["classification_type"],
                classification["confidence"],
                classification["rationale"],
                datetime.fromisoformat(classification["scan_timestamp"].replace('Z', '+00:00')),
                datetime.now()
            )
    
    async def create_quality_monitor(self, monitor_request: QualityMonitor) -> Dict[str, Any]:
        """Cria monitor de qualidade no Databricks"""
        self.logger.info(f"Creating quality monitor for table: {monitor_request.table_name}")
        
        try:
            # Converte regras para formato Databricks
            databricks_rules = []
            for rule in monitor_request.rules:
                databricks_rules.append({
                    "rule_type": rule.rule_type,
                    "column": rule.column,
                    "parameters": rule.parameters or {},
                    "threshold": rule.threshold
                })
            
            # Cria monitor no Databricks
            monitor = await self.client.create_quality_monitor(
                monitor_request.table_name,
                databricks_rules
            )
            
            # Armazena informações do monitor no banco
            async with self.db_pool.acquire() as conn:
                await conn.execute("""
                    INSERT INTO databricks_quality_monitors (
                        monitor_id, table_name, rules, schedule, 
                        alert_threshold, status, created_at
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7)
                """,
                    monitor["monitor_id"],
                    monitor_request.table_name,
                    str(databricks_rules),  # JSON como string
                    monitor_request.schedule,
                    monitor_request.alert_threshold,
                    monitor["status"],
                    datetime.now()
                )
            
            self.logger.info(f"Quality monitor created: {monitor['monitor_id']}")
            return monitor
            
        except Exception as e:
            self.logger.error(f"Failed to create quality monitor: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Monitor creation failed: {str(e)}"
            )
    
    async def get_quality_metrics(self, monitor_id: str) -> Dict[str, Any]:
        """Obtém métricas de qualidade de um monitor"""
        try:
            metrics = await self.client.get_quality_metrics(monitor_id)
            
            # Cache das métricas
            cache_key = f"quality_metrics:{monitor_id}"
            self.redis_client.setex(cache_key, 300, str(metrics))  # Cache por 5 minutos
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"Failed to get quality metrics for {monitor_id}: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to get metrics: {str(e)}"
            )

# Instância global do serviço
service = DatabricksIntegrationService()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gerencia ciclo de vida da aplicação"""
    # Startup
    await service.initialize()
    yield
    # Shutdown
    await service.cleanup()

# Configuração da aplicação FastAPI
app = FastAPI(
    title="Databricks Integration Service",
    description="Microserviço para integração com Databricks Unity Catalog, Data Classification e Lakehouse Monitoring",
    version="1.0.0",
    lifespan=lifespan
)

# Middleware CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Endpoints de Health Check
@app.get("/health", tags=["Health"])
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "databricks-integration-service",
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0"
    }

@app.get("/health/detailed", tags=["Health"])
async def detailed_health_check():
    """Detailed health check with dependencies"""
    health_status = {
        "status": "healthy",
        "service": "databricks-integration-service",
        "timestamp": datetime.now().isoformat(),
        "dependencies": {
            "databricks": "unknown",
            "database": "unknown", 
            "cache": "unknown"
        }
    }
    
    # Testa Databricks
    try:
        catalogs = await service.client.list_catalogs()
        health_status["dependencies"]["databricks"] = "healthy"
    except Exception:
        health_status["dependencies"]["databricks"] = "unhealthy"
        health_status["status"] = "degraded"
    
    # Testa Database
    try:
        if service.db_pool:
            async with service.db_pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
            health_status["dependencies"]["database"] = "healthy"
    except Exception:
        health_status["dependencies"]["database"] = "unhealthy"
        health_status["status"] = "degraded"
    
    # Testa Cache
    try:
        if service.redis_client:
            service.redis_client.ping()
            health_status["dependencies"]["cache"] = "healthy"
    except Exception:
        health_status["dependencies"]["cache"] = "unhealthy"
        health_status["status"] = "degraded"
    
    return health_status

# Endpoints de Configuração
@app.get("/api/v1/config", tags=["Configuration"])
async def get_configuration():
    """Obtém configuração atual (sem dados sensíveis)"""
    return {
        "host": service.config.host,
        "workspace_id": service.config.workspace_id,
        "catalog_name": service.config.catalog_name,
        "token_configured": bool(service.config.token)
    }

# Endpoints de Catálogos
@app.get("/api/v1/catalogs", tags=["Catalogs"])
async def list_catalogs():
    """Lista catálogos disponíveis no Databricks"""
    try:
        catalogs = await service.client.list_catalogs()
        return {
            "catalogs": catalogs,
            "count": len(catalogs),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list catalogs: {str(e)}"
        )

@app.get("/api/v1/catalogs/{catalog_name}/schemas", tags=["Catalogs"])
async def list_schemas(catalog_name: str):
    """Lista schemas de um catálogo"""
    try:
        schemas = await service.client.list_schemas(catalog_name)
        return {
            "catalog_name": catalog_name,
            "schemas": schemas,
            "count": len(schemas),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list schemas: {str(e)}"
        )

@app.get("/api/v1/catalogs/{catalog_name}/schemas/{schema_name}/tables", tags=["Catalogs"])
async def list_tables(catalog_name: str, schema_name: str):
    """Lista tabelas de um schema"""
    try:
        tables = await service.client.list_tables(catalog_name, schema_name)
        return {
            "catalog_name": catalog_name,
            "schema_name": schema_name,
            "tables": tables,
            "count": len(tables),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to list tables: {str(e)}"
        )

# Endpoints de Sincronização
@app.post("/api/v1/sync", tags=["Synchronization"])
async def sync_metadata(sync_request: SyncRequest, background_tasks: BackgroundTasks):
    """Sincroniza metadados do Databricks"""
    if sync_request.sync_type == "all":
        # Executa sincronização em background
        background_tasks.add_task(
            service.sync_catalog_metadata,
            sync_request.catalog_name
        )
        
        return {
            "message": "Synchronization started",
            "catalog_name": sync_request.catalog_name,
            "sync_type": sync_request.sync_type,
            "status": "IN_PROGRESS",
            "timestamp": datetime.now().isoformat()
        }
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only 'all' sync_type is currently supported"
        )

@app.get("/api/v1/sync/status/{catalog_name}", tags=["Synchronization"])
async def get_sync_status(catalog_name: str):
    """Obtém status da sincronização"""
    cache_key = f"sync_result:{catalog_name}"
    cached_result = service.redis_client.get(cache_key)
    
    if cached_result:
        return {
            "status": "COMPLETED",
            "result": eval(cached_result),  # Em produção, usar json.loads
            "timestamp": datetime.now().isoformat()
        }
    else:
        return {
            "status": "NOT_FOUND",
            "message": f"No sync result found for catalog {catalog_name}",
            "timestamp": datetime.now().isoformat()
        }

# Endpoints de Classificação
@app.get("/api/v1/classifications/{catalog_name}/{schema_name}/{table_name}", tags=["Classification"])
async def get_table_classifications(catalog_name: str, schema_name: str, table_name: str):
    """Obtém classificações de uma tabela"""
    try:
        classifications = await service.client.get_table_classifications(catalog_name, schema_name, table_name)
        return {
            "table_name": f"{catalog_name}.{schema_name}.{table_name}",
            "classifications": classifications,
            "count": len(classifications),
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get classifications: {str(e)}"
        )

# Endpoints de Monitoramento de Qualidade
@app.post("/api/v1/quality/monitors", tags=["Quality Monitoring"])
async def create_quality_monitor(monitor_request: QualityMonitor):
    """Cria monitor de qualidade"""
    return await service.create_quality_monitor(monitor_request)

@app.get("/api/v1/quality/monitors/{monitor_id}/metrics", tags=["Quality Monitoring"])
async def get_quality_monitor_metrics(monitor_id: str):
    """Obtém métricas de qualidade de um monitor"""
    return await service.get_quality_metrics(monitor_id)

# Endpoints de Informações
@app.get("/api/v1/tables/{catalog_name}/{schema_name}/{table_name}/info", tags=["Tables"])
async def get_table_info(catalog_name: str, schema_name: str, table_name: str):
    """Obtém informações detalhadas de uma tabela"""
    try:
        table_info = await service.client.get_table_info(catalog_name, schema_name, table_name)
        return table_info
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get table info: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    
    port = int(os.getenv("PORT", "8008"))
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=port,
        reload=True,
        log_level="info"
    )

