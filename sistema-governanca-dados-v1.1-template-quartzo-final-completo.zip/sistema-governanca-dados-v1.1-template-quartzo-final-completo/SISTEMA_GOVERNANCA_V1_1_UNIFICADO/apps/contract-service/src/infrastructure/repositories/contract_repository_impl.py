# Autor: carlos.morais@f1rst.com.br
"""
Contract Repository Implementation using Central Database
"""

from typing import List, Optional, Dict, Any
from uuid import UUID
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, asc, func, text

from ...domain.entities.contract import Contract
from ...domain.repositories.contract_repository import ContractRepository
from ...domain.value_objects.contract_status import ContractStatus
from ..models.contract_model import (
    ContractModel, ContractApprovalModel, PIIClassificationModel,
    UserModel, DatasetModel, OrganizationModel
)
from ..database import get_db


class ContractRepositoryImpl(ContractRepository):
    """
    SQLAlchemy implementation of Contract Repository using central database
    """
    
    def __init__(self, db_session: Session):
        self.db = db_session
    
    async def save(self, contract: Contract) -> Contract:
        """Save contract to central database"""
        try:
            # Check if contract exists
            existing = self.db.query(ContractModel).filter(
                ContractModel.id == contract.id
            ).first()
            
            if existing:
                # Update existing contract
                self._update_model_from_entity(existing, contract)
            else:
                # Create new contract
                contract_model = self._create_model_from_entity(contract)
                self.db.add(contract_model)
            
            self.db.commit()
            return contract
            
        except Exception as e:
            self.db.rollback()
            raise Exception(f"Error saving contract: {str(e)}")
    
    async def find_by_id(self, contract_id: UUID) -> Optional[Contract]:
        """Executa operação find_by_id."""
        """Find contract by ID"""
        try:
            contract_model = self.db.query(ContractModel).filter(
                and_(
                    ContractModel.id == contract_id,
                    ContractModel.deleted_at.is_(None)
                )
            ).first()
            
            if not contract_model:
                return None
            
            return self._create_entity_from_model(contract_model)
            
        except Exception as e:
            raise Exception(f"Error finding contract by ID: {str(e)}")
    
    async def find_by_name(self, name: str, organization_id: UUID) -> Optional[Contract]:
        """Find contract by name within organization"""
        try:
            contract_model = self.db.query(ContractModel).filter(
                and_(
                    ContractModel.name == name,
                    ContractModel.organization_id == organization_id,
                    ContractModel.deleted_at.is_(None)
                )
            ).first()
            
            if not contract_model:
                return None
            
            return self._create_entity_from_model(contract_model)
            
        except Exception as e:
            raise Exception(f"Error finding contract by name: {str(e)}")
    
    async def find_all(
        """Executa operação find_all."""
        self, 
        organization_id: Optional[UUID] = None,
        status: Optional[ContractStatus] = None,
        contains_pii: Optional[bool] = None,
        owner_id: Optional[UUID] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[Contract]:
        """Find contracts with filters"""
        try:
            query = self.db.query(ContractModel).filter(
                ContractModel.deleted_at.is_(None)
            )
            
            # Apply filters
            if organization_id:
                query = query.filter(ContractModel.organization_id == organization_id)
            
            if status:
                query = query.filter(ContractModel.status == status.value)
            
            if contains_pii is not None:
                query = query.filter(ContractModel.contains_pii == contains_pii)
            
            if owner_id:
                query = query.filter(ContractModel.owner_id == owner_id)
            
            # Apply pagination and ordering
            query = query.order_by(desc(ContractModel.updated_at))
            query = query.offset(offset).limit(limit)
            
            contract_models = query.all()
            
            return [
                self._create_entity_from_model(model) 
                for model in contract_models
            ]
            
        except Exception as e:
            raise Exception(f"Error finding contracts: {str(e)}")
    
    async def find_by_owner(self, owner_id: UUID) -> List[Contract]:
        """Find contracts by owner"""
        try:
            contract_models = self.db.query(ContractModel).filter(
                and_(
                    ContractModel.owner_id == owner_id,
                    ContractModel.deleted_at.is_(None)
                )
            ).order_by(desc(ContractModel.updated_at)).all()
            
            return [
                self._create_entity_from_model(model) 
                for model in contract_models
            ]
            
        except Exception as e:
            raise Exception(f"Error finding contracts by owner: {str(e)}")
    
    async def find_active_contracts(self, organization_id: UUID) -> List[Contract]:
        """Find active contracts in organization"""
        try:
            contract_models = self.db.query(ContractModel).filter(
                and_(
                    ContractModel.organization_id == organization_id,
                    ContractModel.is_active == True,
                    ContractModel.status == 'active',
                    ContractModel.deleted_at.is_(None)
                )
            ).order_by(desc(ContractModel.updated_at)).all()
            
            return [
                self._create_entity_from_model(model) 
                for model in contract_models
            ]
            
        except Exception as e:
            raise Exception(f"Error finding active contracts: {str(e)}")
    
    async def find_contracts_with_pii(self, organization_id: UUID) -> List[Contract]:
        """Find contracts containing PII"""
        try:
            contract_models = self.db.query(ContractModel).filter(
                and_(
                    ContractModel.organization_id == organization_id,
                    ContractModel.contains_pii == True,
                    ContractModel.deleted_at.is_(None)
                )
            ).order_by(desc(ContractModel.updated_at)).all()
            
            return [
                self._create_entity_from_model(model) 
                for model in contract_models
            ]
            
        except Exception as e:
            raise Exception(f"Error finding contracts with PII: {str(e)}")
    
    async def find_contracts_needing_approval(self, approver_id: UUID) -> List[Contract]:
        """Find contracts needing approval from specific approver"""
        try:
            # Find contracts with pending approvals for this approver
            contract_models = self.db.query(ContractModel).join(
                ContractApprovalModel
            ).filter(
                and_(
                    ContractApprovalModel.approver_id == approver_id,
                    ContractApprovalModel.status == "pending",
                    ContractModel.deleted_at.is_(None)
                )
            ).order_by(desc(ContractApprovalModel.requested_at)).all()
            
            return [
                self._create_entity_from_model(model) 
                for model in contract_models
            ]
            
        except Exception as e:
            raise Exception(f"Error finding contracts needing approval: {str(e)}")
    
    async def search_contracts(
        self, 
        search_term: str, 
        organization_id: UUID,
        limit: int = 50
    ) -> List[Contract]:
        """Search contracts by name, title, or description"""
        try:
            search_pattern = f"%{search_term}%"
            
            contract_models = self.db.query(ContractModel).filter(
                and_(
                    ContractModel.organization_id == organization_id,
                    ContractModel.deleted_at.is_(None),
                    or_(
                        ContractModel.name.ilike(search_pattern),
                        ContractModel.title.ilike(search_pattern),
                        ContractModel.description.ilike(search_pattern)
                    )
                )
            ).order_by(desc(ContractModel.updated_at)).limit(limit).all()
            
            return [
                self._create_entity_from_model(model) 
                for model in contract_models
            ]
            
        except Exception as e:
            raise Exception(f"Error searching contracts: {str(e)}")
    
    async def delete(self, contract_id: UUID) -> bool:
        """Soft delete contract"""
        try:
            contract_model = self.db.query(ContractModel).filter(
                ContractModel.id == contract_id
            ).first()
            
            if not contract_model:
                return False
            
            contract_model.deleted_at = datetime.utcnow()
            self.db.commit()
            return True
            
        except Exception as e:
            self.db.rollback()
            raise Exception(f"Error deleting contract: {str(e)}")
    
    async def get_statistics(self, organization_id: UUID) -> Dict[str, Any]:
        """Get contract statistics for organization"""
        try:
            total_contracts = self.db.query(func.count(ContractModel.id)).filter(
                and_(
                    ContractModel.organization_id == organization_id,
                    ContractModel.deleted_at.is_(None)
                )
            ).scalar()
            
            active_contracts = self.db.query(func.count(ContractModel.id)).filter(
                and_(
                    ContractModel.organization_id == organization_id,
                    ContractModel.is_active == True,
                    ContractModel.deleted_at.is_(None)
                )
            ).scalar()
            
            contracts_with_pii = self.db.query(func.count(ContractModel.id)).filter(
                and_(
                    ContractModel.organization_id == organization_id,
                    ContractModel.contains_pii == True,
                    ContractModel.deleted_at.is_(None)
                )
            ).scalar()
            
            avg_compliance_score = self.db.query(
                func.avg(ContractModel.lgpd_compliance_score)
            ).filter(
                and_(
                    ContractModel.organization_id == organization_id,
                    ContractModel.deleted_at.is_(None)
                )
            ).scalar() or 0.0
            
            avg_quality_score = self.db.query(
                func.avg(ContractModel.quality_score)
            ).filter(
                and_(
                    ContractModel.organization_id == organization_id,
                    ContractModel.deleted_at.is_(None)
                )
            ).scalar() or 0.0
            
            return {
                "total_contracts": total_contracts,
                "active_contracts": active_contracts,
                "draft_contracts": total_contracts - active_contracts,
                "contracts_with_pii": contracts_with_pii,
                "average_compliance_score": float(avg_compliance_score),
                "average_quality_score": float(avg_quality_score)
            }
            
        except Exception as e:
            raise Exception(f"Error getting contract statistics: {str(e)}")
    
    def _create_model_from_entity(self, contract: Contract) -> ContractModel:
        """Convert Contract entity to ContractModel"""
        return ContractModel(
            id=contract.id,
            name=contract.name,
            title=contract.title,
            description=contract.description,
            version=contract.version,
            status=contract.status.value if contract.status else "draft",
            is_active=contract.is_active,
            schema_definition=contract.schema_definition,
            schema_hash=contract.schema_hash,
            data_classification=contract.data_classification.value if contract.data_classification else "internal",
            contains_pii=contract.contains_pii,
            pii_fields=contract.pii_fields,
            owner_id=contract.owner_id,
            organization_id=contract.organization_id,
            approval_status=contract.approval_status,
            approved_by=contract.approved_by,
            approved_at=contract.approved_at,
            lgpd_compliance_status=contract.lgpd_compliance.status.value if contract.lgpd_compliance else "unknown",
            lgpd_compliance_score=contract.lgpd_compliance.score if contract.lgpd_compliance else 0.0,
            last_compliance_check=contract.lgpd_compliance.last_assessment if contract.lgpd_compliance else None,
            quality_score=contract.quality_metrics.get("overall_score", 0.0) if contract.quality_metrics else 0.0,
            completeness_rate=contract.quality_metrics.get("completeness_rate", 0.0) if contract.quality_metrics else 0.0,
            accuracy_rate=contract.quality_metrics.get("accuracy_rate", 0.0) if contract.quality_metrics else 0.0,
            consistency_rate=contract.quality_metrics.get("consistency_rate", 0.0) if contract.quality_metrics else 0.0,
            usage_count=contract.usage_statistics.get("access_count", 0) if contract.usage_statistics else 0,
            last_used_at=contract.usage_statistics.get("last_accessed", None) if contract.usage_statistics else None,
            documentation_url=contract.documentation_url,
            tags=contract.tags,
            created_at=contract.created_at,
            updated_at=contract.updated_at,
            created_by=contract.created_by,
            updated_by=contract.updated_by
        )
    
    def _update_model_from_entity(self, model: ContractModel, contract: Contract) -> None:
        """Update ContractModel from Contract entity"""
        model.name = contract.name
        model.title = contract.title
        model.description = contract.description
        model.version = contract.version
        model.status = contract.status.value if contract.status else "draft"
        model.is_active = contract.is_active
        model.schema_definition = contract.schema_definition
        model.schema_hash = contract.schema_hash
        model.data_classification = contract.data_classification.value if contract.data_classification else "internal"
        model.contains_pii = contract.contains_pii
        model.pii_fields = contract.pii_fields
        model.owner_id = contract.owner_id
        model.organization_id = contract.organization_id
        model.approval_status = contract.approval_status
        model.approved_by = contract.approved_by
        model.approved_at = contract.approved_at
        model.lgpd_compliance_status = contract.lgpd_compliance.status.value if contract.lgpd_compliance else "unknown"
        model.lgpd_compliance_score = contract.lgpd_compliance.score if contract.lgpd_compliance else 0.0
        model.last_compliance_check = contract.lgpd_compliance.last_assessment if contract.lgpd_compliance else None
        model.quality_score = contract.quality_metrics.get("overall_score", 0.0) if contract.quality_metrics else 0.0
        model.completeness_rate = contract.quality_metrics.get("completeness_rate", 0.0) if contract.quality_metrics else 0.0
        model.accuracy_rate = contract.quality_metrics.get("accuracy_rate", 0.0) if contract.quality_metrics else 0.0
        model.consistency_rate = contract.quality_metrics.get("consistency_rate", 0.0) if contract.quality_metrics else 0.0
        model.usage_count = contract.usage_statistics.get("access_count", 0) if contract.usage_statistics else 0
        model.last_used_at = contract.usage_statistics.get("last_accessed", None) if contract.usage_statistics else None
        model.documentation_url = contract.documentation_url
        model.tags = contract.tags
        model.updated_at = contract.updated_at
        model.updated_by = contract.updated_by
    
    def _create_entity_from_model(self, model: ContractModel) -> Contract:
        """Convert ContractModel to Contract entity"""
        from ...domain.value_objects.contract_status import ContractStatus
        from ...domain.value_objects.data_classification import DataClassification
        from ...domain.value_objects.lgpd_compliance import LGPDCompliance, ComplianceStatus
        
        # Create LGPD compliance value object
        lgpd_compliance = LGPDCompliance(
            status=ComplianceStatus(model.lgpd_compliance_status) if model.lgpd_compliance_status else ComplianceStatus.UNKNOWN,
            score=model.lgpd_compliance_score or 0.0,
            last_assessment=model.last_compliance_check,
            requirements_met=[],
            requirements_pending=[]
        )
        
        # Create quality metrics
        quality_metrics = {
            "overall_score": model.quality_score or 0.0,
            "completeness_rate": model.completeness_rate or 0.0,
            "accuracy_rate": model.accuracy_rate or 0.0,
            "consistency_rate": model.consistency_rate or 0.0,
            "last_check": model.last_quality_check
        }
        
        # Create usage statistics
        usage_statistics = {
            "access_count": model.usage_count or 0,
            "last_accessed": model.last_used_at
        }
        
        # Create Contract entity
        contract = Contract(
            id=model.id,
            name=model.name,
            title=model.title,
            description=model.description,
            version=model.version,
            status=ContractStatus(model.status) if model.status else ContractStatus.DRAFT,
            is_active=model.is_active,
            schema_definition=model.schema_definition or {},
            schema_hash=model.schema_hash,
            data_classification=DataClassification(model.data_classification) if model.data_classification else DataClassification.INTERNAL,
            contains_pii=model.contains_pii,
            pii_fields=model.pii_fields or [],
            owner_id=model.owner_id,
            organization_id=model.organization_id,
            approval_status=model.approval_status,
            approved_by=model.approved_by,
            approved_at=model.approved_at,
            lgpd_compliance=lgpd_compliance,
            quality_metrics=quality_metrics,
            usage_statistics=usage_statistics,
            documentation_url=model.documentation_url,
            tags=model.tags or [],
            created_at=model.created_at,
            updated_at=model.updated_at,
            created_by=model.created_by,
            updated_by=model.updated_by
        )
        
        return contract

