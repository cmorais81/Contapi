# Autor: carlos.morais@f1rst.com.br
"""
Controller Aprimorado para Contratos com Validação Automática de Layout Ativo
"""

from datetime import datetime
from typing import List, Optional, Dict, Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.responses import JSONResponse

from ...application.use_cases.create_contract_with_validation import (
    CreateContractWithValidationUseCase,
    UpdateContractWithValidationUseCase,
    ContractValidationException,
    LayoutValidationException
)
from ...application.dtos.contract_dtos import CreateContractRequest, ContractResponse
from ...domain.services.contract_validation_service import ContractValidationService
from ...domain.services.contract_layout_service import ContractLayoutService
from ..middleware.auth_middleware import get_current_user
from ..middleware.correlation_middleware import get_correlation_id


class ContractControllerEnhanced:
    """
    Controller aprimorado para contratos com validação automática
    
    Responsabilidades:
    - Expor endpoints REST para contratos
    - Aplicar validação automática de layout ativo
    - Gerenciar respostas de validação
    - Fornecer feedback detalhado sobre erros
    """
    
    def __init__(self):
        """Inicializa o controller"""
        self.router = APIRouter(prefix="/api/v1/contracts", tags=["Contratos"])
        self._setup_routes()
    
    def _setup_routes(self):
        """Executa operação _setup_routes."""
        """Executa operação _setup_routes."""
        """Configura as rotas do controller"""
        
        @self.router.post(
            "/",
            response_model=ContractResponse,
            status_code=status.HTTP_201_CREATED,
            summary="Criar contrato com validação automática",
            description="Cria um novo contrato com validação automática de layout ativo e regras de negócio"
        )
        async def create_contract_with_validation(
            """Executa operação create_contract_with_validation."""
            """Executa operação create_contract_with_validation."""
            request: CreateContractRequest,
            current_user: dict = Depends(get_current_user),
            correlation_id: str = Depends(get_correlation_id),
            create_use_case: CreateContractWithValidationUseCase = Depends(self._get_create_use_case)
        ):
            """
            Cria um novo contrato com validação automática completa
            
            Args:
                request: Dados do contrato
                current_user: Usuário autenticado
                correlation_id: ID de correlação
                create_use_case: Use case de criação
                
            Returns:
                ContractResponse: Contrato criado com resultados de validação
                
            Raises:
                HTTPException: Se houver erros de validação ou outros problemas
            """
            try:
                user_id = current_user.get("user_id")
                if not user_id:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="ID do usuário não encontrado no token"
                    )
                
                # Executar criação com validação automática
                response = await create_use_case.execute(request, user_id)
                
                return response
                
            except ContractValidationException as e:
                # Retornar erros de validação com status 422
                return JSONResponse(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    content={
                        "error": "Erro de validação do contrato",
                        "details": e.to_dict(),
                        "correlation_id": correlation_id,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                )
            
            except LayoutValidationException as e:
                # Retornar erros de layout com status 422
                return JSONResponse(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    content={
                        "error": "Erro de validação de layout",
                        "details": e.to_dict(),
                        "correlation_id": correlation_id,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                )
            
            except ValueError as e:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Dados inválidos: {str(e)}"
                )
            
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Erro interno: {str(e)}"
                )
        
        @self.router.put(
            "/{contract_id}",
            response_model=ContractResponse,
            summary="Atualizar contrato com validação automática",
            description="Atualiza um contrato existente com validação automática de layout ativo e verificação de compatibilidade"
        )
        async def update_contract_with_validation(
            contract_id: UUID,
            request: CreateContractRequest,
            current_user: dict = Depends(get_current_user),
            correlation_id: str = Depends(get_correlation_id),
            update_use_case: UpdateContractWithValidationUseCase = Depends(self._get_update_use_case)
        ):
            """
            Atualiza um contrato com validação automática completa
            
            Args:
                contract_id: ID do contrato a ser atualizado
                request: Dados da atualização
                current_user: Usuário autenticado
                correlation_id: ID de correlação
                update_use_case: Use case de atualização
                
            Returns:
                ContractResponse: Contrato atualizado com resultados de validação
            """
            try:
                user_id = current_user.get("user_id")
                if not user_id:
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail="ID do usuário não encontrado no token"
                    )
                
                # Executar atualização com validação automática
                response = await update_use_case.execute(contract_id, request, user_id)
                
                return response
                
            except ContractValidationException as e:
                return JSONResponse(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    content={
                        "error": "Erro de validação do contrato",
                        "details": e.to_dict(),
                        "correlation_id": correlation_id,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                )
            
            except LayoutValidationException as e:
                return JSONResponse(
                    status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                    content={
                        "error": "Erro de validação de layout",
                        "details": e.to_dict(),
                        "correlation_id": correlation_id,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                )
            
            except Exception as e:
                if "não encontrado" in str(e):
                    raise HTTPException(
                        status_code=status.HTTP_404_NOT_FOUND,
                        detail=str(e)
                    )
                else:
                    raise HTTPException(
                        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                        detail=f"Erro interno: {str(e)}"
                    )
        
        @self.router.post(
            "/validate",
            summary="Validar contrato sem persistir",
            description="Executa validação completa de um contrato sem persistir no banco de dados"
        )
        async def validate_contract_only(
            request: CreateContractRequest,
            current_user: dict = Depends(get_current_user),
            correlation_id: str = Depends(get_correlation_id),
            validation_service: ContractValidationService = Depends(self._get_validation_service),
            layout_service: ContractLayoutService = Depends(self._get_layout_service)
        ):
            """
            Valida um contrato sem persistir
            
            Args:
                request: Dados do contrato
                current_user: Usuário autenticado
                correlation_id: ID de correlação
                validation_service: Serviço de validação
                layout_service: Serviço de layout
                
            Returns:
                Dict: Resultados da validação
            """
            try:
                user_id = current_user.get("user_id")
                
                # Criar contrato temporário para validação
                from ...application.use_cases.create_contract_with_validation import CreateContractWithValidationUseCase
                temp_contract = CreateContractWithValidationUseCase(
                    None, validation_service, layout_service, None, None
                )._create_contract_from_request(request, user_id)
                
                # Executar validações
                validation_errors = validation_service.validate_contract(temp_contract)
                layout_result = layout_service.validate_layout(temp_contract)
                
                # Calcular scores
                validation_score = self._calculate_validation_score(validation_errors, layout_result)
                
                return {
                    "is_valid": len([e for e in validation_errors if e.severity == "error"]) == 0 and layout_result.is_valid,
                    "validation_score": validation_score,
                    "validation_errors": [error.to_dict() for error in validation_errors],
                    "layout_validation": layout_result.to_dict(),
                    "summary": {
                        "total_errors": len([e for e in validation_errors if e.severity == "error"]) + len(layout_result.errors),
                        "total_warnings": len([e for e in validation_errors if e.severity == "warning"]) + len(layout_result.warnings),
                        "total_suggestions": len([e for e in validation_errors if e.severity == "info"]) + len(layout_result.suggestions)
                    },
                    "correlation_id": correlation_id,
                    "timestamp": datetime.utcnow().isoformat()
                }
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Erro na validação: {str(e)}"
                )
        
        @self.router.post(
            "/check-compatibility",
            summary="Verificar compatibilidade entre versões",
            description="Verifica compatibilidade entre duas versões de contrato"
        )
        async def check_contract_compatibility(
            old_contract_request: CreateContractRequest,
            new_contract_request: CreateContractRequest,
            current_user: dict = Depends(get_current_user),
            correlation_id: str = Depends(get_correlation_id),
            layout_service: ContractLayoutService = Depends(self._get_layout_service)
        ):
            """
            Verifica compatibilidade entre versões de contrato
            
            Args:
                old_contract_request: Versão anterior
                new_contract_request: Nova versão
                current_user: Usuário autenticado
                correlation_id: ID de correlação
                layout_service: Serviço de layout
                
            Returns:
                Dict: Resultado da verificação de compatibilidade
            """
            try:
                user_id = current_user.get("user_id")
                
                # Criar contratos temporários
                from ...application.use_cases.create_contract_with_validation import CreateContractWithValidationUseCase
                temp_use_case = CreateContractWithValidationUseCase(None, None, layout_service, None, None)
                
                old_contract = temp_use_case._create_contract_from_request(old_contract_request, user_id)
                new_contract = temp_use_case._create_contract_from_request(new_contract_request, user_id)
                
                # Verificar compatibilidade
                compatibility_result = layout_service.check_compatibility(old_contract, new_contract)
                
                # Identificar breaking changes
                breaking_changes = [
                    error for error in compatibility_result.errors 
                    if "breaking" in error.get("message", "").lower()
                ]
                
                return {
                    "is_compatible": compatibility_result.is_valid and len(breaking_changes) == 0,
                    "compatibility_score": compatibility_result.compatibility_score,
                    "breaking_changes": breaking_changes,
                    "compatibility_result": compatibility_result.to_dict(),
                    "recommendations": self._generate_compatibility_recommendations(compatibility_result),
                    "correlation_id": correlation_id,
                    "timestamp": datetime.utcnow().isoformat()
                }
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Erro na verificação de compatibilidade: {str(e)}"
                )
        
        @self.router.get(
            "/{contract_id}/validation-history",
            summary="Histórico de validações",
            description="Obtém histórico de validações de um contrato"
        )
        async def get_validation_history(
            contract_id: UUID,
            current_user: dict = Depends(get_current_user),
            audit_service = Depends(self._get_audit_service)
        ):
            """
            Obtém histórico de validações de um contrato
            
            Args:
                contract_id: ID do contrato
                current_user: Usuário autenticado
                audit_service: Serviço de auditoria
                
            Returns:
                Dict: Histórico de validações
            """
            try:
                # Buscar eventos de validação no audit service
                validation_events = await audit_service.get_contract_validation_events(str(contract_id))
                
                return {
                    "contract_id": str(contract_id),
                    "validation_events": validation_events,
                    "total_validations": len(validation_events),
                    "timestamp": datetime.utcnow().isoformat()
                }
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Erro ao obter histórico: {str(e)}"
                )
        
        @self.router.get(
            "/validation-metrics",
            summary="Métricas de validação",
            description="Obtém métricas agregadas de validação de contratos"
        )
        async def get_validation_metrics(
            start_date: Optional[datetime] = None,
            end_date: Optional[datetime] = None,
            current_user: dict = Depends(get_current_user),
            audit_service = Depends(self._get_audit_service)
        ):
            """
            Obtém métricas de validação
            
            Args:
                start_date: Data inicial
                end_date: Data final
                current_user: Usuário autenticado
                audit_service: Serviço de auditoria
                
            Returns:
                Dict: Métricas de validação
            """
            try:
                # Definir período padrão se não fornecido
                if not end_date:
                    end_date = datetime.utcnow()
                if not start_date:
                    start_date = datetime.utcnow().replace(day=1)  # Início do mês
                
                # Obter métricas do audit service
                metrics = await audit_service.get_validation_metrics(start_date, end_date)
                
                return {
                    "period": {
                        "start_date": start_date.isoformat(),
                        "end_date": end_date.isoformat()
                    },
                    "metrics": metrics,
                    "timestamp": datetime.utcnow().isoformat()
                }
                
            except Exception as e:
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail=f"Erro ao obter métricas: {str(e)}"
                )
    
    def _calculate_validation_score(self, validation_errors, layout_result) -> float:
        """Calcula score de validação"""
        score = 100.0
        
        for error in validation_errors:
            if error.severity == "error":
                score -= 20
            elif error.severity == "warning":
                score -= 5
            elif error.severity == "info":
                score -= 1
        
        score -= len(layout_result.errors) * 15
        score -= len(layout_result.warnings) * 3
        
        return max(0.0, min(100.0, score))
    
    def _generate_compatibility_recommendations(self, compatibility_result) -> List[str]:
        """Gera recomendações baseadas no resultado de compatibilidade"""
        recommendations = []
        
        if compatibility_result.compatibility_score < 80:
            recommendations.append("Considere revisar as mudanças para melhorar a compatibilidade")
        
        if len(compatibility_result.errors) > 0:
            recommendations.append("Corrija os erros identificados antes de prosseguir")
        
        if len(compatibility_result.warnings) > 0:
            recommendations.append("Revise os avisos para evitar problemas futuros")
        
        if len(compatibility_result.suggestions) > 0:
            recommendations.append("Considere implementar as sugestões de melhoria")
        
        return recommendations
    
    def _get_create_use_case(self) -> CreateContractWithValidationUseCase:
        """Dependency injection para CreateContractWithValidationUseCase"""
        # Em produção, isso seria injetado via container DI
        return None  # Placeholder
    
    def _get_update_use_case(self) -> UpdateContractWithValidationUseCase:
        """Dependency injection para UpdateContractWithValidationUseCase"""
        # Em produção, isso seria injetado via container DI
        return None  # Placeholder
    
    def _get_validation_service(self) -> ContractValidationService:
        """Dependency injection para ContractValidationService"""
        return ContractValidationService()
    
    def _get_layout_service(self) -> ContractLayoutService:
        """Dependency injection para ContractLayoutService"""
        return ContractLayoutService()
    
    def _get_audit_service(self):
        """Dependency injection para audit service"""
        # Em produção, isso seria injetado via container DI
        return None  # Placeholder


# Instância global do controller
contract_controller_enhanced = ContractControllerEnhanced()

# Router para ser incluído na aplicação principal
router = contract_controller_enhanced.router

