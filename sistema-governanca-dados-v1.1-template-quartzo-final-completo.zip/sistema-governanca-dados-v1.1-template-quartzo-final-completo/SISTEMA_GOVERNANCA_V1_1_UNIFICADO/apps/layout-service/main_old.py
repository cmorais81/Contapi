"""
Layout Service - Sistema de Governança de Dados V1.1
Microserviço responsável pelo gerenciamento de layouts de contratos e multi-tenancy
"""

from fastapi import FastAPI, HTTPException, Depends, Query, Path
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, validator
from typing import List, Optional, Dict, Any
import asyncpg
import json
import os
import logging
from datetime import datetime
from uuid import UUID, uuid4
import asyncio

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuração da aplicação
app = FastAPI(
    title="Layout Service V4.0",
    description="Serviço de gerenciamento de layouts e multi-tenancy",
    version="4.0.0",
    openapi_tags=[
        {"name": "layouts", "description": "Operações com layouts de contratos"},
        {"name": "tenants", "description": "Operações com tenants"},
        {"name": "assignments", "description": "Associações entre contratos e layouts"},
        {"name": "migrations", "description": "Migrações de layout"}
    ]
)

# Configuração CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configuração do banco de dados
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://governance_user:governance_pass@localhost:5432/governance_db")

# Pool de conexões do banco
db_pool = None

# =====================================================
# MODELOS PYDANTIC
# =====================================================

class TenantCreate(BaseModel):
    """Modelo para criação de tenant"""
    name: str = Field(..., min_length=1, max_length=255, description="Nome do tenant")
    slug: str = Field(..., min_length=1, max_length=100, description="Slug único do tenant")
    description: Optional[str] = Field(None, description="Descrição do tenant")
    settings: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Configurações do tenant")
    
    @validator('slug')
    def validate_slug(cls, v):
        """Valida formato do slug"""
        if not v.replace('-', '').replace('_', '').isalnum():
            raise ValueError('Slug deve conter apenas letras, números, hífens e underscores')
        return v.lower()

class TenantResponse(BaseModel):
    """Modelo de resposta para tenant"""
    id: UUID
    name: str
    slug: str
    description: Optional[str]
    settings: Dict[str, Any]
    is_active: bool
    created_at: datetime
    updated_at: datetime

class LayoutCreate(BaseModel):
    """Modelo para criação de layout"""
    name: str = Field(..., min_length=1, max_length=255, description="Nome do layout")
    description: Optional[str] = Field(None, description="Descrição do layout")
    layout_type: str = Field("default", description="Tipo do layout")
    version: str = Field("1.0.0", description="Versão do layout")
    schema_definition: Dict[str, Any] = Field(..., description="Definição do schema")
    ui_configuration: Dict[str, Any] = Field(..., description="Configuração da interface")
    is_default: bool = Field(False, description="Se é o layout padrão")
    
    @validator('layout_type')
    def validate_layout_type(cls, v):
        """Valida tipo do layout"""
        allowed_types = ['default', 'mobile', 'print', 'executive', 'custom']
        if v not in allowed_types:
            raise ValueError(f'Tipo deve ser um dos: {", ".join(allowed_types)}')
        return v

class LayoutResponse(BaseModel):
    """Modelo de resposta para layout"""
    id: UUID
    tenant_id: UUID
    name: str
    description: Optional[str]
    layout_type: str
    version: str
    schema_definition: Dict[str, Any]
    ui_configuration: Dict[str, Any]
    is_active: bool
    is_default: bool
    created_by: Optional[UUID]
    created_at: datetime
    updated_at: datetime

class LayoutAssignmentCreate(BaseModel):
    """Modelo para associação de layout"""
    contract_id: UUID = Field(..., description="ID do contrato")
    layout_id: UUID = Field(..., description="ID do layout")
    is_primary: bool = Field(False, description="Se é o layout primário")

class LayoutAssignmentResponse(BaseModel):
    """Modelo de resposta para associação"""
    id: UUID
    contract_id: UUID
    layout_id: UUID
    tenant_id: UUID
    is_primary: bool
    assigned_at: datetime
    assigned_by: Optional[UUID]

class ContractLayoutInfo(BaseModel):
    """Informações de layout de um contrato"""
    layout_id: UUID
    layout_name: str
    layout_type: str
    version: str
    is_primary: bool
    ui_configuration: Dict[str, Any]

class LayoutMigrationCreate(BaseModel):
    """Modelo para criação de migração"""
    source_layout_id: Optional[UUID] = Field(None, description="Layout de origem")
    target_layout_id: UUID = Field(..., description="Layout de destino")
    job_type: str = Field("gradual_migration", description="Tipo de migração")
    contract_ids: Optional[List[UUID]] = Field(None, description="IDs específicos de contratos")
    
    @validator('job_type')
    def validate_job_type(cls, v):
        """Valida tipo de job"""
        allowed_types = ['full_migration', 'gradual_migration', 'rollback']
        if v not in allowed_types:
            raise ValueError(f'Tipo deve ser um dos: {", ".join(allowed_types)}')
        return v

class MigrationJobResponse(BaseModel):
    """Modelo de resposta para job de migração"""
    id: UUID
    tenant_id: UUID
    source_layout_id: Optional[UUID]
    target_layout_id: UUID
    job_type: str
    status: str
    total_contracts: int
    processed_contracts: int
    failed_contracts: int
    error_details: Optional[Dict[str, Any]]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_by: Optional[UUID]
    created_at: datetime

# =====================================================
# DEPENDÊNCIAS
# =====================================================

async def get_db_connection():
    """Obtém conexão com o banco de dados"""
    global db_pool
    if db_pool is None:
        db_pool = await asyncpg.create_pool(DATABASE_URL)
    return await db_pool.acquire()

async def get_tenant_id(tenant_slug: str = Query("default", description="Slug do tenant")) -> UUID:
    """Obtém ID do tenant pelo slug"""
    conn = await get_db_connection()
    try:
        tenant = await conn.fetchrow(
            "SELECT id FROM tenants WHERE slug = $1 AND is_active = true",
            tenant_slug
        )
        if not tenant:
            raise HTTPException(status_code=404, detail=f"Tenant '{tenant_slug}' não encontrado")
        return tenant['id']
    finally:
        await db_pool.release(conn)

# =====================================================
# ENDPOINTS - TENANTS
# =====================================================

@app.get("/", tags=["root"])
async def root():
    """Endpoint raiz do serviço"""
    return {
        "service": "layout-service",
        "version": "4.0.0",
        "description": "Serviço de gerenciamento de layouts e multi-tenancy",
        "status": "healthy"
    }

@app.get("/health", tags=["root"])
async def health_check():
    """Verificação de saúde do serviço"""
    try:
        conn = await get_db_connection()
        await conn.fetchval("SELECT 1")
        await db_pool.release(conn)
        return {
            "service": "layout-service",
            "status": "healthy",
            "database": "connected",
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return {
            "service": "layout-service",
            "status": "unhealthy",
            "database": "disconnected",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

@app.post("/api/v1/tenants", response_model=TenantResponse, tags=["tenants"])
async def create_tenant(tenant: TenantCreate):
    """Cria um novo tenant"""
    conn = await get_db_connection()
    try:
        # Verificar se slug já existe
        existing = await conn.fetchrow("SELECT id FROM tenants WHERE slug = $1", tenant.slug)
        if existing:
            raise HTTPException(status_code=400, detail=f"Tenant com slug '{tenant.slug}' já existe")
        
        # Inserir novo tenant
        tenant_id = await conn.fetchval("""
            INSERT INTO tenants (name, slug, description, settings)
            VALUES ($1, $2, $3, $4)
            RETURNING id
        """, tenant.name, tenant.slug, tenant.description, json.dumps(tenant.settings))
        
        # Buscar tenant criado
        created_tenant = await conn.fetchrow("""
            SELECT * FROM tenants WHERE id = $1
        """, tenant_id)
        
        return TenantResponse(
            id=created_tenant['id'],
            name=created_tenant['name'],
            slug=created_tenant['slug'],
            description=created_tenant['description'],
            settings=created_tenant['settings'] or {},
            is_active=created_tenant['is_active'],
            created_at=created_tenant['created_at'],
            updated_at=created_tenant['updated_at']
        )
        
    except asyncpg.UniqueViolationError:
        raise HTTPException(status_code=400, detail="Tenant com este slug já existe")
    except Exception as e:
        logger.error(f"Erro ao criar tenant: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

@app.get("/api/v1/tenants", response_model=List[TenantResponse], tags=["tenants"])
async def list_tenants(
    active_only: bool = Query(True, description="Listar apenas tenants ativos"),
    limit: int = Query(50, ge=1, le=100, description="Limite de resultados"),
    offset: int = Query(0, ge=0, description="Offset para paginação")
):
    """Lista todos os tenants"""
    conn = await get_db_connection()
    try:
        where_clause = "WHERE is_active = true" if active_only else ""
        
        tenants = await conn.fetch(f"""
            SELECT * FROM tenants 
            {where_clause}
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
        """, limit, offset)
        
        return [
            TenantResponse(
                id=tenant['id'],
                name=tenant['name'],
                slug=tenant['slug'],
                description=tenant['description'],
                settings=tenant['settings'] or {},
                is_active=tenant['is_active'],
                created_at=tenant['created_at'],
                updated_at=tenant['updated_at']
            )
            for tenant in tenants
        ]
        
    except Exception as e:
        logger.error(f"Erro ao listar tenants: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

@app.get("/api/v1/tenants/{tenant_slug}", response_model=TenantResponse, tags=["tenants"])
async def get_tenant(tenant_slug: str = Path(..., description="Slug do tenant")):
    """Obtém informações de um tenant específico"""
    conn = await get_db_connection()
    try:
        tenant = await conn.fetchrow("""
            SELECT * FROM tenants WHERE slug = $1
        """, tenant_slug)
        
        if not tenant:
            raise HTTPException(status_code=404, detail=f"Tenant '{tenant_slug}' não encontrado")
        
        return TenantResponse(
            id=tenant['id'],
            name=tenant['name'],
            slug=tenant['slug'],
            description=tenant['description'],
            settings=tenant['settings'] or {},
            is_active=tenant['is_active'],
            created_at=tenant['created_at'],
            updated_at=tenant['updated_at']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao buscar tenant: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

# =====================================================
# ENDPOINTS - LAYOUTS
# =====================================================

@app.post("/api/v1/layouts", response_model=LayoutResponse, tags=["layouts"])
async def create_layout(
    layout: LayoutCreate,
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Cria um novo layout para o tenant"""
    conn = await get_db_connection()
    try:
        # Se é layout padrão, desativar outros padrões do mesmo tipo
        if layout.is_default:
            await conn.execute("""
                UPDATE contract_layouts 
                SET is_default = false 
                WHERE tenant_id = $1 AND layout_type = $2
            """, tenant_id, layout.layout_type)
        
        # Inserir novo layout
        layout_id = await conn.fetchval("""
            INSERT INTO contract_layouts (
                tenant_id, name, description, layout_type, version,
                schema_definition, ui_configuration, is_default
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id
        """, 
            tenant_id, layout.name, layout.description, layout.layout_type,
            layout.version, json.dumps(layout.schema_definition),
            json.dumps(layout.ui_configuration), layout.is_default
        )
        
        # Registrar histórico
        await conn.execute("""
            INSERT INTO layout_change_history (
                tenant_id, layout_id, change_type, new_version, changes_summary
            ) VALUES ($1, $2, 'created', $3, $4)
        """, tenant_id, layout_id, layout.version, json.dumps({"action": "layout_created"}))
        
        # Buscar layout criado
        created_layout = await conn.fetchrow("""
            SELECT * FROM contract_layouts WHERE id = $1
        """, layout_id)
        
        return LayoutResponse(
            id=created_layout['id'],
            tenant_id=created_layout['tenant_id'],
            name=created_layout['name'],
            description=created_layout['description'],
            layout_type=created_layout['layout_type'],
            version=created_layout['version'],
            schema_definition=created_layout['schema_definition'],
            ui_configuration=created_layout['ui_configuration'],
            is_active=created_layout['is_active'],
            is_default=created_layout['is_default'],
            created_by=created_layout['created_by'],
            created_at=created_layout['created_at'],
            updated_at=created_layout['updated_at']
        )
        
    except asyncpg.UniqueViolationError:
        raise HTTPException(status_code=400, detail="Layout com este nome e versão já existe para o tenant")
    except Exception as e:
        logger.error(f"Erro ao criar layout: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

@app.get("/api/v1/layouts", response_model=List[LayoutResponse], tags=["layouts"])
async def list_layouts(
    tenant_id: UUID = Depends(get_tenant_id),
    layout_type: Optional[str] = Query(None, description="Filtrar por tipo de layout"),
    active_only: bool = Query(True, description="Listar apenas layouts ativos"),
    limit: int = Query(50, ge=1, le=100, description="Limite de resultados"),
    offset: int = Query(0, ge=0, description="Offset para paginação")
):
    """Lista layouts do tenant"""
    conn = await get_db_connection()
    try:
        conditions = ["tenant_id = $1"]
        params = [tenant_id]
        param_count = 1
        
        if layout_type:
            param_count += 1
            conditions.append(f"layout_type = ${param_count}")
            params.append(layout_type)
        
        if active_only:
            conditions.append("is_active = true")
        
        where_clause = "WHERE " + " AND ".join(conditions)
        
        layouts = await conn.fetch(f"""
            SELECT * FROM contract_layouts 
            {where_clause}
            ORDER BY is_default DESC, layout_type, created_at DESC
            LIMIT ${param_count + 1} OFFSET ${param_count + 2}
        """, *params, limit, offset)
        
        return [
            LayoutResponse(
                id=layout['id'],
                tenant_id=layout['tenant_id'],
                name=layout['name'],
                description=layout['description'],
                layout_type=layout['layout_type'],
                version=layout['version'],
                schema_definition=layout['schema_definition'],
                ui_configuration=layout['ui_configuration'],
                is_active=layout['is_active'],
                is_default=layout['is_default'],
                created_by=layout['created_by'],
                created_at=layout['created_at'],
                updated_at=layout['updated_at']
            )
            for layout in layouts
        ]
        
    except Exception as e:
        logger.error(f"Erro ao listar layouts: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

@app.get("/api/v1/layouts/{layout_id}", response_model=LayoutResponse, tags=["layouts"])
async def get_layout(
    layout_id: UUID = Path(..., description="ID do layout"),
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Obtém um layout específico"""
    conn = await get_db_connection()
    try:
        layout = await conn.fetchrow("""
            SELECT * FROM contract_layouts 
            WHERE id = $1 AND tenant_id = $2
        """, layout_id, tenant_id)
        
        if not layout:
            raise HTTPException(status_code=404, detail="Layout não encontrado")
        
        return LayoutResponse(
            id=layout['id'],
            tenant_id=layout['tenant_id'],
            name=layout['name'],
            description=layout['description'],
            layout_type=layout['layout_type'],
            version=layout['version'],
            schema_definition=layout['schema_definition'],
            ui_configuration=layout['ui_configuration'],
            is_active=layout['is_active'],
            is_default=layout['is_default'],
            created_by=layout['created_by'],
            created_at=layout['created_at'],
            updated_at=layout['updated_at']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao buscar layout: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

# =====================================================
# ENDPOINTS - ASSOCIAÇÕES DE LAYOUT
# =====================================================

@app.post("/api/v1/contracts/{contract_id}/layouts", response_model=LayoutAssignmentResponse, tags=["assignments"])
async def assign_layout_to_contract(
    contract_id: UUID = Path(..., description="ID do contrato"),
    assignment: LayoutAssignmentCreate = None,
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Associa um layout a um contrato"""
    if assignment is None:
        raise HTTPException(status_code=400, detail="Dados de associação são obrigatórios")
    
    conn = await get_db_connection()
    try:
        # Verificar se layout existe e pertence ao tenant
        layout = await conn.fetchrow("""
            SELECT id FROM contract_layouts 
            WHERE id = $1 AND tenant_id = $2 AND is_active = true
        """, assignment.layout_id, tenant_id)
        
        if not layout:
            raise HTTPException(status_code=404, detail="Layout não encontrado ou inativo")
        
        # Se é primário, remover primário de outras associações do contrato
        if assignment.is_primary:
            await conn.execute("""
                UPDATE contract_layout_assignments 
                SET is_primary = false 
                WHERE contract_id = $1 AND tenant_id = $2
            """, contract_id, tenant_id)
        
        # Inserir associação
        assignment_id = await conn.fetchval("""
            INSERT INTO contract_layout_assignments (
                contract_id, layout_id, tenant_id, is_primary
            ) VALUES ($1, $2, $3, $4)
            RETURNING id
        """, contract_id, assignment.layout_id, tenant_id, assignment.is_primary)
        
        # Buscar associação criada
        created_assignment = await conn.fetchrow("""
            SELECT * FROM contract_layout_assignments WHERE id = $1
        """, assignment_id)
        
        return LayoutAssignmentResponse(
            id=created_assignment['id'],
            contract_id=created_assignment['contract_id'],
            layout_id=created_assignment['layout_id'],
            tenant_id=created_assignment['tenant_id'],
            is_primary=created_assignment['is_primary'],
            assigned_at=created_assignment['assigned_at'],
            assigned_by=created_assignment['assigned_by']
        )
        
    except asyncpg.UniqueViolationError:
        raise HTTPException(status_code=400, detail="Layout já está associado a este contrato")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao associar layout: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

@app.get("/api/v1/contracts/{contract_id}/layouts", response_model=List[ContractLayoutInfo], tags=["assignments"])
async def get_contract_layouts(
    contract_id: UUID = Path(..., description="ID do contrato"),
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Obtém todos os layouts associados a um contrato"""
    conn = await get_db_connection()
    try:
        layouts = await conn.fetch("""
            SELECT * FROM get_contract_active_layouts($1, $2)
        """, contract_id, tenant_id)
        
        return [
            ContractLayoutInfo(
                layout_id=layout['layout_id'],
                layout_name=layout['layout_name'],
                layout_type=layout['layout_type'],
                version=layout['version'],
                is_primary=layout['is_primary'],
                ui_configuration=layout['ui_configuration']
            )
            for layout in layouts
        ]
        
    except Exception as e:
        logger.error(f"Erro ao buscar layouts do contrato: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

@app.get("/api/v1/contracts/{contract_id}/layouts/count", tags=["assignments"])
async def count_contract_layouts(
    contract_id: UUID = Path(..., description="ID do contrato"),
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Conta quantos layouts estão associados a um contrato"""
    conn = await get_db_connection()
    try:
        result = await conn.fetchrow("""
            SELECT 
                COUNT(*) as total_layouts,
                COUNT(CASE WHEN cla.is_primary THEN 1 END) as primary_layouts,
                COUNT(CASE WHEN cl.layout_type = 'default' THEN 1 END) as default_layouts,
                COUNT(CASE WHEN cl.layout_type = 'mobile' THEN 1 END) as mobile_layouts,
                COUNT(CASE WHEN cl.layout_type = 'print' THEN 1 END) as print_layouts
            FROM contract_layout_assignments cla
            JOIN contract_layouts cl ON cla.layout_id = cl.id
            WHERE cla.contract_id = $1 AND cla.tenant_id = $2 AND cl.is_active = true
        """, contract_id, tenant_id)
        
        return {
            "contract_id": contract_id,
            "total_layouts": result['total_layouts'],
            "primary_layouts": result['primary_layouts'],
            "layouts_by_type": {
                "default": result['default_layouts'],
                "mobile": result['mobile_layouts'],
                "print": result['print_layouts']
            },
            "has_layouts": result['total_layouts'] > 0
        }
        
    except Exception as e:
        logger.error(f"Erro ao contar layouts: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

# =====================================================
# STARTUP E SHUTDOWN
# =====================================================

@app.on_event("startup")
async def startup_event():
    """Inicialização da aplicação"""
    global db_pool
    try:
        db_pool = await asyncpg.create_pool(DATABASE_URL)
        logger.info("Layout Service iniciado com sucesso")
        logger.info("Pool de conexões do banco criado")
    except Exception as e:
        logger.error(f"Erro na inicialização: {str(e)}")
        raise

@app.on_event("shutdown")
async def shutdown_event():
    """Finalização da aplicação"""
    global db_pool
    if db_pool:
        await db_pool.close()
        logger.info("Pool de conexões fechado")
    logger.info("Layout Service finalizado")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8007)



# =====================================================
# ENDPOINTS - MIGRAÇÕES DE LAYOUT
# =====================================================

@app.post("/api/v1/migrations", response_model=MigrationJobResponse, tags=["migrations"])
async def create_migration_job(
    migration: LayoutMigrationCreate,
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Cria um job de migração de layout"""
    conn = await get_db_connection()
    try:
        # Verificar se layout de destino existe
        target_layout = await conn.fetchrow("""
            SELECT id, name FROM contract_layouts 
            WHERE id = $1 AND tenant_id = $2 AND is_active = true
        """, migration.target_layout_id, tenant_id)
        
        if not target_layout:
            raise HTTPException(status_code=404, detail="Layout de destino não encontrado")
        
        # Verificar layout de origem se especificado
        if migration.source_layout_id:
            source_layout = await conn.fetchrow("""
                SELECT id FROM contract_layouts 
                WHERE id = $1 AND tenant_id = $2
            """, migration.source_layout_id, tenant_id)
            
            if not source_layout:
                raise HTTPException(status_code=404, detail="Layout de origem não encontrado")
        
        # Contar contratos afetados
        if migration.contract_ids:
            # Migração específica de contratos
            total_contracts = len(migration.contract_ids)
        else:
            # Migração geral baseada no layout de origem
            if migration.source_layout_id:
                total_contracts = await conn.fetchval("""
                    SELECT COUNT(DISTINCT cla.contract_id)
                    FROM contract_layout_assignments cla
                    WHERE cla.layout_id = $1 AND cla.tenant_id = $2
                """, migration.source_layout_id, tenant_id)
            else:
                # Migração de todos os contratos do tenant
                total_contracts = await conn.fetchval("""
                    SELECT COUNT(DISTINCT contract_id)
                    FROM contract_layout_assignments
                    WHERE tenant_id = $1
                """, tenant_id)
        
        # Criar job de migração
        job_id = await conn.fetchval("""
            INSERT INTO layout_migration_jobs (
                tenant_id, source_layout_id, target_layout_id, 
                job_type, total_contracts
            ) VALUES ($1, $2, $3, $4, $5)
            RETURNING id
        """, tenant_id, migration.source_layout_id, migration.target_layout_id,
            migration.job_type, total_contracts)
        
        # Buscar job criado
        created_job = await conn.fetchrow("""
            SELECT * FROM layout_migration_jobs WHERE id = $1
        """, job_id)
        
        # Iniciar processamento assíncrono se necessário
        if migration.job_type == "full_migration":
            asyncio.create_task(process_migration_job(job_id, migration.contract_ids))
        
        return MigrationJobResponse(
            id=created_job['id'],
            tenant_id=created_job['tenant_id'],
            source_layout_id=created_job['source_layout_id'],
            target_layout_id=created_job['target_layout_id'],
            job_type=created_job['job_type'],
            status=created_job['status'],
            total_contracts=created_job['total_contracts'],
            processed_contracts=created_job['processed_contracts'],
            failed_contracts=created_job['failed_contracts'],
            error_details=created_job['error_details'],
            started_at=created_job['started_at'],
            completed_at=created_job['completed_at'],
            created_by=created_job['created_by'],
            created_at=created_job['created_at']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar job de migração: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

@app.get("/api/v1/migrations", response_model=List[MigrationJobResponse], tags=["migrations"])
async def list_migration_jobs(
    tenant_id: UUID = Depends(get_tenant_id),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    limit: int = Query(20, ge=1, le=100, description="Limite de resultados"),
    offset: int = Query(0, ge=0, description="Offset para paginação")
):
    """Lista jobs de migração do tenant"""
    conn = await get_db_connection()
    try:
        conditions = ["tenant_id = $1"]
        params = [tenant_id]
        param_count = 1
        
        if status:
            param_count += 1
            conditions.append(f"status = ${param_count}")
            params.append(status)
        
        where_clause = "WHERE " + " AND ".join(conditions)
        
        jobs = await conn.fetch(f"""
            SELECT * FROM layout_migration_jobs 
            {where_clause}
            ORDER BY created_at DESC
            LIMIT ${param_count + 1} OFFSET ${param_count + 2}
        """, *params, limit, offset)
        
        return [
            MigrationJobResponse(
                id=job['id'],
                tenant_id=job['tenant_id'],
                source_layout_id=job['source_layout_id'],
                target_layout_id=job['target_layout_id'],
                job_type=job['job_type'],
                status=job['status'],
                total_contracts=job['total_contracts'],
                processed_contracts=job['processed_contracts'],
                failed_contracts=job['failed_contracts'],
                error_details=job['error_details'],
                started_at=job['started_at'],
                completed_at=job['completed_at'],
                created_by=job['created_by'],
                created_at=job['created_at']
            )
            for job in jobs
        ]
        
    except Exception as e:
        logger.error(f"Erro ao listar jobs de migração: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

@app.get("/api/v1/migrations/{job_id}", response_model=MigrationJobResponse, tags=["migrations"])
async def get_migration_job(
    job_id: UUID = Path(..., description="ID do job de migração"),
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Obtém detalhes de um job de migração"""
    conn = await get_db_connection()
    try:
        job = await conn.fetchrow("""
            SELECT * FROM layout_migration_jobs 
            WHERE id = $1 AND tenant_id = $2
        """, job_id, tenant_id)
        
        if not job:
            raise HTTPException(status_code=404, detail="Job de migração não encontrado")
        
        return MigrationJobResponse(
            id=job['id'],
            tenant_id=job['tenant_id'],
            source_layout_id=job['source_layout_id'],
            target_layout_id=job['target_layout_id'],
            job_type=job['job_type'],
            status=job['status'],
            total_contracts=job['total_contracts'],
            processed_contracts=job['processed_contracts'],
            failed_contracts=job['failed_contracts'],
            error_details=job['error_details'],
            started_at=job['started_at'],
            completed_at=job['completed_at'],
            created_by=job['created_by'],
            created_at=job['created_at']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao buscar job de migração: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

@app.post("/api/v1/migrations/{job_id}/start", tags=["migrations"])
async def start_migration_job(
    job_id: UUID = Path(..., description="ID do job de migração"),
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Inicia execução de um job de migração"""
    conn = await get_db_connection()
    try:
        # Verificar se job existe e está pendente
        job = await conn.fetchrow("""
            SELECT * FROM layout_migration_jobs 
            WHERE id = $1 AND tenant_id = $2 AND status = 'pending'
        """, job_id, tenant_id)
        
        if not job:
            raise HTTPException(status_code=404, detail="Job não encontrado ou não está pendente")
        
        # Atualizar status para running
        await conn.execute("""
            UPDATE layout_migration_jobs 
            SET status = 'running', started_at = CURRENT_TIMESTAMP
            WHERE id = $1
        """, job_id)
        
        # Iniciar processamento assíncrono
        asyncio.create_task(process_migration_job(job_id))
        
        return {
            "job_id": job_id,
            "status": "running",
            "message": "Job de migração iniciado com sucesso",
            "started_at": datetime.now().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao iniciar job de migração: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

@app.post("/api/v1/migrations/{job_id}/cancel", tags=["migrations"])
async def cancel_migration_job(
    job_id: UUID = Path(..., description="ID do job de migração"),
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Cancela um job de migração"""
    conn = await get_db_connection()
    try:
        # Verificar se job existe e pode ser cancelado
        job = await conn.fetchrow("""
            SELECT status FROM layout_migration_jobs 
            WHERE id = $1 AND tenant_id = $2
        """, job_id, tenant_id)
        
        if not job:
            raise HTTPException(status_code=404, detail="Job de migração não encontrado")
        
        if job['status'] in ['completed', 'failed', 'cancelled']:
            raise HTTPException(status_code=400, detail=f"Job não pode ser cancelado (status: {job['status']})")
        
        # Cancelar job
        await conn.execute("""
            UPDATE layout_migration_jobs 
            SET status = 'cancelled', completed_at = CURRENT_TIMESTAMP
            WHERE id = $1
        """, job_id)
        
        return {
            "job_id": job_id,
            "status": "cancelled",
            "message": "Job de migração cancelado com sucesso",
            "cancelled_at": datetime.now().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao cancelar job de migração: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

# =====================================================
# ENDPOINTS - ANÁLISE DE IMPACTO
# =====================================================

@app.post("/api/v1/layouts/{layout_id}/analyze-impact", tags=["layouts"])
async def analyze_layout_impact(
    layout_id: UUID = Path(..., description="ID do layout"),
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Analisa o impacto de mudanças em um layout"""
    conn = await get_db_connection()
    try:
        # Verificar se layout existe
        layout = await conn.fetchrow("""
            SELECT * FROM contract_layouts 
            WHERE id = $1 AND tenant_id = $2
        """, layout_id, tenant_id)
        
        if not layout:
            raise HTTPException(status_code=404, detail="Layout não encontrado")
        
        # Contar contratos afetados
        affected_contracts = await conn.fetchval("""
            SELECT COUNT(DISTINCT contract_id)
            FROM contract_layout_assignments
            WHERE layout_id = $1 AND tenant_id = $2
        """, layout_id, tenant_id)
        
        # Contar por tipo de associação
        association_stats = await conn.fetchrow("""
            SELECT 
                COUNT(CASE WHEN is_primary THEN 1 END) as primary_associations,
                COUNT(CASE WHEN NOT is_primary THEN 1 END) as secondary_associations
            FROM contract_layout_assignments
            WHERE layout_id = $1 AND tenant_id = $2
        """, layout_id, tenant_id)
        
        # Verificar se é layout padrão
        is_default = layout['is_default']
        
        # Calcular estimativa de tempo de migração
        estimated_time_minutes = max(5, affected_contracts * 0.1)  # Mínimo 5 min, 0.1 min por contrato
        
        # Determinar nível de impacto
        if affected_contracts == 0:
            impact_level = "none"
        elif affected_contracts <= 10:
            impact_level = "low"
        elif affected_contracts <= 100:
            impact_level = "medium"
        else:
            impact_level = "high"
        
        return {
            "layout_id": layout_id,
            "layout_name": layout['name'],
            "layout_type": layout['layout_type'],
            "is_default": is_default,
            "impact_analysis": {
                "affected_contracts": affected_contracts,
                "primary_associations": association_stats['primary_associations'],
                "secondary_associations": association_stats['secondary_associations'],
                "impact_level": impact_level,
                "requires_migration": affected_contracts > 0,
                "estimated_time_minutes": int(estimated_time_minutes),
                "recommendations": generate_impact_recommendations(
                    affected_contracts, is_default, impact_level
                )
            },
            "analyzed_at": datetime.now().isoformat()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao analisar impacto: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

@app.get("/api/v1/tenants/stats", tags=["tenants"])
async def get_tenant_stats(tenant_id: UUID = Depends(get_tenant_id)):
    """Obtém estatísticas do tenant"""
    conn = await get_db_connection()
    try:
        # Estatísticas de layouts
        layout_stats = await conn.fetch("""
            SELECT * FROM count_active_layouts_by_tenant($1)
        """, tenant_id)
        
        # Estatísticas gerais
        general_stats = await conn.fetchrow("""
            SELECT 
                (SELECT COUNT(*) FROM contract_layouts WHERE tenant_id = $1) as total_layouts,
                (SELECT COUNT(*) FROM contract_layouts WHERE tenant_id = $1 AND is_active = true) as active_layouts,
                (SELECT COUNT(*) FROM contract_layout_assignments WHERE tenant_id = $1) as total_assignments,
                (SELECT COUNT(DISTINCT contract_id) FROM contract_layout_assignments WHERE tenant_id = $1) as contracts_with_layouts,
                (SELECT COUNT(*) FROM layout_migration_jobs WHERE tenant_id = $1) as total_migrations,
                (SELECT COUNT(*) FROM layout_migration_jobs WHERE tenant_id = $1 AND status = 'running') as running_migrations
        """, tenant_id)
        
        return {
            "tenant_id": tenant_id,
            "layouts": {
                "total": general_stats['total_layouts'],
                "active": general_stats['active_layouts'],
                "by_type": [
                    {
                        "type": stat['layout_type'],
                        "total": stat['total_layouts'],
                        "active": stat['active_layouts']
                    }
                    for stat in layout_stats
                ]
            },
            "assignments": {
                "total": general_stats['total_assignments'],
                "contracts_with_layouts": general_stats['contracts_with_layouts']
            },
            "migrations": {
                "total": general_stats['total_migrations'],
                "running": general_stats['running_migrations']
            },
            "generated_at": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

# =====================================================
# FUNÇÕES AUXILIARES
# =====================================================

def generate_impact_recommendations(affected_contracts: int, is_default: bool, impact_level: str) -> List[str]:
    """Gera recomendações baseadas no impacto"""
    recommendations = []
    
    if affected_contracts == 0:
        recommendations.append("Nenhum contrato será afetado - mudança segura")
    elif impact_level == "low":
        recommendations.append("Impacto baixo - pode ser aplicado imediatamente")
    elif impact_level == "medium":
        recommendations.append("Impacto médio - recomenda-se janela de manutenção")
        recommendations.append("Considere migração gradual para reduzir impacto")
    else:
        recommendations.append("Impacto alto - planejamento detalhado necessário")
        recommendations.append("Migração deve ser feita em horário de baixo uso")
        recommendations.append("Considere rollback plan em caso de problemas")
    
    if is_default:
        recommendations.append("Layout padrão - impacto em novos contratos")
    
    return recommendations

async def process_migration_job(job_id: UUID, specific_contracts: Optional[List[UUID]] = None):
    """Processa um job de migração de forma assíncrona"""
    conn = await get_db_connection()
    try:
        # Buscar detalhes do job
        job = await conn.fetchrow("""
            SELECT * FROM layout_migration_jobs WHERE id = $1
        """, job_id)
        
        if not job or job['status'] != 'running':
            return
        
        processed = 0
        failed = 0
        
        # Simular processamento (em implementação real, faria a migração real)
        if specific_contracts:
            contracts_to_process = specific_contracts
        else:
            # Buscar contratos baseado no layout de origem
            if job['source_layout_id']:
                contracts = await conn.fetch("""
                    SELECT DISTINCT contract_id 
                    FROM contract_layout_assignments 
                    WHERE layout_id = $1 AND tenant_id = $2
                """, job['source_layout_id'], job['tenant_id'])
                contracts_to_process = [c['contract_id'] for c in contracts]
            else:
                contracts_to_process = []
        
        # Processar cada contrato
        for contract_id in contracts_to_process:
            try:
                # Simular processamento
                await asyncio.sleep(0.1)  # Simular tempo de processamento
                
                # Aqui seria feita a migração real do contrato
                # Por exemplo: atualizar associações, validar dados, etc.
                
                processed += 1
                
                # Atualizar progresso periodicamente
                if processed % 10 == 0:
                    await conn.execute("""
                        UPDATE layout_migration_jobs 
                        SET processed_contracts = $1 
                        WHERE id = $2
                    """, processed, job_id)
                
            except Exception as e:
                failed += 1
                logger.error(f"Erro ao processar contrato {contract_id}: {str(e)}")
        
        # Finalizar job
        status = "completed" if failed == 0 else "failed"
        await conn.execute("""
            UPDATE layout_migration_jobs 
            SET status = $1, processed_contracts = $2, failed_contracts = $3, 
                completed_at = CURRENT_TIMESTAMP
            WHERE id = $4
        """, status, processed, failed, job_id)
        
        logger.info(f"Job {job_id} finalizado: {processed} processados, {failed} falharam")
        
    except Exception as e:
        logger.error(f"Erro no processamento do job {job_id}: {str(e)}")
        await conn.execute("""
            UPDATE layout_migration_jobs 
            SET status = 'failed', error_details = $1, completed_at = CURRENT_TIMESTAMP
            WHERE id = $2
        """, json.dumps({"error": str(e)}), job_id)
    finally:
        await db_pool.release(conn)

# =====================================================
# ENDPOINTS - HISTÓRICO DE MUDANÇAS
# =====================================================

@app.get("/api/v1/layouts/{layout_id}/history", tags=["layouts"])
async def get_layout_history(
    layout_id: UUID = Path(..., description="ID do layout"),
    tenant_id: UUID = Depends(get_tenant_id),
    limit: int = Query(20, ge=1, le=100, description="Limite de resultados"),
    offset: int = Query(0, ge=0, description="Offset para paginação")
):
    """Obtém histórico de mudanças de um layout"""
    conn = await get_db_connection()
    try:
        history = await conn.fetch("""
            SELECT * FROM layout_change_history 
            WHERE layout_id = $1 AND tenant_id = $2
            ORDER BY changed_at DESC
            LIMIT $3 OFFSET $4
        """, layout_id, tenant_id, limit, offset)
        
        return [
            {
                "id": record['id'],
                "change_type": record['change_type'],
                "old_version": record['old_version'],
                "new_version": record['new_version'],
                "changes_summary": record['changes_summary'],
                "impact_analysis": record['impact_analysis'],
                "requires_reprocessing": record['requires_reprocessing'],
                "affected_contracts_count": record['affected_contracts_count'],
                "changed_by": record['changed_by'],
                "changed_at": record['changed_at']
            }
            for record in history
        ]
        
    except Exception as e:
        logger.error(f"Erro ao buscar histórico: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_pool.release(conn)

