"""
Layout Service - Sistema de Governança de Dados V1.1
Microserviço responsável pelo gerenciamento de layouts de contratos e multi-tenancy
VERSÃO CORRIGIDA COM POOL DE CONEXÕES
"""

from libs.performance_middleware import add_all_performance_middlewares, initialize_cache
from fastapi import FastAPI, HTTPException, Depends, Query, Path
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, validator
from typing import List, Optional, Dict, Any
import asyncpg
import json
import os
import logging
from datetime import datetime
from uuid import UUID, uuid4
import asyncio
import sys
sys.path.append('/home/ubuntu/SISTEMA_GOVERNANCA_V1_1_UNIFICADO')
from config.database import get_postgres_config, get_postgres_pool_config

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuração da aplicação
app = FastAPI(
    title="Layout Service V4.1",
    description="Serviço de gerenciamento de layouts e multi-tenancy - VERSÃO CORRIGIDA",
    version="4.1.0",
    openapi_tags=[
        {"name": "layouts", "description": "Operações com layouts de contratos"},
        {"name": "tenants", "description": "Operações com tenants"},
        {"name": "assignments", "description": "Associações entre contratos e layouts"},
        {"name": "migrations", "description": "Migrações de layout"}
    ]
)
# Adicionar middlewares de performance
add_all_performance_middlewares(app, {
    "rate_limit_rpm": 120,
    "compression_min_size": 500,
    "cache_ttl": 300,
    "enable_performance_logging": True
})


# Configuração CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pool de conexões global
db_pool = None

# =====================================================
# MODELOS PYDANTIC
# =====================================================

class TenantCreate(BaseModel):
    """Modelo para criação de tenant"""
    name: str = Field(..., min_length=1, max_length=255, description="Nome do tenant")
    slug: str = Field(..., min_length=1, max_length=100, description="Slug único do tenant")
    description: Optional[str] = Field(None, description="Descrição do tenant")
    settings: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Configurações do tenant")
    
    @validator('slug')
    def validate_slug(cls, v):
        """Valida formato do slug"""
        if not v.replace('-', '').replace('_', '').isalnum():
            raise ValueError('Slug deve conter apenas letras, números, hífens e underscores')
        return v.lower()

class TenantResponse(BaseModel):
    """Modelo de resposta para tenant"""
    id: UUID
    name: str
    slug: str
    description: Optional[str]
    settings: Dict[str, Any]
    is_active: bool
    created_at: datetime
    updated_at: datetime

class LayoutCreate(BaseModel):
    """Modelo para criação de layout"""
    name: str = Field(..., min_length=1, max_length=255, description="Nome do layout")
    description: Optional[str] = Field(None, description="Descrição do layout")
    layout_type: str = Field("default", description="Tipo do layout")
    version: str = Field("1.0.0", description="Versão do layout")
    schema_definition: Dict[str, Any] = Field(..., description="Definição do schema")
    ui_configuration: Dict[str, Any] = Field(..., description="Configuração da interface")
    is_default: bool = Field(False, description="Se é o layout padrão")
    
    @validator('layout_type')
    def validate_layout_type(cls, v):
        """Valida tipo do layout"""
        allowed_types = ['default', 'mobile', 'print', 'executive', 'custom']
        if v not in allowed_types:
            raise ValueError(f'Tipo deve ser um dos: {", ".join(allowed_types)}')
        return v

class LayoutResponse(BaseModel):
    """Modelo de resposta para layout"""
    id: UUID
    tenant_id: UUID
    name: str
    description: Optional[str]
    layout_type: str
    version: str
    schema_definition: Dict[str, Any]
    ui_configuration: Dict[str, Any]
    is_active: bool
    is_default: bool
    created_by: Optional[UUID]
    created_at: datetime
    updated_at: datetime

class LayoutAssignmentCreate(BaseModel):
    """Modelo para associação de layout"""
    layout_id: UUID = Field(..., description="ID do layout")
    is_primary: bool = Field(False, description="Se é o layout primário")

class LayoutAssignmentResponse(BaseModel):
    """Modelo de resposta para associação"""
    id: UUID
    contract_id: UUID
    layout_id: UUID
    tenant_id: UUID
    is_primary: bool
    assigned_at: datetime
    assigned_by: Optional[UUID]

class ContractLayoutInfo(BaseModel):
    """Informações de layout de um contrato"""
    layout_id: UUID
    layout_name: str
    layout_type: str
    version: str
    is_primary: bool
    ui_configuration: Dict[str, Any]

# =====================================================
# GERENCIAMENTO DE CONEXÕES
# =====================================================

class DatabaseManager:
    """Gerenciador de conexões com banco de dados"""
    
    def __init__(self):
        self.pool = None
        self.config = get_postgres_config()
        self.pool_config = get_postgres_pool_config()
    
    async def initialize_pool(self):
        """Inicializa pool de conexões"""
        try:
            self.pool = await asyncpg.create_pool(
                self.config.url,
                **self.pool_config
            )
            logger.info("Pool de conexões inicializado com sucesso")
        except Exception as e:
            logger.error(f"Erro ao inicializar pool: {str(e)}")
            raise
    
    async def get_connection(self):
        """Obtém conexão do pool"""
        if self.pool is None:
            await self.initialize_pool()
        return await self.pool.acquire()
    
    async def release_connection(self, conn):
        """Libera conexão para o pool"""
        if self.pool:
            await self.pool.release(conn)
    
    async def close_pool(self):
        """Fecha pool de conexões"""
        if self.pool:
            await self.pool.close()
            logger.info("Pool de conexões fechado")

# Instância global do gerenciador
db_manager = DatabaseManager()

# =====================================================
# DEPENDÊNCIAS
# =====================================================

async def get_db_connection():
    """Obtém conexão com o banco de dados"""
    return await db_manager.get_connection()

async def get_tenant_id(tenant_slug: str = Query("default", description="Slug do tenant")) -> UUID:
    """Obtém ID do tenant pelo slug"""
    conn = await get_db_connection()
    try:
        tenant = await conn.fetchrow(
            "SELECT id FROM tenants WHERE slug = $1 AND is_active = true",
            tenant_slug
        )
        if not tenant:
            raise HTTPException(status_code=404, detail=f"Tenant '{tenant_slug}' não encontrado")
        return tenant['id']
    finally:
        await db_manager.release_connection(conn)

# =====================================================
# ENDPOINTS - ROOT E HEALTH
# =====================================================

@app.get("/", tags=["root"])
async def root():
    """Endpoint raiz do serviço"""
    return {
        "service": "layout-service",
        "version": "4.1.0",
        "description": "Serviço de gerenciamento de layouts e multi-tenancy - VERSÃO CORRIGIDA",
        "status": "healthy"
    }

@app.get("/health", tags=["root"])
async def health_check():
    """Verificação de saúde do serviço"""
    try:
        conn = await get_db_connection()
        await conn.fetchval("SELECT 1")
        await db_manager.release_connection(conn)
        return {
            "service": "layout-service",
            "status": "healthy",
            "database": "connected",
            "pool_size": db_manager.pool.get_size() if db_manager.pool else 0,
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        return {
            "service": "layout-service",
            "status": "unhealthy",
            "database": "disconnected",
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }

# =====================================================
# ENDPOINTS - TENANTS
# =====================================================

@app.post("/api/v1/tenants", response_model=TenantResponse, tags=["tenants"])
async def create_tenant(tenant: TenantCreate):
    """Cria um novo tenant"""
    conn = await get_db_connection()
    try:
        # Verificar se slug já existe
        existing = await conn.fetchrow("SELECT id FROM tenants WHERE slug = $1", tenant.slug)
        if existing:
            raise HTTPException(status_code=400, detail=f"Tenant com slug '{tenant.slug}' já existe")
        
        # Inserir novo tenant
        tenant_id = await conn.fetchval("""
            INSERT INTO tenants (name, slug, description, settings)
            VALUES ($1, $2, $3, $4)
            RETURNING id
        """, tenant.name, tenant.slug, tenant.description, json.dumps(tenant.settings))
        
        # Buscar tenant criado
        created_tenant = await conn.fetchrow("""
            SELECT * FROM tenants WHERE id = $1
        """, tenant_id)
        
        return TenantResponse(
            id=created_tenant['id'],
            name=created_tenant['name'],
            slug=created_tenant['slug'],
            description=created_tenant['description'],
            settings=created_tenant['settings'] or {},
            is_active=created_tenant['is_active'],
            created_at=created_tenant['created_at'],
            updated_at=created_tenant['updated_at']
        )
        
    except asyncpg.UniqueViolationError:
        raise HTTPException(status_code=400, detail="Tenant com este slug já existe")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar tenant: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_manager.release_connection(conn)

@app.get("/api/v1/tenants", response_model=List[TenantResponse], tags=["tenants"])
async def list_tenants(
    active_only: bool = Query(True, description="Listar apenas tenants ativos"),
    limit: int = Query(50, ge=1, le=100, description="Limite de resultados"),
    offset: int = Query(0, ge=0, description="Offset para paginação")
):
    """Lista todos os tenants"""
    conn = await get_db_connection()
    try:
        where_clause = "WHERE is_active = true" if active_only else ""
        
        tenants = await conn.fetch(f"""
            SELECT * FROM tenants 
            {where_clause}
            ORDER BY created_at DESC
            LIMIT $1 OFFSET $2
        """, limit, offset)
        
        return [
            TenantResponse(
                id=tenant['id'],
                name=tenant['name'],
                slug=tenant['slug'],
                description=tenant['description'],
                settings=tenant['settings'] or {},
                is_active=tenant['is_active'],
                created_at=tenant['created_at'],
                updated_at=tenant['updated_at']
            )
            for tenant in tenants
        ]
        
    except Exception as e:
        logger.error(f"Erro ao listar tenants: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_manager.release_connection(conn)

@app.get("/api/v1/tenants/{tenant_slug}", response_model=TenantResponse, tags=["tenants"])
async def get_tenant(tenant_slug: str = Path(..., description="Slug do tenant")):
    """Obtém informações de um tenant específico"""
    conn = await get_db_connection()
    try:
        tenant = await conn.fetchrow("""
            SELECT * FROM tenants WHERE slug = $1
        """, tenant_slug)
        
        if not tenant:
            raise HTTPException(status_code=404, detail=f"Tenant '{tenant_slug}' não encontrado")
        
        return TenantResponse(
            id=tenant['id'],
            name=tenant['name'],
            slug=tenant['slug'],
            description=tenant['description'],
            settings=tenant['settings'] or {},
            is_active=tenant['is_active'],
            created_at=tenant['created_at'],
            updated_at=tenant['updated_at']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao buscar tenant: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_manager.release_connection(conn)

# =====================================================
# ENDPOINTS - LAYOUTS
# =====================================================

@app.post("/api/v1/layouts", response_model=LayoutResponse, tags=["layouts"])
async def create_layout(
    layout: LayoutCreate,
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Cria um novo layout para o tenant"""
    conn = await get_db_connection()
    try:
        # Se é layout padrão, desativar outros padrões do mesmo tipo
        if layout.is_default:
            await conn.execute("""
                UPDATE contract_layouts 
                SET is_default = false 
                WHERE tenant_id = $1 AND layout_type = $2
            """, tenant_id, layout.layout_type)
        
        # Inserir novo layout
        layout_id = await conn.fetchval("""
            INSERT INTO contract_layouts (
                tenant_id, name, description, layout_type, version,
                schema_definition, ui_configuration, is_default
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id
        """, 
            tenant_id, layout.name, layout.description, layout.layout_type,
            layout.version, json.dumps(layout.schema_definition),
            json.dumps(layout.ui_configuration), layout.is_default
        )
        
        # Registrar histórico
        await conn.execute("""
            INSERT INTO layout_change_history (
                tenant_id, layout_id, change_type, new_version, changes_summary
            ) VALUES ($1, $2, 'created', $3, $4)
        """, tenant_id, layout_id, layout.version, json.dumps({"action": "layout_created"}))
        
        # Buscar layout criado
        created_layout = await conn.fetchrow("""
            SELECT * FROM contract_layouts WHERE id = $1
        """, layout_id)
        
        return LayoutResponse(
            id=created_layout['id'],
            tenant_id=created_layout['tenant_id'],
            name=created_layout['name'],
            description=created_layout['description'],
            layout_type=created_layout['layout_type'],
            version=created_layout['version'],
            schema_definition=created_layout['schema_definition'],
            ui_configuration=created_layout['ui_configuration'],
            is_active=created_layout['is_active'],
            is_default=created_layout['is_default'],
            created_by=created_layout['created_by'],
            created_at=created_layout['created_at'],
            updated_at=created_layout['updated_at']
        )
        
    except asyncpg.UniqueViolationError:
        raise HTTPException(status_code=400, detail="Layout com este nome e versão já existe para o tenant")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar layout: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_manager.release_connection(conn)

@app.get("/api/v1/layouts", response_model=List[LayoutResponse], tags=["layouts"])
async def list_layouts(
    tenant_id: UUID = Depends(get_tenant_id),
    layout_type: Optional[str] = Query(None, description="Filtrar por tipo de layout"),
    active_only: bool = Query(True, description="Listar apenas layouts ativos"),
    limit: int = Query(50, ge=1, le=100, description="Limite de resultados"),
    offset: int = Query(0, ge=0, description="Offset para paginação")
):
    """Lista layouts do tenant"""
    conn = await get_db_connection()
    try:
        conditions = ["tenant_id = $1"]
        params = [tenant_id]
        param_count = 1
        
        if layout_type:
            param_count += 1
            conditions.append(f"layout_type = ${param_count}")
            params.append(layout_type)
        
        if active_only:
            conditions.append("is_active = true")
        
        where_clause = "WHERE " + " AND ".join(conditions)
        
        layouts = await conn.fetch(f"""
            SELECT * FROM contract_layouts 
            {where_clause}
            ORDER BY is_default DESC, layout_type, created_at DESC
            LIMIT ${param_count + 1} OFFSET ${param_count + 2}
        """, *params, limit, offset)
        
        return [
            LayoutResponse(
                id=layout['id'],
                tenant_id=layout['tenant_id'],
                name=layout['name'],
                description=layout['description'],
                layout_type=layout['layout_type'],
                version=layout['version'],
                schema_definition=layout['schema_definition'],
                ui_configuration=layout['ui_configuration'],
                is_active=layout['is_active'],
                is_default=layout['is_default'],
                created_by=layout['created_by'],
                created_at=layout['created_at'],
                updated_at=layout['updated_at']
            )
            for layout in layouts
        ]
        
    except Exception as e:
        logger.error(f"Erro ao listar layouts: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_manager.release_connection(conn)

@app.get("/api/v1/contracts/{contract_id}/layouts/count", tags=["assignments"])
async def count_contract_layouts(
    contract_id: UUID = Path(..., description="ID do contrato"),
    tenant_id: UUID = Depends(get_tenant_id)
):
    """Conta quantos layouts estão associados a um contrato"""
    conn = await get_db_connection()
    try:
        result = await conn.fetchrow("""
            SELECT 
                COUNT(*) as total_layouts,
                COUNT(CASE WHEN cla.is_primary THEN 1 END) as primary_layouts,
                COUNT(CASE WHEN cl.layout_type = 'default' THEN 1 END) as default_layouts,
                COUNT(CASE WHEN cl.layout_type = 'mobile' THEN 1 END) as mobile_layouts,
                COUNT(CASE WHEN cl.layout_type = 'print' THEN 1 END) as print_layouts
            FROM contract_layout_assignments cla
            JOIN contract_layouts cl ON cla.layout_id = cl.id
            WHERE cla.contract_id = $1 AND cla.tenant_id = $2 AND cl.is_active = true
        """, contract_id, tenant_id)
        
        return {
            "contract_id": contract_id,
            "total_layouts": result['total_layouts'],
            "primary_layouts": result['primary_layouts'],
            "layouts_by_type": {
                "default": result['default_layouts'],
                "mobile": result['mobile_layouts'],
                "print": result['print_layouts']
            },
            "has_layouts": result['total_layouts'] > 0
        }
        
    except Exception as e:
        logger.error(f"Erro ao contar layouts: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_manager.release_connection(conn)

@app.get("/api/v1/tenants/stats", tags=["tenants"])
async def get_tenant_stats(tenant_id: UUID = Depends(get_tenant_id)):
    """Obtém estatísticas do tenant"""
    conn = await get_db_connection()
    try:
        # Estatísticas gerais
        general_stats = await conn.fetchrow("""
            SELECT 
                (SELECT COUNT(*) FROM contract_layouts WHERE tenant_id = $1) as total_layouts,
                (SELECT COUNT(*) FROM contract_layouts WHERE tenant_id = $1 AND is_active = true) as active_layouts,
                (SELECT COUNT(*) FROM contract_layout_assignments WHERE tenant_id = $1) as total_assignments,
                (SELECT COUNT(DISTINCT contract_id) FROM contract_layout_assignments WHERE tenant_id = $1) as contracts_with_layouts
        """, tenant_id)
        
        return {
            "tenant_id": tenant_id,
            "layouts": {
                "total": general_stats['total_layouts'],
                "active": general_stats['active_layouts']
            },
            "assignments": {
                "total": general_stats['total_assignments'],
                "contracts_with_layouts": general_stats['contracts_with_layouts']
            },
            "generated_at": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")
    finally:
        await db_manager.release_connection(conn)

# =====================================================
# STARTUP E SHUTDOWN
# =====================================================

@app.on_event("startup")
async def startup_event():
    await initialize_cache()
    """Inicialização da aplicação"""
    try:
        await db_manager.initialize_pool()
        logger.info("Layout Service V4.1 iniciado com sucesso")
    except Exception as e:
        logger.error(f"Erro na inicialização: {str(e)}")
        raise

@app.on_event("shutdown")
async def shutdown_event():
    """Finalização da aplicação"""
    await db_manager.close_pool()
    logger.info("Layout Service V4.1 finalizado")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8007)

