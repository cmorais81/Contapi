# Exemplos - COBOL AI Engine

Esta pasta contém exemplos práticos de uso do COBOL AI Engine.

## 📁 Estrutura

```
examples/
├── README.md              # Este arquivo
├── exemplo_basico.sh      # Exemplo básico sem IA
├── exemplo_com_ia.sh      # Exemplo com análise de IA
├── dados/                 # Arquivos de entrada (você deve copiar seus arquivos aqui)
├── saida/                 # Arquivos de saída gerados
└── config/                # Configurações de exemplo
```

## 🚀 Como Usar

### 1. Preparar Dados

Copie seus arquivos COBOL para a pasta `dados/`:

```bash
cp /caminho/para/seus/fontes.txt dados/
cp /caminho/para/seus/books.txt dados/
```

### 2. Executar Exemplo Básico

```bash
cd examples/
chmod +x exemplo_basico.sh
./exemplo_basico.sh
```

### 3. Executar Exemplo com IA

#### Com OpenAI:
```bash
export OPENAI_API_KEY="sua_chave_aqui"
chmod +x exemplo_com_ia.sh
./exemplo_com_ia.sh
```

#### Com AWS Bedrock:
```bash
export AWS_ACCESS_KEY_ID="sua_chave_aws"
export AWS_SECRET_ACCESS_KEY="sua_chave_secreta"
chmod +x exemplo_com_ia.sh
./exemplo_com_ia.sh
```

#### Sem APIs (Mock AI):
```bash
# Não configure nenhuma variável de ambiente
chmod +x exemplo_com_ia.sh
./exemplo_com_ia.sh
```

## 📋 Exemplos Disponíveis

### exemplo_basico.sh
- **Propósito**: Demonstra uso básico sem IA
- **Requisitos**: Apenas arquivos COBOL
- **Saída**: Documentação básica em Markdown
- **Tempo**: ~5 segundos

### exemplo_com_ia.sh
- **Propósito**: Demonstra análise completa com IA
- **Requisitos**: Arquivos COBOL + API de IA (opcional)
- **Saída**: Documentação rica com análise de IA
- **Tempo**: ~30 segundos (com IA real)

## 📊 Resultados Esperados

### Exemplo Básico
```
saida/exemplo_basico/
├── PROGRAMA1.md           # Documentação individual
├── PROGRAMA2.md           # Documentação individual
├── PROGRAMA3.md           # Documentação individual
└── relatorio_completo.md  # Relatório consolidado
```

### Exemplo com IA
```
saida/exemplo_com_ia/
├── PROGRAMA1.md           # Documentação com análise de IA
├── PROGRAMA2.md           # Documentação com análise de IA
├── PROGRAMA3.md           # Documentação com análise de IA
└── relatorio_completo.md  # Relatório com insights de IA
```

## 🔧 Personalização

### Criar Configuração Personalizada

```bash
# Copiar configuração padrão
cp ../config/config.yaml config/minha_config.yaml

# Editar conforme necessário
nano config/minha_config.yaml

# Usar configuração personalizada
python3 ../main.py \
    --config config/minha_config.yaml \
    --fontes dados/fontes.txt \
    --books dados/books.txt \
    --output saida/personalizado
```

### Exemplo de Configuração Personalizada

```yaml
# config/minha_config.yaml
ai:
  primary_provider: "openai"
  providers:
    openai:
      model_name: "gpt-3.5-turbo"  # Modelo mais barato
      max_tokens: 2000
      temperature: 0.1

documentation:
  language: "pt-br"
  template_style: "business"      # Foco em negócio
  include_complexity_metrics: false

logging:
  level: "WARNING"               # Menos verbose
```

## 🐛 Solução de Problemas

### Erro: "Arquivo não encontrado"
```bash
# Verificar se os arquivos existem
ls -la dados/

# Usar caminhos absolutos se necessário
python3 ../main.py \
    --fontes /caminho/completo/fontes.txt \
    --books /caminho/completo/books.txt \
    --output saida/
```

### Erro: "Permissão negada"
```bash
# Dar permissão de execução aos scripts
chmod +x *.sh

# Verificar permissões dos arquivos de dados
ls -la dados/
```

### Erro: "API não disponível"
```bash
# Verificar variáveis de ambiente
echo $OPENAI_API_KEY
echo $AWS_ACCESS_KEY_ID

# Testar conectividade
curl -H "Authorization: Bearer $OPENAI_API_KEY" \
     https://api.openai.com/v1/models
```

## 📈 Próximos Passos

Após executar os exemplos:

1. **Explorar Configurações**: Teste diferentes configurações em `../config/`
2. **Personalizar Templates**: Modifique templates de documentação
3. **Integrar com CI/CD**: Use os exemplos como base para automação
4. **Escalar para Produção**: Adapte para seus arquivos reais

## 💡 Dicas

- **Performance**: Para arquivos grandes, use `chunk_size` maior na configuração
- **Custos**: Monitore uso de tokens com APIs pagas
- **Qualidade**: Use `temperature` baixa (0.1-0.3) para análises técnicas
- **Debugging**: Use `--log-level DEBUG` para diagnóstico detalhado

---

*Exemplos - COBOL AI Engine v1.0*

