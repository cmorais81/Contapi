"""
COBOL AI Engine v2.1.0 - Provider Manager
Gerenciador completo de provedores com fallback inteligente e controle de tokens.
"""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

from .base_provider import BaseAIProvider, AIRequest, AIResponse
from .luzia_provider import LuziaProvider
from .openai_provider import OpenAIProvider
from .copilot_provider import CopilotProvider
from .enhanced_mock_provider import EnhancedMockProvider
from .basic_provider import BasicProvider


class ProviderManager:
    """
    Gerenciador de provedores com fallback inteligente e seleção automática.
    
    Funcionalidades:
    - Inicialização automática de provedores
    - Sistema de fallback robusto
    - Seleção do melhor provedor disponível
    - Estatísticas e monitoramento
    - Controle de disponibilidade
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o gerenciador de provedores.
        
        Args:
            config: Configuração completa do sistema
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Configurações do gerenciador
        ai_config = config.get('ai', {})
        self.primary_provider = ai_config.get('primary_provider', 'enhanced_mock')
        self.fallback_providers = ai_config.get('fallback_providers', ['basic'])
        self.enable_fallback = ai_config.get('enable_fallback', True)
        self.max_retries = ai_config.get('max_retries', 3)
        self.retry_delay = ai_config.get('retry_delay', 2.0)
        
        # Provedores disponíveis
        self.providers: Dict[str, BaseAIProvider] = {}
        self.provider_classes = {
            'luzia': LuziaProvider,
            'openai': OpenAIProvider,
            'copilot': CopilotProvider,
            'enhanced_mock': EnhancedMockProvider,
            'basic': BasicProvider
        }
        
        # Estatísticas
        self.total_requests = 0
        self.successful_requests = 0
        self.failed_requests = 0
        self.provider_usage = {}
        
        # Inicializar provedores
        self._initialize_providers()
        
        self.logger.info(f"Provider Manager inicializado - Primário: {self.primary_provider}")
    
    def _initialize_providers(self):
        """Inicializa todos os provedores configurados."""
        
        providers_config = self.config.get('ai', {}).get('providers', {})
        
        for provider_name, provider_config in providers_config.items():
            if provider_name in self.provider_classes:
                try:
                    # Verificar se está habilitado
                    if not provider_config.get('enabled', False):
                        self.logger.debug(f"Provedor {provider_name} desabilitado")
                        continue
                    
                    # Inicializar provedor
                    provider_class = self.provider_classes[provider_name]
                    provider = provider_class(provider_name, provider_config)
                    
                    self.providers[provider_name] = provider
                    self.provider_usage[provider_name] = 0
                    
                    self.logger.info(f"Provedor {provider_name} inicializado com sucesso")
                    
                except Exception as e:
                    self.logger.error(f"Erro ao inicializar provedor {provider_name}: {str(e)}")
        
        # Garantir que temos pelo menos Enhanced Mock e Basic
        self._ensure_fallback_providers()
    
    def _ensure_fallback_providers(self):
        """Garante que temos provedores de fallback sempre disponíveis."""
        
        # Enhanced Mock sempre disponível
        if 'enhanced_mock' not in self.providers:
            try:
                enhanced_mock = EnhancedMockProvider('enhanced_mock', {
                    'enabled': True,
                    'response_delay': 0.1,
                    'enable_phasing': True
                })
                self.providers['enhanced_mock'] = enhanced_mock
                self.provider_usage['enhanced_mock'] = 0
                self.logger.info("Enhanced Mock Provider adicionado como fallback")
            except Exception as e:
                self.logger.error(f"Erro ao criar Enhanced Mock: {str(e)}")
        
        # Basic Provider sempre disponível
        if 'basic' not in self.providers:
            try:
                basic = BasicProvider('basic', {
                    'enabled': True,
                    'max_tokens': 1000
                })
                self.providers['basic'] = basic
                self.provider_usage['basic'] = 0
                self.logger.info("Basic Provider adicionado como fallback final")
            except Exception as e:
                self.logger.error(f"Erro ao criar Basic Provider: {str(e)}")
    
    def analyze_with_fallback(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise com sistema de fallback automático.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        self.total_requests += 1
        
        # Lista de provedores para tentar
        providers_to_try = self._get_providers_order()
        
        last_error = None
        
        for provider_name in providers_to_try:
            provider = self.providers.get(provider_name)
            
            if not provider:
                self.logger.warning(f"Provedor {provider_name} não encontrado")
                continue
            
            try:
                self.logger.info(f"Tentando análise com provedor: {provider_name}")
                
                # Verificar disponibilidade
                if not provider.is_available():
                    self.logger.warning(f"Provedor {provider_name} não disponível")
                    continue
                
                # Tentar análise
                response = provider.analyze(request)
                
                if response.success:
                    self.successful_requests += 1
                    self.provider_usage[provider_name] += 1
                    self.logger.info(f"Análise bem-sucedida com provedor: {provider_name}")
                    return response
                else:
                    self.logger.warning(f"Análise falhou com {provider_name}: {response.error_message}")
                    last_error = response.error_message
                    
            except Exception as e:
                self.logger.error(f"Erro com provedor {provider_name}: {str(e)}")
                last_error = str(e)
        
        # Se chegou aqui, todos os provedores falharam
        self.failed_requests += 1
        
        error_response = AIResponse(
            content="",
            tokens_used=0,
            provider_name="none",
            model_name="none",
            success=False,
            error_message=f"Todos os provedores falharam. Último erro: {last_error}"
        )
        
        return error_response
    
    def _get_providers_order(self) -> List[str]:
        """Retorna ordem de provedores para tentar."""
        
        providers_order = []
        
        # Adicionar provedor primário primeiro
        if self.primary_provider in self.providers:
            providers_order.append(self.primary_provider)
        
        # Adicionar provedores de fallback
        if self.enable_fallback:
            for fallback_provider in self.fallback_providers:
                if fallback_provider in self.providers and fallback_provider not in providers_order:
                    providers_order.append(fallback_provider)
        
        # Garantir que Enhanced Mock está na lista
        if 'enhanced_mock' not in providers_order and 'enhanced_mock' in self.providers:
            providers_order.append('enhanced_mock')
        
        # Garantir que Basic está na lista como último recurso
        if 'basic' not in providers_order and 'basic' in self.providers:
            providers_order.append('basic')
        
        return providers_order
    
    def get_provider_status(self) -> Dict[str, Any]:
        """Retorna status de todos os provedores."""
        
        status = {
            'total_providers': len(self.providers),
            'available_providers': 0,
            'primary_provider': self.primary_provider,
            'primary_available': False,
            'providers': {}
        }
        
        for name, provider in self.providers.items():
            try:
                is_available = provider.is_available()
                provider_stats = provider.get_statistics()
                
                status['providers'][name] = {
                    'available': is_available,
                    'enabled': provider.enabled,
                    'statistics': provider_stats,
                    'usage_count': self.provider_usage.get(name, 0)
                }
                
                if is_available:
                    status['available_providers'] += 1
                
                if name == self.primary_provider and is_available:
                    status['primary_available'] = True
                    
            except Exception as e:
                status['providers'][name] = {
                    'available': False,
                    'enabled': False,
                    'error': str(e),
                    'usage_count': self.provider_usage.get(name, 0)
                }
        
        return status
    
    def get_best_provider(self) -> Optional[str]:
        """Retorna o melhor provedor disponível baseado em performance."""
        
        best_provider = None
        best_score = -1
        
        for name, provider in self.providers.items():
            if not provider.is_available():
                continue
            
            try:
                stats = provider.get_statistics()
                
                # Calcular score baseado em taxa de sucesso e uso
                success_rate = stats.get('success_rate', 0)
                usage_count = self.provider_usage.get(name, 0)
                
                # Score: taxa de sucesso com bônus para provedores menos usados
                score = success_rate
                if usage_count < 10:  # Bônus para provedores pouco usados
                    score += 10
                
                if score > best_score:
                    best_score = score
                    best_provider = name
                    
            except Exception as e:
                self.logger.debug(f"Erro ao calcular score para {name}: {str(e)}")
        
        return best_provider
    
    def get_manager_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do gerenciador."""
        
        success_rate = 0.0
        if self.total_requests > 0:
            success_rate = (self.successful_requests / self.total_requests) * 100
        
        return {
            'total_requests': self.total_requests,
            'successful_requests': self.successful_requests,
            'failed_requests': self.failed_requests,
            'success_rate': success_rate,
            'primary_provider': self.primary_provider,
            'fallback_enabled': self.enable_fallback,
            'provider_usage': self.provider_usage.copy(),
            'available_providers': [
                name for name, provider in self.providers.items() 
                if provider.is_available()
            ]
        }
    
    def test_all_providers(self) -> Dict[str, Any]:
        """Testa todos os provedores configurados."""
        
        test_request = AIRequest(
            prompt="Teste de conectividade - responda apenas 'OK'",
            max_tokens=10,
            temperature=0.0
        )
        
        results = {}
        
        for name, provider in self.providers.items():
            try:
                self.logger.info(f"Testando provedor: {name}")
                
                # Testar disponibilidade
                is_available = provider.is_available()
                
                if is_available:
                    # Testar análise
                    response = provider.analyze(test_request)
                    results[name] = {
                        'available': True,
                        'analysis_success': response.success,
                        'response_time': 'N/A',
                        'error': response.error_message if not response.success else None
                    }
                else:
                    results[name] = {
                        'available': False,
                        'analysis_success': False,
                        'response_time': 'N/A',
                        'error': 'Provider not available'
                    }
                    
            except Exception as e:
                results[name] = {
                    'available': False,
                    'analysis_success': False,
                    'response_time': 'N/A',
                    'error': str(e)
                }
        
        return results

