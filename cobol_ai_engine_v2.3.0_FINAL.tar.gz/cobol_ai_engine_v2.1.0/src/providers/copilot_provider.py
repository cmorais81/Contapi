"""
COBOL AI Engine v2.1.0 - GitHub Copilot Provider
Implementação completa com autenticação GitHub e controle de tokens.

Métodos de Autenticação Suportados:
1. GitHub Personal Access Token: GITHUB_COPILOT_TOKEN
2. GitHub App Token: GITHUB_APP_TOKEN + GITHUB_APP_ID
3. GitHub Organization Token: GITHUB_COPILOT_TOKEN + GITHUB_ORG
4. GitHub Enterprise: GITHUB_ENTERPRISE_URL + GITHUB_COPILOT_TOKEN
"""

import logging
import time
import json
from typing import Dict, Any, Optional, List
from datetime import datetime

try:
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from .base_provider import BaseAIProvider, AIRequest, AIResponse


class CopilotProvider(BaseAIProvider):
    """
    Provedor GitHub Copilot com autenticação completa e controle de tokens.
    
    Funcionalidades implementadas:
    - Múltiplos métodos de autenticação GitHub
    - Rate limiting específico para Copilot
    - Controle de tokens por requisição
    - Faseamento automático para grandes análises
    - Suporte a GitHub Enterprise
    - Tratamento robusto de erros
    """
    
    def __init__(self, name: str, config: Dict[str, Any]):
        """
        Inicializa o provedor GitHub Copilot.
        
        Configurações suportadas:
        - github_token: Token de acesso GitHub
        - github_org: Organização GitHub (opcional)
        - github_enterprise_url: URL GitHub Enterprise (opcional)
        - github_app_id: ID da GitHub App (opcional)
        - model: Modelo Copilot (default: gpt-4)
        - max_tokens: Tokens máximos por requisição
        - rate_limit_delay: Delay entre requisições
        """
        super().__init__(name, config)
        
        # Verificar dependências
        if not REQUESTS_AVAILABLE:
            self.logger.error("Biblioteca 'requests' não encontrada. Execute: pip install requests>=2.31.0")
            self.enabled = False
            return
        
        # Configurações de autenticação
        self.github_token = config.get('github_token', '')
        self.github_org = config.get('github_org', '')
        self.github_enterprise_url = config.get('github_enterprise_url', '')
        self.github_app_id = config.get('github_app_id', '')
        
        # Configurações da API
        self.base_url = self.github_enterprise_url or 'https://api.github.com'
        self.copilot_endpoint = f"{self.base_url}/copilot/chat/completions"
        
        # Configurações do modelo
        self.model = config.get('model', 'gpt-4')
        self.rate_limit_delay = config.get('rate_limit_delay', 2.0)
        
        # Configurações de faseamento
        self.enable_phasing = config.get('enable_phasing', True)
        self.max_tokens_per_phase = config.get('max_tokens_per_phase', 3000)
        
        # Configurar sessão HTTP
        self.session = requests.Session()
        retry_strategy = Retry(
            total=3,
            status_forcelist=[429, 500, 502, 503, 504],
            method_whitelist=["HEAD", "GET", "POST"],
            backoff_factor=2
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
        
        # Headers padrão
        self._setup_headers()
        
        # Validar configuração
        if not self.github_token:
            self.logger.warning("Token GitHub Copilot não configurado")
            self.enabled = False
        
        self.logger.info(f"GitHub Copilot Provider inicializado - Org: {self.github_org or 'N/A'}")
    
    def _setup_headers(self):
        """Configura headers de autenticação GitHub."""
        headers = {
            'Authorization': f'Bearer {self.github_token}',
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28',
            'User-Agent': 'COBOL-AI-Engine/2.1.0',
            'Content-Type': 'application/json'
        }
        
        # Adicionar organização se especificada
        if self.github_org:
            headers['X-GitHub-Org'] = self.github_org
        
        # Adicionar App ID se especificado
        if self.github_app_id:
            headers['X-GitHub-App-Id'] = self.github_app_id
        
        self.session.headers.update(headers)
    
    def is_available(self) -> bool:
        """Verifica se GitHub Copilot está disponível."""
        if not self.enabled or not REQUESTS_AVAILABLE:
            return False
        
        if not self.github_token:
            return False
        
        try:
            # Verificar acesso ao Copilot
            return self._test_copilot_access()
        except Exception as e:
            self.logger.debug(f"GitHub Copilot não disponível: {str(e)}")
            return False
    
    def _test_copilot_access(self) -> bool:
        """Testa acesso ao GitHub Copilot."""
        try:
            # Endpoint para verificar acesso ao Copilot
            test_url = f"{self.base_url}/user"
            
            response = self.session.get(test_url, timeout=10)
            
            if response.status_code == 200:
                user_data = response.json()
                self.logger.debug(f"Acesso GitHub confirmado para usuário: {user_data.get('login', 'unknown')}")
                return True
            else:
                self.logger.debug(f"Falha no teste de acesso GitHub: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.debug(f"Erro no teste de acesso: {str(e)}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando GitHub Copilot com faseamento automático se necessário.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta da análise
        """
        if not self._validate_request(request):
            response = self._create_error_response("Requisição inválida")
            self._update_statistics(response)
            return response
        
        try:
            # Verificar se precisa de faseamento
            if self.enable_phasing and self._needs_phasing(request):
                return self._analyze_with_phasing(request)
            else:
                return self._analyze_single_request(request)
                
        except Exception as e:
            self.logger.error(f"Erro na análise Copilot: {str(e)}")
            response = self._create_error_response(f"Erro Copilot: {str(e)}")
            self._update_statistics(response)
            return response
    
    def _needs_phasing(self, request: AIRequest) -> bool:
        """Determina se a requisição precisa de faseamento."""
        # Estimativa: ~4 caracteres por token
        estimated_tokens = len(request.prompt) // 4
        total_estimated = estimated_tokens + request.max_tokens
        
        return total_estimated > self.max_tokens_per_phase
    
    def _analyze_with_phasing(self, request: AIRequest) -> AIResponse:
        """Realiza análise com faseamento automático."""
        self.logger.info("Iniciando análise Copilot com faseamento automático")
        
        # Dividir em fases específicas para COBOL
        phases = self._create_cobol_phases(request)
        
        all_responses = []
        total_tokens = 0
        
        for i, phase_request in enumerate(phases):
            self.logger.debug(f"Executando fase Copilot {i+1}/{len(phases)}")
            
            # Aplicar rate limiting
            if i > 0:
                time.sleep(self.rate_limit_delay)
            
            # Executar fase
            phase_response = self._analyze_single_request(phase_request)
            
            if phase_response.success:
                all_responses.append({
                    'phase_name': phase_request.context.get('phase_name', f'Fase {i+1}'),
                    'content': phase_response.content
                })
                total_tokens += phase_response.tokens_used
            else:
                # Se uma fase falha, retornar erro
                return phase_response
        
        # Consolidar respostas
        consolidated_content = self._consolidate_copilot_responses(all_responses)
        
        # Criar resposta final
        final_response = AIResponse(
            content=consolidated_content,
            tokens_used=total_tokens,
            provider_name=self.name,
            model_name=self.model,
            success=True
        )
        
        self._update_statistics(final_response)
        return final_response
    
    def _create_cobol_phases(self, request: AIRequest) -> List[AIRequest]:
        """Cria fases específicas para análise COBOL."""
        phases = []
        
        # Fases otimizadas para Copilot (foco em código)
        cobol_phases = [
            {
                "name": "Estrutura e Sintaxe",
                "prompt_suffix": "\n\nAnalise especificamente: estrutura do programa COBOL, divisões, seções, sintaxe e organização do código."
            },
            {
                "name": "Lógica Funcional",
                "prompt_suffix": "\n\nAnalise especificamente: O que este programa faz funcionalmente? Qual é o processo de negócio implementado? Qual é o objetivo principal?"
            },
            {
                "name": "Fluxo de Dados",
                "prompt_suffix": "\n\nAnalise especificamente: fluxo de dados, variáveis, estruturas de dados, arquivos de entrada e saída."
            },
            {
                "name": "Otimizações e Melhorias",
                "prompt_suffix": "\n\nAnalise especificamente: possíveis melhorias no código, otimizações, boas práticas e sugestões de refatoração."
            }
        ]
        
        base_prompt = request.prompt
        
        for phase_info in cobol_phases:
            phase_prompt = base_prompt + phase_info["prompt_suffix"]
            
            phase_request = AIRequest(
                prompt=phase_prompt,
                context=request.context.copy() if request.context else {},
                max_tokens=min(request.max_tokens // len(cobol_phases), self.max_tokens_per_phase),
                temperature=request.temperature
            )
            
            # Adicionar contexto da fase
            if phase_request.context is None:
                phase_request.context = {}
            phase_request.context['phase_name'] = phase_info["name"]
            
            phases.append(phase_request)
        
        return phases
    
    def _consolidate_copilot_responses(self, responses: List[Dict[str, str]]) -> str:
        """Consolida respostas de múltiplas fases do Copilot."""
        consolidated = "# Análise COBOL Completa (GitHub Copilot Faseado)\n\n"
        
        for response_data in responses:
            phase_name = response_data['phase_name']
            content = response_data['content']
            
            consolidated += f"## {phase_name}\n\n"
            consolidated += content.strip() + "\n\n"
        
        consolidated += "---\n"
        consolidated += f"*Análise gerada com GitHub Copilot - {len(responses)} fases especializadas*\n"
        
        return consolidated
    
    def _analyze_single_request(self, request: AIRequest) -> AIResponse:
        """Realiza análise em requisição única via GitHub Copilot."""
        try:
            # Aplicar rate limiting
            time.sleep(self.rate_limit_delay)
            
            # Preparar payload para Copilot
            payload = {
                "model": self.model,
                "messages": [
                    {
                        "role": "system",
                        "content": "Você é um especialista em análise de código COBOL com foco em sistemas mainframe e bancários. Forneça análises técnicas precisas e orientadas ao negócio."
                    },
                    {
                        "role": "user",
                        "content": request.prompt
                    }
                ],
                "max_tokens": request.max_tokens,
                "temperature": request.temperature,
                "stream": False
            }
            
            # Fazer requisição
            start_time = time.time()
            
            response = self.session.post(
                self.copilot_endpoint,
                json=payload,
                timeout=self.timeout
            )
            
            end_time = time.time()
            
            # Processar resposta
            if response.status_code == 200:
                return self._process_copilot_response(response.json(), end_time - start_time)
            elif response.status_code == 401:
                return self._create_error_response("Token GitHub Copilot inválido ou expirado")
            elif response.status_code == 403:
                return self._create_error_response("Acesso negado ao GitHub Copilot")
            elif response.status_code == 429:
                return self._create_error_response("Rate limit GitHub Copilot atingido")
            else:
                return self._create_error_response(f"Erro Copilot: {response.status_code} - {response.text}")
                
        except requests.exceptions.Timeout:
            return self._create_error_response("Timeout na requisição Copilot")
        
        except requests.exceptions.ConnectionError:
            return self._create_error_response("Erro de conexão com GitHub Copilot")
        
        except Exception as e:
            self.logger.error(f"Erro inesperado Copilot: {str(e)}")
            return self._create_error_response(f"Erro: {str(e)}")
    
    def _process_copilot_response(self, response_data: Dict[str, Any], response_time: float) -> AIResponse:
        """Processa resposta do GitHub Copilot."""
        try:
            # Extrair conteúdo
            choices = response_data.get('choices', [])
            if not choices:
                return self._create_error_response("Resposta Copilot sem choices")
            
            message = choices[0].get('message', {})
            content = message.get('content', '')
            
            if not content:
                return self._create_error_response("Resposta Copilot vazia")
            
            # Extrair informações de uso
            usage = response_data.get('usage', {})
            total_tokens = usage.get('total_tokens', 0)
            input_tokens = usage.get('prompt_tokens', 0)
            output_tokens = usage.get('completion_tokens', 0)
            
            # Informações do modelo
            model_used = response_data.get('model', self.model)
            
            # Adicionar metadados Copilot
            copilot_metadata = f"\n\n---\n**GitHub Copilot Analysis**\n"
            copilot_metadata += f"- Modelo: {model_used}\n"
            copilot_metadata += f"- Organização: {self.github_org or 'Personal'}\n"
            copilot_metadata += f"- Tempo de resposta: {response_time:.2f}s\n"
            
            content += copilot_metadata
            
            return AIResponse(
                content=content,
                tokens_used=total_tokens,
                provider_name=self.name,
                model_name=model_used,
                success=True,
                input_tokens=input_tokens,
                output_tokens=output_tokens
            )
            
        except Exception as e:
            self.logger.error(f"Erro ao processar resposta Copilot: {str(e)}")
            return self._create_error_response(f"Erro no processamento: {str(e)}")
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações específicas do provedor Copilot."""
        base_info = self.get_statistics()
        
        copilot_info = {
            "model": self.model,
            "github_org": self.github_org,
            "github_enterprise_url": self.github_enterprise_url,
            "github_app_id": self.github_app_id,
            "copilot_endpoint": self.copilot_endpoint,
            "rate_limit_delay": self.rate_limit_delay,
            "enable_phasing": self.enable_phasing,
            "max_tokens_per_phase": self.max_tokens_per_phase,
            "has_token": bool(self.github_token)
        }
        
        base_info.update(copilot_info)
        return base_info

