"""
COBOL AI Engine v2.1.0 - Documentation Generator
Gerador completo de documentação com suporte a faseamento e múltiplos formatos.
"""

import logging
import os
from typing import Dict, Any, List, Optional
from datetime import datetime

from ..parsers.cobol_parser import CobolProgram, CobolBook
from ..providers.base_provider import AIResponse


class DocumentationGenerator:
    """
    Gerador de documentação completo para programas COBOL.
    
    Funcionalidades:
    - Geração de documentação individual por programa
    - Relatório consolidado
    - Suporte a metadados de faseamento
    - Múltiplos formatos de saída
    - Estatísticas detalhadas
    """
    
    def __init__(self, output_dir: str = "output"):
        """
        Inicializa o gerador de documentação.
        
        Args:
            output_dir: Diretório de saída
        """
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        
        # Criar diretório de saída
        os.makedirs(output_dir, exist_ok=True)
        
        # Estatísticas
        self.files_generated = 0
        self.total_programs = 0
        self.total_books = 0
        
        self.logger.info(f"Documentation Generator inicializado - Output: {output_dir}")
    
    def generate_program_documentation(self, program: CobolProgram, 
                                     ai_response: AIResponse,
                                     phase_info: Optional[Dict[str, Any]] = None) -> str:
        """
        Gera documentação para um programa específico.
        
        Args:
            program: Programa COBOL
            ai_response: Resposta da análise de IA
            phase_info: Informações de faseamento (opcional)
            
        Returns:
            Caminho do arquivo gerado
        """
        
        try:
            # Nome do arquivo
            filename = f"{program.name}.md"
            filepath = os.path.join(self.output_dir, filename)
            
            # Gerar conteúdo
            content = self._generate_program_content(program, ai_response, phase_info)
            
            # Escrever arquivo
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.files_generated += 1
            self.logger.info(f"Documentação gerada: {filename}")
            
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação para {program.name}: {str(e)}")
            return ""
    
    def _generate_program_content(self, program: CobolProgram, 
                                ai_response: AIResponse,
                                phase_info: Optional[Dict[str, Any]] = None) -> str:
        """Gera conteúdo da documentação do programa."""
        
        # Obter documentação de prompts se disponível
        prompt_documentation = ""
        if hasattr(ai_response, 'prompt_manager') and ai_response.prompt_manager:
            prompt_documentation = ai_response.prompt_manager.get_prompt_documentation()
        
        content = f"""# Documentação - {program.name}

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}

## Informações Básicas

- **Nome**: {program.name}
- **Linhas de Código**: {program.line_count}
- **Tamanho**: {program.size} caracteres

## Análise com IA

{ai_response.content}

{prompt_documentation}

## Informações Técnicas Detalhadas

### Divisões Identificadas
"""
        
        # Adicionar divisões
        if program.divisions:
            for division_name, division_content in program.divisions.items():
                content += f"- **{division_name} DIVISION**: {len(division_content.split())} linhas\n"
        else:
            content += "- Nenhuma divisão identificada\n"
        
        # Adicionar seções
        content += "\n### Seções Identificadas\n"
        if program.sections:
            for section in program.sections[:10]:  # Limitar a 10
                content += f"- {section}\n"
        else:
            content += "- Nenhuma seção identificada\n"
        
        # Adicionar variáveis
        content += "\n### Principais Variáveis\n"
        if program.variables:
            for variable in program.variables[:15]:  # Limitar a 15
                content += f"- {variable}\n"
        else:
            content += "- Nenhuma variável identificada\n"
        
        # Adicionar arquivos
        content += "\n### Arquivos Utilizados\n"
        if program.files:
            for file_name in program.files:
                content += f"- {file_name}\n"
        else:
            content += "- Nenhum arquivo identificado\n"
        
        # Adicionar metadados da análise
        content += f"\n## Metadados da Análise\n\n"
        content += f"- **Provedor**: {ai_response.provider_name}\n"
        content += f"- **Modelo**: {ai_response.model_name}\n"
        content += f"- **Tokens Utilizados**: {ai_response.tokens_used}\n"
        content += f"- **Timestamp**: {ai_response.timestamp}\n"
        
        # Adicionar informações de faseamento se disponível
        if phase_info:
            content += f"\n### Informações de Faseamento\n\n"
            content += f"- **Faseamento Habilitado**: {phase_info.get('phasing_enabled', 'N/A')}\n"
            content += f"- **Número de Fases**: {phase_info.get('total_phases', 'N/A')}\n"
            content += f"- **Tokens por Fase**: {phase_info.get('tokens_per_phase', 'N/A')}\n"
            
            if 'phases_executed' in phase_info:
                content += f"- **Fases Executadas**: {', '.join(phase_info['phases_executed'])}\n"
        
        # Adicionar breakdown de tokens se disponível
        if ai_response.input_tokens > 0 or ai_response.output_tokens > 0:
            content += f"\n### Breakdown de Tokens\n\n"
            content += f"- **Tokens de Entrada**: {ai_response.input_tokens}\n"
            content += f"- **Tokens de Saída**: {ai_response.output_tokens}\n"
            content += f"- **Total**: {ai_response.tokens_used}\n"
        
        content += f"\n---\n*Documentação gerada pelo COBOL AI Engine v2.1.0*"
        
        return content
    
    def generate_consolidated_report(self, programs: List[CobolProgram],
                                   books: List[CobolBook],
                                   analysis_results: Dict[str, AIResponse],
                                   system_stats: Optional[Dict[str, Any]] = None) -> str:
        """
        Gera relatório consolidado de toda a análise.
        
        Args:
            programs: Lista de programas analisados
            books: Lista de copybooks
            analysis_results: Resultados das análises
            system_stats: Estatísticas do sistema (opcional)
            
        Returns:
            Caminho do arquivo gerado
        """
        
        try:
            filename = "relatorio_consolidado.md"
            filepath = os.path.join(self.output_dir, filename)
            
            # Gerar conteúdo
            content = self._generate_consolidated_content(programs, books, analysis_results, system_stats)
            
            # Escrever arquivo
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.files_generated += 1
            self.logger.info(f"Relatório consolidado gerado: {filename}")
            
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório consolidado: {str(e)}")
            return ""
    
    def _generate_consolidated_content(self, programs: List[CobolProgram],
                                     books: List[CobolBook],
                                     analysis_results: Dict[str, AIResponse],
                                     system_stats: Optional[Dict[str, Any]] = None) -> str:
        """Gera conteúdo do relatório consolidado."""
        
        content = f"""# Relatório Consolidado - Análise COBOL

**Data de Geração**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**COBOL AI Engine**: v2.1.0

## Resumo Executivo

### Estatísticas Gerais
- **Programas Analisados**: {len(programs)}
- **Copybooks Processados**: {len(books)}
- **Arquivos de Documentação Gerados**: {self.files_generated}
- **Total de Análises Realizadas**: {len(analysis_results)}

### Programas Processados
"""
        
        # Lista de programas
        for program in programs:
            content += f"- **{program.name}**: {program.line_count} linhas, {program.size} caracteres\n"
        
        # Lista de copybooks
        if books:
            content += f"\n### Copybooks Processados\n"
            for book in books:
                content += f"- **{book.name}**: {book.line_count} linhas, {len(book.structures)} estruturas\n"
        
        # Estatísticas de análise
        content += f"\n## Estatísticas de Análise\n\n"
        
        total_tokens = sum(response.tokens_used for response in analysis_results.values())
        successful_analyses = sum(1 for response in analysis_results.values() if response.success)
        
        content += f"- **Total de Tokens Utilizados**: {total_tokens}\n"
        content += f"- **Análises Bem-sucedidas**: {successful_analyses}/{len(analysis_results)}\n"
        content += f"- **Taxa de Sucesso**: {(successful_analyses/len(analysis_results)*100):.1f}%\n"
        
        # Breakdown por provedor
        provider_usage = {}
        for response in analysis_results.values():
            provider = response.provider_name
            if provider not in provider_usage:
                provider_usage[provider] = {'count': 0, 'tokens': 0}
            provider_usage[provider]['count'] += 1
            provider_usage[provider]['tokens'] += response.tokens_used
        
        if provider_usage:
            content += f"\n### Uso por Provedor\n"
            for provider, stats in provider_usage.items():
                content += f"- **{provider}**: {stats['count']} análises, {stats['tokens']} tokens\n"
        
        # Estatísticas do sistema se disponível
        if system_stats:
            content += f"\n## Estatísticas do Sistema\n\n"
            
            if 'processing_time' in system_stats:
                content += f"- **Tempo de Processamento**: {system_stats['processing_time']:.2f}s\n"
            
            if 'phasing_enabled' in system_stats:
                content += f"- **Faseamento Habilitado**: {system_stats['phasing_enabled']}\n"
            
            if 'total_phases' in system_stats:
                content += f"- **Total de Fases Executadas**: {system_stats['total_phases']}\n"
            
            if 'providers_used' in system_stats:
                content += f"- **Provedores Utilizados**: {', '.join(system_stats['providers_used'])}\n"
        
        # Detalhes por programa
        content += f"\n## Detalhes por Programa\n\n"
        
        for program in programs:
            content += f"### {program.name}\n\n"
            
            # Informações básicas
            content += f"- **Linhas**: {program.line_count}\n"
            content += f"- **Tamanho**: {program.size} caracteres\n"
            content += f"- **Divisões**: {len(program.divisions)}\n"
            content += f"- **Seções**: {len(program.sections)}\n"
            content += f"- **Variáveis**: {len(program.variables)}\n"
            content += f"- **Arquivos**: {len(program.files)}\n"
            
            # Resultado da análise
            if program.name in analysis_results:
                response = analysis_results[program.name]
                content += f"- **Análise**: {'Sucesso' if response.success else 'Falha'}\n"
                content += f"- **Provedor**: {response.provider_name}\n"
                content += f"- **Tokens**: {response.tokens_used}\n"
            
            content += f"\n"
        
        # Recomendações
        content += f"## Recomendações\n\n"
        content += f"1. **Documentação**: Revisar documentação gerada para cada programa\n"
        content += f"2. **Manutenção**: Considerar refatoração de programas com alta complexidade\n"
        content += f"3. **Testes**: Implementar testes automatizados para validar funcionalidades\n"
        content += f"4. **Monitoramento**: Estabelecer métricas de performance para os programas\n"
        
        content += f"\n---\n*Relatório gerado pelo COBOL AI Engine v2.1.0*"
        
        return content
    
    def generate_system_status_report(self, status_data: Dict[str, Any]) -> str:
        """
        Gera relatório de status do sistema.
        
        Args:
            status_data: Dados de status do sistema
            
        Returns:
            Caminho do arquivo gerado
        """
        
        try:
            filename = "system_status_report.json"
            filepath = os.path.join(self.output_dir, filename)
            
            # Adicionar timestamp
            status_data['report_generated_at'] = datetime.now().isoformat()
            status_data['generator_version'] = "2.1.0"
            
            # Escrever arquivo JSON
            import json
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(status_data, f, indent=2, ensure_ascii=False)
            
            self.files_generated += 1
            self.logger.info(f"Relatório de status gerado: {filename}")
            
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório de status: {str(e)}")
            return ""
    
    def get_generator_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do gerador."""
        
        return {
            "files_generated": self.files_generated,
            "output_directory": self.output_dir,
            "total_programs_processed": self.total_programs,
            "total_books_processed": self.total_books,
            "supported_formats": ["Markdown", "JSON"],
            "features": [
                "Individual program documentation",
                "Consolidated reporting",
                "Phase information tracking",
                "Token usage analysis",
                "System status reporting"
            ]
        }

