# COBOL AI Engine v2.1.0 - Manual Completo de Configuração

**Versão**: 2.1.0  
**Data**: 09 de Setembro de 2025  
**Documento**: Manual Completo de Configuração e Execução

---

## Índice

1. [Visão Geral](#visão-geral)
2. [Métodos de Autenticação](#métodos-de-autenticação)
3. [Configuração de Provedores](#configuração-de-provedores)
4. [Sistema de Faseamento](#sistema-de-faseamento)
5. [Controle de Tokens](#controle-de-tokens)
6. [Formas de Execução](#formas-de-execução)
7. [Configurações Avançadas](#configurações-avançadas)
8. [Troubleshooting](#troubleshooting)

---

## Visão Geral

O COBOL AI Engine v2.1.0 suporta múltiplos provedores de IA com diferentes métodos de autenticação e configuração. Cada provedor possui características específicas e pode ser configurado independentemente.

### Provedores Suportados

1. **LuzIA Provider** - OAuth2 + Knowledge Base + Guardrails
2. **OpenAI Provider** - API Key + Organização + Azure
3. **GitHub Copilot Provider** - GitHub Token + Organização
4. **Enhanced Mock Provider** - Sempre disponível (fallback)
5. **Basic Provider** - Fallback final garantido

---

## Métodos de Autenticação

### 1. LuzIA Provider - Autenticação OAuth2

#### Método 1: Client Credentials Flow (Recomendado)
```bash
# Variáveis de ambiente
export LUZIA_CLIENT_ID="seu_client_id_aqui"
export LUZIA_CLIENT_SECRET="seu_client_secret_aqui"
```

#### Método 2: Configuração no arquivo YAML
```yaml
ai:
  providers:
    luzia:
      enabled: true
      client_id: "${LUZIA_CLIENT_ID}"
      client_secret: "${LUZIA_CLIENT_SECRET}"
      endpoint: "https://gpt-api.aws.santanderbr.dev.corp/genai_services/v1"
      auth_endpoint: "https://login.azure-ad.santanderbr.dev.corp/oauth2/token"
      model: "aws-claude-1-3-sonnet-exp"
      api_version: "2023-05-15"
      
      # Knowledge Base e Guardrails
      knowledge_base_id: "KNOWLEDGE_BASE_COBOL"
      guardrail_id: "GUARDRAIL_BANKING"
      guardrail_version: "GUARDRAIL_VERSION"
      
      # Configurações de performance
      performance_config: "optimized"
      auto_refresh_token: true
      rate_limit_delay: 2.0
      timeout: 120
      
      # Faseamento
      enable_phasing: true
      max_tokens_per_phase: 4000
```

#### Método 3: Autenticação Fresca (Baseado na Documentação)
```yaml
luzia:
  # Autenticação fresca a cada requisição
  fresh_auth_per_request: true
  
  # Configurações OAuth2 específicas
  oauth2:
    grant_type: "client_credentials"
    scope: "genai_services"
    token_endpoint: "https://login.azure-ad.santanderbr.dev.corp/oauth2/token"
    
  # Headers específicos
  headers:
    User-Agent: "COBOL-AI-Engine/2.1.0"
    X-API-Version: "2023-05-15"
```

### 2. OpenAI Provider - Múltiplos Métodos

#### Método 1: API Key Simples
```bash
export OPENAI_API_KEY="sk-proj-..."
```

#### Método 2: API Key + Organização
```bash
export OPENAI_API_KEY="sk-proj-..."
export OPENAI_ORG_ID="org-..."
```

#### Método 3: API Key + Projeto
```bash
export OPENAI_API_KEY="sk-proj-..."
export OPENAI_PROJECT_ID="proj_..."
```

#### Método 4: Azure OpenAI
```bash
export AZURE_OPENAI_KEY="sua_chave_azure"
export AZURE_OPENAI_ENDPOINT="https://seu-recurso.openai.azure.com/"
```

#### Configuração Completa OpenAI
```yaml
ai:
  providers:
    openai:
      enabled: true
      
      # Autenticação básica
      api_key: "${OPENAI_API_KEY}"
      organization: "${OPENAI_ORG_ID}"  # opcional
      project: "${OPENAI_PROJECT_ID}"   # opcional
      
      # Azure OpenAI (alternativo)
      azure_endpoint: "${AZURE_OPENAI_ENDPOINT}"
      azure_api_version: "2024-02-15-preview"
      
      # Configurações do modelo
      model: "gpt-4"
      max_tokens: 4000
      temperature: 0.7
      rate_limit_delay: 1.0
      timeout: 60
      
      # Faseamento automático
      enable_phasing: true
      max_tokens_per_phase: 4000
      phase_overlap_tokens: 200
```

### 3. GitHub Copilot Provider - Autenticação GitHub

#### Método 1: Personal Access Token
```bash
export GITHUB_COPILOT_TOKEN="ghp_..."
```

#### Método 2: Token + Organização
```bash
export GITHUB_COPILOT_TOKEN="ghp_..."
export GITHUB_ORG="sua_organizacao"
```

#### Método 3: GitHub Enterprise
```bash
export GITHUB_COPILOT_TOKEN="ghp_..."
export GITHUB_ENTERPRISE_URL="https://github.sua-empresa.com"
```

#### Método 4: GitHub App
```bash
export GITHUB_APP_TOKEN="ghs_..."
export GITHUB_APP_ID="123456"
```

#### Configuração Completa Copilot
```yaml
ai:
  providers:
    copilot:
      enabled: true
      
      # Autenticação
      github_token: "${GITHUB_COPILOT_TOKEN}"
      github_org: "${GITHUB_ORG}"                    # opcional
      github_enterprise_url: "${GITHUB_ENTERPRISE_URL}" # opcional
      github_app_id: "${GITHUB_APP_ID}"              # opcional
      
      # Configurações
      model: "gpt-4"
      max_tokens: 3000
      rate_limit_delay: 2.0
      timeout: 60
      
      # Faseamento específico para código
      enable_phasing: true
      max_tokens_per_phase: 3000
```

---

## Configuração de Provedores

### Arquivo de Configuração Principal

#### config/config.yaml (Configuração Básica)
```yaml
# COBOL AI Engine v2.1.0 - Configuração Básica
ai:
  # Provedor primário (primeiro a ser tentado)
  primary_provider: "enhanced_mock"
  
  # Provedores de fallback (ordem de tentativa)
  fallback_providers: 
    - "basic"
  
  # Configurações globais
  global_timeout: 120
  global_max_tokens: 4000
  enable_fallback: true
  
  # Provedores disponíveis
  providers:
    enhanced_mock:
      enabled: true
      response_delay: 0.1
      enable_phasing: true
      max_tokens_per_phase: 2000
      simulate_realistic_tokens: true
    
    basic:
      enabled: true
      max_tokens: 1000
```

#### config/config_complete.yaml (Configuração Completa)
```yaml
# COBOL AI Engine v2.1.0 - Configuração Completa
ai:
  # Estratégia de provedores
  primary_provider: "luzia"
  fallback_providers: 
    - "openai"
    - "copilot"
    - "enhanced_mock"
    - "basic"
  
  # Configurações globais
  global_timeout: 120
  global_max_tokens: 4000
  enable_fallback: true
  max_retries: 3
  retry_delay: 2.0
  
  # Sistema de faseamento global
  phasing:
    enabled: true
    max_phases: 7
    overlap_tokens: 200
    adaptive_phasing: true
  
  # Controle de tokens global
  token_management:
    enabled: true
    budget_tracking: true
    cost_optimization: true
  
  # Provedores
  providers:
    # LuzIA - Provedor corporativo
    luzia:
      enabled: true
      client_id: "${LUZIA_CLIENT_ID}"
      client_secret: "${LUZIA_CLIENT_SECRET}"
      endpoint: "https://gpt-api.aws.santanderbr.dev.corp/genai_services/v1"
      auth_endpoint: "https://login.azure-ad.santanderbr.dev.corp/oauth2/token"
      model: "aws-claude-1-3-sonnet-exp"
      api_version: "2023-05-15"
      knowledge_base_id: "KNOWLEDGE_BASE_COBOL"
      guardrail_id: "GUARDRAIL_BANKING"
      guardrail_version: "GUARDRAIL_VERSION"
      performance_config: "optimized"
      auto_refresh_token: true
      rate_limit_delay: 2.0
      timeout: 120
      enable_phasing: true
      max_tokens_per_phase: 4000
    
    # OpenAI - Provedor público
    openai:
      enabled: false  # Habilitar quando necessário
      api_key: "${OPENAI_API_KEY}"
      organization: "${OPENAI_ORG_ID}"
      model: "gpt-4"
      max_tokens: 4000
      temperature: 0.7
      rate_limit_delay: 1.0
      timeout: 60
      enable_phasing: true
      max_tokens_per_phase: 4000
    
    # GitHub Copilot - Provedor de código
    copilot:
      enabled: false  # Habilitar quando necessário
      github_token: "${GITHUB_COPILOT_TOKEN}"
      github_org: "${GITHUB_ORG}"
      model: "gpt-4"
      max_tokens: 3000
      rate_limit_delay: 2.0
      timeout: 60
      enable_phasing: true
      max_tokens_per_phase: 3000
    
    # Enhanced Mock - Fallback inteligente
    enhanced_mock:
      enabled: true
      response_delay: 0.1
      enable_phasing: true
      max_tokens_per_phase: 2000
      simulate_realistic_tokens: true
    
    # Basic - Fallback final
    basic:
      enabled: true
      max_tokens: 1000
```

---

## Sistema de Faseamento

### Configuração de Faseamento por Provedor

#### Faseamento Automático (Recomendado)
```yaml
ai:
  providers:
    luzia:
      enable_phasing: true
      max_tokens_per_phase: 4000
      phase_overlap_tokens: 200
      adaptive_phasing: true
      
      # Fases específicas para COBOL
      cobol_phases:
        - name: "basic_info"
          priority: 1
          max_tokens: 300
          required: true
        - name: "functional_analysis"
          priority: 1
          max_tokens: 600
          required: true
        - name: "technical_analysis"
          priority: 2
          max_tokens: 800
          required: false
        - name: "business_rules"
          priority: 2
          max_tokens: 600
          required: false
        - name: "data_flow"
          priority: 3
          max_tokens: 500
          required: false
        - name: "relationships"
          priority: 3
          max_tokens: 400
          required: false
        - name: "optimization"
          priority: 3
          max_tokens: 300
          required: false
```

#### Faseamento Manual
```yaml
ai:
  providers:
    openai:
      enable_phasing: true
      manual_phases:
        - prompt_suffix: "Foque apenas em: informações básicas e estrutura geral."
          max_tokens: 400
        - prompt_suffix: "Foque apenas em: O que este programa faz funcionalmente?"
          max_tokens: 600
        - prompt_suffix: "Foque apenas em: análise técnica detalhada."
          max_tokens: 800
        - prompt_suffix: "Foque apenas em: regras de negócio e validações."
          max_tokens: 600
```

### Controle de Faseamento por Orçamento

```yaml
ai:
  token_management:
    enabled: true
    
    # Orçamentos por provedor
    provider_budgets:
      luzia:
        max_tokens_per_request: 4000
        max_tokens_per_hour: 20000
        max_tokens_per_day: 100000
      
      openai:
        max_tokens_per_request: 4000
        max_tokens_per_hour: 40000
        max_tokens_per_day: 200000
    
    # Estratégia de faseamento baseada em orçamento
    budget_phasing:
      enabled: true
      reserve_percentage: 20  # Reservar 20% do orçamento
      
      # Fases obrigatórias (sempre executadas)
      mandatory_phases:
        - "basic_info"
        - "functional_analysis"
      
      # Fases opcionais (baseadas em orçamento disponível)
      optional_phases:
        - "technical_analysis"
        - "business_rules"
        - "data_flow"
        - "relationships"
        - "optimization"
```

---

## Controle de Tokens

### Configuração de Orçamentos

```yaml
ai:
  token_management:
    enabled: true
    budget_tracking: true
    cost_optimization: true
    
    # Orçamentos globais
    global_budgets:
      max_tokens_per_analysis: 10000
      max_tokens_per_hour: 100000
      max_tokens_per_day: 500000
    
    # Orçamentos por provedor
    provider_budgets:
      luzia:
        max_tokens_per_request: 4000
        max_tokens_per_hour: 20000
        max_tokens_per_day: 100000
        cost_per_1k_tokens: 0.015  # USD
      
      openai:
        max_tokens_per_request: 4000
        max_tokens_per_hour: 40000
        max_tokens_per_day: 200000
        cost_per_1k_tokens: 0.03   # USD
      
      copilot:
        max_tokens_per_request: 3000
        max_tokens_per_hour: 30000
        max_tokens_per_day: 150000
        cost_per_1k_tokens: 0.02   # USD
    
    # Estratégias de otimização
    optimization:
      enabled: true
      
      # Seleção automática do provedor mais econômico
      cost_optimization: true
      
      # Ajuste automático de parâmetros
      adaptive_parameters: true
      
      # Faseamento inteligente baseado em orçamento
      intelligent_phasing: true
      
      # Alertas de orçamento
      budget_alerts:
        enabled: true
        warning_threshold: 80  # Alerta aos 80%
        critical_threshold: 95 # Crítico aos 95%
```

### Monitoramento de Uso

```yaml
ai:
  monitoring:
    enabled: true
    
    # Métricas coletadas
    metrics:
      - "tokens_used"
      - "cost_incurred"
      - "response_time"
      - "success_rate"
      - "provider_performance"
    
    # Relatórios automáticos
    reporting:
      enabled: true
      frequency: "daily"
      include_cost_analysis: true
      include_performance_metrics: true
    
    # Logs detalhados
    logging:
      level: "INFO"
      include_token_usage: true
      include_provider_selection: true
      include_phasing_decisions: true
```

---

## Formas de Execução

### 1. Execução Básica

#### Comando Simples
```bash
# Análise básica com Enhanced Mock
python main.py --fontes examples/fontes.txt

# Análise com books
python main.py --fontes examples/fontes.txt --books examples/BOOKS.txt

# Especificar diretório de saída
python main.py --fontes examples/fontes.txt --output results
```

### 2. Execução Avançada

#### Sistema Aprimorado (Recomendado)
```bash
# Análise completa com faseamento
python main_enhanced.py --fontes examples/fontes.txt --output results

# Análise com configuração específica
python main_enhanced.py --config config/config_complete.yaml --fontes examples/fontes.txt

# Análise sem faseamento
python main_enhanced.py --fontes examples/fontes.txt --no-phasing

# Análise com log detalhado
python main_enhanced.py --fontes examples/fontes.txt --log-level DEBUG

# Status do sistema
python main_enhanced.py --status

# Versão do sistema
python main_enhanced.py --version
```

### 3. Execução com Provedores Específicos

#### Forçar Provedor Específico
```bash
# Usar apenas LuzIA
python main_enhanced.py --provider luzia --fontes examples/fontes.txt

# Usar apenas OpenAI
python main_enhanced.py --provider openai --fontes examples/fontes.txt

# Usar apenas Copilot
python main_enhanced.py --provider copilot --fontes examples/fontes.txt

# Usar Enhanced Mock
python main_enhanced.py --provider enhanced_mock --fontes examples/fontes.txt
```

#### Configurar Fallback Customizado
```bash
# Ordem específica de fallback
python main_enhanced.py --providers "luzia,openai,enhanced_mock" --fontes examples/fontes.txt

# Desabilitar fallback
python main_enhanced.py --no-fallback --provider openai --fontes examples/fontes.txt
```

### 4. Execução com Controle de Tokens

#### Orçamento Específico
```bash
# Limitar tokens por análise
python main_enhanced.py --max-tokens 5000 --fontes examples/fontes.txt

# Orçamento por provedor
python main_enhanced.py --provider-budget "luzia:3000,openai:4000" --fontes examples/fontes.txt

# Modo econômico
python main_enhanced.py --economy-mode --fontes examples/fontes.txt
```

### 5. Execução em Lote

#### Múltiplos Arquivos
```bash
# Processar múltiplos arquivos de fontes
python main_enhanced.py --fontes "file1.txt,file2.txt,file3.txt" --output batch_results

# Processamento paralelo
python main_enhanced.py --parallel --fontes examples/fontes.txt --output parallel_results

# Processamento com retry automático
python main_enhanced.py --auto-retry --max-retries 3 --fontes examples/fontes.txt
```

### 6. Execução com Monitoramento

#### Monitoramento em Tempo Real
```bash
# Análise com monitoramento detalhado
python main_enhanced.py --monitor --fontes examples/fontes.txt

# Relatório de performance
python main_enhanced.py --performance-report --fontes examples/fontes.txt

# Análise de custos
python main_enhanced.py --cost-analysis --fontes examples/fontes.txt
```

---

## Configurações Avançadas

### 1. Configuração de Ambiente

#### Arquivo .env
```bash
# .env - Configurações de ambiente
COBOL_AI_ENGINE_VERSION=2.1.0

# LuzIA
LUZIA_CLIENT_ID=seu_client_id
LUZIA_CLIENT_SECRET=seu_client_secret
LUZIA_ENDPOINT=https://gpt-api.aws.santanderbr.dev.corp/genai_services/v1
LUZIA_AUTH_ENDPOINT=https://login.azure-ad.santanderbr.dev.corp/oauth2/token

# OpenAI
OPENAI_API_KEY=sk-proj-...
OPENAI_ORG_ID=org-...
OPENAI_PROJECT_ID=proj_...

# Azure OpenAI
AZURE_OPENAI_KEY=sua_chave_azure
AZURE_OPENAI_ENDPOINT=https://seu-recurso.openai.azure.com/

# GitHub Copilot
GITHUB_COPILOT_TOKEN=ghp_...
GITHUB_ORG=sua_organizacao
GITHUB_ENTERPRISE_URL=https://github.sua-empresa.com

# Configurações globais
COBOL_AI_LOG_LEVEL=INFO
COBOL_AI_OUTPUT_DIR=./output
COBOL_AI_CONFIG_FILE=./config/config_complete.yaml
```

### 2. Configuração de Logging

```yaml
logging:
  version: 1
  disable_existing_loggers: false
  
  formatters:
    standard:
      format: '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    detailed:
      format: '%(asctime)s - %(name)s - %(levelname)s - %(module)s - %(funcName)s - %(message)s'
  
  handlers:
    console:
      class: logging.StreamHandler
      level: INFO
      formatter: standard
      stream: ext://sys.stdout
    
    file:
      class: logging.FileHandler
      level: DEBUG
      formatter: detailed
      filename: logs/cobol_ai_engine.log
    
    token_usage:
      class: logging.FileHandler
      level: INFO
      formatter: detailed
      filename: logs/token_usage.log
  
  loggers:
    providers:
      level: DEBUG
      handlers: [console, file]
      propagate: false
    
    token_manager:
      level: INFO
      handlers: [console, token_usage]
      propagate: false
  
  root:
    level: INFO
    handlers: [console, file]
```

### 3. Configuração de Performance

```yaml
performance:
  # Configurações de threading
  threading:
    enabled: true
    max_workers: 4
    timeout: 300
  
  # Cache de respostas
  caching:
    enabled: true
    cache_size: 1000
    cache_ttl: 3600  # 1 hora
  
  # Otimizações de rede
  network:
    connection_pool_size: 10
    max_retries: 3
    backoff_factor: 2
    timeout: 60
  
  # Otimizações de memória
  memory:
    max_memory_usage: "1GB"
    garbage_collection: true
    memory_monitoring: true
```

---

## Troubleshooting

### Problemas Comuns e Soluções

#### 1. Erro de Autenticação LuzIA
```
Erro: "Falha na autenticação LuzIA: 401"

Soluções:
1. Verificar LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET
2. Confirmar endpoints de autenticação
3. Verificar conectividade com o servidor
4. Validar permissões do cliente OAuth2

Comando de teste:
python main_enhanced.py --test-auth luzia
```

#### 2. Rate Limit Atingido
```
Erro: "Rate limit atingido"

Soluções:
1. Aumentar rate_limit_delay na configuração
2. Usar faseamento para distribuir requisições
3. Configurar fallback para outros provedores
4. Implementar retry com backoff exponencial

Configuração:
rate_limit_delay: 5.0  # Aumentar delay
```

#### 3. Tokens Insuficientes
```
Erro: "Orçamento de tokens excedido"

Soluções:
1. Aumentar orçamento na configuração
2. Habilitar faseamento inteligente
3. Usar modo econômico
4. Otimizar prompts para usar menos tokens

Comando:
python main_enhanced.py --economy-mode --max-tokens 2000
```

#### 4. Provedor Indisponível
```
Erro: "Provedor não disponível"

Soluções:
1. Verificar conectividade de rede
2. Confirmar credenciais
3. Usar sistema de fallback
4. Verificar status do serviço

Comando de diagnóstico:
python main_enhanced.py --diagnose-providers
```

### Comandos de Diagnóstico

```bash
# Testar todos os provedores
python main_enhanced.py --test-all-providers

# Verificar configuração
python main_enhanced.py --validate-config

# Status detalhado
python main_enhanced.py --status --verbose

# Teste de conectividade
python main_enhanced.py --connectivity-test

# Análise de performance
python main_enhanced.py --performance-test
```

### Logs de Debug

```bash
# Habilitar logs detalhados
export COBOL_AI_LOG_LEVEL=DEBUG
python main_enhanced.py --fontes examples/fontes.txt --log-level DEBUG

# Logs específicos por componente
python main_enhanced.py --debug-component providers --fontes examples/fontes.txt
python main_enhanced.py --debug-component token_manager --fontes examples/fontes.txt
python main_enhanced.py --debug-component phasing --fontes examples/fontes.txt
```

---

## Exemplos Práticos Completos

### Exemplo 1: Configuração Corporativa com LuzIA
```bash
# 1. Configurar variáveis de ambiente
export LUZIA_CLIENT_ID="client_id_corporativo"
export LUZIA_CLIENT_SECRET="client_secret_corporativo"

# 2. Executar análise completa
python main_enhanced.py \
  --config config/config_complete.yaml \
  --fontes dados/programas_cobol.txt \
  --books dados/copybooks.txt \
  --output relatorios_corporativos \
  --log-level INFO

# 3. Verificar resultados
ls -la relatorios_corporativos/
```

### Exemplo 2: Análise Econômica com Múltiplos Provedores
```bash
# 1. Configurar múltiplos provedores
export OPENAI_API_KEY="sk-proj-..."
export GITHUB_COPILOT_TOKEN="ghp_..."

# 2. Executar com otimização de custos
python main_enhanced.py \
  --providers "enhanced_mock,openai,copilot" \
  --economy-mode \
  --max-tokens 3000 \
  --cost-analysis \
  --fontes examples/fontes.txt \
  --output analise_economica

# 3. Revisar relatório de custos
cat analise_economica/cost_report.json
```

### Exemplo 3: Análise de Alta Performance
```bash
# 1. Configurar para máxima performance
python main_enhanced.py \
  --parallel \
  --max-workers 8 \
  --enable-caching \
  --providers "luzia,openai" \
  --fontes "file1.txt,file2.txt,file3.txt" \
  --output performance_analysis \
  --performance-report

# 2. Monitorar em tempo real
tail -f logs/cobol_ai_engine.log
```

---

**Este manual cobre todas as formas possíveis de configuração e execução do COBOL AI Engine v2.1.0. Para suporte adicional, consulte os logs detalhados e use os comandos de diagnóstico fornecidos.**

