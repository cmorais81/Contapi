# Manual de Configuração - COBOL AI Engine v2.2.0

**Versão**: 2.2.0  
**Data**: 10 de Setembro de 2025  
**Status**: Produção - Configuração Completa Validada

---

## Visão Geral da Configuração

O COBOL AI Engine v2.2.0 oferece configuração flexível e robusta para diferentes ambientes e necessidades. Este manual detalha todas as opções de configuração disponíveis.

### Arquitetura de Configuração

```
config/
├── config.yaml                    # Configuração principal (LuzIA principal)
├── config_luzia_primary.yaml      # Configuração completa LuzIA
├── config_development.yaml        # Configuração para desenvolvimento
├── config_production.yaml         # Configuração para produção
└── config_basic.yaml             # Configuração básica (só Enhanced Mock)
```

---

## Configuração Principal (config.yaml)

### Estrutura Básica
```yaml
# COBOL AI Engine v2.2.0 - Configuração Principal
ai:
  # Provedor principal (primeira tentativa)
  primary_provider: "luzia"
  
  # Provedores de fallback (ordem de tentativa)
  fallback_providers: 
    - "enhanced_mock"
    - "basic"
  
  # Configurações globais
  enable_fallback: true
  global_timeout: 120
  global_max_tokens: 4000
  max_retries: 3
  retry_delay: 2.0
  
  # Configuração de provedores
  providers:
    # [Detalhes dos provedores abaixo]
```

---

## Configuração do LuzIA (Provedor Principal)

### Configuração Completa
```yaml
luzia:
  # Configurações básicas
  enabled: true
  client_id: "${LUZIA_CLIENT_ID}"
  client_secret: "${LUZIA_CLIENT_SECRET}"
  
  # Endpoints e API
  api_base: "https://gpt-api.aws.santanderbr.dev.corp/genai_services/v1"
  auth_endpoint: "https://login.azure.com"
  api_version: "2023-05-15"
  
  # Modelo e parâmetros
  model: "aws-claude-1-3-sonnet-exp"
  max_tokens: 4000
  temperature: 0.7
  timeout: 120
  
  # Funcionalidades avançadas LuzIA
  use_knowledge_base: true
  knowledge_base_id: "${KNOWLEDGE_BASE_ID}"
  guardrail_id: "${GUARDRAIL_ID}"
  guardrail_version: "${GUARDRAIL_VERSION}"
  performance_config: "optimized"
  auto_refresh_token: true
  
  # Faseamento inteligente
  enable_phasing: true
  max_tokens_per_phase: 2000
  phase_overlap: 200
  
  # Orçamento de tokens
  budget:
    max_tokens_per_request: 4000
    max_tokens_per_hour: 50000
    max_tokens_per_day: 200000
    alert_threshold: 0.8
  
  # Rate limiting
  rate_limit:
    requests_per_second: 2
    requests_per_minute: 60
    requests_per_hour: 1000
```

### Variáveis de Ambiente Necessárias

#### Obrigatórias
```bash
# Credenciais de autenticação OAuth2
export LUZIA_CLIENT_ID="seu_client_id_aqui"
export LUZIA_CLIENT_SECRET="seu_client_secret_aqui"
```

#### Opcionais (Funcionalidades Avançadas)
```bash
# Knowledge Base especializada em COBOL
export KNOWLEDGE_BASE_ID="kb_cobol_mainframe_001"

# Guardrails para segurança e conformidade
export GUARDRAIL_ID="guardrail_banking_001"
export GUARDRAIL_VERSION="v1.2.0"

# Configurações de ambiente
export LUZIA_ENVIRONMENT="production"  # ou "development"
export LUZIA_REGION="us-east-1"
```

### Configuração por Ambiente

#### Desenvolvimento
```yaml
luzia:
  enabled: true
  timeout: 60
  max_tokens: 2000
  use_knowledge_base: false
  enable_phasing: false
  budget:
    max_tokens_per_hour: 10000
    max_tokens_per_day: 50000
```

#### Homologação
```yaml
luzia:
  enabled: true
  timeout: 90
  max_tokens: 3000
  use_knowledge_base: true
  enable_phasing: true
  budget:
    max_tokens_per_hour: 25000
    max_tokens_per_day: 100000
```

#### Produção
```yaml
luzia:
  enabled: true
  timeout: 120
  max_tokens: 4000
  use_knowledge_base: true
  enable_phasing: true
  performance_config: "optimized"
  auto_refresh_token: true
  budget:
    max_tokens_per_hour: 50000
    max_tokens_per_day: 200000
```

---

## Configuração do Enhanced Mock (Fallback Inteligente)

### Configuração Completa
```yaml
enhanced_mock:
  # Configurações básicas
  enabled: true
  response_delay: 0.1
  
  # Faseamento automático
  enable_phasing: true
  max_tokens_per_phase: 2000
  phase_overlap: 100
  
  # Simulação realística
  simulate_realistic_tokens: true
  simulate_realistic_delay: true
  
  # Análise específica de COBOL
  cobol_analysis_enabled: true
  code_extraction_enabled: true
  specific_responses: true
  
  # Templates de resposta
  response_templates:
    functional_analysis: "detailed"
    technical_analysis: "with_code_snippets"
    business_rules: "regulatory_focused"
    basic_info: "comprehensive"
  
  # Configurações de qualidade
  quality_settings:
    min_response_length: 500
    max_response_length: 3000
    include_code_examples: true
    include_business_context: true
```

### Funcionalidades do Enhanced Mock

#### Análise Específica por Tipo de Programa
```yaml
enhanced_mock:
  program_type_analysis:
    LHAN_programs:
      context: "BACEN regulatory processing"
      focus: "compliance and data validation"
    LHBR_programs:
      context: "Brazilian market processing"
      focus: "local regulations and calculations"
    MZAN_programs:
      context: "Data analysis and reporting"
      focus: "analytics and business intelligence"
```

#### Templates Contextuais
```yaml
enhanced_mock:
  contextual_templates:
    banking:
      regulatory_compliance: true
      audit_trails: true
      data_validation: "strict"
    mainframe:
      cobol_patterns: true
      file_processing: true
      batch_operations: true
```

---

## Configuração do Basic Provider (Fallback Final)

### Configuração Simples
```yaml
basic:
  # Sempre habilitado (fallback final)
  enabled: true
  
  # Configurações básicas
  max_tokens: 1000
  response_delay: 0.05
  
  # Garantias
  never_fails: true
  always_available: true
  
  # Resposta mínima garantida
  minimum_response:
    functional_question: true
    basic_structure: true
    simple_analysis: true
```

---

## Configuração de Outros Provedores

### OpenAI Provider
```yaml
openai:
  enabled: false  # Desabilitado por padrão
  api_key: "${OPENAI_API_KEY}"
  organization: "${OPENAI_ORG_ID}"
  api_base: "https://api.openai.com/v1"
  model: "gpt-4"
  max_tokens: 4000
  temperature: 0.7
  timeout: 120
  
  # Configurações específicas
  enable_phasing: true
  max_tokens_per_phase: 2000
  
  # Rate limiting
  rate_limit:
    requests_per_minute: 20
    tokens_per_minute: 40000
```

### GitHub Copilot Provider
```yaml
copilot:
  enabled: false  # Desabilitado por padrão
  token: "${GITHUB_COPILOT_TOKEN}"
  organization: "${GITHUB_ORG}"
  api_base: "https://api.github.com"
  model: "copilot-chat"
  max_tokens: 3000
  timeout: 90
```

---

## Configurações Globais

### Sistema de Fallback
```yaml
ai:
  # Controle de fallback
  enable_fallback: true
  fallback_on_error: true
  fallback_on_timeout: true
  fallback_on_rate_limit: true
  
  # Ordem de tentativa
  fallback_providers:
    - "enhanced_mock"  # Primeiro fallback
    - "basic"          # Fallback final
  
  # Configurações de retry
  max_retries: 3
  retry_delay: 2.0
  exponential_backoff: true
```

### Controle de Tokens
```yaml
ai:
  # Limites globais
  global_max_tokens: 4000
  global_timeout: 120
  
  # Faseamento automático
  auto_phasing: true
  phase_threshold: 2000
  max_phases: 5
  
  # Orçamento global
  global_budget:
    daily_limit: 500000
    hourly_limit: 100000
    alert_at_percentage: 80
```

### Logging e Monitoramento
```yaml
logging:
  # Nível de log
  level: "INFO"  # DEBUG, INFO, WARNING, ERROR
  
  # Arquivo de log
  file: "logs/cobol_ai_engine.log"
  max_size: "10MB"
  backup_count: 5
  
  # Formato
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
  
  # Logs específicos
  provider_logs: true
  token_usage_logs: true
  performance_logs: true
```

### Output e Documentação
```yaml
output:
  # Formato de saída
  format: "markdown"
  
  # Conteúdo incluído
  include_metadata: true
  include_prompts: true
  include_statistics: true
  include_code_snippets: true
  
  # Estrutura de arquivos
  separate_files_per_program: true
  generate_consolidated_report: true
  generate_status_report: true
  
  # Qualidade
  min_content_length: 1000
  max_content_length: 10000
```

---

## Configurações por Cenário de Uso

### Cenário 1: Desenvolvimento Local
```yaml
# config/config_development.yaml
ai:
  primary_provider: "enhanced_mock"
  fallback_providers: ["basic"]
  global_timeout: 30
  global_max_tokens: 2000
  
  providers:
    enhanced_mock:
      enabled: true
      response_delay: 0.05
      simulate_realistic_tokens: false
    basic:
      enabled: true
```

### Cenário 2: Teste com LuzIA
```yaml
# config/config_test_luzia.yaml
ai:
  primary_provider: "luzia"
  fallback_providers: ["enhanced_mock", "basic"]
  
  providers:
    luzia:
      enabled: true
      timeout: 60
      max_tokens: 2000
      use_knowledge_base: false
      enable_phasing: false
```

### Cenário 3: Produção Completa
```yaml
# config/config_production.yaml
ai:
  primary_provider: "luzia"
  fallback_providers: ["enhanced_mock", "basic"]
  global_timeout: 120
  global_max_tokens: 4000
  
  providers:
    luzia:
      enabled: true
      use_knowledge_base: true
      enable_phasing: true
      performance_config: "optimized"
      auto_refresh_token: true
```

### Cenário 4: Análise em Lote
```yaml
# config/config_batch.yaml
ai:
  primary_provider: "luzia"
  fallback_providers: ["enhanced_mock"]
  
  providers:
    luzia:
      enable_phasing: true
      max_tokens_per_phase: 1500
      budget:
        max_tokens_per_hour: 100000
```

---

## Validação de Configuração

### Comando de Validação
```bash
# Validar configuração atual
python main.py --validate-config

# Validar configuração específica
python main.py --validate-config --config config/config_production.yaml
```

### Verificação de Dependências
```bash
# Verificar dependências
python main.py --check-dependencies

# Testar conectividade
python main.py --test-providers
```

### Diagnóstico Completo
```bash
# Diagnóstico completo do sistema
python main.py --diagnose
```

---

## Configuração de Segurança

### Proteção de Credenciais
```yaml
security:
  # Criptografia de credenciais
  encrypt_credentials: true
  encryption_key: "${ENCRYPTION_KEY}"
  
  # Rotação de tokens
  auto_rotate_tokens: true
  rotation_interval: "24h"
  
  # Auditoria
  audit_logs: true
  audit_file: "logs/audit.log"
```

### Configuração de Rede
```yaml
network:
  # Proxy settings
  proxy:
    http: "${HTTP_PROXY}"
    https: "${HTTPS_PROXY}"
    no_proxy: "localhost,127.0.0.1"
  
  # SSL/TLS
  ssl_verify: true
  ssl_cert_path: "/path/to/cert.pem"
  
  # Timeouts
  connect_timeout: 30
  read_timeout: 120
```

---

## Configuração de Performance

### Otimização de Recursos
```yaml
performance:
  # Concorrência
  max_concurrent_requests: 5
  request_pool_size: 10
  
  # Cache
  enable_cache: true
  cache_size: 1000
  cache_ttl: 3600
  
  # Compressão
  enable_compression: true
  compression_level: 6
```

### Monitoramento de Performance
```yaml
monitoring:
  # Métricas
  enable_metrics: true
  metrics_file: "logs/metrics.json"
  
  # Alertas
  enable_alerts: true
  alert_thresholds:
    response_time: 30
    error_rate: 0.05
    token_usage: 0.8
```

---

## Configuração de Backup e Recuperação

### Backup Automático
```yaml
backup:
  # Configurações automáticas
  auto_backup: true
  backup_interval: "1h"
  backup_location: "backups/"
  
  # Retenção
  retention_days: 30
  max_backup_files: 100
```

### Recuperação de Falhas
```yaml
recovery:
  # Auto-recovery
  auto_recovery: true
  recovery_attempts: 3
  recovery_delay: 5
  
  # Fallback automático
  fallback_on_failure: true
  fallback_threshold: 3
```

---

## Exemplos de Configuração Completa

### Exemplo 1: Configuração Mínima
```yaml
# config_minimal.yaml
ai:
  primary_provider: "enhanced_mock"
  fallback_providers: ["basic"]
  providers:
    enhanced_mock:
      enabled: true
    basic:
      enabled: true
```

### Exemplo 2: Configuração Corporativa
```yaml
# config_corporate.yaml
ai:
  primary_provider: "luzia"
  fallback_providers: ["enhanced_mock", "basic"]
  global_timeout: 120
  global_max_tokens: 4000
  
  providers:
    luzia:
      enabled: true
      client_id: "${LUZIA_CLIENT_ID}"
      client_secret: "${LUZIA_CLIENT_SECRET}"
      use_knowledge_base: true
      enable_phasing: true
      performance_config: "optimized"
      budget:
        max_tokens_per_day: 200000
    
    enhanced_mock:
      enabled: true
      cobol_analysis_enabled: true
      specific_responses: true
    
    basic:
      enabled: true

logging:
  level: "INFO"
  file: "logs/cobol_ai_engine.log"

output:
  format: "markdown"
  include_metadata: true
  include_prompts: true
```

---

## Troubleshooting de Configuração

### Problemas Comuns

#### 1. Credenciais LuzIA Inválidas
```bash
# Verificar variáveis
echo $LUZIA_CLIENT_ID
echo $LUZIA_CLIENT_SECRET

# Testar autenticação
python main.py --test-providers
```

#### 2. Timeout de Configuração
```yaml
# Aumentar timeouts
ai:
  global_timeout: 180
  providers:
    luzia:
      timeout: 150
```

#### 3. Limite de Tokens Excedido
```yaml
# Ajustar orçamento
ai:
  providers:
    luzia:
      budget:
        max_tokens_per_hour: 100000
        alert_threshold: 0.9
```

### Logs de Diagnóstico
```bash
# Habilitar debug
python main.py --log-level DEBUG --config sua_config.yaml

# Verificar logs específicos
grep "CONFIG" logs/cobol_ai_engine.log
grep "LUZIA" logs/cobol_ai_engine.log
```

---

## Migração de Configurações

### De v2.1 para v2.2
```bash
# Backup da configuração atual
cp config/config.yaml config/config_v2.1_backup.yaml

# Aplicar nova configuração
cp config/config_v2.2_template.yaml config/config.yaml

# Migrar credenciais
# (manter variáveis de ambiente existentes)
```

### Validação Pós-Migração
```bash
# Testar nova configuração
python main.py --validate-config
python main.py --test-providers
python main.py --status
```

---

**COBOL AI Engine v2.2.0 - Configuração Completa e Validada**

Este manual cobre todas as opções de configuração disponíveis. Para uso básico, a configuração padrão é suficiente. Para ambientes corporativos, recomenda-se configurar LuzIA como principal com as funcionalidades avançadas habilitadas.

