#!/usr/bin/env python3
"""
Script para corrigir data types no modelo DBML
- varchar → text
- timestamp → timestamptz
"""

import re
import os

def fix_dbml_datatypes(input_file, output_file):
    """
    Corrige data types no arquivo DBML
    """
    print(f"🔧 Corrigindo data types em {input_file}...")
    
    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Contador de mudanças
    varchar_count = 0
    timestamp_count = 0
    
    # Corrigir varchar para text
    # Padrão: varchar(qualquer_numero) ou varchar
    varchar_pattern = r'\bvarchar\(\d+\)|\bvarchar\b'
    varchar_matches = re.findall(varchar_pattern, content)
    varchar_count = len(varchar_matches)
    content = re.sub(varchar_pattern, 'text', content)
    
    # Corrigir timestamp para timestamptz
    # Padrão: timestamp (mas não timestamptz)
    timestamp_pattern = r'\btimestamp\b(?!tz)'
    timestamp_matches = re.findall(timestamp_pattern, content)
    timestamp_count = len(timestamp_matches)
    content = re.sub(timestamp_pattern, 'timestamptz', content)
    
    # Salvar arquivo corrigido
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"✅ Correções aplicadas:")
    print(f"   - varchar → text: {varchar_count} ocorrências")
    print(f"   - timestamp → timestamptz: {timestamp_count} ocorrências")
    print(f"   - Arquivo salvo: {output_file}")
    
    return varchar_count, timestamp_count

def validate_corrections(file_path):
    """
    Valida se as correções foram aplicadas corretamente
    """
    print(f"🔍 Validando correções em {file_path}...")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Verificar se ainda existem varchar
    varchar_remaining = re.findall(r'\bvarchar\b', content)
    
    # Verificar se ainda existem timestamp (sem tz)
    timestamp_remaining = re.findall(r'\btimestamp\b(?!tz)', content)
    
    if varchar_remaining:
        print(f"⚠️  Ainda existem {len(varchar_remaining)} ocorrências de 'varchar'")
        return False
    
    if timestamp_remaining:
        print(f"⚠️  Ainda existem {len(timestamp_remaining)} ocorrências de 'timestamp' sem 'tz'")
        return False
    
    print("✅ Todas as correções foram aplicadas com sucesso!")
    return True

if __name__ == "__main__":
    input_file = "/home/ubuntu/data-governance-api/docs/data_governance_model_v3_complete.dbml"
    output_file = "/home/ubuntu/data-governance-api/docs/data_governance_model_v3_fixed.dbml"
    
    # Verificar se arquivo de entrada existe
    if not os.path.exists(input_file):
        print(f"❌ Arquivo não encontrado: {input_file}")
        exit(1)
    
    # Aplicar correções
    varchar_count, timestamp_count = fix_dbml_datatypes(input_file, output_file)
    
    # Validar correções
    if validate_corrections(output_file):
        print(f"🎉 Modelo DBML corrigido com sucesso!")
        print(f"   Total de correções: {varchar_count + timestamp_count}")
    else:
        print("❌ Algumas correções podem não ter sido aplicadas corretamente")
        exit(1)

