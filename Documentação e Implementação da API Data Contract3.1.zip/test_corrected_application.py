#!/usr/bin/env python3
"""
Script de teste abrangente para validar aplicação após correções
"""

import requests
import json
import time
from datetime import datetime

BASE_URL = "http://localhost:8000"

def test_endpoint(endpoint, description):
    """
    Testa um endpoint específico
    """
    try:
        response = requests.get(f"{BASE_URL}{endpoint}", timeout=10)
        if response.status_code == 200:
            data = response.json()
            print(f"✅ {description}")
            return True, data
        else:
            print(f"❌ {description} - Status: {response.status_code}")
            return False, None
    except Exception as e:
        print(f"❌ {description} - Erro: {str(e)}")
        return False, None

def run_comprehensive_tests():
    """
    Executa testes abrangentes da aplicação
    """
    print("🚀 Iniciando testes abrangentes da aplicação corrigida...")
    print(f"⏰ Timestamp: {datetime.now().isoformat()}")
    print("=" * 80)
    
    tests = [
        ("/", "Endpoint raiz"),
        ("/health", "Health check"),
        ("/api/v1/stats", "Estatísticas gerais"),
        ("/api/v1/entities/", "Listagem de entidades"),
        ("/api/v1/contracts/", "Listagem de contratos"),
        ("/api/v1/quality/rules/", "Regras de qualidade"),
        ("/api/v1/datahub/entities/?limit=5", "Entidades DataHub"),
        ("/api/v1/costs/azure/?limit=5", "Custos Azure"),
        ("/api/v1/costs/databricks/?limit=5", "Custos Databricks"),
        ("/api/v1/costs/recommendations/?limit=5", "Recomendações de otimização"),
        ("/api/v1/costs/recommendations/summary", "Resumo de recomendações"),
    ]
    
    results = []
    successful_tests = 0
    
    for endpoint, description in tests:
        success, data = test_endpoint(endpoint, description)
        results.append({
            "endpoint": endpoint,
            "description": description,
            "success": success,
            "data_sample": str(data)[:200] + "..." if data else None
        })
        if success:
            successful_tests += 1
        time.sleep(0.5)  # Pequena pausa entre testes
    
    print("=" * 80)
    print(f"📊 Resultados dos testes:")
    print(f"   ✅ Sucessos: {successful_tests}/{len(tests)}")
    print(f"   📈 Taxa de sucesso: {(successful_tests/len(tests)*100):.1f}%")
    
    if successful_tests == len(tests):
        print("🎉 TODOS OS TESTES PASSARAM! Aplicação está funcionando perfeitamente.")
    else:
        print("⚠️  Alguns testes falharam. Verificar logs acima.")
    
    return results, successful_tests, len(tests)

def test_data_integrity():
    """
    Testa integridade dos dados
    """
    print("\n🔍 Testando integridade dos dados...")
    
    # Testar estatísticas
    success, stats = test_endpoint("/api/v1/stats", "Estatísticas para integridade")
    if success and stats:
        print(f"   📊 Entidades: {stats.get('entities', {}).get('total', 0)}")
        print(f"   📋 Contratos: {stats.get('contracts', {}).get('total', 0)}")
        print(f"   🔍 Regras de qualidade: {stats.get('quality_rules', {}).get('total', 0)}")
        print(f"   🏢 Entidades DataHub: {stats.get('datahub_integration', {}).get('total_entities', 0)}")
        print(f"   💰 Registros Azure: {stats.get('cost_management', {}).get('azure_costs', {}).get('total_records', 0)}")
        print(f"   🧱 Registros Databricks: {stats.get('cost_management', {}).get('databricks_costs', {}).get('total_records', 0)}")
        print(f"   💡 Recomendações: {stats.get('cost_management', {}).get('optimization', {}).get('total_recommendations', 0)}")
        
        # Verificar se há dados suficientes
        if (stats.get('entities', {}).get('total', 0) > 0 and 
            stats.get('datahub_integration', {}).get('total_entities', 0) > 0 and
            stats.get('cost_management', {}).get('azure_costs', {}).get('total_records', 0) > 0):
            print("   ✅ Integridade dos dados: OK")
            return True
        else:
            print("   ⚠️  Alguns dados podem estar faltando")
            return False
    
    return False

if __name__ == "__main__":
    print("🔧 TESTE ABRANGENTE - APLICAÇÃO CORRIGIDA")
    print("Validando funcionamento após correções de data types")
    print()
    
    # Aguardar aplicação estar pronta
    print("⏳ Aguardando aplicação estar pronta...")
    time.sleep(2)
    
    # Executar testes
    results, successful, total = run_comprehensive_tests()
    
    # Testar integridade
    integrity_ok = test_data_integrity()
    
    # Resumo final
    print("\n" + "=" * 80)
    print("📋 RESUMO FINAL")
    print(f"   🧪 Testes de endpoints: {successful}/{total} ({(successful/total*100):.1f}%)")
    print(f"   🔍 Integridade de dados: {'✅ OK' if integrity_ok else '⚠️  Verificar'}")
    
    if successful == total and integrity_ok:
        print("\n🎉 APLICAÇÃO TOTALMENTE FUNCIONAL APÓS CORREÇÕES!")
        print("   ✅ Todos os data types corrigidos")
        print("   ✅ Modelos SQLAlchemy atualizados")
        print("   ✅ Schemas Pydantic funcionais")
        print("   ✅ Endpoints operacionais")
        print("   ✅ Dados mockados carregados")
        exit(0)
    else:
        print("\n⚠️  ALGUNS PROBLEMAS DETECTADOS")
        print("   Verificar logs acima para detalhes")
        exit(1)

