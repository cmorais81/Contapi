#!/usr/bin/env python3
"""
Script para corrigir modelos SQLAlchemy e schemas Pydantic
- String(255) → Text()
- DateTime → DateTime(timezone=True)
"""

import os
import re
import glob

def fix_sqlalchemy_models(file_path):
    """
    Corrige data types em modelos SQLAlchemy
    """
    print(f"🔧 Corrigindo SQLAlchemy em {file_path}...")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    original_content = content
    changes = 0
    
    # Corrigir String(qualquer_numero) para Text()
    string_pattern = r'String\(\d+\)'
    string_matches = re.findall(string_pattern, content)
    if string_matches:
        content = re.sub(string_pattern, 'Text()', content)
        changes += len(string_matches)
        print(f"   - String(n) → Text(): {len(string_matches)} ocorrências")
    
    # Corrigir DateTime para DateTime(timezone=True)
    # Padrão: DateTime (mas não DateTime(timezone=True))
    datetime_pattern = r'DateTime(?!\(timezone=True\))'
    datetime_matches = re.findall(datetime_pattern, content)
    if datetime_matches:
        content = re.sub(datetime_pattern, 'DateTime(timezone=True)', content)
        changes += len(datetime_matches)
        print(f"   - DateTime → DateTime(timezone=True): {len(datetime_matches)} ocorrências")
    
    # Adicionar import Text se necessário
    if 'Text()' in content and 'from sqlalchemy import' in content:
        if ', Text' not in content and 'Text,' not in content and 'Text ' not in content:
            # Adicionar Text ao import existente
            content = re.sub(
                r'(from sqlalchemy import [^)]+)',
                r'\1, Text',
                content
            )
            print(f"   - Adicionado import Text")
            changes += 1
    
    if changes > 0:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"   ✅ {changes} correções aplicadas")
    else:
        print(f"   ✅ Nenhuma correção necessária")
    
    return changes

def fix_pydantic_schemas(file_path):
    """
    Corrige schemas Pydantic se necessário
    """
    print(f"🔧 Verificando Pydantic em {file_path}...")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    changes = 0
    
    # Pydantic schemas geralmente usam tipos Python nativos
    # Verificar se há algum problema específico
    
    # Verificar imports de datetime
    if 'datetime' in content and 'from datetime import datetime' not in content:
        if 'import datetime' not in content:
            # Adicionar import se necessário
            content = 'from datetime import datetime\n' + content
            changes += 1
            print(f"   - Adicionado import datetime")
    
    if changes > 0:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"   ✅ {changes} correções aplicadas")
    else:
        print(f"   ✅ Nenhuma correção necessária")
    
    return changes

def find_and_fix_python_files():
    """
    Encontra e corrige todos os arquivos Python relevantes
    """
    total_changes = 0
    
    # Encontrar arquivos de modelos SQLAlchemy
    model_patterns = [
        'app/models/**/*.py',
        'app/core/database.py',
        'app/models/base.py'
    ]
    
    print("🔍 Procurando arquivos de modelos SQLAlchemy...")
    model_files = []
    for pattern in model_patterns:
        model_files.extend(glob.glob(pattern, recursive=True))
    
    # Remover duplicatas e __init__.py
    model_files = list(set([f for f in model_files if not f.endswith('__init__.py')]))
    
    print(f"📁 Encontrados {len(model_files)} arquivos de modelos")
    
    for file_path in model_files:
        if os.path.exists(file_path):
            changes = fix_sqlalchemy_models(file_path)
            total_changes += changes
    
    # Encontrar arquivos de schemas Pydantic
    schema_patterns = [
        'app/schemas/**/*.py'
    ]
    
    print("\n🔍 Procurando arquivos de schemas Pydantic...")
    schema_files = []
    for pattern in schema_patterns:
        schema_files.extend(glob.glob(pattern, recursive=True))
    
    # Remover duplicatas e __init__.py
    schema_files = list(set([f for f in schema_files if not f.endswith('__init__.py')]))
    
    print(f"📁 Encontrados {len(schema_files)} arquivos de schemas")
    
    for file_path in schema_files:
        if os.path.exists(file_path):
            changes = fix_pydantic_schemas(file_path)
            total_changes += changes
    
    return total_changes

if __name__ == "__main__":
    print("🚀 Iniciando correção de modelos Python...")
    
    # Mudar para diretório do projeto
    os.chdir('/home/ubuntu/data-governance-api')
    
    total_changes = find_and_fix_python_files()
    
    print(f"\n🎉 Correção concluída!")
    print(f"   Total de mudanças: {total_changes}")
    
    if total_changes > 0:
        print("✅ Modelos Python atualizados com sucesso!")
    else:
        print("✅ Todos os modelos já estavam corretos!")

