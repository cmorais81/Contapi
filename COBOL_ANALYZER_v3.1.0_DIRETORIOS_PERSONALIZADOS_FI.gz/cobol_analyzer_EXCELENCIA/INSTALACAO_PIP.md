# Instalação via pip - COBOL Analyzer

Este guia mostra como instalar o COBOL Analyzer via `pip install` e usar os comandos `cobol-to-docs` e `cobol-analyzer` globalmente.

## ✅ Instalação Funcionando

A instalação via pip agora funciona corretamente! Siga os passos abaixo:

### Passo 1: Extrair o Pacote

```bash
tar -xzf COBOL_ANALYZER_v3.1.0_GLOBAL_CLI.tar.gz
cd cobol_analyzer_EXCELENCIA
```

### Passo 2: Instalar via pip

```bash
# Instalar o pacote (instala automaticamente todas as dependências)
pip install .

# Ou para instalação em modo desenvolvimento
pip install -e .
```

### Passo 3: Usar os Comandos Globais

Após a instalação, você pode usar os comandos de qualquer diretório:

```bash
# Verificar se está funcionando
cobol-to-docs --help
cobol-analyzer --help

# Análise básica
cobol-to-docs --fontes /caminho/para/fontes.txt --models enhanced_mock

# Análise consolidada
cobol-to-docs --fontes /caminho/para/fontes.txt --consolidado --models enhanced_mock
```

## 🎯 Funcionalidades Disponíveis

Os comandos `cobol-to-docs` e `cobol-analyzer` têm acesso a **todas** as funcionalidades:

- ✅ Análise individual e consolidada de programas COBOL
- ✅ Sistema RAG com auto-learning
- ✅ Múltiplos provedores de IA (OpenAI, AWS Claude, Mock, etc.)
- ✅ Análise especializada e de modernização
- ✅ Geração de documentação no padrão DOC-LEGADO PRO
- ✅ Relatórios HTML/PDF
- ✅ Análise de procedures detalhada
- ✅ Extração de fórmulas e cálculos
- ✅ Sistema de custos e logs detalhados
- ✅ Base de conhecimento dinâmica

## 📋 Opções de Linha de Comando

```bash
cobol-to-docs [OPÇÕES]

Opções principais:
  --fontes ARQUIVO          Arquivo com lista de programas COBOL
  --books ARQUIVO           Arquivo com lista de copybooks COBOL
  --output DIRETÓRIO        Diretório de saída (padrão: output)
  --models MODELOS          Modelos de IA a usar
  --consolidado             Análise consolidada de todos os programas
  --analise-especialista    Análise técnica profunda
  --procedure-detalhada     Foco na PROCEDURE DIVISION
  --modernizacao           Análise de modernização e migração
  --pdf                    Gerar relatórios HTML/PDF
  --status                 Verificar status dos provedores
```

## 💡 Exemplos Práticos

### Análise Básica
```bash
# Criar arquivo de fontes
echo "PROGRAMA1.CBL" > meus_programas.txt
echo "PROGRAMA2.CBL" >> meus_programas.txt

# Executar análise
cobol-to-docs --fontes meus_programas.txt --models enhanced_mock
```

### Análise Consolidada com Copybooks
```bash
# Análise completa do sistema
cobol-to-docs --fontes sistema_fontes.txt \
              --books sistema_books.txt \
              --consolidado \
              --models enhanced_mock \
              --output relatorio_sistema
```

### Análise de Modernização
```bash
# Análise focada em modernização
cobol-to-docs --fontes legado_fontes.txt \
              --modernizacao \
              --analise-especialista \
              --models enhanced_mock
```

### Verificar Status dos Provedores
```bash
cobol-to-docs --status
```

## 🔧 Dependências Instaladas Automaticamente

O `pip install` instala automaticamente:

- `pyyaml>=6.0` - Processamento de arquivos YAML
- `requests>=2.28.0` - Requisições HTTP para APIs
- `numpy>=1.21.0` - Computação numérica para RAG
- `scikit-learn>=1.0.0` - Machine learning para embeddings
- `jinja2>=3.0.0` - Templates para geração de relatórios
- `markdown>=3.3.0` - Processamento de Markdown

## 🚀 Vantagens da Instalação via pip

- ✅ Comandos disponíveis globalmente
- ✅ Instalação automática de dependências
- ✅ Não precisa navegar até o diretório da aplicação
- ✅ Integração fácil com scripts e automações
- ✅ Experiência de uso profissional
- ✅ Todas as funcionalidades preservadas
- ✅ Performance otimizada

## 🔄 Desinstalação

Para remover o pacote:

```bash
pip uninstall cobol-to-docs -y
```

## 🛠️ Solução de Problemas

### Erro de Dependências
Se houver erro de módulos não encontrados:

```bash
# Instalar dependências manualmente
pip install pyyaml numpy scikit-learn requests jinja2 markdown
```

### Comando não encontrado
Se os comandos não forem encontrados após instalação:

1. Verifique se o diretório de scripts está no PATH:
   ```bash
   python -m site --user-base
   ```

2. Adicione ao PATH se necessário:
   ```bash
   export PATH="$HOME/.local/bin:$PATH"
   ```

### Reinstalação
Para reinstalar completamente:

```bash
pip uninstall cobol-to-docs -y
pip install . --force-reinstall
```

## 📊 Validação da Instalação

Para verificar se tudo está funcionando:

```bash
# 1. Verificar comandos
cobol-to-docs --help
cobol-analyzer --help

# 2. Verificar status dos provedores
cobol-to-docs --status

# 3. Teste rápido
echo "PROGRAMA_TESTE.CBL" > teste.txt
cobol-to-docs --fontes teste.txt --models enhanced_mock
```

## 🎉 Sucesso!

Se você conseguiu executar os comandos acima sem erros, a instalação via pip está funcionando perfeitamente!

Agora você pode usar o COBOL Analyzer como uma ferramenta profissional instalada no seu sistema.
