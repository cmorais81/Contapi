#!/usr/bin/env python3
"""
COBOL Analyzer CLI Enhanced v3.1.0 - Interface de linha de comando aprimorada
Suporte completo para inicialização automática e diretórios personalizados
"""

import sys
import subprocess
import os
import argparse
from pathlib import Path

def get_script_directory():
    """Obtém o diretório do script atual, considerando diferentes cenários de instalação."""
    # Se executado como módulo instalado
    if __package__:
        import pkg_resources
        try:
            return pkg_resources.resource_filename(__package__, '')
        except:
            pass
    
    # Se executado diretamente
    return os.path.dirname(os.path.abspath(__file__))

def find_main_script():
    """Encontra o script main.py apropriado (enhanced ou original)."""
    script_dir = get_script_directory()
    
    # Priorizar main_enhanced.py se existir
    enhanced_main = os.path.join(script_dir, 'main_enhanced.py')
    if os.path.exists(enhanced_main):
        return enhanced_main
    
    # Fallback para main.py original
    original_main = os.path.join(script_dir, 'main.py')
    if os.path.exists(original_main):
        return original_main
    
    # Procurar em diretórios alternativos
    for alt_dir in ['.', '..', '../src']:
        alt_path = os.path.join(script_dir, alt_dir, 'main_enhanced.py')
        if os.path.exists(alt_path):
            return alt_path
        
        alt_path = os.path.join(script_dir, alt_dir, 'main.py')
        if os.path.exists(alt_path):
            return alt_path
    
    raise FileNotFoundError("Não foi possível encontrar main.py ou main_enhanced.py")

def create_cli_parser():
    """Cria parser específico para CLI com comandos de conveniência."""
    parser = argparse.ArgumentParser(
        description="COBOL Analyzer CLI v3.1.0 - Interface de linha de comando",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Comandos de conveniência:
  cobol-to-docs --init                    # Inicializar ambiente local
  cobol-to-docs --show-paths              # Mostrar caminhos configurados
  cobol-to-docs --status                  # Verificar status dos provedores
  cobol-to-docs --help-full               # Ajuda completa com todos os parâmetros

Exemplos de uso com diretórios personalizados:
  cobol-to-docs --fontes fontes.txt --config-dir ./config_custom
  cobol-to-docs --fontes fontes.txt --data-dir ./dados_rag --logs-dir ./logs_custom
  cobol-to-docs --init --config-dir ./minha_config --force-init
        """
    )
    
    # Comandos de conveniência
    parser.add_argument('--init', action='store_true',
                        help='Inicializar ambiente local rapidamente')
    parser.add_argument('--show-paths', action='store_true',
                        help='Mostrar caminhos de diretórios configurados')
    parser.add_argument('--status', action='store_true',
                        help='Verificar status dos provedores de IA')
    parser.add_argument('--help-full', action='store_true',
                        help='Exibir ajuda completa do main.py')
    
    # Parâmetros principais mais usados
    parser.add_argument('--fontes', type=str,
                        help='Arquivo com lista de programas COBOL')
    parser.add_argument('--books', type=str,
                        help='Arquivo com lista de copybooks COBOL')
    parser.add_argument('--output', type=str, default='output',
                        help='Diretório de saída para relatórios')
    parser.add_argument('--models', type=str,
                        help='Modelos de IA a utilizar')
    
    # Parâmetros de diretórios personalizados
    parser.add_argument('--config-dir', type=str,
                        help='Diretório personalizado para configurações')
    parser.add_argument('--data-dir', type=str,
                        help='Diretório personalizado para dados RAG')
    parser.add_argument('--logs-dir', type=str,
                        help='Diretório personalizado para logs')
    parser.add_argument('--force-init', action='store_true',
                        help='Forçar reinicialização do ambiente')
    
    # Opções de análise mais comuns
    parser.add_argument('--consolidado', action='store_true',
                        help='Análise consolidada de todo o sistema')
    parser.add_argument('--advanced-analysis', action='store_true',
                        help='Análise avançada com relatório HTML profissional')
    parser.add_argument('--pdf', action='store_true',
                        help='Gerar relatórios em PDF')
    
    return parser

def handle_convenience_commands(args):
    """Trata comandos de conveniência específicos do CLI."""
    
    if args.help_full:
        # Executar main.py --help para mostrar ajuda completa
        main_script = find_main_script()
        cmd = [sys.executable, main_script, '--help']
        subprocess.run(cmd)
        return True
    
    if args.init:
        # Comando rápido de inicialização
        main_script = find_main_script()
        cmd = [sys.executable, main_script, '--init-local']
        
        # Adicionar diretórios personalizados se especificados
        if args.config_dir:
            cmd.extend(['--config-dir', args.config_dir])
        if args.data_dir:
            cmd.extend(['--data-dir', args.data_dir])
        if args.logs_dir:
            cmd.extend(['--logs-dir', args.logs_dir])
        if args.force_init:
            cmd.append('--force-init')
        
        result = subprocess.run(cmd)
        return True
    
    if args.show_paths:
        # Mostrar caminhos configurados
        main_script = find_main_script()
        cmd = [sys.executable, main_script, '--show-paths']
        
        # Adicionar diretórios personalizados se especificados
        if args.config_dir:
            cmd.extend(['--config-dir', args.config_dir])
        if args.data_dir:
            cmd.extend(['--data-dir', args.data_dir])
        if args.logs_dir:
            cmd.extend(['--logs-dir', args.logs_dir])
        
        subprocess.run(cmd)
        return True
    
    if args.status:
        # Verificar status dos provedores
        main_script = find_main_script()
        cmd = [sys.executable, main_script, '--status']
        subprocess.run(cmd)
        return True
    
    return False

def build_main_command(args, remaining_args):
    """Constrói comando para executar o main.py com todos os argumentos."""
    main_script = find_main_script()
    cmd = [sys.executable, main_script]
    
    # Adicionar argumentos conhecidos
    if args.fontes:
        cmd.extend(['--fontes', args.fontes])
    if args.books:
        cmd.extend(['--books', args.books])
    if args.output:
        cmd.extend(['--output', args.output])
    if args.models:
        cmd.extend(['--models', args.models])
    
    # Adicionar diretórios personalizados
    if args.config_dir:
        cmd.extend(['--config-dir', args.config_dir])
    if args.data_dir:
        cmd.extend(['--data-dir', args.data_dir])
    if args.logs_dir:
        cmd.extend(['--logs-dir', args.logs_dir])
    
    # Adicionar flags booleanas
    if args.consolidado:
        cmd.append('--consolidado')
    if args.advanced_analysis:
        cmd.append('--advanced-analysis')
    if args.pdf:
        cmd.append('--pdf')
    if args.force_init:
        cmd.append('--force-init')
    
    # Adicionar argumentos não reconhecidos (passthrough)
    cmd.extend(remaining_args)
    
    return cmd

def main():
    """Ponto de entrada CLI aprimorado."""
    try:
        # Parse argumentos conhecidos, permitindo argumentos desconhecidos
        parser = create_cli_parser()
        args, remaining_args = parser.parse_known_args()
        
        # Tratar comandos de conveniência primeiro
        if handle_convenience_commands(args):
            return
        
        # Se não há argumentos suficientes, mostrar ajuda
        if not args.fontes and not remaining_args:
            print("COBOL Analyzer CLI v3.1.0")
            print("Use --help para ver opções disponíveis ou --help-full para ajuda completa")
            print()
            print("Comandos rápidos:")
            print("  cobol-to-docs --init                 # Configurar ambiente local")
            print("  cobol-to-docs --show-paths           # Mostrar diretórios configurados")
            print("  cobol-to-docs --status               # Status dos provedores")
            print()
            print("Exemplo básico:")
            print("  cobol-to-docs --fontes fontes.txt")
            return
        
        # Construir e executar comando principal
        cmd = build_main_command(args, remaining_args)
        
        print(f"Executando: {' '.join(cmd[2:])}")  # Não mostrar python e caminho do script
        result = subprocess.run(cmd, check=False)
        sys.exit(result.returncode)
        
    except KeyboardInterrupt:
        print("\nOperação cancelada pelo usuário.")
        sys.exit(1)
    except FileNotFoundError as e:
        print(f"Erro: {e}")
        print("Verifique se o COBOL Analyzer está instalado corretamente.")
        sys.exit(1)
    except Exception as e:
        print(f"Erro ao executar a aplicação: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()
