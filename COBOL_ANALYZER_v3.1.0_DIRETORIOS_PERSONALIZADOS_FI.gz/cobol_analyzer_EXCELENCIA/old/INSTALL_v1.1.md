# Guia de Instalação - COBOL to Docs v1.1

## Instalação Automatizada

O sistema COBOL to Docs v1.1 oferece instalação completamente automatizada através do script dedicado. Este método é recomendado para a maioria dos usuários, pois verifica dependências, instala pacotes necessários e configura o ambiente adequadamente.

```bash
# Executar instalação automatizada
python install.py
```

O script de instalação realiza verificação completa do ambiente Python, instalação de todas as dependências listadas no requirements.txt, configuração de variáveis de ambiente necessárias e validação da instalação através de testes básicos.

## Instalação via pip

Para usuários que preferem gerenciar dependências manualmente, o sistema suporta instalação tradicional via pip. Este método oferece maior controle sobre o processo de instalação.

```bash
# Instalar dependências básicas
pip install -r requirements.txt

# Ou instalação mínima
pip install -r requirements-lite.txt
```

## Dependências do Sistema

O COBOL to Docs v1.1 requer Python 3.8 ou superior, com suporte otimizado para Python 3.11. As dependências principais incluem requests para comunicação HTTP, PyYAML para processamento de configurações, Jinja2 para templates de documentação, scikit-learn para análise de similaridade RAG, e numpy para operações matemáticas.

As dependências opcionais incluem sentence-transformers para embeddings avançados, torch para modelos de machine learning, jupyter para notebooks interativos, e weasyprint para geração de PDFs.

## Configuração de Ambiente

### Variáveis LuzIA (Ambiente Santander)

Para uso em ambiente corporativo Santander, configure as seguintes variáveis de ambiente:

```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
export LUZIA_BASE_URL="https://gut-api-aws.santanderbr.pre.corp"
```

### Configuração Alternativa

Para ambientes externos ou desenvolvimento, o sistema funciona automaticamente com providers de fallback, não requerendo configuração adicional.

## Verificação da Instalação

Após a instalação, verifique o funcionamento através dos comandos de status e teste básico:

```bash
# Verificar status dos providers
python main.py --status

# Teste básico com mock provider
python main.py --fontes examples/sample.cbl --models enhanced_mock
```

## Estrutura de Diretórios

O sistema cria automaticamente a estrutura necessária de diretórios, incluindo logs para arquivos de log e relatórios, output para documentação gerada, config para arquivos de configuração, e data para bases de conhecimento RAG.

## Solução de Problemas

### Erro de Dependências

Se encontrar erros relacionados a dependências não encontradas, execute a instalação completa através do script automatizado ou instale manualmente as dependências específicas conforme indicado nas mensagens de erro.

### Problemas de Conectividade

Em caso de problemas de conectividade com LuzIA, o sistema automaticamente utiliza providers de fallback. Verifique a configuração de rede e variáveis de ambiente se necessário.

### Permissões de Arquivo

Certifique-se de que o usuário possui permissões adequadas para criação de diretórios e arquivos no local de instalação.

## Instalação em Diferentes Ambientes

### Ambiente de Desenvolvimento

Para desenvolvimento, recomenda-se a instalação completa com todas as dependências opcionais para acesso a funcionalidades avançadas e ferramentas de debugging.

### Ambiente de Produção

Em produção, utilize requirements-lite.txt para instalação mínima, configurando apenas as dependências essenciais para operação básica.

### Ambiente Corporativo

Em ambientes corporativos, configure adequadamente as variáveis de ambiente LuzIA e verifique políticas de proxy e firewall que possam afetar a conectividade.

## Atualização de Versão

Para atualizar de versões anteriores, faça backup dos arquivos de configuração personalizados, execute a nova instalação sobre a versão anterior, e restaure configurações específicas conforme necessário.

O sistema mantém compatibilidade com configurações de versões anteriores, realizando migração automática quando possível.
