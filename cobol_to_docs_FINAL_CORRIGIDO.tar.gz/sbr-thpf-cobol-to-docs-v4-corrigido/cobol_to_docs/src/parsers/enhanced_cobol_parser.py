"""
COBOL AI Engine v4.0 - Enhanced COBOL Parser
Parser robusto para programas COBOL e copybooks com tratamento avançado de VMEMBER.
"""

import logging
import re
from typing import List, Dict, Any, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum


class MemberType(Enum):
    """Tipos de membros COBOL."""
    PROGRAM = "program"
    COPYBOOK = "copybook"
    UNKNOWN = "unknown"
    EMPTY = "empty"


@dataclass
class ParsedMember:
    """Representa um membro parseado de arquivo empilhado."""
    name: str
    content: str
    member_type: MemberType
    line_count: int
    size: int
    start_line: int = 0
    end_line: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'type': self.member_type.value,
            'line_count': self.line_count,
            'size': self.size,
            'start_line': self.start_line,
            'end_line': self.end_line,
            'metadata': self.metadata
        }


@dataclass
class CobolProgram:
    """Representa um programa COBOL parseado."""
    name: str
    content: str
    line_count: int
    size: int
    divisions: Dict[str, str]
    sections: List[str]
    variables: List[str]
    files: List[str]
    program_id: Optional[str] = None
    source_member: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'line_count': self.line_count,
            'size': self.size,
            'divisions': self.divisions,
            'sections': self.sections,
            'variables': self.variables,
            'files': self.files,
            'program_id': self.program_id,
            'source_member': self.source_member
        }


@dataclass
class CobolBook:
    """Representa um copybook COBOL."""
    name: str
    content: str
    line_count: int
    size: int
    structures: List[str]
    source_member: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'line_count': self.line_count,
            'size': self.size,
            'structures': self.structures,
            'source_member': self.source_member
        }


class EnhancedCOBOLParser:
    """
    Parser robusto para programas COBOL e copybooks.
    
    Melhorias implementadas:
    - Tratamento robusto de arquivos VMEMBER empilhados
    - Detecção inteligente de tipos de membro
    - Limpeza automática de comentários e linhas vazias
    - Validação de estrutura COBOL
    - Tratamento de membros vazios ou corrompidos
    - Estatísticas detalhadas de parsing
    - Suporte a diferentes formatos de VMEMBER
    """
    
    def __init__(self):
        """Inicializa o parser COBOL aprimorado."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões regex otimizados
        self.vmember_patterns = [
            re.compile(r'^\s*VMEMBER\s+NAME\s+([A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'^\s*VMEMBER\s+([A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'^\s*//\s*VMEMBER\s+NAME\s+([A-Z0-9\-_]+)', re.IGNORECASE),
        ]
        
        self.division_pattern = re.compile(r'^\s*([A-Z\-]+)\s+DIVISION\.', re.IGNORECASE)
        self.section_pattern = re.compile(r'^\s*([A-Z0-9\-]+)\s+SECTION\.', re.IGNORECASE)
        self.program_id_pattern = re.compile(r'^\s*PROGRAM-ID\.\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.variable_pattern = re.compile(r'^\s*(\d+)\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.file_pattern = re.compile(r'^\s*SELECT\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.comment_patterns = [
            re.compile(r'^\s*\*.*$'),  # Comentários COBOL tradicionais
            re.compile(r'^\s*//.*$'),  # Comentários estilo C++
            re.compile(r'/\*.*?\*/', re.DOTALL),  # Comentários de bloco
        ]
        
        # Indicadores de programa vs copybook
        self.program_indicators = {
            'IDENTIFICATION DIVISION', 'ID DIVISION', 'PROGRAM-ID',
            'PROCEDURE DIVISION', 'ENVIRONMENT DIVISION'
        }
        
        self.copybook_indicators = {
            'COPY', 'INCLUDE', 'REPLACING'
        }
        
        # Estatísticas de parsing
        self.stats = {
            'files_parsed': 0,
            'members_found': 0,
            'programs_parsed': 0,
            'copybooks_parsed': 0,
            'empty_members': 0,
            'errors': 0
        }
        
        self.logger.info("Enhanced COBOL Parser inicializado")
    
    def parse_file(self, file_path: str) -> Tuple[List[CobolProgram], List[CobolBook]]:
        """
        Parse robusto de arquivo COBOL empilhado ou único.
        
        Args:
            file_path: Caminho para o arquivo
            
        Returns:
            Tuple[List[CobolProgram], List[CobolBook]]: Programas e copybooks encontrados
        """
        programs = []
        books = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            self.logger.info(f"Parseando arquivo: {file_path}")
            self.stats['files_parsed'] += 1
            
            # Detectar se é arquivo empilhado
            if self._is_stacked_file(content):
                members = self._parse_stacked_file(content)
                self.logger.info(f"Arquivo empilhado detectado: {len(members)} membros encontrados")
                
                for member in members:
                    self._process_member(member, programs, books)
            else:
                # Arquivo único
                import os
                file_name = os.path.splitext(os.path.basename(file_path))[0]
                
                # Criar membro único
                member = ParsedMember(
                    name=file_name,
                    content=content,
                    member_type=self._detect_member_type(content),
                    line_count=len(content.split('\n')),
                    size=len(content)
                )
                
                self._process_member(member, programs, books)
                
        except Exception as e:
            self.logger.error(f"Erro ao parsear arquivo {file_path}: {str(e)}")
            self.stats['errors'] += 1
            
        return programs, books
    
    def _is_stacked_file(self, content: str) -> bool:
        """
        Detecta se o arquivo é empilhado (contém VMEMBER).
        
        Args:
            content: Conteúdo do arquivo
            
        Returns:
            bool: True se for arquivo empilhado
        """
        for pattern in self.vmember_patterns:
            if pattern.search(content):
                return True
        return False
    
    def _parse_stacked_file(self, content: str) -> List[ParsedMember]:
        """
        Parse robusto de arquivo empilhado.
        
        Args:
            content: Conteúdo do arquivo
            
        Returns:
            List[ParsedMember]: Lista de membros parseados
        """
        members = []
        lines = content.split('\n')
        current_member = None
        current_content = []
        current_start_line = 0
        
        for line_num, line in enumerate(lines, 1):
            # Verificar se é linha VMEMBER
            vmember_name = self._extract_vmember_name(line)
            
            if vmember_name:
                # Salvar membro anterior se existir
                if current_member and current_content:
                    member = self._create_member(
                        current_member, current_content, 
                        current_start_line, line_num - 1
                    )
                    members.append(member)
                
                # Iniciar novo membro
                current_member = vmember_name
                current_content = []
                current_start_line = line_num
                
            elif current_member:
                # Adicionar linha ao membro atual
                current_content.append(line)
        
        # Salvar último membro
        if current_member:
            member = self._create_member(
                current_member, current_content, 
                current_start_line, len(lines)
            )
            members.append(member)
        
        self.stats['members_found'] += len(members)
        return members
    
    def _extract_vmember_name(self, line: str) -> Optional[str]:
        """
        Extrai nome do VMEMBER de uma linha.
        
        Args:
            line: Linha a analisar
            
        Returns:
            Optional[str]: Nome do membro ou None
        """
        for pattern in self.vmember_patterns:
            match = pattern.match(line)
            if match:
                return match.group(1).upper()
        return None
    
    def _create_member(self, name: str, content_lines: List[str], 
                      start_line: int, end_line: int) -> ParsedMember:
        """
        Cria um objeto ParsedMember.
        
        Args:
            name: Nome do membro
            content_lines: Linhas de conteúdo
            start_line: Linha inicial
            end_line: Linha final
            
        Returns:
            ParsedMember: Membro parseado
        """
        # Limpar conteúdo
        cleaned_content = self._clean_content(content_lines)
        content = '\n'.join(cleaned_content)
        
        # Detectar tipo
        member_type = self._detect_member_type(content)
        
        # Criar metadados
        metadata = {
            'original_lines': len(content_lines),
            'cleaned_lines': len(cleaned_content),
            'has_comments': len(content_lines) != len(cleaned_content)
        }
        
        return ParsedMember(
            name=name,
            content=content,
            member_type=member_type,
            line_count=len(cleaned_content),
            size=len(content),
            start_line=start_line,
            end_line=end_line,
            metadata=metadata
        )
    
    def _clean_content(self, lines: List[str]) -> List[str]:
        """
        Limpa o conteúdo removendo comentários e linhas vazias.
        
        Args:
            lines: Linhas originais
            
        Returns:
            List[str]: Linhas limpas
        """
        cleaned = []
        
        for line in lines:
            # Remover comentários de linha
            is_comment = False
            for pattern in self.comment_patterns:
                if pattern.match(line):
                    is_comment = True
                    break
            
            # Manter linha se não for comentário e não estiver vazia
            if not is_comment and line.strip():
                cleaned.append(line)
        
        return cleaned
    
    def _detect_member_type(self, content: str) -> MemberType:
        """
        Detecta o tipo do membro (programa, copybook, etc.).
        
        Args:
            content: Conteúdo do membro
            
        Returns:
            MemberType: Tipo detectado
        """
        if not content.strip():
            return MemberType.EMPTY
        
        content_upper = content.upper()
        
        # Contar indicadores de programa
        program_score = sum(1 for indicator in self.program_indicators 
                          if indicator in content_upper)
        
        # Contar indicadores de copybook
        copybook_score = sum(1 for indicator in self.copybook_indicators 
                           if indicator in content_upper)
        
        # Verificar estruturas específicas
        has_divisions = 'DIVISION' in content_upper
        has_procedure = 'PROCEDURE DIVISION' in content_upper
        has_data_structures = re.search(r'^\s*\d+\s+[A-Z]', content, re.MULTILINE)
        
        # Lógica de decisão
        if program_score >= 2 or has_procedure:
            return MemberType.PROGRAM
        elif has_data_structures and not has_divisions:
            return MemberType.COPYBOOK
        elif program_score > copybook_score:
            return MemberType.PROGRAM
        elif copybook_score > 0:
            return MemberType.COPYBOOK
        else:
            return MemberType.UNKNOWN
    
    def _process_member(self, member: ParsedMember, 
                       programs: List[CobolProgram], 
                       books: List[CobolBook]) -> None:
        """
        Processa um membro parseado.
        
        Args:
            member: Membro a processar
            programs: Lista de programas
            books: Lista de copybooks
        """
        if member.member_type == MemberType.EMPTY:
            self.stats['empty_members'] += 1
            self.logger.warning(f"Membro vazio ignorado: {member.name}")
            return
        
        try:
            if member.member_type == MemberType.PROGRAM:
                program = self._parse_program(member)
                programs.append(program)
                self.stats['programs_parsed'] += 1
                self.logger.info(f"Programa parseado: {member.name}")
                
            elif member.member_type == MemberType.COPYBOOK:
                book = self._parse_copybook(member)
                books.append(book)
                self.stats['copybooks_parsed'] += 1
                self.logger.info(f"Copybook parseado: {member.name}")
                
            else:
                self.logger.warning(f"Tipo desconhecido para membro: {member.name}")
                
        except Exception as e:
            self.logger.error(f"Erro ao processar membro {member.name}: {str(e)}")
            self.stats['errors'] += 1
    
    def _parse_program(self, member: ParsedMember) -> CobolProgram:
        """
        Parse de um programa COBOL.
        
        Args:
            member: Membro a parsear
            
        Returns:
            CobolProgram: Programa parseado
        """
        # Extrair PROGRAM-ID
        program_id = None
        program_id_match = self.program_id_pattern.search(member.content)
        if program_id_match:
            program_id = program_id_match.group(1)
        
        return CobolProgram(
            name=member.name,
            content=member.content,
            line_count=member.line_count,
            size=member.size,
            divisions=self._extract_divisions(member.content),
            sections=self._extract_sections(member.content),
            variables=self._extract_variables(member.content),
            files=self._extract_files(member.content),
            program_id=program_id,
            source_member=member.name
        )
    
    def _parse_copybook(self, member: ParsedMember) -> CobolBook:
        """
        Parse de um copybook COBOL.
        
        Args:
            member: Membro a parsear
            
        Returns:
            CobolBook: Copybook parseado
        """
        return CobolBook(
            name=member.name,
            content=member.content,
            line_count=member.line_count,
            size=member.size,
            structures=self._extract_data_structures(member.content),
            source_member=member.name
        )
    
    def _extract_divisions(self, content: str) -> Dict[str, str]:
        """Extrai as divisões do programa COBOL."""
        divisions = {}
        lines = content.split('\n')
        current_division = None
        current_content = []
        
        for line in lines:
            division_match = self.division_pattern.match(line)
            if division_match:
                # Salvar divisão anterior
                if current_division and current_content:
                    divisions[current_division] = '\n'.join(current_content)
                
                # Nova divisão
                current_division = division_match.group(1).upper()
                current_content = [line]
            elif current_division:
                current_content.append(line)
        
        # Salvar última divisão
        if current_division and current_content:
            divisions[current_division] = '\n'.join(current_content)
        
        return divisions
    
    def _extract_sections(self, content: str) -> List[str]:
        """Extrai as seções do programa COBOL."""
        sections = []
        for line in content.split('\n'):
            section_match = self.section_pattern.match(line)
            if section_match:
                sections.append(section_match.group(1))
        return sections
    
    def _extract_variables(self, content: str) -> List[str]:
        """Extrai as variáveis do programa COBOL."""
        variables = []
        for line in content.split('\n'):
            variable_match = self.variable_pattern.match(line)
            if variable_match:
                variables.append(variable_match.group(2))
        return variables
    
    def _extract_files(self, content: str) -> List[str]:
        """Extrai os arquivos do programa COBOL."""
        files = []
        for line in content.split('\n'):
            file_match = self.file_pattern.match(line)
            if file_match:
                files.append(file_match.group(1))
        return files
    
    def _extract_data_structures(self, content: str) -> List[str]:
        """Extrai estruturas de dados do copybook."""
        structures = []
        structure_pattern = re.compile(r'^\s*01\s+([A-Z0-9\-]+)', re.IGNORECASE)
        
        for line in content.split('\n'):
            structure_match = structure_pattern.match(line)
            if structure_match:
                structures.append(structure_match.group(1))
        
        return structures
    
    def get_parser_statistics(self) -> Dict[str, Any]:
        """
        Retorna estatísticas detalhadas do parser.
        
        Returns:
            Dict[str, Any]: Estatísticas do parser
        """
        return {
            'parser_version': '4.0-enhanced',
            'statistics': self.stats.copy(),
            'supported_formats': ['COBOL', 'Copybook', 'VMEMBER', 'Stacked Files'],
            'features': [
                'Robust VMEMBER parsing',
                'Intelligent type detection',
                'Comment removal',
                'Empty member handling',
                'Multiple VMEMBER formats',
                'Detailed statistics',
                'Error recovery'
            ]
        }
    
    def reset_statistics(self) -> None:
        """Reseta as estatísticas do parser."""
        self.stats = {
            'files_parsed': 0,
            'members_found': 0,
            'programs_parsed': 0,
            'copybooks_parsed': 0,
            'empty_members': 0,
            'errors': 0
        }
