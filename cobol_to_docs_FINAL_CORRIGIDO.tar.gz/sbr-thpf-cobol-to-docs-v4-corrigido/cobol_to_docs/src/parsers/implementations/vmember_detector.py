"""
COBOL AI Engine v4.0 - VMEMBER Detector
Detector robusto para arquivos VMEMBER e tipos de conteúdo.
"""

import re
import logging
from typing import List

from parsers.interfaces.parser_interface import IContentDetector, ContentType


class VMemberDetector(IContentDetector):
    """
    Detector de arquivos VMEMBER e tipos de conteúdo.
    
    Responsabilidades:
    - Detectar arquivos empilhados (VMEMBER)
    - Identificar arquivos de lista
    - Classificar arquivos únicos
    - Calcular confiança da detecção
    """
    
    def __init__(self):
        """Inicializa o detector VMEMBER."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões VMEMBER suportados
        self.vmember_patterns = [
            re.compile(r'^\s*VMEMBER\s+NAME\s+([A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'^\s*VMEMBER\s+([A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'^\s*//\s*VMEMBER\s+NAME\s+([A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'^\s*\*\s*VMEMBER\s+NAME\s+([A-Z0-9\-_]+)', re.IGNORECASE),
            re.compile(r'^\s*//\*\s*([A-Z0-9\-_]+)\s*\*', re.IGNORECASE),
        ]
        
        # Indicadores de código COBOL
        self.cobol_indicators = [
            'IDENTIFICATION DIVISION',
            'ID DIVISION',
            'PROGRAM-ID',
            'DATA DIVISION',
            'PROCEDURE DIVISION',
            'WORKING-STORAGE SECTION',
            'FILE SECTION',
            'LINKAGE SECTION'
        ]
        
        # Indicadores de copybook
        self.copybook_indicators = [
            'COPY',
            'INCLUDE',
            'REPLACING',
            '01 ',
            '05 ',
            '10 ',
            'PIC ',
            'PICTURE '
        ]
        
        self.logger.info("VMEMBER Detector inicializado")
    
    def detect_content_type(self, content: str) -> ContentType:
        """
        Detecta o tipo do conteúdo.
        
        Args:
            content: Conteúdo a analisar
            
        Returns:
            ContentType: Tipo detectado
        """
        if not content or not content.strip():
            return ContentType.UNKNOWN
        
        # Verificar arquivo empilhado primeiro
        if self.is_stacked_file(content):
            return ContentType.STACKED_FILE
        
        # Verificar arquivo de lista
        if self._is_list_file(content):
            return ContentType.LIST_FILE
        
        # Verificar arquivo COBOL único
        if self._is_single_cobol_file(content):
            return ContentType.SINGLE_FILE
        
        return ContentType.UNKNOWN
    
    def is_stacked_file(self, content: str) -> bool:
        """
        Verifica se é arquivo empilhado.
        
        Args:
            content: Conteúdo a verificar
            
        Returns:
            bool: True se for arquivo empilhado
        """
        # Verificar padrões VMEMBER
        for pattern in self.vmember_patterns:
            if pattern.search(content):
                self.logger.debug("Arquivo empilhado detectado via padrão VMEMBER")
                return True
        
        # Verificar múltiplos programas/copybooks no mesmo arquivo
        lines = content.split('\n')
        program_starts = 0
        
        for line in lines:
            line_upper = line.upper().strip()
            if 'PROGRAM-ID' in line_upper or 'IDENTIFICATION DIVISION' in line_upper:
                program_starts += 1
                if program_starts > 1:
                    self.logger.debug("Arquivo empilhado detectado via múltiplos PROGRAM-ID")
                    return True
        
        return False
    
    def get_confidence_score(self, content: str, content_type: ContentType) -> float:
        """
        Retorna pontuação de confiança para o tipo detectado.
        
        Args:
            content: Conteúdo analisado
            content_type: Tipo a verificar
            
        Returns:
            float: Pontuação de 0.0 a 1.0
        """
        if not content:
            return 0.0
        
        if content_type == ContentType.STACKED_FILE:
            return self._calculate_stacked_confidence(content)
        elif content_type == ContentType.LIST_FILE:
            return self._calculate_list_confidence(content)
        elif content_type == ContentType.SINGLE_FILE:
            return self._calculate_single_confidence(content)
        else:
            return 0.0
    
    def _is_list_file(self, content: str) -> bool:
        """
        Verifica se é arquivo de lista.
        
        Args:
            content: Conteúdo a verificar
            
        Returns:
            bool: True se for arquivo de lista
        """
        lines = content.strip().split('\n')
        
        # Arquivo muito pequeno provavelmente não é lista
        if len(lines) < 2:
            return False
        
        # Verificar se as linhas parecem caminhos de arquivo
        path_like_lines = 0
        cobol_like_lines = 0
        
        for line in lines[:10]:  # Verificar primeiras 10 linhas
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            # Indicadores de caminho
            if (('/' in line or '\\' in line) or
                line.endswith(('.cbl', '.cob', '.cobol', '.txt', '.dat')) or
                (len(line.split()) == 1 and len(line) > 3)):
                path_like_lines += 1
            
            # Indicadores de COBOL
            line_upper = line.upper()
            if any(indicator in line_upper for indicator in self.cobol_indicators):
                cobol_like_lines += 1
        
        # Se tem mais linhas parecidas com caminho que com COBOL, é lista
        return path_like_lines > cobol_like_lines and path_like_lines >= 2
    
    def _is_single_cobol_file(self, content: str) -> bool:
        """
        Verifica se é arquivo COBOL único.
        
        Args:
            content: Conteúdo a verificar
            
        Returns:
            bool: True se for COBOL único
        """
        content_upper = content.upper()
        
        # Verificar indicadores de COBOL
        cobol_score = sum(1 for indicator in self.cobol_indicators 
                         if indicator in content_upper)
        
        # Verificar indicadores de copybook
        copybook_score = sum(1 for indicator in self.copybook_indicators 
                           if indicator in content_upper)
        
        # Se tem pelo menos 2 indicadores de COBOL ou copybook, é arquivo COBOL
        return (cobol_score >= 2) or (copybook_score >= 3)
    
    def _calculate_stacked_confidence(self, content: str) -> float:
        """Calcula confiança para arquivo empilhado."""
        confidence = 0.0
        
        # Verificar padrões VMEMBER explícitos
        vmember_matches = 0
        for pattern in self.vmember_patterns:
            vmember_matches += len(pattern.findall(content))
        
        if vmember_matches > 0:
            confidence += 0.8  # Alta confiança para VMEMBER explícito
            confidence += min(0.2, vmember_matches * 0.05)  # Bônus por múltiplos membros
        
        # Verificar múltiplos PROGRAM-ID
        program_ids = len(re.findall(r'PROGRAM-ID', content, re.IGNORECASE))
        if program_ids > 1:
            confidence += 0.6
            confidence += min(0.3, (program_ids - 1) * 0.1)
        
        return min(1.0, confidence)
    
    def _calculate_list_confidence(self, content: str) -> float:
        """Calcula confiança para arquivo de lista."""
        lines = content.strip().split('\n')
        if len(lines) < 2:
            return 0.0
        
        path_score = 0
        total_lines = 0
        
        for line in lines[:20]:  # Verificar primeiras 20 linhas
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            total_lines += 1
            
            # Pontuação para características de caminho
            if '/' in line or '\\' in line:
                path_score += 0.3
            if line.endswith(('.cbl', '.cob', '.cobol', '.txt')):
                path_score += 0.4
            if len(line.split()) == 1 and 3 < len(line) < 100:
                path_score += 0.2
            if not any(indicator in line.upper() for indicator in self.cobol_indicators):
                path_score += 0.1
        
        if total_lines == 0:
            return 0.0
        
        return min(1.0, path_score / total_lines)
    
    def _calculate_single_confidence(self, content: str) -> float:
        """Calcula confiança para arquivo COBOL único."""
        content_upper = content.upper()
        
        # Pontuação baseada em indicadores COBOL
        cobol_score = sum(0.2 for indicator in self.cobol_indicators 
                         if indicator in content_upper)
        
        # Pontuação baseada em indicadores copybook
        copybook_score = sum(0.1 for indicator in self.copybook_indicators 
                           if indicator in content_upper)
        
        # Penalizar se tem múltiplos PROGRAM-ID (seria empilhado)
        program_ids = len(re.findall(r'PROGRAM-ID', content, re.IGNORECASE))
        if program_ids > 1:
            cobol_score *= 0.3
        
        # Penalizar se tem VMEMBER
        if any(pattern.search(content) for pattern in self.vmember_patterns):
            cobol_score *= 0.1
        
        total_score = cobol_score + copybook_score
        return min(1.0, total_score)
    
    def get_vmember_names(self, content: str) -> List[str]:
        """
        Extrai nomes de membros VMEMBER do conteúdo.
        
        Args:
            content: Conteúdo a analisar
            
        Returns:
            List[str]: Lista de nomes de membros
        """
        member_names = []
        
        for pattern in self.vmember_patterns:
            matches = pattern.findall(content)
            member_names.extend(matches)
        
        # Remover duplicatas mantendo ordem
        seen = set()
        unique_names = []
        for name in member_names:
            if name not in seen:
                seen.add(name)
                unique_names.append(name)
        
        return unique_names
    
    def get_detection_info(self, content: str) -> dict:
        """
        Retorna informações detalhadas sobre a detecção.
        
        Args:
            content: Conteúdo analisado
            
        Returns:
            dict: Informações de detecção
        """
        detected_type = self.detect_content_type(content)
        confidence = self.get_confidence_score(content, detected_type)
        
        info = {
            'detected_type': detected_type.value,
            'confidence': confidence,
            'vmember_names': [],
            'indicators_found': [],
            'analysis': {}
        }
        
        if detected_type == ContentType.STACKED_FILE:
            info['vmember_names'] = self.get_vmember_names(content)
            info['analysis']['vmember_count'] = len(info['vmember_names'])
            info['analysis']['program_ids'] = len(re.findall(r'PROGRAM-ID', content, re.IGNORECASE))
        
        # Adicionar indicadores encontrados
        content_upper = content.upper()
        for indicator in self.cobol_indicators:
            if indicator in content_upper:
                info['indicators_found'].append(indicator)
        
        return info
