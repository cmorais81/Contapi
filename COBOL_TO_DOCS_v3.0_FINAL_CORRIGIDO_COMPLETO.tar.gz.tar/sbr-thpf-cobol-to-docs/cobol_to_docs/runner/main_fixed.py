#!/usr/bin/env python3
"""
COBOL to Docs v3.0 - Main Application
Aplicação principal para análise e documentação de programas COBOL com IA.
"""

import os
import sys
import argparse
import logging
import time
import json
from typing import List, Dict, Any, Optional

# Adicionar o diretório src ao path para imports
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, '..', 'src')
sys.path.insert(0, src_dir)

# Imports dos módulos
from core.config import ConfigManager
from parsers.cobol_parser_original import CobolParser
from core.main_processor import MainProcessor
from providers.enhanced_provider_manager import EnhancedProviderManager
from rag.rag_integration import RAGIntegration
from rag.rag_maintenance import RAGMaintenance
from utils.cost_calculator import CostCalculator
from utils.html_generator import HTMLReportGenerator
from generators.documentation_generator import DocumentationGenerator
from analyzers.enhanced_cobol_analyzer import EnhancedCobolAnalyzer
from core.prompt_manager_dual import ExpertPromptManager


def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)
    
    logging.basicConfig(
        level=numeric_level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('cobol_to_docs.log')
        ]
    )


def parse_arguments():
    """Parse dos argumentos da linha de comando."""
    parser = argparse.ArgumentParser(
        description="COBOL to Docs v3.0 - Análise e Documentação de Programas COBOL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  python main.py --fontes examples/fontes.txt
  python main.py --fontes examples/fontes.txt --books examples/books.txt
  python main.py --fontes examples/fontes.txt --models '["aws-claude-3.7", "enhanced_mock"]'
  python main.py --fontes examples/fontes.txt --consolidado
  python main.py --fontes examples/fontes.txt --books examples/books.txt --consolidado --models enhanced_mock
  python main.py --status
  
Manutenção da Base RAG:
  python main.py --rag-stats                    # Mostrar estatísticas da base
  python main.py --rag-backup                   # Criar backup da base
  python main.py --rag-clean                    # Limpar duplicatas
  python main.py --rag-reindex                  # Reindexação completa
  python main.py --rag-stats --rag-reindex      # Estatísticas + reindexação

Configuração Personalizada:
  python main.py --config-dir /path/to/config --fontes fontes.txt
  python main.py --data-dir /path/to/data --rag-stats
  python main.py --prompts-file /path/to/prompts.yaml --fontes fontes.txt
        """
    )
    
    # Argumentos principais
    parser.add_argument('--fontes', type=str, help='Arquivo com programas COBOL')
    parser.add_argument('--books', type=str, help='Arquivo com copybooks COBOL')
    parser.add_argument('--output', type=str, default='output', help='Diretório de saída')
    parser.add_argument('--models', type=str, help='Modelos de IA (string ou JSON array)')
    parser.add_argument('--prompt-set', type=str, default='original', help='Conjunto de prompts')
    parser.add_argument('--log-level', type=str, default='INFO', help='Nível de log')
    parser.add_argument('--pdf', action='store_true', help='Gerar relatórios HTML/PDF')
    parser.add_argument('--relatorio-unico', action='store_true',
                        help='Gera relatório único consolidado de todo o sistema')
    parser.add_argument('--consolidado', action='store_true',
                        help='Análise consolidada sistêmica de todos os programas simultaneamente')
    parser.add_argument('--analise-especialista', action='store_true',
                        help='Usa prompts especializados para análise técnica profunda')
    parser.add_argument('--procedure-detalhada', action='store_true',
                        help='Foca na análise detalhada da PROCEDURE DIVISION')
    parser.add_argument('--modernizacao', action='store_true',
                        help='Inclui análise de modernização e migração')
    parser.add_argument('--status', action='store_true', help='Verificar status dos provedores')
    parser.add_argument('--auto-model', action='store_true', 
                        help='Seleção automática de modelo baseada na complexidade do código')
    parser.add_argument('--model-comparison', action='store_true',
                        help='Exibir comparação de adequação de modelos para o código')
    parser.add_argument('--deep-analysis', action='store_true',
                        help='Análise detalhada de regras de negócio com valores específicos')
    parser.add_argument('--extract-formulas', action='store_true',
                        help='Extrair fórmulas matemáticas e cálculos específicos do código')
    parser.add_argument('--advanced-analysis', action='store_true',
                        help='Executar análise avançada com relatório consolidado HTML profissional')
    
    # RAG Maintenance Arguments
    parser.add_argument('--rag-reindex', action='store_true',
                        help='Reindexar e otimizar a base de conhecimento RAG')
    parser.add_argument('--rag-stats', action='store_true',
                        help='Mostrar estatísticas da base de conhecimento RAG')
    parser.add_argument('--rag-backup', action='store_true',
                        help='Criar backup da base de conhecimento RAG')
    parser.add_argument('--rag-clean', action='store_true',
                        help='Limpar duplicatas e otimizar a base RAG')
    
    # Configuration Directory Arguments
    parser.add_argument('--config-dir', type=str, 
                        help='Diretório de configuração personalizado (padrão: auto-detectado)')
    parser.add_argument('--config-file', type=str,
                        help='Arquivo de configuração personalizado (padrão: config.yaml)')
    parser.add_argument('--prompts-file', type=str,
                        help='Arquivo de prompts personalizado (padrão: prompts.yaml)')
    parser.add_argument('--data-dir', type=str,
                        help='Diretório de dados/base RAG personalizado (padrão: auto-detectado)')
    
    return parser.parse_args()


def main():
    """Função principal da aplicação."""
    # Parse dos argumentos
    args = parse_arguments()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    try:
        # Carregar configuração com caminhos personalizados se fornecidos
        config_path = None
        if args.config_file:
            config_path = args.config_file
        elif args.config_dir:
            config_path = os.path.join(args.config_dir, 'config.yaml')
        
        config_manager = ConfigManager(config_path=config_path)
        
        # Configurar caminhos personalizados se fornecidos
        if args.prompts_file:
            config_manager.custom_prompts_file = args.prompts_file
        if args.data_dir:
            config_manager.custom_data_dir = args.data_dir
        
        # Inicializar sistema RAG
        rag_integration = RAGIntegration(config_manager.config)
        if rag_integration.is_enabled():
            rag_integration.initialize()
            logger.info("Sistema RAG inicializado com sucesso")
        
        # Verificar se é comando de status
        if args.status:
            provider_manager = EnhancedProviderManager(config_manager.config)
            status_info = provider_manager.get_providers_status()
            
            print("\n=== STATUS DOS PROVEDORES ===")
            for provider, info in status_info.items():
                status = "✅ DISPONÍVEL" if info['available'] else "❌ INDISPONÍVEL"
                print(f"{provider}: {status}")
                if info.get('models'):
                    print(f"  Modelos: {', '.join(info['models'])}")
                if info.get('error'):
                    print(f"  Erro: {info['error']}")
            print("=" * 30)
            return
        
        # Verificar comandos de manutenção RAG
        if any([args.rag_stats, args.rag_backup, args.rag_clean, args.rag_reindex]):
            data_dir = config_manager.get_data_directory()
            rag_maintenance = RAGMaintenance(data_dir)
            
            if args.rag_stats:
                print("\n=== ESTATÍSTICAS DA BASE RAG ===")
                stats = rag_maintenance.get_base_statistics()
                for key, value in stats.items():
                    print(f"{key}: {value}")
                print("=" * 35)
            
            if args.rag_backup:
                backup_file = rag_maintenance.create_backup()
                print(f"✅ Backup criado: {backup_file}")
            
            if args.rag_clean:
                print("🧹 Limpando base RAG...")
                results = rag_maintenance.clean_knowledge_base()
                print(f"✅ Limpeza concluída:")
                for key, value in results.items():
                    print(f"  {key}: {value}")
            
            if args.rag_reindex:
                print("🔄 Reindexando base RAG...")
                results = rag_maintenance.reindex_knowledge_base()
                print(f"✅ Reindexação concluída:")
                for key, value in results.items():
                    print(f"  {key}: {value}")
            
            return
        
        # Verificar se arquivos de entrada foram fornecidos
        if not args.fontes:
            logger.error("Arquivo de fontes não fornecido. Use --fontes para especificar.")
            print("Erro: Arquivo de fontes é obrigatório. Use --help para ver exemplos.")
            return
        
        # Verificar se arquivo existe
        if not os.path.exists(args.fontes):
            logger.error(f"Arquivo de fontes não encontrado: {args.fontes}")
            print(f"Erro: Arquivo não encontrado: {args.fontes}")
            return
        
        # Inicializar componentes
        parser = CobolParser()
        provider_manager = EnhancedProviderManager(config_manager.config)
        cost_calculator = CostCalculator()
        html_generator = HTMLReportGenerator()
        doc_generator = DocumentationGenerator(config_manager.config)
        analyzer = EnhancedCobolAnalyzer(config_manager.config)
        
        # Parse dos arquivos
        logger.info(f"Parseando arquivo de fontes: {args.fontes}")
        programs_result, _ = parser.parse_file(args.fontes)
        programs = programs_result
        
        books = []
        if args.books and os.path.exists(args.books):
            logger.info(f"Parseando arquivo de copybooks: {args.books}")
            _, books_result = parser.parse_file(args.books)
            books = books_result
        
        logger.info(f"Parseados {len(programs)} programas e {len(books)} books")
        
        if not programs:
            logger.error("Nenhum programa encontrado no arquivo de fontes")
            print("Erro: Nenhum programa encontrado no arquivo de fontes")
            return
        
        # Determinar modelos a usar
        models = ['enhanced_mock']  # Padrão
        if args.models:
            try:
                if args.models.startswith('['):
                    models = json.loads(args.models)
                else:
                    models = [args.models]
            except json.JSONDecodeError:
                models = [args.models]
        
        # Criar diretório de saída
        os.makedirs(args.output, exist_ok=True)
        
        # Processar programas
        total_start_time = time.time()
        
        if args.consolidado:
            # Análise consolidada
            logger.info("Iniciando análise consolidada")
            
            # Usar o primeiro modelo para análise consolidada
            model = models[0]
            
            # Criar processador principal
            main_processor = MainProcessor(
                config_manager.config,
                provider_manager,
                cost_calculator,
                doc_generator,
                analyzer,
                rag_integration
            )
            
            # Processar análise consolidada
            result = main_processor.process_consolidated_analysis(
                programs, books, model, args.output
            )
            
            if result['success']:
                logger.info(f"Análise consolidada concluída com sucesso")
                logger.info(f"Tokens utilizados: {result['tokens_used']:,}")
                logger.info(f"Tempo total: {result['analysis_time']:.2f}s")
                print(f"✅ Análise consolidada concluída!")
                print(f"📊 Tokens: {result['tokens_used']:,}")
                print(f"⏱️  Tempo: {result['analysis_time']:.2f}s")
                print(f"📁 Arquivos gerados em: {args.output}")
            else:
                logger.error(f"Falha na análise consolidada: {result.get('error', 'Erro desconhecido')}")
                print(f"❌ Falha na análise consolidada: {result.get('error', 'Erro desconhecido')}")
        
        else:
            # Análise individual
            logger.info("Iniciando análise individual dos programas")
            
            all_results = []
            total_tokens = 0
            
            for program in programs:
                for model in models:
                    logger.info(f"Analisando {program.name} com modelo {model}")
                    
                    # Criar diretório específico do modelo
                    model_output_dir = os.path.join(args.output, f"model_{model}")
                    os.makedirs(model_output_dir, exist_ok=True)
                    
                    # Analisar programa
                    result = analyzer.analyze_program(program, model)
                    
                    if result.success:
                        # Gerar documentação
                        doc_result = doc_generator.generate_program_documentation(program, result)
                        
                        # Gerar PDF se solicitado
                        if args.pdf:
                            try:
                                pdf_path = os.path.join(model_output_dir, f"{program.name}_analise_funcional.pdf")
                                html_generator.generate_pdf(result.content, pdf_path)
                                logger.info(f"PDF gerado: {pdf_path}")
                                print(f"  PDF gerado: {pdf_path}")
                            except Exception as e:
                                logger.warning(f"Erro ao gerar PDF para {program.name}: {e}")
                        
                        all_results.append({
                            'success': True,
                            'program_name': program.name,
                            'model': model,
                            'tokens_used': result.tokens_used,
                            'output_dir': model_output_dir
                        })
                        
                        total_tokens += result.tokens_used
                        
                        # Auto-learning: Adicionar à base RAG
                        if rag_integration and rag_integration.is_enabled():
                            try:
                                rag_integration.add_program_analysis_to_knowledge_base(
                                    program.name, result.content, program.content
                                )
                                logger.info(f"Auto-learning: Conhecimento do programa {program.name} adicionado à base RAG")
                            except Exception as e:
                                logger.warning(f"Auto-learning falhou para {program.name}: {e}")
                        
                        logger.info(f"✅ {program.name} analisado com sucesso ({result.tokens_used:,} tokens)")
                    
                    else:
                        logger.error(f"❌ Falha na análise de {program.name}: {result.error_message}")
                        all_results.append({
                            'success': False,
                            'program_name': program.name,
                            'model': model,
                            'error': result.error_message
                        })
            
            # Resumo final
            total_time = time.time() - total_start_time
            successful_analyses = sum(1 for r in all_results if r['success'])
            total_analyses = len(all_results)
            
            logger.info(f"Análise individual concluída")
            logger.info(f"Sucessos: {successful_analyses}/{total_analyses}")
            logger.info(f"Tokens totais: {total_tokens:,}")
            logger.info(f"Tempo total: {total_time:.2f}s")
            
            print(f"\n✅ Análise individual concluída!")
            print(f"📊 Sucessos: {successful_analyses}/{total_analyses}")
            print(f"🎯 Taxa de sucesso: {(successful_analyses/total_analyses*100):.1f}%")
            print(f"📊 Tokens totais: {total_tokens:,}")
            print(f"⏱️  Tempo total: {total_time:.2f}s")
            print(f"📁 Arquivos gerados em: {args.output}")
        
        # Finalizar sessão RAG
        if rag_integration and rag_integration.is_enabled():
            try:
                session_summary = rag_integration.finalize_session()
                if session_summary:
                    print(f"\n=== RELATÓRIO RAG DISPONÍVEL ===")
                    if 'report_file' in session_summary:
                        print(f"Arquivo: {session_summary['report_file']}")
                    print(f"Operações RAG realizadas: {session_summary.get('total_operations', 0)}")
                    print(f"Programas analisados: {len(session_summary.get('programs_analyzed', []))}")
                    print(f"Itens de conhecimento utilizados: {session_summary.get('knowledge_items_used', 0)}")
                    print("=" * 40)
            except Exception as e:
                logger.warning(f"Erro ao finalizar sessão RAG: {e}")
        
    except KeyboardInterrupt:
        print("\nProcessamento interrompido pelo usuário.")
    except Exception as e:
        import traceback
        logger.error(f"Erro fatal: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        print(f"Erro: {str(e)}")
        print("Traceback completo:")
        traceback.print_exc()


if __name__ == "__main__":
    main()
