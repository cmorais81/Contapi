#!/usr/bin/env python3
"""
Test script to validate configuration parameters functionality
"""

import os
import sys
import tempfile
import yaml
import json

# Add the package to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'cobol_to_docs', 'src'))

from core.config import ConfigManager

def test_default_config():
    """Test default configuration loading"""
    print("=== Testing Default Configuration ===")
    
    config_manager = ConfigManager()
    
    print(f"Execution method: {config_manager.execution_method}")
    print(f"Config path: {config_manager.config_path}")
    print(f"Data directory: {config_manager.get_data_directory()}")
    print(f"System prompt loaded: {'Yes' if config_manager.get_system_prompt() else 'No'}")
    print()

def test_custom_paths():
    """Test custom paths functionality"""
    print("=== Testing Custom Paths ===")
    
    # Create temporary files
    with tempfile.TemporaryDirectory() as temp_dir:
        # Create custom config
        custom_config = {
            'ai': {'prompt': {'prompts_file': 'custom_prompts.yaml'}},
            'providers': {'test_provider': {'enabled': True}},
            'rag': {'enabled': True}
        }
        
        config_file = os.path.join(temp_dir, 'custom_config.yaml')
        with open(config_file, 'w') as f:
            yaml.dump(custom_config, f)
        
        # Create custom prompts
        custom_prompts = {
            'prompts': {
                'system_prompt': 'Custom system prompt for testing'
            }
        }
        
        prompts_file = os.path.join(temp_dir, 'custom_prompts.yaml')
        with open(prompts_file, 'w') as f:
            yaml.dump(custom_prompts, f)
        
        # Create custom data directory
        data_dir = os.path.join(temp_dir, 'custom_data')
        os.makedirs(data_dir)
        
        # Create custom knowledge base
        kb_data = [
            {
                'id': 'test_001',
                'title': 'Test Knowledge',
                'content': 'Test content',
                'category': 'test',
                'keywords': ['test'],
                'cobol_constructs': ['PERFORM'],
                'domain': 'test',
                'complexity_level': 'basic'
            }
        ]
        
        kb_file = os.path.join(data_dir, 'cobol_knowledge_base.json')
        with open(kb_file, 'w') as f:
            json.dump(kb_data, f)
        
        # Test custom configuration
        config_manager = ConfigManager(
            config_path=config_file,
            data_dir=data_dir,
            prompts_file=prompts_file
        )
        
        print(f"Custom config loaded: {config_manager.config_path == config_file}")
        print(f"Custom data dir: {config_manager.get_data_directory() == data_dir}")
        print(f"Custom prompt loaded: {'Custom system prompt' in config_manager.get_system_prompt()}")
        print()

def test_fallback_behavior():
    """Test fallback behavior when files don't exist"""
    print("=== Testing Fallback Behavior ===")
    
    # Test with non-existent paths
    config_manager = ConfigManager(
        config_path='/non/existent/config.yaml',
        data_dir='/non/existent/data',
        prompts_file='/non/existent/prompts.yaml'
    )
    
    print(f"Fallback config created: {os.path.exists(config_manager.config_path)}")
    print(f"Fallback data dir created: {os.path.exists(config_manager.get_data_directory())}")
    print(f"Default system prompt available: {'Você é um especialista' in config_manager.get_system_prompt()}")
    print()

def main():
    """Run all tests"""
    print("COBOL to Docs - Configuration Parameters Test")
    print("=" * 50)
    
    try:
        test_default_config()
        test_custom_paths()
        test_fallback_behavior()
        
        print("✅ All tests completed successfully!")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
