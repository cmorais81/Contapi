# 🍎 COBOL AI Engine v15.0 - macOS Edition

**Versão:** 15.0 - Universal Functional Documentation  
**Compatibilidade:** macOS 12.0+ (Monterey, Ventura, Sonoma)  
**Python:** 3.11+ (Intel e Apple Silicon)  
**Data:** 18/09/2025  

## 🚀 Instalação Rápida no macOS

### Pré-requisitos
```bash
# 1. Instalar Python 3.11+ (se não tiver)
brew install python@3.11

# 2. Verificar instalação
python3.11 --version  # Deve mostrar 3.11.x ou superior
```

### Instalação Automática
```bash
# 1. Extrair o pacote
tar -xzf cobol_ai_engine_v15.0_macOS.tar.gz
cd cobol_ai_engine_v2.0.0/

# 2. Executar instalação automática
./install_macos.sh

# 3. Ativar ambiente virtual
source venv/bin/activate
```

### Instalação Manual (Alternativa)
```bash
# 1. Criar ambiente virtual
python3.11 -m venv venv
source venv/bin/activate

# 2. Instalar dependências
pip install -r requirements_macos.txt

# 3. Configurar ambiente
export PYTHONPATH=./src
export PYTHONIOENCODING=utf-8
```

## 🧪 Teste de Funcionamento

### Demo Rápida (3 programas)
```bash
python main_v15_demo.py
```

### Análise Completa
```bash
python main_v15_universal_functional.py examples/fontes.txt examples/BOOKS.txt
```

### Teste de Dependências
```bash
python -c "import yaml, requests, pandas, numpy; print('✅ Tudo funcionando!')"
```

## 📁 Estrutura do Projeto

```
cobol_ai_engine_v2.0.0/
├── 📄 README_macOS.md              # Este arquivo
├── 🔧 install_macos.sh             # Script de instalação
├── 📦 requirements_macos.txt       # Dependências para macOS
├── 🐍 main_v15_demo.py            # Demo (3 programas)
├── 🐍 main_v15_universal_functional.py  # Análise completa
├── ⚙️ config/
│   ├── config.yaml                # Configurações gerais
│   └── prompts.yaml               # Prompts para LLM
├── 🧠 src/                        # Código fonte
│   ├── analyzers/                 # Analisadores universais
│   ├── generators/                # Geradores de documentação
│   ├── parsers/                   # Parsers COBOL
│   ├── providers/                 # Provedores LLM
│   └── utils/                     # Utilitários
└── 📚 examples/                   # Exemplos
    ├── fontes.txt                 # Programas COBOL
    └── BOOKS.txt                  # Copybooks
```

## 🎯 Uso Básico

### 1. Análise de Demonstração
```bash
# Analisa apenas 3 programas para demonstração
python main_v15_demo.py

# Resultados em: functional_demo_results_v15/
```

### 2. Análise Completa
```bash
# Analisa todos os programas do arquivo fontes.txt
python main_v15_universal_functional.py examples/fontes.txt examples/BOOKS.txt

# Resultados em: functional_analysis_results_v15/
```

### 3. Análise de Arquivos Próprios
```bash
# Substitua pelos seus arquivos
python main_v15_universal_functional.py /caminho/para/seus/fontes.txt /caminho/para/seus/books.txt
```

## 📊 Resultados Gerados

### Para Cada Programa
- **📋 Documentação Funcional** (`PROGRAMA_FUNCTIONAL_DOCS_v15.md`)
- **💻 Código Java/Python** (pronto para reimplementação)
- **📈 Métricas de Qualidade** (score de reimplementação)
- **🔍 Análise de Estruturas** (arquivos, campos, copybooks)
- **🧠 Regras de Negócio** (extraídas automaticamente)

### Relatórios Consolidados
- **📊 Relatório Geral** (`CONSOLIDATED_REPORT_v15.md`)
- **📈 Estatísticas** (scores, sucessos, falhas)
- **🎯 Recomendações** (priorização, esforço estimado)

## 🔧 Configuração Avançada

### Variáveis de Ambiente
```bash
# Adicionar ao ~/.zshrc ou ~/.bash_profile
export PYTHONPATH=/caminho/para/cobol_ai_engine_v2.0.0/src
export PYTHONIOENCODING=utf-8
export LC_ALL=en_US.UTF-8
```

### Provedores LLM (Opcional)
```bash
# OpenAI
export OPENAI_API_KEY="sua_chave_aqui"

# Anthropic (Claude)
export ANTHROPIC_API_KEY="sua_chave_aqui"

# GitHub Copilot
export GITHUB_TOKEN="seu_token_aqui"
```

## 🍎 Específico para macOS

### Apple Silicon (M1/M2/M3)
- ✅ **Totalmente compatível** com ARM64
- ✅ **Performance otimizada** para chips Apple
- ✅ **Dependências nativas** (sem Rosetta)

### Intel Macs
- ✅ **Compatibilidade total** com x86_64
- ✅ **Performance estável** em todos os modelos
- ✅ **Sem dependências especiais**

### Configurações Recomendadas
```bash
# Terminal/iTerm2 - Configuração de encoding
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8

# Aumentar limite de arquivos abertos (para análises grandes)
ulimit -n 4096
```

## 🚨 Solução de Problemas

### Erro de Encoding
```bash
# Solução
export PYTHONIOENCODING=utf-8
export LC_ALL=en_US.UTF-8
```

### Erro de Permissão
```bash
# Solução
chmod +x *.py
chmod +x *.sh
```

### Erro de Dependências
```bash
# Solução
pip install --upgrade -r requirements_macos.txt
```

### Erro de Memória (arquivos grandes)
```bash
# Usar demo para arquivos muito grandes
python main_v15_demo.py  # Processa apenas 3 programas
```

### Python não encontrado
```bash
# Instalar via Homebrew
brew install python@3.11

# Ou via pyenv
brew install pyenv
pyenv install 3.11.5
pyenv global 3.11.5
```

## 📈 Performance no macOS

### Tempos Estimados
- **Demo (3 programas):** 30-60 segundos
- **Análise pequena (10 programas):** 2-5 minutos
- **Análise média (50 programas):** 10-20 minutos
- **Análise grande (200+ programas):** 1-2 horas

### Otimizações
- **SSD recomendado** para melhor I/O
- **8GB+ RAM** para análises grandes
- **Fechar apps desnecessários** durante análise

## 🎯 Exemplos de Uso

### Análise de Sistema Bancário
```bash
python main_v15_universal_functional.py sistema_bancario/fontes.txt sistema_bancario/copybooks.txt
```

### Análise de Sistema de Seguros
```bash
python main_v15_universal_functional.py seguros/programas.txt seguros/includes.txt
```

### Análise de Sistema Governamental
```bash
python main_v15_universal_functional.py governo/cobol_sources.txt governo/copy_members.txt
```

## 📞 Suporte

### Logs de Debug
```bash
# Executar com logs detalhados
python -v main_v15_demo.py 2>&1 | tee debug.log
```

### Informações do Sistema
```bash
# Coletar informações para suporte
system_profiler SPSoftwareDataType
python --version
pip list
```

## 🏆 Recursos Exclusivos macOS

### Integração com Finder
- **Arrastar e soltar** arquivos no Terminal
- **Quick Look** para visualizar resultados
- **Spotlight** para encontrar relatórios gerados

### Notificações
```bash
# Notificar quando análise terminar
python main_v15_demo.py && osascript -e 'display notification "Análise COBOL concluída!" with title "COBOL AI Engine"'
```

### Automator (Opcional)
- Criar **workflow** para análise automática
- **Ações rápidas** no menu de contexto
- **Serviços** integrados ao sistema

---

## 🎉 Pronto para Usar!

O COBOL AI Engine v15.0 está **100% otimizado para macOS** e pronto para analisar seus programas COBOL com a melhor performance possível no ecossistema Apple.

**Comando para começar:**
```bash
./install_macos.sh && source venv/bin/activate && python main_v15_demo.py
```

**Boa análise!** 🚀
