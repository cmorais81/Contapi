#!/usr/bin/env python3
"""
COBOL AI Engine v15.0 - Universal Functional Documentation
Script principal que gera documentação funcional para qualquer programa COBOL.

Melhorias implementadas:
- Analisador universal de estruturas
- Extrator universal de lógica de negócio  
- Gerador de documentação funcional completa
- Código de reimplementação funcional
- Métricas de qualidade e capacidade de reimplementação
"""

import os
import sys
import logging
import argparse
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

# Adiciona o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Imports dos componentes
from analyzers.universal_structure_analyzer import UniversalStructureAnalyzer
from analyzers.universal_business_logic_extractor import UniversalBusinessLogicExtractor
from generators.universal_functional_documentation_generator import UniversalFunctionalDocumentationGenerator
from parsers.multi_program_cobol_parser import MultiProgramCobolParser
from utils.extract_programs import extract_programs_from_file
from utils.extract_books import extract_books_from_file


class UniversalFunctionalAnalyzer:
    """
    Analisador universal que gera documentação funcional para qualquer programa COBOL.
    """
    
    def __init__(self):
        self.setup_logging()
        self.logger = logging.getLogger(self.__class__.__name__)
        
        # Inicializa componentes
        self.structure_analyzer = UniversalStructureAnalyzer()
        self.business_logic_extractor = UniversalBusinessLogicExtractor()
        self.documentation_generator = UniversalFunctionalDocumentationGenerator()
        self.cobol_parser = MultiProgramCobolParser()
        
        self.logger.info("COBOL AI Engine v15.0 - Universal Functional Documentation inicializado")
    
    def setup_logging(self):
        """Configura logging."""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('cobol_ai_engine_v15.log'),
                logging.StreamHandler(sys.stdout)
            ]
        )
    
    def analyze_programs(self, fontes_file: str, books_file: str, output_dir: str = "functional_analysis_results_v15") -> Dict[str, Any]:
        """
        Analisa todos os programas COBOL e gera documentação funcional.
        
        Args:
            fontes_file: Arquivo com lista de programas COBOL
            books_file: Arquivo com copybooks
            output_dir: Diretório de saída
            
        Returns:
            Dicionário com resultados da análise
        """
        self.logger.info(f"Iniciando análise funcional universal")
        self.logger.info(f"Fontes: {fontes_file}")
        self.logger.info(f"Books: {books_file}")
        
        # Cria diretório de saída
        output_path = Path(output_dir)
        output_path.mkdir(exist_ok=True)
        
        try:
            # Extrai programas e copybooks
            self.logger.info("Extraindo programas COBOL...")
            programs = extract_programs_from_file(fontes_file)
            self.logger.info(f"Extraídos {len(programs)} programas")
            
            self.logger.info("Extraindo copybooks...")
            copybooks = extract_books_from_file(books_file)
            self.logger.info(f"Extraídos {len(copybooks)} copybooks")
            
            # Resultados consolidados
            consolidated_results = {
                'analysis_date': datetime.now().isoformat(),
                'version': '15.0 - Universal Functional Documentation',
                'total_programs': len(programs),
                'total_copybooks': len(copybooks),
                'programs_analyzed': 0,
                'programs_successful': 0,
                'programs_failed': 0,
                'average_reimplementation_score': 0.0,
                'programs': {},
                'summary_statistics': {}
            }
            
            # Analisa cada programa
            reimpl_scores = []
            
            for i, program in enumerate(programs, 1):
                program_name = program.get('name', f'PROGRAM_{i}')
                self.logger.info(f"Analisando programa {i}/{len(programs)}: {program_name}")
                
                try:
                    # Análise do programa
                    program_result = self._analyze_single_program(
                        program, copybooks, output_path, program_name
                    )
                    
                    consolidated_results['programs'][program_name] = program_result
                    consolidated_results['programs_successful'] += 1
                    
                    # Coleta score de reimplementação
                    reimpl_score = program_result.get('reimplementation_score', 0.0)
                    reimpl_scores.append(reimpl_score)
                    
                    self.logger.info(f"✅ {program_name} analisado com sucesso (Score: {reimpl_score:.1f}%)")
                    
                except Exception as e:
                    self.logger.error(f"❌ Erro ao analisar {program_name}: {str(e)}")
                    consolidated_results['programs_failed'] += 1
                    consolidated_results['programs'][program_name] = {
                        'status': 'failed',
                        'error': str(e),
                        'reimplementation_score': 0.0
                    }
                
                consolidated_results['programs_analyzed'] += 1
            
            # Calcula estatísticas finais
            if reimpl_scores:
                consolidated_results['average_reimplementation_score'] = sum(reimpl_scores) / len(reimpl_scores)
            
            consolidated_results['summary_statistics'] = self._generate_summary_statistics(consolidated_results)
            
            # Gera relatório consolidado
            self._generate_consolidated_report(consolidated_results, output_path)
            
            # Log final
            success_rate = (consolidated_results['programs_successful'] / consolidated_results['total_programs']) * 100
            avg_score = consolidated_results['average_reimplementation_score']
            
            self.logger.info(f"🎯 Análise Funcional Universal Finalizada!")
            self.logger.info(f"📊 {consolidated_results['programs_successful']}/{consolidated_results['total_programs']} programas analisados com sucesso ({success_rate:.1f}%)")
            self.logger.info(f"📈 Score médio de reimplementação: {avg_score:.1f}%")
            
            # Avaliação qualitativa
            if avg_score >= 70:
                self.logger.info("🎉 EXCELENTE! Maioria dos programas com alta capacidade de reimplementação!")
            elif avg_score >= 50:
                self.logger.info("👍 BOM! Programas com capacidade média de reimplementação!")
            else:
                self.logger.info("⚠️ ATENÇÃO! Programas requerem análise manual adicional!")
            
            return consolidated_results
            
        except Exception as e:
            self.logger.error(f"Erro na análise: {str(e)}")
            raise
    
    def _analyze_single_program(self, program: Dict[str, Any], copybooks: List[Dict], 
                               output_path: Path, program_name: str) -> Dict[str, Any]:
        """Analisa um programa individual."""
        
        # Cria diretório para o programa
        program_dir = output_path / program_name
        program_dir.mkdir(exist_ok=True)
        
        # Obtém código COBOL
        cobol_code = program.get('content', '')
        if not cobol_code:
            raise ValueError(f"Código COBOL não encontrado para {program_name}")
        
        # Análise estrutural universal
        self.logger.debug(f"Executando análise estrutural para {program_name}")
        structure_analysis = self.structure_analyzer.analyze(cobol_code, copybooks)
        
        # Extração de lógica de negócio universal
        self.logger.debug(f"Extraindo lógica de negócio para {program_name}")
        business_logic = self.business_logic_extractor.extract(cobol_code, structure_analysis)
        
        # Gera documentação funcional
        self.logger.debug(f"Gerando documentação funcional para {program_name}")
        functional_documentation = self.documentation_generator.generate(
            structure_analysis, business_logic, program_name
        )
        
        # Salva documentação
        doc_file = program_dir / f"{program_name}_FUNCTIONAL_DOCS_v15.md"
        with open(doc_file, 'w', encoding='utf-8') as f:
            f.write(functional_documentation)
        
        # Salva dados de análise em JSON
        import json
        analysis_data = {
            'program_name': program_name,
            'analysis_date': datetime.now().isoformat(),
            'structure_analysis': structure_analysis,
            'business_logic': business_logic,
            'reimplementation_score': self._calculate_reimplementation_score(structure_analysis, business_logic)
        }
        
        json_file = program_dir / f"{program_name}_analysis_data_v15.json"
        with open(json_file, 'w', encoding='utf-8') as f:
            json.dump(analysis_data, f, indent=2, ensure_ascii=False, default=str)
        
        return {
            'status': 'success',
            'program_name': program_name,
            'documentation_file': str(doc_file),
            'analysis_data_file': str(json_file),
            'reimplementation_score': analysis_data['reimplementation_score'],
            'structure_analysis': structure_analysis,
            'business_logic': business_logic
        }
    
    def _calculate_reimplementation_score(self, structure_analysis: Dict[str, Any], business_logic: Dict[str, Any]) -> float:
        """Calcula score de capacidade de reimplementação."""
        score = 0.0
        
        # Estruturas identificadas (30%)
        files = structure_analysis.get('files', [])
        if files:
            score += min(30.0, len(files) * 5)
        
        # Regras de negócio (40%)
        rules = business_logic.get('business_rules', [])
        if rules:
            avg_confidence = sum(rule.get('confidence', 0.0) for rule in rules) / len(rules)
            score += avg_confidence * 40
        
        # Fluxos de dados (20%)
        data_flows = business_logic.get('data_flows', [])
        if data_flows:
            score += min(20.0, len(data_flows) * 2)
        
        # Padrões identificados (10%)
        patterns = business_logic.get('patterns', [])
        if patterns:
            avg_pattern_confidence = sum(p.get('confidence', 0.0) for p in patterns) / len(patterns)
            score += avg_pattern_confidence * 10
        
        return min(100.0, score)
    
    def _generate_summary_statistics(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Gera estatísticas resumidas."""
        programs = results.get('programs', {})
        
        # Distribui scores por faixas
        score_ranges = {
            'high_readiness': 0,  # 70-100%
            'medium_readiness': 0,  # 40-69%
            'low_readiness': 0  # 0-39%
        }
        
        total_files = 0
        total_rules = 0
        total_complexity = 0
        
        for program_name, program_data in programs.items():
            if program_data.get('status') == 'success':
                score = program_data.get('reimplementation_score', 0.0)
                
                if score >= 70:
                    score_ranges['high_readiness'] += 1
                elif score >= 40:
                    score_ranges['medium_readiness'] += 1
                else:
                    score_ranges['low_readiness'] += 1
                
                # Coleta estatísticas adicionais
                structure = program_data.get('structure_analysis', {})
                business = program_data.get('business_logic', {})
                
                total_files += len(structure.get('files', []))
                total_rules += len(business.get('business_rules', []))
                total_complexity += business.get('complexity_analysis', {}).get('total_complexity', 0)
        
        successful_programs = results.get('programs_successful', 0)
        
        return {
            'score_distribution': score_ranges,
            'average_files_per_program': total_files / max(successful_programs, 1),
            'average_rules_per_program': total_rules / max(successful_programs, 1),
            'average_complexity_per_program': total_complexity / max(successful_programs, 1),
            'total_files_identified': total_files,
            'total_rules_identified': total_rules,
            'total_complexity_points': total_complexity
        }
    
    def _generate_consolidated_report(self, results: Dict[str, Any], output_path: Path):
        """Gera relatório consolidado."""
        
        report_content = f"""# 📋 Relatório Consolidado - Análise Funcional Universal v15.0

**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Versão:** 15.0 - Universal Functional Documentation  
**Tipo:** Análise Funcional Completa  

## 📊 RESUMO EXECUTIVO

### Estatísticas Gerais
- **Total de Programas:** {results['total_programs']}
- **Programas Analisados:** {results['programs_analyzed']}
- **Sucessos:** {results['programs_successful']} ({(results['programs_successful']/results['total_programs']*100):.1f}%)
- **Falhas:** {results['programs_failed']} ({(results['programs_failed']/results['total_programs']*100):.1f}%)
- **Score Médio de Reimplementação:** {results['average_reimplementation_score']:.1f}%

### Distribuição de Capacidade de Reimplementação
- **🟢 Alta Capacidade (70-100%):** {results['summary_statistics']['score_distribution']['high_readiness']} programas
- **🟡 Média Capacidade (40-69%):** {results['summary_statistics']['score_distribution']['medium_readiness']} programas  
- **🔴 Baixa Capacidade (0-39%):** {results['summary_statistics']['score_distribution']['low_readiness']} programas

## 🎯 ANÁLISE DETALHADA

### Métricas Técnicas
- **Arquivos Identificados:** {results['summary_statistics']['total_files_identified']}
- **Regras de Negócio:** {results['summary_statistics']['total_rules_identified']}
- **Pontos de Complexidade:** {results['summary_statistics']['total_complexity_points']}
- **Média de Arquivos/Programa:** {results['summary_statistics']['average_files_per_program']:.1f}
- **Média de Regras/Programa:** {results['summary_statistics']['average_rules_per_program']:.1f}

## 📋 PROGRAMAS ANALISADOS

"""
        
        # Lista programas por categoria de score
        high_readiness = []
        medium_readiness = []
        low_readiness = []
        failed_programs = []
        
        for program_name, program_data in results['programs'].items():
            if program_data.get('status') == 'failed':
                failed_programs.append((program_name, program_data.get('error', 'Erro desconhecido')))
            else:
                score = program_data.get('reimplementation_score', 0.0)
                if score >= 70:
                    high_readiness.append((program_name, score))
                elif score >= 40:
                    medium_readiness.append((program_name, score))
                else:
                    low_readiness.append((program_name, score))
        
        # Ordena por score
        high_readiness.sort(key=lambda x: x[1], reverse=True)
        medium_readiness.sort(key=lambda x: x[1], reverse=True)
        low_readiness.sort(key=lambda x: x[1], reverse=True)
        
        # Adiciona seções
        if high_readiness:
            report_content += "### 🟢 Alta Capacidade de Reimplementação (70-100%)\n\n"
            for program_name, score in high_readiness:
                report_content += f"- **{program_name}:** {score:.1f}% - ✅ Pronto para reimplementação\n"
        
        if medium_readiness:
            report_content += "\n### 🟡 Média Capacidade de Reimplementação (40-69%)\n\n"
            for program_name, score in medium_readiness:
                report_content += f"- **{program_name}:** {score:.1f}% - ⚠️ Requer análise adicional\n"
        
        if low_readiness:
            report_content += "\n### 🔴 Baixa Capacidade de Reimplementação (0-39%)\n\n"
            for program_name, score in low_readiness:
                report_content += f"- **{program_name}:** {score:.1f}% - 🔍 Análise manual necessária\n"
        
        if failed_programs:
            report_content += "\n### ❌ Programas com Falha na Análise\n\n"
            for program_name, error in failed_programs:
                report_content += f"- **{program_name}:** {error}\n"
        
        # Recomendações
        avg_score = results['average_reimplementation_score']
        
        report_content += f"""

## 💡 RECOMENDAÇÕES

### Estratégia de Modernização
"""
        
        if avg_score >= 70:
            report_content += """
**🎉 EXCELENTE CENÁRIO**
- Maioria dos programas com alta capacidade de reimplementação
- **Estratégia:** Modernização em lote com validação automatizada
- **Prazo estimado:** 2-4 meses para todo o conjunto
- **Risco:** BAIXO
"""
        elif avg_score >= 50:
            report_content += """
**👍 BOM CENÁRIO**  
- Programas com capacidade média de reimplementação
- **Estratégia:** Modernização faseada com análise complementar
- **Prazo estimado:** 4-8 meses para todo o conjunto
- **Risco:** MÉDIO
"""
        else:
            report_content += """
**⚠️ CENÁRIO DESAFIADOR**
- Programas requerem análise manual significativa
- **Estratégia:** Análise detalhada antes da modernização
- **Prazo estimado:** 8-12 meses para todo o conjunto  
- **Risco:** ALTO
"""
        
        report_content += f"""

### Próximos Passos
1. **Priorizar** programas com score > 70% para modernização imediata
2. **Analisar manualmente** programas com score < 40%
3. **Complementar** análise dos programas com score médio
4. **Validar** regras de negócio identificadas com especialistas
5. **Testar** código gerado com dados reais

## 🔧 DETALHES TÉCNICOS

### Componentes Utilizados
- **Analisador Universal de Estruturas:** Identifica arquivos, campos e estruturas
- **Extrator Universal de Lógica:** Extrai regras de negócio e fluxos
- **Gerador de Documentação Funcional:** Cria docs para reimplementação
- **Gerador de Código:** Produz código Java/Python funcional

### Limitações Conhecidas
- Análise baseada em padrões comuns COBOL
- Regras implícitas podem não ser detectadas
- Validação manual recomendada para regras críticas
- Código gerado requer ajustes para ambiente específico

---

**Relatório gerado por:** COBOL AI Engine v15.0 - Universal Functional Documentation  
**Qualidade:** {"ALTA" if avg_score > 70 else "MÉDIA" if avg_score > 40 else "BAIXA"}  
**Recomendação:** {"Prosseguir com modernização" if avg_score > 50 else "Análise manual adicional necessária"}
"""
        
        # Salva relatório
        report_file = output_path / "CONSOLIDATED_FUNCTIONAL_REPORT_v15.md"
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        self.logger.info(f"Relatório consolidado salvo em: {report_file}")


def main():
    """Função principal."""
    parser = argparse.ArgumentParser(
        description='COBOL AI Engine v15.0 - Universal Functional Documentation'
    )
    parser.add_argument('fontes_file', help='Arquivo com lista de programas COBOL')
    parser.add_argument('books_file', help='Arquivo com copybooks')
    parser.add_argument('--output', '-o', default='functional_analysis_results_v15',
                       help='Diretório de saída (default: functional_analysis_results_v15)')
    
    args = parser.parse_args()
    
    # Valida arquivos de entrada
    if not os.path.exists(args.fontes_file):
        print(f"❌ Arquivo de fontes não encontrado: {args.fontes_file}")
        return 1
    
    if not os.path.exists(args.books_file):
        print(f"❌ Arquivo de books não encontrado: {args.books_file}")
        return 1
    
    try:
        # Executa análise
        analyzer = UniversalFunctionalAnalyzer()
        results = analyzer.analyze_programs(args.fontes_file, args.books_file, args.output)
        
        print(f"\n🎯 Análise concluída com sucesso!")
        print(f"📊 Resultados salvos em: {args.output}")
        print(f"📈 Score médio de reimplementação: {results['average_reimplementation_score']:.1f}%")
        
        return 0
        
    except Exception as e:
        print(f"❌ Erro na análise: {str(e)}")
        return 1


if __name__ == "__main__":
    exit(main())
