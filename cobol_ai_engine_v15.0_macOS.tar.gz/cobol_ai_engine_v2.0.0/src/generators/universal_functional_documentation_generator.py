"""
COBOL AI Engine v15.0 - Universal Functional Documentation Generator
Gerador universal de documentação funcional que funciona com qualquer programa COBOL.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime


class UniversalFunctionalDocumentationGenerator:
    """
    Gerador universal de documentação funcional COBOL.
    Cria documentação detalhada que permite reimplementação para qualquer programa.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def generate(self, 
                 structure_analysis: Dict[str, Any],
                 business_logic: Dict[str, Any],
                 program_name: str = "UNKNOWN") -> str:
        """
        Gera documentação funcional completa para qualquer programa COBOL.
        
        Args:
            structure_analysis: Análise de estruturas do programa
            business_logic: Lógica de negócio extraída
            program_name: Nome do programa
            
        Returns:
            String com documentação funcional completa
        """
        self.logger.info(f"Gerando documentação funcional para {program_name}")
        
        try:
            doc_sections = []
            
            # Cabeçalho
            doc_sections.append(self._generate_header(program_name, structure_analysis, business_logic))
            
            # Resumo Executivo
            doc_sections.append(self._generate_executive_summary(structure_analysis, business_logic))
            
            # Especificações Técnicas
            doc_sections.append(self._generate_technical_specifications(structure_analysis))
            
            # Estruturas de Dados
            doc_sections.append(self._generate_data_structures(structure_analysis))
            
            # Regras de Negócio
            doc_sections.append(self._generate_business_rules(business_logic))
            
            # Fluxo de Processamento
            doc_sections.append(self._generate_processing_flow(business_logic))
            
            # Validações e Controles
            doc_sections.append(self._generate_validations_controls(business_logic))
            
            # Código de Reimplementação
            doc_sections.append(self._generate_implementation_code(structure_analysis, business_logic, program_name))
            
            # Análise de Complexidade
            doc_sections.append(self._generate_complexity_analysis(business_logic))
            
            # Guia de Reimplementação
            doc_sections.append(self._generate_reimplementation_guide(structure_analysis, business_logic))
            
            # Métricas de Qualidade
            doc_sections.append(self._generate_quality_metrics(structure_analysis, business_logic))
            
            return "\n\n".join(doc_sections)
            
        except Exception as e:
            self.logger.error(f"Erro na geração de documentação: {str(e)}")
            return f"# Erro na Documentação\n\nErro: {str(e)}"
    
    def _generate_header(self, program_name: str, structure_analysis: Dict[str, Any], business_logic: Dict[str, Any]) -> str:
        """Gera cabeçalho da documentação."""
        stats = structure_analysis.get('statistics', {})
        bl_stats = business_logic.get('statistics', {})
        
        return f"""# 📋 Documentação Funcional - {program_name}

**Versão:** 15.0 - Universal Functional Documentation  
**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Programa:** {program_name}  
**Tipo:** Programa COBOL Universal  

## 📊 Estatísticas Gerais
- **Arquivos:** {stats.get('total_files', 0)}
- **Campos:** {stats.get('total_fields', 0)}
- **Copybooks:** {stats.get('total_copybooks', 0)}
- **Regras de Negócio:** {bl_stats.get('total_business_rules', 0)}
- **Pontos de Decisão:** {bl_stats.get('total_decision_points', 0)}
- **Complexidade:** {bl_stats.get('complexity_score', 0)}

---"""
    
    def _generate_executive_summary(self, structure_analysis: Dict[str, Any], business_logic: Dict[str, Any]) -> str:
        """Gera resumo executivo."""
        files = structure_analysis.get('files', [])
        patterns = business_logic.get('patterns', [])
        
        # Identifica propósito baseado nos padrões
        purpose = self._identify_program_purpose(files, patterns, business_logic)
        
        input_files = [f for f in files if f.get('type') == 'input']
        output_files = [f for f in files if f.get('type') == 'output']
        
        return f"""## 🎯 RESUMO EXECUTIVO

### Propósito do Programa
{purpose}

### Funcionalidade Principal
- **Entrada:** {len(input_files)} arquivo(s) de entrada
- **Processamento:** {business_logic.get('statistics', {}).get('total_business_rules', 0)} regras de negócio
- **Saída:** {len(output_files)} arquivo(s) de saída

### Padrões Identificados
{self._format_patterns(patterns)}

### Impacto no Negócio
{self._assess_business_impact(business_logic, files)}"""
    
    def _generate_technical_specifications(self, structure_analysis: Dict[str, Any]) -> str:
        """Gera especificações técnicas detalhadas."""
        files = structure_analysis.get('files', [])
        copybooks = structure_analysis.get('copybooks', [])
        variables = structure_analysis.get('variables', [])
        
        spec_sections = []
        
        # Arquivos
        if files:
            spec_sections.append("### 📁 Arquivos")
            for file_obj in files:
                spec_sections.append(f"""
**{file_obj.get('name', 'UNKNOWN')}**
- **Tipo:** {file_obj.get('type', 'unknown').title()}
- **Organização:** {file_obj.get('organization', 'sequential').title()}
- **Campos:** {len(file_obj.get('fields', []))}
- **Descrição:** {file_obj.get('description', 'Arquivo do sistema')}""")
        
        # Copybooks
        if copybooks:
            spec_sections.append("\n### 📚 Copybooks Utilizados")
            for copybook in copybooks:
                spec_sections.append(f"- **{copybook.get('name')}** (linha {copybook.get('line')})")
        
        # Constantes e Variáveis
        if variables:
            spec_sections.append("\n### 🔢 Constantes e Variáveis")
            for var in variables[:10]:  # Limita para não ficar muito longo
                spec_sections.append(f"- **{var.get('name')}:** {var.get('description', 'Variável do sistema')}")
        
        return f"""## 🔧 ESPECIFICAÇÕES TÉCNICAS

{chr(10).join(spec_sections)}"""
    
    def _generate_data_structures(self, structure_analysis: Dict[str, Any]) -> str:
        """Gera documentação das estruturas de dados."""
        files = structure_analysis.get('files', [])
        ws_fields = structure_analysis.get('working_storage_fields', [])
        data_structures = structure_analysis.get('data_structures', [])
        
        sections = []
        
        # Estruturas de arquivos
        if files:
            sections.append("### 📄 Estruturas de Arquivos")
            for file_obj in files:
                if file_obj.get('fields'):
                    sections.append(f"\n**{file_obj.get('name')}:**")
                    sections.append("```")
                    for field in file_obj.get('fields', [])[:10]:  # Limita campos
                        pic = field.get('pic_clause', '')
                        size = field.get('size', 0)
                        sections.append(f"{field.get('level', '01'):02d} {field.get('name', 'FIELD')} PIC {pic} ({size} bytes)")
                    sections.append("```")
        
        # Working Storage principais
        if ws_fields:
            sections.append("\n### 💾 Working Storage (Principais)")
            sections.append("```")
            for field in ws_fields[:15]:  # Top 15 campos
                pic = field.get('pic_clause', '')
                desc = field.get('description', '')
                sections.append(f"{field.get('level', '01'):02d} {field.get('name', 'FIELD')} PIC {pic} - {desc}")
            sections.append("```")
        
        # Estruturas complexas
        if data_structures:
            sections.append("\n### 🏗️ Estruturas de Dados Complexas")
            for struct in data_structures[:5]:  # Top 5 estruturas
                sections.append(f"\n**{struct.get('name')}:**")
                sections.append(f"- **Tipo:** {struct.get('type', 'group').title()}")
                sections.append(f"- **Campos:** {len(struct.get('fields', []))}")
                sections.append(f"- **Descrição:** {struct.get('description', 'Estrutura de dados')}")
        
        return f"""## 📊 ESTRUTURAS DE DADOS

{chr(10).join(sections)}"""
    
    def _generate_business_rules(self, business_logic: Dict[str, Any]) -> str:
        """Gera documentação das regras de negócio."""
        rules = business_logic.get('business_rules', [])
        
        if not rules:
            return """## 📋 REGRAS DE NEGÓCIO

*Nenhuma regra de negócio específica identificada automaticamente.*
*Recomenda-se análise manual para identificar regras implícitas.*"""
        
        sections = []
        sections.append("### 🎯 Regras Identificadas")
        
        # Agrupa por categoria
        rules_by_category = {}
        for rule in rules:
            category = rule.get('category', 'general')
            if category not in rules_by_category:
                rules_by_category[category] = []
            rules_by_category[category].append(rule)
        
        for category, category_rules in rules_by_category.items():
            sections.append(f"\n#### {category.title()}")
            for rule in category_rules[:10]:  # Limita por categoria
                confidence = rule.get('confidence', 0.0)
                confidence_icon = "🟢" if confidence > 0.7 else "🟡" if confidence > 0.4 else "🔴"
                
                sections.append(f"""
**{rule.get('id', 'RN000')}** {confidence_icon}
- **Descrição:** {rule.get('description', 'Regra não identificada')}
- **Condição:** `{rule.get('condition', 'N/A')}`
- **Ação:** `{rule.get('action', 'N/A')}`
- **Linha:** {rule.get('line_number', 0)}
- **Confiança:** {confidence:.1%}""")
        
        return f"""## 📋 REGRAS DE NEGÓCIO

{chr(10).join(sections)}"""
    
    def _generate_processing_flow(self, business_logic: Dict[str, Any]) -> str:
        """Gera documentação do fluxo de processamento."""
        decision_points = business_logic.get('decision_points', [])
        data_flows = business_logic.get('data_flows', [])
        
        sections = []
        
        # Pontos de decisão
        if decision_points:
            sections.append("### 🔀 Pontos de Decisão")
            for dp in decision_points[:10]:  # Top 10
                complexity_icon = "🔴" if dp.get('complexity', 1) > 5 else "🟡" if dp.get('complexity', 1) > 2 else "🟢"
                
                sections.append(f"""
**{dp.get('name', 'DECISION')}** {complexity_icon}
- **Tipo:** {dp.get('type', 'UNKNOWN')}
- **Complexidade:** {dp.get('complexity', 1)}
- **Condições:** {len(dp.get('conditions', []))}
- **Ações:** {len(dp.get('actions', []))}
- **Linha:** {dp.get('line_number', 0)}""")
        
        # Fluxo de dados
        if data_flows:
            sections.append("\n### 📊 Fluxo de Dados (Principais)")
            
            # Agrupa por operação
            flows_by_operation = {}
            for flow in data_flows:
                op = flow.get('operation', 'UNKNOWN')
                if op not in flows_by_operation:
                    flows_by_operation[op] = []
                flows_by_operation[op].append(flow)
            
            for operation, flows in flows_by_operation.items():
                sections.append(f"\n#### {operation}")
                for flow in flows[:5]:  # Top 5 por operação
                    sections.append(f"- `{flow.get('source', 'SOURCE')}` → `{flow.get('target', 'TARGET')}` (linha {flow.get('line_number', 0)})")
        
        return f"""## 🔄 FLUXO DE PROCESSAMENTO

{chr(10).join(sections)}"""
    
    def _generate_validations_controls(self, business_logic: Dict[str, Any]) -> str:
        """Gera documentação de validações e controles."""
        validations = business_logic.get('validations', [])
        controls = business_logic.get('controls', [])
        
        sections = []
        
        if validations:
            sections.append("### ✅ Validações")
            for validation in validations[:10]:
                sections.append(f"- **{validation.get('keyword', 'VALIDATION')}:** {validation.get('description', 'Validação identificada')} (linha {validation.get('line', 0)})")
        
        if controls:
            sections.append("\n### 🎛️ Controles")
            for control in controls[:10]:
                sections.append(f"- **{control.get('keyword', 'CONTROL')}:** {control.get('description', 'Controle identificado')} (linha {control.get('line', 0)})")
        
        if not validations and not controls:
            sections.append("*Nenhuma validação ou controle específico identificado automaticamente.*")
            sections.append("*Recomenda-se análise manual para identificar validações implícitas.*")
        
        return f"""## ✅ VALIDAÇÕES E CONTROLES

{chr(10).join(sections)}"""
    
    def _generate_implementation_code(self, structure_analysis: Dict[str, Any], business_logic: Dict[str, Any], program_name: str) -> str:
        """Gera código de reimplementação funcional."""
        files = structure_analysis.get('files', [])
        rules = business_logic.get('business_rules', [])
        data_flows = business_logic.get('data_flows', [])
        
        input_files = [f for f in files if f.get('type') == 'input']
        output_files = [f for f in files if f.get('type') == 'output']
        
        # Gera código Java funcional
        java_code = self._generate_java_implementation(program_name, input_files, output_files, rules, data_flows)
        
        # Gera código Python alternativo
        python_code = self._generate_python_implementation(program_name, input_files, output_files, rules, data_flows)
        
        return f"""## 💻 CÓDIGO DE REIMPLEMENTAÇÃO

### Java Implementation

```java
{java_code}
```

### Python Alternative

```python
{python_code}
```

### 📝 Notas de Implementação
- **Linguagem recomendada:** Java (melhor para sistemas corporativos)
- **Alternativa:** Python (mais rápido para prototipagem)
- **Dependências:** Bibliotecas padrão da linguagem
- **Configuração:** Ajustar caminhos de arquivos conforme ambiente"""
    
    def _generate_java_implementation(self, program_name: str, input_files: List[Dict], output_files: List[Dict], rules: List[Dict], data_flows: List[Dict]) -> str:
        """Gera implementação Java funcional."""
        class_name = program_name.replace('-', '').replace('_', '') + "Processor"
        
        # Imports
        imports = [
            "import java.io.*;",
            "import java.nio.file.*;",
            "import java.util.*;",
            "import java.util.logging.*;"
        ]
        
        # Constantes baseadas em regras
        constants = []
        for rule in rules[:5]:
            if 'LIMIT' in rule.get('condition', '').upper() or 'MAX' in rule.get('condition', '').upper():
                constants.append(f"    private static final int MAX_RECORDS = 50000; // Baseado em {rule.get('id', 'RN000')}")
        
        if not constants:
            constants.append("    private static final int MAX_RECORDS = 50000; // Valor padrão")
        
        # Métodos de processamento
        processing_methods = []
        
        # Método principal de processamento
        main_processing = f"""    public void processar() throws IOException {{
        Logger logger = Logger.getLogger({class_name}.class.getName());
        logger.info("Iniciando processamento do {program_name}");
        
        try {{"""
        
        # Adiciona leitura de arquivos de entrada
        for i, input_file in enumerate(input_files[:3]):  # Máximo 3 arquivos
            file_name = input_file.get('name', f'INPUT_{i+1}')
            main_processing += f"""
            // Processamento de {file_name}
            processarArquivo{i+1}("{file_name}.txt");"""
        
        main_processing += """
        } catch (Exception e) {
            logger.severe("Erro no processamento: " + e.getMessage());
            throw new RuntimeException("Falha no processamento", e);
        }
    }"""
        
        processing_methods.append(main_processing)
        
        # Métodos específicos por arquivo
        for i, input_file in enumerate(input_files[:3]):
            file_name = input_file.get('name', f'INPUT_{i+1}')
            method = f"""    private void processarArquivo{i+1}(String nomeArquivo) throws IOException {{
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(nomeArquivo))) {{
            String linha;
            int contador = 0;
            
            while ((linha = reader.readLine()) != null && contador < MAX_RECORDS) {{
                // Processamento específico baseado nas regras identificadas
                processarRegistro(linha, contador);
                contador++;
            }}
            
            System.out.println("Processados " + contador + " registros de " + nomeArquivo);
        }}
    }}"""
            processing_methods.append(method)
        
        # Método de processamento de registro
        record_processing = """    private void processarRegistro(String registro, int contador) {
        // Implementar validações baseadas nas regras de negócio identificadas
        if (registro == null || registro.trim().isEmpty()) {
            return; // Registro inválido
        }
        
        // Exemplo de processamento baseado em regras identificadas"""
        
        for rule in rules[:3]:
            if 'TIPO' in rule.get('condition', '').upper():
                record_processing += f"""
        // {rule.get('id', 'RN000')}: {rule.get('description', 'Regra não identificada')}
        if (registro.length() > 2) {{
            String tipo = registro.substring(0, 2);
            processarPorTipo(tipo, registro);
        }}"""
        
        record_processing += """
    }"""
        
        processing_methods.append(record_processing)
        
        # Método de processamento por tipo
        type_processing = """    private void processarPorTipo(String tipo, String registro) {
        switch (tipo) {"""
        
        # Adiciona cases baseados em regras
        for rule in rules[:5]:
            condition = rule.get('condition', '')
            if '=' in condition and any(c.isdigit() for c in condition):
                # Extrai valor da condição
                parts = condition.split('=')
                if len(parts) > 1:
                    value = parts[1].strip().replace("'", "").replace('"', '')
                    if value.isdigit() or (len(value) <= 3 and value.isalnum()):
                        type_processing += f"""
            case "{value}":
                // {rule.get('description', 'Processamento específico')}
                gravarRegistro(registro, "SAIDA_{value}.txt");
                break;"""
        
        type_processing += """
            default:
                // Tipo não identificado - gravar em arquivo de erro
                gravarRegistro(registro, "ERRO.txt");
                break;
        }
    }"""
        
        processing_methods.append(type_processing)
        
        # Método de gravação
        write_method = """    private void gravarRegistro(String registro, String nomeArquivo) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(nomeArquivo, true))) {
            writer.println(registro);
        } catch (IOException e) {
            System.err.println("Erro ao gravar no arquivo " + nomeArquivo + ": " + e.getMessage());
        }
    }"""
        
        processing_methods.append(write_method)
        
        # Método main
        main_method = f"""    public static void main(String[] args) {{
        {class_name} processor = new {class_name}();
        try {{
            processor.processar();
            System.out.println("Processamento concluído com sucesso!");
        }} catch (Exception e) {{
            System.err.println("Erro no processamento: " + e.getMessage());
            e.printStackTrace();
        }}
    }}"""
        
        processing_methods.append(main_method)
        
        # Monta classe completa
        full_class = f"""{chr(10).join(imports)}

public class {class_name} {{
{chr(10).join(constants)}

{chr(10).join(processing_methods)}
}}"""
        
        return full_class
    
    def _generate_python_implementation(self, program_name: str, input_files: List[Dict], output_files: List[Dict], rules: List[Dict], data_flows: List[Dict]) -> str:
        """Gera implementação Python funcional."""
        class_name = program_name.replace('-', '_').replace(' ', '_') + "_processor"
        
        python_code = f"""#!/usr/bin/env python3
\"\"\"
Reimplementação do programa COBOL {program_name}
Gerado automaticamente pelo COBOL AI Engine v15.0
\"\"\"

import logging
from pathlib import Path
from typing import List, Dict, Any


class {class_name.title()}:
    \"\"\"Processador para {program_name}\"\"\"
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.max_records = 50000  # Baseado em análise das regras
        self.contador_total = 0
        
    def processar(self) -> None:
        \"\"\"Método principal de processamento\"\"\"
        self.logger.info(f"Iniciando processamento do {program_name}")
        
        try:"""
        
        # Adiciona processamento de arquivos de entrada
        for i, input_file in enumerate(input_files[:3]):
            file_name = input_file.get('name', f'input_{i+1}')
            python_code += f"""
            self._processar_arquivo_{i+1}("{file_name}.txt")"""
        
        python_code += f"""
            
            self.logger.info(f"Processamento concluído. Total de registros: {{self.contador_total}}")
            
        except Exception as e:
            self.logger.error(f"Erro no processamento: {{e}}")
            raise
    """
        
        # Métodos de processamento por arquivo
        for i, input_file in enumerate(input_files[:3]):
            file_name = input_file.get('name', f'input_{i+1}')
            python_code += f"""
    def _processar_arquivo_{i+1}(self, nome_arquivo: str) -> None:
        \"\"\"Processa arquivo {file_name}\"\"\"
        try:
            with open(nome_arquivo, 'r', encoding='utf-8') as arquivo:
                contador = 0
                for linha in arquivo:
                    if contador >= self.max_records:
                        break
                    
                    self._processar_registro(linha.strip(), contador)
                    contador += 1
                    self.contador_total += 1
                
                self.logger.info(f"Processados {{contador}} registros de {{nome_arquivo}}")
                
        except FileNotFoundError:
            self.logger.warning(f"Arquivo {{nome_arquivo}} não encontrado")
        except Exception as e:
            self.logger.error(f"Erro ao processar {{nome_arquivo}}: {{e}}")
            raise"""
        
        # Método de processamento de registro
        python_code += """
    def _processar_registro(self, registro: str, contador: int) -> None:
        \"\"\"Processa um registro individual\"\"\"
        if not registro:
            return
        
        # Validações básicas
        if len(registro) < 2:
            self._gravar_erro(registro, "Registro muito curto")
            return
        """
        
        # Adiciona lógica baseada em regras
        for rule in rules[:3]:
            if 'TIPO' in rule.get('condition', '').upper():
                python_code += f"""
        # {rule.get('id', 'RN000')}: {rule.get('description', 'Regra não identificada')}
        tipo = registro[:2]
        self._processar_por_tipo(tipo, registro)"""
        
        python_code += """
    def _processar_por_tipo(self, tipo: str, registro: str) -> None:
        \"\"\"Processa registro baseado no tipo\"\"\"
        """
        
        # Adiciona cases baseados em regras
        type_mapping = {}
        for rule in rules[:5]:
            condition = rule.get('condition', '')
            if '=' in condition:
                parts = condition.split('=')
                if len(parts) > 1:
                    value = parts[1].strip().replace("'", "").replace('"', '')
                    if value.isdigit() or (len(value) <= 3 and value.isalnum()):
                        type_mapping[value] = f"saida_{value}.txt"
        
        if type_mapping:
            python_code += f"""
        type_mapping = {type_mapping}
        
        arquivo_saida = type_mapping.get(tipo, "erro.txt")
        self._gravar_registro(registro, arquivo_saida)"""
        else:
            python_code += """
        # Mapeamento padrão baseado em análise
        if tipo in ['01', '02']:
            self._gravar_registro(registro, "saida_principal.txt")
        elif tipo == '03':
            self._gravar_registro(registro, "saida_especial.txt")
        else:
            self._gravar_erro(registro, f"Tipo não reconhecido: {tipo}")"""
        
        # Métodos auxiliares
        python_code += """
    def _gravar_registro(self, registro: str, nome_arquivo: str) -> None:
        \"\"\"Grava registro em arquivo de saída\"\"\"
        try:
            with open(nome_arquivo, 'a', encoding='utf-8') as arquivo:
                arquivo.write(registro + '\\n')
        except Exception as e:
            self.logger.error(f"Erro ao gravar em {nome_arquivo}: {e}")
    
    def _gravar_erro(self, registro: str, motivo: str) -> None:
        \"\"\"Grava registro de erro\"\"\"
        self.logger.warning(f"Erro no registro: {motivo}")
        self._gravar_registro(f"{registro} | ERRO: {motivo}", "erros.txt")


def main():
    \"\"\"Função principal\"\"\"
    logging.basicConfig(level=logging.INFO, 
                       format='%(asctime)s - %(levelname)s - %(message)s')
    
    processor = """ + class_name.title() + """()
    try:
        processor.processar()
        print("Processamento concluído com sucesso!")
    except Exception as e:
        print(f"Erro no processamento: {e}")
        return 1
    
    return 0


if __name__ == "__main__":
    exit(main())"""
        
        return python_code
    
    def _generate_complexity_analysis(self, business_logic: Dict[str, Any]) -> str:
        """Gera análise de complexidade."""
        complexity_analysis = business_logic.get('complexity_analysis', {})
        
        total_complexity = complexity_analysis.get('total_complexity', 0)
        avg_complexity = complexity_analysis.get('average_complexity', 0)
        high_complexity = complexity_analysis.get('high_complexity_points', [])
        
        complexity_level = "BAIXA" if total_complexity < 10 else "MÉDIA" if total_complexity < 25 else "ALTA"
        complexity_icon = "🟢" if complexity_level == "BAIXA" else "🟡" if complexity_level == "MÉDIA" else "🔴"
        
        return f"""## 📈 ANÁLISE DE COMPLEXIDADE

### Métricas de Complexidade {complexity_icon}
- **Complexidade Total:** {total_complexity}
- **Complexidade Média:** {avg_complexity:.1f}
- **Nível:** {complexity_level}
- **Pontos Críticos:** {len(high_complexity)}

### Pontos de Alta Complexidade
{chr(10).join([f"- {point}" for point in high_complexity[:5]]) if high_complexity else "*Nenhum ponto de alta complexidade identificado.*"}

### Recomendações
- **Baixa Complexidade:** Reimplementação direta possível
- **Média Complexidade:** Requer análise adicional de regras específicas
- **Alta Complexidade:** Recomenda-se análise manual detalhada"""
    
    def _generate_reimplementation_guide(self, structure_analysis: Dict[str, Any], business_logic: Dict[str, Any]) -> str:
        """Gera guia de reimplementação."""
        files = structure_analysis.get('files', [])
        rules = business_logic.get('business_rules', [])
        complexity = business_logic.get('complexity_analysis', {}).get('total_complexity', 0)
        
        # Calcula score de reimplementação
        reimpl_score = self._calculate_reimplementation_score(structure_analysis, business_logic)
        
        score_icon = "🟢" if reimpl_score > 70 else "🟡" if reimpl_score > 40 else "🔴"
        score_level = "ALTA" if reimpl_score > 70 else "MÉDIA" if reimpl_score > 40 else "BAIXA"
        
        return f"""## 🚀 GUIA DE REIMPLEMENTAÇÃO

### Score de Reimplementação: {reimpl_score}% {score_icon}
**Capacidade:** {score_level}

### Passos Recomendados

#### 1. Preparação
- [ ] Analisar arquivos de entrada disponíveis
- [ ] Configurar ambiente de desenvolvimento
- [ ] Preparar arquivos de teste

#### 2. Implementação Base
- [ ] Implementar leitura de arquivos ({len([f for f in files if f.get('type') == 'input'])} arquivos)
- [ ] Implementar estruturas de dados básicas
- [ ] Implementar gravação de saída ({len([f for f in files if f.get('type') == 'output'])} arquivos)

#### 3. Regras de Negócio
- [ ] Implementar {len(rules)} regras identificadas
- [ ] Validar lógica de processamento
- [ ] Implementar tratamento de erros

#### 4. Testes e Validação
- [ ] Testar com dados reais
- [ ] Comparar resultados com sistema original
- [ ] Ajustar conforme necessário

### Estimativa de Esforço
- **Baixa Complexidade:** 1-2 semanas
- **Média Complexidade:** 3-4 semanas  
- **Alta Complexidade:** 5-8 semanas

### Riscos Identificados
{self._identify_risks(structure_analysis, business_logic)}"""
    
    def _generate_quality_metrics(self, structure_analysis: Dict[str, Any], business_logic: Dict[str, Any]) -> str:
        """Gera métricas de qualidade da documentação."""
        # Calcula métricas
        completeness = self._calculate_completeness(structure_analysis, business_logic)
        accuracy = self._calculate_accuracy(business_logic)
        reimpl_readiness = self._calculate_reimplementation_score(structure_analysis, business_logic)
        
        return f"""## 📊 MÉTRICAS DE QUALIDADE

### Qualidade da Documentação
- **Completude:** {completeness:.1f}% {"🟢" if completeness > 70 else "🟡" if completeness > 40 else "🔴"}
- **Precisão:** {accuracy:.1f}% {"🟢" if accuracy > 70 else "🟡" if accuracy > 40 else "🔴"}
- **Prontidão para Reimplementação:** {reimpl_readiness:.1f}% {"🟢" if reimpl_readiness > 70 else "🟡" if reimpl_readiness > 40 else "🔴"}

### Detalhamento
- **Arquivos Identificados:** {len(structure_analysis.get('files', []))}
- **Regras Extraídas:** {len(business_logic.get('business_rules', []))}
- **Pontos de Decisão:** {len(business_logic.get('decision_points', []))}
- **Fluxos de Dados:** {len(business_logic.get('data_flows', []))}

### Recomendações de Melhoria
{self._generate_improvement_recommendations(completeness, accuracy, reimpl_readiness)}

---

**Documentação gerada por:** COBOL AI Engine v15.0 - Universal Functional Documentation  
**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Qualidade:** {"ALTA" if min(completeness, accuracy, reimpl_readiness) > 70 else "MÉDIA" if min(completeness, accuracy, reimpl_readiness) > 40 else "BAIXA"}"""
    
    def _identify_program_purpose(self, files: List[Dict], patterns: List[Dict], business_logic: Dict[str, Any]) -> str:
        """Identifica propósito do programa baseado em análise."""
        input_count = len([f for f in files if f.get('type') == 'input'])
        output_count = len([f for f in files if f.get('type') == 'output'])
        rules_count = len(business_logic.get('business_rules', []))
        
        # Análise de padrões
        has_validation = any(p.get('type') == 'validation_pattern' for p in patterns)
        has_sequential = any(p.get('type') == 'sequential_processing' for p in patterns)
        has_control = any(p.get('type') == 'control_pattern' for p in patterns)
        
        # Determina propósito
        if input_count > output_count and has_sequential:
            return f"**Consolidador de dados** - Processa {input_count} fontes de entrada e consolida em {output_count} saída(s)"
        elif input_count < output_count:
            return f"**Distribuidor/Particionador** - Divide dados de {input_count} entrada(s) em {output_count} saída(s)"
        elif has_validation and rules_count > 5:
            return f"**Validador de dados** - Aplica {rules_count} regras de validação aos dados processados"
        elif has_control:
            return f"**Processador com controles** - Processa dados com controles específicos de qualidade"
        else:
            return f"**Processador de dados** - Transforma dados de {input_count} entrada(s) para {output_count} saída(s)"
    
    def _format_patterns(self, patterns: List[Dict]) -> str:
        """Formata padrões identificados."""
        if not patterns:
            return "*Nenhum padrão específico identificado automaticamente.*"
        
        formatted = []
        for pattern in patterns[:5]:
            confidence = pattern.get('confidence', 0.0)
            confidence_icon = "🟢" if confidence > 0.7 else "🟡" if confidence > 0.4 else "🔴"
            formatted.append(f"- **{pattern.get('name', 'Padrão')}** {confidence_icon}: {pattern.get('description', 'Padrão identificado')}")
        
        return chr(10).join(formatted)
    
    def _assess_business_impact(self, business_logic: Dict[str, Any], files: List[Dict]) -> str:
        """Avalia impacto no negócio."""
        rules_count = len(business_logic.get('business_rules', []))
        files_count = len(files)
        complexity = business_logic.get('complexity_analysis', {}).get('total_complexity', 0)
        
        if complexity > 20 or rules_count > 10:
            return "**CRÍTICO** - Programa complexo com múltiplas regras de negócio"
        elif files_count > 5 or rules_count > 5:
            return "**ALTO** - Programa importante com processamento significativo"
        else:
            return "**MÉDIO** - Programa de suporte com processamento padrão"
    
    def _calculate_reimplementation_score(self, structure_analysis: Dict[str, Any], business_logic: Dict[str, Any]) -> float:
        """Calcula score de capacidade de reimplementação."""
        score = 0.0
        
        # Estruturas identificadas (30%)
        files = structure_analysis.get('files', [])
        if files:
            score += min(30.0, len(files) * 5)
        
        # Regras de negócio (40%)
        rules = business_logic.get('business_rules', [])
        if rules:
            avg_confidence = sum(rule.get('confidence', 0.0) for rule in rules) / len(rules)
            score += avg_confidence * 40
        
        # Fluxos de dados (20%)
        data_flows = business_logic.get('data_flows', [])
        if data_flows:
            score += min(20.0, len(data_flows) * 2)
        
        # Padrões identificados (10%)
        patterns = business_logic.get('patterns', [])
        if patterns:
            avg_pattern_confidence = sum(p.get('confidence', 0.0) for p in patterns) / len(patterns)
            score += avg_pattern_confidence * 10
        
        return min(100.0, score)
    
    def _calculate_completeness(self, structure_analysis: Dict[str, Any], business_logic: Dict[str, Any]) -> float:
        """Calcula completude da análise."""
        completeness = 0.0
        
        # Arquivos identificados
        if structure_analysis.get('files'):
            completeness += 25.0
        
        # Campos identificados
        if structure_analysis.get('working_storage_fields'):
            completeness += 20.0
        
        # Regras de negócio
        if business_logic.get('business_rules'):
            completeness += 30.0
        
        # Fluxos de dados
        if business_logic.get('data_flows'):
            completeness += 15.0
        
        # Padrões
        if business_logic.get('patterns'):
            completeness += 10.0
        
        return completeness
    
    def _calculate_accuracy(self, business_logic: Dict[str, Any]) -> float:
        """Calcula precisão da análise."""
        rules = business_logic.get('business_rules', [])
        if not rules:
            return 50.0  # Score neutro se não há regras
        
        # Média da confiança das regras
        avg_confidence = sum(rule.get('confidence', 0.0) for rule in rules) / len(rules)
        return avg_confidence * 100
    
    def _identify_risks(self, structure_analysis: Dict[str, Any], business_logic: Dict[str, Any]) -> str:
        """Identifica riscos da reimplementação."""
        risks = []
        
        # Complexidade alta
        complexity = business_logic.get('complexity_analysis', {}).get('total_complexity', 0)
        if complexity > 25:
            risks.append("- **Alta Complexidade:** Programa com lógica complexa pode ter regras não identificadas")
        
        # Poucas regras identificadas
        rules_count = len(business_logic.get('business_rules', []))
        if rules_count < 3:
            risks.append("- **Poucas Regras:** Possível existência de regras implícitas não detectadas")
        
        # Arquivos não identificados
        files_count = len(structure_analysis.get('files', []))
        if files_count < 2:
            risks.append("- **Poucos Arquivos:** Possível existência de arquivos não mapeados")
        
        # Baixa confiança nas regras
        rules = business_logic.get('business_rules', [])
        if rules:
            avg_confidence = sum(rule.get('confidence', 0.0) for rule in rules) / len(rules)
            if avg_confidence < 0.6:
                risks.append("- **Baixa Confiança:** Regras identificadas podem estar incompletas")
        
        if not risks:
            risks.append("- **Baixo Risco:** Programa bem estruturado para reimplementação")
        
        return chr(10).join(risks)
    
    def _generate_improvement_recommendations(self, completeness: float, accuracy: float, reimpl_readiness: float) -> str:
        """Gera recomendações de melhoria."""
        recommendations = []
        
        if completeness < 70:
            recommendations.append("- **Completude:** Analisar manualmente seções não identificadas")
        
        if accuracy < 70:
            recommendations.append("- **Precisão:** Validar regras identificadas com especialistas")
        
        if reimpl_readiness < 70:
            recommendations.append("- **Reimplementação:** Complementar com análise manual detalhada")
        
        if not recommendations:
            recommendations.append("- **Excelente qualidade:** Documentação adequada para reimplementação")
        
        return chr(10).join(recommendations)
