"""
COBOL AI Engine v14.0 - Providers Module Consolidado
Módulo de provedores consolidado sem redundâncias.
"""

from .base_provider import BaseProvider, AIRequest, AIResponse
from .openai_provider import OpenAIProvider
from .copilot_provider import CopilotProvider
from .luzia_provider import LuziaProvider
from .enhanced_mock_provider import EnhancedMockProvider
from .basic_provider import BasicProvider
from .bedrock_provider import BedrockProvider
from .databricks_provider import DatabricksProvider
from .provider_manager import ProviderManager
from .multi_provider_analyzer import MultiProviderAnalyzer

__all__ = [
    'BaseProvider',
    'AIRequest', 
    'AIResponse',
    'OpenAIProvider',
    'CopilotProvider',
    'LuziaProvider',
    'EnhancedMockProvider',
    'BasicProvider',
    'BedrockProvider',
    'DatabricksProvider',
    'ProviderManager',
    'MultiProviderAnalyzer'
]

# Providers disponíveis (sem redundâncias)
AVAILABLE_PROVIDERS = {
    'openai': OpenAIProvider,
    'copilot': CopilotProvider,
    'luzia': LuziaProvider,
    'enhanced_mock': EnhancedMockProvider,
    'basic': BasicProvider,
    'bedrock': BedrockProvider,
    'databricks': DatabricksProvider
}

# Providers com fallback automático
FALLBACK_CHAIN = [
    'openai',        # Primary: OpenAI (se configurado)
    'copilot',       # Fallback 1: GitHub Copilot (se configurado)
    'luzia',         # Fallback 2: LuzIA (se configurado)
    'enhanced_mock', # Fallback 3: Mock avançado (sempre disponível)
    'basic'          # Fallback 4: Básico (nunca falha)
]

def get_provider(provider_name: str, config: dict):
    """
    Obtém uma instância do provedor especificado.
    
    Args:
        provider_name: Nome do provedor
        config: Configuração do provedor
        
    Returns:
        Instância do provedor
        
    Raises:
        ValueError: Se o provedor não for encontrado
    """
    if provider_name not in AVAILABLE_PROVIDERS:
        raise ValueError(f"Provider '{provider_name}' não encontrado. Disponíveis: {list(AVAILABLE_PROVIDERS.keys())}")
    
    provider_class = AVAILABLE_PROVIDERS[provider_name]
    return provider_class(config)

def list_providers():
    """
    Lista todos os provedores disponíveis.
    
    Returns:
        Lista de nomes dos provedores
    """
    return list(AVAILABLE_PROVIDERS.keys())

def get_fallback_chain():
    """
    Obtém a cadeia de fallback dos provedores.
    
    Returns:
        Lista ordenada de provedores para fallback
    """
    return FALLBACK_CHAIN.copy()
