"""
Modelos de Domínio
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any

@dataclass
class CobolProgram:
    name: str
    content: str
    copybooks: List[str]

@dataclass
class CobolBook:
    name: str
    content: str
    line_count: int
    size: int
    structures: List[str]

@dataclass
class KnowledgeItem:
    name: str
    description: str
    content: str
    category: str
    tags: List[str]
    id: str = ""

@dataclass
class AnalysisResult:
    success: bool
    program_name: str
    model: str
    provider: str
    content: str
    tokens_used: int
    prompts_used: List[Dict[str, str]] = field(default_factory=list)
    error_message: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

