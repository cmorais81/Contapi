#!/usr/bin/env python3
"""
Debug que intercepta exatamente o que está sendo enviado para a API
"""

import json
import requests
from unittest.mock import patch
from src.providers.luzia_provider import LuziaProvider
from src.providers.base_provider import AIRequest

# Variável global para capturar requisições
captured_requests = []

def mock_requests_post(*args, **kwargs):
    """Mock que captura exatamente o que está sendo enviado"""
    
    print("=== REQUISIÇÃO INTERCEPTADA ===")
    print(f"URL: {args[0] if args else kwargs.get('url', 'N/A')}")
    
    # Capturar headers
    headers = kwargs.get('headers', {})
    print("HEADERS:")
    for key, value in headers.items():
        print(f"  {key}: {value}")
    
    # Capturar payload
    if 'json' in kwargs:
        print("MÉTODO: json=payload")
        payload = kwargs['json']
        print("PAYLOAD (via json=):")
        print(json.dumps(payload, indent=2, ensure_ascii=False))
        
    elif 'data' in kwargs:
        print("MÉTODO: data=...")
        data = kwargs['data']
        print(f"TIPO DE DATA: {type(data)}")
        
        if isinstance(data, str):
            try:
                payload = json.loads(data)
                print("PAYLOAD (via data= deserializado):")
                print(json.dumps(payload, indent=2, ensure_ascii=False))
                
                # Verificar estrutura específica
                if 'input' in payload:
                    input_field = payload['input']
                    print(f"\nANÁLISE DO CAMPO 'input':")
                    print(f"- Tipo: {type(input_field)}")
                    
                    if isinstance(input_field, dict) and 'query' in input_field:
                        query_field = input_field['query']
                        print(f"- Campo 'query' tipo: {type(query_field)}")
                        print(f"- Campo 'query' tamanho: {len(query_field) if isinstance(query_field, list) else 'N/A'}")
                        
                        if isinstance(query_field, list):
                            print("- Conteúdo da query:")
                            for i, item in enumerate(query_field):
                                print(f"  [{i}] {type(item)}: {item.get('role', 'N/A') if isinstance(item, dict) else item}")
                    else:
                        print(f"- PROBLEMA: 'input' não tem 'query' ou estrutura incorreta")
                        print(f"- Conteúdo de 'input': {input_field}")
                
            except json.JSONDecodeError as e:
                print(f"ERRO ao deserializar data: {e}")
                print(f"DATA bruto: {data[:200]}...")
        else:
            print(f"DATA não é string: {data}")
    
    # Salvar requisição
    captured_requests.append({
        'url': args[0] if args else kwargs.get('url'),
        'headers': headers,
        'payload': kwargs.get('json') or kwargs.get('data'),
        'method': 'json' if 'json' in kwargs else 'data'
    })
    
    # Simular resposta de erro como na API real
    class MockResponse:
        def __init__(self):
            self.status_code = 400
            
        def json(self):
            return {
                "code": 400,
                "description": "Request validation failed.",
                "level": "error", 
                "message": "Input should be a valid list",
                "input": {"type": "catena.llm.LLMRouter"}
            }
    
    return MockResponse()

def test_real_provider():
    """Testar provider real com interceptação"""
    
    print("=== TESTE COM PROVIDER REAL ===")
    
    # Configurar provider
    provider = LuziaProvider({
        'base_url': 'https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit',
        'client_id': 'test_client',
        'client_secret': 'test_secret'
    })
    
    # Criar request correto
    request = AIRequest(
        prompt="Analise este programa COBOL: IDENTIFICATION DIVISION. PROGRAM-ID. TESTE.",
        program_name="TESTE.cbl",
        program_code="IDENTIFICATION DIVISION. PROGRAM-ID. TESTE."
    )
    
    print(f"REQUEST CRIADO:")
    print(f"- Prompt: {request.prompt[:50]}...")
    print(f"- Program name: {request.program_name}")
    
    # Interceptar requisições
    with patch('requests.post', side_effect=mock_requests_post):
        try:
            # Simular token válido
            provider._token = "fake_token_for_test"
            provider._token_expires_at = 9999999999  # Futuro distante
            
            # Executar análise
            result = provider.analyze(request)
            print(f"RESULTADO: {result}")
            
        except Exception as e:
            print(f"ERRO durante análise: {e}")
    
    print(f"\nTOTAL DE REQUISIÇÕES CAPTURADAS: {len(captured_requests)}")

if __name__ == "__main__":
    test_real_provider()
    
    print("\n=== RESUMO ===")
    print("Este teste intercepta exatamente o que está sendo enviado.")
    print("Compare com o payload do seu teste.py que funciona.")
