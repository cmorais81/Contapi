# COBOL AI Engine v1.0.4 - Instruções para Produção

## Instalação Rápida

### 1. Extrair o Pacote
```bash
tar -xzf cobol_ai_engine_v1.0.4_producao.tar.gz
cd cobol_ai_engine_v2.0.0/
```

### 2. Instalar Dependências
```bash
# Opção 1: Instalação completa (recomendada)
pip install -r requirements.txt

# Opção 2: Instalação mínima (apenas essenciais)
pip install -r requirements-minimal.txt
```

### 3. Configurar Variáveis de Ambiente
```bash
# Configurar credenciais da LuzIA
export LUZIA_CLIENT_ID="seu_client_id_aqui"
export LUZIA_CLIENT_SECRET="seu_client_secret_aqui"

# Opcional: OpenAI como backup
export OPENAI_API_KEY="sua_chave_openai"
```

### 4. Testar Instalação
```bash
# Teste rápido com mock (não precisa de credenciais)
python main.py --fontes examples/fontes.txt --models "mock_enhanced"
```

## Uso em Produção

### Comando Básico
```bash
# Usa modelos configurados automaticamente
python main.py --fontes seus_fontes.txt
```

### Análise Completa
```bash
# Com copybooks e geração HTML para PDF
python main.py --fontes seus_fontes.txt --books seus_books.txt --pdf --output relatorio_producao
```

### Múltiplos Modelos
```bash
# Comparar resultados de diferentes modelos
python main.py --fontes seus_fontes.txt --models '["claude_3_5_sonnet","luzia_standard"]'
```

## Configuração

### Modelos Padrão
Edite `config/config.yaml` para definir os modelos que serão usados automaticamente:

```yaml
ai:
  default_models:
    - "claude_3_5_sonnet"
    - "luzia_standard"
```

### Verificar Configuração
```bash
# Ver modelos configurados
grep -A 3 "default_models" config/config.yaml

# Verificar credenciais
echo $LUZIA_CLIENT_ID
echo $LUZIA_CLIENT_SECRET
```

## Estrutura de Saída

### Modelo Único
```
output/
├── PROGRAMA1.md
├── PROGRAMA2.md
└── PROGRAMA3.md
```

### Múltiplos Modelos
```
output/
├── model_claude_3_5_sonnet/
├── model_luzia_standard/
└── relatorio_comparativo_modelos.md
```

### Com HTML (--pdf)
```
output/
├── PROGRAMA1.md
├── PROGRAMA1.html    # Para conversão PDF
├── index.html        # Índice navegável
└── ...
```

## Conversão para PDF

1. Execute com `--pdf`
2. Abra qualquer `.html` no navegador
3. Pressione `Ctrl+P` (Windows/Linux) ou `Cmd+P` (Mac)
4. Selecione "Salvar como PDF"
5. Configure margens "Mínimas"
6. Salve o arquivo

## Monitoramento

### Logs
```bash
# Ver logs em tempo real
tail -f logs/cobol_ai_engine_*.log

# Ver últimos erros
grep ERROR logs/cobol_ai_engine_*.log
```

### Performance
- Tempo típico: 0.5-2.0s por programa
- Tokens típicos: 2.000-8.000 por análise
- Taxa de sucesso: 99%+

## Solução de Problemas

### Erro de Credenciais
```bash
# Verificar se estão configuradas
env | grep LUZIA

# Reconfigurar
export LUZIA_CLIENT_ID="novo_valor"
export LUZIA_CLIENT_SECRET="novo_valor"
```

### Erro de Arquivo
```bash
# Verificar se existe
ls -la seus_fontes.txt

# Usar caminho absoluto
python main.py --fontes /caminho/completo/seus_fontes.txt
```

### Teste de Conectividade
```bash
# Testar com mock primeiro
python main.py --fontes examples/fontes.txt --models "mock_enhanced"

# Depois testar com LuzIA
python main.py --fontes examples/fontes.txt --models "claude_3_5_sonnet"
```

## Arquivos Importantes

- **main.py**: Script principal
- **config/config.yaml**: Configuração principal
- **config/prompts.yaml**: Prompts por modelo
- **examples/**: Arquivos de exemplo
- **README.md**: Documentação completa
- **INSTALACAO.md**: Guia detalhado

## Suporte

1. Consulte logs em `logs/`
2. Verifique configuração em `config/`
3. Teste com arquivos em `examples/`
4. Consulte documentação em `docs/`

---

**COBOL AI Engine v1.0.4 - Pronto para Produção**
