# Guia de Referência Rápida - COBOL AI Engine v1.0.2

## Instalação Rápida

```bash
tar -xzf cobol_ai_engine_v1.0.2.tar.gz
cd cobol_ai_engine_v2.0.0/
pip install -r requirements.txt
export LUZIA_API_KEY="sua_chave_aqui"
```

## Comandos Essenciais

### Análise Básica
```bash
# Configuração padrão
python main.py examples/fontes.txt

# Modelo específico
python main.py examples/fontes.txt --models "claude_3_5_sonnet"

# Com copybooks
python main.py examples/fontes.txt --books examples/BOOKS.txt
```

### Análise Multi-Modelo
```bash
# Dois modelos
python main.py examples/fontes.txt --models '["claude_3_5_sonnet","luzia_standard"]'

# Com PDF
python main.py examples/fontes.txt --models '["claude_3_5_sonnet","luzia_standard"]' --pdf
```

### Configuração Personalizada
```bash
# Arquivo de configuração customizado
python main.py examples/fontes.txt --config minha_config.yaml

# Diretório de saída específico
python main.py examples/fontes.txt --output minha_analise

# Log detalhado
python main.py examples/fontes.txt --log DEBUG
```

## Estrutura de Arquivos

### Arquivos Principais
```
main.py                     # Script principal
config/config.yaml         # Configuração do sistema
config/prompts.yaml        # Prompts por modelo
requirements.txt           # Dependências Python
```

### Arquivos de Entrada
```
examples/fontes.txt         # Lista de programas COBOL
examples/BOOKS.txt          # Lista de copybooks
```

### Saída Gerada
```
output/                     # Diretório padrão
├── PROGRAMA1.md           # Análise individual
├── PROGRAMA2.md
└── relatorio_comparativo_modelos.md  # Multi-modelo
```

## Configuração Rápida

### Variáveis de Ambiente
```bash
# LuzIA (principal)
export LUZIA_API_KEY="sua_chave_luzia"

# OpenAI (opcional)
export OPENAI_API_KEY="sua_chave_openai"
```

### Modelos Padrão (config.yaml)
```yaml
ai:
  default_models:
    - "claude_3_5_sonnet"
    - "luzia_standard"
```

### Provedor LuzIA (config.yaml)
```yaml
providers:
  luzia:
    enabled: true
    auth_url: "https://api.luzia.com/auth"
    endpoint: "https://api.luzia.com/v1/chat/completions"
    models:
      claude_3_5_sonnet:
        name: "claude-3-5-sonnet-20241022"
        max_tokens: 8192
```

## Modelos Disponíveis

| Modelo | Provedor | Tokens | Uso Recomendado |
|--------|----------|--------|-----------------|
| claude_3_5_sonnet | LuzIA | 200K | Análises profundas |
| luzia_standard | LuzIA | 32K | Análises padrão |
| openai_gpt4 | OpenAI | 128K | Análises alternativas |
| mock_enhanced | Mock | - | Testes e desenvolvimento |

## Formatos de Saída

### Modelo Único
```
output/
├── PROGRAMA1.md
├── PROGRAMA2.md
└── PROGRAMA3.md
```

### Múltiplos Modelos
```
output/
├── model_claude_3_5_sonnet/
│   ├── PROGRAMA1.md
│   └── PROGRAMA2.md
├── model_luzia_standard/
│   ├── PROGRAMA1.md
│   └── PROGRAMA2.md
└── relatorio_comparativo_modelos.md
```

## Seções dos Relatórios

Cada relatório inclui:

1. **Resumo Executivo**: Visão geral
2. **Análise Técnica**: Estrutura e arquitetura
3. **Regras de Negócio**: Lógica empresarial
4. **Estruturas de Dados**: Layouts e formatos
5. **Interfaces**: Dependências externas
6. **Recomendações**: Sugestões de melhoria
7. **Transparência**: Prompts utilizados

## Solução Rápida de Problemas

### Erro de Autenticação
```bash
# Verificar chave
echo $LUZIA_API_KEY

# Reconfigurar
export LUZIA_API_KEY="nova_chave"
```

### Modelo Não Encontrado
```bash
# Testar com mock
python main.py examples/fontes.txt --models "mock_enhanced"

# Verificar configuração
grep -A 5 "claude_3_5_sonnet" config/config.yaml
```

### Arquivo Não Encontrado
```bash
# Verificar arquivo
ls -la examples/fontes.txt

# Usar caminho absoluto
python main.py /caminho/completo/fontes.txt
```

### Timeout ou Erro de Rede
```bash
# Aumentar timeout (config.yaml)
timeout: 300

# Testar conectividade
curl -I https://api.luzia.com/v1/chat/completions
```

## Personalização Rápida

### Adicionar Novo Modelo
```yaml
# Em config.yaml
providers:
  luzia:
    models:
      meu_modelo:
        name: "nome-do-modelo-na-api"
        max_tokens: 4096
        temperature: 0.1
```

### Personalizar Prompts
```yaml
# Em prompts.yaml
model_prompts:
  meu_modelo:
    system_prompt: |
      Meu prompt personalizado...
    analysis_depth: "standard"
```

### Alterar Saída Padrão
```yaml
# Em config.yaml
output:
  format: "markdown"
  structure:
    single_model: "flat"
    multi_model: "separated"
```

## Comandos de Diagnóstico

### Verificar Instalação
```bash
python --version          # Deve ser 3.11+
pip list | grep -E "pyyaml|requests"
```

### Testar Configuração
```bash
python main.py --help
python -c "import yaml; print('YAML OK')"
```

### Teste Completo
```bash
# Teste rápido
python main.py examples/fontes.txt --models "mock_enhanced" --output teste

# Verificar saída
ls -la teste/
head -20 teste/LHAN0542.md
```

## Logs e Monitoramento

### Localização dos Logs
```bash
ls -la logs/cobol_ai_engine_*.log
```

### Níveis de Log
```bash
--log DEBUG    # Máximo detalhe
--log INFO     # Padrão
--log WARNING  # Apenas avisos
--log ERROR    # Apenas erros
```

### Monitorar Execução
```bash
# Em tempo real
tail -f logs/cobol_ai_engine_$(date +%Y%m%d)_*.log

# Filtrar erros
grep ERROR logs/cobol_ai_engine_*.log
```

## Performance

### Métricas Típicas
- **Tempo por programa**: 0.5-2.0s
- **Tokens por análise**: 2K-8K
- **Taxa de sucesso**: 99%+
- **Uso de memória**: <100MB

### Otimização
```yaml
# Em config.yaml
performance:
  timeout: 300
  memory:
    max_program_size: "5MB"
  processing:
    chunk_size: 4000
```

## Exemplos Práticos

### Análise de Desenvolvimento
```bash
python main.py meus_fontes.txt \
  --models "mock_enhanced" \
  --output dev_analysis \
  --log DEBUG
```

### Análise de Produção
```bash
python main.py fontes_producao.txt \
  --books books_producao.txt \
  --models '["claude_3_5_sonnet","luzia_standard"]' \
  --output analise_producao \
  --pdf
```

### Análise Crítica
```bash
python main.py fontes_criticos.txt \
  --books books_criticos.txt \
  --models '["claude_3_5_sonnet","luzia_standard","openai_gpt4"]' \
  --output analise_critica
```

## Integração com Scripts

### Script Bash
```bash
#!/bin/bash
export LUZIA_API_KEY="sua_chave"
python main.py "$1" --models "claude_3_5_sonnet" --output "analise_$(date +%Y%m%d)"
```

### Script Python
```python
import subprocess
import os

os.environ['LUZIA_API_KEY'] = 'sua_chave'
result = subprocess.run([
    'python', 'main.py', 
    'fontes.txt', 
    '--models', 'claude_3_5_sonnet'
], capture_output=True, text=True)
```

## Recursos Avançados

### Análise Comparativa
- Múltiplos modelos simultaneamente
- Relatório consolidado automático
- Estatísticas por modelo
- Recomendações baseadas em consenso

### Transparência Total
- Prompts salvos em cada relatório
- Metadados completos da análise
- Rastreabilidade total do processo
- Reprodutibilidade garantida

### Configuração Flexível
- Modelos padrão configuráveis
- Prompts personalizáveis por modelo
- Parâmetros ajustáveis por cenário
- Suporte a múltiplos provedores

---

**Guia de Referência Rápida - COBOL AI Engine v1.0.2**  
**Para suporte completo, consulte: DOCUMENTACAO_TECNICA_v1.0.2.md**
