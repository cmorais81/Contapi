#!/usr/bin/env python3
"""
Script para executar todos os testes do COBOL AI Engine.
"""

import sys
import os
import subprocess
import time

def run_test_file(test_file):
    """
    Executa um arquivo de teste específico.
    
    Args:
        test_file: Caminho para o arquivo de teste
        
    Returns:
        True se os testes passaram, False caso contrário
    """
    print(f"\n{'='*60}")
    print(f"Executando: {test_file}")
    print('='*60)
    
    try:
        result = subprocess.run([sys.executable, test_file], 
                              capture_output=False, 
                              text=True)
        return result.returncode == 0
    except Exception as e:
        print(f"Erro ao executar {test_file}: {e}")
        return False

def main():
    """Função principal."""
    print("COBOL AI Engine - Execução de Testes")
    print("="*60)
    
    # Diretório de testes
    tests_dir = os.path.join(os.path.dirname(__file__), 'tests')
    
    # Lista de arquivos de teste
    test_files = [
        'test_exceptions.py',
        'test_config_unified.py'
    ]
    
    # Estatísticas
    total_tests = len(test_files)
    passed_tests = 0
    failed_tests = []
    
    start_time = time.time()
    
    # Executar cada arquivo de teste
    for test_file in test_files:
        test_path = os.path.join(tests_dir, test_file)
        
        if not os.path.exists(test_path):
            print(f"❌ Arquivo de teste não encontrado: {test_path}")
            failed_tests.append(test_file)
            continue
        
        if run_test_file(test_path):
            passed_tests += 1
            print(f"✅ {test_file} - PASSOU")
        else:
            failed_tests.append(test_file)
            print(f"❌ {test_file} - FALHOU")
    
    end_time = time.time()
    execution_time = end_time - start_time
    
    # Relatório final
    print("\n" + "="*60)
    print("RELATÓRIO FINAL DE TESTES")
    print("="*60)
    print(f"Total de arquivos de teste: {total_tests}")
    print(f"Testes que passaram: {passed_tests}")
    print(f"Testes que falharam: {len(failed_tests)}")
    print(f"Tempo de execução: {execution_time:.2f} segundos")
    
    if failed_tests:
        print(f"\nTestes que falharam:")
        for test in failed_tests:
            print(f"  - {test}")
    
    # Resultado final
    if passed_tests == total_tests:
        print("\n🎉 TODOS OS TESTES PASSARAM!")
        return 0
    else:
        print(f"\n💥 {len(failed_tests)} TESTE(S) FALHARAM!")
        return 1

if __name__ == "__main__":
    sys.exit(main())

