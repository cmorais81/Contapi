# Guia de Uso: Prompts de Componentização v3.1.0

## Visão Geral

Este guia descreve como utilizar o novo padrão de prompts para análise de código COBOL com foco em **componentização** e **abstração** de funcionalidades reutilizáveis.

O arquivo `config/prompts_componentizacao_v3.1.0.yaml` contém prompts especializados que vão além da análise técnica tradicional, identificando oportunidades de extração de componentes, mapeamento BIAN, e estratégias de migração.

---

## Estrutura dos Prompts

### 1. Prompts Existentes (Aprimorados)

Estes prompts foram mantidos para compatibilidade, mas agora incluem identificação de candidatos a componentes:

#### `business_rule_extraction`
- **Objetivo**: Extrair regras de negócio com detalhes específicos
- **Novo campo**: "Candidato a Componente Reutilizável"
- **Uso**: Identificar lógica que pode ser centralizada

#### `financial_calculations`
- **Objetivo**: Identificar cálculos financeiros detalhados
- **Novo campo**: "Candidato a Componente"
- **Uso**: Extrair engines de cálculo reutilizáveis (impostos, juros, tarifas)

#### `data_validation_rules`
- **Objetivo**: Mapear validações de dados
- **Novo campo**: "Candidato a Validação Centralizada/Componente"
- **Uso**: Criar serviços de validação compartilhados

#### `detailed_copybook_analysis`
- **Objetivo**: Analisar estruturas de dados em copybooks
- **Novo campo**: "Candidatos a Reuso/Componente"
- **Uso**: Identificar DTOs e schemas reutilizáveis

#### `deep_business_analysis`
- **Objetivo**: Análise profunda com valores específicos
- **Nova seção**: "Componentes Reutilizáveis"
- **Uso**: Análise consolidada com mapeamento BIAN e contratos

---

### 2. Novos Prompts de Componentização

#### `component_design_and_abstraction`
**O prompt mais importante desta versão.**

**Objetivo**: Analisar documentação de sistemas legados e propor componentes reutilizáveis com:
- Nome e descrição do componente
- Contratos de entrada/saída (JSON Schema)
- Eventos gerados/consumidos
- Mapeamento BIAN sugerido
- Regras macro aplicáveis
- Requisitos não-funcionais (SLA, segurança, idempotência)
- Estratégia de migração e compatibilidade
- Observabilidade e auditoria

**Entregáveis obrigatórios**:
1. Tabela priorizada de componentes (impacto/complexidade/benefício)
2. JSON Schemas de exemplo para componentes principais
3. Lista de "macro rules" aplicáveis a todos os componentes
4. Checklist de migração incremental

**Exemplo de uso**:
```python
from src.core.prompt_manager import PromptManager

pm = PromptManager("config/prompts_componentizacao_v3.1.0.yaml")
prompt = pm.get_prompt("component_design_and_abstraction", {
    "system_documentation": cobol_code + copybooks
})
```

#### `component_templates`
**Objetivo**: Fornecer templates práticos de JSON Schema e eventos.

Inclui exemplos prontos para:
- TaxCalculationService (entrada/saída)
- CADOC Generator (entrada)
- Eventos de alteração de regras fiscais

#### `migration_and_governance`
**Objetivo**: Gerar checklists de migração incremental.

Fornece passo-a-passo para extrair componentes de monólitos legados com:
- Feature flags
- Testes de contrato
- Fallback para fluxo legado
- Rollout por fases

---

## Macros/Regras Padrão

Todos os componentes identificados devem respeitar estas **macro rules**:

1. **Idempotência**: Operações públicas devem ser repetíveis sem duplicação (usar `requestId`)
2. **Versionamento**: APIs e regras devem ter versão `major.minor` com estratégia de migração
3. **Configurabilidade**: Parâmetros de negócio devem residir em configuração externa
4. **Observabilidade**: Cada execução deve registrar evento de auditoria com `traceId`
5. **Transacionalidade**: Definir se é ACID local, sagas ou eventual consistency
6. **Segurança e PII**: Mascaramento, criptografia e controle de acesso RBAC/ABAC
7. **Localização & Fiscalidade**: Suportar multi-jurisdiction
8. **Performance & SLA**: Definir latência máxima (ex: <200ms para cálculos síncronos)
9. **Testabilidade**: Contratos devem ter suíte de testes automatizados
10. **Reuso de dados mestres**: Consultar Reference Data Service em vez de duplicar tabelas
11. **Tolerância a falhas**: Retries exponenciais, circuit-breaker, dead-letter queues
12. **Observância regulatória**: Trilha de auditoria imutável para componentes fiscais/regulatórios

---

## Como Usar

### Opção 1: Script Dedicado (Recomendado)

Use o script `use_componentization_prompts.py`:

```bash
# Análise completa de componentização
python use_componentization_prompts.py \
  --fontes examples/fontes.txt \
  --books examples/BOOKS.txt \
  --full-analysis \
  --output output_componentization

# Apenas análise de design de componentes
python use_componentization_prompts.py \
  --fontes examples/fontes.txt \
  --books examples/BOOKS.txt \
  --component-analysis \
  --output output_components
```

**Saídas geradas**:
- `00_RELATORIO_RESUMO.md`: Resumo executivo
- `01_ANALISE_COPYBOOKS.md`: Análise de copybooks com candidatos a reuso
- `02_ANALISE_PROFUNDA_<programa>.md`: Análise profunda de cada programa
- `03_DESIGN_COMPONENTES.md`: **Documento principal** com componentes propostos, JSON Schemas, macro rules e checklist de migração

### Opção 2: Integração com `main.py`

Modifique a configuração para usar os novos prompts:

```bash
# Editar config/config.yaml
ai:
  prompt:
    prompts_file: config/prompts_componentizacao_v3.1.0.yaml

# Executar análise
python main.py \
  --fontes examples/fontes.txt \
  --books examples/BOOKS.txt \
  --deep-analysis \
  --output output
```

### Opção 3: Uso Programático

```python
from use_componentization_prompts import ComponentizationAnalyzer

analyzer = ComponentizationAnalyzer()

# Análise completa
results = analyzer.full_componentization_analysis(
    fontes_file="examples/fontes.txt",
    books_file="examples/BOOKS.txt",
    output_dir="output_componentization",
    model="aws-claude-3-5-sonnet"
)

print(f"Tokens: {results['total_tokens']:,}")
print(f"Custo: ${results['total_cost']:.4f}")
```

---

## Fluxo de Trabalho Recomendado

### Fase 1: Análise Inicial
1. Executar análise completa com `--full-analysis`
2. Revisar `03_DESIGN_COMPONENTES.md`
3. Validar componentes propostos com arquitetos e analistas de negócio

### Fase 2: Priorização
1. Usar a tabela de priorização (impacto/complexidade/benefício)
2. Selecionar 3-5 componentes para POC
3. Validar JSON Schemas e contratos

### Fase 3: Implementação Incremental
1. Seguir checklist de migração (`migration_and_governance`)
2. Implementar com feature flags
3. Criar testes de contrato
4. Rollout por fases (canary)

### Fase 4: Governança
1. Aplicar macro rules a todos os componentes
2. Implementar observabilidade e auditoria
3. Documentar runbooks operacionais
4. Desativar código legado quando 95% do tráfego usar o novo componente

---

## Exemplos de Componentes Identificados

### TaxCalculationService
**Descrição**: Serviço centralizado para cálculo de impostos sobre transações bancárias

**Entrada (JSON Schema)**:
```json
{
  "transactionId": "string",
  "productId": "string",
  "amount": "number",
  "currency": "string",
  "jurisdiction": "string",
  "effectiveDate": "date"
}
```

**Saída (JSON Schema)**:
```json
{
  "transactionId": "string",
  "taxComponents": [
    {
      "name": "string",
      "base": "number",
      "rate": "number",
      "amount": "number"
    }
  ],
  "totalTax": "number",
  "calculationVersion": "string"
}
```

**Mapeamento BIAN**: Fees & Charges / Taxation

**Regras Macro**:
- Versionamento de regras
- Round half even, 2 decimais
- Auditoria por cálculo
- Idempotência via `transactionId`

---

## Diferenças em Relação aos Prompts Anteriores

### Prompts Anteriores (`prompts_deep_business_rules.yaml`)
- Foco em **extração de regras de negócio**
- Identificação de valores e fórmulas específicas
- Sem orientação para componentização

### Novos Prompts (`prompts_componentizacao_v3.1.0.yaml`)
- **Tudo do anterior** +
- Identificação de **candidatos a componentes**
- **Contratos de entrada/saída** (JSON Schema)
- **Mapeamento BIAN** sugerido
- **Macro rules** aplicáveis
- **Estratégia de migração** incremental
- **Requisitos não-funcionais** (SLA, segurança, observabilidade)
- **Templates práticos** de JSON Schema e eventos

---

## Modelos Recomendados

Para análise de componentização, recomendamos modelos com:
- **Alta capacidade de raciocínio**: Claude 3.5 Sonnet, GPT-4
- **Contexto longo**: Para processar múltiplos programas e copybooks
- **Conhecimento de arquitetura**: Para sugerir padrões BIAN e contratos

**Modelo padrão**: `aws-claude-3-5-sonnet`

---

## Custos Estimados

Baseado em análise de sistema bancário médio:

| Análise | Programas | Tokens | Custo (Claude 3.5) |
|---------|-----------|--------|-------------------|
| Copybooks | 10 | ~5.000 | $0.08 |
| Análise Profunda (por programa) | 1 | ~8.000 | $0.12 |
| Design de Componentes | Sistema | ~15.000 | $0.23 |
| **Total (10 programas)** | 10 | **~100.000** | **$1.50** |

---

## Suporte e Feedback

Para dúvidas ou sugestões sobre os prompts de componentização:

1. Revisar exemplos em `examples/`
2. Consultar logs em `logs/componentization_*.log`
3. Ajustar prompts em `config/prompts_componentizacao_v3.1.0.yaml`

---

## Changelog

### v3.1.0 (Outubro 2025)
- ✅ Adicionado prompt `component_design_and_abstraction`
- ✅ Adicionado prompt `component_templates`
- ✅ Adicionado prompt `migration_and_governance`
- ✅ Aprimorados prompts existentes com campo "Candidato a Componente"
- ✅ Incluídas macro rules padrão
- ✅ Criado script dedicado `use_componentization_prompts.py`
- ✅ Documentação completa de uso

---

**Autor**: Sistema de Análise COBOL v3.1.0  
**Data**: Outubro 2025  
**Licença**: Uso interno

