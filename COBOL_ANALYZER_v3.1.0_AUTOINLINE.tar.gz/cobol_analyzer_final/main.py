#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration import RAGIntegration
from src.core.intelligent_model_selector import IntelligentModelSelector
from src.analytics.consolidated_analysis import (
    process_advanced_consolidated_analysis,
    process_detailed_business_analysis
)

from src.utils.cobol_preprocessor import COBOLPreprocessor # Importar o pre-processador


def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        # String simples
        return [models_str]

def analyze_program_with_model(program: CobolProgram, all_books: List[CobolBook], model: str, output_dir: str, config_manager: ConfigManager, is_multi_model: bool, prompt_set: str, cost_calculator: CostCalculator, rag_integration=None, args=None) -> Dict[str, Any]:
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)
    
    # Criar diretório específico do modelo se multi-modelo
    if is_multi_model:
        model_output_dir = os.path.join(output_dir, f"model_{model.replace('/', '_').replace('-', '_')}")
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = output_dir
    
    try:
        # Inicializar componentes específicos para o modelo
        prompt_manager = DualPromptManager(config_manager.config, prompt_set)
        provider_manager = EnhancedProviderManager(config_manager.config)
        doc_generator = DocumentationGenerator(model_output_dir)
        
        # Inicializar analisador
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager, rag_integration)
        
        # Obter conteúdo dos copybooks para inlining
        copybooks_content = {book.name: book.content for book in all_books}
        
        # Inlining dos copybooks no conteúdo do programa
        preprocessor = COBOLPreprocessor()
        inlined_program_content = preprocessor.inline_copybooks(program.content, copybooks_content)
        
        # Criar um novo objeto CobolProgram com o conteúdo inlined
        inlined_program = CobolProgram(
            name=program.name,
            content=inlined_program_content,
            line_count=len(inlined_program_content.split("\n")),
            size=len(inlined_program_content.encode("utf-8")),
            divisions=program.divisions,
            sections=program.sections,
            variables=program.variables,
            files=program.files
        )

        # Remoção de comentários se solicitado ou se há muitos comentários
        if args:
            has_many_comments = preprocessor.has_comments(inlined_program.content)
            logger.info(f"Verificando comentários em {inlined_program.name}: no_comments={getattr(args, 'no_comments', False)}, has_many_comments={has_many_comments}")
            
            if hasattr(args, 'no_comments') and (args.no_comments or has_many_comments):
                if args.no_comments:
                    logger.info(f"Remoção de comentários solicitada para {inlined_program.name}")
                else:
                    logger.info(f"Muitos comentários detectados em {inlined_program.name} - removendo para análise focada")
                
                # Modificar o conteúdo do programa inlined
                inlined_program.content, removed_comments = preprocessor.remove_comments(inlined_program.content)
                logger.info(f"Removidos {removed_comments} comentários de {inlined_program.name}")
            else:
                logger.info(f"Mantendo comentários em {inlined_program.name}")
        
        start_time = time.time()
        
        # Log do provider que será usado
        logger.info(f"*** PROVIDER SELECIONADO: {model} ***")
        logger.info(f"Iniciando análise de {inlined_program.name} com provider {model}")
        logger.debug(f"Conteúdo do programa após inlining e remoção de comentários:\n{inlined_program.content}")
        
        analysis_result = analyzer.analyze_program(inlined_program, model)
        analysis_time = time.time() - start_time
        
        # Log do provider efetivamente usado
        provider_usado = getattr(analysis_result, 'provider_used', model)
        logger.info(f"*** ANÁLISE CONCLUÍDA COM PROVIDER: {provider_usado} ***")
        
        if not analysis_result.success:
            error_msg = f"ERRO na análise de {inlined_program.name} com modelo {model}: {analysis_result.error_message}"
            logger.error(error_msg)
            print(f"\n {error_msg}")
            print(f"   Programa: {inlined_program.name}")
            print(f"   Modelo solicitado: {model}")
            print(f"   Tempo decorrido: {analysis_time:.2f}s")
            print(f"   Detalhes do erro: {analysis_result.error_message}")
            return {
                'success': False,
                'program_name': inlined_program.name,
                'model': model,
                'error': analysis_result.error_message,
                'tokens_used': 0,
                'analysis_time': analysis_time,
                'output_dir': model_output_dir
            }
        
        # Calcular custos
        cost_info = cost_calculator.tokens_analytics(
            {'usage': [{'total_tokens': analysis_result.tokens_used}]},
            analysis_result.model_used
        )
        
        # Gerar documentação
        from src.providers.base_provider import AIResponse
        
        # Obter prompts utilizados do prompt_manager
        prompts_used = {
            'system_prompt': prompt_manager.get_system_prompt(),
            'original_prompt': getattr(analysis_result, 'original_prompt', 'Prompt gerado dinamicamente'),
            'main_prompt': getattr(analysis_result, 'prompt_used', 'Prompt principal não disponível')
        }
        
        ai_response = AIResponse(
            success=True,
            content=analysis_result.content,
            tokens_used=analysis_result.tokens_used,
            model=analysis_result.model_used,
            provider=getattr(analysis_result, 'provider_used', 'enhanced_mock'),
            prompts_used=prompts_used,
            response_time=analysis_time
        )
        
        doc_result = doc_generator.generate_program_documentation(inlined_program, ai_response)
        
        logger.info(f"Análise de {inlined_program.name} com {model} bem-sucedida.")
        logger.info(f"Tokens utilizados: {analysis_result.tokens_used:,}")
        logger.info(f"Custo: ${cost_info['cost']:.4f}")
        logger.info(f"Modelo utilizado: {analysis_result.model_used}")
        
        # Auto-learning: Adicionar análise bem-sucedida à base de conhecimento
        if rag_integration and hasattr(rag_integration, 'add_program_analysis_to_knowledge_base'):
            try:
                rag_integration.add_program_analysis_to_knowledge_base(
                inlined_program.name, 
                    analysis_result.content, 
                    inlined_program.content
                )
                logger.info(f"Auto-learning: Conhecimento do programa {inlined_program.name} adicionado à base RAG")
            except Exception as e:
                logger.warning(f"Auto-learning falhou para {inlined_program.name}: {e}")
        
            return {
                'success': True,
                'program_name': inlined_program.name,
                'model': model,
                'tokens_used': analysis_result.tokens_used,
                'analysis_time': analysis_time,
                'output_dir': model_output_dir,
                'files_generated': [doc_result] if doc_result else [],
                'response': analysis_result
            }

    except Exception as e:
        logger.error(f"Erro na análise de {inlined_program.name} com modelo {model}: {str(e)}")
        return {
            'success': False,
            'program_name': inlined_program.name,
            'model': model,
            'error': str(e),
            'tokens_used': 0,
            'analysis_time': 0,
            'output_dir': model_output_dir
        }

def generate_comparative_report(programs: List[CobolProgram], all_results: List[Dict[str, Any]], output_dir: str) -> None:
    """Gera relatório comparativo entre modelos."""
    logger = logging.getLogger(__name__)
    
    try:
        report_path = os.path.join(output_dir, "relatorio_comparativo_modelos.md")
        
        # Agrupar resultados por modelo
        models_used = list(set(r['model'] for r in all_results))
        results_by_model = {model: [r for r in all_results if r['model'] == model] for model in models_used}
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Comparativo de Modelos\n\n")
            f.write(f"**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Programas Analisados:** {len(programs)}\n")
            f.write(f"**Modelos Utilizados:** {len(models_used)}\n\n")
            
            # Resumo geral
            f.write("## Resumo Geral\n\n")
            f.write("| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios |\n")
            f.write("|--------|----------|--------|-----------------|---------------|\n")
            
            for model in models_used:
                model_results = results_by_model[model]
                success_count = sum(1 for r in model_results if r['success'])
                failure_count = len(model_results) - success_count
                success_rate = (success_count / len(model_results)) * 100 if model_results else 0
                avg_tokens = sum(r['tokens_used'] for r in model_results) / len(model_results) if model_results else 0
                f.write(f"| {model} | {success_count} | {failure_count} | {success_rate:.2f}% | {avg_tokens:,.0f} |\n")
            
            f.write("\n## Detalhes por Programa\n\n")
            
            for program in programs:
                f.write(f"### Programa: {program.name}\n\n")
                f.write("| Modelo | Status | Tokens | Tempo (s) | Custo ($) | Arquivos Gerados |\n")
                f.write("|--------|--------|--------|-----------|-----------|------------------|\n")
                
                program_results = [r for r in all_results if r['program_name'] == program.name]
                
                for result in sorted(program_results, key=lambda r: r['model']):
                    status = "Sucesso" if result['success'] else "Falha"
                    cost_info = cost_calculator.tokens_analytics(
                        {'usage': [{'total_tokens': result['tokens_used']}]},
                        result.get('response', {}).get('model_used', result['model'])
                    )
                    cost = cost_info['cost']
                    files_generated = ', '.join(result.get('files_generated', []))
                    f.write(f"| {result['model']} | {status} | {result['tokens_used']:,} | {result['analysis_time']:.2f} | {cost:.4f} | {files_generated} |\n")
                
                f.write("\n")

            f.write("## Recomendações\n\n")
            
            # Encontrar melhor modelo por taxa de sucesso
            best_model = max(models_used, key=lambda m: sum(1 for r in results_by_model[m] if r['success']) / len(results_by_model[m]))
            f.write(f"- **Melhor Modelo (Taxa de Sucesso):** `{best_model}`\n")
            
            # Encontrar modelo mais rápido
            fastest_model = min(all_results, key=lambda r: r['analysis_time'])['model']
            f.write(f"- **Modelo Mais Rápido (Média):** `{fastest_model}`\n")
            
            # Encontrar modelo mais econômico
            cheapest_model = min(all_results, key=lambda r: cost_calculator.tokens_analytics({'usage': [{'total_tokens': r['tokens_used']}]}, r.get('response', {}).get('model_used', r['model']))['cost'])['model']
            f.write(f"- **Modelo Mais Econômico (Média):** `{cheapest_model}`\n\n")

        logger.info(f"Relatório comparativo gerado em {report_path}")

    except Exception as e:
        logger.error(f"Erro ao gerar relatório comparativo: {e}")

def main(args: argparse.Namespace) -> None:
    """Função principal do sistema."""
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)

    logger.info("="*50)
    logger.info("COBOL to Docs v1.0 - Iniciando Análise")
    logger.info("="*50)

    # Carregar configurações
    try:
        config_manager = ConfigManager(args.config)
    except FileNotFoundError:
        logger.error(f"Arquivo de configuração não encontrado em {args.config}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Erro ao carregar configuração: {e}")
        sys.exit(1)

    # Inicializar gerenciador de custos
    cost_calculator = CostCalculator()

    # Inicializar RAG se a URL do ChromaDB for fornecida
    rag_integration = None
    if args.chromadb_url:
        try:
            rag_integration = RAGIntegration(args.chromadb_url, config_manager.config)
            logger.info(f"RAG Integration ativado com ChromaDB em {args.chromadb_url}")
        except Exception as e:
            logger.error(f"Falha ao inicializar RAG Integration: {e}")
            sys.exit(1)

    # Parse dos modelos
    models = parse_models_argument(args.models)
    if not models:
        logger.error("Nenhum modelo de IA foi especificado. Use o argumento --models.")
        sys.exit(1)

    # Análise de negócio detalhada
    if args.deep_analysis:
        parser = COBOLParser()
        process_detailed_business_analysis(args, config_manager, cost_calculator, parser, models)
        return

    # Análise consolidada avançada
    if args.consolidated_analysis:
        parser = COBOLParser()
        process_advanced_consolidated_analysis(args, config_manager, cost_calculator, parser, models)
        return

    # Processamento normal
    parser = COBOLParser()
    programs = []
    if args.fontes:
        if parser._is_file_a_list(args.fontes):
            programs.extend(parser.parse_program_list_file(args.fontes))
        else:
            # Tratar como um único arquivo COBOL
            try:
                with open(args.fontes, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                program_name = Path(args.fontes).name
                program = parser._parse_program(program_name, content)
                programs.append(program)
                logger.info(f"Programa COBOL único parseado: {program_name}")
            except Exception as e:
                logger.error(f"Erro ao parsear programa COBOL único {args.fontes}: {str(e)}")

    books = []
    if args.books:
        books.extend(parser.parse_book_list_file(args.books))
    elif len(programs) == 1: # Se um único programa foi fornecido e nenhum book.txt
        program = programs[0]
        logger.info(f"Detectando copybooks automaticamente para o programa: {program.name}")
        preprocessor = COBOLPreprocessor()
        referenced_copybooks = preprocessor.detect_copybooks(program.content)
        
        if referenced_copybooks:
            # Definir caminhos de busca para copybooks
            # Priorizar o diretório do programa, depois um diretório 'copybooks' no mesmo nível
            program_dir = Path(args.fontes).parent # Se args.fontes é um arquivo único, pega o diretório dele.
                                                # Se args.fontes é uma lista, o programa já tem o caminho completo.
            search_paths = [str(program_dir), str(program_dir / "copybooks"), str(Path(__file__).parent / "examples")]
            logger.info(f"Caminhos de busca para copybooks: {search_paths}")
            
            found_books = parser.find_copybook_files(referenced_copybooks, search_paths)
            books.extend(found_books)
            logger.info(f"Encontrados {len(found_books)} copybooks automaticamente para {program.name}")
        else:
            logger.info(f"Nenhum copybook referenciado detectado em {program.name}")

    if not programs:
        logger.warning("Nenhum programa COBOL encontrado para análise.")
        return

    logger.info(f"Encontrados {len(programs)} programas e {len(books)} copybooks.")

    all_results = []
    total_cost = 0.0

    # Seleção inteligente de modelo, se ativada
    if args.intelligent_model_selection:
        selector = IntelligentModelSelector(config_manager.config, cost_calculator)
        selected_model = selector.select_model(programs[0]) # Seleciona baseado no primeiro programa
        logger.info(f"Seleção inteligente ativada. Modelo escolhido: {selected_model}")
        models = [selected_model]

    is_multi_model = len(models) > 1

    for program in programs:
        if is_multi_model:
            logger.info(f"--- Analisando programa: {program.name} com múltiplos modelos ---")
            program_results = []
            for model in models:
                result = analyze_program_with_model(
                    program, books, model, args.output, config_manager, is_multi_model, args.prompt_set, cost_calculator, rag_integration, args
                )
                program_results.append(result)
                if result['success']:
                    cost_info = cost_calculator.tokens_analytics(
                        {'usage': [{'total_tokens': result['tokens_used']}]},
                        result.get('response', {}).get('model_used', result['model'])
                    )
                    total_cost += cost_info['cost']
            all_results.extend(program_results)
        else:
            current_model = models[0]
            logger.info(f"--- Analisando programa: {program.name} com modelo {current_model} ---")
            result = analyze_program_with_model(
                program, books, current_model, args.output, config_manager, is_multi_model, args.prompt_set, cost_calculator, rag_integration, args
            )
            all_results.append(result)
            if result['success']:
                cost_info = cost_calculator.tokens_analytics(
                    {'usage': [{'total_tokens': result['tokens_used']}]},
                    result.get('response', {}).get('model_used', result['model'])
                )
                total_cost += cost_info['cost']

    logger.info("="*50)
    logger.info("Análise Concluída")
    logger.info(f"Custo total estimado: ${total_cost:.4f}")
    logger.info("="*50)

    if is_multi_model:
        generate_comparative_report(programs, all_results, args.output)

    # Gerar relatório HTML se solicitado
    if args.html_report:
        html_gen = HTMLReportGenerator(args.output, cost_calculator)
        html_gen.generate_from_results(all_results)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="COBOL to Docs - Sistema de Análise e Documentação de Programas COBOL")
    
    # Argumentos principais
    parser.add_argument("--fontes", required=True, help="Caminho para o arquivo com os fontes COBOL")
    parser.add_argument("--books", help="Caminho para o arquivo com os copybooks")
    parser.add_argument("--output", default="output", help="Diretório de saída para a documentação")
    parser.add_argument("--config", default="config/config.yaml", help="Caminho para o arquivo de configuração")
    
    # Argumentos de modelo
    parser.add_argument("--models", default='gemini-1.5-pro-latest', help="Modelo(s) de IA a ser(em) usado(s). Pode ser uma string ou uma lista JSON.")
    parser.add_argument("--prompt-set", default="default", help="Conjunto de prompts a ser usado (ex: default, componentizacao)")
    parser.add_argument("--intelligent-model-selection", action="store_true", help="Ativa a seleção inteligente de modelo")

    # Modos de análise especiais
    parser.add_argument("--consolidated-analysis", action="store_true", help="Executa uma análise consolidada de múltiplos programas")
    parser.add_argument("--deep-analysis", action="store_true", help="Executa uma análise de negócio detalhada e aprofundada")

    # Opções de pré-processamento
    parser.add_argument("--no-comments", action="store_true", help="Remove comentários do código antes da análise")

    # Opções de relatório
    parser.add_argument("--html-report", action="store_true", help="Gera um relatório HTML consolidado")

    # Opções de RAG
    parser.add_argument("--chromadb-url", help="URL para o ChromaDB para integração RAG")

    # Opções de logging
    parser.add_argument("--log-level", default="INFO", choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'], help="Nível de logging")

    args = parser.parse_args()
    main(args)

