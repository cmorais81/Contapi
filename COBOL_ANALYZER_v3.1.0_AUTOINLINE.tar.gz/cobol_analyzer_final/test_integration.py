#!/usr/bin/env python3
"""Teste de integração dos prompts de componentização com main.py"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager

print("=" * 80)
print("TESTE DE INTEGRAÇÃO - PROMPTS DE COMPONENTIZAÇÃO")
print("=" * 80)
print()

# Teste 1: Carregar ConfigManager
print("1. Testando ConfigManager...")
try:
    config_manager = ConfigManager()
    print("   ✅ ConfigManager carregado")
except Exception as e:
    print(f"   ❌ Erro: {e}")
    sys.exit(1)

# Teste 2: Carregar DualPromptManager com 'componentizacao'
print()
print("2. Testando DualPromptManager com prompt_set='componentizacao'...")
try:
    pm = DualPromptManager(config_manager.config, 'componentizacao')
    print(f"   ✅ DualPromptManager inicializado")
    print(f"   ✅ Conjunto ativo: {pm.active_prompt_set}")
    
    # Verificar se carregou o arquivo correto
    if pm.prompts_config:
        print(f"   ✅ Configuração de prompts carregada")
        if 'prompts' in pm.prompts_config:
            prompts = pm.prompts_config['prompts']
            print(f"   ✅ Total de prompts: {len(prompts)}")
            
            # Verificar se tem o prompt de componentização
            if 'component_design_and_abstraction' in prompts:
                print("   ✅ Prompt 'component_design_and_abstraction' encontrado!")
            else:
                print("   ⚠️  Prompt 'component_design_and_abstraction' NÃO encontrado")
        else:
            print("   ⚠️  Chave 'prompts' não encontrada na configuração")
    else:
        print("   ❌ Configuração de prompts vazia")
        sys.exit(1)
        
except Exception as e:
    print(f"   ❌ Erro: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Teste 3: Testar outros aliases
print()
print("3. Testando aliases...")
for alias in ['bian', 'componentizacao_v3']:
    try:
        pm_alias = DualPromptManager(config_manager.config, alias)
        print(f"   ✅ Alias '{alias}' funciona")
    except Exception as e:
        print(f"   ❌ Alias '{alias}' falhou: {e}")

print()
print("=" * 80)
print("TESTE CONCLUÍDO COM SUCESSO!")
print("=" * 80)
print()
print("Agora você pode usar:")
print("  python main.py --fontes ... --prompt-set componentizacao")
print("  python main.py --fontes ... --prompt-set bian")
print("  python main.py --fontes ... --prompt-set componentizacao_v3")
