#!/usr/bin/env python3
"""
API Simples do COBOL Analyzer
Funciona garantidamente após instalação
"""

import os
import sys
import subprocess
import tempfile
from pathlib import Path

def init(config_dir='./config', data_dir='./data', logs_dir='./logs'):
    """
    Inicializa ambiente COBOL Analyzer
    
    Args:
        config_dir: Diretório para configurações
        data_dir: Diretório para dados
        logs_dir: Diretório para logs
        
    Returns:
        bool: True se sucesso, False se erro
    """
    try:
        cmd = ['cobol-to-docs', '--init']
        
        if config_dir != './config':
            cmd.extend(['--config-dir', config_dir])
        if data_dir != './data':
            cmd.extend(['--data-dir', data_dir])
        if logs_dir != './logs':
            cmd.extend(['--logs-dir', logs_dir])
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        return result.returncode == 0
        
    except Exception:
        return False

def analyze_program(program_content, program_name="programa.cbl"):
    """
    Analisa programa COBOL a partir do conteúdo
    
    Args:
        program_content: Código COBOL como string
        program_name: Nome do programa
        
    Returns:
        dict: Resultado da análise
    """
    try:
        # Criar arquivo temporário
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cbl', delete=False) as f:
            f.write(program_content)
            temp_file = f.name
        
        # Criar lista de fontes temporária
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write(f"{temp_file}\n")
            fontes_file = f.name
        
        try:
            # Executar análise
            cmd = ['cobol-to-docs', '--fontes', fontes_file]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            success = result.returncode == 0
            
            return {
                'success': success,
                'program_name': program_name,
                'stdout': result.stdout,
                'stderr': result.stderr,
                'documentation': result.stdout if success else ""
            }
            
        finally:
            # Limpar arquivos temporários
            try:
                os.unlink(temp_file)
                os.unlink(fontes_file)
            except:
                pass
                
    except Exception as e:
        return {
            'success': False,
            'program_name': program_name,
            'error': str(e),
            'documentation': ""
        }

def analyze_file(file_path):
    """
    Analisa arquivo COBOL
    
    Args:
        file_path: Caminho para arquivo COBOL
        
    Returns:
        dict: Resultado da análise
    """
    try:
        if not os.path.exists(file_path):
            return {
                'success': False,
                'program_name': file_path,
                'error': 'Arquivo não encontrado',
                'documentation': ""
            }
        
        # Criar lista de fontes temporária
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write(f"{file_path}\n")
            fontes_file = f.name
        
        try:
            # Executar análise
            cmd = ['cobol-to-docs', '--fontes', fontes_file]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            success = result.returncode == 0
            
            return {
                'success': success,
                'program_name': os.path.basename(file_path),
                'stdout': result.stdout,
                'stderr': result.stderr,
                'documentation': result.stdout if success else ""
            }
            
        finally:
            # Limpar arquivo temporário
            try:
                os.unlink(fontes_file)
            except:
                pass
                
    except Exception as e:
        return {
            'success': False,
            'program_name': os.path.basename(file_path),
            'error': str(e),
            'documentation': ""
        }

def status():
    """
    Verifica status do COBOL Analyzer
    
    Returns:
        dict: Status do sistema
    """
    try:
        # Verificar se comando existe
        result = subprocess.run(['which', 'cobol-to-docs'], 
                              capture_output=True, text=True)
        command_available = result.returncode == 0
        
        # Verificar se ambiente está inicializado
        initialized = os.path.exists('.cobol_analyzer_init')
        
        return {
            'command_available': command_available,
            'initialized': initialized,
            'config_dir': './config' if os.path.exists('./config') else None,
            'data_dir': './data' if os.path.exists('./data') else None,
            'logs_dir': './logs' if os.path.exists('./logs') else None,
            'version': '3.1.0'
        }
        
    except Exception as e:
        return {
            'command_available': False,
            'initialized': False,
            'error': str(e),
            'version': '3.1.0'
        }

# Classe simples para compatibilidade
class COBOLAnalyzer:
    """Analisador COBOL simples"""
    
    def __init__(self):
        self.config = {}
    
    def configure(self, **kwargs):
        """Configura analisador"""
        self.config.update(kwargs)
    
    def analyze_program(self, content, name="programa.cbl"):
        """Analisa programa"""
        return analyze_program(content, name)
    
    def analyze_file(self, file_path):
        """Analisa arquivo"""
        return analyze_file(file_path)

class COBOLProject:
    """Projeto COBOL simples"""
    
    def __init__(self, name):
        self.name = name
        self.programs = []
    
    def add_program(self, file_path):
        """Adiciona programa ao projeto"""
        self.programs.append(file_path)
    
    def analyze_all(self):
        """Analisa todos os programas"""
        results = []
        for program in self.programs:
            result = analyze_file(program)
            results.append(result)
        return results

# Exportar funções principais
__all__ = [
    'init',
    'analyze_program', 
    'analyze_file',
    'status',
    'COBOLAnalyzer',
    'COBOLProject'
]

if __name__ == "__main__":
    # Teste básico
    print("Testando API simples...")
    
    # Testar status
    st = status()
    print(f"Status: {st}")
    
    # Testar init se comando disponível
    if st['command_available']:
        print("Testando init...")
        result = init()
        print(f"Init: {result}")
        
        # Testar análise
        codigo = '''
        IDENTIFICATION DIVISION.
        PROGRAM-ID. TESTE.
        PROCEDURE DIVISION.
            DISPLAY "HELLO WORLD".
            STOP RUN.
        '''
        
        print("Testando análise...")
        resultado = analyze_program(codigo, "TESTE.CBL")
        print(f"Análise: {resultado['success']}")
    
    print("Teste concluído!")
