#!/usr/bin/env python3
"""
Instalador API Programática - COBOL Analyzer
============================================

Instala o COBOL Analyzer com suporte completo à API programática.
Após a instalação, você pode usar: import cobol_to_docs
"""

import os
import sys
import subprocess
import shutil
from pathlib import Path

def print_step(message):
    print(f"\n {message}")

def run_command(cmd, description):
    """Executa comando e retorna resultado"""
    print(f"💻 {description}")
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        print(f" Sucesso")
        return True
    except subprocess.CalledProcessError as e:
        print(f" Erro: {e}")
        print(f" Stderr: {e.stderr}")
        return False

def create_api_entry_point():
    """Cria entry point para API programática"""
    
    script_content = '''#!/usr/bin/env python3
import sys
import os
import subprocess
from pathlib import Path

def main():
    # Se é comando --init, usar main_enhanced.py
    if '--init' in sys.argv:
        # Locais possíveis para main_enhanced.py
        locations = [
            "/usr/local/lib/python3.11/dist-packages/main_enhanced.py",
            "/usr/local/bin/main_enhanced.py",
            "/home/ubuntu/cobol_analyzer_EXCELENCIA/main_enhanced.py",
            "./main_enhanced.py"
        ]
        
        for location in locations:
            if os.path.exists(location):
                # Substituir --init por --init-local
                args = [arg if arg != '--init' else '--init-local' for arg in sys.argv[1:]]
                cmd = [sys.executable, location] + args
                result = subprocess.run(cmd)
                sys.exit(result.returncode)
        
        print(" Erro: main_enhanced.py não encontrado")
        print(" Tente: python main_enhanced.py --init-local")
        sys.exit(1)
    
    # Para outros comandos, usar main.py
    try:
        sys.path.insert(0, "/usr/local/lib/python3.11/dist-packages")
        from main import main as main_func
        main_func()
    except ImportError:
        locations = [
            "/usr/local/lib/python3.11/dist-packages/main.py",
            "/usr/local/bin/main.py",
            "/home/ubuntu/cobol_analyzer_EXCELENCIA/main.py",
            "./main.py"
        ]
        
        for location in locations:
            if os.path.exists(location):
                cmd = [sys.executable, location] + sys.argv[1:]
                result = subprocess.run(cmd)
                sys.exit(result.returncode)
        
        print(" Erro: main.py não encontrado")
        sys.exit(1)

if __name__ == "__main__":
    main()
'''
    
    return script_content

def install_api_entry_point():
    """Instala entry point para API"""
    
    # Tentar diferentes locais para bin
    bin_locations = ["/usr/local/bin", "/usr/bin"]
    
    for bin_dir in bin_locations:
        if os.path.exists(bin_dir) and os.access(bin_dir, os.W_OK):
            script_path = os.path.join(bin_dir, "cobol-to-docs")
            
            try:
                with open(script_path, 'w') as f:
                    f.write(create_api_entry_point())
                
                os.chmod(script_path, 0o755)
                print(f" Entry point criado: {script_path}")
                return True
                
            except Exception as e:
                print(f" Erro ao criar entry point: {e}")
                continue
    
    print(" Não foi possível criar entry point")
    return False

def test_api_installation():
    """Testa a instalação da API"""
    
    print("\n TESTANDO INSTALAÇÃO DA API")
    
    # Teste 1: Comando disponível
    if not shutil.which('cobol-to-docs'):
        print(" Comando cobol-to-docs não encontrado")
        return False
    print(" Comando encontrado")
    
    # Teste 2: Import da API
    try:
        # Testar import básico
        result = subprocess.run([
            sys.executable, '-c', 
            'import cobol_to_docs; print("API importada com sucesso")'
        ], capture_output=True, text=True, timeout=10)
        
        if result.returncode == 0:
            print(" API importável")
        else:
            print(f" Erro no import da API: {result.stderr}")
            return False
    except Exception as e:
        print(f" Erro ao testar import: {e}")
        return False
    
    # Teste 3: Funcionalidades básicas da API
    try:
        test_script = '''
import cobol_to_docs

# Testar inicialização
try:
    cobol_to_docs.init()
    print(" Init funcionando")
except Exception as e:
    print(f" Init falhou: {e}")

# Testar configuração
try:
    config = cobol_to_docs.get_config()
    print(f" Config obtida: {len(config)} itens")
except Exception as e:
    print(f" Config falhou: {e}")

# Testar status
try:
    status = cobol_to_docs.status()
    print(f" Status obtido: {status.get('initialized', False)}")
except Exception as e:
    print(f" Status falhou: {e}")

print(" Testes da API concluídos")
'''
        
        result = subprocess.run([
            sys.executable, '-c', test_script
        ], capture_output=True, text=True, timeout=30)
        
        print(" Resultado dos testes da API:")
        print(result.stdout)
        
        if result.stderr:
            print("  Avisos:")
            print(result.stderr)
        
        return " Init funcionando" in result.stdout
        
    except Exception as e:
        print(f" Erro ao testar API: {e}")
        return False

def create_api_example():
    """Cria exemplo de uso da API"""
    
    example_content = '''#!/usr/bin/env python3
"""
Exemplo Rápido - API COBOL Analyzer
Após instalação via: pip install cobol-to-docs
"""

def exemplo_rapido():
    print(" Exemplo Rápido da API COBOL Analyzer")
    print("=" * 50)
    
    try:
        # Importar API
        import cobol_to_docs
        print(" API importada")
        
        # Inicializar
        cobol_to_docs.init()
        print(" Ambiente inicializado")
        
        # Programa exemplo
        programa = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. EXEMPLO-RAPIDO.
        PROCEDURE DIVISION.
            DISPLAY 'API FUNCIONANDO'.
            STOP RUN.
        """
        
        # Analisar
        resultado = cobol_to_docs.analyze_program(programa, "EXEMPLO.CBL")
        print(f" Análise: {resultado.success}")
        print(f" Documentação: {len(resultado.documentation)} caracteres")
        
        return True
        
    except Exception as e:
        print(f" Erro: {e}")
        return False

if __name__ == "__main__":
    exemplo_rapido()
'''
    
    try:
        with open("exemplo_api_rapido.py", "w") as f:
            f.write(example_content)
        print(" Exemplo criado: exemplo_api_rapido.py")
        return True
    except Exception as e:
        print(f" Erro ao criar exemplo: {e}")
        return False

def main():
    """Instalação principal da API"""
    
    print(" COBOL ANALYZER - INSTALAÇÃO API PROGRAMÁTICA")
    print("=" * 60)
    print("Instala com suporte completo a: import cobol_to_docs")
    print("=" * 60)
    
    # Passo 1: Desinstalar anterior
    print_step("Removendo instalação anterior")
    run_command([sys.executable, '-m', 'pip', 'uninstall', 'cobol-to-docs', '-y'], 
                "Desinstalar")
    
    # Passo 2: Instalar com API
    print_step("Instalando COBOL Analyzer com API")
    if not run_command([sys.executable, 'setup_api.py', 'install'], 
                      "Instalar com API"):
        print(" Falha na instalação")
        sys.exit(1)
    
    # Passo 3: Entry point
    print_step("Configurando entry point")
    if not install_api_entry_point():
        print("  Entry point não criado - use execução direta")
    
    # Passo 4: Testar API
    print_step("Testando API")
    if test_api_installation():
        print(" API funcionando")
    else:
        print(" API com problemas")
    
    # Passo 5: Criar exemplo
    print_step("Criando exemplo de uso")
    create_api_example()
    
    print("\n INSTALAÇÃO DA API CONCLUÍDA!")
    print("=" * 40)
    print(" Como usar:")
    print("   import cobol_to_docs")
    print("   cobol_to_docs.init()")
    print("   resultado = cobol_to_docs.analyze_program(codigo)")
    print("")
    print(" Teste rápido:")
    print("   python exemplo_api_rapido.py")
    print("")
    print("📚 Exemplo completo:")
    print("   python exemplo_api_completa.py")

if __name__ == "__main__":
    main()
