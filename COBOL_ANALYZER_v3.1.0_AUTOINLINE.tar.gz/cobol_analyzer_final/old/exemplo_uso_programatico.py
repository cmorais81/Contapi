#!/usr/bin/env python3
"""
Exemplo de Uso Programático - COBOL Analyzer
Após instalação via: pip install cobol-to-docs

Este exemplo mostra como usar o COBOL Analyzer como componente
programático em seus próprios scripts Python.
"""

import os
import sys
from pathlib import Path

def exemplo_basico():
    """Exemplo básico de uso programático"""
    
    print(" EXEMPLO 1: Uso Básico Programático")
    print("=" * 50)
    
    try:
        # Importar componentes do COBOL Analyzer
        from src.core.config_enhanced import EnhancedConfigManager
        from src.providers.enhanced_provider_manager import EnhancedProviderManager
        from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
        from src.parsers.cobol_parser_original import COBOLParser
        
        # 1. Configurar ambiente
        print(" Configurando ambiente...")
        config_manager = EnhancedConfigManager()
        
        # 2. Inicializar provedor de IA
        print("🤖 Inicializando provedor de IA...")
        provider_manager = EnhancedProviderManager(config_manager.config)
        
        # 3. Criar analisador
        print(" Criando analisador...")
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, config_manager)
        
        # 4. Analisar programa COBOL (exemplo)
        programa_exemplo = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. EXEMPLO-PROG.
        
        DATA DIVISION.
        WORKING-STORAGE SECTION.
        01 WS-CONTADOR PIC 9(3) VALUE 0.
        01 WS-NOME     PIC X(30).
        
        PROCEDURE DIVISION.
        INICIO.
            DISPLAY 'PROGRAMA EXEMPLO'.
            MOVE 100 TO WS-CONTADOR.
            DISPLAY 'CONTADOR: ' WS-CONTADOR.
            STOP RUN.
        """
        
        print(" Analisando programa COBOL...")
        resultado = analyzer.analyze_program(
            program_content=programa_exemplo,
            program_name="EXEMPLO-PROG.CBL"
        )
        
        print(" Análise concluída!")
        print(f" Resultado: {len(resultado)} caracteres de documentação gerada")
        
        return resultado
        
    except ImportError as e:
        print(f" Erro de importação: {e}")
        print(" Certifique-se de que o COBOL Analyzer está instalado:")
        print("   pip install cobol-to-docs")
        return None
    except Exception as e:
        print(f" Erro: {e}")
        return None

def exemplo_com_configuracao_personalizada():
    """Exemplo com configuração personalizada"""
    
    print("\n EXEMPLO 2: Configuração Personalizada")
    print("=" * 50)
    
    try:
        from src.core.config_enhanced import EnhancedConfigManager
        from src.providers.enhanced_provider_manager import EnhancedProviderManager
        
        # 1. Configuração personalizada
        config_personalizada = {
            'models': {
                'default': 'enhanced_mock',
                'enhanced_mock': {
                    'provider': 'enhanced_mock',
                    'model': 'enhanced-mock-gpt-4',
                    'enabled': True
                }
            },
            'analysis': {
                'depth': 'detailed',
                'include_comments': True,
                'include_business_rules': True
            }
        }
        
        print("⚙️ Usando configuração personalizada...")
        config_manager = EnhancedConfigManager()
        config_manager.config.update(config_personalizada)
        
        # 2. Analisar com configuração personalizada
        provider_manager = EnhancedProviderManager(config_manager.config)
        
        print(" Configuração personalizada aplicada!")
        print(f"🤖 Modelo padrão: {config_manager.config['models']['default']}")
        
        return config_manager
        
    except Exception as e:
        print(f" Erro: {e}")
        return None

def exemplo_analise_multiplos_programas():
    """Exemplo de análise de múltiplos programas"""
    
    print("\n EXEMPLO 3: Análise de Múltiplos Programas")
    print("=" * 50)
    
    try:
        from src.core.config_enhanced import EnhancedConfigManager
        from src.providers.enhanced_provider_manager import EnhancedProviderManager
        from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
        
        # Lista de programas para analisar
        programas = [
            {
                'nome': 'CALC-JUROS.CBL',
                'conteudo': '''
                IDENTIFICATION DIVISION.
                PROGRAM-ID. CALC-JUROS.
                DATA DIVISION.
                WORKING-STORAGE SECTION.
                01 WS-PRINCIPAL PIC 9(7)V99.
                01 WS-TAXA      PIC 9V999.
                01 WS-JUROS     PIC 9(7)V99.
                PROCEDURE DIVISION.
                    COMPUTE WS-JUROS = WS-PRINCIPAL * WS-TAXA.
                    STOP RUN.
                '''
            },
            {
                'nome': 'VALIDA-CPF.CBL',
                'conteudo': '''
                IDENTIFICATION DIVISION.
                PROGRAM-ID. VALIDA-CPF.
                DATA DIVISION.
                WORKING-STORAGE SECTION.
                01 WS-CPF       PIC 9(11).
                01 WS-VALIDO    PIC X VALUE 'N'.
                PROCEDURE DIVISION.
                    IF WS-CPF > 0
                        MOVE 'S' TO WS-VALIDO
                    END-IF.
                    STOP RUN.
                '''
            }
        ]
        
        # Configurar analisador
        config_manager = EnhancedConfigManager()
        provider_manager = EnhancedProviderManager(config_manager.config)
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, config_manager)
        
        resultados = []
        
        print(f" Analisando {len(programas)} programas...")
        
        for i, programa in enumerate(programas, 1):
            print(f" Analisando {programa['nome']} ({i}/{len(programas)})...")
            
            resultado = analyzer.analyze_program(
                program_content=programa['conteudo'],
                program_name=programa['nome']
            )
            
            resultados.append({
                'programa': programa['nome'],
                'resultado': resultado,
                'tamanho': len(resultado)
            })
            
            print(f" {programa['nome']} analisado - {len(resultado)} caracteres")
        
        print(f"\n Resumo da análise:")
        for resultado in resultados:
            print(f"   {resultado['programa']}: {resultado['tamanho']} caracteres")
        
        return resultados
        
    except Exception as e:
        print(f" Erro: {e}")
        return None

def exemplo_integracao_com_sistema():
    """Exemplo de integração com sistema existente"""
    
    print("\n EXEMPLO 4: Integração com Sistema")
    print("=" * 50)
    
    try:
        import json
        from datetime import datetime
        
        # Simular sistema existente
        sistema_dados = {
            'projeto': 'Sistema Bancário',
            'versao': '2.1.0',
            'programas': [
                '/sistema/cobol/CONTA-CORRENTE.CBL',
                '/sistema/cobol/CALC-SALDO.CBL',
                '/sistema/cobol/EXTRATO.CBL'
            ]
        }
        
        print(f"🏢 Integrando com: {sistema_dados['projeto']} v{sistema_dados['versao']}")
        
        # Função para processar programas do sistema
        def processar_programas_sistema(dados_sistema):
            """Processa programas de um sistema existente"""
            
            resultados_sistema = {
                'projeto': dados_sistema['projeto'],
                'versao': dados_sistema['versao'],
                'data_analise': datetime.now().isoformat(),
                'programas_analisados': [],
                'resumo': {
                    'total_programas': len(dados_sistema['programas']),
                    'total_documentacao': 0
                }
            }
            
            print(f" Processando {len(dados_sistema['programas'])} programas...")
            
            for programa_path in dados_sistema['programas']:
                programa_nome = Path(programa_path).name
                
                # Simular análise (em sistema real, leria o arquivo)
                print(f" Analisando {programa_nome}...")
                
                # Aqui você usaria o analisador real
                documentacao_simulada = f"Documentação gerada para {programa_nome}"
                
                resultado_programa = {
                    'nome': programa_nome,
                    'caminho': programa_path,
                    'documentacao': documentacao_simulada,
                    'tamanho_doc': len(documentacao_simulada)
                }
                
                resultados_sistema['programas_analisados'].append(resultado_programa)
                resultados_sistema['resumo']['total_documentacao'] += len(documentacao_simulada)
                
                print(f" {programa_nome} processado")
            
            return resultados_sistema
        
        # Processar sistema
        resultado_final = processar_programas_sistema(sistema_dados)
        
        # Salvar resultado
        arquivo_resultado = f"analise_{sistema_dados['projeto'].lower().replace(' ', '_')}.json"
        with open(arquivo_resultado, 'w', encoding='utf-8') as f:
            json.dump(resultado_final, f, indent=2, ensure_ascii=False)
        
        print(f"💾 Resultado salvo em: {arquivo_resultado}")
        print(f" Total de documentação gerada: {resultado_final['resumo']['total_documentacao']} caracteres")
        
        return resultado_final
        
    except Exception as e:
        print(f" Erro: {e}")
        return None

def exemplo_uso_com_api():
    """Exemplo de uso como API/serviço"""
    
    print("\n EXEMPLO 5: Uso como API/Serviço")
    print("=" * 50)
    
    try:
        # Simular classe de serviço
        class COBOLAnalyzerService:
            """Serviço de análise COBOL para integração"""
            
            def __init__(self):
                print(" Inicializando serviço COBOL Analyzer...")
                # Aqui você inicializaria os componentes reais
                self.initialized = True
                print(" Serviço inicializado")
            
            def analisar_programa(self, codigo_cobol, nome_programa=None):
                """Analisa um programa COBOL"""
                if not self.initialized:
                    raise Exception("Serviço não inicializado")
                
                print(f" Analisando programa: {nome_programa or 'sem nome'}")
                
                # Aqui você usaria o analisador real
                resultado = {
                    'programa': nome_programa,
                    'status': 'sucesso',
                    'documentacao': f"Documentação gerada para {nome_programa}",
                    'metadados': {
                        'linhas_codigo': len(codigo_cobol.split('\n')),
                        'tamanho_bytes': len(codigo_cobol.encode('utf-8'))
                    }
                }
                
                print(f" Análise concluída para {nome_programa}")
                return resultado
            
            def analisar_lote(self, programas):
                """Analisa múltiplos programas"""
                resultados = []
                
                print(f"📦 Processando lote de {len(programas)} programas...")
                
                for programa in programas:
                    resultado = self.analisar_programa(
                        programa['codigo'], 
                        programa['nome']
                    )
                    resultados.append(resultado)
                
                print(f" Lote processado: {len(resultados)} programas")
                return resultados
        
        # Usar o serviço
        servico = COBOLAnalyzerService()
        
        # Exemplo de uso
        programa_teste = {
            'nome': 'TESTE-API.CBL',
            'codigo': '''
            IDENTIFICATION DIVISION.
            PROGRAM-ID. TESTE-API.
            PROCEDURE DIVISION.
                DISPLAY 'TESTE VIA API'.
                STOP RUN.
            '''
        }
        
        resultado = servico.analisar_programa(
            programa_teste['codigo'], 
            programa_teste['nome']
        )
        
        print(f" Resultado da API:")
        print(f"   Status: {resultado['status']}")
        print(f"   Linhas: {resultado['metadados']['linhas_codigo']}")
        print(f"   Tamanho: {resultado['metadados']['tamanho_bytes']} bytes")
        
        return servico
        
    except Exception as e:
        print(f" Erro: {e}")
        return None

def main():
    """Função principal - executa todos os exemplos"""
    
    print(" COBOL ANALYZER - EXEMPLOS DE USO PROGRAMÁTICO")
    print("=" * 60)
    print("Após instalação via: pip install cobol-to-docs")
    print("=" * 60)
    
    # Verificar se está no diretório correto
    if not Path("src").exists():
        print("  Executando fora do diretório do projeto")
        print(" Para usar programaticamente após pip install:")
        print("   1. pip install cobol-to-docs")
        print("   2. cobol-to-docs --init  # Criar ambiente local")
        print("   3. Usar os exemplos abaixo")
        print()
    
    # Executar exemplos
    exemplos = [
        exemplo_basico,
        exemplo_com_configuracao_personalizada,
        exemplo_analise_multiplos_programas,
        exemplo_integracao_com_sistema,
        exemplo_uso_com_api
    ]
    
    resultados = []
    
    for exemplo in exemplos:
        try:
            resultado = exemplo()
            resultados.append(resultado)
        except Exception as e:
            print(f" Erro no exemplo {exemplo.__name__}: {e}")
            resultados.append(None)
    
    print("\n EXEMPLOS CONCLUÍDOS")
    print("=" * 30)
    print(f" Exemplos executados: {len(exemplos)}")
    print(f" Sucessos: {sum(1 for r in resultados if r is not None)}")
    print(f" Falhas: {sum(1 for r in resultados if r is None)}")
    
    print("\n PRÓXIMOS PASSOS:")
    print("1. Instale via: pip install cobol-to-docs")
    print("2. Inicialize: cobol-to-docs --init")
    print("3. Adapte os exemplos acima para seu uso")
    print("4. Integre com seus sistemas existentes")

if __name__ == "__main__":
    main()
