# COBOL Analyzer v3.1.0 - Script de Instalação PowerShell

Write-Host "==========================================" -ForegroundColor Green
Write-Host "COBOL Analyzer v3.1.0 - Instalação" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Green

# Verificar Python
Write-Host "Verificando Python..." -ForegroundColor Yellow
try {
    $pythonVersion = python --version 2>&1
    Write-Host "Python encontrado: $pythonVersion" -ForegroundColor Green
} catch {
    Write-Host "ERRO: Python não encontrado. Instale Python 3.8 ou superior." -ForegroundColor Red
    Read-Host "Pressione Enter para sair"
    exit 1
}

# Verificar pip
Write-Host "Verificando pip..." -ForegroundColor Yellow
try {
    $pipVersion = pip --version 2>&1
    Write-Host "pip encontrado: $pipVersion" -ForegroundColor Green
} catch {
    Write-Host "ERRO: pip não encontrado. Instale pip para Python." -ForegroundColor Red
    Read-Host "Pressione Enter para sair"
    exit 1
}

# Instalar dependências
Write-Host "Instalando dependências..." -ForegroundColor Yellow
try {
    pip install -r requirements.txt
    Write-Host "Dependências instaladas com sucesso!" -ForegroundColor Green
} catch {
    Write-Host "ERRO: Falha ao instalar dependências." -ForegroundColor Red
    Read-Host "Pressione Enter para sair"
    exit 1
}

# Instalar COBOL Analyzer
Write-Host "Instalando COBOL Analyzer..." -ForegroundColor Yellow
try {
    pip install .
    Write-Host "COBOL Analyzer instalado com sucesso!" -ForegroundColor Green
} catch {
    Write-Host "ERRO: Falha ao instalar COBOL Analyzer." -ForegroundColor Red
    Read-Host "Pressione Enter para sair"
    exit 1
}

# Verificar instalação
Write-Host "Verificando instalação..." -ForegroundColor Yellow
try {
    cobol-to-docs --help | Out-Null
    Write-Host "SUCESSO: COBOL Analyzer instalado e funcionando!" -ForegroundColor Green
} catch {
    Write-Host "ERRO: Instalação falhou. Comando cobol-to-docs não encontrado." -ForegroundColor Red
    Read-Host "Pressione Enter para sair"
    exit 1
}

Write-Host ""
Write-Host "Para começar a usar:" -ForegroundColor Cyan
Write-Host "1. Execute: cobol-to-docs --init" -ForegroundColor White
Write-Host "2. Configure suas credenciais de IA" -ForegroundColor White
Write-Host "3. Execute: cobol-to-docs --fontes seus_programas.txt --models luzia" -ForegroundColor White
Write-Host ""
Write-Host "Para mais informações, consulte docs\README.md" -ForegroundColor White

Write-Host "==========================================" -ForegroundColor Green
Write-Host "Instalação concluída com sucesso!" -ForegroundColor Green
Write-Host "==========================================" -ForegroundColor Green

Read-Host "Pressione Enter para finalizar"
