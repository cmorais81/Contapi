"""
COBOL AI Engine v3.0.0 - Enhanced Provider Manager
Gerenciador aprimorado de provedores com suporte a múltiplos modelos e configurações específicas.
"""

import logging
import time
from typing import Dict, List, Any, Optional
try:
    from .base_provider import BaseProvider, AIRequest, AIResponse
    from .luzia_provider import LuziaProvider
    from .enhanced_mock_provider import EnhancedMockProvider
    from .basic_provider import BasicProvider
    from .databricks_provider import DatabricksProvider
    from .bedrock_provider import BedrockProvider
    from .openai_provider import OpenAIProvider
    from .github_copilot_provider import GitHubCopilotProvider
except ImportError:
    from base_provider import BaseProvider, AIRequest, AIResponse
    from luzia_provider import LuziaProvider
    from enhanced_mock_provider import EnhancedMockProvider
    from basic_provider import BasicProvider
    from databricks_provider import DatabricksProvider
    from bedrock_provider import BedrockProvider
    from openai_provider import OpenAIProvider
    from github_copilot_provider import GitHubCopilotProvider


class EnhancedProviderManager:
    """
    Gerenciador aprimorado de provedores de IA com suporte a múltiplos modelos
    e configurações específicas por modelo.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o gerenciador aprimorado de provedores."""
        self.logger = logging.getLogger(__name__)
        self.config = config
        self.providers: Dict[str, BaseProvider] = {}
        self.model_configurations: Dict[str, Dict[str, Any]] = {}
        self.statistics: Dict[str, Dict[str, Any]] = {}
        
        # Configuração de provedores
        ai_config = config.get('ai', {})
        self.primary_provider = ai_config.get('primary_provider', 'enhanced_mock')
        self.fallback_providers = ai_config.get('fallback_providers', ['basic'])
        
        # Configurações específicas por modelo (será preenchido durante inicialização)
        self.model_configurations = {}
        
        # Inicializar provedores
        self._initialize_providers(ai_config)
        
        self.logger.info(f"Enhanced Provider Manager inicializado - Primário: {self.primary_provider}")
        self.logger.info(f"Modelos configurados: {list(self.model_configurations.keys())}")
    
    def _initialize_providers(self, ai_config: Dict[str, Any]) -> None:
        """Inicializa todos os provedores disponíveis com configurações específicas."""
        # A configuração de providers está no nível raiz, não dentro de 'ai'
        providers_config = self.config.get('providers', {})
        
        # Provedores disponíveis
        available_providers = {
            'luzia': LuziaProvider,
            'enhanced_mock': EnhancedMockProvider,
            'basic': BasicProvider,
            'databricks': DatabricksProvider,
            'bedrock': BedrockProvider,
            'openai': OpenAIProvider,
            'github_copilot': GitHubCopilotProvider
        }
        
        for provider_name, provider_class in available_providers.items():
            try:
                provider_config = providers_config.get(provider_name, {})
                
                # Verificar se provider está habilitado
                is_enabled = provider_config.get('enabled', False)
                is_fallback = provider_name in ['enhanced_mock', 'basic']
                
                # Log do status do provider
                if is_enabled:
                    self.logger.info(f"Tentando inicializar provider {provider_name} (habilitado na configuração)")
                elif is_fallback:
                    self.logger.info(f"Inicializando provider {provider_name} (fallback obrigatório)")
                else:
                    self.logger.info(f"Pulando provider {provider_name} (desabilitado na configuração)")
                    continue
                
                if is_enabled or is_fallback:
                    # Verificar credenciais para providers que precisam
                    if provider_name in ['luzia']:
                        import os
                        client_id = os.getenv('LUZIA_CLIENT_ID')
                        client_secret = os.getenv('LUZIA_CLIENT_SECRET')
                        
                        if not client_id or not client_secret:
                            self.logger.warning(f"Provider {provider_name} habilitado mas credenciais não encontradas")
                            self.logger.warning(f"   LUZIA_CLIENT_ID: {'Definido' if client_id else 'Não definido'}")
                            self.logger.warning(f"   LUZIA_CLIENT_SECRET: {'Definido' if client_secret else 'Não definido'}")
                            self.logger.warning(f"   Provider {provider_name} será inicializado mas ficará indisponível")
                            # Não fazer continue - permitir inicialização
                        else:
                            self.logger.info(f"Credenciais LuzIA encontradas - inicializando provider {provider_name}")
                    
                    # Aplicar configurações específicas do modelo se disponível
                    enhanced_config = self._apply_model_specific_config(provider_name, provider_config)
                    provider = provider_class(enhanced_config)
                    self.providers[provider_name] = provider
                    
                    # Carregar modelos do provider
                    self._load_provider_models(provider_name, provider_config)
                    
                    # Inicializar estatísticas
                    self._initialize_provider_statistics(provider_name)
                    
                    self.logger.info(f"Provider {provider_name} inicializado com sucesso")
                    
            except Exception as e:
                self.logger.error(f"ERRO ao inicializar provider {provider_name}: {str(e)}")
    
    def _load_provider_models(self, provider_name: str, provider_config: Dict[str, Any]) -> None:
        """Carrega os modelos de um provider para model_configurations."""
        models = provider_config.get('models', {})
        
        for model_key, model_config in models.items():
            # Usar o nome do modelo da configuração ou o key como fallback
            model_name = model_config.get('name', model_key)
            
            # Adicionar informações do provider ao modelo
            full_model_config = {
                'provider': provider_name,
                'name': model_name,
                **model_config
            }
            
            self.model_configurations[model_name] = full_model_config
            self.logger.info(f"Modelo {model_name} carregado do provider {provider_name}")
    
    def _initialize_provider_statistics(self, provider_name: str) -> None:
        """Inicializa estatísticas para um provider."""
        self.statistics[provider_name] = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'total_tokens': 0,
            'average_response_time': 0.0,
            'last_request_time': None,
            'consecutive_failures': 0,
            'model_specific_stats': {}
        }
    
    def _apply_model_specific_config(self, provider_name: str, provider_config: Dict[str, Any]) -> Dict[str, Any]:
        """Aplica configurações específicas do modelo ao provedor."""
        enhanced_config = provider_config.copy()
        
        # Verificar se há configurações específicas para este provedor
        for model_name, model_config in self.model_configurations.items():
            if model_config.get('provider') == provider_name:
                # Mesclar configurações específicas do modelo
                enhanced_config.update(model_config.get('config', {}))
                self.logger.info(f"Configurações do modelo {model_name} aplicadas ao provedor {provider_name}")
        
        return enhanced_config
    
    def analyze_with_model(self, model_name: str, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando um modelo específico SEM FALLBACK.
        Se o modelo falhar, retorna erro ao invés de tentar outros providers.
        """
        self.logger.info(f"*** ANÁLISE COM MODELO ESPECÍFICO: {model_name} (SEM FALLBACK) ***")
        
        # Mapear nomes de providers para modelos padrão
        provider_to_default_model = {
            'luzia': 'aws-claude-3-5-sonnet',
            'enhanced_mock': 'enhanced-mock-gpt-4',
            'openai': 'gpt-4',
            'bedrock': 'claude-3-sonnet'
        }
        
        # Se o modelo solicitado é um nome de provider, usar o modelo padrão
        if model_name in provider_to_default_model:
            actual_model = provider_to_default_model[model_name]
            self.logger.info(f"Mapeando provider '{model_name}' para modelo '{actual_model}'")
        else:
            actual_model = model_name
        
        # Verificar se o modelo está configurado
        if actual_model not in self.model_configurations:
            error_msg = f"Modelo {actual_model} não está configurado no sistema"
            self.logger.error(error_msg)
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=actual_model,
                provider="none",
                error_message=error_msg
            )
        
        model_config = self.model_configurations[actual_model]
        provider_name = model_config.get('provider', self.primary_provider)
        
        # Verificar se o provedor está disponível
        if provider_name not in self.providers:
            error_msg = f"Provider {provider_name} para modelo {actual_model} não está disponível"
            self.logger.error(error_msg)
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=actual_model,
                provider=provider_name,
                error_message=error_msg
            )
        
        # Aplicar configurações específicas do modelo ao request
        enhanced_request = self._enhance_request_for_model(request, model_config)
        
        # Executar análise APENAS com o provider solicitado
        self.logger.info(f"Executando análise EXCLUSIVAMENTE com {provider_name} para modelo {actual_model}")
        response = self._try_provider(provider_name, enhanced_request)
        
        # Se falhar, NÃO fazer fallback - retornar o erro
        if not response.success:
            self.logger.error(f"*** FALHA NO MODELO ESPECÍFICO {actual_model} (solicitado como {model_name}) ***")
            self.logger.error(f"Provider: {provider_name}")
            self.logger.error(f"Erro: {response.error_message}")
            self.logger.error("*** NÃO SERÁ FEITO FALLBACK - MODELO ESPECÍFICO SOLICITADO ***")
        
        # Atualizar estatísticas específicas do modelo
        self._update_model_statistics(provider_name, actual_model, response)
        
        return response
    
    def _enhance_request_for_model(self, request: AIRequest, model_config: Dict[str, Any]) -> AIRequest:
        """Aplica configurações específicas do modelo ao request."""
        enhanced_request = AIRequest(
            prompt=request.prompt,
            program_name=request.program_name,
            program_code=request.program_code,
            context=request.context.copy() if request.context else {}
        )
        
        # Aplicar configurações específicas do modelo
        model_settings = model_config.get('settings', {})
        
        # Atualizar configurações no contexto
        enhanced_request.context['model_settings'] = model_settings
        enhanced_request.context['model_name'] = model_config.get('name', 'unknown')
        
        return enhanced_request
    
    def get_available_models(self) -> List[str]:
        """Retorna lista de modelos disponíveis."""
        available_models = []
        
        for model_name, model_config in self.model_configurations.items():
            provider_name = model_config.get('provider')
            if provider_name in self.providers:
                try:
                    if self.providers[provider_name].is_available():
                        available_models.append(model_name)
                except Exception as e:
                    self.logger.error(f"Erro ao verificar disponibilidade do modelo {model_name}: {e}")
        
        return available_models
    
    def get_model_info(self, model_name: str) -> Dict[str, Any]:
        """Retorna informações detalhadas sobre um modelo."""
        if model_name not in self.model_configurations:
            return {}
        
        model_config = self.model_configurations[model_name]
        provider_name = model_config.get('provider')
        
        info = {
            'name': model_name,
            'provider': provider_name,
            'description': model_config.get('description', ''),
            'capabilities': model_config.get('capabilities', []),
            'settings': model_config.get('settings', {}),
            'available': False
        }
        
        # Verificar disponibilidade
        if provider_name in self.providers:
            try:
                info['available'] = self.providers[provider_name].is_available()
            except Exception:
                info['available'] = False
        
        return info
    
    def get_model_statistics(self, model_name: str) -> Dict[str, Any]:
        """Retorna estatísticas específicas de um modelo."""
        if model_name not in self.model_configurations:
            return {}
        
        model_config = self.model_configurations[model_name]
        provider_name = model_config.get('provider')
        
        if provider_name not in self.statistics:
            return {}
        
        provider_stats = self.statistics[provider_name]
        model_stats = provider_stats.get('model_specific_stats', {}).get(model_name, {})
        
        return {
            'model_name': model_name,
            'provider': provider_name,
            'requests': model_stats.get('requests', 0),
            'successful_requests': model_stats.get('successful_requests', 0),
            'failed_requests': model_stats.get('failed_requests', 0),
            'total_tokens': model_stats.get('total_tokens', 0),
            'average_response_time': model_stats.get('average_response_time', 0.0)
        }
    
    def _update_model_statistics(self, provider_name: str, model_name: str, response: AIResponse) -> None:
        """Atualiza estatísticas específicas do modelo."""
        if provider_name not in self.statistics:
            return
        
        provider_stats = self.statistics[provider_name]
        
        if 'model_specific_stats' not in provider_stats:
            provider_stats['model_specific_stats'] = {}
        
        if model_name not in provider_stats['model_specific_stats']:
            provider_stats['model_specific_stats'][model_name] = {
                'requests': 0,
                'successful_requests': 0,
                'failed_requests': 0,
                'total_tokens': 0,
                'average_response_time': 0.0
            }
        
        model_stats = provider_stats['model_specific_stats'][model_name]
        model_stats['requests'] += 1
        
        if response.success:
            model_stats['successful_requests'] += 1
            model_stats['total_tokens'] += response.tokens_used
        else:
            model_stats['failed_requests'] += 1
    
    def get_system_status_enhanced(self) -> Dict[str, Any]:
        """Retorna status completo do sistema incluindo informações de modelos."""
        base_status = self.get_system_status()
        
        # Adicionar informações de modelos
        model_status = {}
        for model_name in self.model_configurations.keys():
            model_status[model_name] = {
                'info': self.get_model_info(model_name),
                'statistics': self.get_model_statistics(model_name)
            }
        
        base_status['models'] = model_status
        base_status['available_models'] = self.get_available_models()
        
        return base_status
    
    # Herdar métodos da classe base
    def get_available_providers(self) -> List[str]:
        """Retorna lista de provedores disponíveis."""
        available = []
        for name, provider in self.providers.items():
            try:
                if provider.is_available():
                    available.append(name)
            except Exception as e:
                self.logger.error(f"Erro ao verificar disponibilidade do {name}: {e}")
        return available
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """Realiza análise usando o sistema de fallback."""
        self.logger.info(f"Iniciando análise com provider primário: {self.primary_provider}")
        
        # Tentar provedor primário primeiro
        if self.primary_provider in self.providers:
            self.logger.info(f"Tentando provider primário: {self.primary_provider}")
            response = self._try_provider(self.primary_provider, request)
            if response.success:
                self.logger.info(f"Análise bem-sucedida com {self.primary_provider} - Tokens: {response.tokens_used}")
                return response
            else:
                self.logger.warning(f"Falha no provider primário {self.primary_provider}: {response.error_message}")
        else:
            self.logger.error(f"Provider primário {self.primary_provider} não disponível")
            self.logger.error(f"Providers disponíveis: {list(self.providers.keys())}")
        
        # Tentar provedores de fallback
        self.logger.info(f"Tentando providers de fallback: {self.fallback_providers}")
        for fallback_provider in self.fallback_providers:
            if fallback_provider in self.providers:
                self.logger.info(f"Tentando fallback: {fallback_provider}")
                response = self._try_provider(fallback_provider, request)
                if response.success:
                    self.logger.info(f"Análise bem-sucedida com fallback {fallback_provider} - Tokens: {response.tokens_used}")
                    return response
                else:
                    self.logger.warning(f"Falha no fallback {fallback_provider}: {response.error_message}")
            else:
                self.logger.warning(f"Fallback {fallback_provider} não disponível")
        
        # Se todos falharam, retornar erro
        self.logger.error("TODOS OS PROVEDORES FALHARAM - Análise não pôde ser concluída")
        return AIResponse(
            success=False,
            content="",
            tokens_used=0,
            model="none",
            provider="none",
            error_message="Todos os provedores falharam"
        )
    
    def get_system_status(self) -> Dict[str, Any]:
        """Retorna status completo do sistema."""
        available_providers = self.get_available_providers()
        
        provider_details = {}
        for provider_name in self.providers.keys():
            provider_details[provider_name] = self.get_provider_status(provider_name)
        
        return {
            'total_providers': len(self.providers),
            'available_providers': len(available_providers),
            'primary_provider': self.primary_provider,
            'primary_available': self.primary_provider in available_providers,
            'fallback_providers': self.fallback_providers,
            'provider_details': provider_details,
            'timestamp': time.time()
        }
    
    def get_provider_status(self, provider_name: str) -> Dict[str, Any]:
        """Retorna status detalhado de um provedor."""
        if provider_name not in self.providers:
            return {
                'available': False,
                'error': f'Provedor {provider_name} não encontrado'
            }
        
        try:
            provider = self.providers[provider_name]
            stats = self.statistics.get(provider_name, {})
            
            return {
                'available': provider.is_available(),
                'enabled': getattr(provider, 'enabled', True),
                'model': getattr(provider, 'model', 'unknown'),
                'statistics': stats,
                'last_health_check': time.time()
            }
        except Exception as e:
            return {
                'available': False,
                'error': str(e)
            }
    
    def _try_provider(self, provider_name: str, request: AIRequest) -> AIResponse:
        """Tenta executar análise com um provedor específico."""
        try:
            provider = self.providers[provider_name]
            
            # Log detalhado do início
            self.logger.info(f"Executando análise com {provider_name}")
            self.logger.debug(f"Request: {len(request.prompt)} caracteres")
            
            # Atualizar estatísticas
            start_time = time.time()
            
            # Executar análise
            response = provider.analyze(request)
            
            # Calcular tempo de execução
            execution_time = time.time() - start_time
            
            # Log detalhado do resultado
            if response.success:
                self.logger.info(f"{provider_name} respondeu em {execution_time:.2f}s - {response.tokens_used} tokens")
                self.logger.debug(f"Resposta: {len(response.content)} caracteres")
            else:
                self.logger.error(f"{provider_name} falhou em {execution_time:.2f}s: {response.error_message}")
            
            # Atualizar estatísticas do provedor
            self._update_provider_statistics(provider_name, response, execution_time, True)
            
            return response
            
        except Exception as e:
            self.logger.error(f"ERRO CRÍTICO ao executar análise com {provider_name}: {e}")
            
            # Atualizar estatísticas de erro
            self._update_provider_statistics(provider_name, None, 0, False)
            
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model="unknown",
                provider=provider_name,
                error_message=str(e)
            )    
    def _update_provider_statistics(self, provider_name: str, response: Optional[AIResponse], 
                                  response_time: float, success: bool) -> None:
        """Atualiza estatísticas do provedor."""
        if provider_name not in self.statistics:
            return
        
        stats = self.statistics[provider_name]
        
        stats['total_requests'] += 1
        stats['last_request_time'] = time.time()
        
        if success:
            stats['successful_requests'] += 1
            stats['consecutive_failures'] = 0
            if response:
                stats['total_tokens'] += response.tokens_used
        else:
            stats['failed_requests'] += 1
            stats['consecutive_failures'] += 1
        
        # Atualizar tempo médio de resposta
        total_requests = stats['total_requests']
        current_avg = stats['average_response_time']
        stats['average_response_time'] = ((current_avg * (total_requests - 1)) + response_time) / total_requests
