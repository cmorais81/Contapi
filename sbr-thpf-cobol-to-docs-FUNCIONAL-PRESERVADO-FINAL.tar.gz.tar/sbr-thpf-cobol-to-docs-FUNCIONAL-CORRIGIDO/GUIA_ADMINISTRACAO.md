# Guia de Administração - COBOL Analyzer v3.1.0

## Visão Geral

Este guia destina-se a administradores de sistema responsáveis pela instalação, configuração e manutenção do COBOL Analyzer em ambiente corporativo. Aborda aspectos de segurança, performance, monitoramento e manutenção da ferramenta.

## Instalação Corporativa

### Ambiente de Produção

#### Requisitos de Infraestrutura

**Servidor de Aplicação:**
- CPU: 8 cores ou superior
- RAM: 16GB mínimo, 32GB recomendado
- Armazenamento: 50GB SSD para aplicação e dados
- Sistema Operacional: Linux (Ubuntu 20.04+ ou CentOS 8+)
- Python: 3.9 ou superior

**Conectividade:**
- Acesso HTTPS para provedores de IA
- Conectividade com sistemas de autenticação corporativa
- Acesso a repositórios de código COBOL
- Conectividade com sistemas de logging centralizados

#### Instalação em Ambiente Corporativo

```bash
# Criar usuário dedicado
sudo useradd -m -s /bin/bash cobol-analyzer
sudo usermod -aG sudo cobol-analyzer

# Configurar ambiente Python
sudo apt update
sudo apt install python3.9 python3.9-venv python3.9-dev
sudo -u cobol-analyzer python3.9 -m venv /home/cobol-analyzer/venv

# Instalar aplicação
sudo -u cobol-analyzer /home/cobol-analyzer/venv/bin/pip install -r requirements.txt
sudo -u cobol-analyzer /home/cobol-analyzer/venv/bin/pip install .
```

#### Configuração de Serviço Systemd

```ini
# /etc/systemd/system/cobol-analyzer.service
[Unit]
Description=COBOL Analyzer Service
After=network.target

[Service]
Type=simple
User=cobol-analyzer
Group=cobol-analyzer
WorkingDirectory=/home/cobol-analyzer
Environment=PATH=/home/cobol-analyzer/venv/bin
ExecStart=/home/cobol-analyzer/venv/bin/python /home/cobol-analyzer/runner/main.py --daemon
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### Configuração de Segurança

#### Controle de Acesso

**Permissões de Arquivo:**
```bash
# Configurar permissões restritivas
chmod 750 /home/cobol-analyzer
chmod 640 /home/cobol-analyzer/config/*.yaml
chmod 600 /home/cobol-analyzer/config/credentials.yaml
```

**Configuração de Firewall:**
```bash
# Permitir apenas conexões necessárias
sudo ufw allow from 10.0.0.0/8 to any port 22
sudo ufw allow out 443
sudo ufw enable
```

#### Gestão de Credenciais

**Arquivo de Credenciais Seguro:**
```yaml
# /home/cobol-analyzer/config/credentials.yaml
providers:
  luzia:
    client_id: "${LUZIA_CLIENT_ID}"
    client_secret: "${LUZIA_CLIENT_SECRET}"
  
  openai:
    api_key: "${OPENAI_API_KEY}"
  
  github_copilot:
    token: "${GITHUB_TOKEN}"
```

**Variáveis de Ambiente Seguras:**
```bash
# /home/cobol-analyzer/.env
LUZIA_CLIENT_ID=valor_seguro
LUZIA_CLIENT_SECRET=valor_seguro
OPENAI_API_KEY=valor_seguro
GITHUB_TOKEN=valor_seguro
```

#### Auditoria e Logging

**Configuração de Logging Avançado:**
```yaml
# config/logging.yaml
version: 1
formatters:
  detailed:
    format: '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    
handlers:
  file:
    class: logging.handlers.RotatingFileHandler
    filename: /var/log/cobol-analyzer/application.log
    maxBytes: 10485760  # 10MB
    backupCount: 5
    formatter: detailed
    
  syslog:
    class: logging.handlers.SysLogHandler
    address: /dev/log
    formatter: detailed
    
loggers:
  cobol_analyzer:
    level: INFO
    handlers: [file, syslog]
```

## Configuração Avançada

### Otimização de Performance

#### Configuração de Cache

```yaml
# config/cache.yaml
cache:
  embeddings:
    enabled: true
    max_size: 1000
    ttl: 86400  # 24 horas
    
  responses:
    enabled: true
    max_size: 500
    ttl: 3600   # 1 hora
    
  knowledge_base:
    preload: true
    refresh_interval: 3600
```

#### Configuração de Pool de Conexões

```yaml
# config/performance.yaml
performance:
  max_concurrent_requests: 10
  request_timeout: 300
  retry_attempts: 3
  retry_delay: 5
  
  providers:
    luzia:
      max_connections: 5
      connection_timeout: 30
      
    openai:
      max_connections: 3
      connection_timeout: 60
```

### Configuração de Provedores

#### Luzia (Santander)

```yaml
# config/providers/luzia.yaml
luzia:
  enabled: true
  endpoint: "https://api.luzia.santander.com.br"
  model: "aws-claude-3-5-sonnet"
  max_tokens: 32000
  temperature: 0.1
  
  authentication:
    type: "oauth2"
    client_id: "${LUZIA_CLIENT_ID}"
    client_secret: "${LUZIA_CLIENT_SECRET}"
    scope: "cobol-analysis"
    
  rate_limiting:
    requests_per_minute: 60
    tokens_per_minute: 100000
    
  retry_policy:
    max_attempts: 3
    backoff_factor: 2
```

#### OpenAI

```yaml
# config/providers/openai.yaml
openai:
  enabled: true
  api_key: "${OPENAI_API_KEY}"
  model: "gpt-4"
  max_tokens: 8000
  temperature: 0.1
  
  rate_limiting:
    requests_per_minute: 20
    tokens_per_minute: 40000
    
  cost_control:
    max_cost_per_hour: 50.00
    alert_threshold: 80
```

### Sistema RAG Avançado

#### Configuração da Base de Conhecimento

```yaml
# config/rag_advanced.yaml
rag:
  knowledge_base:
    primary: "data/cobol_knowledge_base.json"
    secondary: "data/cobol_patterns.json"
    custom: "data/company_standards.json"
    
  embeddings:
    model: "sentence-transformers/all-MiniLM-L6-v2"
    cache_path: "data/embeddings_cache.pkl"
    batch_size: 32
    
  retrieval:
    max_items: 10
    similarity_threshold: 0.7
    diversity_threshold: 0.3
    
  enhancement:
    auto_learning: true
    feedback_integration: true
    quality_scoring: true
```

#### Atualização Automática da Base

```bash
#!/bin/bash
# /home/cobol-analyzer/scripts/update_knowledge_base.sh

# Backup da base atual
cp data/cobol_knowledge_base.json data/backup/cobol_knowledge_base_$(date +%Y%m%d).json

# Atualizar base com novos padrões
python scripts/knowledge_base_updater.py \
  --source /path/to/new/patterns \
  --output data/cobol_knowledge_base.json \
  --merge

# Recriar cache de embeddings
rm data/embeddings_cache.pkl
python scripts/rebuild_embeddings.py
```

## Monitoramento e Alertas

### Métricas de Sistema

#### Métricas de Performance

```python
# scripts/metrics_collector.py
import psutil
import json
from datetime import datetime

def collect_system_metrics():
    return {
        'timestamp': datetime.now().isoformat(),
        'cpu_usage': psutil.cpu_percent(),
        'memory_usage': psutil.virtual_memory().percent,
        'disk_usage': psutil.disk_usage('/').percent,
        'network_io': psutil.net_io_counters()._asdict()
    }

def collect_application_metrics():
    # Métricas específicas da aplicação
    return {
        'active_analyses': get_active_analyses_count(),
        'queue_size': get_analysis_queue_size(),
        'success_rate': get_success_rate_last_hour(),
        'average_processing_time': get_avg_processing_time()
    }
```

#### Dashboard de Monitoramento

```yaml
# config/monitoring.yaml
monitoring:
  enabled: true
  interval: 60  # segundos
  
  metrics:
    system:
      - cpu_usage
      - memory_usage
      - disk_usage
      
    application:
      - analyses_per_hour
      - success_rate
      - error_rate
      - processing_time
      
  alerts:
    cpu_threshold: 80
    memory_threshold: 85
    error_rate_threshold: 5
    
  notifications:
    email: admin@empresa.com
    slack_webhook: "${SLACK_WEBHOOK_URL}"
```

### Logs e Auditoria

#### Configuração de Logs Estruturados

```python
# config/logging_config.py
import logging
import json
from datetime import datetime

class StructuredFormatter(logging.Formatter):
    def format(self, record):
        log_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }
        
        if hasattr(record, 'user_id'):
            log_entry['user_id'] = record.user_id
            
        if hasattr(record, 'analysis_id'):
            log_entry['analysis_id'] = record.analysis_id
            
        return json.dumps(log_entry)
```

#### Auditoria de Análises

```python
# scripts/audit_logger.py
def log_analysis_start(user_id, files, models):
    audit_logger.info(
        "Analysis started",
        extra={
            'user_id': user_id,
            'file_count': len(files),
            'models': models,
            'event_type': 'analysis_start'
        }
    )

def log_analysis_complete(analysis_id, success_count, total_count, duration):
    audit_logger.info(
        "Analysis completed",
        extra={
            'analysis_id': analysis_id,
            'success_count': success_count,
            'total_count': total_count,
            'duration_seconds': duration,
            'event_type': 'analysis_complete'
        }
    )
```

## Backup e Recuperação

### Estratégia de Backup

#### Backup Automático

```bash
#!/bin/bash
# /home/cobol-analyzer/scripts/backup.sh

BACKUP_DIR="/backup/cobol-analyzer"
DATE=$(date +%Y%m%d_%H%M%S)

# Criar diretório de backup
mkdir -p "$BACKUP_DIR/$DATE"

# Backup de configurações
tar -czf "$BACKUP_DIR/$DATE/config.tar.gz" config/

# Backup de dados
tar -czf "$BACKUP_DIR/$DATE/data.tar.gz" data/

# Backup de logs (últimos 7 dias)
find logs/ -name "*.log" -mtime -7 | tar -czf "$BACKUP_DIR/$DATE/logs.tar.gz" -T -

# Backup de base de conhecimento
cp data/cobol_knowledge_base.json "$BACKUP_DIR/$DATE/"

# Limpeza de backups antigos (manter 30 dias)
find "$BACKUP_DIR" -type d -mtime +30 -exec rm -rf {} \;
```

#### Configuração de Cron

```bash
# Adicionar ao crontab do usuário cobol-analyzer
0 2 * * * /home/cobol-analyzer/scripts/backup.sh
0 6 * * 0 /home/cobol-analyzer/scripts/weekly_maintenance.sh
```

### Procedimentos de Recuperação

#### Recuperação de Configuração

```bash
#!/bin/bash
# scripts/restore_config.sh

BACKUP_DATE=$1
BACKUP_DIR="/backup/cobol-analyzer/$BACKUP_DATE"

if [ -f "$BACKUP_DIR/config.tar.gz" ]; then
    # Backup da configuração atual
    mv config config.backup.$(date +%Y%m%d_%H%M%S)
    
    # Restaurar configuração
    tar -xzf "$BACKUP_DIR/config.tar.gz"
    
    echo "Configuração restaurada de $BACKUP_DATE"
else
    echo "Backup não encontrado: $BACKUP_DIR/config.tar.gz"
    exit 1
fi
```

#### Recuperação de Dados

```bash
#!/bin/bash
# scripts/restore_data.sh

BACKUP_DATE=$1
BACKUP_DIR="/backup/cobol-analyzer/$BACKUP_DATE"

# Parar serviço
sudo systemctl stop cobol-analyzer

# Backup dos dados atuais
mv data data.backup.$(date +%Y%m%d_%H%M%S)

# Restaurar dados
tar -xzf "$BACKUP_DIR/data.tar.gz"

# Reiniciar serviço
sudo systemctl start cobol-analyzer
```

## Manutenção

### Manutenção Preventiva

#### Script de Manutenção Semanal

```bash
#!/bin/bash
# scripts/weekly_maintenance.sh

echo "Iniciando manutenção semanal..."

# Limpeza de logs antigos
find logs/ -name "*.log" -mtime +30 -delete
find logs/ -name "rag_*.json" -mtime +7 -delete

# Limpeza de cache
find temp/ -type f -mtime +1 -delete

# Otimização da base de conhecimento
python scripts/optimize_knowledge_base.py

# Verificação de integridade
python scripts/integrity_check.py

# Atualização de estatísticas
python scripts/update_statistics.py

echo "Manutenção semanal concluída."
```

#### Verificação de Integridade

```python
# scripts/integrity_check.py
import json
import os
from pathlib import Path

def check_config_integrity():
    """Verifica integridade dos arquivos de configuração"""
    config_files = [
        'config/config.yaml',
        'config/providers.yaml',
        'config/rag.yaml'
    ]
    
    for config_file in config_files:
        if not os.path.exists(config_file):
            print(f"ERRO: Arquivo de configuração ausente: {config_file}")
            return False
            
    return True

def check_knowledge_base_integrity():
    """Verifica integridade da base de conhecimento"""
    kb_file = 'data/cobol_knowledge_base.json'
    
    try:
        with open(kb_file, 'r') as f:
            data = json.load(f)
            
        if not isinstance(data, list):
            print("ERRO: Base de conhecimento com formato inválido")
            return False
            
        print(f"Base de conhecimento OK: {len(data)} itens")
        return True
        
    except Exception as e:
        print(f"ERRO: Falha ao verificar base de conhecimento: {e}")
        return False

if __name__ == "__main__":
    config_ok = check_config_integrity()
    kb_ok = check_knowledge_base_integrity()
    
    if config_ok and kb_ok:
        print("Verificação de integridade: SUCESSO")
        exit(0)
    else:
        print("Verificação de integridade: FALHA")
        exit(1)
```

### Atualizações

#### Processo de Atualização

```bash
#!/bin/bash
# scripts/update_system.sh

VERSION=$1

if [ -z "$VERSION" ]; then
    echo "Uso: $0 <versão>"
    exit 1
fi

echo "Atualizando para versão $VERSION..."

# Backup completo antes da atualização
./scripts/backup.sh

# Parar serviço
sudo systemctl stop cobol-analyzer

# Backup da instalação atual
mv /home/cobol-analyzer/app /home/cobol-analyzer/app.backup.$(date +%Y%m%d)

# Instalar nova versão
tar -xzf "releases/COBOL_ANALYZER_v${VERSION}.tar.gz" -C /home/cobol-analyzer/
mv "/home/cobol-analyzer/sbr-thpf-cobol-to-docs" "/home/cobol-analyzer/app"

# Instalar dependências
cd /home/cobol-analyzer/app
/home/cobol-analyzer/venv/bin/pip install -r requirements.txt
/home/cobol-analyzer/venv/bin/pip install . --upgrade

# Migrar configurações se necessário
python scripts/migrate_config.py

# Reiniciar serviço
sudo systemctl start cobol-analyzer

# Verificar funcionamento
sleep 10
python scripts/health_check.py

echo "Atualização para versão $VERSION concluída."
```

## Troubleshooting Avançado

### Diagnóstico de Performance

#### Script de Diagnóstico

```python
# scripts/performance_diagnostic.py
import psutil
import time
import json

def diagnose_performance():
    """Executa diagnóstico completo de performance"""
    
    # CPU
    cpu_percent = psutil.cpu_percent(interval=1)
    cpu_count = psutil.cpu_count()
    
    # Memória
    memory = psutil.virtual_memory()
    
    # Disco
    disk = psutil.disk_usage('/')
    
    # Rede
    network = psutil.net_io_counters()
    
    # Processos
    processes = []
    for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
        if 'python' in proc.info['name'].lower():
            processes.append(proc.info)
    
    report = {
        'timestamp': time.time(),
        'cpu': {
            'usage_percent': cpu_percent,
            'core_count': cpu_count
        },
        'memory': {
            'total_gb': round(memory.total / (1024**3), 2),
            'used_percent': memory.percent,
            'available_gb': round(memory.available / (1024**3), 2)
        },
        'disk': {
            'total_gb': round(disk.total / (1024**3), 2),
            'used_percent': round((disk.used / disk.total) * 100, 2),
            'free_gb': round(disk.free / (1024**3), 2)
        },
        'network': {
            'bytes_sent': network.bytes_sent,
            'bytes_recv': network.bytes_recv
        },
        'python_processes': processes
    }
    
    return report

if __name__ == "__main__":
    report = diagnose_performance()
    print(json.dumps(report, indent=2))
```

### Resolução de Problemas Comuns

#### Alto Uso de Memória

```bash
# Verificar processos Python
ps aux | grep python | sort -k4 -nr

# Verificar cache de embeddings
du -sh data/embeddings_cache.pkl

# Limpar cache se necessário
rm data/embeddings_cache.pkl
```

#### Problemas de Conectividade

```bash
# Testar conectividade com provedores
curl -I https://api.openai.com/v1/models
curl -I https://api.github.com/copilot_internal

# Verificar DNS
nslookup api.openai.com
nslookup api.github.com
```

#### Problemas de Permissão

```bash
# Verificar permissões
ls -la config/
ls -la data/

# Corrigir permissões se necessário
chown -R cobol-analyzer:cobol-analyzer /home/cobol-analyzer/
chmod 750 /home/cobol-analyzer/
chmod 640 config/*.yaml
```

## Segurança Avançada

### Hardening do Sistema

#### Configuração de SELinux/AppArmor

```bash
# Criar perfil AppArmor para COBOL Analyzer
sudo cat > /etc/apparmor.d/cobol-analyzer << EOF
#include <tunables/global>

/home/cobol-analyzer/venv/bin/python {
  #include <abstractions/base>
  #include <abstractions/python>
  
  /home/cobol-analyzer/** r,
  /home/cobol-analyzer/logs/** rw,
  /home/cobol-analyzer/output/** rw,
  /home/cobol-analyzer/temp/** rw,
  
  network inet stream,
  network inet6 stream,
  
  deny /etc/shadow r,
  deny /etc/passwd w,
  deny /home/*/.*history r,
}
EOF

sudo apparmor_parser -r /etc/apparmor.d/cobol-analyzer
```

#### Configuração de Fail2Ban

```ini
# /etc/fail2ban/jail.d/cobol-analyzer.conf
[cobol-analyzer]
enabled = true
port = ssh
filter = cobol-analyzer
logpath = /var/log/cobol-analyzer/application.log
maxretry = 5
bantime = 3600
findtime = 600
```

### Auditoria de Segurança

#### Script de Auditoria

```bash
#!/bin/bash
# scripts/security_audit.sh

echo "=== Auditoria de Segurança COBOL Analyzer ==="

# Verificar permissões de arquivos críticos
echo "Verificando permissões..."
find config/ -type f -perm /o+r -exec echo "ALERTA: Arquivo legível por outros: {}" \;

# Verificar credenciais em texto plano
echo "Verificando credenciais..."
grep -r "password\|secret\|key" config/ --include="*.yaml" | grep -v "\${" && echo "ALERTA: Credenciais em texto plano encontradas"

# Verificar conexões de rede
echo "Verificando conexões..."
netstat -tulpn | grep python

# Verificar logs de acesso
echo "Verificando logs de acesso..."
grep "FAILED\|ERROR\|UNAUTHORIZED" logs/*.log | tail -10

echo "Auditoria concluída."
```

---

**COBOL Analyzer v3.1.0**  
Guia de Administração  
Desenvolvido pela equipe COBOL Analyzer - Outubro 2025
