#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from core.config import ConfigManager
from core.prompt_manager_dual import DualPromptManager
from providers.enhanced_provider_manager import EnhancedProviderManager
from parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from generators.documentation_generator import DocumentationGenerator
from utils.html_generator import HTMLReportGenerator
from utils.cost_calculator import CostCalculator
from rag.rag_integration import RAGIntegration
from core.intelligent_model_selector import IntelligentModelSelector

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        # String simples
        return [models_str]

def analyze_program_with_model(program: CobolProgram, books: List[CobolBook], model: str, output_dir: str, config_manager: ConfigManager, is_multi_model: bool, prompt_set: str, cost_calculator: CostCalculator, rag_integration=None) -> Dict[str, Any]:
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)
    
    # Criar diretório específico do modelo se multi-modelo
    if is_multi_model:
        model_output_dir = os.path.join(output_dir, f"model_{model.replace('/', '_').replace('-', '_')}")
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = output_dir
    
    try:
        # Inicializar componentes específicos para o modelo
        prompt_manager = DualPromptManager(config_manager.config, prompt_set)
        provider_manager = EnhancedProviderManager(config_manager.config)
        doc_generator = DocumentationGenerator(model_output_dir)
        
        # Análise com IA (passando RAG integration)
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager, rag_integration)
        
        start_time = time.time()
        
        # Log do provider que será usado
        logger.info(f"*** PROVIDER SELECIONADO: {model} ***")
        logger.info(f"Iniciando análise de {program.name} com provider {model}")
        
        analysis_result = analyzer.analyze_program(program, model)
        analysis_time = time.time() - start_time
        
        # Log do provider efetivamente usado
        provider_usado = getattr(analysis_result, 'provider_used', model)
        logger.info(f"*** ANÁLISE CONCLUÍDA COM PROVIDER: {provider_usado} ***")
        
        if not analysis_result.success:
            logger.error(f"Falha na análise de {program.name} com modelo {model}: {analysis_result.error_message}")
            return {
                'success': False,
                'program_name': program.name,
                'model': model,
                'error': analysis_result.error_message,
                'tokens_used': 0,
                'analysis_time': analysis_time,
                'output_dir': model_output_dir
            }
        
        # Calcular custos
        cost_info = cost_calculator.tokens_analytics(
            {'usage': [{'total_tokens': analysis_result.tokens_used}]}, 
            analysis_result.model_used
        )
        
        # Gerar documentação
        from providers.base_provider import AIResponse
        
        # Obter prompts utilizados do prompt_manager
        prompts_used = {
            'system_prompt': prompt_manager.get_system_prompt(),
            'original_prompt': getattr(analysis_result, 'original_prompt', 'Prompt gerado dinamicamente'),
            'main_prompt': getattr(analysis_result, 'prompt_used', 'Prompt principal não disponível')
        }
        
        ai_response = AIResponse(
            success=True,
            content=analysis_result.content,
            tokens_used=analysis_result.tokens_used,
            model=analysis_result.model_used,
            provider=getattr(analysis_result, 'provider_used', 'enhanced_mock'),
            prompts_used=prompts_used,
            response_time=analysis_time
        )
        
        doc_result = doc_generator.generate_program_documentation(program, ai_response)
        
        logger.info(f"Análise de {program.name} com {model} bem-sucedida.")
        logger.info(f"Tokens utilizados: {analysis_result.tokens_used:,}")
        logger.info(f"Custo: ${cost_info['cost']:.4f}")
        logger.info(f"Modelo utilizado: {analysis_result.model_used}")
        
        # Auto-learning: Adicionar análise bem-sucedida à base de conhecimento
        if rag_integration and hasattr(rag_integration, 'add_program_analysis_to_knowledge_base'):
            try:
                rag_integration.add_program_analysis_to_knowledge_base(
                    program.name, 
                    analysis_result.content, 
                    program.content
                )
                logger.info(f"Auto-learning: Conhecimento do programa {program.name} adicionado à base RAG")
            except Exception as e:
                logger.warning(f"Auto-learning falhou para {program.name}: {e}")
        
        return {
            'success': True,
            'program_name': program.name,
            'model': model,
            'tokens_used': analysis_result.tokens_used,
            'analysis_time': analysis_time,
            'output_dir': model_output_dir,
            'files_generated': [doc_result] if doc_result else [],
            'response': analysis_result
        }
        
    except Exception as e:
        logger.error(f"Erro na análise de {program.name} com modelo {model}: {str(e)}")
        return {
            'success': False,
            'program_name': program.name,
            'model': model,
            'error': str(e),
            'tokens_used': 0,
            'analysis_time': 0,
            'output_dir': model_output_dir
        }

def generate_comparative_report(programs: List[CobolProgram], all_results: List[Dict[str, Any]], output_dir: str) -> None:
    """Gera relatório comparativo entre modelos."""
    logger = logging.getLogger(__name__)
    
    try:
        report_path = os.path.join(output_dir, "relatorio_comparativo_modelos.md")
        
        # Agrupar resultados por modelo
        models_used = list(set(r['model'] for r in all_results))
        results_by_model = {model: [r for r in all_results if r['model'] == model] for model in models_used}
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Comparativo de Modelos\n\n")
            f.write(f"**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Programas Analisados:** {len(programs)}\n")
            f.write(f"**Modelos Utilizados:** {len(models_used)}\n\n")
            
            # Resumo geral
            f.write("## Resumo Geral\n\n")
            f.write("| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios |\n")
            f.write("|--------|----------|--------|-----------------|---------------|\n")
            
            for model in models_used:
                model_results = results_by_model[model]
                successes = sum(1 for r in model_results if r['success'])
                failures = len(model_results) - successes
                success_rate = (successes / len(model_results)) * 100 if model_results else 0
                avg_tokens = sum(r.get('tokens_used', 0) for r in model_results if r['success']) / max(successes, 1)
                
                f.write(f"| {model} | {successes} | {failures} | {success_rate:.1f}% | {avg_tokens:.0f} |\n")
            
            f.write("\n")
            
            # Detalhes por programa
            f.write("## Detalhes por Programa\n\n")
            
            for program in programs:
                f.write(f"### {program.name}\n\n")
                
                program_results = [r for r in all_results if r.get('program_name') == program.name]
                
                if program_results:
                    f.write("| Modelo | Status | Tokens | Qualidade | Diretório |\n")
                    f.write("|--------|--------|--------|-----------|----------|\n")
                    
                    for result in program_results:
                        status = "Sucesso" if result['success'] else "Falha"
                        tokens = result.get('tokens_used', 0)
                        quality = "Alta" if tokens > 2000 else "Média" if tokens > 1000 else "Baixa"
                        output_dir_name = os.path.basename(result['output_dir'])
                        
                        f.write(f"| {result['model']} | {status} | {tokens} | {quality} | {output_dir_name} |\n")
                    
                    f.write("\n")
                else:
                    f.write("Nenhum resultado encontrado para este programa.\n\n")
            
            # Recomendações
            f.write("## Recomendações\n\n")
            
            # Encontrar melhor modelo por taxa de sucesso
            best_model = max(models_used, key=lambda m: sum(1 for r in results_by_model[m] if r['success']) / len(results_by_model[m]))
            f.write(f"**Modelo Recomendado:** {best_model} (melhor taxa de sucesso)\n\n")
            
            # Encontrar modelo com mais tokens em média
            highest_tokens_model = max(models_used, key=lambda m: sum(r.get('tokens_used', 0) for r in results_by_model[m] if r['success']) / max(sum(1 for r in results_by_model[m] if r['success']), 1))
            f.write(f"**Modelo Mais Detalhado:** {highest_tokens_model} (maior média de tokens)\n\n")
            
            f.write("### Uso Recomendado por Cenário\n\n")
            f.write("- **Análise Rápida:** Use o modelo com melhor taxa de sucesso\n")
            f.write("- **Análise Detalhada:** Use o modelo com maior média de tokens\n")
            f.write("- **Análise Crítica:** Execute com múltiplos modelos e compare resultados\n")
            f.write("- **Produção:** Use o modelo mais estável baseado nas estatísticas\n\n")
            
            f.write("---\n")
            f.write("**Relatório gerado automaticamente pelo COBOL to Docs v1.1**\n")
        
        logger.info(f"Relatório comparativo gerado: {report_path}")
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatório comparativo: {e}")

def get_models_from_providers(config_manager: ConfigManager) -> List[str]:
    """Obtém lista de modelos dos providers configurados."""
    models = []
    providers_config = config_manager.config.get('providers', {})
    
    # Iterar pelos providers habilitados
    for provider_name, provider_config in providers_config.items():
        if provider_config.get('enabled', False):
            provider_models = provider_config.get('models', {})
            
            # Adicionar modelos do provider
            for model_key, model_config in provider_models.items():
                model_name = model_config.get('name')
                if model_name:
                    models.append(model_name)
    
    # Se nenhum modelo encontrado, usar fallback
    if not models:
        logger = logging.getLogger(__name__)
        logger.warning("Nenhum modelo encontrado nos providers, usando fallback")
        models = ['enhanced_mock']  # Fallback seguro
    
    return models

def process_cobol_files(args, config_manager: ConfigManager, cost_calculator: CostCalculator, rag_integration) -> None:
    """Processa arquivos COBOL com funcionalidade completa restaurada."""
    logger = logging.getLogger(__name__)
    
    # Inicializar seletor inteligente de modelos
    model_selector = IntelligentModelSelector()
    
    # Determinar modelos a usar
    if hasattr(args, 'models') and args.models:
        models = parse_models_argument(args.models)
        logger.info(f"Modelos especificados pelo usuário: {models}")
    else:
        # Obter modelos dos providers configurados
        models = get_models_from_providers(config_manager)
        logger.info(f"Modelos obtidos dos providers: {models}")
    
    # Inicializar parser
    parser = COBOLParser()
    
    # Verificar modo de operação
    if args.consolidado:
        logger.info("=== MODO ANÁLISE CONSOLIDADA SISTÊMICA ===")
        process_consolidated_analysis(args, config_manager, cost_calculator, parser, models, rag_integration)
        return
    
    if args.relatorio_unico:
        logger.info("=== MODO RELATÓRIO ÚNICO CONSOLIDADO ===")
        process_consolidated_report(args, config_manager, cost_calculator, parser, models)
        return
    
    # Verificar se deve usar análise especializada
    if args.analise_especialista or args.procedure_detalhada or args.modernizacao:
        logger.info("=== MODO ANÁLISE ESPECIALIZADA ===")
        process_expert_analysis(args, config_manager, cost_calculator, parser, models)
        return
    
    # Verificar se deve usar análise avançada com relatório consolidado
    if hasattr(args, 'advanced_analysis') and args.advanced_analysis:
        logger.info("=== MODO ANÁLISE AVANÇADA COM RELATÓRIO CONSOLIDADO ===")
        process_advanced_consolidated_analysis(args, config_manager, cost_calculator, parser, models)
        return
    
    # Verificar se deve usar análise detalhada de regras de negócio
    if hasattr(args, 'deep_analysis') and args.deep_analysis:
        logger.info("=== MODO ANÁLISE DETALHADA DE REGRAS DE NEGÓCIO ===")
        process_detailed_business_analysis(args, config_manager, cost_calculator, parser, models)
        return
    
    logger.info("=== INICIANDO PROCESSAMENTO COMPLETO ===")
    logger.info(f"Modelos selecionados: {models}")
    logger.info(f"Arquivo de fontes: {args.fontes}")
    if args.books:
        logger.info(f"Arquivo de books: {args.books}")
    logger.info(f"Diretório de saída: {args.output}")
    
    start_time = time.time()
    
    try:
        # Parse do arquivo principal
        programs, books = parser.parse_file(args.fontes)
        
        # Parse de copybooks adicionais se especificado
        if args.books and os.path.exists(args.books):
            _, additional_books = parser.parse_file(args.books)
            books.extend(additional_books)
        
        logger.info(f"Programas encontrados: {len(programs)}, Books encontrados: {len(books)}")
        
        if not programs:
            print("Nenhum programa encontrado para análise.")
            return
            
    except Exception as e:
        logger.error(f"Erro ao parsear arquivos: {str(e)}")
        return
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    all_results = []
    is_multi_model = len(models) > 1
    
    print(f"\nCOBOL to Docs v1.1 - Iniciando processamento")
    print(f"Autor: Carlos Morais")
    print(f"Programas COBOL: {len(programs)}")
    if books:
        print(f"Copybooks: {len(books)}")
    print(f"Modelos: {', '.join(models)}")
    print(f"Diretório de saída: {args.output}")
    print("=" * 60)
    
    # Processamento baseado no número de modelos
    if not is_multi_model:
        # Modelo único - usar seleção inteligente se não especificado pelo usuário
        if not hasattr(args, 'models') or not args.models:
            # Seleção inteligente baseada na complexidade do primeiro programa
            first_program_code = programs[0].content if programs else ""
            recommendation = model_selector.select_optimal_model(first_program_code)
            
            # Verificar se o modelo recomendado está disponível
            if recommendation.model_name in models:
                model = recommendation.model_name
                logger.info(f" SELEÇÃO INTELIGENTE: {model}")
                logger.info(f"   Justificativa: {recommendation.reasoning}")
                logger.info(f"   Confiança: {recommendation.confidence:.1%}")
                print(f" Modelo selecionado automaticamente: {model} (confiança: {recommendation.confidence:.1%})")
            else:
                model = models[0]
                logger.warning(f"Modelo recomendado {recommendation.model_name} não disponível, usando {model}")
        else:
            model = models[0]
        
        for i, program in enumerate(programs, 1):
            print(f"Analisando programa {i}/{len(programs)}: {program.name}")
            
            # Para cada programa, verificar se deve usar seleção inteligente individual
            if len(programs) > 1 and not hasattr(args, 'models'):
                program_recommendation = model_selector.select_optimal_model(program.content)
                if program_recommendation.model_name in models and program_recommendation.model_name != model:
                    logger.info(f" Ajustando modelo para {program.name}: {program_recommendation.model_name}")
                    current_model = program_recommendation.model_name
                else:
                    current_model = model
            else:
                current_model = model
            
            result = analyze_program_with_model(
                program, books, current_model, args.output, config_manager, is_multi_model, args.prompt_set, cost_calculator, rag_integration
            )
            
            all_results.append(result)
    else:
        # Múltiplos modelos - estrutura com diretórios separados
        total_analyses = len(programs) * len(models)
        current_analysis = 0
        
        for i, program in enumerate(programs, 1):
            logger.info(f"\nPrograma {i}/{len(programs)}: {program.name}")
            
            for j, model in enumerate(models, 1):
                current_analysis += 1
                print(f"Analisando {program.name} com {model} ({current_analysis}/{total_analyses})")
                
                result = analyze_program_with_model(
                    program, books, model, args.output, config_manager, is_multi_model, args.prompt_set, cost_calculator, rag_integration
                )
                
                all_results.append(result)
    
    # Calcular estatísticas finais
    total_time = time.time() - start_time
    successful_results = [r for r in all_results if r['success']]
    successful_analyses = len(successful_results)
    total_analyses = len(all_results)
    success_rate = (successful_analyses / total_analyses * 100) if total_analyses > 0 else 0
    
    # Obter modelos únicos bem-sucedidos
    successful_models = list(set(r['model'] for r in successful_results if 'model' in r))
    
    # Calcular custo total
    cost_summary = cost_calculator.get_cost_summary()
    total_cost = cost_summary['total_cost']
    total_tokens = cost_summary['total_tokens']
    
    # Gerar relatório comparativo se múltiplos modelos
    if is_multi_model and len(models) > 1:
        generate_comparative_report(args.output, all_results, programs)
    
    logger.info(f"Total de tokens utilizados: {total_tokens:,}")
    logger.info(f"Custo total: ${total_cost:.4f}")
    logger.info(f"Tempo total de processamento: {total_time:.2f}s")
    logger.info(f"Documentação gerada em: {args.output}")
    if is_multi_model:
        logger.info(f"Relatório comparativo: {os.path.join(args.output, 'relatorio_comparativo_modelos.md')}")
    
    # Estatísticas finais para o usuário
    print("=" * 60)
    print("PROCESSAMENTO CONCLUÍDO")
    print(f"Programas processados: {len(programs)}")
    print(f"Modelos utilizados: {len(successful_models)} ({', '.join(successful_models)})")
    print(f"Análises bem-sucedidas: {successful_analyses}/{total_analyses}")
    print(f"Taxa de sucesso geral: {success_rate:.1f}%")
    print(f"Total de tokens utilizados: {total_tokens:,}")
    print(f"Custo total: ${total_cost:.4f}")
    print(f"Tempo total de processamento: {total_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    print(f"Relatório de custos: {os.path.join(args.output, 'relatorio_custos.txt')}")
    if is_multi_model:
        print(f"Relatório comparativo: {os.path.join(args.output, 'relatorio_comparativo_modelos.md')}")  # Gerar relatório de custos
    cost_report = cost_calculator.format_cost_report()
    cost_report_file = os.path.join(args.output, "relatorio_custos.txt")
    with open(cost_report_file, 'w', encoding='utf-8') as f:
        f.write(cost_report)
    
    # Gerar HTML/PDF se solicitado
    if args.pdf:
        print("\nGerando relatórios HTML/PDF...")
        generate_html_reports(args.output, programs, all_results, is_multi_model)
def process_expert_analysis(args, config_manager, cost_calculator, parser, models):
    """
    Processa análise especializada com prompts técnicos profundos.
    """
    import os
    import time
    from core.prompt_manager_dual import DualPromptManager
    from providers.enhanced_provider_manager import EnhancedProviderManager
    from generators.documentation_generator import DocumentationGenerator
    from utils.cobol_preprocessor import COBOLPreprocessor
    from providers.base_provider import AIResponse
    
    logger = logging.getLogger(__name__)
    
    logger.info(f"Modelos selecionados: {models}")
    logger.info(f"Arquivo de fontes: {args.fontes}")
    logger.info(f"Diretório de saída: {args.output}")
    
    # Configurar tipo de análise
    analysis_types = []
    if args.analise_especialista:
        analysis_types.append("especialista")
    if args.procedure_detalhada:
        analysis_types.append("procedure_detalhada")
    if args.modernizacao:
        analysis_types.append("modernizacao")
    
    logger.info(f"Tipos de análise: {analysis_types}")
    
    start_time = time.time()
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    # Carregar programas COBOL
    logger.info("Carregando programas COBOL...")
    programs, _ = parser.parse_file(args.fontes)
    logger.info(f"Programas carregados: {len(programs)}")
    
    # Carregar copybooks se especificado
    books = []
    if args.books:
        logger.info("Carregando copybooks...")
        _, books_result = parser.parse_file(args.books)
        books = books_result
        logger.info(f"Copybooks carregados: {len(books)}")
    
    # Inicializar componentes com prompts especializados
    try:
        # Tentar carregar prompts especializados
        config_especialista = config_manager.config.copy()
        config_especialista['prompts_file'] = 'config/prompts_especialista.yaml'
        expert_prompt_manager = DualPromptManager(config_especialista, "especialista")
    except:
        # Fallback para prompts originais
        logger.warning("Prompts especializados não encontrados, usando prompts originais")
        expert_prompt_manager = DualPromptManager(config_manager.config, "original")
    
    provider_manager = EnhancedProviderManager(config_manager.config)
    doc_generator = DocumentationGenerator(args.output)
    preprocessor = COBOLPreprocessor()
    
    # Processar cada programa com análise especializada
    total_tokens = 0
    total_cost = 0.0
    successful_analyses = 0
    
    for program in programs:
        logger.info(f"Iniciando análise especializada de {program.name}")
        
        # Preparar código para análise
        program_code = program.content
        
        # Detecção automática de comentários
        has_comments = preprocessor.has_comments(program_code)
        if not has_comments:
            logger.info(f"Poucos comentários detectados em {program.name} - usando análise de capacidade pura")
            program_code, removed_comments = preprocessor.remove_comments(program_code)
            logger.info(f"Removidos {removed_comments} comentários de {program.name}")
        
        # Análise de complexidade
        complexity = preprocessor.analyze_complexity(program_code)
        logger.info(f"Complexidade de {program.name}: {complexity['cyclomatic_complexity']} pontos")
        
        # Detectar copybooks
        detected_copybooks = preprocessor.detect_copybooks(program_code)
        logger.info(f"Copybooks detectados em {program.name}: {detected_copybooks}")
        
        # Extrair parágrafos da PROCEDURE DIVISION
        paragraphs = preprocessor.extract_paragraphs(program_code)
        logger.info(f"Parágrafos extraídos de {program.name}: {len(paragraphs)}")
        
        # Processar com cada modelo
        for model in models:
            logger.info(f"Analisando {program.name} com {model} (análise especializada)")
            
            try:
                # Obter prompts do sistema
                system_prompt = expert_prompt_manager.get_system_prompt()
                main_prompt = expert_prompt_manager.get_main_prompt({
                    'program_content': program_code,
                    'program_name': program.name,
                    'complexity': complexity,
                    'copybooks': detected_copybooks,
                    'paragraphs': paragraphs
                })
                
                # Executar análise
                analysis_result = provider_manager.analyze_cobol(
                    program_content=program_code,
                    program_name=program.name,
                    prompt=main_prompt,
                    model=model
                )
                
                if analysis_result.success:
                    # Calcular custo
                    cost = cost_calculator.calculate_cost(model, analysis_result.tokens_used)
                    cost_calculator.add_request(model, analysis_result.tokens_used, cost)
                    
                    # Criar AIResponse com informações completas
                    ai_response = AIResponse(
                        success=True,
                        content=analysis_result.content,
                        tokens_used=analysis_result.tokens_used,
                        model=model,
                        provider=analysis_result.provider,
                        prompts_used={
                            'system_prompt': system_prompt,
                            'main_prompt': main_prompt,
                            'analysis_type': analysis_types,
                            'complexity_metrics': complexity,
                            'detected_copybooks': detected_copybooks,
                            'paragraphs_found': len(paragraphs)
                        }
                    )
                    
                    # Gerar documentação especializada
                    output_dir = os.path.join(args.output, f"model_{model.replace('-', '_')}")
                    os.makedirs(output_dir, exist_ok=True)
                    
                    doc_generator.generate_functional_report(
                        ai_response, program.name, output_dir
                    )
                    
                    total_tokens += analysis_result.tokens_used
                    total_cost += cost
                    successful_analyses += 1
                    
                    logger.info(f"Análise especializada de {program.name} com {model} bem-sucedida.")
                    logger.info(f"Tokens utilizados: {analysis_result.tokens_used:,}")
                    logger.info(f"Custo: ${cost:.4f}")
                    logger.info(f"Modelo utilizado: {model}")
                    
                else:
                    logger.error(f"Falha na análise especializada de {program.name} com {model}")
                    
            except Exception as e:
                logger.error(f"Erro na análise especializada de {program.name} com {model}: {e}")
    
    # Gerar relatório de custos
    cost_report = cost_calculator.format_cost_report()
    cost_report_path = os.path.join(args.output, 'relatorio_custos_especialista.txt')
    with open(cost_report_path, 'w', encoding='utf-8') as f:
        f.write(cost_report)
    
    # Resumo final
    total_time = time.time() - start_time
    total_analyses = len(programs) * len(models)
    success_rate = (successful_analyses / total_analyses) * 100 if total_analyses > 0 else 0
    
    print("=" * 60)
    print("ANÁLISE ESPECIALIZADA CONCLUÍDA")
    print(f"Programas processados: {len(programs)}")
    print(f"Modelos utilizados: {len(models)} ({', '.join(models)})")
    print(f"Tipos de análise: {', '.join(analysis_types)}")
    print(f"Análises bem-sucedidas: {successful_analyses}/{total_analyses}")
    print(f"Taxa de sucesso geral: {success_rate:.1f}%")
    print(f"Total de tokens utilizados: {total_tokens:,}")
    print(f"Custo total: ${total_cost:.4f}")
    print(f"Tempo total de processamento: {total_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    print(f"Relatório de custos: {cost_report_path}")
    print("=" * 60)

def process_consolidated_report(args, config_manager, cost_calculator, parser, models):
    """
    Processa análise consolidada gerando um relatório único.
    
    Args:
        args: Argumentos da linha de comando
        config_manager: Gerenciador de configuração
        cost_calculator: Calculadora de custos
        parser: Parser COBOL
        models: Lista de modelos a usar
    """
    logger = logging.getLogger(__name__)
    
    logger.info(f"Modelos selecionados: {models}")
    logger.info(f"Arquivo de fontes: {args.fontes}")
    if args.books:
        logger.info(f"Arquivo de books: {args.books}")
    logger.info(f"Diretório de saída: {args.output}")
    
    start_time = time.time()
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    # Carregar programas COBOL
    logger.info("Carregando programas COBOL...")
    programs, _ = parser.parse_file(args.fontes)
    logger.info(f"Programas carregados: {len(programs)}")
    
    # Carregar copybooks se especificado
    books = []
    if args.books:
        logger.info("Carregando copybooks...")
        _, books_result = parser.parse_file(args.books)
        books = books_result
        logger.info(f"Copybooks carregados: {len(books)}")
    
    # Inicializar componentes
    prompt_manager = DualPromptManager(config_manager.config, args.prompt_set)
    provider_manager = EnhancedProviderManager(config_manager.config)
    consolidated_analyzer = ConsolidatedAnalyzer(provider_manager, prompt_manager)
    doc_generator = DocumentationGenerator(args.output)
    
    # Processar com cada modelo
    all_results = []
    
    for model in models:
        logger.info(f"Processando análise consolidada com modelo: {model}")
        
        model_start_time = time.time()
        
        # Executar análise consolidada
        analysis_result = consolidated_analyzer.analyze_consolidated(programs, books, model)
        
        if analysis_result['success']:
            analysis_time = time.time() - model_start_time
            
            # Calcular custos
            cost_info = cost_calculator.tokens_analytics(
                {'usage': [{'total_tokens': analysis_result['tokens_used']}]}, 
                model
            )
            
            # Criar diretório para o modelo
            model_output_dir = os.path.join(args.output, f"model_{model.replace('-', '_')}")
            os.makedirs(model_output_dir, exist_ok=True)
            
            # Gerar documentação consolidada
            from providers.base_provider import AIResponse
            
            prompts_used = {
                'system_prompt': prompt_manager.get_system_prompt(),
                'original_prompt': analysis_result.get('prompt_used', 'Prompt consolidado gerado dinamicamente'),
                'main_prompt': 'Análise consolidada de todo o sistema bancário'
            }
            
            ai_response = AIResponse(
                success=True,
                content=analysis_result['content'],
                tokens_used=analysis_result['tokens_used'],
                model=analysis_result['model_used'],
                provider=analysis_result.get('provider_used', 'unknown'),
                prompts_used=prompts_used,
                response_time=analysis_time
            )
            
            # Gerar documentação consolidada
            doc_filename = os.path.join(model_output_dir, "SISTEMA_BANCARIO_ANALISE_CONSOLIDADA.md")
            with open(doc_filename, 'w', encoding='utf-8') as f:
                f.write(f"# ANÁLISE CONSOLIDADA DO SISTEMA BANCÁRIO COBOL\n\n")
                f.write(f"**Modelo:** {analysis_result['model_used']}\n")
                f.write(f"**Programas analisados:** {analysis_result['programs_analyzed']}\n")
                f.write(f"**Copybooks analisados:** {analysis_result['books_analyzed']}\n")
                f.write(f"**Tokens utilizados:** {analysis_result['tokens_used']:,}\n")
                f.write(f"**Custo:** ${cost_info['cost']:.4f}\n")
                f.write(f"**Tempo de análise:** {analysis_time:.2f}s\n\n")
                f.write("---\n\n")
                f.write(analysis_result['content'])
            
            logger.info(f"Análise consolidada com {model} bem-sucedida.")
            logger.info(f"Tokens utilizados: {analysis_result['tokens_used']:,}")
            logger.info(f"Custo: ${cost_info['cost']:.4f}")
            logger.info(f"Modelo utilizado: {analysis_result['model_used']}")
            
            all_results.append({
                'success': True,
                'model': model,
                'tokens_used': analysis_result['tokens_used'],
                'cost': cost_info['cost'],
                'analysis_time': analysis_time,
                'output_dir': model_output_dir
            })
            
        else:
            logger.error(f"Falha na análise consolidada com {model}: {analysis_result.get('error', 'Erro desconhecido')}")
            all_results.append({
                'success': False,
                'model': model,
                'error': analysis_result.get('error', 'Erro desconhecido')
            })
    
    # Gerar relatório de custos
    cost_report = cost_calculator.format_cost_report()
    cost_report_file = os.path.join(args.output, "relatorio_custos_consolidado.txt")
    with open(cost_report_file, 'w', encoding='utf-8') as f:
        f.write(cost_report)
    
    # Gerar relatório HTML se solicitado
    if hasattr(args, 'pdf') and args.pdf:
        logger.info("Gerando relatórios HTML...")
        generate_consolidated_html_reports(args.output, all_results)
    
    # Estatísticas finais
    total_time = time.time() - start_time
    successful_analyses = [r for r in all_results if r['success']]
    total_cost = sum(r.get('cost', 0) for r in successful_analyses)
    total_tokens = sum(r.get('tokens_used', 0) for r in successful_analyses)
    
    logger.info("=" * 60)
    logger.info("ANÁLISE CONSOLIDADA CONCLUÍDA")
    logger.info(f"Programas analisados: {len(programs)}")
    logger.info(f"Copybooks analisados: {len(books)}")
    logger.info(f"Modelos utilizados: {len(successful_analyses)} ({', '.join(r['model'] for r in successful_analyses)})")
    logger.info(f"Análises bem-sucedidas: {len(successful_analyses)}/{len(models)}")
    logger.info(f"Taxa de sucesso geral: {len(successful_analyses)/len(models)*100:.1f}%")
    logger.info(f"Total de tokens utilizados: {total_tokens:,}")
    logger.info(f"Custo total: ${total_cost:.4f}")
    logger.info(f"Tempo total de processamento: {total_time:.2f}s")
    logger.info(f"Documentação gerada em: {args.output}")
    logger.info(f"Relatório de custos: {cost_report_file}")

def generate_consolidated_html_reports(output_dir: str, results: List[Dict]) -> None:
    """
    Gera relatórios HTML para análise consolidada.
    
    Args:
        output_dir: Diretório de saída
        results: Lista com resultados das análises
    """
    logger = logging.getLogger(__name__)
    
    try:
        from utils.html_generator import HTMLReportGenerator
        
        html_generator = HTMLReportGenerator()
        html_files_generated = []
        
        for result in results:
            if result['success']:
                model_dir = result['output_dir']
                md_file = os.path.join(model_dir, "SISTEMA_BANCARIO_ANALISE_CONSOLIDADA.md")
                
                if os.path.exists(md_file):
                    html_generator.generate_html_report(md_file, model_dir)
                    html_file = md_file.replace('.md', '.html')
                    if os.path.exists(html_file):
                        html_files_generated.append(html_file)
        
        logger.info(f"Relatórios HTML gerados: {len(html_files_generated)}")
        for html_file in html_files_generated:
            logger.info(f"  - {html_file}")
            
    except Exception as e:
        logger.error(f"Erro ao gerar relatórios HTML: {e}")

def generate_html_reports(output_dir: str, programs: List, all_results: List[Dict], is_multi_model: bool) -> None:
    """Gera relatórios HTML/PDF a partir dos arquivos Markdown."""
    try:
        from utils.html_generator import HTMLReportGenerator
        
        html_generator = HTMLReportGenerator()
        html_files_generated = []
        
        if is_multi_model:
            # Para múltiplos modelos, processar cada diretório de modelo
            for result in all_results:
                if result['success']:
                    model_dir = result['output_dir']
                    md_files = [f for f in os.listdir(model_dir) if f.endswith('_analise_funcional.md')]
                    
                    for md_file in md_files:
                        md_path = os.path.join(model_dir, md_file)
                        
                        # Gerar HTML (passando diretório, não arquivo)
                        html_file = html_generator.generate_html_report(md_path, model_dir)
                        html_files_generated.append(html_file)
                        print(f"  HTML gerado: {html_file}")
        else:
            # Para modelo único, processar arquivos na raiz
            md_files = [f for f in os.listdir(output_dir) if f.endswith('_analise_funcional.md')]
            
            for md_file in md_files:
                md_path = os.path.join(output_dir, md_file)
                
                # Gerar HTML (passando diretório, não arquivo)
                html_file = html_generator.generate_html_report(md_path, output_dir)
                html_files_generated.append(html_file)
                print(f"  HTML gerado: {html_file}")
        
        print(f"\nTotal de relatórios HTML gerados: {len(html_files_generated)}")
        
    except Exception as e:
        print(f"Erro ao gerar relatórios HTML: {e}")
        logging.getLogger(__name__).error(f"Erro ao gerar relatórios HTML: {e}")

def process_consolidated_analysis(args, config_manager, cost_calculator, parser, models, rag_integration=None):
    """
    Processa análise consolidada sistêmica de todos os programas COBOL simultaneamente.
    
    Args:
        args: Argumentos da linha de comando
        config_manager: Gerenciador de configuração
        cost_calculator: Calculadora de custos
        parser: Parser COBOL
        models: Lista de modelos a usar
    """
    import os
    import time
    import json
    from datetime import datetime
    from typing import Dict, List, Any, Optional
    
    logger = logging.getLogger(__name__)
    
    logger.info(f"Modelos selecionados: {models}")
    logger.info(f"Arquivo de fontes: {args.fontes}")
    if args.books:
        logger.info(f"Arquivo de copybooks: {args.books}")
    logger.info(f"Diretório de saída: {args.output}")
    
    start_time = time.time()
    
    print("=" * 80)
    print("COBOL to Docs v1.1 - ANÁLISE CONSOLIDADA SISTÊMICA")
    print("Análise Integrada de Todos os Programas COBOL Simultaneamente")
    print("=" * 80)
    print()
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    try:
        # Usar o parser existente para carregar programas
        programs_parsed, books_parsed = parser.parse_file(args.fontes)
        
        # Converter para formato consolidado
        programs = {}
        for prog in programs_parsed:
            programs[prog.name] = {
                'name': prog.name,
                'code': prog.content,
                'metadata': {
                    'purpose': 'Programa COBOL do sistema bancário',
                    'operations': [],
                    'files': [],
                    'copybooks': [],
                    'complexity': {'code_lines': prog.line_count}
                }
            }
        
        logger.info(f"Carregados {len(programs)} programas COBOL")
        
        print(f"Programas COBOL carregados: {len(programs)}")
        for prog_name in programs.keys():
            print(f"  - {prog_name}")
        
        # Carregar copybooks se fornecido
        copybooks = {}
        if args.books and os.path.exists(args.books):
            logger.info(f"Carregando copybooks de: {args.books}")
            _, books_additional = parser.parse_file(args.books)
            books_parsed.extend(books_additional)
            
            for i, book in enumerate(books_parsed):
                copybooks[f"COPYBOOK_{i+1:02d}"] = book.content
            
            logger.info(f"Carregados {len(copybooks)} copybooks")
            print(f" Copybooks carregados: {len(copybooks)}")
        
        # Preparar contexto consolidado básico
        system_context = {
            'overview': {
                'total_programs': len(programs),
                'total_copybooks': len(copybooks),
                'system_type': 'Sistema Bancário COBOL Mainframe'
            },
            'programs_summary': {},
            'relationships': [],
            'business_processes': []
        }
        
        for prog_name, prog_info in programs.items():
            system_context['programs_summary'][prog_name] = {
                'purpose': prog_info['metadata']['purpose'],
                'operations': prog_info['metadata']['operations'],
                'files': prog_info['metadata']['files'],
                'complexity': prog_info['metadata']['complexity']['code_lines']
            }
        
        print(f" Contexto do sistema preparado:")
        print(f"  - Relacionamentos identificados: {len(system_context['relationships'])}")
        print(f"  - Processos de negócio: {len(system_context['business_processes'])}")
        print()
        
        # Processar com cada modelo
        all_results = []
        successful_analyses = 0
        total_tokens = 0
        total_cost = 0.0
        
        for model in models:
            # Garantir que model é uma string
            model_name = str(model) if not isinstance(model, str) else model
            print(f" Executando análise consolidada com modelo: {model_name}")
            
            # Gerar prompt especializado para análise consolidada
            logger.info("Gerando prompt especializado para análise consolidada")
            consolidated_prompt = generate_consolidated_prompt_simple(system_context, programs, copybooks)
            
            # Executar análise consolidada
            logger.info(f"Executando análise consolidada com modelo: {model_name}")
            
            provider_manager = EnhancedProviderManager(config_manager.get_config())
            
            from providers.base_provider import AIRequest
            request = AIRequest(
                prompt=consolidated_prompt,
                temperature=0.1,
                max_tokens=8000
            )
            
            analysis_result = provider_manager.analyze(request)
            
            # Processar resultado
            if analysis_result.success:
                logger.info(f"Análise consolidada bem-sucedida - {analysis_result.tokens_used} tokens")
                
                # Calcular custo
                cost = cost_calculator.calculate_cost(analysis_result.model, analysis_result.tokens_used)
                
                # Gerar documentação consolidada
                result = generate_consolidated_documentation_simple(
                    analysis_result,
                    system_context,
                    programs,
                    copybooks,
                    args.output,
                    model_name,
                    cost
                )
                
                all_results.append(result)
                successful_analyses += 1
                total_tokens += analysis_result.tokens_used
                total_cost += cost
                
                print(f"   Sucesso - {analysis_result.tokens_used:,} tokens - ${cost:.4f}")
                
                # Auto-learning: Adicionar análise bem-sucedida à base de conhecimento
                if rag_integration and hasattr(rag_integration, 'add_program_analysis_to_knowledge_base'):
                    try:
                        # Adicionar conhecimento de cada programa analisado
                        for prog_name, prog_data in programs.items():
                            rag_integration.add_program_analysis_to_knowledge_base(
                                prog_name, 
                                analysis_result.content, 
                                prog_data['codigo']
                            )
                        logger.info(f"Auto-learning: Conhecimento adicionado à base RAG para {len(programs)} programas")
                    except Exception as e:
                        logger.warning(f"Auto-learning falhou: {e}")
                
            else:
                logger.error(f"Falha na análise consolidada: {analysis_result.error_message}")
                print(f"   Falha: {analysis_result.error_message}")
        
        # Processar tempo total
        processing_time = time.time() - start_time
        
        # Gerar relatório de custos consolidado
        cost_report_path = os.path.join(args.output, "relatorio_custos_consolidado.txt")
        
        with open(cost_report_path, 'w', encoding='utf-8') as f:
            f.write("=" * 80 + "\n")
            f.write("RELATÓRIO DE CUSTOS - ANÁLISE CONSOLIDADA SISTÊMICA\n")
            f.write("=" * 80 + "\n\n")
            f.write(f"CUSTO TOTAL: ${total_cost:.4f}\n")
            f.write(f"TOKENS TOTAIS: {total_tokens:,}\n")
            f.write(f"TEMPO DE PROCESSAMENTO: {processing_time:.2f}s\n\n")
            f.write("DETALHES DO SISTEMA:\n")
            f.write("-" * 40 + "\n")
            f.write(f"Programas analisados: {len(programs)}\n")
            f.write(f"Copybooks analisados: {len(copybooks)}\n")
            f.write(f"Análises realizadas: {len(all_results)}\n")
            f.write(f"Custo por token: ${total_cost/total_tokens:.6f}\n" if total_tokens > 0 else "Custo por token: $0.000000\n")
            f.write(f"Custo por programa: ${total_cost/len(programs):.4f}\n" if len(programs) > 0 else "Custo por programa: $0.0000\n")
        
        # Imprimir resumo final
        print()
        print("=" * 80)
        print("RESUMO DA ANÁLISE CONSOLIDADA")
        print("=" * 80)
        print(f" Análises bem-sucedidas: {successful_analyses}/{len(models)}")
        print(f" Programas analisados: {len(programs)}")
        print(f" Copybooks processados: {len(copybooks)}")
        print(f"🔢 Total de tokens: {total_tokens:,}")
        print(f" Custo total: ${total_cost:.4f}")
        print(f"⏱ Tempo de processamento: {processing_time:.2f} segundos")
        print(f" Documentação gerada em: {args.output}")
        print()
        
        if successful_analyses > 0:
            print(" Análise consolidada concluída com sucesso!")
            print(" Arquivos principais gerados:")
            for result in all_results:
                if result['success']:
                    print(f"  - {result['files_generated']['main_document']}")
        else:
            print(" Nenhuma análise foi bem-sucedida")
        
        print("=" * 80)
        
    except Exception as e:
        logger.error(f"Erro no processamento consolidado: {e}")
        print(f" Erro: {e}")


def generate_consolidated_prompt_simple(system_context, programs, copybooks):
    """Gera prompt consolidado robusto para análise sistêmica profunda."""
    prompt_parts = []
    
    prompt_parts.append("=== ANÁLISE SISTÊMICA CONSOLIDADA - SISTEMA BANCÁRIO COBOL ===")
    prompt_parts.append("")
    prompt_parts.append("Você é um ARQUITETO DE SISTEMAS COBOL SÊNIOR com mais de 25 anos de experiência em sistemas bancários mainframe.")
    prompt_parts.append("Especialista em análise de sistemas legados, modernização, migração e arquitetura de software bancário.")
    prompt_parts.append("Sua expertise inclui: análise de impacto, mapeamento de dependências, extração de regras de negócio, e documentação técnica.")
    prompt_parts.append("")
    prompt_parts.append("MISSÃO: Realizar uma ANÁLISE SISTÊMICA COMPLETA E PROFUNDA do sistema bancário COBOL apresentado,")
    prompt_parts.append("fornecendo insights técnicos e de negócio que permitam compreender totalmente o sistema para:")
    prompt_parts.append("- Manutenção e evolução do sistema")
    prompt_parts.append("- Análise de impacto de mudanças")
    prompt_parts.append("- Modernização e migração")
    prompt_parts.append("- Documentação técnica completa")
    prompt_parts.append("- Treinamento de novos desenvolvedores")
    prompt_parts.append("")
    
    # Contexto do sistema
    prompt_parts.append("CONTEXTO DO SISTEMA:")
    prompt_parts.append(f"- Total de Programas: {system_context['overview']['total_programs']}")
    prompt_parts.append(f"- Total de Copybooks: {system_context['overview']['total_copybooks']}")
    prompt_parts.append(f"- Tipo: {system_context['overview']['system_type']}")
    prompt_parts.append("")
    
    # Resumo dos programas
    prompt_parts.append("PROGRAMAS DO SISTEMA:")
    for prog_name, prog_info in programs.items():
        prompt_parts.append(f"- {prog_name}: Programa COBOL do sistema bancário")
        prompt_parts.append(f"  Linhas de código: {prog_info['metadata']['complexity']['code_lines']}")
    prompt_parts.append("")
    
    # Código fonte completo
    prompt_parts.append("=== CÓDIGO FONTE COMPLETO DOS PROGRAMAS ===")
    for prog_name, prog_info in programs.items():
        prompt_parts.append(f"\n--- PROGRAMA {prog_name} ---")
        prompt_parts.append(prog_info['code'])
        prompt_parts.append("")
    
    # Copybooks se existirem
    if copybooks:
        prompt_parts.append("=== COPYBOOKS DO SISTEMA ===")
        for book_name, book_code in copybooks.items():
            prompt_parts.append(f"\n--- COPYBOOK {book_name} ---")
            prompt_parts.append(book_code)
            prompt_parts.append("")
    
    # Instruções para análise MUITO MAIS DETALHADAS
    prompt_parts.append("=== INSTRUÇÕES PARA ANÁLISE SISTÊMICA PROFUNDA ===")
    prompt_parts.append("")
    prompt_parts.append("Como ARQUITETO DE SISTEMAS COBOL SÊNIOR, forneça uma análise técnica EXTREMAMENTE DETALHADA que inclua:")
    prompt_parts.append("")
    
    prompt_parts.append("## 1. ARQUITETURA E DESIGN DO SISTEMA")
    prompt_parts.append("### 1.1 Visão Arquitetural")
    prompt_parts.append("- Padrão arquitetural utilizado (batch, online, híbrido)")
    prompt_parts.append("- Estratégia de modularização e separação de responsabilidades")
    prompt_parts.append("- Acoplamento e coesão entre componentes")
    prompt_parts.append("- Padrões de design identificados (MVC, Strategy, etc.)")
    prompt_parts.append("")
    prompt_parts.append("### 1.2 Fluxo de Dados e Integração")
    prompt_parts.append("- Mapeamento completo do fluxo de dados entre programas")
    prompt_parts.append("- Identificação de pontos de integração")
    prompt_parts.append("- Dependências entre programas e copybooks")
    prompt_parts.append("- Estratégia de persistência (arquivos, DB2, VSAM, etc.)")
    prompt_parts.append("")
    
    prompt_parts.append("## 2. ANÁLISE TÉCNICA DETALHADA")
    prompt_parts.append("### 2.1 Qualidade do Código")
    prompt_parts.append("- Aderência às convenções COBOL e padrões bancários")
    prompt_parts.append("- Estruturação e organização do código")
    prompt_parts.append("- Nomenclatura de variáveis, parágrafos e seções")
    prompt_parts.append("- Comentários e documentação inline")
    prompt_parts.append("")
    prompt_parts.append("### 2.2 Complexidade e Manutenibilidade")
    prompt_parts.append("- Análise de complexidade ciclomática")
    prompt_parts.append("- Identificação de código duplicado")
    prompt_parts.append("- Pontos de alta complexidade que necessitam refatoração")
    prompt_parts.append("- Facilidade de manutenção e extensibilidade")
    prompt_parts.append("")
    prompt_parts.append("### 2.3 Robustez e Tratamento de Erros")
    prompt_parts.append("- Estratégias de tratamento de erros implementadas")
    prompt_parts.append("- Validação de dados de entrada")
    prompt_parts.append("- Recuperação de falhas e rollback")
    prompt_parts.append("- Logging e auditoria")
    prompt_parts.append("")
    
    prompt_parts.append("## 3. ANÁLISE DE NEGÓCIO PROFUNDA")
    prompt_parts.append("### 3.1 Processos de Negócio")
    prompt_parts.append("- Identificação completa de todos os processos implementados")
    prompt_parts.append("- Fluxo de trabalho (workflow) de cada processo")
    prompt_parts.append("- Pontos de decisão e validação de negócio")
    prompt_parts.append("- Integração com outros sistemas bancários")
    prompt_parts.append("")
    prompt_parts.append("### 3.2 Regras de Negócio Detalhadas")
    prompt_parts.append("- Extração completa de todas as regras de negócio do código")
    prompt_parts.append("- Regras de validação de dados")
    prompt_parts.append("- Cálculos financeiros e fórmulas")
    prompt_parts.append("- Regras de autorização e segurança")
    prompt_parts.append("- Regras de compliance e regulamentação")
    prompt_parts.append("")
    prompt_parts.append("### 3.3 Entidades e Modelo de Dados")
    prompt_parts.append("- Identificação de todas as entidades de negócio")
    prompt_parts.append("- Relacionamentos entre entidades")
    prompt_parts.append("- Estrutura de dados (layouts de arquivo/registro)")
    prompt_parts.append("- Chaves primárias e índices")
    prompt_parts.append("")
    
    prompt_parts.append("## 4. ANÁLISE DA PROCEDURE DIVISION")
    prompt_parts.append("### 4.1 Fluxo de Execução Detalhado")
    prompt_parts.append("- Mapeamento completo do fluxo de execução de cada programa")
    prompt_parts.append("- Sequência de parágrafos e seções")
    prompt_parts.append("- Condições e loops identificados")
    prompt_parts.append("- Pontos de entrada e saída")
    prompt_parts.append("")
    prompt_parts.append("### 4.2 Lógica de Negócio")
    prompt_parts.append("- Análise detalhada de cada parágrafo da PROCEDURE DIVISION")
    prompt_parts.append("- Operações realizadas em cada seção")
    prompt_parts.append("- Transformações de dados")
    prompt_parts.append("- Validações e controles implementados")
    prompt_parts.append("")
    
    prompt_parts.append("## 5. DEPENDÊNCIAS E RELACIONAMENTOS")
    prompt_parts.append("### 5.1 Mapa de Dependências")
    prompt_parts.append("- Dependências entre programas")
    prompt_parts.append("- Uso de copybooks e includes")
    prompt_parts.append("- Chamadas de subprogramas (CALL)")
    prompt_parts.append("- Dependências de arquivos e datasets")
    prompt_parts.append("")
    prompt_parts.append("### 5.2 Análise de Impacto")
    prompt_parts.append("- Impacto de mudanças em cada programa")
    prompt_parts.append("- Programas que seriam afetados por alterações")
    prompt_parts.append("- Pontos críticos do sistema")
    prompt_parts.append("- Riscos de regressão")
    prompt_parts.append("")
    
    prompt_parts.append("## 6. RECOMENDAÇÕES ESTRATÉGICAS")
    prompt_parts.append("### 6.1 Modernização")
    prompt_parts.append("- Oportunidades de modernização identificadas")
    prompt_parts.append("- Refatorações recomendadas")
    prompt_parts.append("- Migração para tecnologias modernas")
    prompt_parts.append("- Estratégia de evolução do sistema")
    prompt_parts.append("")
    prompt_parts.append("### 6.2 Manutenibilidade")
    prompt_parts.append("- Melhorias na estrutura do código")
    prompt_parts.append("- Documentação adicional necessária")
    prompt_parts.append("- Testes automatizados recomendados")
    prompt_parts.append("- Padrões de codificação a implementar")
    prompt_parts.append("")
    
    prompt_parts.append("## FORMATO DA RESPOSTA")
    prompt_parts.append("Estruture sua análise em formato Markdown profissional com:")
    prompt_parts.append("- Cabeçalhos hierárquicos claros")
    prompt_parts.append("- Tabelas para dados estruturados")
    prompt_parts.append("- Listas para enumerações")
    prompt_parts.append("- Código COBOL em blocos de código quando necessário")
    prompt_parts.append("- Diagramas textuais para fluxos complexos")
    prompt_parts.append("")
    prompt_parts.append("IMPORTANTE: Esta análise será utilizada por:")
    prompt_parts.append("- Arquitetos de software para decisões técnicas")
    prompt_parts.append("- Analistas de negócio para compreensão funcional")
    prompt_parts.append("- Desenvolvedores para manutenção e evolução")
    prompt_parts.append("- Gestores para planejamento estratégico")
    prompt_parts.append("")
    prompt_parts.append("Seja EXTREMAMENTE DETALHADO e TÉCNICO. Não omita informações importantes.")
    prompt_parts.append("")
    prompt_parts.append("RESPONDA SEMPRE EM PORTUGUÊS BRASILEIRO com linguagem técnica precisa e profissional.")
    prompt_parts.append("Forneça exemplos específicos do código quando relevante.")
    prompt_parts.append("Analise o sistema como um TODO INTEGRADO, não programas isolados.")
    
    return "\n".join(prompt_parts)


def generate_consolidated_documentation_simple(analysis_result, system_context, programs, copybooks, output_dir, model, cost):
    """Gera documentação consolidada simplificada."""
    from datetime import datetime
    
    # Gerar documento principal
    main_doc_path = os.path.join(output_dir, f"ANALISE_CONSOLIDADA_SISTEMA_BANCARIO_{model.replace('-', '_')}.md")
    
    with open(main_doc_path, 'w', encoding='utf-8') as f:
        f.write("# ANÁLISE CONSOLIDADA DO SISTEMA BANCÁRIO COBOL\n\n")
        f.write(f"**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n")
        f.write(f"**Modelo Utilizado:** {analysis_result.model}\n")
        f.write(f"**Provider:** {analysis_result.provider}\n")
        f.write(f"**Tokens Utilizados:** {analysis_result.tokens_used:,}\n")
        f.write(f"**Custo Estimado:** ${cost:.4f}\n")
        f.write(f"**Tempo de Processamento:** {analysis_result.response_time:.2f} segundos\n\n")
        
        f.write("---\n\n")
        f.write(analysis_result.content)
    
    # Gerar relatório de metadados
    metadata_path = os.path.join(output_dir, f"metadados_sistema_{model.replace('-', '_')}.json")
    
    import json
    metadata = {
        'timestamp': datetime.now().isoformat(),
        'analysis_type': 'consolidated_system_analysis',
        'model_used': model,
        'system_context': system_context,
        'programs_analyzed': list(programs.keys()),
        'copybooks_analyzed': list(copybooks.keys()),
        'processing_stats': {
            'tokens_used': analysis_result.tokens_used,
            'processing_time': analysis_result.response_time,
            'estimated_cost': cost,
            'model_used': analysis_result.model,
            'provider_used': analysis_result.provider
        }
    }
    
    with open(metadata_path, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
    
    return {
        'success': True,
        'analysis_content': analysis_result.content,
        'files_generated': {
            'main_document': main_doc_path,
            'metadata': metadata_path
        },
        'stats': {
            'programs_analyzed': len(programs),
            'copybooks_analyzed': len(copybooks),
            'tokens_used': analysis_result.tokens_used,
            'processing_time': analysis_result.response_time,
            'estimated_cost': cost,
            'model_used': analysis_result.model,
            'provider_used': analysis_result.provider
        }
    }


def main():
    """Função principal."""
    parser = argparse.ArgumentParser(
        description="COBOL to Docs v1.0 - Análise e Documentação de Programas COBOL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  python main.py --fontes examples/fontes.txt
  python main.py --fontes examples/fontes.txt --books examples/books.txt
  python main.py --fontes examples/fontes.txt --models '["aws-claude-3.7", "enhanced_mock"]'
  python main.py --fontes examples/fontes.txt --consolidado
  python main.py --fontes examples/fontes.txt --books examples/books.txt --consolidado --models enhanced_mock
  python main.py --status
        """
    )
    
    parser.add_argument('--fontes', type=str, help='Arquivo com programas COBOL')
    parser.add_argument('--books', type=str, help='Arquivo com copybooks COBOL')
    parser.add_argument('--output', type=str, default='output', help='Diretório de saída')
    parser.add_argument('--models', type=str, help='Modelos de IA (string ou JSON array)')
    parser.add_argument('--prompt-set', type=str, default='original', help='Conjunto de prompts')
    parser.add_argument('--log-level', type=str, default='INFO', help='Nível de log')
    parser.add_argument('--pdf', action='store_true', help='Gerar relatórios HTML/PDF')
    parser.add_argument('--relatorio-unico', action='store_true',
                        help='Gera relatório único consolidado de todo o sistema')
    parser.add_argument('--consolidado', action='store_true',
                        help='Análise consolidada sistêmica de todos os programas simultaneamente')
    parser.add_argument('--analise-especialista', action='store_true',
                        help='Usa prompts especializados para análise técnica profunda')

    parser.add_argument('--procedure-detalhada', action='store_true',
                        help='Foca na análise detalhada da PROCEDURE DIVISION')
    parser.add_argument('--modernizacao', action='store_true',
                        help='Inclui análise de modernização e migração')
    parser.add_argument('--status', action='store_true', help='Verificar status dos provedores')
    parser.add_argument('--auto-model', action='store_true', 
                        help='Seleção automática de modelo baseada na complexidade do código')
    parser.add_argument('--model-comparison', action='store_true',
                        help='Exibir comparação de adequação de modelos para o código')
    parser.add_argument('--deep-analysis', action='store_true',
                        help='Análise detalhada de regras de negócio com valores específicos')
    parser.add_argument('--extract-formulas', action='store_true',
                        help='Extrair fórmulas matemáticas e cálculos específicos do código')
    parser.add_argument('--advanced-analysis', action='store_true',
                        help='Executar análise avançada com relatório consolidado HTML profissional')
    
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    try:
        # Carregar configuração
        config_manager = ConfigManager()
        
        # Inicializar sistema RAG
        rag_integration = RAGIntegration(config_manager.config)
        if rag_integration.is_enabled():
            rag_stats = rag_integration.get_rag_statistics()
            logger.info(f"Sistema RAG inicializado: {rag_stats['total_items']} itens na base de conhecimento")
        else:
            logger.info("Sistema RAG desabilitado")
        
        # Inicializar calculadora de custos
        cost_calculator = CostCalculator()
        
        # Verificar status se solicitado
        if args.status:
            provider_manager = EnhancedProviderManager(config_manager.config)
            print("=== STATUS DOS PROVEDORES ===")
            # Verificar status de cada provider
            providers = ['luzia', 'enhanced_mock', 'basic']
            for name in providers:
                try:
                    available = provider_manager.get_provider_status(name)
                    print(f"  {name}: {'Disponível' if available else 'Indisponível'}")
                except Exception as e:
                    print(f"  {name}: Erro - {e}")
            return
        
        # Validar argumentos
        if not args.fontes:
            print("Erro: --fontes é obrigatório")
            parser.print_help()
            return
        
        if not os.path.exists(args.fontes):
            print(f"Erro: Arquivo não encontrado: {args.fontes}")
            return
        
        # Processar arquivos COBOL
        process_cobol_files(args, config_manager, cost_calculator, rag_integration)
        
        # Finalizar sessão RAG e gerar relatório
        if rag_integration.is_enabled():
            try:
                rag_report = rag_integration.finalize_session()
                if rag_report:
                    logger.info(f"Relatório de uso do RAG gerado: {rag_report}")
                    print(f"\n=== RELATÓRIO RAG DISPONÍVEL ===")
                    print(f"Arquivo: {rag_report}")
                    
                    # Exibir resumo da sessão
                    session_summary = rag_integration.get_session_summary()
                    if session_summary:
                        print(f"Operações RAG realizadas: {session_summary.get('total_operations', 0)}")
                        print(f"Programas analisados: {len(session_summary.get('programs_analyzed', []))}")
                        print(f"Itens de conhecimento utilizados: {session_summary.get('knowledge_items_used', 0)}")
                        print("=" * 40)
            except Exception as e:
                logger.warning(f"Erro ao finalizar sessão RAG: {e}")
        
    except KeyboardInterrupt:
        print("\nProcessamento interrompido pelo usuário.")
    except Exception as e:
        import traceback
        logger.error(f"Erro fatal: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        print(f"Erro: {str(e)}")
        print("Traceback completo:")
        traceback.print_exc()

if __name__ == "__main__":
    main()
