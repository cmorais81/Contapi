#!/usr/bin/env python3
"""
COBOL Analyzer CLI - Interface de linha de comando
Ponto de entrada alternativo para a aplicação
"""

import sys
import os

# Adicionar src ao path
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(os.path.dirname(current_dir), 'src')
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

def main():
    """Ponto de entrada CLI - redireciona para main.py"""
    from main import main as main_function
    main_function()

if __name__ == "__main__":
    main()
