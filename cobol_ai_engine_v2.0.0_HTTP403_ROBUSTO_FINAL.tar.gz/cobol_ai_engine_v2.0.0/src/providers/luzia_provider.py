#!/usr/bin/env python3
"""
Provedor LuzIA v2.0.0 Final - Integração completa com configuração YAML
Implementa todas as correções identificadas e leitura de configuração do YAML.
"""

import os
import json
import logging
import time
import warnings
import re
from typing import Dict, Any, Optional, List
from datetime import datetime

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse


class LuziaProvider(BaseProvider):
    """
    Provedor LuzIA v2.0.0 Final com integração completa ao YAML.
    
    Características:
    1. Lê todas as configurações do config_unified.yaml
    2. Respeita configuração de token splitting por provedor
    3. Payload JSON completo e correto
    4. Headers e autenticação adequados
    5. Tratamento robusto de erros
    6. Parsing flexível de respostas
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor LuzIA v2.0.0 Final.
        
        Args:
            config: Configuração completa do YAML incluindo configurações globais
        """
        super().__init__(config)
        
        if not REQUESTS_AVAILABLE:
            raise ImportError("requests é necessário para o LuziaProvider")
        
        # Configurações do provedor LuzIA do YAML
        luzia_config = config.get('luzia', {})
        
        # Credenciais e URLs - Expandir variáveis de ambiente do YAML
        self.client_id = self._expand_env_vars(luzia_config.get('client_id', '${LUZIA_CLIENT_ID}'))
        self.client_secret = self._expand_env_vars(luzia_config.get('client_secret', '${LUZIA_CLIENT_SECRET}'))
        self.sso_endpoint = self._expand_env_vars(luzia_config.get('auth_url', 'https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token'))
        self.base_url = self._expand_env_vars(luzia_config.get('api_url', 'https://gpt-api-aws.santanderbr.dev.corp/genai_services/v1/chat/completions'))
        
        # Configurações do modelo
        self.model = luzia_config.get('model', 'azure-gpt-4o-mini')
        self.temperature = luzia_config.get('temperature', 0.1)
        self.max_tokens = luzia_config.get('max_tokens', 4000)
        self.timeout = luzia_config.get('timeout', 180.0)
        
        # Configurações de token management específicas do LuzIA
        token_config = config.get('performance', {}).get('token_management', {})
        provider_specific = token_config.get('provider_specific', {}).get('luzia', {})
        
        self.enable_token_splitting = provider_specific.get('enable_token_splitting', False)
        self.max_tokens_per_request = provider_specific.get('max_tokens_per_request', 200000)
        
        # Configurações de retry e rate limiting
        retry_config = luzia_config.get('retry', {})
        self.max_retries = retry_config.get('max_attempts', 5)
        self.base_delay = retry_config.get('base_delay', 2.0)
        self.max_delay = retry_config.get('max_delay', 60.0)
        self.backoff_multiplier = retry_config.get('backoff_multiplier', 2.0)
        
        # Rate limiting
        self.requests_per_minute = retry_config.get('requests_per_minute', 10)
        self.request_timestamps = []
        
        # Token de acesso e controle de expiração
        self._token = None
        self._token_expires_at = None
        
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"LuzIA Provider v2.1.2 inicializado com retry e rate limiting")
        self.logger.info(f"Modelo: {self.model}")
        self.logger.info(f"Token splitting: {'Habilitado' if self.enable_token_splitting else 'Desabilitado'}")
        self.logger.info(f"Max retries: {self.max_retries}")
        self.logger.info(f"Rate limit: {self.requests_per_minute} req/min")
        self.logger.info(f"Max tokens por requisição: {self.max_tokens_per_request}")
        self.logger.debug(f"Client ID: {self.client_id[:8] if self.client_id else 'N/A'}...")
        self.logger.debug(f"Auth URL: {self.sso_endpoint}")
        self.logger.debug(f"API URL: {self.base_url}")
    
    def _expand_env_vars(self, value: str) -> str:
        """
        Expande variáveis de ambiente no formato ${VAR_NAME}.
        
        Args:
            value: String que pode conter variáveis de ambiente
            
        Returns:
            String com variáveis expandidas
        """
        if not isinstance(value, str):
            return value
        
        # Padrão para encontrar ${VAR_NAME}
        pattern = r'\$\{([^}]+)\}'
        
        def replace_var(match):
            var_name = match.group(1)
            return os.getenv(var_name, match.group(0))  # Retorna a variável original se não encontrada
        
        return re.sub(pattern, replace_var, value)
    
    def is_available(self) -> bool:
        """
        Verifica se o provedor LuzIA está disponível.
        
        Returns:
            bool: True se as credenciais estão configuradas
        """
        return (
            bool(self.client_id and not self.client_id.startswith('${')) and
            bool(self.client_secret and not self.client_secret.startswith('${'))
        )
    
    def _is_token_expired(self) -> bool:
        """
        Verifica se o token atual está expirado ou prestes a expirar.
        
        Returns:
            bool: True se o token estiver expirado ou não existir
        """
        if not self._token or not self._token_expires_at:
            return True
        
        return time.time() >= self._token_expires_at
    
    def _ensure_valid_token(self) -> None:
        """
        Garante que temos um token válido, renovando se necessário.
        """
        if self._is_token_expired():
            self.logger.info("Token expirado ou inexistente, renovando...")
            self.get_token()
    
    def get_token(self) -> str:
        """
        Obtém token OAuth2 do LuzIA.
        
        Returns:
            str: Token de acesso
            
        Raises:
            Exception: Se não conseguir obter o token
        """
        try:
            # Verificar se as credenciais estão configuradas
            if not self.client_id or self.client_id.startswith('${'):
                raise Exception("LUZIA_CLIENT_ID não configurado nas variáveis de ambiente")
            
            if not self.client_secret or self.client_secret.startswith('${'):
                raise Exception("LUZIA_CLIENT_SECRET não configurado nas variáveis de ambiente")
            
            # Payload OAuth2 client_credentials
            request_body = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            # Headers para autenticação
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': '*/*'
            }
            
            self.logger.debug("Solicitando token OAuth2...")
            
            # Fazer requisição de token
            response = requests.post(
                self.sso_endpoint,
                headers=headers,
                data=request_body,
                verify=False,
                timeout=30
            )
            
            if response.status_code == 200:
                token_data = response.json()
                raw_token = token_data.get('access_token')
                
                if not raw_token:
                    raise Exception("Token não encontrado na resposta")
                
                # Limpar token de caracteres problemáticos e validar formato
                clean_token = str(raw_token).strip()
                
                # Remover caracteres invisíveis e quebras de linha
                clean_token = ''.join(char for char in clean_token if char.isprintable() and not char.isspace())
                
                # Validar se o token não está vazio após limpeza
                if not clean_token:
                    raise Exception("Token vazio após validação")
                
                # Validar formato básico do token JWT
                if clean_token.count('.') < 2:
                    self.logger.warning("Token obtido não parece ser um JWT válido")
                
                self._token = clean_token
                
                # Log do token (apenas primeiros/últimos caracteres por segurança)
                token_preview = f"{self._token[:10]}...{self._token[-10:]}" if len(self._token) > 20 else "***"
                self.logger.debug(f"Token obtido: {token_preview}")
                
                # Calcular tempo de expiração (padrão 3600 segundos se não especificado)
                expires_in = token_data.get('expires_in', 3600)
                self._token_expires_at = time.time() + expires_in - 60  # 60s de margem de segurança
                
                self.logger.info(f"Token OAuth2 obtido com sucesso (expira em {expires_in}s)")
                return self._token
            else:
                error_msg = f"Erro ao obter token: {response.status_code} - {response.text}"
                self.logger.error(error_msg)
                raise Exception(error_msg)
                
        except requests.exceptions.RequestException as e:
            error_msg = f"Erro de conexão ao obter token: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
        except Exception as e:
            error_msg = f"Erro inesperado ao obter token: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
    
    def create_complete_payload(self, system_prompt: str, user_prompt: str) -> Dict[str, Any]:
        """
        Cria payload JSON completo e correto para API LuzIA.
        
        Baseado no erro real: config deve ser uma lista, não um objeto
        
        Args:
            system_prompt: Prompt do sistema
            user_prompt: Prompt do usuário
            
        Returns:
            Dict: Payload completo para API
        """
        payload = {
            "input": {
                "query": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user", 
                        "content": user_prompt
                    }
                ]
            },
            "config": [
                {
                    "type": "catena.llm.LLMRouter",
                    "obj_kwargs": {
                        "routing_model": self.model,
                        "temperature": self.temperature,
                        "max_tokens": self.max_tokens
                    }
                }
            ]
        }
        
        return payload
    
    def validate_payload(self, payload: Dict[str, Any]) -> None:
        """
        Valida estrutura do payload antes de enviar.
        
        Args:
            payload: Payload a ser validado
            
        Raises:
            ValueError: Se payload estiver inválido
        """
        # Verificações baseadas na estrutura correta: {"input": {"query": [...]}, "config": [...]}
        if "input" not in payload:
            raise ValueError("Payload deve conter 'input'")
        
        if not isinstance(payload["input"], dict):
            raise ValueError("input deve ser um dicionário")
        
        if "query" not in payload["input"]:
            raise ValueError("input deve conter 'query'")
        
        if not isinstance(payload["input"]["query"], list):
            raise ValueError("input.query deve ser uma lista")
        
        if len(payload["input"]["query"]) == 0:
            raise ValueError("input.query não pode estar vazio")
        
        # Validar mensagens
        for i, msg in enumerate(payload["input"]["query"]):
            if not isinstance(msg, dict):
                raise ValueError(f"Mensagem {i} deve ser um dicionário")
            if "role" not in msg or "content" not in msg:
                raise ValueError(f"Mensagem {i} deve ter 'role' e 'content'")
        
        if "config" not in payload:
            raise ValueError("Payload deve conter 'config'")
        
        if not isinstance(payload["config"], list):
            raise ValueError("config deve ser uma lista")
        
        if len(payload["config"]) == 0:
            raise ValueError("config não pode estar vazio")
        
        # Validar primeiro item da config
        config_item = payload["config"][0]
        if not isinstance(config_item, dict):
            raise ValueError("Item da config deve ser um dicionário")
        
        if "type" not in config_item:
            raise ValueError("Item da config deve conter 'type'")
        
        if "obj_kwargs" not in config_item:
            raise ValueError("Item da config deve conter 'obj_kwargs'")
        
        self.logger.debug("Payload validado com sucesso")
    
    def submit_request_with_retry(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Submete requisição com retry automático e rate limiting.
        
        Args:
            payload: Payload da requisição
            
        Returns:
            Dict: Resposta da API
            
        Raises:
            Exception: Se todas as tentativas falharem
        """
        # Validar payload antes de enviar
        self.validate_payload(payload)
        
        # Rate limiting
        self._enforce_rate_limit()
        
        # Garantir token válido antes de fazer a requisição
        self._ensure_valid_token()
        
        # Validar token antes de usar
        if not self._token or not isinstance(self._token, str):
            raise Exception("Token inválido ou não definido")
        
        # Limpar token de caracteres problemáticos e validar formato
        clean_token = str(self._token).strip()
        
        # Remover caracteres invisíveis e quebras de linha
        clean_token = ''.join(char for char in clean_token if char.isprintable() and not char.isspace())
        
        if not clean_token:
            raise Exception("Token vazio após limpeza")
        
        # Validar formato básico do token JWT (deve ter pelo menos 2 pontos)
        if clean_token.count('.') < 2:
            self.logger.warning("Token não parece ser um JWT válido")
        
        # Construir cabeçalho de forma mais robusta
        auth_header = f"Bearer {clean_token}"
        
        # Validar se o cabeçalho não contém caracteres problemáticos
        if any(char in auth_header for char in ['\n', '\r', '\t', '\0']):
            raise Exception("Token contém caracteres inválidos")
        
        headers = {
            'Content-Type': 'application/json',
            'Authorization': auth_header,
            'Accept': 'application/json',
            'User-Agent': 'COBOL-AI-Engine/2.0.0'
        }
        
        last_exception = None
        
        for attempt in range(self.max_retries):
            try:
                self.logger.debug(f"Tentativa {attempt + 1}/{self.max_retries}")
                
                # Fazer requisição
                response = requests.post(
                    self.base_url,
                    headers=headers,
                    json=payload,
                    verify=False,
                    timeout=self.timeout
                )
                
                # Log da resposta para debug
                self.logger.debug(f"Status: {response.status_code}")
                self.logger.debug(f"Headers: {dict(response.headers)}")
                
                if response.status_code in [200, 201]:
                    try:
                        response_data = response.json()
                        self.logger.info(f"Requisição bem-sucedida (HTTP {response.status_code})")
                        return response_data
                    except json.JSONDecodeError as e:
                        self.logger.error(f"Erro ao decodificar JSON: {e}")
                        self.logger.error(f"Resposta bruta: {response.text[:500]}")
                        raise Exception(f"Resposta inválida da API: {e}")
                
                elif response.status_code == 401:
                    # Token expirado ou inválido, forçar renovação
                    self.logger.warning(f"Erro 401 - Token inválido/expirado na tentativa {attempt + 1}")
                    self._token = None
                    self._token_expires_at = None
                    
                    try:
                        self.get_token()
                        # Validar e limpar token renovado com mesma lógica robusta
                        clean_token = str(self._token).strip() if self._token else ""
                        clean_token = ''.join(char for char in clean_token if char.isprintable() and not char.isspace())
                        
                        if not clean_token:
                            raise Exception("Token renovado está vazio")
                        
                        # Validar formato do token renovado
                        if clean_token.count('.') < 2:
                            self.logger.warning("Token renovado não parece ser um JWT válido")
                        
                        # Construir novo cabeçalho
                        new_auth_header = f"Bearer {clean_token}"
                        
                        # Validar se não contém caracteres problemáticos
                        if any(char in new_auth_header for char in ['\n', '\r', '\t', '\0']):
                            raise Exception("Token renovado contém caracteres inválidos")
                        
                        headers['Authorization'] = new_auth_header
                        self.logger.info("Token renovado com sucesso, tentando novamente...")
                        continue
                    except Exception as token_error:
                        self.logger.error(f"Falha ao renovar token: {token_error}")
                        last_exception = Exception(f"Falha na renovação de token: {token_error}")
                        # Se não conseguir renovar token, continuar para próxima tentativa
                
                else:
                    error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                    self.logger.error(error_msg)
                    
                    # Se for erro 4xx (exceto 401), não tentar novamente
                    if 400 <= response.status_code < 500 and response.status_code != 401:
                        raise Exception(error_msg)
                    
                    last_exception = Exception(error_msg)
                    
            except requests.exceptions.RequestException as e:
                error_msg = f"Erro de conexão: {str(e)}"
                self.logger.error(error_msg)
                last_exception = Exception(error_msg)
            
            except Exception as e:
                error_msg = f"Erro inesperado: {str(e)}"
                self.logger.error(error_msg)
                last_exception = Exception(error_msg)
            
            # Aguardar antes da próxima tentativa (exceto na última)
            if attempt < self.max_retries - 1:
                delay = min(self.base_delay * (self.backoff_multiplier ** attempt), self.max_delay)
                self.logger.info(f"Aguardando {delay:.1f}s antes da próxima tentativa...")
                time.sleep(delay)
        
        # Se chegou aqui, todas as tentativas falharam
        error_msg = f"Todas as {self.max_retries} tentativas falharam"
        if last_exception:
            error_msg += f". Último erro: {str(last_exception)}"
        
        self.logger.error(error_msg)
        raise Exception(error_msg)
    
    def _enforce_rate_limit(self) -> None:
        """
        Aplica rate limiting baseado em requests por minuto.
        """
        now = time.time()
        
        # Remover timestamps antigos (mais de 1 minuto)
        self.request_timestamps = [ts for ts in self.request_timestamps if now - ts < 60]
        
        # Verificar se excedeu o limite
        if len(self.request_timestamps) >= self.requests_per_minute:
            # Calcular tempo de espera
            oldest_request = min(self.request_timestamps)
            wait_time = 60 - (now - oldest_request)
            
            if wait_time > 0:
                self.logger.info(f"Rate limit atingido. Aguardando {wait_time:.1f}s...")
                time.sleep(wait_time)
        
        # Adicionar timestamp atual
        self.request_timestamps.append(now)
    
    def extract_response_content(self, response_data: Dict[str, Any]) -> str:
        """
        Extrai conteúdo da resposta da API LuzIA.
        
        Args:
            response_data: Dados da resposta da API
            
        Returns:
            str: Conteúdo extraído
            
        Raises:
            Exception: Se não conseguir extrair o conteúdo
        """
        try:
            # Múltiplos caminhos para extrair conteúdo
            content_paths = [
                ['output', 'content'],
                ['result', 'content'],
                ['response', 'content'],
                ['data', 'content'],
                ['content'],
                ['output'],
                ['result'],
                ['response']
            ]
            
            for path in content_paths:
                try:
                    current = response_data
                    for key in path:
                        current = current[key]
                    
                    if isinstance(current, str) and current.strip():
                        self.logger.debug(f"Conteúdo extraído via path: {' -> '.join(path)}")
                        return current.strip()
                    
                except (KeyError, TypeError):
                    continue
            
            # Se não encontrou por paths, tentar buscar recursivamente
            content = self._find_content_recursive(response_data)
            if content:
                return content
            
            # Último recurso: converter resposta inteira para string
            self.logger.warning("Não foi possível extrair conteúdo estruturado, usando resposta completa")
            return json.dumps(response_data, indent=2, ensure_ascii=False)
            
        except Exception as e:
            error_msg = f"Erro ao extrair conteúdo da resposta: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
    
    def _find_content_recursive(self, data: Any, depth: int = 0) -> Optional[str]:
        """
        Busca recursivamente por conteúdo na resposta.
        
        Args:
            data: Dados para buscar
            depth: Profundidade atual (para evitar recursão infinita)
            
        Returns:
            Optional[str]: Conteúdo encontrado ou None
        """
        if depth > 5:  # Limitar profundidade
            return None
        
        if isinstance(data, str) and len(data.strip()) > 50:  # Conteúdo substancial
            return data.strip()
        
        elif isinstance(data, dict):
            # Priorizar chaves que provavelmente contêm conteúdo
            priority_keys = ['content', 'text', 'message', 'response', 'result', 'output']
            
            for key in priority_keys:
                if key in data:
                    result = self._find_content_recursive(data[key], depth + 1)
                    if result:
                        return result
            
            # Buscar em outras chaves
            for key, value in data.items():
                if key not in priority_keys:
                    result = self._find_content_recursive(value, depth + 1)
                    if result:
                        return result
        
        elif isinstance(data, list) and data:
            # Buscar no primeiro item da lista
            result = self._find_content_recursive(data[0], depth + 1)
            if result:
                return result
        
        return None
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Executa a análise com o provedor LuzIA, com fallback para mock em caso de erro.
        """
        try:
            # Extrair system e user prompt
            prompt_parts = request.prompt.split("=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===", 1)
            if len(prompt_parts) == 2:
                system_prompt = prompt_parts[0].strip()
                user_prompt = "=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===" + prompt_parts[1]
            else:
                system_prompt = "Você é um analista de sistemas COBOL especializado."
                user_prompt = request.prompt

            # 1. Criar o payload
            payload = self.create_complete_payload(system_prompt, user_prompt)

            # 2. Submeter a requisição
            response_data = self.submit_request_with_retry(payload)

            # 3. Extrair o conteúdo
            content = self.extract_response_content(response_data)

            # 4. Criar a resposta
            return AIResponse(
                success=True,
                content=content,
                tokens_used=len(content) // 4,
                model=self.model,
                provider="luzia",
            )
        except Exception as e:
            self.logger.error(f"Falha na análise com LuzIA: {e}")
            # Retornar erro em vez de fallback
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=self.model,
                provider="luzia",
                error_message=f"Erro de conectividade com LuzIA: {str(e)}",
                metadata={
                    "program_name": request.program_name,
                    "error_type": "connectivity_error",
                    "error_details": str(e)
                }
            )

    def _get_mock_response(self, request: AIRequest) -> AIResponse:
        """
        Gera uma resposta de mock detalhada e descritiva.
        """
        mock_content = f"""
# Análise Detalhada do Programa: {request.program_name}

## 1. Análise Funcional Detalhada

O programa **{request.program_name}** é um componente crítico no sistema de processamento de transações financeiras. Sua principal finalidade é orquestrar o fluxo de validação, enriquecimento e roteamento de operações interbancárias. Ele atua como um ponto central de controle, garantindo que todas as transações sejam processadas de acordo com as políticas de conformidade e as regras de negócio da instituição. O programa é responsável por ler arquivos de transações recebidos de sistemas parceiros, aplicar uma série de validações rigorosas, enriquecer os dados com informações de clientes e contas, e, finalmente, direcionar as transações para os sistemas de liquidação apropriados. A sua execução é tipicamente agendada em lotes (batch) durante a janela de processamento noturno.

## 2. Análise de Regras de Negócio Exaustiva

O programa implementa um conjunto complexo e extenso de regras de negócio, que são fundamentais para a integridade e a conformidade do processo de transações. As regras mais significativas incluem:

- **Validação de Limites de Transação:** O programa verifica se o valor de cada transação excede os limites pré-estabelecidos para o tipo de conta e o perfil do cliente. Transações que violam esses limites são marcadas para revisão manual.
- **Verificação de Sanções e Listas de Restrição:** Uma regra de negócio crítica é a verificação do nome do originador e do beneficiário da transação contra listas de sanções internacionais e listas de restrição internas. Qualquer correspondência resulta no bloqueio imediato da transação e na geração de um alerta para o departamento de compliance.
- **Cálculo de Tarifas e Impostos:** O programa calcula as tarifas de serviço e os impostos aplicáveis a cada transação, com base no tipo de operação, no valor e na jurisdição. A lógica de cálculo é complexa e envolve a consulta a tabelas de parâmetros que são atualizadas regularmente.

## 3. Análise Técnica Arquitetural Profunda

Do ponto de vista técnico, o programa **{request.program_name}** é um programa COBOL estruturado, projetado para alta performance e processamento de grandes volumes de dados. Ele utiliza uma arquitetura de processamento em lote tradicional, com as seguintes características:

- **Estrutura de Arquivos:** O programa opera sobre arquivos sequenciais (QSAM) para entrada e saída de dados. Ele lê um arquivo de transações de entrada, processa cada registro e gera múltiplos arquivos de saída, incluindo um arquivo de transações validadas, um arquivo de rejeições e um arquivo de log detalhado.
- **Interação com Banco de Dados:** Para o enriquecimento de dados, o programa realiza chamadas a um banco de dados DB2 para obter informações de clientes e contas. As chamadas são encapsuladas em módulos de acesso a dados (DAOs) para promover a reutilização e a manutenibilidade.
- **Modularidade:** O programa é altamente modular, com a lógica de negócio dividida em parágrafos e seções bem definidas. A lógica de validação, enriquecimento e roteamento é separada em módulos distintos, o que facilita a compreensão e a modificação do código.
"""

        return AIResponse(
            success=True,
            content=mock_content,
            tokens_used=len(mock_content) // 4,  # Estimativa
            model="mock-aws-claude-3-5-sonnet",
            provider="luzia-mock-fallback",
            timestamp=datetime.now(),
            error_message="",
            metadata={
                "program_name": request.program_name,
                "analysis_type": "enhanced_descriptive_mock"
            }
        )
