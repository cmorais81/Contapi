"""
Provedor LuzIA v2.0.0 Final - Integração completa com configuração YAML
Implementa todas as correções identificadas e leitura de configuração do YAML.
"""

import os
import json
import logging
import warnings
from typing import Dict, Any, Optional, List
from datetime import datetime

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse


class LuziaProvider(BaseProvider):
    """
    Provedor LuzIA v2.0.0 Final com integração completa ao YAML.
    
    Características:
    1. Lê todas as configurações do config_unified.yaml
    2. Respeita configuração de token splitting por provedor
    3. Payload JSON completo e correto
    4. Headers e autenticação adequados
    5. Tratamento robusto de erros
    6. Parsing flexível de respostas
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor LuzIA v2.0.0 Final.
        
        Args:
            config: Configuração completa do YAML incluindo configurações globais
        """
        super().__init__(config)
        
        if not REQUESTS_AVAILABLE:
            raise ImportError("requests é necessário para o LuziaProvider")
        
        # Configurações do provedor LuzIA do YAML
        luzia_config = config.get('luzia', {})
        
        # Credenciais e URLs
        self.client_id = luzia_config.get('client_id', os.getenv('LUZIA_CLIENT_ID', '71530749-db0a-424c-8a1c-72bf90315afa'))
        self.client_secret = luzia_config.get('client_secret', os.getenv('LUZIA_CLIENT_SECRET', '90a337834c9vH9zXAqc3D0g0031f73'))
        self.sso_endpoint = luzia_config.get('auth_url', os.getenv('LUZIA_AUTH_URL', 'https://login.azure.pass.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token'))
        self.base_url = luzia_config.get('api_url', os.getenv('LUZIA_API_URL', 'https://prd-api-aws.santanderbr.dev.corp/genai_services/v1'))
        
        # Configurações do modelo
        self.model = luzia_config.get('model', 'azure-gpt-4o-mini')
        self.temperature = luzia_config.get('temperature', 0.1)
        self.max_tokens = luzia_config.get('max_tokens', 4000)
        self.timeout = luzia_config.get('timeout', 180.0)
        
        # Configurações de token management específicas do LuzIA
        token_config = config.get('performance', {}).get('token_management', {})
        provider_specific = token_config.get('provider_specific', {}).get('luzia', {})
        
        self.enable_token_splitting = provider_specific.get('enable_token_splitting', False)
        self.max_tokens_per_request = provider_specific.get('max_tokens_per_request', 200000)
        
        # Configurações de retry e rate limiting
        retry_config = luzia_config.get('retry', {})
        self.max_retries = retry_config.get('max_attempts', 5)
        self.base_delay = retry_config.get('base_delay', 2.0)
        self.max_delay = retry_config.get('max_delay', 60.0)
        self.backoff_multiplier = retry_config.get('backoff_multiplier', 2.0)
        
        # Rate limiting
        self.requests_per_minute = retry_config.get('requests_per_minute', 10)
        self.request_timestamps = []
        
        # Token de acesso
        self._token = None
        
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"LuzIA Provider v2.1.2 inicializado com retry e rate limiting")
        self.logger.info(f"Modelo: {self.model}")
        self.logger.info(f"Token splitting: {'Habilitado' if self.enable_token_splitting else 'Desabilitado'}")
        self.logger.info(f"Max retries: {self.max_retries}")
        self.logger.info(f"Rate limit: {self.requests_per_minute} req/min")
        self.logger.info(f"Max tokens por requisição: {self.max_tokens_per_request}")
        self.logger.debug(f"Client ID: {self.client_id[:8]}...")
        self.logger.debug(f"Auth URL: {self.sso_endpoint}")
        self.logger.debug(f"API URL: {self.base_url}")
    
    def get_token(self) -> str:
        """
        Obtém token OAuth2 do LuzIA.
        
        Returns:
            str: Token de acesso
            
        Raises:
            Exception: Se não conseguir obter o token
        """
        try:
            # Payload OAuth2 client_credentials
            request_body = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            # Headers para autenticação
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': '*/*'
            }
            
            self.logger.debug("Solicitando token OAuth2...")
            
            # Fazer requisição de token
            response = requests.post(
                self.sso_endpoint,
                headers=headers,
                data=request_body,
                verify=False,
                timeout=30
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self._token = token_data.get('access_token')
                
                if not self._token:
                    raise Exception("Token não encontrado na resposta")
                
                self.logger.info(" Token OAuth2 obtido com sucesso")
                return self._token
            else:
                error_msg = f"Erro ao obter token: {response.status_code} - {response.text}"
                self.logger.error(error_msg)
                raise Exception(error_msg)
                
        except requests.exceptions.RequestException as e:
            error_msg = f"Erro de conexão ao obter token: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
        except Exception as e:
            error_msg = f"Erro inesperado ao obter token: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
    
    def create_complete_payload(self, system_prompt: str, user_prompt: str) -> Dict[str, Any]:
        """
        Cria payload JSON completo e correto para API LuzIA.
        
        Baseado no erro real: config deve ser uma lista, não um objeto
        
        Args:
            system_prompt: Prompt do sistema
            user_prompt: Prompt do usuário
            
        Returns:
            Dict: Payload completo para API
        """
        payload = {
            "input": {
                "query": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user", 
                        "content": user_prompt
                    }
                ]
            },
            "config": [
                {
                    "type": "catena.llm.LLMRouter",
                    "obj_kwargs": {
                        "routing_model": self.model,
                        "temperature": self.temperature,
                        "max_tokens": self.max_tokens
                    }
                }
            ]
        }
        
        return payload
    
    def validate_payload(self, payload: Dict[str, Any]) -> None:
        """
        Valida estrutura do payload antes de enviar.
        
        Args:
            payload: Payload a ser validado
            
        Raises:
            ValueError: Se payload estiver inválido
        """
        # Verificações baseadas na estrutura correta: {"input": {"query": [...]}, "config": [...]}
        if "input" not in payload:
            raise ValueError("Payload deve conter 'input'")
        
        if not isinstance(payload["input"], dict):
            raise ValueError("input deve ser um dicionário")
        
        if "query" not in payload["input"]:
            raise ValueError("input deve conter 'query'")
        
        if not isinstance(payload["input"]["query"], list):
            raise ValueError("input.query deve ser uma lista")
        
        if len(payload["input"]["query"]) == 0:
            raise ValueError("input.query não pode estar vazio")
        
        # Validar mensagens
        for i, msg in enumerate(payload["input"]["query"]):
            if not isinstance(msg, dict):
                raise ValueError(f"Mensagem {i} deve ser um dicionário")
            if "role" not in msg or "content" not in msg:
                raise ValueError(f"Mensagem {i} deve ter 'role' e 'content'")
        
        if "config" not in payload:
            raise ValueError("Payload deve conter 'config'")
        
        if not isinstance(payload["config"], list):
            raise ValueError("config deve ser uma lista")
        
        if len(payload["config"]) == 0:
            raise ValueError("config não pode estar vazio")
        
        # Validar primeiro item da config
        config_item = payload["config"][0]
        if not isinstance(config_item, dict):
            raise ValueError("Item da config deve ser um dicionário")
        
        if "type" not in config_item:
            raise ValueError("Item da config deve conter 'type'")
        
        if "obj_kwargs" not in config_item:
            raise ValueError("Item da config deve conter 'obj_kwargs'")
        
        self.logger.debug(" Payload validado com sucesso")
    
    def check_rate_limit(self) -> None:
        """
        Verifica e aplica rate limiting.
        """
        now = datetime.now()
        # Remove timestamps antigos (mais de 1 minuto)
        self.request_timestamps = [ts for ts in self.request_timestamps if (now - ts).seconds < 60]
        
        # Se atingiu o limite, aguarda
        if len(self.request_timestamps) >= self.requests_per_minute:
            oldest_request = min(self.request_timestamps)
            wait_time = 60 - (now - oldest_request).seconds
            if wait_time > 0:
                self.logger.info(f"Rate limit atingido. Aguardando {wait_time}s...")
                time.sleep(wait_time)
                # Limpa timestamps após espera
                self.request_timestamps = []
        
        # Registra nova requisição
        self.request_timestamps.append(now)
    
    def submit_request_with_retry(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Submete requisição para API LuzIA com retry e rate limiting.
        
        Args:
            payload: Payload da requisição
            
        Returns:
            Dict: Resposta da API
            
        Raises:
            Exception: Se todas as tentativas falharem
        """
        last_exception = None
        
        for attempt in range(self.max_retries + 1):
            try:
                # Aplicar rate limiting
                self.check_rate_limit()
                
                # Obter token se necessário
                if not self._token:
                    self.get_token()
                
                # Headers corretos
                headers = {
                    "x-santander-client-id": self.client_id,
                    "Authorization": f"Bearer {self._token}",
                    "Content-Type": "application/json",
                    "Accept": "application/json"
                }
                
                # Validar payload
                self.validate_payload(payload)
                
                # Log da tentativa
                if attempt > 0:
                    self.logger.info(f"Tentativa {attempt + 1}/{self.max_retries + 1}")
                
                # Serializar payload
                json_payload = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
                self.logger.debug(f"JSON payload size: {len(json_payload)} chars")
                
                # Fazer requisição
                response = requests.post(
                    f"{self.base_url}/pipelines/submit",
                    data=json_payload,
                    headers=headers,
                    timeout=self.timeout,
                    verify=False
                )
                
                self.logger.debug(f"Status Code: {response.status_code}")
                
                if response.status_code in [200, 201]:  # 201 também é sucesso para LuzIA
                    response_data = response.json()
                    self.logger.debug("Resposta recebida com sucesso")
                    return response_data
                
                # Tratar erros específicos
                elif response.status_code in [400, 429]:
                    error_text = response.text
                    self.logger.warning(f"Erro {response.status_code}: {error_text}")
                    
                    # Se é rate limiting, aguarda mais tempo
                    if "rate limit" in error_text.lower() or "too many requests" in error_text.lower():
                        if attempt < self.max_retries:
                            delay = min(self.base_delay * (self.backoff_multiplier ** attempt), self.max_delay)
                            self.logger.info(f"Rate limit detectado. Aguardando {delay}s antes da próxima tentativa...")
                            time.sleep(delay)
                            continue
                    
                    # Para outros erros 400, não tenta novamente
                    if response.status_code == 400 and "rate limit" not in error_text.lower():
                        raise Exception(f"Erro na API LuzIA: {response.status_code} - {error_text}")
                
                else:
                    error_text = response.text
                    self.logger.warning(f"Erro HTTP {response.status_code}: {error_text}")
                    
                    if attempt < self.max_retries:
                        delay = min(self.base_delay * (self.backoff_multiplier ** attempt), self.max_delay)
                        self.logger.info(f"Aguardando {delay}s antes da próxima tentativa...")
                        time.sleep(delay)
                        continue
                    else:
                        raise Exception(f"Erro na API LuzIA: {response.status_code} - {error_text}")
            
            except requests.exceptions.RequestException as e:
                last_exception = e
                self.logger.warning(f"Erro de conexão (tentativa {attempt + 1}): {str(e)}")
                
                if attempt < self.max_retries:
                    delay = min(self.base_delay * (self.backoff_multiplier ** attempt), self.max_delay)
                    self.logger.info(f"Aguardando {delay}s antes da próxima tentativa...")
                    time.sleep(delay)
                    continue
                else:
                    raise Exception(f"Erro de conexão após {self.max_retries + 1} tentativas: {str(e)}")
            
            except Exception as e:
                last_exception = e
                self.logger.error(f"Erro inesperado (tentativa {attempt + 1}): {str(e)}")
                
                if attempt < self.max_retries:
                    delay = min(self.base_delay * (self.backoff_multiplier ** attempt), self.max_delay)
                    self.logger.info(f"Aguardando {delay}s antes da próxima tentativa...")
                    time.sleep(delay)
                    continue
                else:
                    raise
        
        # Se chegou aqui, todas as tentativas falharam
        raise Exception(f"Todas as {self.max_retries + 1} tentativas falharam. Último erro: {str(last_exception)}")

    def submit_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Submete requisição para API LuzIA (wrapper para método com retry).
        
        Args:
            payload: Payload da requisição
            
        Returns:
            Dict: Resposta da API
        """
        return self.submit_request_with_retry(payload)
    
    def extract_response_content(self, response_data: Dict[str, Any]) -> str:
        """
        Extrai conteúdo da resposta da API LuzIA.
        
        Baseado no exemplo real: {"output": {"content": "...", "metadata": {...}}}
        
        Args:
            response_data: Dados da resposta da API
            
        Returns:
            str: Conteúdo extraído da resposta
        """
        if not isinstance(response_data, dict):
            return str(response_data)
        
        # Estrutura principal do LuzIA: output.content
        if 'output' in response_data and isinstance(response_data['output'], dict):
            if 'content' in response_data['output']:
                content = response_data['output']['content']
                if content:
                    self.logger.debug("Conteúdo extraído via: output.content")
                    return str(content).strip()
        
        # Estruturas alternativas (fallback)
        possible_paths = [
            ['result', 'output'],
            ['output'],
            ['content'],
            ['response'],
            ['data', 'content'],
            ['body', 'output'],
            ['choices', 0, 'message', 'content'],  # Formato OpenAI-like
            ['message', 'content']
        ]
        
        for path in possible_paths:
            try:
                current = response_data
                for key in path:
                    if isinstance(current, dict) and key in current:
                        current = current[key]
                    elif isinstance(current, list) and isinstance(key, int) and len(current) > key:
                        current = current[key]
                    else:
                        break
                else:
                    # Se chegou até aqui, encontrou o caminho
                    content = str(current).strip()
                    if content:
                        self.logger.debug(f"Conteúdo extraído via: {' -> '.join(map(str, path))}")
                        return content
            except (KeyError, IndexError, TypeError):
                continue
        
        # Fallback - usar toda a resposta como string
        self.logger.warning("Usando resposta completa como fallback")
        return str(response_data)
    
    def extract_tokens_from_metadata(self, response_data: Dict[str, Any]) -> int:
        """
        Extrai número de tokens da metadata do LuzIA.
        
        Baseado no exemplo real: {"output": {"metadata": {"usage": [{"total_tokens": 43710}]}}}
        
        Args:
            response_data: Dados da resposta da API
            
        Returns:
            int: Número de tokens utilizados
        """
        try:
            # Estrutura principal do LuzIA: output.metadata.usage[0].total_tokens
            if ('output' in response_data and 
                isinstance(response_data['output'], dict) and
                'metadata' in response_data['output'] and
                isinstance(response_data['output']['metadata'], dict) and
                'usage' in response_data['output']['metadata'] and
                isinstance(response_data['output']['metadata']['usage'], list) and
                len(response_data['output']['metadata']['usage']) > 0):
                
                usage = response_data['output']['metadata']['usage'][0]
                if isinstance(usage, dict) and 'total_tokens' in usage:
                    tokens = int(usage['total_tokens'])
                    self.logger.debug(f"Tokens extraídos da metadata: {tokens}")
                    return tokens
            
        except Exception as e:
            self.logger.debug(f"Erro ao extrair tokens da metadata: {str(e)}")
        
        # Fallback - estimar baseado no tamanho do conteúdo
        content = self.extract_response_content(response_data)
        estimated = len(content.split()) * 2  # Estimativa grosseira
        self.logger.debug(f"Tokens estimados baseado no conteúdo: {estimated}")
        return estimated
    
    def is_available(self) -> bool:
        """
        Verifica se o provedor LuzIA está disponível.
        
        Returns:
            bool: True se disponível, False caso contrário
        """
        try:
            # Verificar credenciais básicas
            if not self.client_id or not self.client_secret:
                self.logger.warning("Credenciais LuzIA não configuradas")
                return False
            
            # Tentar obter token
            self.get_token()
            
            self.logger.info(" LuzIA disponível")
            return True
            
        except Exception as e:
            self.logger.error(f" LuzIA não disponível: {str(e)}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Analisa código COBOL usando LuzIA.
        
        Args:
            request: Requisição de análise
            
        Returns:
            AIResponse: Resposta da análise
        """
        try:
            # Carregar system prompt do arquivo de configuração
            from ..core.config import ConfigManager
            config_manager = ConfigManager("config/config_unified.yaml")
            system_prompt = config_manager.get_system_prompt()
            
            user_prompt = request.prompt
            
            # Verificar se deve dividir tokens (baseado na configuração)
            if self.enable_token_splitting:
                # TODO: Implementar divisão de tokens se necessário
                # Por enquanto, sempre envia completo
                self.logger.info("Token splitting habilitado, mas enviando completo por enquanto")
            
            # Criar payload completo
            payload = self.create_complete_payload(system_prompt, user_prompt)
            
            # Submeter requisição
            self.logger.info(f"Iniciando análise COBOL: {request.program_name}")
            response_data = self.submit_request(payload)
            
            # Processar resposta
            analysis_text = self.extract_response_content(response_data)
            
            # Extrair tokens da metadata do LuzIA
            total_tokens = self.extract_tokens_from_metadata(response_data)
            
            self.logger.info(f" Análise concluída - Tokens: {total_tokens}")
            
            return AIResponse(
                content=analysis_text,
                provider="luzia_v2_final",
                model=self.model,
                tokens_used=total_tokens,
                success=True,
                raw_response=response_data  # Adicionar resposta bruta para metadata
            )
            
        except Exception as e:
            error_msg = f"Erro na análise LuzIA: {str(e)}"
            self.logger.error(error_msg)
            
            return AIResponse(
                content=f"Erro na análise: {error_msg}",
                provider="luzia_v2_final",
                model=self.model,
                tokens_used=0,
                success=False,
                error_message=error_msg
            )
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Testa conexão com API LuzIA usando payload simples.
        
        Returns:
            Dict: Resultado do teste
        """
        try:
            self.logger.info("Testando conexão com LuzIA...")
            
            # Payload de teste simples
            test_payload = self.create_complete_payload(
                system_prompt="Você é um assistente útil. Responda em português brasileiro.",
                user_prompt="Diga apenas 'Conexão com LuzIA v2.0.0 funcionando corretamente' em português."
            )
            
            # Submeter teste
            response = self.submit_request(test_payload)
            content = self.extract_response_content(response)
            
            return {
                "success": True,
                "message": " Conexão com LuzIA v2.0.0 OK",
                "response": content,
                "model": self.model,
                "token_splitting": self.enable_token_splitting
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f" Erro na conexão: {str(e)}",
                "response": None,
                "model": self.model,
                "token_splitting": self.enable_token_splitting
            }

