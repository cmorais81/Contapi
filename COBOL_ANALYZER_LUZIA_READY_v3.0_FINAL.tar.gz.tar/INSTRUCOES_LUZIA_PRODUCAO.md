# 🚀 Instruções para Usar com Luzia em Produção

## 📋 Pré-requisitos

1. **Credenciais Luzia configuradas:**
   - `LUZIA_CLIENT_ID` (variável de ambiente ou config.yaml)
   - `LUZIA_CLIENT_SECRET` (variável de ambiente ou config.yaml)

2. **Acesso às URLs da Luzia:**
   - Auth URL: `https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token`
   - API URL: `https://gut-api-aws.santanderbr.pre.corp/genai_services/v1/`

## ⚙️ Configuração

### Opção 1: Variáveis de Ambiente
```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

### Opção 2: Editar config.yaml
```yaml
providers:
  luzia:
    enabled: true  # ← ALTERAR PARA true
    client_id: "seu_client_id"
    client_secret: "seu_client_secret"
    auth_url: "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
    api_url: "https://gut-api-aws.santanderbr.pre.corp/genai_services/v1/"
    models:
      aws-claude-3-5-sonnet:
        name: "aws-claude-3-5-sonnet"
        max_tokens: 8192
        temperature: 0.1
        timeout: 120
```

## 🧪 Testes de Validação

### 1. Verificar Status da Luzia
```bash
python cobol_to_docs/runner/main.py --status
```
**Resultado esperado:** `luzia: Disponível`

### 2. Análise Individual com Luzia
```bash
python cobol_to_docs/runner/main.py --fontes fontes.txt --books BOOKS.txt --models luzia
```

### 3. Análise Consolidada com Luzia
```bash
python cobol_to_docs/runner/main.py --fontes fontes.txt --books BOOKS.txt --models luzia --consolidado
```

### 4. Geração de PDF com Luzia
```bash
python cobol_to_docs/runner/main.py --fontes fontes.txt --books BOOKS.txt --models luzia --pdf
```

## 📊 Payload Enviado para Luzia

O sistema envia o seguinte formato (VALIDADO):

```json
{
  "input": {
    "query": [
      {
        "role": "system",
        "content": "Você é um analista de sistemas COBOL especializado..."
      },
      {
        "role": "user", 
        "content": "CONTEÚDO COMPLETO DO PROGRAMA COBOL + PROMPT DE ANÁLISE"
      }
    ]
  },
  "config": [
    {
      "type": "catena.llm.LLMRouter",
      "obj_kwargs": {
        "routing_model": "aws-claude-3-5-sonnet",
        "temperature": 0.1,
        "max_tokens": 8192,
        "system_prompt": "Responda sempre em português brasileiro..."
      }
    }
  ]
}
```

## ✅ Funcionalidades Validadas

- ✅ **Parsing múltiplos programas** - fontes.txt com VMEMBER
- ✅ **Parsing copybooks** - BOOKS.txt
- ✅ **Conteúdo completo enviado** - código COBOL integral na request
- ✅ **Payload correto** - formato catena.llm.LLMRouter
- ✅ **Headers corretos** - Authorization Bearer + X-santander-client-id
- ✅ **Análise consolidada** - múltiplos programas em uma análise
- ✅ **Análise individual** - cada programa separadamente
- ✅ **Geração PDF** - relatórios em HTML e PDF
- ✅ **Sistema RAG** - auto-learning funcional
- ✅ **Fallback** - enhanced_mock como backup

## 🔧 Troubleshooting

### Erro de Autenticação (401/403)
- Verificar credenciais `LUZIA_CLIENT_ID` e `LUZIA_CLIENT_SECRET`
- Confirmar acesso às URLs da Luzia
- Verificar se o token OAuth2 está sendo obtido corretamente

### Erro de Conexão (503)
- Luzia temporariamente indisponível
- Sistema automaticamente usa fallback (enhanced_mock)

### Logs Detalhados
```bash
python cobol_to_docs/runner/main.py --fontes fontes.txt --models luzia --log-level DEBUG
```

## 📁 Estrutura de Saída

```
output/
├── model_luzia/
│   ├── LHAN0542_analise_funcional.md
│   ├── LHAN0542_analise_funcional.pdf
│   ├── LHAN0705_analise_funcional.md
│   └── ...
├── ai_requests/
│   ├── LHAN0542_ai_request.json
│   └── ...
└── ANALISE_CONSOLIDADA_SISTEMA_BANCARIO_luzia.md
```

## 🎯 Comandos Prontos para Produção

```bash
# Análise completa com Luzia
python cobol_to_docs/runner/main.py \
  --fontes seu_arquivo_fontes.txt \
  --books seu_arquivo_books.txt \
  --models luzia \
  --consolidado \
  --pdf \
  --log-level INFO

# Múltiplos modelos (Luzia + fallback)
python cobol_to_docs/runner/main.py \
  --fontes seu_arquivo_fontes.txt \
  --books seu_arquivo_books.txt \
  --models '["luzia", "enhanced_mock"]' \
  --consolidado
```

**O sistema está 100% pronto para produção com Luzia!** 🚀
