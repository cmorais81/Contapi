# Jornadas de Usuário - Sistema de Governança de Dados V1.1

**Versão:** 1.1.0  
**Data:** 31 de julho de 2025  
**Documento:** Jornadas de Usuário Detalhadas

---

## VISÃO GERAL

Este documento apresenta as jornadas detalhadas dos três principais perfis de usuário do Sistema de Governança de Dados V1.1, incluindo fluxos completos, pontos de contato com o sistema, e funcionalidades específicas para cada perfil.

### PERFIS DE USUÁRIO IDENTIFICADOS

1. **Dono do Dado (Data Owner)** - Responsável pela governança e controle dos ativos de dados
2. **Engenheiro de Dados (Data Engineer)** - Responsável pela implementação técnica e pipelines
3. **Usuário Não Técnico (Business User)** - Consumidor de dados para análises e relatórios

---

## JORNADA 1: DONO DO DADO

![Jornada do Dono do Dado](jornadas/jornada_data_owner.png)

### PERFIL DO USUÁRIO
- **Função:** Data Owner, Data Steward, Gestor de Dados
- **Responsabilidades:** Definir políticas, controlar acesso, garantir qualidade
- **Nível Técnico:** Intermediário a Avançado
- **Objetivos:** Governança efetiva, compliance, controle de qualidade

### FLUXO DETALHADO

#### 1. LOGIN E AUTENTICAÇÃO
**Endpoint:** `POST /api/v1/auth/login`
**Microserviço:** Identity Service (porta 8006)

**Processo:**
- Acesso via interface web ou API
- Autenticação com credenciais corporativas
- Validação de roles e permissões
- Geração de token JWT com escopo adequado

**Funcionalidades:**
- Single Sign-On (SSO) integrado
- Autenticação multifator opcional
- Controle de sessão por tenant
- Auditoria de acessos

#### 2. REGISTRO DE ATIVOS DE DADOS
**Endpoint:** `POST /api/v1/catalog/assets`
**Microserviço:** Catalog Service (porta 8002)

**Processo:**
- Cadastro de novos ativos de dados
- Definição de metadados descritivos
- Classificação por domínio e categoria
- Estabelecimento de ownership

**Funcionalidades:**
- Descoberta automática de assets
- Importação em lote via CSV/Excel
- Integração com sistemas fonte
- Versionamento de metadados

#### 3. DEFINIÇÃO DE CONTRATOS DE DADOS
**Endpoint:** `POST /api/v1/contracts`
**Microserviço:** Contract Service (porta 8001)

**Processo:**
- Criação de contratos formais para datasets
- Definição de esquemas e estruturas
- Estabelecimento de SLAs de qualidade
- Configuração de políticas de acesso

**Funcionalidades:**
- Templates de contratos pré-definidos
- Versionamento automático
- Validação de esquemas
- Aprovação por workflow

#### 4. DEFINIÇÃO DE REGRAS DE QUALIDADE
**Endpoint:** `POST /api/v1/quality/rules`
**Microserviço:** Quality Service (porta 8003)

**Processo:**
- Configuração de regras de validação
- Definição de métricas de qualidade
- Estabelecimento de thresholds
- Configuração de alertas

**Funcionalidades:**
- Biblioteca de regras pré-definidas
- Regras customizáveis por SQL
- Monitoramento contínuo
- Alertas automáticos

#### 5. MONITORAMENTO DE CONFORMIDADE
**Endpoint:** `GET /api/v1/governance/compliance`
**Microserviço:** Governance Service (porta 8004)

**Processo:**
- Visualização de dashboards de compliance
- Análise de métricas de qualidade
- Identificação de violações
- Acompanhamento de tendências

**Funcionalidades:**
- Dashboards interativos
- Relatórios automatizados
- Alertas em tempo real
- Análise de tendências

#### 6. ANÁLISE DE SOLICITAÇÕES DE ACESSO
**Endpoint:** `GET /api/v1/access/requests`
**Microserviço:** Stewardship Service (porta 8009)

**Processo:**
- Revisão de solicitações pendentes
- Análise de justificativas de negócio
- Verificação de compliance
- Tomada de decisão

**Funcionalidades:**
- Fila de aprovações
- Histórico de decisões
- Integração com workflow
- Notificações automáticas

#### 7. APROVAÇÃO/NEGAÇÃO DE ACESSO
**Endpoint:** `PUT /api/v1/access/requests/{id}/approve`
**Microserviço:** Stewardship Service (porta 8009)

**Processo:**
- Decisão sobre solicitações
- Definição de permissões específicas
- Configuração de tempo de acesso
- Comunicação da decisão

**Funcionalidades:**
- Aprovação em lote
- Permissões granulares
- Acesso temporário
- Auditoria completa

#### 8. GERAÇÃO DE RELATÓRIOS
**Endpoint:** `GET /api/v1/analytics/reports`
**Microserviço:** Analytics Service (porta 8005)

**Processo:**
- Geração de relatórios de governança
- Análise de uso de dados
- Métricas de qualidade
- Relatórios de compliance

**Funcionalidades:**
- Relatórios pré-definidos
- Relatórios customizáveis
- Exportação em múltiplos formatos
- Agendamento automático

### PONTOS DE DIFICULDADE IDENTIFICADOS
1. **Complexidade na definição de regras de qualidade**
   - Solução: Templates e assistente guiado
2. **Volume de solicitações de acesso**
   - Solução: Aprovação em lote e automação
3. **Interpretação de métricas de compliance**
   - Solução: Dashboards intuitivos e alertas contextuais

### MÉTRICAS DE SUCESSO
- Tempo médio para aprovação de acesso: < 2 horas
- Taxa de compliance: > 95%
- Satisfação do usuário: > 4.5/5
- Redução de violações de qualidade: > 60%

---

## JORNADA 2: ENGENHEIRO DE DADOS

![Jornada do Engenheiro de Dados](jornadas/jornada_data_engineer.png)

### PERFIL DO USUÁRIO
- **Função:** Data Engineer, DevOps Engineer, Platform Engineer
- **Responsabilidades:** Implementar pipelines, garantir performance, manter infraestrutura
- **Nível Técnico:** Avançado
- **Objetivos:** Eficiência operacional, performance, confiabilidade

### FLUXO DETALHADO

#### 1. ACESSO AO SISTEMA E AUTENTICAÇÃO
**Endpoint:** `POST /api/v1/auth/token`
**Microserviço:** Identity Service (porta 8006)

**Processo:**
- Autenticação via API key ou token
- Validação de permissões técnicas
- Acesso a recursos de desenvolvimento
- Configuração de ambiente

**Funcionalidades:**
- API keys com escopos específicos
- Tokens de longa duração
- Acesso programático completo
- Integração com CI/CD

#### 2. DESCOBERTA DE ATIVOS DE DADOS
**Endpoint:** `GET /api/v1/catalog/discover`
**Microserviço:** Data Discovery Service (porta 8026)

**Processo:**
- Exploração do catálogo de dados
- Identificação de datasets relevantes
- Análise de metadados técnicos
- Compreensão de dependências

**Funcionalidades:**
- API de descoberta automática
- Busca avançada por metadados
- Visualização de lineage
- Documentação técnica

#### 3. COMPREENSÃO DE CONTRATOS DE DADOS
**Endpoint:** `GET /api/v1/contracts/{id}/schema`
**Microserviço:** Contract Service (porta 8001)

**Processo:**
- Análise de esquemas de dados
- Compreensão de SLAs
- Identificação de dependências
- Planejamento de implementação

**Funcionalidades:**
- Esquemas em formato JSON/Avro
- Documentação de APIs
- Exemplos de uso
- Versionamento de contratos

#### 4. IMPLEMENTAÇÃO DE PIPELINES DE DADOS
**Endpoint:** `POST /api/v1/pipelines`
**Microserviço:** Workflow Service (porta 8008)

**Processo:**
- Desenvolvimento de pipelines ETL/ELT
- Configuração de transformações
- Implementação de validações
- Deploy em ambiente de produção

**Funcionalidades:**
- Templates de pipeline
- Orquestração de workflows
- Monitoramento de execução
- Rollback automático

#### 5. VALIDAÇÃO DE QUALIDADE DE DADOS
**Endpoint:** `POST /api/v1/quality/validate`
**Microserviço:** Quality Service (porta 8003)

**Processo:**
- Execução de validações automáticas
- Verificação de regras de qualidade
- Identificação de anomalias
- Correção de problemas

**Funcionalidades:**
- Validação em tempo real
- Relatórios de qualidade
- Alertas automáticos
- Integração com pipelines

#### 6. MONITORAMENTO DE PERFORMANCE
**Endpoint:** `GET /api/v1/monitoring/pipelines`
**Microserviço:** Monitoring Service (porta 8015)

**Processo:**
- Acompanhamento de métricas de performance
- Identificação de gargalos
- Análise de tendências
- Otimização proativa

**Funcionalidades:**
- Dashboards de performance
- Alertas de SLA
- Análise de recursos
- Recomendações de otimização

#### 7. GERENCIAMENTO DE LINEAGE DE DADOS
**Endpoint:** `GET /api/v1/lineage/trace`
**Microserviço:** Lineage Service (porta 8007)

**Processo:**
- Rastreamento de origem dos dados
- Mapeamento de transformações
- Análise de impacto
- Documentação de fluxos

**Funcionalidades:**
- Visualização gráfica de lineage
- Rastreamento automático
- Análise de impacto
- Documentação automática

#### 8. RESOLUÇÃO DE PROBLEMAS
**Endpoint:** `GET /api/v1/audit/logs`
**Microserviço:** Audit Service (porta 8010)

**Processo:**
- Análise de logs de sistema
- Identificação de causas raiz
- Implementação de correções
- Prevenção de recorrências

**Funcionalidades:**
- Logs centralizados
- Busca avançada
- Correlação de eventos
- Alertas proativos

### PONTOS DE DIFICULDADE IDENTIFICADOS
1. **Complexidade na configuração de pipelines**
   - Solução: Templates e assistente de configuração
2. **Debugging de problemas de qualidade**
   - Solução: Logs detalhados e ferramentas de análise
3. **Otimização de performance**
   - Solução: Recomendações automáticas e profiling

### MÉTRICAS DE SUCESSO
- Tempo de desenvolvimento de pipeline: < 4 horas
- Taxa de sucesso de pipelines: > 99%
- Tempo médio de resolução de problemas: < 30 minutos
- Satisfação do desenvolvedor: > 4.5/5

---

## JORNADA 3: USUÁRIO NÃO TÉCNICO

![Jornada do Usuário Não Técnico](jornadas/jornada_business_user.png)

### PERFIL DO USUÁRIO
- **Função:** Analista de Negócios, Gerente, Executivo
- **Responsabilidades:** Análise de dados, tomada de decisão, relatórios
- **Nível Técnico:** Básico a Intermediário
- **Objetivos:** Insights de negócio, relatórios, facilidade de uso

### FLUXO DETALHADO

#### 1. LOGIN SIMPLES
**Endpoint:** Interface Web `/login`
**Microserviço:** API Gateway (porta 8000)

**Processo:**
- Login via interface web intuitiva
- Autenticação simplificada
- Redirecionamento para dashboard
- Personalização por perfil

**Funcionalidades:**
- Interface responsiva
- Login social opcional
- Lembrança de credenciais
- Onboarding guiado

#### 2. NAVEGAÇÃO NO CATÁLOGO DE DADOS
**Endpoint:** Interface Web `/catalog`
**Microserviço:** Catalog Service (porta 8002)

**Processo:**
- Exploração visual do catálogo
- Navegação por categorias
- Filtragem por domínio
- Visualização de metadados

**Funcionalidades:**
- Interface visual intuitiva
- Categorização clara
- Busca por palavras-chave
- Favoritos e histórico

#### 3. BUSCA POR DADOS
**Endpoint:** `GET /api/v1/catalog/search`
**Microserviço:** Catalog Service (porta 8002)

**Processo:**
- Busca por termos de negócio
- Filtragem por critérios
- Visualização de resultados
- Seleção de datasets

**Funcionalidades:**
- Busca em linguagem natural
- Sugestões automáticas
- Filtros inteligentes
- Resultados ranqueados

#### 4. SOLICITAÇÃO DE ACESSO A DADOS
**Endpoint:** `POST /api/v1/access/request`
**Microserviço:** Stewardship Service (porta 8009)

**Processo:**
- Formulário simplificado de solicitação
- Justificativa de negócio
- Seleção de período de acesso
- Submissão para aprovação

**Funcionalidades:**
- Formulários intuitivos
- Templates de justificativa
- Acompanhamento de status
- Notificações automáticas

#### 5. VISUALIZAÇÃO DE INSIGHTS
**Endpoint:** Interface Web `/insights`
**Microserviço:** Analytics Service (porta 8005)

**Processo:**
- Acesso a dashboards pré-construídos
- Visualização de métricas-chave
- Análise de tendências
- Drill-down em dados

**Funcionalidades:**
- Dashboards interativos
- Visualizações responsivas
- Exportação de gráficos
- Personalização de views

#### 6. GERAÇÃO DE RELATÓRIOS DE NEGÓCIO
**Endpoint:** `POST /api/v1/reports/generate`
**Microserviço:** Analytics Service (porta 8005)

**Processo:**
- Seleção de templates de relatório
- Configuração de parâmetros
- Geração automática
- Download ou compartilhamento

**Funcionalidades:**
- Templates pré-definidos
- Relatórios customizáveis
- Múltiplos formatos de saída
- Agendamento automático

#### 7. COMPARTILHAMENTO DE DESCOBERTAS
**Endpoint:** `POST /api/v1/collaboration/share`
**Microserviço:** External Integration Service (porta 8022)

**Processo:**
- Seleção de insights para compartilhar
- Escolha de destinatários
- Configuração de permissões
- Envio de notificações

**Funcionalidades:**
- Compartilhamento seguro
- Controle de permissões
- Integração com email/Slack
- Histórico de compartilhamentos

#### 8. FORNECIMENTO DE FEEDBACK
**Endpoint:** `POST /api/v1/feedback`
**Microserviço:** Stewardship Service (porta 8009)

**Processo:**
- Avaliação de qualidade dos dados
- Sugestões de melhorias
- Relato de problemas
- Contribuição para governança

**Funcionalidades:**
- Sistema de avaliação
- Comentários estruturados
- Categorização de feedback
- Acompanhamento de resoluções

### PONTOS DE DIFICULDADE IDENTIFICADOS
1. **Complexidade na busca de dados relevantes**
   - Solução: Busca em linguagem natural e sugestões
2. **Interpretação de dados técnicos**
   - Solução: Glossário de negócios e documentação clara
3. **Tempo de aprovação de acesso**
   - Solução: Aprovação automática para dados públicos

### MÉTRICAS DE SUCESSO
- Tempo para encontrar dados relevantes: < 5 minutos
- Taxa de aprovação de solicitações: > 90%
- Satisfação com interface: > 4.5/5
- Adoção da plataforma: > 80% dos usuários alvo

---

## INTEGRAÇÃO ENTRE JORNADAS

### PONTOS DE INTERSECÇÃO

#### 1. APROVAÇÃO DE ACESSO
- **Dono do Dado:** Aprova solicitações
- **Usuário Não Técnico:** Solicita acesso
- **Engenheiro de Dados:** Implementa controles de acesso

#### 2. QUALIDADE DE DADOS
- **Dono do Dado:** Define regras de qualidade
- **Engenheiro de Dados:** Implementa validações
- **Usuário Não Técnico:** Reporta problemas de qualidade

#### 3. CONTRATOS DE DADOS
- **Dono do Dado:** Define contratos
- **Engenheiro de Dados:** Implementa contratos
- **Usuário Não Técnico:** Consome dados conforme contratos

### FLUXOS COLABORATIVOS

#### FLUXO DE ONBOARDING DE NOVOS DADOS
1. **Engenheiro:** Descobre e cataloga novos dados
2. **Dono do Dado:** Define políticas e contratos
3. **Usuário Não Técnico:** Acessa e utiliza dados

#### FLUXO DE RESOLUÇÃO DE PROBLEMAS
1. **Usuário Não Técnico:** Reporta problema
2. **Dono do Dado:** Analisa e prioriza
3. **Engenheiro:** Implementa correção

#### FLUXO DE MELHORIA CONTÍNUA
1. **Usuário Não Técnico:** Fornece feedback
2. **Dono do Dado:** Avalia necessidades
3. **Engenheiro:** Implementa melhorias

---

## TECNOLOGIAS E INTEGRAÇÕES

### INTERFACES DE USUÁRIO
- **Web App:** React.js responsivo para todos os perfis
- **API REST:** Acesso programático para engenheiros
- **Mobile App:** Acesso móvel para consultas rápidas

### INTEGRAÇÕES EXTERNAS
- **SSO:** Active Directory, LDAP, SAML
- **Notificações:** Email, Slack, Microsoft Teams
- **BI Tools:** Power BI, Tableau, Looker
- **Data Tools:** Databricks, Snowflake, BigQuery

### PERSONALIZAÇÃO POR PERFIL
- **Dono do Dado:** Dashboards de governança e compliance
- **Engenheiro:** Ferramentas técnicas e APIs
- **Usuário Não Técnico:** Interface simplificada e visual

---

## MÉTRICAS GLOBAIS DE SUCESSO

### ADOÇÃO
- Taxa de adoção por perfil: > 80%
- Frequência de uso semanal: > 3 sessões
- Tempo médio de sessão: > 15 minutos

### EFICIÊNCIA
- Redução no tempo de descoberta de dados: > 70%
- Melhoria na qualidade de dados: > 60%
- Redução de solicitações de suporte: > 50%

### SATISFAÇÃO
- Net Promoter Score (NPS): > 50
- Satisfação geral: > 4.5/5
- Taxa de retenção: > 95%

---

## PRÓXIMOS PASSOS

### MELHORIAS IDENTIFICADAS
1. **Personalização Avançada:** IA para recomendações personalizadas
2. **Automação Inteligente:** Aprovações automáticas baseadas em ML
3. **Colaboração Aprimorada:** Recursos de anotação e discussão
4. **Mobile First:** App nativo com funcionalidades offline

### ROADMAP DE EVOLUÇÃO
- **Q1 2025:** Implementação de IA para recomendações
- **Q2 2025:** Automação inteligente de aprovações
- **Q3 2025:** Recursos colaborativos avançados
- **Q4 2025:** Aplicativo mobile nativo

---

**Documento elaborado em:** 31 de julho de 2025  
**Responsável:** Sistema de Governança de Dados V1.1  
**Próxima revisão:** Trimestral

