# Manual Técnico - Sistema de Governança de Dados V1.1

## Visão Geral

O Sistema de Governança de Dados V1.1 é uma solução completa para gestão, controle e monitoramento de ativos de dados corporativos. Implementado como uma arquitetura de microserviços, oferece funcionalidades abrangentes para catálogo de dados, contratos de dados, qualidade, lineage, compliance e auditoria.

## Arquitetura do Sistema

### Estrutura de Monorepo

O projeto está organizado como um monorepo com a seguinte estrutura:

```
SISTEMA_GOVERNANCA_V1_1_UNIFICADO/
├── apps/                    # Microserviços da aplicação
├── libs/                    # Bibliotecas compartilhadas
├── scripts/                 # Scripts de automação e utilitários
├── database/                # Esquemas e modelos de dados
├── docs/                    # Documentação do projeto
├── test_data/              # Dados de teste e mock
├── docker-compose.yml      # Orquestração de containers
└── README.md               # Documentação principal
```

### Microserviços Implementados

O sistema é composto por 29 microserviços organizados em domínios funcionais:

#### Domínio Core
- **api-gateway**: Gateway principal para roteamento de requisições
- **identity-service**: Autenticação e autorização de usuários
- **audit-service**: Auditoria e logs de sistema

#### Domínio de Dados
- **catalog-service**: Catálogo de ativos de dados
- **contract-service**: Gestão de contratos de dados
- **quality-service**: Monitoramento de qualidade de dados
- **lineage-service**: Rastreabilidade e linhagem de dados
- **data-discovery-service**: Descoberta automática de dados
- **data-masking-service**: Mascaramento e anonimização

#### Domínio de Governança
- **governance-service**: Políticas e regras de governança
- **stewardship-service**: Gestão de data stewards
- **workflow-service**: Processos de aprovação
- **domain-service**: Gestão de domínios de dados

#### Domínio de Monitoramento
- **monitoring-service**: Monitoramento de sistema
- **analytics-service**: Analytics e relatórios
- **notification-service**: Sistema de notificações

#### Domínio de Infraestrutura
- **security-service**: Segurança e criptografia
- **cache-service**: Cache distribuído
- **message-queue-service**: Mensageria assíncrona
- **backup-service**: Backup e recuperação

#### Domínio de Integração
- **external-integration-service**: Integrações externas
- **auto-discovery-service**: Descoberta automática
- **automation-engine-service**: Motor de automação

#### Domínio de Utilidades
- **tag-management-service**: Gestão de tags e metadados
- **rate-limiting-service**: Controle de taxa de requisições
- **glossary-service**: Glossário de termos de negócio

## Tecnologias Utilizadas

### Backend
- **Python 3.13**: Linguagem principal
- **FastAPI**: Framework web para APIs REST
- **Uvicorn**: Servidor ASGI de alta performance
- **Pydantic**: Validação de dados e serialização
- **SQLAlchemy**: ORM para acesso a dados
- **Asyncpg**: Driver assíncrono para PostgreSQL

### Banco de Dados
- **PostgreSQL 15**: Banco de dados principal
- **Redis**: Cache e sessões
- **Elasticsearch**: Busca e indexação (opcional)

### Infraestrutura
- **Docker**: Containerização
- **Docker Compose**: Orquestração local
- **Nginx**: Proxy reverso e load balancer

### Monitoramento e Observabilidade
- **Prometheus**: Métricas de sistema
- **Grafana**: Dashboards e visualização
- **Structlog**: Logging estruturado
- **OpenTelemetry**: Tracing distribuído

## Modelo de Dados

O sistema utiliza um modelo de dados robusto com 43 tabelas organizadas em 8 domínios:

### Domínio: Identidade e Acesso
- `users`: Usuários do sistema
- `user_sessions`: Sessões ativas
- `roles`: Papéis e permissões
- `user_roles`: Associação usuário-papel

### Domínio: Catálogo de Dados
- `data_assets`: Ativos de dados
- `data_schemas`: Esquemas detalhados
- `data_lineage`: Linhagem de dados

### Domínio: Contratos de Dados
- `data_contracts`: Contratos formais
- `contract_versions`: Versionamento
- `contract_validations`: Validações automáticas

### Domínio: Qualidade de Dados
- `quality_metrics`: Métricas de qualidade
- `quality_rules`: Regras configuráveis
- `quality_incidents`: Incidentes de qualidade

### Domínio: Políticas e Governança
- `governance_policies`: Políticas de governança
- `policy_violations`: Violações detectadas
- `compliance_frameworks`: Frameworks de compliance
- `compliance_assessments`: Avaliações de conformidade

### Domínio: Workflow e Aprovações
- `workflows`: Definições de workflow
- `workflow_instances`: Instâncias ativas
- `workflow_steps`: Etapas individuais

### Domínio: Auditoria e Monitoramento
- `audit_logs`: Logs de auditoria
- `system_metrics`: Métricas de sistema
- `notifications`: Sistema de notificações

### Domínio: Descoberta e Automação
- `discovery_jobs`: Jobs de descoberta
- `discovery_results`: Resultados de descoberta
- `automation_rules`: Regras de automação
- `automation_executions`: Execuções de automação

## Configuração e Instalação

### Pré-requisitos

- Python 3.13 ou superior
- Docker e Docker Compose
- PostgreSQL 15
- Redis 7
- Git

### Instalação Local

1. **Clone o repositório**:
```bash
git clone <repository-url>
cd SISTEMA_GOVERNANCA_V1_1_UNIFICADO
```

2. **Configure o ambiente Python**:
```bash
python -m venv venv
source venv/bin/activate  # Linux/macOS
# ou
venv\Scripts\activate     # Windows

pip install -r requirements.txt
```

3. **Configure as variáveis de ambiente**:
```bash
cp .env.example .env
# Edite o arquivo .env com suas configurações
```

4. **Inicie os serviços de infraestrutura**:
```bash
docker-compose up -d postgres redis
```

5. **Execute as migrações do banco**:
```bash
python scripts/setup_database.py
```

6. **Inicie os microserviços**:
```bash
docker-compose up -d
```

### Configuração com Docker

Para ambiente de desenvolvimento completo com Docker:

```bash
# Construir todas as imagens
docker-compose build

# Iniciar todos os serviços
docker-compose up -d

# Verificar status dos serviços
docker-compose ps

# Visualizar logs
docker-compose logs -f api-gateway
```

## APIs e Endpoints

### API Gateway (Porta 8000)

O API Gateway centraliza o acesso a todos os microserviços:

```
GET  /health                    # Health check geral
GET  /api/v1/docs              # Documentação Swagger
POST /api/v1/auth/login        # Autenticação
GET  /api/v1/catalog/assets    # Listar ativos de dados
POST /api/v1/contracts         # Criar contrato
GET  /api/v1/quality/metrics   # Métricas de qualidade
```

### Autenticação

O sistema utiliza JWT para autenticação:

```bash
# Login
curl -X POST http://localhost:8000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "admin123"}'

# Usar token nas requisições
curl -H "Authorization: Bearer <token>" \
  http://localhost:8000/api/v1/catalog/assets
```

### Documentação Interativa

Cada microserviço expõe documentação Swagger:

- API Gateway: http://localhost:8000/docs
- Identity Service: http://localhost:8001/docs
- Catalog Service: http://localhost:8002/docs
- Contract Service: http://localhost:8003/docs

## Desenvolvimento

### Estrutura de um Microserviço

Cada microserviço segue a arquitetura hexagonal:

```
apps/exemplo-service/
├── src/
│   ├── main.py                    # Ponto de entrada
│   ├── domain/                    # Lógica de negócio
│   │   ├── entities/             # Entidades de domínio
│   │   ├── services/             # Serviços de domínio
│   │   ├── interfaces/           # Contratos abstratos
│   │   └── exceptions/           # Exceções customizadas
│   ├── application/              # Casos de uso
│   │   ├── use_cases/           # Implementação de casos de uso
│   │   └── dtos/                # Data Transfer Objects
│   ├── infrastructure/          # Infraestrutura
│   │   ├── database/            # Acesso a dados
│   │   ├── repositories/        # Implementação de repositórios
│   │   └── external/            # Integrações externas
│   └── presentation/            # Interface web
│       ├── controllers/         # Controladores REST
│       └── middlewares/         # Middlewares
├── tests/                       # Testes automatizados
│   ├── unit/                   # Testes unitários
│   ├── integration/            # Testes de integração
│   └── conftest.py             # Configuração de testes
├── Dockerfile                  # Imagem Docker
├── requirements.txt            # Dependências Python
└── config.yml                 # Configurações
```

### Padrões de Código

#### Princípios SOLID

O código segue rigorosamente os princípios SOLID:

- **Single Responsibility**: Cada classe tem uma única responsabilidade
- **Open/Closed**: Aberto para extensão, fechado para modificação
- **Liskov Substitution**: Subtipos devem ser substituíveis por seus tipos base
- **Interface Segregation**: Interfaces específicas são melhores que interfaces gerais
- **Dependency Inversion**: Dependa de abstrações, não de implementações

#### Clean Code

- Nomes descritivos para variáveis, funções e classes
- Funções pequenas com responsabilidade única
- Comentários explicativos quando necessário
- Tratamento robusto de erros
- Testes abrangentes

### Testes

#### Estrutura de Testes

```bash
# Executar todos os testes
python -m pytest

# Testes com cobertura
python -m pytest --cov=src --cov-report=html

# Testes específicos
python -m pytest tests/unit/test_catalog_service.py

# Testes de integração
python -m pytest tests/integration/
```

#### Tipos de Testes

1. **Testes Unitários**: Testam componentes isolados
2. **Testes de Integração**: Testam interação entre componentes
3. **Testes de API**: Testam endpoints REST
4. **Testes de Performance**: Testam performance e carga

### Monitoramento e Logs

#### Logging Estruturado

```python
import structlog

logger = structlog.get_logger()

logger.info(
    "Asset created",
    asset_id="123e4567-e89b-12d3-a456-426614174000",
    asset_type="database_table",
    owner="data_team"
)
```

#### Métricas

```python
from prometheus_client import Counter, Histogram

# Contador de requisições
REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP requests')

# Histograma de latência
REQUEST_LATENCY = Histogram('http_request_duration_seconds', 'HTTP request latency')
```

## Segurança

### Autenticação e Autorização

- JWT tokens com expiração configurável
- Refresh tokens para renovação automática
- Controle de acesso baseado em roles (RBAC)
- Permissões granulares por recurso

### Proteção de Dados

- Criptografia de dados sensíveis em repouso
- Comunicação HTTPS obrigatória
- Mascaramento automático de dados pessoais
- Auditoria completa de acessos

### Compliance

- Frameworks de compliance configuráveis
- Avaliações automáticas de conformidade
- Relatórios de compliance
- Políticas de retenção de dados

## Performance e Escalabilidade

### Otimizações de Performance

- Cache distribuído com Redis
- Índices otimizados no PostgreSQL
- Paginação em todas as listagens
- Compressão de respostas HTTP

### Escalabilidade Horizontal

- Microserviços stateless
- Load balancing automático
- Auto-scaling baseado em métricas
- Particionamento de dados

### Monitoramento de Performance

- Métricas de latência por endpoint
- Monitoramento de recursos (CPU, memória)
- Alertas automáticos para degradação
- Dashboards em tempo real

## Troubleshooting

### Problemas Comuns

#### Erro de Conexão com Banco de Dados

```bash
# Verificar status do PostgreSQL
docker-compose ps postgres

# Verificar logs
docker-compose logs postgres

# Testar conexão
psql -h localhost -p 5432 -U governance_user -d governance_db
```

#### Microserviço Não Responde

```bash
# Verificar status
docker-compose ps

# Verificar logs específicos
docker-compose logs api-gateway

# Reiniciar serviço
docker-compose restart api-gateway
```

#### Problemas de Performance

```bash
# Verificar métricas
curl http://localhost:8000/metrics

# Verificar logs de performance
docker-compose logs | grep "slow_query"

# Analisar queries do banco
SELECT * FROM pg_stat_activity WHERE state = 'active';
```

### Logs e Debugging

#### Níveis de Log

- **DEBUG**: Informações detalhadas para debugging
- **INFO**: Informações gerais de operação
- **WARNING**: Situações que merecem atenção
- **ERROR**: Erros que não impedem funcionamento
- **CRITICAL**: Erros críticos que impedem funcionamento

#### Configuração de Logs

```yaml
# config/logging.yml
version: 1
formatters:
  structured:
    format: '%(asctime)s %(name)s %(levelname)s %(message)s'
handlers:
  console:
    class: logging.StreamHandler
    formatter: structured
loggers:
  governance:
    level: INFO
    handlers: [console]
```

## Backup e Recuperação

### Estratégia de Backup

- Backup automático diário do PostgreSQL
- Retenção de 30 dias para backups
- Backup incremental a cada 6 horas
- Backup de configurações e scripts

### Procedimentos de Recuperação

```bash
# Backup manual
docker-compose exec postgres pg_dump -U governance_user governance_db > backup.sql

# Restauração
docker-compose exec postgres psql -U governance_user governance_db < backup.sql

# Verificação de integridade
docker-compose exec postgres pg_dump --schema-only governance_db | grep -c "CREATE TABLE"
```

## Integração com Ferramentas Externas

### Informatica Axon

O sistema pode ser integrado com Informatica Axon para:

- Sincronização de metadados
- Importação de glossários de negócio
- Exportação de lineage de dados
- Integração com workflows de aprovação

### Unity Catalog

Integração com Databricks Unity Catalog:

- Descoberta automática de ativos no Unity Catalog
- Sincronização de classificações de dados
- Importação de métricas de qualidade
- Controle de acesso unificado

### APIs de Integração

```python
# Exemplo de integração com API externa
import httpx

async def sync_with_external_catalog():
    async with httpx.AsyncClient() as client:
        response = await client.get("https://api.external-catalog.com/assets")
        assets = response.json()
        
        for asset in assets:
            await create_or_update_asset(asset)
```

## Manutenção e Atualizações

### Atualizações de Versão

1. **Backup completo do sistema**
2. **Teste em ambiente de homologação**
3. **Execução de migrações de banco**
4. **Deploy gradual dos microserviços**
5. **Verificação de integridade**
6. **Rollback se necessário**

### Manutenção Preventiva

- Limpeza de logs antigos
- Otimização de índices do banco
- Atualização de dependências
- Verificação de segurança
- Teste de backups

### Monitoramento Contínuo

- Alertas para degradação de performance
- Monitoramento de uso de recursos
- Verificação de integridade de dados
- Auditoria de segurança

## Conclusão

Este manual técnico fornece uma visão abrangente do Sistema de Governança de Dados V1.1. Para informações adicionais, consulte:

- Documentação de APIs: `/docs` em cada microserviço
- Manual Funcional: `MANUAL_FUNCIONAL_COMPLETO_V1_1.md`
- Manual Operacional: `MANUAL_OPERACIONAL_COMPLETO_V1_1.md`
- Arquitetura do Sistema: `docs/arquitetura/`

Para suporte técnico, consulte os logs do sistema e utilize as ferramentas de debugging descritas neste manual.

