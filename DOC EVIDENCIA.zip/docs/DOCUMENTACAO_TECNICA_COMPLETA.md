# Documentação Técnica Completa - Sistema de Governança de Dados V1.1

**Versão:** 1.1.0  
**Data:** 31 de julho de 2025  
**Documento:** Especificação Técnica Completa

---

## VISÃO GERAL TÉCNICA

O Sistema de Governança de Dados V1.1 é uma plataforma distribuída baseada em arquitetura de microserviços, desenvolvida para fornecer governança completa de dados corporativos. O sistema implementa padrões modernos de desenvolvimento, incluindo princípios SOLID, clean code, e práticas DevOps maduras.

### CARACTERÍSTICAS TÉCNICAS PRINCIPAIS

- **Arquitetura:** Microserviços distribuídos
- **Linguagem:** Python 3.13
- **Framework:** FastAPI com Uvicorn
- **Banco de Dados:** PostgreSQL 15+
- **Cache:** Redis 7+
- **Containerização:** Docker + Docker Compose
- **Orquestração:** Kubernetes (opcional)
- **Monitoramento:** Prometheus + Grafana
- **CI/CD:** GitHub Actions

---

## ARQUITETURA DO SISTEMA

![Arquitetura de Microserviços](arquitetura/arquitetura_microservicos_atual.png)

### CAMADAS ARQUITETURAIS

#### 1. CAMADA DE GATEWAY
**API Gateway (Porta 8000)**
- Ponto único de entrada para todas as requisições
- Roteamento inteligente para microserviços
- Autenticação e autorização centralizadas
- Rate limiting e throttling
- Load balancing automático

**Tecnologias:**
```python
# Principais dependências
fastapi==0.104.1
uvicorn==0.24.0
httpx==0.25.2
redis==5.0.1
```

#### 2. CAMADA DE SERVIÇOS CORE

**Identity Service (Porta 8006)**
- Gerenciamento de usuários e autenticação
- Controle de roles e permissões
- Integração com SSO (SAML, OAuth2)
- Auditoria de acessos

**Contract Service (Porta 8001)**
- Gerenciamento de contratos de dados
- Versionamento de esquemas
- Validação de estruturas
- SLA de qualidade

**Layout Service (Porta 8007)**
- Gerenciamento de múltiplos layouts
- Migração automática entre layouts
- Versionamento de apresentações
- API de configuração visual

**Analytics Service (Porta 8005)**
- Processamento de métricas
- Dashboards em tempo real
- Relatórios automatizados
- Business Intelligence

**Catalog Service (Porta 8002)**
- Catálogo de ativos de dados
- Metadados e documentação
- Descoberta automática
- Classificação e taxonomia

#### 3. CAMADA DE SERVIÇOS ESPECIALIZADOS

**Quality Service (Porta 8003)**
- Validação de qualidade de dados
- Regras customizáveis
- Monitoramento contínuo
- Alertas automáticos

**Governance Service (Porta 8004)**
- Políticas de governança
- Compliance e auditoria
- Workflow de aprovações
- Relatórios regulatórios

**Workflow Service (Porta 8008)**
- Orquestração de processos
- Automação de tarefas
- Pipeline de aprovações
- Integração com sistemas externos

**Stewardship Service (Porta 8009)**
- Gestão de data stewards
- Solicitações de acesso
- Aprovações e negações
- Comunicação com usuários

**Audit Service (Porta 8010)**
- Log centralizado de eventos
- Rastreabilidade completa
- Análise de segurança
- Compliance reporting

#### 4. CAMADA DE INFRAESTRUTURA

**PostgreSQL**
- Banco principal com 43 tabelas
- Particionamento por tenant
- Índices otimizados
- Backup automático

**Redis**
- Cache distribuído
- Sessões de usuário
- Rate limiting
- Pub/Sub para eventos

**Message Queue**
- Comunicação assíncrona
- Processamento em background
- Garantia de entrega
- Dead letter queues

---

## ESPECIFICAÇÕES TÉCNICAS DETALHADAS

### PADRÕES DE DESENVOLVIMENTO

#### PRINCÍPIOS SOLID IMPLEMENTADOS

**Single Responsibility Principle (SRP)**
```python
# Exemplo: Separação de responsabilidades
class ContractRepository:
    """Responsável apenas por operações de dados de contratos"""
    def save(self, contract: Contract) -> Contract: ...
    def find_by_id(self, contract_id: str) -> Contract: ...

class ContractValidator:
    """Responsável apenas por validação de contratos"""
    def validate_schema(self, contract: Contract) -> ValidationResult: ...
    def validate_business_rules(self, contract: Contract) -> ValidationResult: ...

class ContractService:
    """Responsável apenas por lógica de negócio de contratos"""
    def __init__(self, repository: ContractRepository, validator: ContractValidator):
        self.repository = repository
        self.validator = validator
```

**Open/Closed Principle (OCP)**
```python
# Exemplo: Extensibilidade via interfaces
class QualityRule(ABC):
    @abstractmethod
    def validate(self, data: Any) -> ValidationResult: ...

class NotNullRule(QualityRule):
    def validate(self, data: Any) -> ValidationResult:
        return ValidationResult(is_valid=data is not None)

class RangeRule(QualityRule):
    def __init__(self, min_val: float, max_val: float):
        self.min_val = min_val
        self.max_val = max_val
    
    def validate(self, data: Any) -> ValidationResult:
        return ValidationResult(is_valid=self.min_val <= data <= self.max_val)
```

#### CLEAN CODE IMPLEMENTADO

**Nomenclatura Clara e Consistente**
```python
# Boas práticas aplicadas
class DataAssetCatalogService:
    def register_new_data_asset(self, asset_metadata: DataAssetMetadata) -> DataAsset:
        """
        Registra um novo ativo de dados no catálogo.
        
        Args:
            asset_metadata: Metadados do ativo a ser registrado
            
        Returns:
            DataAsset: Ativo registrado com ID gerado
            
        Raises:
            ValidationError: Se os metadados são inválidos
            DuplicateAssetError: Se o ativo já existe
        """
        self._validate_asset_metadata(asset_metadata)
        self._check_for_duplicates(asset_metadata.name)
        
        asset = self._create_data_asset(asset_metadata)
        return self._save_to_catalog(asset)
```

**Tratamento de Erros Robusto**
```python
# Sistema de exceções customizadas
class GovernanceException(Exception):
    """Exceção base do sistema de governança"""
    pass

class ContractValidationError(GovernanceException):
    """Erro de validação de contrato"""
    def __init__(self, contract_id: str, validation_errors: List[str]):
        self.contract_id = contract_id
        self.validation_errors = validation_errors
        super().__init__(f"Contrato {contract_id} inválido: {validation_errors}")

class AccessDeniedError(GovernanceException):
    """Erro de acesso negado"""
    def __init__(self, user_id: str, resource: str):
        self.user_id = user_id
        self.resource = resource
        super().__init__(f"Usuário {user_id} não tem acesso a {resource}")
```

### CONFIGURAÇÃO E DEPLOYMENT

#### CONFIGURAÇÃO CENTRALIZADA

**Arquivo: `config/database.py`**
```python
from pydantic import BaseSettings
from typing import Optional

class DatabaseConfig(BaseSettings):
    """Configuração centralizada de banco de dados"""
    
    # PostgreSQL Principal
    postgres_host: str = "localhost"
    postgres_port: int = 5432
    postgres_db: str = "governance_db"
    postgres_user: str = "governance_user"
    postgres_password: str = "governance_pass"
    
    # Pool de Conexões
    postgres_pool_min: int = 5
    postgres_pool_max: int = 20
    postgres_pool_timeout: int = 30
    
    # Redis Cache
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_db: int = 0
    redis_password: Optional[str] = None
    
    # Configurações por Ambiente
    environment: str = "development"
    debug: bool = True
    log_level: str = "INFO"
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

# Instância global de configuração
config = DatabaseConfig()
```

#### DOCKER COMPOSE PARA PRODUÇÃO

**Arquivo: `docker-compose.production.yml`**
```yaml
version: '3.8'

services:
  # Infraestrutura
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: governance_db
      POSTGRES_USER: governance_user
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./database/schema_complete_v1_0.sql:/docker-entrypoint-initdb.d/01-schema.sql
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U governance_user -d governance_db"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          memory: 2G
          cpus: '1.0'

  redis:
    image: redis:7-alpine
    command: redis-server --appendonly yes --maxmemory 512mb --maxmemory-policy allkeys-lru
    volumes:
      - redis_data:/data
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      resources:
        limits:
          memory: 512M
          cpus: '0.5'

  # API Gateway
  api-gateway:
    build: ./apps/api-gateway
    environment:
      - DATABASE_URL=postgresql://governance_user:${POSTGRES_PASSWORD}@postgres:5432/governance_db
      - REDIS_URL=redis://redis:6379/0
      - ENVIRONMENT=production
    ports:
      - "8000:8000"
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      replicas: 2
      resources:
        limits:
          memory: 512M
          cpus: '0.5'

  # Microserviços Core
  identity-service:
    build: ./apps/identity-service
    environment:
      - DATABASE_URL=postgresql://governance_user:${POSTGRES_PASSWORD}@postgres:5432/governance_db
      - REDIS_URL=redis://redis:6379/0
    ports:
      - "8006:8006"
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    deploy:
      replicas: 2

  contract-service:
    build: ./apps/contract-service
    environment:
      - DATABASE_URL=postgresql://governance_user:${POSTGRES_PASSWORD}@postgres:5432/governance_db
      - REDIS_URL=redis://redis:6379/0
    ports:
      - "8001:8001"
    depends_on:
      postgres:
        condition: service_healthy
    deploy:
      replicas: 2

  layout-service:
    build: ./apps/layout-service
    environment:
      - DATABASE_URL=postgresql://governance_user:${POSTGRES_PASSWORD}@postgres:5432/governance_db
      - REDIS_URL=redis://redis:6379/0
    ports:
      - "8007:8007"
    depends_on:
      postgres:
        condition: service_healthy
    deploy:
      replicas: 1

  # Monitoramento
  prometheus:
    image: prom/prometheus:latest
    ports:
      - "9090:9090"
    volumes:
      - ./monitoring/prometheus.yml:/etc/prometheus/prometheus.yml
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
      - '--storage.tsdb.path=/prometheus'
      - '--web.console.libraries=/etc/prometheus/console_libraries'
      - '--web.console.templates=/etc/prometheus/consoles'

  grafana:
    image: grafana/grafana:latest
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=${GRAFANA_PASSWORD}
    volumes:
      - grafana_data:/var/lib/grafana
      - ./monitoring/grafana/dashboards:/etc/grafana/provisioning/dashboards
      - ./monitoring/grafana/datasources:/etc/grafana/provisioning/datasources

volumes:
  postgres_data:
  redis_data:
  grafana_data:

networks:
  default:
    driver: bridge
```

### MIDDLEWARE E INTERCEPTADORES

#### MIDDLEWARE DE PERFORMANCE
```python
import time
import logging
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

class PerformanceMiddleware(BaseHTTPMiddleware):
    """Middleware para monitoramento de performance"""
    
    def __init__(self, app, logger: logging.Logger):
        super().__init__(app)
        self.logger = logger
    
    async def dispatch(self, request: Request, call_next) -> Response:
        # Início da medição
        start_time = time.time()
        
        # Processamento da requisição
        response = await call_next(request)
        
        # Fim da medição
        process_time = time.time() - start_time
        
        # Log de performance
        self.logger.info(
            f"Performance: {request.method} {request.url.path} "
            f"- {process_time:.3f}s - {response.status_code}"
        )
        
        # Adicionar header de tempo de resposta
        response.headers["X-Process-Time"] = str(process_time)
        
        # Alertas para requisições lentas
        if process_time > 2.0:
            self.logger.warning(
                f"Requisição lenta detectada: {request.url.path} "
                f"levou {process_time:.3f}s"
            )
        
        return response
```

#### MIDDLEWARE DE TENANT
```python
from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware

class TenantMiddleware(BaseHTTPMiddleware):
    """Middleware para isolamento de tenant"""
    
    async def dispatch(self, request: Request, call_next) -> Response:
        # Detectar tenant via diferentes métodos
        tenant_id = self._extract_tenant_id(request)
        
        if not tenant_id:
            raise HTTPException(
                status_code=400,
                detail="Tenant ID é obrigatório"
            )
        
        # Validar se tenant existe
        if not await self._validate_tenant(tenant_id):
            raise HTTPException(
                status_code=404,
                detail=f"Tenant {tenant_id} não encontrado"
            )
        
        # Adicionar tenant ao contexto da requisição
        request.state.tenant_id = tenant_id
        
        # Processar requisição com contexto de tenant
        response = await call_next(request)
        
        # Adicionar header de tenant na resposta
        response.headers["X-Tenant-ID"] = tenant_id
        
        return response
    
    def _extract_tenant_id(self, request: Request) -> str:
        """Extrai tenant ID de diferentes fontes"""
        
        # 1. Header HTTP
        tenant_id = request.headers.get("X-Tenant-ID")
        if tenant_id:
            return tenant_id
        
        # 2. Query parameter
        tenant_id = request.query_params.get("tenant")
        if tenant_id:
            return tenant_id
        
        # 3. Subdomain
        host = request.headers.get("host", "")
        if "." in host:
            subdomain = host.split(".")[0]
            if subdomain != "www" and subdomain != "api":
                return subdomain
        
        return None
```

### SISTEMA DE CACHE INTELIGENTE

#### IMPLEMENTAÇÃO REDIS
```python
import json
import hashlib
from typing import Any, Optional
from redis import Redis
from functools import wraps

class IntelligentCache:
    """Sistema de cache inteligente com Redis"""
    
    def __init__(self, redis_client: Redis):
        self.redis = redis_client
        self.default_ttl = 300  # 5 minutos
    
    def cache_key(self, prefix: str, *args, **kwargs) -> str:
        """Gera chave única para cache"""
        key_data = f"{prefix}:{args}:{sorted(kwargs.items())}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    async def get(self, key: str) -> Optional[Any]:
        """Recupera valor do cache"""
        try:
            value = await self.redis.get(key)
            return json.loads(value) if value else None
        except Exception as e:
            logging.warning(f"Erro ao recuperar cache {key}: {e}")
            return None
    
    async def set(self, key: str, value: Any, ttl: int = None) -> bool:
        """Armazena valor no cache"""
        try:
            ttl = ttl or self.default_ttl
            serialized = json.dumps(value, default=str)
            await self.redis.setex(key, ttl, serialized)
            return True
        except Exception as e:
            logging.warning(f"Erro ao armazenar cache {key}: {e}")
            return False
    
    async def invalidate_pattern(self, pattern: str) -> int:
        """Invalida chaves que correspondem ao padrão"""
        try:
            keys = await self.redis.keys(pattern)
            if keys:
                return await self.redis.delete(*keys)
            return 0
        except Exception as e:
            logging.warning(f"Erro ao invalidar cache {pattern}: {e}")
            return 0

# Decorator para cache automático
def cached(ttl: int = 300, key_prefix: str = "default"):
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            cache = IntelligentCache(redis_client)
            
            # Gerar chave de cache
            cache_key = cache.cache_key(
                f"{key_prefix}:{func.__name__}",
                *args, **kwargs
            )
            
            # Tentar recuperar do cache
            cached_result = await cache.get(cache_key)
            if cached_result is not None:
                return cached_result
            
            # Executar função e cachear resultado
            result = await func(*args, **kwargs)
            await cache.set(cache_key, result, ttl)
            
            return result
        return wrapper
    return decorator
```

### MONITORAMENTO E OBSERVABILIDADE

#### COLETA DE MÉTRICAS
```python
from prometheus_client import Counter, Histogram, Gauge, generate_latest
import time

# Métricas Prometheus
REQUEST_COUNT = Counter(
    'http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status']
)

REQUEST_DURATION = Histogram(
    'http_request_duration_seconds',
    'HTTP request duration',
    ['method', 'endpoint']
)

ACTIVE_CONNECTIONS = Gauge(
    'active_connections',
    'Active database connections'
)

class MetricsCollector:
    """Coletor de métricas do sistema"""
    
    def __init__(self):
        self.start_time = time.time()
    
    def record_request(self, method: str, endpoint: str, status: int, duration: float):
        """Registra métricas de requisição"""
        REQUEST_COUNT.labels(
            method=method,
            endpoint=endpoint,
            status=status
        ).inc()
        
        REQUEST_DURATION.labels(
            method=method,
            endpoint=endpoint
        ).observe(duration)
    
    def update_db_connections(self, count: int):
        """Atualiza contador de conexões ativas"""
        ACTIVE_CONNECTIONS.set(count)
    
    def get_metrics(self) -> str:
        """Retorna métricas em formato Prometheus"""
        return generate_latest()
```

#### SISTEMA DE ALERTAS
```python
import asyncio
from enum import Enum
from dataclasses import dataclass
from typing import List, Callable

class AlertSeverity(Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

@dataclass
class Alert:
    title: str
    message: str
    severity: AlertSeverity
    service: str
    timestamp: float
    metadata: dict = None

class AlertManager:
    """Gerenciador de alertas do sistema"""
    
    def __init__(self):
        self.handlers: List[Callable] = []
        self.alert_rules = {
            "high_cpu": lambda metrics: metrics.get("cpu_usage", 0) > 80,
            "high_memory": lambda metrics: metrics.get("memory_usage", 0) > 85,
            "slow_response": lambda metrics: metrics.get("avg_response_time", 0) > 2.0,
            "error_rate": lambda metrics: metrics.get("error_rate", 0) > 5.0
        }
    
    def add_handler(self, handler: Callable[[Alert], None]):
        """Adiciona handler de alerta"""
        self.handlers.append(handler)
    
    async def check_metrics(self, metrics: dict, service: str):
        """Verifica métricas e dispara alertas se necessário"""
        for rule_name, rule_func in self.alert_rules.items():
            if rule_func(metrics):
                alert = Alert(
                    title=f"Alerta: {rule_name}",
                    message=f"Regra {rule_name} violada no serviço {service}",
                    severity=AlertSeverity.WARNING,
                    service=service,
                    timestamp=time.time(),
                    metadata=metrics
                )
                await self._send_alert(alert)
    
    async def _send_alert(self, alert: Alert):
        """Envia alerta para todos os handlers"""
        for handler in self.handlers:
            try:
                await handler(alert)
            except Exception as e:
                logging.error(f"Erro ao enviar alerta: {e}")
```

---

## SEGURANÇA E COMPLIANCE

### AUTENTICAÇÃO E AUTORIZAÇÃO

#### JWT TOKEN MANAGEMENT
```python
import jwt
from datetime import datetime, timedelta
from typing import Dict, Optional

class JWTManager:
    """Gerenciador de tokens JWT"""
    
    def __init__(self, secret_key: str, algorithm: str = "HS256"):
        self.secret_key = secret_key
        self.algorithm = algorithm
        self.access_token_expire = timedelta(hours=1)
        self.refresh_token_expire = timedelta(days=7)
    
    def create_access_token(self, user_data: Dict) -> str:
        """Cria token de acesso"""
        expire = datetime.utcnow() + self.access_token_expire
        payload = {
            "user_id": user_data["id"],
            "username": user_data["username"],
            "tenant_id": user_data["tenant_id"],
            "roles": user_data["roles"],
            "exp": expire,
            "type": "access"
        }
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    def create_refresh_token(self, user_id: str) -> str:
        """Cria token de refresh"""
        expire = datetime.utcnow() + self.refresh_token_expire
        payload = {
            "user_id": user_id,
            "exp": expire,
            "type": "refresh"
        }
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    def verify_token(self, token: str) -> Optional[Dict]:
        """Verifica e decodifica token"""
        try:
            payload = jwt.decode(
                token, 
                self.secret_key, 
                algorithms=[self.algorithm]
            )
            return payload
        except jwt.ExpiredSignatureError:
            raise AuthenticationError("Token expirado")
        except jwt.InvalidTokenError:
            raise AuthenticationError("Token inválido")
```

#### CONTROLE DE ACESSO BASEADO EM ROLES (RBAC)
```python
from enum import Enum
from typing import Set, List
from functools import wraps

class Permission(Enum):
    # Contratos
    CONTRACT_READ = "contract:read"
    CONTRACT_WRITE = "contract:write"
    CONTRACT_DELETE = "contract:delete"
    
    # Catálogo
    CATALOG_READ = "catalog:read"
    CATALOG_WRITE = "catalog:write"
    
    # Qualidade
    QUALITY_READ = "quality:read"
    QUALITY_WRITE = "quality:write"
    
    # Administração
    ADMIN_USERS = "admin:users"
    ADMIN_SYSTEM = "admin:system"

class Role:
    """Definição de role com permissões"""
    
    def __init__(self, name: str, permissions: Set[Permission]):
        self.name = name
        self.permissions = permissions

# Definição de roles padrão
ROLES = {
    "data_owner": Role("Data Owner", {
        Permission.CONTRACT_READ,
        Permission.CONTRACT_WRITE,
        Permission.CATALOG_READ,
        Permission.CATALOG_WRITE,
        Permission.QUALITY_READ,
        Permission.QUALITY_WRITE
    }),
    
    "data_engineer": Role("Data Engineer", {
        Permission.CONTRACT_READ,
        Permission.CATALOG_READ,
        Permission.QUALITY_READ
    }),
    
    "business_user": Role("Business User", {
        Permission.CATALOG_READ,
        Permission.QUALITY_READ
    }),
    
    "admin": Role("Administrator", set(Permission))
}

def require_permission(permission: Permission):
    """Decorator para verificar permissões"""
    def decorator(func):
        @wraps(func)
        async def wrapper(request: Request, *args, **kwargs):
            # Extrair usuário do token
            user = request.state.user
            
            # Verificar se usuário tem a permissão
            if not has_permission(user, permission):
                raise HTTPException(
                    status_code=403,
                    detail=f"Permissão {permission.value} necessária"
                )
            
            return await func(request, *args, **kwargs)
        return wrapper
    return decorator

def has_permission(user: dict, permission: Permission) -> bool:
    """Verifica se usuário tem permissão específica"""
    user_roles = user.get("roles", [])
    
    for role_name in user_roles:
        role = ROLES.get(role_name)
        if role and permission in role.permissions:
            return True
    
    return False
```

### AUDITORIA E COMPLIANCE

#### SISTEMA DE AUDITORIA
```python
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Dict, Any
import json

@dataclass
class AuditEvent:
    """Evento de auditoria"""
    event_type: str
    user_id: str
    tenant_id: str
    resource_type: str
    resource_id: str
    action: str
    timestamp: datetime
    ip_address: str
    user_agent: str
    request_data: Optional[Dict[str, Any]] = None
    response_data: Optional[Dict[str, Any]] = None
    success: bool = True
    error_message: Optional[str] = None

class AuditLogger:
    """Logger de auditoria"""
    
    def __init__(self, database_connection):
        self.db = database_connection
    
    async def log_event(self, event: AuditEvent):
        """Registra evento de auditoria"""
        try:
            query = """
            INSERT INTO audit_logs (
                event_type, user_id, tenant_id, resource_type, 
                resource_id, action, timestamp, ip_address, 
                user_agent, request_data, response_data, 
                success, error_message
            ) VALUES (
                $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13
            )
            """
            
            await self.db.execute(
                query,
                event.event_type,
                event.user_id,
                event.tenant_id,
                event.resource_type,
                event.resource_id,
                event.action,
                event.timestamp,
                event.ip_address,
                event.user_agent,
                json.dumps(event.request_data) if event.request_data else None,
                json.dumps(event.response_data) if event.response_data else None,
                event.success,
                event.error_message
            )
        except Exception as e:
            # Log crítico - não pode falhar
            logging.critical(f"Falha ao registrar auditoria: {e}")
    
    async def get_audit_trail(
        self, 
        resource_type: str, 
        resource_id: str,
        tenant_id: str
    ) -> List[AuditEvent]:
        """Recupera trilha de auditoria para recurso"""
        query = """
        SELECT * FROM audit_logs 
        WHERE resource_type = $1 
        AND resource_id = $2 
        AND tenant_id = $3
        ORDER BY timestamp DESC
        """
        
        rows = await self.db.fetch(query, resource_type, resource_id, tenant_id)
        return [self._row_to_event(row) for row in rows]

# Decorator para auditoria automática
def audit(event_type: str, resource_type: str):
    def decorator(func):
        @wraps(func)
        async def wrapper(request: Request, *args, **kwargs):
            start_time = datetime.utcnow()
            success = True
            error_message = None
            response_data = None
            
            try:
                # Executar função
                result = await func(request, *args, **kwargs)
                response_data = {"status": "success"}
                return result
            except Exception as e:
                success = False
                error_message = str(e)
                raise
            finally:
                # Registrar evento de auditoria
                event = AuditEvent(
                    event_type=event_type,
                    user_id=request.state.user["id"],
                    tenant_id=request.state.tenant_id,
                    resource_type=resource_type,
                    resource_id=kwargs.get("id", "unknown"),
                    action=request.method,
                    timestamp=start_time,
                    ip_address=request.client.host,
                    user_agent=request.headers.get("user-agent", ""),
                    request_data=dict(request.query_params),
                    response_data=response_data,
                    success=success,
                    error_message=error_message
                )
                
                await audit_logger.log_event(event)
        
        return wrapper
    return decorator
```

---

## TESTES E QUALIDADE

### ESTRATÉGIA DE TESTES

#### TESTES UNITÁRIOS
```python
import pytest
from unittest.mock import Mock, AsyncMock
from apps.contract_service.services.contract_service import ContractService
from apps.contract_service.models.contract import Contract

class TestContractService:
    """Testes unitários para ContractService"""
    
    @pytest.fixture
    def mock_repository(self):
        """Mock do repositório"""
        return Mock()
    
    @pytest.fixture
    def mock_validator(self):
        """Mock do validador"""
        return Mock()
    
    @pytest.fixture
    def contract_service(self, mock_repository, mock_validator):
        """Instância do serviço para testes"""
        return ContractService(mock_repository, mock_validator)
    
    @pytest.mark.asyncio
    async def test_create_contract_success(self, contract_service, mock_repository, mock_validator):
        """Teste de criação de contrato com sucesso"""
        # Arrange
        contract_data = {
            "name": "Contrato Teste",
            "version": "1.0.0",
            "schema": {"type": "object"}
        }
        
        mock_validator.validate_schema.return_value = ValidationResult(is_valid=True)
        mock_repository.save.return_value = Contract(**contract_data, id="123")
        
        # Act
        result = await contract_service.create_contract(contract_data)
        
        # Assert
        assert result.id == "123"
        assert result.name == "Contrato Teste"
        mock_validator.validate_schema.assert_called_once()
        mock_repository.save.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_create_contract_validation_error(self, contract_service, mock_validator):
        """Teste de criação de contrato com erro de validação"""
        # Arrange
        contract_data = {"name": "Contrato Inválido"}
        mock_validator.validate_schema.return_value = ValidationResult(
            is_valid=False, 
            errors=["Schema obrigatório"]
        )
        
        # Act & Assert
        with pytest.raises(ContractValidationError) as exc_info:
            await contract_service.create_contract(contract_data)
        
        assert "Schema obrigatório" in str(exc_info.value)
```

#### TESTES DE INTEGRAÇÃO
```python
import pytest
import httpx
from fastapi.testclient import TestClient
from apps.api_gateway.main import app

class TestContractAPI:
    """Testes de integração para API de contratos"""
    
    @pytest.fixture
    def client(self):
        """Cliente de teste"""
        return TestClient(app)
    
    @pytest.fixture
    def auth_headers(self):
        """Headers de autenticação"""
        return {"Authorization": "Bearer test_token"}
    
    def test_create_contract_integration(self, client, auth_headers):
        """Teste de integração para criação de contrato"""
        # Arrange
        contract_data = {
            "name": "Contrato Integração",
            "version": "1.0.0",
            "schema": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "name": {"type": "string"}
                }
            }
        }
        
        # Act
        response = client.post(
            "/api/v1/contracts",
            json=contract_data,
            headers=auth_headers
        )
        
        # Assert
        assert response.status_code == 201
        data = response.json()
        assert data["name"] == "Contrato Integração"
        assert "id" in data
    
    def test_get_contract_integration(self, client, auth_headers):
        """Teste de integração para busca de contrato"""
        # Act
        response = client.get(
            "/api/v1/contracts/123",
            headers=auth_headers
        )
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert "name" in data
        assert "version" in data
```

#### TESTES DE PERFORMANCE
```python
import asyncio
import time
from locust import HttpUser, task, between

class DataGovernanceUser(HttpUser):
    """Usuário de teste para performance"""
    
    wait_time = between(1, 3)
    
    def on_start(self):
        """Setup inicial do usuário"""
        # Login
        response = self.client.post("/api/v1/auth/login", json={
            "username": "test_user",
            "password": "test_password"
        })
        
        if response.status_code == 200:
            self.token = response.json()["access_token"]
            self.headers = {"Authorization": f"Bearer {self.token}"}
        else:
            self.headers = {}
    
    @task(3)
    def list_contracts(self):
        """Teste de listagem de contratos"""
        self.client.get("/api/v1/contracts", headers=self.headers)
    
    @task(2)
    def get_contract_details(self):
        """Teste de detalhes de contrato"""
        self.client.get("/api/v1/contracts/123", headers=self.headers)
    
    @task(1)
    def create_contract(self):
        """Teste de criação de contrato"""
        contract_data = {
            "name": f"Contrato Teste {time.time()}",
            "version": "1.0.0",
            "schema": {"type": "object"}
        }
        self.client.post(
            "/api/v1/contracts",
            json=contract_data,
            headers=self.headers
        )
    
    @task(2)
    def search_catalog(self):
        """Teste de busca no catálogo"""
        self.client.get(
            "/api/v1/catalog/search?q=test",
            headers=self.headers
        )
```

### COBERTURA DE TESTES

#### CONFIGURAÇÃO PYTEST
```python
# pytest.ini
[tool:pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = 
    --cov=apps
    --cov-report=html
    --cov-report=xml
    --cov-report=term-missing
    --cov-fail-under=85
    -v
    --tb=short
asyncio_mode = auto

# Marcadores personalizados
markers =
    unit: Testes unitários
    integration: Testes de integração
    performance: Testes de performance
    slow: Testes que demoram para executar
```

#### RELATÓRIO DE COBERTURA
```bash
# Executar testes com cobertura
pytest --cov=apps --cov-report=html --cov-report=term

# Resultado esperado:
# Name                                    Stmts   Miss  Cover
# -------------------------------------------------------
# apps/api_gateway/main.py                  45      2    96%
# apps/contract_service/main.py             38      1    97%
# apps/identity_service/main.py             42      3    93%
# apps/layout_service/main.py               35      2    94%
# -------------------------------------------------------
# TOTAL                                    847     72    85%
```

---

## PERFORMANCE E OTIMIZAÇÃO

### BENCHMARKS DE PERFORMANCE

#### MÉTRICAS ATUAIS
- **Tempo médio de resposta:** 65ms
- **P95:** 120ms
- **P99:** 180ms
- **Throughput:** 350 req/s
- **Taxa de erro:** < 0.1%

#### OTIMIZAÇÕES IMPLEMENTADAS

**Pool de Conexões Otimizado**
```python
# Configuração PostgreSQL
POSTGRES_POOL_CONFIG = {
    "min_size": 5,
    "max_size": 20,
    "max_queries": 50000,
    "max_inactive_connection_lifetime": 300,
    "timeout": 30,
    "command_timeout": 60
}

# Configuração Redis
REDIS_POOL_CONFIG = {
    "max_connections": 50,
    "retry_on_timeout": True,
    "socket_keepalive": True,
    "socket_keepalive_options": {
        "TCP_KEEPIDLE": 1,
        "TCP_KEEPINTVL": 3,
        "TCP_KEEPCNT": 5
    }
}
```

**Cache Inteligente**
```python
# Estratégias de cache por tipo de dados
CACHE_STRATEGIES = {
    "contracts": {"ttl": 1800, "pattern": "contract:*"},
    "users": {"ttl": 900, "pattern": "user:*"},
    "catalog": {"ttl": 3600, "pattern": "catalog:*"},
    "quality_rules": {"ttl": 7200, "pattern": "quality:*"}
}

# Invalidação automática
async def invalidate_related_cache(entity_type: str, entity_id: str):
    """Invalida cache relacionado quando entidade é modificada"""
    patterns = [
        f"{entity_type}:{entity_id}",
        f"{entity_type}:list:*",
        f"dashboard:*"  # Dashboards dependem de múltiplas entidades
    ]
    
    for pattern in patterns:
        await cache.invalidate_pattern(pattern)
```

### MONITORAMENTO DE PERFORMANCE

#### ALERTAS DE PERFORMANCE
```python
PERFORMANCE_THRESHOLDS = {
    "response_time_p95": 200,  # ms
    "response_time_p99": 500,  # ms
    "error_rate": 1.0,         # %
    "cpu_usage": 80,           # %
    "memory_usage": 85,        # %
    "disk_usage": 90,          # %
    "db_connections": 18       # max 20
}

async def check_performance_metrics():
    """Verifica métricas de performance e dispara alertas"""
    metrics = await collect_metrics()
    
    for metric, threshold in PERFORMANCE_THRESHOLDS.items():
        current_value = metrics.get(metric, 0)
        
        if current_value > threshold:
            await send_alert(
                title=f"Performance Alert: {metric}",
                message=f"{metric} = {current_value} (threshold: {threshold})",
                severity=AlertSeverity.WARNING
            )
```

---

## PRÓXIMOS PASSOS TÉCNICOS

### ROADMAP DE EVOLUÇÃO TÉCNICA

#### Q1 2025: OTIMIZAÇÕES AVANÇADAS
- Implementação de cache distribuído
- Otimização de queries com índices especializados
- Compressão de dados em trânsito
- CDN para assets estáticos

#### Q2 2025: ARQUITETURA EVENT-DRIVEN
- Migração para Apache Kafka
- Implementação de Event Sourcing
- CQRS (Command Query Responsibility Segregation)
- Stream processing em tempo real

#### Q3 2025: INTELIGÊNCIA ARTIFICIAL
- ML para detecção de anomalias
- Recomendações inteligentes
- Auto-scaling baseado em ML
- Processamento de linguagem natural

#### Q4 2025: CLOUD NATIVE
- Migração para Kubernetes
- Service mesh com Istio
- Serverless functions
- Multi-cloud deployment

---

**Documentação elaborada em:** 31 de julho de 2025  
**Responsável:** Sistema de Governança de Dados V1.1  
**Próxima revisão:** Trimestral

