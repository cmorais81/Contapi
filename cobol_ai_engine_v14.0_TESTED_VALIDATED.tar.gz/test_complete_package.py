#!/usr/bin/env python3
"""
Script de Teste Completo - COBOL AI Engine v14.0
Testa todos os componentes e funcionalidades do pacote
"""

import os
import sys
import json
import yaml
import subprocess
import traceback
from pathlib import Path

# Adicionar o diretório do projeto ao path
project_dir = Path(__file__).parent / "cobol_ai_engine_v2.0.0"
sys.path.insert(0, str(project_dir))

class PackageTestSuite:
    def __init__(self):
        self.project_dir = project_dir
        self.test_results = []
        self.errors = []
        
    def log_test(self, test_name, status, message="", error=None):
        """Registra resultado de um teste"""
        result = {
            "test": test_name,
            "status": status,
            "message": message,
            "error": str(error) if error else None
        }
        self.test_results.append(result)
        
        status_icon = "✅" if status == "PASS" else "❌" if status == "FAIL" else "⚠️"
        print(f"{status_icon} {test_name}: {message}")
        
        if error:
            print(f"   Erro: {error}")
            self.errors.append(f"{test_name}: {error}")
    
    def test_file_structure(self):
        """Testa se todos os arquivos essenciais existem"""
        print("\n🔍 TESTE 1: Estrutura de Arquivos")
        
        essential_files = [
            "main.py",
            "README.md",
            "requirements.txt",
            "config/config.yaml",
            "examples/fontes.txt",
            "examples/BOOKS.txt",
            "src/__init__.py",
            "src/analyzers/__init__.py",
            "src/analyzers/purpose_extractor.py",
            "src/analyzers/simple_flow_mapper.py",
            "src/generators/__init__.py",
            "src/generators/executive_summary_generator.py",
            "src/parsers/__init__.py",
            "src/parsers/multi_program_cobol_parser.py",
            "src/utils/__init__.py",
            "src/utils/extract_programs.py",
            "src/utils/extract_books.py"
        ]
        
        missing_files = []
        for file_path in essential_files:
            full_path = self.project_dir / file_path
            if full_path.exists():
                self.log_test(f"Arquivo {file_path}", "PASS", f"Existe ({full_path.stat().st_size} bytes)")
            else:
                missing_files.append(file_path)
                self.log_test(f"Arquivo {file_path}", "FAIL", "Arquivo não encontrado")
        
        if not missing_files:
            self.log_test("Estrutura de Arquivos", "PASS", "Todos os arquivos essenciais presentes")
        else:
            self.log_test("Estrutura de Arquivos", "FAIL", f"{len(missing_files)} arquivos faltando")
    
    def test_config_files(self):
        """Testa se os arquivos de configuração são válidos"""
        print("\n⚙️ TESTE 2: Arquivos de Configuração")
        
        # Teste config.yaml
        try:
            config_path = self.project_dir / "config" / "config.yaml"
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            # Verificar seções essenciais
            required_sections = ['ai', 'analysis', 'logging', 'output']
            missing_sections = [s for s in required_sections if s not in config]
            
            if missing_sections:
                self.log_test("Config YAML", "FAIL", f"Seções faltando: {missing_sections}")
            else:
                self.log_test("Config YAML", "PASS", "Estrutura válida com todas as seções")
                
            # Verificar provedores
            if 'providers' in config.get('ai', {}):
                providers = config['ai']['providers']
                provider_count = len([p for p in providers if isinstance(providers[p], dict)])
                self.log_test("Provedores AI", "PASS", f"{provider_count} provedores configurados")
            
        except Exception as e:
            self.log_test("Config YAML", "FAIL", "Erro ao carregar", e)
    
    def test_python_imports(self):
        """Testa se todos os módulos podem ser importados"""
        print("\n🐍 TESTE 3: Importações Python")
        
        modules_to_test = [
            ("src.analyzers.purpose_extractor", "PurposeExtractor"),
            ("src.analyzers.simple_flow_mapper", "SimpleFlowMapper"),
            ("src.generators.executive_summary_generator", "ExecutiveSummaryGenerator"),
            ("src.parsers.multi_program_cobol_parser", "MultiProgramCOBOLParser"),
            ("src.utils.extract_programs", None),
            ("src.utils.extract_books", None)
        ]
        
        for module_name, class_name in modules_to_test:
            try:
                module = __import__(module_name, fromlist=[class_name] if class_name else [])
                if class_name:
                    cls = getattr(module, class_name)
                    self.log_test(f"Import {module_name}.{class_name}", "PASS", "Classe importada com sucesso")
                else:
                    self.log_test(f"Import {module_name}", "PASS", "Módulo importado com sucesso")
            except Exception as e:
                self.log_test(f"Import {module_name}", "FAIL", "Erro na importação", e)
    
    def test_dependencies(self):
        """Testa se as dependências estão instaladas"""
        print("\n📦 TESTE 4: Dependências")
        
        required_deps = ['yaml', 'json', 're', 'os', 'pathlib', 'datetime', 'logging']
        
        for dep in required_deps:
            try:
                if dep == 'yaml':
                    import yaml
                elif dep == 'json':
                    import json
                elif dep == 're':
                    import re
                elif dep == 'os':
                    import os
                elif dep == 'pathlib':
                    import pathlib
                elif dep == 'datetime':
                    import datetime
                elif dep == 'logging':
                    import logging
                
                self.log_test(f"Dependência {dep}", "PASS", "Disponível")
            except ImportError as e:
                self.log_test(f"Dependência {dep}", "FAIL", "Não instalada", e)
    
    def test_example_files(self):
        """Testa se os arquivos de exemplo são válidos"""
        print("\n📄 TESTE 5: Arquivos de Exemplo")
        
        # Teste fontes.txt
        try:
            fontes_path = self.project_dir / "examples" / "fontes.txt"
            with open(fontes_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            lines = [line.strip() for line in content.split('\n') if line.strip()]
            program_count = len([line for line in lines if not line.startswith('#')])
            
            self.log_test("fontes.txt", "PASS", f"{program_count} programas listados")
            
        except Exception as e:
            self.log_test("fontes.txt", "FAIL", "Erro ao ler arquivo", e)
        
        # Teste BOOKS.txt
        try:
            books_path = self.project_dir / "examples" / "BOOKS.txt"
            with open(books_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Contar copybooks
            copybook_count = content.count('COPY ')
            self.log_test("BOOKS.txt", "PASS", f"~{copybook_count} referências COPY encontradas")
            
        except Exception as e:
            self.log_test("BOOKS.txt", "FAIL", "Erro ao ler arquivo", e)
    
    def test_main_script_syntax(self):
        """Testa se o script principal tem sintaxe válida"""
        print("\n🔧 TESTE 6: Sintaxe do Script Principal")
        
        try:
            main_path = self.project_dir / "main.py"
            with open(main_path, 'r', encoding='utf-8') as f:
                code = f.read()
            
            # Compilar para verificar sintaxe
            compile(code, str(main_path), 'exec')
            self.log_test("Sintaxe main.py", "PASS", "Sintaxe Python válida")
            
            # Verificar se tem função main
            if 'def main(' in code:
                self.log_test("Função main()", "PASS", "Função principal encontrada")
            else:
                self.log_test("Função main()", "WARN", "Função main() não encontrada")
                
        except SyntaxError as e:
            self.log_test("Sintaxe main.py", "FAIL", "Erro de sintaxe", e)
        except Exception as e:
            self.log_test("Sintaxe main.py", "FAIL", "Erro ao verificar", e)
    
    def test_component_instantiation(self):
        """Testa se os componentes podem ser instanciados"""
        print("\n🏗️ TESTE 7: Instanciação de Componentes")
        
        try:
            # Teste PurposeExtractor
            from src.analyzers.purpose_extractor import PurposeExtractor
            extractor = PurposeExtractor()
            self.log_test("PurposeExtractor", "PASS", "Instanciado com sucesso")
        except Exception as e:
            self.log_test("PurposeExtractor", "FAIL", "Erro na instanciação", e)
        
        try:
            # Teste SimpleFlowMapper
            from src.analyzers.simple_flow_mapper import SimpleFlowMapper
            mapper = SimpleFlowMapper()
            self.log_test("SimpleFlowMapper", "PASS", "Instanciado com sucesso")
        except Exception as e:
            self.log_test("SimpleFlowMapper", "FAIL", "Erro na instanciação", e)
        
        try:
            # Teste ExecutiveSummaryGenerator
            from src.generators.executive_summary_generator import ExecutiveSummaryGenerator
            generator = ExecutiveSummaryGenerator()
            self.log_test("ExecutiveSummaryGenerator", "PASS", "Instanciado com sucesso")
        except Exception as e:
            self.log_test("ExecutiveSummaryGenerator", "FAIL", "Erro na instanciação", e)
    
    def test_full_execution(self):
        """Testa execução completa do sistema"""
        print("\n🚀 TESTE 8: Execução Completa")
        
        try:
            # Executar o script principal
            cmd = [
                sys.executable, 
                str(self.project_dir / "main.py"),
                str(self.project_dir / "examples" / "fontes.txt"),
                str(self.project_dir / "examples" / "BOOKS.txt")
            ]
            
            result = subprocess.run(
                cmd,
                cwd=str(self.project_dir),
                capture_output=True,
                text=True,
                timeout=120  # 2 minutos timeout
            )
            
            if result.returncode == 0:
                # Verificar se gerou resultados
                output_dir = self.project_dir / "conceptual_understanding_results_v14"
                if output_dir.exists():
                    files_generated = len(list(output_dir.rglob("*.md")))
                    self.log_test("Execução Completa", "PASS", f"Executado com sucesso, {files_generated} arquivos gerados")
                else:
                    self.log_test("Execução Completa", "WARN", "Executado mas sem diretório de resultados")
            else:
                self.log_test("Execução Completa", "FAIL", f"Código de saída: {result.returncode}")
                if result.stderr:
                    print(f"   Stderr: {result.stderr[:500]}...")
                    
        except subprocess.TimeoutExpired:
            self.log_test("Execução Completa", "FAIL", "Timeout na execução")
        except Exception as e:
            self.log_test("Execução Completa", "FAIL", "Erro na execução", e)
    
    def test_output_validation(self):
        """Valida a qualidade dos resultados gerados"""
        print("\n📊 TESTE 9: Validação de Resultados")
        
        try:
            # Verificar relatório consolidado
            consolidated_path = self.project_dir / "conceptual_understanding_results_v14" / "CONSOLIDATED_UNDERSTANDING_REPORT_v14.md"
            
            if consolidated_path.exists():
                with open(consolidated_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Verificar conteúdo essencial
                checks = [
                    ("Score médio", "Score médio" in content or "score" in content.lower()),
                    ("Programas analisados", "programas" in content.lower()),
                    ("Resumo executivo", len(content) > 1000),  # Conteúdo substancial
                ]
                
                passed_checks = sum(1 for _, check in checks if check)
                self.log_test("Relatório Consolidado", "PASS" if passed_checks >= 2 else "WARN", 
                            f"{passed_checks}/{len(checks)} verificações passaram")
            else:
                self.log_test("Relatório Consolidado", "FAIL", "Arquivo não encontrado")
                
            # Verificar relatórios individuais
            results_dir = self.project_dir / "conceptual_understanding_results_v14"
            if results_dir.exists():
                individual_reports = list(results_dir.glob("*/LHAN*_UNDERSTANDING_v14.md"))
                self.log_test("Relatórios Individuais", "PASS", f"{len(individual_reports)} relatórios encontrados")
            else:
                self.log_test("Relatórios Individuais", "FAIL", "Diretório de resultados não encontrado")
                
        except Exception as e:
            self.log_test("Validação de Resultados", "FAIL", "Erro na validação", e)
    
    def run_all_tests(self):
        """Executa todos os testes"""
        print("🧪 INICIANDO TESTE COMPLETO DO PACOTE COBOL AI ENGINE v14.0")
        print("=" * 60)
        
        # Executar todos os testes
        self.test_file_structure()
        self.test_config_files()
        self.test_python_imports()
        self.test_dependencies()
        self.test_example_files()
        self.test_main_script_syntax()
        self.test_component_instantiation()
        self.test_full_execution()
        self.test_output_validation()
        
        # Resumo final
        print("\n" + "=" * 60)
        print("📋 RESUMO DOS TESTES")
        print("=" * 60)
        
        total_tests = len(self.test_results)
        passed = len([r for r in self.test_results if r['status'] == 'PASS'])
        failed = len([r for r in self.test_results if r['status'] == 'FAIL'])
        warnings = len([r for r in self.test_results if r['status'] == 'WARN'])
        
        print(f"📊 Total de testes: {total_tests}")
        print(f"✅ Passou: {passed}")
        print(f"❌ Falhou: {failed}")
        print(f"⚠️ Avisos: {warnings}")
        print(f"📈 Taxa de sucesso: {(passed/total_tests)*100:.1f}%")
        
        if failed == 0:
            print("\n🎉 TODOS OS TESTES CRÍTICOS PASSARAM!")
            print("✅ O pacote está funcionando corretamente!")
        elif failed <= 2:
            print(f"\n⚠️ {failed} teste(s) falharam, mas o pacote deve funcionar")
        else:
            print(f"\n❌ {failed} testes falharam - pacote pode ter problemas")
        
        if self.errors:
            print("\n🔍 ERROS ENCONTRADOS:")
            for error in self.errors[:5]:  # Mostrar apenas os primeiros 5
                print(f"   • {error}")
        
        return failed == 0

if __name__ == "__main__":
    tester = PackageTestSuite()
    success = tester.run_all_tests()
    sys.exit(0 if success else 1)
