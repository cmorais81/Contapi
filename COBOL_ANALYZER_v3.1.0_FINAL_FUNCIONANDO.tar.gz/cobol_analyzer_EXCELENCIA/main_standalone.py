#!/usr/bin/env python3
"""
COBOL Analyzer - Versão Standalone
Versão que funciona independentemente após instalação via pip
"""

import sys
import os
import subprocess
from pathlib import Path

def find_original_main():
    """Encontra o main.py original da aplicação"""
    # Procurar no diretório atual primeiro
    current_dir = Path.cwd()
    main_candidates = [
        current_dir / "main.py",
        current_dir / "cobol_analyzer_EXCELENCIA" / "main.py",
    ]
    
    # Procurar no diretório do script
    script_dir = Path(__file__).parent
    main_candidates.extend([
        script_dir / "main.py",
        script_dir.parent / "main.py",
        script_dir.parent / "cobol_analyzer_EXCELENCIA" / "main.py",
    ])
    
    # Verificar se algum existe e tem o conteúdo correto
    for candidate in main_candidates:
        if candidate.exists() and candidate.name != "main_standalone.py":
            # Verificar se é o main.py correto (contém imports do src)
            try:
                with open(candidate, 'r') as f:
                    content = f.read()
                    if 'from src.core.config import ConfigManager' in content:
                        return str(candidate)
            except:
                continue
    
    return None

def main():
    """Função principal que executa o COBOL Analyzer"""
    # Encontrar o main.py original
    original_main = find_original_main()
    
    if original_main:
        # Executar o main.py original
        try:
            # Mudar para o diretório do main.py original para resolver imports
            original_dir = os.path.dirname(original_main)
            os.chdir(original_dir)
            
            # Executar como subprocess
            cmd = [sys.executable, original_main] + sys.argv[1:]
            return subprocess.call(cmd)
            
        except Exception as e:
            print(f"Erro ao executar o main.py original: {e}")
    
    # Fallback: tentar executar main.py do PATH
    try:
        cmd = [sys.executable, "main.py"] + sys.argv[1:]
        return subprocess.call(cmd)
    except Exception as e:
        print("Erro: Não foi possível executar o COBOL Analyzer.")
        print("\nPossíveis soluções:")
        print("1. Execute diretamente: python3 main.py --help")
        print("2. Use o CLI: python3 cli.py --help")
        print("3. Navegue até o diretório da aplicação e execute")
        print(f"\nErro técnico: {e}")
        return 1

if __name__ == '__main__':
    sys.exit(main())
