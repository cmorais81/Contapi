"""
Verificador de Status Simples - COBOL Analysis Engine v2.0
Verifica conectividade com provedores de IA de forma robusta
"""

import os
import asyncio
import httpx
from typing import Dict, Any

class SimpleStatusChecker:
    """Verificador de status simples e robusto"""
    
    def __init__(self):
        self.results = {}
    
    async def check_all_providers(self) -> Dict[str, Any]:
        """Verifica status de todos os provedores disponíveis"""
        
        print(" Verificando conectividade com provedores de IA...")
        print("=" * 60)
        
        # Verificar LuzIA
        await self._check_luzia()
        
        # Verificar OpenAI
        await self._check_openai()
        
        # Verificar outros provedores básicos
        await self._check_basic_providers()
        
        print("=" * 60)
        self._show_summary()
        
        return self.results
    
    async def _check_luzia(self):
        """Verifica conectividade com LuzIA"""
        
        provider_name = "LUZIA"
        
        try:
            client_id = os.getenv("LUZIA_CLIENT_ID")
            client_secret = os.getenv("LUZIA_CLIENT_SECRET")
            
            if not client_id or not client_secret:
                print(f"⚪ {provider_name}: Credenciais não configuradas")
                print(f"   Configure: LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET")
                self.results[provider_name.lower()] = {
                    'status': 'not_configured',
                    'message': 'Credenciais não configuradas'
                }
                return
            
            # Testar autenticação
            sso_endpoint = "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
            
            payload = {
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret
            }
            
            async with httpx.AsyncClient(verify=False, timeout=10.0) as client:
                response = await client.post(sso_endpoint, data=payload)
                
                if response.status_code == 200:
                    token_data = response.json()
                    if token_data.get("access_token"):
                        print(f" {provider_name}: Conectado")
                        print(f"   Modelo: azure-gpt-4o-mini")
                        print(f"   Endpoint: gut-api-aws.santanderbr.dev.corp")
                        self.results[provider_name.lower()] = {
                            'status': 'connected',
                            'model': 'azure-gpt-4o-mini'
                        }
                    else:
                        print(f" {provider_name}: Token inválido")
                        self.results[provider_name.lower()] = {
                            'status': 'error',
                            'message': 'Token inválido'
                        }
                else:
                    print(f" {provider_name}: Falha na autenticação (HTTP {response.status_code})")
                    self.results[provider_name.lower()] = {
                        'status': 'error',
                        'message': f'HTTP {response.status_code}'
                    }
                    
        except Exception as e:
            print(f" {provider_name}: Erro - {str(e)}")
            self.results[provider_name.lower()] = {
                'status': 'error',
                'message': str(e)
            }
        
        print()
    
    async def _check_openai(self):
        """Verifica conectividade com OpenAI"""
        
        provider_name = "OPENAI"
        
        try:
            api_key = os.getenv("OPENAI_API_KEY")
            
            if not api_key:
                print(f"⚪ {provider_name}: API Key não configurada")
                print(f"   Configure: OPENAI_API_KEY")
                self.results[provider_name.lower()] = {
                    'status': 'not_configured',
                    'message': 'API Key não configurada'
                }
                return
            
            # Testar conexão básica
            headers = {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json"
            }
            
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.get(
                    "https://api.openai.com/v1/models",
                    headers=headers
                )
                
                if response.status_code == 200:
                    print(f" {provider_name}: Conectado")
                    print(f"   Modelo: gpt-4o-mini")
                    print(f"   Endpoint: api.openai.com")
                    self.results[provider_name.lower()] = {
                        'status': 'connected',
                        'model': 'gpt-4o-mini'
                    }
                elif response.status_code == 401:
                    print(f" {provider_name}: API Key inválida")
                    self.results[provider_name.lower()] = {
                        'status': 'error',
                        'message': 'API Key inválida'
                    }
                else:
                    print(f" {provider_name}: Falha na conexão (HTTP {response.status_code})")
                    self.results[provider_name.lower()] = {
                        'status': 'error',
                        'message': f'HTTP {response.status_code}'
                    }
                    
        except Exception as e:
            print(f" {provider_name}: Erro - {str(e)}")
            self.results[provider_name.lower()] = {
                'status': 'error',
                'message': str(e)
            }
        
        print()
    
    async def _check_basic_providers(self):
        """Verifica outros provedores básicos"""
        
        # Verificar se bibliotecas estão instaladas
        providers_to_check = [
            ("DATABRICKS", "databricks"),
            ("BEDROCK", "boto3"),
            ("GITHUB_COPILOT", "github")
        ]
        
        for provider_name, module_name in providers_to_check:
            try:
                __import__(module_name)
                print(f"⚪ {provider_name}: Biblioteca disponível (não configurado)")
                self.results[provider_name.lower()] = {
                    'status': 'available',
                    'message': 'Biblioteca instalada, configuração necessária'
                }
            except ImportError:
                print(f"⚪ {provider_name}: Biblioteca não instalada")
                self.results[provider_name.lower()] = {
                    'status': 'not_installed',
                    'message': f'Execute: pip install {module_name}'
                }
            
            print()
    
    def _show_summary(self):
        """Mostra resumo dos resultados"""
        
        connected = len([r for r in self.results.values() if r['status'] == 'connected'])
        available = len([r for r in self.results.values() if r['status'] in ['connected', 'available']])
        total = len(self.results)
        
        print(f" Resumo:")
        print(f"   Conectados: {connected}")
        print(f"   Disponíveis: {available}")
        print(f"   Total verificados: {total}")
        print()
        print(f"💡 Dicas de configuração:")
        print(f"   - Para usar LuzIA: Configure as variáveis LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET")
        print(f"   - Para usar OpenAI: Configure a variável OPENAI_API_KEY")
        print(f"   - Sistema funciona no modo básico mesmo sem IAs configuradas")
        print()
        print(f" Sistema sempre funcional no modo traditional")
