"""
COBOL AI Engine v4.0 - Enhanced COBOL Parser
Parser aprimorado mantendo compatibilidade total com o sistema existente.
"""

import logging
import time
from typing import List, Dict, Any, Optional, Tuple

# Importar classes existentes para manter compatibilidade
from parsers.cobol_parser import COBOLParser, CobolProgram, CobolBook
from parsers.interfaces.parser_interface import (
    ICobolParser, IContentDetector, IContentCleaner, 
    IMemberExtractor, ITypeClassifier, ParseResult, ParseStatistics
)


class EnhancedCobolParser(ICobolParser):
    """
    Parser COBOL aprimorado que mantém compatibilidade total com o sistema existente.
    
    Funcionalidades:
    - Compatibilidade 100% com COBOLParser original
    - Detecção inteligente de formato de arquivo
    - Limpeza robusta de conteúdo
    - Extração aprimorada de membros VMEMBER
    - Classificação automática de tipos
    - Estatísticas detalhadas
    - Tratamento de erros robusto
    """
    
    def __init__(self, 
                 detector: Optional[IContentDetector] = None,
                 cleaner: Optional[IContentCleaner] = None,
                 extractor: Optional[IMemberExtractor] = None,
                 classifier: Optional[ITypeClassifier] = None,
                 statistics_collector=None):
        """
        Inicializa o parser aprimorado.
        
        Args:
            detector: Detector de conteúdo (opcional)
            cleaner: Limpador de conteúdo (opcional)
            extractor: Extrator de membros (opcional)
            classifier: Classificador de tipos (opcional)
            statistics_collector: Coletor de estatísticas (opcional)
        """
        self.logger = logging.getLogger(__name__)
        
        # Manter parser original para compatibilidade
        self.original_parser = COBOLParser()
        
        # Componentes opcionais (injeção de dependência)
        self._detector = detector
        self._cleaner = cleaner
        self._extractor = extractor
        self._classifier = classifier
        self._statistics_collector = statistics_collector
        
        # Estatísticas
        self.statistics = ParseStatistics()
        
        self.logger.info("Enhanced COBOL Parser inicializado com compatibilidade total")
    
    def parse_file(self, file_path: str) -> ParseResult:
        """
        Parse um arquivo COBOL mantendo compatibilidade com o método original.
        
        Args:
            file_path: Caminho para o arquivo
            
        Returns:
            ParseResult: Resultado do parsing
        """
        start_time = time.time()
        
        try:
            self.logger.info(f"Parseando arquivo: {file_path}")
            
            # Usar parser original para manter compatibilidade
            programs, books = self.original_parser.parse_file(file_path)
            
            # Atualizar estatísticas
            self.statistics.files_parsed += 1
            self.statistics.programs_parsed += len(programs)
            self.statistics.copybooks_parsed += len(books)
            self.statistics.processing_time_ms += (time.time() - start_time) * 1000
            
            # Criar resultado compatível
            result = ParseResult(
                programs=programs,
                copybooks=books,
                source=file_path,
                success=True,
                statistics=self.statistics
            )
            
            self.logger.info(f"Parsing concluído: {len(programs)} programas, {len(books)} copybooks")
            return result
            
        except Exception as e:
            self.logger.error(f"Erro ao parsear arquivo {file_path}: {e}")
            self.statistics.errors += 1
            return ParseResult.create_error_result(str(e), file_path)
    
    def parse_content(self, content: str, source_name: str = None) -> ParseResult:
        """
        Parse conteúdo COBOL diretamente.
        
        Args:
            content: Conteúdo COBOL
            source_name: Nome da fonte (opcional)
            
        Returns:
            ParseResult: Resultado do parsing
        """
        start_time = time.time()
        
        try:
            self.logger.info(f"Parseando conteúdo: {source_name or 'fonte desconhecida'}")
            
            # Se temos componentes aprimorados, usar lógica aprimorada
            if self._detector and self._extractor and self._classifier:
                return self._parse_content_enhanced(content, source_name)
            else:
                # Usar lógica compatível com parser original
                return self._parse_content_compatible(content, source_name)
                
        except Exception as e:
            self.logger.error(f"Erro ao parsear conteúdo: {e}")
            self.statistics.errors += 1
            return ParseResult.create_error_result(str(e), source_name)
    
    def _parse_content_compatible(self, content: str, source_name: str) -> ParseResult:
        """Parse usando lógica compatível com o parser original."""
        
        # Simular arquivo temporário para usar parser original
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.cbl', delete=False) as temp_file:
            temp_file.write(content)
            temp_file_path = temp_file.name
        
        try:
            # Usar parser original
            programs, books = self.original_parser.parse_file(temp_file_path)
            
            # Atualizar estatísticas
            self.statistics.programs_parsed += len(programs)
            self.statistics.copybooks_parsed += len(books)
            
            return ParseResult(
                programs=programs,
                copybooks=books,
                source=source_name,
                success=True,
                statistics=self.statistics
            )
            
        finally:
            # Limpar arquivo temporário
            try:
                os.unlink(temp_file_path)
            except:
                pass
    
    def _parse_content_enhanced(self, content: str, source_name: str) -> ParseResult:
        """Parse usando componentes aprimorados."""
        
        programs = []
        copybooks = []
        
        # Detectar tipo de conteúdo
        content_type = self._detector.detect_content_type(content)
        
        if content_type.value == "stacked":
            # Arquivo empilhado - extrair membros
            members = self._extractor.extract_members(content)
            
            for member in members:
                # Limpar conteúdo se temos limpador
                if self._cleaner:
                    cleaned_lines = self._cleaner.clean_content(member.content.split('\n'))
                    member.content = '\n'.join(cleaned_lines)
                
                # Classificar tipo
                member_type = self._classifier.classify_member(member.content)
                
                # Converter para classes compatíveis
                if member_type.value == "program":
                    program = self._create_compatible_program(member)
                    programs.append(program)
                elif member_type.value == "copybook":
                    copybook = self._create_compatible_copybook(member)
                    copybooks.append(copybook)
        else:
            # Arquivo único - usar parser original
            return self._parse_content_compatible(content, source_name)
        
        # Atualizar estatísticas
        self.statistics.programs_parsed += len(programs)
        self.statistics.copybooks_parsed += len(books)
        
        return ParseResult(
            programs=programs,
            copybooks=copybooks,
            source=source_name,
            success=True,
            statistics=self.statistics
        )
    
    def _create_compatible_program(self, member) -> CobolProgram:
        """Cria programa compatível com a classe original."""
        
        # Usar parser original para extrair detalhes
        temp_program = self.original_parser._parse_program(member.name, member.content)
        
        return temp_program
    
    def _create_compatible_copybook(self, member) -> CobolBook:
        """Cria copybook compatível com a classe original."""
        
        # Usar parser original para extrair detalhes
        temp_book = self.original_parser._parse_book(member.name, member.content)
        
        return temp_book
    
    def get_statistics(self) -> ParseStatistics:
        """
        Retorna estatísticas do parser.
        
        Returns:
            ParseStatistics: Estatísticas de processamento
        """
        return self.statistics
    
    def reset_statistics(self) -> None:
        """Reseta as estatísticas do parser."""
        self.statistics = ParseStatistics()
    
    def get_supported_formats(self) -> List[str]:
        """
        Retorna formatos suportados pelo parser.
        
        Returns:
            List[str]: Lista de formatos suportados
        """
        return ['COBOL', 'Copybook', 'VMEMBER', 'Stacked Files']
    
    def validate_content(self, content: str) -> bool:
        """
        Valida se o conteúdo é COBOL válido.
        
        Args:
            content: Conteúdo a validar
            
        Returns:
            bool: True se válido, False caso contrário
        """
        if not content or not content.strip():
            return False
        
        # Verificar indicadores básicos de COBOL
        cobol_indicators = [
            'IDENTIFICATION', 'PROGRAM-ID', 'DATA DIVISION',
            'PROCEDURE DIVISION', 'WORKING-STORAGE', 'VMEMBER'
        ]
        
        content_upper = content.upper()
        return any(indicator in content_upper for indicator in cobol_indicators)
    
    # Métodos para compatibilidade com COBOLParser original
    def parse_program(self, content: str, file_path: str = None) -> CobolProgram:
        """
        Método de compatibilidade com COBOLParser original.
        
        Args:
            content: Conteúdo do programa
            file_path: Caminho do arquivo (opcional)
            
        Returns:
            CobolProgram: Programa parseado
        """
        return self.original_parser.parse_program(content, file_path)
    
    def get_parser_statistics(self) -> Dict[str, Any]:
        """
        Método de compatibilidade com COBOLParser original.
        
        Returns:
            Dict[str, Any]: Estatísticas do parser
        """
        original_stats = self.original_parser.get_parser_statistics()
        
        # Adicionar estatísticas aprimoradas
        enhanced_stats = {
            'enhanced_version': '4.0',
            'enhanced_features': [
                'Intelligent content detection',
                'Robust member extraction',
                'Automatic type classification',
                'Enhanced error handling',
                'Detailed statistics'
            ],
            'compatibility': 'Full backward compatibility with v2.1.0',
            'statistics': self.statistics.to_dict()
        }
        
        # Mesclar estatísticas
        original_stats.update(enhanced_stats)
        return original_stats
