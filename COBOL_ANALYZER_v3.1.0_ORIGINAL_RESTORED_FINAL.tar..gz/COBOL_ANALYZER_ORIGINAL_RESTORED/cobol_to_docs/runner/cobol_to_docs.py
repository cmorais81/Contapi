#!/usr/bin/env python3
"""
COBOL to Docs - Ponto de entrada principal
Ferramenta de análise de código COBOL com IA
"""

import sys
import os
import argparse
import shutil
from pathlib import Path

def find_package_path():
    """Encontra o caminho do pacote instalado"""
    try:
        import cobol_to_docs
        package_path = Path(cobol_to_docs.__file__).parent
        return package_path
    except ImportError:
        # Se não conseguir importar, tenta encontrar pelo caminho do script
        script_path = Path(__file__).parent.parent
        return script_path

def init_project(target_dir=None):
    """Inicializa um projeto COBOL Analyzer copiando todos os arquivos necessários"""
    if target_dir is None:
        target_dir = Path.cwd()
    else:
        target_dir = Path(target_dir)
    
    print(f"Inicializando projeto COBOL Analyzer em: {target_dir}")
    
    # Encontrar o caminho do pacote
    package_path = find_package_path()
    
    # Diretórios a serem copiados
    dirs_to_copy = ["config", "data", "examples"]
    
    success_count = 0
    
    for dir_name in dirs_to_copy:
        source_dir = package_path / dir_name
        target_subdir = target_dir / dir_name
        
        if source_dir.exists():
            try:
                if target_subdir.exists():
                    print(f"Diretório {dir_name} já existe, sobrescrevendo...")
                    shutil.rmtree(target_subdir)
                
                shutil.copytree(source_dir, target_subdir)
                print(f"✓ Copiado: {dir_name}/")
                success_count += 1
            except Exception as e:
                print(f"✗ Erro ao copiar {dir_name}: {e}")
        else:
            print(f"⚠ Diretório {dir_name} não encontrado em {source_dir}")
    
    # Criar diretórios de trabalho
    work_dirs = ["logs", "output", "temp"]
    for work_dir in work_dirs:
        work_path = target_dir / work_dir
        work_path.mkdir(exist_ok=True)
        print(f"✓ Criado: {work_dir}/")
    
    # Criar arquivo de exemplo de fontes se não existir
    fontes_example = target_dir / "fontes_exemplo.txt"
    if not fontes_example.exists():
        with open(fontes_example, "w", encoding="utf-8") as f:
            f.write("# Lista de programas COBOL para análise\n")
            f.write("# Um programa por linha\n")
            f.write("# Exemplo:\n")
            f.write("# programa1.cbl\n")
            f.write("# programa2.cbl\n")
        print("✓ Criado: fontes_exemplo.txt")
    
    print(f"\n✓ Inicialização concluída!")
    print(f"Arquivos copiados: {success_count}/{len(dirs_to_copy)}")
    print(f"\nPara usar:")
    print(f"1. Configure suas credenciais de IA no arquivo config/config.yaml")
    print(f"2. Liste seus programas COBOL em um arquivo (ex: fontes_exemplo.txt)")
    print(f"3. Execute: cobol-to-docs --fontes fontes_exemplo.txt --models enhanced_mock")

def main():
    """Função principal"""
    parser = argparse.ArgumentParser(
        description="COBOL to Docs v3.1.0 - Análise automatizada de código COBOL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  cobol-to-docs --init
  cobol-to-docs --fontes programas.txt --models luzia
  cobol-to-docs --fontes programas.txt --books copybooks.txt --models enhanced_mock
  cobol-to-docs --fontes programas.txt --consolidado --models luzia
  cobol-to-docs --status
        """
    )
    
    # Argumentos principais
    parser.add_argument("--init", action="store_true", 
                       help="Inicializar projeto copiando config, data e examples")
    parser.add_argument("--init-dir", type=str,
                       help="Diretório para inicialização (padrão: diretório atual)")
    parser.add_argument("--fontes", type=str,
                       help="Arquivo com lista de programas COBOL ou código COBOL direto")
    parser.add_argument("--books", type=str,
                       help="Arquivo com lista de copybooks")
    parser.add_argument("--models", type=str,
                       help="Modelo(s) de IA a usar (string ou JSON array)")
    parser.add_argument("--output", type=str, default="output",
                       help="Diretório de saída (padrão: output)")
    
    # Opções de análise
    parser.add_argument("--consolidado", action="store_true",
                       help="Análise consolidada sistêmica")
    parser.add_argument("--relatorio-unico", action="store_true",
                       help="Relatório único consolidado")
    parser.add_argument("--analise-especialista", action="store_true",
                       help="Análise especializada")
    parser.add_argument("--procedure-detalhada", action="store_true",
                       help="Análise detalhada da PROCEDURE DIVISION")
    parser.add_argument("--modernizacao", action="store_true",
                       help="Análise para modernização")
    
    # Opções de configuração
    parser.add_argument("--prompt-set", type=str,
                       help="Conjunto de prompts a usar")
    parser.add_argument("--no-comments", action="store_true",
                       help="Remover comentários do código")
    parser.add_argument("--pdf", action="store_true",
                       help="Gerar relatórios HTML/PDF")
    parser.add_argument("--log-level", type=str, default="INFO",
                       help="Nível de logging")
    
    # Comandos utilitários
    parser.add_argument("--status", action="store_true",
                       help="Verificar status do sistema")
    
    args = parser.parse_args()
    
    # Comando de inicialização
    if args.init:
        init_project(args.init_dir)
        return 0
    
    # Se não for inicialização, delegar para o main.py
    try:
        # Adicionar o diretório do pacote ao path
        package_path = find_package_path()
        sys.path.insert(0, str(package_path.parent))
        
        # Importar e executar o main
        from cobol_to_docs.runner.main import main as main_func
        
        # Reconstruir sys.argv para o main.py
        new_argv = ["main.py"]
        if args.fontes:
            new_argv.extend(["--fontes", args.fontes])
        if args.books:
            new_argv.extend(["--books", args.books])
        if args.models:
            new_argv.extend(["--models", args.models])
        if args.output != "output":
            new_argv.extend(["--output", args.output])
        if args.consolidado:
            new_argv.append("--consolidado")
        if args.relatorio_unico:
            new_argv.append("--relatorio-unico")
        if args.analise_especialista:
            new_argv.append("--analise-especialista")
        if args.procedure_detalhada:
            new_argv.append("--procedure-detalhada")
        if args.modernizacao:
            new_argv.append("--modernizacao")
        if args.prompt_set:
            new_argv.extend(["--prompt-set", args.prompt_set])
        if args.no_comments:
            new_argv.append("--no-comments")
        if args.pdf:
            new_argv.append("--pdf")
        if args.log_level != "INFO":
            new_argv.extend(["--log-level", args.log_level])
        if args.status:
            new_argv.append("--status")
        
        # Substituir sys.argv temporariamente
        old_argv = sys.argv
        sys.argv = new_argv
        
        try:
            return main_func()
        finally:
            sys.argv = old_argv
            
    except ImportError as e:
        print(f"Erro: Não foi possível importar o módulo principal: {e}")
        print("Certifique-se de que o COBOL Analyzer está instalado corretamente.")
        return 1
    except Exception as e:
        print(f"Erro inesperado: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
