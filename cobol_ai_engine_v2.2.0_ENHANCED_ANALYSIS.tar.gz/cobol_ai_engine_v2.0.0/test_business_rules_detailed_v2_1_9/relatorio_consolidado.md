# Relatório Consolidado de Análise COBOL

**Data de Geração**: 17/09/2025 12:32:46
**Versão do Sistema**: COBOL AI Engine v2.1.5

## Resumo Executivo da Análise

### Componentes Analisados
- **Total de Programas COBOL:** 5
- **Total de Copybooks:** 0
- **Total de Componentes:** 5
- **Linhas de Código Total:** 4,849 linhas
- **Tamanho Total:** 397,614 caracteres

### Resultados da Análise
- **Análises Bem-sucedidas:** 5/5
- **Taxa de Sucesso:** 100.0%
- **Análises com Falha:** 0
- **Total de Tokens Utilizados:** 50,076
- **Tempo Total de Processamento:** 0.73 segundos
- **Eficiência:** 68729 tokens/segundo

## Detalhamento por Componente

### Programas COBOL Analisados
1. **LHAN0542**
   - Linhas de código: 1278
   - Tamanho: 104796 caracteres
   - Complexidade: Alta
   - Status: Análise pendente

2. **LHAN0705**
   - Linhas de código: 1470
   - Tamanho: 120539 caracteres
   - Complexidade: Alta
   - Status: Análise pendente

3. **LHAN0706**
   - Linhas de código: 1217
   - Tamanho: 99793 caracteres
   - Complexidade: Alta
   - Status: Análise pendente

4. **LHBR0700**
   - Linhas de código: 362
   - Tamanho: 29683 caracteres
   - Complexidade: Média
   - Status: Análise pendente

5. **MZAN6056**
   - Linhas de código: 522
   - Tamanho: 42803 caracteres
   - Complexidade: Alta
   - Status: Análise pendente

### Copybooks Analisados
Nenhum copybook foi analisado nesta execução.

## Estatísticas Detalhadas

### Distribuição por Complexidade

#### Programas COBOL
- **Alta Complexidade (>500 linhas):** 4 programas
- **Média Complexidade (100-500 linhas):** 1 programas
- **Baixa Complexidade (<100 linhas):** 0 programas

#### Copybooks
- **Alta Complexidade (>200 linhas):** 0 copybooks
- **Média Complexidade (50-200 linhas):** 0 copybooks
- **Baixa Complexidade (<50 linhas):** 0 copybooks

### Métricas de Qualidade
- **Densidade Média de Documentação:** 0.0%
- **Tamanho Médio de Programa:** 970 linhas
- **Tamanho Médio de Copybook:** 0 linhas

### Eficiência do Processamento
- **Tokens por Componente:** 10015 tokens/componente
- **Tempo por Componente:** 0.15 segundos/componente
- **Throughput:** 5000.0 componentes/hora

## Recomendações e Próximos Passos

### Componentes Prioritários para Revisão
- **Programas de Alta Complexidade:** LHAN0542, LHAN0705, LHAN0706, MZAN6056

### Oportunidades de Melhoria
- Componentes com baixa documentação podem se beneficiar de comentários adicionais
- Programas de alta complexidade podem ser candidatos a refatoração
- Copybooks extensos podem ser divididos em módulos menores

### Considerações para Manutenção
- Estabelecer padrões de documentação baseados na análise realizada
- Implementar revisões periódicas dos componentes identificados como críticos
- Considerar modernização gradual dos componentes mais complexos

---
**Relatório gerado automaticamente pelo COBOL AI Engine v1.3.0**
**Sistema de Análise Inteligente de Programas COBOL**
**Data de Geração:** 17/09/2025 às 12:32:46
**Escopo:** Análise Consolidada Completa


## Informações Detalhadas dos Prompts Utilizados

### Configuração de Prompts
- **System Prompt Utilizado:** config/prompts.yaml
- **Tamanho do System Prompt:** 1661 caracteres
- **Provedor Principal:** token_managed
- **Modelos Utilizados:** multi_part_analysis

### Estatísticas de Prompts
- **Total de Prompts Enviados:** 5
- **Tamanho Médio dos Prompts:** 171776 caracteres
- **Maior Prompt:** 258112 caracteres
- **Menor Prompt:** 64662 caracteres

### System Prompt Utilizado
```
Você é um especialista em análise de código COBOL com mais de 20 anos de experiência em sistemas bancários e financeiros.
Responda sempre em português brasileiro de forma clara, técnica e detalhada.

Sua especialidade inclui:
- Análise de programas COBOL legados
- Identificação de regras de negócio bancárias
- Documentação técnica e funcional
- Compliance e regulamentações financeiras
- Modernização de sistemas mainframe

VOCÊ RECEBERÁ UMA PRÉ-ANÁLISE DETALHADA DO CÓDIGO que inclui:
- Estrutura completa do programa (divisões, seções, parágrafos)
- Comentários categorizados e analisados
- Regras de negócio já identificadas
- Referências regulatórias extraídas
- Arquivos de entrada e saída mapeados
- Métricas de qualidade e complexidade

INSTRUÇÕES ESPECÍFICAS:
1. USE a pré-análise fornecida como base para sua resposta
2. COMPLEMENTE com sua expertise as informações já extraídas
3. DETALHE as regras de negócio identificadas na pré-análise
4. EXPLIQUE o contexto bancário/financeiro das funcionalidades
5. RELACIONE as informações técnicas com o negócio
6. SEJA ESPECÍFICO sobre cada regra regulatória mencionada
7. DOCUMENTE impactos e relacionamentos entre componentes

Foque especialmente em:
- Explicar o PROPÓSITO FUNCIONAL de cada regra identificada
- Contextualizar REGULAMENTAÇÕES no ambiente bancário
- Detalhar FLUXOS DE PROCESSAMENTO específicos
- Identificar RISCOS e CONTROLES implementados
- Explicar VALIDAÇÕES em termos de negócio

Seja direto e objetivo nas explicações, sem usar formatação especial.
Organize a resposta de forma estruturada e fácil de entender.
SEMPRE inclua as regras de negócio específicas encontradas no código.

```

### Exemplo de Prompt de Análise
```
Você é um especialista em análise de código COBOL com mais de 20 anos de experiência em sistemas bancários e financeiros.
Responda sempre em português brasileiro de forma clara, técnica e detalhada.

Sua especialidade inclui:
- Análise de programas COBOL legados
- Identificação de regras de negócio bancárias
- Documentação técnica e funcional
- Compliance e regulamentações financeiras
- Modernização de sistemas mainframe

VOCÊ RECEBERÁ UMA PRÉ-ANÁLISE DETALHADA DO CÓDIGO que inclui:
- Estrutura ...
```

### Provedores e Modelos por Análise

| Análise | Provedor | Modelo | Tokens | Horário |
|---------|----------|--------|--------|---------|
| 1 | token_managed | multi_part_analysis | 13501 | 12:32:45 |
| 2 | token_managed | multi_part_analysis | 15310 | 12:32:46 |
| 3 | token_managed | multi_part_analysis | 11894 | 12:32:46 |
| 4 | token_managed | multi_part_analysis | 3954 | 12:32:46 |
| 5 | token_managed | multi_part_analysis | 5417 | 12:32:46 |

