# Parâmetros da API Claude 3.5 Sonnet para Análises Mais Aprofundadas

## Parâmetros Principais Identificados

### 1. **system** (string)
- **Função**: Define o prompt do sistema que estabelece o papel e comportamento do Claude
- **Uso para análises aprofundadas**: Pode ser usado para definir um papel específico como "especialista em análise de código COBOL" com instruções detalhadas sobre o nível de profundidade esperado

### 2. **temperature** (number, 0.0-1.0)
- **Função**: Controla a aleatoriedade das respostas
- **Valor atual no sistema**: 0.1 (baixo para consistência)
- **Recomendação**: Manter baixo (0.1-0.3) para análises técnicas consistentes

### 3. **max_tokens** (integer, required)
- **Função**: Número máximo de tokens a serem gerados
- **Valor atual no sistema**: 4000
- **Potencial melhoria**: Aumentar para 8000-8192 (máximo suportado pelo Claude 3.5 Sonnet) para análises mais extensas

### 4. **messages** (array, required)
- **Função**: Array de mensagens da conversa
- **Estrutura**: Cada mensagem tem `role` ("user", "assistant") e `content`
- **Uso aprimorado**: Pode incluir múltiplas mensagens para criar contexto mais rico

## Parâmetros Avançados Potenciais

### 5. **Estrutura de Mensagens Complexas**
- **content**: Pode ser string simples ou array de blocos de conteúdo
- **Tipos de conteúdo**: "text", "image_url" (para análise visual de código)

### 6. **Configurações de Modelo Específicas**
- **Modelo**: "claude-3-5-sonnet-20241022" (versão mais recente)
- **Context Window**: 200,000 tokens (muito maior que o atual)

## Recomendações para Análises Mais Aprofundadas

### 1. **Aumentar max_tokens**
```yaml
luzia:
  max_tokens: 8000  # Aumentar de 4000 para 8000
```

### 2. **Otimizar system prompt**
```yaml
system_prompts:
  detailed_analysis: |
    Você é um especialista sênior em análise de código COBOL com 20+ anos de experiência em sistemas bancários e financeiros.
    
    Sua tarefa é realizar análises EXTREMAMENTE DETALHADAS e APROFUNDADAS, incluindo:
    
    1. ANÁLISE FUNCIONAL EXAUSTIVA:
       - Descreva cada funcionalidade em detalhes técnicos
       - Explique o propósito de negócio de cada seção
       - Identifique padrões arquiteturais utilizados
    
    2. ANÁLISE DE REGRAS DE NEGÓCIO COMPLETA:
       - Liste TODAS as regras identificadas
       - Explique o contexto regulatório de cada regra
       - Detalhe as implicações de compliance
    
    3. ANÁLISE TÉCNICA PROFUNDA:
       - Avalie a qualidade do código
       - Identifique pontos de melhoria
       - Sugira otimizações específicas
    
    IMPORTANTE: Seja EXTREMAMENTE DETALHADO. Prefira análises longas e completas a resumos superficiais.
```

### 3. **Usar temperatura mais baixa para consistência**
```yaml
luzia:
  temperature: 0.05  # Ainda mais baixo para máxima consistência
```

### 4. **Implementar mensagens estruturadas**
- Usar múltiplas mensagens para criar contexto
- Incluir exemplos de análises esperadas
- Fornecer templates de resposta detalhados

## Parâmetros Específicos do LuzIA

Com base na configuração atual, o LuzIA usa uma estrutura específica:

```json
{
  "input": {
    "query": [
      {"role": "system", "content": "prompt_do_sistema"},
      {"role": "user", "content": "prompt_do_usuario"}
    ]
  },
  "config": [
    {
      "type": "catena.llm.LLMRouter",
      "obj_kwargs": {
        "routing_model": "aws-claude-3-5-sonnet",
        "temperature": 0.1,
        "max_tokens": 4000
      }
    }
  ]
}
```

### Melhorias Sugeridas para o LuzIA:
1. **Aumentar max_tokens para 8000**
2. **Implementar system prompts mais detalhados**
3. **Usar temperatura ainda mais baixa (0.05)**
4. **Adicionar parâmetros de configuração específicos se disponíveis**

## Próximos Passos

1. **Testar com max_tokens aumentado**
2. **Implementar system prompts mais detalhados**
3. **Validar se o LuzIA suporta parâmetros adicionais**
4. **Comparar resultados com configurações otimizadas**
