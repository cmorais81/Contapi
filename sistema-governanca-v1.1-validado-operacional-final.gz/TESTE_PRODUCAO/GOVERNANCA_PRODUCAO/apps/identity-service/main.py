"""
Identity Service - Serviço de Identidade e Autenticação
"""

from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from datetime import timedelta
import uvicorn
import sys
import os

# Adicionar diretório raiz ao path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from config.auth import authenticate_user, create_access_token, ACCESS_TOKEN_EXPIRE_MINUTES
from config.middleware import get_current_user, require_admin

app = FastAPI(
    title="Identity Service - Governança de Dados",
    description="Serviço de identidade e autenticação",
    version="1.1.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Endpoint raiz"""
    return {
        "service": "identity-service",
        "version": "1.1.0",
        "status": "running",
        "auth": "enabled"
    }

@app.get("/health")
async def health_check():
    """Health check"""
    return {"status": "healthy", "service": "identity-service"}

@app.post("/api/v1/auth/login")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    """Login e geração de token"""
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenciais inválidas",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["username"], "roles": user["roles"]},
        expires_delta=access_token_expires
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        "user": {
            "username": user["username"],
            "full_name": user["full_name"],
            "email": user["email"],
            "roles": user["roles"]
        }
    }

@app.get("/api/v1/auth/me")
async def get_current_user_info(current_user: dict = Depends(get_current_user)):
    """Obter informações do usuário atual"""
    return {
        "username": current_user.get("sub"),
        "roles": current_user.get("roles", []),
        "token_valid": True
    }

@app.post("/api/v1/auth/refresh")
async def refresh_token(current_user: dict = Depends(get_current_user)):
    """Renovar token"""
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": current_user.get("sub"), "roles": current_user.get("roles", [])},
        expires_delta=access_token_expires
    )
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60
    }

@app.get("/api/v1/users")
async def list_users(current_user: dict = Depends(require_admin)):
    """Listar usuários (apenas admin)"""
    # Mock de usuários
    users = [
        {
            "username": "admin",
            "full_name": "Administrador",
            "email": "admin@governance.com",
            "roles": ["admin", "user"],
            "active": True
        },
        {
            "username": "user",
            "full_name": "Usuário Padrão",
            "email": "user@governance.com",
            "roles": ["user"],
            "active": True
        }
    ]
    return users

@app.get("/api/v1/roles")
async def list_roles(current_user: dict = Depends(require_admin)):
    """Listar roles disponíveis"""
    roles = [
        {
            "name": "admin",
            "description": "Administrador do sistema",
            "permissions": ["read", "write", "delete", "admin"]
        },
        {
            "name": "user",
            "description": "Usuário padrão",
            "permissions": ["read", "write"]
        }
    ]
    return roles

if __name__ == "__main__":
    print("Iniciando Identity Service na porta 8001...")
    uvicorn.run(app, host="0.0.0.0", port=8001)
