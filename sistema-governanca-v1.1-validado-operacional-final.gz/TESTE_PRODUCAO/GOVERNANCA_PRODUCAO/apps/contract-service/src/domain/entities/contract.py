"""
Contract Entity - Entidade de domínio para contratos de dados
Segue princípios SOLID - Single Responsibility Principle
"""
from datetime import datetime
from typing import Dict, List, Optional, Any
from uuid import uuid4
from dataclasses import dataclass, field
from enum import Enum


class ContractStatus(Enum):
    """Status possíveis de um contrato"""
    DRAFT = "draft"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"


class DataClassification(Enum):
    """Classificação de dados"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"


@dataclass
class Contract:
    """
    Entidade Contract - representa um contrato de dados
    Responsabilidade única: representar dados de um contrato
    """
    # Campos obrigatórios
    name: str
    data_classification: DataClassification
    owner_email: str
    
    # Campos com valores padrão
    id: str = field(default_factory=lambda: str(uuid4()))
    version: str = "1.0.0"
    status: ContractStatus = ContractStatus.DRAFT
    
    # Campos opcionais
    description: Optional[str] = None
    template_id: Optional[str] = None
    template_name: Optional[str] = None
    schema_definition: Optional[Dict[str, Any]] = None
    sla_requirements: Optional[Dict[str, Any]] = None
    compliance_requirements: Optional[List[str]] = None
    pii_fields: Optional[List[str]] = None
    generated_at: Optional[datetime] = None
    generated_by: Optional[str] = None
    
    # Campos de auditoria
    data_criacao: datetime = field(default_factory=datetime.now)
    data_atualizacao: datetime = field(default_factory=datetime.now)

    def __post_init__(self):
        """Validações pós-inicialização"""
        if not self.name or not self.name.strip():
            raise ValueError("Nome do contrato é obrigatório")
        if not self.owner_email or '@' not in self.owner_email:
            raise ValueError("Email do proprietário deve ser válido")
        if self.compliance_requirements is None:
            self.compliance_requirements = []
        if self.pii_fields is None:
            self.pii_fields = []

    def update_status(self, new_status: ContractStatus) -> None:
        """Atualiza status do contrato"""
        if not isinstance(new_status, ContractStatus):
            raise ValueError("Status deve ser um ContractStatus válido")
        self.status = new_status
        self.data_atualizacao = datetime.now()

    def add_pii_field(self, field_name: str) -> None:
        """Adiciona campo PII detectado"""
        if field_name and field_name not in self.pii_fields:
            self.pii_fields.append(field_name)
            self.data_atualizacao = datetime.now()

    def add_compliance_requirement(self, framework: str) -> None:
        """Adiciona framework de compliance"""
        if framework and framework not in self.compliance_requirements:
            self.compliance_requirements.append(framework)
            self.data_atualizacao = datetime.now()

    def is_active(self) -> bool:
        """Verifica se contrato está ativo"""
        return self.status == ContractStatus.ACTIVE

    def has_pii(self) -> bool:
        """Verifica se contrato possui campos PII"""
        return bool(self.pii_fields)

    def requires_compliance(self, framework: str) -> bool:
        """Verifica se contrato requer compliance específico"""
        return framework in (self.compliance_requirements or [])

    def to_dict(self) -> Dict[str, Any]:
        """Converte entidade para dicionário"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'version': self.version,
            'status': self.status.value,
            'data_classification': self.data_classification.value,
            'owner_email': self.owner_email,
            'template_id': self.template_id,
            'template_name': self.template_name,
            'schema_definition': self.schema_definition,
            'sla_requirements': self.sla_requirements,
            'compliance_requirements': self.compliance_requirements,
            'pii_fields': self.pii_fields,
            'generated_at': self.generated_at.isoformat() if self.generated_at else None,
            'generated_by': self.generated_by,
            'data_criacao': self.data_criacao.isoformat(),
            'data_atualizacao': self.data_atualizacao.isoformat()
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Contract':
        """Cria entidade a partir de dicionário"""
        # Converter enums
        if 'status' in data:
            data['status'] = ContractStatus(data['status'])
        if 'data_classification' in data:
            data['data_classification'] = DataClassification(data['data_classification'])
        
        # Converter datas
        if 'data_criacao' in data and isinstance(data['data_criacao'], str):
            data['data_criacao'] = datetime.fromisoformat(data['data_criacao'])
        if 'data_atualizacao' in data and isinstance(data['data_atualizacao'], str):
            data['data_atualizacao'] = datetime.fromisoformat(data['data_atualizacao'])
        if 'generated_at' in data and isinstance(data['generated_at'], str):
            data['generated_at'] = datetime.fromisoformat(data['generated_at'])
        
        return cls(**data)
