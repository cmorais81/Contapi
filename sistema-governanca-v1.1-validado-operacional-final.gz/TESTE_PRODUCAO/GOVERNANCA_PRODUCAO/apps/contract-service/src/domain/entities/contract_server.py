"""
Contract Server Entity - Entidade para servidores de contratos de dados
Baseado no Open Data Contract Standard (ODCS)
Segue princípios SOLID - Single Responsibility Principle
"""
from datetime import datetime
from typing import Dict, List, Optional, Any
from uuid import uuid4
from dataclasses import dataclass, field
from enum import Enum


class ServerType(Enum):
    """Tipos de servidor conforme ODCS"""
    API = "api"
    ATHENA = "athena"
    AZURE = "azure"
    BIGQUERY = "bigquery"
    CLICKHOUSE = "clickhouse"
    DATABRICKS = "databricks"
    DREMIO = "dremio"
    DRILL = "drill"
    DRUID = "druid"
    ELASTICSEARCH = "elasticsearch"
    HIVE = "hive"
    IMPALA = "impala"
    KAFKA = "kafka"
    KINESIS = "kinesis"
    MONGODB = "mongodb"
    MYSQL = "mysql"
    ORACLE = "oracle"
    POSTGRES = "postgres"
    PRESTO = "presto"
    REDSHIFT = "redshift"
    S3 = "s3"
    SNOWFLAKE = "snowflake"
    SPARK = "spark"
    SQLSERVER = "sqlserver"
    TRINO = "trino"


class Environment(Enum):
    """Ambientes de servidor"""
    PRODUCTION = "prod"
    STAGING = "staging"
    DEVELOPMENT = "dev"
    TESTING = "test"
    SANDBOX = "sandbox"
    PREPROD = "preprod"


@dataclass
class ContractServer:
    """
    Entidade ContractServer - representa um servidor de dados conforme ODCS
    Responsabilidade única: representar configuração e acesso a servidores
    """
    # Campos obrigatórios conforme ODCS
    server: str  # Identificador único do servidor
    type: ServerType  # Tipo do servidor
    description: str  # Descrição do servidor
    environment: Environment  # Ambiente do servidor
    
    # Campos opcionais
    id: str = field(default_factory=lambda: str(uuid4()))
    roles: List[str] = field(default_factory=list)  # Papéis com acesso
    connection_details: Optional[Dict[str, Any]] = None
    custom_properties: Optional[Dict[str, Any]] = None
    
    # Status e configuração
    is_active: bool = True
    is_default: bool = False
    priority: int = 1
    
    # Configurações específicas por tipo
    host: Optional[str] = None
    port: Optional[int] = None
    database: Optional[str] = None
    schema: Optional[str] = None
    username: Optional[str] = None
    
    # Configurações de segurança
    ssl_enabled: bool = True
    auth_method: Optional[str] = None
    certificate_path: Optional[str] = None
    
    # Configurações de performance
    connection_timeout: int = 30
    max_connections: int = 10
    connection_pool_size: int = 5
    
    # Metadados
    tags: List[str] = field(default_factory=list)
    owner_email: Optional[str] = None
    team: Optional[str] = None
    cost_center: Optional[str] = None
    
    # Campos de auditoria
    data_criacao: datetime = field(default_factory=datetime.now)
    data_atualizacao: datetime = field(default_factory=datetime.now)
    created_by: Optional[str] = None
    updated_by: Optional[str] = None

    def __post_init__(self):
        """Validações pós-inicialização"""
        if not self.server or not self.server.strip():
            raise ValueError("Identificador do servidor é obrigatório")
        
        if not self.description or not self.description.strip():
            raise ValueError("Descrição do servidor é obrigatória")
        
        if not isinstance(self.type, ServerType):
            raise ValueError("Tipo de servidor deve ser um ServerType válido")
        
        if not isinstance(self.environment, Environment):
            raise ValueError("Ambiente deve ser um Environment válido")
        
        # Validações específicas por tipo
        self._validate_type_specific_config()
        
        # Inicializar listas se None
        if self.roles is None:
            self.roles = []
        if self.tags is None:
            self.tags = []

    def _validate_type_specific_config(self):
        """Valida configurações específicas por tipo de servidor"""
        database_types = {ServerType.MYSQL, ServerType.POSTGRES, ServerType.ORACLE, 
                         ServerType.SQLSERVER, ServerType.REDSHIFT, ServerType.SNOWFLAKE}
        
        if self.type in database_types:
            if not self.host:
                raise ValueError(f"Host é obrigatório para servidor tipo {self.type.value}")
        
        if self.type == ServerType.API:
            if not self.host or not self.host.startswith(('http://', 'https://')):
                raise ValueError("Host deve ser uma URL válida para servidor tipo API")

    def add_role(self, role: str) -> None:
        """Adiciona papel com acesso ao servidor"""
        if role and role not in self.roles:
            self.roles.append(role)
            self.data_atualizacao = datetime.now()

    def remove_role(self, role: str) -> None:
        """Remove papel do acesso ao servidor"""
        if role in self.roles:
            self.roles.remove(role)
            self.data_atualizacao = datetime.now()

    def has_role(self, role: str) -> bool:
        """Verifica se papel tem acesso ao servidor"""
        return role in self.roles

    def add_tag(self, tag: str) -> None:
        """Adiciona tag ao servidor"""
        if tag and tag not in self.tags:
            self.tags.append(tag)
            self.data_atualizacao = datetime.now()

    def remove_tag(self, tag: str) -> None:
        """Remove tag do servidor"""
        if tag in self.tags:
            self.tags.remove(tag)
            self.data_atualizacao = datetime.now()

    def update_connection_details(self, details: Dict[str, Any]) -> None:
        """Atualiza detalhes de conexão"""
        if self.connection_details is None:
            self.connection_details = {}
        
        self.connection_details.update(details)
        self.data_atualizacao = datetime.now()

    def get_connection_string(self) -> Optional[str]:
        """Gera string de conexão baseada no tipo"""
        if not self.host:
            return None
        
        if self.type == ServerType.POSTGRES:
            port = self.port or 5432
            db = self.database or "postgres"
            return f"postgresql://{self.username}@{self.host}:{port}/{db}"
        
        elif self.type == ServerType.MYSQL:
            port = self.port or 3306
            db = self.database or "mysql"
            return f"mysql://{self.username}@{self.host}:{port}/{db}"
        
        elif self.type == ServerType.API:
            return self.host
        
        # Para outros tipos, retornar configuração customizada
        return self.connection_details.get('connection_string') if self.connection_details else None

    def is_production(self) -> bool:
        """Verifica se é ambiente de produção"""
        return self.environment == Environment.PRODUCTION

    def is_accessible_by_role(self, role: str) -> bool:
        """Verifica se papel pode acessar o servidor"""
        return self.is_active and (not self.roles or role in self.roles)

    def get_odcs_format(self) -> Dict[str, Any]:
        """Retorna formato compatível com ODCS"""
        return {
            "server": self.server,
            "type": self.type.value,
            "description": self.description,
            "environment": self.environment.value,
            "roles": self.roles.copy() if self.roles else [],
            "customProperties": self.custom_properties.copy() if self.custom_properties else {}
        }

    def to_dict(self) -> Dict[str, Any]:
        """Converte entidade para dicionário"""
        return {
            'id': self.id,
            'server': self.server,
            'type': self.type.value,
            'description': self.description,
            'environment': self.environment.value,
            'roles': self.roles.copy() if self.roles else [],
            'connection_details': self.connection_details.copy() if self.connection_details else None,
            'custom_properties': self.custom_properties.copy() if self.custom_properties else None,
            'is_active': self.is_active,
            'is_default': self.is_default,
            'priority': self.priority,
            'host': self.host,
            'port': self.port,
            'database': self.database,
            'schema': self.schema,
            'username': self.username,
            'ssl_enabled': self.ssl_enabled,
            'auth_method': self.auth_method,
            'certificate_path': self.certificate_path,
            'connection_timeout': self.connection_timeout,
            'max_connections': self.max_connections,
            'connection_pool_size': self.connection_pool_size,
            'tags': self.tags.copy() if self.tags else [],
            'owner_email': self.owner_email,
            'team': self.team,
            'cost_center': self.cost_center,
            'data_criacao': self.data_criacao.isoformat(),
            'data_atualizacao': self.data_atualizacao.isoformat(),
            'created_by': self.created_by,
            'updated_by': self.updated_by
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ContractServer':
        """Cria entidade a partir de dicionário"""
        # Converter enums
        if 'type' in data:
            data['type'] = ServerType(data['type'])
        if 'environment' in data:
            data['environment'] = Environment(data['environment'])
        
        # Converter datas
        if 'data_criacao' in data and isinstance(data['data_criacao'], str):
            data['data_criacao'] = datetime.fromisoformat(data['data_criacao'])
        if 'data_atualizacao' in data and isinstance(data['data_atualizacao'], str):
            data['data_atualizacao'] = datetime.fromisoformat(data['data_atualizacao'])
        
        return cls(**data)

    @classmethod
    def from_odcs_format(cls, odcs_data: Dict[str, Any]) -> 'ContractServer':
        """Cria entidade a partir do formato ODCS"""
        return cls(
            server=odcs_data['server'],
            type=ServerType(odcs_data['type']),
            description=odcs_data['description'],
            environment=Environment(odcs_data['environment']),
            roles=odcs_data.get('roles', []),
            custom_properties=odcs_data.get('customProperties', {})
        )

    def __str__(self) -> str:
        return f"ContractServer({self.server}, {self.type.value}, {self.environment.value})"

    def __repr__(self) -> str:
        return (f"ContractServer(server='{self.server}', type={self.type}, "
                f"environment={self.environment}, active={self.is_active})")

