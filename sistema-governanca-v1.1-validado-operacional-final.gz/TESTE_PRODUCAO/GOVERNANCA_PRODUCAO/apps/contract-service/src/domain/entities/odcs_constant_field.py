"""
ODCS Constant Field Entity
Implementa campos com valores constantes conforme Open Data Contract Standard v3.0.2
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Union
from enum import Enum
from datetime import datetime
import json


class ConstantType(Enum):
    """Tipos de campos constantes conforme ODCS"""
    FIXED_VALUE = "FIXED_VALUE"
    DEFAULT_VALUE = "DEFAULT_VALUE"
    ENUM_VALUES = "ENUM_VALUES"
    CALCULATED_VALUE = "CALCULATED_VALUE"
    SYSTEM_GENERATED = "SYSTEM_GENERATED"


class ChangePolicy(Enum):
    """Políticas de mudança para campos constantes"""
    IMMUTABLE = "IMMUTABLE"
    CONTROLLED_EVOLUTION = "CONTROLLED_EVOLUTION"
    VERSION_UPGRADE_ONLY = "VERSION_UPGRADE_ONLY"
    BUSINESS_APPROVAL_REQUIRED = "BUSINESS_APPROVAL_REQUIRED"


class QualityDimension(Enum):
    """Dimensões de qualidade conforme ODCS"""
    CONFORMITY = "conformity"
    ACCURACY = "accuracy"
    COMPLETENESS = "completeness"
    CONSISTENCY = "consistency"
    VALIDITY = "validity"
    UNIQUENESS = "uniqueness"


class Severity(Enum):
    """Níveis de severidade para validação"""
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class QualityRule:
    """Regra de qualidade ODCS para validação de campos constantes"""
    rule: str
    dimension: QualityDimension
    severity: Severity
    description: str
    business_impact: str = "operational"
    valid_values: Optional[List[str]] = None
    must_be_less_than: Optional[Union[int, float]] = None
    must_be_greater_than: Optional[Union[int, float]] = None
    custom_query: Optional[str] = None
    
    def to_odcs_dict(self) -> Dict[str, Any]:
        """Converte para formato ODCS YAML"""
        result = {
            "rule": self.rule,
            "dimension": self.dimension.value,
            "severity": self.severity.value,
            "description": self.description,
            "businessImpact": self.business_impact
        }
        
        if self.valid_values:
            result["validValues"] = self.valid_values
        if self.must_be_less_than is not None:
            result["mustBeLessThan"] = self.must_be_less_than
        if self.must_be_greater_than is not None:
            result["mustBeGreaterThan"] = self.must_be_greater_than
        if self.custom_query:
            result["query"] = self.custom_query
            
        return result


@dataclass
class ChangeHistoryEntry:
    """Entrada no histórico de mudanças"""
    version: str
    change_date: datetime
    change_description: str
    approved_by: str
    old_value: Optional[Any] = None
    new_value: Optional[Any] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "changeDate": self.change_date.isoformat(),
            "changeDescription": self.change_description,
            "approvedBy": self.approved_by,
            "oldValue": self.old_value,
            "newValue": self.new_value
        }


@dataclass
class ODCSConstantField:
    """
    Entidade para campos com valores constantes conforme ODCS v3.0.2
    
    Implementa todos os padrões ODCS para campos constantes mutáveis:
    - Quality Rules para validação
    - Custom Properties para configuração
    - Change Policies para controle de mutabilidade
    - Rastreabilidade completa de mudanças
    """
    
    # Propriedades básicas ODCS
    name: str
    business_name: str
    logical_type: str
    physical_type: str
    description: str
    
    # Tipo de campo constante
    constant_type: ConstantType
    
    # Valores e configuração
    default_value: Optional[Any] = None
    allowed_values: Optional[List[str]] = None
    current_value: Optional[Any] = None
    
    # Política de mudança
    change_policy: ChangePolicy = ChangePolicy.CONTROLLED_EVOLUTION
    change_approval_required: bool = True
    change_notification_required: bool = True
    approval_workflow: str = "data-governance-committee"
    
    # Regras de qualidade
    quality_rules: List[QualityRule] = field(default_factory=list)
    
    # Rastreabilidade
    change_history_enabled: bool = True
    change_audit_table: Optional[str] = None
    change_notification_topic: Optional[str] = None
    change_history: List[ChangeHistoryEntry] = field(default_factory=list)
    
    # Metadados ODCS
    classification: str = "internal"
    tags: List[str] = field(default_factory=list)
    examples: List[str] = field(default_factory=list)
    
    # Propriedades customizadas
    custom_properties: Dict[str, Any] = field(default_factory=dict)
    
    # Campos calculados
    transform_logic: Optional[str] = None
    dependencies: List[str] = field(default_factory=list)
    
    # Controle de versão
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    version: str = "1.0.0"
    
    def __post_init__(self):
        """Inicialização pós-criação"""
        self._setup_default_quality_rules()
        self._setup_default_custom_properties()
    
    def _setup_default_quality_rules(self):
        """Configura regras de qualidade padrão baseadas no tipo"""
        if self.constant_type == ConstantType.ENUM_VALUES and self.allowed_values:
            rule = QualityRule(
                rule="validValues",
                dimension=QualityDimension.CONFORMITY,
                severity=Severity.ERROR,
                description=f"Campo {self.name} deve ter um dos valores válidos",
                business_impact="operational",
                valid_values=self.allowed_values
            )
            if rule not in self.quality_rules:
                self.quality_rules.append(rule)
    
    def _setup_default_custom_properties(self):
        """Configura propriedades customizadas padrão"""
        default_props = {
            "constantType": self.constant_type.value,
            "changePolicy": self.change_policy.value,
            "changeApprovalRequired": self.change_approval_required,
            "changeNotificationRequired": self.change_notification_required,
            "approvalWorkflow": self.approval_workflow,
            "changeHistory": self.change_history_enabled
        }
        
        if self.default_value is not None:
            default_props["defaultValue"] = self.default_value
        if self.allowed_values:
            default_props["allowedValues"] = self.allowed_values
        if self.change_audit_table:
            default_props["changeAuditTable"] = self.change_audit_table
        if self.change_notification_topic:
            default_props["changeNotificationTopic"] = self.change_notification_topic
        if self.dependencies:
            default_props["dependencies"] = self.dependencies
        
        # Merge com propriedades existentes
        for key, value in default_props.items():
            if key not in self.custom_properties:
                self.custom_properties[key] = value
    
    def validate_value(self, value: Any) -> tuple[bool, List[str]]:
        """
        Valida um valor contra as regras de qualidade
        
        Returns:
            tuple: (is_valid, error_messages)
        """
        errors = []
        
        # Validação por tipo de campo constante
        if self.constant_type == ConstantType.ENUM_VALUES:
            if self.allowed_values and str(value) not in self.allowed_values:
                errors.append(f"Valor '{value}' não está na lista de valores permitidos: {self.allowed_values}")
        
        elif self.constant_type == ConstantType.FIXED_VALUE:
            if self.current_value is not None and value != self.current_value:
                errors.append(f"Campo de valor fixo não pode ser alterado. Valor atual: {self.current_value}")
        
        # Validação das regras de qualidade
        for rule in self.quality_rules:
            if rule.rule == "validValues" and rule.valid_values:
                if str(value) not in rule.valid_values:
                    errors.append(f"Regra {rule.rule}: valor '{value}' inválido")
            
            elif rule.rule == "minCheck" and rule.must_be_greater_than is not None:
                try:
                    if float(value) <= rule.must_be_greater_than:
                        errors.append(f"Regra {rule.rule}: valor deve ser maior que {rule.must_be_greater_than}")
                except (ValueError, TypeError):
                    errors.append(f"Regra {rule.rule}: valor não é numérico")
            
            elif rule.rule == "maxCheck" and rule.must_be_less_than is not None:
                try:
                    if float(value) >= rule.must_be_less_than:
                        errors.append(f"Regra {rule.rule}: valor deve ser menor que {rule.must_be_less_than}")
                except (ValueError, TypeError):
                    errors.append(f"Regra {rule.rule}: valor não é numérico")
        
        return len(errors) == 0, errors
    
    def can_change_value(self, new_value: Any, user_context: Dict[str, Any] = None) -> tuple[bool, str]:
        """
        Verifica se o valor pode ser alterado baseado na política de mudança
        
        Args:
            new_value: Novo valor proposto
            user_context: Contexto do usuário (permissões, etc.)
        
        Returns:
            tuple: (can_change, reason)
        """
        if self.change_policy == ChangePolicy.IMMUTABLE:
            return False, "Campo é imutável e não pode ser alterado"
        
        if self.change_policy == ChangePolicy.VERSION_UPGRADE_ONLY:
            return False, "Campo só pode ser alterado em nova versão do contrato"
        
        if self.change_policy == ChangePolicy.BUSINESS_APPROVAL_REQUIRED:
            if not user_context or not user_context.get("has_approval"):
                return False, "Alteração requer aprovação do comitê de governança"
        
        # Validar o novo valor
        is_valid, errors = self.validate_value(new_value)
        if not is_valid:
            return False, f"Valor inválido: {'; '.join(errors)}"
        
        return True, "Alteração permitida"
    
    def change_value(self, new_value: Any, user_context: Dict[str, Any] = None, 
                    change_description: str = "") -> bool:
        """
        Altera o valor do campo seguindo as políticas de mudança
        
        Args:
            new_value: Novo valor
            user_context: Contexto do usuário
            change_description: Descrição da mudança
        
        Returns:
            bool: True se alteração foi bem-sucedida
        """
        can_change, reason = self.can_change_value(new_value, user_context)
        if not can_change:
            raise ValueError(f"Não é possível alterar o valor: {reason}")
        
        # Registrar mudança no histórico
        if self.change_history_enabled:
            history_entry = ChangeHistoryEntry(
                version=self.version,
                change_date=datetime.now(),
                change_description=change_description or f"Valor alterado de '{self.current_value}' para '{new_value}'",
                approved_by=user_context.get("user_id", "system") if user_context else "system",
                old_value=self.current_value,
                new_value=new_value
            )
            self.change_history.append(history_entry)
        
        # Atualizar valor
        old_value = self.current_value
        self.current_value = new_value
        self.updated_at = datetime.now()
        
        return True
    
    def add_quality_rule(self, rule: QualityRule):
        """Adiciona uma regra de qualidade"""
        if rule not in self.quality_rules:
            self.quality_rules.append(rule)
            self.updated_at = datetime.now()
    
    def remove_quality_rule(self, rule_name: str):
        """Remove uma regra de qualidade pelo nome"""
        self.quality_rules = [r for r in self.quality_rules if r.rule != rule_name]
        self.updated_at = datetime.now()
    
    def to_odcs_property(self) -> Dict[str, Any]:
        """
        Converte para formato ODCS Property conforme especificação v3.0.2
        
        Returns:
            Dict: Propriedade no formato ODCS YAML
        """
        property_dict = {
            "name": self.name,
            "businessName": self.business_name,
            "logicalType": self.logical_type,
            "physicalType": self.physical_type,
            "description": self.description,
            "classification": self.classification,
            "tags": self.tags,
            "customProperties": [
                {"property": key, "value": value} 
                for key, value in self.custom_properties.items()
            ]
        }
        
        # Adicionar exemplos se existirem
        if self.examples:
            property_dict["examples"] = self.examples
        
        # Adicionar regras de qualidade
        if self.quality_rules:
            property_dict["quality"] = [rule.to_odcs_dict() for rule in self.quality_rules]
        
        # Adicionar lógica de transformação se existir
        if self.transform_logic:
            property_dict["transformLogic"] = self.transform_logic
        
        return property_dict
    
    def to_json(self) -> str:
        """Serializa para JSON"""
        data = {
            "name": self.name,
            "businessName": self.business_name,
            "logicalType": self.logical_type,
            "physicalType": self.physical_type,
            "description": self.description,
            "constantType": self.constant_type.value,
            "defaultValue": self.default_value,
            "allowedValues": self.allowed_values,
            "currentValue": self.current_value,
            "changePolicy": self.change_policy.value,
            "changeApprovalRequired": self.change_approval_required,
            "changeNotificationRequired": self.change_notification_required,
            "approvalWorkflow": self.approval_workflow,
            "qualityRules": [rule.to_odcs_dict() for rule in self.quality_rules],
            "changeHistoryEnabled": self.change_history_enabled,
            "changeAuditTable": self.change_audit_table,
            "changeNotificationTopic": self.change_notification_topic,
            "changeHistory": [entry.to_dict() for entry in self.change_history],
            "classification": self.classification,
            "tags": self.tags,
            "examples": self.examples,
            "customProperties": self.custom_properties,
            "transformLogic": self.transform_logic,
            "dependencies": self.dependencies,
            "createdAt": self.created_at.isoformat(),
            "updatedAt": self.updated_at.isoformat(),
            "version": self.version
        }
        return json.dumps(data, indent=2, ensure_ascii=False)
    
    @classmethod
    def from_odcs_property(cls, property_dict: Dict[str, Any]) -> 'ODCSConstantField':
        """
        Cria instância a partir de propriedade ODCS
        
        Args:
            property_dict: Dicionário no formato ODCS Property
        
        Returns:
            ODCSConstantField: Nova instância
        """
        # Extrair custom properties
        custom_props = {}
        if "customProperties" in property_dict:
            for prop in property_dict["customProperties"]:
                custom_props[prop["property"]] = prop["value"]
        
        # Determinar tipo de campo constante
        constant_type = ConstantType.DEFAULT_VALUE
        if "constantType" in custom_props:
            constant_type = ConstantType(custom_props["constantType"])
        
        # Determinar política de mudança
        change_policy = ChangePolicy.CONTROLLED_EVOLUTION
        if "changePolicy" in custom_props:
            change_policy = ChangePolicy(custom_props["changePolicy"])
        
        # Criar regras de qualidade
        quality_rules = []
        if "quality" in property_dict:
            for rule_dict in property_dict["quality"]:
                rule = QualityRule(
                    rule=rule_dict["rule"],
                    dimension=QualityDimension(rule_dict.get("dimension", "conformity")),
                    severity=Severity(rule_dict.get("severity", "error")),
                    description=rule_dict.get("description", ""),
                    business_impact=rule_dict.get("businessImpact", "operational"),
                    valid_values=rule_dict.get("validValues"),
                    must_be_less_than=rule_dict.get("mustBeLessThan"),
                    must_be_greater_than=rule_dict.get("mustBeGreaterThan"),
                    custom_query=rule_dict.get("query")
                )
                quality_rules.append(rule)
        
        return cls(
            name=property_dict["name"],
            business_name=property_dict.get("businessName", property_dict["name"]),
            logical_type=property_dict.get("logicalType", "string"),
            physical_type=property_dict.get("physicalType", "varchar"),
            description=property_dict.get("description", ""),
            constant_type=constant_type,
            default_value=custom_props.get("defaultValue"),
            allowed_values=custom_props.get("allowedValues"),
            change_policy=change_policy,
            change_approval_required=custom_props.get("changeApprovalRequired", True),
            change_notification_required=custom_props.get("changeNotificationRequired", True),
            approval_workflow=custom_props.get("approvalWorkflow", "data-governance-committee"),
            quality_rules=quality_rules,
            change_history_enabled=custom_props.get("changeHistory", True),
            change_audit_table=custom_props.get("changeAuditTable"),
            change_notification_topic=custom_props.get("changeNotificationTopic"),
            classification=property_dict.get("classification", "internal"),
            tags=property_dict.get("tags", []),
            examples=property_dict.get("examples", []),
            custom_properties=custom_props,
            transform_logic=property_dict.get("transformLogic"),
            dependencies=custom_props.get("dependencies", [])
        )


# Exemplo de uso
if __name__ == "__main__":
    # Criar campo de status com valores enumerados
    status_field = ODCSConstantField(
        name="contract_status",
        business_name="Status do Contrato",
        logical_type="string",
        physical_type="varchar(20)",
        description="Status atual do contrato de dados",
        constant_type=ConstantType.ENUM_VALUES,
        default_value="DRAFT",
        allowed_values=["DRAFT", "ACTIVE", "DEPRECATED", "RETIRED"],
        change_policy=ChangePolicy.CONTROLLED_EVOLUTION,
        tags=["governance", "status", "controlled"],
        examples=["DRAFT", "ACTIVE", "DEPRECATED"]
    )
    
    # Testar validação
    is_valid, errors = status_field.validate_value("ACTIVE")
    print(f"Validação 'ACTIVE': {is_valid}, Erros: {errors}")
    
    # Testar mudança de valor
    try:
        user_context = {"user_id": "admin", "has_approval": True}
        status_field.change_value("ACTIVE", user_context, "Ativando contrato")
        print(f"Valor alterado para: {status_field.current_value}")
    except ValueError as e:
        print(f"Erro ao alterar valor: {e}")
    
    # Converter para formato ODCS
    odcs_property = status_field.to_odcs_property()
    print("\nFormato ODCS:")
    print(json.dumps(odcs_property, indent=2, ensure_ascii=False))

