"""
Constant Field Validator Service - Serviço para validação de campos constantes
Integra com ContractLayoutService para validar valores fixos e constantes
Segue princípios SOLID - Single Responsibility Principle
"""
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import logging

from ..value_objects.constant_field import ConstantField, ConstantFieldType, ValidationLevel
from ..entities.contract import Contract


logger = logging.getLogger(__name__)


class ConstantFieldValidationResult:
    """Resultado da validação de campos constantes"""
    
    def __init__(self):
        self.is_valid = True
        self.errors = []
        self.warnings = []
        self.info_messages = []
        self.corrected_values = {}
        self.validation_summary = {}
        self.processed_fields = 0
        self.failed_fields = 0

    def add_error(self, field_name: str, message: str, code: str = None):
        """Adiciona erro de validação"""
        self.is_valid = False
        self.failed_fields += 1
        self.errors.append({
            "field": field_name,
            "message": message,
            "code": code,
            "level": "error",
            "timestamp": datetime.utcnow().isoformat()
        })

    def add_warning(self, field_name: str, message: str, code: str = None):
        """Adiciona aviso de validação"""
        self.warnings.append({
            "field": field_name,
            "message": message,
            "code": code,
            "level": "warning",
            "timestamp": datetime.utcnow().isoformat()
        })

    def add_info(self, field_name: str, message: str, code: str = None):
        """Adiciona informação de validação"""
        self.info_messages.append({
            "field": field_name,
            "message": message,
            "code": code,
            "level": "info",
            "timestamp": datetime.utcnow().isoformat()
        })

    def set_corrected_value(self, field_name: str, original_value: Any, corrected_value: Any):
        """Define valor corrigido para um campo"""
        self.corrected_values[field_name] = {
            "original": original_value,
            "corrected": corrected_value,
            "timestamp": datetime.utcnow().isoformat()
        }

    def to_dict(self) -> Dict[str, Any]:
        """Converte resultado para dicionário"""
        return {
            "is_valid": self.is_valid,
            "processed_fields": self.processed_fields,
            "failed_fields": self.failed_fields,
            "success_rate": (self.processed_fields - self.failed_fields) / max(1, self.processed_fields) * 100,
            "errors": self.errors,
            "warnings": self.warnings,
            "info_messages": self.info_messages,
            "corrected_values": self.corrected_values,
            "validation_summary": self.validation_summary,
            "validation_timestamp": datetime.utcnow().isoformat()
        }


class ConstantFieldValidatorService:
    """
    Serviço de validação de campos constantes
    Responsabilidades:
    - Validar campos com valores fixos
    - Aplicar valores padrão
    - Verificar enums e listas de valores permitidos
    - Calcular campos derivados
    - Gerar relatórios de validação
    """

    def __init__(self):
        """Inicializa o serviço"""
        self.logger = logger
        self._registered_constant_fields = {}
        self._validation_cache = {}

    def register_constant_field(self, constant_field: ConstantField) -> None:
        """
        Registra um campo constante para validação
        
        Args:
            constant_field: Definição do campo constante
        """
        self._registered_constant_fields[constant_field.field_name] = constant_field
        self.logger.info(f"Campo constante registrado: {constant_field.field_name}")

    def register_multiple_constant_fields(self, constant_fields: List[ConstantField]) -> None:
        """
        Registra múltiplos campos constantes
        
        Args:
            constant_fields: Lista de campos constantes
        """
        for field in constant_fields:
            self.register_constant_field(field)

    def unregister_constant_field(self, field_name: str) -> None:
        """
        Remove registro de campo constante
        
        Args:
            field_name: Nome do campo a ser removido
        """
        if field_name in self._registered_constant_fields:
            del self._registered_constant_fields[field_name]
            self.logger.info(f"Campo constante removido: {field_name}")

    def validate_contract_data(self, contract: Contract, data: Dict[str, Any]) -> ConstantFieldValidationResult:
        """
        Valida dados de um contrato contra campos constantes registrados
        
        Args:
            contract: Contrato sendo validado
            data: Dados a serem validados
            
        Returns:
            Resultado da validação
        """
        result = ConstantFieldValidationResult()
        
        try:
            self.logger.info(f"Iniciando validação de campos constantes para contrato: {contract.name}")
            
            # Obter campos constantes do schema do contrato
            contract_constant_fields = self._extract_constant_fields_from_schema(contract)
            
            # Combinar com campos registrados globalmente
            all_constant_fields = {**self._registered_constant_fields, **contract_constant_fields}
            
            if not all_constant_fields:
                self.logger.info("Nenhum campo constante definido para validação")
                return result
            
            # Validar cada campo constante
            for field_name, constant_field in all_constant_fields.items():
                result.processed_fields += 1
                field_value = data.get(field_name)
                
                # Validar campo
                field_result = constant_field.validate_value(field_value)
                
                # Processar resultado
                self._process_field_validation_result(
                    field_name, field_value, field_result, result
                )
            
            # Aplicar valores calculados
            self._apply_calculated_fields(data, all_constant_fields, result)
            
            # Gerar resumo
            result.validation_summary = self._generate_validation_summary(all_constant_fields, result)
            
            self.logger.info(f"Validação concluída. Sucesso: {result.is_valid}")
            
        except Exception as e:
            self.logger.error(f"Erro durante validação de campos constantes: {str(e)}")
            result.add_error("validation", f"Erro interno durante validação: {str(e)}", "INTERNAL_ERROR")
        
        return result

    def validate_schema_constant_fields(self, schema: Dict[str, Any]) -> ConstantFieldValidationResult:
        """
        Valida definições de campos constantes em um schema
        
        Args:
            schema: Schema a ser validado
            
        Returns:
            Resultado da validação
        """
        result = ConstantFieldValidationResult()
        
        try:
            fields = schema.get('fields', [])
            
            for field in fields:
                field_name = field.get('name')
                constraints = field.get('constraints', {})
                
                # Verificar se campo tem definições de constantes
                if self._has_constant_definitions(constraints):
                    result.processed_fields += 1
                    
                    # Validar definições de constantes
                    validation_result = self._validate_constant_definitions(field_name, constraints)
                    
                    if not validation_result['is_valid']:
                        for error in validation_result['errors']:
                            result.add_error(field_name, error, "INVALID_CONSTANT_DEFINITION")
                    
                    for warning in validation_result.get('warnings', []):
                        result.add_warning(field_name, warning, "CONSTANT_DEFINITION_WARNING")
            
        except Exception as e:
            self.logger.error(f"Erro durante validação de schema: {str(e)}")
            result.add_error("schema", f"Erro interno durante validação: {str(e)}", "INTERNAL_ERROR")
        
        return result

    def apply_constant_values(self, data: Dict[str, Any], 
                            constant_fields: Optional[List[ConstantField]] = None) -> Dict[str, Any]:
        """
        Aplica valores constantes aos dados
        
        Args:
            data: Dados originais
            constant_fields: Campos constantes específicos (opcional)
            
        Returns:
            Dados com valores constantes aplicados
        """
        result_data = data.copy()
        
        fields_to_process = constant_fields or list(self._registered_constant_fields.values())
        
        for constant_field in fields_to_process:
            field_name = constant_field.field_name
            current_value = result_data.get(field_name)
            
            # Aplicar valor baseado no tipo
            if constant_field.constant_type == ConstantFieldType.FIXED_VALUE:
                result_data[field_name] = constant_field.fixed_value
            
            elif constant_field.constant_type == ConstantFieldType.DEFAULT_VALUE:
                if current_value is None or current_value == "":
                    result_data[field_name] = constant_field.default_value
            
            elif constant_field.constant_type == ConstantFieldType.SYSTEM_GENERATED:
                # Remover valor fornecido pelo usuário
                if field_name in result_data:
                    del result_data[field_name]
        
        return result_data

    def get_constant_fields_for_contract(self, contract: Contract) -> List[ConstantField]:
        """
        Obtém todos os campos constantes aplicáveis a um contrato
        
        Args:
            contract: Contrato
            
        Returns:
            Lista de campos constantes
        """
        # Campos globais
        global_fields = list(self._registered_constant_fields.values())
        
        # Campos específicos do contrato
        contract_fields = list(self._extract_constant_fields_from_schema(contract).values())
        
        # Combinar evitando duplicatas
        all_fields = {}
        for field in global_fields + contract_fields:
            all_fields[field.field_name] = field
        
        return list(all_fields.values())

    def _extract_constant_fields_from_schema(self, contract: Contract) -> Dict[str, ConstantField]:
        """Extrai campos constantes do schema do contrato"""
        constant_fields = {}
        
        if not contract.schema_definition:
            return constant_fields
        
        fields = contract.schema_definition.get('fields', [])
        
        for field in fields:
            field_name = field.get('name')
            constraints = field.get('constraints', {})
            
            # Verificar se tem definições de constantes
            if self._has_constant_definitions(constraints):
                try:
                    constant_field = self._create_constant_field_from_constraints(field_name, constraints)
                    constant_fields[field_name] = constant_field
                except Exception as e:
                    self.logger.warning(f"Erro ao criar campo constante {field_name}: {str(e)}")
        
        return constant_fields

    def _has_constant_definitions(self, constraints: Dict[str, Any]) -> bool:
        """Verifica se constraints contém definições de constantes"""
        constant_keys = [
            'fixed_value', 'default_value', 'allowed_values', 
            'enum_values', 'constant_value', 'calculated_formula'
        ]
        return any(key in constraints for key in constant_keys)

    def _create_constant_field_from_constraints(self, field_name: str, 
                                              constraints: Dict[str, Any]) -> ConstantField:
        """Cria ConstantField a partir de constraints"""
        
        # Determinar tipo de campo constante
        if 'fixed_value' in constraints or 'constant_value' in constraints:
            return ConstantField(
                field_name=field_name,
                constant_type=ConstantFieldType.FIXED_VALUE,
                fixed_value=constraints.get('fixed_value') or constraints.get('constant_value'),
                validation_level=ValidationLevel.STRICT
            )
        
        elif 'default_value' in constraints:
            return ConstantField(
                field_name=field_name,
                constant_type=ConstantFieldType.DEFAULT_VALUE,
                default_value=constraints.get('default_value'),
                validation_level=ValidationLevel.WARNING
            )
        
        elif 'allowed_values' in constraints or 'enum_values' in constraints:
            return ConstantField(
                field_name=field_name,
                constant_type=ConstantFieldType.ENUM_VALUES,
                allowed_values=constraints.get('allowed_values') or constraints.get('enum_values'),
                validation_level=ValidationLevel.STRICT
            )
        
        elif 'calculated_formula' in constraints:
            return ConstantField(
                field_name=field_name,
                constant_type=ConstantFieldType.CALCULATED,
                calculation_formula=constraints.get('calculated_formula'),
                validation_level=ValidationLevel.INFO
            )
        
        else:
            # Fallback para campo com valor padrão
            return ConstantField(
                field_name=field_name,
                constant_type=ConstantFieldType.DEFAULT_VALUE,
                default_value=None,
                validation_level=ValidationLevel.INFO
            )

    def _validate_constant_definitions(self, field_name: str, 
                                     constraints: Dict[str, Any]) -> Dict[str, Any]:
        """Valida definições de constantes em constraints"""
        result = {"is_valid": True, "errors": [], "warnings": []}
        
        # Verificar conflitos
        constant_keys = ['fixed_value', 'default_value', 'allowed_values', 'constant_value']
        defined_keys = [key for key in constant_keys if key in constraints]
        
        if len(defined_keys) > 1:
            result["is_valid"] = False
            result["errors"].append(
                f"Campo '{field_name}' tem múltiplas definições de constantes: {defined_keys}"
            )
        
        # Validar valores específicos
        if 'allowed_values' in constraints:
            allowed = constraints['allowed_values']
            if not isinstance(allowed, list) or len(allowed) == 0:
                result["is_valid"] = False
                result["errors"].append(
                    f"Campo '{field_name}': allowed_values deve ser uma lista não vazia"
                )
        
        return result

    def _process_field_validation_result(self, field_name: str, field_value: Any,
                                       field_result: Dict[str, Any], 
                                       result: ConstantFieldValidationResult):
        """Processa resultado da validação de um campo"""
        
        # Processar erros
        for error in field_result.get('errors', []):
            result.add_error(field_name, error, "CONSTANT_FIELD_VALIDATION")
        
        # Processar avisos
        for warning in field_result.get('warnings', []):
            result.add_warning(field_name, warning, "CONSTANT_FIELD_WARNING")
        
        # Processar valor corrigido
        corrected_value = field_result.get('corrected_value')
        if corrected_value != field_value:
            result.set_corrected_value(field_name, field_value, corrected_value)

    def _apply_calculated_fields(self, data: Dict[str, Any], 
                               constant_fields: Dict[str, ConstantField],
                               result: ConstantFieldValidationResult):
        """Aplica valores para campos calculados"""
        
        calculated_fields = [
            field for field in constant_fields.values()
            if field.constant_type == ConstantFieldType.CALCULATED
        ]
        
        for field in calculated_fields:
            try:
                # Aqui seria implementada a lógica de cálculo real
                # Por simplicidade, apenas registramos que o campo é calculado
                result.add_info(
                    field.field_name,
                    f"Campo calculado usando fórmula: {field.calculation_formula}",
                    "CALCULATED_FIELD"
                )
            except Exception as e:
                result.add_error(
                    field.field_name,
                    f"Erro ao calcular campo: {str(e)}",
                    "CALCULATION_ERROR"
                )

    def _generate_validation_summary(self, constant_fields: Dict[str, ConstantField],
                                   result: ConstantFieldValidationResult) -> Dict[str, Any]:
        """Gera resumo da validação"""
        
        summary = {
            "total_constant_fields": len(constant_fields),
            "fields_by_type": {},
            "validation_levels": {},
            "success_rate": (result.processed_fields - result.failed_fields) / max(1, result.processed_fields) * 100
        }
        
        # Contar por tipo
        for field in constant_fields.values():
            field_type = field.constant_type.value
            summary["fields_by_type"][field_type] = summary["fields_by_type"].get(field_type, 0) + 1
            
            validation_level = field.validation_level.value
            summary["validation_levels"][validation_level] = summary["validation_levels"].get(validation_level, 0) + 1
        
        return summary

    def clear_cache(self):
        """Limpa cache de validação"""
        self._validation_cache.clear()

    def get_registered_fields(self) -> List[ConstantField]:
        """Retorna lista de campos constantes registrados"""
        return list(self._registered_constant_fields.values())

    def get_field_by_name(self, field_name: str) -> Optional[ConstantField]:
        """Retorna campo constante por nome"""
        return self._registered_constant_fields.get(field_name)

