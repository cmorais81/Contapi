"""
Constant Field Value Object - Objeto de valor para campos com valores constantes
Baseado no conceito de campos fixos do ODCS
Segue princípios SOLID - Single Responsibility Principle
"""
from dataclasses import dataclass
from typing import Any, Optional, List, Dict, Union
from enum import Enum


class ConstantFieldType(Enum):
    """Tipos de campos constantes"""
    FIXED_VALUE = "fixed_value"  # Valor fixo obrigatório
    DEFAULT_VALUE = "default_value"  # Valor padrão se não informado
    ENUM_VALUES = "enum_values"  # Lista de valores permitidos
    CALCULATED = "calculated"  # Valor calculado baseado em outros campos
    SYSTEM_GENERATED = "system_generated"  # Gerado pelo sistema


class ValidationLevel(Enum):
    """Níveis de validação para campos constantes"""
    STRICT = "strict"  # Validação rígida - falha se não atender
    WARNING = "warning"  # Gera aviso mas permite
    INFO = "info"  # Apenas informativo


@dataclass(frozen=True)
class ConstantField:
    """
    Value Object para campos com valores constantes
    Responsabilidade única: representar regras de valores fixos/constantes
    """
    field_name: str
    constant_type: ConstantFieldType
    validation_level: ValidationLevel = ValidationLevel.STRICT
    
    # Valores possíveis
    fixed_value: Optional[Any] = None
    default_value: Optional[Any] = None
    allowed_values: Optional[List[Any]] = None
    
    # Configurações de validação
    is_required: bool = True
    allow_null: bool = False
    case_sensitive: bool = True
    
    # Metadados
    description: Optional[str] = None
    business_rule: Optional[str] = None
    error_message: Optional[str] = None
    
    # Configurações para campos calculados
    calculation_formula: Optional[str] = None
    dependent_fields: Optional[List[str]] = None
    
    def __post_init__(self):
        """Validações pós-inicialização"""
        if not self.field_name or not self.field_name.strip():
            raise ValueError("Nome do campo é obrigatório")
        
        # Validações específicas por tipo
        if self.constant_type == ConstantFieldType.FIXED_VALUE:
            if self.fixed_value is None and not self.allow_null:
                raise ValueError("Valor fixo é obrigatório para tipo FIXED_VALUE")
        
        elif self.constant_type == ConstantFieldType.DEFAULT_VALUE:
            if self.default_value is None and not self.allow_null:
                raise ValueError("Valor padrão é obrigatório para tipo DEFAULT_VALUE")
        
        elif self.constant_type == ConstantFieldType.ENUM_VALUES:
            if not self.allowed_values or len(self.allowed_values) == 0:
                raise ValueError("Lista de valores permitidos é obrigatória para tipo ENUM_VALUES")
        
        elif self.constant_type == ConstantFieldType.CALCULATED:
            if not self.calculation_formula:
                raise ValueError("Fórmula de cálculo é obrigatória para tipo CALCULATED")
        
        # Validar dependências para campos calculados
        if self.dependent_fields and self.constant_type != ConstantFieldType.CALCULATED:
            raise ValueError("Campos dependentes só são válidos para tipo CALCULATED")

    def validate_value(self, value: Any) -> Dict[str, Any]:
        """
        Valida um valor contra as regras do campo constante
        
        Args:
            value: Valor a ser validado
            
        Returns:
            Dict com resultado da validação
        """
        result = {
            "is_valid": True,
            "errors": [],
            "warnings": [],
            "corrected_value": value,
            "validation_level": self.validation_level.value
        }
        
        # Verificar null
        if value is None:
            if not self.allow_null:
                result["is_valid"] = False
                result["errors"].append(f"Campo '{self.field_name}' não permite valor nulo")
            return result
        
        # Validação por tipo
        if self.constant_type == ConstantFieldType.FIXED_VALUE:
            result.update(self._validate_fixed_value(value))
        
        elif self.constant_type == ConstantFieldType.DEFAULT_VALUE:
            result.update(self._validate_default_value(value))
        
        elif self.constant_type == ConstantFieldType.ENUM_VALUES:
            result.update(self._validate_enum_values(value))
        
        elif self.constant_type == ConstantFieldType.CALCULATED:
            result.update(self._validate_calculated_value(value))
        
        elif self.constant_type == ConstantFieldType.SYSTEM_GENERATED:
            result.update(self._validate_system_generated(value))
        
        return result

    def _validate_fixed_value(self, value: Any) -> Dict[str, Any]:
        """Valida valor fixo"""
        result = {"errors": [], "warnings": []}
        
        expected = self.fixed_value
        actual = value
        
        # Comparação considerando case sensitivity
        if isinstance(expected, str) and isinstance(actual, str) and not self.case_sensitive:
            expected = expected.lower()
            actual = actual.lower()
        
        if actual != expected:
            error_msg = (self.error_message or 
                        f"Campo '{self.field_name}' deve ter valor fixo '{self.fixed_value}', "
                        f"mas recebeu '{value}'")
            
            if self.validation_level == ValidationLevel.STRICT:
                result["errors"].append(error_msg)
            elif self.validation_level == ValidationLevel.WARNING:
                result["warnings"].append(error_msg)
            
            # Sugerir correção
            result["corrected_value"] = self.fixed_value
        
        return result

    def _validate_default_value(self, value: Any) -> Dict[str, Any]:
        """Valida valor padrão"""
        result = {"errors": [], "warnings": []}
        
        # Para campos com valor padrão, se não informado, usar o padrão
        if value is None or value == "":
            result["corrected_value"] = self.default_value
            if self.validation_level == ValidationLevel.INFO:
                result["warnings"].append(
                    f"Campo '{self.field_name}' usando valor padrão '{self.default_value}'"
                )
        
        return result

    def _validate_enum_values(self, value: Any) -> Dict[str, Any]:
        """Valida valores de enum"""
        result = {"errors": [], "warnings": []}
        
        allowed = self.allowed_values
        actual = value
        
        # Comparação considerando case sensitivity
        if not self.case_sensitive and isinstance(actual, str):
            allowed = [str(v).lower() for v in allowed]
            actual = str(actual).lower()
        
        if actual not in allowed:
            error_msg = (self.error_message or 
                        f"Campo '{self.field_name}' deve ter um dos valores: {self.allowed_values}, "
                        f"mas recebeu '{value}'")
            
            if self.validation_level == ValidationLevel.STRICT:
                result["errors"].append(error_msg)
            elif self.validation_level == ValidationLevel.WARNING:
                result["warnings"].append(error_msg)
            
            # Sugerir primeiro valor válido como correção
            if self.allowed_values:
                result["corrected_value"] = self.allowed_values[0]
        
        return result

    def _validate_calculated_value(self, value: Any) -> Dict[str, Any]:
        """Valida valor calculado"""
        result = {"errors": [], "warnings": []}
        
        # Para campos calculados, o valor deve ser gerado pelo sistema
        # Esta validação seria mais complexa e dependeria do contexto
        if self.validation_level == ValidationLevel.INFO:
            result["warnings"].append(
                f"Campo '{self.field_name}' é calculado usando: {self.calculation_formula}"
            )
        
        return result

    def _validate_system_generated(self, value: Any) -> Dict[str, Any]:
        """Valida valor gerado pelo sistema"""
        result = {"errors": [], "warnings": []}
        
        # Campos gerados pelo sistema não devem ser fornecidos pelo usuário
        if value is not None:
            error_msg = (self.error_message or 
                        f"Campo '{self.field_name}' é gerado pelo sistema e não deve ser informado")
            
            if self.validation_level == ValidationLevel.STRICT:
                result["errors"].append(error_msg)
            elif self.validation_level == ValidationLevel.WARNING:
                result["warnings"].append(error_msg)
            
            result["corrected_value"] = None
        
        return result

    def get_expected_value(self, context: Optional[Dict[str, Any]] = None) -> Any:
        """
        Retorna o valor esperado para o campo baseado no tipo
        
        Args:
            context: Contexto com outros campos para cálculos
            
        Returns:
            Valor esperado
        """
        if self.constant_type == ConstantFieldType.FIXED_VALUE:
            return self.fixed_value
        
        elif self.constant_type == ConstantFieldType.DEFAULT_VALUE:
            return self.default_value
        
        elif self.constant_type == ConstantFieldType.ENUM_VALUES:
            return self.allowed_values[0] if self.allowed_values else None
        
        elif self.constant_type == ConstantFieldType.CALCULATED:
            # Aqui seria implementada a lógica de cálculo
            # Por simplicidade, retornamos None
            return None
        
        elif self.constant_type == ConstantFieldType.SYSTEM_GENERATED:
            # Valores gerados pelo sistema não têm valor esperado fixo
            return None
        
        return None

    def is_strict_validation(self) -> bool:
        """Verifica se usa validação rígida"""
        return self.validation_level == ValidationLevel.STRICT

    def requires_calculation(self) -> bool:
        """Verifica se campo requer cálculo"""
        return self.constant_type == ConstantFieldType.CALCULATED

    def is_user_editable(self) -> bool:
        """Verifica se campo pode ser editado pelo usuário"""
        return self.constant_type not in [
            ConstantFieldType.FIXED_VALUE,
            ConstantFieldType.SYSTEM_GENERATED
        ]

    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            'field_name': self.field_name,
            'constant_type': self.constant_type.value,
            'validation_level': self.validation_level.value,
            'fixed_value': self.fixed_value,
            'default_value': self.default_value,
            'allowed_values': self.allowed_values.copy() if self.allowed_values else None,
            'is_required': self.is_required,
            'allow_null': self.allow_null,
            'case_sensitive': self.case_sensitive,
            'description': self.description,
            'business_rule': self.business_rule,
            'error_message': self.error_message,
            'calculation_formula': self.calculation_formula,
            'dependent_fields': self.dependent_fields.copy() if self.dependent_fields else None
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ConstantField':
        """Cria instância a partir de dicionário"""
        # Converter enums
        if 'constant_type' in data:
            data['constant_type'] = ConstantFieldType(data['constant_type'])
        if 'validation_level' in data:
            data['validation_level'] = ValidationLevel(data['validation_level'])
        
        return cls(**data)

    @classmethod
    def create_fixed_value(cls, field_name: str, value: Any, 
                          description: str = None) -> 'ConstantField':
        """Cria campo com valor fixo"""
        return cls(
            field_name=field_name,
            constant_type=ConstantFieldType.FIXED_VALUE,
            fixed_value=value,
            description=description
        )

    @classmethod
    def create_default_value(cls, field_name: str, default: Any,
                           description: str = None) -> 'ConstantField':
        """Cria campo com valor padrão"""
        return cls(
            field_name=field_name,
            constant_type=ConstantFieldType.DEFAULT_VALUE,
            default_value=default,
            is_required=False,
            description=description
        )

    @classmethod
    def create_enum_field(cls, field_name: str, allowed_values: List[Any],
                         description: str = None) -> 'ConstantField':
        """Cria campo com valores permitidos"""
        return cls(
            field_name=field_name,
            constant_type=ConstantFieldType.ENUM_VALUES,
            allowed_values=allowed_values,
            description=description
        )

    def __str__(self) -> str:
        return f"ConstantField({self.field_name}, {self.constant_type.value})"

    def __repr__(self) -> str:
        return (f"ConstantField(field_name='{self.field_name}', "
                f"type={self.constant_type}, level={self.validation_level})")

