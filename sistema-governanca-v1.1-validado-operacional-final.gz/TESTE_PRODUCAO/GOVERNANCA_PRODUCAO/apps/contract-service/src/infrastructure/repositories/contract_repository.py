"""
Repositório para contratos de dados
"""

from typing import List, Optional
from sqlalchemy.orm import Session
from src.domain.models.contract import DataContract, ContractVersion
from config.database import get_database
import uuid

class ContractRepository:
    """Repositório para operações de contratos"""
    
    def __init__(self, db: Session):
        self.db = db
    
    def create_contract(self, contract_data: dict) -> DataContract:
        """Criar novo contrato"""
        contract = DataContract(**contract_data)
        self.db.add(contract)
        self.db.commit()
        self.db.refresh(contract)
        return contract
    
    def get_contract(self, contract_id: str) -> Optional[DataContract]:
        """Obter contrato por ID"""
        return self.db.query(DataContract).filter(
            DataContract.id == uuid.UUID(contract_id)
        ).first()
    
    def get_contracts(self, skip: int = 0, limit: int = 100) -> List[DataContract]:
        """Listar contratos"""
        return self.db.query(DataContract).offset(skip).limit(limit).all()
    
    def update_contract(self, contract_id: str, contract_data: dict) -> Optional[DataContract]:
        """Atualizar contrato"""
        contract = self.get_contract(contract_id)
        if contract:
            for key, value in contract_data.items():
                setattr(contract, key, value)
            self.db.commit()
            self.db.refresh(contract)
        return contract
    
    def delete_contract(self, contract_id: str) -> bool:
        """Deletar contrato"""
        contract = self.get_contract(contract_id)
        if contract:
            self.db.delete(contract)
            self.db.commit()
            return True
        return False
    
    def get_contracts_by_status(self, status: str) -> List[DataContract]:
        """Obter contratos por status"""
        return self.db.query(DataContract).filter(
            DataContract.status == status
        ).all()
