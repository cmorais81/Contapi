"""
ODCS Constant Field Repository
Repositório para persistir campos constantes conforme ODCS v3.0.2
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
import json
import uuid
from sqlalchemy import Column, String, Text, DateTime, Boolean, JSON, Integer
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy import create_engine

from ..entities.odcs_constant_field import ODCSConstantField, ConstantType, ChangePolicy

Base = declarative_base()


class ODCSConstantFieldModel(Base):
    """Modelo SQLAlchemy para campos constantes ODCS"""
    
    __tablename__ = 'odcs_constant_fields'
    
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(255), unique=True, nullable=False, index=True)
    business_name = Column(String(255), nullable=False)
    logical_type = Column(String(50), nullable=False)
    physical_type = Column(String(100), nullable=False)
    description = Column(Text)
    
    # Tipo e configuração do campo constante
    constant_type = Column(String(50), nullable=False)
    default_value = Column(Text)
    allowed_values = Column(JSON)
    current_value = Column(Text)
    
    # Política de mudança
    change_policy = Column(String(50), nullable=False)
    change_approval_required = Column(Boolean, default=True)
    change_notification_required = Column(Boolean, default=True)
    approval_workflow = Column(String(255), default='data-governance-committee')
    
    # Regras de qualidade (JSON)
    quality_rules = Column(JSON)
    
    # Rastreabilidade
    change_history_enabled = Column(Boolean, default=True)
    change_audit_table = Column(String(255))
    change_notification_topic = Column(String(255))
    change_history = Column(JSON)
    
    # Metadados ODCS
    classification = Column(String(50), default='internal')
    tags = Column(JSON)
    examples = Column(JSON)
    custom_properties = Column(JSON)
    
    # Campos calculados
    transform_logic = Column(Text)
    dependencies = Column(JSON)
    
    # Controle de versão
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    version = Column(String(20), default='1.0.0')
    
    # Metadados do contrato
    contract_id = Column(String(36), index=True)
    object_name = Column(String(255), index=True)
    
    def to_entity(self) -> ODCSConstantField:
        """Converte modelo para entidade de domínio"""
        from ..entities.odcs_constant_field import QualityRule, QualityDimension, Severity, ChangeHistoryEntry
        
        # Converter regras de qualidade
        quality_rules = []
        if self.quality_rules:
            for rule_data in self.quality_rules:
                rule = QualityRule(
                    rule=rule_data['rule'],
                    dimension=QualityDimension(rule_data.get('dimension', 'conformity')),
                    severity=Severity(rule_data.get('severity', 'error')),
                    description=rule_data.get('description', ''),
                    business_impact=rule_data.get('business_impact', 'operational'),
                    valid_values=rule_data.get('valid_values'),
                    must_be_less_than=rule_data.get('must_be_less_than'),
                    must_be_greater_than=rule_data.get('must_be_greater_than'),
                    custom_query=rule_data.get('custom_query')
                )
                quality_rules.append(rule)
        
        # Converter histórico de mudanças
        change_history = []
        if self.change_history:
            for history_data in self.change_history:
                entry = ChangeHistoryEntry(
                    version=history_data['version'],
                    change_date=datetime.fromisoformat(history_data['change_date']),
                    change_description=history_data['change_description'],
                    approved_by=history_data['approved_by'],
                    old_value=history_data.get('old_value'),
                    new_value=history_data.get('new_value')
                )
                change_history.append(entry)
        
        return ODCSConstantField(
            name=self.name,
            business_name=self.business_name,
            logical_type=self.logical_type,
            physical_type=self.physical_type,
            description=self.description or '',
            constant_type=ConstantType(self.constant_type),
            default_value=self.default_value,
            allowed_values=self.allowed_values,
            current_value=self.current_value,
            change_policy=ChangePolicy(self.change_policy),
            change_approval_required=self.change_approval_required,
            change_notification_required=self.change_notification_required,
            approval_workflow=self.approval_workflow,
            quality_rules=quality_rules,
            change_history_enabled=self.change_history_enabled,
            change_audit_table=self.change_audit_table,
            change_notification_topic=self.change_notification_topic,
            change_history=change_history,
            classification=self.classification,
            tags=self.tags or [],
            examples=self.examples or [],
            custom_properties=self.custom_properties or {},
            transform_logic=self.transform_logic,
            dependencies=self.dependencies or [],
            created_at=self.created_at,
            updated_at=self.updated_at,
            version=self.version
        )
    
    @classmethod
    def from_entity(cls, entity: ODCSConstantField, contract_id: str = None, 
                   object_name: str = None) -> 'ODCSConstantFieldModel':
        """Cria modelo a partir de entidade de domínio"""
        
        # Converter regras de qualidade para JSON
        quality_rules_json = []
        for rule in entity.quality_rules:
            rule_dict = {
                'rule': rule.rule,
                'dimension': rule.dimension.value,
                'severity': rule.severity.value,
                'description': rule.description,
                'business_impact': rule.business_impact
            }
            if rule.valid_values:
                rule_dict['valid_values'] = rule.valid_values
            if rule.must_be_less_than is not None:
                rule_dict['must_be_less_than'] = rule.must_be_less_than
            if rule.must_be_greater_than is not None:
                rule_dict['must_be_greater_than'] = rule.must_be_greater_than
            if rule.custom_query:
                rule_dict['custom_query'] = rule.custom_query
            quality_rules_json.append(rule_dict)
        
        # Converter histórico de mudanças para JSON
        change_history_json = []
        for entry in entity.change_history:
            change_history_json.append({
                'version': entry.version,
                'change_date': entry.change_date.isoformat(),
                'change_description': entry.change_description,
                'approved_by': entry.approved_by,
                'old_value': entry.old_value,
                'new_value': entry.new_value
            })
        
        return cls(
            name=entity.name,
            business_name=entity.business_name,
            logical_type=entity.logical_type,
            physical_type=entity.physical_type,
            description=entity.description,
            constant_type=entity.constant_type.value,
            default_value=entity.default_value,
            allowed_values=entity.allowed_values,
            current_value=entity.current_value,
            change_policy=entity.change_policy.value,
            change_approval_required=entity.change_approval_required,
            change_notification_required=entity.change_notification_required,
            approval_workflow=entity.approval_workflow,
            quality_rules=quality_rules_json,
            change_history_enabled=entity.change_history_enabled,
            change_audit_table=entity.change_audit_table,
            change_notification_topic=entity.change_notification_topic,
            change_history=change_history_json,
            classification=entity.classification,
            tags=entity.tags,
            examples=entity.examples,
            custom_properties=entity.custom_properties,
            transform_logic=entity.transform_logic,
            dependencies=entity.dependencies,
            created_at=entity.created_at,
            updated_at=entity.updated_at,
            version=entity.version,
            contract_id=contract_id,
            object_name=object_name
        )


class ODCSConstantFieldRepository:
    """
    Repositório para campos constantes ODCS
    
    Responsabilidades:
    - Persistir e recuperar campos constantes
    - Gerenciar relacionamentos com contratos
    - Consultas e filtros avançados
    - Auditoria e histórico
    """
    
    def __init__(self, session: Session):
        self.session = session
    
    def save(self, field: ODCSConstantField, contract_id: str = None, 
            object_name: str = None) -> ODCSConstantField:
        """
        Salva um campo constante
        
        Args:
            field: Campo a salvar
            contract_id: ID do contrato associado
            object_name: Nome do objeto associado
        
        Returns:
            ODCSConstantField: Campo salvo
        """
        # Verificar se já existe
        existing = self.session.query(ODCSConstantFieldModel).filter_by(name=field.name).first()
        
        if existing:
            # Atualizar existente
            model = existing
            # Atualizar campos
            model.business_name = field.business_name
            model.logical_type = field.logical_type
            model.physical_type = field.physical_type
            model.description = field.description
            model.constant_type = field.constant_type.value
            model.default_value = field.default_value
            model.allowed_values = field.allowed_values
            model.current_value = field.current_value
            model.change_policy = field.change_policy.value
            model.change_approval_required = field.change_approval_required
            model.change_notification_required = field.change_notification_required
            model.approval_workflow = field.approval_workflow
            model.change_history_enabled = field.change_history_enabled
            model.change_audit_table = field.change_audit_table
            model.change_notification_topic = field.change_notification_topic
            model.classification = field.classification
            model.tags = field.tags
            model.examples = field.examples
            model.custom_properties = field.custom_properties
            model.transform_logic = field.transform_logic
            model.dependencies = field.dependencies
            model.updated_at = datetime.utcnow()
            model.version = field.version
            
            if contract_id:
                model.contract_id = contract_id
            if object_name:
                model.object_name = object_name
            
            # Atualizar regras de qualidade
            quality_rules_json = []
            for rule in field.quality_rules:
                rule_dict = {
                    'rule': rule.rule,
                    'dimension': rule.dimension.value,
                    'severity': rule.severity.value,
                    'description': rule.description,
                    'business_impact': rule.business_impact
                }
                if rule.valid_values:
                    rule_dict['valid_values'] = rule.valid_values
                if rule.must_be_less_than is not None:
                    rule_dict['must_be_less_than'] = rule.must_be_less_than
                if rule.must_be_greater_than is not None:
                    rule_dict['must_be_greater_than'] = rule.must_be_greater_than
                if rule.custom_query:
                    rule_dict['custom_query'] = rule.custom_query
                quality_rules_json.append(rule_dict)
            model.quality_rules = quality_rules_json
            
            # Atualizar histórico de mudanças
            change_history_json = []
            for entry in field.change_history:
                change_history_json.append({
                    'version': entry.version,
                    'change_date': entry.change_date.isoformat(),
                    'change_description': entry.change_description,
                    'approved_by': entry.approved_by,
                    'old_value': entry.old_value,
                    'new_value': entry.new_value
                })
            model.change_history = change_history_json
            
        else:
            # Criar novo
            model = ODCSConstantFieldModel.from_entity(field, contract_id, object_name)
            self.session.add(model)
        
        self.session.commit()
        self.session.refresh(model)
        
        return model.to_entity()
    
    def find_by_name(self, name: str) -> Optional[ODCSConstantField]:
        """Busca campo por nome"""
        model = self.session.query(ODCSConstantFieldModel).filter_by(name=name).first()
        return model.to_entity() if model else None
    
    def find_by_id(self, field_id: str) -> Optional[ODCSConstantField]:
        """Busca campo por ID"""
        model = self.session.query(ODCSConstantFieldModel).filter_by(id=field_id).first()
        return model.to_entity() if model else None
    
    def find_by_contract(self, contract_id: str) -> List[ODCSConstantField]:
        """Busca campos por contrato"""
        models = self.session.query(ODCSConstantFieldModel).filter_by(contract_id=contract_id).all()
        return [model.to_entity() for model in models]
    
    def find_by_object(self, object_name: str) -> List[ODCSConstantField]:
        """Busca campos por objeto"""
        models = self.session.query(ODCSConstantFieldModel).filter_by(object_name=object_name).all()
        return [model.to_entity() for model in models]
    
    def find_all(self, filters: Dict[str, Any] = None) -> List[ODCSConstantField]:
        """
        Busca todos os campos com filtros opcionais
        
        Args:
            filters: Filtros a aplicar
        
        Returns:
            List[ODCSConstantField]: Lista de campos
        """
        query = self.session.query(ODCSConstantFieldModel)
        
        if filters:
            if 'constant_type' in filters:
                query = query.filter(ODCSConstantFieldModel.constant_type == filters['constant_type'])
            
            if 'change_policy' in filters:
                query = query.filter(ODCSConstantFieldModel.change_policy == filters['change_policy'])
            
            if 'classification' in filters:
                query = query.filter(ODCSConstantFieldModel.classification == filters['classification'])
            
            if 'contract_id' in filters:
                query = query.filter(ODCSConstantFieldModel.contract_id == filters['contract_id'])
            
            if 'object_name' in filters:
                query = query.filter(ODCSConstantFieldModel.object_name == filters['object_name'])
            
            if 'tags' in filters:
                # Buscar campos que contenham todas as tags especificadas
                for tag in filters['tags']:
                    query = query.filter(ODCSConstantFieldModel.tags.contains([tag]))
        
        models = query.all()
        return [model.to_entity() for model in models]
    
    def delete(self, name: str) -> bool:
        """
        Remove um campo por nome
        
        Args:
            name: Nome do campo
        
        Returns:
            bool: True se removido com sucesso
        """
        model = self.session.query(ODCSConstantFieldModel).filter_by(name=name).first()
        if model:
            self.session.delete(model)
            self.session.commit()
            return True
        return False
    
    def count_by_type(self) -> Dict[str, int]:
        """Conta campos por tipo"""
        from sqlalchemy import func
        
        result = self.session.query(
            ODCSConstantFieldModel.constant_type,
            func.count(ODCSConstantFieldModel.id)
        ).group_by(ODCSConstantFieldModel.constant_type).all()
        
        return {constant_type: count for constant_type, count in result}
    
    def count_by_policy(self) -> Dict[str, int]:
        """Conta campos por política de mudança"""
        from sqlalchemy import func
        
        result = self.session.query(
            ODCSConstantFieldModel.change_policy,
            func.count(ODCSConstantFieldModel.id)
        ).group_by(ODCSConstantFieldModel.change_policy).all()
        
        return {policy: count for policy, count in result}
    
    def find_fields_with_changes(self, since: datetime = None) -> List[ODCSConstantField]:
        """
        Busca campos que tiveram mudanças
        
        Args:
            since: Data a partir da qual buscar mudanças
        
        Returns:
            List[ODCSConstantField]: Campos com mudanças
        """
        query = self.session.query(ODCSConstantFieldModel).filter(
            ODCSConstantFieldModel.change_history.isnot(None)
        )
        
        if since:
            query = query.filter(ODCSConstantFieldModel.updated_at >= since)
        
        models = query.all()
        
        # Filtrar apenas campos que realmente têm histórico
        fields_with_changes = []
        for model in models:
            entity = model.to_entity()
            if entity.change_history:
                fields_with_changes.append(entity)
        
        return fields_with_changes
    
    def get_statistics(self) -> Dict[str, Any]:
        """Obtém estatísticas dos campos"""
        from sqlalchemy import func
        
        total = self.session.query(func.count(ODCSConstantFieldModel.id)).scalar()
        
        # Contar por tipo
        type_counts = self.count_by_type()
        
        # Contar por política
        policy_counts = self.count_by_policy()
        
        # Contar campos com histórico
        with_history = self.session.query(func.count(ODCSConstantFieldModel.id)).filter(
            ODCSConstantFieldModel.change_history.isnot(None)
        ).scalar()
        
        # Contar campos com regras de qualidade
        with_quality_rules = self.session.query(func.count(ODCSConstantFieldModel.id)).filter(
            ODCSConstantFieldModel.quality_rules.isnot(None)
        ).scalar()
        
        return {
            'total_fields': total,
            'by_constant_type': type_counts,
            'by_change_policy': policy_counts,
            'fields_with_change_history': with_history,
            'fields_with_quality_rules': with_quality_rules
        }
    
    def bulk_update_contract_association(self, field_names: List[str], 
                                       contract_id: str, object_name: str = None):
        """
        Atualiza associação de contrato em lote
        
        Args:
            field_names: Lista de nomes de campos
            contract_id: ID do contrato
            object_name: Nome do objeto (opcional)
        """
        query = self.session.query(ODCSConstantFieldModel).filter(
            ODCSConstantFieldModel.name.in_(field_names)
        )
        
        update_data = {'contract_id': contract_id, 'updated_at': datetime.utcnow()}
        if object_name:
            update_data['object_name'] = object_name
        
        query.update(update_data, synchronize_session=False)
        self.session.commit()


# Factory para criar repositório
class ODCSConstantFieldRepositoryFactory:
    """Factory para criar repositórios"""
    
    @staticmethod
    def create(database_url: str) -> ODCSConstantFieldRepository:
        """
        Cria repositório com conexão de banco
        
        Args:
            database_url: URL de conexão do banco
        
        Returns:
            ODCSConstantFieldRepository: Repositório configurado
        """
        engine = create_engine(database_url)
        Base.metadata.create_all(engine)
        
        SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
        session = SessionLocal()
        
        return ODCSConstantFieldRepository(session)


# Exemplo de uso
if __name__ == "__main__":
    from ..entities.odcs_constant_field import ODCSConstantField, ConstantType, ChangePolicy
    
    # Criar repositório (em memória para teste)
    repository = ODCSConstantFieldRepositoryFactory.create("sqlite:///:memory:")
    
    # Criar campo de teste
    field = ODCSConstantField(
        name="test_status",
        business_name="Status de Teste",
        logical_type="string",
        physical_type="varchar(20)",
        description="Campo de status para teste",
        constant_type=ConstantType.ENUM_VALUES,
        default_value="DRAFT",
        allowed_values=["DRAFT", "ACTIVE", "DEPRECATED"],
        change_policy=ChangePolicy.CONTROLLED_EVOLUTION,
        tags=["test", "status"],
        examples=["DRAFT", "ACTIVE"]
    )
    
    # Salvar campo
    saved_field = repository.save(field, contract_id="test-contract-123", object_name="test_object")
    print(f"Campo salvo: {saved_field.name}")
    
    # Buscar campo
    found_field = repository.find_by_name("test_status")
    print(f"Campo encontrado: {found_field.name if found_field else 'Não encontrado'}")
    
    # Estatísticas
    stats = repository.get_statistics()
    print(f"Estatísticas: {stats}")

