#!/usr/bin/env python3
"""
Catalog Service - Sistema de Governança de Dados
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

app = FastAPI(
    title="Catalog Service - Governança de Dados",
    description="Catalog Service do Sistema de Governança de Dados",
    version="1.1.0"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Endpoint raiz"""
    return {
        "message": "Catalog Service - Sistema de Governança de Dados",
        "status": "running"
    }

@app.get("/health")
async def health_check():
    """Health check do serviço"""
    return {"status": "healthy", "service": "catalog-service"}

@app.get("/api/v1/status")
async def get_status():
    """Status do serviço"""
    return {
        "service": "catalog-service",
        "status": "operational",
        "version": "1.1.0"
    }

if __name__ == "__main__":
    print("Iniciando Catalog Service na porta 8004...")
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8004,
        log_level="info"
    )
