
# Configure logging
logger = logging.getLogger(__name__)

# Autor: carlos.morais@f1rst.com.br
"""
Governance Policy Domain Entity
Core business entity for governance policies and compliance management
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any, Set
from uuid import UUID, uuid4
from enum import Enum

from ..value_objects.policy_type import PolicyType, PolicyScope
from ..value_objects.compliance_status import ComplianceStatus
from ..events.governance_events import (
    PolicyCreated, PolicyActivated, PolicyViolated,
    ComplianceAssessed, PolicyUpdated, PolicyDeactivated
)


class PolicyCategory(Enum):
    """Categories of governance policies"""
    DATA_CLASSIFICATION = "data_classification"
    ACCESS_CONTROL = "access_control"
    DATA_RETENTION = "data_retention"
    DATA_QUALITY = "data_quality"
    PRIVACY_PROTECTION = "privacy_protection"
    AUDIT_LOGGING = "audit_logging"
    DATA_LINEAGE = "data_lineage"
    MASKING_ANONYMIZATION = "masking_anonymization"
    CROSS_BORDER_TRANSFER = "cross_border_transfer"
    CONSENT_MANAGEMENT = "consent_management"


class EnforcementLevel(Enum):
    """Policy enforcement levels"""
    ADVISORY = "advisory"  # Warning only
    PREVENTIVE = "preventive"  # Block action
    DETECTIVE = "detective"  # Detect and alert
    CORRECTIVE = "corrective"  # Auto-remediate


@dataclass
class GovernancePolicy:
    # NOTA: Esta classe tem 26 métodos. Considere dividir em classes menores
    """
    Governance Policy aggregate root for managing data governance policies
    """
    # Identity
    id: UUID = field(default_factory=uuid4)
    name: str = ""
    title: str = ""
    description: Optional[str] = None
    version: str = "1.0.0"
    
    # Policy classification
    policy_type: PolicyType = field(default=PolicyType.DATA_CLASSIFICATION)
    category: PolicyCategory = field(default=PolicyCategory.DATA_CLASSIFICATION)
    scope: PolicyScope = field(default=PolicyScope.ORGANIZATION)
    
    # Policy definition
    policy_rules: List[Dict[str, Any]] = field(default_factory=list)
    conditions: Dict[str, Any] = field(default_factory=dict)
    exceptions: List[Dict[str, Any]] = field(default_factory=list)
    
    # Enforcement
    enforcement_level: EnforcementLevel = field(default=EnforcementLevel.ADVISORY)
    auto_remediation: bool = False
    remediation_actions: List[str] = field(default_factory=list)
    
    # Compliance framework
    regulatory_framework: str = "LGPD"  # LGPD, GDPR, CCPA, etc.
    compliance_requirements: List[str] = field(default_factory=list)
    legal_basis: Optional[str] = None
    
    # Scope and applicability
    applies_to_datasets: Set[UUID] = field(default_factory=set)
    applies_to_contracts: Set[UUID] = field(default_factory=set)
    applies_to_organizations: Set[UUID] = field(default_factory=set)
    applies_to_users: Set[UUID] = field(default_factory=set)
    
    # Status and lifecycle
    is_active: bool = False
    effective_date: datetime = field(default_factory=datetime.utcnow)
    expiration_date: Optional[datetime] = None
    
    # Ownership and approval
    owner_id: UUID = field(default_factory=uuid4)
    approved_by: Optional[UUID] = None
    approved_at: Optional[datetime] = None
    organization_id: UUID = field(default_factory=uuid4)
    
    # Monitoring and compliance
    violation_count: int = 0
    last_violation_at: Optional[datetime] = None
    compliance_score: float = 1.0
    last_assessment_at: Optional[datetime] = None
    
    # Notifications
    alert_on_violation: bool = True
    notification_recipients: List[str] = field(default_factory=list)
    escalation_policy: Dict[str, Any] = field(default_factory=dict)
    
    # Documentation
    documentation_url: Optional[str] = None
    training_materials: List[str] = field(default_factory=list)
    implementation_guide: Optional[str] = None
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    business_justification: Optional[str] = None
    risk_level: str = "medium"  # low, medium, high, critical
    
    # Audit fields
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    created_by: UUID = field(default_factory=uuid4)
    updated_by: UUID = field(default_factory=uuid4)
    deleted_at: Optional[datetime] = None
    
    # Domain events
    _domain_events: List[Any] = field(default_factory=list, init=False)
    
    def __post_init__(self):
        """Post-initialization validation and setup"""
        if not self.name:
            raise ValueError("Policy name is required")
        
        if not self.title:
            self.title = self.name.replace('_', ' ').title()
        
        # Set default compliance requirements for LGPD
        if self.regulatory_framework == "LGPD" and not self.compliance_requirements:
            self.compliance_requirements = [
                "Consentimento do titular",
                "Finalidade específica",
                "Minimização de dados",
                "Transparência",
                "Segurança",
                "Responsabilização"
            ]
        
        # Initialize default escalation policy
        if not self.escalation_policy:
            self.escalation_policy = {
                "immediate": ["data_protection_officer"],
                "24_hours": ["compliance_team"],
                "72_hours": ["executive_team"]
            }
    
    def create(self, created_by: UUID) -> None:
        """Create a new governance policy"""
        self.created_by = created_by
        self.updated_by = created_by
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
        
        # Validate policy definition
        if not self._validate_policy():
            raise ValueError("Policy validation failed")
        
        # Raise domain event
        self._add_domain_event(PolicyCreated(
            policy_id=self.id,
            name=self.name,
            policy_type=self.policy_type.value,
            category=self.category.value,
            regulatory_framework=self.regulatory_framework,
            owner_id=self.owner_id,
            created_by=created_by,
            occurred_at=datetime.utcnow()
        ))
    
    def update(self, updated_by: UUID, **kwargs) -> None:
        """Update policy configuration"""
        if self.is_active and self._has_breaking_changes(kwargs):
            raise ValueError("Cannot make breaking changes to active policy")
        
        old_values = {}
        for key, value in kwargs.items():
            if hasattr(self, key):
                old_values[key] = getattr(self, key)
                setattr(self, key, value)
        
        self.updated_by = updated_by
        self.updated_at = datetime.utcnow()
        
        # Increment version for significant changes
        if any(key in kwargs for key in ['policy_rules', 'conditions', 'enforcement_level']):
            self._increment_version()
        
        # Raise domain event
        self._add_domain_event(PolicyUpdated(
            policy_id=self.id,
            updated_fields=list(kwargs.keys()),
            old_values=old_values,
            new_values=kwargs,
            updated_by=updated_by,
            occurred_at=datetime.utcnow()
        ))
    
    def activate(self, activated_by: UUID) -> None:
        """Activate governance policy"""
        if self.is_active:
            return  # Already active
        
        if not self._validate_policy():
            raise ValueError("Cannot activate invalid policy")
        
        if self.effective_date > datetime.utcnow():
            raise ValueError("Cannot activate policy before effective date")
        
        self.is_active = True
        self.updated_by = activated_by
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(PolicyActivated(
            policy_id=self.id,
            activated_by=activated_by,
            effective_date=self.effective_date,
            occurred_at=datetime.utcnow()
        ))
    
    def deactivate(self, deactivated_by: UUID, reason: str) -> None:
        """Deactivate governance policy"""
        if not self.is_active:
            return  # Already inactive
        
        self.is_active = False
        self.updated_by = deactivated_by
        self.updated_at = datetime.utcnow()
        
        # Raise domain event
        self._add_domain_event(PolicyDeactivated(
            policy_id=self.id,
            deactivated_by=deactivated_by,
            reason=reason,
            occurred_at=datetime.utcnow()
        ))
    
    def approve(self, approved_by: UUID) -> None:
        """Approve policy for activation"""
        self.approved_by = approved_by
        self.approved_at = datetime.utcnow()
        self.updated_by = approved_by
        self.updated_at = datetime.utcnow()
    
    def record_violation(self, violation_details: Dict[str, Any], detected_by: UUID) -> 'PolicyViolation':
        """Record a policy violation"""
        violation_id = uuid4()
        occurred_at = datetime.utcnow()
        
        # Update violation statistics
        self.violation_count += 1
        self.last_violation_at = occurred_at
        
        # Recalculate compliance score
        self._recalculate_compliance_score()
        
        # Create violation record
        violation = PolicyViolation(
            violation_id=violation_id,
            policy_id=self.id,
            violation_type=violation_details.get('type', 'unknown'),
            severity=violation_details.get('severity', 'medium'),
            description=violation_details.get('description', ''),
            affected_resource_id=violation_details.get('resource_id'),
            detected_by=detected_by,
            occurred_at=occurred_at,
            details=violation_details
        )
        
        # Raise domain event
        self._add_domain_event(PolicyViolated(
            policy_id=self.id,
            violation_id=violation_id,
            violation_type=violation.violation_type,
            severity=violation.severity,
            affected_resource_id=violation.affected_resource_id,
            detected_by=detected_by,
            occurred_at=occurred_at
        ))
        
        # Trigger auto-remediation if configured
        if self.auto_remediation and self.remediation_actions:
            self._trigger_remediation(violation)
        
        return violation
    
    def assess_compliance(self, assessment_data: Dict[str, Any], assessed_by: UUID) -> ComplianceStatus:
        """Assess compliance against this policy"""
        assessment_id = uuid4()
        assessed_at = datetime.utcnow()
        
        # Calculate compliance score based on assessment data
        compliance_score = self._calculate_compliance_score(assessment_data)
        
        # Determine compliance status
        if compliance_score >= 0.95:
            status = ComplianceStatus.COMPLNT
        elif compliance_score >= 0.8:
            status = ComplianceStatus.PARTLLY_COMPLNT
        else:
            status = ComplianceStatus.NON_COMPLNT
        
        # Update policy compliance metrics
        self.compliance_score = compliance_score
        self.last_assessment_at = assessed_at
        self.updated_at = datetime.utcnow()
        
        # Create compliance assessment
        assessment = ComplianceAssessment(
            assessment_id=assessment_id,
            policy_id=self.id,
            status=status,
            score=compliance_score,
            assessed_by=assessed_by,
            assessed_at=assessed_at,
            findings=assessment_data.get('findings', []),
            recommendations=assessment_data.get('recommendations', [])
        )
        
        # Raise domain event
        self._add_domain_event(ComplianceAssessed(
            policy_id=self.id,
            assessment_id=assessment_id,
            status=status.value,
            score=compliance_score,
            assessed_by=assessed_by,
            occurred_at=assessed_at
        ))
        
        return assessment
    
    def add_rule(self, rule: Dict[str, Any]) -> None:
        """Add rule to policy"""
        if 'id' not in rule:
            rule['id'] = str(uuid4())
        
        self.policy_rules.append(rule)
        self.updated_at = datetime.utcnow()
    
    def remove_rule(self, rule_id: str) -> None:
        """Remove rule from policy"""
        self.policy_rules = [r for r in self.policy_rules if r.get('id') != rule_id]
        self.updated_at = datetime.utcnow()
    
    def add_exception(self, exception: Dict[str, Any]) -> None:
        """Add exception to policy"""
        if 'id' not in exception:
            exception['id'] = str(uuid4())
        
        self.exceptions.append(exception)
        self.updated_at = datetime.utcnow()
    
    def apply_to_dataset(self, dataset_id: UUID) -> None:
        """Apply policy to a dataset"""
        self.applies_to_datasets.add(dataset_id)
        self.updated_at = datetime.utcnow()
    
    def apply_to_contract(self, contract_id: UUID) -> None:
        """Apply policy to a contract"""
        self.applies_to_contracts.add(contract_id)
        self.updated_at = datetime.utcnow()
    
    def is_applicable_to(self, resource_type: str, resource_id: UUID) -> bool:
        """Check if policy applies to a specific resource"""
        if resource_type == "dataset":
            return resource_id in self.applies_to_datasets
        elif resource_type == "contract":
            return resource_id in self.applies_to_contracts
        elif resource_type == "organization":
            return resource_id in self.applies_to_organizations
        elif resource_type == "user":
            return resource_id in self.applies_to_users
        
        return False
    
    def is_effective(self) -> bool:
        """Check if policy is currently effective"""
        now = datetime.utcnow()
        return (
            self.is_active and
            self.effective_date <= now and
            (not self.expiration_date or self.expiration_date > now)
        )
    
    def is_expired(self) -> bool:
        """Check if policy is expired"""
        if not self.expiration_date:
            return False
        return datetime.utcnow() > self.expiration_date
    
    def get_violation_rate(self) -> float:
        """Get violation rate (violations per day since activation)"""
        if not self.is_active or not self.last_violation_at:
            return 0.0
        
        days_active = (datetime.utcnow() - self.effective_date).days
        if days_active == 0:
            days_active = 1
        
        return self.violation_count / days_active
    
    def needs_review(self) -> bool:
        """Check if policy needs review"""
        # Policy needs review if:
        # 1. High violation rate
        # 2. Low compliance score
        # 3. No recent assessment
        
        if self.get_violation_rate() > 5:  # More than 5 violations per day
            return True
        
        if self.compliance_score < 0.7:
            return True
        
        if self.last_assessment_at:
            days_since_assessment = (datetime.utcnow() - self.last_assessment_at).days
            if days_since_assessment > 90:  # No assessment in 3 months
                return True
        
        return False
    
    def get_domain_events(self) -> List[Any]:
        """Get and clear domain events"""
        events = self._domain_events.copy()
        self._domain_events.clear()
        return events
    
    def _add_domain_event(self, event: Any) -> None:
        """Add a domain event"""
        self._domain_events.append(event)
    
    def _validate_policy(self) -> bool:
        """Validate policy configuration"""
        # Must have at least one rule
        if not self.policy_rules:
            return False
        
        # Must have valid regulatory framework
        valid_frameworks = ["LGPD", "GDPR", "CCPA", "PIPEDA", "Custom"]
        if self.regulatory_framework not in valid_frameworks:
            return False
        
        # Must have owner
        if not self.owner_id:
            return False
        
        return True
    
    def _has_breaking_changes(self, changes: Dict[str, Any]) -> bool:
        """Check if changes are breaking for active policy"""
        breaking_fields = ['policy_rules', 'enforcement_level', 'scope']
        return any(field in changes for field in breaking_fields)
    
    def _increment_version(self) -> None:
        """Increment policy version"""
        try:
            major, minor, patch = self.version.split('.')
            self.version = f"{major}.{int(minor) + 1}.0"
        except Exception as e:
        logger.error(f"Erro inesperado: {e}")
            self.version = "1.1.0"
    
    def _recalculate_compliance_score(self) -> None:
        """Recalculate compliance score based on violations"""
        # Simple algorithm - in real implementation would be more sophisticated
        if self.violation_count == 0:
            self.compliance_score = 1.0
        else:
            # Decrease score based on violation rate
            violation_rate = self.get_violation_rate()
            score_reduction = min(violation_rate * 0.1, 0.5)  # Max 50% reduction
            self.compliance_score = max(1.0 - score_reduction, 0.0)
    
    def _calculate_compliance_score(self, assessment_data: Dict[str, Any]) -> float:
        """Calculate compliance score from assessment data"""
        # Simple scoring algorithm
        total_checks = assessment_data.get('total_checks', 1)
        passed_checks = assessment_data.get('passed_checks', 0)
        
        base_score = passed_checks / total_checks
        
        # Apply penalties for critical findings
        critical_findings = assessment_data.get('critical_findings', 0)
        penalty = critical_findings * 0.1
        
        return max(base_score - penalty, 0.0)
    
    def _trigger_remediation(self, violation: 'PolicyViolation') -> None:
        """Trigger auto-remediation actions"""
        # In real implementation, this would trigger actual remediation workflows
        pass


@dataclass
class PolicyViolation:
    """Represents a policy violation"""
    violation_id: UUID = field(default_factory=uuid4)
    policy_id: UUID = field(default_factory=uuid4)
    
    # Violation details
    violation_type: str = ""
    severity: str = "medium"  # low, medium, high, critical
    description: str = ""
    
    # Context
    affected_resource_id: Optional[UUID] = None
    affected_resource_type: Optional[str] = None
    user_id: Optional[UUID] = None
    
    # Detection
    detected_by: UUID = field(default_factory=uuid4)
    detected_at: datetime = field(default_factory=datetime.utcnow)
    detection_method: str = "automated"
    
    # Resolution
    status: str = "open"  # open, investigating, resolved, false_positive
    resolved_at: Optional[datetime] = None
    resolved_by: Optional[UUID] = None
    resolution_notes: Optional[str] = None
    
    # Additional data
    details: Dict[str, Any] = field(default_factory=dict)
    evidence: List[str] = field(default_factory=list)
    
    def resolve(self, resolved_by: UUID, resolution_notes: str) -> None:
        """Resolve violation"""
        self.status = "resolved"
        self.resolved_at = datetime.utcnow()
        self.resolved_by = resolved_by
        self.resolution_notes = resolution_notes
    
    def mark_false_positive(self, marked_by: UUID, reason: str) -> None:
        """Mark violation as false positive"""
        self.status = "false_positive"
        self.resolved_at = datetime.utcnow()
        self.resolved_by = marked_by
        self.resolution_notes = f"False positive: {reason}"


@dataclass
class ComplianceAssessment:
    """Represents a compliance assessment"""
    assessment_id: UUID = field(default_factory=uuid4)
    policy_id: UUID = field(default_factory=uuid4)
    
    # Assessment results
    status: ComplianceStatus = field(default=ComplianceStatus.UNKNOWN)
    score: float = 0.0
    
    # Assessment details
    assessed_by: UUID = field(default_factory=uuid4)
    assessed_at: datetime = field(default_factory=datetime.utcnow)
    assessment_method: str = "automated"
    
    # Findings
    findings: List[Dict[str, Any]] = field(default_factory=list)
    recommendations: List[str] = field(default_factory=list)
    
    # Scope
    scope: str = "full"  # full, partial, targeted
    resources_assessed: List[UUID] = field(default_factory=list)
    
    def add_finding(self, finding_type: str, severity: str, description: str, resource_id: Optional[UUID] = None) -> None:
        """Add finding to assessment"""
        finding = {
            'id': str(uuid4()),
            'type': finding_type,
            'severity': severity,
            'description': description,
            'resource_id': str(resource_id) if resource_id else None,
            'found_at': datetime.utcnow().isoformat()
        }
        self.findings.append(finding)
    
    def add_recommendation(self, recommendation: str) -> None:
        """Add recommendation to assessment"""
        if recommendation not in self.recommendations:
            self.recommendations.append(recommendation)
    
    def is_compliant(self) -> bool:
        """Check if assessment shows compliance"""
        return self.status == ComplianceStatus.COMPLNT
    
    def has_critical_findings(self) -> bool:
        """Check if assessment has critical findings"""
        return any(f.get('severity') == 'critical' for f in self.findings)

