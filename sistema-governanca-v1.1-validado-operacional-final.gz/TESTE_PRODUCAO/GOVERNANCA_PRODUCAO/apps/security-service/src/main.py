#!/usr/bin/env python3
"""
Security Service - Sistema de Governança de Dados V1.0
Microserviço para security service
"""

import os
import sys
from pathlib import Path

# Adicionar diretório raiz ao path
root_dir = Path(__file__).parent.parent.parent
sys.path.append(str(root_dir))

try:
    from fastapi import FastAPI, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    import uvicorn
    from config.settings import get_settings
except ImportError as e:
    print(f"Erro ao importar dependências: {e}")
    print("Execute: pip install fastapi uvicorn")
    sys.exit(1)

# Configurações
settings = get_settings()
app = FastAPI(
    title="Security Service",
    description="Microserviço do Sistema de Governança de Dados",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    """Endpoint raiz"""
    return {
        "service": "security-service",
        "status": "running",
        "version": "1.0.0",
        "port": 8011
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "security-service",
        "timestamp": "2025-08-07T22:00:00Z"
    }

@app.get("/api/v1/status")
async def get_status():
    """Status do serviço"""
    return {
        "service": "security-service",
        "status": "operational",
        "endpoints": ["/", "/health", "/api/v1/status"],
        "database": "connected",
        "cache": "connected"
    }

if __name__ == "__main__":
    print(f"Iniciando {'security-service'.replace('-', ' ').title()} na porta 8011...")
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8011,
        log_level="info"
    )
