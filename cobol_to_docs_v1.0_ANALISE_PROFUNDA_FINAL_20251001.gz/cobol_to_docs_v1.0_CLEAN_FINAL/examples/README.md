# Exemplos COBOL to Docs v1.1

**Autor:** Carlos Morais  
**Sistema:** Análise e Documentação Automatizada de Programas COBOL

Esta pasta contém exemplos práticos de uso do COBOL to Docs v1.1.

## Arquivos de Exemplo

### Programas COBOL
- **programa_exemplo.cbl** - Programa COBOL funcional de cálculo de juros
- **fontes.txt** - Lista de arquivos COBOL para análise

### Copybooks
- **copybook_cliente.cpy** - Estrutura de dados de cliente
- **copybook_conta.cpy** - Estrutura de conta bancária  
- **copybook_transacao.cpy** - Estrutura de transações
- **books.txt** - Lista de copybooks para análise

### Documentação e Tutoriais
- **COBOL_to_Docs_Tutorial.ipynb** - Notebook Jupyter com tutorial completo
- **requisitos_exemplo.txt** - Exemplo de requisitos para geração de prompts

## Como Usar os Exemplos

### 1. Análise Básica
```bash
python3 main.py --fontes examples/fontes.txt --models enhanced_mock
```

### 2. Análise com Copybooks
```bash
python3 main.py --fontes examples/fontes.txt --books examples/books.txt --models enhanced_mock
```

### 3. Tutorial Interativo
```bash
jupyter notebook examples/COBOL_to_Docs_Tutorial.ipynb
```

### 4. Geração de Prompts
```bash
python3 generate_prompts.py --input examples/requisitos_exemplo.txt
```

## Estrutura dos Arquivos

### fontes.txt
Arquivo de texto contendo lista de programas COBOL para análise:
```
# Lista de arquivos COBOL para análise
# Formato: um arquivo por linha
examples/programa_exemplo.cbl
```

### books.txt
Arquivo de texto contendo lista de copybooks:
```
# Lista de copybooks COBOL para análise
# Formato: um arquivo por linha
examples/copybook_cliente.cpy
examples/copybook_conta.cpy
examples/copybook_transacao.cpy
```

### requisitos_exemplo.txt
Texto livre que será convertido em prompts YAML:
```
Análise de sistema bancário COBOL focando em:
- Validação de dados de entrada
- Processamento de transações
- Controles de segurança
- Performance e otimização
```

## Detecção Automática

O sistema detecta automaticamente se um arquivo contém:

1. **Lista de caminhos** (como fontes.txt e books.txt)
2. **Código COBOL direto** (arquivos com IDENTIFICATION DIVISION, PROGRAM-ID, etc.)

### Exemplo com Código Direto
Se você tiver um arquivo contendo código COBOL completo:
```bash
python3 main.py --fontes meu_codigo_cobol.txt --models enhanced_mock
```

O sistema detectará automaticamente e processará o código.

## Resultados Esperados

Após executar as análises, você encontrará na pasta `output/`:

- **Documentação MD** - Análise funcional detalhada
- **JSON de Resposta** - Dados completos da análise IA
- **JSON de Request** - Parâmetros da requisição
- **Logs** - Histórico de processamento

## Notebook Tutorial

O arquivo `COBOL_to_Docs_Tutorial.ipynb` contém um tutorial interativo completo que demonstra:

1. Configuração inicial
2. Verificação de status
3. Análise de programas
4. Análise com copybooks
5. Visualização de resultados
6. Análise de métricas
7. Geração de prompts
8. Análise multi-modelo
9. Uso programático
10. Detecção automática

### Executar o Notebook
```bash
# Instalar Jupyter (se necessário)
pip install jupyter

# Executar notebook
jupyter notebook examples/COBOL_to_Docs_Tutorial.ipynb
```

## Personalização

### Modificar Exemplos
Você pode modificar os arquivos de exemplo para testar com seus próprios códigos:

1. Edite `programa_exemplo.cbl` com seu código COBOL
2. Adicione seus copybooks na pasta examples/
3. Atualize `fontes.txt` e `books.txt` com os novos caminhos
4. Execute as análises

### Criar Novos Prompts
Use o arquivo `requisitos_exemplo.txt` como base:

1. Descreva seus requisitos específicos
2. Execute: `python3 generate_prompts.py --input requisitos_exemplo.txt`
3. Use o arquivo YAML gerado: `python3 main.py --prompts-file requisitos_exemplo_prompts.yaml`

## Troubleshooting

### Arquivo não encontrado
- Verifique se os caminhos em fontes.txt e books.txt estão corretos
- Use caminhos relativos a partir do diretório principal

### Provider não disponível
- Verifique configuração em `config/config.yaml`
- Use `enhanced_mock` para testes sem credenciais externas

### Notebook não abre
- Instale Jupyter: `pip install jupyter`
- Execute no diretório correto: `cd cobol_to_docs_v1.1`

## Suporte

Para dúvidas ou problemas:

1. Consulte `docs/GUIA_COMPLETO_USO.md`
2. Verifique `docs/DOCUMENTACAO_TECNICA.md`
3. Execute `python3 main.py --status` para diagnóstico

---

**COBOL to Docs v1.1**  
**Desenvolvido por Carlos Morais**  
**Sistema de Análise e Documentação COBOL com IA**
