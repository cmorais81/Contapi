#!/usr/bin/env python3
"""
Teste das correções incrementais aplicadas
"""

import os
import sys
import subprocess
import json
from datetime import datetime

def test_system():
    """Testa o sistema corrigido"""
    
    # Criar programa de teste
    test_program = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTEINCREMENTAL.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       COPY CADOC-VALIDACOES.
       COPY CADOC-CONSTANTES.
       01  WS-CONTADOR PIC 9(05) VALUE ZEROS.
       
       PROCEDURE DIVISION.
       0000-PRINCIPAL.
           PERFORM 1000-PROCESSAR
           STOP RUN.
       
       1000-PROCESSAR.
           ADD 1 TO WS-CONTADOR
           DISPLAY 'PROCESSAMENTO CADOC INCREMENTAL'.
"""
    
    test_file = "TESTEINCREMENTAL.cbl"
    with open(test_file, 'w', encoding='utf-8') as f:
        f.write(test_program)
    
    # Executar teste
    cmd = [
        'python3', 'main.py',
        '--fontes', test_file,
        '--models', 'enhanced_mock',
        '--output', 'teste_incremental'
    ]
    
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120
        )
        
        success = result.returncode == 0
        
        # Verificar arquivos gerados
        expected_files = [
            "teste_incremental/TESTEINCREMENTAL_analise_funcional.md",
            "teste_incremental/ai_requests/TESTEINCREMENTAL_ai_request.json",
            "teste_incremental/ai_responses/TESTEINCREMENTAL_ai_response.json"
        ]
        
        files_found = []
        for expected_file in expected_files:
            if os.path.exists(expected_file):
                files_found.append(expected_file)
        
        print(f"\n🧪 TESTE DAS CORREÇÕES INCREMENTAIS")
        print("=" * 50)
        print(f"Execução: {'✅ SUCESSO' if success else '❌ FALHA'}")
        print(f"Código de retorno: {result.returncode}")
        print(f"Arquivos gerados: {len(files_found)}/{len(expected_files)}")
        
        for file_found in files_found:
            print(f"  ✅ {file_found}")
        
        for expected_file in expected_files:
            if expected_file not in files_found:
                print(f"  ❌ {expected_file} (não encontrado)")
        
        if success and len(files_found) >= 2:
            print("\n✅ CORREÇÕES APLICADAS COM SUCESSO!")
            print("   • Sistema executa sem erros")
            print("   • Análise aprimorada funcionando")
            print("   • Arquivos de debug gerados")
        else:
            print("\n⚠️  ALGUMAS CORREÇÕES PRECISAM AJUSTE")
            if result.stderr:
                print(f"Erro: {result.stderr[:500]}")
        
        # Limpeza
        if os.path.exists(test_file):
            os.remove(test_file)
        
        return success and len(files_found) >= 2
        
    except Exception as e:
        print(f"Erro no teste: {e}")
        return False

if __name__ == "__main__":
    test_system()
