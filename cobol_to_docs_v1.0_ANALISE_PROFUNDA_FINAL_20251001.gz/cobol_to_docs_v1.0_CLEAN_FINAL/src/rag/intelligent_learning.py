"""
Sistema Inteligente de Aprendizado Contínuo
Aprende automaticamente com cada análise e melhora a base de conhecimento
"""

import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional
from collections import Counter
import re

class IntelligentLearningSystem:
    """Sistema inteligente que aprende continuamente com as análises"""
    
    def __init__(self, knowledge_base_path: str):
        self.knowledge_base_path = knowledge_base_path
        self.logger = logging.getLogger('IntelligentLearning')
        self.learning_stats = {
            'total_analyses': 0,
            'knowledge_items_added': 0,
            'patterns_discovered': 0,
            'last_learning_session': None
        }
    
    def learn_from_analysis(self, analysis_content: str, program_name: str, 
                          program_content: str) -> Dict[str, Any]:
        """
        Aprende automaticamente com uma análise
        
        Args:
            analysis_content: Conteúdo da análise gerada
            program_name: Nome do programa analisado
            program_content: Código fonte do programa
            
        Returns:
            Relatório do aprendizado realizado
        """
        try:
            self.learning_stats['total_analyses'] += 1
            
            learning_report = {
                'program_analyzed': program_name,
                'timestamp': datetime.now().isoformat(),
                'knowledge_extracted': [],
                'patterns_found': [],
                'improvements_suggested': [],
                'confidence_scores': {}
            }
            
            # 1. Extrair conhecimento técnico específico
            technical_knowledge = self._extract_technical_knowledge(
                analysis_content, program_content, program_name
            )
            learning_report['knowledge_extracted'].extend(technical_knowledge)
            
            # 2. Identificar novos padrões
            new_patterns = self._identify_new_patterns(
                analysis_content, program_content
            )
            learning_report['patterns_found'].extend(new_patterns)
            
            # 3. Extrair regras de negócio específicas
            business_rules = self._extract_business_rules_knowledge(
                analysis_content, program_name
            )
            learning_report['knowledge_extracted'].extend(business_rules)
            
            # 4. Identificar técnicas de implementação
            implementation_techniques = self._extract_implementation_techniques(
                program_content, analysis_content
            )
            learning_report['knowledge_extracted'].extend(implementation_techniques)
            
            # 5. Sugerir melhorias na base de conhecimento
            improvements = self._suggest_knowledge_base_improvements(
                analysis_content, program_content
            )
            learning_report['improvements_suggested'].extend(improvements)
            
            # 6. Calcular scores de confiança
            learning_report['confidence_scores'] = self._calculate_confidence_scores(
                learning_report
            )
            
            # 7. Adicionar conhecimento valioso à base
            added_items = self._add_valuable_knowledge_to_base(learning_report)
            self.learning_stats['knowledge_items_added'] += len(added_items)
            
            # 8. Atualizar estatísticas
            self.learning_stats['last_learning_session'] = datetime.now().isoformat()
            
            learning_report['items_added_to_base'] = added_items
            learning_report['learning_stats'] = self.learning_stats.copy()
            
            return learning_report
            
        except Exception as e:
            self.logger.error(f"Erro no aprendizado automático: {e}")
            return {}
    
    def _extract_technical_knowledge(self, analysis: str, code: str, 
                                   program_name: str) -> List[Dict]:
        """Extrai conhecimento técnico específico"""
        knowledge_items = []
        
        # Extrair padrões de estruturas de dados
        if 'OCCURS' in code.upper() and 'DEPENDING' in code.upper():
            knowledge_items.append({
                'type': 'technical_pattern',
                'title': f'Estrutura Dinâmica em {program_name}',
                'content': 'Uso de OCCURS DEPENDING ON para estruturas de tamanho variável, '
                          'demonstrando otimização de memória em ambiente mainframe',
                'keywords': ['occurs depending', 'estrutura dinâmica', 'otimização memória'],
                'cobol_constructs': ['OCCURS DEPENDING ON'],
                'confidence': 0.9,
                'source': program_name
            })
        
        # Extrair padrões de validação complexa
        evaluate_count = code.upper().count('EVALUATE')
        if evaluate_count > 2:
            knowledge_items.append({
                'type': 'validation_pattern',
                'title': f'Padrão de Validação Complexa em {program_name}',
                'content': f'Uso extensivo de EVALUATE ({evaluate_count} ocorrências) para '
                          'validações complexas, demonstrando estruturação de lógica de negócio',
                'keywords': ['evaluate', 'validação complexa', 'lógica estruturada'],
                'cobol_constructs': ['EVALUATE', 'WHEN'],
                'confidence': 0.85,
                'source': program_name
            })
        
        # Extrair padrões de tratamento de erro
        if 'FILE STATUS' in code.upper() and 'DECLARATIVES' in code.upper():
            knowledge_items.append({
                'type': 'error_handling',
                'title': f'Tratamento de Erro Robusto em {program_name}',
                'content': 'Implementação de tratamento de erro com FILE STATUS e DECLARATIVES, '
                          'demonstrando boas práticas de robustez em sistemas críticos',
                'keywords': ['file status', 'declaratives', 'tratamento erro'],
                'cobol_constructs': ['FILE STATUS', 'DECLARATIVES'],
                'confidence': 0.9,
                'source': program_name
            })
        
        return knowledge_items
    
    def _identify_new_patterns(self, analysis: str, code: str) -> List[Dict]:
        """Identifica novos padrões não presentes na base atual"""
        patterns = []
        
        # Padrão de nomenclatura de variáveis
        var_pattern = re.findall(r'\b(WS-[A-Z0-9\-]+)\b', code.upper())
        if len(var_pattern) > 5:
            prefix_counter = Counter([var.split('-')[1] if len(var.split('-')) > 1 else 'UNKNOWN' 
                                    for var in var_pattern])
            most_common = prefix_counter.most_common(1)[0]
            
            patterns.append({
                'type': 'naming_convention',
                'title': f'Convenção de Nomenclatura: {most_common[0]}',
                'content': f'Padrão de nomenclatura identificado: prefixo {most_common[0]} '
                          f'usado em {most_common[1]} variáveis, indicando convenção específica',
                'keywords': ['nomenclatura', 'convenção', 'padrão'],
                'confidence': 0.8
            })
        
        # Padrão de organização de parágrafos
        paragraph_pattern = re.findall(r'^\s*([0-9]{4}-[A-Z\-]+)\.$', code, re.MULTILINE)
        if len(paragraph_pattern) > 3:
            patterns.append({
                'type': 'organization_pattern',
                'title': 'Padrão de Organização Numérica de Parágrafos',
                'content': f'Organização estruturada com {len(paragraph_pattern)} parágrafos '
                          'numerados, demonstrando metodologia de desenvolvimento disciplinada',
                'keywords': ['organização', 'parágrafos', 'estrutura'],
                'confidence': 0.85
            })
        
        return patterns
    
    def _extract_business_rules_knowledge(self, analysis: str, program_name: str) -> List[Dict]:
        """Extrai conhecimento específico de regras de negócio"""
        business_knowledge = []
        
        # Extrair regras de validação específicas
        validation_keywords = ['validação', 'critério', 'regra', 'controle']
        if any(keyword in analysis.lower() for keyword in validation_keywords):
            # Extrair seções que mencionam validações
            validation_sections = []
            lines = analysis.split('\n')
            for i, line in enumerate(lines):
                if any(keyword in line.lower() for keyword in validation_keywords):
                    # Capturar contexto (linha atual + próximas 2)
                    context = ' '.join(lines[i:i+3])
                    if len(context) > 50:  # Apenas contextos substanciais
                        validation_sections.append(context)
            
            if validation_sections:
                business_knowledge.append({
                    'type': 'business_rule',
                    'title': f'Regras de Validação Específicas - {program_name}',
                    'content': f'Regras de validação identificadas: {"; ".join(validation_sections[:2])}',
                    'keywords': ['validação', 'regra negócio', 'critério'],
                    'domain': 'Regras de Negócio',
                    'confidence': 0.8,
                    'source': program_name
                })
        
        return business_knowledge
    
    def _extract_implementation_techniques(self, code: str, analysis: str) -> List[Dict]:
        """Extrai técnicas específicas de implementação"""
        techniques = []
        
        # Técnica de otimização com SEARCH
        if 'SEARCH' in code.upper() and 'WHEN' in code.upper():
            techniques.append({
                'type': 'optimization_technique',
                'title': 'Otimização com SEARCH Binário',
                'content': 'Uso de SEARCH para busca eficiente em tabelas, '
                          'demonstrando preocupação com performance em processamento de dados',
                'keywords': ['search', 'otimização', 'performance'],
                'cobol_constructs': ['SEARCH', 'WHEN'],
                'confidence': 0.85
            })
        
        # Técnica de modularização
        perform_count = code.upper().count('PERFORM')
        if perform_count > 10:
            techniques.append({
                'type': 'modularization_technique',
                'title': 'Modularização Extensiva com PERFORM',
                'content': f'Uso extensivo de PERFORM ({perform_count} ocorrências) '
                          'demonstrando boa prática de modularização e reutilização de código',
                'keywords': ['perform', 'modularização', 'reutilização'],
                'cobol_constructs': ['PERFORM'],
                'confidence': 0.8
            })
        
        return techniques
    
    def _suggest_knowledge_base_improvements(self, analysis: str, code: str) -> List[str]:
        """Sugere melhorias na base de conhecimento"""
        suggestions = []
        
        # Sugerir adição de padrões específicos
        if 'CICS' in code.upper():
            suggestions.append(
                "Adicionar conhecimento sobre padrões CICS para melhor análise de programas online"
            )
        
        if 'DB2' in code.upper() or 'SQL' in code.upper():
            suggestions.append(
                "Expandir conhecimento sobre integração DB2/SQL em programas COBOL"
            )
        
        if 'MQ' in code.upper():
            suggestions.append(
                "Incluir padrões de integração com MQ Series para análise de mensageria"
            )
        
        return suggestions
    
    def _calculate_confidence_scores(self, learning_report: Dict) -> Dict[str, float]:
        """Calcula scores de confiança do aprendizado"""
        scores = {}
        
        # Score baseado na quantidade de conhecimento extraído
        knowledge_count = len(learning_report.get('knowledge_extracted', []))
        scores['knowledge_extraction'] = min(knowledge_count / 5.0, 1.0)
        
        # Score baseado na qualidade dos padrões
        patterns_count = len(learning_report.get('patterns_found', []))
        scores['pattern_recognition'] = min(patterns_count / 3.0, 1.0)
        
        # Score geral
        scores['overall'] = (scores['knowledge_extraction'] + scores['pattern_recognition']) / 2
        
        return scores
    
    def _add_valuable_knowledge_to_base(self, learning_report: Dict) -> List[str]:
        """Adiciona conhecimento valioso à base de conhecimento"""
        added_items = []
        
        try:
            # Carregar base atual
            with open(self.knowledge_base_path, 'r', encoding='utf-8') as f:
                knowledge_base = json.load(f)
            
            # Filtrar itens valiosos (alta confiança)
            valuable_items = [
                item for item in learning_report.get('knowledge_extracted', [])
                if item.get('confidence', 0) > 0.8
            ]
            
            # Adicionar à base
            for item in valuable_items:
                knowledge_item = {
                    'id': f"auto_learned_{len(knowledge_base)}_{item['type']}",
                    'title': item['title'],
                    'content': item['content'],
                    'category': f"Auto-aprendizado {item.get('type', 'Geral').replace('_', ' ').title()}",
                    'keywords': item.get('keywords', []),
                    'cobol_constructs': item.get('cobol_constructs', []),
                    'domain': item.get('domain', 'Análise Automática'),
                    'complexity_level': 'intermediario',
                    'confidence_score': item.get('confidence', 0.8),
                    'source_program': item.get('source', 'Unknown'),
                    'learning_type': 'automatic_extraction',
                    'created_at': datetime.now().isoformat()
                }
                
                knowledge_base.append(knowledge_item)
                added_items.append(knowledge_item['id'])
            
            # Salvar base atualizada
            if added_items:
                with open(self.knowledge_base_path, 'w', encoding='utf-8') as f:
                    json.dump(knowledge_base, f, indent=2, ensure_ascii=False)
                
                self.logger.info(f"Adicionados {len(added_items)} itens à base de conhecimento")
            
        except Exception as e:
            self.logger.error(f"Erro ao adicionar conhecimento à base: {e}")
        
        return added_items
    
    def get_learning_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do aprendizado"""
        return self.learning_stats.copy()
    
    def generate_learning_report(self) -> str:
        """Gera relatório do aprendizado realizado"""
        stats = self.get_learning_statistics()
        
        report = f"""
RELATÓRIO DE APRENDIZADO INTELIGENTE
===================================

Estatísticas Gerais:
- Total de análises processadas: {stats['total_analyses']}
- Itens de conhecimento adicionados: {stats['knowledge_items_added']}
- Padrões descobertos: {stats['patterns_discovered']}
- Última sessão: {stats['last_learning_session']}

Taxa de Aprendizado:
- Conhecimento por análise: {stats['knowledge_items_added'] / max(stats['total_analyses'], 1):.2f}
- Eficiência de descoberta: {stats['patterns_discovered'] / max(stats['total_analyses'], 1):.2f}

Status: Sistema aprendendo continuamente e melhorando a base de conhecimento
"""
        
        return report
