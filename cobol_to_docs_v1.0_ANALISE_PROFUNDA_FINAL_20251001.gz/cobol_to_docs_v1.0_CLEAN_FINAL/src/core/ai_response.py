"""
Classe para respostas de IA - Versão Final Limpa
"""

from typing import Dict, Any, Optional
from datetime import datetime

class AIResponse:
    """Resposta de análise de IA - Compatível com todos os providers"""
    
    def __init__(self, success: bool, content: str, model: str = None, 
                 provider: str = None, tokens_used: int = 0, 
                 error_message: str = None, response_time: float = 0.0, **kwargs):
        self.success = success
        self.content = content
        self.analysis_content = content  # Alias para compatibilidade
        self.model = model
        self.model_used = model  # Alias para compatibilidade
        self.provider = provider
        self.provider_used = provider  # Alias para compatibilidade
        self.tokens_used = tokens_used
        self.error_message = error_message or ""
        self.response_time = response_time
        self.timestamp = datetime.now()
        
        # Atributos adicionais
        for key, value in kwargs.items():
            setattr(self, key, value)
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        return {
            'success': self.success,
            'content': self.content,
            'model': self.model,
            'provider': self.provider,
            'tokens_used': self.tokens_used,
            'error_message': self.error_message,
            'response_time': self.response_time,
            'timestamp': self.timestamp.isoformat()
        }
