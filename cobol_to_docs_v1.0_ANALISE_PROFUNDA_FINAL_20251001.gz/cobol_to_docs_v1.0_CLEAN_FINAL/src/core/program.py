"""
Classe para representar um programa COBOL
"""

from pathlib import Path
from typing import Optional

class COBOLProgram:
    """Representa um programa COBOL"""
    
    def __init__(self, name: str, content: str, file_path: Optional[str] = None):
        """
        Inicializa um programa COBOL
        
        Args:
            name: Nome do programa
            content: Conteúdo do código COBOL
            file_path: Caminho do arquivo (opcional)
        """
        self.name = name
        self.content = content
        self.file_path = file_path
        
    @classmethod
    def from_file(cls, file_path: str) -> 'COBOLProgram':
        """
        Cria um programa COBOL a partir de um arquivo
        
        Args:
            file_path: Caminho para o arquivo COBOL
            
        Returns:
            Instância de COBOLProgram
        """
        path = Path(file_path)
        
        with open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Extrair nome do programa do arquivo ou usar nome do arquivo
        name = path.stem
        
        return cls(name, content, str(path))
    
    def get_size(self) -> int:
        """Retorna o tamanho do programa em caracteres"""
        return len(self.content)
    
    def get_lines_count(self) -> int:
        """Retorna o número de linhas do programa"""
        return len(self.content.split('\n'))
    
    def __str__(self) -> str:
        return f"COBOLProgram(name='{self.name}', size={self.get_size()}, lines={self.get_lines_count()})"
    
    def __repr__(self) -> str:
        return self.__str__()
