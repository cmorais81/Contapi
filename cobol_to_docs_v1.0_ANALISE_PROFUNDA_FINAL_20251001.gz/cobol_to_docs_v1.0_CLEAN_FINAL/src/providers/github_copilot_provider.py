"""
Provider para GitHub Copilot
Integração com GitHub Copilot para análise de código COBOL
"""

import os
import json
import logging
import requests
from typing import Dict, Any, Optional, List
from datetime import datetime

from .base_provider import BaseProvider

class GitHubCopilotProvider(BaseProvider):
    """Provider para GitHub Copilot"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.provider_name = "github_copilot"
        self.api_key = config.get('api_key') or os.getenv('GITHUB_COPILOT_API_KEY')
        self.base_url = config.get('base_url', 'https://api.github.com/copilot')
        self.model = config.get('model', 'gpt-4')
        self.max_tokens = config.get('max_tokens', 8000)
        self.temperature = config.get('temperature', 0.1)
        
        if not self.api_key:
            self.logger.warning("GitHub Copilot API key não configurada")
    
    def analyze_program(self, program_content: str, prompt: str, 
                       model: str = None) -> Dict[str, Any]:
        """Analisa programa usando GitHub Copilot"""
        try:
            if not self.api_key:
                return self._create_error_response("API key não configurada")
            
            # Preparar payload
            payload = {
                "model": model or self.model,
                "messages": [
                    {"role": "system", "content": prompt},
                    {"role": "user", "content": f"Analise o seguinte programa COBOL:\n\n{program_content}"}
                ],
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
                "stream": False
            }
            
            # Headers
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            # Fazer requisição
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                
                if 'choices' in result and len(result['choices']) > 0:
                    content = result['choices'][0]['message']['content']
                    
                    return {
                        'success': True,
                        'content': content,
                        'model': model or self.model,
                        'provider': self.provider_name,
                        'tokens_used': result.get('usage', {}).get('total_tokens', 0),
                        'response_time': 0,
                        'timestamp': datetime.now().isoformat()
                    }
                else:
                    return self._create_error_response("Resposta inválida da API")
            
            else:
                error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                return self._create_error_response(error_msg)
                
        except Exception as e:
            return self._create_error_response(f"Erro inesperado: {str(e)}")
    
    def _create_error_response(self, error_message: str) -> Dict[str, Any]:
        """Cria resposta de erro padronizada"""
        return {
            'success': False,
            'error': error_message,
            'content': '',
            'model': self.model,
            'provider': self.provider_name,
            'tokens_used': 0,
            'response_time': 0,
            'timestamp': datetime.now().isoformat()
        }
    
    def get_available_models(self) -> List[str]:
        """Retorna modelos disponíveis"""
        return ["gpt-4", "gpt-4-turbo", "gpt-3.5-turbo"]
    
    def validate_configuration(self) -> bool:
        """Valida configuração do provider"""
        return bool(self.api_key)
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações do provider"""
        return {
            'name': 'GitHub Copilot',
            'provider_id': self.provider_name,
            'models': self.get_available_models(),
            'max_tokens': self.max_tokens,
            'supports_streaming': False,
            'requires_auth': True,
            'auth_type': 'api_key',
            'base_url': self.base_url
        }
