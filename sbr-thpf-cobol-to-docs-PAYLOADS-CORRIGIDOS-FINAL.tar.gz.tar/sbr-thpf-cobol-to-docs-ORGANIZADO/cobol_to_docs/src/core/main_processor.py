"""
COBOL AI Engine v3.0.0 - Main Processor
Processador principal para análise de arquivos COBOL
"""

import logging
import os
import time
from typing import List, Dict, Any, Optional
from pathlib import Path

from .config import ConfigManager
from .prompt_manager_dual import DualPromptManager
from providers.enhanced_provider_manager import EnhancedProviderManager
from parsers.cobol_parser_ultra_robust import UltraRobustCOBOLParser as COBOLParser
from models.cobol_program import CobolProgram
from models.cobol_book import CobolBook
from analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from generators.documentation_generator import DocumentationGenerator
from utils.html_generator import HTMLReportGenerator
from utils.cost_calculator import CostCalculator
from rag.rag_integration import RAGIntegration
from .intelligent_model_selector import IntelligentModelSelector

class MainProcessor:
    """Processador principal para análise de arquivos COBOL"""
    
    def __init__(self, config_manager: ConfigManager, output_dir: str = "output"):
        """
        Inicializa o processador principal
        
        Args:
            config_manager: Gerenciador de configuração
            output_dir: Diretório de saída
        """
        self.logger = logging.getLogger(__name__)
        self.config_manager = config_manager
        self.output_dir = output_dir
        
        # Criar diretório de saída se não existir
        Path(output_dir).mkdir(exist_ok=True)
        
        # Inicializar componentes
        self.parser = COBOLParser()
        self.provider_manager = EnhancedProviderManager(config_manager)
        self.cost_calculator = CostCalculator()
        
        # Inicializar RAG se disponível
        try:
            self.rag_integration = RAGIntegration(config_manager.config)
        except Exception as e:
            self.logger.warning(f"RAG não disponível: {e}")
            self.rag_integration = None
    
    def process_programs(self, fontes_file: str, books_file: Optional[str] = None, 
                        models: List[str] = None, remove_comments: bool = False,
                        prompt_set: Optional[str] = None) -> bool:
        """
        Processa programas COBOL
        
        Args:
            fontes_file: Arquivo com lista de programas ou programa único
            books_file: Arquivo com lista de copybooks (opcional)
            models: Lista de modelos a usar
            remove_comments: Se deve remover comentários
            prompt_set: Conjunto de prompts a usar
            
        Returns:
            True se processamento foi bem-sucedido
        """
        try:
            self.logger.info("=== INICIANDO PROCESSAMENTO ===")
            
            # Parse dos modelos
            if not models:
                models = ["enhanced_mock"]
            
            # Verificar se é arquivo ou código direto
            if os.path.isfile(fontes_file):
                # Ler lista de programas do arquivo
                with open(fontes_file, 'r', encoding='utf-8') as f:
                    program_files = [line.strip() for line in f if line.strip() and not line.startswith('#')]
            else:
                # Tratar como programa único
                program_files = [fontes_file]
            
            # Processar copybooks se fornecidos
            copybooks = []
            if books_file and os.path.isfile(books_file):
                with open(books_file, 'r', encoding='utf-8') as f:
                    copybook_files = [line.strip() for line in f if line.strip() and not line.startswith('#')]
                
                for book_file in copybook_files:
                    if os.path.isfile(book_file):
                        copybook = self.parser.parse_copybook(book_file)
                        if copybook:
                            copybooks.append(copybook)
            
            # Processar cada programa
            total_programs = len(program_files)
            successful_analyses = 0
            total_tokens = 0
            total_cost = 0.0
            
            for i, program_file in enumerate(program_files, 1):
                self.logger.info(f"Processando programa {i}/{total_programs}: {program_file}")
                
                # Parse do programa
                if os.path.isfile(program_file):
                    programs, books = self.parser.parse_file(program_file)
                    program = programs[0] if programs else None
                else:
                    # Criar programa temporário
                    program = CobolProgram(
                        name="TEMP_PROGRAM",
                        content=program_file,
                        line_count=len(program_file.split('\n')),
                        size=len(program_file),
                        divisions={},
                        sections=[],
                        variables=[],
                        files=[]
                    )
                
                if not program:
                    self.logger.error(f"Erro ao parsear programa: {program_file}")
                    continue
                
                # Copybooks serão processados separadamente
                
                # Processar com cada modelo
                for model in models:
                    try:
                        # Inicializar analisador
                        analyzer = EnhancedCOBOLAnalyzer(
                            config_manager=self.config_manager,
                            provider_manager=self.provider_manager,
                            rag_integration=self.rag_integration
                        )
                        
                        # Executar análise
                        result = analyzer.analyze_program(program, model)
                        
                        if result and result.get('success'):
                            # Gerar documentação
                            doc_generator = DocumentationGenerator(self.output_dir)
                            
                            # Criar um AIResponse mock para compatibilidade
                            from providers.base_provider import AIResponse
                            mock_response = AIResponse(
                                success=result['success'],
                                content=result['content'],
                                tokens_used=result['tokens_used'],
                                model=result['model_used'],
                                provider=result.get('provider_used', 'enhanced_mock')
                            )
                            
                            doc_generator.generate_program_documentation(
                                program, mock_response
                            )
                            
                            # Contabilizar tokens e custo
                            tokens = result.get('tokens_used', 0)
                            cost = result.get('cost', 0.0)
                            total_tokens += tokens
                            total_cost += cost
                            
                            successful_analyses += 1
                            
                            self.logger.info(f"Análise de {program.name} com {model} bem-sucedida.")
                            self.logger.info(f"Tokens utilizados: {tokens:,}")
                            self.logger.info(f"Custo: ${cost:.4f}")
                            self.logger.info(f"Modelo utilizado: {result.get('model_used', model)}")
                        else:
                            self.logger.error(f"Falha na análise de {program.name} com {model}")
                    
                    except Exception as e:
                        self.logger.error(f"Erro ao processar {program.name} com {model}: {e}")
            
            # Relatório final
            print("=" * 60)
            print("PROCESSAMENTO CONCLUÍDO")
            print(f"Programas processados: {total_programs}")
            print(f"Modelos utilizados: {len(models)} ({', '.join(models)})")
            print(f"Análises bem-sucedidas: {successful_analyses}/{total_programs * len(models)}")
            
            if total_programs * len(models) > 0:
                success_rate = (successful_analyses / (total_programs * len(models))) * 100
                print(f"Taxa de sucesso geral: {success_rate:.1f}%")
            
            print(f"Total de tokens utilizados: {total_tokens:,}")
            print(f"Custo total: ${total_cost:.4f}")
            print(f"Documentação gerada em: {self.output_dir}")
            print("=" * 60)
            
            # Gerar relatório RAG se disponível
            if self.rag_integration:
                try:
                    rag_report = self.rag_integration.finalize_session()
                    if rag_report:
                        self.logger.info(f"Relatório de uso do RAG gerado: {rag_report}")
                        print("=== RELATÓRIO RAG DISPONÍVEL ===")
                        print(f"Arquivo: {rag_report}")
                        
                        # Ler estatísticas do RAG
                        rag_stats = self.rag_integration.get_session_stats()
                        print(f"Operações RAG realizadas: {rag_stats.get('operations', 0)}")
                        print(f"Programas analisados: {rag_stats.get('programs', [])}")
                        print(f"Itens de conhecimento utilizados: {rag_stats.get('knowledge_items', 0)}")
                        print("=" * 40)
                except Exception as e:
                    self.logger.warning(f"Erro ao gerar relatório RAG: {e}")
            
            return successful_analyses > 0
            
        except Exception as e:
            self.logger.error(f"Erro durante processamento: {e}")
            return False


def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    import json
    
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            return []
    else:
        # String simples
        return [models_str]


def get_models_from_providers(config_manager: ConfigManager) -> List[str]:
    """Obtém lista de modelos dos providers configurados."""
    models = []
    providers_config = config_manager.get('ai.providers', {})
    
    # Iterar pelos providers habilitados
    for provider_name, provider_config in providers_config.items():
        if provider_config.get('enabled', False):
            provider_models = provider_config.get('models', {})
            
            # Adicionar modelos do provider
            for model_key, model_config in provider_models.items():
                model_name = model_config.get('name')
                if model_name:
                    models.append(model_name)
    
    return models if models else ["enhanced_mock"]


# Funções de processamento (mantidas para compatibilidade)
def process_cobol_files(args, config_manager: ConfigManager, cost_calculator: CostCalculator, rag_integration) -> None:
    """Processa arquivos COBOL com funcionalidade completa restaurada."""
    processor = MainProcessor(config_manager, getattr(args, 'output', 'output'))
    
    models = parse_models_argument(getattr(args, 'models', None))
    if not models:
        models = get_models_from_providers(config_manager)
    
    processor.process_programs(
        fontes_file=args.fontes,
        books_file=getattr(args, 'books', None),
        models=models,
        remove_comments=getattr(args, 'no_comments', False),
        prompt_set=getattr(args, 'prompt_set', None)
    )


def process_standard_analysis(args, config_manager, cost_calculator, parser, models, rag_integration):
    """Processamento padrão de análise"""
    processor = MainProcessor(config_manager, getattr(args, 'output', 'output'))
    processor.process_programs(
        fontes_file=args.fontes,
        books_file=getattr(args, 'books', None),
        models=models,
        remove_comments=getattr(args, 'no_comments', False),
        prompt_set=getattr(args, 'prompt_set', None)
    )


def process_consolidated_analysis(args, config_manager, cost_calculator, parser, models, rag_integration):
    """Processamento de análise consolidada"""
    print("Análise consolidada não implementada ainda")


def process_consolidated_report(args, config_manager, cost_calculator, parser, models):
    """Processamento de relatório consolidado"""
    print("Relatório consolidado não implementado ainda")


def process_expert_analysis(args, config_manager, cost_calculator, parser, models):
    """Processamento de análise especializada"""
    print("Análise especializada não implementada ainda")
