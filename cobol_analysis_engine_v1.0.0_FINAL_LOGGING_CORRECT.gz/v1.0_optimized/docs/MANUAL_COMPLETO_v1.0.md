# Manual Completo - Sistema de Análise COBOL v1.0

## Índice
1. [Visão Geral](#visão-geral)
2. [Instalação e Configuração](#instalação-e-configuração)
3. [Formas de Execução](#formas-de-execução)
4. [Configuração Avançada](#configuração-avançada)
5. [Provedores de IA](#provedores-de-ia)
6. [Exemplos Práticos](#exemplos-práticos)
7. [Troubleshooting](#troubleshooting)
8. [Referência Completa](#referência-completa)

## Visão Geral

O Sistema de Análise COBOL v1.0 é uma ferramenta completa para análise, documentação e modernização de programas COBOL. Oferece múltiplas abordagens de análise, desde extração básica de conteúdo até análise avançada com múltiplas IAs.

### Características Principais

- **Análise Multi-IA**: 4 análises especializadas em paralelo
- **Validação Cruzada**: Verificação automática entre diferentes análises
- **Geração Híbrida**: Combina extração de código real com análise de IA
- **Múltiplos Provedores**: OpenAI, LuzIA corporativo, Enhanced Mock
- **Logging Transparente**: Visualização completa dos prompts enviados
- **Configuração SSL**: Suporte completo a ambientes corporativos
- **Documentação Detalhada**: Análise técnica, estrutural e de negócio

## Instalação e Configuração

### Pré-requisitos

```bash
# Python 3.11+
python3 --version

# Dependências
pip3 install httpx pyyaml asyncio pathlib
```

### Estrutura do Projeto

```
cobol_analysis_engine_v1.0/
├── main.py                    # Script principal
├── config/
│   └── config.yaml           # Configuração completa
├── src/
│   ├── core/                 # Núcleo do sistema
│   ├── providers/            # Provedores de IA
│   ├── generators/           # Geradores de documentação
│   ├── extractors/           # Extratores de conteúdo
│   └── utils/               # Utilitários
├── examples/                 # Arquivos de exemplo
├── logs/                    # Logs do sistema
└── docs/                    # Documentação
```

### Configuração Inicial

1. **Extrair o pacote**:
```bash
tar -xzf cobol_analysis_engine_v1.0_FINAL.tar.gz
cd v1.0_clean
```

2. **Configurar variáveis de ambiente** (opcional):
```bash
export OPENAI_API_KEY="sua_chave_openai"
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
export SSL_CERT_PATH="/path/to/cert.pem"
```

3. **Verificar status do sistema**:
```bash
python3 main.py --status
```

## Formas de Execução

### 1. Análise Básica (Programa Individual)

```bash
# Análise padrão com Enhanced Mock
python3 main.py programa.cbl

# Análise com provider específico
python3 main.py programa.cbl --provider openai
python3 main.py programa.cbl --provider luzia
python3 main.py programa.cbl --provider enhanced_mock
```

### 2. Análise Multi-IA (Recomendado)

```bash
# Multi-IA com audiência combinada (padrão)
python3 main.py programa.cbl --mode multi_ai

# Multi-IA com audiência específica
python3 main.py programa.cbl --mode multi_ai --audience technical
python3 main.py programa.cbl --mode multi_ai --audience executive
python3 main.py programa.cbl --mode multi_ai --audience business
python3 main.py programa.cbl --mode multi_ai --audience implementation
```

### 3. Análise de Múltiplos Programas

```bash
# Arquivo com lista de programas
python3 main.py fontes.txt

# Múltiplos arquivos
python3 main.py fontes.txt copybooks.txt

# Com copybooks específicos
python3 main.py fontes.txt --copybooks BOOKS.txt

# Diretório de saída personalizado
python3 main.py fontes.txt --output resultados_analise/
```

### 4. Análise Tradicional

```bash
# Modo tradicional (sem IA)
python3 main.py programa.cbl --mode traditional

# Tradicional com copybooks
python3 main.py programa.cbl --copybooks BOOKS.txt --mode traditional
```

### 5. Modo Demonstração

```bash
# Análise rápida para demonstração
python3 main.py programa.cbl --demo

# Demo com logging verboso
python3 main.py programa.cbl --demo --verbose
```

### 6. Análise Automática

```bash
# Detecção automática do melhor modo
python3 main.py programa.cbl --mode auto

# Auto com fallback inteligente
python3 main.py fontes.txt --mode auto --provider luzia
```

### 7. Comandos de Sistema

```bash
# Verificar status completo
python3 main.py --status

# Análise silenciosa
python3 main.py programa.cbl --quiet

# Análise com logging detalhado
python3 main.py programa.cbl --verbose
```

## Configuração Avançada

### Arquivo config.yaml

O arquivo `config/config.yaml` contém todas as configurações do sistema:

```yaml
# Configuração SSL Global
ssl:
  verify: true
  cert_path: ${SSL_CERT_PATH}
  ca_bundle: ${SSL_CA_BUNDLE}

# Provedores de IA
ai:
  primary_provider: "enhanced_mock"
  fallback_providers: ["openai", "luzia"]
  global_max_tokens: 8000
  timeout: 180

# Configuração de Análise
analysis:
  max_programs: 50
  default_mode: "multi_ai"
  default_audience: "combined"
  
  multi_ai:
    parallel_analyses: 4
    validation_threshold: 0.75
    clarity_threshold: 0.6
    cross_validation: true

# Logging
logging:
  level: "INFO"
  dir: "logs"
  prompt_logging: true
  performance_logging: true
```

### Variáveis de Ambiente Suportadas

| Variável | Descrição | Exemplo |
|----------|-----------|---------|
| `OPENAI_API_KEY` | Chave da API OpenAI | `sk-...` |
| `LUZIA_CLIENT_ID` | Client ID do LuzIA | `client_123` |
| `LUZIA_CLIENT_SECRET` | Client Secret do LuzIA | `secret_456` |
| `SSL_CERT_PATH` | Caminho do certificado SSL | `/path/cert.pem` |
| `SSL_CA_BUNDLE` | Bundle de CAs | `/path/ca-bundle.crt` |

## Provedores de IA

### 1. Enhanced Mock (Padrão)
- **Uso**: Desenvolvimento e testes
- **Vantagens**: Sempre disponível, rápido, sem custos
- **Configuração**: Não requer configuração adicional

```bash
python3 main.py programa.cbl --provider enhanced_mock
```

### 2. OpenAI GPT
- **Uso**: Análise avançada com GPT-4
- **Vantagens**: Alta qualidade, amplo conhecimento
- **Configuração**: Requer `OPENAI_API_KEY`

```bash
export OPENAI_API_KEY="sua_chave"
python3 main.py programa.cbl --provider openai
```

### 3. LuzIA Corporativo
- **Uso**: Ambiente corporativo Santander
- **Vantagens**: Compliance, segurança corporativa
- **Configuração**: Requer credenciais corporativas

```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
python3 main.py programa.cbl --provider luzia
```

### Fallback Automático

O sistema implementa fallback automático entre provedores:

1. **Provider Principal**: Definido em `config.yaml`
2. **Fallback 1**: Primeiro provider da lista de fallback
3. **Fallback 2**: Enhanced Mock (sempre disponível)

## Exemplos Práticos

### Cenário 1: Análise Corporativa Completa

```bash
# Configurar ambiente corporativo
export LUZIA_CLIENT_ID="corp_client"
export LUZIA_CLIENT_SECRET="corp_secret"
export SSL_CERT_PATH="/etc/ssl/corp-cert.pem"

# Análise Multi-IA com LuzIA
python3 main.py sistema_completo.txt --mode multi_ai --provider luzia --audience combined --output relatorios_corporativos/
```

### Cenário 2: Modernização de Sistema Legacy

```bash
# Análise detalhada para modernização
python3 main.py programas_legacy.txt --copybooks copybooks_sistema.txt --mode multi_ai --audience implementation --verbose
```

### Cenário 3: Auditoria Técnica

```bash
# Análise técnica detalhada
python3 main.py modulos_criticos.txt --mode multi_ai --audience technical --provider openai --output auditoria_tecnica/
```

### Cenário 4: Documentação para Negócio

```bash
# Documentação para stakeholders de negócio
python3 main.py processos_negocio.txt --mode multi_ai --audience business --output documentacao_negocio/
```

### Cenário 5: Desenvolvimento e Testes

```bash
# Análise rápida para desenvolvimento
python3 main.py novo_programa.cbl --demo --provider enhanced_mock

# Teste de múltiplos providers
python3 main.py programa_teste.cbl --mode auto --verbose
```

## Estrutura de Saída

### Arquivos Gerados

Para cada programa analisado, o sistema gera:

1. **`PROGRAMA_MULTI_AI_ANALYSIS.md`**: Documentação principal
2. **`PROGRAMA_technical_data.json`**: Dados técnicos estruturados
3. **Logs detalhados** em `logs/`

### Estrutura da Documentação

```markdown
# Documentação de Sistemas COBOL - Análise Hybrid Real Content Plus Ai

## Resumo Executivo
## Programas Analisados
## Análise Detalhada do Código
## Estrutura de Dados
## Fluxo de Processamento
## Análise Técnica
## Regras de Negócio
## Recomendações
```

### Logs Gerados

- **`logs/cobol_analysis.log`**: Log principal do sistema
- **`logs/luzia_prompts.log`**: Prompts enviados para LuzIA
- **Logs de performance**: Métricas de execução

## Troubleshooting

### Problemas Comuns

#### 1. Erro de Conexão LuzIA
```
Erro: HTTPSConnectionPool(...): Max retries exceeded
```

**Solução**:
```bash
# Verificar certificado SSL
export SSL_CERT_PATH="/path/to/corporate-cert.pem"

# Verificar credenciais
echo $LUZIA_CLIENT_ID
echo $LUZIA_CLIENT_SECRET
```

#### 2. Arquivo de Configuração Não Encontrado
```
Erro: Config file not found
```

**Solução**:
```bash
# Verificar estrutura de diretórios
ls -la config/config.yaml

# Executar do diretório correto
cd v1.0_clean
python3 main.py --status
```

#### 3. Análise Vazia ou Incompleta
```
Documentação gerada vazia
```

**Solução**:
```bash
# Verificar conteúdo dos arquivos
head -10 examples/programa.cbl

# Usar modo verboso para debug
python3 main.py programa.cbl --verbose --provider enhanced_mock
```

#### 4. Erro de Permissão nos Logs
```
Permission denied: logs/
```

**Solução**:
```bash
# Criar diretório de logs
mkdir -p logs
chmod 755 logs

# Ou usar diretório alternativo
export LOG_DIR="/tmp/cobol_logs"
```

### Verificação de Status

```bash
# Status completo do sistema
python3 main.py --status

# Verificar providers específicos
python3 main.py --status | grep -A 5 "Providers"

# Verificar logs
tail -f logs/cobol_analysis.log
```

## Referência Completa

### Argumentos da Linha de Comando

| Argumento | Tipo | Descrição | Padrão |
|-----------|------|-----------|--------|
| `input_files` | Posicional | Arquivos COBOL ou lista | Obrigatório |
| `--copybooks`, `-b` | String | Arquivo de copybooks | Opcional |
| `--output`, `-o` | String | Diretório de saída | `analysis_results` |
| `--mode`, `-m` | Choice | Modo de análise | `auto` |
| `--audience` | Choice | Audiência alvo | `combined` |
| `--provider` | Choice | Provider de IA | `enhanced_mock` |
| `--status` | Flag | Verificar status | - |
| `--demo` | Flag | Modo demonstração | - |
| `--verbose` | Flag | Logging verboso | - |
| `--quiet` | Flag | Saída silenciosa | - |

### Modos de Análise

| Modo | Descrição | Uso Recomendado |
|------|-----------|-----------------|
| `auto` | Detecção automática | Uso geral |
| `multi_ai` | Análise com múltiplas IAs | Análise completa |
| `traditional` | Análise sem IA | Extração básica |
| `demo` | Demonstração rápida | Testes |

### Audiências Disponíveis

| Audiência | Foco | Conteúdo |
|-----------|------|----------|
| `executive` | Executivos | Resumo, impacto, ROI |
| `technical` | Técnicos | Detalhes técnicos, arquitetura |
| `business` | Negócio | Regras, processos, funcionalidades |
| `implementation` | Implementação | Guias, migração, código |
| `combined` | Combinado | Técnico + Implementação |

### Códigos de Saída

| Código | Significado |
|--------|-------------|
| `0` | Sucesso |
| `1` | Erro geral |
| `2` | Erro de configuração |
| `3` | Erro de arquivo |
| `4` | Erro de provider |

### Formatos de Arquivo Suportados

| Extensão | Tipo | Descrição |
|----------|------|-----------|
| `.cbl`, `.cob` | COBOL | Programas COBOL |
| `.txt` | Lista | Lista de programas |
| `.copy`, `.inc` | Copybook | Copybooks COBOL |

---

## Suporte e Contato

Para suporte técnico, consulte:
- **Logs do sistema**: `logs/cobol_analysis.log`
- **Status do sistema**: `python3 main.py --status`
- **Modo verboso**: `--verbose` para debugging

**Versão**: 1.0  
**Data**: 2025-09-19  
**Compatibilidade**: Python 3.11+, COBOL-85/2002/2014
