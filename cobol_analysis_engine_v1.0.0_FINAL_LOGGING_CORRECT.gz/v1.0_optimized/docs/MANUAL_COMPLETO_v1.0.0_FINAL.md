# Manual Completo - Sistema de Análise COBOL v1.0.0

**Versão**: 1.0.0 Final Corrigida (19/09/2025)

## 1. Visão Geral

O Sistema de Análise COBOL v1.0.0 é uma ferramenta poderosa para analisar e documentar programas COBOL, utilizando uma estratégia Multi-IA para enriquecer a análise com múltiplos provedores de IA.

## 2. Funcionalidades Principais

- **Análise Multi-IA**: Utiliza 6 provedores de IA para uma análise completa.
- **Extração de Conteúdo**: Processa arquivos `fontes.txt` e `BOOKS.txt`.
- **Logging Transparente**: Gera logs detalhados de execução e prompts.
- **Configuração Flexível**: Suporte a SSL global e variáveis de ambiente.
- **Relatórios Detalhados**: Gera documentação funcional e técnica por programa.

## 3. Instalação e Configuração

### 3.1. Pré-requisitos
- Python 3.10+
- Dependências listadas em `requirements.txt`

### 3.2. Configuração (config.yaml)

O arquivo `config/config.yaml` centraliza todas as configurações:

```yaml
# SSL Global para todos os providers
ssl:
  verify: true
  cert_path: "${SSL_CERT_PATH}"
  ca_bundle: "${SSL_CA_BUNDLE}"

# 6 Providers Essenciais
ai:
  providers:
    enhanced_mock:
      enabled: true
    openai:
      enabled: true
      api_key: "${OPENAI_API_KEY}"
    luzia:
      enabled: true
      client_id: "${LUZIA_CLIENT_ID}"
      client_secret: "${LUZIA_CLIENT_SECRET}"
    bedrock:
      enabled: true
      region: "${AWS_REGION:-us-east-1}"
    databricks:
      enabled: true
      token: "${DATABRICKS_TOKEN}"
    github_copilot:
      enabled: true
      token: "${GITHUB_TOKEN}"
```

### 3.3. Variáveis de Ambiente

É recomendado o uso de variáveis de ambiente para configurar as credenciais dos providers:

```bash
export OPENAI_API_KEY="seu_api_key"
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
export AWS_REGION="sua_regiao"
export DATABRICKS_TOKEN="seu_token"
export GITHUB_TOKEN="seu_token"
export SSL_CERT_PATH="/caminho/para/seu/certificado.pem"
```

## 4. Como Usar

### 4.1. Comando Principal

O comando principal para análise é:

```bash
python3 main.py [input_files...] [options]
```

### 4.2. Exemplos de Uso

#### Análise de Múltiplos Programas (fontes.txt + BOOKS.txt)

**Comando Correto**:

```bash
python3 main.py examples/fontes.txt --copybooks examples/BOOKS.txt
```

**Descrição**:
- `examples/fontes.txt`: Arquivo com a lista de programas a serem analisados.
- `--copybooks examples/BOOKS.txt`: Arquivo com os copybooks a serem utilizados.

#### Análise com Provider Específico e Logging Detalhado

```bash
python3 main.py programa.cbl --provider luzia --verbose
```

**Descrição**:
- `--provider luzia`: Força o uso do provider LuzIA.
- `--verbose`: Ativa o logging detalhado, incluindo prompts e respostas.

#### Verificar Status do Sistema

```bash
python3 main.py --status
```

**Descrição**:
- Verifica a disponibilidade e configuração de todos os componentes.

## 5. Logging e Debugging

### 5.1. Estrutura de Logs

A pasta `logs/` é criada automaticamente e contém:

- `execution_detailed.log`: Log completo da execução.
- `luzia_prompts.log`: Prompts enviados para o LuzIA.
- `openai_prompts.log`: Prompts enviados para o OpenAI.
- `multi_ai_orchestration.log`: Detalhes da orquestração Multi-IA.

### 5.2. Visualizando Prompts

Para ver o prompt exato enviado para a IA, verifique os arquivos `*_prompts.log`:

```bash
$ cat logs/luzia_prompts.log

================================================================================
TIMESTAMP: 2025-09-19T22:30:00.123456
PROVIDER: luzia
PROMPT:
--------------------
<prompt enviado para a IA>
--------------------
================================================================================
```

## 6. Relatórios de Saída

### 6.1. Estrutura dos Relatórios

Os relatórios são gerados em `analysis_results/` e contêm:

- **Análise Funcional**: Objetivo do programa e regras de negócio.
- **Análise Técnica**: Estrutura, copybooks e detalhes técnicos.

### 6.2. Código nos Relatórios

O código COBOL é formatado em blocos de código para melhor legibilidade:

```markdown
- **Regra 1**: Descrição da regra
  - **Condição**: `IF CAMPO > 10`
  - **Ação**: `MOVE "A" TO OUTRO-CAMPO`
```

## 7. Solução de Problemas

### Erro: `stat: path should be string, bytes, os.PathLike or integer, not list`

**Causa**: O comando para análise de múltiplos arquivos está incorreto.

**Solução**: Utilize o comando correto:

```bash
python3 main.py examples/fontes.txt --copybooks examples/BOOKS.txt
```

### Erro: `provider não disponível`

**Causa**: Credenciais do provider não configuradas corretamente.

**Solução**: Verifique as variáveis de ambiente e o arquivo `config.yaml`.

---

**Manual gerado em**: 19 de setembro de 2025
