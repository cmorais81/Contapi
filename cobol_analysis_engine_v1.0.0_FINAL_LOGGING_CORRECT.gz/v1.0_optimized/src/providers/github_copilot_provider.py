import os
import httpx
from .base_provider import BaseProvider

class GitHubCopilotProvider(BaseProvider):
    def __init__(self, config):
        super().__init__(config)
        self.token = config.get("token") or os.getenv("GITHUB_TOKEN")
        self.api_url = "https://api.github.com/copilot/completions"

    def analyze(self, content):
        if not self.token:
            return {"error": "Token do GitHub não configurado."}

        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json"
        }
        data = {
            "prompt": content,
            "max_tokens": self.config.get("max_tokens", 2048)
        }

        try:
            with httpx.Client() as client:
                response = client.post(self.api_url, headers=headers, json=data)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            return {"error": f"Erro na API do GitHub Copilot: {e}"}

    def get_status(self):
        return {
            "provider": "github_copilot",
            "status": "ready" if self.token else "unconfigured",
            "authenticated": bool(self.token)
        }

