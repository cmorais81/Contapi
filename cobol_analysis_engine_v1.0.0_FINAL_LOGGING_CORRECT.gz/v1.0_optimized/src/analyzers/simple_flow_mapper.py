#!/usr/bin/env python3
"""
Simple Flow Mapper - Sistema de Análise COBOL v14.0
Mapeia fluxo de dados de forma visual e simples
"""

import re
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

@dataclass
class FlowStep:
    """Representa um passo no fluxo de processamento."""
    step_number: int
    description: str
    input_data: List[str]
    output_data: List[str]
    conditions: List[str]

@dataclass
class ProgramFlow:
    """Representa o fluxo completo de um programa."""
    program_name: str
    overall_flow: str  # Descrição geral do fluxo
    steps: List[FlowStep]
    decision_points: List[str]
    error_handling: List[str]

class SimpleFlowMapper:
    """
    Mapeador de Fluxo Simples
    
    Cria representação visual e clara do fluxo de dados
    em programas COBOL, focando no entendimento conceitual.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões para identificar seções do programa
        self.section_patterns = {
            'INITIALIZATION': [
                r'INICIALIZA', r'ABERTURA', r'OPEN', r'INICIO'
            ],
            'INPUT_PROCESSING': [
                r'LE\s+', r'READ\s+', r'LEITURA', r'INPUT'
            ],
            'VALIDATION': [
                r'VALIDA', r'CRITICA', r'VERIFICA', r'CHECA'
            ],
            'TRANSFORMATION': [
                r'PROCESSA', r'CALCULA', r'TRANSFORMA', r'CONVERTE'
            ],
            'ROUTING': [
                r'ROTEIA', r'DIRECIONA', r'EVALUATE', r'IF.*THEN'
            ],
            'OUTPUT_PROCESSING': [
                r'GRAVA', r'WRITE', r'SAIDA', r'OUTPUT'
            ],
            'FINALIZATION': [
                r'FINALIZA', r'FECHAMENTO', r'CLOSE', r'FIM'
            ]
        }
        
        # Padrões de decisão
        self.decision_patterns = [
            r'IF\s+(.+?)\s+THEN',
            r'EVALUATE\s+(.+?)(?:\s+WHEN|\s+END-EVALUATE)',
            r'WHEN\s+(.+?)(?:\s+PERFORM|\s+MOVE|\s+GO)',
            r'PERFORM\s+(.+?)\s+UNTIL'
        ]

    def map_flow(self, program_name: str, code_lines: List[str]) -> ProgramFlow:
        """
        Mapeia o fluxo de processamento do programa.
        """
        self.logger.info(f"Mapeando fluxo de {program_name}")
        
        # Identifica seções principais
        sections = self._identify_sections(code_lines)
        
        # Cria passos do fluxo
        steps = self._create_flow_steps(sections, code_lines)
        
        # Identifica pontos de decisão
        decision_points = self._extract_decision_points(code_lines)
        
        # Identifica tratamento de erros
        error_handling = self._extract_error_handling(code_lines)
        
        # Gera descrição geral do fluxo
        overall_flow = self._generate_overall_flow_description(steps)
        
        return ProgramFlow(
            program_name=program_name,
            overall_flow=overall_flow,
            steps=steps,
            decision_points=decision_points,
            error_handling=error_handling
        )

    def _identify_sections(self, code_lines: List[str]) -> Dict[str, List[int]]:
        """Identifica seções do programa por linha."""
        sections = {section: [] for section in self.section_patterns.keys()}
        
        for i, line in enumerate(code_lines):
            line_upper = line.upper()
            
            for section, patterns in self.section_patterns.items():
                for pattern in patterns:
                    if re.search(pattern, line_upper):
                        sections[section].append(i)
                        break
        
        return sections

    def _create_flow_steps(self, sections: Dict[str, List[int]], 
                          code_lines: List[str]) -> List[FlowStep]:
        """Cria passos do fluxo baseado nas seções identificadas."""
        steps = []
        step_number = 1
        
        # Ordem lógica das seções
        section_order = [
            'INITIALIZATION', 'INPUT_PROCESSING', 'VALIDATION',
            'TRANSFORMATION', 'ROUTING', 'OUTPUT_PROCESSING', 'FINALIZATION'
        ]
        
        for section_name in section_order:
            if sections[section_name]:
                step = self._create_step_from_section(
                    step_number, section_name, sections[section_name], code_lines
                )
                if step:
                    steps.append(step)
                    step_number += 1
        
        return steps

    def _create_step_from_section(self, step_number: int, section_name: str,
                                 line_numbers: List[int], 
                                 code_lines: List[str]) -> Optional[FlowStep]:
        """Cria um passo do fluxo a partir de uma seção."""
        
        # Descrições padrão por seção
        descriptions = {
            'INITIALIZATION': 'Inicialização e abertura de arquivos',
            'INPUT_PROCESSING': 'Leitura de dados de entrada',
            'VALIDATION': 'Validação e crítica dos dados',
            'TRANSFORMATION': 'Processamento e transformação',
            'ROUTING': 'Roteamento e decisões de negócio',
            'OUTPUT_PROCESSING': 'Gravação de dados de saída',
            'FINALIZATION': 'Finalização e fechamento'
        }
        
        description = descriptions.get(section_name, f'Processamento {section_name}')
        
        # Extrai dados de entrada/saída específicos da seção
        input_data = []
        output_data = []
        conditions = []
        
        for line_num in line_numbers[:5]:  # Analisa até 5 linhas da seção
            if line_num < len(code_lines):
                line = code_lines[line_num].upper()
                
                # Identifica arquivos/dados
                file_matches = re.findall(r'([A-Z0-9]+[ES]\d+)', line)
                if 'READ' in line or 'INPUT' in line:
                    input_data.extend(file_matches)
                elif 'WRITE' in line or 'OUTPUT' in line:
                    output_data.extend(file_matches)
                
                # Identifica condições
                if 'IF' in line or 'WHEN' in line:
                    condition_match = re.search(r'(IF|WHEN)\s+(.+?)(?:\s+THEN|\s+PERFORM)', line)
                    if condition_match:
                        conditions.append(condition_match.group(2).strip())
        
        # Remove duplicatas
        input_data = list(set(input_data))
        output_data = list(set(output_data))
        conditions = list(set(conditions))
        
        return FlowStep(
            step_number=step_number,
            description=description,
            input_data=input_data,
            output_data=output_data,
            conditions=conditions
        )

    def _extract_decision_points(self, code_lines: List[str]) -> List[str]:
        """Extrai pontos de decisão do código."""
        decisions = []
        
        for line in code_lines:
            line_upper = line.upper()
            
            for pattern in self.decision_patterns:
                matches = re.finditer(pattern, line_upper)
                for match in matches:
                    condition = match.group(1).strip()
                    if len(condition) > 5:  # Evita condições muito curtas
                        decisions.append(condition)
        
        return list(set(decisions))  # Remove duplicatas

    def _extract_error_handling(self, code_lines: List[str]) -> List[str]:
        """Extrai tratamento de erros."""
        error_patterns = [
            r'ERROR', r'ERRO', r'EXCEPTION', r'ABEND',
            r'FILE\s+STATUS', r'INVALID', r'NOT\s+FOUND'
        ]
        
        error_handling = []
        
        for line in code_lines:
            line_upper = line.upper()
            
            for pattern in error_patterns:
                if re.search(pattern, line_upper):
                    # Extrai a linha completa como tratamento de erro
                    clean_line = line.strip()
                    if len(clean_line) > 10:  # Evita linhas muito curtas
                        error_handling.append(clean_line)
                    break
        
        return error_handling[:5]  # Máximo 5 exemplos

    def _generate_overall_flow_description(self, steps: List[FlowStep]) -> str:
        """Gera descrição geral do fluxo."""
        if not steps:
            return "Fluxo não identificado"
        
        # Identifica padrão geral
        has_input = any('INPUT' in step.description.upper() or 'LEITURA' in step.description.upper() for step in steps)
        has_validation = any('VALIDAÇÃO' in step.description.upper() or 'CRITICA' in step.description.upper() for step in steps)
        has_routing = any('ROTEAMENTO' in step.description.upper() or 'DECISÃO' in step.description.upper() for step in steps)
        has_output = any('GRAVAÇÃO' in step.description.upper() or 'SAÍDA' in step.description.upper() for step in steps)
        
        # Gera descrição baseada no padrão
        if has_input and has_validation and has_routing and has_output:
            return "Fluxo completo: Leitura → Validação → Roteamento → Gravação"
        elif has_input and has_output:
            return "Fluxo básico: Leitura → Processamento → Gravação"
        elif has_routing:
            return "Fluxo de roteamento: Análise → Decisão → Direcionamento"
        else:
            return f"Fluxo de {len(steps)} etapas identificadas"

    def generate_flow_report(self, flow: ProgramFlow) -> str:
        """Gera relatório do fluxo em formato markdown."""
        
        report = [
            f"## 🔄 Fluxo de Processamento - {flow.program_name}",
            "",
            f"**Visão Geral:** {flow.overall_flow}",
            "",
            "###  Passos do Processamento",
            ""
        ]
        
        # Adiciona cada passo
        for step in flow.steps:
            report.append(f"#### {step.step_number}. {step.description}")
            
            if step.input_data:
                report.append(f"**Entrada:** {', '.join(step.input_data)}")
            
            if step.output_data:
                report.append(f"**Saída:** {', '.join(step.output_data)}")
            
            if step.conditions:
                report.append(f"**Condições:** {'; '.join(step.conditions[:2])}")  # Máximo 2
            
            report.append("")
        
        # Fluxo visual
        if flow.steps:
            report.extend([
                "###  Fluxo Visual",
                "",
                "```"
            ])
            
            for i, step in enumerate(flow.steps):
                arrow = " → " if i < len(flow.steps) - 1 else ""
                report.append(f"[{step.step_number}. {step.description.split()[0]}]{arrow}")
            
            report.extend([
                "```",
                ""
            ])
        
        # Pontos de decisão
        if flow.decision_points:
            report.extend([
                "###  Pontos de Decisão",
                ""
            ])
            
            for i, decision in enumerate(flow.decision_points[:5], 1):
                report.append(f"{i}. {decision}")
            
            report.append("")
        
        # Tratamento de erros
        if flow.error_handling:
            report.extend([
                "### 🚨 Tratamento de Erros",
                ""
            ])
            
            for error in flow.error_handling[:3]:
                report.append(f"- {error}")
            
            report.append("")
        
        return '\n'.join(report)
