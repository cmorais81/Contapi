import logging
from typing import Dict, Any

class DetailedReportGenerator:
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)

    def generate(self, program_data: Dict[str, Any], ai_analysis: Dict[str, Any]) -> str:
        report_parts = []
        report_parts.append(self._generate_header(program_data))
        report_parts.append(self._generate_functional_analysis(program_data, ai_analysis))
        report_parts.append(self._generate_technical_analysis(program_data, ai_analysis))
        return "\n".join(report_parts)

    def _generate_header(self, program_data: Dict[str, Any]) -> str:
        return f"# Análise Detalhada do Programa: {program_data.get('name', 'N/A')}\n"

    def _generate_functional_analysis(self, program_data: Dict[str, Any], ai_analysis: Dict[str, Any]) -> str:
        functional_parts = ["## Análise Funcional"]
        
        # Extrair informações do programa
        program_name = program_data.get('name', 'N/A')
        program_code = program_data.get('code', '')
        
        # Objetivo do programa baseado no código ou análise
        objective = program_data.get('objective', 'Não especificado.')
        if objective == 'Não especificado.' and program_code:
            # Tentar extrair objetivo dos comentários do código
            lines = program_code.split('\n')
            for line in lines[:20]:  # Primeiras 20 linhas
                if '*' in line and ('OBJETIVO' in line.upper() or 'FUNCAO' in line.upper()):
                    objective = line.strip('* ').strip()
                    break
        
        functional_parts.append(f"### Objetivo do Programa\n{objective}")
        functional_parts.append("### Regras de Negócio Identificadas")
        
        # Regras de negócio
        business_rules = program_data.get('business_rules', [])
        if not business_rules and program_code:
            # Extrair regras básicas do código
            if 'IF' in program_code:
                functional_parts.append("- **Regra Condicional**: Programa contém lógica condicional")
            if 'PERFORM' in program_code:
                functional_parts.append("- **Regra de Processamento**: Programa executa rotinas específicas")
        else:
            for rule in business_rules:
                if isinstance(rule, dict):
                    functional_parts.append(f"- **{rule.get('id', 'N/A')}**: {rule.get('description', 'N/A')}")
                    functional_parts.append(f"  - **Condição**: `{rule.get('condition', 'N/A')}`")
                    functional_parts.append(f"  - **Ação**: `{rule.get('action', 'N/A')}`")
                else:
                    functional_parts.append(f"- {rule}")
        
        return "\n".join(functional_parts)

    def _generate_technical_analysis(self, program_data: Dict[str, Any], ai_analysis: Dict[str, Any]) -> str:
        technical_parts = ["## Análise Técnica"]
        
        # Estrutura do programa
        divisions = program_data.get('divisions', [])
        if not divisions:
            # Tentar extrair divisões do código
            program_code = program_data.get('code', '')
            if 'IDENTIFICATION DIVISION' in program_code:
                divisions.append('IDENTIFICATION DIVISION')
            if 'ENVIRONMENT DIVISION' in program_code:
                divisions.append('ENVIRONMENT DIVISION')
            if 'DATA DIVISION' in program_code:
                divisions.append('DATA DIVISION')
            if 'PROCEDURE DIVISION' in program_code:
                divisions.append('PROCEDURE DIVISION')
        
        technical_parts.append(f"### Estrutura do Programa\n- **Divisões:** {', '.join(divisions) if divisions else 'Não identificadas'}")
        
        # Copybooks utilizados
        technical_parts.append("### Copybooks Utilizados")
        copybooks_used = program_data.get('copybooks_used', [])
        if not copybooks_used:
            # Tentar extrair copybooks do código
            program_code = program_data.get('code', '')
            lines = program_code.split('\n')
            for line in lines:
                if 'COPY' in line.upper():
                    copybook_name = line.strip().split()[-1].strip('.')
                    copybooks_used.append(copybook_name)
        
        if copybooks_used:
            for copybook in copybooks_used:
                technical_parts.append(f"- {copybook}")
        else:
            technical_parts.append("- Nenhum copybook identificado")
        
        # Informações adicionais
        technical_parts.append("### Características Técnicas")
        program_code = program_data.get('code', '')
        if program_code:
            lines_count = len(program_code.split('\n'))
            technical_parts.append(f"- **Linhas de código:** {lines_count}")
            
            if 'FILE SECTION' in program_code:
                technical_parts.append("- **Manipulação de arquivos:** Sim")
            if 'WORKING-STORAGE SECTION' in program_code:
                technical_parts.append("- **Variáveis de trabalho:** Sim")
            if 'LINKAGE SECTION' in program_code:
                technical_parts.append("- **Parâmetros de entrada:** Sim")
        
        return "\n".join(technical_parts)

