# Sistema Dual Prompts - COBOL AI Engine v2.0.0

**Data:** 22 de setembro de 2025  
**Versão:** 2.0.0 Dual Prompts  
**Funcionalidade:** Múltiplas metodologias de análise  

## 🎯 Nova Funcionalidade: Duplos Prompts

O COBOL AI Engine v2.0.0 agora oferece **duas metodologias de análise** distintas, permitindo escolher a abordagem mais adequada para cada situação.

## 📋 Metodologias Disponíveis

### **1. Prompts Padrão (prompts.yaml)**
- **Foco:** Análise funcional estruturada em 9 questões
- **Público:** Desenvolvedores e analistas de negócio
- **Características:**
  - ✅ Análise em duas etapas (geral + específica)
  - ✅ 9 questões estruturadas específicas
  - ✅ Rastreabilidade direta ao código
  - ✅ Formato funcional para validação
  - ✅ Seção de transparência completa

### **2. DOC-LEGADO PRO (prompts_doc_legado.yaml)**
- **Foco:** Documentação sistêmica completa
- **Público:** Arquitetos e especialistas em migração
- **Características:**
  - ✅ Documento Funcional + Especificação Técnica
  - ✅ Artefatos visuais (Mermaid/PlantUML)
  - ✅ Matrizes CRUD e DMN
  - ✅ Rastreabilidade arquivo/linha/objeto
  - ✅ Lacunas & Suposições estruturadas
  - ✅ Próximos passos (DOR → AÇÃO → DONO → PRAZO)

## 🔧 Como Alternar Entre Metodologias

### **Método 1: Configuração no config.yaml**
```yaml
ai:
  prompt:
    # Para análise funcional padrão (9 questões)
    prompts_file: "config/prompts.yaml"
    
    # Para metodologia DOC-LEGADO PRO sistêmica
    # prompts_file: "config/prompts_doc_legado.yaml"
```

### **Método 2: Renomeação Simples**
```bash
# Backup atual
cp config/prompts.yaml config/prompts_backup.yaml

# Usar DOC-LEGADO PRO
cp config/prompts_doc_legado.yaml config/prompts.yaml

# Voltar ao padrão
cp config/prompts_backup.yaml config/prompts.yaml
```

## 📊 Comparação Detalhada

| Aspecto | Prompts Padrão | DOC-LEGADO PRO |
|---------|----------------|----------------|
| **Estrutura de Saída** | 9 questões funcionais | Documento + Especificação |
| **Tempo de Análise** | Rápido (5-10 min) | Detalhado (15-30 min) |
| **Nível de Detalhe** | Funcional | Sistêmico completo |
| **Diagramas** | Básicos | Mermaid/PlantUML |
| **Rastreabilidade** | Linhas de código | Arquivo/linha/objeto |
| **Público-alvo** | Dev/Negócio | Arquitetos/Migração |
| **Formato** | Relatório funcional | Doc técnica completa |
| **Validação** | Com área de negócio | Arquitetural/técnica |

## 🎯 Quando Usar Cada Metodologia

### **Use Prompts Padrão para:**
- ✅ **Análise rápida** de programas para desenvolvimento
- ✅ **Validação com negócio** de regras funcionais
- ✅ **Manutenção** de sistemas existentes
- ✅ **Documentação funcional** para equipes
- ✅ **Análise de impacto** de mudanças
- ✅ **Treinamento** de novos desenvolvedores

### **Use DOC-LEGADO PRO para:**
- ✅ **Projetos de migração** mainframe → cloud
- ✅ **Documentação sistêmica** completa
- ✅ **Análise arquitetural** detalhada
- ✅ **Auditoria e compliance** com rastreabilidade
- ✅ **Modernização** de sistemas legados
- ✅ **Especificações técnicas** para reescrita

## 📝 Exemplos de Saída

### **Prompts Padrão - Estrutura**
```markdown
# Análise Funcional - PROGRAMA_EXEMPLO

## 1. Contexto e Objetivo
[Propósito do programa no negócio]

## 2. Visão de Alto Nível  
[Entradas → Processamento → Saídas]

## 3. Regras de Negócio
| ID | Regra | Evidência (Linha) | Criticidade |
|----|-------|------------------|-------------|
| RN001 | Validação CPF | Linhas 150-160 | Alta |

[... 9 questões estruturadas ...]

## Seção de Transparência
- Prompts utilizados
- Metodologia aplicada
- Estatísticas de análise
```

### **DOC-LEGADO PRO - Estrutura**
```markdown
## RESUMO EXECUTIVO
• Programa de validação de clientes
• Processa 10.000 registros/dia
• Interface com sistema CRM

## DOCUMENTO FUNCIONAL v1.0

### 1. Contexto e Objetivo do Componente
[Análise sistêmica do propósito]

### 2. Visão de Alto Nível
**Entradas:** Arquivo CLIENTE.DAT
**Transformações:** Validações + Enriquecimento
**Saídas:** Arquivo CLIENTE_VALID.DAT

[... 9 seções funcionais ...]

## ESPECIFICAÇÃO TÉCNICA v1.0

### 1. Arquitetura Atual
```mermaid
graph TD
    A[CLIENTE.DAT] --> B[VALIDADOR]
    B --> C[DB2_CLIENTES]
    B --> D[CLIENTE_VALID.DAT]
```

[... 10 seções técnicas ...]

## LACUNAS & SUPOSIÇÕES
- Falta documentação da tabela CLIENTE_HIST
- Assumido que campo STATUS é obrigatório

## PRÓXIMOS PASSOS
| DOR | AÇÃO | DONO | PRAZO |
|-----|------|------|-------|
| Falta doc | Documentar CLIENTE_HIST | Arquiteto | 1 semana |
```

## 🔄 Migração Entre Metodologias

### **Cenário 1: Desenvolvimento → Migração**
```bash
# Início: análise rápida com prompts padrão
prompts_file: "config/prompts.yaml"

# Depois: análise completa para migração
prompts_file: "config/prompts_doc_legado.yaml"
```

### **Cenário 2: Auditoria → Desenvolvimento**
```bash
# Início: documentação completa para auditoria
prompts_file: "config/prompts_doc_legado.yaml"

# Depois: análise funcional para desenvolvimento
prompts_file: "config/prompts.yaml"
```

## 🛠️ Personalização Avançada

### **Criando Sua Própria Metodologia**
1. **Copie** um arquivo existente como base
2. **Modifique** conforme sua metodologia
3. **Configure** no `config.yaml`
4. **Teste** com programas conhecidos
5. **Documente** a nova metodologia

### **Estrutura Mínima**
```yaml
system_role: |
  [Definição do papel da IA]

prompts:
  general_analysis:
    template: |
      [Template principal]
  
  structured_questions:
    question_1:
      question: "[Pergunta]"
      template: "[Template específico]"

settings:
  max_tokens: 8192
  temperature: 0.1

metadata:
  version: "1.0.0"
  methodology: "Sua Metodologia"
```

## 📋 Validação e Testes

### **Teste de Configuração**
```bash
# Verificar arquivo carregado
python main.py --status

# Análise de teste
python main.py --fontes examples/fontes.txt --output teste_metodologia
```

### **Logs de Validação**
```
INFO - Configuração de prompts carregada de: config/prompts.yaml
INFO - Configuração de prompts carregada de: config/prompts_doc_legado.yaml
```

## 🎯 Recomendações de Uso

### **Para Equipes de Desenvolvimento**
- **Padrão diário:** prompts.yaml (análise funcional)
- **Documentação:** prompts_doc_legado.yaml (quando necessário)
- **Consistência:** mantenha a mesma metodologia por projeto

### **Para Projetos de Migração**
- **Análise inicial:** prompts_doc_legado.yaml (visão sistêmica)
- **Desenvolvimento:** prompts.yaml (implementação)
- **Validação:** ambas as metodologias para comparação

### **Para Auditoria/Compliance**
- **Documentação:** prompts_doc_legado.yaml (rastreabilidade completa)
- **Evidências:** manter ambas as análises
- **Relatórios:** usar metodologia mais adequada ao público

## 🏆 Benefícios do Sistema Dual

### **Flexibilidade Total**
- **Escolha** a metodologia adequada ao contexto
- **Adapte** conforme necessidades específicas
- **Evolua** entre metodologias conforme projeto

### **Eficiência Otimizada**
- **Análise rápida** quando necessário (padrão)
- **Análise completa** quando requerido (DOC-LEGADO PRO)
- **Sem retrabalho** - cada metodologia tem seu propósito

### **Qualidade Garantida**
- **Duas abordagens** validadas e testadas
- **Rastreabilidade** em ambas as metodologias
- **Documentação** adequada para cada público

## 📦 Pacote Final

**Arquivo:** `cobol_ai_engine_v2.0.0_DUAL_PROMPTS_FINAL.tar.gz` (553KB)

### **Conteúdo Incluído**
- ✅ **config/prompts.yaml** - Metodologia padrão (9 questões)
- ✅ **config/prompts_doc_legado.yaml** - Metodologia DOC-LEGADO PRO
- ✅ **GUIA_PROMPTS_v2.0.0.md** - Documentação completa
- ✅ **Sistema configurado** para alternar entre metodologias
- ✅ **Todas as funcionalidades** anteriores preservadas

### **Uso Imediato**
```bash
# Extrair e configurar
tar -xzf cobol_ai_engine_v2.0.0_DUAL_PROMPTS_FINAL.tar.gz
cd cobol_ai_engine_v2.0.0

# Configurar credenciais
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# Usar metodologia padrão (já configurado)
python main.py --fontes examples/fontes.txt --output analise_padrao

# Alternar para DOC-LEGADO PRO
# Editar config/config.yaml: prompts_file: "config/prompts_doc_legado.yaml"
python main.py --fontes examples/fontes.txt --output analise_doc_legado
```

## 🚀 Resultado Final

O COBOL AI Engine v2.0.0 Dual Prompts oferece:

- **Duas metodologias** validadas e complementares
- **Flexibilidade total** para diferentes contextos
- **Qualidade garantida** em ambas as abordagens
- **Facilidade de uso** com alternância simples
- **Documentação completa** para cada metodologia
- **Compatibilidade total** com versões anteriores
- **Extensibilidade** para novas metodologias

Agora você tem a ferramenta perfeita para qualquer tipo de análise COBOL, desde desenvolvimento rápido até documentação sistêmica completa!

---

**Sistema Dual Prompts desenvolvido pela equipe COBOL AI Engine**  
**Implementado em 22/09/2025 para máxima flexibilidade e qualidade**
