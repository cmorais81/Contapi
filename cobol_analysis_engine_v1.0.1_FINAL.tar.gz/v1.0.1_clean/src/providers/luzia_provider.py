"""
Provider LuzIA - Baseado no exemplo que funcionava na v2.0.0
Apenas REST API simples, sem AWS Bedrock
"""

import os
import requests
import json
import time
import logging
from typing import Dict, Any, Optional
from .base_provider import BaseProvider

class LuziaProvider(BaseProvider):
    """Provider para LuzIA Corporativo - REST API simples."""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        
        if not requests:
            raise ImportError("requests é necessário para o LuziaProvider")
        
        # Configurações do provedor LuzIA do YAML
        luzia_config = config.get('luzia', {})
        
        # Credenciais e URLs
        self.client_id = luzia_config.get('client_id', os.getenv('LUZIA_CLIENT_ID', '7153e7d9-d0a9-42ac-8a1c-72bf903155fa'))
        self.client_secret = luzia_config.get('client_secret', os.getenv('LUZIA_CLIENT_SECRET', '90A337BtXt9vH9zXAqc5500gNozjR7xJ'))
        self.sso_endpoint = luzia_config.get('auth_url', 'https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token')
        self.base_url = luzia_config.get('api_url', 'https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/')
        
        # Configurações do modelo
        self.model = luzia_config.get('model', 'aws-claude-3-5-sonnet')
        self.temperature = luzia_config.get('temperature', 0.1)
        self.max_tokens = luzia_config.get('max_tokens', 4000)
        self.timeout = luzia_config.get('timeout', 180.0)
        
        # Configurações de token management específicas do LuzIA
        token_config = config.get('performance', {}).get('token_management', {})
        provider_specific = token_config.get('provider_specific', {}).get('luzia', {})
        
        self.logger = self._setup_logging()
        self.access_token = None
        self.token_expires_at = 0
        
    def _setup_logging(self) -> logging.Logger:
        """Configura sistema de logging."""
        logger = logging.getLogger('LuziaProvider')
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    def _get_access_token(self) -> str:
        """Obtém token de acesso OAuth2."""
        
        # Verificar se token ainda é válido
        if self.access_token and time.time() < self.token_expires_at:
            return self.access_token
        
        try:
            # Dados para autenticação OAuth2 client_credentials
            auth_data = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            
            self.logger.info("Obtendo token de acesso LuzIA...")
            
            response = requests.post(
                self.sso_endpoint,
                data=auth_data,
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self.access_token = token_data['access_token']
                expires_in = token_data.get('expires_in', 3600)
                self.token_expires_at = time.time() + expires_in - 60  # 1 min buffer
                
                self.logger.info("Token LuzIA obtido com sucesso")
                return self.access_token
            else:
                self.logger.error(f"Erro na autenticação LuzIA: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Erro ao obter token LuzIA: {str(e)}")
            return None
    
    def analyze(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Executa análise usando LuzIA."""
        
        try:
            # Verificar conectividade
            if not self._test_connectivity():
                self.logger.warning("LuzIA não acessível, usando modo simulado")
                return self._make_mock_request(prompt, context)
            
            # Obter token de acesso
            access_token = self._get_access_token()
            if not access_token:
                self.logger.warning("Falha na autenticação LuzIA, usando modo simulado")
                return self._make_mock_request(prompt, context)
            
            # Preparar requisição
            headers = {
                'Authorization': f'Bearer {access_token}',
                'Content-Type': 'application/json'
            }
            
            payload = {
                'model': self.model,
                'messages': [
                    {
                        'role': 'user',
                        'content': prompt
                    }
                ],
                'temperature': self.temperature,
                'max_tokens': self.max_tokens
            }
            
            # Fazer requisição
            self.logger.info(f"Enviando requisição para LuzIA (modelo: {self.model})")
            
            response = requests.post(
                f"{self.base_url}chat/completions",
                headers=headers,
                json=payload,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                result = response.json()
                
                # Extrair conteúdo da resposta
                content = result.get('choices', [{}])[0].get('message', {}).get('content', '')
                
                return {
                    'success': True,
                    'content': content,
                    'provider': 'luzia',
                    'model': self.model,
                    'tokens_used': result.get('usage', {}).get('total_tokens', 0),
                    'response_time': response.elapsed.total_seconds()
                }
            else:
                self.logger.error(f"Erro na requisição LuzIA: {response.status_code} - {response.text}")
                return self._make_mock_request(prompt, context)
                
        except Exception as e:
            self.logger.error(f"Erro na análise LuzIA: {str(e)}")
            return self._make_mock_request(prompt, context)
    
    def _test_connectivity(self) -> bool:
        """Testa conectividade com LuzIA."""
        try:
            response = requests.get(
                self.sso_endpoint.replace('/token', '/'),
                timeout=5
            )
            return response.status_code in [200, 401, 403]  # Qualquer resposta válida
        except:
            return False
    
    def _make_mock_request(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Cria resposta simulada quando LuzIA não está disponível."""
        
        # Análise básica do prompt para gerar resposta relevante
        if 'estrutural' in prompt.lower() or 'structure' in prompt.lower():
            mock_content = """
            Análise Estrutural COBOL (Modo Simulado):
            
            O programa apresenta estrutura COBOL padrão com:
            - IDENTIFICATION DIVISION: Identificação do programa
            - ENVIRONMENT DIVISION: Configurações de ambiente
            - DATA DIVISION: Definições de dados e arquivos
            - PROCEDURE DIVISION: Lógica de processamento
            
            Recomendações:
            - Estrutura bem organizada seguindo padrões COBOL
            - Divisões claramente separadas
            - Boa legibilidade do código
            """
        elif 'negócio' in prompt.lower() or 'business' in prompt.lower():
            mock_content = """
            Análise de Negócio COBOL (Modo Simulado):
            
            Regras de negócio identificadas:
            - Processamento de arquivos sequenciais
            - Validações de dados de entrada
            - Cálculos e transformações específicas
            - Geração de relatórios de saída
            
            Impacto no negócio:
            - Sistema crítico para operações
            - Processamento em lote eficiente
            - Conformidade com regulamentações
            """
        elif 'técnica' in prompt.lower() or 'technical' in prompt.lower():
            mock_content = """
            Análise Técnica COBOL (Modo Simulado):
            
            Aspectos técnicos:
            - Algoritmos de processamento eficientes
            - Uso adequado de estruturas de dados
            - Tratamento de erros implementado
            - Performance otimizada para lote
            
            Recomendações técnicas:
            - Considerar modernização gradual
            - Manter compatibilidade com sistemas existentes
            - Documentar interfaces críticas
            """
        else:
            mock_content = """
            Análise COBOL Geral (Modo Simulado):
            
            O sistema COBOL analisado apresenta:
            - Estrutura bem definida e organizada
            - Lógica de negócio clara e documentada
            - Implementação técnica adequada aos padrões
            - Oportunidades de modernização identificadas
            
            Nota: Esta análise foi gerada em modo simulado devido à 
            indisponibilidade do provider LuzIA.
            """
        
        return {
            'success': True,
            'content': mock_content.strip(),
            'provider': 'luzia_mock',
            'model': f"{self.model}_simulated",
            'tokens_used': len(prompt) + len(mock_content),
            'response_time': 0.1,
            'note': 'Resposta simulada - LuzIA não acessível'
        }
    
    def get_status(self) -> Dict[str, Any]:
        """Retorna status do provider LuzIA."""
        
        connectivity = self._test_connectivity()
        
        status = {
            'provider': 'luzia',
            'available': connectivity,
            'model': self.model,
            'endpoint': self.base_url,
            'auth_endpoint': self.sso_endpoint
        }
        
        if connectivity:
            # Testar autenticação
            token = self._get_access_token()
            status['authenticated'] = token is not None
            status['status'] = 'operational' if token else 'auth_failed'
        else:
            status['authenticated'] = False
            status['status'] = 'unreachable'
            status['note'] = 'URLs corporativas não acessíveis externamente'
        
        return status
