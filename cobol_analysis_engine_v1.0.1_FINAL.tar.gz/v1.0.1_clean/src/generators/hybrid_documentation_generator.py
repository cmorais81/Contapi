#!/usr/bin/env python3
"""
Hybrid Documentation Generator - Sistema de Análise COBOL v1.0.0
Gera documentação rica baseada em conteúdo real + análise IA quando disponível.
"""

import json
import logging
from typing import Dict, List, Any
from datetime import datetime

class HybridDocumentationGenerator:
    """Gera documentação híbrida combinando conteúdo real e análise IA."""
    
    def __init__(self):
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def generate_documentation(self, 
                             enriched_content: Dict[str, Any],
                             target_audience: str = 'technical',
                             output_format: str = 'markdown') -> str:
        """
        Gera documentação híbrida baseada em conteúdo real e análise IA.
        
        Args:
            enriched_content: Conteúdo enriquecido (real + IA)
            target_audience: Audiência alvo
            output_format: Formato de saída
            
        Returns:
            Documentação formatada
        """
        
        if output_format == 'markdown':
            return self._generate_markdown_documentation(enriched_content, target_audience)
        elif output_format == 'json':
            return json.dumps(enriched_content, indent=2, ensure_ascii=False)
        else:
            return self._generate_markdown_documentation(enriched_content, target_audience)
    
    def _generate_markdown_documentation(self, content: Dict, audience: str) -> str:
        """Gera documentação em formato Markdown."""
        
        doc = []
        
        # Cabeçalho
        doc.extend(self._generate_header(content, audience))
        
        # Resumo Executivo
        doc.extend(self._generate_executive_summary(content, audience))
        
        # Programas Analisados
        doc.extend(self._generate_programs_section(content, audience))
        
        # Copybooks
        doc.extend(self._generate_copybooks_section(content, audience))
        
        # Análise Técnica
        doc.extend(self._generate_technical_analysis(content, audience))
        
        # Regras de Negócio
        doc.extend(self._generate_business_rules_section(content, audience))
        
        # Recomendações
        doc.extend(self._generate_recommendations(content, audience))
        
        # Rodapé
        doc.extend(self._generate_footer(content))
        
        return '\n'.join(doc)
    
    def _generate_header(self, content: Dict, audience: str) -> List[str]:
        """Gera cabeçalho da documentação."""
        
        programs_count = content.get('summary', {}).get('programs_found', 0)
        copybooks_count = content.get('summary', {}).get('copybooks_found', 0)
        
        ai_available = content.get('ai_enhancement', {}).get('available', False)
        analysis_method = content.get('ai_enhancement', {}).get('analysis_method', 'real_content_only')
        
        header = [
            f"# Documentação de Sistemas COBOL - Análise {analysis_method.replace('_', ' ').title()}",
            "",
            f"**Data de Geração:** {datetime.now().strftime('%d/%m/%Y %H:%M')}",
            f"**Audiência:** {audience.title()}",
            f"**Programas Analisados:** {programs_count}",
            f"**Copybooks Analisados:** {copybooks_count}",
            f"**Método de Análise:** {'Híbrido (Conteúdo Real + IA)' if ai_available else 'Conteúdo Real Extraído'}",
            f"**Qualidade do Conteúdo:** {content.get('summary', {}).get('content_quality', 'high').title()}",
            ""
        ]
        
        return header
    
    def _generate_executive_summary(self, content: Dict, audience: str) -> List[str]:
        """Gera resumo executivo adaptado por audiência."""
        
        programs = content.get('programs', [])
        copybooks = content.get('copybooks', [])
        tech_info = content.get('technical_info', {})
        
        summary = ["## Resumo Executivo", ""]
        
        if audience == 'executive':
            summary.extend([
                f"Esta análise apresenta **{len(programs)} sistemas COBOL** e **{len(copybooks)} estruturas de dados** ",
                "relacionados ao processamento de informações do Banco Central do Brasil (BACEN). ",
                "",
                "### Principais Descobertas:",
                "",
                f"- **Sistemas Ativos:** {len(programs)} programas em operação",
                f"- **Estruturas de Dados:** {len(copybooks)} copybooks com definições do BACEN",
                f"- **Autores Identificados:** {len(tech_info.get('authors', []))} desenvolvedores",
                f"- **Arquivos Processados:** {sum(tech_info.get('file_types', {}).values())} arquivos de dados",
                ""
            ])
            
        elif audience == 'technical':
            summary.extend([
                f"Análise técnica detalhada de **{len(programs)} programas COBOL** e **{len(copybooks)} copybooks** ",
                "extraídos dos arquivos fontes.txt e BOOKS.txt. O sistema identificou estruturas complexas ",
                "relacionadas ao processamento de dados do Banco Central.",
                "",
                "### Características Técnicas:",
                "",
                f"- **Linguagem:** COBOL (COBOL-85/2002/2014)",
                f"- **Ambiente:** Mainframe IBM",
                f"- **Divisões COBOL:** {', '.join(tech_info.get('divisions_used', []))}",
                f"- **Tipos de Arquivo:** {tech_info.get('file_types', {})}",
                ""
            ])
            
        elif audience == 'business':
            objectives = [p.get('objective', '') for p in programs if p.get('objective')]
            summary.extend([
                f"Análise de **{len(programs)} sistemas de negócio** relacionados ao Banco Central, ",
                "incluindo funcionalidades de particionamento, validação e transmissão de dados.",
                "",
                "### Funcionalidades Principais:",
                ""
            ])
            
            for obj in objectives[:3]:  # Limitar a 3 objetivos
                if obj:
                    summary.append(f"- {obj}")
            summary.append("")
            
        else:  # implementation
            summary.extend([
                f"Guia de implementação para modernização de **{len(programs)} programas COBOL** ",
                "com foco em preservação de regras de negócio e estruturas de dados.",
                "",
                "### Escopo da Modernização:",
                "",
                f"- **Programas a Migrar:** {len(programs)}",
                f"- **Estruturas de Dados:** {len(copybooks)} copybooks",
                f"- **Complexidade:** {'Alta' if len(programs) > 3 else 'Média'}",
                f"- **Histórico Disponível:** {'Sim' if any(p.get('version_history') for p in programs) else 'Não'}",
                ""
            ])
        
        return summary
    
    def _generate_programs_section(self, content: Dict, audience: str) -> List[str]:
        """Gera seção de programas analisados."""
        
        programs = content.get('programs', [])
        section = ["## Programas Analisados", ""]
        
        for i, program in enumerate(programs, 1):
            section.append(f"### {i}. {program['name']}")
            section.append("")
            
            # Objetivo (sempre importante)
            if program.get('objective'):
                section.append(f"**Objetivo:** {program['objective']}")
                section.append("")
            
            # Informações por audiência
            if audience in ['technical', 'implementation']:
                if program.get('author'):
                    section.append(f"**Autor:** {program['author']}")
                if program.get('date_written'):
                    section.append(f"**Data de Criação:** {program['date_written']}")
                section.append("")
                
                # Arquivos
                if program.get('files'):
                    section.append("**Arquivos Utilizados:**")
                    for file_info in program['files']:
                        section.append(f"- `{file_info['name']}` ({file_info['type']}): {file_info['description']}")
                    section.append("")
            
            # Histórico de versões (importante para todas as audiências)
            if program.get('version_history'):
                section.append("**Histórico de Versões:**")
                for version in program['version_history']:
                    section.append(f"- **v{version['version']}** ({version['date']}) por {version['author']}: {version['description']}")
                section.append("")
            
            # Análise IA se disponível
            if program.get('ai_analysis'):
                ai_analysis = program['ai_analysis']
                if any(ai_analysis.values()):
                    section.append("**Análise Inteligente:**")
                    
                    if ai_analysis.get('structural', {}).get('success'):
                        section.append("- Análise estrutural: Concluída")
                    if ai_analysis.get('business', {}).get('success'):
                        section.append("- Análise de negócio: Concluída")
                    if ai_analysis.get('technical', {}).get('success'):
                        section.append("- Análise técnica: Concluída")
                    if ai_analysis.get('quality', {}).get('success'):
                        section.append("- Análise de qualidade: Concluída")
                    
                    section.append("")
            
            section.append("---")
            section.append("")
        
        return section
    
    def _generate_copybooks_section(self, content: Dict, audience: str) -> List[str]:
        """Gera seção de copybooks."""
        
        copybooks = content.get('copybooks', [])
        if not copybooks:
            return []
        
        section = ["## Estruturas de Dados (Copybooks)", ""]
        
        for i, copybook in enumerate(copybooks, 1):
            section.append(f"### {i}. {copybook['name']}")
            section.append("")
            
            if copybook.get('description'):
                section.append(f"**Descrição:** {copybook['description']}")
                section.append("")
            
            # Tabelas para audiência técnica
            if audience in ['technical', 'implementation'] and copybook.get('tables'):
                section.append("**Tabelas Definidas:**")
                for table in copybook['tables'][:5]:  # Limitar a 5
                    section.append(f"- `{table['name']}` (nível {table['level']})")
                if len(copybook['tables']) > 5:
                    section.append(f"- ... e mais {len(copybook['tables']) - 5} tabelas")
                section.append("")
            
            # Campos principais
            if copybook.get('fields'):
                section.append("**Campos Principais:**")
                field_count = 5 if audience == 'executive' else 10
                for field in copybook['fields'][:field_count]:
                    pic_info = f" PIC {field['pic']}" if field['pic'] else ""
                    section.append(f"- `{field['name']}` (nível {field['level']}){pic_info}")
                if len(copybook['fields']) > field_count:
                    section.append(f"- ... e mais {len(copybook['fields']) - field_count} campos")
                section.append("")
            
            section.append("---")
            section.append("")
        
        return section
    
    def _generate_technical_analysis(self, content: Dict, audience: str) -> List[str]:
        """Gera análise técnica consolidada."""
        
        if audience == 'executive':
            return []  # Executivos não precisam de detalhes técnicos
        
        tech_info = content.get('technical_info', {})
        section = ["## Análise Técnica Consolidada", ""]
        
        section.extend([
            "### Características do Sistema",
            "",
            f"**Linguagem:** COBOL (COBOL-85/2002/2014)",
            f"**Ambiente:** Mainframe IBM",
            f"**Domínio:** Sistema Bancário - Banco Central do Brasil",
            f"**Total de Programas:** {tech_info.get('total_programs', 0)}",
            f"**Total de Copybooks:** {tech_info.get('total_copybooks', 0)}",
            ""
        ])
        
        # Distribuição de arquivos
        file_types = tech_info.get('file_types', {})
        if any(file_types.values()):
            section.extend([
                "### Distribuição de Arquivos",
                "",
                f"- **Arquivos de Entrada:** {file_types.get('input', 0)}",
                f"- **Arquivos de Saída:** {file_types.get('output', 0)}",
                f"- **Arquivos de Trabalho:** {file_types.get('work', 0)}",
                ""
            ])
        
        # Indicadores de complexidade
        complexity = tech_info.get('complexity_indicators', {})
        if any(complexity.values()):
            section.extend([
                "### Indicadores de Complexidade",
                "",
                f"- **Programas com Histórico de Versões:** {complexity.get('has_version_history', 0)}",
                f"- **Programas com Múltiplos Arquivos:** {complexity.get('has_multiple_files', 0)}",
                f"- **Programas com Procedures:** {complexity.get('has_procedures', 0)}",
                ""
            ])
        
        return section
    
    def _generate_business_rules_section(self, content: Dict, audience: str) -> List[str]:
        """Gera seção de regras de negócio."""
        
        business_rules = content.get('business_rules', [])
        if not business_rules:
            return []
        
        section = ["## Regras de Negócio Identificadas", ""]
        
        # Agrupar por tipo
        objectives = [rule for rule in business_rules if rule.get('type') == 'objective']
        logic_rules = [rule for rule in business_rules if rule.get('type') == 'business_logic']
        
        if objectives:
            section.extend(["### Objetivos dos Sistemas", ""])
            for rule in objectives:
                section.append(f"**{rule['source']}:** {rule['description']}")
                section.append("")
        
        if logic_rules and audience in ['business', 'technical', 'implementation']:
            section.extend(["### Lógica de Negócio", ""])
            for rule in logic_rules[:10]:  # Limitar a 10
                section.append(f"- {rule['description']} *(Fonte: {rule['source']})*")
            if len(logic_rules) > 10:
                section.append(f"- ... e mais {len(logic_rules) - 10} regras identificadas")
            section.append("")
        
        return section
    
    def _generate_recommendations(self, content: Dict, audience: str) -> List[str]:
        """Gera recomendações por audiência."""
        
        programs_count = len(content.get('programs', []))
        has_version_history = any(p.get('version_history') for p in content.get('programs', []))
        
        section = ["## Recomendações", ""]
        
        if audience == 'executive':
            section.extend([
                "### Estratégia de Modernização",
                "",
                "1. **Abordagem Gradual:** Migração por módulos funcionais para reduzir riscos",
                "2. **Preservação de Investimento:** Manter lógica de negócio validada ao longo dos anos",
                "3. **Compliance BACEN:** Garantir conformidade com regulamentações bancárias",
                f"4. **Escopo Controlado:** {programs_count} programas identificados para modernização",
                "5. **ROI Previsível:** Documentação detalhada permite estimativas precisas",
                ""
            ])
            
        elif audience == 'technical':
            section.extend([
                "### Recomendações Técnicas",
                "",
                "1. **Análise de Dependências:** Mapear relacionamentos entre programas e copybooks",
                "2. **Testes Abrangentes:** Validar cálculos e processamentos críticos do BACEN",
                "3. **Migração de Dados:** Preservar estruturas de dados complexas identificadas",
                "4. **Performance:** Otimizar processamento de arquivos grandes (particionamento)",
                "5. **Integração:** Planejar interfaces com sistemas modernos",
                ""
            ])
            
        elif audience == 'business':
            section.extend([
                "### Recomendações de Negócio",
                "",
                "1. **Continuidade Operacional:** Manter funcionalidades críticas do BACEN",
                "2. **Validação de Regras:** Confirmar regras de negócio com especialistas",
                "3. **Treinamento:** Capacitar equipe nas novas tecnologias",
                "4. **Documentação:** Expandir documentação de processos específicos",
                "5. **Compliance:** Validar conformidade regulatória pós-migração",
                ""
            ])
            
        else:  # implementation
            section.extend([
                "### Guia de Implementação",
                "",
                "1. **Fase 1:** Análise detalhada de dependências e interfaces",
                "2. **Fase 2:** Migração de copybooks e estruturas de dados",
                "3. **Fase 3:** Conversão de programas por ordem de complexidade",
                "4. **Fase 4:** Testes integrados e validação de resultados",
                "5. **Fase 5:** Deploy gradual com rollback planejado",
                "",
                f"**Vantagem:** {'Histórico de versões disponível' if has_version_history else 'Documentação interna rica'} facilita a migração",
                ""
            ])
        
        return section
    
    def _generate_footer(self, content: Dict) -> List[str]:
        """Gera rodapé da documentação."""
        
        ai_available = content.get('ai_enhancement', {}).get('available', False)
        analysis_method = content.get('ai_enhancement', {}).get('analysis_method', 'real_content_only')
        
        footer = [
            "---",
            "",
            f"*Documentação gerada pelo Sistema de Análise COBOL v1.0.0*",
            f"*Método: {analysis_method.replace('_', ' ').title()}*",
            f"*Qualidade: {content.get('summary', {}).get('content_quality', 'high').title()} (baseado em conteúdo real)*",
            ""
        ]
        
        if ai_available:
            confidence = content.get('ai_enhancement', {}).get('confidence', 0)
            footer.insert(-1, f"*Confiança da Análise IA: {confidence:.1%}*")
        
        return footer
