#!/bin/bash
# COBOL AI Engine v15.0 - macOS Installation Script
# Compatible with Python 3.11+ on macOS (Intel/Apple Silicon)

set -e  # Exit on any error

echo "🍎 COBOL AI Engine v15.0 - macOS Installation"
echo "=============================================="

# Check if we're on macOS
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo "❌ This script is designed for macOS only"
    exit 1
fi

# Check Python version
echo "🐍 Checking Python version..."
if command -v python3.11 &> /dev/null; then
    PYTHON_CMD="python3.11"
elif command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
    if [[ "$PYTHON_VERSION" == "3.11" ]] || [[ "$PYTHON_VERSION" > "3.11" ]]; then
        PYTHON_CMD="python3"
    else
        echo "❌ Python 3.11+ required. Found: $PYTHON_VERSION"
        echo "💡 Install Python 3.11+ using Homebrew:"
        echo "   brew install python@3.11"
        exit 1
    fi
else
    echo "❌ Python 3.11+ not found"
    echo "💡 Install Python 3.11+ using Homebrew:"
    echo "   brew install python@3.11"
    exit 1
fi

echo "✅ Using Python: $PYTHON_CMD ($($PYTHON_CMD --version))"

# Check if pip is available
echo "📦 Checking pip..."
if ! $PYTHON_CMD -m pip --version &> /dev/null; then
    echo "❌ pip not found"
    echo "💡 Install pip:"
    echo "   curl https://bootstrap.pypa.io/get-pip.py | $PYTHON_CMD"
    exit 1
fi

echo "✅ pip available"

# Create virtual environment (recommended for macOS)
echo "🔧 Creating virtual environment..."
if [[ ! -d "venv" ]]; then
    $PYTHON_CMD -m venv venv
    echo "✅ Virtual environment created"
else
    echo "✅ Virtual environment already exists"
fi

# Activate virtual environment
echo "🔄 Activating virtual environment..."
source venv/bin/activate

# Upgrade pip
echo "⬆️ Upgrading pip..."
pip install --upgrade pip

# Install dependencies
echo "📦 Installing dependencies..."
if [[ -f "requirements_macos.txt" ]]; then
    pip install -r requirements_macos.txt
    echo "✅ macOS-specific dependencies installed"
elif [[ -f "requirements.txt" ]]; then
    pip install -r requirements.txt
    echo "✅ Standard dependencies installed"
else
    echo "⚠️ No requirements file found, installing basic dependencies..."
    pip install PyYAML requests pandas numpy beautifulsoup4 reportlab markdown
fi

# Set up environment
echo "🔧 Setting up environment..."

# Create .env file for macOS
cat > .env << EOF
# COBOL AI Engine v15.0 - macOS Environment
PYTHONPATH=./src
PYTHONIOENCODING=utf-8
LC_ALL=en_US.UTF-8
LANG=en_US.UTF-8

# Optional: AI Provider API Keys
# OPENAI_API_KEY=your_openai_key_here
# ANTHROPIC_API_KEY=your_anthropic_key_here
# GITHUB_TOKEN=your_github_token_here
EOF

# Make scripts executable
echo "🔐 Setting permissions..."
chmod +x *.py 2>/dev/null || true
chmod +x *.sh 2>/dev/null || true

# Test installation
echo "🧪 Testing installation..."
if $PYTHON_CMD -c "import yaml, requests, pandas, numpy; print('✅ Core dependencies working')" 2>/dev/null; then
    echo "✅ Installation test passed"
else
    echo "❌ Installation test failed"
    exit 1
fi

echo ""
echo "🎉 Installation completed successfully!"
echo ""
echo "📋 Next steps:"
echo "1. Activate virtual environment: source venv/bin/activate"
echo "2. Run demo: python main_v15_demo.py"
echo "3. Run full analysis: python main_v15_universal_functional.py examples/fontes.txt examples/BOOKS.txt"
echo ""
echo "💡 Tips for macOS:"
echo "- Use Terminal or iTerm2 for best experience"
echo "- Ensure sufficient disk space (>1GB for large analyses)"
echo "- For Apple Silicon Macs, all dependencies are native ARM64"
echo ""
echo "🔧 Troubleshooting:"
echo "- If encoding issues: export PYTHONIOENCODING=utf-8"
echo "- If permission issues: chmod +x *.py"
echo "- If dependency issues: pip install --upgrade -r requirements_macos.txt"
echo ""
echo "✅ Ready to analyze COBOL programs on macOS!"
