# Script simples para executar TBR GDP Core Data Governance API
# Para uso quando já estiver no diretório src/
# Desenvolvido por Carlos Morais

param(
    [int]$Port = 8000,
    [string]$Host = "0.0.0.0"
)

Write-Host "🚀 TBR GDP Core Data Governance API v2.1" -ForegroundColor Green
Write-Host "Desenvolvido por Carlos Morais" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan

# Verificar se estamos no diretório src
if (Test-Path "main.py") {
    Write-Host "✅ Executando do diretório src/" -ForegroundColor Green
    Write-Host "🌐 Iniciando servidor..." -ForegroundColor Blue
    Write-Host "URL: http://$Host`:$Port" -ForegroundColor Yellow
    Write-Host "Docs: http://$Host`:$Port/docs" -ForegroundColor Yellow
    Write-Host "Health: http://$Host`:$Port/health" -ForegroundColor Yellow
    Write-Host "================================================" -ForegroundColor Cyan
    
    # Comando correto quando dentro de src/
    uvicorn main:app --host $Host --port $Port --reload
    
} elseif (Test-Path "src\main.py") {
    Write-Host "✅ Executando do diretório raiz" -ForegroundColor Green
    Write-Host "🌐 Iniciando servidor..." -ForegroundColor Blue
    Write-Host "URL: http://$Host`:$Port" -ForegroundColor Yellow
    Write-Host "Docs: http://$Host`:$Port/docs" -ForegroundColor Yellow
    Write-Host "Health: http://$Host`:$Port/health" -ForegroundColor Yellow
    Write-Host "================================================" -ForegroundColor Cyan
    
    # Comando correto quando no diretório raiz
    uvicorn main:app --host $Host --port $Port --reload --app-dir src
    
} else {
    Write-Host "❌ Arquivo main.py não encontrado!" -ForegroundColor Red
    Write-Host "Certifique-se de estar no diretório correto:" -ForegroundColor Yellow
    Write-Host "- No diretório raiz do projeto (onde está src/)" -ForegroundColor Yellow
    Write-Host "- Ou dentro do diretório src/" -ForegroundColor Yellow
    Write-Host "Diretório atual: $(Get-Location)" -ForegroundColor Red
    exit 1
}

