# Script para executar TBR GDP Core Data Governance API no Windows
# Compatível com Python 3.14
# Desenvolvido por Carlos Morais

param(
    [string]$Environment = "development",
    [int]$Port = 8000,
    [string]$Host = "0.0.0.0"
)

Write-Host "🚀 Iniciando TBR GDP Core Data Governance API..." -ForegroundColor Green
Write-Host "Projeto: tbr-gdpcore-dtgovapi" -ForegroundColor Cyan
Write-Host "Versão: 2.1.0" -ForegroundColor Cyan
Write-Host "Ambiente: $Environment" -ForegroundColor Yellow
Write-Host "Porta: $Port" -ForegroundColor Yellow

# Verificar se estamos no diretório correto
if (-not (Test-Path "src\main.py")) {
    Write-Host "❌ Arquivo src\main.py não encontrado. Certifique-se de estar no diretório raiz do projeto." -ForegroundColor Red
    Write-Host "Diretório atual: $(Get-Location)" -ForegroundColor Red
    exit 1
}

# Verificar se o ambiente virtual existe
if (-not (Test-Path ".venv") -and -not (Test-Path "venv")) {
    Write-Host "❌ Ambiente virtual não encontrado. Execute setup.ps1 primeiro." -ForegroundColor Red
    exit 1
}

# Ativar ambiente virtual (priorizar .venv)
Write-Host "📦 Ativando ambiente virtual..." -ForegroundColor Blue
if (Test-Path ".venv") {
    & ".venv\Scripts\Activate.ps1"
    Write-Host "✅ Ambiente virtual .venv ativado" -ForegroundColor Green
} elseif (Test-Path "venv") {
    & "venv\Scripts\Activate.ps1"
    Write-Host "✅ Ambiente virtual venv ativado" -ForegroundColor Green
}

# Verificar variáveis de ambiente
if (-not (Test-Path ".env")) {
    Write-Host "⚠️  Arquivo .env não encontrado. Copiando de .env.example..." -ForegroundColor Yellow
    if (Test-Path ".env.example") {
        Copy-Item ".env.example" ".env"
        Write-Host "✅ Arquivo .env criado" -ForegroundColor Green
    } else {
        Write-Host "❌ Arquivo .env.example não encontrado" -ForegroundColor Red
        exit 1
    }
}

# Configurar PYTHONPATH
$env:PYTHONPATH = "$(Get-Location)\src"
Write-Host "📁 PYTHONPATH configurado: $env:PYTHONPATH" -ForegroundColor Blue

# Verificar se as dependências estão instaladas
Write-Host "🔍 Verificando dependências..." -ForegroundColor Blue
try {
    python -c "import fastapi, uvicorn, sqlalchemy" 2>$null
    Write-Host "✅ Dependências principais encontradas" -ForegroundColor Green
} catch {
    Write-Host "❌ Dependências não encontradas. Instalando..." -ForegroundColor Red
    pip install -r requirements.txt
}

# Executar migrações se necessário (opcional para desenvolvimento)
if ($Environment -eq "production") {
    Write-Host "🔄 Executando migrações do banco..." -ForegroundColor Blue
    try {
        python -m alembic upgrade head
        Write-Host "✅ Migrações executadas com sucesso" -ForegroundColor Green
    } catch {
        Write-Host "⚠️  Erro nas migrações, continuando..." -ForegroundColor Yellow
    }
}

# Iniciar servidor
Write-Host "🌐 Iniciando servidor FastAPI..." -ForegroundColor Green
Write-Host "URL: http://$Host`:$Port" -ForegroundColor Cyan
Write-Host "Documentação: http://$Host`:$Port/docs" -ForegroundColor Cyan
Write-Host "Health Check: http://$Host`:$Port/health" -ForegroundColor Cyan
Write-Host "" -ForegroundColor White
Write-Host "Para parar o servidor, pressione Ctrl+C" -ForegroundColor Yellow
Write-Host "================================================" -ForegroundColor Cyan

# Comando correto baseado no diretório atual
if ($Environment -eq "development") {
    # Para desenvolvimento com reload
    uvicorn main:app --host $Host --port $Port --reload --log-level debug --app-dir src
} else {
    # Para produção com múltiplos workers
    uvicorn main:app --host $Host --port $Port --workers 4 --app-dir src
}

