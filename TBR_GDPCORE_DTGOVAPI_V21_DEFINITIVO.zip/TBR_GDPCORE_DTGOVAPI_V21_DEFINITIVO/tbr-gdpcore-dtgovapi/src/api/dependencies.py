"""
Dependências para injeção no FastAPI
"""

from typing import Optional
from uuid import UUID

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from sqlalchemy.ext.asyncio import AsyncSession

from application.services import (
    DataContractService,
    EntityService,
    GovernanceService,
    IntegrationService,
    QualityService,
)
from config.settings import get_settings
from database.connection import get_db_session
from database.repositories import UserRepository

# Security
security = HTTPBearer()
settings = get_settings()


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    session: AsyncSession = Depends(get_db_session)
) -> Optional[dict]:
    """Obtém usuário atual a partir do token JWT"""
    
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        payload = jwt.decode(
            credentials.credentials,
            settings.secret_key,
            algorithms=[settings.algorithm]
        )
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    
    user_repo = UserRepository(session)
    user = await user_repo.get_by_username(username)
    
    if user is None:
        raise credentials_exception
    
    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "is_active": user.is_active,
        "is_superuser": user.is_superuser
    }


async def get_current_active_user(
    current_user: dict = Depends(get_current_user)
) -> dict:
    """Obtém usuário ativo atual"""
    if not current_user["is_active"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user"
        )
    return current_user


async def get_current_superuser(
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Obtém superusuário atual"""
    if not current_user["is_superuser"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    return current_user


# Service Dependencies
async def get_data_contract_service(
    session: AsyncSession = Depends(get_db_session)
) -> DataContractService:
    """Obtém serviço de contratos de dados"""
    return DataContractService(session)


async def get_entity_service(
    session: AsyncSession = Depends(get_db_session)
) -> EntityService:
    """Obtém serviço de entidades"""
    return EntityService(session)


async def get_quality_service(
    session: AsyncSession = Depends(get_db_session)
) -> QualityService:
    """Obtém serviço de qualidade"""
    return QualityService(session)


async def get_governance_service(
    session: AsyncSession = Depends(get_db_session)
) -> GovernanceService:
    """Obtém serviço de governança"""
    return GovernanceService(session)


async def get_integration_service(
    session: AsyncSession = Depends(get_db_session)
) -> IntegrationService:
    """Obtém serviço de integração"""
    return IntegrationService(session)


# Validation Dependencies
def validate_uuid(uuid_str: str) -> UUID:
    """Valida e converte string para UUID"""
    try:
        return UUID(uuid_str)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid UUID format: {uuid_str}"
        )


def validate_pagination(
    page: int = 1,
    size: int = 20,
    order_by: Optional[str] = None
) -> dict:
    """Valida parâmetros de paginação"""
    if page < 1:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Page must be greater than 0"
        )
    
    if size < 1 or size > 100:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Size must be between 1 and 100"
        )
    
    return {
        "page": page,
        "size": size,
        "order_by": order_by
    }

