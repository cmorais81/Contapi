"""
Database Layer - Persistência e modelos SQLAlchemy
"""

