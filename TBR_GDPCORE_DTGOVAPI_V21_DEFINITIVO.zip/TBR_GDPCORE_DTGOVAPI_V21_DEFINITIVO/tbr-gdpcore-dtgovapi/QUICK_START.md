# Quick Start - TBR GDP Core Data Governance API

**Projeto:** tbr-gdpcore-dtgovapi  
**Desenvolvido por:** Carlos Morais  
**Versão:** 2.1  

## 🚀 Início Rápido (Windows 11)

### Opção 1: Execução Simples (Recomendada)

**Se você está no diretório raiz do projeto:**
```powershell
# Ativar ambiente virtual
.venv\Scripts\Activate.ps1

# Executar aplicação
.\scripts\windows\run_simple.ps1
```

**Se você está dentro do diretório src/:**
```powershell
# Ativar ambiente virtual (se necessário)
..\.venv\Scripts\Activate.ps1

# Executar aplicação diretamente
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### Opção 2: Script Completo

```powershell
# Do diretório raiz do projeto
.\scripts\windows\run.ps1
```

## 🔧 Comandos Corretos por Situação

### Situação 1: Você está no diretório raiz (onde está a pasta src/)
```powershell
# Comando correto:
uvicorn main:app --host 0.0.0.0 --port 8000 --reload --app-dir src

# OU usar o script:
.\scripts\windows\run_simple.ps1
```

### Situação 2: Você está dentro da pasta src/
```powershell
# Comando correto:
uvicorn main:app --host 0.0.0.0 --port 8000 --reload

# NÃO usar: uvicorn src.main:app (isso causa o erro!)
```

## ❌ Erro Comum

**ERRO:**
```
ModuleNotFoundError: No module named 'src'
```

**CAUSA:**
Executar `uvicorn src.main:app` quando já está dentro do diretório `src/`

**SOLUÇÃO:**
- Se estiver em `src/`: use `uvicorn main:app`
- Se estiver na raiz: use `uvicorn main:app --app-dir src`

## 🌐 URLs Importantes

Após iniciar a aplicação:

- **Health Check:** http://localhost:8000/health
- **Documentação:** http://localhost:8000/docs
- **API Root:** http://localhost:8000/
- **Métricas:** http://localhost:8000/metrics
- **OpenAPI:** http://localhost:8000/openapi.json

## 🔍 Verificação Rápida

```powershell
# Testar se está funcionando
curl http://localhost:8000/health

# Resposta esperada:
# {"status":"healthy","timestamp":"...","version":"2.1.0","environment":"development","developer":"Carlos Morais"}
```

## 📋 Pré-requisitos

- Python 3.14+
- Ambiente virtual ativado
- Dependências instaladas (`pip install -r requirements.txt`)
- Arquivo `.env` configurado

## 🆘 Troubleshooting

### Problema: "No module named 'src'"
**Solução:** Verificar em qual diretório você está e usar o comando correto

### Problema: "ModuleNotFoundError: No module named 'fastapi'"
**Solução:** Ativar ambiente virtual e instalar dependências
```powershell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

### Problema: "Port already in use"
**Solução:** Usar porta diferente
```powershell
uvicorn main:app --host 0.0.0.0 --port 8001 --reload
```

---

**Desenvolvido por Carlos Morais - Janeiro 2025**

