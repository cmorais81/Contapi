"""
Testes de integração para API de contratos de dados
"""

import pytest
from httpx import AsyncClient
from unittest.mock import patch

from governance_api.application.dtos import DataContractCreateDTO, DataContractVersionCreateDTO


class TestDataContractsAPI:
    """Testes de integração para endpoints de contratos"""
    
    @pytest.mark.asyncio
    async def test_create_contract_success(
        self,
        test_client: AsyncClient,
        sample_contract_data: dict,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa criação de contrato com sucesso"""
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.post(
                "/api/v1/contracts/",
                json=sample_contract_data,
                headers=auth_headers
            )
        
        assert response.status_code == 201
        data = response.json()
        
        assert data["name"] == sample_contract_data["name"]
        assert data["description"] == sample_contract_data["description"]
        assert data["status"] == "draft"
        assert "id" in data
        assert "created_at" in data
        assert "updated_at" in data
    
    @pytest.mark.asyncio
    async def test_create_contract_invalid_data(
        self,
        test_client: AsyncClient,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa criação de contrato com dados inválidos"""
        
        invalid_data = {
            "name": "",  # Nome vazio
            "description": "Test description"
        }
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.post(
                "/api/v1/contracts/",
                json=invalid_data,
                headers=auth_headers
            )
        
        assert response.status_code == 422  # Validation error
    
    @pytest.mark.asyncio
    async def test_create_contract_unauthorized(
        self,
        test_client: AsyncClient,
        sample_contract_data: dict
    ):
        """Testa criação de contrato sem autenticação"""
        
        response = await test_client.post(
            "/api/v1/contracts/",
            json=sample_contract_data
        )
        
        assert response.status_code == 401
    
    @pytest.mark.asyncio
    async def test_list_contracts(
        self,
        test_client: AsyncClient,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa listagem de contratos"""
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.get(
                "/api/v1/contracts/",
                headers=auth_headers
            )
        
        assert response.status_code == 200
        data = response.json()
        
        assert "items" in data
        assert "total" in data
        assert "page" in data
        assert "size" in data
        assert "pages" in data
    
    @pytest.mark.asyncio
    async def test_list_contracts_with_filters(
        self,
        test_client: AsyncClient,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa listagem de contratos com filtros"""
        
        params = {
            "status": "active",
            "page": 1,
            "size": 10
        }
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.get(
                "/api/v1/contracts/",
                params=params,
                headers=auth_headers
            )
        
        assert response.status_code == 200
        data = response.json()
        assert data["page"] == 1
        assert data["size"] == 10
    
    @pytest.mark.asyncio
    async def test_get_contract_not_found(
        self,
        test_client: AsyncClient,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa busca de contrato inexistente"""
        
        fake_id = "123e4567-e89b-12d3-a456-426614174000"
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.get(
                f"/api/v1/contracts/{fake_id}",
                headers=auth_headers
            )
        
        assert response.status_code == 404
    
    @pytest.mark.asyncio
    async def test_update_contract(
        self,
        test_client: AsyncClient,
        test_contract,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa atualização de contrato"""
        
        update_data = {
            "name": "Updated Contract Name",
            "description": "Updated description"
        }
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.put(
                f"/api/v1/contracts/{test_contract.id}",
                json=update_data,
                headers=auth_headers
            )
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["name"] == update_data["name"]
        assert data["description"] == update_data["description"]
    
    @pytest.mark.asyncio
    async def test_delete_contract(
        self,
        test_client: AsyncClient,
        test_contract,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa deleção de contrato"""
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.delete(
                f"/api/v1/contracts/{test_contract.id}",
                headers=auth_headers
            )
        
        assert response.status_code == 204


class TestDataContractVersionsAPI:
    """Testes para endpoints de versões de contratos"""
    
    @pytest.mark.asyncio
    async def test_create_contract_version(
        self,
        test_client: AsyncClient,
        test_contract,
        sample_contract_version_data: dict,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa criação de versão de contrato"""
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.post(
                f"/api/v1/contracts/{test_contract.id}/versions",
                json=sample_contract_version_data,
                headers=auth_headers
            )
        
        assert response.status_code == 201
        data = response.json()
        
        assert data["version"] == sample_contract_version_data["version"]
        assert data["contract_id"] == str(test_contract.id)
        assert data["is_active"] is False  # Nova versão não é ativa por padrão
    
    @pytest.mark.asyncio
    async def test_activate_contract_version(
        self,
        test_client: AsyncClient,
        test_contract,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa ativação de versão de contrato"""
        
        version = "1.0.0"
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.post(
                f"/api/v1/contracts/{test_contract.id}/versions/{version}/activate",
                headers=auth_headers
            )
        
        # Como não temos versão criada, deve retornar 404
        assert response.status_code == 404
    
    @pytest.mark.asyncio
    async def test_export_contract_odcs(
        self,
        test_client: AsyncClient,
        test_contract,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa export ODCS de contrato"""
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.get(
                f"/api/v1/contracts/{test_contract.id}/odcs",
                headers=auth_headers
            )
        
        # Como não há versão ativa, deve retornar 404
        assert response.status_code == 404
    
    @pytest.mark.asyncio
    async def test_validate_contract(
        self,
        test_client: AsyncClient,
        test_contract,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa validação de contrato"""
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.post(
                f"/api/v1/contracts/{test_contract.id}/validate",
                headers=auth_headers
            )
        
        # Como não há versão ativa, deve retornar 404
        assert response.status_code == 404


class TestDataContractsBusinessRules:
    """Testes para regras de negócio de contratos"""
    
    @pytest.mark.asyncio
    async def test_duplicate_contract_name_in_domain(
        self,
        test_client: AsyncClient,
        test_contract,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa criação de contrato com nome duplicado no mesmo domínio"""
        
        duplicate_data = {
            "name": test_contract.name,
            "domain_id": str(test_contract.domain_id),
            "description": "Duplicate contract"
        }
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.post(
                "/api/v1/contracts/",
                json=duplicate_data,
                headers=auth_headers
            )
        
        assert response.status_code == 400
        data = response.json()
        assert "já existe contrato" in data["message"].lower()
    
    @pytest.mark.asyncio
    async def test_duplicate_unity_catalog_path(
        self,
        test_client: AsyncClient,
        test_contract,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa criação de contrato com Unity Catalog path duplicado"""
        
        duplicate_data = {
            "name": "Different Name",
            "unity_catalog_path": str(test_contract.unity_catalog_path),
            "description": "Contract with duplicate path"
        }
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.post(
                "/api/v1/contracts/",
                json=duplicate_data,
                headers=auth_headers
            )
        
        assert response.status_code == 400
        data = response.json()
        assert "já está em uso" in data["message"].lower()
    
    @pytest.mark.asyncio
    async def test_create_version_duplicate(
        self,
        test_client: AsyncClient,
        test_contract,
        sample_contract_version_data: dict,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa criação de versão duplicada"""
        
        # Primeiro, criar uma versão
        with patch('jose.jwt.decode', mock_jwt_decode):
            response1 = await test_client.post(
                f"/api/v1/contracts/{test_contract.id}/versions",
                json=sample_contract_version_data,
                headers=auth_headers
            )
        
        assert response1.status_code == 201
        
        # Tentar criar a mesma versão novamente
        with patch('jose.jwt.decode', mock_jwt_decode):
            response2 = await test_client.post(
                f"/api/v1/contracts/{test_contract.id}/versions",
                json=sample_contract_version_data,
                headers=auth_headers
            )
        
        assert response2.status_code == 400
        data = response2.json()
        assert "já existe" in data["message"].lower()


class TestDataContractsPerformance:
    """Testes de performance para API de contratos"""
    
    @pytest.mark.asyncio
    async def test_list_contracts_pagination_performance(
        self,
        test_client: AsyncClient,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa performance da paginação"""
        
        import time
        
        start_time = time.time()
        
        with patch('jose.jwt.decode', mock_jwt_decode):
            response = await test_client.get(
                "/api/v1/contracts/",
                params={"page": 1, "size": 100},
                headers=auth_headers
            )
        
        end_time = time.time()
        response_time = end_time - start_time
        
        assert response.status_code == 200
        assert response_time < 1.0  # Deve responder em menos de 1 segundo
    
    @pytest.mark.asyncio
    async def test_concurrent_contract_creation(
        self,
        test_client: AsyncClient,
        auth_headers: dict,
        mock_jwt_decode
    ):
        """Testa criação concorrente de contratos"""
        
        import asyncio
        
        async def create_contract(index: int):
            contract_data = {
                "name": f"Concurrent Contract {index}",
                "description": f"Contract created concurrently {index}"
            }
            
            with patch('jose.jwt.decode', mock_jwt_decode):
                response = await test_client.post(
                    "/api/v1/contracts/",
                    json=contract_data,
                    headers=auth_headers
                )
            
            return response
        
        # Criar 5 contratos concorrentemente
        tasks = [create_contract(i) for i in range(5)]
        responses = await asyncio.gather(*tasks)
        
        # Todos devem ter sucesso
        for response in responses:
            assert response.status_code == 201

