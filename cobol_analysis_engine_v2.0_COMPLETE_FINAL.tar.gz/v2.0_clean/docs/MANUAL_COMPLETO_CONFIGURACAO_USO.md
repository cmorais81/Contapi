# Manual Completo: Configuração e Uso - COBOL Analysis Engine v2.0

**Versão:** 2.0 - Documentação Enriquecida  
**Data:** Setembro 2025  
**Autor:** Equipe COBOL Analysis Engine  

---

## Índice

1. [Visão Geral](#visão-geral)
2. [Instalação e Configuração](#instalação-e-configuração)
3. [Configurações Avançadas](#configurações-avançadas)
4. [Modos de Execução](#modos-de-execução)
5. [Linha de Comando](#linha-de-comando)
6. [SDK para Notebooks](#sdk-para-notebooks)
7. [Configuração de Provedores de IA](#configuração-de-provedores-de-ia)
8. [Processamento em Lote](#processamento-em-lote)
9. [Personalização de Prompts](#personalização-de-prompts)
10. [Troubleshooting](#troubleshooting)
11. [Exemplos Práticos](#exemplos-práticos)

---

## Visão Geral

O COBOL Analysis Engine v2.0 é um sistema avançado de análise de código COBOL que oferece três modos de operação:

- **Traditional**: Análise estrutural básica e rápida
- **Multi-AI**: Análise com múltiplos provedores de IA
- **Enhanced**: Documentação enriquecida mostrando origem das informações

### Arquivos Suportados

- **Programas COBOL individuais** (`.cbl`, `.cob`, `.cobol`)
- **Arquivos fontes.txt** (múltiplos programas)
- **Arquivos BOOKS.txt** (copybooks)

---

## Instalação e Configuração

### Requisitos do Sistema

```bash
# Sistema Operacional
Ubuntu 22.04+ / Windows 10+ / macOS 12+

# Python
Python 3.11+

# Dependências
pip install -r requirements.txt
```

### Instalação Básica

```bash
# 1. Extrair o pacote
tar -xzf cobol_analysis_engine_v2.0_ENRICHED_FINAL.tar.gz
cd v2.0_clean

# 2. Instalar dependências
pip install -r requirements.txt

# 3. Configurar variáveis de ambiente (opcional)
export OPENAI_API_KEY="sua_chave_openai"
export COBOL_ANALYSIS_LOG_LEVEL="INFO"

# 4. Testar instalação
python main.py --help
```

### Estrutura de Diretórios

```
v2.0_clean/
├── main.py                 # Aplicação principal
├── config/
│   └── config.yaml        # Configurações do sistema
├── src/                   # Código fonte
│   ├── analyzers/         # Analisadores especializados
│   ├── core/             # Núcleo do sistema
│   ├── generators/       # Geradores de documentação
│   ├── providers/        # Provedores de IA
│   ├── prompts/          # Sistema de prompts
│   └── utils/            # Utilitários
├── examples/             # Exemplos de uso
├── docs/                 # Documentação
└── tests/               # Testes
```

---

## Configurações Avançadas

### Arquivo config.yaml

```yaml
# Configuração completa do sistema
system:
  version: "2.0"
  log_level: "INFO"
  max_concurrent_analyses: 5
  timeout_seconds: 300
  
# Configuração de análise
analysis:
  default_mode: "enhanced"
  enable_cross_validation: true
  enable_clarity_engine: true
  max_file_size_mb: 50
  
# Configuração de saída
output:
  format: "markdown"
  include_prompts: true
  include_raw_responses: true
  generate_pdf: false
  
# Provedores de IA
ai:
  default_provider: "openai"
  specialized_ais:
    structural:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.1
      max_tokens: 4000
    business:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.2
      max_tokens: 4000
    technical:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.1
      max_tokens: 4000
    data_model:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.1
      max_tokens: 4000
    quality:
      provider: "openai"
      model: "gpt-4-turbo"
      temperature: 0.2
      max_tokens: 4000

# Configuração OpenAI
openai:
  api_key: "${OPENAI_API_KEY}"
  model: "gpt-4-turbo"
  temperature: 0.1
  max_tokens: 4000
  timeout: 60
  retry_attempts: 3
  
# Configuração de logging
logging:
  level: "INFO"
  file: "logs/cobol_analysis.log"
  max_size_mb: 100
  backup_count: 5
  
# Configuração de cache
cache:
  enabled: true
  directory: "cache/"
  ttl_hours: 24
  max_size_mb: 1000
```

### Variáveis de Ambiente

```bash
# Chaves de API
export OPENAI_API_KEY="sk-..."
export ANTHROPIC_API_KEY="sk-ant-..."
export AZURE_OPENAI_KEY="..."

# Configurações do sistema
export COBOL_ANALYSIS_LOG_LEVEL="DEBUG"
export COBOL_ANALYSIS_MAX_WORKERS="10"
export COBOL_ANALYSIS_TIMEOUT="600"
export COBOL_ANALYSIS_CACHE_DIR="/tmp/cobol_cache"

# Configurações de proxy (se necessário)
export HTTP_PROXY="http://proxy.empresa.com:8080"
export HTTPS_PROXY="https://proxy.empresa.com:8080"
```

---

## Modos de Execução

### 1. Modo Traditional (Rápido)

```bash
# Análise básica sem IA
python main.py programa.cbl -m traditional -o output/

# Características:
# - Tempo: 1-3 segundos
# - Saída: 50-80 linhas
# - Foco: Estrutura e elementos básicos
```

### 2. Modo Multi-AI (Balanceado)

```bash
# Análise com múltiplos provedores de IA
python main.py programa.cbl -m multi_ai -o output/

# Características:
# - Tempo: 30-60 segundos
# - Saída: 100-200 linhas
# - Foco: Análise estrutural com insights de IA
```

### 3. Modo Enhanced (Completo)

```bash
# Documentação enriquecida com origem das informações
python main.py programa.cbl -m enhanced -o output/

# Características:
# - Tempo: 45-90 segundos
# - Saída: 200-400 linhas
# - Foco: Transparência total das fontes
```

---

## Linha de Comando

### Sintaxe Básica

```bash
python main.py <arquivo> [opções]
```

### Opções Disponíveis

```bash
# Arquivo de entrada
python main.py programa.cbl                    # Programa individual
python main.py fontes.txt                      # Múltiplos programas

# Modo de análise
-m, --mode {traditional,multi_ai,enhanced}     # Modo de análise
--mode enhanced                                 # Modo recomendado

# Diretório de saída
-o, --output DIR                               # Diretório de saída
--output /caminho/para/resultados/

# Copybooks
-b, --books ARQUIVO                            # Arquivo BOOKS.txt
--books copybooks/BOOKS.txt

# Configuração
-c, --config ARQUIVO                           # Arquivo de configuração
--config config/custom.yaml

# Logging
-v, --verbose                                  # Modo verboso
-q, --quiet                                    # Modo silencioso
--log-level {DEBUG,INFO,WARNING,ERROR}

# Formato de saída
--format {markdown,html,pdf}                   # Formato de saída
--no-prompts                                   # Não incluir prompts
--no-raw-responses                             # Não incluir respostas brutas

# Performance
--max-workers N                                # Máximo de workers paralelos
--timeout N                                    # Timeout em segundos
--no-cache                                     # Desabilitar cache
```

### Exemplos de Uso

```bash
# Análise simples
python main.py examples/LHAN0542_TESTE.cbl

# Análise completa com copybooks
python main.py examples/fontes.txt \
  --books examples/BOOKS.txt \
  --mode enhanced \
  --output resultados/ \
  --verbose

# Análise personalizada
python main.py programa.cbl \
  --mode multi_ai \
  --config config/producao.yaml \
  --format html \
  --max-workers 8 \
  --timeout 300

# Análise em lote silenciosa
python main.py fontes.txt \
  --mode enhanced \
  --quiet \
  --output /dados/analises/ \
  --no-prompts
```

---

## SDK para Notebooks

### Instalação do SDK

```python
# Importar o SDK
import sys
sys.path.append('/caminho/para/v2.0_clean')

from src.api.cobol_analyzer import COBOLAnalyzer
from src.config.config_loader import load_config
```

### Classe COBOLAnalyzer

```python
class COBOLAnalyzer:
    """SDK para uso em notebooks e scripts Python"""
    
    def __init__(self, config_path="config/config.yaml"):
        """Inicializa o analisador"""
        self.config = load_config(config_path)
        self.system = COBOLAnalysisSystem(config_path)
    
    def analyze_file(self, file_path, mode="enhanced", output_dir="output/"):
        """Analisa um arquivo COBOL"""
        
    def analyze_code(self, cobol_code, program_name, mode="enhanced"):
        """Analisa código COBOL diretamente"""
        
    def analyze_batch(self, fontes_path, books_path=None, mode="enhanced"):
        """Analisa múltiplos programas"""
        
    def get_analysis_summary(self, analysis_result):
        """Extrai resumo da análise"""
        
    def export_to_format(self, analysis_result, format="pdf"):
        """Exporta resultado para diferentes formatos"""
```

### Exemplos de Uso em Notebook

#### 1. Análise Básica

```python
# Célula 1: Configuração
from cobol_analyzer_sdk import COBOLAnalyzer
import pandas as pd

# Inicializar analisador
analyzer = COBOLAnalyzer()

# Célula 2: Análise de arquivo
result = analyzer.analyze_file(
    file_path="examples/LHAN0542_TESTE.cbl",
    mode="enhanced",
    output_dir="notebook_output/"
)

print(f"Status: {result['status']}")
print(f"Relatório: {result['report_path']}")

# Célula 3: Visualizar resumo
summary = analyzer.get_analysis_summary(result)
print("Resumo da Análise:")
for key, value in summary.items():
    print(f"- {key}: {value}")
```

#### 2. Análise de Código Direto

```python
# Célula 1: Código COBOL inline
cobol_code = """
IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE-NOTEBOOK.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CONTADOR PIC 9(3) VALUE ZEROS.

PROCEDURE DIVISION.
0000-PRINCIPAL SECTION.
    DISPLAY 'TESTE NOTEBOOK'.
    STOP RUN.
"""

# Célula 2: Análise
result = analyzer.analyze_code(
    cobol_code=cobol_code,
    program_name="TESTE-NOTEBOOK",
    mode="enhanced"
)

# Célula 3: Exibir resultado
from IPython.display import Markdown, display
display(Markdown(result['documentation']))
```

#### 3. Análise em Lote com Visualizações

```python
# Célula 1: Análise em lote
batch_results = analyzer.analyze_batch(
    fontes_path="examples/fontes.txt",
    books_path="examples/BOOKS.txt",
    mode="enhanced"
)

# Célula 2: Criar DataFrame dos resultados
df_results = pd.DataFrame([
    {
        'Programa': r['program'],
        'Status': r['status'],
        'Linhas': r.get('lines_count', 0),
        'Complexidade': r.get('complexity_score', 0)
    }
    for r in batch_results
])

display(df_results)

# Célula 3: Visualizações
import matplotlib.pyplot as plt
import seaborn as sns

# Gráfico de status
plt.figure(figsize=(10, 6))
sns.countplot(data=df_results, x='Status')
plt.title('Status das Análises')
plt.show()

# Gráfico de complexidade
plt.figure(figsize=(10, 6))
sns.barplot(data=df_results, x='Programa', y='Complexidade')
plt.xticks(rotation=45)
plt.title('Complexidade por Programa')
plt.tight_layout()
plt.show()
```

#### 4. Análise Comparativa

```python
# Célula 1: Análise com diferentes modos
programa = "examples/LHAN0542_TESTE.cbl"

results = {}
for mode in ['traditional', 'multi_ai', 'enhanced']:
    results[mode] = analyzer.analyze_file(
        file_path=programa,
        mode=mode,
        output_dir=f"comparison_{mode}/"
    )

# Célula 2: Comparar resultados
comparison_df = pd.DataFrame([
    {
        'Modo': mode,
        'Tempo (s)': result.get('execution_time', 0),
        'Linhas': result.get('output_lines', 0),
        'Tamanho (KB)': result.get('file_size_kb', 0)
    }
    for mode, result in results.items()
])

display(comparison_df)

# Célula 3: Gráfico comparativo
fig, axes = plt.subplots(1, 3, figsize=(15, 5))

comparison_df.plot(x='Modo', y='Tempo (s)', kind='bar', ax=axes[0])
comparison_df.plot(x='Modo', y='Linhas', kind='bar', ax=axes[1])
comparison_df.plot(x='Modo', y='Tamanho (KB)', kind='bar', ax=axes[2])

plt.tight_layout()
plt.show()
```

#### 5. Análise Interativa com Widgets

```python
# Célula 1: Importar widgets
import ipywidgets as widgets
from IPython.display import display, clear_output

# Célula 2: Interface interativa
def analyze_interactive():
    # Widgets
    file_upload = widgets.FileUpload(
        accept='.cbl,.cob,.cobol',
        multiple=False,
        description='Upload COBOL'
    )
    
    mode_dropdown = widgets.Dropdown(
        options=['traditional', 'multi_ai', 'enhanced'],
        value='enhanced',
        description='Modo:'
    )
    
    analyze_button = widgets.Button(
        description='Analisar',
        button_style='success'
    )
    
    output_area = widgets.Output()
    
    def on_analyze_click(b):
        with output_area:
            clear_output()
            if file_upload.value:
                # Salvar arquivo temporário
                content = file_upload.value[0]['content']
                with open('temp_program.cbl', 'wb') as f:
                    f.write(content)
                
                # Analisar
                result = analyzer.analyze_file(
                    file_path='temp_program.cbl',
                    mode=mode_dropdown.value
                )
                
                print(f"✅ Análise concluída!")
                print(f"📄 Relatório: {result['report_path']}")
                
                # Exibir resumo
                summary = analyzer.get_analysis_summary(result)
                for key, value in summary.items():
                    print(f"- {key}: {value}")
    
    analyze_button.on_click(on_analyze_click)
    
    # Layout
    display(widgets.VBox([
        widgets.HBox([file_upload, mode_dropdown]),
        analyze_button,
        output_area
    ]))

# Célula 3: Executar interface
analyze_interactive()
```

### SDK Avançado

#### Configuração Personalizada

```python
# Configuração customizada
custom_config = {
    'ai': {
        'default_provider': 'openai',
        'specialized_ais': {
            'structural': {
                'provider': 'openai',
                'model': 'gpt-4-turbo',
                'temperature': 0.1
            }
        }
    },
    'output': {
        'include_prompts': True,
        'include_raw_responses': True
    }
}

analyzer = COBOLAnalyzer(custom_config=custom_config)
```

#### Análise com Callbacks

```python
def progress_callback(step, total, message):
    print(f"[{step}/{total}] {message}")

def result_callback(program_name, result):
    print(f"✅ {program_name}: {result['status']}")

# Análise com callbacks
analyzer.analyze_batch(
    fontes_path="fontes.txt",
    progress_callback=progress_callback,
    result_callback=result_callback
)
```

#### Exportação Avançada

```python
# Exportar para múltiplos formatos
result = analyzer.analyze_file("programa.cbl")

# PDF
analyzer.export_to_format(result, format="pdf", 
                         output_path="relatorio.pdf")

# HTML interativo
analyzer.export_to_format(result, format="html", 
                         output_path="relatorio.html",
                         include_charts=True)

# JSON estruturado
analyzer.export_to_format(result, format="json", 
                         output_path="dados.json")

# Excel com múltiplas abas
analyzer.export_to_format(result, format="excel", 
                         output_path="analise.xlsx",
                         include_summary=True)
```

---

## Configuração de Provedores de IA

### OpenAI

```yaml
openai:
  api_key: "${OPENAI_API_KEY}"
  model: "gpt-4-turbo"
  temperature: 0.1
  max_tokens: 4000
  timeout: 60
  retry_attempts: 3
  base_url: "https://api.openai.com/v1"  # Opcional
```

```python
# Configuração programática
analyzer.configure_provider('openai', {
    'api_key': 'sk-...',
    'model': 'gpt-4-turbo',
    'temperature': 0.1
})
```

### Azure OpenAI

```yaml
azure_openai:
  api_key: "${AZURE_OPENAI_KEY}"
  endpoint: "https://sua-instancia.openai.azure.com/"
  deployment_name: "gpt-4-turbo"
  api_version: "2024-02-15-preview"
```

### Anthropic Claude

```yaml
anthropic:
  api_key: "${ANTHROPIC_API_KEY}"
  model: "claude-3-sonnet-20240229"
  max_tokens: 4000
  temperature: 0.1
```

### Configuração Multi-Provider

```yaml
ai:
  providers:
    - name: "openai_primary"
      type: "openai"
      config:
        model: "gpt-4-turbo"
        temperature: 0.1
    - name: "claude_secondary"
      type: "anthropic"
      config:
        model: "claude-3-sonnet"
        temperature: 0.1
  
  routing:
    structural: "openai_primary"
    business: "claude_secondary"
    technical: "openai_primary"
    data_model: "openai_primary"
    quality: "claude_secondary"
```

---

## Processamento em Lote

### Formato do fontes.txt

```
VMEMBER NAME  LHAN0542
V      IDENTIFICATION                  DIVISION.
V      PROGRAM-ID.                     LHAN0542.
V      [... código do programa ...]
VMEMBER NAME  LHAN0705
V      IDENTIFICATION                  DIVISION.
V      PROGRAM-ID.                     LHAN0705.
V      [... código do programa ...]
```

### Formato do BOOKS.txt

```
MEMBER NAME  LHCP3402
       01  LHCP3402-LAYOUT.
           05  CAMPO1          PIC X(10).
           05  CAMPO2          PIC 9(5).
MEMBER NAME  LHCE0700
       01  LHCE0700-LAYOUT.
           05  OUTRO-CAMPO     PIC X(20).
```

### Processamento Avançado

```bash
# Processamento com filtros
python main.py fontes.txt \
  --books BOOKS.txt \
  --mode enhanced \
  --filter-programs "LH*" \
  --exclude-programs "*TEST*" \
  --max-programs 10

# Processamento paralelo
python main.py fontes.txt \
  --mode multi_ai \
  --max-workers 8 \
  --batch-size 5

# Processamento incremental
python main.py fontes.txt \
  --mode enhanced \
  --incremental \
  --cache-dir cache/
```

### Monitoramento de Progresso

```python
# Em notebook
from tqdm.notebook import tqdm

def progress_callback(current, total, program_name):
    progress_bar.update(1)
    progress_bar.set_description(f"Processando {program_name}")

progress_bar = tqdm(total=total_programs)
analyzer.analyze_batch(
    fontes_path="fontes.txt",
    progress_callback=progress_callback
)
progress_bar.close()
```

---

## Personalização de Prompts

### Sistema de Prompts

```python
# Customizar prompts
from src.prompts.luzia_prompts import LuziaPromptGenerator

generator = LuziaPromptGenerator()

# Prompt personalizado para análise de negócio
custom_business_prompt = """
Analise este programa COBOL focando especificamente em:
1. Regras de compliance bancário
2. Validações de dados financeiros
3. Controles de auditoria
4. Processamento de transações

Código:
{cobol_code}

Contexto do sistema: {system_context}
"""

generator.set_custom_prompt('business', custom_business_prompt)
```

### Templates de Prompts

```yaml
# config/prompts.yaml
prompts:
  structural:
    template: |
      Analise a estrutura do programa COBOL:
      {cobol_code}
      
      Foque em: {focus_areas}
      Contexto: {context}
    
    focus_areas:
      - "Organização das divisões"
      - "Modularização"
      - "Padrões de nomenclatura"
  
  business:
    template: |
      Extraia regras de negócio do programa:
      {cobol_code}
      
      Considere: {business_context}
    
    business_context:
      - "Validações críticas"
      - "Fluxos de processamento"
      - "Controles de qualidade"
```

### Prompts Condicionais

```python
# Prompts baseados no contexto
def get_contextual_prompt(program_name, system_type):
    if system_type == "banking":
        return banking_compliance_prompt
    elif system_type == "insurance":
        return insurance_regulatory_prompt
    else:
        return generic_business_prompt

# Configurar no analisador
analyzer.set_prompt_selector(get_contextual_prompt)
```

---

## Troubleshooting

### Problemas Comuns

#### 1. Erro de API Key

```bash
# Erro
Error: OpenAI API key not found

# Solução
export OPENAI_API_KEY="sk-..."
# ou
echo 'OPENAI_API_KEY=sk-...' >> .env
```

#### 2. Timeout de Análise

```bash
# Erro
TimeoutError: Analysis timed out after 300 seconds

# Solução
python main.py programa.cbl --timeout 600
# ou no config.yaml
system:
  timeout_seconds: 600
```

#### 3. Memória Insuficiente

```bash
# Erro
MemoryError: Unable to allocate memory

# Solução
python main.py fontes.txt --max-workers 2 --batch-size 1
```

#### 4. Arquivo Muito Grande

```bash
# Erro
FileSizeError: File exceeds maximum size

# Solução
# Dividir arquivo ou aumentar limite
system:
  max_file_size_mb: 100
```

### Logs de Debug

```bash
# Habilitar logs detalhados
python main.py programa.cbl --log-level DEBUG

# Logs em arquivo
python main.py programa.cbl --log-file debug.log

# Logs estruturados
export COBOL_ANALYSIS_LOG_FORMAT="json"
```

### Validação de Configuração

```python
# Validar configuração
from src.config.config_validator import validate_config

config = load_config("config.yaml")
validation_result = validate_config(config)

if not validation_result.is_valid:
    for error in validation_result.errors:
        print(f"❌ {error}")
else:
    print("✅ Configuração válida")
```

---

## Exemplos Práticos

### 1. Análise de Sistema Bancário

```bash
# Análise completa de sistema bancário
python main.py sistema_bancario/fontes.txt \
  --books sistema_bancario/BOOKS.txt \
  --mode enhanced \
  --output relatorios_banco/ \
  --config config/banking.yaml \
  --filter-programs "LH*,BR*" \
  --verbose
```

### 2. Migração de Sistema Legacy

```python
# Notebook para migração
analyzer = COBOLAnalyzer(config_path="config/migration.yaml")

# Analisar todos os programas
migration_results = analyzer.analyze_batch(
    fontes_path="legacy_system/fontes.txt",
    books_path="legacy_system/BOOKS.txt",
    mode="enhanced"
)

# Gerar relatório de migração
migration_report = analyzer.generate_migration_report(migration_results)
analyzer.export_to_format(migration_report, format="pdf", 
                         output_path="migration_analysis.pdf")
```

### 3. Auditoria de Código

```bash
# Auditoria completa
python main.py auditoria/fontes.txt \
  --mode enhanced \
  --config config/audit.yaml \
  --output auditoria_resultados/ \
  --include-quality-metrics \
  --include-security-analysis \
  --generate-compliance-report
```

### 4. Documentação de API

```python
# Gerar documentação de APIs COBOL
api_analyzer = COBOLAnalyzer(config_path="config/api_documentation.yaml")

for program in cobol_api_programs:
    result = api_analyzer.analyze_file(
        file_path=program,
        mode="enhanced",
        focus="api_documentation"
    )
    
    # Gerar documentação OpenAPI
    openapi_spec = api_analyzer.generate_openapi_spec(result)
    with open(f"{program}_api.yaml", "w") as f:
        yaml.dump(openapi_spec, f)
```

### 5. Análise de Performance

```python
# Análise de performance
performance_config = {
    'analysis': {
        'focus_areas': ['performance', 'optimization', 'bottlenecks'],
        'include_metrics': True
    }
}

analyzer = COBOLAnalyzer(custom_config=performance_config)

# Analisar programas críticos
critical_programs = ["BATCH_PROCESSOR.cbl", "TRANSACTION_HANDLER.cbl"]

for program in critical_programs:
    result = analyzer.analyze_file(program, mode="enhanced")
    
    # Extrair métricas de performance
    metrics = analyzer.extract_performance_metrics(result)
    print(f"{program}: {metrics}")
```

---

## Conclusão

Este manual fornece uma visão completa de todas as possibilidades de configuração e uso do COBOL Analysis Engine v2.0. O sistema oferece flexibilidade máxima para diferentes cenários de uso, desde análises simples até processamentos complexos em lote com múltiplos provedores de IA.

### Recursos Principais

- **Três modos de análise** para diferentes necessidades
- **SDK completo** para integração em notebooks e scripts
- **Configuração flexível** via YAML e variáveis de ambiente
- **Processamento em lote** otimizado para grandes volumes
- **Personalização de prompts** para contextos específicos
- **Múltiplos formatos de saída** (Markdown, HTML, PDF, JSON, Excel)
- **Monitoramento e logging** avançados
- **Troubleshooting** abrangente

### Próximos Passos

1. **Instalar** o sistema seguindo as instruções
2. **Configurar** os provedores de IA necessários
3. **Testar** com os exemplos fornecidos
4. **Personalizar** para suas necessidades específicas
5. **Integrar** em seus workflows existentes

Para suporte adicional, consulte a documentação técnica ou entre em contato com a equipe de desenvolvimento.

---

**Versão do Manual:** 2.0  
**Última Atualização:** Setembro 2025  
**Compatibilidade:** COBOL Analysis Engine v2.0+
