"""
Parser de Layout de Registros COBOL
Extrai estrutura detalhada dos registros com posições, tamanhos e tipos
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass

@dataclass
class FieldDefinition:
    """Definição de um campo no registro COBOL"""
    name: str
    level: int
    start_position: int
    length: int
    data_type: str
    picture_clause: str
    occurs: Optional[int] = None
    redefines: Optional[str] = None
    value: Optional[str] = None
    usage: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'level': self.level,
            'start_position': self.start_position,
            'length': self.length,
            'data_type': self.data_type,
            'picture_clause': self.picture_clause,
            'occurs': self.occurs,
            'redefines': self.redefines,
            'value': self.value,
            'usage': self.usage
        }

class RecordLayoutParser:
    """Parser especializado em extrair layouts de registros COBOL"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões regex para identificar definições de campos
        self.field_pattern = re.compile(
            r'^\s*(\d{2})\s+([A-Z0-9\-_]+)(?:\s+REDEFINES\s+([A-Z0-9\-_]+))?\s*'
            r'(?:PIC\s+([X9SVZ\(\)\.\-\+]+))?\s*'
            r'(?:OCCURS\s+(\d+))?\s*'
            r'(?:USAGE\s+([A-Z\-]+))?\s*'
            r'(?:VALUE\s+([\'"][^\'\"]*[\'"]|\d+))?\s*\.?\s*$',
            re.IGNORECASE
        )
        
        # Padrões para diferentes tipos de PIC
        self.pic_patterns = {
            'numeric': re.compile(r'^9+(\((\d+)\))?$'),
            'decimal': re.compile(r'^9+(\((\d+)\))?V9+(\((\d+)\))?$'),
            'signed_numeric': re.compile(r'^S9+(\((\d+)\))?$'),
            'signed_decimal': re.compile(r'^S9+(\((\d+)\))?V9+(\((\d+)\))?$'),
            'alphanumeric': re.compile(r'^X+(\((\d+)\))?$'),
            'alphabetic': re.compile(r'^A+(\((\d+)\))?$'),
            'edited_numeric': re.compile(r'^[9Z\.\,\-\+\$]+$'),
        }
    
    def parse_record_layouts(self, cobol_code: str) -> Dict[str, List[FieldDefinition]]:
        """
        Extrai todos os layouts de registros do código COBOL
        
        Args:
            cobol_code: Código COBOL completo
            
        Returns:
            Dict com nome do registro e lista de campos
        """
        self.logger.info("Iniciando extração de layouts de registros")
        
        layouts = {}
        lines = cobol_code.split('\n')
        current_record = None
        current_fields = []
        current_position = 1
        in_data_division = False
        
        for line_num, line in enumerate(lines, 1):
            # Detectar DATA DIVISION
            if 'DATA DIVISION' in line.upper():
                in_data_division = True
                continue
                
            # Detectar PROCEDURE DIVISION (fim da área de dados)
            if 'PROCEDURE DIVISION' in line.upper():
                in_data_division = False
                # Salvar último registro se existir
                if current_record and current_fields:
                    layouts[current_record] = current_fields.copy()
                break
            
            # Só processar se estiver na DATA DIVISION
            if not in_data_division:
                continue
            
            # Remover comentários e linhas vazias
            clean_line = line.strip()
            if not clean_line or clean_line.startswith('*') or clean_line.startswith('/'):
                continue
            
            # Identificar início de novo registro (nível 01)
            if self._is_record_definition(line):
                # Salvar registro anterior se existir
                if current_record and current_fields:
                    layouts[current_record] = current_fields.copy()
                
                # Iniciar novo registro
                current_record = self._extract_record_name(line)
                current_fields = []
                current_position = 1
                self.logger.debug(f"Novo registro encontrado: {current_record}")
                
                # Adicionar o próprio registro nível 01
                field = self._parse_field_definition(line, current_position)
                if field:
                    current_fields.append(field)
                    current_position += field.length
                continue
            
            # Processar campos do registro atual
            if current_record:
                field = self._parse_field_definition(line, current_position)
                if field:
                    current_fields.append(field)
                    # Atualizar posição para próximo campo
                    if field.level > 1 and field.data_type != "group":  # Só contar campos elementares
                        current_position += field.length
                    self.logger.debug(f"Campo adicionado: {field.name} (pos: {field.start_position}, len: {field.length})")
        
        # Salvar último registro
        if current_record and current_fields:
            layouts[current_record] = current_fields.copy()
        
        self.logger.info(f"Layouts extraídos: {len(layouts)} registros, {sum(len(fields) for fields in layouts.values())} campos")
        return layouts
    
    def _is_record_definition(self, line: str) -> bool:
        """Verifica se a linha define um registro (nível 01)"""
        stripped = line.strip()
        return bool(re.match(r'^\s*01\s+[A-Z0-9\-_]+', stripped, re.IGNORECASE))
    
    def _extract_record_name(self, line: str) -> str:
        """Extrai o nome do registro da linha de definição"""
        match = re.search(r'^\s*01\s+([A-Z0-9\-_]+)', line.strip(), re.IGNORECASE)
        return match.group(1) if match else "UNKNOWN_RECORD"
    
    def _parse_field_definition(self, line: str, current_position: int) -> Optional[FieldDefinition]:
        """
        Analisa uma linha e extrai definição de campo se presente
        
        Args:
            line: Linha do código COBOL
            current_position: Posição atual no registro
            
        Returns:
            FieldDefinition se campo válido encontrado, None caso contrário
        """
        stripped = line.strip()
        if not stripped or stripped.startswith('*'):
            return None
        
        # Tentar match com padrão de campo
        match = self.field_pattern.match(stripped)
        if not match:
            return None
        
        level = int(match.group(1))
        name = match.group(2)
        redefines = match.group(3)
        pic_clause = match.group(4)
        occurs = int(match.group(5)) if match.group(5) else None
        usage = match.group(6)
        value = match.group(7)
        
        # Determinar tipo e tamanho do campo
        if pic_clause:
            data_type, length = self._analyze_picture_clause(pic_clause)
        else:
            # Campo de grupo (sem PIC)
            data_type = "group"
            length = 0
        
        # Aplicar OCCURS se presente
        if occurs:
            length *= occurs
        
        # Ajustar posição para REDEFINES
        start_pos = current_position
        if redefines:
            # REDEFINES usa a mesma posição do campo redefinido
            # Por simplicidade, mantemos a posição atual
            pass
        
        return FieldDefinition(
            name=name,
            level=level,
            start_position=start_pos,
            length=length,
            data_type=data_type,
            picture_clause=pic_clause or "",
            occurs=occurs,
            redefines=redefines,
            value=value,
            usage=usage
        )
    
    def _analyze_picture_clause(self, pic_clause: str) -> Tuple[str, int]:
        """
        Analisa cláusula PIC e determina tipo e tamanho
        
        Args:
            pic_clause: Cláusula PIC (ex: X(10), 9(5)V99, S9(7)COMP-3)
            
        Returns:
            Tupla (tipo_de_dados, tamanho_em_bytes)
        """
        pic_clean = pic_clause.upper().strip()
        
        # Numeric patterns
        if self.pic_patterns['signed_decimal'].match(pic_clean):
            return "signed_decimal", self._calculate_pic_length(pic_clean)
        elif self.pic_patterns['decimal'].match(pic_clean):
            return "decimal", self._calculate_pic_length(pic_clean)
        elif self.pic_patterns['signed_numeric'].match(pic_clean):
            return "signed_numeric", self._calculate_pic_length(pic_clean)
        elif self.pic_patterns['numeric'].match(pic_clean):
            return "numeric", self._calculate_pic_length(pic_clean)
        elif self.pic_patterns['alphanumeric'].match(pic_clean):
            return "alphanumeric", self._calculate_pic_length(pic_clean)
        elif self.pic_patterns['alphabetic'].match(pic_clean):
            return "alphabetic", self._calculate_pic_length(pic_clean)
        elif self.pic_patterns['edited_numeric'].match(pic_clean):
            return "edited_numeric", self._calculate_pic_length(pic_clean)
        else:
            return "unknown", self._calculate_pic_length(pic_clean)
    
    def _calculate_pic_length(self, pic_clause: str) -> int:
        """
        Calcula o tamanho em bytes de uma cláusula PIC
        
        Args:
            pic_clause: Cláusula PIC
            
        Returns:
            Tamanho em bytes
        """
        pic_clean = pic_clause.upper().strip()
        total_length = 0
        
        # Padrão para extrair repetições: X(10), 9(5), etc.
        repeat_pattern = re.compile(r'([X9AVSZ\.\,\-\+\$])(\((\d+)\))?')
        
        for match in repeat_pattern.finditer(pic_clean):
            char = match.group(1)
            repeat_count = int(match.group(3)) if match.group(3) else 1
            
            if char in ['X', 'A', '9', 'Z']:
                total_length += repeat_count
            elif char == 'V':
                # V não ocupa espaço (ponto decimal implícito)
                pass
            elif char in ['.', ',', '-', '+', '$']:
                total_length += repeat_count
        
        # Se não encontrou padrões, contar caracteres diretamente
        if total_length == 0:
            # Remover parênteses e contar caracteres significativos
            clean_pic = re.sub(r'[()]', '', pic_clean)
            total_length = len(clean_pic)
        
        return max(total_length, 1)  # Mínimo 1 byte
    
    def generate_layout_documentation(self, layouts: Dict[str, List[FieldDefinition]]) -> str:
        """
        Gera documentação formatada dos layouts de registros
        
        Args:
            layouts: Dicionário com layouts extraídos
            
        Returns:
            String com documentação formatada
        """
        doc = "## Layouts de Registros Detalhados\n\n"
        
        for record_name, fields in layouts.items():
            doc += f"### {record_name}\n\n"
            doc += "| Campo | Nível | Posição | Tamanho | Tipo | PIC | Observações |\n"
            doc += "|-------|-------|---------|---------|------|-----|-------------|\n"
            
            for field in fields:
                observations = []
                if field.occurs:
                    observations.append(f"OCCURS {field.occurs}")
                if field.redefines:
                    observations.append(f"REDEFINES {field.redefines}")
                if field.value:
                    observations.append(f"VALUE {field.value}")
                if field.usage:
                    observations.append(f"USAGE {field.usage}")
                
                obs_text = ", ".join(observations) if observations else "-"
                
                doc += f"| {field.name} | {field.level:02d} | {field.start_position} | {field.length} | {field.data_type} | {field.picture_clause} | {obs_text} |\n"
            
            doc += "\n"
        
        return doc
    
    def get_field_mapping_for_language(self, layouts: Dict[str, List[FieldDefinition]], target_language: str) -> Dict[str, str]:
        """
        Gera mapeamento de campos COBOL para linguagem alvo
        
        Args:
            layouts: Layouts extraídos
            target_language: Linguagem alvo (java, python, csharp)
            
        Returns:
            Dicionário com mapeamento de tipos
        """
        type_mappings = {
            'java': {
                'numeric': 'int',
                'signed_numeric': 'int',
                'decimal': 'BigDecimal',
                'signed_decimal': 'BigDecimal',
                'alphanumeric': 'String',
                'alphabetic': 'String',
                'edited_numeric': 'String',
                'group': 'Object',
                'unknown': 'String'
            },
            'python': {
                'numeric': 'int',
                'signed_numeric': 'int',
                'decimal': 'Decimal',
                'signed_decimal': 'Decimal',
                'alphanumeric': 'str',
                'alphabetic': 'str',
                'edited_numeric': 'str',
                'group': 'dict',
                'unknown': 'str'
            },
            'csharp': {
                'numeric': 'int',
                'signed_numeric': 'int',
                'decimal': 'decimal',
                'signed_decimal': 'decimal',
                'alphanumeric': 'string',
                'alphabetic': 'string',
                'edited_numeric': 'string',
                'group': 'object',
                'unknown': 'string'
            }
        }
        
        mappings = type_mappings.get(target_language.lower(), type_mappings['java'])
        result = {}
        
        for record_name, fields in layouts.items():
            for field in fields:
                cobol_type = field.data_type
                target_type = mappings.get(cobol_type, 'String')
                result[f"{record_name}.{field.name}"] = target_type
        
        return result
