"""
Analisador de Fluxo de Dados para Programas COBOL
Mapeia relacionamentos entre arquivos, transformações e critérios de roteamento
"""

import re
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

@dataclass
class FileDefinition:
    """Representa a definição de um arquivo"""
    name: str
    type: str  # 'input', 'output', 'input-output'
    record_size: int
    record_format: str
    usage_pattern: str
    related_copybooks: List[str]

@dataclass
class DataTransformation:
    """Representa uma transformação de dados"""
    source_field: str
    target_field: str
    transformation_type: str  # 'move', 'calculate', 'format', 'validate'
    transformation_rule: str
    location: str

@dataclass
class RoutingCriteria:
    """Representa critérios de roteamento de dados"""
    decision_field: str
    criteria_type: str  # 'value_based', 'range_based', 'condition_based'
    routing_rules: Dict[str, str]  # valor -> destino
    default_action: str

@dataclass
class DataFlow:
    """Representa um fluxo completo de dados"""
    flow_name: str
    source: str
    destination: str
    data_volume: str
    processing_logic: str
    transformations: List[DataTransformation]
    conditions: List[str]

class COBOLDataFlowAnalyzer:
    """Analisador especializado em fluxo de dados COBOL"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões para identificar definições de arquivos
        self.file_patterns = {
            'select': r'SELECT\s+(\w+)\s+ASSIGN\s+TO\s+([\w\-]+)',
            'fd': r'FD\s+(\w+)',
            'record_size': r'RECORD\s+CONTAINS\s+(\d+)\s+CHARACTERS',
            'block_size': r'BLOCK\s+CONTAINS\s+(\d+)\s+RECORDS',
            'label_records': r'LABEL\s+RECORDS\s+ARE\s+(\w+)'
        }
        
        # Padrões para operações de I/O
        self.io_patterns = {
            'open_input': r'OPEN\s+INPUT\s+(\w+)',
            'open_output': r'OPEN\s+OUTPUT\s+(\w+)',
            'open_io': r'OPEN\s+I-O\s+(\w+)',
            'read': r'READ\s+(\w+)',
            'write': r'WRITE\s+(\w+)',
            'close': r'CLOSE\s+(\w+)'
        }
        
        # Padrões para transformações de dados
        self.transformation_patterns = {
            'move': r'MOVE\s+([\w\-\(\):]+)\s+TO\s+([\w\-\(\):]+)',
            'compute': r'COMPUTE\s+(\w+)\s+=\s+(.*)',
            'add': r'ADD\s+([\w\d]+)\s+TO\s+(\w+)',
            'subtract': r'SUBTRACT\s+([\w\d]+)\s+FROM\s+(\w+)',
            'multiply': r'MULTIPLY\s+(\w+)\s+BY\s+(\w+)',
            'divide': r'DIVIDE\s+(\w+)\s+INTO\s+(\w+)',
            'string': r'STRING\s+(.*)\s+INTO\s+(\w+)',
            'unstring': r'UNSTRING\s+(\w+)\s+.*\s+INTO\s+(.*)'
        }
        
        # Padrões para critérios de roteamento
        self.routing_patterns = {
            'evaluate': r'EVALUATE\s+(\w+)',
            'when_value': r'WHEN\s+[\'\"]([\w\d]+)[\'\"]\s*',
            'when_range': r'WHEN\s+(\d+)\s+THRU\s+(\d+)',
            'when_condition': r'WHEN\s+(.*)',
            'if_condition': r'IF\s+(.*)\s+THEN',
            'perform_section': r'PERFORM\s+(\d+\-[\w\-]+)'
        }

    def analyze_file_definitions(self, cobol_code: str) -> List[FileDefinition]:
        """Analisa definições de arquivos no programa"""
        
        files = []
        lines = cobol_code.split('\n')
        current_file = None
        
        for i, line in enumerate(lines):
            line = line.strip()
            
            # Identificar SELECT statements
            select_match = re.search(self.file_patterns['select'], line, re.IGNORECASE)
            if select_match:
                file_name = select_match.group(1)
                assign_name = select_match.group(2)
                
                # Determinar tipo baseado no uso
                file_type = self._determine_file_type(file_name, lines)
                
                current_file = {
                    'name': file_name,
                    'assign_name': assign_name,
                    'type': file_type,
                    'record_size': 0,
                    'record_format': 'FIXED',
                    'usage_pattern': '',
                    'related_copybooks': []
                }
            
            # Identificar FD statements e detalhes
            if current_file:
                fd_match = re.search(self.file_patterns['fd'], line, re.IGNORECASE)
                if fd_match and fd_match.group(1) == current_file['name']:
                    # Processar linhas seguintes para detalhes do arquivo
                    for j in range(i + 1, min(i + 10, len(lines))):
                        detail_line = lines[j].strip()
                        
                        # Tamanho do registro
                        size_match = re.search(self.file_patterns['record_size'], detail_line, re.IGNORECASE)
                        if size_match:
                            current_file['record_size'] = int(size_match.group(1))
                        
                        # Se chegou em outro FD ou 01, finalizar arquivo atual
                        if (detail_line.startswith('FD ') or 
                            detail_line.startswith('01 ') or
                            'WORKING-STORAGE' in detail_line):
                            break
                    
                    # Adicionar arquivo à lista
                    files.append(FileDefinition(
                        name=current_file['name'],
                        type=current_file['type'],
                        record_size=current_file['record_size'],
                        record_format=current_file['record_format'],
                        usage_pattern=self._analyze_usage_pattern(current_file['name'], lines),
                        related_copybooks=self._find_related_copybooks(current_file['name'], lines)
                    ))
                    current_file = None
        
        return files

    def analyze_data_transformations(self, cobol_code: str) -> List[DataTransformation]:
        """Analisa transformações de dados no programa"""
        
        transformations = []
        lines = cobol_code.split('\n')
        
        for i, line in enumerate(lines):
            line = line.strip()
            
            # Analisar cada tipo de transformação
            for trans_type, pattern in self.transformation_patterns.items():
                matches = re.finditer(pattern, line, re.IGNORECASE)
                for match in matches:
                    transformation = self._create_transformation(
                        trans_type, match, line, i + 1
                    )
                    if transformation:
                        transformations.append(transformation)
        
        return transformations

    def analyze_routing_criteria(self, cobol_code: str) -> List[RoutingCriteria]:
        """Analisa critérios de roteamento de dados"""
        
        routing_criteria = []
        lines = cobol_code.split('\n')
        
        for i, line in enumerate(lines):
            line = line.strip()
            
            # Identificar blocos EVALUATE
            evaluate_match = re.search(self.routing_patterns['evaluate'], line, re.IGNORECASE)
            if evaluate_match:
                criteria = self._analyze_evaluate_block(lines, i, evaluate_match.group(1))
                if criteria:
                    routing_criteria.append(criteria)
            
            # Identificar blocos IF complexos para roteamento
            if_match = re.search(self.routing_patterns['if_condition'], line, re.IGNORECASE)
            if if_match and self._is_routing_if(line):
                criteria = self._analyze_if_routing(lines, i, if_match.group(1))
                if criteria:
                    routing_criteria.append(criteria)
        
        return routing_criteria

    def map_data_flows(self, cobol_code: str) -> List[DataFlow]:
        """Mapeia fluxos completos de dados"""
        
        files = self.analyze_file_definitions(cobol_code)
        transformations = self.analyze_data_transformations(cobol_code)
        routing_criteria = self.analyze_routing_criteria(cobol_code)
        
        flows = []
        
        # Mapear fluxos principais baseado nos arquivos
        input_files = [f for f in files if f.type == 'input']
        output_files = [f for f in files if f.type == 'output']
        
        for input_file in input_files:
            for output_file in output_files:
                flow = self._create_data_flow(
                    input_file, output_file, transformations, routing_criteria, cobol_code
                )
                if flow:
                    flows.append(flow)
        
        return flows

    def _determine_file_type(self, file_name: str, lines: List[str]) -> str:
        """Determina o tipo de arquivo baseado no uso"""
        
        has_read = False
        has_write = False
        
        for line in lines:
            if f'READ {file_name}' in line.upper():
                has_read = True
            if f'WRITE {file_name}' in line.upper() or f'WRITE REG-{file_name}' in line.upper():
                has_write = True
            if f'OPEN INPUT {file_name}' in line.upper():
                has_read = True
            if f'OPEN OUTPUT {file_name}' in line.upper():
                has_write = True
        
        if has_read and has_write:
            return 'input-output'
        elif has_read:
            return 'input'
        elif has_write:
            return 'output'
        else:
            return 'unknown'

    def _analyze_usage_pattern(self, file_name: str, lines: List[str]) -> str:
        """Analisa padrão de uso do arquivo"""
        
        patterns = []
        
        for line in lines:
            line_upper = line.upper()
            if file_name.upper() in line_upper:
                if 'READ' in line_upper:
                    patterns.append('sequential_read')
                if 'WRITE' in line_upper:
                    patterns.append('sequential_write')
                if 'AT END' in line_upper:
                    patterns.append('end_of_file_processing')
                if 'PERFORM UNTIL' in line_upper:
                    patterns.append('loop_processing')
        
        return ', '.join(set(patterns)) if patterns else 'basic_io'

    def _find_related_copybooks(self, file_name: str, lines: List[str]) -> List[str]:
        """Encontra copybooks relacionados ao arquivo"""
        
        copybooks = []
        
        for line in lines:
            if 'COPY' in line.upper() and file_name.upper() in line.upper():
                copy_match = re.search(r'COPY\s+(\w+)', line, re.IGNORECASE)
                if copy_match:
                    copybooks.append(copy_match.group(1))
        
        return copybooks

    def _create_transformation(self, trans_type: str, match, line: str, line_number: int) -> Optional[DataTransformation]:
        """Cria objeto de transformação baseado no padrão encontrado"""
        
        transformation_rules = {
            'move': f"Copia valor de {match.group(1)} para {match.group(2)}",
            'compute': f"Calcula {match.group(2)} e armazena em {match.group(1)}",
            'add': f"Adiciona {match.group(1)} ao valor de {match.group(2)}",
            'subtract': f"Subtrai {match.group(1)} do valor de {match.group(2)}",
            'multiply': f"Multiplica {match.group(1)} por {match.group(2)}",
            'divide': f"Divide {match.group(1)} por {match.group(2)}",
            'string': f"Concatena campos em {match.group(2)}",
            'unstring': f"Separa {match.group(1)} em campos individuais"
        }
        
        if len(match.groups()) >= 2:
            return DataTransformation(
                source_field=match.group(1),
                target_field=match.group(2) if len(match.groups()) >= 2 else match.group(1),
                transformation_type=trans_type,
                transformation_rule=transformation_rules.get(trans_type, f"Transformação {trans_type}"),
                location=f"Linha {line_number}: {line.strip()}"
            )
        
        return None

    def _analyze_evaluate_block(self, lines: List[str], start_index: int, evaluate_var: str) -> Optional[RoutingCriteria]:
        """Analisa um bloco EVALUATE para extrair critérios de roteamento"""
        
        routing_rules = {}
        default_action = "Nenhuma ação definida"
        
        i = start_index + 1
        while i < len(lines) and 'END-EVALUATE' not in lines[i].upper():
            line = lines[i].strip()
            
            # Identificar WHEN com valor
            when_match = re.search(self.routing_patterns['when_value'], line, re.IGNORECASE)
            if when_match:
                value = when_match.group(1)
                
                # Encontrar ação correspondente
                action_lines = []
                j = i + 1
                while (j < len(lines) and 
                       not lines[j].strip().startswith('WHEN') and 
                       'END-EVALUATE' not in lines[j].upper()):
                    if lines[j].strip():
                        action_lines.append(lines[j].strip())
                    j += 1
                
                if action_lines:
                    routing_rules[value] = '; '.join(action_lines)
            
            # Identificar WHEN OTHER
            if 'WHEN OTHER' in line.upper():
                action_lines = []
                j = i + 1
                while j < len(lines) and 'END-EVALUATE' not in lines[j].upper():
                    if lines[j].strip():
                        action_lines.append(lines[j].strip())
                    j += 1
                
                if action_lines:
                    default_action = '; '.join(action_lines)
            
            i += 1
        
        if routing_rules:
            return RoutingCriteria(
                decision_field=evaluate_var,
                criteria_type='value_based',
                routing_rules=routing_rules,
                default_action=default_action
            )
        
        return None

    def _is_routing_if(self, line: str) -> bool:
        """Verifica se um IF é usado para roteamento"""
        
        routing_keywords = ['PERFORM', 'WRITE', 'MOVE', 'CALL']
        return any(keyword in line.upper() for keyword in routing_keywords)

    def _analyze_if_routing(self, lines: List[str], start_index: int, condition: str) -> Optional[RoutingCriteria]:
        """Analisa um bloco IF para extrair critérios de roteamento"""
        
        # Simplificado - apenas captura a condição principal
        routing_rules = {
            'true': "Ação quando condição verdadeira",
            'false': "Ação quando condição falsa"
        }
        
        return RoutingCriteria(
            decision_field=condition.split()[0] if condition.split() else 'unknown',
            criteria_type='condition_based',
            routing_rules=routing_rules,
            default_action="Continua processamento normal"
        )

    def _create_data_flow(self, input_file: FileDefinition, output_file: FileDefinition, 
                         transformations: List[DataTransformation], 
                         routing_criteria: List[RoutingCriteria],
                         cobol_code: str) -> Optional[DataFlow]:
        """Cria um fluxo de dados entre arquivos"""
        
        # Encontrar transformações relevantes
        relevant_transformations = []
        for trans in transformations:
            if (input_file.name.upper() in trans.source_field.upper() or
                output_file.name.upper() in trans.target_field.upper()):
                relevant_transformations.append(trans)
        
        # Encontrar critérios de roteamento relevantes
        relevant_conditions = []
        for criteria in routing_criteria:
            if any(output_file.name.upper() in action.upper() 
                  for action in criteria.routing_rules.values()):
                relevant_conditions.append(f"Roteamento baseado em {criteria.decision_field}")
        
        # Estimar volume de dados
        data_volume = self._estimate_data_volume(input_file, output_file, cobol_code)
        
        # Gerar lógica de processamento
        processing_logic = self._generate_processing_logic(
            input_file, output_file, relevant_transformations, routing_criteria
        )
        
        return DataFlow(
            flow_name=f"{input_file.name} → {output_file.name}",
            source=input_file.name,
            destination=output_file.name,
            data_volume=data_volume,
            processing_logic=processing_logic,
            transformations=relevant_transformations,
            conditions=relevant_conditions
        )

    def _estimate_data_volume(self, input_file: FileDefinition, output_file: FileDefinition, cobol_code: str) -> str:
        """Estima volume de dados baseado em constantes no código"""
        
        # Procurar por constantes de limite
        max_records_match = re.search(r'(\w+)\s+PIC\s+9\(\d+\)\s+VALUE\s+(\d+)', cobol_code)
        if max_records_match and 'MAX' in max_records_match.group(1).upper():
            return f"Máximo {max_records_match.group(2)} registros por arquivo"
        
        # Estimativa baseada no tamanho do registro
        if input_file.record_size > 0:
            return f"Registros de {input_file.record_size} caracteres"
        
        return "Volume não especificado"

    def _generate_processing_logic(self, input_file: FileDefinition, output_file: FileDefinition,
                                 transformations: List[DataTransformation],
                                 routing_criteria: List[RoutingCriteria]) -> str:
        """Gera descrição da lógica de processamento"""
        
        logic_parts = []
        
        # Leitura
        logic_parts.append(f"Lê registros de {input_file.name}")
        
        # Transformações
        if transformations:
            logic_parts.append(f"Aplica {len(transformations)} transformações")
        
        # Roteamento
        if routing_criteria:
            logic_parts.append("Aplica critérios de roteamento")
        
        # Escrita
        logic_parts.append(f"Grava em {output_file.name}")
        
        return " → ".join(logic_parts)

    def generate_data_flow_documentation(self, cobol_code: str) -> Dict:
        """Gera documentação completa de fluxo de dados"""
        
        self.logger.info("Iniciando análise de fluxo de dados")
        
        # Analisar componentes
        files = self.analyze_file_definitions(cobol_code)
        transformations = self.analyze_data_transformations(cobol_code)
        routing_criteria = self.analyze_routing_criteria(cobol_code)
        data_flows = self.map_data_flows(cobol_code)
        
        # Organizar documentação
        documentation = {
            'file_definitions': [
                {
                    'name': f.name,
                    'type': f.type,
                    'record_size': f.record_size,
                    'usage_pattern': f.usage_pattern,
                    'related_copybooks': f.related_copybooks
                } for f in files
            ],
            'data_transformations': [
                {
                    'source': t.source_field,
                    'target': t.target_field,
                    'type': t.transformation_type,
                    'rule': t.transformation_rule,
                    'location': t.location
                } for t in transformations
            ],
            'routing_criteria': [
                {
                    'decision_field': r.decision_field,
                    'type': r.criteria_type,
                    'rules': r.routing_rules,
                    'default_action': r.default_action
                } for r in routing_criteria
            ],
            'data_flows': [
                {
                    'name': f.flow_name,
                    'source': f.source,
                    'destination': f.destination,
                    'volume': f.data_volume,
                    'logic': f.processing_logic,
                    'transformations_count': len(f.transformations),
                    'conditions': f.conditions
                } for f in data_flows
            ],
            'summary': {
                'total_files': len(files),
                'input_files': len([f for f in files if f.type == 'input']),
                'output_files': len([f for f in files if f.type == 'output']),
                'total_transformations': len(transformations),
                'routing_criteria_count': len(routing_criteria),
                'data_flows_count': len(data_flows)
            }
        }
        
        self.logger.info(f"Análise concluída: {len(files)} arquivos, {len(transformations)} transformações")
        
        return documentation
