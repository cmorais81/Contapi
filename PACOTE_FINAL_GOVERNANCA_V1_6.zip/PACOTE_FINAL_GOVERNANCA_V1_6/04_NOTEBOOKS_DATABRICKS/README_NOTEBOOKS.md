# Notebooks Databricks para API de Governança de Dados

**Desenvolvido por:** Carlos Morais  
**Versão:** 2.1  
**Data:** Junho 2025

## 📋 Índice

1. [Visão Geral](#visão-geral)
2. [Mapa Mental da Arquitetura](#mapa-mental-da-arquitetura)
3. [Método Ivy Lee - Priorização](#método-ivy-lee---priorização)
4. [Método GTD - Organização Completa](#método-gtd---organização-completa)
5. [Notebooks Disponíveis](#notebooks-disponíveis)
6. [Configuração e Setup](#configuração-e-setup)
7. [Execução e Monitoramento](#execução-e-monitoramento)
8. [Troubleshooting](#troubleshooting)

---

## 🎯 Visão Geral

Este projeto fornece dois notebooks Databricks especializados para extrair dados de diferentes fontes e alimentar o modelo de governança de dados baseado no ODCS v3.0.2 com 56 tabelas:

### 📊 **Notebook 1: Unity Catalog Extractor**
- **Arquivo:** `notebook_unity_catalog_extractor.py`
- **Objetivo:** Extrair metadados e dados do Unity Catalog
- **Cobertura:** Catálogos, schemas, tabelas, colunas, lineage, métricas de uso

### 🔷 **Notebook 2: Azure SPN Extractor**
- **Arquivo:** `notebook_azure_spn_extractor.py`
- **Objetivo:** Extrair dados dos serviços Azure via Service Principal
- **Cobertura:** Data Factory, Synapse, Storage, SQL Database, Monitor

### 🎯 **Resultado Final**
- Alimentação automática da API de Governança de Dados
- Mapeamento para 56 tabelas do modelo ODCS v3.0.2
- Integração completa com pipeline de dados

---


## 🧠 Mapa Mental da Arquitetura

```
                    🎯 API GOVERNANÇA DE DADOS (56 TABELAS)
                                    │
                    ┌───────────────┼───────────────┐
                    │               │               │
            📊 UNITY CATALOG    🔷 AZURE SPN    🏗️ MODELO ODCS
                    │               │               │
        ┌───────────┼───────────┐   │   ┌───────────┼───────────┐
        │           │           │   │   │           │           │
    📁 CATALOGS  📋 SCHEMAS  📊 TABLES │ 🏭 ADF   💾 STORAGE  🗄️ SQL
        │           │           │   │   │           │           │
    ┌───┼───┐   ┌───┼───┐   ┌───┼───┐ │ ┌─┼─┐   ┌───┼───┐   ┌───┼───┐
    │   │   │   │   │   │   │   │   │ │ │ │ │   │   │   │   │   │   │
   C1  C2  C3  S1  S2  S3  T1  T2  T3 │ P D L   A1  A2  A3  D1  D2  D3
                    │           │     │ │ │ │   │   │   │   │   │   │
                ┌───┼───┐   ┌───┼───┐ │ │ │ │   │   │   │   │   │   │
                │   │   │   │   │   │ │ │ │ │   │   │   │   │   │   │
               COL1 COL2 COL3 M1  M2  M3│ │ │ │   │   │   │   │   │   │
                                       │ │ │ │   │   │   │   │   │   │
                    🔗 LINEAGE         │ │ │ │   │   │   │   │   │   │
                    📈 METRICS         │ │ │ │   │   │   │   │   │   │
                    🏷️ TAGS            │ │ │ │   │   │   │   │   │   │
                                       │ │ │ │   │   │   │   │   │   │
                    ┌──────────────────┘ │ │ │   │   │   │   │   │   │
                    │                    │ │ │   │   │   │   │   │   │
            🔄 SYNAPSE ANALYTICS         │ │ │   │   │   │   │   │   │
                    │                    │ │ │   │   │   │   │   │   │
        ┌───────────┼───────────┐        │ │ │   │   │   │   │   │   │
        │           │           │        │ │ │   │   │   │   │   │   │
    🏢 WORKSPACES 🏊 SQL POOLS 🔥 SPARK  │ │ │   │   │   │   │   │   │
                                         │ │ │   │   │   │   │   │   │
                    📈 AZURE MONITOR ────┘ │ │   │   │   │   │   │   │
                                           │ │   │   │   │   │   │   │
                    LEGENDA:               │ │   │   │   │   │   │   │
                    ────────               │ │   │   │   │   │   │   │
                    C = Catalog            │ │   │   │   │   │   │   │
                    S = Schema             │ │   │   │   │   │   │   │
                    T = Table              │ │   │   │   │   │   │   │
                    COL = Column           │ │   │   │   │   │   │   │
                    M = Metric             │ │   │   │   │   │   │   │
                    P = Pipeline           │ │   │   │   │   │   │   │
                    D = Dataset            │ │   │   │   │   │   │   │
                    L = Linked Service     │ │   │   │   │   │   │   │
                    A = Storage Account    │ │   │   │   │   │   │   │
                    D = Database           │ │   │   │   │   │   │   │
                                           │ │   │   │   │   │   │   │
            🎯 FLUXO DE DADOS:             │ │   │   │   │   │   │   │
            ──────────────────             │ │   │   │   │   │   │   │
                                           │ │   │   │   │   │   │   │
    1. 📊 EXTRAÇÃO ──────────────────────┐ │ │   │   │   │   │   │   │
       │                                 │ │ │   │   │   │   │   │   │
       ├─ Unity Catalog Metadata        │ │ │   │   │   │   │   │   │
       ├─ Azure Services Data           │ │ │   │   │   │   │   │   │
       └─ Usage Metrics & Lineage      │ │ │   │   │   │   │   │   │
                                        │ │ │   │   │   │   │   │   │
    2. 🔄 TRANSFORMAÇÃO ────────────────┐│ │ │   │   │   │   │   │   │
       │                                ││ │ │   │   │   │   │   │   │
       ├─ Mapeamento para ODCS v3.0.2   ││ │ │   │   │   │   │   │   │
       ├─ Normalização de Dados         ││ │ │   │   │   │   │   │   │
       └─ Enriquecimento com Contexto   ││ │ │   │   │   │   │   │   │
                                        ││ │ │   │   │   │   │   │   │
    3. 📤 CARREGAMENTO ─────────────────┐││ │ │   │   │   │   │   │   │
       │                                │││ │ │   │   │   │   │   │   │
       ├─ API Governança (56 tabelas)   │││ │ │   │   │   │   │   │   │
       ├─ Validação de Integridade      │││ │ │   │   │   │   │   │   │
       └─ Logs de Auditoria             │││ │ │   │   │   │   │   │   │
                                        │││ │ │   │   │   │   │   │   │
    4. 📊 GOVERNANÇA ──────────────────┐│││ │ │   │   │   │   │   │   │
       │                               ││││ │ │   │   │   │   │   │   │
       ├─ Contratos de Dados           ││││ │ │   │   │   │   │   │   │
       ├─ Qualidade de Dados           ││││ │ │   │   │   │   │   │   │
       ├─ Lineage e Relacionamentos    ││││ │ │   │   │   │   │   │   │
       ├─ Classificação e Tags         ││││ │ │   │   │   │   │   │   │
       └─ Políticas de Acesso          ││││ │ │   │   │   │   │   │   │
                                       ││││ │ │   │   │   │   │   │   │
                                       ││││ │ │   │   │   │   │   │   │
    🔧 COMPONENTES TÉCNICOS:           ││││ │ │   │   │   │   │   │   │
    ────────────────────────           ││││ │ │   │   │   │   │   │   │
                                       ││││ │ │   │   │   │   │   │   │
    ┌─ 🔐 AUTENTICAÇÃO ──────────────┐ ││││ │ │   │   │   │   │   │   │
    │  ├─ Azure SPN                  │ ││││ │ │   │   │   │   │   │   │
    │  ├─ Databricks Secrets        │ ││││ │ │   │   │   │   │   │   │
    │  └─ API Tokens                 │ ││││ │ │   │   │   │   │   │   │
    └────────────────────────────────┘ ││││ │ │   │   │   │   │   │   │
                                       ││││ │ │   │   │   │   │   │   │
    ┌─ 📊 PROCESSAMENTO ─────────────┐ ││││ │ │   │   │   │   │   │   │
    │  ├─ PySpark                    │ ││││ │ │   │   │   │   │   │   │
    │  ├─ Pandas                     │ ││││ │ │   │   │   │   │   │   │
    │  └─ Azure SDK                  │ ││││ │ │   │   │   │   │   │   │
    └────────────────────────────────┘ ││││ │ │   │   │   │   │   │   │
                                       ││││ │ │   │   │   │   │   │   │
    ┌─ 🔄 ORQUESTRAÇÃO ─────────────┐ ││││ │ │   │   │   │   │   │   │
    │  ├─ Databricks Jobs            │ ││││ │ │   │   │   │   │   │   │
    │  ├─ Scheduling (Cron)          │ ││││ │ │   │   │   │   │   │   │
    │  └─ Error Handling             │ ││││ │ │   │   │   │   │   │   │
    └────────────────────────────────┘ ││││ │ │   │   │   │   │   │   │
                                       ││││ │ │   │   │   │   │   │   │
    ┌─ 📈 MONITORAMENTO ────────────┐ ││││ │ │   │   │   │   │   │   │
    │  ├─ Logs Estruturados         │ ││││ │ │   │   │   │   │   │   │
    │  ├─ Métricas de Performance   │ ││││ │ │   │   │   │   │   │   │
    │  └─ Alertas e Notificações    │ ││││ │ │   │   │   │   │   │   │
    └────────────────────────────────┘ ││││ │ │   │   │   │   │   │   │
```

### 🎯 **Pontos-Chave da Arquitetura:**

1. **📊 Fonte de Dados Dupla:** Unity Catalog + Azure Services
2. **🔄 Processamento Paralelo:** Notebooks independentes e complementares
3. **🎯 Destino Unificado:** API de Governança com 56 tabelas
4. **🔗 Integração Completa:** Lineage, métricas e relacionamentos
5. **🔐 Segurança:** Autenticação via SPN e secrets management
6. **📈 Monitoramento:** Logs, métricas e alertas integrados

---


## 📋 Método Ivy Lee - Priorização

O **Método Ivy Lee** foca nas 6 tarefas mais importantes do dia. Aplicado ao projeto de notebooks de governança de dados:

### 🎯 **AS 6 TAREFAS MAIS IMPORTANTES (Por Ordem de Prioridade)**

#### **1. 🔐 CONFIGURAR AUTENTICAÇÃO E SECRETS**
**⏱️ Tempo Estimado:** 30 minutos  
**🎯 Objetivo:** Garantir acesso seguro aos sistemas  
**📋 Ações:**
- Criar Service Principal no Azure AD
- Configurar permissões necessárias (Reader, Contributor)
- Adicionar secrets no Databricks (azure scope, governance scope)
- Testar conectividade com Unity Catalog e Azure APIs

**✅ Critério de Sucesso:** Notebooks executam sem erros de autenticação

---

#### **2. 📊 EXECUTAR NOTEBOOK UNITY CATALOG**
**⏱️ Tempo Estimado:** 45 minutos  
**🎯 Objetivo:** Extrair metadados completos do Unity Catalog  
**📋 Ações:**
- Executar `notebook_unity_catalog_extractor.py`
- Validar extração de catálogos, schemas e tabelas
- Verificar mapeamento para modelo de governança
- Confirmar envio para API de Governança

**✅ Critério de Sucesso:** Dados Unity Catalog carregados na API (domains, entities, attributes)

---

#### **3. 🔷 EXECUTAR NOTEBOOK AZURE SPN**
**⏱️ Tempo Estimado:** 60 minutos  
**🎯 Objetivo:** Extrair dados dos serviços Azure  
**📋 Ações:**
- Executar `notebook_azure_spn_extractor.py`
- Validar extração de Data Factory, Synapse, Storage, SQL
- Verificar métricas do Azure Monitor
- Confirmar integração com API de Governança

**✅ Critério de Sucesso:** Dados Azure carregados na API (pipelines, datasets, métricas)

---

#### **4. 🔍 VALIDAR INTEGRIDADE DOS DADOS**
**⏱️ Tempo Estimado:** 30 minutos  
**🎯 Objetivo:** Garantir qualidade e consistência  
**📋 Ações:**
- Verificar contagem de registros nas 56 tabelas
- Validar relacionamentos e foreign keys
- Confirmar lineage e métricas de uso
- Testar endpoints da API de Governança

**✅ Critério de Sucesso:** Todas as tabelas populadas corretamente, API respondendo

---

#### **5. ⏰ CONFIGURAR AGENDAMENTO AUTOMÁTICO**
**⏱️ Tempo Estimado:** 20 minutos  
**🎯 Objetivo:** Automatizar execução dos notebooks  
**📋 Ações:**
- Criar jobs no Databricks para ambos notebooks
- Configurar schedule (Unity Catalog: diário 2h, Azure: diário 3h)
- Definir alertas para falhas
- Testar execução agendada

**✅ Critério de Sucesso:** Jobs executando automaticamente sem intervenção

---

#### **6. 📊 CRIAR DASHBOARD DE MONITORAMENTO**
**⏱️ Tempo Estimado:** 40 minutos  
**🎯 Objetivo:** Visibilidade operacional completa  
**📋 Ações:**
- Configurar métricas de execução dos notebooks
- Criar alertas para falhas e anomalias
- Dashboard com status de sincronização
- Relatórios de qualidade de dados

**✅ Critério de Sucesso:** Dashboard operacional com métricas em tempo real

---

### 🎯 **REGRAS DO MÉTODO IVY LEE:**

1. **📝 Foque apenas nestas 6 tarefas** - Não adicione mais até completar
2. **🔢 Execute na ordem de prioridade** - Não pule para a próxima sem terminar
3. **⏰ Dedique tempo total a cada tarefa** - Sem multitasking
4. **✅ Complete antes de avançar** - Critério de sucesso deve ser atingido
5. **🔄 Revise diariamente** - Ajuste prioridades conforme necessário
6. **📊 Meça resultados** - Acompanhe tempo real vs estimado

### 📈 **CRONOGRAMA SUGERIDO:**

```
DIA 1 (3h 45min):
├─ 09:00-09:30 → Tarefa 1: Configurar Autenticação
├─ 09:30-10:15 → Tarefa 2: Notebook Unity Catalog
├─ 10:15-10:30 → ☕ Break
├─ 10:30-11:30 → Tarefa 3: Notebook Azure SPN
├─ 11:30-12:00 → Tarefa 4: Validar Integridade
├─ 12:00-13:00 → 🍽️ Almoço
├─ 13:00-13:20 → Tarefa 5: Configurar Agendamento
└─ 13:20-14:00 → Tarefa 6: Dashboard Monitoramento
```

### 🎯 **BENEFÍCIOS ESPERADOS:**

- **⚡ Foco Total:** Uma tarefa por vez, máxima eficiência
- **🎯 Resultados Claros:** Critérios objetivos de sucesso
- **📊 Progresso Visível:** Acompanhamento em tempo real
- **🔄 Melhoria Contínua:** Ajustes baseados em resultados
- **✅ Entrega Garantida:** Priorização elimina desperdício

---


## 🗂️ Método GTD - Organização Completa

O **Getting Things Done (GTD)** organiza todo o projeto em um sistema completo de produtividade. Aplicado aos notebooks de governança de dados:

### 📥 **1. CAPTURA (INBOX)**

Todas as ideias, tarefas e informações relacionadas ao projeto:

```
📥 INBOX - ITENS CAPTURADOS:
├─ 🔐 Configurar Service Principal Azure
├─ 📊 Testar conectividade Unity Catalog
├─ 🔷 Validar permissões Azure APIs
├─ 📋 Documentar processo de setup
├─ ⚡ Otimizar performance dos notebooks
├─ 🔍 Implementar validação de dados
├─ 📈 Criar métricas de monitoramento
├─ 🚨 Configurar alertas de falha
├─ 📊 Dashboard de governança
├─ 🔄 Processo de backup e recovery
├─ 📚 Treinamento da equipe
├─ 🧪 Testes de carga
├─ 🔒 Auditoria de segurança
├─ 📝 Documentação técnica
└─ 🎯 Roadmap de melhorias
```

### 🤔 **2. ESCLARECER (CLARIFY)**

Processamento de cada item do inbox:

#### **🔐 Configurar Service Principal Azure**
- **❓ É acionável?** ✅ Sim
- **⏱️ Leva menos de 2 min?** ❌ Não (30 min)
- **🎯 Qual o resultado desejado?** SPN configurado com permissões corretas
- **🚀 Próxima ação?** Acessar Azure Portal e criar SPN

#### **📊 Testar conectividade Unity Catalog**
- **❓ É acionável?** ✅ Sim
- **⏱️ Leva menos de 2 min?** ❌ Não (15 min)
- **🎯 Qual o resultado desejado?** Notebook executa sem erros de conexão
- **🚀 Próxima ação?** Executar células de teste no notebook

#### **🔷 Validar permissões Azure APIs**
- **❓ É acionável?** ✅ Sim
- **⏱️ Leva menos de 2 min?** ❌ Não (20 min)
- **🎯 Qual o resultado desejado?** Todas as APIs Azure acessíveis
- **🚀 Próxima ação?** Testar cada cliente Azure no notebook

### 📋 **3. ORGANIZAR (ORGANIZE)**

#### **🎯 PROJETOS (Resultados com múltiplas ações)**

##### **📊 PROJETO 1: Setup Inicial dos Notebooks**
**🎯 Resultado:** Notebooks funcionando e extraindo dados  
**📅 Prazo:** 1 dia  
**📋 Próximas Ações:**
1. Criar Service Principal no Azure AD
2. Configurar permissões (Reader, Contributor, etc.)
3. Adicionar secrets no Databricks
4. Testar conectividade Unity Catalog
5. Testar conectividade Azure APIs
6. Executar notebooks completos
7. Validar dados na API de Governança

##### **🔄 PROJETO 2: Automação e Agendamento**
**🎯 Resultado:** Execução automática sem intervenção  
**📅 Prazo:** 2 dias  
**📋 Próximas Ações:**
1. Criar jobs no Databricks
2. Configurar schedules (cron expressions)
3. Definir dependências entre jobs
4. Configurar retry policies
5. Testar execução agendada
6. Validar logs e métricas

##### **📈 PROJETO 3: Monitoramento e Alertas**
**🎯 Resultado:** Visibilidade operacional completa  
**📅 Prazo:** 3 dias  
**📋 Próximas Ações:**
1. Configurar logging estruturado
2. Criar métricas de performance
3. Implementar health checks
4. Configurar alertas (email, Slack)
5. Dashboard de monitoramento
6. Relatórios de qualidade

##### **🔒 PROJETO 4: Segurança e Compliance**
**🎯 Resultado:** Ambiente seguro e auditável  
**📅 Prazo:** 2 dias  
**📋 Próximas Ações:**
1. Auditoria de permissões
2. Implementar logs de auditoria
3. Configurar backup de secrets
4. Documentar procedimentos de segurança
5. Teste de disaster recovery
6. Compliance check

#### **📅 CALENDÁRIO (Ações com data específica)**

```
📅 SEGUNDA-FEIRA:
├─ 09:00 → Criar Service Principal Azure
├─ 10:00 → Configurar secrets Databricks
├─ 11:00 → Testar notebook Unity Catalog
├─ 14:00 → Testar notebook Azure SPN
└─ 16:00 → Validar dados na API

📅 TERÇA-FEIRA:
├─ 09:00 → Criar jobs Databricks
├─ 10:00 → Configurar schedules
├─ 11:00 → Testar automação
├─ 14:00 → Configurar alertas
└─ 16:00 → Dashboard inicial

📅 QUARTA-FEIRA:
├─ 09:00 → Implementar logging
├─ 10:00 → Métricas de performance
├─ 11:00 → Health checks
├─ 14:00 → Finalizar dashboard
└─ 16:00 → Testes de carga

📅 QUINTA-FEIRA:
├─ 09:00 → Auditoria de segurança
├─ 10:00 → Backup procedures
├─ 11:00 → Disaster recovery test
├─ 14:00 → Documentação final
└─ 16:00 → Treinamento equipe

📅 SEXTA-FEIRA:
├─ 09:00 → Review semanal
├─ 10:00 → Ajustes finais
├─ 11:00 → Deploy produção
├─ 14:00 → Monitoramento pós-deploy
└─ 16:00 → Retrospectiva
```

#### **📋 PRÓXIMAS AÇÕES (Por Contexto)**

##### **💻 @DATABRICKS**
- [ ] Criar workspace secrets (azure, governance)
- [ ] Configurar jobs para notebooks
- [ ] Testar execução agendada
- [ ] Configurar cluster policies
- [ ] Implementar logging estruturado

##### **🔷 @AZURE**
- [ ] Criar Service Principal
- [ ] Configurar permissões IAM
- [ ] Testar APIs (ADF, Synapse, Storage, SQL)
- [ ] Validar Azure Monitor access
- [ ] Configurar Key Vault

##### **🖥️ @API_GOVERNANCA**
- [ ] Testar endpoints de criação
- [ ] Validar schema de dados
- [ ] Configurar rate limiting
- [ ] Testar batch operations
- [ ] Verificar logs de auditoria

##### **📞 @CALLS**
- [ ] Reunião com equipe de segurança
- [ ] Alinhamento com arquitetos de dados
- [ ] Review com stakeholders
- [ ] Treinamento da equipe operacional

##### **📧 @EMAIL**
- [ ] Solicitar permissões Azure
- [ ] Comunicar cronograma para stakeholders
- [ ] Documentar procedimentos
- [ ] Compartilhar relatórios de progresso

#### **⏳ AGUARDANDO (WAITING FOR)**

```
⏳ AGUARDANDO RESPOSTAS:
├─ 🔐 Aprovação de permissões Azure (Equipe Segurança)
├─ 📊 Acesso ao Unity Catalog produção (Equipe Dados)
├─ 🔷 Configuração de rede (Equipe Infraestrutura)
├─ 📋 Review de documentação (Arquiteto de Dados)
└─ ✅ Aprovação para deploy produção (Gerente)

⏳ AGUARDANDO ENTREGAS:
├─ 🔒 Certificados SSL (Equipe Segurança)
├─ 📈 Dashboard template (Equipe BI)
├─ 🧪 Ambiente de testes (Equipe DevOps)
└─ 📚 Documentação de APIs (Equipe Desenvolvimento)
```

#### **🔮 ALGUM DIA/TALVEZ (SOMEDAY/MAYBE)**

```
🔮 MELHORIAS FUTURAS:
├─ 🤖 Machine Learning para classificação automática
├─ 🔍 Análise de sentimento em comentários
├─ 📊 Integração com Power BI
├─ 🔄 Sincronização bidirecional
├─ 🌐 Interface web para configuração
├─ 📱 App mobile para monitoramento
├─ 🔗 Integração com Slack/Teams
├─ 📈 Métricas avançadas de qualidade
├─ 🎯 Recomendações automáticas
└─ 🔒 Criptografia end-to-end
```

### 🔄 **4. REFLETIR (REFLECT)**

#### **📅 REVISÕES REGULARES**

##### **🌅 REVISÃO DIÁRIA (5 min)**
- [ ] Verificar inbox
- [ ] Atualizar próximas ações
- [ ] Revisar calendário do dia
- [ ] Identificar bloqueadores

##### **📅 REVISÃO SEMANAL (30 min)**
- [ ] Revisar todos os projetos
- [ ] Atualizar listas de próximas ações
- [ ] Processar inbox completamente
- [ ] Revisar calendário da semana
- [ ] Atualizar lista "Aguardando"
- [ ] Revisar "Algum dia/Talvez"

##### **📊 MÉTRICAS DE ACOMPANHAMENTO**

```
📊 DASHBOARD GTD:
├─ 📥 Itens no Inbox: 0 (meta)
├─ 🎯 Projetos Ativos: 4
├─ 📋 Próximas Ações: 23
├─ ⏳ Aguardando: 9
├─ 🔮 Algum Dia: 10
├─ ✅ Ações Completadas (semana): 15
├─ ⏱️ Tempo médio por ação: 25 min
└─ 🎯 Taxa de conclusão: 85%
```

### 🚀 **5. ENGAJAR (ENGAGE)**

#### **🎯 CRITÉRIOS DE DECISÃO**

Ao escolher qual ação executar, considerar:

1. **📍 Contexto atual** - Onde estou? (@Databricks, @Azure, etc.)
2. **⏰ Tempo disponível** - 15 min, 1h, meio dia?
3. **⚡ Energia atual** - Alta (tarefas complexas) ou baixa (administrativas)?
4. **🎯 Prioridade** - Crítico, importante, ou nice-to-have?

#### **⚡ NÍVEIS DE ENERGIA**

##### **🔥 ENERGIA ALTA (Manhã)**
- Configuração de Service Principal
- Desenvolvimento de funcionalidades
- Resolução de problemas complexos
- Arquitetura e design

##### **⚖️ ENERGIA MÉDIA (Tarde)**
- Testes e validações
- Configuração de jobs
- Documentação técnica
- Reviews de código

##### **🔋 ENERGIA BAIXA (Final do dia)**
- Organização de arquivos
- Atualização de documentação
- Emails administrativos
- Limpeza de inbox

#### **🎯 MATRIZ DE PRIORIDADES**

```
🎯 URGENTE + IMPORTANTE (FAZER AGORA):
├─ 🔐 Configurar autenticação (bloqueador)
├─ 🚨 Resolver erros críticos
└─ 📅 Entregas com deadline hoje

⚡ IMPORTANTE + NÃO URGENTE (AGENDAR):
├─ 📊 Implementar monitoramento
├─ 🔒 Auditoria de segurança
└─ 📚 Documentação completa

⏰ URGENTE + NÃO IMPORTANTE (DELEGAR):
├─ 📧 Emails administrativos
├─ 📋 Relatórios de status
└─ 🔄 Tarefas operacionais

❌ NÃO URGENTE + NÃO IMPORTANTE (ELIMINAR):
├─ 📱 Notificações desnecessárias
├─ 🔄 Reuniões sem objetivo
└─ 📊 Métricas irrelevantes
```

### 📈 **BENEFÍCIOS DO GTD APLICADO**

1. **🧠 Mente Livre:** Tudo capturado no sistema, não na cabeça
2. **🎯 Foco Total:** Próxima ação sempre clara
3. **📊 Visibilidade:** Status de todos os projetos
4. **⚡ Agilidade:** Decisões rápidas baseadas em contexto
5. **🔄 Melhoria Contínua:** Revisões regulares garantem evolução
6. **✅ Resultados:** Sistema orientado a outcomes, não atividades

---


## 📚 Notebooks Disponíveis

### 📊 **Notebook 1: Unity Catalog Extractor**

**📁 Arquivo:** `notebook_unity_catalog_extractor.py`

#### **🎯 Funcionalidades:**
- **📋 Extração de Metadados:** Catálogos, schemas, tabelas e colunas
- **🔗 Lineage Analysis:** Relacionamentos entre tabelas
- **📈 Usage Metrics:** Métricas de acesso e uso
- **🏷️ Tags & Classification:** Tags e classificações automáticas
- **🔄 Incremental Sync:** Sincronização incremental baseada em timestamps

#### **📊 Dados Extraídos:**
```
📊 UNITY CATALOG METADATA:
├─ 📁 Catalogs (name, properties, created_at)
├─ 📋 Schemas (catalog, name, properties)
├─ 📊 Tables (schema, name, type, columns)
├─ 🔗 Columns (table, name, data_type, comment)
├─ 📈 Usage Metrics (access_count, unique_users)
├─ 🔗 Lineage (source, target, relationship_type)
└─ 🏷️ Tags (name, category, description)
```

#### **🎯 Mapeamento para Governança:**
- **Domains** ← Catalogs
- **Entities** ← Tables
- **Entity Attributes** ← Columns
- **External References** ← Unity Catalog paths
- **Usage Metrics** ← Access statistics
- **Lineage Relationships** ← Table dependencies

---

### 🔷 **Notebook 2: Azure SPN Extractor**

**📁 Arquivo:** `notebook_azure_spn_extractor.py`

#### **🎯 Funcionalidades:**
- **🏭 Azure Data Factory:** Pipelines, datasets, linked services
- **🔄 Azure Synapse:** Workspaces, SQL pools, Spark pools
- **💾 Azure Storage:** Accounts, containers, file shares
- **🗄️ Azure SQL Database:** Servers, databases, tables, columns
- **📈 Azure Monitor:** Métricas de uso e performance

#### **📊 Dados Extraídos:**
```
🔷 AZURE SERVICES METADATA:
├─ 🏭 Data Factory
│   ├─ Factories (name, location, resource_group)
│   ├─ Pipelines (name, activities, parameters)
│   ├─ Datasets (name, type, schema, linked_service)
│   └─ Linked Services (name, type, connection)
├─ 🔄 Synapse Analytics
│   ├─ Workspaces (name, location, sql_admin)
│   ├─ SQL Pools (name, status, sku, size)
│   └─ Spark Pools (name, node_count, spark_version)
├─ 💾 Storage
│   ├─ Accounts (name, kind, sku, encryption)
│   ├─ Containers (name, public_access, metadata)
│   └─ File Shares (name, quota, metadata)
├─ 🗄️ SQL Database
│   ├─ Servers (name, version, admin_login)
│   ├─ Databases (name, status, collation, size)
│   ├─ Tables (schema, name, type)
│   └─ Columns (name, data_type, nullable)
└─ 📈 Monitor
    └─ Metrics (resource, metric_name, value, timestamp)
```

#### **🎯 Mapeamento para Governança:**
- **Domains** ← Resource Groups
- **Entities** ← Pipelines, Tables, Containers
- **Entity Attributes** ← Dataset schemas, Table columns
- **External References** ← Azure resource URLs
- **Usage Metrics** ← Azure Monitor metrics
- **Integration Configs** ← Azure service connections

---

## ⚙️ Configuração e Setup

### 🔐 **1. Pré-requisitos**

#### **🔷 Azure Requirements:**
```bash
# Service Principal com permissões:
- Subscription: Reader, Monitoring Reader
- Data Factory: Data Factory Contributor
- Synapse: Synapse Contributor  
- Storage: Storage Account Contributor, Storage Blob Data Reader
- SQL Database: SQL DB Contributor
- Key Vault: Key Vault Reader, Key Vault Secrets User
```

#### **📊 Databricks Requirements:**
```bash
# Cluster com bibliotecas:
- azure-identity
- azure-mgmt-resource
- azure-mgmt-datafactory
- azure-mgmt-synapse
- azure-mgmt-storage
- azure-mgmt-sql
- azure-mgmt-monitor
- pyodbc
```

### 🔑 **2. Configuração de Secrets**

#### **🔷 Azure Secrets:**
```bash
# Criar scope Azure
databricks secrets create-scope azure

# Adicionar credenciais SPN
databricks secrets put-secret azure tenant_id
databricks secrets put-secret azure client_id  
databricks secrets put-secret azure client_secret
databricks secrets put-secret azure subscription_id
```

#### **🎯 Governance API Secrets:**
```bash
# Criar scope Governance
databricks secrets create-scope governance

# Adicionar token da API
databricks secrets put-secret governance api_token
```

### 🔧 **3. Configuração dos Notebooks**

#### **📊 Unity Catalog Notebook:**
```python
# Configurações principais (células 1-2):
API_BASE_URL = "https://your-governance-api.com/api/v1"
API_TOKEN = dbutils.secrets.get(scope="governance", key="api_token")

# Personalizar extração:
CATALOGS_TO_EXTRACT = ["prod_catalog", "analytics_catalog"]  # ou None para todos
EXTRACT_LINEAGE = True
EXTRACT_USAGE_METRICS = True
BATCH_SIZE = 50
```

#### **🔷 Azure SPN Notebook:**
```python
# Configurações principais (células 1-2):
TENANT_ID = dbutils.secrets.get(scope="azure", key="tenant_id")
CLIENT_ID = dbutils.secrets.get(scope="azure", key="client_id")
CLIENT_SECRET = dbutils.secrets.get(scope="azure", key="client_secret")
SUBSCRIPTION_ID = dbutils.secrets.get(scope="azure", key="subscription_id")

# Personalizar extração:
RESOURCE_GROUPS = ["rg-data", "rg-analytics"]  # ou None para todos
EXTRACT_METRICS_DAYS = 7  # Últimos 7 dias
BATCH_SIZE = 50
```

---

## 🚀 Execução e Monitoramento

### ▶️ **1. Execução Manual**

#### **📊 Unity Catalog:**
```python
# 1. Abrir notebook no Databricks
# 2. Anexar ao cluster configurado
# 3. Executar todas as células (Ctrl+Shift+A)
# 4. Verificar logs na última célula
# 5. Validar dados na API de Governança
```

#### **🔷 Azure SPN:**
```python
# 1. Verificar permissões Azure SPN
# 2. Abrir notebook no Databricks  
# 3. Anexar ao cluster configurado
# 4. Executar todas as células (Ctrl+Shift+A)
# 5. Verificar relatório final
```

### ⏰ **2. Agendamento Automático**

#### **📅 Job Configuration:**
```json
{
  "name": "Data Governance Extraction",
  "tasks": [
    {
      "task_key": "unity_catalog_extraction",
      "notebook_task": {
        "notebook_path": "/Shared/governance/notebook_unity_catalog_extractor"
      },
      "job_cluster_key": "governance_cluster"
    },
    {
      "task_key": "azure_spn_extraction", 
      "notebook_task": {
        "notebook_path": "/Shared/governance/notebook_azure_spn_extractor"
      },
      "job_cluster_key": "governance_cluster",
      "depends_on": [{"task_key": "unity_catalog_extraction"}]
    }
  ],
  "schedule": {
    "quartz_cron_expression": "0 0 2 * * ?",
    "timezone_id": "America/Sao_Paulo"
  },
  "email_notifications": {
    "on_failure": ["admin@company.com"],
    "on_success": ["data-team@company.com"]
  }
}
```

#### **⏰ Schedules Recomendados:**
```
📊 Unity Catalog: Diário às 02:00 (baixo impacto)
🔷 Azure SPN: Diário às 03:00 (após Unity Catalog)
🔄 Incremental: A cada 4 horas (apenas mudanças)
📈 Métricas: A cada hora (dados de uso)
```

### 📊 **3. Monitoramento**

#### **📈 Métricas-Chave:**
```
📊 EXECUÇÃO:
├─ ⏱️ Tempo de execução (meta: <30 min)
├─ ✅ Taxa de sucesso (meta: >95%)
├─ 📊 Registros processados
├─ 🚨 Erros por categoria
└─ 📈 Tendência de performance

📊 DADOS:
├─ 📋 Tabelas populadas (56/56)
├─ 🔗 Relacionamentos criados
├─ 📊 Métricas coletadas
├─ 🏷️ Tags aplicadas
└─ 🔄 Sincronização bem-sucedida

📊 QUALIDADE:
├─ 🎯 Completude dos dados (meta: >90%)
├─ 🔍 Integridade referencial
├─ ⏰ Freshness dos dados
├─ 📊 Consistência entre fontes
└─ 🔒 Conformidade de segurança
```

#### **🚨 Alertas Configurados:**
```
🚨 CRÍTICOS (Imediato):
├─ 💥 Falha na execução do job
├─ 🔐 Erro de autenticação
├─ 📊 API de Governança indisponível
└─ 🗄️ Perda de conectividade com fontes

⚠️ WARNINGS (1 hora):
├─ ⏱️ Execução mais lenta que o normal
├─ 📊 Redução significativa de dados
├─ 🔍 Falhas em validações de qualidade
└─ 📈 Métricas fora do padrão

ℹ️ INFO (Diário):
├─ ✅ Execução bem-sucedida
├─ 📊 Relatório de dados processados
├─ 📈 Métricas de performance
└─ 🔄 Status de sincronização
```

### 📋 **4. Logs e Debugging**

#### **📁 Arquivos de Log:**
```
📁 /tmp/logs/
├─ unity_catalog_metadata.json
├─ unity_catalog_extraction_report.json
├─ azure_complete_metadata.json
├─ azure_extraction_report.json
├─ governance_api_responses.log
└─ error_details.log
```

#### **🔍 Debugging Common Issues:**

##### **🔐 Authentication Errors:**
```python
# Verificar secrets
dbutils.secrets.list(scope="azure")
dbutils.secrets.list(scope="governance")

# Testar conectividade
from azure.identity import ClientSecretCredential
credential = ClientSecretCredential(tenant_id, client_id, client_secret)
```

##### **📊 Data Quality Issues:**
```python
# Verificar contagem de registros
SELECT table_name, COUNT(*) FROM information_schema.tables;

# Validar relacionamentos
SELECT COUNT(*) FROM entities WHERE domain_id IS NULL;
```

##### **⚡ Performance Issues:**
```python
# Monitorar uso de cluster
spark.sparkContext.statusTracker().getExecutorInfos()

# Otimizar batch size
BATCH_SIZE = 25  # Reduzir se necessário
```

---

## 🔧 Troubleshooting

### 🚨 **Problemas Comuns e Soluções**

#### **🔐 Erro de Autenticação Azure**
```
❌ ERRO: AuthenticationError: Invalid client credentials

✅ SOLUÇÃO:
1. Verificar se Service Principal existe
2. Confirmar client_id e client_secret corretos
3. Validar permissões no subscription
4. Testar autenticação manualmente:
   az login --service-principal -u CLIENT_ID -p CLIENT_SECRET --tenant TENANT_ID
```

#### **📊 Unity Catalog Inacessível**
```
❌ ERRO: AnalysisException: Catalog 'catalog_name' not found

✅ SOLUÇÃO:
1. Verificar se cluster tem acesso ao Unity Catalog
2. Confirmar permissões de leitura nos catálogos
3. Testar comando: SHOW CATALOGS
4. Verificar configuração do metastore
```

#### **🔷 Azure APIs Retornando 403**
```
❌ ERRO: HttpResponseError: (Forbidden) Insufficient privileges

✅ SOLUÇÃO:
1. Verificar permissões do Service Principal:
   - Subscription: Reader
   - Resource Groups: Contributor
2. Aguardar propagação de permissões (até 30 min)
3. Testar com Azure CLI:
   az resource list --subscription SUBSCRIPTION_ID
```

#### **🎯 API de Governança Indisponível**
```
❌ ERRO: ConnectionError: Failed to establish connection

✅ SOLUÇÃO:
1. Verificar se API está rodando
2. Confirmar URL e porta corretas
3. Testar conectividade: curl -I API_BASE_URL/health
4. Verificar token de autenticação
5. Checar firewall/proxy
```

#### **💾 Erro de Memória no Cluster**
```
❌ ERRO: OutOfMemoryError: Java heap space

✅ SOLUÇÃO:
1. Aumentar tamanho do cluster
2. Reduzir BATCH_SIZE para 25 ou 10
3. Processar catálogos individualmente
4. Configurar spark.sql.adaptive.enabled=true
```

#### **⏱️ Timeout em Operações**
```
❌ ERRO: TimeoutError: Operation timed out

✅ SOLUÇÃO:
1. Aumentar timeout nas configurações
2. Implementar retry com backoff
3. Processar em lotes menores
4. Verificar latência de rede
```

### 🔍 **Debugging Avançado**

#### **📊 Verificação de Dados:**
```python
# Contar registros por tabela
tables = ['domains', 'entities', 'entity_attributes', 'external_references']
for table in tables:
    count = spark.sql(f"SELECT COUNT(*) FROM governance.{table}").collect()[0][0]
    print(f"{table}: {count} registros")

# Verificar integridade referencial
orphaned = spark.sql("""
    SELECT COUNT(*) FROM entities e 
    LEFT JOIN domains d ON e.domain_id = d.id 
    WHERE d.id IS NULL
""").collect()[0][0]
print(f"Entidades órfãs: {orphaned}")
```

#### **⚡ Análise de Performance:**
```python
# Monitorar execução
import time
start_time = time.time()
# ... código ...
execution_time = time.time() - start_time
print(f"Tempo de execução: {execution_time:.2f} segundos")

# Verificar uso de recursos
spark.sparkContext.statusTracker().getExecutorInfos()
```

#### **📋 Logs Detalhados:**
```python
import logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Usar em pontos críticos
logger.info(f"Processando {len(data)} registros")
logger.debug(f"Dados: {data[:5]}")  # Primeiros 5 registros
```

### 📞 **Suporte e Contatos**

```
🆘 SUPORTE TÉCNICO:
├─ 📧 Email: data-governance@company.com
├─ 💬 Slack: #data-governance
├─ 📱 Telefone: +55 11 9999-9999
└─ 🎫 Ticket: https://support.company.com

📚 DOCUMENTAÇÃO:
├─ 🔗 API Docs: https://api-docs.company.com
├─ 📖 Wiki: https://wiki.company.com/data-governance
├─ 🎥 Videos: https://training.company.com
└─ 📋 FAQ: https://faq.company.com/data-governance

👥 EQUIPE:
├─ 🏗️ Arquiteto: Carlos Morais (carlos.morais@company.com)
├─ 🔧 DevOps: João Silva (joao.silva@company.com)
├─ 🔒 Segurança: Maria Santos (maria.santos@company.com)
└─ 📊 Dados: Ana Costa (ana.costa@company.com)
```

---

## 🎯 Conclusão

Os notebooks de extração de dados para a API de Governança representam uma solução completa e robusta para alimentar o modelo ODCS v3.0.2 com dados do Unity Catalog e serviços Azure.

### ✅ **Benefícios Alcançados:**

1. **🔄 Automação Completa:** Extração, transformação e carregamento automatizados
2. **📊 Visibilidade Total:** Dados de múltiplas fontes centralizados
3. **🎯 Governança Efetiva:** Modelo ODCS v3.0.2 implementado
4. **🔒 Segurança Garantida:** Autenticação via SPN e secrets management
5. **📈 Monitoramento Ativo:** Métricas, logs e alertas configurados
6. **🚀 Escalabilidade:** Arquitetura preparada para crescimento

### 🔮 **Próximos Passos:**

1. **🤖 Machine Learning:** Classificação automática de dados sensíveis
2. **🔍 Lineage Avançado:** Parser de SQL para lineage detalhado
3. **📊 Analytics:** Dashboards avançados de governança
4. **🔗 Integrações:** Conectores para outras ferramentas
5. **🌐 Self-Service:** Interface web para configuração
6. **📱 Mobile:** App para monitoramento móvel

**Desenvolvido por Carlos Morais - Janeiro 2025** 🚀

