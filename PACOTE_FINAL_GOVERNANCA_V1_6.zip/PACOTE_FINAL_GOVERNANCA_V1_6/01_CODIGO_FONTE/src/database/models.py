"""
Modelos SQLAlchemy para a API de Governança de Dados
"""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import uuid4

from sqlalchemy import (
    BigInteger,
    UniqueConstraint,
    Index,
    ARRAY,
    Boolean,
    DateTime,
    ForeignKey,
    Integer,
    Numeric,
    String,
    Text,
    func,
)
from sqlalchemy.dialects.postgresql import INET, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database.connection import Base


class TimestampMixin:
    """Mixin para campos de timestamp"""
    
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False
    )


class UserTrackingMixin:
    """Mixin para rastreamento de usuário"""
    
    created_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=True
    )
    updated_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=True
    )


# ========================================
# USER MANAGEMENT
# ========================================

class User(Base, TimestampMixin):
    """Modelo de usuário"""
    
    __tablename__ = "users"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    username: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    full_name: Mapped[Optional[str]] = mapped_column(String(255))
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_superuser: Mapped[bool] = mapped_column(Boolean, default=False)
    last_login: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    
    # Relationships
    created_contracts: Mapped[List["DataContract"]] = relationship(
        "DataContract", 
        foreign_keys="DataContract.created_by",
        back_populates="creator"
    )
    updated_contracts: Mapped[List["DataContract"]] = relationship(
        "DataContract",
        foreign_keys="DataContract.updated_by",
        back_populates="updater"
    )


class UserRole(Base, TimestampMixin):
    """Modelo de papel de usuário"""
    
    __tablename__ = "user_roles"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    permissions: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False)


class UserRoleAssignment(Base):
    """Modelo de atribuição de papel"""
    
    __tablename__ = "user_role_assignments"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    user_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )
    role_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("user_roles.id"),
        nullable=False
    )
    domain_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("domains.id")
    )
    assigned_by: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )
    assigned_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now()
    )
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))


# ========================================
# GOVERNANCE STRUCTURE
# ========================================

class Domain(Base, TimestampMixin):
    """Modelo de domínio"""
    
    __tablename__ = "domains"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    parent_domain_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("domains.id")
    )
    steward_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("stewards.id")
    )
    additional_metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Relationships
    parent_domain: Mapped[Optional["Domain"]] = relationship(
        "Domain",
        remote_side=[id],
        back_populates="child_domains"
    )
    child_domains: Mapped[List["Domain"]] = relationship(
        "Domain",
        back_populates="parent_domain"
    )
    contracts: Mapped[List["DataContract"]] = relationship(
        "DataContract",
        back_populates="domain"
    )
    entities: Mapped[List["Entity"]] = relationship(
        "Entity",
        back_populates="domain"
    )


class Steward(Base):
    """Modelo de steward"""
    
    __tablename__ = "stewards"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    user_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )
    domain_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("domains.id"),
        nullable=False
    )
    role: Mapped[str] = mapped_column(String(50), nullable=False)  # primary, secondary, technical
    responsibilities: Mapped[Optional[str]] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    assigned_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now()
    )
    assigned_by: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )
    
    # Relationships
    user: Mapped["User"] = relationship("User")
    domain: Mapped["Domain"] = relationship("Domain")


# ========================================
# DATA CONTRACTS
# ========================================

class DataContract(Base, TimestampMixin, UserTrackingMixin):
    """Modelo de contrato de dados"""
    
    __tablename__ = "data_contracts"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    domain_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("domains.id")
    )
    steward_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("stewards.id")
    )
    status: Mapped[str] = mapped_column(String(50), default="draft")
    current_version_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("data_contract_versions.id")
    )
    unity_catalog_path: Mapped[Optional[str]] = mapped_column(String(500))
    
    # Relationships
    domain: Mapped[Optional["Domain"]] = relationship(
        "Domain",
        back_populates="contracts"
    )
    steward: Mapped[Optional["Steward"]] = relationship("Steward")
    versions: Mapped[List["DataContractVersion"]] = relationship(
        "DataContractVersion",
        foreign_keys="DataContractVersion.contract_id",
        back_populates="contract"
    )
    current_version: Mapped[Optional["DataContractVersion"]] = relationship(
        "DataContractVersion",
        foreign_keys=[current_version_id],
        post_update=True
    )
    creator: Mapped[Optional["User"]] = relationship(
        "User",
        foreign_keys=[UserTrackingMixin.created_by],
        back_populates="created_contracts"
    )
    updater: Mapped[Optional["User"]] = relationship(
        "User",
        foreign_keys=[UserTrackingMixin.updated_by],
        back_populates="updated_contracts"
    )


class DataContractVersion(Base, TimestampMixin):
    """Modelo de versão de contrato"""
    
    __tablename__ = "data_contract_versions"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    contract_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("data_contracts.id"),
        nullable=False
    )
    version: Mapped[str] = mapped_column(String(20), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    schema_definition: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False)
    quality_rules: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    sla_definition: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    terms_and_conditions: Mapped[Optional[str]] = mapped_column(Text)
    odcs_export: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    is_active: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    
    # Relationships
    contract: Mapped["DataContract"] = relationship(
        "DataContract",
        foreign_keys=[contract_id],
        back_populates="versions"
    )
    creator: Mapped[Optional["User"]] = relationship("User")


# ========================================
# ENTITIES AND METADATA
# ========================================

class Entity(Base, TimestampMixin, UserTrackingMixin):
    """Modelo de entidade"""
    
    __tablename__ = "entities"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    type: Mapped[str] = mapped_column(String(50), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    domain_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("domains.id")
    )
    steward_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("stewards.id")
    )
    unity_catalog_path: Mapped[Optional[str]] = mapped_column(String(500))
    schema_definition: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    business_glossary_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("business_glossary.id")
    )
    classification: Mapped[str] = mapped_column(String(50), default="internal")
    
    # Relationships
    domain: Mapped[Optional["Domain"]] = relationship(
        "Domain",
        back_populates="entities"
    )
    steward: Mapped[Optional["Steward"]] = relationship("Steward")
    attributes: Mapped[List["EntityAttribute"]] = relationship(
        "EntityAttribute",
        back_populates="entity",
        cascade="all, delete-orphan"
    )
    tags: Mapped[List["EntityTag"]] = relationship(
        "EntityTag",
        back_populates="entity",
        cascade="all, delete-orphan"
    )
    quality_rules: Mapped[List["QualityRule"]] = relationship(
        "QualityRule",
        back_populates="entity"
    )


class EntityAttribute(Base, TimestampMixin):
    """Modelo de atributo de entidade"""
    
    __tablename__ = "entity_attributes"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    data_type: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    is_nullable: Mapped[bool] = mapped_column(Boolean, default=True)
    is_primary_key: Mapped[bool] = mapped_column(Boolean, default=False)
    is_foreign_key: Mapped[bool] = mapped_column(Boolean, default=False)
    business_term_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("business_terms.id")
    )
    classification: Mapped[Optional[str]] = mapped_column(String(50))
    masking_policy_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("masking_policies.id")
    )
    
    # Relationships
    entity: Mapped["Entity"] = relationship(
        "Entity",
        back_populates="attributes"
    )
    business_term: Mapped[Optional["BusinessTerm"]] = relationship("BusinessTerm")
    masking_policy: Mapped[Optional["MaskingPolicy"]] = relationship("MaskingPolicy")


class Tag(Base, TimestampMixin):
    """Modelo de tag"""
    
    __tablename__ = "tags"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    category: Mapped[Optional[str]] = mapped_column(String(100))
    parent_tag_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tags.id")
    )
    additional_metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    
    # Relationships
    parent_tag: Mapped[Optional["Tag"]] = relationship(
        "Tag",
        remote_side=[id],
        back_populates="child_tags"
    )
    child_tags: Mapped[List["Tag"]] = relationship(
        "Tag",
        back_populates="parent_tag"
    )
    entity_tags: Mapped[List["EntityTag"]] = relationship(
        "EntityTag",
        back_populates="tag"
    )


class EntityTag(Base):
    """Modelo de associação entre entidade e tag"""
    
    __tablename__ = "entity_tags"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    tag_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("tags.id"),
        nullable=False
    )
    assigned_by: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id"),
        nullable=False
    )
    assigned_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now()
    )
    
    # Relationships
    entity: Mapped["Entity"] = relationship(
        "Entity",
        back_populates="tags"
    )
    tag: Mapped["Tag"] = relationship(
        "Tag",
        back_populates="entity_tags"
    )
    assigner: Mapped["User"] = relationship("User")


# ========================================
# QUALITY MANAGEMENT
# ========================================

class QualityDimension(Base, TimestampMixin):
    """Modelo de dimensão de qualidade"""
    
    __tablename__ = "quality_dimensions"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    category: Mapped[Optional[str]] = mapped_column(String(50))
    
    # Relationships
    quality_rules: Mapped[List["QualityRule"]] = relationship(
        "QualityRule",
        back_populates="dimension"
    )


class QualityRule(Base, TimestampMixin, UserTrackingMixin):
    """Modelo de regra de qualidade"""
    
    __tablename__ = "quality_rules"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    attribute_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entity_attributes.id")
    )
    dimension_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("quality_dimensions.id"),
        nullable=False
    )
    rule_type: Mapped[str] = mapped_column(String(50), nullable=False)
    rule_definition: Mapped[Dict[str, Any]] = mapped_column(JSONB, nullable=False)
    threshold_warning: Mapped[Optional[float]] = mapped_column(Numeric(5, 2))
    threshold_critical: Mapped[Optional[float]] = mapped_column(Numeric(5, 2))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    
    # Relationships
    entity: Mapped["Entity"] = relationship(
        "Entity",
        back_populates="quality_rules"
    )
    attribute: Mapped[Optional["EntityAttribute"]] = relationship("EntityAttribute")
    dimension: Mapped["QualityDimension"] = relationship(
        "QualityDimension",
        back_populates="quality_rules"
    )
    metrics: Mapped[List["QualityMetric"]] = relationship(
        "QualityMetric",
        back_populates="rule"
    )


class QualityMetric(Base, TimestampMixin):
    """Modelo de métrica de qualidade"""
    
    __tablename__ = "quality_metrics"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    rule_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("quality_rules.id"),
        nullable=False
    )
    entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    execution_date: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False
    )
    metric_value: Mapped[float] = mapped_column(Numeric(10, 4), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False)
    details: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    execution_time_ms: Mapped[Optional[int]] = mapped_column(Integer)
    
    # Relationships
    rule: Mapped["QualityRule"] = relationship(
        "QualityRule",
        back_populates="metrics"
    )
    entity: Mapped["Entity"] = relationship("Entity")


class QualityIncident(Base, TimestampMixin):
    """Modelo de incidente de qualidade"""
    
    __tablename__ = "quality_incidents"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    rule_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("quality_rules.id"),
        nullable=False
    )
    entity_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("entities.id"),
        nullable=False
    )
    metric_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("quality_metrics.id"),
        nullable=False
    )
    severity: Mapped[str] = mapped_column(String(20), nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="open")
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    assigned_to: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    resolution_notes: Mapped[Optional[str]] = mapped_column(Text)
    
    # Relationships
    rule: Mapped["QualityRule"] = relationship("QualityRule")
    entity: Mapped["Entity"] = relationship("Entity")
    metric: Mapped["QualityMetric"] = relationship("QualityMetric")
    assignee: Mapped[Optional["User"]] = relationship("User")


# ========================================
# BUSINESS GLOSSARY
# ========================================

class BusinessGlossary(Base, TimestampMixin):
    """Modelo de glossário de negócio"""
    
    __tablename__ = "business_glossary"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    domain_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("domains.id")
    )
    steward_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("stewards.id")
    )
    
    # Relationships
    domain: Mapped[Optional["Domain"]] = relationship("Domain")
    steward: Mapped[Optional["Steward"]] = relationship("Steward")
    terms: Mapped[List["BusinessTerm"]] = relationship(
        "BusinessTerm",
        back_populates="glossary"
    )


class BusinessTerm(Base, TimestampMixin):
    """Modelo de termo de negócio"""
    
    __tablename__ = "business_terms"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    glossary_id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("business_glossary.id"),
        nullable=False
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    definition: Mapped[str] = mapped_column(Text, nullable=False)
    synonyms: Mapped[Optional[List[str]]] = mapped_column(ARRAY(String))
    related_terms: Mapped[Optional[List[UUID]]] = mapped_column(ARRAY(UUID))
    domain_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("domains.id")
    )
    steward_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("stewards.id")
    )
    status: Mapped[str] = mapped_column(String(20), default="draft")
    
    # Relationships
    glossary: Mapped["BusinessGlossary"] = relationship(
        "BusinessGlossary",
        back_populates="terms"
    )
    domain: Mapped[Optional["Domain"]] = relationship("Domain")
    steward: Mapped[Optional["Steward"]] = relationship("Steward")


# ========================================
# MASKING AND PRIVACY
# ========================================

class MaskingPolicy(Base, TimestampMixin):
    """Modelo de política de mascaramento"""
    
    __tablename__ = "masking_policies"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    name: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    policy_type: Mapped[str] = mapped_column(String(50), nullable=False)
    masking_function: Mapped[str] = mapped_column(String(100), nullable=False)
    parameters: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


# ========================================
# MONITORING AND METRICS
# ========================================

class SystemMetric(Base):
    """Modelo de métrica do sistema"""
    
    __tablename__ = "system_metrics"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    metric_name: Mapped[str] = mapped_column(String(100), nullable=False)
    metric_type: Mapped[str] = mapped_column(String(50), nullable=False)
    metric_value: Mapped[float] = mapped_column(Numeric(15, 4), nullable=False)
    labels: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False
    )


class HealthCheck(Base):
    """Modelo de health check"""
    
    __tablename__ = "health_checks"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    component_name: Mapped[str] = mapped_column(String(100), nullable=False)
    status: Mapped[str] = mapped_column(String(20), nullable=False)
    response_time_ms: Mapped[Optional[int]] = mapped_column(Integer)
    error_message: Mapped[Optional[str]] = mapped_column(Text)
    additional_metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    checked_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        nullable=False
    )


class AuditLog(Base):
    """Modelo de log de auditoria"""
    
    __tablename__ = "audit_logs"
    
    id: Mapped[UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        default=uuid4
    )
    user_id: Mapped[Optional[UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id")
    )
    action: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_id: Mapped[Optional[UUID]] = mapped_column(UUID(as_uuid=True))
    old_values: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    new_values: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    ip_address: Mapped[Optional[str]] = mapped_column(INET)
    user_agent: Mapped[Optional[str]] = mapped_column(Text)
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now()
    )
    
    # Relationships
    user: Mapped[Optional["User"]] = relationship("User")



# ========================================
# AUDIT LOGS - Modelos de Auditoria
# ========================================

class AuditLogRetentionPolicy(Base):
    """Políticas de retenção de logs de auditoria"""
    __tablename__ = "audit_log_retention_policies"
    
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    resource_type: Mapped[str] = mapped_column(String(100), nullable=False)
    event_type: Mapped[Optional[str]] = mapped_column(String(100))
    retention_days: Mapped[int] = mapped_column(Integer, nullable=False, default=365)
    archive_after_days: Mapped[Optional[int]] = mapped_column(Integer, default=90)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now(), onupdate=func.now())
    created_by: Mapped[Optional[str]] = mapped_column(String, ForeignKey("users.id"))
    updated_by: Mapped[Optional[str]] = mapped_column(String, ForeignKey("users.id"))
    
    # Relacionamentos
    created_by_user: Mapped[Optional["User"]] = relationship("User", foreign_keys=[created_by])
    updated_by_user: Mapped[Optional["User"]] = relationship("User", foreign_keys=[updated_by])
    
    __table_args__ = (
        UniqueConstraint('resource_type', 'event_type', name='uq_retention_policy'),
    )


class AuditLogArchive(Base):
    """Arquivos de logs de auditoria"""
    __tablename__ = "audit_log_archives"
    
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    original_log_id: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    archive_date: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now(), index=True)
    archive_location: Mapped[Optional[str]] = mapped_column(String(500))
    compression_type: Mapped[str] = mapped_column(String(20), default="gzip")
    checksum: Mapped[Optional[str]] = mapped_column(String(64))
    size_bytes: Mapped[Optional[int]] = mapped_column(BigInteger)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now())


# ========================================
# RATE LIMITING - Modelos de Rate Limiting
# ========================================

class RateLimitPolicy(Base):
    """Políticas de rate limiting"""
    __tablename__ = "rate_limit_policies"
    
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    description: Mapped[Optional[str]] = mapped_column(Text)
    user_role: Mapped[Optional[str]] = mapped_column(String(100), index=True)
    endpoint_pattern: Mapped[Optional[str]] = mapped_column(String(500))
    requests_per_minute: Mapped[int] = mapped_column(Integer, nullable=False, default=60)
    requests_per_hour: Mapped[int] = mapped_column(Integer, nullable=False, default=1000)
    requests_per_day: Mapped[int] = mapped_column(Integer, nullable=False, default=10000)
    burst_limit: Mapped[Optional[int]] = mapped_column(Integer, default=10)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    priority: Mapped[int] = mapped_column(Integer, default=100, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now(), onupdate=func.now())
    created_by: Mapped[Optional[str]] = mapped_column(String, ForeignKey("users.id"))
    updated_by: Mapped[Optional[str]] = mapped_column(String, ForeignKey("users.id"))
    
    # Relacionamentos
    created_by_user: Mapped[Optional["User"]] = relationship("User", foreign_keys=[created_by])
    updated_by_user: Mapped[Optional["User"]] = relationship("User", foreign_keys=[updated_by])
    user_overrides: Mapped[List["RateLimitUserOverride"]] = relationship("RateLimitUserOverride", back_populates="policy")
    violations: Mapped[List["RateLimitViolation"]] = relationship("RateLimitViolation", back_populates="policy")


class RateLimitUserOverride(Base):
    """Overrides de rate limiting por usuário"""
    __tablename__ = "rate_limit_user_overrides"
    
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String, ForeignKey("users.id"), nullable=False, index=True)
    policy_id: Mapped[Optional[str]] = mapped_column(String, ForeignKey("rate_limit_policies.id"))
    custom_requests_per_minute: Mapped[Optional[int]] = mapped_column(Integer)
    custom_requests_per_hour: Mapped[Optional[int]] = mapped_column(Integer)
    custom_requests_per_day: Mapped[Optional[int]] = mapped_column(Integer)
    custom_burst_limit: Mapped[Optional[int]] = mapped_column(Integer)
    reason: Mapped[Optional[str]] = mapped_column(Text)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), index=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now(), onupdate=func.now())
    created_by: Mapped[Optional[str]] = mapped_column(String, ForeignKey("users.id"))
    updated_by: Mapped[Optional[str]] = mapped_column(String, ForeignKey("users.id"))
    
    # Relacionamentos
    user: Mapped["User"] = relationship("User", foreign_keys=[user_id], back_populates="rate_limit_overrides")
    policy: Mapped[Optional["RateLimitPolicy"]] = relationship("RateLimitPolicy", back_populates="user_overrides")
    created_by_user: Mapped[Optional["User"]] = relationship("User", foreign_keys=[created_by])
    updated_by_user: Mapped[Optional["User"]] = relationship("User", foreign_keys=[updated_by])
    
    __table_args__ = (
        UniqueConstraint('user_id', 'policy_id', name='uq_user_policy_override'),
    )


class RateLimitViolation(Base):
    """Violações de rate limiting"""
    __tablename__ = "rate_limit_violations"
    
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[Optional[str]] = mapped_column(String, ForeignKey("users.id"), index=True)
    policy_id: Mapped[Optional[str]] = mapped_column(String, ForeignKey("rate_limit_policies.id"))
    endpoint: Mapped[str] = mapped_column(String(500), nullable=False)
    ip_address: Mapped[Optional[str]] = mapped_column(String, index=True)
    user_agent: Mapped[Optional[str]] = mapped_column(Text)
    violation_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    limit_value: Mapped[int] = mapped_column(Integer, nullable=False)
    actual_requests: Mapped[int] = mapped_column(Integer, nullable=False)
    time_window_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    time_window_end: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    blocked_duration_seconds: Mapped[Optional[int]] = mapped_column(Integer)
    additional_metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now(), index=True)
    
    # Relacionamentos
    user: Mapped[Optional["User"]] = relationship("User", back_populates="rate_limit_violations")
    policy: Mapped[Optional["RateLimitPolicy"]] = relationship("RateLimitPolicy", back_populates="violations")
    
    # Índices compostos
    __table_args__ = (
        Index('idx_violation_user_created', 'user_id', 'created_at'),
        Index('idx_violation_ip_created', 'ip_address', 'created_at'),
    )


# ========================================
# PERFORMANCE MONITORING - Modelos de Performance
# ========================================

class QueryPerformanceLog(Base):
    """Logs de performance de queries"""
    __tablename__ = "query_performance_logs"
    
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    query_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    query_text: Mapped[str] = mapped_column(Text, nullable=False)
    execution_time_ms: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    rows_returned: Mapped[Optional[int]] = mapped_column(Integer)
    rows_examined: Mapped[Optional[int]] = mapped_column(Integer)
    index_usage: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    execution_plan: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    endpoint: Mapped[Optional[str]] = mapped_column(String(500), index=True)
    user_id: Mapped[Optional[str]] = mapped_column(String, ForeignKey("users.id"), index=True)
    database_name: Mapped[Optional[str]] = mapped_column(String(100))
    table_names: Mapped[Optional[List[str]]] = mapped_column(ARRAY(String))
    is_slow_query: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    optimization_suggestions: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now(), index=True)
    
    # Relacionamentos
    user: Mapped[Optional["User"]] = relationship("User")
    
    # Índices compostos
    __table_args__ = (
        Index('idx_query_hash_created', 'query_hash', 'created_at'),
        Index('idx_query_endpoint_created', 'endpoint', 'created_at'),
    )


class ConnectionPoolMetrics(Base):
    """Métricas do pool de conexões"""
    __tablename__ = "connection_pool_metrics"
    
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    pool_name: Mapped[str] = mapped_column(String(100), nullable=False, index=True)
    active_connections: Mapped[int] = mapped_column(Integer, nullable=False)
    idle_connections: Mapped[int] = mapped_column(Integer, nullable=False)
    total_connections: Mapped[int] = mapped_column(Integer, nullable=False)
    max_connections: Mapped[int] = mapped_column(Integer, nullable=False)
    connection_wait_time_ms: Mapped[Optional[int]] = mapped_column(Integer)
    connection_creation_time_ms: Mapped[Optional[int]] = mapped_column(Integer)
    failed_connections: Mapped[int] = mapped_column(Integer, default=0)
    pool_utilization_percent: Mapped[Optional[float]] = mapped_column(Numeric(5, 2))
    health_status: Mapped[str] = mapped_column(String(20), default="healthy", index=True)
    additional_metrics: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now(), index=True)
    
    # Índices compostos
    __table_args__ = (
        Index('idx_pool_name_recorded', 'pool_name', 'recorded_at'),
    )


# ========================================
# LOAD BALANCING - Modelos de Load Balancing
# ========================================

class ApplicationInstance(Base):
    """Instâncias da aplicação para load balancing"""
    __tablename__ = "application_instances"
    
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    instance_name: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    host: Mapped[str] = mapped_column(String(255), nullable=False)
    port: Mapped[int] = mapped_column(Integer, nullable=False)
    health_check_url: Mapped[Optional[str]] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(String(20), default="active", index=True)
    weight: Mapped[int] = mapped_column(Integer, default=100, index=True)
    max_connections: Mapped[int] = mapped_column(Integer, default=1000)
    current_connections: Mapped[int] = mapped_column(Integer, default=0)
    cpu_usage_percent: Mapped[Optional[float]] = mapped_column(Numeric(5, 2))
    memory_usage_percent: Mapped[Optional[float]] = mapped_column(Numeric(5, 2))
    response_time_avg_ms: Mapped[Optional[int]] = mapped_column(Integer)
    last_health_check: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), index=True)
    health_check_failures: Mapped[int] = mapped_column(Integer, default=0)
    version: Mapped[Optional[str]] = mapped_column(String(50))
    deployment_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    additional_metadata: Mapped[Optional[Dict[str, Any]]] = mapped_column(JSONB)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now(), onupdate=func.now())
    
    # Relacionamentos
    load_balancer_metrics: Mapped[List["LoadBalancerMetrics"]] = relationship("LoadBalancerMetrics", back_populates="instance")
    
    __table_args__ = (
        UniqueConstraint('host', 'port', name='uq_host_port'),
    )


class LoadBalancerRule(Base):
    """Regras de load balancing"""
    __tablename__ = "load_balancer_rules"
    
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    rule_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    endpoint_pattern: Mapped[Optional[str]] = mapped_column(String(500))
    target_instances: Mapped[Optional[List[str]]] = mapped_column(ARRAY(String))
    health_check_interval_seconds: Mapped[int] = mapped_column(Integer, default=30)
    failure_threshold: Mapped[int] = mapped_column(Integer, default=3)
    recovery_threshold: Mapped[int] = mapped_column(Integer, default=2)
    timeout_seconds: Mapped[int] = mapped_column(Integer, default=30)
    sticky_sessions: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, index=True)
    priority: Mapped[int] = mapped_column(Integer, default=100, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now(), onupdate=func.now())
    created_by: Mapped[Optional[str]] = mapped_column(String, ForeignKey("users.id"))
    updated_by: Mapped[Optional[str]] = mapped_column(String, ForeignKey("users.id"))
    
    # Relacionamentos
    created_by_user: Mapped[Optional["User"]] = relationship("User", foreign_keys=[created_by])
    updated_by_user: Mapped[Optional["User"]] = relationship("User", foreign_keys=[updated_by])
    load_balancer_metrics: Mapped[List["LoadBalancerMetrics"]] = relationship("LoadBalancerMetrics", back_populates="rule")


class LoadBalancerMetrics(Base):
    """Métricas de load balancing"""
    __tablename__ = "load_balancer_metrics"
    
    id: Mapped[str] = mapped_column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    instance_id: Mapped[str] = mapped_column(String, ForeignKey("application_instances.id"), nullable=False, index=True)
    rule_id: Mapped[Optional[str]] = mapped_column(String, ForeignKey("load_balancer_rules.id"))
    requests_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    successful_requests: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    failed_requests: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    avg_response_time_ms: Mapped[Optional[int]] = mapped_column(Integer)
    min_response_time_ms: Mapped[Optional[int]] = mapped_column(Integer)
    max_response_time_ms: Mapped[Optional[int]] = mapped_column(Integer)
    bytes_sent: Mapped[int] = mapped_column(BigInteger, default=0)
    bytes_received: Mapped[int] = mapped_column(BigInteger, default=0)
    active_connections: Mapped[int] = mapped_column(Integer, default=0)
    time_window_start: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    time_window_end: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    recorded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=func.now(), index=True)
    
    # Relacionamentos
    instance: Mapped["ApplicationInstance"] = relationship("ApplicationInstance", back_populates="load_balancer_metrics")
    rule: Mapped[Optional["LoadBalancerRule"]] = relationship("LoadBalancerRule", back_populates="load_balancer_metrics")
    
    # Índices compostos
    __table_args__ = (
        Index('idx_instance_time_window', 'instance_id', 'time_window_start'),
    )


# Atualizar relacionamentos existentes
User.audit_logs = relationship("AuditLog", back_populates="user")
User.rate_limit_overrides = relationship("RateLimitUserOverride", foreign_keys="RateLimitUserOverride.user_id", back_populates="user")
User.rate_limit_violations = relationship("RateLimitViolation", back_populates="user")



# ===========================
# MODELO DE USUÁRIO PARA AUTENTICAÇÃO
# ===========================

