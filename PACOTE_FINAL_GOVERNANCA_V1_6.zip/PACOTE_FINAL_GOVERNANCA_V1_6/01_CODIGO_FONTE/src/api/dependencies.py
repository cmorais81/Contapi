"""
Dependências da API
API de Governança de Dados V1.5
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from typing import AsyncGenerator, Dict, Optional, Any
from uuid import UUID
import logging

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

logger = logging.getLogger(__name__)

# Security
security = HTTPBearer()

# Simulação de sessão de banco de dados
class MockSession:
    """Sessão simulada para desenvolvimento"""
    def __init__(self):
        self.data = {}
        logger.info("MockSession criada")
    
    async def close(self):
        logger.info("MockSession fechada")

async def get_db_session() -> MockSession:
    """Dependency para obter sessão do banco de dados (simulada)"""
    try:
        session = MockSession()
        logger.info("Sessão de banco simulada criada")
        return session
    except Exception as e:
        logger.error(f"Erro ao criar sessão de banco: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

# Importações seguras dos serviços
try:
    from application.services.data_contract_service import DataContractService
except ImportError:
    logger.warning("DataContractService não pôde ser importado")
    DataContractService = None

try:
    from application.services.domain_service import DomainService
except ImportError:
    logger.warning("DomainService não pôde ser importado")
    DomainService = None

try:
    from application.services.lineage_service import LineageService
except ImportError:
    logger.warning("LineageService não pôde ser importado")
    LineageService = None

try:
    from application.services.quality_service import QualityService
except ImportError:
    logger.warning("QualityService não pôde ser importado")
    QualityService = None

try:
    from application.services.policy_service import PolicyService
except ImportError:
    logger.warning("PolicyService não pôde ser importado")
    PolicyService = None

try:
    from application.services.stewardship_service import StewardshipService
except ImportError:
    logger.warning("StewardshipService não pôde ser importado")
    StewardshipService = None

# Factories para serviços
def get_data_contract_service() -> Any:
    """Factory para DataContractService"""
    if DataContractService:
        return DataContractService()
    else:
        logger.warning("DataContractService não disponível, retornando mock")
        return MockService("DataContractService")

def get_domain_service() -> Any:
    """Factory para DomainService"""
    if DomainService:
        return DomainService()
    else:
        logger.warning("DomainService não disponível, retornando mock")
        return MockService("DomainService")

def get_lineage_service() -> Any:
    """Factory para LineageService"""
    if LineageService:
        return LineageService()
    else:
        logger.warning("LineageService não disponível, retornando mock")
        return MockService("LineageService")

def get_quality_service() -> Any:
    """Factory para QualityService"""
    if QualityService:
        return QualityService()
    else:
        logger.warning("QualityService não disponível, retornando mock")
        return MockService("QualityService")

def get_policy_service() -> Any:
    """Factory para PolicyService"""
    if PolicyService:
        return PolicyService()
    else:
        logger.warning("PolicyService não disponível, retornando mock")
        return MockService("PolicyService")

def get_stewardship_service() -> Any:
    """Factory para StewardshipService"""
    if StewardshipService:
        return StewardshipService()
    else:
        logger.warning("StewardshipService não disponível, retornando mock")
        return MockService("StewardshipService")

class MockService:
    """Serviço mock para desenvolvimento"""
    def __init__(self, service_name: str):
        self.service_name = service_name
        logger.info(f"MockService criado para {service_name}")
    
    async def __getattr__(self, name):
        """Retorna método mock para qualquer chamada"""
        async def mock_method(*args, **kwargs):
            logger.info(f"Método mock {name} chamado em {self.service_name}")
            return {
                "message": f"Mock response from {self.service_name}.{name}",
                "service": self.service_name,
                "method": name,
                "args": args,
                "kwargs": kwargs,
                "author": "Carlos Morais",
                "email": "carlos.morais@f1rst.com.br"
            }
        return mock_method

# Dependency para autenticação (simulada)
async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> Dict[str, Any]:
    """Dependency para obter usuário atual (simulado)"""
    try:
        # Simulação de autenticação
        user = {
            "id": "user_123",
            "username": "carlos.morais",
            "email": "carlos.morais@f1rst.com.br",
            "roles": ["admin", "data_steward"],
            "permissions": ["read", "write", "admin"],
            "organization": "F1rst"
        }
        logger.info(f"Usuário autenticado: {user['username']}")
        return user
    except Exception as e:
        logger.error(f"Erro na autenticação: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido",
            headers={"WWW-Authenticate": "Bearer"},
        )

# Dependency para paginação
class PaginationParams:
    """Parâmetros de paginação"""
    def __init__(self, limit: int = 100, offset: int = 0):
        self.limit = min(limit, 1000)  # Máximo 1000 itens
        self.offset = max(offset, 0)   # Mínimo 0

def get_pagination_params(limit: int = 100, offset: int = 0) -> PaginationParams:
    """Dependency para parâmetros de paginação"""
    return PaginationParams(limit=limit, offset=offset)

# Dependency para validação de UUID
def validate_uuid(uuid_str: str) -> UUID:
    """Valida e converte string para UUID"""
    try:
        return UUID(uuid_str)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"UUID inválido: {uuid_str}"
        )

# Dependency para headers de auditoria
def get_audit_headers() -> Dict[str, str]:
    """Retorna headers de auditoria"""
    return {
        "X-API-Version": "1.5.0",
        "X-Author": "Carlos Morais",
        "X-Author-Email": "carlos.morais@f1rst.com.br",
        "X-Organization": "F1rst"
    }

