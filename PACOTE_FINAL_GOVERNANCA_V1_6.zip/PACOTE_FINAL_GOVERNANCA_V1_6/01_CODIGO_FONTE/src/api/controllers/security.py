"""
Controller para Segurança Avançada
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from application.dtos.security import (
    RoleCreateDTO,
    RoleResponseDTO,
    PermissionCreateDTO,
    PermissionResponseDTO,
    AccessControlCreateDTO,
    AccessControlResponseDTO,
    AccessLogDTO,
    EncryptionKeyCreateDTO,
    EncryptionKeyResponseDTO,
    SecurityComplianceReportDTO,
    SecurityMetricsDTO,
    UserRoleAssignmentDTO,
    PermissionType,
    ResourceType,
    AccessLevel,
    EncryptionAlgorithm,
    KeyStatus,
)
from application.dtos import PaginatedResponse, PaginationParams
from application.services.security_service import SecurityService
from domain.exceptions import BusinessRuleViolation, EntityNotFoundError, UnauthorizedError
from api.dependencies import get_current_active_user, get_security_service, validate_pagination

router = APIRouter(prefix="/api/v1/security", tags=["Advanced Security"])


# Roles Management
@router.post(
    "/roles",
    response_model=RoleResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar papel",
    description="Cria um novo papel com permissões específicas"
)
async def create_role(
    role: RoleCreateDTO,
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> RoleResponseDTO:
    """Cria novo papel"""
    try:
        return await service.create_role(role, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


@router.get(
    "/roles",
    response_model=PaginatedResponse[RoleResponseDTO],
    summary="Listar papéis",
    description="Lista papéis do sistema com filtros"
)
async def list_roles(
    pagination: PaginationParams = Depends(validate_pagination),
    is_system_role: Optional[bool] = Query(None, description="Filtro por papel do sistema"),
    resource_type: Optional[ResourceType] = Query(None, description="Filtro por tipo de recurso"),
    is_active: bool = Query(True, description="Filtro por ativo"),
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[RoleResponseDTO]:
    """Lista papéis"""
    filters = {
        "is_system_role": is_system_role,
        "resource_type": resource_type,
        "is_active": is_active
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_roles(pagination, filters)


@router.get(
    "/roles/{role_id}",
    response_model=RoleResponseDTO,
    summary="Buscar papel",
    description="Retorna detalhes de um papel específico"
)
async def get_role(
    role_id: UUID,
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> RoleResponseDTO:
    """Busca papel específico"""
    try:
        return await service.get_role(role_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.put(
    "/roles/{role_id}",
    response_model=RoleResponseDTO,
    summary="Atualizar papel",
    description="Atualiza um papel existente"
)
async def update_role(
    role_id: UUID,
    role: RoleCreateDTO,
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> RoleResponseDTO:
    """Atualiza papel"""
    try:
        return await service.update_role(role_id, role, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


@router.delete(
    "/roles/{role_id}",
    response_model=dict,
    summary="Deletar papel",
    description="Remove um papel do sistema"
)
async def delete_role(
    role_id: UUID,
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Deleta papel"""
    try:
        await service.delete_role(role_id, current_user["id"])
        return {"message": "Role deleted successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


# Permissions Management
@router.post(
    "/permissions",
    response_model=PermissionResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar permissão",
    description="Cria uma nova permissão no sistema"
)
async def create_permission(
    permission: PermissionCreateDTO,
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> PermissionResponseDTO:
    """Cria nova permissão"""
    try:
        return await service.create_permission(permission, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


@router.get(
    "/permissions",
    response_model=PaginatedResponse[PermissionResponseDTO],
    summary="Listar permissões",
    description="Lista permissões do sistema com filtros"
)
async def list_permissions(
    pagination: PaginationParams = Depends(validate_pagination),
    permission_type: Optional[PermissionType] = Query(None, description="Filtro por tipo"),
    resource_type: Optional[ResourceType] = Query(None, description="Filtro por recurso"),
    is_system_permission: Optional[bool] = Query(None, description="Filtro por sistema"),
    is_active: bool = Query(True, description="Filtro por ativo"),
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[PermissionResponseDTO]:
    """Lista permissões"""
    filters = {
        "permission_type": permission_type,
        "resource_type": resource_type,
        "is_system_permission": is_system_permission,
        "is_active": is_active
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_permissions(pagination, filters)


# Access Control
@router.post(
    "/access-control",
    response_model=AccessControlResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar controle de acesso",
    description="Concede acesso específico a um usuário"
)
async def create_access_control(
    access_control: AccessControlCreateDTO,
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> AccessControlResponseDTO:
    """Cria controle de acesso"""
    try:
        access_control.granted_by = current_user["id"]
        return await service.create_access_control(access_control)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


@router.get(
    "/access-control",
    response_model=PaginatedResponse[AccessControlResponseDTO],
    summary="Listar controles de acesso",
    description="Lista controles de acesso ativos"
)
async def list_access_controls(
    pagination: PaginationParams = Depends(validate_pagination),
    user_id: Optional[UUID] = Query(None, description="Filtro por usuário"),
    resource_type: Optional[ResourceType] = Query(None, description="Filtro por tipo de recurso"),
    resource_id: Optional[UUID] = Query(None, description="Filtro por recurso específico"),
    access_level: Optional[AccessLevel] = Query(None, description="Filtro por nível de acesso"),
    is_active: bool = Query(True, description="Filtro por ativo"),
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[AccessControlResponseDTO]:
    """Lista controles de acesso"""
    filters = {
        "user_id": user_id,
        "resource_type": resource_type,
        "resource_id": resource_id,
        "access_level": access_level,
        "is_active": is_active
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_access_controls(pagination, filters)


@router.delete(
    "/access-control/{access_id}",
    response_model=dict,
    summary="Revogar acesso",
    description="Revoga um controle de acesso específico"
)
async def revoke_access_control(
    access_id: UUID,
    reason: str = Query(..., description="Motivo da revogação"),
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Revoga controle de acesso"""
    try:
        await service.revoke_access_control(access_id, reason, current_user["id"])
        return {"message": "Access control revoked successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


# Access Logs
@router.get(
    "/access-logs",
    response_model=PaginatedResponse[AccessLogDTO],
    summary="Logs de acesso",
    description="Lista logs de acesso ao sistema"
)
async def get_access_logs(
    pagination: PaginationParams = Depends(validate_pagination),
    user_id: Optional[UUID] = Query(None, description="Filtro por usuário"),
    resource_type: Optional[ResourceType] = Query(None, description="Filtro por tipo de recurso"),
    action: Optional[str] = Query(None, description="Filtro por ação"),
    access_granted: Optional[bool] = Query(None, description="Filtro por acesso concedido"),
    risk_threshold: Optional[float] = Query(None, ge=0, le=1, description="Filtro por risco mínimo"),
    hours_ago: int = Query(24, ge=1, le=8760, description="Período em horas"),
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[AccessLogDTO]:
    """Obtém logs de acesso"""
    filters = {
        "user_id": user_id,
        "resource_type": resource_type,
        "action": action,
        "access_granted": access_granted,
        "risk_threshold": risk_threshold,
        "hours_ago": hours_ago
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.get_access_logs(pagination, filters)


# Encryption Keys
@router.post(
    "/encryption/keys",
    response_model=EncryptionKeyResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar chave de criptografia",
    description="Gera uma nova chave de criptografia"
)
async def create_encryption_key(
    key: EncryptionKeyCreateDTO,
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> EncryptionKeyResponseDTO:
    """Cria chave de criptografia"""
    try:
        return await service.create_encryption_key(key, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


@router.get(
    "/encryption/keys",
    response_model=PaginatedResponse[EncryptionKeyResponseDTO],
    summary="Listar chaves de criptografia",
    description="Lista chaves de criptografia do sistema"
)
async def list_encryption_keys(
    pagination: PaginationParams = Depends(validate_pagination),
    algorithm: Optional[EncryptionAlgorithm] = Query(None, description="Filtro por algoritmo"),
    status: Optional[KeyStatus] = Query(None, description="Filtro por status"),
    purpose: Optional[str] = Query(None, description="Filtro por propósito"),
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[EncryptionKeyResponseDTO]:
    """Lista chaves de criptografia"""
    filters = {
        "algorithm": algorithm,
        "status": status,
        "purpose": purpose
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_encryption_keys(pagination, filters)


@router.post(
    "/encryption/keys/{key_id}/rotate",
    response_model=EncryptionKeyResponseDTO,
    summary="Rotacionar chave",
    description="Força a rotação de uma chave de criptografia"
)
async def rotate_encryption_key(
    key_id: UUID,
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> EncryptionKeyResponseDTO:
    """Rotaciona chave de criptografia"""
    try:
        return await service.rotate_encryption_key(key_id, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


# Compliance Reports
@router.get(
    "/compliance/report",
    response_model=SecurityComplianceReportDTO,
    summary="Relatório de compliance",
    description="Gera relatório de compliance de segurança"
)
async def generate_compliance_report(
    report_type: str = Query("security_audit", description="Tipo de relatório"),
    frameworks: List[str] = Query(["SOC2", "ISO27001"], description="Frameworks de compliance"),
    period_days: int = Query(30, ge=1, le=365, description="Período em dias"),
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> SecurityComplianceReportDTO:
    """Gera relatório de compliance"""
    try:
        return await service.generate_compliance_report(
            report_type, frameworks, period_days, current_user["id"]
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


# Security Metrics
@router.get(
    "/metrics",
    response_model=SecurityMetricsDTO,
    summary="Métricas de segurança",
    description="Retorna métricas consolidadas de segurança"
)
async def get_security_metrics(
    period_days: int = Query(30, ge=1, le=365, description="Período em dias"),
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> SecurityMetricsDTO:
    """Obtém métricas de segurança"""
    try:
        return await service.get_security_metrics(period_days)
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


# User Role Assignment
@router.post(
    "/users/{user_id}/roles",
    response_model=dict,
    summary="Atribuir papéis",
    description="Atribui papéis a um usuário"
)
async def assign_user_roles(
    user_id: UUID,
    assignment: UserRoleAssignmentDTO,
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Atribui papéis ao usuário"""
    try:
        assignment.user_id = user_id
        assignment.assigned_by = current_user["id"]
        await service.assign_user_roles(assignment)
        return {"message": "Roles assigned successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


@router.get(
    "/users/{user_id}/roles",
    response_model=List[RoleResponseDTO],
    summary="Papéis do usuário",
    description="Lista papéis atribuídos a um usuário"
)
async def get_user_roles(
    user_id: UUID,
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[RoleResponseDTO]:
    """Obtém papéis do usuário"""
    try:
        return await service.get_user_roles(user_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.delete(
    "/users/{user_id}/roles/{role_id}",
    response_model=dict,
    summary="Remover papel",
    description="Remove um papel de um usuário"
)
async def remove_user_role(
    user_id: UUID,
    role_id: UUID,
    reason: str = Query(..., description="Motivo da remoção"),
    service: SecurityService = Depends(get_security_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Remove papel do usuário"""
    try:
        await service.remove_user_role(user_id, role_id, reason, current_user["id"])
        return {"message": "Role removed successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )

