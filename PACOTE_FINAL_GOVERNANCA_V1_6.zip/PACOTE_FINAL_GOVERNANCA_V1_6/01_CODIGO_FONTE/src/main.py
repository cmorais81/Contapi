"""
API de Governança de Dados V1.5
Desenvolvida por: Carlos Morais
Email: carlos.morais@f1rst.com.br
Organização: F1rst

Versão ultra-robusta com imports seguros e tratamento completo de erros.
Compatível com Python 3.13 e Windows.
"""

import sys
import os
from pathlib import Path
from datetime import datetime
import logging

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Adicionar o diretório src ao PYTHONPATH para compatibilidade Windows
current_dir = Path(__file__).parent
src_dir = current_dir
if str(src_dir) not in sys.path:
    sys.path.insert(0, str(src_dir))

# Importações básicas
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn

# Importar módulos com tratamento de erro ultra-robusto
modules_loaded = []
modules_failed = []

# Função auxiliar para importação segura
def safe_import(module_name, from_module=None):
    """Importa módulo de forma segura com logging detalhado"""
    try:
        if from_module:
            module = __import__(f'{from_module}.{module_name}', fromlist=[module_name])
            imported_item = getattr(module, module_name, module)
        else:
            imported_item = __import__(module_name)
        
        modules_loaded.append(module_name)
        logger.info(f"✓ {module_name} importado com sucesso")
        return imported_item
    except ImportError as e:
        modules_failed.append(f"{module_name}: {str(e)}")
        logger.warning(f"✗ {module_name} não pôde ser importado: {e}")
        return None
    except Exception as e:
        modules_failed.append(f"{module_name}: {str(e)}")
        logger.error(f"✗ Erro inesperado ao importar {module_name}: {e}")
        return None

# Importar middleware
LoggingMiddleware = safe_import('LoggingMiddleware', 'api.middleware')
ErrorHandlingMiddleware = safe_import('ErrorHandlingMiddleware', 'api.error_middleware')
setup_exception_handlers = safe_import('setup_exception_handlers', 'api.exception_handlers')

# Lista de controllers para tentar importar
controller_modules = [
    'contracts', 'entities', 'quality', 'auth', 'audit', 
    'rate_limiting', 'system', 'metrics', 'domains', 
    'lineage', 'policies', 'stewardship', 'tags', 
    'analytics', 'discovery', 'workflows', 'notifications', 
    'integrations', 'security', 'performance'
]

controllers = {}
controllers_loaded = []
controllers_failed = []

for controller_name in controller_modules:
    try:
        module = __import__(f'api.controllers.{controller_name}', fromlist=[controller_name])
        controllers[controller_name] = module
        controllers_loaded.append(controller_name)
        logger.info(f"✓ Controller {controller_name} carregado com sucesso")
    except ImportError as e:
        controllers_failed.append(f"{controller_name}: {str(e)}")
        logger.warning(f"✗ Controller {controller_name} não pôde ser importado: {e}")
    except Exception as e:
        controllers_failed.append(f"{controller_name}: {str(e)}")
        logger.error(f"✗ Erro inesperado ao carregar controller {controller_name}: {e}")

# Log de resumo
logger.info(f"Resumo de importações:")
logger.info(f"  Módulos carregados: {len(modules_loaded)}")
logger.info(f"  Módulos falharam: {len(modules_failed)}")
logger.info(f"  Controllers carregados: {len(controllers_loaded)}")
logger.info(f"  Controllers falharam: {len(controllers_failed)}")

# Criar aplicação FastAPI
app = FastAPI(
    title="API de Governança de Dados",
    description=f"""
    ## API de Governança de Dados V1.5
    
    **Desenvolvida por:** Carlos Morais  
    **Email:** carlos.morais@f1rst.com.br  
    **Organização:** F1rst
    
    Uma solução enterprise ultra-robusta para gestão, controle e monitoramento de dados.
    
    **Compatibilidade:**
    - Python 3.13+ (compatível com 3.9+)
    - Windows, Linux, macOS
    - Docker e Kubernetes
    
    ### Funcionalidades Principais:
    - Gestão de Domínios e Hierarquias
    - Contratos de Dados com Versionamento
    - Descoberta e Catálogo Inteligente
    - Políticas e Compliance (LGPD/GDPR)
    - Qualidade de Dados e Métricas
    - Lineage e Rastreabilidade
    - Stewardship e Responsabilidades
    - Notificações Multi-canal
    - Workflows e Aprovações
    - Integrações Externas
    
    ### Melhorias V1.5:
    - Imports ultra-robustos com fallbacks
    - DTOs completos criados
    - Dependencies com mocks funcionais
    - Tratamento de erro avançado
    - Compatibilidade total Windows/Python 3.13
    - Logging detalhado de importações
    
    ### Status de Importações:
    - **Módulos carregados:** {len(modules_loaded)}
    - **Controllers carregados:** {len(controllers_loaded)}
    - **Módulos com falha:** {len(modules_failed)}
    - **Controllers com falha:** {len(controllers_failed)}
    """,
    version="1.5.0",
    contact={
        "name": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br",
    },
    license_info={
        "name": "Proprietário",
        "url": "mailto:carlos.morais@f1rst.com.br",
    },
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Adicionar middleware personalizado se disponível
if ErrorHandlingMiddleware:
    try:
        app.add_middleware(ErrorHandlingMiddleware)
        logger.info("✓ ErrorHandlingMiddleware adicionado com sucesso")
    except Exception as e:
        logger.warning(f"✗ Erro ao adicionar ErrorHandlingMiddleware: {e}")

if LoggingMiddleware:
    try:
        app.add_middleware(LoggingMiddleware)
        logger.info("✓ LoggingMiddleware adicionado com sucesso")
    except Exception as e:
        logger.warning(f"✗ Erro ao adicionar LoggingMiddleware: {e}")

# Configurar exception handlers se disponível
if setup_exception_handlers:
    try:
        setup_exception_handlers(app)
        logger.info("✓ Exception handlers configurados com sucesso")
    except Exception as e:
        logger.warning(f"✗ Erro ao configurar exception handlers: {e}")

# Health check endpoint ultra-detalhado
@app.get("/health", tags=["System"])
async def health_check():
    """
    Health check endpoint ultra-detalhado para verificar status da API.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.5.0",
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "platform": sys.platform,
        "author": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br",
        "organization": "F1rst",
        "imports": {
            "modules_loaded": modules_loaded,
            "modules_failed": modules_failed,
            "controllers_loaded": controllers_loaded,
            "controllers_failed": controllers_failed,
            "total_modules_loaded": len(modules_loaded),
            "total_controllers_loaded": len(controllers_loaded),
            "total_modules_failed": len(modules_failed),
            "total_controllers_failed": len(controllers_failed),
            "success_rate_modules": len(modules_loaded) / (len(modules_loaded) + len(modules_failed)) if (len(modules_loaded) + len(modules_failed)) > 0 else 1.0,
            "success_rate_controllers": len(controllers_loaded) / (len(controllers_loaded) + len(controllers_failed)) if (len(controllers_loaded) + len(controllers_failed)) > 0 else 1.0
        },
        "middleware": {
            "error_handling": ErrorHandlingMiddleware is not None,
            "logging": LoggingMiddleware is not None,
            "exception_handlers": setup_exception_handlers is not None,
            "cors": True
        }
    }

# Root endpoint
@app.get("/", tags=["System"])
async def root():
    """
    Endpoint raiz da API de Governança de Dados.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    return {
        "message": "API de Governança de Dados V1.5 - Ultra-Robusta",
        "author": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br",
        "organization": "F1rst",
        "version": "1.5.0",
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "platform": sys.platform,
        "docs": "/docs",
        "redoc": "/redoc",
        "health": "/health",
        "status": "running",
        "imports_summary": {
            "modules_loaded": len(modules_loaded),
            "controllers_loaded": len(controllers_loaded),
            "modules_failed": len(modules_failed),
            "controllers_failed": len(controllers_failed)
        },
        "improvements_v15": [
            "Imports ultra-robustos com fallbacks",
            "DTOs completos criados",
            "Dependencies com mocks funcionais",
            "Tratamento de erro avançado",
            "Compatibilidade total Windows/Python 3.13",
            "Logging detalhado de importações"
        ]
    }

# Endpoint de diagnóstico detalhado
@app.get("/diagnostics", tags=["System"])
async def diagnostics():
    """
    Diagnóstico detalhado do sistema.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    return {
        "system": {
            "version": "1.5.0",
            "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "platform": sys.platform,
            "timestamp": datetime.utcnow().isoformat(),
            "pythonpath": sys.path[:5]  # Primeiros 5 caminhos
        },
        "author": {
            "name": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br",
            "organization": "F1rst"
        },
        "imports": {
            "modules": {
                "loaded": modules_loaded,
                "failed": modules_failed,
                "count_loaded": len(modules_loaded),
                "count_failed": len(modules_failed)
            },
            "controllers": {
                "loaded": controllers_loaded,
                "failed": controllers_failed,
                "count_loaded": len(controllers_loaded),
                "count_failed": len(controllers_failed)
            }
        },
        "middleware": {
            "error_handling_available": ErrorHandlingMiddleware is not None,
            "logging_available": LoggingMiddleware is not None,
            "exception_handlers_available": setup_exception_handlers is not None
        },
        "recommendations": [
            "Verificar logs para detalhes de imports falhados",
            "Instalar dependências faltantes se necessário",
            "Verificar estrutura de diretórios",
            "Confirmar compatibilidade Python 3.13"
        ]
    }

# Incluir routers dos controllers disponíveis
routers_included = []
routers_failed = []

for controller_name, controller_module in controllers.items():
    try:
        if hasattr(controller_module, 'router'):
            app.include_router(
                controller_module.router, 
                prefix="/api/v1", 
                tags=[controller_name.title()]
            )
            routers_included.append(controller_name)
            logger.info(f"✓ Router {controller_name} incluído com sucesso")
        else:
            routers_failed.append(f"{controller_name}: router não encontrado")
            logger.warning(f"✗ Controller {controller_name} não possui router")
    except Exception as e:
        routers_failed.append(f"{controller_name}: {str(e)}")
        logger.error(f"✗ Erro ao incluir router {controller_name}: {e}")

logger.info(f"Routers incluídos: {len(routers_included)}")
logger.info(f"Routers falharam: {len(routers_failed)}")

# Middleware para adicionar headers de autor e diagnóstico
@app.middleware("http")
async def add_diagnostic_headers(request: Request, call_next):
    """Adiciona headers com informações de diagnóstico"""
    response = await call_next(request)
    response.headers["X-Author"] = "Carlos Morais"
    response.headers["X-Author-Email"] = "carlos.morais@f1rst.com.br"
    response.headers["X-Organization"] = "F1rst"
    response.headers["X-API-Version"] = "1.5.0"
    response.headers["X-Python-Version"] = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    response.headers["X-Platform"] = sys.platform
    response.headers["X-Modules-Loaded"] = str(len(modules_loaded))
    response.headers["X-Controllers-Loaded"] = str(len(controllers_loaded))
    response.headers["X-Routers-Included"] = str(len(routers_included))
    response.headers["X-Modules-Failed"] = str(len(modules_failed))
    response.headers["X-Controllers-Failed"] = str(len(controllers_failed))
    response.headers["X-Routers-Failed"] = str(len(routers_failed))
    return response

# Endpoint para listar controllers e routers
@app.get("/status", tags=["System"])
async def system_status():
    """
    Status completo do sistema com detalhes de imports.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    return {
        "modules": {
            "loaded": modules_loaded,
            "failed": modules_failed,
            "count_loaded": len(modules_loaded),
            "count_failed": len(modules_failed)
        },
        "controllers": {
            "loaded": controllers_loaded,
            "failed": controllers_failed,
            "count_loaded": len(controllers_loaded),
            "count_failed": len(controllers_failed)
        },
        "routers": {
            "included": routers_included,
            "failed": routers_failed,
            "count_included": len(routers_included),
            "count_failed": len(routers_failed)
        },
        "summary": {
            "total_success": len(modules_loaded) + len(controllers_loaded) + len(routers_included),
            "total_failures": len(modules_failed) + len(controllers_failed) + len(routers_failed),
            "overall_health": "healthy" if len(routers_included) > 0 else "degraded"
        },
        "author": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br"
    }

if __name__ == "__main__":
    logger.info("=" * 80)
    logger.info("Iniciando API de Governança de Dados V1.5 - Ultra-Robusta")
    logger.info("Desenvolvida por: Carlos Morais (carlos.morais@f1rst.com.br)")
    logger.info("Organização: F1rst")
    logger.info("=" * 80)
    logger.info(f"Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro} em {sys.platform}")
    logger.info(f"Módulos carregados: {len(modules_loaded)}")
    logger.info(f"Módulos falharam: {len(modules_failed)}")
    logger.info(f"Controllers carregados: {len(controllers_loaded)}")
    logger.info(f"Controllers falharam: {len(controllers_failed)}")
    logger.info(f"Routers incluídos: {len(routers_included)}")
    logger.info(f"Routers falharam: {len(routers_failed)}")
    logger.info("=" * 80)
    
    if len(routers_included) == 0:
        logger.warning("ATENÇÃO: Nenhum router foi incluído com sucesso!")
        logger.warning("A API funcionará apenas com endpoints básicos (health, status, diagnostics)")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

