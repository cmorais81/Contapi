"""
Sistema de Rate Limiting por Usuário
Desenvolvido por Carlos Morais
"""

import asyncio
import time
import json
import re
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum

import redis.asyncio as redis
from fastapi import Request, HTTPException, status
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_

from database.models import RateLimitPolicy, RateLimitUserOverride, RateLimitViolation
from database.connection import get_async_session
from config.settings import get_settings
from monitoring.audit_logger import audit_logger, EventType, Severity


class ViolationType(str, Enum):
    """Tipos de violação de rate limiting"""
    MINUTE = "minute"
    HOUR = "hour"
    DAY = "day"
    BURST = "burst"


@dataclass
class RateLimitConfig:
    """Configuração de rate limiting"""
    requests_per_minute: int
    requests_per_hour: int
    requests_per_day: int
    burst_limit: int
    policy_id: Optional[str] = None
    policy_name: Optional[str] = None


@dataclass
class RateLimitStatus:
    """Status atual do rate limiting"""
    allowed: bool
    remaining_minute: int
    remaining_hour: int
    remaining_day: int
    remaining_burst: int
    reset_time_minute: int
    reset_time_hour: int
    reset_time_day: int
    violation_type: Optional[ViolationType] = None
    retry_after: Optional[int] = None


class SlidingWindowRateLimiter:
    """Rate limiter usando sliding window algorithm"""
    
    def __init__(self, redis_client: redis.Redis):
        self.redis = redis_client
        self.settings = get_settings()
    
    async def check_rate_limit(
        self,
        user_id: str,
        endpoint: str,
        config: RateLimitConfig,
        ip_address: Optional[str] = None
    ) -> RateLimitStatus:
        """
        Verifica se a requisição está dentro dos limites
        
        Args:
            user_id: ID do usuário
            endpoint: Endpoint sendo acessado
            config: Configuração de rate limiting
            ip_address: IP do cliente
            
        Returns:
            Status do rate limiting
        """
        
        current_time = int(time.time())
        
        # Chaves Redis para diferentes janelas de tempo
        keys = {
            "minute": f"rate_limit:{user_id}:minute:{current_time // 60}",
            "hour": f"rate_limit:{user_id}:hour:{current_time // 3600}",
            "day": f"rate_limit:{user_id}:day:{current_time // 86400}",
            "burst": f"rate_limit:{user_id}:burst"
        }
        
        # Pipeline Redis para operações atômicas
        pipe = self.redis.pipeline()
        
        # Verificar contadores atuais
        for key in keys.values():
            pipe.get(key)
        
        results = await pipe.execute()
        
        # Obter contadores atuais
        current_counts = {
            "minute": int(results[0] or 0),
            "hour": int(results[1] or 0),
            "day": int(results[2] or 0),
            "burst": int(results[3] or 0)
        }
        
        # Verificar limites
        violations = []
        
        if current_counts["minute"] >= config.requests_per_minute:
            violations.append(ViolationType.MINUTE)
        
        if current_counts["hour"] >= config.requests_per_hour:
            violations.append(ViolationType.HOUR)
        
        if current_counts["day"] >= config.requests_per_day:
            violations.append(ViolationType.DAY)
        
        if current_counts["burst"] >= config.burst_limit:
            violations.append(ViolationType.BURST)
        
        # Se há violações, não permitir
        if violations:
            # Calcular tempo de retry
            retry_after = self._calculate_retry_after(violations[0], current_time)
            
            # Log da violação
            await self._log_violation(
                user_id=user_id,
                endpoint=endpoint,
                config=config,
                violation_type=violations[0],
                current_counts=current_counts,
                ip_address=ip_address
            )
            
            return RateLimitStatus(
                allowed=False,
                remaining_minute=max(0, config.requests_per_minute - current_counts["minute"]),
                remaining_hour=max(0, config.requests_per_hour - current_counts["hour"]),
                remaining_day=max(0, config.requests_per_day - current_counts["day"]),
                remaining_burst=max(0, config.burst_limit - current_counts["burst"]),
                reset_time_minute=(current_time // 60 + 1) * 60,
                reset_time_hour=(current_time // 3600 + 1) * 3600,
                reset_time_day=(current_time // 86400 + 1) * 86400,
                violation_type=violations[0],
                retry_after=retry_after
            )
        
        # Incrementar contadores
        pipe = self.redis.pipeline()
        
        # Incrementar e definir TTL
        pipe.incr(keys["minute"])
        pipe.expire(keys["minute"], 60)
        
        pipe.incr(keys["hour"])
        pipe.expire(keys["hour"], 3600)
        
        pipe.incr(keys["day"])
        pipe.expire(keys["day"], 86400)
        
        # Burst counter com sliding window de 10 segundos
        pipe.incr(keys["burst"])
        pipe.expire(keys["burst"], 10)
        
        await pipe.execute()
        
        # Atualizar contadores
        current_counts["minute"] += 1
        current_counts["hour"] += 1
        current_counts["day"] += 1
        current_counts["burst"] += 1
        
        return RateLimitStatus(
            allowed=True,
            remaining_minute=max(0, config.requests_per_minute - current_counts["minute"]),
            remaining_hour=max(0, config.requests_per_hour - current_counts["hour"]),
            remaining_day=max(0, config.requests_per_day - current_counts["day"]),
            remaining_burst=max(0, config.burst_limit - current_counts["burst"]),
            reset_time_minute=(current_time // 60 + 1) * 60,
            reset_time_hour=(current_time // 3600 + 1) * 3600,
            reset_time_day=(current_time // 86400 + 1) * 86400
        )
    
    def _calculate_retry_after(self, violation_type: ViolationType, current_time: int) -> int:
        """Calcula o tempo de retry em segundos"""
        
        if violation_type == ViolationType.MINUTE:
            return 60 - (current_time % 60)
        elif violation_type == ViolationType.HOUR:
            return 3600 - (current_time % 3600)
        elif violation_type == ViolationType.DAY:
            return 86400 - (current_time % 86400)
        elif violation_type == ViolationType.BURST:
            return 10  # Burst window de 10 segundos
        
        return 60  # Default
    
    async def _log_violation(
        self,
        user_id: str,
        endpoint: str,
        config: RateLimitConfig,
        violation_type: ViolationType,
        current_counts: Dict[str, int],
        ip_address: Optional[str] = None
    ):
        """Log da violação de rate limiting"""
        
        try:
            async with get_async_session() as session:
                # Criar registro de violação
                violation = RateLimitViolation(
                    user_id=user_id,
                    policy_id=config.policy_id,
                    endpoint=endpoint,
                    ip_address=ip_address,
                    violation_type=violation_type.value,
                    limit_value=getattr(config, f"requests_per_{violation_type.value}"),
                    actual_requests=current_counts[violation_type.value],
                    time_window_start=datetime.utcnow() - timedelta(
                        seconds=60 if violation_type == ViolationType.MINUTE else
                               3600 if violation_type == ViolationType.HOUR else
                               86400 if violation_type == ViolationType.DAY else 10
                    ),
                    time_window_end=datetime.utcnow(),
                    blocked_duration_seconds=self._calculate_retry_after(violation_type, int(time.time())),
                    additional_metadata={
                        "policy_name": config.policy_name,
                        "all_counts": current_counts
                    }
                )
                
                session.add(violation)
                await session.commit()
                
                # Log de auditoria
                await audit_logger.log_event(
                    event_type=EventType.ACCESS_DENIED,
                    resource_type="rate_limit",
                    resource_id=endpoint,
                    user_id=user_id,
                    additional_metadata={
                        "violation_type": violation_type.value,
                        "limit_exceeded": True,
                        "policy_id": config.policy_id,
                        "ip_address": ip_address
                    },
                    severity=Severity.WARN,
                    tags=["rate_limit", "violation"],
                    session=session
                )
                
        except Exception as e:
            # Não falhar a requisição por erro de log
            print(f"Error logging rate limit violation: {e}")


class RateLimitManager:
    """Gerenciador de políticas de rate limiting"""
    
    def __init__(self):
        self.settings = get_settings()
        self._policy_cache = {}
        self._cache_ttl = 300  # 5 minutos
        self._last_cache_update = 0
    
    async def get_rate_limit_config(
        self,
        user_id: str,
        user_role: str,
        endpoint: str,
        session: Optional[AsyncSession] = None
    ) -> RateLimitConfig:
        """
        Obtém a configuração de rate limiting para um usuário/endpoint
        
        Args:
            user_id: ID do usuário
            user_role: Role do usuário
            endpoint: Endpoint sendo acessado
            session: Sessão do banco de dados
            
        Returns:
            Configuração de rate limiting
        """
        
        async def _get_config(db_session: AsyncSession) -> RateLimitConfig:
            # Verificar override específico do usuário primeiro
            override_query = select(RateLimitUserOverride).where(
                and_(
                    RateLimitUserOverride.user_id == user_id,
                    RateLimitUserOverride.is_active == True,
                    or_(
                        RateLimitUserOverride.expires_at.is_(None),
                        RateLimitUserOverride.expires_at > datetime.utcnow()
                    )
                )
            )
            
            override_result = await db_session.execute(override_query)
            override = override_result.scalar_one_or_none()
            
            if override:
                return RateLimitConfig(
                    requests_per_minute=override.custom_requests_per_minute or 60,
                    requests_per_hour=override.custom_requests_per_hour or 1000,
                    requests_per_day=override.custom_requests_per_day or 10000,
                    burst_limit=override.custom_burst_limit or 10,
                    policy_id=override.policy_id,
                    policy_name=f"User Override: {user_id}"
                )
            
            # Buscar política aplicável
            policies_query = select(RateLimitPolicy).where(
                and_(
                    RateLimitPolicy.is_active == True,
                    or_(
                        RateLimitPolicy.user_role == user_role,
                        RateLimitPolicy.user_role.is_(None)
                    )
                )
            ).order_by(RateLimitPolicy.priority.asc())
            
            policies_result = await db_session.execute(policies_query)
            policies = policies_result.scalars().all()
            
            # Encontrar política que corresponde ao endpoint
            for policy in policies:
                if self._endpoint_matches_pattern(endpoint, policy.endpoint_pattern):
                    return RateLimitConfig(
                        requests_per_minute=policy.requests_per_minute,
                        requests_per_hour=policy.requests_per_hour,
                        requests_per_day=policy.requests_per_day,
                        burst_limit=policy.burst_limit,
                        policy_id=str(policy.id),
                        policy_name=policy.name
                    )
            
            # Configuração padrão
            return RateLimitConfig(
                requests_per_minute=60,
                requests_per_hour=1000,
                requests_per_day=10000,
                burst_limit=10,
                policy_name="Default Policy"
            )
        
        if session:
            return await _get_config(session)
        else:
            async with get_async_session() as db_session:
                return await _get_config(db_session)
    
    def _endpoint_matches_pattern(self, endpoint: str, pattern: Optional[str]) -> bool:
        """Verifica se o endpoint corresponde ao padrão"""
        
        if not pattern:
            return True  # Padrão vazio corresponde a todos
        
        try:
            return bool(re.match(pattern, endpoint))
        except re.error:
            # Se o padrão regex é inválido, tratar como string literal
            return pattern in endpoint


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware de rate limiting"""
    
    def __init__(self, app, redis_url: Optional[str] = None):
        super().__init__(app)
        self.redis_url = redis_url or get_settings().redis_url
        self.redis_client = None
        self.rate_limiter = None
        self.rate_limit_manager = RateLimitManager()
        
    async def dispatch(self, request: Request, call_next):
        # Inicializar Redis se necessário
        if not self.redis_client:
            try:
                self.redis_client = redis.from_url(self.redis_url)
                self.rate_limiter = SlidingWindowRateLimiter(self.redis_client)
            except Exception as e:
                # Se Redis não estiver disponível, pular rate limiting
                print(f"Redis not available for rate limiting: {e}")
                return await call_next(request)
        
        # Verificar se deve aplicar rate limiting
        if not self._should_rate_limit(request):
            return await call_next(request)
        
        # Obter informações do usuário
        user_id = getattr(request.state, 'user_id', None)
        user_role = getattr(request.state, 'user_role', 'guest')
        
        if not user_id:
            # Para usuários não autenticados, usar IP
            user_id = f"ip:{request.client.host}" if request.client else "anonymous"
            user_role = "guest"
        
        endpoint = request.url.path
        ip_address = request.client.host if request.client else None
        
        try:
            # Obter configuração de rate limiting
            config = await self.rate_limit_manager.get_rate_limit_config(
                user_id=user_id,
                user_role=user_role,
                endpoint=endpoint
            )
            
            # Verificar rate limit
            status = await self.rate_limiter.check_rate_limit(
                user_id=user_id,
                endpoint=endpoint,
                config=config,
                ip_address=ip_address
            )
            
            # Se não permitido, retornar erro
            if not status.allowed:
                headers = {
                    "X-RateLimit-Limit-Minute": str(config.requests_per_minute),
                    "X-RateLimit-Limit-Hour": str(config.requests_per_hour),
                    "X-RateLimit-Limit-Day": str(config.requests_per_day),
                    "X-RateLimit-Remaining-Minute": str(status.remaining_minute),
                    "X-RateLimit-Remaining-Hour": str(status.remaining_hour),
                    "X-RateLimit-Remaining-Day": str(status.remaining_day),
                    "X-RateLimit-Reset-Minute": str(status.reset_time_minute),
                    "X-RateLimit-Reset-Hour": str(status.reset_time_hour),
                    "X-RateLimit-Reset-Day": str(status.reset_time_day),
                    "Retry-After": str(status.retry_after)
                }
                
                return Response(
                    content=json.dumps({
                        "error": "Rate limit exceeded",
                        "message": f"Too many requests. Limit: {getattr(config, f'requests_per_{status.violation_type.value}')} per {status.violation_type.value}",
                        "violation_type": status.violation_type.value,
                        "retry_after": status.retry_after
                    }),
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    headers=headers,
                    media_type="application/json"
                )
            
            # Processar requisição
            response = await call_next(request)
            
            # Adicionar headers informativos
            response.headers["X-RateLimit-Limit-Minute"] = str(config.requests_per_minute)
            response.headers["X-RateLimit-Limit-Hour"] = str(config.requests_per_hour)
            response.headers["X-RateLimit-Limit-Day"] = str(config.requests_per_day)
            response.headers["X-RateLimit-Remaining-Minute"] = str(status.remaining_minute)
            response.headers["X-RateLimit-Remaining-Hour"] = str(status.remaining_hour)
            response.headers["X-RateLimit-Remaining-Day"] = str(status.remaining_day)
            response.headers["X-RateLimit-Reset-Minute"] = str(status.reset_time_minute)
            response.headers["X-RateLimit-Reset-Hour"] = str(status.reset_time_hour)
            response.headers["X-RateLimit-Reset-Day"] = str(status.reset_time_day)
            
            if config.policy_name:
                response.headers["X-RateLimit-Policy"] = config.policy_name
            
            return response
            
        except Exception as e:
            # Em caso de erro, permitir a requisição
            print(f"Rate limiting error: {e}")
            return await call_next(request)
    
    def _should_rate_limit(self, request: Request) -> bool:
        """Determina se a requisição deve ter rate limiting aplicado"""
        
        path = request.url.path
        
        # Não aplicar rate limiting em health checks e métricas
        skip_paths = ['/health', '/metrics', '/docs', '/openapi.json']
        if any(path.startswith(skip_path) for skip_path in skip_paths):
            return False
        
        # Aplicar rate limiting em endpoints da API
        return path.startswith('/api/')
    
    async def close(self):
        """Fechar conexões Redis"""
        if self.redis_client:
            await self.redis_client.close()

