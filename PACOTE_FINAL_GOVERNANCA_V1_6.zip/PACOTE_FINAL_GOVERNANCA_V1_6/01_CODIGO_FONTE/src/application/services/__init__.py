"""
Módulo de Serviços da Aplicação
API de Governança de Dados V1.4
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

# Importações dos serviços disponíveis
try:
    from .data_contract_service import DataContractService
except ImportError:
    DataContractService = None

try:
    from .domain_service import DomainService
except ImportError:
    DomainService = None

try:
    from .lineage_service import LineageService
except ImportError:
    LineageService = None

try:
    from .quality_service import QualityService
except ImportError:
    QualityService = None

try:
    from .policy_service import PolicyService
except ImportError:
    PolicyService = None

try:
    from .stewardship_service import StewardshipService
except ImportError:
    StewardshipService = None

__all__ = [
    'DataContractService',
    'DomainService', 
    'LineageService',
    'QualityService',
    'PolicyService',
    'StewardshipService'
]

