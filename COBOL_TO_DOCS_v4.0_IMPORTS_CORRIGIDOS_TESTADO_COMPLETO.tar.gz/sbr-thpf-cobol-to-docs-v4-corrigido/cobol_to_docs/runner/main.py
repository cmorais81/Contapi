#!/usr/bin/env python3
"""
COBOL to Docs v4.0 - Sistema de Análise e Documentação de Programas COBOL
Sistema completo para análise automatizada de programas COBOL com IA.
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Configurar path para imports
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, '..', 'src')
sys.path.insert(0, src_dir)

# Imports do sistema
try:
    from core.config import ConfigManager
    from parsers.cobol_parser import COBOLParser
    from providers.enhanced_provider_manager import EnhancedProviderManager
    from rag.rag_integration import RAGIntegration
    from providers.base_provider import AIRequest
    from core.custom_prompt_manager import CustomPromptManager
    from utils.enhanced_response_formatter import EnhancedResponseFormatter
except ImportError as e:
    print(f"Erro de import: {e}")
    print("Verifique se todos os módulos estão no diretório src/")
    sys.exit(1)

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

def parse_arguments() -> argparse.Namespace:
    """Parse dos argumentos da linha de comando."""
    parser = argparse.ArgumentParser(
        description='COBOL to Docs v4.0 - Análise automatizada de programas COBOL',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    # Argumentos principais
    parser.add_argument('--fontes', type=str, help='Arquivo com lista de programas COBOL')
    parser.add_argument('--books', type=str, help='Arquivo com lista de copybooks')
    parser.add_argument('--custom-prompt', type=str, help='Arquivo .txt com prompt customizado')
    parser.add_argument('--output', type=str, default='output', help='Diretório de saída')
    
    # Modos de análise
    parser.add_argument('--consolidado', action='store_true', help='Análise consolidada sistêmica')
    parser.add_argument('--analise-especialista', action='store_true', help='Análise especialista avançada')
    parser.add_argument('--deep-analysis', action='store_true', help='Análise detalhada de regras de negócio')
    
    # Configurações
    parser.add_argument('--config-dir', type=str, help='Diretório de configuração customizado')
    parser.add_argument('--data-dir', type=str, help='Diretório de dados customizado')
    parser.add_argument('--prompts-file', type=str, help='Arquivo de prompts customizado')
    parser.add_argument('--prompt-set', type=str, default='especialista', help='Conjunto de prompts')
    
    # Sistema
    parser.add_argument('--status', action='store_true', help='Mostrar status do sistema')
    parser.add_argument('--verbose', action='store_true', help='Logging detalhado')
    
    return parser.parse_args()

def show_status(config_manager: ConfigManager) -> None:
    """Mostra o status do sistema."""
    print("=== STATUS DO SISTEMA ===")
    
    try:
        # Inicializar provider manager
        provider_manager = EnhancedProviderManager(config_manager.config)
        
        print("\nProviders disponíveis:")
        for provider_name in provider_manager.providers:
            print(f"  {provider_name}: ✅ Ativo")
        
        # Status RAG
        try:
            rag_integration = RAGIntegration(config_manager)
            stats = rag_integration.get_rag_statistics()
            print(f"  Status RAG: ✅ {stats.get('total_items', 0)} itens")
        except Exception as e:
            print(f"  Status RAG: ❌ Erro - {e}")
            
    except Exception as e:
        print(f"Erro ao verificar status: {e}")

def load_file_list(file_path: str) -> List[str]:
    """Carrega lista de arquivos de um arquivo texto."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")
    
    with open(file_path, 'r', encoding='utf-8') as f:
        files = [line.strip() for line in f if line.strip()]
    
    return files

def main_logic(args: argparse.Namespace) -> None:
    """Lógica principal do programa."""
    logger = logging.getLogger(__name__)
    
    # Inicializar ConfigManager
    config_manager = ConfigManager(
        config_path=args.config_dir,
        data_dir=args.data_dir,
        prompts_file=args.prompts_file
    )
    
    # Mostrar status se solicitado
    if args.status:
        show_status(config_manager)
        return
    
    # Verificar se tem arquivos para processar
    if not args.fontes:
        print("Erro: É necessário especificar --fontes com o arquivo de lista de programas")
        return
    
    # Detectar modo avançado automático
    if not any([args.consolidado, args.analise_especialista, args.deep_analysis]):
        logger.info("=== NENHUM MODO ESPECÍFICO ESCOLHIDO - ATIVANDO MODO AVANÇADO PADRÃO ===")
        logger.info("Ativando: --consolidado + --analise-especialista + --deep-analysis")
        args.consolidado = True
        args.analise_especialista = True
        args.deep_analysis = True
        args.prompt_set = 'especialista'
    
    # Inicializar componentes
    provider_manager = EnhancedProviderManager(config_manager.config)
    parser = COBOLParser()
    
    # Verificar se deve usar prompt customizado
    use_custom_prompt = hasattr(args, 'custom_prompt') and args.custom_prompt and os.path.exists(args.custom_prompt)
    custom_prompt_manager = None
    
    if use_custom_prompt:
        logger.info(f"=== USANDO PROMPT CUSTOMIZADO: {args.custom_prompt} ===")
        try:
            custom_prompt_manager = CustomPromptManager(args.custom_prompt)
            
            if not custom_prompt_manager.has_custom_prompt():
                logger.error("Falha ao carregar prompt customizado")
                print("Erro: Não foi possível carregar o prompt customizado")
                use_custom_prompt = False
            else:
                prompt_info = custom_prompt_manager.get_prompt_info()
                logger.info(f"Prompt customizado: {prompt_info['size']} caracteres")
                print(f"Usando prompt customizado: {os.path.basename(args.custom_prompt)} ({prompt_info['size']} chars)")
        except Exception as e:
            logger.error(f"Erro ao inicializar custom prompt: {e}")
            use_custom_prompt = False
            custom_prompt_manager = None
    else:
        logger.info("=== USANDO PROMPTS PADRÕES ===")
    
    # Carregar lista de arquivos
    try:
        program_files = load_file_list(args.fontes)
        copybook_files = load_file_list(args.books) if args.books else []
        
        logger.info(f"Programas para processar: {len(program_files)}")
        logger.info(f"Copybooks disponíveis: {len(copybook_files)}")
        
    except Exception as e:
        logger.error(f"Erro ao carregar arquivos: {e}")
        print(f"Erro: {e}")
        return
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    # Processar programas
    all_results = []
    
    print(f"\nIniciando análise de {len(program_files)} programa(s)...")
    
    for i, program_file in enumerate(program_files, 1):
        print(f"Analisando programa {i}/{len(program_files)}: {os.path.basename(program_file)}")
        
        try:
            # Parse do programa
            programs, copybooks = parser.parse_file(program_file)
            
            if not programs:
                logger.warning(f"Nenhum programa encontrado em: {program_file}")
                continue
            
            program = programs[0]  # Usar o primeiro programa
            
            # Análise com prompt customizado
            if use_custom_prompt and custom_prompt_manager:
                try:
                    # Criar prompt customizado
                    prompt = custom_prompt_manager.create_custom_analysis_prompt(
                        program_name=program.name,
                        program_code=program.content,
                        copybooks=copybooks
                    )
                    
                    # Criar request
                    request = AIRequest(
                        prompt=prompt,
                        program_code=program.content,
                        program_name=program.name,
                        context={'model': 'custom_prompt', 'prompt_file': args.custom_prompt}
                    )
                    
                    # Fazer análise
                    response = provider_manager.analyze(request)
                    
                    if response.success:
                        # Salvar resultado
                        output_file = os.path.join(args.output, f"{program.name}_custom_prompt_analise.md")
                        debug_file = os.path.join(args.output, f"{program.name}_custom_prompt_debug.json")
                        
                        # Usar Enhanced Response Formatter
                        response_formatter = EnhancedResponseFormatter()
                        
                        request_info = {
                            'program_name': program.name,
                            'model': 'custom_prompt',
                            'prompt_length': len(prompt),
                            'program_code_length': len(program.content),
                            'prompt_file': args.custom_prompt,
                            'copybooks_count': len(copybooks),
                            'custom_prompt': True
                        }
                        
                        complete_report = response_formatter.format_complete_analysis_report(
                            program_name=program.name,
                            response=response,
                            request_info=request_info,
                            debug_mode=True
                        )
                        
                        with open(output_file, 'w', encoding='utf-8') as f:
                            f.write(complete_report)
                        
                        debug_data = response_formatter.create_debug_json(
                            program_name=program.name,
                            request_info=request_info,
                            response=response
                        )
                        
                        with open(debug_file, 'w', encoding='utf-8') as f:
                            json.dump(debug_data, f, indent=2, ensure_ascii=False)
                        
                        logger.info(f"Análise customizada salva em: {output_file}")
                        print(f"   Análise concluída - {response.tokens_used} tokens")
                        
                        all_results.append({
                            'program': program.name,
                            'model': 'custom_prompt',
                            'success': True,
                            'tokens': response.tokens_used,
                            'time': response.response_time,
                            'output_file': output_file
                        })
                        
                        continue  # Pular análise padrão
                    
                    else:
                        logger.error(f"Erro com prompt customizado: {response.error_message}")
                        print(f"   Erro: {response.error_message}")
                        # Continuar com análise padrão como fallback
                
                except Exception as e:
                    logger.error(f"Erro na análise customizada: {e}")
                    print(f"   Erro na análise customizada: {e}")
                    # Continuar com análise padrão como fallback
            
            # Análise padrão (fallback ou modo normal)
            try:
                # Criar prompt padrão simples
                prompt = f"Analise o programa COBOL: {program.name}\n\nCódigo:\n{program.content}"
                
                request = AIRequest(
                    prompt=prompt,
                    program_code=program.content,
                    program_name=program.name,
                    context={'model': 'enhanced_mock'}
                )
                
                response = provider_manager.analyze(request)
                
                if response.success:
                    # Salvar resultado padrão
                    output_file = os.path.join(args.output, f"{program.name}_enhanced_mock_analise.md")
                    debug_file = os.path.join(args.output, f"{program.name}_enhanced_mock_debug.json")
                    
                    response_formatter = EnhancedResponseFormatter()
                    
                    request_info = {
                        'program_name': program.name,
                        'model': 'enhanced_mock',
                        'prompt_length': len(prompt),
                        'program_code_length': len(program.content),
                        'copybooks_count': len(copybooks),
                        'custom_prompt': False
                    }
                    
                    complete_report = response_formatter.format_complete_analysis_report(
                        program_name=program.name,
                        response=response,
                        request_info=request_info,
                        debug_mode=True
                    )
                    
                    with open(output_file, 'w', encoding='utf-8') as f:
                        f.write(complete_report)
                    
                    debug_data = response_formatter.create_debug_json(
                        program_name=program.name,
                        request_info=request_info,
                        response=response
                    )
                    
                    with open(debug_file, 'w', encoding='utf-8') as f:
                        json.dump(debug_data, f, indent=2, ensure_ascii=False)
                    
                    logger.info(f"Análise padrão salva em: {output_file}")
                    print(f"   Análise concluída - {response.tokens_used} tokens")
                    
                    all_results.append({
                        'program': program.name,
                        'model': 'enhanced_mock',
                        'success': True,
                        'tokens': response.tokens_used,
                        'time': response.response_time,
                        'output_file': output_file
                    })
                
                else:
                    logger.error(f"Erro na análise padrão: {response.error_message}")
                    print(f"   Erro: {response.error_message}")
            
            except Exception as e:
                logger.error(f"Erro ao processar {program.name}: {e}")
                print(f"   Erro: {e}")
        
        except Exception as e:
            logger.error(f"Erro ao processar arquivo {program_file}: {e}")
            print(f"   Erro: {e}")
    
    # Resumo final
    successful_analyses = [r for r in all_results if r['success']]
    total_tokens = sum(r['tokens'] for r in successful_analyses)
    total_time = sum(r['time'] for r in successful_analyses)
    
    print("\n" + "="*60)
    print("PROCESSAMENTO CONCLUÍDO")
    print(f"Programas processados: {len(program_files)}")
    print(f"Análises bem-sucedidas: {len(successful_analyses)}/{len(all_results)}")
    print(f"Total de tokens utilizados: {total_tokens}")
    print(f"Tempo total: {total_time:.2f}s")
    print(f"Resultados salvos em: {args.output}")
    
    logger.info("Processamento concluído com sucesso")

def main() -> None:
    """Função principal."""
    args = parse_arguments()
    
    # Configurar logging
    log_level = "DEBUG" if args.verbose else "INFO"
    setup_logging(log_level)
    
    try:
        main_logic(args)
    except KeyboardInterrupt:
        print("\nProcessamento interrompido pelo usuário")
    except Exception as e:
        logging.error(f"Erro fatal: {e}")
        print(f"Erro fatal: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
