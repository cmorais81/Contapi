# Documentação Técnica Completa - API de Governança de Dados V1.1

**Desenvolvido por:** Carlos Morais (carlos.morais@f1rst.com.br)  
**Organização:** F1rst  
**Versão:** 1.1.0  
**Data:** Junho 2025

## Sumário

1. [Introdução](#introdução)
2. [Arquitetura do Sistema](#arquitetura-do-sistema)
3. [Instalação e Configuração](#instalação-e-configuração)
4. [Autenticação e Autorização](#autenticação-e-autorização)
5. [Guia de Início Rápido](#guia-de-início-rápido)
6. [Referência Completa da API](#referência-completa-da-api)
7. [Modelos de Dados](#modelos-de-dados)
8. [Exemplos de Uso](#exemplos-de-uso)
9. [Integrações](#integrações)
10. [Tratamento de Erros](#tratamento-de-erros)
11. [Performance e Otimização](#performance-e-otimização)
12. [Segurança](#segurança)
13. [Monitoramento](#monitoramento)
14. [Troubleshooting](#troubleshooting)
15. [FAQ](#faq)
16. [Suporte](#suporte)

## Introdução

A API de Governança de Dados V1.1 é uma solução enterprise robusta projetada para gerenciar o ciclo de vida completo dos dados corporativos. Esta documentação fornece informações detalhadas sobre instalação, configuração, uso e manutenção da plataforma.

### Principais Funcionalidades

**Descoberta e Catalogação**
- Detecção automática de novas entidades de dados
- Catalogação inteligente com enriquecimento por IA
- Classificação automática de sensibilidade

**Contratos de Dados**
- Definição formal de SLAs de qualidade
- Versionamento de contratos
- Processo de aprovação estruturado

**Qualidade de Dados**
- Regras de qualidade configuráveis
- Monitoramento contínuo
- Alertas automáticos

**Segurança e Compliance**
- Mascaramento dinâmico de dados sensíveis
- Políticas de retenção e expurgo
- Auditoria completa de acessos

**Otimização de Custos**
- Gestão inteligente de temperatura dos dados
- Migração automática entre tiers de storage
- Análise de padrões de uso

## Arquitetura do Sistema

### Visão Geral da Arquitetura

```
┌─────────────────────────────────────────────────────────────────┐
│                    Frontend Applications                        │
├─────────────────────────────────────────────────────────────────┤
│  Web UI  │  Power BI  │  Tableau  │  Custom Apps  │  CLI Tools  │
└─────────────────────────────────────────────────────────────────┘
                                │
┌─────────────────────────────────────────────────────────────────┐
│                      API Gateway                                │
├─────────────────────────────────────────────────────────────────┤
│  Authentication  │  Rate Limiting  │  Load Balancing  │  Logging │
└─────────────────────────────────────────────────────────────────┘
                                │
┌─────────────────────────────────────────────────────────────────┐
│                   Core API Services                             │
├─────────────────────────────────────────────────────────────────┤
│ Catalog │ Quality │ Lineage │ Security │ Workflows │ Analytics  │
└─────────────────────────────────────────────────────────────────┘
                                │
┌─────────────────────────────────────────────────────────────────┐
│                   Data Layer                                    │
├─────────────────────────────────────────────────────────────────┤
│  PostgreSQL  │  Redis Cache  │  Object Storage  │  Search Index │
└─────────────────────────────────────────────────────────────────┘
                                │
┌─────────────────────────────────────────────────────────────────┐
│                 External Integrations                           │
├─────────────────────────────────────────────────────────────────┤
│   Azure   │ Databricks │ Informatica │ Collibra │ Power BI     │
└─────────────────────────────────────────────────────────────────┘
```

### Componentes Principais

**API Gateway**
- Nginx com módulos de autenticação
- Rate limiting e throttling
- Load balancing entre instâncias
- SSL termination

**Core Services**
- FastAPI com Python 3.11
- Arquitetura de microserviços
- Processamento assíncrono com Celery
- Cache distribuído com Redis

**Banco de Dados**
- PostgreSQL 14+ como banco principal
- Elasticsearch para busca full-text
- Redis para cache e sessões
- MinIO para armazenamento de objetos

**Monitoramento**
- Prometheus para coleta de métricas
- Grafana para visualização
- ELK Stack para logs centralizados
- Jaeger para tracing distribuído

## Instalação e Configuração

### Requisitos do Sistema

**Hardware Mínimo**
- CPU: 4 cores
- RAM: 16GB
- Storage: 100GB SSD
- Network: 1Gbps

**Hardware Recomendado**
- CPU: 8 cores
- RAM: 32GB
- Storage: 500GB SSD
- Network: 10Gbps

**Software**
- Docker 20.10+
- Docker Compose 2.0+
- Python 3.11+
- PostgreSQL 14+
- Redis 6+

### Instalação via Docker

```bash
# 1. Clone o repositório
git clone https://github.com/f1rst/governance-data-api-v1.1.git
cd governance-data-api-v1.1

# 2. Configure as variáveis de ambiente
cp .env.example .env
nano .env

# 3. Inicie os serviços
docker-compose up -d

# 4. Execute as migrações
docker-compose exec api alembic upgrade head

# 5. Crie o usuário administrador
docker-compose exec api python scripts/create_admin.py
```

### Configuração Manual

```bash
# 1. Instale as dependências
pip install -r requirements.txt

# 2. Configure o banco de dados
createdb governance_api
psql governance_api < schema/init.sql

# 3. Execute as migrações
alembic upgrade head

# 4. Configure o Redis
redis-server --daemonize yes

# 5. Inicie a aplicação
uvicorn main:app --host 0.0.0.0 --port 8000
```

### Variáveis de Ambiente

```bash
# Banco de Dados
DATABASE_URL=postgresql://user:password@localhost:5432/governance_api
REDIS_URL=redis://localhost:6379/0

# Autenticação
SECRET_KEY=your-secret-key-here
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=30

# Integrações
AZURE_CLIENT_ID=your-azure-client-id
AZURE_CLIENT_SECRET=your-azure-client-secret
DATABRICKS_TOKEN=your-databricks-token

# Monitoramento
PROMETHEUS_ENABLED=true
GRAFANA_ENABLED=true
LOG_LEVEL=INFO
```

## Autenticação e Autorização

### Métodos de Autenticação

**API Keys**
```python
import requests

headers = {
    'X-API-Key': 'your-api-key-here',
    'Content-Type': 'application/json'
}

response = requests.get(
    'https://api.governance.f1rst.com/v1/entities',
    headers=headers
)
```

**OAuth2 / JWT**
```python
# 1. Obter token
auth_response = requests.post(
    'https://api.governance.f1rst.com/v1/auth/token',
    data={
        'username': 'your-username',
        'password': 'your-password'
    }
)
token = auth_response.json()['access_token']

# 2. Usar token nas requisições
headers = {
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json'
}
```

**Azure AD Integration**
```python
from azure.identity import DefaultAzureCredential
from azure.core.credentials import AccessToken

credential = DefaultAzureCredential()
token = credential.get_token("https://api.governance.f1rst.com/.default")

headers = {
    'Authorization': f'Bearer {token.token}',
    'Content-Type': 'application/json'
}
```

### Sistema de Permissões

**Roles Padrão**
- **Admin:** Acesso completo ao sistema
- **Data Steward:** Gestão de entidades e qualidade
- **Data Engineer:** Criação e manutenção de pipelines
- **Business Analyst:** Consulta e análise de dados
- **Viewer:** Apenas leitura

**Permissões Granulares**
```json
{
  "permissions": {
    "entities": ["read", "write", "delete"],
    "contracts": ["read", "write"],
    "quality": ["read", "write"],
    "lineage": ["read"],
    "admin": ["users", "roles", "system"]
  }
}
```

## Guia de Início Rápido

### Cenário 1: Catalogar uma Nova Tabela

```python
import requests

# 1. Criar entidade
entity_data = {
    "name": "customer_orders",
    "description": "Tabela de pedidos de clientes",
    "entity_type": "table",
    "data_source": "Azure SQL Database",
    "schema_name": "dbo",
    "table_name": "customer_orders",
    "domain_id": "sales_domain_id"
}

response = requests.post(
    'https://api.governance.f1rst.com/v1/entities',
    json=entity_data,
    headers=headers
)
entity_id = response.json()['id']

# 2. Adicionar atributos
attributes = [
    {
        "name": "order_id",
        "data_type": "integer",
        "is_primary_key": True,
        "description": "Identificador único do pedido"
    },
    {
        "name": "customer_id",
        "data_type": "integer",
        "is_pii": True,
        "description": "Identificador do cliente"
    },
    {
        "name": "total_amount",
        "data_type": "decimal",
        "is_sensitive": True,
        "description": "Valor total do pedido"
    }
]

for attr in attributes:
    attr['entity_id'] = entity_id
    requests.post(
        'https://api.governance.f1rst.com/v1/attributes',
        json=attr,
        headers=headers
    )
```

### Cenário 2: Definir Contrato de Dados

```python
# Criar contrato
contract_data = {
    "name": "customer_orders_contract",
    "description": "Contrato para tabela de pedidos",
    "entity_id": entity_id,
    "version": "1.0.0",
    "schema_definition": {
        "type": "object",
        "properties": {
            "order_id": {"type": "integer", "minimum": 1},
            "customer_id": {"type": "integer", "minimum": 1},
            "total_amount": {"type": "number", "minimum": 0.01}
        },
        "required": ["order_id", "customer_id", "total_amount"]
    },
    "sla_definition": {
        "availability": 99.99,
        "freshness_minutes": 15,
        "completeness": 99.9
    }
}

contract_response = requests.post(
    'https://api.governance.f1rst.com/v1/contracts',
    json=contract_data,
    headers=headers
)
```

### Cenário 3: Configurar Regras de Qualidade

```python
# Regra de completude
completeness_rule = {
    "name": "customer_orders_completeness",
    "entity_id": entity_id,
    "rule_type": "completeness",
    "rule_definition": {
        "fields": ["order_id", "customer_id", "total_amount"],
        "threshold": 99.9
    },
    "severity": "high"
}

# Regra de validade
validity_rule = {
    "name": "customer_orders_validity",
    "entity_id": entity_id,
    "rule_type": "validity",
    "sql_expression": "total_amount > 0 AND order_date <= CURRENT_DATE",
    "threshold_value": 99.5,
    "severity": "medium"
}

# Criar regras
for rule in [completeness_rule, validity_rule]:
    requests.post(
        'https://api.governance.f1rst.com/v1/quality/rules',
        json=rule,
        headers=headers
    )
```

## Referência Completa da API

### Entidades (Entities)

**Listar Entidades**
```http
GET /api/v1/entities
```

Parâmetros de Query:
- `domain_id` (string): Filtrar por domínio
- `entity_type` (string): Filtrar por tipo
- `classification` (string): Filtrar por classificação
- `page` (int): Número da página (padrão: 1)
- `size` (int): Tamanho da página (padrão: 20)

Exemplo de Resposta:
```json
{
  "items": [
    {
      "id": "entity_123",
      "name": "customer_orders",
      "description": "Tabela de pedidos de clientes",
      "entity_type": "table",
      "domain_id": "sales_domain",
      "classification": "confidential",
      "is_active": true,
      "created_at": "2025-06-15T10:30:00Z",
      "updated_at": "2025-06-15T10:30:00Z"
    }
  ],
  "total": 1,
  "page": 1,
  "size": 20
}
```

**Criar Entidade**
```http
POST /api/v1/entities
```

Corpo da Requisição:
```json
{
  "name": "customer_orders",
  "description": "Tabela de pedidos de clientes",
  "entity_type": "table",
  "data_source": "Azure SQL Database",
  "domain_id": "sales_domain_id",
  "classification": "confidential",
  "is_pii": false,
  "is_sensitive": true
}
```

**Obter Entidade**
```http
GET /api/v1/entities/{entity_id}
```

**Atualizar Entidade**
```http
PUT /api/v1/entities/{entity_id}
```

**Deletar Entidade**
```http
DELETE /api/v1/entities/{entity_id}
```

### Contratos de Dados (Data Contracts)

**Listar Contratos**
```http
GET /api/v1/contracts
```

**Criar Contrato**
```http
POST /api/v1/contracts
```

Exemplo de Corpo:
```json
{
  "name": "customer_orders_contract",
  "description": "Contrato para tabela de pedidos",
  "entity_id": "entity_123",
  "version": "1.0.0",
  "schema_definition": {
    "type": "object",
    "properties": {
      "order_id": {"type": "integer"},
      "customer_id": {"type": "integer"},
      "total_amount": {"type": "number"}
    }
  },
  "sla_definition": {
    "availability": 99.99,
    "freshness_minutes": 15,
    "completeness": 99.9
  }
}
```

**Versões do Contrato**
```http
GET /api/v1/contracts/{contract_id}/versions
```

**Aprovar Contrato**
```http
POST /api/v1/contracts/{contract_id}/approve
```

### Qualidade de Dados (Data Quality)

**Listar Regras de Qualidade**
```http
GET /api/v1/quality/rules
```

**Criar Regra de Qualidade**
```http
POST /api/v1/quality/rules
```

Exemplo de Regra de Completude:
```json
{
  "name": "customer_orders_completeness",
  "entity_id": "entity_123",
  "rule_type": "completeness",
  "rule_definition": {
    "fields": ["order_id", "customer_id"],
    "threshold": 99.9
  },
  "severity": "high",
  "is_active": true
}
```

Exemplo de Regra de Validade:
```json
{
  "name": "customer_orders_validity",
  "entity_id": "entity_123",
  "rule_type": "validity",
  "sql_expression": "total_amount > 0",
  "threshold_value": 99.5,
  "severity": "medium"
}
```

**Métricas de Qualidade**
```http
GET /api/v1/quality/metrics
```

Parâmetros:
- `entity_id` (string): ID da entidade
- `rule_id` (string): ID da regra
- `start_date` (string): Data inicial (ISO 8601)
- `end_date` (string): Data final (ISO 8601)

**Executar Regra de Qualidade**
```http
POST /api/v1/quality/rules/{rule_id}/execute
```

### Lineage de Dados

**Obter Lineage de uma Entidade**
```http
GET /api/v1/lineage/{entity_id}
```

Parâmetros:
- `direction` (string): upstream, downstream, both (padrão: both)
- `depth` (int): Profundidade do lineage (padrão: 3)

**Registrar Lineage**
```http
POST /api/v1/lineage
```

Exemplo:
```json
{
  "source_entity_id": "source_entity_123",
  "target_entity_id": "target_entity_456",
  "transformation_type": "aggregation",
  "transformation_logic": "GROUP BY customer_id, SUM(total_amount)",
  "job_name": "daily_sales_summary"
}
```

### Políticas de Governança

**Listar Políticas**
```http
GET /api/v1/policies
```

**Criar Política**
```http
POST /api/v1/policies
```

Exemplo de Política de Retenção:
```json
{
  "name": "customer_data_retention",
  "policy_type": "retention",
  "description": "Política de retenção para dados de clientes",
  "policy_definition": {
    "retention_period_days": 2555,  // 7 anos
    "archive_after_days": 730,      // 2 anos
    "delete_after_days": 6205       // 17 anos
  },
  "enforcement_level": "blocking"
}
```

**Violações de Política**
```http
GET /api/v1/policies/violations
```

### Mascaramento de Dados

**Listar Regras de Mascaramento**
```http
GET /api/v1/masking/rules
```

**Criar Regra de Mascaramento**
```http
POST /api/v1/masking/rules
```

Exemplo:
```json
{
  "name": "customer_id_masking",
  "entity_id": "entity_123",
  "attribute_id": "attr_456",
  "masking_type": "hash",
  "masking_algorithm": "sha256",
  "environments": ["dev", "test"],
  "preserve_format": true
}
```

### Gestão de Temperatura

**Políticas de Temperatura**
```http
GET /api/v1/temperature/policies
POST /api/v1/temperature/policies
```

**Padrões de Acesso**
```http
GET /api/v1/temperature/access-patterns/{entity_id}
```

**Migrações de Storage**
```http
GET /api/v1/temperature/migrations
POST /api/v1/temperature/migrations
```

### Catálogo e Descoberta

**Buscar no Catálogo**
```http
GET /api/v1/catalog/search
```

Parâmetros:
- `q` (string): Termo de busca
- `domain` (string): Filtrar por domínio
- `tags` (array): Filtrar por tags
- `classification` (string): Filtrar por classificação

**Entradas do Catálogo**
```http
GET /api/v1/catalog/entries
POST /api/v1/catalog/entries
```

### Workflows

**Definições de Workflow**
```http
GET /api/v1/workflows/definitions
POST /api/v1/workflows/definitions
```

**Instâncias de Workflow**
```http
GET /api/v1/workflows/instances
POST /api/v1/workflows/instances
```

**Executar Workflow**
```http
POST /api/v1/workflows/instances/{instance_id}/execute
```

### Notificações

**Listar Notificações**
```http
GET /api/v1/notifications
```

**Marcar como Lida**
```http
PUT /api/v1/notifications/{notification_id}/read
```

**Preferências de Notificação**
```http
GET /api/v1/notifications/preferences
PUT /api/v1/notifications/preferences
```

### Auditoria

**Logs de Auditoria**
```http
GET /api/v1/audit/logs
```

Parâmetros:
- `user_id` (string): Filtrar por usuário
- `action` (string): Filtrar por ação
- `resource_type` (string): Filtrar por tipo de recurso
- `start_date` (string): Data inicial
- `end_date` (string): Data final

**Métricas de Performance**
```http
GET /api/v1/audit/performance
```

## Modelos de Dados

### Entidade (Entity)

```json
{
  "id": "uuid",
  "name": "string",
  "display_name": "string",
  "description": "string",
  "domain_id": "uuid",
  "contract_id": "uuid",
  "entity_type": "table|view|file|api|stream",
  "data_source": "string",
  "physical_location": "string",
  "schema_name": "string",
  "table_name": "string",
  "classification": "public|internal|confidential|restricted",
  "sensitivity_level": "low|medium|high|critical",
  "owner_id": "uuid",
  "steward_id": "uuid",
  "is_pii": "boolean",
  "is_sensitive": "boolean",
  "is_active": "boolean",
  "row_count": "integer",
  "size_bytes": "integer",
  "created_at": "datetime",
  "updated_at": "datetime"
}
```

### Contrato de Dados (Data Contract)

```json
{
  "id": "uuid",
  "name": "string",
  "description": "string",
  "domain_id": "uuid",
  "owner_id": "uuid",
  "version": "string",
  "status": "draft|review|approved|deprecated",
  "schema_definition": "object",
  "sla_definition": {
    "availability": "number",
    "freshness_minutes": "integer",
    "completeness": "number",
    "accuracy": "number"
  },
  "quality_requirements": "object",
  "security_requirements": "object",
  "retention_policy": "object",
  "effective_date": "datetime",
  "expiration_date": "datetime",
  "created_at": "datetime",
  "updated_at": "datetime"
}
```

### Regra de Qualidade (Quality Rule)

```json
{
  "id": "uuid",
  "name": "string",
  "description": "string",
  "entity_id": "uuid",
  "attribute_id": "uuid",
  "rule_type": "completeness|uniqueness|validity|consistency",
  "rule_definition": "object",
  "sql_expression": "string",
  "threshold_value": "number",
  "severity": "low|medium|high|critical",
  "is_active": "boolean",
  "schedule_expression": "string",
  "created_at": "datetime",
  "updated_at": "datetime"
}
```

### Métrica de Qualidade (Quality Metric)

```json
{
  "id": "uuid",
  "rule_id": "uuid",
  "entity_id": "uuid",
  "execution_date": "datetime",
  "metric_value": "number",
  "threshold_value": "number",
  "status": "passed|failed|warning",
  "total_records": "integer",
  "failed_records": "integer",
  "execution_time_ms": "integer",
  "error_message": "string",
  "details": "object",
  "created_at": "datetime"
}
```

## Exemplos de Uso

### Exemplo 1: Monitoramento de Qualidade em Tempo Real

```python
import asyncio
import websockets
import json

async def monitor_quality():
    uri = "wss://api.governance.f1rst.com/v1/quality/monitor"
    
    async with websockets.connect(uri) as websocket:
        # Subscrever a entidade
        subscribe_msg = {
            "action": "subscribe",
            "entity_id": "customer_orders_entity_id"
        }
        await websocket.send(json.dumps(subscribe_msg))
        
        # Receber atualizações
        async for message in websocket:
            data = json.loads(message)
            
            if data['type'] == 'quality_metric':
                metric = data['payload']
                print(f"Nova métrica: {metric['rule_name']}")
                print(f"Valor: {metric['metric_value']}")
                print(f"Status: {metric['status']}")
                
                if metric['status'] == 'failed':
                    # Enviar alerta
                    send_alert(metric)

def send_alert(metric):
    # Implementar lógica de alerta
    pass

# Executar monitoramento
asyncio.run(monitor_quality())
```

### Exemplo 2: Automação de Catalogação

```python
import os
import sqlalchemy
from governance_api_client import GovernanceClient

def auto_catalog_database():
    # Conectar ao banco
    engine = sqlalchemy.create_engine(os.getenv('DATABASE_URL'))
    
    # Conectar à API de governança
    client = GovernanceClient(
        base_url='https://api.governance.f1rst.com',
        api_key=os.getenv('GOVERNANCE_API_KEY')
    )
    
    # Obter lista de tabelas
    inspector = sqlalchemy.inspect(engine)
    tables = inspector.get_table_names()
    
    for table_name in tables:
        # Verificar se já está catalogada
        existing = client.entities.search(name=table_name)
        if existing:
            continue
            
        # Obter metadados da tabela
        columns = inspector.get_columns(table_name)
        
        # Criar entidade
        entity = client.entities.create({
            'name': table_name,
            'entity_type': 'table',
            'data_source': 'PostgreSQL',
            'schema_name': 'public',
            'table_name': table_name
        })
        
        # Adicionar atributos
        for column in columns:
            client.attributes.create({
                'entity_id': entity['id'],
                'name': column['name'],
                'data_type': str(column['type']),
                'is_nullable': column['nullable'],
                'is_primary_key': column.get('primary_key', False)
            })
        
        print(f"Catalogada: {table_name}")

if __name__ == '__main__':
    auto_catalog_database()
```

### Exemplo 3: Implementação de Data Contract Testing

```python
import pytest
from governance_api_client import GovernanceClient
import pandas as pd

class TestDataContract:
    def setup_method(self):
        self.client = GovernanceClient(
            base_url='https://api.governance.f1rst.com',
            api_key=os.getenv('GOVERNANCE_API_KEY')
        )
        self.entity_id = 'customer_orders_entity_id'
    
    def test_schema_compliance(self):
        """Testa se os dados estão em conformidade com o schema do contrato"""
        # Obter contrato
        contract = self.client.contracts.get_by_entity(self.entity_id)
        schema = contract['schema_definition']
        
        # Obter amostra dos dados
        data_sample = self.client.entities.sample(self.entity_id, limit=1000)
        df = pd.DataFrame(data_sample)
        
        # Validar schema
        for field, definition in schema['properties'].items():
            assert field in df.columns, f"Campo {field} não encontrado"
            
            if definition['type'] == 'integer':
                assert df[field].dtype in ['int64', 'int32']
            elif definition['type'] == 'number':
                assert df[field].dtype in ['float64', 'float32']
    
    def test_sla_compliance(self):
        """Testa se os SLAs estão sendo atendidos"""
        # Obter métricas de qualidade
        metrics = self.client.quality.get_metrics(
            entity_id=self.entity_id,
            days=1
        )
        
        # Verificar SLA de completude
        completeness_metrics = [m for m in metrics if m['rule_type'] == 'completeness']
        if completeness_metrics:
            latest = max(completeness_metrics, key=lambda x: x['execution_date'])
            assert latest['metric_value'] >= 99.9, "SLA de completude não atendido"
        
        # Verificar SLA de atualidade
        freshness = self.client.entities.get_freshness(self.entity_id)
        assert freshness['minutes'] <= 15, "SLA de atualidade não atendido"
    
    def test_data_quality_rules(self):
        """Testa regras específicas de qualidade"""
        # Executar todas as regras de qualidade
        rules = self.client.quality.get_rules(entity_id=self.entity_id)
        
        for rule in rules:
            result = self.client.quality.execute_rule(rule['id'])
            assert result['status'] in ['passed', 'warning'], f"Regra {rule['name']} falhou"

if __name__ == '__main__':
    pytest.main([__file__])
```

## Integrações

### Azure Integration

**Configuração do Azure Connector**

```python
azure_config = {
    "type": "azure",
    "subscription_id": "your-subscription-id",
    "resource_group": "your-resource-group",
    "credentials": {
        "client_id": "your-client-id",
        "client_secret": "your-client-secret",
        "tenant_id": "your-tenant-id"
    },
    "services": {
        "sql_database": {
            "enabled": True,
            "auto_discovery": True,
            "masking_enabled": True
        },
        "synapse": {
            "enabled": True,
            "workspace_name": "your-synapse-workspace"
        },
        "data_lake": {
            "enabled": True,
            "account_name": "your-storage-account",
            "lifecycle_management": True
        },
        "purview": {
            "enabled": True,
            "account_name": "your-purview-account",
            "sync_bidirectional": True
        }
    }
}

# Registrar conector
response = requests.post(
    'https://api.governance.f1rst.com/v1/integrations',
    json=azure_config,
    headers=headers
)
```

**Azure SQL Database Integration**

```python
# Configurar mascaramento dinâmico
masking_config = {
    "server": "your-server.database.windows.net",
    "database": "your-database",
    "rules": [
        {
            "table": "customers",
            "column": "email",
            "masking_function": "email()"
        },
        {
            "table": "customers", 
            "column": "phone",
            "masking_function": "partial(1,'XXX-XXX-',4)"
        }
    ]
}

# Aplicar configuração
client.integrations.azure.configure_masking(masking_config)
```

### Databricks Unity Catalog Integration

**Configuração**

```python
databricks_config = {
    "type": "databricks",
    "workspace_url": "https://your-workspace.cloud.databricks.com",
    "token": "your-access-token",
    "unity_catalog": {
        "enabled": True,
        "metastore_id": "your-metastore-id",
        "sync_frequency": "hourly"
    },
    "lineage_tracking": {
        "enabled": True,
        "include_notebooks": True,
        "include_jobs": True
    }
}

# Registrar integração
client.integrations.create(databricks_config)
```

**Sincronização de Metadados**

```python
# Sincronizar catálogos
sync_job = client.integrations.databricks.sync_catalogs()

# Monitorar progresso
while sync_job['status'] == 'running':
    time.sleep(30)
    sync_job = client.integrations.get_job(sync_job['id'])

print(f"Sincronização concluída: {sync_job['records_synced']} registros")
```

### Power BI Integration

**Descoberta de Datasets**

```python
powerbi_config = {
    "type": "powerbi",
    "tenant_id": "your-tenant-id",
    "client_id": "your-client-id",
    "client_secret": "your-client-secret",
    "workspaces": ["workspace-1", "workspace-2"],
    "auto_discovery": True,
    "lineage_tracking": True
}

# Descobrir datasets
datasets = client.integrations.powerbi.discover_datasets()

for dataset in datasets:
    # Criar entidade no catálogo
    entity = client.entities.create({
        'name': dataset['name'],
        'entity_type': 'dataset',
        'data_source': 'Power BI',
        'external_id': dataset['id'],
        'metadata': dataset
    })
```

## Tratamento de Erros

### Códigos de Erro Padrão

**400 - Bad Request**
```json
{
  "error": "validation_error",
  "message": "Dados de entrada inválidos",
  "details": {
    "field": "entity_type",
    "error": "Valor deve ser um de: table, view, file, api, stream"
  }
}
```

**401 - Unauthorized**
```json
{
  "error": "authentication_required",
  "message": "Token de autenticação necessário"
}
```

**403 - Forbidden**
```json
{
  "error": "insufficient_permissions",
  "message": "Permissões insuficientes para esta operação",
  "required_permission": "entities:write"
}
```

**404 - Not Found**
```json
{
  "error": "resource_not_found",
  "message": "Entidade não encontrada",
  "resource_id": "entity_123"
}
```

**429 - Rate Limit Exceeded**
```json
{
  "error": "rate_limit_exceeded",
  "message": "Limite de requisições excedido",
  "retry_after": 60
}
```

**500 - Internal Server Error**
```json
{
  "error": "internal_error",
  "message": "Erro interno do servidor",
  "request_id": "req_123456"
}
```

### Tratamento de Erros no Cliente

```python
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

class GovernanceAPIClient:
    def __init__(self, base_url, api_key):
        self.base_url = base_url
        self.session = requests.Session()
        self.session.headers.update({
            'X-API-Key': api_key,
            'Content-Type': 'application/json'
        })
        
        # Configurar retry automático
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504]
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
    
    def make_request(self, method, endpoint, **kwargs):
        url = f"{self.base_url}{endpoint}"
        
        try:
            response = self.session.request(method, url, **kwargs)
            response.raise_for_status()
            return response.json()
            
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 400:
                error_data = e.response.json()
                raise ValidationError(error_data['message'], error_data.get('details'))
            elif e.response.status_code == 401:
                raise AuthenticationError("Token inválido ou expirado")
            elif e.response.status_code == 403:
                raise PermissionError("Permissões insuficientes")
            elif e.response.status_code == 404:
                raise ResourceNotFoundError("Recurso não encontrado")
            elif e.response.status_code == 429:
                raise RateLimitError("Limite de requisições excedido")
            else:
                raise APIError(f"Erro da API: {e.response.status_code}")
                
        except requests.exceptions.ConnectionError:
            raise ConnectionError("Erro de conexão com a API")
        except requests.exceptions.Timeout:
            raise TimeoutError("Timeout na requisição")

# Exceções customizadas
class APIError(Exception):
    pass

class ValidationError(APIError):
    def __init__(self, message, details=None):
        super().__init__(message)
        self.details = details

class AuthenticationError(APIError):
    pass

class PermissionError(APIError):
    pass

class ResourceNotFoundError(APIError):
    pass

class RateLimitError(APIError):
    pass
```

## Performance e Otimização

### Configurações de Performance

**Cache Configuration**

```python
# Redis cache settings
CACHE_CONFIG = {
    "redis_url": "redis://localhost:6379/0",
    "default_timeout": 300,  # 5 minutos
    "key_prefix": "governance_api:",
    "cache_strategies": {
        "entities": {
            "timeout": 600,  # 10 minutos
            "invalidate_on_update": True
        },
        "quality_metrics": {
            "timeout": 60,   # 1 minuto
            "invalidate_on_update": False
        },
        "search_results": {
            "timeout": 180,  # 3 minutos
            "invalidate_on_update": False
        }
    }
}
```

**Database Optimization**

```sql
-- Índices recomendados para performance
CREATE INDEX CONCURRENTLY idx_entities_domain_id ON entities(domain_id);
CREATE INDEX CONCURRENTLY idx_entities_entity_type ON entities(entity_type);
CREATE INDEX CONCURRENTLY idx_entities_classification ON entities(classification);
CREATE INDEX CONCURRENTLY idx_quality_metrics_entity_date ON quality_metrics(entity_id, execution_date);
CREATE INDEX CONCURRENTLY idx_audit_logs_user_date ON audit_logs(user_id, created_at);
CREATE INDEX CONCURRENTLY idx_lineage_source_target ON data_lineage(source_entity_id, target_entity_id);

-- Particionamento para tabelas grandes
CREATE TABLE quality_metrics_2025 PARTITION OF quality_metrics
FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');

CREATE TABLE audit_logs_2025 PARTITION OF audit_logs
FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');
```

**API Rate Limiting**

```python
# Configuração de rate limiting
RATE_LIMIT_CONFIG = {
    "default": "1000/hour",
    "authenticated": "5000/hour",
    "premium": "10000/hour",
    "per_endpoint": {
        "/api/v1/entities": "100/minute",
        "/api/v1/quality/execute": "10/minute",
        "/api/v1/search": "200/minute"
    }
}
```

### Monitoramento de Performance

```python
# Métricas de performance
performance_metrics = client.monitoring.get_metrics([
    'api_response_time_avg',
    'api_response_time_p95',
    'api_requests_per_second',
    'database_query_time_avg',
    'cache_hit_ratio',
    'error_rate'
])

print(f"Tempo médio de resposta: {performance_metrics['api_response_time_avg']}ms")
print(f"P95 tempo de resposta: {performance_metrics['api_response_time_p95']}ms")
print(f"Taxa de cache hit: {performance_metrics['cache_hit_ratio']}%")
```

## Segurança

### Configurações de Segurança

**Criptografia**

```python
# Configuração de criptografia
ENCRYPTION_CONFIG = {
    "at_rest": {
        "enabled": True,
        "algorithm": "AES-256-GCM",
        "key_rotation_days": 90
    },
    "in_transit": {
        "tls_version": "1.3",
        "cipher_suites": [
            "TLS_AES_256_GCM_SHA384",
            "TLS_CHACHA20_POLY1305_SHA256"
        ]
    },
    "sensitive_fields": [
        "hashed_password",
        "api_keys.key_hash",
        "external_integrations.configuration"
    ]
}
```

**Auditoria de Segurança**

```python
# Configurar auditoria de segurança
security_audit = client.security.configure_audit({
    "log_all_access": True,
    "log_failed_attempts": True,
    "log_privilege_escalation": True,
    "retention_days": 2555,  # 7 anos
    "real_time_alerts": {
        "multiple_failed_logins": {
            "threshold": 5,
            "window_minutes": 15
        },
        "unusual_access_patterns": {
            "enabled": True,
            "ml_detection": True
        }
    }
})
```

**Vulnerability Scanning**

```python
# Executar scan de vulnerabilidades
scan_result = client.security.vulnerability_scan({
    "scan_type": "full",
    "include_dependencies": True,
    "severity_threshold": "medium"
})

if scan_result['vulnerabilities']:
    for vuln in scan_result['vulnerabilities']:
        print(f"Vulnerabilidade: {vuln['cve_id']}")
        print(f"Severidade: {vuln['severity']}")
        print(f"Componente: {vuln['component']}")
        print(f"Correção: {vuln['fix_available']}")
```

## Monitoramento

### Dashboards de Monitoramento

**Dashboard Operacional**

```python
# Configurar dashboard operacional
operational_dashboard = {
    "name": "Governance API - Operational",
    "widgets": [
        {
            "type": "metric",
            "title": "Requests per Second",
            "query": "rate(api_requests_total[5m])",
            "alert_threshold": 1000
        },
        {
            "type": "metric", 
            "title": "Average Response Time",
            "query": "avg(api_response_time_seconds)",
            "alert_threshold": 0.5
        },
        {
            "type": "metric",
            "title": "Error Rate",
            "query": "rate(api_errors_total[5m]) / rate(api_requests_total[5m])",
            "alert_threshold": 0.01
        },
        {
            "type": "graph",
            "title": "Database Connections",
            "query": "database_connections_active"
        }
    ]
}
```

**Dashboard de Qualidade**

```python
# Dashboard de qualidade de dados
quality_dashboard = {
    "name": "Data Quality Monitoring",
    "widgets": [
        {
            "type": "gauge",
            "title": "Overall Quality Score",
            "query": "avg(data_quality_score)",
            "thresholds": {"good": 95, "warning": 90, "critical": 85}
        },
        {
            "type": "table",
            "title": "Quality Issues by Entity",
            "query": "quality_issues_by_entity"
        },
        {
            "type": "heatmap",
            "title": "Quality Trends",
            "query": "quality_metrics_over_time"
        }
    ]
}
```

### Alertas

**Configuração de Alertas**

```python
# Alertas de sistema
system_alerts = [
    {
        "name": "High API Response Time",
        "condition": "avg(api_response_time_seconds) > 1.0",
        "duration": "5m",
        "severity": "warning",
        "channels": ["email", "slack"]
    },
    {
        "name": "Database Connection Pool Exhausted",
        "condition": "database_connections_active >= database_connections_max * 0.9",
        "duration": "1m",
        "severity": "critical",
        "channels": ["email", "slack", "pagerduty"]
    },
    {
        "name": "Quality SLA Violation",
        "condition": "data_quality_score < 95",
        "duration": "10m",
        "severity": "warning",
        "channels": ["email"]
    }
]

# Registrar alertas
for alert in system_alerts:
    client.monitoring.create_alert(alert)
```

## Troubleshooting

### Problemas Comuns

**1. Erro de Conexão com Banco de Dados**

```bash
# Verificar conectividade
pg_isready -h localhost -p 5432 -U governance_user

# Verificar logs
docker-compose logs postgres

# Verificar configuração
cat .env | grep DATABASE_URL
```

**2. Performance Lenta da API**

```python
# Verificar métricas de performance
metrics = client.monitoring.get_metrics([
    'database_query_time_avg',
    'cache_hit_ratio',
    'api_response_time_p95'
])

# Verificar queries lentas
slow_queries = client.monitoring.get_slow_queries(limit=10)
for query in slow_queries:
    print(f"Query: {query['sql']}")
    print(f"Tempo: {query['duration']}ms")
    print(f"Execuções: {query['count']}")
```

**3. Falhas de Sincronização**

```python
# Verificar status das integrações
integrations = client.integrations.list()
for integration in integrations:
    if integration['status'] != 'healthy':
        print(f"Integração {integration['name']} com problema:")
        print(f"Status: {integration['status']}")
        print(f"Último erro: {integration['last_error']}")
        
        # Tentar reconectar
        client.integrations.reconnect(integration['id'])
```

**4. Problemas de Qualidade de Dados**

```python
# Verificar regras falhando
failed_rules = client.quality.get_failed_rules(days=1)
for rule in failed_rules:
    print(f"Regra: {rule['name']}")
    print(f"Entidade: {rule['entity_name']}")
    print(f"Último erro: {rule['last_error']}")
    
    # Re-executar regra
    result = client.quality.execute_rule(rule['id'])
    print(f"Resultado: {result['status']}")
```

### Logs e Debugging

**Configuração de Logs**

```python
import logging

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('governance_api.log'),
        logging.StreamHandler()
    ]
)

# Logger específico para debugging
debug_logger = logging.getLogger('governance_api.debug')
debug_logger.setLevel(logging.DEBUG)
```

**Análise de Logs**

```bash
# Filtrar logs por erro
grep "ERROR" governance_api.log | tail -20

# Analisar performance
grep "slow_query" governance_api.log | awk '{print $NF}' | sort -n

# Monitorar em tempo real
tail -f governance_api.log | grep "quality_check"
```

## FAQ

**Q: Como posso migrar dados de outra ferramenta de governança?**

A: A API oferece endpoints de importação para as principais ferramentas:

```python
# Importar de Collibra
migration_job = client.migration.import_from_collibra({
    "collibra_url": "https://your-collibra.com",
    "username": "your-username",
    "password": "your-password",
    "import_assets": True,
    "import_lineage": True,
    "import_policies": True
})

# Monitorar progresso
while migration_job['status'] == 'running':
    time.sleep(30)
    migration_job = client.migration.get_job(migration_job['id'])
```

**Q: Como configurar backup automático?**

A: Configure políticas de backup através da API:

```python
backup_policy = {
    "name": "daily_backup",
    "frequency": "daily",
    "retention_days": 30,
    "storage_location": "s3://your-backup-bucket",
    "encryption_enabled": True,
    "notification_on_failure": True
}

client.backup.create_policy(backup_policy)
```

**Q: Como escalar horizontalmente a API?**

A: A API suporta escalonamento horizontal através de load balancers:

```yaml
# docker-compose.scale.yml
version: '3.8'
services:
  api:
    image: governance-api:latest
    deploy:
      replicas: 3
    environment:
      - DATABASE_URL=postgresql://user:pass@postgres:5432/db
      - REDIS_URL=redis://redis:6379/0
  
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
```

**Q: Como implementar disaster recovery?**

A: Configure um plano de DR completo:

```python
dr_plan = {
    "name": "governance_api_dr",
    "rto_hours": 4,
    "rpo_hours": 1,
    "backup_locations": [
        "s3://primary-backup-bucket",
        "s3://secondary-backup-bucket"
    ],
    "failover_procedures": [
        "Switch DNS to secondary region",
        "Restore database from latest backup",
        "Update configuration for new region",
        "Validate all integrations"
    ]
}

client.disaster_recovery.create_plan(dr_plan)
```

## Suporte

### Canais de Suporte

**Suporte Técnico**
- Email: carlos.morais@f1rst.com.br
- Horário: Segunda a Sexta, 9h às 18h (GMT-3)
- SLA: Resposta em até 4 horas

**Comunidade**
- Slack: #governance-api-community
- GitHub: github.com/f1rst/governance-api
- Stack Overflow: Tag `f1rst-governance-api`

**Documentação**
- Portal: docs.governance.f1rst.com
- API Reference: api.governance.f1rst.com/docs
- Tutoriais: tutorials.governance.f1rst.com

### Informações de Contato

**Desenvolvedor Principal**
- Nome: Carlos Morais
- Email: carlos.morais@f1rst.com.br
- LinkedIn: linkedin.com/in/carlos-morais

**Organização**
- Nome: F1rst
- Website: f1rst.com.br
- Email: contato@f1rst.com.br

---

*Documentação desenvolvida com excelência técnica por Carlos Morais - F1rst*

