"""
Dependências da API
"""

from typing import AsyncGenerator, Dict, Optional
from uuid import UUID

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession

from application.services.data_contract_service import DataContractService
from application.services.entity_service import EntityService
from application.services.quality_service import QualityService
from application.services.domain_service import DomainService
from application.dtos import PaginationParams
from database.connection import db_manager
from database.repositories.data_contract_repository import DataContractRepository
from database.repositories.entity_repository import EntityRepository
from database.repositories.quality_repository import QualityRepository
from database.repositories.domain_repository import DomainRepository

# Security
security = HTTPBearer()


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """Dependency para obter sessão do banco de dados"""
    async with db_manager.get_session() as session:
        yield session


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> Dict:
    """Dependency para obter usuário atual (mock)"""
    # TODO: Implementar validação JWT real
    return {
        "id": UUID("123e4567-e89b-12d3-a456-426614174000"),
        "username": "admin",
        "email": "admin@company.com",
        "is_active": True,
        "is_admin": True
    }


async def get_current_active_user(
    current_user: Dict = Depends(get_current_user)
) -> Dict:
    """Dependency para obter usuário ativo"""
    if not current_user.get("is_active"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user"
        )
    return current_user


def validate_pagination(
    page: int = 1,
    size: int = 20
) -> PaginationParams:
    """Dependency para validar parâmetros de paginação"""
    if page < 1:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Page must be greater than 0"
        )
    
    if size < 1 or size > 100:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Size must be between 1 and 100"
        )
    
    return PaginationParams(page=page, size=size)


# Service Dependencies
async def get_data_contract_service(
    session: AsyncSession = Depends(get_db_session)
) -> DataContractService:
    """Dependency para obter DataContractService"""
    repository = DataContractRepository(session)
    return DataContractService(repository)


async def get_entity_service(
    session: AsyncSession = Depends(get_db_session)
) -> EntityService:
    """Dependency para obter EntityService"""
    repository = EntityRepository(session)
    return EntityService(repository)


async def get_quality_service(
    session: AsyncSession = Depends(get_db_session)
) -> QualityService:
    """Dependency para obter QualityService"""
    repository = QualityRepository(session)
    return QualityService(repository)


async def get_domain_service(
    session: AsyncSession = Depends(get_db_session)
) -> DomainService:
    """Dependency para obter DomainService"""
    repository = DomainRepository(session)
    return DomainService(repository)

