"""
DTOs para Stewardship e Responsabilidades
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class StewardRole(str, Enum):
    """Papel do steward"""
    DATA_OWNER = "data_owner"
    DATA_STEWARD = "data_steward"
    DATA_CUSTODIAN = "data_custodian"
    BUSINESS_ANALYST = "business_analyst"
    TECHNICAL_LEAD = "technical_lead"
    COMPLIANCE_OFFICER = "compliance_officer"


class ResponsibilityType(str, Enum):
    """Tipo de responsabilidade"""
    DATA_QUALITY = "data_quality"
    DATA_GOVERNANCE = "data_governance"
    DATA_PRIVACY = "data_privacy"
    DATA_ACCESS = "data_access"
    DATA_LIFECYCLE = "data_lifecycle"
    COMPLIANCE = "compliance"
    DOCUMENTATION = "documentation"


class StewardStatus(str, Enum):
    """Status do steward"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"
    SUSPENDED = "suspended"


class StewardCreateDTO(BaseModel):
    """DTO para criação de steward"""
    user_id: UUID
    name: str = Field(..., min_length=1, max_length=255)
    email: str = Field(..., regex=r'^[^@]+@[^@]+\.[^@]+$')
    role: StewardRole
    department: Optional[str] = None
    job_title: Optional[str] = None
    phone: Optional[str] = None
    responsibilities: List[ResponsibilityType] = Field(default_factory=list)
    expertise_areas: List[str] = Field(default_factory=list)
    certification_level: Optional[str] = None  # basic, intermediate, advanced, expert
    manager_email: Optional[str] = None
    delegate_email: Optional[str] = None
    is_primary_contact: bool = Field(default=False)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "user_id": "123e4567-e89b-12d3-a456-426614174000",
                "name": "John Doe",
                "email": "john.doe@company.com",
                "role": "data_steward",
                "department": "Data & Analytics",
                "job_title": "Senior Data Steward",
                "phone": "+55 11 99999-9999",
                "responsibilities": ["data_quality", "data_governance"],
                "expertise_areas": ["customer_data", "financial_data"],
                "certification_level": "advanced",
                "manager_email": "manager@company.com",
                "is_primary_contact": True,
                "metadata": {"location": "São Paulo", "timezone": "America/Sao_Paulo"}
            }
        }


class StewardUpdateDTO(BaseModel):
    """DTO para atualização de steward"""
    name: Optional[str] = None
    email: Optional[str] = None
    department: Optional[str] = None
    job_title: Optional[str] = None
    phone: Optional[str] = None
    responsibilities: Optional[List[ResponsibilityType]] = None
    expertise_areas: Optional[List[str]] = None
    certification_level: Optional[str] = None
    manager_email: Optional[str] = None
    delegate_email: Optional[str] = None
    is_primary_contact: Optional[bool] = None
    status: Optional[StewardStatus] = None
    metadata: Optional[Dict] = None


class StewardResponseDTO(BaseModel):
    """DTO para resposta de steward"""
    id: UUID
    user_id: UUID
    name: str
    email: str
    role: StewardRole
    department: Optional[str]
    job_title: Optional[str]
    phone: Optional[str]
    responsibilities: List[ResponsibilityType]
    expertise_areas: List[str]
    certification_level: Optional[str]
    manager_email: Optional[str]
    delegate_email: Optional[str]
    is_primary_contact: bool
    status: StewardStatus
    assigned_entities_count: int = Field(default=0)
    assigned_domains_count: int = Field(default=0)
    active_tasks_count: int = Field(default=0)
    performance_score: float = Field(default=0.0, ge=0, le=100)
    last_activity: Optional[datetime] = None
    metadata: Dict
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ResponsibilityAssignmentDTO(BaseModel):
    """DTO para atribuição de responsabilidade"""
    steward_id: UUID
    entity_id: Optional[UUID] = None
    domain_id: Optional[UUID] = None
    responsibility_type: ResponsibilityType
    scope: str = Field(default="full")  # full, read_only, specific
    specific_attributes: List[str] = Field(default_factory=list)
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    delegation_allowed: bool = Field(default=False)
    escalation_contact: Optional[str] = None
    business_justification: str
    approval_required: bool = Field(default=True)

    class Config:
        json_schema_extra = {
            "example": {
                "steward_id": "123e4567-e89b-12d3-a456-426614174000",
                "entity_id": "456e7890-e89b-12d3-a456-426614174000",
                "responsibility_type": "data_quality",
                "scope": "full",
                "start_date": "2025-01-15T00:00:00Z",
                "delegation_allowed": True,
                "escalation_contact": "manager@company.com",
                "business_justification": "John has expertise in customer data quality",
                "approval_required": False
            }
        }


class ResponsibilityResponseDTO(BaseModel):
    """DTO para resposta de responsabilidade"""
    id: UUID
    steward_id: UUID
    steward_name: str
    steward_email: str
    entity_id: Optional[UUID]
    entity_name: Optional[str]
    domain_id: Optional[UUID]
    domain_name: Optional[str]
    responsibility_type: ResponsibilityType
    scope: str
    specific_attributes: List[str]
    start_date: Optional[datetime]
    end_date: Optional[datetime]
    delegation_allowed: bool
    escalation_contact: Optional[str]
    business_justification: str
    status: str  # active, inactive, pending, expired
    assigned_by: UUID
    approved_by: Optional[UUID] = None
    approved_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class StewardPerformanceDTO(BaseModel):
    """DTO para performance do steward"""
    steward_id: UUID
    steward_name: str
    period_start: datetime
    period_end: datetime
    total_entities: int
    entities_with_issues: int
    resolved_issues: int
    pending_issues: int
    overdue_issues: int
    avg_resolution_time_hours: float
    quality_score: float = Field(ge=0, le=100)
    compliance_score: float = Field(ge=0, le=100)
    responsiveness_score: float = Field(ge=0, le=100)
    overall_score: float = Field(ge=0, le=100)
    achievements: List[str] = Field(default_factory=list)
    improvement_areas: List[str] = Field(default_factory=list)

    class Config:
        json_schema_extra = {
            "example": {
                "steward_id": "123e4567-e89b-12d3-a456-426614174000",
                "steward_name": "John Doe",
                "period_start": "2025-01-01T00:00:00Z",
                "period_end": "2025-01-31T23:59:59Z",
                "total_entities": 25,
                "entities_with_issues": 8,
                "resolved_issues": 15,
                "pending_issues": 3,
                "overdue_issues": 1,
                "avg_resolution_time_hours": 24.5,
                "quality_score": 87.5,
                "compliance_score": 92.0,
                "responsiveness_score": 85.0,
                "overall_score": 88.2,
                "achievements": [
                    "Resolved all critical data quality issues",
                    "Improved documentation coverage by 30%"
                ],
                "improvement_areas": [
                    "Reduce average resolution time",
                    "Increase proactive monitoring"
                ]
            }
        }


class StewardTaskDTO(BaseModel):
    """DTO para tarefa do steward"""
    id: UUID
    steward_id: UUID
    task_type: str  # data_quality_review, compliance_check, documentation_update
    title: str
    description: str
    priority: str  # low, medium, high, critical
    status: str  # pending, in_progress, completed, cancelled
    entity_id: Optional[UUID] = None
    entity_name: Optional[str] = None
    domain_id: Optional[UUID] = None
    domain_name: Optional[str] = None
    due_date: Optional[datetime] = None
    estimated_hours: Optional[int] = None
    actual_hours: Optional[int] = None
    assigned_by: UUID
    assigned_at: datetime
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    notes: Optional[str] = None
    attachments: List[str] = Field(default_factory=list)

    class Config:
        from_attributes = True


class StewardDashboardDTO(BaseModel):
    """DTO para dashboard do steward"""
    steward_id: UUID
    steward_name: str
    total_responsibilities: int
    active_entities: int
    active_domains: int
    pending_tasks: int
    overdue_tasks: int
    completed_tasks_this_month: int
    quality_issues_open: int
    compliance_issues_open: int
    recent_activities: List[Dict]
    upcoming_deadlines: List[Dict]
    performance_summary: Dict
    alerts: List[Dict] = Field(default_factory=list)

    class Config:
        json_schema_extra = {
            "example": {
                "steward_id": "123e4567-e89b-12d3-a456-426614174000",
                "steward_name": "John Doe",
                "total_responsibilities": 15,
                "active_entities": 25,
                "active_domains": 3,
                "pending_tasks": 8,
                "overdue_tasks": 2,
                "completed_tasks_this_month": 12,
                "quality_issues_open": 5,
                "compliance_issues_open": 1,
                "recent_activities": [
                    {
                        "type": "quality_check",
                        "entity": "customer_table",
                        "timestamp": "2025-01-14T09:30:00Z",
                        "status": "completed"
                    }
                ],
                "upcoming_deadlines": [
                    {
                        "task": "Monthly compliance review",
                        "due_date": "2025-01-31T17:00:00Z",
                        "priority": "high"
                    }
                ],
                "performance_summary": {
                    "overall_score": 88.2,
                    "trend": "improving"
                },
                "alerts": [
                    {
                        "type": "overdue_task",
                        "message": "Data quality review for sales_data is overdue",
                        "severity": "medium"
                    }
                ]
            }
        }


class StewardSearchDTO(BaseModel):
    """DTO para busca de stewards"""
    query: Optional[str] = None
    role: Optional[StewardRole] = None
    department: Optional[str] = None
    responsibilities: Optional[List[ResponsibilityType]] = None
    expertise_areas: Optional[List[str]] = None
    certification_level: Optional[str] = None
    status: Optional[StewardStatus] = None
    is_primary_contact: Optional[bool] = None

    class Config:
        json_schema_extra = {
            "example": {
                "query": "john",
                "role": "data_steward",
                "department": "Data & Analytics",
                "responsibilities": ["data_quality"],
                "status": "active"
            }
        }

