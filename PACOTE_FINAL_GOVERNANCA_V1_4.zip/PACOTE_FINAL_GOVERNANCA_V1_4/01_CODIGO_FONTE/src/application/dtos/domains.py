"""
DTOs para Domínios de Negócio
"""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class DomainCreateDTO(BaseModel):
    """DTO para criação de domínio"""
    name: str = Field(..., min_length=1, max_length=255, description="Nome do domínio")
    display_name: str = Field(..., min_length=1, max_length=255, description="Nome de exibição")
    description: Optional[str] = Field(None, description="Descrição do domínio")
    parent_domain_id: Optional[UUID] = Field(None, description="ID do domínio pai")
    domain_type: str = Field(default="business", description="Tipo do domínio")
    business_owner: Optional[str] = Field(None, description="Responsável de negócio")
    technical_owner: Optional[str] = Field(None, description="Responsável técnico")
    is_active: bool = Field(default=True, description="Se o domínio está ativo")

    class Config:
        json_schema_extra = {
            "example": {
                "name": "customer_data",
                "display_name": "Customer Data",
                "description": "Domain containing all customer-related data",
                "parent_domain_id": None,
                "domain_type": "business",
                "business_owner": "john.doe@company.com",
                "technical_owner": "jane.smith@company.com",
                "is_active": True
            }
        }


class DomainUpdateDTO(BaseModel):
    """DTO para atualização de domínio"""
    display_name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = Field(None)
    parent_domain_id: Optional[UUID] = Field(None)
    domain_type: Optional[str] = Field(None)
    business_owner: Optional[str] = Field(None)
    technical_owner: Optional[str] = Field(None)
    is_active: Optional[bool] = Field(None)

    class Config:
        json_schema_extra = {
            "example": {
                "display_name": "Updated Customer Data",
                "description": "Updated description for customer domain",
                "business_owner": "new.owner@company.com"
            }
        }


class DomainResponseDTO(BaseModel):
    """DTO para resposta de domínio"""
    id: UUID
    name: str
    display_name: str
    description: Optional[str]
    parent_domain_id: Optional[UUID]
    domain_type: str
    business_owner: Optional[str]
    technical_owner: Optional[str]
    is_active: bool
    entity_count: int = Field(default=0, description="Número de entidades no domínio")
    subdomain_count: int = Field(default=0, description="Número de subdomínios")
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
        json_schema_extra = {
            "example": {
                "id": "123e4567-e89b-12d3-a456-426614174000",
                "name": "customer_data",
                "display_name": "Customer Data",
                "description": "Domain containing all customer-related data",
                "parent_domain_id": None,
                "domain_type": "business",
                "business_owner": "john.doe@company.com",
                "technical_owner": "jane.smith@company.com",
                "is_active": True,
                "entity_count": 15,
                "subdomain_count": 3,
                "created_at": "2025-01-14T10:00:00Z",
                "updated_at": "2025-01-14T10:00:00Z"
            }
        }


class DomainHierarchyDTO(BaseModel):
    """DTO para hierarquia de domínios"""
    id: UUID
    name: str
    display_name: str
    description: Optional[str]
    domain_type: str
    is_active: bool
    entity_count: int
    children: List['DomainHierarchyDTO'] = Field(default_factory=list)

    class Config:
        from_attributes = True


class DomainSearchDTO(BaseModel):
    """DTO para busca de domínios"""
    query: Optional[str] = Field(None, description="Termo de busca")
    domain_type: Optional[str] = Field(None, description="Filtro por tipo")
    is_active: Optional[bool] = Field(None, description="Filtro por status ativo")
    parent_domain_id: Optional[UUID] = Field(None, description="Filtro por domínio pai")
    business_owner: Optional[str] = Field(None, description="Filtro por responsável de negócio")
    technical_owner: Optional[str] = Field(None, description="Filtro por responsável técnico")

    class Config:
        json_schema_extra = {
            "example": {
                "query": "customer",
                "domain_type": "business",
                "is_active": True,
                "business_owner": "john.doe@company.com"
            }
        }


class DomainStatsDTO(BaseModel):
    """DTO para estatísticas do domínio"""
    total_entities: int
    total_contracts: int
    total_quality_rules: int
    quality_score: float = Field(ge=0, le=100)
    compliance_score: float = Field(ge=0, le=100)
    last_updated: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "total_entities": 25,
                "total_contracts": 8,
                "total_quality_rules": 45,
                "quality_score": 87.5,
                "compliance_score": 92.0,
                "last_updated": "2025-01-14T10:00:00Z"
            }
        }


# Atualizar referências circulares
DomainHierarchyDTO.model_rebuild()

