"""
DTOs para Tags e Classificação
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class TagType(str, Enum):
    """Tipo de tag"""
    BUSINESS = "business"
    TECHNICAL = "technical"
    CLASSIFICATION = "classification"
    QUALITY = "quality"
    COMPLIANCE = "compliance"
    CUSTOM = "custom"


class ClassificationLevel(str, Enum):
    """Nível de classificação"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"
    SECRET = "secret"


class TagScope(str, Enum):
    """Escopo da tag"""
    GLOBAL = "global"
    DOMAIN = "domain"
    ENTITY = "entity"
    ATTRIBUTE = "attribute"


class TagCreateDTO(BaseModel):
    """DTO para criação de tag"""
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    tag_type: TagType
    scope: TagScope = TagScope.GLOBAL
    color: Optional[str] = Field(None, regex=r'^#[0-9A-Fa-f]{6}$')
    icon: Optional[str] = None
    is_system_tag: bool = Field(default=False)
    is_mandatory: bool = Field(default=False)
    allowed_values: Optional[List[str]] = None
    validation_rules: Optional[Dict] = None
    parent_tag_id: Optional[UUID] = None
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "PII",
                "description": "Personally Identifiable Information",
                "tag_type": "classification",
                "scope": "attribute",
                "color": "#FF5722",
                "icon": "shield",
                "is_system_tag": True,
                "is_mandatory": True,
                "allowed_values": ["high", "medium", "low"],
                "validation_rules": {"regex": "^(high|medium|low)$"},
                "metadata": {"compliance_framework": "LGPD"}
            }
        }


class TagUpdateDTO(BaseModel):
    """DTO para atualização de tag"""
    description: Optional[str] = None
    color: Optional[str] = Field(None, regex=r'^#[0-9A-Fa-f]{6}$')
    icon: Optional[str] = None
    is_mandatory: Optional[bool] = None
    allowed_values: Optional[List[str]] = None
    validation_rules: Optional[Dict] = None
    metadata: Optional[Dict] = None


class TagResponseDTO(BaseModel):
    """DTO para resposta de tag"""
    id: UUID
    name: str
    description: Optional[str]
    tag_type: TagType
    scope: TagScope
    color: Optional[str]
    icon: Optional[str]
    is_system_tag: bool
    is_mandatory: bool
    allowed_values: Optional[List[str]]
    validation_rules: Optional[Dict]
    parent_tag_id: Optional[UUID]
    parent_tag_name: Optional[str]
    child_tags_count: int = Field(default=0)
    usage_count: int = Field(default=0)
    metadata: Dict
    created_by: UUID
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class TagAssignmentDTO(BaseModel):
    """DTO para atribuição de tag"""
    tag_id: UUID
    entity_id: Optional[UUID] = None
    attribute_id: Optional[UUID] = None
    domain_id: Optional[UUID] = None
    tag_value: Optional[str] = None
    confidence_score: float = Field(default=1.0, ge=0, le=1)
    assigned_by: Optional[str] = None  # system, user, ml_model
    assignment_reason: Optional[str] = None
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "tag_id": "123e4567-e89b-12d3-a456-426614174000",
                "entity_id": "456e7890-e89b-12d3-a456-426614174000",
                "tag_value": "high",
                "confidence_score": 0.95,
                "assigned_by": "ml_model",
                "assignment_reason": "Detected PII patterns in column names",
                "metadata": {"detection_method": "regex_pattern"}
            }
        }


class TagAssignmentResponseDTO(BaseModel):
    """DTO para resposta de atribuição"""
    id: UUID
    tag_id: UUID
    tag_name: str
    tag_type: TagType
    entity_id: Optional[UUID]
    entity_name: Optional[str]
    attribute_id: Optional[UUID]
    attribute_name: Optional[str]
    domain_id: Optional[UUID]
    domain_name: Optional[str]
    tag_value: Optional[str]
    confidence_score: float
    assigned_by: Optional[str]
    assignment_reason: Optional[str]
    is_validated: bool = Field(default=False)
    validated_by: Optional[UUID] = None
    validated_at: Optional[datetime] = None
    metadata: Dict
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ClassificationRuleDTO(BaseModel):
    """DTO para regra de classificação"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str
    rule_type: str  # regex, keyword, ml_model, custom
    rule_definition: Dict
    target_scope: TagScope
    classification_tag_id: UUID
    default_classification_level: ClassificationLevel
    confidence_threshold: float = Field(default=0.8, ge=0, le=1)
    is_active: bool = Field(default=True)
    priority: int = Field(default=100, ge=1, le=1000)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "SSN Detection Rule",
                "description": "Detects Social Security Numbers in column names and data",
                "rule_type": "regex",
                "rule_definition": {
                    "pattern": r"\b\d{3}-\d{2}-\d{4}\b",
                    "column_patterns": ["ssn", "social_security", "cpf"]
                },
                "target_scope": "attribute",
                "classification_tag_id": "123e4567-e89b-12d3-a456-426614174000",
                "default_classification_level": "confidential",
                "confidence_threshold": 0.9,
                "priority": 10
            }
        }


class ClassificationResultDTO(BaseModel):
    """DTO para resultado de classificação"""
    entity_id: UUID
    entity_name: str
    entity_type: str
    suggested_tags: List[Dict]
    confidence_scores: Dict[str, float]
    classification_level: ClassificationLevel
    applied_rules: List[str]
    manual_review_required: bool
    recommendations: List[str]
    processing_time_ms: int

    class Config:
        json_schema_extra = {
            "example": {
                "entity_id": "123e4567-e89b-12d3-a456-426614174000",
                "entity_name": "customer_data",
                "entity_type": "table",
                "suggested_tags": [
                    {"tag_name": "PII", "value": "high", "confidence": 0.95}
                ],
                "confidence_scores": {
                    "PII": 0.95,
                    "Financial": 0.75
                },
                "classification_level": "confidential",
                "applied_rules": ["SSN Detection Rule", "Email Pattern Rule"],
                "manual_review_required": False,
                "recommendations": [
                    "Apply encryption to PII columns",
                    "Set up access controls"
                ],
                "processing_time_ms": 250
            }
        }


class TagHierarchyDTO(BaseModel):
    """DTO para hierarquia de tags"""
    tag_id: UUID
    tag_name: str
    level: int
    children: List['TagHierarchyDTO'] = Field(default_factory=list)
    usage_count: int = Field(default=0)

    class Config:
        json_schema_extra = {
            "example": {
                "tag_id": "123e4567-e89b-12d3-a456-426614174000",
                "tag_name": "Data Classification",
                "level": 0,
                "children": [
                    {
                        "tag_id": "456e7890-e89b-12d3-a456-426614174000",
                        "tag_name": "PII",
                        "level": 1,
                        "children": [],
                        "usage_count": 150
                    }
                ],
                "usage_count": 300
            }
        }


class TagSearchDTO(BaseModel):
    """DTO para busca de tags"""
    query: Optional[str] = None
    tag_type: Optional[TagType] = None
    scope: Optional[TagScope] = None
    is_system_tag: Optional[bool] = None
    is_mandatory: Optional[bool] = None
    parent_tag_id: Optional[UUID] = None
    include_usage_stats: bool = Field(default=False)

    class Config:
        json_schema_extra = {
            "example": {
                "query": "classification",
                "tag_type": "classification",
                "scope": "attribute",
                "is_system_tag": True,
                "include_usage_stats": True
            }
        }


class TagUsageStatsDTO(BaseModel):
    """DTO para estatísticas de uso de tags"""
    tag_id: UUID
    tag_name: str
    total_assignments: int
    entities_count: int
    attributes_count: int
    domains_count: int
    most_common_values: List[Dict]
    usage_by_domain: Dict[str, int]
    usage_trend: List[Dict]  # time series data
    last_used: Optional[datetime]

    class Config:
        json_schema_extra = {
            "example": {
                "tag_id": "123e4567-e89b-12d3-a456-426614174000",
                "tag_name": "PII",
                "total_assignments": 250,
                "entities_count": 45,
                "attributes_count": 180,
                "domains_count": 8,
                "most_common_values": [
                    {"value": "high", "count": 120},
                    {"value": "medium", "count": 80}
                ],
                "usage_by_domain": {
                    "Customer": 150,
                    "Finance": 70,
                    "HR": 30
                },
                "usage_trend": [
                    {"date": "2025-01-01", "count": 200},
                    {"date": "2025-01-14", "count": 250}
                ],
                "last_used": "2025-01-14T10:30:00Z"
            }
        }


class BulkTagAssignmentDTO(BaseModel):
    """DTO para atribuição em lote"""
    assignments: List[TagAssignmentDTO] = Field(min_items=1, max_items=100)
    validation_mode: str = Field(default="strict")  # strict, lenient, skip
    conflict_resolution: str = Field(default="merge")  # merge, replace, skip

    class Config:
        json_schema_extra = {
            "example": {
                "assignments": [
                    {
                        "tag_id": "123e4567-e89b-12d3-a456-426614174000",
                        "entity_id": "456e7890-e89b-12d3-a456-426614174000",
                        "tag_value": "high"
                    }
                ],
                "validation_mode": "strict",
                "conflict_resolution": "merge"
            }
        }


class BulkTagAssignmentResultDTO(BaseModel):
    """DTO para resultado de atribuição em lote"""
    total_assignments: int
    successful_assignments: int
    failed_assignments: int
    skipped_assignments: int
    errors: List[Dict]
    warnings: List[Dict]
    processing_time_ms: int

    class Config:
        json_schema_extra = {
            "example": {
                "total_assignments": 50,
                "successful_assignments": 47,
                "failed_assignments": 2,
                "skipped_assignments": 1,
                "errors": [
                    {"assignment_index": 5, "error": "Tag not found"}
                ],
                "warnings": [
                    {"assignment_index": 10, "warning": "Low confidence score"}
                ],
                "processing_time_ms": 1500
            }
        }

