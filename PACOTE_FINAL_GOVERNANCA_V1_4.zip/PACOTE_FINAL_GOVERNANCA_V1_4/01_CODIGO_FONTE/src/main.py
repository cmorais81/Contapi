"""
API de Governança de Dados V1.4
Desenvolvida por: Carlos Morais
Email: carlos.morais@f1rst.com.br
Organização: F1rst

Versão corrigida com módulos faltantes criados.
Compatível com Python 3.13 e Windows.
"""

import sys
import os
from pathlib import Path
from datetime import datetime
import logging

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Adicionar o diretório src ao PYTHONPATH para compatibilidade Windows
current_dir = Path(__file__).parent
src_dir = current_dir
if str(src_dir) not in sys.path:
    sys.path.insert(0, str(src_dir))

# Importações básicas
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn

# Importar módulos com tratamento de erro robusto
modules_loaded = []

# Importar middleware
try:
    from api.middleware import LoggingMiddleware
    modules_loaded.append("LoggingMiddleware")
except ImportError as e:
    logger.warning(f"LoggingMiddleware não pôde ser importado: {e}")
    LoggingMiddleware = None

try:
    from api.error_middleware import ErrorHandlingMiddleware
    modules_loaded.append("ErrorHandlingMiddleware")
except ImportError as e:
    logger.warning(f"ErrorHandlingMiddleware não pôde ser importado: {e}")
    ErrorHandlingMiddleware = None

try:
    from api.exception_handlers import setup_exception_handlers
    modules_loaded.append("setup_exception_handlers")
except ImportError as e:
    logger.warning(f"setup_exception_handlers não pôde ser importado: {e}")
    setup_exception_handlers = None

# Importar controllers disponíveis
controllers_loaded = []

# Lista de controllers para tentar importar
controller_modules = [
    'contracts', 'entities', 'quality', 'auth', 'audit', 
    'rate_limiting', 'system', 'metrics', 'domains', 
    'lineage', 'policies', 'stewardship', 'tags', 
    'analytics', 'discovery', 'workflows', 'notifications', 
    'integrations', 'security', 'performance'
]

controllers = {}

for controller_name in controller_modules:
    try:
        module = __import__(f'api.controllers.{controller_name}', fromlist=[controller_name])
        controllers[controller_name] = module
        controllers_loaded.append(controller_name)
        logger.info(f"Controller {controller_name} carregado com sucesso")
    except ImportError as e:
        logger.warning(f"Controller {controller_name} não pôde ser importado: {e}")
    except Exception as e:
        logger.error(f"Erro ao carregar controller {controller_name}: {e}")

logger.info(f"Controllers carregados: {', '.join(controllers_loaded)}")
logger.info(f"Módulos carregados: {', '.join(modules_loaded)}")

# Criar aplicação FastAPI
app = FastAPI(
    title="API de Governança de Dados",
    description="""
    ## API de Governança de Dados V1.4
    
    **Desenvolvida por:** Carlos Morais  
    **Email:** carlos.morais@f1rst.com.br  
    **Organização:** F1rst
    
    Uma solução enterprise completa para gestão, controle e monitoramento de dados.
    
    **Compatibilidade:**
    - Python 3.13+ (compatível com 3.9+)
    - Windows, Linux, macOS
    - Docker e Kubernetes
    
    ### Funcionalidades Principais:
    - Gestão de Domínios e Hierarquias
    - Contratos de Dados com Versionamento
    - Descoberta e Catálogo Inteligente
    - Políticas e Compliance (LGPD/GDPR)
    - Qualidade de Dados e Métricas
    - Lineage e Rastreabilidade
    - Stewardship e Responsabilidades
    - Notificações Multi-canal
    - Workflows e Aprovações
    - Integrações Externas
    
    ### Melhorias V1.4:
    - Módulos faltantes criados
    - Imports corrigidos para Windows
    - Tratamento robusto de erros
    - Compatibilidade Python 3.13
    """,
    version="1.4.0",
    contact={
        "name": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br",
    },
    license_info={
        "name": "Proprietário",
        "url": "mailto:carlos.morais@f1rst.com.br",
    },
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Adicionar middleware personalizado se disponível
if ErrorHandlingMiddleware:
    try:
        app.add_middleware(ErrorHandlingMiddleware)
        logger.info("ErrorHandlingMiddleware adicionado com sucesso")
    except Exception as e:
        logger.warning(f"Erro ao adicionar ErrorHandlingMiddleware: {e}")

if LoggingMiddleware:
    try:
        app.add_middleware(LoggingMiddleware)
        logger.info("LoggingMiddleware adicionado com sucesso")
    except Exception as e:
        logger.warning(f"Erro ao adicionar LoggingMiddleware: {e}")

# Configurar exception handlers se disponível
if setup_exception_handlers:
    try:
        setup_exception_handlers(app)
        logger.info("Exception handlers configurados com sucesso")
    except Exception as e:
        logger.warning(f"Erro ao configurar exception handlers: {e}")

# Health check endpoint melhorado
@app.get("/health", tags=["System"])
async def health_check():
    """
    Health check endpoint para verificar status da API.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.4.0",
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "platform": sys.platform,
        "author": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br",
        "organization": "F1rst",
        "controllers_loaded": controllers_loaded,
        "modules_loaded": modules_loaded,
        "total_controllers": len(controllers_loaded),
        "total_modules": len(modules_loaded)
    }

# Root endpoint
@app.get("/", tags=["System"])
async def root():
    """
    Endpoint raiz da API de Governança de Dados.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    return {
        "message": "API de Governança de Dados V1.4",
        "author": "Carlos Morais",
        "email": "carlos.morais@f1rst.com.br",
        "organization": "F1rst",
        "version": "1.4.0",
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "platform": sys.platform,
        "docs": "/docs",
        "redoc": "/redoc",
        "health": "/health",
        "controllers_available": len(controllers_loaded),
        "modules_available": len(modules_loaded),
        "status": "running",
        "improvements": [
            "Módulos faltantes criados",
            "Imports corrigidos para Windows",
            "Tratamento robusto de erros",
            "Compatibilidade Python 3.13"
        ]
    }

# Endpoint de informações detalhadas
@app.get("/info", tags=["System"])
async def system_info():
    """
    Informações detalhadas do sistema.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    return {
        "system": {
            "version": "1.4.0",
            "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
            "platform": sys.platform,
            "timestamp": datetime.utcnow().isoformat()
        },
        "author": {
            "name": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br",
            "organization": "F1rst"
        },
        "modules": {
            "controllers_loaded": controllers_loaded,
            "modules_loaded": modules_loaded,
            "total_controllers": len(controllers_loaded),
            "total_modules": len(modules_loaded)
        },
        "features": {
            "middleware_support": ErrorHandlingMiddleware is not None,
            "logging_support": LoggingMiddleware is not None,
            "exception_handling": setup_exception_handlers is not None,
            "cors_enabled": True
        },
        "endpoints": {
            "health": "/health",
            "docs": "/docs",
            "redoc": "/redoc",
            "info": "/info"
        }
    }

# Incluir routers dos controllers disponíveis
routers_included = []

# Tentar incluir routers dos controllers carregados
for controller_name, controller_module in controllers.items():
    try:
        if hasattr(controller_module, 'router'):
            app.include_router(
                controller_module.router, 
                prefix="/api/v1", 
                tags=[controller_name.title()]
            )
            routers_included.append(controller_name)
            logger.info(f"Router {controller_name} incluído com sucesso")
        else:
            logger.warning(f"Controller {controller_name} não possui router")
    except Exception as e:
        logger.error(f"Erro ao incluir router {controller_name}: {e}")

logger.info(f"Routers incluídos: {', '.join(routers_included)}")

# Middleware para adicionar headers de autor
@app.middleware("http")
async def add_author_headers(request: Request, call_next):
    """Adiciona headers com informações do autor"""
    response = await call_next(request)
    response.headers["X-Author"] = "Carlos Morais"
    response.headers["X-Author-Email"] = "carlos.morais@f1rst.com.br"
    response.headers["X-Organization"] = "F1rst"
    response.headers["X-API-Version"] = "1.4.0"
    response.headers["X-Python-Version"] = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    response.headers["X-Platform"] = sys.platform
    response.headers["X-Controllers-Loaded"] = str(len(controllers_loaded))
    response.headers["X-Modules-Loaded"] = str(len(modules_loaded))
    return response

# Endpoint para listar controllers disponíveis
@app.get("/controllers", tags=["System"])
async def list_controllers():
    """
    Lista todos os controllers disponíveis.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    return {
        "controllers_loaded": controllers_loaded,
        "routers_included": routers_included,
        "total_controllers": len(controllers_loaded),
        "total_routers": len(routers_included),
        "status": "ok"
    }

if __name__ == "__main__":
    logger.info("Iniciando API de Governança de Dados V1.4")
    logger.info("Desenvolvida por: Carlos Morais (carlos.morais@f1rst.com.br)")
    logger.info(f"Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro} em {sys.platform}")
    logger.info(f"Controllers carregados: {len(controllers_loaded)}")
    logger.info(f"Routers incluídos: {len(routers_included)}")
    logger.info(f"Módulos carregados: {len(modules_loaded)}")
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

