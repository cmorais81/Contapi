import re
import logging
from typing import Dict, Any, List, Tuple
from dataclasses import dataclass

@dataclass
class ComplexitySection:
    """Representa uma seção complexa do código."""
    name: str
    start_line: int
    end_line: int
    complexity_score: int
    complexity_factors: List[str]
    estimated_analysis_time: int  # em minutos
    priority: str  # HIGH, MEDIUM, LOW
    code_snippet: str

class ComplexityAnalyzer:
    """
    Analisador de Complexidade Avançado
    
    Identifica as seções mais complexas do programa COBOL e calcula
    métricas para ajudar especialistas a priorizar seu tempo de análise.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Pesos para diferentes fatores de complexidade
        self.complexity_weights = {
            'nested_if': 5,
            'evaluate_when': 3,
            'perform_until': 4,
            'perform_times': 3,
            'compute_statement': 4,
            'file_operations': 2,
            'redefines': 6,
            'occurs': 4,
            'call_statement': 3,
            'goto_statement': 8,  # Alto peso por ser problemático
            'alter_statement': 10,  # Muito problemático
            'string_operations': 3,
            'math_operations': 2,
            'date_operations': 4,
            'error_handling': 3
        }

    def analyze_complexity(self, program_name: str, code_lines: List[str]) -> Dict[str, Any]:
        """
        Analisa a complexidade do programa e identifica seções críticas.
        """
        self.logger.info(f"Iniciando análise de complexidade para {program_name}")
        
        code_text = '\n'.join(code_lines)
        
        # Identifica seções do programa
        sections = self._identify_sections(code_lines)
        
        # Calcula complexidade de cada seção
        complex_sections = []
        for section in sections:
            complexity = self._calculate_section_complexity(section, code_lines)
            if complexity.complexity_score >= 10:  # Apenas seções significativamente complexas
                complex_sections.append(complexity)
        
        # Ordena por complexidade (mais complexas primeiro)
        complex_sections.sort(key=lambda x: x.complexity_score, reverse=True)
        
        # Calcula métricas gerais
        overall_metrics = self._calculate_overall_metrics(code_lines, complex_sections)
        
        # Gera recomendações
        recommendations = self._generate_complexity_recommendations(complex_sections, overall_metrics)
        
        return {
            "program_name": program_name,
            "overall_complexity": overall_metrics,
            "top_complex_sections": complex_sections[:10],  # Top 10
            "total_sections_analyzed": len(sections),
            "high_complexity_sections": len([s for s in complex_sections if s.priority == "HIGH"]),
            "estimated_total_analysis_time": sum(s.estimated_analysis_time for s in complex_sections),
            "recommendations": recommendations,
            "complexity_distribution": self._calculate_complexity_distribution(complex_sections)
        }

    def _identify_sections(self, code_lines: List[str]) -> List[Dict[str, Any]]:
        """Identifica seções lógicas do programa."""
        sections = []
        current_section = None
        
        for i, line in enumerate(code_lines):
            line_upper = line.strip().upper()
            
            # Identifica início de parágrafos
            if re.match(r'^\s*[0-9]+-[A-Z0-9-]+\s*\.$', line_upper):
                if current_section:
                    current_section['end_line'] = i - 1
                    sections.append(current_section)
                
                paragraph_name = line_upper.replace('.', '').strip()
                current_section = {
                    'name': paragraph_name,
                    'type': 'paragraph',
                    'start_line': i,
                    'end_line': None
                }
            
            # Identifica seções especiais
            elif any(keyword in line_upper for keyword in ['WORKING-STORAGE', 'FILE SECTION', 'LINKAGE SECTION']):
                if current_section:
                    current_section['end_line'] = i - 1
                    sections.append(current_section)
                
                section_name = line_upper.strip()
                current_section = {
                    'name': section_name,
                    'type': 'data_section',
                    'start_line': i,
                    'end_line': None
                }
        
        # Fecha a última seção
        if current_section:
            current_section['end_line'] = len(code_lines) - 1
            sections.append(current_section)
        
        return sections

    def _calculate_section_complexity(self, section: Dict[str, Any], code_lines: List[str]) -> ComplexitySection:
        """Calcula a complexidade de uma seção específica."""
        start_line = section['start_line']
        end_line = section['end_line'] or len(code_lines) - 1
        
        section_code = code_lines[start_line:end_line + 1]
        section_text = '\n'.join(section_code)
        
        complexity_score = 0
        complexity_factors = []
        
        # Analisa diferentes fatores de complexidade
        factors = self._analyze_complexity_factors(section_text)
        
        for factor, count in factors.items():
            if count > 0:
                weight = self.complexity_weights.get(factor, 1)
                factor_score = count * weight
                complexity_score += factor_score
                complexity_factors.append(f"{factor}: {count} (score: {factor_score})")
        
        # Determina prioridade
        if complexity_score >= 30:
            priority = "HIGH"
        elif complexity_score >= 15:
            priority = "MEDIUM"
        else:
            priority = "LOW"
        
        # Estima tempo de análise (baseado na complexidade)
        base_time = 10  # 10 minutos base
        complexity_time = complexity_score * 2  # 2 minutos por ponto de complexidade
        estimated_time = min(base_time + complexity_time, 120)  # máximo 2 horas
        
        # Extrai snippet do código
        snippet_lines = min(10, len(section_code))
        code_snippet = '\n'.join(section_code[:snippet_lines])
        if len(section_code) > snippet_lines:
            code_snippet += "\n... (mais linhas)"
        
        return ComplexitySection(
            name=section['name'],
            start_line=start_line + 1,  # 1-indexed para usuário
            end_line=end_line + 1,
            complexity_score=complexity_score,
            complexity_factors=complexity_factors,
            estimated_analysis_time=estimated_time,
            priority=priority,
            code_snippet=code_snippet
        )

    def _analyze_complexity_factors(self, code_text: str) -> Dict[str, int]:
        """Analisa fatores específicos de complexidade no código."""
        factors = {}
        
        # IFs aninhados
        factors['nested_if'] = self._count_nested_ifs(code_text)
        
        # EVALUATE/WHEN statements
        factors['evaluate_when'] = code_text.upper().count('WHEN ')
        
        # PERFORM statements
        factors['perform_until'] = len(re.findall(r'PERFORM.*UNTIL', code_text, re.IGNORECASE))
        factors['perform_times'] = len(re.findall(r'PERFORM.*TIMES', code_text, re.IGNORECASE))
        
        # Operações matemáticas
        factors['compute_statement'] = code_text.upper().count('COMPUTE ')
        factors['math_operations'] = len(re.findall(r'(ADD|SUBTRACT|MULTIPLY|DIVIDE)', code_text, re.IGNORECASE))
        
        # Operações de arquivo
        file_ops = ['OPEN', 'CLOSE', 'READ', 'WRITE', 'REWRITE', 'DELETE']
        factors['file_operations'] = sum(code_text.upper().count(op) for op in file_ops)
        
        # Estruturas de dados complexas
        factors['redefines'] = code_text.upper().count('REDEFINES')
        factors['occurs'] = code_text.upper().count('OCCURS')
        
        # Chamadas e controle de fluxo
        factors['call_statement'] = code_text.upper().count('CALL ')
        factors['goto_statement'] = code_text.upper().count('GO TO')
        factors['alter_statement'] = code_text.upper().count('ALTER ')
        
        # Operações de string
        string_ops = ['STRING', 'UNSTRING', 'INSPECT', 'MOVE CORRESPONDING']
        factors['string_operations'] = sum(code_text.upper().count(op) for op in string_ops)
        
        # Operações de data
        date_ops = ['ACCEPT', 'CURRENT-DATE', 'FUNCTION CURRENT-DATE']
        factors['date_operations'] = sum(code_text.upper().count(op) for op in date_ops)
        
        # Tratamento de erros
        error_keywords = ['FILE STATUS', 'INVALID KEY', 'AT END', 'NOT AT END']
        factors['error_handling'] = sum(code_text.upper().count(keyword) for keyword in error_keywords)
        
        return factors

    def _count_nested_ifs(self, code_text: str) -> int:
        """Conta IFs aninhados para medir complexidade ciclomática."""
        lines = code_text.split('\n')
        if_depth = 0
        max_depth = 0
        nested_count = 0
        
        for line in lines:
            line_upper = line.strip().upper()
            
            if line_upper.startswith('IF '):
                if_depth += 1
                if if_depth > 1:
                    nested_count += 1
                max_depth = max(max_depth, if_depth)
            elif 'END-IF' in line_upper:
                if_depth = max(0, if_depth - 1)
        
        return nested_count

    def _calculate_overall_metrics(self, code_lines: List[str], complex_sections: List[ComplexitySection]) -> Dict[str, Any]:
        """Calcula métricas gerais de complexidade do programa."""
        total_lines = len([line for line in code_lines if line.strip()])
        
        total_complexity = sum(section.complexity_score for section in complex_sections)
        avg_complexity = total_complexity / len(complex_sections) if complex_sections else 0
        
        # Classifica complexidade geral
        if avg_complexity >= 25:
            overall_rating = "VERY_HIGH"
        elif avg_complexity >= 15:
            overall_rating = "HIGH"
        elif avg_complexity >= 10:
            overall_rating = "MEDIUM"
        else:
            overall_rating = "LOW"
        
        return {
            "total_lines": total_lines,
            "total_complexity_score": total_complexity,
            "average_complexity": round(avg_complexity, 2),
            "overall_rating": overall_rating,
            "complexity_density": round(total_complexity / total_lines * 100, 2) if total_lines > 0 else 0
        }

    def _calculate_complexity_distribution(self, complex_sections: List[ComplexitySection]) -> Dict[str, int]:
        """Calcula distribuição de complexidade por prioridade."""
        distribution = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}
        
        for section in complex_sections:
            distribution[section.priority] += 1
        
        return distribution

    def _generate_complexity_recommendations(self, complex_sections: List[ComplexitySection], 
                                           overall_metrics: Dict[str, Any]) -> List[str]:
        """Gera recomendações baseadas na análise de complexidade."""
        recommendations = []
        
        high_complexity_sections = [s for s in complex_sections if s.priority == "HIGH"]
        
        if len(high_complexity_sections) > 5:
            recommendations.append(
                f"CRÍTICO: {len(high_complexity_sections)} seções de alta complexidade identificadas. "
                "Considere dividir a análise em múltiplas sessões."
            )
        
        if overall_metrics["overall_rating"] == "VERY_HIGH":
            recommendations.append(
                "Programa extremamente complexo. Recomenda-se análise por especialista sênior "
                "com pelo menos 5 anos de experiência em COBOL."
            )
        
        # Recomendações específicas por tipo de complexidade
        goto_sections = [s for s in complex_sections if any('goto_statement' in f for f in s.complexity_factors)]
        if goto_sections:
            recommendations.append(
                f"ATENÇÃO: {len(goto_sections)} seções com GO TO identificadas. "
                "Mapeie cuidadosamente o fluxo de controle antes de modernizar."
            )
        
        nested_if_sections = [s for s in complex_sections if any('nested_if' in f for f in s.complexity_factors)]
        if len(nested_if_sections) > 3:
            recommendations.append(
                f"Múltiplas seções ({len(nested_if_sections)}) com IFs aninhados complexos. "
                "Considere refatorar para padrões mais simples durante modernização."
            )
        
        total_time = sum(s.estimated_analysis_time for s in complex_sections)
        if total_time > 480:  # 8 horas
            recommendations.append(
                f"Tempo estimado de análise: {total_time//60}h {total_time%60}min. "
                "Considere dividir em múltiplas sessões de análise."
            )
        
        return recommendations

    def generate_complexity_report(self, complexity_analysis: Dict[str, Any]) -> str:
        """Gera relatório de complexidade em formato Markdown."""
        program_name = complexity_analysis["program_name"]
        overall = complexity_analysis["overall_complexity"]
        sections = complexity_analysis["top_complex_sections"]
        
        report = [
            f"#  Análise de Complexidade - {program_name}",
            "",
            "##  Métricas Gerais",
            f"- **Complexidade Geral:** {overall['overall_rating']}",
            f"- **Score Total:** {overall['total_complexity_score']}",
            f"- **Complexidade Média:** {overall['average_complexity']}",
            f"- **Densidade:** {overall['complexity_density']}% (complexidade por linha)",
            f"- **Tempo Estimado de Análise:** {complexity_analysis['estimated_total_analysis_time']//60}h {complexity_analysis['estimated_total_analysis_time']%60}min",
            "",
            "##  Top 10 Seções Mais Complexas",
            "",
            "| # | Seção | Score | Prioridade | Tempo Est. | Fatores Principais |",
            "|---|-------|-------|------------|------------|-------------------|"
        ]
        
        for i, section in enumerate(sections, 1):
            main_factors = section.complexity_factors[:2]  # Principais fatores
            factors_str = "; ".join(main_factors) if main_factors else "N/A"
            
            report.append(
                f"| {i} | {section.name} | {section.complexity_score} | "
                f"{section.priority} | {section.estimated_analysis_time}min | {factors_str} |"
            )
        
        report.extend([
            "",
            "## 🚨 Recomendações Críticas",
            ""
        ])
        
        for i, recommendation in enumerate(complexity_analysis["recommendations"], 1):
            report.append(f"{i}. {recommendation}")
        
        report.extend([
            "",
            "##  Estratégia de Análise Sugerida",
            "",
            "### Fase 1: Seções Críticas (Prioridade HIGH)",
            "Foque primeiro nas seções de alta complexidade para entender os pontos mais críticos:",
            ""
        ])
        
        high_priority_sections = [s for s in sections if s.priority == "HIGH"]
        for section in high_priority_sections:
            report.append(f"- **{section.name}** (Linhas {section.start_line}-{section.end_line}) - {section.estimated_analysis_time}min")
        
        report.extend([
            "",
            "### Fase 2: Seções Importantes (Prioridade MEDIUM)",
            "Após entender as seções críticas, analise as seções de complexidade média:",
            ""
        ])
        
        medium_priority_sections = [s for s in sections if s.priority == "MEDIUM"]
        for section in medium_priority_sections[:5]:  # Top 5 medium
            report.append(f"- **{section.name}** (Linhas {section.start_line}-{section.end_line}) - {section.estimated_analysis_time}min")
        
        report.extend([
            "",
            "##  Dicas para Especialistas",
            "",
            "1. **Comece pelas seções HIGH** - Elas contêm a lógica mais crítica",
            "2. **Mapeie dependências** - Entenda como as seções se relacionam",
            "3. **Documente padrões** - Identifique padrões repetitivos para acelerar análise",
            "4. **Valide com negócio** - Seções complexas geralmente contêm regras críticas",
            "5. **Considere refatoração** - Seções muito complexas podem se beneficiar de simplificação",
            ""
        ])
        
        return "\n".join(report)
