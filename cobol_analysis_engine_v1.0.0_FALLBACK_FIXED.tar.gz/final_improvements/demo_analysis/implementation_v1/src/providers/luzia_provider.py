#!/usr/bin/env python3
"""
Provider LuzIA corrigido baseado no exemplo que funcionava.
Implementa autenticação OAuth2 e fallback inteligente.
"""

import os
import json
import requests
import time
import logging
from typing import Dict, Any, Optional
from datetime import datetime, timedelta

# Imports condicionais
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse


class LuziaProvider(BaseProvider):
    """Provider LuzIA corrigido baseado no exemplo que funcionava."""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        
        self.client_id = config.get('client_id', os.getenv('LUZIA_CLIENT_ID', ''))
        self.client_secret = config.get('client_secret', os.getenv('LUZIA_CLIENT_SECRET', ''))
        self.auth_endpoint = config.get('auth_url', 'https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token')
        self.api_endpoint = config.get('api_url', 'https://gpt-api.aws.santanderbr.dev.corp/genai_services/v1')
        self.model = config.get('model', 'aws-claude-1-3-sonnet-exp')
        
        # Configurações de autenticação
        self.access_token = None
        self.token_expires_at = None
        self.token_type = "Bearer"
        
        # Configurações de retry
        retry_config = config.get('retry', {})
        self.max_attempts = retry_config.get('max_attempts', 3)
        self.base_delay = retry_config.get('base_delay', 2.0)
        self.max_delay = retry_config.get('max_delay', 30.0)
        self.backoff_multiplier = retry_config.get('backoff_multiplier', 2.0)
        
        # Rate limiting
        self.requests_per_minute = retry_config.get('requests_per_minute', 8)
        self.last_request_time = 0
        
        # Configurações mock
        self.mock_config = config.get('mock', {})
        self.mode = config.get('mode', 'rest')
        
        # Testar conectividade na inicialização
        if self.mode == 'rest' and not self._test_connectivity():
            print(f"⚠️  Provider LuzIA: URLs corporativas não acessíveis externamente")
            print(f"   Auth URL: {self.auth_endpoint}")
            print(f"   API URL: {self.api_endpoint}")
            print(f"   Continuando com modo simulado...")
            self.mode = 'mock'
        
        self.logger.info(f"LuzIA Provider inicializado em modo {self.mode}")
    
    def _test_connectivity(self) -> bool:
        """Testa conectividade com URLs corporativas."""
        if not REQUESTS_AVAILABLE:
            return False
        
        try:
            # Teste rápido de conectividade (timeout baixo)
            response = requests.get(
                self.auth_endpoint, 
                timeout=5, 
                verify=False
            )
            # Qualquer resposta (mesmo 405) indica que o endpoint está acessível
            return True
            
        except (requests.exceptions.ConnectTimeout, 
                requests.exceptions.ConnectionError,
                requests.exceptions.Timeout):
            return False
        except Exception:
            return False
    
    def _get_access_token(self) -> Optional[str]:
        """Obtém token de acesso OAuth2."""
        if not REQUESTS_AVAILABLE:
            return None
        
        current_time = datetime.now()
        
        # Verifica se o token ainda é válido
        if (self.access_token and self.token_expires_at and 
            current_time < self.token_expires_at):
            return self.access_token
        
        try:
            # Dados de autenticação OAuth2 client_credentials
            auth_data = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json'
            }
            
            response = requests.post(
                self.auth_endpoint,
                data=auth_data,
                headers=headers,
                timeout=30,
                verify=False
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self.access_token = token_data.get('access_token')
                expires_in = token_data.get('expires_in', 3600)
                
                # Define expiração com margem de segurança
                self.token_expires_at = current_time + timedelta(seconds=expires_in - 60)
                
                self.logger.info("Token de acesso LuzIA obtido com sucesso")
                return self.access_token
            else:
                self.logger.error(f"Erro ao obter token LuzIA: {response.status_code}")
                self.logger.error(f"Resposta: {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Erro na autenticação LuzIA: {e}")
            return None
    
    def _rate_limit(self):
        """Implementa rate limiting."""
        if self.requests_per_minute <= 0:
            return
        
        min_interval = 60.0 / self.requests_per_minute
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < min_interval:
            sleep_time = min_interval - time_since_last
            self.logger.debug(f"Rate limiting: aguardando {sleep_time:.2f}s")
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def _make_rest_request(self, prompt: str) -> str:
        """Faz requisição via API REST."""
        token = self._get_access_token()
        if not token:
            raise Exception("Não foi possível obter token de acesso")
        
        self._rate_limit()
        
        headers = {
            'Authorization': f'{self.token_type} {token}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        
        # Payload baseado no exemplo que funcionava
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "stream": False
        }
        
        response = requests.post(
            f"{self.api_endpoint}/chat/completions",
            json=payload,
            headers=headers,
            timeout=self.timeout,
            verify=False
        )
        
        if response.status_code == 200:
            result = response.json()
            
            # Extrai conteúdo da resposta
            if 'choices' in result and len(result['choices']) > 0:
                return result['choices'][0]['message']['content']
            elif 'content' in result:
                return result['content']
            else:
                return str(result)
        else:
            raise Exception(f"Erro na API LuzIA: {response.status_code} - {response.text}")
    
    def _make_mock_request(self, prompt: str) -> str:
        """Gera resposta mock para LuzIA."""
        
        # Simular latência se configurado
        if self.mock_config.get('simulate_latency', False):
            time.sleep(0.5)
        
        quality = self.mock_config.get('quality_level', 'high')
        
        if quality == 'high':
            return f"""# Análise COBOL - LuzIA (Modo Simulado)

## Resumo Executivo
Este programa COBOL foi analisado usando o sistema LuzIA em modo simulado, 
pois as URLs corporativas do Santander não estão acessíveis externamente.

## Análise Estrutural
- Programa identificado com estrutura COBOL padrão
- Divisões: IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE
- Compatível com COBOL-85/2002

## Análise de Negócio
- Processamento de dados corporativos
- Regras de negócio identificadas
- Validações de entrada implementadas

## Recomendações Técnicas
- Código bem estruturado
- Padrões corporativos seguidos
- Pronto para modernização

*Nota: Esta é uma resposta simulada. Para análise real, configure acesso às URLs corporativas do Santander.*
"""
        elif quality == 'medium':
            return "Análise COBOL realizada com LuzIA (modo simulado). Estrutura básica identificada."
        else:
            return "Análise básica concluída (LuzIA mock)."
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """Executa análise usando LuzIA com fallback inteligente."""
        start_time = time.time()
        
        for attempt in range(self.max_attempts):
            try:
                self.logger.info(f"LuzIA: Tentativa {attempt + 1}/{self.max_attempts}")
                
                # Escolhe o método baseado no modo
                if self.mode == 'rest':
                    response_text = self._make_rest_request(request.prompt)
                else:
                    response_text = self._make_mock_request(request.prompt)
                
                # Sucesso
                end_time = time.time()
                
                return AIResponse(
                    content=response_text,
                    model=self.model if self.mode == 'rest' else f"{self.model}-mock",
                    provider="luzia",
                    tokens_used=len(response_text.split()),
                    response_time=end_time - start_time,
                    success=True
                )
                
            except Exception as e:
                self.logger.warning(f"Tentativa {attempt + 1} falhou: {e}")
                
                if attempt < self.max_attempts - 1:
                    delay = min(self.base_delay * (self.backoff_multiplier ** attempt), self.max_delay)
                    self.logger.info(f"Aguardando {delay:.2f}s antes da próxima tentativa")
                    time.sleep(delay)
                else:
                    # Última tentativa falhou, usar mock
                    self.logger.error("Todas as tentativas falharam, usando resposta mock")
                    response_text = self._make_mock_request(request.prompt)
                    
                    end_time = time.time()
                    return AIResponse(
                        content=response_text,
                        model="luzia-mock",
                        provider="luzia",
                        tokens_used=len(response_text.split()),
                        response_time=end_time - start_time,
                        success=False,
                        error=str(e)
                    )
    
    def is_available(self) -> bool:
        """Verifica se o provedor está disponível."""
        if self.mode == 'rest':
            return REQUESTS_AVAILABLE and bool(self.client_id and self.client_secret)
        else:
            return True  # Mock sempre disponível
    
    def get_model_info(self) -> Dict[str, Any]:
        """Retorna informações do modelo."""
        return {
            'provider': 'luzia',
            'mode': self.mode,
            'model': self.model,
            'max_tokens': self.max_tokens,
            'temperature': self.temperature,
            'available': self.is_available(),
            'auth_endpoint': self.auth_endpoint,
            'api_endpoint': self.api_endpoint
        }
