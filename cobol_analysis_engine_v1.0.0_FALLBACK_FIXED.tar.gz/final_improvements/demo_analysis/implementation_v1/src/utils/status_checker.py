#!/usr/bin/env python3
"""
Status Checker - Sistema de Análise COBOL v1.0.0
Verifica status dos providers e componentes do sistema.
"""

import os
import sys
import importlib
from typing import Dict, Any, List
import logging

class SystemStatusChecker:
    """Verificador de status do sistema."""
    
    def __init__(self):
        """Inicializa o verificador de status."""
        self.logger = logging.getLogger(__name__)
        
    def check_all_status(self) -> Dict[str, Any]:
        """Verifica status completo do sistema."""
        
        status = {
            'system': self._check_system_status(),
            'dependencies': self._check_dependencies(),
            'providers': self._check_providers_status(),
            'multi_ai': self._check_multi_ai_status(),
            'extractors': self._check_extractors_status(),
            'config': self._check_config_status(),
            'examples': self._check_examples_status()
        }
        
        # Calcular status geral
        status['overall'] = self._calculate_overall_status(status)
        
        return status
    
    def _check_system_status(self) -> Dict[str, Any]:
        """Verifica status básico do sistema."""
        
        return {
            'python_version': sys.version,
            'platform': sys.platform,
            'working_directory': os.getcwd(),
            'script_path': os.path.abspath(__file__),
            'status': 'operational'
        }
    
    def _check_dependencies(self) -> Dict[str, Any]:
        """Verifica dependências Python."""
        
        required_packages = [
            'yaml', 'json', 'pathlib', 'asyncio', 'logging',
            'datetime', 'time', 'os', 'sys', 're'
        ]
        
        dependencies = {}
        all_available = True
        
        for package in required_packages:
            try:
                importlib.import_module(package)
                dependencies[package] = {'status': 'available', 'version': 'built-in'}
            except ImportError:
                dependencies[package] = {'status': 'missing', 'version': None}
                all_available = False
        
        # Verificar PyYAML especificamente
        try:
            import yaml
            dependencies['PyYAML'] = {'status': 'available', 'version': getattr(yaml, '__version__', 'unknown')}
        except ImportError:
            dependencies['PyYAML'] = {'status': 'missing', 'version': None}
            all_available = False
        
        return {
            'packages': dependencies,
            'all_available': all_available,
            'status': 'complete' if all_available else 'incomplete'
        }
    
    def _check_providers_status(self) -> Dict[str, Any]:
        """Verifica status dos providers LLM."""
        
        providers = {}
        
        # OpenAI
        openai_key = os.getenv('OPENAI_API_KEY')
        providers['openai'] = {
            'configured': bool(openai_key),
            'api_key_set': bool(openai_key),
            'status': 'ready' if openai_key else 'not_configured',
            'type': 'external_api'
        }
        
        # GitHub Copilot
        copilot_key = os.getenv('COPILOT_API_KEY')
        providers['copilot'] = {
            'configured': bool(copilot_key),
            'api_key_set': bool(copilot_key),
            'status': 'ready' if copilot_key else 'not_configured',
            'type': 'external_api'
        }
        
        # LuzIA
        luzia_key = os.getenv('LUZIA_API_KEY')
        luzia_url = os.getenv('LUZIA_API_URL')
        providers['luzia'] = {
            'configured': bool(luzia_key),
            'api_key_set': bool(luzia_key),
            'api_url_set': bool(luzia_url),
            'status': 'ready' if luzia_key else 'not_configured',
            'type': 'external_api'
        }
        
        # Enhanced Mock (sempre disponível)
        providers['enhanced_mock'] = {
            'configured': True,
            'api_key_set': True,
            'status': 'ready',
            'type': 'internal_mock'
        }
        
        # Mock básico (sempre disponível)
        providers['mock'] = {
            'configured': True,
            'api_key_set': True,
            'status': 'ready',
            'type': 'internal_mock'
        }
        
        # Contar providers prontos
        ready_providers = sum(1 for p in providers.values() if p['status'] == 'ready')
        external_ready = sum(1 for p in providers.values() if p['type'] == 'external_api' and p['status'] == 'ready')
        
        return {
            'providers': providers,
            'total_providers': len(providers),
            'ready_providers': ready_providers,
            'external_ready': external_ready,
            'multi_ai_capable': external_ready >= 1,  # Pelo menos 1 externo + mocks
            'status': 'operational' if ready_providers >= 2 else 'limited'
        }
    
    def _check_multi_ai_status(self) -> Dict[str, Any]:
        """Verifica status do sistema Multi-IA."""
        
        components = {}
        
        # Verificar componentes Multi-IA
        multi_ai_components = [
            'src.core.multi_ai_orchestrator',
            'src.core.cross_validator',
            'src.core.clarity_engine'
        ]
        
        all_available = True
        for component in multi_ai_components:
            try:
                importlib.import_module(component)
                components[component.split('.')[-1]] = {'status': 'available'}
            except ImportError as e:
                components[component.split('.')[-1]] = {'status': 'missing', 'error': str(e)}
                all_available = False
        
        return {
            'components': components,
            'all_available': all_available,
            'status': 'operational' if all_available else 'degraded'
        }
    
    def _check_extractors_status(self) -> Dict[str, Any]:
        """Verifica status dos extratores de conteúdo."""
        
        extractors = {}
        
        # Verificar extratores
        extractor_components = [
            'src.extractors.content_extractor',
            'src.generators.hybrid_documentation_generator'
        ]
        
        all_available = True
        for component in extractor_components:
            try:
                importlib.import_module(component)
                extractors[component.split('.')[-1]] = {'status': 'available'}
            except ImportError as e:
                extractors[component.split('.')[-1]] = {'status': 'missing', 'error': str(e)}
                all_available = False
        
        return {
            'extractors': extractors,
            'all_available': all_available,
            'status': 'operational' if all_available else 'degraded'
        }
    
    def _check_config_status(self) -> Dict[str, Any]:
        """Verifica status dos arquivos de configuração."""
        
        config_files = {
            'config/config.yaml': 'main_config',
            'config/prompts.yaml': 'prompts_config'
        }
        
        configs = {}
        all_available = True
        
        for file_path, config_type in config_files.items():
            if os.path.exists(file_path):
                try:
                    import yaml
                    with open(file_path, 'r', encoding='utf-8') as f:
                        config_data = yaml.safe_load(f)
                    
                    configs[config_type] = {
                        'status': 'available',
                        'file_exists': True,
                        'valid_yaml': True,
                        'size_kb': round(os.path.getsize(file_path) / 1024, 1)
                    }
                except Exception as e:
                    configs[config_type] = {
                        'status': 'invalid',
                        'file_exists': True,
                        'valid_yaml': False,
                        'error': str(e)
                    }
                    all_available = False
            else:
                configs[config_type] = {
                    'status': 'missing',
                    'file_exists': False,
                    'valid_yaml': False
                }
                all_available = False
        
        return {
            'configs': configs,
            'all_available': all_available,
            'status': 'complete' if all_available else 'incomplete'
        }
    
    def _check_examples_status(self) -> Dict[str, Any]:
        """Verifica status dos arquivos de exemplo."""
        
        example_files = {
            'examples/fontes.txt': 'multi_program_file',
            'examples/BOOKS.txt': 'copybooks_file',
            'examples/LHAN0542_TESTE.cbl': 'individual_program'
        }
        
        examples = {}
        all_available = True
        
        for file_path, file_type in example_files.items():
            if os.path.exists(file_path):
                size_kb = round(os.path.getsize(file_path) / 1024, 1)
                
                # Verificar conteúdo básico
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    
                    if file_type == 'multi_program_file':
                        program_count = content.count('VMEMBER NAME')
                        examples[file_type] = {
                            'status': 'available',
                            'size_kb': size_kb,
                            'programs_found': program_count
                        }
                    elif file_type == 'copybooks_file':
                        copybook_count = content.count('COPY ')
                        examples[file_type] = {
                            'status': 'available',
                            'size_kb': size_kb,
                            'copybooks_found': copybook_count
                        }
                    else:
                        examples[file_type] = {
                            'status': 'available',
                            'size_kb': size_kb,
                            'lines': len(content.splitlines())
                        }
                        
                except Exception as e:
                    examples[file_type] = {
                        'status': 'invalid',
                        'error': str(e)
                    }
                    all_available = False
            else:
                examples[file_type] = {'status': 'missing'}
                all_available = False
        
        return {
            'examples': examples,
            'all_available': all_available,
            'status': 'complete' if all_available else 'incomplete'
        }
    
    def _calculate_overall_status(self, status: Dict[str, Any]) -> Dict[str, Any]:
        """Calcula status geral do sistema."""
        
        # Verificar componentes críticos
        critical_ok = (
            status['dependencies']['status'] == 'complete' and
            status['config']['status'] == 'complete' and
            status['examples']['status'] == 'complete'
        )
        
        # Verificar capacidades
        multi_ai_ready = (
            status['multi_ai']['status'] == 'operational' and
            status['providers']['multi_ai_capable']
        )
        
        extraction_ready = status['extractors']['status'] == 'operational'
        
        # Determinar status geral
        if critical_ok and multi_ai_ready and extraction_ready:
            overall_status = 'excellent'
            capabilities = ['multi_ai', 'extraction', 'traditional', 'hybrid']
        elif critical_ok and extraction_ready:
            overall_status = 'good'
            capabilities = ['extraction', 'traditional', 'hybrid_limited']
        elif critical_ok:
            overall_status = 'basic'
            capabilities = ['traditional', 'demo']
        else:
            overall_status = 'degraded'
            capabilities = ['limited']
        
        return {
            'status': overall_status,
            'capabilities': capabilities,
            'critical_components_ok': critical_ok,
            'multi_ai_ready': multi_ai_ready,
            'extraction_ready': extraction_ready,
            'ready_for_production': overall_status in ['excellent', 'good']
        }
    
    def format_status_report(self, status: Dict[str, Any]) -> str:
        """Formata relatório de status para exibição."""
        
        report = []
        report.append("Sistema de Análise COBOL v1.0.0 - Status Report")
        report.append("=" * 60)
        
        # Status geral
        overall = status['overall']
        report.append(f"\nStatus Geral: {overall['status'].upper()}")
        report.append(f"Pronto para Produção: {'SIM' if overall['ready_for_production'] else 'NÃO'}")
        report.append(f"Capacidades: {', '.join(overall['capabilities'])}")
        
        # Providers
        providers = status['providers']
        report.append(f"\nProviders LLM:")
        
        for name, info in providers['providers'].items():
            status_icon = "✅" if info['status'] == 'ready' else "❌"
            report.append(f"  {status_icon} {name}: {info['status']}")
        
        # Componentes
        report.append(f"\nComponentes:")
        
        components_status = [
            ("Dependências", status['dependencies']['status']),
            ("Multi-IA", status['multi_ai']['status']),
            ("Extratores", status['extractors']['status']),
            ("Configuração", status['config']['status']),
            ("Exemplos", status['examples']['status'])
        ]
        
        for name, comp_status in components_status:
            status_icon = "✅" if comp_status in ['complete', 'operational'] else "❌"
            report.append(f"  {status_icon} {name}: {comp_status}")
        
        # Arquivos de exemplo
        examples = status['examples']['examples']
        report.append(f"\nArquivos de Exemplo:")
        for name, info in examples.items():
            status_icon = "✅" if info['status'] == 'available' else "❌"
            if info['status'] == 'available':
                if 'programs_found' in info:
                    report.append(f"  {status_icon} {name}: {info['programs_found']} programas ({info['size_kb']}KB)")
                elif 'copybooks_found' in info:
                    report.append(f"  {status_icon} {name}: {info['copybooks_found']} copybooks ({info['size_kb']}KB)")
                else:
                    report.append(f"  {status_icon} {name}: {info.get('lines', 0)} linhas ({info['size_kb']}KB)")
            else:
                report.append(f"  {status_icon} {name}: {info['status']}")
        
        # Recomendações
        report.append(f"\nRecomendações:")
        
        if not overall['multi_ai_ready']:
            report.append("  • Configure pelo menos 1 provider externo para Multi-IA:")
            if not providers['providers']['openai']['configured']:
                report.append("    export OPENAI_API_KEY='sua_chave'")
            if not providers['providers']['copilot']['configured']:
                report.append("    export COPILOT_API_KEY='sua_chave'")
        
        if overall['status'] == 'excellent':
            report.append("  • Sistema totalmente operacional!")
            report.append("  • Todas as funcionalidades disponíveis")
        elif overall['status'] == 'good':
            report.append("  • Sistema operacional com funcionalidades híbridas")
        else:
            report.append("  • Configure providers para funcionalidade completa")
        
        return "\n".join(report)

def main():
    """Função principal para execução standalone."""
    
    checker = SystemStatusChecker()
    status = checker.check_all_status()
    report = checker.format_status_report(status)
    
    print(report)
    
    # Retornar código de saída baseado no status
    if status['overall']['ready_for_production']:
        return 0
    else:
        return 1

if __name__ == "__main__":
    import sys
    sys.exit(main())
