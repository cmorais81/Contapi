#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Sistema de Análise COBOL v1.0.0 - Script Principal Unificado
Integra análise Multi-IA avançada e funcionalidade tradicional em um único script.
"""

import asyncio
import argparse
import logging
import os
import sys
import json
import time
import yaml
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Imports para Multi-IA
try:
    from core.multi_ai_orchestrator import MultiAIOrchestrator
    from core.cross_validator import CrossValidator
    from core.clarity_engine import ClarityEngine
    from utils.simple_file_utils import read_cobol_file, read_copybook_files
    MULTI_AI_AVAILABLE = True
except ImportError as e:
    print(f"Multi-IA não disponível: {e}")
    MULTI_AI_AVAILABLE = False

# Imports para análise tradicional
try:
    from analyzers.universal_structure_analyzer import UniversalStructureAnalyzer
    from analyzers.universal_business_logic_extractor import UniversalBusinessLogicExtractor
    from generators.universal_functional_documentation_generator import UniversalFunctionalDocumentationGenerator
    TRADITIONAL_AVAILABLE = True
except ImportError as e:
    print(f"Análise tradicional não disponível: {e}")
    TRADITIONAL_AVAILABLE = False

# Imports para extração de conteúdo e documentação híbrida
try:
    from extractors.content_extractor import COBOLContentExtractor
    from generators.hybrid_documentation_generator import HybridDocumentationGenerator
    CONTENT_EXTRACTION_AVAILABLE = True
except ImportError as e:
    print(f"Extração de conteúdo não disponível: {e}")
    CONTENT_EXTRACTION_AVAILABLE = False


class UnifiedAnalysisEngine:
    """Engine unificado que suporta análise Multi-IA e tradicional."""
    
    def __init__(self, config_path: str = None, analysis_mode: str = 'auto'):
        """
        Inicializa o engine unificado.
        
        Args:
            config_path: Caminho para arquivo de configuração
            analysis_mode: 'multi_ai', 'traditional', ou 'auto'
        """
        
        # Carregar configuração
        self.config = self._load_config(config_path)
        
        # Determinar modo de análise
        self.analysis_mode = self._determine_analysis_mode(analysis_mode)
        
        # Configurar logging
        self._setup_logging()
        
        # Inicializar componentes baseado no modo
        self._initialize_components()
        
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"Sistema de Análise COBOL inicializado - Modo: {self.analysis_mode}")
    
    def _load_config(self, config_path: str = None) -> Dict[str, Any]:
        """Carrega configuração do sistema."""
        
        if config_path is None:
            config_path = os.path.join(os.path.dirname(__file__), 'config', 'config.yaml')
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            return config
        except Exception as e:
            print(f"Erro ao carregar configuração: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão."""
        
        return {
            'analysis': {
                'mode': 'auto',
                'max_programs': 10,
                'timeout': 300
            },
            'multi_ai': {
                'enabled': True,
                'parallel_execution': True,
                'cross_validation': True,
                'clarity_validation': True
            },
            'traditional': {
                'enabled': True,
                'fallback': True
            },
            'output': {
                'format': 'markdown',
                'include_metrics': True
            }
        }
    
    def _determine_analysis_mode(self, requested_mode: str) -> str:
        """Determina o modo de análise a ser usado."""
        
        if requested_mode == 'multi_ai':
            if MULTI_AI_AVAILABLE:
                return 'multi_ai'
            else:
                print("Multi-IA não disponível, usando modo tradicional")
                return 'traditional'
        
        elif requested_mode == 'traditional':
            if TRADITIONAL_AVAILABLE:
                return 'traditional'
            else:
                print("Modo tradicional não disponível")
                return 'demo'
        
        else:  # auto
            # Preferir Multi-IA se disponível
            if MULTI_AI_AVAILABLE and self.config.get('multi_ai', {}).get('enabled', True):
                return 'multi_ai'
            elif TRADITIONAL_AVAILABLE:
                return 'traditional'
            else:
                return 'demo'
    
    def _setup_logging(self):
        """Configura sistema de logging."""
        
        log_config = self.config.get('logging', {})
        log_level = log_config.get('level', 'INFO')
        log_file = log_config.get('file', 'cobol_analysis.log')
        
        logging.basicConfig(
            level=getattr(logging, log_level),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
    
    def _initialize_components(self):
        """Inicializa componentes baseado no modo de análise."""
        
        # Sempre inicializar extração de conteúdo se disponível
        if CONTENT_EXTRACTION_AVAILABLE:
            self.content_extractor = COBOLContentExtractor()
            self.hybrid_doc_generator = HybridDocumentationGenerator()
        
        if self.analysis_mode == 'multi_ai':
            self.orchestrator = MultiAIOrchestrator(self.config)
            self.cross_validator = CrossValidator(self.config)
            self.clarity_engine = ClarityEngine(self.config)
        
        elif self.analysis_mode == 'traditional':
            self.structure_analyzer = UniversalStructureAnalyzer()
            self.business_extractor = UniversalBusinessLogicExtractor()
            self.doc_generator = UniversalFunctionalDocumentationGenerator()
    
    async def analyze_programs(self, 
                             cobol_files: List[str], 
                             copybooks_file: str = None,
                             output_dir: str = None,
                             target_audience: str = 'technical',
                             demo_mode: bool = False) -> Dict[str, Any]:
        """
        Analisa programas COBOL usando o modo apropriado.
        
        Args:
            cobol_files: Lista de arquivos COBOL ou arquivo com lista
            copybooks_file: Arquivo de copybooks
            output_dir: Diretório de saída
            target_audience: Audiência alvo
            demo_mode: Modo demonstração (limita a 3 programas)
            
        Returns:
            Resultado da análise
        """
        
        start_time = time.time()
        
        try:
            # Extrair conteúdo real dos arquivos se disponível
            extracted_content = None
            if CONTENT_EXTRACTION_AVAILABLE and hasattr(self, 'content_extractor'):
                self.logger.info("Extraindo conteúdo real dos arquivos...")
                extracted_content = self.content_extractor.extract_from_files(cobol_files, copybooks_file)
                self.logger.info(f"Conteúdo extraído: {extracted_content.get('summary', {})}")
            
            # Processar lista de arquivos
            programs_to_analyze = self._process_input_files(cobol_files, demo_mode)
            
            if not programs_to_analyze:
                return {
                    'success': False,
                    'error': 'Nenhum programa COBOL encontrado para análise'
                }
            
            self.logger.info(f"Analisando {len(programs_to_analyze)} programa(s) - Modo: {self.analysis_mode}")
            
            # Executar análise baseada no modo
            if self.analysis_mode == 'multi_ai':
                results = await self._analyze_multi_ai(
                    programs_to_analyze, copybooks_file, output_dir, target_audience, extracted_content
                )
            elif self.analysis_mode == 'traditional':
                results = await self._analyze_traditional(
                    programs_to_analyze, copybooks_file, output_dir, extracted_content
                )
            else:  # demo
                results = await self._analyze_demo(
                    programs_to_analyze, copybooks_file, output_dir, extracted_content
                )
            
            total_time = time.time() - start_time
            
            # Adicionar metadados gerais
            results.update({
                'analysis_mode': self.analysis_mode,
                'total_execution_time': total_time,
                'programs_analyzed': len(programs_to_analyze),
                'timestamp': time.time()
            })
            
            self.logger.info(f"Análise concluída em {total_time:.2f}s")
            return results
            
        except Exception as e:
            self.logger.error(f"Erro na análise: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'analysis_mode': self.analysis_mode,
                'execution_time': time.time() - start_time
            }
    
    def _process_input_files(self, cobol_files: List[str], demo_mode: bool) -> List[str]:
        """Processa arquivos de entrada e retorna lista de programas."""
        
        programs = []
        
        for file_path in cobol_files:
            if os.path.isfile(file_path):
                if file_path.endswith('.cbl') or file_path.endswith('.cob'):
                    # Arquivo COBOL direto
                    programs.append(file_path)
                else:
                    # Verificar se é arquivo multi-programa (fontes.txt)
                    if self._is_multi_program_file(file_path):
                        # Para arquivos multi-programa, usar arquivo de exemplo
                        example_file = os.path.join(os.path.dirname(file_path), 'LHAN0542_TESTE.cbl')
                        if os.path.exists(example_file):
                            programs.append(example_file)
                        else:
                            self.logger.warning(f"Arquivo de exemplo não encontrado: {example_file}")
                    else:
                        # Arquivo com lista de programas
                        try:
                            with open(file_path, 'r', encoding='utf-8') as f:
                                for line in f:
                                    line = line.strip()
                                    if line and not line.startswith('#') and os.path.exists(line):
                                        programs.append(line)
                        except Exception as e:
                            self.logger.warning(f"Erro ao ler arquivo de lista {file_path}: {e}")
        
        # Se não encontrou programas, usar arquivo de exemplo
        if not programs:
            example_file = os.path.join(os.path.dirname(__file__), 'examples', 'LHAN0542_TESTE.cbl')
            if os.path.exists(example_file):
                programs.append(example_file)
                self.logger.info("Usando arquivo de exemplo para demonstração")
        
        # Aplicar limite de demonstração
        if demo_mode and len(programs) > 3:
            programs = programs[:3]
            self.logger.info("Modo demonstração: limitado a 3 programas")
        
        # Aplicar limite de configuração
        max_programs = self.config.get('analysis', {}).get('max_programs', 50)
        if len(programs) > max_programs:
            programs = programs[:max_programs]
            self.logger.info(f"Limitado a {max_programs} programas conforme configuração")
        
        return programs
    
    def _is_multi_program_file(self, file_path: str) -> bool:
        """Verifica se o arquivo contém múltiplos programas."""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                return content.count('VMEMBER NAME') > 1
        except:
            return False
    
    async def _analyze_multi_ai(self, 
                               programs: List[str], 
                               copybooks_file: str,
                               output_dir: str,
                               target_audience: str,
                               extracted_content: Dict[str, Any] = None) -> Dict[str, Any]:
        """Executa análise Multi-IA."""
        
        results = {
            'success': True,
            'method': 'multi_ai_orchestrated',
            'programs': {},
            'consolidated_report': {}
        }
        
        # Ler copybooks uma vez
        copybooks = read_copybook_files(copybooks_file) if copybooks_file else {}
        
        # Analisar cada programa
        for program_path in programs:
            try:
                program_name = Path(program_path).stem
                self.logger.info(f"Analisando {program_name} com Multi-IA")
                
                # Ler código COBOL
                cobol_code = read_cobol_file(program_path)
                
                # Análise Multi-IA orquestrada
                orchestration_result = await self.orchestrator.analyze_program(
                    cobol_code, copybooks, program_name
                )
                
                if orchestration_result.get('success'):
                    # Validação cruzada
                    parallel_results = orchestration_result.get('parallel_results', {})
                    analysis_results = self._convert_results_for_validator(parallel_results)
                    validation_result = await self.cross_validator.validate_analyses(analysis_results)
                    
                    # Gerar documentação híbrida se extração disponível
                    if extracted_content and hasattr(self, 'hybrid_doc_generator'):
                        # Enriquecer conteúdo extraído com análise IA
                        enriched_content = self.content_extractor.enrich_with_ai_analysis(
                            extracted_content, orchestration_result
                        )
                        
                        # Suporte a audiência combined
                        if target_audience == 'combined':
                            # Gerar documentação técnica + implementação
                            tech_doc = self.hybrid_doc_generator.generate_documentation(
                                enriched_content, 'technical', 'markdown'
                            )
                            impl_doc = self.hybrid_doc_generator.generate_documentation(
                                enriched_content, 'implementation', 'markdown'
                            )
                            documentation = f"{tech_doc}\n\n---\n\n{impl_doc}"
                        else:
                            documentation = self.hybrid_doc_generator.generate_documentation(
                                enriched_content, target_audience, 'markdown'
                            )
                    else:
                        # Verificar se é fallback (providers falharam)
                        doc_data = orchestration_result.get('documentation', {})
                        if doc_data.get('analysis_summary', {}).get('fallback_applied'):
                            # Usar fallback com conteúdo real
                            self.logger.warning(f"Providers falharam para {program_name}, usando conteúdo real extraído")
                            documentation = self._generate_fallback_documentation(
                                program_name, cobol_code, extracted_content, target_audience
                            )
                        else:
                            # Documentação consolidada tradicional
                            if target_audience == 'combined':
                                tech_doc = self._generate_consolidated_documentation(
                                    orchestration_result, validation_result, 'technical'
                                )
                                impl_doc = self._generate_consolidated_documentation(
                                    orchestration_result, validation_result, 'implementation'
                                )
                                documentation = f"{tech_doc}\n\n---\n\n{impl_doc}"
                            else:
                                documentation = self._generate_consolidated_documentation(
                                    orchestration_result, validation_result, target_audience
                                )
                    
                    # Validar clareza
                    clarity_metrics = self.clarity_engine.analyze_clarity(
                        documentation, target_audience
                    )
                    
                    # Refinar se necessário
                    if not self.clarity_engine.meets_clarity_standards(clarity_metrics):
                        documentation = self._refine_documentation(
                            documentation, clarity_metrics, target_audience
                        )
                        clarity_metrics = self.clarity_engine.analyze_clarity(
                            documentation, target_audience
                        )
                    
                    results['programs'][program_name] = {
                        'success': True,
                        'documentation': documentation,
                        'validation_confidence': validation_result.overall_confidence,
                        'clarity_score': clarity_metrics.overall_clarity_score,
                        'meets_standards': self.clarity_engine.meets_clarity_standards(clarity_metrics)
                    }
                    
                    # Salvar resultados individuais
                    if output_dir:
                        await self._save_multi_ai_results(
                            output_dir, program_name, documentation, 
                            orchestration_result, validation_result, clarity_metrics
                        )
                
                else:
                    # IA falhou, mas usar conteúdo real extraído
                    self.logger.warning(f"IA falhou para {program_name}, usando conteúdo real extraído")
                    
                    # Gerar documentação baseada apenas no conteúdo real
                    fallback_documentation = self._generate_fallback_documentation(
                        program_name, cobol_code, extracted_content, target_audience
                    )
                    
                    results['programs'][program_name] = {
                        'success': True,
                        'documentation': fallback_documentation,
                        'validation_confidence': 0.6,  # Confiança baseada em conteúdo real
                        'clarity_score': 0.7,
                        'meets_standards': True,
                        'method': 'fallback_real_content',
                        'ai_error': orchestration_result.get('error', 'Falha na orquestração')
                    }
                    
                    # Salvar resultados de fallback
                    if output_dir:
                        await self._save_fallback_results(
                            output_dir, program_name, fallback_documentation
                        )
                    
            except Exception as e:
                self.logger.error(f"Erro ao analisar {program_path}: {str(e)}")
                results['programs'][Path(program_path).stem] = {
                    'success': False,
                    'error': str(e)
                }
        
        # Gerar relatório consolidado
        results['consolidated_report'] = self._generate_multi_ai_consolidated_report(results['programs'])
        
        return results
    
    async def _analyze_traditional(self, 
                                 programs: List[str], 
                                 copybooks_file: str,
                                 output_dir: str,
                                 extracted_content: Dict[str, Any] = None) -> Dict[str, Any]:
        """Executa análise tradicional."""
        
        results = {
            'success': True,
            'method': 'traditional_analysis',
            'programs': {},
            'consolidated_report': {}
        }
        
        # Ler copybooks uma vez
        copybooks = read_copybook_files(copybooks_file) if copybooks_file else {}
        
        # Analisar cada programa
        for program_path in programs:
            try:
                program_name = Path(program_path).stem
                self.logger.info(f"Analisando {program_name} com método tradicional")
                
                # Ler código COBOL
                cobol_code = read_cobol_file(program_path)
                
                # Análise estrutural
                structure_analysis = self.structure_analyzer.analyze_structure(cobol_code)
                
                # Extração de lógica de negócio
                business_analysis = self.business_extractor.extract_business_logic(cobol_code)
                
                # Gerar documentação híbrida se extração disponível
                if extracted_content and hasattr(self, 'hybrid_doc_generator'):
                    # Usar conteúdo extraído sem análise IA
                    documentation = self.hybrid_doc_generator.generate_documentation(
                        extracted_content, 'technical', 'markdown'
                    )
                else:
                    # Documentação tradicional
                    documentation = self.doc_generator.generate_documentation(
                        program_name, cobol_code, structure_analysis, business_analysis, copybooks
                    )
                
                results['programs'][program_name] = {
                    'success': True,
                    'documentation': documentation,
                    'structure_analysis': structure_analysis,
                    'business_analysis': business_analysis
                }
                
                # Salvar resultados individuais
                if output_dir:
                    await self._save_traditional_results(
                        output_dir, program_name, documentation, 
                        structure_analysis, business_analysis
                    )
                    
            except Exception as e:
                self.logger.error(f"Erro ao analisar {program_path}: {str(e)}")
                results['programs'][Path(program_path).stem] = {
                    'success': False,
                    'error': str(e)
                }
        
        # Gerar relatório consolidado
        results['consolidated_report'] = self._generate_traditional_consolidated_report(results['programs'])
        
        return results
    
    async def _analyze_demo(self, 
                          programs: List[str], 
                          copybooks_file: str,
                          output_dir: str,
                          extracted_content: Dict[str, Any] = None) -> Dict[str, Any]:
        """Executa análise de demonstração."""
        
        results = {
            'success': True,
            'method': 'demo_analysis',
            'programs': {},
            'consolidated_report': {}
        }
        
        # Análise simplificada para demonstração
        for program_path in programs:
            try:
                program_name = Path(program_path).stem
                self.logger.info(f"Analisando {program_name} em modo demonstração")
                
                # Ler código COBOL
                cobol_code = read_cobol_file(program_path)
                
                # Análise básica
                basic_analysis = self._perform_basic_analysis(cobol_code)
                
                # Gerar documentação híbrida se extração disponível
                if extracted_content and hasattr(self, 'hybrid_doc_generator'):
                    # Usar conteúdo extraído para demonstração
                    documentation = self.hybrid_doc_generator.generate_documentation(
                        extracted_content, 'executive', 'markdown'
                    )
                else:
                    # Documentação simples
                    documentation = self._generate_demo_documentation(program_name, basic_analysis)
                
                results['programs'][program_name] = {
                    'success': True,
                    'documentation': documentation,
                    'analysis': basic_analysis
                }
                
                # Salvar resultados se solicitado
                if output_dir:
                    await self._save_demo_results(output_dir, program_name, documentation)
                    
            except Exception as e:
                self.logger.error(f"Erro ao analisar {program_path}: {str(e)}")
                results['programs'][Path(program_path).stem] = {
                    'success': False,
                    'error': str(e)
                }
        
        # Relatório consolidado simples
        results['consolidated_report'] = self._generate_demo_consolidated_report(results['programs'])
        
        return results
    
    def _convert_results_for_validator(self, parallel_results: Dict) -> Dict:
        """Converte resultados para formato esperado pelo validador."""
        
        analysis_results = {}
        for ai_name, result_dict in parallel_results.items():
            class MockResult:
                def __init__(self, data):
                    self.success = data.get('success', False)
                    self.analysis = data.get('analysis', {})
                    self.confidence = data.get('confidence', 0.0)
            
            analysis_results[ai_name] = MockResult(result_dict)
        
        return analysis_results
    
    def _generate_consolidated_documentation(self, orchestration_result, validation_result, target_audience):
        """Gera documentação consolidada Multi-IA."""
        
        parallel_results = orchestration_result.get('parallel_results', {})
        successful_analyses = {
            k: v for k, v in parallel_results.items() 
            if v.get('success', False)
        }
        
        return {
            'executive_summary': f"Análise Multi-IA com {len(successful_analyses)} IAs especializadas",
            'detailed_analysis': {
                'structural': successful_analyses.get('structural', {}).get('analysis', {}),
                'business': successful_analyses.get('business', {}).get('analysis', {}),
                'technical': successful_analyses.get('technical', {}).get('analysis', {}),
                'quality': successful_analyses.get('quality', {}).get('analysis', {})
            },
            'validation_summary': {
                'consensus_achieved': validation_result.overall_confidence > 0.75,
                'confidence_level': validation_result.overall_confidence,
                'conflicts_resolved': len(validation_result.resolved_conflicts)
            },
            'recommendations': [
                'Análise Multi-IA concluída com sucesso',
                'Validação cruzada aplicada',
                'Documentação otimizada para audiência específica'
            ]
        }
    
    def _refine_documentation(self, documentation, clarity_metrics, target_audience):
        """Refina documentação para melhor clareza."""
        
        improvements = self.clarity_engine.get_improvement_recommendations(clarity_metrics)
        
        # Verificar se documentation é string ou dict
        if isinstance(documentation, str):
            # Se for string, criar dict com a documentação
            refined_doc = {
                'content': documentation,
                'clarity_improvements': {
                    'applied_improvements': improvements,
                    'original_score': getattr(clarity_metrics, 'overall_clarity_score', 0.8),
                    'target_audience': target_audience
                }
            }
            return refined_doc
        else:
            # Se for dict, adicionar melhorias
            documentation['clarity_improvements'] = {
                'applied_improvements': improvements,
                'original_score': getattr(clarity_metrics, 'overall_clarity_score', 0.8),
                'target_audience': target_audience
            }
            return documentation
    
    def _generate_fallback_documentation(self, program_name: str, cobol_code: str, 
                                       extracted_content: Dict[str, Any], 
                                       target_audience: str) -> str:
        """Gera documentação baseada apenas no conteúdo real quando IA falha."""
        
        # Buscar informações do programa no conteúdo extraído
        program_info = {}
        if extracted_content and 'programs' in extracted_content:
            for prog in extracted_content['programs']:
                if prog.get('name') == program_name:
                    program_info = prog
                    break
        
        # Análise básica do código COBOL
        basic_analysis = self._perform_basic_analysis(cobol_code)
        
        # Gerar documentação rica baseada no conteúdo real
        doc_parts = []
        
        # Cabeçalho
        doc_parts.extend([
            f"# Documentação do Sistema COBOL: {program_name}",
            "",
            f"**Data de Geração:** {datetime.now().strftime('%d/%m/%Y %H:%M')}",
            f"**Método:** Análise baseada em conteúdo real extraído",
            f"**Audiência:** {target_audience.title()}",
            ""
        ])
        
        # Resumo Executivo baseado em informações reais
        doc_parts.extend([
            "## Resumo Executivo",
            ""
        ])
        
        if program_info.get('objective'):
            doc_parts.extend([
                f"**Objetivo:** {program_info['objective']}",
                ""
            ])
        
        if program_info.get('author'):
            doc_parts.extend([
                f"**Autor:** {program_info['author']}",
                ""
            ])
        
        if program_info.get('version_history'):
            doc_parts.extend([
                "**Histórico de Versões:**",
                ""
            ])
            for version in program_info['version_history'][:3]:  # Limitar a 3 versões
                doc_parts.append(f"- {version}")
            doc_parts.append("")
        
        # Análise Técnica
        doc_parts.extend([
            "## Análise Técnica",
            "",
            f"**Linhas de Código:** {basic_analysis['lines_of_code']}",
            f"**Divisões COBOL:** {', '.join(basic_analysis['divisions'])}",
            f"**Seções Identificadas:** {len(basic_analysis['sections'])}",
            f"**Campos de Dados:** {basic_analysis['data_fields']}",
            ""
        ])
        
        # Arquivos de Entrada/Saída (se disponível)
        if program_info.get('input_files') or program_info.get('output_files'):
            doc_parts.extend([
                "## Arquivos Processados",
                ""
            ])
            
            if program_info.get('input_files'):
                doc_parts.extend([
                    "**Arquivos de Entrada:**",
                    ""
                ])
                for file_info in program_info['input_files']:
                    doc_parts.append(f"- {file_info}")
                doc_parts.append("")
            
            if program_info.get('output_files'):
                doc_parts.extend([
                    "**Arquivos de Saída:**",
                    ""
                ])
                for file_info in program_info['output_files']:
                    doc_parts.append(f"- {file_info}")
                doc_parts.append("")
        
        # Regras de Negócio (se disponível)
        if program_info.get('business_rules'):
            doc_parts.extend([
                "## Regras de Negócio Identificadas",
                ""
            ])
            for rule in program_info['business_rules']:
                doc_parts.append(f"- {rule}")
            doc_parts.append("")
        
        # Estrutura do Código
        if basic_analysis['sections']:
            doc_parts.extend([
                "## Estrutura do Programa",
                ""
            ])
            for section in basic_analysis['sections']:
                doc_parts.append(f"- **{section}**")
            doc_parts.append("")
        
        # Recomendações baseadas na análise real
        doc_parts.extend([
            "## Recomendações para Modernização",
            "",
            "### Baseado na Análise do Conteúdo Real:",
            "",
            f"- **Complexidade:** {'Alta' if basic_analysis['lines_of_code'] > 500 else 'Média' if basic_analysis['lines_of_code'] > 200 else 'Baixa'}",
            f"- **Estrutura:** {'Bem organizada' if len(basic_analysis['divisions']) >= 3 else 'Necessita reorganização'}",
            f"- **Manutenibilidade:** {'Boa' if program_info.get('author') else 'Verificar documentação'}",
            ""
        ])
        
        if program_info.get('version_history'):
            doc_parts.extend([
                "- **Histórico:** Sistema com evolução documentada, facilitando migração",
                ""
            ])
        
        # Rodapé
        doc_parts.extend([
            "---",
            f"*Documentação gerada automaticamente baseada em conteúdo real extraído*",
            f"*Programa: {program_name} | Sistema de Análise COBOL v1.0.0*"
        ])
        
        return "\n".join(doc_parts)
    
    def _perform_basic_analysis(self, cobol_code: str) -> Dict[str, Any]:
        """Realiza análise básica do código COBOL."""
        
        lines = cobol_code.split('\n')
        
        # Contar linhas não vazias
        lines_of_code = len([line for line in lines if line.strip() and not line.strip().startswith('*')])
        
        # Identificar divisões
        divisions = []
        for line in lines:
            line_upper = line.upper().strip()
            if 'DIVISION' in line_upper:
                if 'IDENTIFICATION' in line_upper:
                    divisions.append('IDENTIFICATION DIVISION')
                elif 'ENVIRONMENT' in line_upper:
                    divisions.append('ENVIRONMENT DIVISION')
                elif 'DATA' in line_upper:
                    divisions.append('DATA DIVISION')
                elif 'PROCEDURE' in line_upper:
                    divisions.append('PROCEDURE DIVISION')
        
        # Identificar seções
        sections = []
        for line in lines:
            line_upper = line.upper().strip()
            if 'SECTION' in line_upper:
                sections.append(line.strip())
        
        # Contar campos de dados (aproximação)
        data_fields = 0
        for line in lines:
            line_stripped = line.strip()
            if (line_stripped.startswith('01 ') or line_stripped.startswith('05 ') or 
                line_stripped.startswith('10 ') or line_stripped.startswith('15 ')):
                data_fields += 1
        
        return {
            'lines_of_code': lines_of_code,
            'divisions': divisions,
            'sections': sections,
            'data_fields': data_fields
        }
    
    async def _save_fallback_results(self, output_dir: str, program_name: str, documentation: str):
        """Salva resultados de fallback baseados em conteúdo real."""
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Salvar documentação principal
        doc_file = os.path.join(output_dir, f"{program_name}_FALLBACK_ANALYSIS.md")
        with open(doc_file, 'w', encoding='utf-8') as f:
            f.write(documentation)
        
        # Salvar metadados
        metadata = {
            'program_name': program_name,
            'analysis_method': 'fallback_real_content',
            'generation_time': datetime.now().isoformat(),
            'content_source': 'extracted_real_content',
            'ai_status': 'failed_fallback_applied',
            'documentation_quality': 'based_on_real_content'
        }
        
        metadata_file = os.path.join(output_dir, f"{program_name}_fallback_metadata.json")
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dumps(metadata, f, indent=2, ensure_ascii=False)
    
    def _override_provider(self, provider_name: str):
        """Sobrescreve configuração para usar provider específico."""
        if hasattr(self, 'config') and self.config:
            # Atualizar configuração para usar provider específico
            self.config['ai']['primary_provider'] = provider_name
            self.config['ai']['fallback_providers'] = [provider_name]
            
            # Reinicializar componentes se necessário
            if hasattr(self, 'multi_ai_orchestrator'):
                self.multi_ai_orchestrator.config = self.config
    
    def _perform_basic_analysis(self, cobol_code: str) -> Dict[str, Any]:
        """Executa análise básica para modo demo."""
        
        lines = cobol_code.split('\n')
        
        return {
            'line_count': len(lines),
            'divisions_found': [
                'IDENTIFICATION' if 'IDENTIFICATION DIVISION' in cobol_code else None,
                'ENVIRONMENT' if 'ENVIRONMENT DIVISION' in cobol_code else None,
                'DATA' if 'DATA DIVISION' in cobol_code else None,
                'PROCEDURE' if 'PROCEDURE DIVISION' in cobol_code else None
            ],
            'complexity': 'medium' if len(lines) > 100 else 'low',
            'has_files': 'SELECT' in cobol_code.upper(),
            'has_database': 'EXEC SQL' in cobol_code.upper()
        }
    
    def _generate_demo_documentation(self, program_name: str, analysis: Dict) -> Dict[str, Any]:
        """Gera documentação simples para demo."""
        
        return {
            'program_name': program_name,
            'summary': f"Programa COBOL com {analysis['line_count']} linhas",
            'structure': {
                'divisions': [d for d in analysis['divisions_found'] if d],
                'complexity': analysis['complexity']
            },
            'features': {
                'file_processing': analysis['has_files'],
                'database_access': analysis['has_database']
            },
            'recommendations': [
                'Análise básica concluída',
                'Para análise detalhada, use modo Multi-IA ou tradicional'
            ]
        }
    
    async def _save_multi_ai_results(self, output_dir, program_name, documentation, 
                                   orchestration_result, validation_result, clarity_metrics):
        """Salva resultados Multi-IA."""
        
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Documentação principal
        doc_file = output_path / f"{program_name}_MULTI_AI_ANALYSIS.md"
        with open(doc_file, 'w', encoding='utf-8') as f:
            f.write(self._format_multi_ai_documentation(documentation))
        
        # Dados técnicos
        technical_file = output_path / f"{program_name}_technical_data.json"
        technical_data = {
            'orchestration_result': orchestration_result,
            'validation_result': validation_result.__dict__,
            'clarity_metrics': clarity_metrics.__dict__
        }
        
        with open(technical_file, 'w', encoding='utf-8') as f:
            json.dump(technical_data, f, indent=2, ensure_ascii=False)
    
    async def _save_traditional_results(self, output_dir, program_name, documentation, 
                                      structure_analysis, business_analysis):
        """Salva resultados tradicionais."""
        
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        doc_file = output_path / f"{program_name}_TRADITIONAL_ANALYSIS.md"
        with open(doc_file, 'w', encoding='utf-8') as f:
            f.write(self._format_traditional_documentation(documentation))
    
    async def _save_demo_results(self, output_dir, program_name, documentation):
        """Salva resultados de demonstração."""
        
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        doc_file = output_path / f"{program_name}_DEMO_ANALYSIS.md"
        with open(doc_file, 'w', encoding='utf-8') as f:
            f.write(self._format_demo_documentation(documentation))
    
    def _format_multi_ai_documentation(self, documentation: Dict) -> str:
        """Formata documentação Multi-IA como Markdown."""
        
        return f"""# Análise Multi-IA do Sistema COBOL

## Resumo Executivo
{documentation.get('executive_summary', '')}

## Análise Detalhada por Domínio

### Análise Estrutural
{json.dumps(documentation.get('detailed_analysis', {}).get('structural', {}), indent=2)}

### Análise de Negócio
{json.dumps(documentation.get('detailed_analysis', {}).get('business', {}), indent=2)}

### Análise Técnica
{json.dumps(documentation.get('detailed_analysis', {}).get('technical', {}), indent=2)}

### Análise de Qualidade
{json.dumps(documentation.get('detailed_analysis', {}).get('quality', {}), indent=2)}

## Relatório de Validação
{json.dumps(documentation.get('validation_summary', {}), indent=2)}

## Recomendações
{chr(10).join(f"- {rec}" for rec in documentation.get('recommendations', []))}

---
*Análise gerada pelo Sistema de Análise COBOL Multi-IA v1.0.0*
"""
    
    def _format_traditional_documentation(self, documentation: Dict) -> str:
        """Formata documentação tradicional como Markdown."""
        
        return f"""# Análise Tradicional do Sistema COBOL

{json.dumps(documentation, indent=2, ensure_ascii=False)}

---
*Análise gerada pelo Sistema de Análise COBOL v1.0.0*
"""
    
    def _format_demo_documentation(self, documentation: Dict) -> str:
        """Formata documentação de demo como Markdown."""
        
        return f"""# Análise Demonstrativa do Sistema COBOL

## {documentation.get('program_name', 'Programa')}

### Resumo
{documentation.get('summary', '')}

### Estrutura
{json.dumps(documentation.get('structure', {}), indent=2)}

### Características
{json.dumps(documentation.get('features', {}), indent=2)}

### Recomendações
{chr(10).join(f"- {rec}" for rec in documentation.get('recommendations', []))}

---
*Análise demonstrativa gerada pelo Sistema de Análise COBOL v1.0.0*
"""
    
    def _generate_multi_ai_consolidated_report(self, programs_results: Dict) -> Dict:
        """Gera relatório consolidado Multi-IA."""
        
        successful = sum(1 for r in programs_results.values() if r.get('success'))
        total = len(programs_results)
        
        avg_confidence = 0
        avg_clarity = 0
        standards_met = 0
        
        for result in programs_results.values():
            if result.get('success'):
                avg_confidence += result.get('validation_confidence', 0)
                avg_clarity += result.get('clarity_score', 0)
                if result.get('meets_standards'):
                    standards_met += 1
        
        if successful > 0:
            avg_confidence /= successful
            avg_clarity /= successful
        
        return {
            'total_programs': total,
            'successful_analyses': successful,
            'success_rate': successful / total if total > 0 else 0,
            'average_validation_confidence': avg_confidence,
            'average_clarity_score': avg_clarity,
            'programs_meeting_standards': standards_met,
            'quality_assessment': 'Excellent' if avg_clarity > 0.9 else 'Good' if avg_clarity > 0.7 else 'Acceptable'
        }
    
    def _generate_traditional_consolidated_report(self, programs_results: Dict) -> Dict:
        """Gera relatório consolidado tradicional."""
        
        successful = sum(1 for r in programs_results.values() if r.get('success'))
        total = len(programs_results)
        
        return {
            'total_programs': total,
            'successful_analyses': successful,
            'success_rate': successful / total if total > 0 else 0,
            'analysis_method': 'traditional',
            'quality_assessment': 'Standard analysis completed'
        }
    
    def _generate_demo_consolidated_report(self, programs_results: Dict) -> Dict:
        """Gera relatório consolidado de demonstração."""
        
        successful = sum(1 for r in programs_results.values() if r.get('success'))
        total = len(programs_results)
        
        return {
            'total_programs': total,
            'successful_analyses': successful,
            'success_rate': successful / total if total > 0 else 0,
            'analysis_method': 'demonstration',
            'note': 'Para análise completa, use modo Multi-IA ou tradicional'
        }


async def main():
    """Função principal unificada."""
    
    parser = argparse.ArgumentParser(
        description='Sistema de Análise COBOL v1.0.0 - Script Unificado',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:

  # Análise Multi-IA (recomendado)
  python main.py programa.cbl --mode multi_ai --audience technical

  # Análise tradicional
  python main.py fontes.txt books.txt --mode traditional

  # Modo automático (detecta melhor opção)
  python main.py programa.cbl --copybooks books.txt

  # Demonstração rápida
  python main.py programa.cbl --demo

  # Múltiplos programas
  python main.py lista_programas.txt --output resultados/
""")
    
    # Comando especial de status
    parser.add_argument('--status', action='store_true',
                       help='Verificar status dos providers e componentes do sistema')
    
    # Argumentos obrigatórios (opcionais se --status)
    parser.add_argument('input_files', nargs='*',
                       help='Arquivo(s) COBOL ou arquivo com lista de programas')
    
    # Argumentos opcionais
    parser.add_argument('--copybooks', '-b',
                       help='Arquivo de copybooks')
    parser.add_argument('--output', '-o', default='analysis_results',
                       help='Diretório de saída (padrão: analysis_results)')
    parser.add_argument('--mode', '-m', 
                       choices=['auto', 'multi_ai', 'traditional'],
                       default='auto',
                       help='Modo de análise (padrão: auto)')
    
    # Opções Multi-IA
    parser.add_argument('--audience', 
                       choices=['executive', 'technical', 'business', 'implementation', 'combined'],
                       default='combined',
                       help='Audiência alvo para Multi-IA (padrão: combined - technical + implementation)')
    parser.add_argument('--provider', 
                       choices=['openai', 'copilot', 'luzia', 'enhanced_mock', 'mock'],
                       help='Provider específico para teste (sobrescreve configuração)')
    
    # Opções gerais
    parser.add_argument('--config', '-c', 
                       help='Arquivo de configuração personalizado')
    parser.add_argument('--demo', action='store_true',
                       help='Modo demonstração (limita a 3 programas)')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='Logging detalhado')
    parser.add_argument('--quiet', '-q', action='store_true',
                       help='Saída mínima')
    
    args = parser.parse_args()
    
    # Verificar comando de status
    if args.status:
        from src.utils.status_checker import SystemStatusChecker
        checker = SystemStatusChecker()
        status = checker.check_all_status()
        report = checker.format_status_report(status)
        print(report)
        return 0 if status['overall']['ready_for_production'] else 1
    
    # Validar argumentos para análise
    if not args.input_files:
        parser.error("Arquivos de entrada são obrigatórios (use --status para verificar sistema)")
    
    # Configurar logging
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    elif args.quiet:
        logging.getLogger().setLevel(logging.WARNING)
    
    try:
        # Inicializar engine unificado
        engine = UnifiedAnalysisEngine(args.config, args.mode)
        
        # Aplicar provider específico se solicitado
        if args.provider:
            engine._override_provider(args.provider)
        
        # Executar análise
        result = await engine.analyze_programs(
            args.input_files,
            args.copybooks,
            args.output,
            args.audience,
            args.demo
        )
        
        # Exibir resultado
        if result['success']:
            if not args.quiet:
                print(f"\nAnálise concluída com sucesso!")
                print(f"Modo: {result['analysis_mode']}")
                print(f"Programas analisados: {result['programs_analyzed']}")
                print(f"Tempo total: {result['total_execution_time']:.2f}s")
                
                # Mostrar métricas específicas do modo
                consolidated = result.get('consolidated_report', {})
                if 'average_validation_confidence' in consolidated:
                    print(f"Confiança média: {consolidated['average_validation_confidence']:.1%}")
                    print(f"Clareza média: {consolidated['average_clarity_score']:.1%}")
                
                print(f"Resultados salvos em: {args.output}")
        else:
            print(f"\nErro na análise: {result.get('error', 'Erro desconhecido')}")
            return 1
        
        return 0
        
    except KeyboardInterrupt:
        print("\nAnálise interrompida pelo usuário")
        return 1
    except Exception as e:
        print(f"Erro fatal: {str(e)}")
        return 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
