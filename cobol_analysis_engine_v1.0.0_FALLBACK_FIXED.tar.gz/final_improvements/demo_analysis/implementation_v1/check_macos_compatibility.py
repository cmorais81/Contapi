#!/usr/bin/env python3
"""
Sistema de Análise COBOL v15.0 - macOS Compatibility Checker
Verifica se o sistema macOS está pronto para executar o Sistema de Análise COBOL
"""

import sys
import platform
import subprocess
import importlib
import os
from pathlib import Path

def check_macos_compatibility():
    """Verifica compatibilidade completa com macOS."""
    
    print("🍎 Sistema de Análise COBOL v15.0 - Verificação de Compatibilidade macOS")
    print("=" * 65)
    
    issues = []
    warnings = []
    
    # 1. Verificar se está no macOS
    print("\n1. 🖥️  Verificando Sistema Operacional...")
    if platform.system() != "Darwin":
        issues.append(" Sistema não é macOS")
        print(f"    Sistema detectado: {platform.system()}")
        print("    Este pacote é específico para macOS")
    else:
        macos_version = platform.mac_ver()[0]
        print(f"    macOS {macos_version}")
        
        # Verificar versão mínima (macOS 12.0+)
        version_parts = macos_version.split('.')
        major_version = int(version_parts[0])
        if major_version < 12:
            warnings.append(f"⚠️ macOS {macos_version} pode ter problemas. Recomendado: 12.0+")
    
    # 2. Verificar arquitetura (Intel vs Apple Silicon)
    print("\n2.  Verificando Arquitetura...")
    arch = platform.machine()
    if arch == "arm64":
        print("    Apple Silicon (M1/M2/M3) - Nativo ARM64")
    elif arch == "x86_64":
        print("    Intel Mac - x86_64")
    else:
        warnings.append(f"⚠️ Arquitetura não testada: {arch}")
    
    # 3. Verificar Python
    print("\n3. 🐍 Verificando Python...")
    python_version = sys.version_info
    print(f"   📍 Versão atual: {python_version.major}.{python_version.minor}.{python_version.micro}")
    
    if python_version.major != 3:
        issues.append(" Python 3 requerido")
    elif python_version.minor < 11:
        issues.append(f" Python 3.11+ requerido. Atual: {python_version.major}.{python_version.minor}")
        print("    Instalar: brew install python@3.11")
    else:
        print("    Versão compatível")
    
    # 4. Verificar pip
    print("\n4.  Verificando pip...")
    try:
        import pip
        pip_version = pip.__version__
        print(f"    pip {pip_version} disponível")
    except ImportError:
        issues.append(" pip não encontrado")
        print("    Instalar: curl https://bootstrap.pypa.io/get-pip.py | python3")
    
    # 5. Verificar dependências principais
    print("\n5.  Verificando Dependências Principais...")
    
    required_packages = {
        'yaml': 'PyYAML',
        'requests': 'requests',
        'pandas': 'pandas',
        'numpy': 'numpy',
        'bs4': 'beautifulsoup4'
    }
    
    missing_packages = []
    
    for module, package in required_packages.items():
        try:
            importlib.import_module(module)
            print(f"    {package}")
        except ImportError:
            missing_packages.append(package)
            print(f"    {package}")
    
    if missing_packages:
        warnings.append(f"⚠️ Pacotes faltando: {', '.join(missing_packages)}")
        print(f"    Instalar: pip install {' '.join(missing_packages)}")
    
    # 6. Verificar encoding
    print("\n6. 🔤 Verificando Encoding...")
    encoding = sys.getdefaultencoding()
    if encoding.lower() in ['utf-8', 'utf8']:
        print(f"    Encoding: {encoding}")
    else:
        warnings.append(f"⚠️ Encoding pode causar problemas: {encoding}")
        print("    Configurar: export PYTHONIOENCODING=utf-8")
    
    # 7. Verificar espaço em disco
    print("\n7. 💾 Verificando Espaço em Disco...")
    try:
        statvfs = os.statvfs('.')
        free_space_gb = (statvfs.f_frsize * statvfs.f_bavail) / (1024**3)
        print(f"   📍 Espaço livre: {free_space_gb:.1f} GB")
        
        if free_space_gb < 1:
            warnings.append("⚠️ Pouco espaço em disco (<1GB)")
        elif free_space_gb < 0.5:
            issues.append(" Espaço insuficiente (<500MB)")
        else:
            print("    Espaço suficiente")
    except:
        warnings.append("⚠️ Não foi possível verificar espaço em disco")
    
    # 8. Verificar Homebrew (opcional mas recomendado)
    print("\n8. 🍺 Verificando Homebrew...")
    try:
        result = subprocess.run(['brew', '--version'], 
                              capture_output=True, text=True, timeout=5)
        if result.returncode == 0:
            brew_version = result.stdout.split('\n')[0]
            print(f"    {brew_version}")
        else:
            warnings.append("⚠️ Homebrew não funciona corretamente")
    except (subprocess.TimeoutExpired, FileNotFoundError):
        warnings.append("⚠️ Homebrew não encontrado")
        print("    Instalar: /bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\"")
    
    # 9. Verificar arquivos do projeto
    print("\n9. 📁 Verificando Arquivos do Projeto...")
    
    required_files = [
        'main_v15_demo.py',
        'main_v15_universal_functional.py',
        'requirements_macos.txt',
        'install_macos.sh',
        'config/config.yaml',
        'src/analyzers',
        'examples/fontes.txt'
    ]
    
    missing_files = []
    for file_path in required_files:
        if Path(file_path).exists():
            print(f"    {file_path}")
        else:
            missing_files.append(file_path)
            print(f"    {file_path}")
    
    if missing_files:
        issues.append(f" Arquivos faltando: {', '.join(missing_files)}")
    
    # 10. Teste de importação dos módulos principais
    print("\n10. 🧪 Testando Importações Principais...")
    
    sys.path.insert(0, 'src')
    
    test_modules = [
        'analyzers.universal_structure_analyzer',
        'generators.universal_functional_documentation_generator',
        'parsers.multi_program_cobol_parser'
    ]
    
    for module in test_modules:
        try:
            importlib.import_module(module)
            print(f"    {module}")
        except ImportError as e:
            issues.append(f" Erro ao importar {module}: {e}")
            print(f"    {module}")
    
    # Resumo final
    print("\n" + "=" * 65)
    print(" RESUMO DA VERIFICAÇÃO")
    print("=" * 65)
    
    if not issues and not warnings:
        print(" PERFEITO! Sistema 100% compatível com Sistema de Análise COBOL v15.0")
        print("\n Próximos passos:")
        print("   1. ./install_macos.sh")
        print("   2. source venv/bin/activate")
        print("   3. python main_v15_demo.py")
        return True
    
    elif not issues:
        print("👍 BOM! Sistema compatível com pequenos avisos")
        print(f"\n⚠️ Avisos ({len(warnings)}):")
        for warning in warnings:
            print(f"   {warning}")
        print("\n Pode prosseguir com a instalação")
        return True
    
    else:
        print(" PROBLEMAS ENCONTRADOS! Corrigir antes de prosseguir")
        print(f"\n🚨 Problemas críticos ({len(issues)}):")
        for issue in issues:
            print(f"   {issue}")
        
        if warnings:
            print(f"\n⚠️ Avisos adicionais ({len(warnings)}):")
            for warning in warnings:
                print(f"   {warning}")
        
        print("\n Corrigir problemas e executar novamente:")
        print("   python check_macos_compatibility.py")
        return False


def main():
    """Função principal."""
    try:
        success = check_macos_compatibility()
        return 0 if success else 1
    except KeyboardInterrupt:
        print("\n\n⏹️ Verificação interrompida pelo usuário")
        return 1
    except Exception as e:
        print(f"\n\n Erro inesperado: {e}")
        return 1


if __name__ == "__main__":
    exit(main())
