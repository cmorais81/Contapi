# Documentação de Sistemas COBOL - Análise Real Content Only

**Data de Geração:** 19/09/2025 14:26
**Audiência:** Technical
**Programas Analisados:** 5
**Copybooks Analisados:** 11
**Método de Análise:** Conteúdo Real Extraído
**Qualidade do Conteúdo:** High

## Resumo Executivo

Análise técnica detalhada de **5 programas COBOL** e **11 copybooks** 
extraídos dos arquivos fontes.txt e BOOKS.txt. O sistema identificou estruturas complexas 
relacionadas ao processamento de dados do Banco Central.

### Características Técnicas:

- **Linguagem:** COBOL (COBOL-85/2002/2014)
- **Ambiente:** Mainframe IBM
- **Divisões COBOL:** IDENTIFICATION, PROCEDURE, ENVIRONMENT, DATA
- **Tipos de Arquivo:** {'input': 11, 'output': 8, 'work': 0}

## Programas Analisados

### 1. LHAN0542

**Objetivo:** PARTICIONAR ARQUIVO BACEN DOC3040 SERAO GERADOS ARQUIVOS PARTICIONADOS DINAMICAMENTE COM RESPECTIVOS ARQUIVOS BASTOES P/ TRANSMISSAO VERSAO*   DATA   *  AUTOR   *            MOTIVO 01  * 11/01/11 * EDIVALDO * NOVO

**Autor:** EDIVALDO-DEDIC/GPTI.
**Data de Criação:** 11/01/11.

**Arquivos Utilizados:**
- `LHS542E1` (input): Arquivo input do sistema
- `LHS542E2` (input): Arquivo input do sistema
- `LHS542E3` (input): Arquivo input do sistema
- `LHS542E4` (input): Arquivo input do sistema
- `LHS542E5` (input): Arquivo input do sistema
- `LHS542S1` (output): Arquivo output do sistema
- `LHS542S2` (output): Arquivo output do sistema
- `LHS542S3` (output): Arquivo output do sistema

**Histórico de Versões:**
- **v01** (11/01/11) por EDIVALDO: NOVO
- **v02** (27/01/14) por MARCELLO: - PARTICIONAMENTO 4000 MB
- **v03** (15/09/15) por ROBERTO: PROJETO DADOS RESPONSAVEL
- **v04** (06/01/25) por CABRAL: RES 4966 DO BACEN - PROD. JAN/25

---

### 2. LHAN0705

**Autor:** T520Q6S.
**Data de Criação:** AGOSTO/2013.

**Arquivos Utilizados:**
- `E1DQ0705` (input): Arquivo input do sistema
- `S1DQ0705` (output): Arquivo output do sistema
- `S2DQ0705` (output): Arquivo output do sistema
- `MZV5002E` (input): Arquivo input do sistema

---

### 3. LHAN0706

**Autor:** T520Q6S.
**Data de Criação:** AGOSTO/2013.

**Arquivos Utilizados:**
- `E1DQ0706` (input): Arquivo input do sistema
- `E2DQ0706` (input): Arquivo input do sistema
- `S1DQ0706` (output): Arquivo output do sistema
- `S2DQ0706` (output): Arquivo output do sistema

---

### 4. LHBR0700

**Autor:** MARCELLO KOJIMA - RESOURCE.
**Data de Criação:** 25/09/2014.

---

### 5. MZAN6056

**Data de Criação:** 03/02/2014.

**Arquivos Utilizados:**
- `E1DQ6056` (input): Arquivo input do sistema
- `E2DQ6056` (input): Arquivo input do sistema
- `S1DQ6056` (output): Arquivo output do sistema

---

## Estruturas de Dados (Copybooks)

### 1. LHCP3402

**Descrição:** Área das tabelas de consistências dos códigos do Banco Central

**Tabelas Definidas:**
- `TB-ANEXO-01` (nível 01)
- `TB-ANEXO-02` (nível 01)
- `TB-ANEXO-03` (nível 01)
- `TB-ANEXO-04` (nível 01)
- `TB-ANEXO-05` (nível 01)
- ... e mais 9 tabelas

**Campos Principais:**
- `TABELA-01` (nível 05)
- `FILLER` (nível 10) PIC X(
- `FILLER` (nível 10) PIC X(
- `FILLER` (nível 10) PIC X(
- `FILLER` (nível 10) PIC X(
- `FILLER` (nível 10) PIC X(
- `FILLER` (nível 10) PIC X(
- `FILLER` (nível 10) PIC X(
- `FILLER` (nível 10) PIC X(
- `FILLER` (nível 10) PIC X(
- ... e mais 302 campos

---

### 2. LHCE0700

**Campos Principais:**
- `LHCE0700-TX-OP1-TIPOSUBTIPO` (nível 05)
- `LHCE0700-TX-OP1-MODSUBMOD` (nível 05)
- `LHCE0700-TX-OP2-TIPOSUB` (nível 05)
- `LHCE0700-TX-OP2-NAT` (nível 05) PIC 9(
- `FILLER` (nível 05) PIC X(

---

### 3. LHCE0400

**Campos Principais:**
- `FILLER` (nível 05)
- `LHCE0400-NR-OPR-LY` (nível 10) PIC X(
- `LHCE0400-NR-OPR-BRANCOS` (nível 10) PIC X(
- `FILLER` (nível 10)
- `LHCE0400-NR-OPR` (nível 10) PIC 9(
- `LHCE0400-CH-ALTAIR` (nível 05)
- `LHCE0400-ENT-ALTAIR` (nível 10) PIC 9(
- `LHCE0400-OFC-ALTAIR` (nível 10) PIC 9(
- `LHCE0400-CTR-ALTAIR` (nível 10) PIC 9(
- `LHCE0400-ID-PRO-ALTAIR` (nível 10)
- ... e mais 132 campos

---

### 4. DRR00082

**Campos Principais:**
- `W82-VOLSER` (nível 05) PIC X(
- `W82-FIXO-VARIAVEL` (nível 05) PIC X(
- `W82-BLOCKED-UNBLOCKED` (nível 05) PIC X(
- `W82-ASA-MACHINE` (nível 05) PIC X(

---

### 5. LHCE0430

**Campos Principais:**
- `LHCE0430-TP-REG` (nível 05) PIC 9(
- `LHCE0430-DT-BSE` (nível 05) PIC 9(
- `LHCE0430-CD-ITF` (nível 05) PIC X(
- `LHCE0430-CD-CIC` (nível 05) PIC 9(
- `LHCE0430-NR-OPR-X` (nível 05) PIC X(
- `LHCE0430-CD-MOD-CTR` (nível 05) PIC 9(

---

### 6. MZTC5001

**Campos Principais:**
- `MZ5001-TABELA` (nível 05) PIC X(
- `MZ5001-ENTIDADE` (nível 05) PIC 9(
- `MZ5001-TCCIDIOM` (nível 05) PIC X(
- `CHAVEH-5001` (nível 05)
- `DATA-BASE-5002` (nível 05) PIC 9(
- `INDIC-PROC-5002` (nível 05) PIC 9(
- `CT-REG-5002` (nível 05) PIC 9(
- `DATA-BASE-ANT-5002` (nível 05) PIC 9(
- `TP-PROC-5002` (nível 05) PIC X(
- `FILLER` (nível 05) PIC X(

---

### 7. MZCE6001

**Campos Principais:**
- `FILLER` (nível 05) PIC X(
- `ID-PRO-ALTAIR-6001` (nível 05) PIC X(
- `FILLER` (nível 05) PIC X(
- `GR-GAR-6001` (nível 05)
- `PC-PAG-ACD-6001-R` (nível 05) PIC 9(
- `PC-PAG-ACO-MES-ANT-6001-R` (nível 05) PIC 9(

---

### 8. MZCE5113

**Campos Principais:**
- `DATA-BASE-SS-MZ13` (nível 05) PIC 9(
- `DATA-BASE-AA-MZ13` (nível 05) PIC 9(
- `DATA-BASE-MM-MZ13` (nível 05) PIC 9(

---

### 9. MZTCM530

**Tabelas Definidas:**
- `MZTCM530` (nível 01)

**Campos Principais:**
- `MZM530-CHAVE` (nível 05)
- `MZM530-TABELA` (nível 10) PIC X(
- `MZM530-ENTIDADE` (nível 10) PIC 9(
- `MZM530-CHAVTAB` (nível 10)
- `MZM530-DADOS` (nível 05)
- `MZM530-NOME-RESP` (nível 10) PIC X(
- `MZM530-EMAIL-RESP` (nível 10) PIC X(
- `MZM530-FONE-RESP` (nível 10) PIC X(
- `FILLER` (nível 10) PIC X(

---

### 10. MZTCL000

**Tabelas Definidas:**
- `MZTCL000` (nível 01)

**Campos Principais:**
- `MZL0-ENTRADA` (nível 05)
- `MZL0-TIPOACC` (nível 10) PIC X(
- `MZL0-SAIDA` (nível 05)
- `MZL0-CDRETORN` (nível 10) PIC X(
- `MZL0-DB2-LOG` (nível 10)
- `MZL0-MZDT001` (nível 05)
- `MZL0-TABELA` (nível 10)
- `MZL0-ENTIDAD` (nível 10) PIC X(
- `MZL0-IDIOMA` (nível 10) PIC X(
- `MZL0-CHAVE` (nível 10) PIC X(
- ... e mais 1 campos

---

### 11. MZTCL040

**Tabelas Definidas:**
- `MZTCL040` (nível 01)

**Campos Principais:**
- `MZL4-ENTRADA` (nível 05)
- `MZL4-TIPOACC` (nível 10) PIC X(
- `MZL4-SAIDA` (nível 05)
- `MZL4-CDRETORN` (nível 10) PIC X(
- `MZL4-DB2-LOG` (nível 10)
- `MZL4-MZDT001` (nível 05)
- `MZL4-TABELA` (nível 10) PIC X(
- `MZL4-ENTIDAD` (nível 10) PIC X(
- `MZL4-IDIOMA` (nível 10) PIC X(
- `MZL4-CHAVE` (nível 10) PIC X(
- ... e mais 1 campos

---

## Análise Técnica Consolidada

### Características do Sistema

**Linguagem:** COBOL (COBOL-85/2002/2014)
**Ambiente:** Mainframe IBM
**Domínio:** Sistema Bancário - Banco Central do Brasil
**Total de Programas:** 5
**Total de Copybooks:** 11

### Distribuição de Arquivos

- **Arquivos de Entrada:** 11
- **Arquivos de Saída:** 8
- **Arquivos de Trabalho:** 0

### Indicadores de Complexidade

- **Programas com Histórico de Versões:** 1
- **Programas com Múltiplos Arquivos:** 4
- **Programas com Procedures:** 0

## Regras de Negócio Identificadas

### Objetivos dos Sistemas

**LHAN0542:** PARTICIONAR ARQUIVO BACEN DOC3040 SERAO GERADOS ARQUIVOS PARTICIONADOS DINAMICAMENTE COM RESPECTIVOS ARQUIVOS BASTOES P/ TRANSMISSAO VERSAO*   DATA   *  AUTOR   *            MOTIVO 01  * 11/01/11 * EDIVALDO * NOVO

### Lógica de Negócio

- PARTICIONAR ARQUIVO BACEN DOC3040                          ** *(Fonte: LHAN0542)*
- SERAO GERADOS ARQUIVOS PARTICIONADOS DINAMICAMENTE         ** *(Fonte: LHAN0542)*
- 02  * 27/01/14 * MARCELLO * - PARTICIONAMENTO 4000 MB      ** *(Fonte: LHAN0542)*
- 04  * 06/01/25 *  CABRAL  * RES 4966 DO BACEN - PROD. JAN/25* *(Fonte: LHAN0542)*
- --- GRAVA POR PARTE O LIMITE CALCULADO NA SECAO 1-INICIO, MAIS *(Fonte: LHAN0542)*
- --- SE NAO FOR FIM DA ENTRADA E2, TESTA SE ALCANCOU LIMITES DE *(Fonte: LHAN0542)*
- OBJETIVO:  VALIDACAO FISICA E LOGICA DE ARQUIVO        * *(Fonte: LHAN0705)*
- 03/21 - RECOMNPILACAO BOOK - LIMITES                          * *(Fonte: LHAN0705)*
- ARQUIVO DE OPERACOES MARCADAS COMPULSORIO - APOS VALIDACAO *(Fonte: LHAN0705)*
- --- AREA PARA DRAM0152 - VALIDACAO DE DATA *(Fonte: LHAN0705)*
- ... e mais 34 regras identificadas

## Recomendações

### Recomendações Técnicas

1. **Análise de Dependências:** Mapear relacionamentos entre programas e copybooks
2. **Testes Abrangentes:** Validar cálculos e processamentos críticos do BACEN
3. **Migração de Dados:** Preservar estruturas de dados complexas identificadas
4. **Performance:** Otimizar processamento de arquivos grandes (particionamento)
5. **Integração:** Planejar interfaces com sistemas modernos

---

*Documentação gerada pelo Sistema de Análise COBOL v1.0.0*
*Método: Real Content Only*
*Qualidade: High (baseado em conteúdo real)*
