#!/usr/bin/env python3
"""
Sistema de Análise COBOL v1.0.0 - Demo Rápida
"""

import subprocess
import sys
import os

def run_demo():
    """Executa a demonstração principal."""
    print(" Iniciando demonstração rápida do Sistema de Análise COBOL v1.0.0...")
    
    # Verifica se os arquivos de exemplo existem
    fontes_file = "examples/fontes_teste.txt"
    if not os.path.exists(fontes_file):
        fontes_file = "examples/fontes.txt"
        print(f"⚠️ Usando {fontes_file} como arquivo de fontes")
    
    books_file = "examples/BOOKS.txt"
    if not os.path.exists(books_file):
        print(f" Arquivo de copybooks não encontrado: {books_file}")
        return 1
    
    try:
        # Comando para executar a análise principal em modo de demonstração
        command = [
            sys.executable, 
            "main.py", 
            fontes_file, 
            books_file,
            "--demo-mode",
            "--verbose"
        ]
        
        print(f"Executando: {' '.join(command)}")
        
        # Executa o processo e captura a saída em tempo real
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8')
        
        while True:
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                print(output.strip())
        
        rc = process.poll()
        if rc == 0:
            print("\n Demonstração concluída com sucesso!")
            print("Verifique os resultados no diretório 'functional_analysis_results_v15'")
        else:
            print(f"\n Erro na demonstração (código de saída: {rc})")
            
    except FileNotFoundError:
        print("Erro: 'main.py' não encontrado. Verifique se você está no diretório correto.")
    except Exception as e:
        print(f"Ocorreu um erro inesperado: {e}")

if __name__ == "__main__":
    run_demo()

