import logging
from typing import Dict, Any, List, Optional


class CostCalculator:
    """
    Calculadora de custos para consultas de IA.
    Suporta múltiplos modelos com preços diferenciados.
    """
    
    def __init__(self, api_costs: Optional[Dict[str, Dict[str, float]]] = None):
        """Inicializa a calculadora de custos.
        Args:
            api_costs: Dicionário de custos de API por modelo, se fornecido.
        """
        self.logger = logging.getLogger(__name__)
        
        # Documentação de custo https://confluence.santanderbr.corp/x/6sAdP
        self.MODEL_COSTS = {
            "azure-gpt-4o-mini": {"prompt": 0.2640, "completion": 1.0560},
            "azure-gpt-4o": {"prompt": 5.0000, "completion": 15.0000},
            "azure-o1-preview": {"prompt": 0.0165, "completion": 0.066},
            "azure-text-embedding-3-large": {"prompt": 0.00013, "completion": 0},
            "azure-text-embedding-3-small": {"prompt": 0.00002, "completion": 0},
            "dall-e-3": {"prompt": 0.0064, "completion": 0},    
            "aws-claude-3-5-sonnet": {"prompt": 3.0000, "completion": 15.0000},
            "aws-claude-3-haiku": {"prompt": 0.2500, "completion": 1.2500},
            "amazon-titan-embed-text-v2": {"prompt": 0.0008, "completion": 0},
            "amazon-titan-embed-image-v1": {"prompt": 0.00006, "completion": 0},
            "amazon-nova-micro-v1": {"prompt": 0.000035, "completion": 0.00014},
            "amazon-nova-lite-v1": {"prompt": 0.00006, "completion": 0.00024},
            "amazon-nova-pro-v1": {"prompt": 0.0008, "completion": 0.0032},
            # Modelos mock para testes
            "enhanced-mock-gpt-4": {"prompt": 0.0000, "completion": 0.0000},
            "basic-mock": {"prompt": 0.0000, "completion": 0.0000}
        }
        
        if api_costs:
            self.MODEL_COSTS.update(api_costs)

        # Tracking de custos
        self.total_costs = {}
        self.total_tokens = {}
        
    def tokens_analytics(self, response: Dict[str, Any], model: str) -> Dict[str, Any]:
        """ 
        Analyzes and calculates token information and costs for API calls.
        
        Args:
            response (Dict[str, Any]): API response containing usage information
            model (str): Model name used for the request
            
        Returns:
            Dict[str, Any]: Dictionary containing:
                - prompt_tokens (int): Total number of prompt tokens used
                - completion_tokens (int): Total number of completion tokens used  
                - total_tokens (int): Total number of tokens used
                - cost (float): Calculated cost for the API call
                - model (str): Model name used
        """
        # Extrair informações de uso da resposta
        usage_info = self._extract_usage_info(response)
        
        tokens_info = {
            "prompt_tokens": usage_info["prompt_tokens"],
            "completion_tokens": usage_info["completion_tokens"],
            "total_tokens": usage_info["total_tokens"],
            "model": model
        }
        
        # Calcular custo
        tokens_info["cost"] = self.calculate_cost(tokens_info, model)
        
        # Atualizar tracking
        self._update_tracking(model, tokens_info)
        
        self.logger.info(f"Modelo: {model} | Tokens: {tokens_info['total_tokens']} | Custo: ${tokens_info['cost']:.4f}")
        
        return tokens_info

    def _extract_usage_info(self, response: Dict[str, Any]) -> Dict[str, int]:
        """
        Extrai informações de uso de tokens da resposta da API.
        Implementa algoritmo baseado em entrada + saída conforme especificação.
        
        Args:
            response: Resposta da API
            
        Returns:
            Dict com informações de tokens (entrada + saída)
        """
        # Tentar extrair do metadata (formato LuzIA)
        if isinstance(response, dict):
            metadata = response.get("metadata", {})
            if "usage" in metadata:
                usage = metadata["usage"]
                if isinstance(usage, list) and len(usage) > 0:
                    usage_item = usage[0]
                    prompt_tokens = usage_item.get("prompt_tokens", 0)
                    completion_tokens = usage_item.get("completion_tokens", 0)
                    return {
                        "prompt_tokens": prompt_tokens,
                        "completion_tokens": completion_tokens,
                        "total_tokens": prompt_tokens + completion_tokens  # Entrada + Saída
                    }
            
            # Tentar formato direto de usage
            if "usage" in response:
                usage = response["usage"]
                if isinstance(usage, list):
                    prompt_total = sum(item.get("prompt_tokens", 0) for item in usage)
                    completion_total = sum(item.get("completion_tokens", 0) for item in usage)
                    return {
                        "prompt_tokens": prompt_total,
                        "completion_tokens": completion_total,
                        "total_tokens": prompt_total + completion_total  # Entrada + Saída
                    }
                elif isinstance(usage, dict):
                    prompt_tokens = usage.get("prompt_tokens", 0)
                    completion_tokens = usage.get("completion_tokens", 0)
                    return {
                        "prompt_tokens": prompt_tokens,
                        "completion_tokens": completion_tokens,
                        "total_tokens": prompt_tokens + completion_tokens  # Entrada + Saída
                    }
        
        # Fallback: estimar tokens baseado no tamanho da resposta
        if isinstance(response, dict) and "content" in response:
            content = str(response["content"])
            estimated_output_tokens = len(content.split()) * 1.3  # Estimativa: ~1.3 tokens por palavra
            return {
                "prompt_tokens": 0,
                "completion_tokens": int(estimated_output_tokens),
                "total_tokens": int(estimated_output_tokens)
            }
        
        # Fallback final
        return {
            "prompt_tokens": 0,
            "completion_tokens": 0,
            "total_tokens": 0
        }

    def calculate_cost(self, tokens: Dict[str, int], model: str) -> float:
        """
        Calculate the cost of using a specific AI model based on token usage.
        Implementa algoritmo baseado em tokens de entrada + saída.
        
        Args:
            tokens (Dict[str, int]): Dictionary containing token counts
            model (str): Name of the AI model used
            
        Returns:
            float: Total cost in USD (entrada + saída)
        """
        if model not in self.MODEL_COSTS:
            self.logger.warning(f"Modelo {model} não encontrado na tabela de custos. Custo = $0.00")
            return 0.0
        
        costs = self.MODEL_COSTS[model]
        
        # Cálculo baseado em entrada + saída (conforme especificação)
        prompt_cost = (tokens["prompt_tokens"] / 1000) * costs["prompt"]
        completion_cost = (tokens["completion_tokens"] / 1000) * costs["completion"]
        total_cost = prompt_cost + completion_cost
        
        # Log detalhado do cálculo
        self.logger.debug(f"Cálculo de custo para {model}:")
        self.logger.debug(f"  Tokens entrada: {tokens['prompt_tokens']} x ${costs['prompt']}/1k = ${prompt_cost:.4f}")
        self.logger.debug(f"  Tokens saída: {tokens['completion_tokens']} x ${costs['completion']}/1k = ${completion_cost:.4f}")
        self.logger.debug(f"  Total: ${total_cost:.4f}")
        
        return total_cost

    def _update_tracking(self, model: str, tokens_info: Dict[str, Any]) -> None:
        """
        Atualiza o tracking de custos e tokens por modelo.
        
        Args:
            model: Nome do modelo
            tokens_info: Informações de tokens e custo
        """
        if model not in self.total_costs:
            self.total_costs[model] = 0.0
            self.total_tokens[model] = {
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0,
                "requests": 0
            }
        
        self.total_costs[model] += tokens_info["cost"]
        self.total_tokens[model]["prompt_tokens"] += tokens_info["prompt_tokens"]
        self.total_tokens[model]["completion_tokens"] += tokens_info["completion_tokens"]
        self.total_tokens[model]["total_tokens"] += tokens_info["total_tokens"]
        self.total_tokens[model]["requests"] += 1

    def get_cost_summary(self) -> Dict[str, Any]:
        """
        Retorna um resumo completo dos custos.
        
        Returns:
            Dict com resumo de custos por modelo e total
        """
        total_cost = sum(self.total_costs.values())
        total_tokens_all = sum(tokens["total_tokens"] for tokens in self.total_tokens.values())
        total_requests = sum(tokens["requests"] for tokens in self.total_tokens.values())
        
        summary = {
            "total_cost": total_cost,
            "total_tokens": total_tokens_all,
            "total_requests": total_requests,
            "models": {}
        }
        
        for model in self.total_costs:
            summary["models"][model] = {
                "cost": self.total_costs[model],
                "tokens": self.total_tokens[model],
                "cost_per_token": self.total_costs[model] / max(self.total_tokens[model]["total_tokens"], 1)
            }
        
        return summary

    def format_cost_report(self) -> str:
        """
        Formata um relatório de custos legível.
        
        Returns:
            String com relatório formatado
        """
        summary = self.get_cost_summary()
        
        report = []
        report.append("=" * 60)
        report.append("RELATÓRIO DE CUSTOS - Análise COBOL")
        report.append("=" * 60)
        report.append("")
        
        # Resumo geral
        report.append(f"CUSTO TOTAL: ${summary['total_cost']:.4f}")
        report.append(f"TOKENS TOTAIS: {summary['total_tokens']:,}")
        report.append(f"REQUISIÇÕES TOTAIS: {summary['total_requests']}")
        report.append("")
        
        # Detalhes por modelo
        report.append("DETALHES POR MODELO:")
        report.append("-" * 40)
        
        for model, data in summary["models"].items():
            report.append(f"Modelo: {model}")
            report.append(f"  Custo: ${data['cost']:.4f}")
            report.append(f"  Tokens: {data['tokens']['total_tokens']:,}")
            report.append(f"  Requisições: {data['requests']}")
            report.append(f"  Custo/Token: ${data['cost_per_token']:.6f}")
            report.append("")
        
        return "\n".join(report)

    def reset_tracking(self) -> None:
        """
        Reset do tracking de custos.
        """
        self.total_costs.clear()
        self.total_tokens.clear()

