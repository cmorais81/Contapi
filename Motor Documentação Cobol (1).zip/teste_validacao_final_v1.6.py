#!/usr/bin/env python3
"""
Teste de Validação Final - COBOL AI Engine v1.6.0
Valida TODAS as funcionalidades e garante que as perguntas foram respondidas.
"""

import os
import sys
import json
import time
from datetime import datetime
from typing import Dict, Any, List

# Adicionar src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

def executar_teste_completo():
    """Executa teste completo de todas as funcionalidades."""
    
    print("🔍 TESTE DE VALIDAÇÃO FINAL - COBOL AI ENGINE v1.6.0")
    print("=" * 80)
    print()
    
    resultados = {
        "data_teste": datetime.now().isoformat(),
        "versao": "1.6.0",
        "testes": {},
        "status_geral": "PENDENTE"
    }
    
    # 1. Teste do Parser COBOL
    print("📋 1. TESTANDO PARSER COBOL")
    print("-" * 50)
    
    try:
        from src.infrastructure.parsers.cobol_file_parser import CobolFileParser
        from src.infrastructure.parsers.books_parser import BooksParser
        
        parser = CobolFileParser()
        books_parser = BooksParser()
        
        # Testar parsing de programas
        fontes_path = "../upload/fontes.txt"
        if os.path.exists(fontes_path):
            programs = parser.parse_file(fontes_path)
            print(f"✅ Programas parseados: {len(programs)}")
            print(f"   Nomes: {[p.name for p in programs]}")
            
            resultados["testes"]["parser_programas"] = {
                "status": "SUCESSO",
                "quantidade": len(programs),
                "programas": [p.name for p in programs]
            }
        else:
            print(f"❌ Arquivo não encontrado: {fontes_path}")
            resultados["testes"]["parser_programas"] = {"status": "ERRO", "motivo": "Arquivo não encontrado"}
        
        # Testar parsing de books
        books_path = "../upload/BOOKS.txt"
        if os.path.exists(books_path):
            books = books_parser.parse_file(books_path)
            print(f"✅ Books parseados: {len(books)}")
            
            resultados["testes"]["parser_books"] = {
                "status": "SUCESSO",
                "quantidade": len(books)
            }
        else:
            print(f"❌ Arquivo não encontrado: {books_path}")
            resultados["testes"]["parser_books"] = {"status": "ERRO", "motivo": "Arquivo não encontrado"}
            
    except Exception as e:
        print(f"❌ Erro no teste de parser: {str(e)}")
        resultados["testes"]["parser_programas"] = {"status": "ERRO", "motivo": str(e)}
    
    print()
    
    # 2. Teste de Provedores de IA
    print("🤖 2. TESTANDO PROVEDORES DE IA")
    print("-" * 50)
    
    try:
        from src.infrastructure.ai_providers.ai_provider_factory import AIProviderFactory
        from src.domain.entities.ai_configuration import OpenAIConfiguration
        
        factory = AIProviderFactory()
        
        # Testar Enhanced Mock (sempre disponível)
        try:
            from src.infrastructure.ai_providers.enhanced_mock_ai_provider import EnhancedMockAIProvider
            
            mock_config = OpenAIConfiguration(
                api_key="mock",
                model_name="enhanced-mock-gpt-4",
                max_tokens=4000,
                temperature=0.1
            )
            
            mock_provider = EnhancedMockAIProvider(mock_config)
            disponivel = mock_provider.is_available()
            
            print(f"✅ Enhanced Mock Provider: {'Disponível' if disponivel else 'Indisponível'}")
            
            resultados["testes"]["enhanced_mock"] = {
                "status": "SUCESSO" if disponivel else "ERRO",
                "disponivel": disponivel
            }
            
        except Exception as e:
            print(f"❌ Enhanced Mock Provider: {str(e)}")
            resultados["testes"]["enhanced_mock"] = {"status": "ERRO", "motivo": str(e)}
        
        # Testar LuzIA Complete
        try:
            from src.infrastructure.ai_providers.luzia_complete_provider import LuziaCompleteProvider
            
            luzia_config = OpenAIConfiguration(
                api_key="test_client_id",
                api_endpoint="https://gpt-api.aws.santanderbr.dev.corp/genai_services/v1",
                model_name="aws-claude-1-3-sonnet-exp",
                max_tokens=4000,
                temperature=0.1,
                additional_parameters={
                    "client_secret": "test_secret",
                    "api_version": "2023-05-15"
                }
            )
            
            luzia_provider = LuziaCompleteProvider(luzia_config)
            print("✅ LuzIA Complete Provider: Implementado")
            
            resultados["testes"]["luzia_complete"] = {
                "status": "SUCESSO",
                "implementado": True
            }
            
        except Exception as e:
            print(f"❌ LuzIA Complete Provider: {str(e)}")
            resultados["testes"]["luzia_complete"] = {"status": "ERRO", "motivo": str(e)}
        
    except Exception as e:
        print(f"❌ Erro geral nos provedores: {str(e)}")
    
    print()
    
    # 3. Teste de Documentação
    print("📝 3. TESTANDO GERAÇÃO DE DOCUMENTAÇÃO")
    print("-" * 50)
    
    try:
        from src.application.services.documentation_generator import DocumentationGenerator
        
        doc_generator = DocumentationGenerator()
        
        # Criar programa de teste
        from src.domain.entities.cobol_program import CobolProgram
        
        programa_teste = CobolProgram(
            name="TESTE001",
            source_lines=[
                "IDENTIFICATION DIVISION.",
                "PROGRAM-ID. TESTE001.",
                "PROCEDURE DIVISION.",
                "DISPLAY 'HELLO WORLD'.",
                "STOP RUN."
            ]
        )
        
        # Testar geração de documentação básica
        doc_basica = doc_generator.generate_program_documentation(programa_teste)
        
        if "TESTE001" in doc_basica and "IDENTIFICATION DIVISION" in doc_basica:
            print("✅ Documentação básica: Gerada com sucesso")
            resultados["testes"]["documentacao_basica"] = {"status": "SUCESSO"}
        else:
            print("❌ Documentação básica: Conteúdo inválido")
            resultados["testes"]["documentacao_basica"] = {"status": "ERRO", "motivo": "Conteúdo inválido"}
        
        # Testar documentação com IA (mock)
        ai_analysis = {
            "summary": {
                "content": "Este é um programa de teste que exibe 'HELLO WORLD'.",
                "tokens_used": 50,
                "provider_used": "enhanced_mock"
            }
        }
        
        doc_ia = doc_generator.generate_enhanced_program_documentation(programa_teste, ai_analysis)
        
        if "HELLO WORLD" in doc_ia and "enhanced_mock" in doc_ia:
            print("✅ Documentação com IA: Gerada com sucesso")
            resultados["testes"]["documentacao_ia"] = {"status": "SUCESSO"}
        else:
            print("❌ Documentação com IA: Conteúdo inválido")
            resultados["testes"]["documentacao_ia"] = {"status": "ERRO", "motivo": "Conteúdo inválido"}
            
    except Exception as e:
        print(f"❌ Erro na documentação: {str(e)}")
        resultados["testes"]["documentacao_basica"] = {"status": "ERRO", "motivo": str(e)}
    
    print()
    
    # 4. Teste do Sistema Principal
    print("🚀 4. TESTANDO SISTEMA PRINCIPAL")
    print("-" * 50)
    
    try:
        # Executar main.py com arquivos de teste
        import subprocess
        
        cmd = [
            "python3", "main.py",
            "--fontes", "../upload/fontes.txt",
            "--books", "../upload/BOOKS.txt", 
            "--output", "teste_validacao_v1.6"
        ]
        
        print("Executando comando:", " ".join(cmd))
        
        start_time = time.time()
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        end_time = time.time()
        
        tempo_execucao = end_time - start_time
        
        if result.returncode == 0:
            print(f"✅ Sistema principal: Executado com sucesso ({tempo_execucao:.1f}s)")
            
            # Verificar arquivos gerados
            output_dir = "teste_validacao_v1.6"
            if os.path.exists(output_dir):
                arquivos = os.listdir(output_dir)
                print(f"✅ Arquivos gerados: {len(arquivos)}")
                
                resultados["testes"]["sistema_principal"] = {
                    "status": "SUCESSO",
                    "tempo_execucao": tempo_execucao,
                    "arquivos_gerados": len(arquivos),
                    "arquivos": arquivos
                }
            else:
                print("❌ Diretório de saída não criado")
                resultados["testes"]["sistema_principal"] = {"status": "ERRO", "motivo": "Diretório não criado"}
        else:
            print(f"❌ Sistema principal: Erro na execução")
            print(f"   Stdout: {result.stdout}")
            print(f"   Stderr: {result.stderr}")
            
            resultados["testes"]["sistema_principal"] = {
                "status": "ERRO",
                "motivo": "Erro na execução",
                "stderr": result.stderr
            }
            
    except subprocess.TimeoutExpired:
        print("❌ Sistema principal: Timeout na execução")
        resultados["testes"]["sistema_principal"] = {"status": "ERRO", "motivo": "Timeout"}
    except Exception as e:
        print(f"❌ Sistema principal: {str(e)}")
        resultados["testes"]["sistema_principal"] = {"status": "ERRO", "motivo": str(e)}
    
    print()
    
    # 5. Validação das Perguntas Centrais
    print("❓ 5. VALIDANDO PERGUNTAS CENTRAIS")
    print("-" * 50)
    
    perguntas_validadas = []
    
    # Pergunta 1: "O que este programa faz funcionalmente?"
    if os.path.exists("teste_validacao_v1.6"):
        arquivos_md = [f for f in os.listdir("teste_validacao_v1.6") if f.endswith('.md')]
        
        pergunta_respondida = False
        for arquivo in arquivos_md:
            caminho = os.path.join("teste_validacao_v1.6", arquivo)
            try:
                with open(caminho, 'r', encoding='utf-8') as f:
                    conteudo = f.read()
                    if "funcionalmente" in conteudo.lower() or "objetivo" in conteudo.lower():
                        pergunta_respondida = True
                        break
            except:
                pass
        
        if pergunta_respondida:
            print("✅ Pergunta 'O que faz funcionalmente?': RESPONDIDA")
            perguntas_validadas.append("funcionalidade")
        else:
            print("❌ Pergunta 'O que faz funcionalmente?': NÃO RESPONDIDA")
    
    # Pergunta 2: Integração Multi-IA
    if "enhanced_mock" in resultados["testes"] and resultados["testes"]["enhanced_mock"]["status"] == "SUCESSO":
        print("✅ Integração Multi-IA: IMPLEMENTADA")
        perguntas_validadas.append("multi_ia")
    else:
        print("❌ Integração Multi-IA: FALHOU")
    
    # Pergunta 3: Análise COBOL
    if "parser_programas" in resultados["testes"] and resultados["testes"]["parser_programas"]["status"] == "SUCESSO":
        print("✅ Análise COBOL: FUNCIONANDO")
        perguntas_validadas.append("analise_cobol")
    else:
        print("❌ Análise COBOL: FALHOU")
    
    # Pergunta 4: Documentação Automática
    if "documentacao_basica" in resultados["testes"] and resultados["testes"]["documentacao_basica"]["status"] == "SUCESSO":
        print("✅ Documentação Automática: FUNCIONANDO")
        perguntas_validadas.append("documentacao")
    else:
        print("❌ Documentação Automática: FALHOU")
    
    resultados["perguntas_validadas"] = perguntas_validadas
    
    print()
    
    # 6. Resumo Final
    print("📊 6. RESUMO FINAL DA VALIDAÇÃO")
    print("-" * 50)
    
    total_testes = len(resultados["testes"])
    testes_sucesso = sum(1 for t in resultados["testes"].values() if t.get("status") == "SUCESSO")
    
    print(f"Total de testes: {total_testes}")
    print(f"Testes com sucesso: {testes_sucesso}")
    print(f"Taxa de sucesso: {(testes_sucesso/total_testes*100):.1f}%")
    print()
    
    print("Perguntas centrais validadas:")
    for pergunta in perguntas_validadas:
        print(f"  ✅ {pergunta}")
    
    if len(perguntas_validadas) >= 3:  # Pelo menos 3 das 4 perguntas principais
        resultados["status_geral"] = "APROVADO"
        print()
        print("🎉 STATUS GERAL: APROVADO")
        print("   Sistema pronto para pacote v1.6.0")
    else:
        resultados["status_geral"] = "REPROVADO"
        print()
        print("❌ STATUS GERAL: REPROVADO")
        print("   Necessárias correções antes do pacote final")
    
    # Salvar resultados
    with open("RESULTADOS_VALIDACAO_v1.6.json", 'w', encoding='utf-8') as f:
        json.dump(resultados, f, indent=2, ensure_ascii=False)
    
    print()
    print("=" * 80)
    print(f"Resultados salvos em: RESULTADOS_VALIDACAO_v1.6.json")
    
    return resultados

if __name__ == "__main__":
    executar_teste_completo()

