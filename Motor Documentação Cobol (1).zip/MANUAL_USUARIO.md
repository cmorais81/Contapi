# Manual do Usuário - COBOL AI Engine v1.6.0

## 📋 Índice

1. [Introdução](#introdução)
2. [Instalação](#instalação)
3. [Configuração](#configuração)
4. [Uso Básico](#uso-básico)
5. [Uso Avançado](#uso-avançado)
6. [Exemplos Práticos](#exemplos-práticos)
7. [Solução de Problemas](#solução-de-problemas)
8. [FAQ](#faq)

## 🎯 Introdução

O **COBOL AI Engine** é uma ferramenta avançada para análise automatizada e documentação de programas COBOL usando Inteligência Artificial. A ferramenta processa arquivos COBOL empilhados, identifica relacionamentos entre programas e gera documentação técnica e funcional completa.

### Principais Funcionalidades

- **Parsing Inteligente**: Processa arquivos COBOL empilhados e copybooks
- **Análise de IA**: Integração com OpenAI, AWS Bedrock e GitHub Copilot
- **Documentação Automática**: Gera documentação técnica e funcional em Markdown
- **Mapeamento de Relacionamentos**: Identifica dependências e sequência de execução
- **Análise de Complexidade**: Avalia complexidade e métricas de código

### Requisitos do Sistema

- **Sistema Operacional**: Linux, macOS ou Windows
- **Python**: Versão 3.11 ou superior
- **Memória RAM**: Mínimo 512MB, recomendado 2GB
- **Espaço em Disco**: 100MB para instalação + espaço para arquivos de saída
- **Conexão Internet**: Para APIs de IA (opcional)

## 🚀 Instalação

### Passo 1: Verificar Python

```bash
python3 --version
# Deve retornar Python 3.11 ou superior
```

### Passo 2: Baixar e Extrair

```bash
# Extrair o pacote
tar -xzf cobol_ai_engine_v1.0.tar.gz
cd cobol_ai_engine
```

### Passo 3: Instalar Dependências

```bash
# Instalar dependências Python
pip3 install -r requirements.txt
```

### Passo 4: Verificar Instalação

```bash
# Testar instalação
python3 main.py --version
# Deve retornar: COBOL AI Engine 1.0.0
```

## ⚙️ Configuração

### Configuração Básica (Sem IA)

Para uso básico sem análise de IA, nenhuma configuração adicional é necessária. O sistema funcionará com parsing e documentação básica.

### Configuração com OpenAI

1. **Obter Chave da API**:
   - Acesse [platform.openai.com](https://platform.openai.com)
   - Crie uma conta e gere uma API key

2. **Configurar Variável de Ambiente**:
   ```bash
   export OPENAI_API_KEY="sua_chave_aqui"
   ```

3. **Configurar Arquivo** (opcional):
   ```yaml
   # config/config.yaml
   ai:
     primary_provider: "openai"
     providers:
       openai:
         api_key: "${OPENAI_API_KEY}"
         model_name: "gpt-4"
   ```

### Configuração com LuzIA

1. **Obter Credenciais**:
   - As credenciais para o LuzIA são gerenciadas internamente.

2. **Configurar Arquivo**:
   ```yaml
   # config/config.yaml
   ai:
     primary_provider: "luzia"
     providers:
       luzia:
         api_version: "2023-05-15"
   ```

### Configuração com AWS Bedrock

1. **Configurar Credenciais AWS**:
   ```bash
   export AWS_ACCESS_KEY_ID="sua_chave_aws"
   export AWS_SECRET_ACCESS_KEY="sua_chave_secreta"
   export AWS_DEFAULT_REGION="us-east-1"
   ```

2. **Configurar Arquivo**:
   ```yaml
   # config/config.yaml
   ai:
     primary_provider: "bedrock"
     providers:
       bedrock:
         aws_access_key_id: "${AWS_ACCESS_KEY_ID}"
         aws_secret_access_key: "${AWS_SECRET_ACCESS_KEY}"
         aws_region: "us-east-1"
         model_name: "anthropic.claude-3-sonnet-20240229-v1:0"
   ```

### Configuração com Múltiplas IAs

```yaml
# config/config.yaml
ai:
  primary_provider: "openai"
  fallback_providers: ["bedrock"]
  providers:
    openai:
      api_key: "${OPENAI_API_KEY}"
      model_name: "gpt-4"
    bedrock:
      aws_access_key_id: "${AWS_ACCESS_KEY_ID}"
      aws_secret_access_key: "${AWS_SECRET_ACCESS_KEY}"
      model_name: "anthropic.claude-3-sonnet-20240229-v1:0"
```

## 📖 Uso Básico

### Comando Simples

```bash
python3 main.py --fontes arquivos/fontes.txt --books arquivos/books.txt --output documentacao/
```

### Parâmetros Obrigatórios

- `--fontes` ou `-f`: Caminho para arquivo de fontes COBOL
- `--books` ou `-b`: Caminho para arquivo de books/copybooks
- `--output` ou `-o`: Diretório de saída para documentação

### Parâmetros Opcionais

- `--config` ou `-c`: Arquivo de configuração personalizado
- `--log-level`: Nível de logging (DEBUG, INFO, WARNING, ERROR)
- `--log-file`: Arquivo para salvar logs

### Exemplo Completo

```bash
python3 main.py \
  --fontes /dados/fontes.txt \
  --books /dados/books.txt \
  --output /documentacao/projeto_bacen \
  --config config/producao.yaml \
  --log-level INFO \
  --log-file logs/processamento.log
```

## 🔧 Uso Avançado

### Configuração Personalizada

Crie um arquivo de configuração personalizado:

```yaml
# config/minha_config.yaml
ai:
  primary_provider: "openai"
  fallback_providers: ["bedrock"]
  
parsing:
  extract_comments: true
  validate_cobol_format: true
  max_line_length: 72

documentation:
  include_complexity_metrics: true
  include_sequence_analysis: true
  language: "pt-br"
  template_style: "technical"

logging:
  level: "DEBUG"
  file: "logs/debug.log"
```

### Processamento em Lote

Para processar múltiplos projetos:

```bash
#!/bin/bash
# script_lote.sh

projetos=("projeto1" "projeto2" "projeto3")

for projeto in "${projetos[@]}"; do
    echo "Processando $projeto..."
    python3 main.py \
        --fontes "dados/$projeto/fontes.txt" \
        --books "dados/$projeto/books.txt" \
        --output "docs/$projeto" \
        --log-file "logs/$projeto.log"
done
```

### Integração com CI/CD

```yaml
# .github/workflows/cobol-docs.yml
name: Gerar Documentação COBOL
on:
  push:
    paths: ['cobol/**']

jobs:
  generate-docs:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Setup Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.11'
      - name: Install dependencies
        run: pip install -r requirements.txt
      - name: Generate documentation
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
        run: |
          python3 main.py \
            --fontes cobol/fontes.txt \
            --books cobol/books.txt \
            --output docs/
```

## 💡 Exemplos Práticos

### Exemplo 1: Projeto Simples

**Estrutura de Arquivos**:
```
projeto/
├── fontes.txt      # Programas COBOL empilhados
├── books.txt       # Copybooks
└── docs/          # Saída (será criado)
```

**Comando**:
```bash
python3 main.py -f projeto/fontes.txt -b projeto/books.txt -o projeto/docs/
```

**Resultado**:
```
projeto/docs/
├── PROGRAMA1.md
├── PROGRAMA2.md
├── PROGRAMA3.md
└── relatorio_completo.md
```

### Exemplo 2: Análise com IA

**Configuração**:
```bash
export OPENAI_API_KEY="sk-..."
```

**Comando**:
```bash
python3 main.py \
  --fontes dados/sistema_bacen.txt \
  --books dados/copybooks_bacen.txt \
  --output docs/bacen_analysis \
  --log-level INFO
```

**Resultado com IA**:
- Documentação técnica detalhada
- Análise funcional de negócio
- Identificação de relacionamentos
- Métricas de complexidade

### Exemplo 3: Configuração Empresarial

**Arquivo de Configuração** (`config/empresa.yaml`):
```yaml
ai:
  primary_provider: "bedrock"
  fallback_providers: ["openai"]
  
documentation:
  include_version_history: true
  include_complexity_metrics: true
  language: "pt-br"
  template_style: "corporate"

logging:
  level: "INFO"
  file: "/var/log/cobol_engine.log"
```

**Comando**:
```bash
python3 main.py \
  --config config/empresa.yaml \
  --fontes /mainframe/exports/fontes.txt \
  --books /mainframe/exports/books.txt \
  --output /docs/mainframe_analysis
```

## 🔍 Solução de Problemas

### Problema: "Arquivo não encontrado"

**Sintoma**:
```
ERROR - Arquivo de fontes não encontrado: fontes.txt
```

**Solução**:
1. Verificar se o arquivo existe
2. Usar caminho absoluto
3. Verificar permissões de leitura

```bash
ls -la fontes.txt
python3 main.py --fontes /caminho/completo/fontes.txt ...
```

### Problema: "Erro de API de IA"

**Sintoma**:
```
WARNING - Provedor openai não disponível
```

**Soluções**:
1. Verificar chave da API:
   ```bash
   echo $OPENAI_API_KEY
   ```

2. Testar conectividade:
   ```bash
   curl -H "Authorization: Bearer $OPENAI_API_KEY" \
        https://api.openai.com/v1/models
   ```

3. Verificar saldo da conta OpenAI

### Problema: "Erro de parsing COBOL"

**Sintoma**:
```
ERROR - Erro parseando programa: formato inválido
```

**Soluções**:
1. Verificar formato do arquivo (deve ter VMEMBER NAME)
2. Verificar encoding (UTF-8 recomendado)
3. Usar configuração de parsing personalizada:

```yaml
parsing:
  validate_cobol_format: false
  max_line_length: 80
```

### Problema: "Memória insuficiente"

**Sintoma**:
```
MemoryError: Unable to allocate array
```

**Soluções**:
1. Processar arquivos menores
2. Aumentar memória disponível
3. Usar configuração otimizada:

```yaml
performance:
  max_concurrent_requests: 1
  chunk_size: 1000
```

## ❓ FAQ

### Q: O sistema funciona sem conexão com internet?
**R**: Sim, o parsing e documentação básica funcionam offline. As análises de IA requerem conexão.

### Q: Quais formatos de arquivo COBOL são suportados?
**R**: Arquivos empilhados com formato VMEMBER NAME e arquivos individuais .cob/.cbl.

### Q: Posso usar múltiplas APIs de IA simultaneamente?
**R**: Sim, configure um provedor primário e fallbacks. O sistema tentará automaticamente.

### Q: Como personalizar os templates de documentação?
**R**: Edite os arquivos em `src/application/services/documentation_generator.py` ou crie templates customizados.

### Q: O sistema preserva comentários do código original?
**R**: Sim, comentários são extraídos e incluídos na documentação quando configurado.

### Q: Posso processar arquivos muito grandes?
**R**: Sim, o sistema é otimizado para grandes volumes. Configure `chunk_size` se necessário.

### Q: Como integrar com sistemas de versionamento?
**R**: Use hooks do Git ou pipelines CI/CD para gerar documentação automaticamente.

### Q: Existe suporte para outros mainframes além do IBM?
**R**: O sistema é compatível com COBOL padrão. Ajustes podem ser necessários para dialetos específicos.

### Q: Como exportar documentação para outros formatos?
**R**: Use ferramentas como Pandoc para converter Markdown para PDF, Word, etc:

```bash
pandoc documentacao.md -o documentacao.pdf
```

### Q: Posso contribuir com melhorias?
**R**: O sistema segue arquitetura modular. Consulte `ARCHITECTURE.md` para detalhes de extensão.

---

## 📞 Suporte

Para suporte técnico ou dúvidas:

- **Documentação**: Consulte `README.md` e `ARCHITECTURE.md`
- **Exemplos**: Veja pasta `examples/`
- **Logs**: Ative logging DEBUG para diagnóstico detalhado

---

*Manual do Usuário - COBOL AI Engine v1.6.0*
*Última atualização: Setembro 2025*

