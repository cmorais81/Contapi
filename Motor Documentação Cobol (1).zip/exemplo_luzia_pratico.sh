#!/bin/bash

echo "🚀 EXEMPLO PRÁTICO - LUZIA COMPLETE PROVIDER v1.5.0"
echo "============================================================"

# Configurações
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="exemplo_luzia_output"
CONFIG_FILE="config/luzia_complete_config.yaml"

echo "📁 Diretório do script: $SCRIPT_DIR"
echo "📂 Diretório de saída: $OUTPUT_DIR"
echo "⚙️  Arquivo de configuração: $CONFIG_FILE"
echo ""

# Verificar se estamos no diretório correto
if [ ! -f "main.py" ] || [ ! -d "src" ]; then
    echo "❌ ERRO: Execute este script no diretório raiz do COBOL AI Engine"
    echo "   cd cobol_ai_engine && ./exemplo_luzia_pratico.sh"
    exit 1
fi

# Verificar arquivos de entrada
FONTES_FILE="../upload/fontes.txt"
BOOKS_FILE="../upload/BOOKS.txt"

if [ ! -f "$FONTES_FILE" ]; then
    echo "❌ ERRO: Arquivo de fontes não encontrado: $FONTES_FILE"
    exit 1
fi

if [ ! -f "$BOOKS_FILE" ]; then
    echo "❌ ERRO: Arquivo de books não encontrado: $BOOKS_FILE"
    exit 1
fi

echo "✅ Arquivos de entrada encontrados:"
echo "   📄 Fontes: $FONTES_FILE"
echo "   📚 Books: $BOOKS_FILE"
echo ""

# Verificar configuração LuzIA
if [ ! -f "$CONFIG_FILE" ]; then
    echo "❌ ERRO: Arquivo de configuração não encontrado: $CONFIG_FILE"
    echo "   Criando configuração de exemplo..."
    
    # Criar configuração de exemplo
    mkdir -p config
    cat > "$CONFIG_FILE" << 'EOF'
ai_providers:
  primary: "luzia_complete"
  fallback: ["enhanced_mock_ai"]
  
  luzia_complete:
    api_key: "${LUZIA_CLIENT_ID}"
    api_base: "https://gpt-api.aws.santanderbr.dev.corp/genai_services/v1"
    model: "aws-claude-1-3-sonnet-exp"
    max_tokens: 4000
    temperature: 0.1
    additional_params:
      client_secret: "${LUZIA_CLIENT_SECRET}"
      api_version: "2023-05-15"
      auth_endpoint: "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
      use_knowledge_base: true
      knowledge_base_id: "KNOWLEDGE_BASE_ID"
      guardrail_id: "GUARDRAIL_ID"
      guardrail_version: "GUARDRAIL_VERSION"
      auto_refresh_token: true
      timeout: 120
      
  enhanced_mock_ai:
    api_key: "mock"
    model: "enhanced-mock-gpt-4"
    max_tokens: 4000
    temperature: 0.1

cobol_analysis:
  enable_relationship_mapping: true
  enable_business_rules_extraction: true
  enable_logic_flow_analysis: true
  include_prompts_in_documentation: true

output:
  format: "markdown"
  include_metadata: true
  include_prompts: true
  include_statistics: true

logging:
  level: "INFO"
  include_ai_responses: true
  include_token_usage: true
EOF
    
    echo "✅ Configuração de exemplo criada: $CONFIG_FILE"
fi

# Verificar credenciais LuzIA (opcional)
echo "🔐 Verificando credenciais LuzIA..."
if [ -z "$LUZIA_CLIENT_ID" ]; then
    echo "⚠️  LUZIA_CLIENT_ID não configurado - usando fallback Enhanced Mock"
else
    echo "✅ LUZIA_CLIENT_ID configurado"
fi

if [ -z "$LUZIA_CLIENT_SECRET" ]; then
    echo "⚠️  LUZIA_CLIENT_SECRET não configurado - usando fallback Enhanced Mock"
else
    echo "✅ LUZIA_CLIENT_SECRET configurado"
fi

echo ""
echo "🧠 Iniciando análise COBOL com LuzIA Provider..."
echo "============================================================"

# Executar análise
python3 main.py \
    --fontes "$FONTES_FILE" \
    --books "$BOOKS_FILE" \
    --output "$OUTPUT_DIR" \
    --log-level INFO

# Verificar resultado
EXIT_CODE=$?
echo ""
echo "============================================================"

if [ $EXIT_CODE -eq 0 ]; then
    echo "🎉 ANÁLISE CONCLUÍDA COM SUCESSO!"
    echo ""
    echo "📊 Resultados salvos em: $OUTPUT_DIR/"
    echo ""
    
    # Listar arquivos gerados
    if [ -d "$OUTPUT_DIR" ]; then
        echo "📋 Arquivos gerados:"
        ls -la "$OUTPUT_DIR/" | grep -E '\.(md)$' | while read -r line; do
            filename=$(echo "$line" | awk '{print $NF}')
            size=$(echo "$line" | awk '{print $5}')
            echo "   📄 $filename ($size bytes)"
        done
        
        echo ""
        echo "🔍 Para visualizar os resultados:"
        echo "   cat $OUTPUT_DIR/relatorio_completo.md"
        echo ""
        echo "📖 Para ver análise específica de um programa:"
        echo "   cat $OUTPUT_DIR/LHAN0542.md"
        
        # Mostrar resumo do relatório principal se existir
        MAIN_REPORT="$OUTPUT_DIR/relatorio_completo.md"
        if [ -f "$MAIN_REPORT" ]; then
            echo ""
            echo "📋 RESUMO DO RELATÓRIO PRINCIPAL:"
            echo "============================================================"
            head -n 20 "$MAIN_REPORT"
            echo "..."
            echo "(Para ver o relatório completo: cat $MAIN_REPORT)"
        fi
        
    else
        echo "⚠️  Diretório de saída não encontrado"
    fi
    
else
    echo "❌ ERRO na análise (código: $EXIT_CODE)"
    echo ""
    echo "🔧 Possíveis soluções:"
    echo "   1. Verificar se os arquivos de entrada existem"
    echo "   2. Verificar dependências Python: pip3 install -r requirements.txt"
    echo "   3. Executar com debug: python3 main.py ... --log-level DEBUG"
    echo "   4. Verificar logs de erro acima"
    echo ""
    echo "💡 O sistema usa fallback automático, então deve funcionar mesmo sem LuzIA"
    exit $EXIT_CODE
fi

echo ""
echo "============================================================"
echo "✅ Exemplo LuzIA Complete Provider v1.5.0 concluído!"
echo ""
echo "🎯 Funcionalidades demonstradas:"
echo "   ✅ Integração LuzIA SDK oficial"
echo "   ✅ Autenticação OAuth2 fresca"
echo "   ✅ Sistema de fallback inteligente"
echo "   ✅ Documentação com prompts"
echo "   ✅ Análise funcional garantida"
echo "   ✅ Knowledge Base especializada"
echo "   ✅ Guardrails de segurança"
echo ""
echo "🚀 Sistema pronto para produção!"

