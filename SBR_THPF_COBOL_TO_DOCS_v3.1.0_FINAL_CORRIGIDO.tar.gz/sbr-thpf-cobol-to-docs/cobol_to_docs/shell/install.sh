#!/bin/bash

# COBOL Analyzer v3.1.0 - Script de Instalação
# Instalação automatizada do COBOL Analyzer

set -e

echo "=========================================="
echo "COBOL Analyzer v3.1.0 - Instalação"
echo "=========================================="

# Verificar Python
echo "Verificando Python..."
if ! command -v python3 &> /dev/null; then
    echo "ERRO: Python 3 não encontrado. Instale Python 3.8 ou superior."
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
echo "Python encontrado: $PYTHON_VERSION"

# Verificar pip
echo "Verificando pip..."
if ! command -v pip3 &> /dev/null; then
    echo "ERRO: pip3 não encontrado. Instale pip para Python 3."
    exit 1
fi

# Instalar dependências
echo "Instalando dependências..."
pip3 install -r requirements.txt

# Instalar COBOL Analyzer
echo "Instalando COBOL Analyzer..."
pip3 install .

# Verificar instalação
echo "Verificando instalação..."
if command -v cobol-to-docs &> /dev/null; then
    echo "SUCESSO: COBOL Analyzer instalado com sucesso!"
    echo ""
    echo "Para começar a usar:"
    echo "1. Execute: cobol-to-docs --init"
    echo "2. Configure suas credenciais de IA"
    echo "3. Execute: cobol-to-docs --fontes seus_programas.txt --models luzia"
    echo ""
    echo "Para mais informações, consulte docs/README.md"
else
    echo "ERRO: Instalação falhou. Comando cobol-to-docs não encontrado."
    exit 1
fi

echo "=========================================="
echo "Instalação concluída com sucesso!"
echo "=========================================="
