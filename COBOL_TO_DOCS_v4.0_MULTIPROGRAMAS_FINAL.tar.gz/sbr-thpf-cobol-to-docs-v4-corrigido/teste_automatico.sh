#!/bin/bash

# Script de Teste Automatizado - COBOL_ANALYZER v4.0
# Data: 13 de Outubro de 2025

echo "🚀 INICIANDO TESTES AUTOMATIZADOS - COBOL_ANALYZER v4.0"
echo "========================================================"

# Cores para output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Função para verificar sucesso
check_success() {
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ $1${NC}"
        return 0
    else
        echo -e "${RED}❌ $1${NC}"
        return 1
    fi
}

# Função para contar arquivos
count_files() {
    local pattern=$1
    local expected=$2
    local description=$3
    
    local count=$(find . -name "$pattern" 2>/dev/null | wc -l)
    if [ "$count" -eq "$expected" ]; then
        echo -e "${GREEN}✅ $description: $count/$expected${NC}"
        return 0
    else
        echo -e "${RED}❌ $description: $count/$expected${NC}"
        return 1
    fi
}

echo ""
echo "📋 TESTE 1: Verificação de Arquivos Necessários"
echo "------------------------------------------------"

# Verificar arquivos essenciais
test -f "fontes.txt" && echo -e "${GREEN}✅ fontes.txt encontrado${NC}" || echo -e "${RED}❌ fontes.txt não encontrado${NC}"
test -f "BOOKS.txt" && echo -e "${GREEN}✅ BOOKS.txt encontrado${NC}" || echo -e "${RED}❌ BOOKS.txt não encontrado${NC}"
test -f "minato_promt.txt" && echo -e "${GREEN}✅ minato_promt.txt encontrado${NC}" || echo -e "${RED}❌ minato_promt.txt não encontrado${NC}"
test -f "cobol_to_docs/runner/main.py" && echo -e "${GREEN}✅ main.py encontrado${NC}" || echo -e "${RED}❌ main.py não encontrado${NC}"

echo ""
echo "🧪 TESTE 2: Processamento de Múltiplos Programas (Padrão)"
echo "--------------------------------------------------------"

python3 cobol_to_docs/runner/main.py \
    --fontes fontes.txt \
    --books BOOKS.txt \
    --output teste_multiprogramas \
    --log-level INFO

check_success "Execução do teste padrão"

# Verificar resultados
if [ -d "teste_multiprogramas" ]; then
    echo -e "${YELLOW}📊 Verificando resultados...${NC}"
    
    count_files "teste_multiprogramas/model_*/LHAN*_analise_funcional.md" 4 "Análises LHAN*"
    count_files "teste_multiprogramas/model_*/LHBR*_analise_funcional.md" 1 "Análises LHBR*"
    count_files "teste_multiprogramas/model_*/MZAN*_analise_funcional.md" 1 "Análises MZAN*"
    count_files "teste_multiprogramas/model_*/ai_requests/*.json" 5 "Arquivos de request"
    count_files "teste_multiprogramas/model_*/ai_responses/*.json" 5 "Arquivos de response"
    
    # Verificar estrutura de diretórios
    if [ -d "teste_multiprogramas/model_enhanced_mock/ai_requests" ] && [ -d "teste_multiprogramas/model_enhanced_mock/ai_responses" ]; then
        echo -e "${GREEN}✅ Estrutura de diretórios correta${NC}"
    else
        echo -e "${RED}❌ Estrutura de diretórios incorreta${NC}"
    fi
fi

echo ""
echo "🎯 TESTE 3: Processamento com Prompt Customizado"
echo "-----------------------------------------------"

python3 cobol_to_docs/runner/main.py \
    --fontes fontes.txt \
    --books BOOKS.txt \
    --custom-prompt minato_promt.txt \
    --output teste_prompt_customizado \
    --log-level INFO

check_success "Execução com prompt customizado"

# Verificar se prompt customizado foi usado
if [ -d "teste_prompt_customizado" ]; then
    echo -e "${YELLOW}📊 Verificando prompt customizado...${NC}"
    
    # Verificar flag custom_prompt_used
    custom_count=$(grep -r "custom_prompt_used.*true" teste_prompt_customizado/ 2>/dev/null | wc -l)
    if [ "$custom_count" -gt 0 ]; then
        echo -e "${GREEN}✅ Prompt customizado usado: $custom_count ocorrências${NC}"
    else
        echo -e "${RED}❌ Prompt customizado não foi usado${NC}"
    fi
fi

echo ""
echo "📈 TESTE 4: Verificação de Performance"
echo "------------------------------------"

# Verificar logs
if [ -d "logs" ] && [ "$(ls -A logs)" ]; then
    echo -e "${GREEN}✅ Logs gerados${NC}"
    
    # Verificar se há erros críticos
    error_count=$(grep -r "CRITICAL\|ERROR" logs/ 2>/dev/null | grep -v "Falha no provider primário luzia" | wc -l)
    if [ "$error_count" -eq 0 ]; then
        echo -e "${GREEN}✅ Nenhum erro crítico encontrado${NC}"
    else
        echo -e "${YELLOW}⚠️  $error_count erros encontrados (verificar logs)${NC}"
    fi
else
    echo -e "${RED}❌ Logs não foram gerados${NC}"
fi

echo ""
echo "📋 RESUMO DOS TESTES"
echo "==================="

# Contar sucessos
total_programs_1=$(find teste_multiprogramas -name "*_analise_funcional.md" 2>/dev/null | wc -l)
total_programs_2=$(find teste_prompt_customizado -name "*_analise_funcional.md" 2>/dev/null | wc -l)

echo "📊 Teste Padrão:"
echo "   - Programas processados: $total_programs_1/5"
echo "   - Arquivos gerados: $(find teste_multiprogramas -type f 2>/dev/null | wc -l)"

echo "📊 Teste com Prompt Customizado:"
echo "   - Programas processados: $total_programs_2/5"
echo "   - Arquivos gerados: $(find teste_prompt_customizado -type f 2>/dev/null | wc -l)"

# Verificação final
if [ "$total_programs_1" -eq 5 ] && [ "$total_programs_2" -eq 5 ]; then
    echo ""
    echo -e "${GREEN}🎉 TODOS OS TESTES PASSARAM COM SUCESSO!${NC}"
    echo -e "${GREEN}✅ A aplicação está funcionando perfeitamente!${NC}"
    exit 0
else
    echo ""
    echo -e "${RED}❌ ALGUNS TESTES FALHARAM${NC}"
    echo -e "${YELLOW}⚠️  Verificar logs e arquivos de saída${NC}"
    exit 1
fi
