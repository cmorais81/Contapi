#!/usr/bin/env python3
"""
Enhanced Prompt Manager - Garantir que todo conteúdo do arquivo de prompt seja incluído
"""

import os
import yaml
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime

class EnhancedPromptManager:
    """
    Gerenciador de prompts aprimorado que garante inclusão completa do conteúdo.
    """
    
    def __init__(self, config_manager):
        """Inicializa o gerenciador de prompts aprimorado."""
        self.config_manager = config_manager
        self.logger = logging.getLogger(__name__)
        
    def load_complete_prompt_file(self, prompt_set: str = 'especialista') -> Dict[str, Any]:
        """
        Carrega COMPLETAMENTE o arquivo de prompt especificado.
        
        Args:
            prompt_set: Nome do conjunto de prompts
            
        Returns:
            Dicionário com TODO o conteúdo do arquivo YAML
        """
        # Mapear conjunto para arquivo
        prompt_files = {
            'especialista': 'prompts_especialista.yaml',
            'cadoc_deep': 'prompts_cadoc_deep_analysis.yaml',
            'deep_business': 'prompts_deep_business_rules.yaml',
            'melhorado_rag': 'prompts_melhorado_rag.yaml',
            'original': 'prompts_original.yaml'
        }
        
        prompt_filename = prompt_files.get(prompt_set, 'prompts_especialista.yaml')
        
        # Buscar arquivo nos diretórios possíveis
        search_paths = [
            f"/home/ubuntu/sbr-thpf-cobol-to-docs/cobol_to_docs/config/{prompt_filename}",
            f"/home/ubuntu/sbr-thpf-cobol-to-docs/config/{prompt_filename}",
            f"config/{prompt_filename}",
            prompt_filename
        ]
        
        prompt_file_path = None
        for path in search_paths:
            if os.path.exists(path):
                prompt_file_path = path
                break
        
        if not prompt_file_path:
            self.logger.error(f"Arquivo de prompt não encontrado: {prompt_filename}")
            return self._get_fallback_prompt()
        
        try:
            with open(prompt_file_path, 'r', encoding='utf-8') as f:
                complete_content = yaml.safe_load(f)
            
            self.logger.info(f"Prompt completo carregado de: {prompt_file_path}")
            self.logger.info(f"Seções encontradas: {list(complete_content.keys())}")
            
            # Log do tamanho do conteúdo para verificar se está completo
            total_chars = sum(len(str(v)) for v in complete_content.values())
            self.logger.info(f"Total de caracteres no prompt: {total_chars:,}")
            
            return complete_content
            
        except Exception as e:
            self.logger.error(f"Erro ao carregar prompt de {prompt_file_path}: {e}")
            return self._get_fallback_prompt()
    
    def _get_fallback_prompt(self) -> Dict[str, Any]:
        """Prompt de fallback básico."""
        return {
            'system_prompt': 'Você é um analista de sistemas COBOL especializado em análise técnica detalhada.',
            'main_prompt': 'Realize uma análise técnica completa do programa COBOL fornecido.',
            'analysis_questions': {
                'structure': {'question': 'Analise a estrutura do programa.'},
                'business_rules': {'question': 'Extraia as regras de negócio.'},
                'data_flow': {'question': 'Descreva o fluxo de dados.'}
            }
        }
    
    def create_complete_analysis_prompt(self, 
                                      program_name: str, 
                                      program_code: str, 
                                      copybooks: List = None,
                                      prompt_set: str = 'especialista') -> str:
        """
        Cria prompt de análise incluindo TODO o conteúdo do arquivo de prompt.
        
        Args:
            program_name: Nome do programa
            program_code: Código completo do programa
            copybooks: Lista de copybooks relacionados
            prompt_set: Conjunto de prompts a usar
            
        Returns:
            Prompt completo com TODO o conteúdo do arquivo
        """
        # Carregar prompt completo
        prompt_config = self.load_complete_prompt_file(prompt_set)
        
        # Construir prompt final incluindo TUDO
        prompt_parts = []
        
        # 1. SYSTEM PROMPT COMPLETO
        if 'system_prompt' in prompt_config:
            prompt_parts.append("=== SYSTEM PROMPT COMPLETO ===")
            prompt_parts.append(str(prompt_config['system_prompt']))
        
        # 2. MAIN PROMPT COMPLETO
        if 'main_prompt' in prompt_config:
            prompt_parts.append("\\n=== INSTRUÇÕES PRINCIPAIS COMPLETAS ===")
            prompt_parts.append(str(prompt_config['main_prompt']))
        
        # 3. TODAS AS QUESTÕES DE ANÁLISE
        if 'analysis_questions' in prompt_config:
            prompt_parts.append("\\n=== QUESTÕES DE ANÁLISE ESPECÍFICAS ===")
            
            questions = prompt_config['analysis_questions']
            for i, (key, question_data) in enumerate(questions.items(), 1):
                prompt_parts.append(f"\\n{i}. {key.upper().replace('_', ' ')}:")
                
                if isinstance(question_data, dict):
                    if 'question' in question_data:
                        prompt_parts.append(f"   {question_data['question']}")
                    if 'description' in question_data:
                        prompt_parts.append(f"   Detalhes: {question_data['description']}")
                    if 'examples' in question_data:
                        prompt_parts.append(f"   Exemplos: {question_data['examples']}")
                else:
                    prompt_parts.append(f"   {str(question_data)}")
        
        # 4. INSTRUÇÕES ADICIONAIS (se existirem)
        for key, value in prompt_config.items():
            if key not in ['system_prompt', 'main_prompt', 'analysis_questions']:
                prompt_parts.append(f"\\n=== {key.upper().replace('_', ' ')} ===")
                prompt_parts.append(str(value))
        
        # 5. CONTEXTO DO PROGRAMA
        prompt_parts.append("\\n=== PROGRAMA PARA ANÁLISE ===")
        prompt_parts.append(f"Nome do programa: {program_name}")
        prompt_parts.append(f"Timestamp da análise: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # 6. COPYBOOKS (se fornecidos)
        if copybooks:
            prompt_parts.append(f"\\nCopybooks relacionados ({len(copybooks)}):")
            for i, copybook in enumerate(copybooks, 1):
                if hasattr(copybook, 'name') and hasattr(copybook, 'content'):
                    prompt_parts.append(f"\\n--- COPYBOOK {i}: {copybook.name} ---")
                    prompt_parts.append(copybook.content)
                else:
                    prompt_parts.append(f"\\n--- COPYBOOK {i} ---")
                    prompt_parts.append(str(copybook))
        
        # 7. CÓDIGO DO PROGRAMA
        prompt_parts.append(f"\\n=== CÓDIGO FONTE COMPLETO ===")
        prompt_parts.append(program_code)
        
        # 8. INSTRUÇÃO FINAL
        prompt_parts.append("\\n=== INSTRUÇÃO FINAL ===")
        prompt_parts.append("Responda com TODOS os detalhes solicitados acima. Não omita nenhuma informação. Seja extremamente detalhado e técnico.")
        
        # Juntar tudo
        complete_prompt = "\\n".join(prompt_parts)
        
        # Log para verificar se está completo
        self.logger.info(f"Prompt completo criado:")
        self.logger.info(f"  - Tamanho total: {len(complete_prompt):,} caracteres")
        self.logger.info(f"  - Seções incluídas: {len([p for p in prompt_parts if p.startswith('===')])} seções")
        self.logger.info(f"  - Prompt set usado: {prompt_set}")
        
        return complete_prompt

def test_enhanced_prompt_manager():
    """Testa o gerenciador de prompts aprimorado."""
    
    print("=== TESTE DO ENHANCED PROMPT MANAGER ===")
    
    # Simular config manager
    class MockConfigManager:
        pass
    
    config_manager = MockConfigManager()
    
    # Criar gerenciador
    prompt_manager = EnhancedPromptManager(config_manager)
    
    # Testar carregamento de prompt
    prompt_config = prompt_manager.load_complete_prompt_file('especialista')
    
    print(f"\\nPrompt carregado:")
    print(f"  - Seções: {list(prompt_config.keys())}")
    
    for key, value in prompt_config.items():
        value_str = str(value)
        print(f"  - {key}: {len(value_str):,} caracteres")
        if len(value_str) > 100:
            print(f"    Preview: {value_str[:100]}...")
        else:
            print(f"    Conteúdo: {value_str}")
    
    # Testar criação de prompt completo
    test_program_code = '''       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTE001.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01  WS-CONTADOR    PIC 9(3) VALUE ZEROS.
       
       PROCEDURE DIVISION.
       MAIN-PROGRAMA.
           DISPLAY 'TESTE'
           STOP RUN.'''
    
    complete_prompt = prompt_manager.create_complete_analysis_prompt(
        program_name="TESTE001",
        program_code=test_program_code,
        prompt_set='especialista'
    )
    
    print(f"\\nPrompt completo gerado:")
    print(f"  - Tamanho: {len(complete_prompt):,} caracteres")
    print(f"  - Preview (primeiros 500 chars):")
    print(complete_prompt[:500] + "...")

if __name__ == "__main__":
    test_enhanced_prompt_manager()
