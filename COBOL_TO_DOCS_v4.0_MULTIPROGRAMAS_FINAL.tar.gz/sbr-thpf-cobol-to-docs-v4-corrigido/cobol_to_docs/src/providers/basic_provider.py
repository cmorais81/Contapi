"""
COBOL AI Engine v2.1.0 - Basic Provider
Provider básico como fallback final garantido.
"""

import logging
import time
from typing import Dict, Any
from datetime import datetime

from providers.base_provider import BaseProvider, AIRequest, AIResponse


class BasicProvider(BaseProvider):
    """
    Provider básico que nunca falha - fallback final garantido.
    
    Funcionalidades:
    - Sempre disponível (100% uptime)
    - Respostas estruturadas básicas
    - Nunca falha
    - Resposta mínima para "O que faz funcionalmente?"
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o Basic Provider com configurações do config.yaml.
        
        Args:
            config: Configuração do provedor
        """
        super().__init__(config)
        
        # Obter configurações do basic do config.yaml
        basic_config = config.get('providers', {}).get('basic', {})
        
        # Sempre habilitado (fallback final)
        self.enabled = basic_config.get('enabled', True)
        
        # Configurações do modelo
        models_config = basic_config.get('models', {})
        if models_config:
            # Pegar o primeiro modelo configurado
            first_model_key = list(models_config.keys())[0]
            model_config = models_config[first_model_key]
            self.model = model_config.get('name', 'basic-fallback')
            self.max_tokens = model_config.get('max_tokens', 4096)
            self.temperature = model_config.get('temperature', 0.0)
            self.timeout = model_config.get('timeout', 1)
        else:
            # Valores padrão se não configurado
            self.model = 'basic-fallback'
            self.max_tokens = 4096
            self.temperature = 0.0
            self.timeout = 1
        
        # Configurações básicas
        self.response_delay = self.timeout * 0.05  # 5% do timeout como delay
        
        self.logger.info(f"Basic Provider configurado: modelo={self.model}, timeout={self.timeout}s")
        self.logger.info("Basic Provider inicializado - Fallback final garantido")
    
    def is_available(self) -> bool:
        """Basic Provider sempre está disponível."""
        return True
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise básica que nunca falha.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Resposta básica estruturada
        """
        try:
            # Simular delay mínimo
            time.sleep(self.response_delay)
            
            # Gerar resposta básica
            content = self._generate_basic_response(request)
            
            # Simular uso de tokens
            tokens_used = min(len(content) // 4, self.max_tokens)
            
            response = AIResponse(
                success=True,
                content=content,
                tokens_used=tokens_used,
                model="basic-fallback-v1",
                provider=self.name,
                prompts_used={
                    'Prompt Original': request.prompt,
                    'Prompt Básico': "Análise básica de programa COBOL (fallback)",
                    'Contexto': f"Programa: {request.program_name}"
                },
                metadata={
                    'fallback_provider': True,
                    'response_delay': self.response_delay,
                    'max_tokens': self.max_tokens
                }
            )
            
            self._update_statistics(response)
            return response
            
        except Exception as e:
            # Basic Provider nunca deve falhar, mas se falhar, retornar resposta mínima
            self.logger.error(f"Erro inesperado no Basic Provider: {str(e)}")
            
            minimal_response = AIResponse(
                success=True,
                content=self._get_minimal_response(),
                tokens_used=50,
                model="basic-fallback-v1",
                provider=self.name,
                prompts_used={
                    'Prompt de Fallback': "Resposta mínima de fallback para garantir funcionamento",
                    'Contexto de Erro': f"Erro: {str(e)}"
                }
            )
            
            self._update_statistics(minimal_response)
            return minimal_response
    
    def _generate_basic_response(self, request: AIRequest) -> str:
        """Gera resposta básica estruturada."""
        
        # Extrair contexto se disponível
        context = request.context or {}
        program_name = context.get('program_name', 'PROGRAMA')
        
        # Template de resposta básica
        response = f"""# Análise Básica - {program_name}

## Informações Gerais

- **Programa**: {program_name}
- **Tipo**: Programa COBOL
- **Status**: Analisado com Basic Provider

## O que este programa faz funcionalmente?

Este programa COBOL implementa processamento de dados corporativo. Funcionalmente:

### Objetivo Principal
- Processamento de dados em ambiente mainframe
- Execução de lógica de negócio específica
- Manipulação de arquivos e registros

### Processo Básico
1. **Entrada**: Recebe dados de entrada
2. **Processamento**: Aplica regras de negócio
3. **Saída**: Gera resultados processados

### Características Técnicas
- Estrutura COBOL padrão
- Divisões: IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE
- Processamento sequencial de dados
- Controle de fluxo estruturado

## Recomendações

- Revisar documentação técnica detalhada
- Validar regras de negócio implementadas
- Testar com dados de exemplo
- Manter backup dos dados processados

---
*Análise gerada pelo Basic Provider - Fallback Final Garantido*
*Para análise mais detalhada, configure provedores de IA avançados*
"""
        
        return response
    
    def _get_minimal_response(self) -> str:
        """Retorna resposta mínima em caso de erro extremo."""
        
        return """# Análise Básica

## O que este programa faz funcionalmente?

Este é um programa COBOL que processa dados corporativos.

**Funcionalidade**: Processamento de dados em ambiente mainframe.

---
*Análise mínima - Basic Provider*
"""
    
    def get_provider_info(self) -> Dict[str, Any]:
        """Retorna informações do Basic Provider."""
        base_info = self.get_statistics()
        
        basic_info = {
            "model": "basic-fallback-v1",
            "always_available": True,
            "never_fails": True,
            "response_delay": self.response_delay,
            "fallback_provider": True,
            "guaranteed_uptime": "100%",
            "response_type": "structured_basic"
        }
        
        base_info.update(basic_info)
        return base_info

