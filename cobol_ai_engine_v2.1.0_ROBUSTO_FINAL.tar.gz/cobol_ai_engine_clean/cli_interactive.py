#!/usr/bin/env python3
"""
COBOL AI Engine v2.0.0 - CLI Interativo
Interface de linha de comando interativa e amigável.
"""

import os
import sys
import argparse
import json
import logging
from pathlib import Path
from typing import List, Dict, Any

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser import COBOLParser
from src.generators.documentation_generator import DocumentationGenerator
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer


class InteractiveCLI:
    """Interface de linha de comando interativa."""
    
    def __init__(self):
        self.config_manager = None
        self.provider_manager = None
        self.parser = None
        self.doc_generator = None
        self.analyzer = None
        self.current_provider = "luzia"
        
    def show_banner(self):
        """Exibe banner do sistema."""
        print("=" * 60)
        print("    COBOL AI Engine v2.0.0 - Interface Interativa")
        print("=" * 60)
        print()
    
    def show_menu(self):
        """Exibe menu principal."""
        print("Opções Disponíveis:")
        print("1. Analisar código COBOL (digitar/colar)")
        print("2. Analisar arquivo COBOL")
        print("3. Analisar múltiplos arquivos")
        print("4. Ver status dos provedores")
        print("5. Configurar provedor de IA")
        print("6. Ajuda e exemplos")
        print("0. Sair")
        print()
    
    def initialize_analyzer(self):
        """Inicializa o analisador se necessário."""
        if self.config_manager is None:
            try:
                print("🔄 Inicializando sistema...")
                self.config_manager = ConfigManager()
                self.provider_manager = EnhancedProviderManager(self.config_manager.config)
                self.parser = COBOLParser()
                self.doc_generator = DocumentationGenerator("output_cli")
                self.analyzer = EnhancedCOBOLAnalyzer()
                print("✅ Sistema inicializado com sucesso!")
                return True
            except Exception as e:
                print(f"❌ Erro ao inicializar sistema: {e}")
                return False
        return True
    
    def analyze_code_input(self):
        """Analisa código COBOL digitado pelo usuário."""
        if not self.initialize_analyzer():
            return
        
        print("\n--- Análise de Código COBOL ---")
        print("Digite ou cole seu código COBOL abaixo.")
        print("Para finalizar, digite uma linha contendo apenas 'END' e pressione Enter:")
        print()
        
        lines = []
        while True:
            try:
                line = input()
                if line.strip().upper() == 'END':
                    break
                lines.append(line)
            except KeyboardInterrupt:
                print("\n❌ Operação cancelada.")
                return
        
        if not lines:
            print("❌ Nenhum código fornecido.")
            return
        
        code = '\n'.join(lines)
        program_name = input("\nNome do programa (opcional): ").strip() or "PROGRAMA_CLI"
        
        print(f"\n🔄 Analisando programa {program_name}...")
        
        try:
            # Parse do código
            program = self.parser.parse_program(program_name, code)
            
            # Análise com IA
            provider = self.provider_manager.get_provider(self.current_provider)
            if not provider or not provider.is_available():
                print(f"❌ Provedor {self.current_provider} não disponível")
                return
            
            result = self.analyzer.analyze_program(program, {}, provider)
            
            if result['success']:
                # Gerar documentação
                filepath = self.doc_generator.generate_program_documentation(
                    program, result['ai_response']
                )
                print(f"✅ Análise concluída!")
                print(f"📄 Relatório salvo em: {filepath}")
                
                # Mostrar resumo
                print(f"\n--- Resumo da Análise ---")
                print(f"Programa: {program_name}")
                print(f"Linhas de código: {program.line_count}")
                print(f"Tokens utilizados: {result['ai_response'].tokens_used}")
                print(f"Provedor: {result['ai_response'].provider}")
                
            else:
                print(f"❌ Falha na análise: {result.get('error', 'Erro desconhecido')}")
                
        except Exception as e:
            print(f"❌ Erro durante análise: {e}")
    
    def analyze_file(self):
        """Analisa arquivo COBOL."""
        if not self.initialize_analyzer():
            return
        
        print("\n--- Análise de Arquivo COBOL ---")
        filepath = input("Caminho do arquivo COBOL: ").strip()
        
        if not filepath or not os.path.exists(filepath):
            print("❌ Arquivo não encontrado.")
            return
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                code = f.read()
            
            program_name = Path(filepath).stem
            print(f"\n🔄 Analisando arquivo {filepath}...")
            
            # Parse do código
            program = self.parser.parse_program(program_name, code)
            
            # Análise com IA
            provider = self.provider_manager.get_provider(self.current_provider)
            if not provider or not provider.is_available():
                print(f"❌ Provedor {self.current_provider} não disponível")
                return
            
            result = self.analyzer.analyze_program(program, {}, provider)
            
            if result['success']:
                # Gerar documentação
                doc_filepath = self.doc_generator.generate_program_documentation(
                    program, result['ai_response']
                )
                print(f"✅ Análise concluída!")
                print(f"📄 Relatório salvo em: {doc_filepath}")
                
                # Mostrar resumo
                print(f"\n--- Resumo da Análise ---")
                print(f"Arquivo: {filepath}")
                print(f"Programa: {program_name}")
                print(f"Linhas de código: {program.line_count}")
                print(f"Tokens utilizados: {result['ai_response'].tokens_used}")
                print(f"Provedor: {result['ai_response'].provider}")
                
            else:
                print(f"❌ Falha na análise: {result.get('error', 'Erro desconhecido')}")
                
        except Exception as e:
            print(f"❌ Erro ao processar arquivo: {e}")
    
    def analyze_multiple_files(self):
        """Analisa múltiplos arquivos COBOL."""
        if not self.initialize_analyzer():
            return
        
        print("\n--- Análise de Múltiplos Arquivos ---")
        print("Digite os caminhos dos arquivos, um por linha.")
        print("Para finalizar, digite uma linha contendo apenas 'END':")
        print()
        
        filepaths = []
        while True:
            try:
                filepath = input("Arquivo: ").strip()
                if filepath.upper() == 'END':
                    break
                if filepath and os.path.exists(filepath):
                    filepaths.append(filepath)
                    print(f"✅ {filepath}")
                elif filepath:
                    print(f"❌ Arquivo não encontrado: {filepath}")
            except KeyboardInterrupt:
                print("\n❌ Operação cancelada.")
                return
        
        if not filepaths:
            print("❌ Nenhum arquivo válido fornecido.")
            return
        
        print(f"\n🔄 Analisando {len(filepaths)} arquivo(s)...")
        
        successful = 0
        failed = 0
        
        for i, filepath in enumerate(filepaths, 1):
            try:
                print(f"\n[{i}/{len(filepaths)}] Processando {filepath}...")
                
                with open(filepath, 'r', encoding='utf-8') as f:
                    code = f.read()
                
                program_name = Path(filepath).stem
                
                # Parse do código
                program = self.parser.parse_program(program_name, code)
                
                # Análise com IA
                provider = self.provider_manager.get_provider(self.current_provider)
                if not provider or not provider.is_available():
                    print(f"❌ Provedor {self.current_provider} não disponível")
                    failed += 1
                    continue
                
                result = self.analyzer.analyze_program(program, {}, provider)
                
                if result['success']:
                    # Gerar documentação
                    doc_filepath = self.doc_generator.generate_program_documentation(
                        program, result['ai_response']
                    )
                    print(f"✅ Concluído: {doc_filepath}")
                    successful += 1
                else:
                    print(f"❌ Falha: {result.get('error', 'Erro desconhecido')}")
                    failed += 1
                    
            except Exception as e:
                print(f"❌ Erro: {e}")
                failed += 1
        
        print(f"\n--- Resumo Final ---")
        print(f"✅ Sucessos: {successful}")
        print(f"❌ Falhas: {failed}")
        print(f"📁 Relatórios em: output_cli/")
    
    def show_provider_status(self):
        """Mostra status dos provedores."""
        if not self.initialize_analyzer():
            return
        
        print("\n--- Status dos Provedores ---")
        
        providers = self.provider_manager.get_available_providers()
        
        if not providers:
            print("❌ Nenhum provedor disponível.")
            return
        
        for provider_name in providers:
            provider = self.provider_manager.get_provider(provider_name)
            if provider:
                status = "✅ Disponível" if provider.is_available() else "❌ Indisponível"
                current = " (ATUAL)" if provider_name == self.current_provider else ""
                print(f"{provider_name}: {status}{current}")
    
    def configure_provider(self):
        """Configura provedor de IA."""
        if not self.initialize_analyzer():
            return
        
        print("\n--- Configuração de Provedor ---")
        
        providers = self.provider_manager.get_available_providers()
        
        if not providers:
            print("❌ Nenhum provedor disponível.")
            return
        
        print("Provedores disponíveis:")
        for i, provider_name in enumerate(providers, 1):
            current = " (ATUAL)" if provider_name == self.current_provider else ""
            print(f"{i}. {provider_name}{current}")
        
        try:
            choice = input("\nEscolha um provedor (número): ").strip()
            if choice.isdigit():
                idx = int(choice) - 1
                if 0 <= idx < len(providers):
                    self.current_provider = providers[idx]
                    print(f"✅ Provedor alterado para: {self.current_provider}")
                else:
                    print("❌ Opção inválida.")
            else:
                print("❌ Digite um número válido.")
        except KeyboardInterrupt:
            print("\n❌ Operação cancelada.")
    
    def show_help(self):
        """Mostra ajuda e exemplos."""
        print("\n--- Ajuda e Exemplos ---")
        print()
        print("🔧 CONFIGURAÇÃO INICIAL:")
        print("Antes de usar, configure as variáveis de ambiente:")
        print("export LUZIA_CLIENT_ID='seu_client_id'")
        print("export LUZIA_CLIENT_SECRET='seu_client_secret'")
        print()
        print("📝 EXEMPLO DE CÓDIGO COBOL:")
        print("IDENTIFICATION DIVISION.")
        print("PROGRAM-ID. EXEMPLO.")
        print("DATA DIVISION.")
        print("WORKING-STORAGE SECTION.")
        print("01 WS-CONTADOR PIC 9(3) VALUE 0.")
        print("PROCEDURE DIVISION.")
        print("INICIO.")
        print("    DISPLAY 'HELLO WORLD'.")
        print("    STOP RUN.")
        print("END")
        print()
        print("💡 DICAS:")
        print("- Use a opção 1 para testar códigos pequenos")
        print("- Use a opção 2 para arquivos individuais")
        print("- Use a opção 3 para processar vários arquivos")
        print("- Verifique o status dos provedores na opção 4")
        print("- Os relatórios são salvos na pasta 'output_cli/'")
    
    def run(self):
        """Executa o CLI interativo."""
        self.show_banner()
        
        while True:
            self.show_menu()
            
            try:
                choice = input("Escolha uma opção: ").strip()
                
                if choice == '0':
                    print("👋 Até logo!")
                    break
                elif choice == '1':
                    self.analyze_code_input()
                elif choice == '2':
                    self.analyze_file()
                elif choice == '3':
                    self.analyze_multiple_files()
                elif choice == '4':
                    self.show_provider_status()
                elif choice == '5':
                    self.configure_provider()
                elif choice == '6':
                    self.show_help()
                else:
                    print("❌ Opção inválida. Tente novamente.")
                
                if choice != '0':
                    input("\nPressione Enter para continuar...")
                    print()
                    
            except KeyboardInterrupt:
                print("\n\n👋 Até logo!")
                break
            except Exception as e:
                print(f"\n❌ Erro inesperado: {e}")
                input("Pressione Enter para continuar...")


def main():
    """Função principal."""
    parser = argparse.ArgumentParser(description='COBOL AI Engine v2.0.0 - CLI Interativo')
    parser.add_argument('--log', default='INFO', help='Nível de log (DEBUG, INFO, WARNING, ERROR)')
    
    args = parser.parse_args()
    
    # Configurar logging
    logging.basicConfig(
        level=getattr(logging, args.log.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Executar CLI
    cli = InteractiveCLI()
    cli.run()


if __name__ == "__main__":
    main()
