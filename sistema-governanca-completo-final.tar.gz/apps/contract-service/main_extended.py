#!/usr/bin/env python3
"""
Contract Service - Versão Estendida com Integração Databricks
Microserviço para gestão de contratos de dados com integração nativa ao Databricks
"""

import os
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Depends, BackgroundTasks, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import asyncpg
from redis import Redis

# Importa extensões Databricks
from databricks_extensions import DatabricksContractExtensions, DatabricksTableMapping

# Configuração de logging
logging.basicConfig(
 level=logging.INFO,
 format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Models Pydantic
class ContractBase(BaseModel):
    pass
 """Modelo base para contratos"""
 name: str = Field(..., description="Nome do contrato")
 version: str = Field(default="1.0.0", description="Versão do contrato")
 description: Optional[str] = Field(default=None, description="Descrição do contrato")
 owner: Optional[str] = Field(default=None, description="Proprietário do contrato")
 tags: Optional[List[str]] = Field(default=[], description="Tags do contrato")

class ContractCreate(ContractBase):
    pass
 """Modelo para criação de contrato"""
 schema: Optional[Dict[str, Any]] = Field(default=None, description="Schema dos dados")
 quality_rules: Optional[List[Dict[str, Any]]] = Field(default=[], description="Regras de qualidade")
 business_rules: Optional[List[Dict[str, Any]]] = Field(default=[], description="Regras de negócio")

class DatabricksContractCreate(ContractCreate):
    pass
 """Modelo para criação de contrato com integração Databricks"""
 databricks_mapping: Dict[str, Any] = Field(..., description="Configuração do mapeamento Databricks")

class ContractUpdate(BaseModel):
    pass
 """Modelo para atualização de contrato"""
 name: Optional[str] = Field(default=None, description="Nome do contrato")
 description: Optional[str] = Field(default=None, description="Descrição do contrato")
 owner: Optional[str] = Field(default=None, description="Proprietário do contrato")
 tags: Optional[List[str]] = Field(default=None, description="Tags do contrato")
 status: Optional[str] = Field(default=None, description="Status do contrato")

class ContractResponse(ContractBase):
    pass
 """Modelo de resposta para contratos"""
 id: str = Field(..., description="ID único do contrato")
 status: str = Field(..., description="Status do contrato")
 created_at: datetime = Field(..., description="Data de criação")
 updated_at: datetime = Field(..., description="Data de atualização")
 databricks_integration: Optional[Dict[str, Any]] = Field(default=None, description="Informações da integração Databricks")

class SyncRequest(BaseModel):
    pass
 """Requisição de sincronização com Databricks"""
 contract_id: str = Field(..., description="ID do contrato")
 sync_type: str = Field(default="all", description="Tipo de sincronização (classifications, monitors, all)")

# Serviço principal
class ExtendedContractService:
    pass
 """Contract Service estendido com integração Databricks"""
 
 def __init__(self):
    pass
 self.db_pool = None
 self.redis_client = None
 self.databricks_extensions = None
 self.logger = logging.getLogger(f"{__name__}.ExtendedContractService")
 
 async def initialize(self):
    pass
 """Inicializa conexões e extensões"""
 try:
    pass
 # Conexão com PostgreSQL
 self.db_pool = await asyncpg.create_pool(
 host=os.getenv("DB_HOST", "localhost"),
 port=int(os.getenv("DB_PORT", "5432")),
 user=os.getenv("DB_USER", "governance_user"),
 password=os.getenv("DB_PASSWORD", "governance_pass"),
 database=os.getenv("DB_NAME", "governance_db"),
 min_size=2,
 max_size=10
 )
 
 # Conexão com Redis
 self.redis_client = Redis(
 host=os.getenv("REDIS_HOST", "localhost"),
 port=int(os.getenv("REDIS_PORT", "6379")),
 decode_responses=True
 )
 
 # Inicializa extensões Databricks
 databricks_service_url = os.getenv("DATABRICKS_SERVICE_URL", "http://localhost:8010")
 self.databricks_extensions = DatabricksContractExtensions(
 self.db_pool, 
 databricks_service_url
 )
 
 self.logger.info("Extended Contract Service initialized successfully")
 
 except Exception as e:
    pass
 self.logger.error(f"Failed to initialize service: {e}")
 raise
 
 async def cleanup(self):
    pass
 """Limpa recursos"""
 if self.databricks_extensions:
    pass
 await self.databricks_extensions.cleanup()
 if self.db_pool:
    pass
 await self.db_pool.close()
 if self.redis_client:
    pass
 self.redis_client.close()
 
 async def create_contract(self, contract_data: ContractCreate) -> ContractResponse:
    pass
 """Cria contrato padrão"""
 self.logger.info(f"Creating standard contract: {contract_data.name}")
 
 try:
    pass
 contract_id = f"contract_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
 
 async with self.db_pool.acquire() as conn:
    pass
 await conn.execute("""
 INSERT INTO contracts (id, name, version, status, data, created_at, updated_at)
 VALUES ($1, $2, $3, $4, $5, $6, $7)
 """,
 contract_id,
 contract_data.name,
 contract_data.version,
 "active",
 str(contract_data.dict()), # JSON como string
 datetime.now(),
 datetime.now()
 )
 
 # Cache do contrato
 cache_key = f"contract:{contract_id}"
 self.redis_client.setex(cache_key, 3600, str(contract_data.dict()))
 
 return ContractResponse(
 id=contract_id,
 name=contract_data.name,
 version=contract_data.version,
 description=contract_data.description,
 owner=contract_data.owner,
 tags=contract_data.tags or [],
 status="active",
 created_at=datetime.now(),
 updated_at=datetime.now()
 )
 
 except Exception as e:
    pass
 self.logger.error(f"Failed to create contract: {e}")
 raise HTTPException(
 status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
 detail=f"Contract creation failed: {str(e)}"
 )
 
 async def create_databricks_contract(self, contract_data: DatabricksContractCreate) -> Dict[str, Any]:
    pass
 """Cria contrato com integração Databricks"""
 self.logger.info(f"Creating Databricks contract: {contract_data.name}")
 
 try:
    pass
 # Cria mapeamento Databricks
 mapping_data = contract_data.databricks_mapping
 databricks_mapping = DatabricksTableMapping(
 contract_id="", # Será preenchido após criação
 catalog_name=mapping_data["catalog_name"],
 schema_name=mapping_data["schema_name"],
 table_name=mapping_data["table_name"],
 mapping_type=mapping_data.get("mapping_type", "direct"),
 sync_enabled=mapping_data.get("sync_enabled", True),
 auto_update_classifications=mapping_data.get("auto_update_classifications", True),
 auto_create_monitors=mapping_data.get("auto_create_monitors", True)
 )
 
 # Cria contrato com integração Databricks
 result = await self.databricks_extensions.create_contract_with_databricks_mapping(
 contract_data.dict(exclude={"databricks_mapping"}),
 databricks_mapping
 )
 
 return result
 
 except Exception as e:
    pass
 self.logger.error(f"Failed to create Databricks contract: {e}")
 raise HTTPException(
 status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
 detail=f"Databricks contract creation failed: {str(e)}"
 )
 
 async def get_contract(self, contract_id: str) -> ContractResponse:
    pass
 """Busca contrato por ID"""
 try:
    pass
 # Tenta cache primeiro
 cache_key = f"contract:{contract_id}"
 cached_data = self.redis_client.get(cache_key)
 
 if cached_data:
    pass
 # Em produção, usar json.loads
 contract_data = eval(cached_data)
 return ContractResponse(**contract_data, id=contract_id)
 
 # Busca no banco
 async with self.db_pool.acquire() as conn:
    pass
 row = await conn.fetchrow("""
 SELECT * FROM contracts WHERE id = $1
 """, contract_id)
 
 if not row:
    pass
 raise HTTPException(
 status_code=status.HTTP_404_NOT_FOUND,
 detail=f"Contract {contract_id} not found"
 )
 
 # Busca status Databricks se aplicável
 databricks_status = None
 try:
    pass
 databricks_status = await self.databricks_extensions.get_contract_databricks_status(contract_id)
 if databricks_status.get("databricks_integration"):
    pass
 databricks_status = databricks_status
 else:
    pass
 databricks_status = None
 except:
    pass
 databricks_status = None
 
 return ContractResponse(
 id=row["id"],
 name=row["name"],
 version=row["version"],
 description=None, # Extrair do JSON data se necessário
 owner=None, # Extrair do JSON data se necessário
 tags=[], # Extrair do JSON data se necessário
 status=row["status"],
 created_at=row["created_at"],
 updated_at=row["updated_at"],
 databricks_integration=databricks_status
 )
 
 except HTTPException:
    pass
 raise
 except Exception as e:
    pass
 self.logger.error(f"Failed to get contract {contract_id}: {e}")
 raise HTTPException(
 status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
 detail=f"Failed to get contract: {str(e)}"
 )
 
 async def list_contracts(self, limit: int = 50, offset: int = 0) -> Dict[str, Any]:
    pass
 """Lista contratos"""
 try:
    pass
 async with self.db_pool.acquire() as conn:
    pass
 # Conta total
 total = await conn.fetchval("SELECT COUNT(*) FROM contracts")
 
 # Busca contratos
 rows = await conn.fetch("""
 SELECT * FROM contracts 
 ORDER BY updated_at DESC 
 LIMIT $1 OFFSET $2
 """, limit, offset)
 
 contracts = []
 for row in rows:
    pass
 contracts.append({
 "id": row["id"],
 "name": row["name"],
 "version": row["version"],
 "status": row["status"],
 "created_at": row["created_at"].isoformat(),
 "updated_at": row["updated_at"].isoformat()
 })
 
 return {
 "contracts": contracts,
 "total": total,
 "limit": limit,
 "offset": offset,
 "has_more": (offset + limit) < total
 }
 
 except Exception as e:
    pass
 self.logger.error(f"Failed to list contracts: {e}")
 raise HTTPException(
 status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
 detail=f"Failed to list contracts: {str(e)}"
 )
 
 async def sync_contract_with_databricks(self, sync_request: SyncRequest) -> Dict[str, Any]:
    pass
 """Sincroniza contrato com Databricks"""
 return await self.databricks_extensions.sync_contract_with_databricks(sync_request.contract_id)
 
 async def list_databricks_contracts(self) -> List[Dict[str, Any]]:
    pass
 """Lista contratos com integração Databricks"""
 return await self.databricks_extensions.list_contracts_with_databricks_integration()

# Instância global do serviço
service = ExtendedContractService()

@asynccontextmanager
async def lifespan(app: FastAPI):
    pass
 """Gerencia ciclo de vida da aplicação"""
 # Startup
 await service.initialize()
 yield
 # Shutdown
 await service.cleanup()

# Configuração da aplicação FastAPI
app = FastAPI(
 title="Contract Service - Extended",
 description="Microserviço para gestão de contratos de dados com integração Databricks",
 version="2.0.0",
 lifespan=lifespan
)

# Middleware CORS
app.add_middleware(
 CORSMiddleware,
 allow_origins=["*"],
 allow_credentials=True,
 allow_methods=["*"],
 allow_headers=["*"],
)

# Endpoints de Health Check
@app.get("/health", tags=["Health"])
async def health_check():
    pass
 """Health check endpoint"""
 return {
 "status": "healthy",
 "service": "contract-service-extended",
 "timestamp": datetime.now().isoformat(),
 "version": "2.0.0",
 "databricks_integration": True
 }

# Endpoints de Contratos Padrão
@app.post("/api/v1/contracts", response_model=ContractResponse, tags=["Contracts"])
async def create_contract(contract_data: ContractCreate):
    pass
 """Cria contrato padrão"""
 return await service.create_contract(contract_data)

@app.get("/api/v1/contracts/{contract_id}", response_model=ContractResponse, tags=["Contracts"])
async def get_contract(contract_id: str):
    pass
 """Busca contrato por ID"""
 return await service.get_contract(contract_id)

@app.get("/api/v1/contracts", tags=["Contracts"])
async def list_contracts(limit: int = 50, offset: int = 0):
    pass
 """Lista contratos"""
 return await service.list_contracts(limit, offset)

# Endpoints de Integração Databricks
@app.post("/api/v1/contracts/databricks", tags=["Databricks Integration"])
async def create_databricks_contract(contract_data: DatabricksContractCreate):
    pass
 """Cria contrato com integração Databricks"""
 return await service.create_databricks_contract(contract_data)

@app.post("/api/v1/contracts/databricks/sync", tags=["Databricks Integration"])
async def sync_contract_with_databricks(sync_request: SyncRequest):
    pass
 """Sincroniza contrato com Databricks"""
 return await service.sync_contract_with_databricks(sync_request)

@app.get("/api/v1/contracts/{contract_id}/databricks/status", tags=["Databricks Integration"])
async def get_contract_databricks_status(contract_id: str):
    pass
 """Obtém status da integração Databricks"""
 return await service.databricks_extensions.get_contract_databricks_status(contract_id)

@app.get("/api/v1/contracts/databricks/list", tags=["Databricks Integration"])
async def list_databricks_contracts():
    pass
 """Lista contratos com integração Databricks"""
 return await service.list_databricks_contracts()

# Endpoints de Classificações
@app.get("/api/v1/contracts/{contract_id}/classifications", tags=["Classifications"])
async def get_contract_classifications(contract_id: str):
    pass
 """Obtém classificações de um contrato"""
 try:
    pass
 classifications = await service.databricks_extensions._get_contract_classifications(contract_id)
 return {
 "contract_id": contract_id,
 "classifications": classifications,
 "count": len(classifications),
 "timestamp": datetime.now().isoformat()
 }
 except Exception as e:
    pass
 raise HTTPException(
 status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
 detail=f"Failed to get classifications: {str(e)}"
 )

# Endpoints de Monitoramento de Qualidade
@app.get("/api/v1/contracts/{contract_id}/quality/monitors", tags=["Quality Monitoring"])
async def get_contract_quality_monitors(contract_id: str):
    pass
 """Obtém monitores de qualidade de um contrato"""
 try:
    pass
 monitors = await service.databricks_extensions._get_contract_quality_monitors(contract_id)
 return {
 "contract_id": contract_id,
 "monitors": monitors,
 "count": len(monitors),
 "timestamp": datetime.now().isoformat()
 }
 except Exception as e:
    pass
 raise HTTPException(
 status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
 detail=f"Failed to get quality monitors: {str(e)}"
 )

if __name__ == "__main__":
    pass
 import uvicorn
 
 port = int(os.getenv("PORT", "8011"))
 uvicorn.run(
 "main_extended:app",
 host="0.0.0.0",
 port=port,
 reload=True,
 log_level="info"
 )

