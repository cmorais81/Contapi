#!/bin/bash

echo "=========================================="
echo "COBOL Analyzer v4.0 - Teste Completo"
echo "=========================================="

# Verificar arquivos necessários
echo "1. Verificando arquivos necessários..."
if [ ! -f "fontes.txt" ]; then
    echo "❌ Arquivo fontes.txt não encontrado"
    exit 1
fi

if [ ! -f "BOOKS.txt" ]; then
    echo "❌ Arquivo BOOKS.txt não encontrado"
    exit 1
fi

if [ ! -f "minato_promt.txt" ]; then
    echo "❌ Arquivo minato_promt.txt não encontrado"
    exit 1
fi

echo "✅ Todos os arquivos necessários encontrados"

# Teste 1: Sem prompt customizado
echo ""
echo "2. Executando teste sem prompt customizado..."
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --books BOOKS.txt --output teste_padrao
if [ $? -eq 0 ]; then
    echo "✅ Teste padrão executado com sucesso"
else
    echo "❌ Falha no teste padrão"
fi

# Teste 2: Com prompt customizado
echo ""
echo "3. Executando teste com prompt customizado..."
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --books BOOKS.txt --custom-prompt minato_promt.txt --output teste_customizado
if [ $? -eq 0 ]; then
    echo "✅ Teste com prompt customizado executado com sucesso"
else
    echo "❌ Falha no teste com prompt customizado"
fi

# Verificar estrutura de saída
echo ""
echo "4. Verificando estrutura de saída..."
if [ -d "teste_padrao/model_enhanced_mock" ]; then
    echo "✅ Estrutura de modelo criada (teste padrão)"
else
    echo "❌ Estrutura de modelo não criada (teste padrão)"
fi

if [ -d "teste_customizado/model_enhanced_mock" ]; then
    echo "✅ Estrutura de modelo criada (teste customizado)"
else
    echo "❌ Estrutura de modelo não criada (teste customizado)"
fi

# Contar programas processados
echo ""
echo "5. Contando programas processados..."
PROGRAMAS_PADRAO=$(find teste_padrao -name "*_analise_funcional.md" | wc -l)
PROGRAMAS_CUSTOM=$(find teste_customizado -name "*_analise_funcional.md" | wc -l)

echo "📊 Programas processados (padrão): $PROGRAMAS_PADRAO/5"
echo "📊 Programas processados (customizado): $PROGRAMAS_CUSTOM/5"

# Verificar arquivos de request/response
echo ""
echo "6. Verificando arquivos de request/response..."
REQUESTS_PADRAO=$(find teste_padrao -name "*_ai_request.json" | wc -l)
RESPONSES_PADRAO=$(find teste_padrao -name "*_ai_response.json" | wc -l)
REQUESTS_CUSTOM=$(find teste_customizado -name "*_ai_request.json" | wc -l)
RESPONSES_CUSTOM=$(find teste_customizado -name "*_ai_response.json" | wc -l)

echo "📁 Requests (padrão): $REQUESTS_PADRAO"
echo "📁 Responses (padrão): $RESPONSES_PADRAO"
echo "📁 Requests (customizado): $REQUESTS_CUSTOM"
echo "📁 Responses (customizado): $RESPONSES_CUSTOM"

# Teste de status
echo ""
echo "7. Testando comando de status..."
python3 cobol_to_docs/runner/main.py --status
if [ $? -eq 0 ]; then
    echo "✅ Comando de status funcionando"
else
    echo "❌ Falha no comando de status"
fi

echo ""
echo "=========================================="
echo "TESTE COMPLETO FINALIZADO"
echo "=========================================="
echo "📁 Resultados salvos em:"
echo "   - teste_padrao/"
echo "   - teste_customizado/"
echo ""
echo "Para visualizar a estrutura:"
echo "   tree teste_padrao"
echo "   tree teste_customizado"
