#!/bin/bash

echo "=========================================="
echo "COBOL Analyzer v4.0 - Teste Completo Final"
echo "=========================================="

# Verificar arquivos necessários
echo "1. Verificando arquivos necessários..."
if [ ! -f "fontes.txt" ]; then
    echo "❌ Arquivo fontes.txt não encontrado"
    exit 1
fi

if [ ! -f "BOOKS.txt" ]; then
    echo "❌ Arquivo BOOKS.txt não encontrado"
    exit 1
fi

if [ ! -f "config/prompts_minato.yaml" ]; then
    echo "❌ Arquivo config/prompts_minato.yaml não encontrado"
    exit 1
fi

echo "✅ Todos os arquivos necessários encontrados"

# Teste 1: Sem prompt customizado (padrão)
echo ""
echo "2. Executando teste padrão (sem prompt customizado)..."
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --books BOOKS.txt --output teste_padrao
if [ $? -eq 0 ]; then
    echo "✅ Teste padrão executado com sucesso"
else
    echo "❌ Falha no teste padrão"
fi

# Teste 2: Com prompt YAML Minato
echo ""
echo "3. Executando teste com prompt YAML Minato..."
python3 cobol_to_docs/runner/main.py --fontes fontes.txt --books BOOKS.txt --prompts-yaml config/prompts_minato.yaml --output teste_yaml_minato
if [ $? -eq 0 ]; then
    echo "✅ Teste com prompt YAML Minato executado com sucesso"
else
    echo "❌ Falha no teste com prompt YAML Minato"
fi

# Teste 3: Com prompt TXT (se existir)
echo ""
echo "4. Executando teste com prompt TXT (se disponível)..."
if [ -f "minato_promt.txt" ]; then
    python3 cobol_to_docs/runner/main.py --fontes fontes.txt --books BOOKS.txt --custom-prompt minato_promt.txt --output teste_txt_customizado
    if [ $? -eq 0 ]; then
        echo "✅ Teste com prompt TXT executado com sucesso"
    else
        echo "❌ Falha no teste com prompt TXT"
    fi
else
    echo "⚠️  Arquivo minato_promt.txt não encontrado - pulando teste TXT"
fi

# Verificar estrutura de saída
echo ""
echo "5. Verificando estrutura de saída..."

# Verificar teste padrão
if [ -d "teste_padrao/model_enhanced_mock" ]; then
    echo "✅ Estrutura de modelo criada (teste padrão)"
    ARQUIVOS_PADRAO=$(find teste_padrao -name "*.md" | wc -l)
    echo "   📄 Arquivos MD gerados: $ARQUIVOS_PADRAO"
else
    echo "❌ Estrutura de modelo não criada (teste padrão)"
fi

# Verificar teste YAML
if [ -d "teste_yaml_minato/model_enhanced_mock" ]; then
    echo "✅ Estrutura de modelo criada (teste YAML Minato)"
    ARQUIVOS_YAML=$(find teste_yaml_minato -name "*.md" | wc -l)
    echo "   📄 Arquivos MD gerados: $ARQUIVOS_YAML"
else
    echo "❌ Estrutura de modelo não criada (teste YAML Minato)"
fi

# Verificar teste TXT
if [ -d "teste_txt_customizado/model_enhanced_mock" ]; then
    echo "✅ Estrutura de modelo criada (teste TXT customizado)"
    ARQUIVOS_TXT=$(find teste_txt_customizado -name "*.md" | wc -l)
    echo "   📄 Arquivos MD gerados: $ARQUIVOS_TXT"
fi

# Contar programas processados
echo ""
echo "6. Contando programas processados..."
PROGRAMAS_PADRAO=$(find teste_padrao -name "*_analise_funcional.md" 2>/dev/null | wc -l)
PROGRAMAS_YAML=$(find teste_yaml_minato -name "*_analise_funcional.md" 2>/dev/null | wc -l)
PROGRAMAS_TXT=$(find teste_txt_customizado -name "*_analise_funcional.md" 2>/dev/null | wc -l)

echo "📊 Programas processados (padrão): $PROGRAMAS_PADRAO/5"
echo "📊 Programas processados (YAML Minato): $PROGRAMAS_YAML/5"
if [ -d "teste_txt_customizado" ]; then
    echo "📊 Programas processados (TXT customizado): $PROGRAMAS_TXT/5"
fi

# Verificar arquivos de request/response
echo ""
echo "7. Verificando arquivos de request/response..."
REQUESTS_PADRAO=$(find teste_padrao -name "*_ai_request.json" 2>/dev/null | wc -l)
RESPONSES_PADRAO=$(find teste_padrao -name "*_ai_response.json" 2>/dev/null | wc -l)
REQUESTS_YAML=$(find teste_yaml_minato -name "*_ai_request.json" 2>/dev/null | wc -l)
RESPONSES_YAML=$(find teste_yaml_minato -name "*_ai_response.json" 2>/dev/null | wc -l)

echo "📁 Requests (padrão): $REQUESTS_PADRAO"
echo "📁 Responses (padrão): $RESPONSES_PADRAO"
echo "📁 Requests (YAML Minato): $REQUESTS_YAML"
echo "📁 Responses (YAML Minato): $RESPONSES_YAML"

# Verificar diferenças entre prompts
echo ""
echo "8. Verificando aplicação do prompt YAML..."
if [ -f "teste_yaml_minato/model_enhanced_mock/ai_requests/LHAN0542_ai_request.json" ]; then
    YAML_PROMPT_CHECK=$(grep -c "BIAN\|Componentes Reutilizáveis\|componentização" teste_yaml_minato/model_enhanced_mock/ai_requests/LHAN0542_ai_request.json)
    if [ $YAML_PROMPT_CHECK -gt 0 ]; then
        echo "✅ Prompt YAML Minato aplicado corretamente (encontradas $YAML_PROMPT_CHECK referências)"
    else
        echo "⚠️  Prompt YAML pode não ter sido aplicado completamente"
    fi
fi

# Teste de status
echo ""
echo "9. Testando comando de status..."
python3 cobol_to_docs/runner/main.py --status
if [ $? -eq 0 ]; then
    echo "✅ Comando de status funcionando"
else
    echo "❌ Falha no comando de status"
fi

echo ""
echo "=========================================="
echo "TESTE COMPLETO FINALIZADO"
echo "=========================================="
echo "📁 Resultados salvos em:"
echo "   - teste_padrao/ (prompt padrão)"
echo "   - teste_yaml_minato/ (prompt YAML Minato)"
if [ -d "teste_txt_customizado" ]; then
    echo "   - teste_txt_customizado/ (prompt TXT)"
fi
echo ""
echo "🔍 Para visualizar a estrutura:"
echo "   tree teste_padrao"
echo "   tree teste_yaml_minato"
echo ""
echo "📋 Para verificar o conteúdo dos prompts:"
echo "   cat teste_yaml_minato/model_enhanced_mock/ai_requests/LHAN0542_ai_request.json | jq '.prompts_sent.custom_prompt_content' | head -20"
