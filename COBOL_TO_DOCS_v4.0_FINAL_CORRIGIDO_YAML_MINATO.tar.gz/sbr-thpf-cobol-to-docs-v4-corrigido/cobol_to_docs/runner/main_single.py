#!/usr/bin/env python3
"""
COBOL to Docs v4.0 - Sistema de Análise e Documentação de Programas COBOL
Sistema completo para análise automatizada de programas COBOL com IA.

FUNCIONALIDADES:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA com fallback
- Análise de copybooks complementares
- Sistema RAG para contexto expandido
- Modo padrão avançado automático
- Geração de documentação profissional
- Estrutura de saída organizada por modelo
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Configurar path para imports
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, '..', 'src')
sys.path.insert(0, src_dir)

# Imports do sistema
from core.config import ConfigManager
from parsers.cobol_parser import COBOLParser
from providers.enhanced_provider_manager import EnhancedProviderManager
from rag.rag_integration import RAGIntegration
from rag.rag_maintenance import RAGMaintenance
from utils.cost_calculator import CostCalculator
from generators.advanced_report_generator import HTMLReportGenerator
from generators.documentation_generator import DocumentationGenerator
from analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from core.prompt_manager_dual import DualPromptManager
from core.intelligent_model_selector import IntelligentModelSelector
from providers.base_provider import AIRequest
from core.enhanced_prompt_manager import EnhancedPromptManager
from utils.enhanced_response_formatter import EnhancedResponseFormatter
from core.custom_prompt_manager import CustomPromptManager

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"cobol_analyzer_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=log_level.upper(),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(log_file)
        ]
    )
    logging.getLogger("urllib3").setLevel(logging.WARNING)

def create_output_structure(base_output_dir: str, program_name: str, model_name: str) -> Dict[str, str]:
    """
    Cria a estrutura de diretórios de saída seguindo o padrão original.
    
    Args:
        base_output_dir: Diretório base de saída
        program_name: Nome do programa COBOL
        model_name: Nome do modelo utilizado
        
    Returns:
        Dicionário com os caminhos dos diretórios criados
    """
    # Criar estrutura: output/model_{model_name}/
    model_dir = os.path.join(base_output_dir, f"model_{model_name.replace('.', '_').replace('-', '_')}")
    ai_requests_dir = os.path.join(model_dir, "ai_requests")
    ai_responses_dir = os.path.join(model_dir, "ai_responses")
    
    # Criar diretórios
    os.makedirs(model_dir, exist_ok=True)
    os.makedirs(ai_requests_dir, exist_ok=True)
    os.makedirs(ai_responses_dir, exist_ok=True)
    
    return {
        'model_dir': model_dir,
        'ai_requests_dir': ai_requests_dir,
        'ai_responses_dir': ai_responses_dir
    }

def save_analysis_files(program_name: str, model_name: str, response: Any, request: Any, 
                       output_dirs: Dict[str, str], custom_prompt_used: bool = False) -> None:
    """
    Salva os arquivos de análise seguindo o padrão original.
    
    Args:
        program_name: Nome do programa
        model_name: Nome do modelo
        response: Resposta do provider
        request: Request enviado
        output_dirs: Diretórios de saída
        custom_prompt_used: Se foi usado prompt customizado
    """
    # Nomes dos arquivos
    analysis_file = os.path.join(output_dirs['model_dir'], f"{program_name}_analise_funcional.md")
    request_file = os.path.join(output_dirs['ai_requests_dir'], f"{program_name}_ai_request.json")
    response_file = os.path.join(output_dirs['ai_responses_dir'], f"{program_name}_ai_response.json")
    
    # 1. Salvar análise funcional (Markdown)
    analysis_content = f"""# Análise Funcional do Programa {program_name}

**Data da análise:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Modelo utilizado:** {model_name}
**Provider:** {response.provider if hasattr(response, 'provider') else 'N/A'}
**Tokens utilizados:** {response.tokens_used if hasattr(response, 'tokens_used') else 'N/A'}
**Prompt customizado:** {'Sim' if custom_prompt_used else 'Não'}

## Resultado da Análise

{response.content if hasattr(response, 'content') else str(response)}

---
*Análise gerada pelo COBOL-to-Docs v4.0*
"""
    
    with open(analysis_file, 'w', encoding='utf-8') as f:
        f.write(analysis_content)
    
    # 2. Salvar request (JSON)
    request_data = {
        "program_name": program_name,
        "timestamp": datetime.now().isoformat(),
        "provider": response.provider if hasattr(response, 'provider') else model_name,
        "model": model_name,
        "custom_prompt_used": custom_prompt_used,
        "request_payload": {
            "prompt": request.prompt[:1000] + "..." if len(request.prompt) > 1000 else request.prompt,
            "program_code": request.program_code[:1000] + "..." if len(request.program_code) > 1000 else request.program_code,
            "program_name": request.program_name
        },
        "prompts_sent": {
            "system_prompt": request.prompt[:500] + "..." if len(request.prompt) > 500 else request.prompt,
            "original_prompt": "Prompt gerado dinamicamente",
            "main_prompt": "Prompt principal não disponível"
        },
        "headers": {},
        "endpoint": "",
        "method": "POST",
        "request_size": len(request.prompt) + len(request.program_code),
        "configuration": {
            "temperature": 0.1,
            "max_tokens": 4000,
            "timeout": 120
        }
    }
    
    with open(request_file, 'w', encoding='utf-8') as f:
        json.dump(request_data, f, indent=2, ensure_ascii=False)
    
    # 3. Salvar response (JSON)
    response_data = {
        "program_name": program_name,
        "timestamp": datetime.now().isoformat(),
        "provider": response.provider if hasattr(response, 'provider') else model_name,
        "model": model_name,
        "success": response.success if hasattr(response, 'success') else True,
        "content": response.content if hasattr(response, 'content') else str(response),
        "tokens_used": response.tokens_used if hasattr(response, 'tokens_used') else 0,
        "response_time": response.response_time if hasattr(response, 'response_time') else 0,
        "error_message": response.error_message if hasattr(response, 'error_message') else "",
        "metadata": {
            "analysis_type": "functional_analysis",
            "custom_prompt_used": custom_prompt_used,
            "timestamp": time.time()
        }
    }
    
    with open(response_file, 'w', encoding='utf-8') as f:
        json.dump(response_data, f, indent=2, ensure_ascii=False)

def main():
    """Função principal para execução do sistema."""
    parser = argparse.ArgumentParser(
        description="COBOL to Docs v4.0 - Análise e Documentação de Programas COBOL com IA",
        epilog="Exemplos de uso:\n  python3 main.py --fontes fontes.txt --books books.txt\n  python3 main.py --fontes fontes.txt --consolidado --analise-especialista\n  python3 main.py --status\n  python3 main.py --rag-stats",
        formatter_class=argparse.RawTextHelpFormatter
    )
    
    # Argumentos principais
    parser.add_argument('--fontes', type=str, help='Arquivo com lista de programas COBOL')
    parser.add_argument('--books', type=str, help='Arquivo com lista de copybooks')
    parser.add_argument('--output', type=str, default='output', help='Diretório de saída')
    parser.add_argument('--log-level', type=str, default='INFO', help='Nível de log')
    
    # Modos de análise
    parser.add_argument('--consolidado', action='store_true', help='Análise consolidada sistêmica')
    parser.add_argument('--analise-especialista', action='store_true', help='Análise especialista')
    parser.add_argument('--deep-analysis', action='store_true', help='Análise detalhada de regras')
    parser.add_argument('--relatorio-unico', action='store_true', help='Relatório único consolidado')
    parser.add_argument('--procedure-detalhada', action='store_true', help='Análise detalhada de procedures')
    parser.add_argument('--modernizacao', action='store_true', help='Análise de modernização')
    
    # Configurações
    parser.add_argument('--config-dir', type=str, help='Diretório de configuração customizado')
    parser.add_argument('--data-dir', type=str, help='Diretório de dados customizado')
    parser.add_argument('--prompts-file', type=str, help='Arquivo de prompts customizado')
    parser.add_argument('--custom-prompt', type=str, help='Arquivo de prompt customizado (.txt)')
    parser.add_argument('--prompt-set', type=str, default='especialista', help='Conjunto de prompts')
    
    # RAG
    parser.add_argument('--rag-stats', action='store_true', help='Estatísticas da base RAG')
    parser.add_argument('--rag-backup', action='store_true', help='Backup da base RAG')
    parser.add_argument('--rag-clean', action='store_true', help='Limpeza da base RAG')
    parser.add_argument('--rag-reindex', action='store_true', help='Reindexar base RAG')
    
    # Outros
    parser.add_argument('--status', action='store_true', help='Status do sistema')

    args = parser.parse_args()
    
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    config_manager = ConfigManager(args.config_dir, args.prompts_file)
    
    if args.status:
        print("Verificando status do sistema...")
        # Implementar lógica de status
        return

    if args.rag_stats or args.rag_backup or args.rag_clean or args.rag_reindex:
        rag_maintenance = RAGMaintenance(config_manager)
        if args.rag_stats:
            rag_maintenance.show_statistics()
        if args.rag_backup:
            rag_maintenance.backup_database()
        if args.rag_clean:
            rag_maintenance.clean_database()
        if args.rag_reindex:
            rag_maintenance.reindex_database()
        return

    try:
        # Verificar arquivos obrigatórios
        if not args.fontes:
            logger.error("Arquivo de fontes é obrigatório")
            print("Erro: Especifique o arquivo de fontes com --fontes")
            return
        
        if not os.path.exists(args.fontes):
            logger.error(f"Arquivo de fontes não encontrado: {args.fontes}")
            print(f"Erro: Arquivo {args.fontes} não encontrado")
            return
        
        # Criar diretório de saída
        os.makedirs(args.output, exist_ok=True)
        
        # Inicializar componentes
        provider_manager = EnhancedProviderManager(config_manager.config)
        parser = COBOLParser()
        
        # Ler conteúdo COBOL diretamente dos arquivos
        programs = []
        copybooks = []
        
        # Processar arquivo fontes.txt (contém código COBOL diretamente)
        if args.fontes and os.path.exists(args.fontes):
            try:
                with open(args.fontes, 'r', encoding='utf-8') as f:
                    cobol_content = f.read()
                
                # Extrair nome do programa do conteúdo
                program_name = "PROGRAMA"
                for line in cobol_content.split('\n'):
                    if 'PROGRAM-ID' in line.upper():
                        parts = line.upper().split('PROGRAM-ID')
                        if len(parts) > 1:
                            name_part = parts[1].strip().replace('.', '').strip()
                            if name_part:
                                program_name = name_part.split()[0] if name_part.split() else "PROGRAMA"
                        break
                    elif 'VMEMBER NAME' in line.upper():
                        parts = line.split()
                        if len(parts) >= 3:
                            program_name = parts[2].strip()
                        break
                
                class Program:
                    def __init__(self, name, content, file_path):
                        self.name = name
                        self.content = content
                        self.file_path = file_path
                
                programs.append(Program(program_name, cobol_content, args.fontes))
                logger.info(f"Programa {program_name} carregado de {args.fontes} - {len(cobol_content)} caracteres")

            except Exception as e:
                logger.error(f"Erro ao processar fontes.txt: {e}")

        # Processar arquivo BOOKS.txt (contém código COBOL diretamente)
        if args.books and os.path.exists(args.books):
            try:
                with open(args.books, 'r', encoding='utf-8') as f:
                    copybook_content = f.read()
                
                class Copybook:
                    def __init__(self, name, content):
                        self.name = name
                        self.content = content
                
                copybooks.append(Copybook("BOOKS", copybook_content))
                logger.info(f"Copybooks carregados de {args.books} - {len(copybook_content)} caracteres")

            except Exception as e:
                logger.error(f"Erro ao processar BOOKS.txt: {e}")
        else:
            logger.warning(f"Arquivo BOOKS.txt não encontrado: {args.books}")       
        
        if not programs:
            logger.error("Nenhum programa válido encontrado")
            print("Erro: Nenhum programa COBOL válido encontrado")
            return
        
        # Executar análise
        print(f"\nIniciando análise de {len(programs)} programa(s)...")
        
        start_time = time.time()
        all_results = []
        
        # Modelos configurados (usar enhanced_mock como padrão)
        models = ['enhanced_mock']
        
        # Gerenciador de prompt customizado
        custom_prompt_manager = None
        custom_prompt_used = False
        
        if args.custom_prompt:
            if os.path.exists(args.custom_prompt):
                custom_prompt_manager = CustomPromptManager(args.custom_prompt)
                custom_prompt_used = custom_prompt_manager.has_custom_prompt()
                logger.info(f"Prompt customizado carregado: {args.custom_prompt}")
            else:
                logger.error(f"Arquivo de prompt customizado não encontrado: {args.custom_prompt}")
                print(f"Erro: Arquivo de prompt customizado não encontrado: {args.custom_prompt}")
                return

        for i, program in enumerate(programs, 1):
            print(f"Analisando programa {i}/{len(programs)}: {program.name}")
            
            for model in models:
                try:
                    # Criar estrutura de saída para este modelo
                    output_dirs = create_output_structure(args.output, program.name, model)
                    
                    enhanced_prompt_manager = EnhancedPromptManager(config_manager)
                    
                    # Usar prompt customizado se disponível
                    if custom_prompt_manager and custom_prompt_used:
                        prompt = custom_prompt_manager.get_custom_prompt(program.content)
                        logger.info(f"Usando prompt customizado para {program.name}")
                    else:
                        prompt = enhanced_prompt_manager.create_complete_analysis_prompt(
                            program_name=program.name,
                            program_code=program.content,
                            copybooks=copybooks,
                            prompt_set=args.prompt_set
                        )
                        logger.info(f"Usando prompt padrão ({args.prompt_set}) para {program.name}")
                    
                    request = AIRequest(
                        prompt=prompt,
                        program_code=program.content,
                        program_name=program.name,
                        context={'model': model}
                    )
                    
                    response = provider_manager.analyze(request)
                    
                    if response.success:
                        # Salvar arquivos seguindo o padrão original
                        save_analysis_files(
                            program_name=program.name,
                            model_name=model,
                            response=response,
                            request=request,
                            output_dirs=output_dirs,
                            custom_prompt_used=custom_prompt_used
                        )
                        
                        logger.info(f"Análise salva em: {output_dirs['model_dir']}")
                        print(f"   Análise concluída - {response.tokens_used} tokens")
                        print(f"   Arquivos salvos em: model_{model.replace('.', '_').replace('-', '_')}/")
                        all_results.append(response)
                        break
                    else:
                        logger.error(f"Falha na análise com {model}: {response.error_message}")
                
                except Exception as e:
                    logger.critical(f"Erro fatal durante a análise com {model}: {e}", exc_info=True)

        end_time = time.time()
        total_time = end_time - start_time
        total_tokens = sum(r.tokens_used for r in all_results if r)
        
        print("\n============================================================")
        print("PROCESSAMENTO CONCLUÍDO")
        print(f"Programas processados: {len(programs)}")
        print(f"Modelos utilizados: {len(set(r.provider for r in all_results if r))}")
        print(f"Análises bem-sucedidas: {len(all_results)}/{len(programs)}")
        print(f"Total de tokens utilizados: {total_tokens:,}")
        print(f"Tempo total: {total_time:.2f}s")
        print(f"Resultados salvos em: {args.output}")
        print(f"Prompt customizado usado: {'Sim' if custom_prompt_used else 'Não'}")
        logger.info("Processamento concluído com sucesso")

    except Exception as e:
        logger.critical(f"Erro inesperado no processamento: {e}", exc_info=True)
        print(f"Ocorreu um erro crítico. Verifique o log em {os.path.join('logs', 'cobol_analyzer.log')}")

if __name__ == "__main__":
    main()
