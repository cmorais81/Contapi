#!/usr/bin/env python3
"""
RAG Maintenance - Manutenção e Otimização da Base de Conhecimento
Funcionalidades para reindexar, organizar e otimizar a base RAG
"""

import os
import json
import pickle
import logging
from datetime import datetime
from typing import Dict, List, Any, Tuple
from pathlib import Path
import hashlib

class RAGMaintenance:
    """Classe para manutenção e otimização da base de conhecimento RAG"""
    
    def __init__(self, data_dir: str = None):
        """
        Inicializa o sistema de manutenção RAG
        
        Args:
            data_dir: Diretório da base de dados (padrão: cobol_to_docs/data)
        """
        if data_dir is None:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            self.data_dir = os.path.join(os.path.dirname(os.path.dirname(current_dir)), 'data')
        else:
            self.data_dir = data_dir
            
        self.knowledge_base_file = os.path.join(self.data_dir, 'cobol_knowledge_base.json')
        self.embeddings_file = os.path.join(self.data_dir, 'cobol_embeddings.pkl')
        self.backup_dir = os.path.join(self.data_dir, 'backups')
        
        # Criar diretório de backup se não existir
        os.makedirs(self.backup_dir, exist_ok=True)
        
        self.logger = logging.getLogger(__name__)
        
    def create_backup(self) -> str:
        """
        Cria backup da base atual antes da manutenção
        
        Returns:
            Path do backup criado
        """
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_name = f"knowledge_base_backup_{timestamp}"
        backup_path = os.path.join(self.backup_dir, backup_name)
        
        os.makedirs(backup_path, exist_ok=True)
        
        # Backup da base de conhecimento
        if os.path.exists(self.knowledge_base_file):
            backup_kb = os.path.join(backup_path, 'cobol_knowledge_base.json')
            with open(self.knowledge_base_file, 'r', encoding='utf-8') as src:
                with open(backup_kb, 'w', encoding='utf-8') as dst:
                    dst.write(src.read())
        
        # Backup dos embeddings
        if os.path.exists(self.embeddings_file):
            backup_emb = os.path.join(backup_path, 'cobol_embeddings.pkl')
            with open(self.embeddings_file, 'rb') as src:
                with open(backup_emb, 'wb') as dst:
                    dst.write(src.read())
        
        self.logger.info(f"Backup criado em: {backup_path}")
        return backup_path
    
    def load_knowledge_base(self) -> Dict[str, Any]:
        """Carrega a base de conhecimento atual"""
        if not os.path.exists(self.knowledge_base_file):
            return {}
        
        try:
            with open(self.knowledge_base_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            self.logger.error(f"Erro ao carregar base de conhecimento: {e}")
            return {}
    
    def save_knowledge_base(self, knowledge_base: Dict[str, Any]) -> None:
        """Salva a base de conhecimento otimizada"""
        try:
            with open(self.knowledge_base_file, 'w', encoding='utf-8') as f:
                json.dump(knowledge_base, f, indent=2, ensure_ascii=False)
            self.logger.info(f"Base de conhecimento salva: {len(knowledge_base)} itens")
        except Exception as e:
            self.logger.error(f"Erro ao salvar base de conhecimento: {e}")
    
    def remove_duplicates(self, knowledge_base: Dict[str, Any]) -> Tuple[Dict[str, Any], int]:
        """
        Remove entradas duplicadas da base de conhecimento
        
        Returns:
            Tupla com (base_limpa, quantidade_removida)
        """
        # Converter lista para dicionário se necessário
        if isinstance(knowledge_base, list):
            kb_dict = {}
            for i, entry in enumerate(knowledge_base):
                kb_dict[f"kb_{i:04d}"] = entry
            knowledge_base = kb_dict
        
        seen_hashes = set()
        clean_base = {}
        removed_count = 0
        
        for kb_id, entry in knowledge_base.items():
            # Criar hash do conteúdo principal para detectar duplicatas
            content_str = json.dumps({
                'program_name': entry.get('program_name', ''),
                'analysis': entry.get('analysis', ''),
                'business_rules': entry.get('business_rules', [])
            }, sort_keys=True)
            
            content_hash = hashlib.md5(content_str.encode()).hexdigest()
            
            if content_hash not in seen_hashes:
                seen_hashes.add(content_hash)
                clean_base[kb_id] = entry
            else:
                removed_count += 1
                self.logger.debug(f"Removida entrada duplicada: {kb_id}")
        
        return clean_base, removed_count
    
    def consolidate_similar_entries(self, knowledge_base: Dict[str, Any]) -> Tuple[Dict[str, Any], int]:
        """
        Consolida entradas similares (mesmo programa, análises diferentes)
        
        Returns:
            Tupla com (base_consolidada, quantidade_consolidada)
        """
        # Converter lista para dicionário se necessário
        if isinstance(knowledge_base, list):
            kb_dict = {}
            for i, entry in enumerate(knowledge_base):
                kb_dict[f"kb_{i:04d}"] = entry
            knowledge_base = kb_dict
        
        program_groups = {}
        consolidated_count = 0
        
        # Agrupar por nome do programa
        for kb_id, entry in knowledge_base.items():
            program_name = entry.get('program_name', 'unknown')
            if program_name not in program_groups:
                program_groups[program_name] = []
            program_groups[program_name].append((kb_id, entry))
        
        consolidated_base = {}
        
        for program_name, entries in program_groups.items():
            if len(entries) == 1:
                # Apenas uma entrada, manter como está
                kb_id, entry = entries[0]
                consolidated_base[kb_id] = entry
            else:
                # Múltiplas entradas, consolidar
                consolidated_entry = self._merge_entries([entry for _, entry in entries])
                
                # Usar o ID mais recente ou criar novo
                latest_entry = max(entries, key=lambda x: x[1].get('timestamp', ''))
                consolidated_base[latest_entry[0]] = consolidated_entry
                consolidated_count += len(entries) - 1
                
                self.logger.debug(f"Consolidadas {len(entries)} entradas para {program_name}")
        
        return consolidated_base, consolidated_count
    
    def _merge_entries(self, entries: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Mescla múltiplas entradas de um mesmo programa"""
        if not entries:
            return {}
        
        # Usar a entrada mais recente como base
        base_entry = max(entries, key=lambda x: x.get('timestamp', ''))
        merged = base_entry.copy()
        
        # Consolidar regras de negócio
        all_rules = []
        for entry in entries:
            rules = entry.get('business_rules', [])
            if isinstance(rules, list):
                all_rules.extend(rules)
        
        # Remover regras duplicadas
        unique_rules = []
        seen_rules = set()
        for rule in all_rules:
            rule_str = str(rule).lower().strip()
            if rule_str not in seen_rules:
                seen_rules.add(rule_str)
                unique_rules.append(rule)
        
        merged['business_rules'] = unique_rules
        
        # Consolidar análises (manter a mais completa)
        longest_analysis = max(entries, key=lambda x: len(str(x.get('analysis', ''))))
        merged['analysis'] = longest_analysis.get('analysis', '')
        
        # Atualizar timestamp
        merged['timestamp'] = datetime.now().isoformat()
        merged['consolidated'] = True
        merged['source_entries'] = len(entries)
        
        return merged
    
    def optimize_embeddings(self) -> int:
        """
        Otimiza o cache de embeddings removendo entradas órfãs
        
        Returns:
            Quantidade de embeddings removidos
        """
        if not os.path.exists(self.embeddings_file):
            return 0
        
        try:
            with open(self.embeddings_file, 'rb') as f:
                embeddings = pickle.load(f)
        except Exception as e:
            self.logger.error(f"Erro ao carregar embeddings: {e}")
            return 0
        
        # Carregar base de conhecimento atual
        knowledge_base = self.load_knowledge_base()
        valid_ids = set(knowledge_base.keys())
        
        # Remover embeddings órfãos
        original_count = len(embeddings)
        cleaned_embeddings = {k: v for k, v in embeddings.items() if k in valid_ids}
        removed_count = original_count - len(cleaned_embeddings)
        
        # Salvar embeddings limpos
        try:
            with open(self.embeddings_file, 'wb') as f:
                pickle.dump(cleaned_embeddings, f)
            self.logger.info(f"Embeddings otimizados: {removed_count} órfãos removidos")
        except Exception as e:
            self.logger.error(f"Erro ao salvar embeddings otimizados: {e}")
        
        return removed_count
    
    def reindex_knowledge_base(self) -> Dict[str, int]:
        """
        Executa reindexação completa da base de conhecimento
        
        Returns:
            Estatísticas da operação
        """
        self.logger.info("=== INICIANDO REINDEXAÇÃO DA BASE RAG ===")
        
        # Criar backup
        backup_path = self.create_backup()
        
        # Carregar base atual
        knowledge_base = self.load_knowledge_base()
        original_count = len(knowledge_base)
        
        if original_count == 0:
            self.logger.info("Base de conhecimento vazia, nada para reindexar")
            return {'original_entries': 0, 'final_entries': 0}
        
        self.logger.info(f"Base original: {original_count} entradas")
        
        # Remover duplicatas
        knowledge_base, duplicates_removed = self.remove_duplicates(knowledge_base)
        self.logger.info(f"Duplicatas removidas: {duplicates_removed}")
        
        # Consolidar entradas similares
        knowledge_base, consolidated = self.consolidate_similar_entries(knowledge_base)
        self.logger.info(f"Entradas consolidadas: {consolidated}")
        
        # Reorganizar IDs sequencialmente
        reorganized_base = {}
        for i, (old_id, entry) in enumerate(knowledge_base.items(), 1):
            new_id = f"kb_{i:04d}"
            entry['reindexed_at'] = datetime.now().isoformat()
            entry['original_id'] = old_id
            reorganized_base[new_id] = entry
        
        # Salvar base reorganizada
        self.save_knowledge_base(reorganized_base)
        
        # Otimizar embeddings
        embeddings_removed = self.optimize_embeddings()
        
        final_count = len(reorganized_base)
        
        stats = {
            'original_entries': original_count,
            'duplicates_removed': duplicates_removed,
            'entries_consolidated': consolidated,
            'embeddings_cleaned': embeddings_removed,
            'final_entries': final_count,
            'backup_path': backup_path
        }
        
        self.logger.info("=== REINDEXAÇÃO CONCLUÍDA ===")
        self.logger.info(f"Entradas finais: {final_count}")
        self.logger.info(f"Redução total: {original_count - final_count} entradas")
        
        return stats
    
    def get_base_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas da base de conhecimento atual"""
        knowledge_base = self.load_knowledge_base()
        
        if not knowledge_base:
            return {'total_entries': 0, 'status': 'empty'}
        
        # Verificar se é lista ou dicionário
        if isinstance(knowledge_base, list):
            # Converter lista para dicionário para processamento
            kb_dict = {}
            for i, entry in enumerate(knowledge_base):
                if isinstance(entry, dict):
                    kb_dict[f"kb_{i:04d}"] = entry
                else:
                    kb_dict[f"kb_{i:04d}"] = {'content': str(entry)}
            knowledge_base = kb_dict
        
        # Estatísticas básicas
        total_entries = len(knowledge_base)
        
        # Contar por programa
        programs = {}
        for entry in knowledge_base.values():
            if isinstance(entry, dict):
                program_name = entry.get('program_name', entry.get('title', 'unknown'))
            else:
                program_name = 'unknown'
            programs[program_name] = programs.get(program_name, 0) + 1
        
        # Contar entradas consolidadas
        consolidated_count = sum(1 for entry in knowledge_base.values() 
                               if isinstance(entry, dict) and entry.get('consolidated', False))
        
        # Verificar embeddings
        embeddings_count = 0
        if os.path.exists(self.embeddings_file):
            try:
                with open(self.embeddings_file, 'rb') as f:
                    embeddings = pickle.load(f)
                    embeddings_count = len(embeddings)
            except:
                embeddings_count = 0
        
        return {
            'total_entries': total_entries,
            'unique_programs': len(programs),
            'programs_distribution': programs,
            'consolidated_entries': consolidated_count,
            'embeddings_cached': embeddings_count,
            'data_directory': self.data_dir,
            'last_modified': datetime.fromtimestamp(
                os.path.getmtime(self.knowledge_base_file)
            ).isoformat() if os.path.exists(self.knowledge_base_file) else None
        }

def main():
    """Função principal para execução standalone"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Manutenção da Base RAG')
    parser.add_argument('--reindex', action='store_true', 
                       help='Executar reindexação completa')
    parser.add_argument('--stats', action='store_true', 
                       help='Mostrar estatísticas da base')
    parser.add_argument('--data-dir', type=str, 
                       help='Diretório da base de dados')
    
    args = parser.parse_args()
    
    # Configurar logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    maintenance = RAGMaintenance(args.data_dir)
    
    if args.stats:
        stats = maintenance.get_base_statistics()
        print("\n=== ESTATÍSTICAS DA BASE RAG ===")
        for key, value in stats.items():
            print(f"{key}: {value}")
    
    if args.reindex:
        stats = maintenance.reindex_knowledge_base()
        print("\n=== RESULTADO DA REINDEXAÇÃO ===")
        for key, value in stats.items():
            print(f"{key}: {value}")

if __name__ == "__main__":
    main()
