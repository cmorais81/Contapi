#!/usr/bin/env python3
"""
COBOL AI Engine v2.0.0 - Main com Análise de Linhagem
Versão principal com análise completa de linhagem e sequência de execução.
"""

import argparse
import logging
import os
import sys
import time
from datetime import datetime
from typing import List, Dict, Any

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager import PromptManager
from src.core.token_manager import TokenManager
from src.providers.provider_manager import ProviderManager
from src.generators.documentation_generator import DocumentationGenerator
from src.parsers.cobol_parser import COBOLParser
from src.utils.pdf_converter import MarkdownToPDFConverter
from src.analyzers.completeness_analyzer import CompletenessAnalyzer
from src.analyzers.lineage_mapper import LineageMapper
from src.reports.lineage_reporter import LineageReporter


def setup_logging(log_level: str = "INFO") -> None:
    """Configura sistema de logging."""
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('logs/cobol_ai_engine.log', encoding='utf-8')
        ]
    )


def parse_arguments() -> argparse.Namespace:
    """Parse argumentos da linha de comando."""
    parser = argparse.ArgumentParser(
        description='COBOL AI Engine v2.0.0 - Análise com Linhagem',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  python main_with_lineage.py --fontes examples/fontes.txt --output resultado
  python main_with_lineage.py --fontes examples/fontes.txt --books examples/BOOKS.txt --pdf
  python main_with_lineage.py --status
        """
    )
    
    parser.add_argument('--fontes', type=str,
                       help='Arquivo com lista de programas COBOL')
    parser.add_argument('--books', type=str,
                       help='Arquivo com lista de copybooks')
    parser.add_argument('--output', type=str, default='output',
                       help='Diretório de saída (padrão: output)')
    parser.add_argument('--config', type=str, default='config/config_unified.yaml',
                       help='Arquivo de configuração')
    parser.add_argument('--provider', type=str,
                       help='Provedor específico a usar')
    parser.add_argument('--pdf', action='store_true',
                       help='Gerar PDFs da documentação')
    parser.add_argument('--lineage-only', action='store_true',
                       help='Executar apenas análise de linhagem')
    parser.add_argument('--status', action='store_true',
                       help='Mostrar status dos provedores')
    parser.add_argument('--version', action='store_true',
                       help='Mostrar versão do sistema')
    parser.add_argument('--log-level', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                       default='INFO', help='Nível de log')
    
    return parser.parse_args()


def show_version() -> None:
    """Mostra versão do sistema."""
    print("COBOL AI Engine v2.0.0 - Análise com Linhagem")
    print("Copyright (c) 2025 - Sistema de Análise de Código COBOL")
    print("Funcionalidades: Análise completa, Linhagem, Sequência de execução")


def show_provider_status(provider_manager: ProviderManager) -> None:
    """Mostra status dos provedores."""
    print("\n=== STATUS DOS PROVEDORES ===")
    
    available_providers = provider_manager.get_available_providers()
    
    if not available_providers:
        print("❌ Nenhum provedor disponível")
        return
    
    for provider_name in available_providers:
        try:
            provider = provider_manager.get_provider(provider_name)
            if provider and provider.is_available():
                print(f"✅ {provider_name}: Disponível")
            else:
                print(f"❌ {provider_name}: Indisponível")
        except Exception as e:
            print(f"❌ {provider_name}: Erro - {e}")


def process_programs_with_lineage(fontes_file: str, books_file: str, 
                                output_dir: str, config_manager: ConfigManager,
                                provider_manager: ProviderManager,
                                generate_pdf: bool = False,
                                lineage_only: bool = False) -> Dict[str, Any]:
    """
    Processa programas com análise completa de linhagem.
    
    Args:
        fontes_file: Arquivo com programas
        books_file: Arquivo com copybooks
        output_dir: Diretório de saída
        config_manager: Gerenciador de configuração
        provider_manager: Gerenciador de provedores
        generate_pdf: Se deve gerar PDFs
        lineage_only: Se deve executar apenas análise de linhagem
        
    Returns:
        Dicionário com resultados do processamento
    """
    logger = logging.getLogger(__name__)
    start_time = time.time()
    
    # Criar diretórios
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    
    # Inicializar componentes
    parser = COBOLParser()
    completeness_analyzer = CompletenessAnalyzer()
    lineage_mapper = LineageMapper()
    lineage_reporter = LineageReporter(output_dir)
    
    # Carregar programas esperados
    expected_programs = completeness_analyzer.load_expected_programs(fontes_file)
    logger.info(f"Programas esperados carregados: {len(expected_programs)}")
    
    # Parse dos arquivos
    logger.info("Iniciando parse dos programas...")
    programs, copybooks = parser.parse_file(fontes_file)
    if books_file:
        _, additional_copybooks = parser.parse_file(books_file)
        copybooks.extend(additional_copybooks)
    
    # Atualizar status de completude
    for program in programs:
        completeness_analyzer.mark_program_found(
            program.name, fontes_file,  # usar fontes_file como caminho
            program.size, program.line_count
        )
        completeness_analyzer.mark_program_parsed(program.name)
    
    logger.info(f"Programas parseados: {len(programs)}")
    logger.info(f"Copybooks parseados: {len(copybooks)}")
    
    # Análise de dependências
    logger.info("Analisando dependências...")
    completeness_analyzer.analyze_dependencies(programs, copybooks)
    
    # Construir grafo de linhagem
    dependencies = completeness_analyzer.dependencies
    lineage_mapper.build_dependency_graph(dependencies)
    
    # Analisar sequências de execução
    logger.info("Analisando sequências de execução...")
    execution_sequences = lineage_mapper.analyze_execution_sequences()
    
    results = {
        'programs_processed': len(programs),
        'copybooks_processed': len(copybooks),
        'dependencies_found': len(dependencies),
        'execution_sequences': len(execution_sequences),
        'expected_programs': len(expected_programs),
        'processing_time': 0,
        'success_rate': 0,
        'reports_generated': []
    }
    
    if not lineage_only:
        # Processamento completo com documentação
        logger.info("Iniciando análise e documentação...")
        
        # Inicializar geradores
        prompt_manager = PromptManager(config_manager.get_config().get('prompts', {}))
        token_manager = TokenManager(config_manager.get_config().get('token_limits', {}))
        doc_generator = DocumentationGenerator(
            provider_manager, prompt_manager, token_manager, output_dir
        )
        
        # Processar cada programa
        successful_analyses = 0
        total_tokens = 0
        
        for i, program in enumerate(programs, 1):
            try:
                logger.info(f"[{i}/{len(programs)}] Processando {program.name}...")
                
                # Análise e documentação
                result = doc_generator.generate_documentation(program)
                
                if result['success']:
                    successful_analyses += 1
                    total_tokens += result.get('tokens_used', 0)
                    
                    # Atualizar status
                    completeness_analyzer.mark_program_analyzed(program.name)
                    completeness_analyzer.mark_program_documented(program.name)
                    
                    print(f"[{i}/{len(programs)}] ✅ {program.name}")
                else:
                    error_msg = result.get('error', 'Erro desconhecido')
                    completeness_analyzer.mark_program_error(program.name, error_msg)
                    print(f"[{i}/{len(programs)}] ❌ {program.name} - {error_msg}")
                
            except Exception as e:
                error_msg = f"Erro no processamento: {e}"
                completeness_analyzer.mark_program_error(program.name, error_msg)
                logger.error(f"Erro ao processar {program.name}: {e}")
                print(f"[{i}/{len(programs)}] ❌ {program.name} - {error_msg}")
        
        # Atualizar resultados
        results.update({
            'successful_analyses': successful_analyses,
            'total_tokens': total_tokens,
            'success_rate': (successful_analyses / len(programs)) * 100 if programs else 0
        })
        
        # Gerar PDFs se solicitado
        if generate_pdf:
            logger.info("Gerando PDFs...")
            pdf_converter = MarkdownToPDFConverter()
            pdf_results = pdf_converter.convert_directory(output_dir)
            results['pdfs_generated'] = pdf_results['converted_count']
    
    # Gerar relatórios de linhagem
    logger.info("Gerando relatórios de linhagem...")
    
    # Relatório de completude
    completeness_report = lineage_reporter.generate_completeness_report(completeness_analyzer)
    if completeness_report:
        results['reports_generated'].append(completeness_report)
    
    # Relatório de linhagem
    lineage_report = lineage_reporter.generate_lineage_report(lineage_mapper)
    if lineage_report:
        results['reports_generated'].append(lineage_report)
    
    # Relatório consolidado
    consolidated_report = lineage_reporter.generate_consolidated_report(
        completeness_analyzer, lineage_mapper, expected_programs
    )
    if consolidated_report:
        results['reports_generated'].append(consolidated_report)
    
    # Tempo total
    results['processing_time'] = time.time() - start_time
    
    return results


def main():
    """Função principal."""
    args = parse_arguments()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    # Mostrar versão
    if args.version:
        show_version()
        return
    
    try:
        # Carregar configuração
        config_manager = ConfigManager(args.config)
        
        # Inicializar provedor
        provider_manager = ProviderManager(config_manager.get_config())
        
        # Mostrar status
        if args.status:
            show_provider_status(provider_manager)
            return
        
        # Validar argumentos
        if not args.fontes:
            print("❌ Erro: Arquivo de fontes é obrigatório")
            print("Use --help para ver opções disponíveis")
            return
        
        if not os.path.exists(args.fontes):
            print(f"❌ Erro: Arquivo de fontes não encontrado: {args.fontes}")
            return
        
        if args.books and not os.path.exists(args.books):
            print(f"❌ Erro: Arquivo de copybooks não encontrado: {args.books}")
            return
        
        # Processar com linhagem
        print(f"\n🚀 COBOL AI Engine v2.0.0 - Análise com Linhagem")
        print(f"📁 Arquivo de fontes: {args.fontes}")
        if args.books:
            print(f"📚 Arquivo de copybooks: {args.books}")
        print(f"📂 Diretório de saída: {args.output}")
        if args.lineage_only:
            print("🔍 Modo: Apenas análise de linhagem")
        print()
        
        # Executar processamento
        results = process_programs_with_lineage(
            args.fontes, args.books, args.output,
            config_manager, provider_manager,
            args.pdf, args.lineage_only
        )
        
        # Mostrar resultados
        print("\n" + "="*50)
        print("PROCESSAMENTO CONCLUÍDO")
        print("="*50)
        
        print(f"Programas esperados: {results['expected_programs']}")
        print(f"Programas processados: {results['programs_processed']}")
        print(f"Copybooks processados: {results['copybooks_processed']}")
        print(f"Dependências encontradas: {results['dependencies_found']}")
        print(f"Sequências de execução: {results['execution_sequences']}")
        
        if not args.lineage_only:
            print(f"Análises bem-sucedidas: {results.get('successful_analyses', 0)}/{results['programs_processed']}")
            print(f"Taxa de sucesso: {results.get('success_rate', 0):.1f}%")
            print(f"Total de tokens utilizados: {results.get('total_tokens', 0):,}")
            
            if args.pdf and 'pdfs_generated' in results:
                print(f"PDFs gerados: {results['pdfs_generated']}")
        
        print(f"Tempo de processamento: {results['processing_time']:.2f}s")
        print(f"Relatórios gerados: {len(results['reports_generated'])}")
        
        # Listar relatórios gerados
        if results['reports_generated']:
            print("\nRelatórios disponíveis:")
            for report_path in results['reports_generated']:
                report_name = os.path.basename(report_path)
                print(f"  📊 {report_name}")
        
        print(f"\n📂 Arquivos salvos em: {args.output}")
        
        # Mostrar próximos passos
        print("\n🎯 Próximos passos:")
        print("  1. Revisar relatórios de linhagem gerados")
        print("  2. Verificar sequências de execução identificadas")
        print("  3. Implementar otimizações de paralelização sugeridas")
        print("  4. Validar completude do processamento")
        
    except KeyboardInterrupt:
        print("\n⚠️ Processamento interrompido pelo usuário")
        logger.info("Processamento interrompido pelo usuário")
    except Exception as e:
        print(f"\n❌ Erro durante execução: {e}")
        logger.error(f"Erro durante execução: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()

