#!/usr/bin/env python3
"""
Suite de Testes Abrangente - COBOL AI Engine v2.0.1
Valida todas as funcionalidades principais incluindo as correções do LuzIA.
"""

import os
import sys
import yaml
import json
import logging
import subprocess
from pathlib import Path
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

class TestSuite:
    """Suite de testes para COBOL AI Engine v2.0.1."""
    
    def __init__(self):
        self.project_root = Path(__file__).parent
        self.results = {
            'total_tests': 0,
            'passed_tests': 0,
            'failed_tests': 0,
            'test_details': []
        }
        
    def log_test_result(self, test_name: str, success: bool, details: str = ""):
        """Registra resultado de um teste."""
        self.results['total_tests'] += 1
        if success:
            self.results['passed_tests'] += 1
            status = "PASSOU"
        else:
            self.results['failed_tests'] += 1
            status = "FALHOU"
        
        self.results['test_details'].append({
            'test': test_name,
            'status': status,
            'details': details
        })
        
        print(f"{'✅' if success else '❌'} {test_name}: {status}")
        if details:
            print(f"   {details}")
    
    def test_version_update(self):
        """Testa se a versão foi atualizada corretamente."""
        try:
            version_file = self.project_root / "VERSION"
            if version_file.exists():
                version = version_file.read_text().strip()
                success = version == "2.0.1"
                details = f"Versão encontrada: {version}"
            else:
                success = False
                details = "Arquivo VERSION não encontrado"
            
            self.log_test_result("Atualização de Versão", success, details)
            return success
            
        except Exception as e:
            self.log_test_result("Atualização de Versão", False, f"Erro: {e}")
            return False
    
    def test_config_yaml_structure(self):
        """Testa estrutura do config_unified.yaml."""
        try:
            config_file = self.project_root / "config" / "config_unified.yaml"
            
            with open(config_file, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            # Verificar estrutura principal
            required_sections = ['ai', 'performance', 'logging', 'output']
            missing_sections = [s for s in required_sections if s not in config]
            
            if missing_sections:
                success = False
                details = f"Seções faltando: {missing_sections}"
            else:
                # Verificar configurações específicas do LuzIA
                luzia_config = config.get('ai', {}).get('providers', {}).get('luzia', {})
                token_config = config.get('performance', {}).get('token_management', {})
                provider_specific = token_config.get('provider_specific', {})
                
                has_luzia_config = bool(luzia_config)
                has_token_config = 'luzia' in provider_specific
                
                if has_luzia_config and has_token_config:
                    success = True
                    details = "Configuração YAML completa com LuzIA"
                else:
                    success = False
                    details = f"LuzIA config: {has_luzia_config}, Token config: {has_token_config}"
            
            self.log_test_result("Estrutura Config YAML", success, details)
            return success
            
        except Exception as e:
            self.log_test_result("Estrutura Config YAML", False, f"Erro: {e}")
            return False
    
    def test_luzia_provider_import(self):
        """Testa importação do provedor LuzIA."""
        try:
            sys.path.insert(0, str(self.project_root / "src"))
            
            from src.providers.luzia_provider import LuziaProvider
            from src.providers.base_provider import AIRequest, AIResponse
            
            success = True
            details = "Importação bem-sucedida"
            
            self.log_test_result("Importação Provedor LuzIA", success, details)
            return success
            
        except Exception as e:
            self.log_test_result("Importação Provedor LuzIA", False, f"Erro: {e}")
            return False
    
    def test_luzia_provider_initialization(self):
        """Testa inicialização do provedor LuzIA."""
        try:
            sys.path.insert(0, str(self.project_root / "src"))
            
            # Carregar configuração
            config_file = self.project_root / "config" / "config_unified.yaml"
            with open(config_file, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            # Configuração do LuzIA
            ai_config = config.get('ai', {})
            providers = ai_config.get('providers', {})
            luzia_config = providers.get('luzia', {})
            
            # Adicionar configurações globais
            full_config = {**luzia_config}
            full_config['performance'] = config.get('performance', {})
            
            from src.providers.luzia_provider import LuziaProvider
            
            provider = LuziaProvider(full_config)
            
            # Verificar atributos importantes
            has_correct_model = provider.model == "azure-gpt-4o-mini"
            has_token_splitting_disabled = provider.enable_token_splitting == False
            has_correct_max_tokens = provider.max_tokens_per_request == 200000
            
            if has_correct_model and has_token_splitting_disabled and has_correct_max_tokens:
                success = True
                details = f"Modelo: {provider.model}, Token splitting: {provider.enable_token_splitting}"
            else:
                success = False
                details = f"Modelo: {provider.model}, Token splitting: {provider.enable_token_splitting}, Max tokens: {provider.max_tokens_per_request}"
            
            self.log_test_result("Inicialização Provedor LuzIA", success, details)
            return success
            
        except Exception as e:
            self.log_test_result("Inicialização Provedor LuzIA", False, f"Erro: {e}")
            return False
    
    def test_payload_creation(self):
        """Testa criação de payload correto."""
        try:
            sys.path.insert(0, str(self.project_root / "src"))
            
            # Configuração mínima
            config = {
                'model': 'azure-gpt-4o-mini',
                'temperature': 0.1,
                'max_tokens': 4000,
                'performance': {
                    'token_management': {
                        'provider_specific': {
                            'luzia': {
                                'enable_token_splitting': False,
                                'max_tokens_per_request': 200000
                            }
                        }
                    }
                }
            }
            
            from src.providers.luzia_provider import LuziaProvider
            
            provider = LuziaProvider(config)
            
            # Criar payload
            payload = provider.create_complete_payload("Sistema", "Usuário")
            
            # Validar estrutura
            has_body = 'body' in payload
            has_input = 'input' in payload.get('body', {})
            input_is_list = isinstance(payload.get('body', {}).get('input'), list)
            has_config = 'config' in payload
            has_type = 'type' in payload.get('config', {})
            has_obj_kwargs = 'obj_kwargs' in payload.get('config', {})
            
            # Validar payload
            try:
                provider.validate_payload(payload)
                validation_ok = True
            except Exception:
                validation_ok = False
            
            if all([has_body, has_input, input_is_list, has_config, has_type, has_obj_kwargs, validation_ok]):
                success = True
                details = f"Payload válido com {len(payload['body']['input'])} mensagens"
            else:
                success = False
                details = f"Body: {has_body}, Input: {has_input}, Lista: {input_is_list}, Config: {has_config}, Validação: {validation_ok}"
            
            self.log_test_result("Criação de Payload", success, details)
            return success
            
        except Exception as e:
            self.log_test_result("Criação de Payload", False, f"Erro: {e}")
            return False
    
    def test_main_script_execution(self):
        """Testa execução do script principal."""
        try:
            # Testar comando de versão
            result = subprocess.run(
                [sys.executable, "main.py", "--version"],
                cwd=self.project_root,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                output = result.stdout.strip()
                if "2.0.1" in output:
                    success = True
                    details = f"Versão retornada: {output}"
                else:
                    success = False
                    details = f"Versão incorreta: {output}"
            else:
                success = False
                details = f"Erro na execução: {result.stderr}"
            
            self.log_test_result("Execução Script Principal", success, details)
            return success
            
        except Exception as e:
            self.log_test_result("Execução Script Principal", False, f"Erro: {e}")
            return False
    
    def test_enhanced_mock_provider(self):
        """Testa provedor enhanced_mock para garantir fallback."""
        try:
            # Testar análise com enhanced_mock
            result = subprocess.run([
                sys.executable, "main.py",
                "--config", "config/config_unified.yaml",
                "--fontes", "examples/fontes.txt",
                "--output", "test_output_v2_0_1",
                "--provider", "enhanced_mock"
            ], cwd=self.project_root, capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                # Verificar se arquivo foi gerado
                output_file = self.project_root / "test_output_v2_0_1" / "LHAN0542.md"
                if output_file.exists():
                    success = True
                    details = "Análise executada e arquivo gerado"
                else:
                    success = False
                    details = "Análise executada mas arquivo não encontrado"
            else:
                success = False
                details = f"Erro na execução: {result.stderr[:200]}"
            
            self.log_test_result("Provedor Enhanced Mock", success, details)
            return success
            
        except Exception as e:
            self.log_test_result("Provedor Enhanced Mock", False, f"Erro: {e}")
            return False
    
    def test_documentation_files(self):
        """Testa presença de arquivos de documentação."""
        try:
            required_files = [
                "README.md",
                "CHANGELOG.md",
                "docs/API_DOCUMENTATION.md",
                "docs/CLI_DOCUMENTATION.md"
            ]
            
            missing_files = []
            for file_path in required_files:
                if not (self.project_root / file_path).exists():
                    missing_files.append(file_path)
            
            if not missing_files:
                success = True
                details = "Todos os arquivos de documentação presentes"
            else:
                success = False
                details = f"Arquivos faltando: {missing_files}"
            
            self.log_test_result("Arquivos de Documentação", success, details)
            return success
            
        except Exception as e:
            self.log_test_result("Arquivos de Documentação", False, f"Erro: {e}")
            return False
    
    def run_all_tests(self):
        """Executa todos os testes."""
        print("=" * 60)
        print("COBOL AI Engine v2.0.1 - Suite de Testes Abrangente")
        print("=" * 60)
        print(f"Iniciado em: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print()
        
        # Lista de testes
        tests = [
            self.test_version_update,
            self.test_config_yaml_structure,
            self.test_luzia_provider_import,
            self.test_luzia_provider_initialization,
            self.test_payload_creation,
            self.test_main_script_execution,
            self.test_enhanced_mock_provider,
            self.test_documentation_files
        ]
        
        # Executar testes
        for test in tests:
            try:
                test()
            except Exception as e:
                test_name = test.__name__.replace('test_', '').replace('_', ' ').title()
                self.log_test_result(test_name, False, f"Erro inesperado: {e}")
        
        # Resultado final
        print("\n" + "=" * 60)
        print("RESULTADO FINAL")
        print("=" * 60)
        print(f"Total de testes: {self.results['total_tests']}")
        print(f"Testes aprovados: {self.results['passed_tests']}")
        print(f"Testes falharam: {self.results['failed_tests']}")
        
        success_rate = (self.results['passed_tests'] / self.results['total_tests']) * 100
        print(f"Taxa de sucesso: {success_rate:.1f}%")
        
        if self.results['failed_tests'] == 0:
            print("\n🎉 TODOS OS TESTES PASSARAM!")
            print("   COBOL AI Engine v2.0.1 está pronto para uso!")
        else:
            print(f"\n⚠️  {self.results['failed_tests']} TESTE(S) FALHARAM")
            print("   Verifique os detalhes acima.")
        
        return self.results['failed_tests'] == 0
    
    def generate_test_report(self):
        """Gera relatório detalhado dos testes."""
        report_file = self.project_root / "TEST_REPORT_v2_0_1.md"
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("# Relatório de Testes - COBOL AI Engine v2.0.1\n\n")
            f.write(f"**Data:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            f.write("## Resumo\n\n")
            f.write(f"- **Total de testes:** {self.results['total_tests']}\n")
            f.write(f"- **Testes aprovados:** {self.results['passed_tests']}\n")
            f.write(f"- **Testes falharam:** {self.results['failed_tests']}\n")
            
            success_rate = (self.results['passed_tests'] / self.results['total_tests']) * 100
            f.write(f"- **Taxa de sucesso:** {success_rate:.1f}%\n\n")
            
            f.write("## Detalhes dos Testes\n\n")
            
            for test in self.results['test_details']:
                status_icon = "✅" if test['status'] == "PASSOU" else "❌"
                f.write(f"### {status_icon} {test['test']}\n\n")
                f.write(f"**Status:** {test['status']}\n\n")
                if test['details']:
                    f.write(f"**Detalhes:** {test['details']}\n\n")
        
        print(f"\n📄 Relatório salvo em: {report_file}")

def main():
    """Função principal."""
    suite = TestSuite()
    success = suite.run_all_tests()
    suite.generate_test_report()
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())

