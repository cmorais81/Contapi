"""
Provedor LuzIA v2.0.0 Final - Integração completa com configuração YAML
Implementa todas as correções identificadas e leitura de configuração do YAML.
"""

import os
import json
import logging
import warnings
from typing import Dict, Any, Optional, List
from datetime import datetime

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse


class LuziaProvider(BaseProvider):
    """
    Provedor LuzIA v2.0.0 Final com integração completa ao YAML.
    
    Características:
    1. Lê todas as configurações do config_unified.yaml
    2. Respeita configuração de token splitting por provedor
    3. Payload JSON completo e correto
    4. Headers e autenticação adequados
    5. Tratamento robusto de erros
    6. Parsing flexível de respostas
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor LuzIA v2.0.0 Final.
        
        Args:
            config: Configuração completa do YAML incluindo configurações globais
        """
        super().__init__(config)
        
        if not REQUESTS_AVAILABLE:
            raise ImportError("requests é necessário para o LuziaProvider")
        
        # Configurações do provedor LuzIA do YAML
        luzia_config = config.get('luzia', {})
        
        # Credenciais e URLs
        self.client_id = luzia_config.get('client_id', os.getenv('LUZIA_CLIENT_ID', '71530749-db0a-424c-8a1c-72bf90315afa'))
        self.client_secret = luzia_config.get('client_secret', os.getenv('LUZIA_CLIENT_SECRET', '90a337834c9vH9zXAqc3D0g0031f73'))
        self.sso_endpoint = luzia_config.get('auth_url', os.getenv('LUZIA_AUTH_URL', 'https://login.azure.pass.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token'))
        self.base_url = luzia_config.get('api_url', os.getenv('LUZIA_API_URL', 'https://prd-api-aws.santanderbr.dev.corp/genai_services/v1'))
        
        # Configurações do modelo
        self.model = luzia_config.get('model', 'azure-gpt-4o-mini')
        self.temperature = luzia_config.get('temperature', 0.1)
        self.max_tokens = luzia_config.get('max_tokens', 4000)
        self.timeout = luzia_config.get('timeout', 180.0)
        
        # Configurações de token management específicas do LuzIA
        token_config = config.get('performance', {}).get('token_management', {})
        provider_specific = token_config.get('provider_specific', {}).get('luzia', {})
        
        self.enable_token_splitting = provider_specific.get('enable_token_splitting', False)
        self.max_tokens_per_request = provider_specific.get('max_tokens_per_request', 200000)
        
        # Token de acesso
        self._token = None
        
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"LuzIA Provider v2.0.0 Final inicializado")
        self.logger.info(f"Modelo: {self.model}")
        self.logger.info(f"Token splitting: {'Habilitado' if self.enable_token_splitting else 'Desabilitado'}")
        self.logger.info(f"Max tokens por requisição: {self.max_tokens_per_request}")
        self.logger.debug(f"Client ID: {self.client_id[:8]}...")
        self.logger.debug(f"Auth URL: {self.sso_endpoint}")
        self.logger.debug(f"API URL: {self.base_url}")
    
    def get_token(self) -> str:
        """
        Obtém token OAuth2 do LuzIA.
        
        Returns:
            str: Token de acesso
            
        Raises:
            Exception: Se não conseguir obter o token
        """
        try:
            # Payload OAuth2 client_credentials
            request_body = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            # Headers para autenticação
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': '*/*'
            }
            
            self.logger.debug("Solicitando token OAuth2...")
            
            # Fazer requisição de token
            response = requests.post(
                self.sso_endpoint,
                headers=headers,
                data=request_body,
                verify=False,
                timeout=30
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self._token = token_data.get('access_token')
                
                if not self._token:
                    raise Exception("Token não encontrado na resposta")
                
                self.logger.info("✅ Token OAuth2 obtido com sucesso")
                return self._token
            else:
                error_msg = f"Erro ao obter token: {response.status_code} - {response.text}"
                self.logger.error(error_msg)
                raise Exception(error_msg)
                
        except requests.exceptions.RequestException as e:
            error_msg = f"Erro de conexão ao obter token: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
        except Exception as e:
            error_msg = f"Erro inesperado ao obter token: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
    
    def create_complete_payload(self, system_prompt: str, user_prompt: str) -> Dict[str, Any]:
        """
        Cria payload JSON completo e correto para API LuzIA.
        
        Baseado na análise das imagens de erro:
        1. body.input deve ser lista de mensagens (não string)
        2. config deve ter type e obj_kwargs completos
        3. JSON deve estar completo sem cortes
        
        Args:
            system_prompt: Prompt do sistema
            user_prompt: Prompt do usuário
            
        Returns:
            Dict: Payload completo para API
        """
        payload = {
            "body": {
                "input": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user", 
                        "content": user_prompt
                    }
                ]
            },
            "config": {
                "type": "catena.llm.LLMRouter",
                "obj_kwargs": {
                    "routing_model": self.model,
                    "temperature": self.temperature,
                    "max_tokens": self.max_tokens
                }
            }
        }
        
        return payload
    
    def validate_payload(self, payload: Dict[str, Any]) -> None:
        """
        Valida estrutura do payload antes de enviar.
        
        Args:
            payload: Payload a ser validado
            
        Raises:
            ValueError: Se payload estiver inválido
        """
        # Verificações baseadas nos erros identificados
        if "body" not in payload:
            raise ValueError("Payload deve conter 'body'")
        
        if "input" not in payload["body"]:
            raise ValueError("body deve conter 'input'")
        
        if not isinstance(payload["body"]["input"], list):
            raise ValueError("body.input deve ser uma lista (não string)")
        
        if len(payload["body"]["input"]) == 0:
            raise ValueError("body.input não pode estar vazio")
        
        # Validar mensagens
        for i, msg in enumerate(payload["body"]["input"]):
            if not isinstance(msg, dict):
                raise ValueError(f"Mensagem {i} deve ser um dicionário")
            if "role" not in msg or "content" not in msg:
                raise ValueError(f"Mensagem {i} deve ter 'role' e 'content'")
        
        if "config" not in payload:
            raise ValueError("Payload deve conter 'config'")
        
        if "type" not in payload["config"]:
            raise ValueError("config deve conter 'type'")
        
        if "obj_kwargs" not in payload["config"]:
            raise ValueError("config deve conter 'obj_kwargs'")
        
        self.logger.debug("✅ Payload validado com sucesso")
    
    def submit_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Submete requisição para API LuzIA.
        
        Args:
            payload: Payload da requisição
            
        Returns:
            Dict: Resposta da API
            
        Raises:
            Exception: Se requisição falhar
        """
        # Obter token se necessário
        if not self._token:
            self.get_token()
        
        # Headers corretos baseados na documentação
        headers = {
            "x-santander-client-id": self.client_id,
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        
        # Validar payload antes de enviar
        self.validate_payload(payload)
        
        # Log estrutural (sem dados sensíveis)
        self.logger.debug(f"Enviando requisição para: {self.base_url}/pipelines/submit")
        self.logger.debug(f"Payload estrutura: {list(payload.keys())}")
        self.logger.debug(f"Número de mensagens: {len(payload['body']['input'])}")
        
        try:
            # Fazer requisição
            response = requests.post(
                f"{self.base_url}/pipelines/submit",
                json=payload,
                headers=headers,
                timeout=self.timeout,
                verify=False
            )
            
            self.logger.debug(f"Status Code: {response.status_code}")
            
            if response.status_code == 200:
                response_data = response.json()
                self.logger.info("✅ Requisição LuzIA bem-sucedida")
                return response_data
            else:
                # Log detalhado do erro
                error_msg = f"Erro na API LuzIA: {response.status_code} - {response.text}"
                self.logger.error(error_msg)
                raise Exception(error_msg)
                
        except requests.exceptions.Timeout:
            error_msg = f"Timeout na requisição LuzIA (>{self.timeout}s)"
            self.logger.error(error_msg)
            raise Exception(error_msg)
        except requests.exceptions.RequestException as e:
            error_msg = f"Erro de conexão com LuzIA: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
        except json.JSONDecodeError as e:
            error_msg = f"Erro ao decodificar resposta JSON: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
    
    def extract_response_content(self, response_data: Dict[str, Any]) -> str:
        """
        Extrai conteúdo da resposta da API LuzIA.
        
        Tenta diferentes estruturas de resposta para máxima compatibilidade.
        
        Args:
            response_data: Dados da resposta da API
            
        Returns:
            str: Conteúdo extraído da resposta
        """
        if not isinstance(response_data, dict):
            return str(response_data)
        
        # Estruturas possíveis de resposta (em ordem de prioridade)
        possible_paths = [
            ['result', 'output'],
            ['output'],
            ['content'],
            ['response'],
            ['data', 'content'],
            ['body', 'output'],
            ['choices', 0, 'message', 'content'],  # Formato OpenAI-like
            ['message', 'content']
        ]
        
        for path in possible_paths:
            try:
                current = response_data
                for key in path:
                    if isinstance(current, dict) and key in current:
                        current = current[key]
                    elif isinstance(current, list) and isinstance(key, int) and len(current) > key:
                        current = current[key]
                    else:
                        break
                else:
                    # Se chegou até aqui, encontrou o caminho
                    content = str(current).strip()
                    if content:
                        self.logger.debug(f"Conteúdo extraído via: {' -> '.join(map(str, path))}")
                        return content
            except (KeyError, IndexError, TypeError):
                continue
        
        # Fallback - usar toda a resposta como string
        self.logger.warning("Usando resposta completa como fallback")
        return str(response_data)
    
    def is_available(self) -> bool:
        """
        Verifica se o provedor LuzIA está disponível.
        
        Returns:
            bool: True se disponível, False caso contrário
        """
        try:
            # Verificar credenciais básicas
            if not self.client_id or not self.client_secret:
                self.logger.warning("Credenciais LuzIA não configuradas")
                return False
            
            # Tentar obter token
            self.get_token()
            
            self.logger.info("✅ LuzIA disponível")
            return True
            
        except Exception as e:
            self.logger.error(f"❌ LuzIA não disponível: {str(e)}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Analisa código COBOL usando LuzIA.
        
        Args:
            request: Requisição de análise
            
        Returns:
            AIResponse: Resposta da análise
        """
        try:
            # Preparar prompts otimizados
            system_prompt = """
Você é um especialista em análise de código COBOL com mais de 20 anos de experiência em sistemas mainframe.
Responda todas as perguntas em português brasileiro de forma clara, técnica e detalhada.

Analise o código fornecido identificando:
- Estrutura e organização do programa
- Lógica de negócio implementada
- Dependências e relacionamentos
- Pontos críticos e considerações técnicas
- Fluxo de dados e processamento

Seja direto e objetivo nas explicações, sem usar formatação especial.
Organize a resposta de forma estruturada e fácil de entender.
"""
            
            user_prompt = request.prompt
            
            # Verificar se deve dividir tokens (baseado na configuração)
            if self.enable_token_splitting:
                # TODO: Implementar divisão de tokens se necessário
                # Por enquanto, sempre envia completo
                self.logger.info("Token splitting habilitado, mas enviando completo por enquanto")
            
            # Criar payload completo
            payload = self.create_complete_payload(system_prompt, user_prompt)
            
            # Submeter requisição
            self.logger.info(f"Iniciando análise COBOL: {request.program_name}")
            response_data = self.submit_request(payload)
            
            # Processar resposta
            analysis_text = self.extract_response_content(response_data)
            
            # Calcular tokens (estimativa)
            input_tokens = len(system_prompt.split()) + len(user_prompt.split())
            output_tokens = len(analysis_text.split())
            total_tokens = input_tokens + output_tokens
            
            self.logger.info(f"✅ Análise concluída - Tokens: {total_tokens}")
            
            return AIResponse(
                content=analysis_text,
                provider="luzia_v2_final",
                model=self.model,
                tokens_used=total_tokens,
                success=True
            )
            
        except Exception as e:
            error_msg = f"Erro na análise LuzIA: {str(e)}"
            self.logger.error(error_msg)
            
            return AIResponse(
                content=f"Erro na análise: {error_msg}",
                provider="luzia_v2_final",
                model=self.model,
                tokens_used=0,
                success=False,
                error=error_msg
            )
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Testa conexão com API LuzIA usando payload simples.
        
        Returns:
            Dict: Resultado do teste
        """
        try:
            self.logger.info("Testando conexão com LuzIA...")
            
            # Payload de teste simples
            test_payload = self.create_complete_payload(
                system_prompt="Você é um assistente útil. Responda em português brasileiro.",
                user_prompt="Diga apenas 'Conexão com LuzIA v2.0.0 funcionando corretamente' em português."
            )
            
            # Submeter teste
            response = self.submit_request(test_payload)
            content = self.extract_response_content(response)
            
            return {
                "success": True,
                "message": "✅ Conexão com LuzIA v2.0.0 OK",
                "response": content,
                "model": self.model,
                "token_splitting": self.enable_token_splitting
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"❌ Erro na conexão: {str(e)}",
                "response": None,
                "model": self.model,
                "token_splitting": self.enable_token_splitting
            }

