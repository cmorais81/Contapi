"""
Provedor LuzIA final corrigido para COBOL AI Engine.
Corrige o payload JSON que estava sendo cortado no final.
"""

import os
import json
import logging
import warnings
from typing import Dict, Any, Optional, List
from datetime import datetime

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse


class LuziaProviderFinal(BaseProvider):
    """
    Provedor LuzIA final com payload JSON completo e correto.
    
    Corrige:
    1. "Input should be a valid list" - input deve ser lista de mensagens
    2. Payload JSON cortado - estrutura completa
    3. Headers corretos para API LuzIA
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor LuzIA final.
        """
        super().__init__(config)
        
        if not REQUESTS_AVAILABLE:
            raise ImportError("requests é necessário para o LuziaProvider")
        
        # Configurações
        self.client_id = config.get('client_id', os.getenv('LUZIA_CLIENT_ID'))
        self.client_secret = config.get('client_secret', os.getenv('LUZIA_CLIENT_SECRET'))
        self.sso_endpoint = config.get('auth_url', 'https://login.azure.pass.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token')
        
        # URLs da API
        self.base_url = "https://prd-api-aws.santanderbr.dev.corp/genai_services/v1"
        self.model = config.get('model', 'azure-gpt-4o-mini')
        
        # Configurações
        self.temperature = config.get('temperature', 0.1)
        self.timeout = config.get('timeout', 120.0)
        
        # Token de acesso
        self._token = None
        
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"LuzIA Provider Final inicializado - Modelo: {self.model}")
    
    def get_token(self) -> str:
        """
        Obtém token OAuth2.
        """
        try:
            # Payload OAuth2
            request_body = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            # Headers
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': '*/*'
            }
            
            # Fazer requisição
            response = requests.post(
                self.sso_endpoint,
                headers=headers,
                data=request_body,
                verify=False,
                timeout=30
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self._token = token_data.get('access_token')
                self.logger.info("Token OAuth2 obtido com sucesso")
                return self._token
            else:
                raise Exception(f"Erro ao obter token: {response.status_code} - {response.text}")
                
        except Exception as e:
            self.logger.error(f"Erro ao obter token: {str(e)}")
            raise
    
    def create_complete_payload(self, system_prompt: str, user_prompt: str) -> Dict[str, Any]:
        """
        Cria payload JSON completo e correto.
        
        Baseado na análise das imagens:
        1. body.input deve ser lista de mensagens
        2. config deve ter type e obj_kwargs completos
        3. JSON deve estar completo sem cortes
        """
        # Payload completo e correto
        payload = {
            "body": {
                "input": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user", 
                        "content": user_prompt
                    }
                ]
            },
            "config": {
                "type": "catena.llm.LLMRouter",
                "obj_kwargs": {
                    "routing_model": self.model,
                    "temperature": self.temperature
                }
            }
        }
        
        return payload
    
    def submit_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Submete requisição para API LuzIA com payload completo.
        """
        # Obter token se necessário
        if not self._token:
            self.get_token()
        
        # Headers corretos baseados nas imagens
        headers = {
            "x-santander-client-id": self.client_id,
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        
        # Validar payload antes de enviar
        self.validate_payload(payload)
        
        # Log do payload para debug (apenas estrutura)
        self.logger.debug(f"Enviando payload com estrutura: {list(payload.keys())}")
        self.logger.debug(f"body.input tem {len(payload['body']['input'])} mensagens")
        
        # Fazer requisição
        try:
            response = requests.post(
                f"{self.base_url}/pipelines/submit",
                json=payload,
                headers=headers,
                timeout=self.timeout,
                verify=False
            )
            
            self.logger.debug(f"Status Code: {response.status_code}")
            
            if response.status_code == 200:
                return response.json()
            else:
                # Log detalhado do erro
                error_msg = f"Erro na API LuzIA: {response.status_code} - {response.text}"
                self.logger.error(error_msg)
                raise Exception(error_msg)
                
        except requests.exceptions.RequestException as e:
            error_msg = f"Erro de conexão com LuzIA: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)
    
    def validate_payload(self, payload: Dict[str, Any]) -> None:
        """
        Valida estrutura do payload antes de enviar.
        """
        # Verificações baseadas no erro da imagem
        if "body" not in payload:
            raise ValueError("Payload deve conter 'body'")
        
        if "input" not in payload["body"]:
            raise ValueError("body deve conter 'input'")
        
        if not isinstance(payload["body"]["input"], list):
            raise ValueError("body.input deve ser uma lista")
        
        if len(payload["body"]["input"]) == 0:
            raise ValueError("body.input não pode estar vazio")
        
        if "config" not in payload:
            raise ValueError("Payload deve conter 'config'")
        
        if "type" not in payload["config"]:
            raise ValueError("config deve conter 'type'")
        
        if "obj_kwargs" not in payload["config"]:
            raise ValueError("config deve conter 'obj_kwargs'")
        
        self.logger.debug("✅ Payload validado com sucesso")
    
    def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        """
        try:
            # Verificar credenciais
            if not self.client_id or not self.client_secret:
                self.logger.warning("Credenciais LuzIA não configuradas")
                return False
            
            # Tentar obter token
            self.get_token()
            return True
            
        except Exception as e:
            self.logger.error(f"LuzIA não disponível: {str(e)}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Analisa código COBOL usando LuzIA com payload completo.
        """
        try:
            # Preparar prompts
            system_prompt = """
Você é um especialista em análise de código COBOL com mais de 20 anos de experiência.
Responda todas as perguntas em português brasileiro de forma clara e técnica.
Analise o código fornecido de maneira detalhada, identificando:
- Estrutura e organização do programa
- Lógica de negócio implementada
- Dependências e relacionamentos
- Pontos críticos e considerações técnicas

Não use brackets, asteriscos ou formatação especial na resposta.
Seja direto e objetivo nas explicações.
"""
            
            user_prompt = f"""
Analise o seguinte programa COBOL:

NOME DO PROGRAMA: {request.program_name}

CÓDIGO COBOL:
{request.program_code}

PERGUNTAS PARA ANÁLISE:
{chr(10).join(f"{i+1}. {q}" for i, q in enumerate(request.questions))}

Forneça uma análise completa e detalhada respondendo a cada pergunta de forma clara e técnica.
Organize a resposta de forma estruturada e fácil de entender.
"""
            
            # Criar payload completo
            payload = self.create_complete_payload(system_prompt, user_prompt)
            
            # Submeter requisição
            response_data = self.submit_request(payload)
            
            # Processar resposta
            analysis_text = self.extract_response_content(response_data)
            
            # Calcular tokens (estimativa)
            input_tokens = len(system_prompt.split()) + len(user_prompt.split())
            output_tokens = len(analysis_text.split())
            
            return AIResponse(
                content=analysis_text,
                provider="luzia_final",
                model=self.model,
                tokens_used=input_tokens + output_tokens,
                success=True
            )
            
        except Exception as e:
            error_msg = f"Erro na análise LuzIA: {str(e)}"
            self.logger.error(error_msg)
            
            return AIResponse(
                content=f"Erro na análise: {error_msg}",
                provider="luzia_final",
                model=self.model,
                tokens_used=0,
                success=False,
                error=error_msg
            )
    
    def extract_response_content(self, response_data: Dict[str, Any]) -> str:
        """
        Extrai conteúdo da resposta da API LuzIA.
        """
        # Tentar diferentes estruturas de resposta
        if isinstance(response_data, dict):
            # Estrutura 1: result.output
            if 'result' in response_data and 'output' in response_data['result']:
                return str(response_data['result']['output'])
            
            # Estrutura 2: output direto
            if 'output' in response_data:
                return str(response_data['output'])
            
            # Estrutura 3: content
            if 'content' in response_data:
                return str(response_data['content'])
            
            # Estrutura 4: response
            if 'response' in response_data:
                return str(response_data['response'])
        
        # Fallback - usar toda a resposta como string
        return str(response_data)
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Testa conexão com API LuzIA usando payload simples.
        """
        try:
            # Payload de teste simples
            test_payload = self.create_complete_payload(
                system_prompt="Você é um assistente útil. Responda em português brasileiro.",
                user_prompt="Diga apenas 'Conexão com LuzIA funcionando corretamente' em português."
            )
            
            # Submeter teste
            response = self.submit_request(test_payload)
            
            return {
                "success": True,
                "message": "Conexão com LuzIA OK",
                "response": self.extract_response_content(response)
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Erro na conexão: {str(e)}",
                "response": None
            }


# Alias para compatibilidade
LuziaProvider = LuziaProviderFinal

