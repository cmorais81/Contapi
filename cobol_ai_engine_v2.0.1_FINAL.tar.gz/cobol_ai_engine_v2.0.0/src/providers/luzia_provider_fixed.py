"""
Provedor LuzIA corrigido para COBOL AI Engine.
Corrige o erro de validação de request baseado na análise do erro 400.
"""

import os
import json
import logging
import asyncio
import warnings
from typing import Dict, Any, Optional, List
from datetime import datetime

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')

try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    HTTPX_AVAILABLE = False

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

from .base_provider import BaseProvider, AIRequest, AIResponse


class LuziaProviderFixed(BaseProvider):
    """
    Provedor LuzIA corrigido com payload estruturado corretamente.
    
    Corrige o erro: "Input should be a valid list" no campo 'input' de 'obj_kwargs'
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor LuzIA corrigido.
        
        Args:
            config: Configuração do provedor
        """
        super().__init__(config)
        
        # Verificar dependências
        if not HTTPX_AVAILABLE and not REQUESTS_AVAILABLE:
            raise ImportError("httpx ou requests é necessário para o LuziaProvider")
        
        # Configurações baseadas no código funcional
        self.client_id = config.get('client_id', os.getenv('LUZIA_CLIENT_ID', '71530749-db0a-424c-8a1c-72bf90315afa'))
        self.client_secret = config.get('client_secret', os.getenv('LUZIA_CLIENT_SECRET', '90a337834c9vH9zXAqc3D0g0031f73'))
        self.sso_endpoint = config.get('auth_url', 'https://login.azure.pass.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token')
        
        # URLs da API
        self.base_url = "https://prd-api-aws.santanderbr.dev.corp/genai_services/v1"
        self.model = config.get('model', 'azure-gpt-4o-mini')
        
        # Configurações
        self.temperature = config.get('temperature', 0.1)
        self.timeout = config.get('timeout', 120.0)
        
        # Token de acesso
        self._token = None
        
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info(f"LuzIA Provider Fixed inicializado - Modelo: {self.model}")
    
    def get_token(self) -> str:
        """
        Obtém token OAuth2.
        """
        try:
            # Payload OAuth2
            request_body = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            # Headers
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': '*/*'
            }
            
            # Fazer requisição
            if REQUESTS_AVAILABLE:
                response = requests.post(
                    self.sso_endpoint,
                    headers=headers,
                    data=request_body,
                    verify=False,
                    timeout=30
                )
                
                if response.status_code == 200:
                    token_data = response.json()
                    self._token = token_data.get('access_token')
                    self.logger.info("Token OAuth2 obtido com sucesso")
                    return self._token
                else:
                    raise Exception(f"Erro ao obter token: {response.status_code} - {response.text}")
            else:
                raise Exception("requests não disponível")
                
        except Exception as e:
            self.logger.error(f"Erro ao obter token: {str(e)}")
            raise
    
    def create_correct_payload(self, system_prompt: str, user_prompt: str) -> Dict[str, Any]:
        """
        Cria payload corrigido baseado na análise do erro.
        
        O erro mostrava que 'input' deve ser uma lista válida.
        Corrigindo a estrutura do payload.
        """
        # Payload corrigido - 'input' deve ser uma lista de mensagens
        payload = {
            "body": {
                "input": [  # CORREÇÃO: input deve ser uma lista
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user", 
                        "content": user_prompt
                    }
                ]
            },
            "config": {
                "type": "catena.llm.LLMRouter",
                "obj_kwargs": {
                    "routing_model": self.model,
                    "temperature": self.temperature
                }
            }
        }
        
        return payload
    
    def submit_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Submete requisição para API LuzIA com payload corrigido.
        """
        # Obter token se necessário
        if not self._token:
            self.get_token()
        
        # Headers corretos
        headers = {
            "x-santander-client-id": self.client_id,
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        
        # Log do payload para debug
        self.logger.debug(f"Payload enviado: {json.dumps(payload, indent=2)}")
        
        # Fazer requisição
        if REQUESTS_AVAILABLE:
            response = requests.post(
                f"{self.base_url}/pipelines/submit",
                json=payload,
                headers=headers,
                timeout=self.timeout,
                verify=False
            )
            
            self.logger.debug(f"Status Code: {response.status_code}")
            self.logger.debug(f"Response: {response.text}")
            
            if response.status_code == 200:
                return response.json()
            else:
                # Log detalhado do erro
                error_msg = f"Erro na API LuzIA: {response.status_code} - {response.text}"
                self.logger.error(error_msg)
                raise Exception(error_msg)
        else:
            raise Exception("requests não disponível")
    
    def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        """
        try:
            # Verificar credenciais
            if not self.client_id or not self.client_secret:
                self.logger.warning("Credenciais LuzIA não configuradas")
                return False
            
            # Tentar obter token
            self.get_token()
            return True
            
        except Exception as e:
            self.logger.error(f"LuzIA não disponível: {str(e)}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Analisa código COBOL usando LuzIA com payload corrigido.
        """
        try:
            # Preparar prompts
            system_prompt = """
Você é um especialista em análise de código COBOL. 
Responda todas as perguntas em português brasileiro.
Analise o código fornecido de forma detalhada e técnica.
Não use brackets ou formatação especial na resposta.
"""
            
            user_prompt = f"""
Analise o seguinte programa COBOL:

Nome do programa: {request.program_name}

Código COBOL:
{request.program_code}

Perguntas para análise:
{chr(10).join(f"{i+1}. {q}" for i, q in enumerate(request.questions))}

Forneça uma análise detalhada respondendo a cada pergunta de forma clara e técnica.
"""
            
            # Criar payload corrigido
            payload = self.create_correct_payload(system_prompt, user_prompt)
            
            # Submeter requisição
            response_data = self.submit_request(payload)
            
            # Processar resposta
            if 'result' in response_data and 'output' in response_data['result']:
                analysis_text = response_data['result']['output']
            elif 'output' in response_data:
                analysis_text = response_data['output']
            else:
                # Fallback - usar toda a resposta como string
                analysis_text = str(response_data)
            
            # Calcular tokens (estimativa)
            input_tokens = len(system_prompt.split()) + len(user_prompt.split())
            output_tokens = len(analysis_text.split())
            
            return AIResponse(
                content=analysis_text,
                provider="luzia_fixed",
                model=self.model,
                tokens_used=input_tokens + output_tokens,
                success=True
            )
            
        except Exception as e:
            error_msg = f"Erro na análise LuzIA: {str(e)}"
            self.logger.error(error_msg)
            
            return AIResponse(
                content=f"Erro na análise: {error_msg}",
                provider="luzia_fixed",
                model=self.model,
                tokens_used=0,
                success=False,
                error=error_msg
            )
    
    def test_connection(self) -> Dict[str, Any]:
        """
        Testa conexão com API LuzIA usando payload simples.
        """
        try:
            # Payload de teste simples
            test_payload = self.create_correct_payload(
                system_prompt="Você é um assistente útil.",
                user_prompt="Diga apenas 'Conexão OK' em português."
            )
            
            # Submeter teste
            response = self.submit_request(test_payload)
            
            return {
                "success": True,
                "message": "Conexão com LuzIA OK",
                "response": response
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": f"Erro na conexão: {str(e)}",
                "response": None
            }


# Alias para compatibilidade
LuziaProvider = LuziaProviderFixed

