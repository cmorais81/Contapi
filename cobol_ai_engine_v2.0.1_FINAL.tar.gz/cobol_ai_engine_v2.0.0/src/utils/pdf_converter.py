"""
COBOL AI Engine v1.6.0 - Conversor Markdown para PDF
Utilitário para converter documentação Markdown em PDF.
"""

import os
import logging
import subprocess
from typing import Optional, Dict, Any
from pathlib import Path


class MarkdownToPDFConverter:
    """Conversor de Markdown para PDF usando múltiplas estratégias."""
    
    def __init__(self):
        """Inicializa o conversor."""
        self.logger = logging.getLogger(__name__)
        self.available_methods = self._check_available_methods()
        
    def _check_available_methods(self) -> Dict[str, bool]:
        """Verifica quais métodos de conversão estão disponíveis."""
        methods = {
            'weasyprint': False,
            'markdown_pdf': False,
            'pandoc': False,
            'custom_html': True  # Sempre disponível
        }
        
        # Verificar WeasyPrint
        try:
            import weasyprint
            methods['weasyprint'] = True
            self.logger.info("WeasyPrint disponível")
        except ImportError:
            pass
        
        # Verificar markdown-pdf (via npm)
        try:
            result = subprocess.run(['which', 'markdown-pdf'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                methods['markdown_pdf'] = True
                self.logger.info("markdown-pdf disponível")
        except Exception:
            pass
        
        # Verificar Pandoc
        try:
            result = subprocess.run(['which', 'pandoc'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                methods['pandoc'] = True
                self.logger.info("Pandoc disponível")
        except Exception:
            pass
        
        return methods
    
    def get_status(self) -> Dict[str, Any]:
        """Retorna status dos métodos de conversão."""
        available_count = sum(1 for available in self.available_methods.values() if available)
        
        # Determinar método preferido
        preference_order = ['weasyprint', 'pandoc', 'markdown_pdf', 'custom_html']
        preferred_method = None
        for method in preference_order:
            if self.available_methods.get(method, False):
                preferred_method = method
                break
        
        return {
            'available_methods': self.available_methods,
            'total_methods': available_count,
            'preferred_method': preferred_method
        }
    
    def convert_file(self, markdown_file: str, pdf_file: str, method: Optional[str] = None) -> bool:
        """
        Converte um arquivo Markdown para PDF.
        
        Args:
            markdown_file: Caminho do arquivo Markdown
            pdf_file: Caminho do arquivo PDF de saída
            method: Método específico a usar (opcional)
            
        Returns:
            True se a conversão foi bem-sucedida
        """
        if not os.path.exists(markdown_file):
            self.logger.error(f"Arquivo Markdown não encontrado: {markdown_file}")
            return False
        
        # Criar diretório de saída se não existir
        os.makedirs(os.path.dirname(pdf_file), exist_ok=True)
        
        # Determinar métodos a tentar
        if method and method in self.available_methods:
            methods_to_try = [method]
        else:
            # Tentar métodos em ordem de preferência
            methods_to_try = [
                'weasyprint', 
                'pandoc',
                'markdown_pdf',
                'custom_html'
            ]
            # Filtrar apenas métodos disponíveis
            methods_to_try = [m for m in methods_to_try if self.available_methods.get(m, False)]
        
        # Tentar cada método
        for method_name in methods_to_try:
            try:
                self.logger.info(f"Tentando conversão com método: {method_name}")
                
                if method_name == 'weasyprint':
                    success = self._convert_with_weasyprint(markdown_file, pdf_file)
                elif method_name == 'pandoc':
                    success = self._convert_with_pandoc(markdown_file, pdf_file)
                elif method_name == 'markdown_pdf':
                    success = self._convert_with_markdown_pdf(markdown_file, pdf_file)
                elif method_name == 'custom_html':
                    success = self._convert_with_custom_html(markdown_file, pdf_file)
                else:
                    continue
                
                if success:
                    self.logger.info(f"Conversão bem-sucedida com {method_name}: {pdf_file}")
                    return True
                    
            except Exception as e:
                self.logger.warning(f"Erro no método {method_name}: {str(e)}")
                continue
        
        self.logger.error("Todos os métodos de conversão falharam")
        return False
    
    def _convert_with_weasyprint(self, markdown_file: str, pdf_file: str) -> bool:
        """Converte usando WeasyPrint."""
        try:
            import weasyprint
            import markdown
            
            # Ler arquivo Markdown
            with open(markdown_file, 'r', encoding='utf-8') as f:
                markdown_content = f.read()
            
            # Converter Markdown para HTML
            html_content = markdown.markdown(markdown_content, extensions=['tables', 'fenced_code'])
            
            # Adicionar CSS básico
            html_with_css = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }}
                    h1, h2, h3 {{ color: #333; }}
                    code {{ background-color: #f4f4f4; padding: 2px 4px; border-radius: 3px; }}
                    pre {{ background-color: #f4f4f4; padding: 10px; border-radius: 5px; overflow-x: auto; }}
                    table {{ border-collapse: collapse; width: 100%; }}
                    th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                    th {{ background-color: #f2f2f2; }}
                </style>
            </head>
            <body>
                {html_content}
            </body>
            </html>
            """
            
            # Converter HTML para PDF
            weasyprint.HTML(string=html_with_css).write_pdf(pdf_file)
            return os.path.exists(pdf_file)
            
        except Exception as e:
            self.logger.warning(f"Erro no WeasyPrint: {str(e)}")
            return False
    
    def _convert_with_pandoc(self, markdown_file: str, pdf_file: str) -> bool:
        """Converte usando Pandoc."""
        try:
            result = subprocess.run([
                'pandoc', 
                markdown_file, 
                '-o', pdf_file,
                '--pdf-engine=wkhtmltopdf'
            ], capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                return os.path.exists(pdf_file)
            else:
                self.logger.warning(f"Pandoc falhou: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            self.logger.warning("Pandoc timeout")
            return False
        except Exception as e:
            self.logger.warning(f"Erro no Pandoc: {str(e)}")
            return False
    
    def _convert_with_markdown_pdf(self, markdown_file: str, pdf_file: str) -> bool:
        """Converte usando markdown-pdf."""
        try:
            result = subprocess.run([
                'markdown-pdf', 
                markdown_file,
                '-o', pdf_file
            ], capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                return os.path.exists(pdf_file)
            else:
                self.logger.warning(f"markdown-pdf falhou: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            self.logger.warning("markdown-pdf timeout")
            return False
        except Exception as e:
            self.logger.warning(f"Erro no markdown-pdf: {str(e)}")
            return False
    
    def _convert_with_custom_html(self, markdown_file: str, pdf_file: str) -> bool:
        """Converte usando método customizado HTML → PDF."""
        try:
            import markdown
            from weasyprint import HTML, CSS
            
            # Ler arquivo Markdown
            with open(markdown_file, 'r', encoding='utf-8') as f:
                markdown_content = f.read()
            
            # Converter Markdown para HTML
            html_content = markdown.markdown(
                markdown_content, 
                extensions=['tables', 'fenced_code', 'codehilite']
            )
            
            # CSS profissional
            css_content = """
            @page {
                margin: 2cm;
                size: A4;
            }
            body {
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                font-size: 11pt;
                line-height: 1.6;
                color: #333;
                max-width: none;
            }
            h1 {
                color: #2c3e50;
                font-size: 24pt;
                margin-top: 30pt;
                margin-bottom: 15pt;
                border-bottom: 2px solid #3498db;
                padding-bottom: 5pt;
            }
            h2 {
                color: #34495e;
                font-size: 18pt;
                margin-top: 25pt;
                margin-bottom: 12pt;
            }
            h3 {
                color: #34495e;
                font-size: 14pt;
                margin-top: 20pt;
                margin-bottom: 10pt;
            }
            p {
                margin-bottom: 10pt;
                text-align: justify;
            }
            code {
                background-color: #f8f9fa;
                padding: 2pt 4pt;
                border-radius: 3pt;
                font-family: 'Courier New', monospace;
                font-size: 10pt;
            }
            pre {
                background-color: #f8f9fa;
                padding: 12pt;
                border-radius: 5pt;
                border-left: 4px solid #3498db;
                overflow-x: auto;
                font-family: 'Courier New', monospace;
                font-size: 9pt;
                line-height: 1.4;
            }
            table {
                border-collapse: collapse;
                width: 100%;
                margin: 15pt 0;
            }
            th, td {
                border: 1px solid #bdc3c7;
                padding: 8pt;
                text-align: left;
            }
            th {
                background-color: #ecf0f1;
                font-weight: bold;
                color: #2c3e50;
            }
            ul, ol {
                margin-bottom: 10pt;
                padding-left: 20pt;
            }
            li {
                margin-bottom: 5pt;
            }
            blockquote {
                border-left: 4px solid #3498db;
                padding-left: 15pt;
                margin-left: 0;
                font-style: italic;
                color: #555;
            }
            """
            
            # HTML completo
            html_with_css = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>Documentação COBOL</title>
            </head>
            <body>
                {html_content}
            </body>
            </html>
            """
            
            # Converter para PDF
            HTML(string=html_with_css).write_pdf(
                pdf_file,
                stylesheets=[CSS(string=css_content)]
            )
            
            return os.path.exists(pdf_file)
            
        except Exception as e:
            self.logger.warning(f"Erro no método customizado: {str(e)}")
            return False
    
    def convert_directory(self, input_dir: str, output_dir: str, pattern: str = "*.md") -> Dict[str, bool]:
        """
        Converte todos os arquivos Markdown de um diretório.
        
        Args:
            input_dir: Diretório de entrada
            output_dir: Diretório de saída
            pattern: Padrão de arquivos (default: "*.md")
            
        Returns:
            Dicionário com resultado de cada conversão
        """
        import glob
        
        # Criar diretório de saída
        os.makedirs(output_dir, exist_ok=True)
        
        # Encontrar arquivos
        search_pattern = os.path.join(input_dir, pattern)
        markdown_files = glob.glob(search_pattern)
        
        if not markdown_files:
            self.logger.warning(f"Nenhum arquivo encontrado com padrão: {search_pattern}")
            return {}
        
        results = {}
        total_files = len(markdown_files)
        
        print(f"Convertendo {total_files} arquivos para PDF...")
        
        for i, markdown_file in enumerate(markdown_files, 1):
            filename = os.path.basename(markdown_file)
            pdf_filename = os.path.splitext(filename)[0] + '.pdf'
            pdf_file = os.path.join(output_dir, pdf_filename)
            
            print(f"[{i}/{total_files}] Convertendo: {filename}")
            
            success = self.convert_file(markdown_file, pdf_file)
            results[filename] = success
            
            if success:
                print(f"[{i}/{total_files}] ✅ {filename}")
            else:
                print(f"[{i}/{total_files}] ❌ {filename}")
        
        return results
    
    def get_preferred_method(self) -> Optional[str]:
        """Retorna o método preferido de conversão."""
        preference_order = ['weasyprint', 'pandoc', 'markdown_pdf', 'custom_html']
        for method in preference_order:
            if self.available_methods.get(method, False):
                return method
        return None

