#!/usr/bin/env python3
"""Teste da API do COBOL AI Engine v2.0.0"""

import cobol_ai_engine as cae

print("✅ COBOL AI Engine v2.0.0 carregado!")

# Código COBOL de teste
codigo = '''
IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE-API.
PROCEDURE DIVISION.
DISPLAY 'Testando API v2.0.0'.
STOP RUN.
'''

# Testar análise
print("🔄 Testando análise...")
resultado = cae.analyze_cobol(codigo)

print(f"Sucesso: {resultado['success']}")
print(f"Programa: {resultado['program_name']}")

if resultado['success']:
    print(f"Provedor: {resultado['provider_used']}")
    print("✅ API funcionando perfeitamente!")
    print(f"Documentação (primeiras 200 chars): {resultado['documentation'][:200]}...")
else:
    print(f"❌ Erro: {resultado['error']}")

print("\n🎉 Teste concluído!")

