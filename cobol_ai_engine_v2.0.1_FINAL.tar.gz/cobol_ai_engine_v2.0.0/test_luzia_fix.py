#!/usr/bin/env python3
"""
Script de teste para o provider LuzIA corrigido.
Testa a correção do erro 400 "Input should be a valid list".
"""

import os
import sys
import json
import logging

# Adicionar path do projeto
sys.path.append('/home/ubuntu/cobol_ai_engine_v2.0.0')

from src.providers.luzia_provider_fixed import LuziaProviderFixed
from src.providers.base_provider import AIRequest

# Configurar logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def test_luzia_fixed():
    """
    Testa o provider LuzIA corrigido.
    """
    print("🔧 Testando LuzIA Provider Corrigido")
    print("=" * 50)
    
    # Configuração do provider
    config = {
        'client_id': os.getenv('LUZIA_CLIENT_ID', '71530749-db0a-424c-8a1c-72bf90315afa'),
        'client_secret': os.getenv('LUZIA_CLIENT_SECRET', '90a337834c9vH9zXAqc3D0g0031f73'),
        'model': 'azure-gpt-4o-mini',
        'temperature': 0.1,
        'timeout': 60.0
    }
    
    # Verificar credenciais
    if not config['client_id'] or not config['client_secret']:
        print("❌ Credenciais LuzIA não configuradas")
        print("Configure LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET")
        return False
    
    try:
        # Inicializar provider
        print("🚀 Inicializando LuzIA Provider Fixed...")
        provider = LuziaProviderFixed(config)
        
        # Teste 1: Verificar disponibilidade
        print("\n📡 Teste 1: Verificando disponibilidade...")
        is_available = provider.is_available()
        print(f"   Disponível: {'✅' if is_available else '❌'}")
        
        if not is_available:
            print("❌ Provider não disponível")
            return False
        
        # Teste 2: Teste de conexão simples
        print("\n🔗 Teste 2: Testando conexão...")
        connection_test = provider.test_connection()
        print(f"   Conexão: {'✅' if connection_test['success'] else '❌'}")
        
        if connection_test['success']:
            print(f"   Resposta: {connection_test.get('response', 'N/A')}")
        else:
            print(f"   Erro: {connection_test['message']}")
            return False
        
        # Teste 3: Análise de código COBOL simples
        print("\n📊 Teste 3: Análise de código COBOL...")
        
        # Código COBOL de teste
        cobol_code = """
IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE001.
AUTHOR. TESTE.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CONTADOR PIC 9(03) VALUE ZEROS.

PROCEDURE DIVISION.
0000-MAIN.
    DISPLAY 'PROGRAMA DE TESTE'
    ADD 1 TO WS-CONTADOR
    DISPLAY 'CONTADOR: ' WS-CONTADOR
    GOBACK.
"""
        
        # Criar request
        request = AIRequest(
            program_name="TESTE001",
            program_code=cobol_code,
            questions=[
                "O que este programa faz funcionalmente?",
                "Qual é a estrutura técnica do programa?",
                "Quais são as variáveis utilizadas?"
            ]
        )
        
        # Executar análise
        response = provider.analyze(request)
        
        print(f"   Sucesso: {'✅' if response.success else '❌'}")
        print(f"   Provider: {response.provider}")
        print(f"   Model: {response.model}")
        print(f"   Tokens: {response.tokens_used}")
        
        if response.success:
            print(f"   Análise (primeiros 200 chars): {response.content[:200]}...")
        else:
            print(f"   Erro: {response.error}")
        
        return response.success
        
    except Exception as e:
        print(f"❌ Erro no teste: {str(e)}")
        return False

def test_payload_structure():
    """
    Testa especificamente a estrutura do payload corrigido.
    """
    print("\n🔍 Teste de Estrutura do Payload")
    print("=" * 40)
    
    config = {
        'client_id': 'test-client-id',
        'client_secret': 'test-client-secret',
        'model': 'azure-gpt-4o-mini',
        'temperature': 0.1
    }
    
    provider = LuziaProviderFixed(config)
    
    # Criar payload de teste
    system_prompt = "Você é um assistente útil."
    user_prompt = "Teste de payload."
    
    payload = provider.create_correct_payload(system_prompt, user_prompt)
    
    print("📋 Estrutura do Payload Corrigido:")
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    
    # Verificar estrutura
    checks = [
        ("body existe", "body" in payload),
        ("body.input existe", "input" in payload.get("body", {})),
        ("body.input é lista", isinstance(payload.get("body", {}).get("input"), list)),
        ("config existe", "config" in payload),
        ("config.type existe", "type" in payload.get("config", {})),
        ("config.obj_kwargs existe", "obj_kwargs" in payload.get("config", {}))
    ]
    
    print("\n✅ Verificações de Estrutura:")
    for check_name, check_result in checks:
        status = "✅" if check_result else "❌"
        print(f"   {status} {check_name}")
    
    return all(check[1] for check in checks)

if __name__ == "__main__":
    print("🧪 TESTE DO LUZIA PROVIDER CORRIGIDO")
    print("=" * 60)
    
    # Teste 1: Estrutura do payload
    payload_ok = test_payload_structure()
    
    # Teste 2: Funcionalidade completa
    if payload_ok:
        luzia_ok = test_luzia_fixed()
        
        print("\n" + "=" * 60)
        print("📊 RESULTADO DOS TESTES:")
        print(f"   Estrutura do Payload: {'✅' if payload_ok else '❌'}")
        print(f"   Funcionalidade LuzIA: {'✅' if luzia_ok else '❌'}")
        
        if payload_ok and luzia_ok:
            print("\n🎉 TODOS OS TESTES PASSARAM!")
            print("   O provider LuzIA foi corrigido com sucesso.")
        else:
            print("\n⚠️ ALGUNS TESTES FALHARAM")
            print("   Verifique os logs acima para detalhes.")
    else:
        print("\n❌ ESTRUTURA DO PAYLOAD INCORRETA")
        print("   Não executando teste de funcionalidade.")

