#!/usr/bin/env python3
"""
Teste final do provider LuzIA corrigido.
Testa a correção do payload JSON cortado e erro 400.
"""

import os
import sys
import json
import logging

# Adicionar path do projeto
sys.path.append('/home/ubuntu/cobol_ai_engine_v2.0.0')

from src.providers.luzia_provider import LuziaProvider
from src.providers.base_provider import AIRequest

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def test_payload_structure():
    """
    Testa a estrutura do payload corrigido.
    """
    print("🔍 TESTE 1: Estrutura do Payload")
    print("=" * 40)
    
    config = {
        'client_id': 'test-client-id',
        'client_secret': 'test-client-secret',
        'model': 'azure-gpt-4o-mini',
        'temperature': 0.1
    }
    
    provider = LuziaProvider(config)
    
    # Criar payload de teste
    system_prompt = "Você é um especialista em COBOL."
    user_prompt = "Analise este programa COBOL de teste."
    
    payload = provider.create_complete_payload(system_prompt, user_prompt)
    
    print("📋 Payload Gerado:")
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    
    # Verificar estrutura
    checks = [
        ("✅ body existe", "body" in payload),
        ("✅ body.input existe", "input" in payload.get("body", {})),
        ("✅ body.input é lista", isinstance(payload.get("body", {}).get("input"), list)),
        ("✅ body.input tem mensagens", len(payload.get("body", {}).get("input", [])) > 0),
        ("✅ config existe", "config" in payload),
        ("✅ config.type existe", "type" in payload.get("config", {})),
        ("✅ config.obj_kwargs existe", "obj_kwargs" in payload.get("config", {})),
        ("✅ routing_model definido", "routing_model" in payload.get("config", {}).get("obj_kwargs", {})),
        ("✅ temperature definida", "temperature" in payload.get("config", {}).get("obj_kwargs", {}))
    ]
    
    print("\n🔍 Verificações:")
    all_ok = True
    for check_name, check_result in checks:
        if check_result:
            print(f"   {check_name}")
        else:
            print(f"   ❌ {check_name.replace('✅', '')}")
            all_ok = False
    
    # Validar payload
    try:
        provider.validate_payload(payload)
        print("   ✅ Validação do payload passou")
    except Exception as e:
        print(f"   ❌ Validação falhou: {e}")
        all_ok = False
    
    return all_ok

def test_mock_request():
    """
    Testa requisição simulada (sem conectar à API real).
    """
    print("\n🧪 TESTE 2: Requisição Simulada")
    print("=" * 40)
    
    config = {
        'client_id': os.getenv('LUZIA_CLIENT_ID', 'test-client-id'),
        'client_secret': os.getenv('LUZIA_CLIENT_SECRET', 'test-client-secret'),
        'model': 'azure-gpt-4o-mini',
        'temperature': 0.1,
        'timeout': 30.0
    }
    
    provider = LuziaProvider(config)
    
    # Código COBOL de teste
    cobol_code = """
IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE001.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CONTADOR PIC 9(03) VALUE ZEROS.

PROCEDURE DIVISION.
0000-MAIN.
    DISPLAY 'TESTE'
    ADD 1 TO WS-CONTADOR
    GOBACK.
"""
    
    # Criar request
    questions = [
        "O que este programa faz?",
        "Quais são as variáveis utilizadas?",
        "Qual é a estrutura do programa?"
    ]
    
    prompt = f"Analise o programa COBOL {cobol_code} e responda: {'; '.join(questions)}"
    
    request = AIRequest(
        prompt=prompt,
        program_name="TESTE001",
        program_code=cobol_code
    )
    
    # Testar criação do payload
    try:
        system_prompt = "Você é um especialista em COBOL."
        user_prompt = f"Analise: {request.program_name}\n{request.program_code}\n\nPerguntas: {'; '.join(questions)}"
        
        payload = provider.create_complete_payload(system_prompt, user_prompt)
        
        print("✅ Payload criado com sucesso")
        print(f"   Mensagens no input: {len(payload['body']['input'])}")
        print(f"   Modelo: {payload['config']['obj_kwargs']['routing_model']}")
        print(f"   Temperatura: {payload['config']['obj_kwargs']['temperature']}")
        
        # Verificar tamanho do conteúdo
        total_chars = len(system_prompt) + len(user_prompt)
        print(f"   Total de caracteres: {total_chars}")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro ao criar payload: {e}")
        return False

def test_error_handling():
    """
    Testa tratamento de erros.
    """
    print("\n🛡️ TESTE 3: Tratamento de Erros")
    print("=" * 40)
    
    config = {
        'client_id': '',  # Credencial vazia para testar erro
        'client_secret': '',
        'model': 'azure-gpt-4o-mini'
    }
    
    provider = LuziaProvider(config)
    
    # Teste 1: Credenciais vazias
    is_available = provider.is_available()
    print(f"   Credenciais vazias: {'✅' if not is_available else '❌'} (deve ser False)")
    
    # Teste 2: Payload inválido
    try:
        invalid_payload = {"invalid": "structure"}
        provider.validate_payload(invalid_payload)
        print("   ❌ Validação deveria ter falhado")
        return False
    except ValueError:
        print("   ✅ Validação de payload inválido funcionou")
    
    # Teste 3: Extração de resposta
    test_responses = [
        {"result": {"output": "Teste 1"}},
        {"output": "Teste 2"},
        {"content": "Teste 3"},
        "Teste 4 direto"
    ]
    
    for i, test_response in enumerate(test_responses, 1):
        content = provider.extract_response_content(test_response)
        expected = f"Teste {i}" if i < 4 else "Teste 4 direto"
        if expected in content:
            print(f"   ✅ Extração de resposta {i} funcionou")
        else:
            print(f"   ❌ Extração de resposta {i} falhou")
            return False
    
    return True

if __name__ == "__main__":
    print("🧪 TESTE COMPLETO DO LUZIA PROVIDER CORRIGIDO")
    print("=" * 60)
    
    # Executar testes
    test1_ok = test_payload_structure()
    test2_ok = test_mock_request()
    test3_ok = test_error_handling()
    
    print("\n" + "=" * 60)
    print("📊 RESULTADO FINAL:")
    print(f"   Estrutura do Payload: {'✅' if test1_ok else '❌'}")
    print(f"   Requisição Simulada: {'✅' if test2_ok else '❌'}")
    print(f"   Tratamento de Erros: {'✅' if test3_ok else '❌'}")
    
    if test1_ok and test2_ok and test3_ok:
        print("\n🎉 TODOS OS TESTES PASSARAM!")
        print("   O provider LuzIA foi corrigido com sucesso.")
        print("   Correções aplicadas:")
        print("   • Payload JSON completo (não cortado)")
        print("   • body.input como lista de mensagens")
        print("   • Validação completa da estrutura")
        print("   • Tratamento robusto de erros")
        print("   • Extração flexível de respostas")
    else:
        print("\n⚠️ ALGUNS TESTES FALHARAM")
        print("   Verifique os logs acima para detalhes.")
    
    print("\n💡 PRÓXIMOS PASSOS:")
    print("   1. Configurar LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET")
    print("   2. Testar com API real do LuzIA")
    print("   3. Integrar ao sistema principal")

