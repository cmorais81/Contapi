# Guia de Instalação e Uso - COBOL to Docs v3.0

## Instalação

### Método 1: Instalação via pip (Recomendado)

```bash
# Instalar o pacote
pip install cobol-to-docs

# Verificar instalação
cobol-to-docs --help
```

### Método 2: Instalação em Modo Desenvolvimento

```bash
# Clonar ou descompactar o projeto
cd sbr-thpf-cobol-to-docs

# Instalar em modo editável
pip install -e .

# Verificar instalação
cobol-to-docs --help
```

### Método 3: Execução Direta (Sem Instalação)

```bash
# Navegar para o diretório do projeto
cd sbr-thpf-cobol-to-docs

# Executar diretamente
python3 cobol_to_docs/runner/main.py --help
```

## Uso Básico

### Análise Simples de Programa COBOL

```bash
# Analisar um arquivo de programas COBOL
cobol-to-docs --fontes examples/fontes.txt --output resultados

# Incluir copybooks na análise
cobol-to-docs --fontes examples/fontes.txt --books examples/books.txt --output resultados
```

### Especificar Modelos de IA

```bash
# Usar modelo específico
cobol-to-docs --fontes examples/fontes.txt --models enhanced_mock

# Usar múltiplos modelos para comparação
cobol-to-docs --fontes examples/fontes.txt --models '["enhanced_mock", "luzia"]'
```

## Configuração Personalizada

### Usando Diretórios Personalizados

```bash
# Especificar diretório de configuração personalizado
cobol-to-docs --fontes programa.cbl --config-dir /minha/config

# Especificar diretório de dados RAG personalizado
cobol-to-docs --fontes programa.cbl --data-dir /minha/base-rag

# Usar arquivo de configuração específico
cobol-to-docs --fontes programa.cbl --config-file /caminho/para/config.yaml
```

### Configuração de Prompts Personalizados

```bash
# Usar arquivo de prompts personalizado
cobol-to-docs --fontes programa.cbl --prompts-file /caminho/para/prompts.yaml

# Combinar configurações personalizadas
cobol-to-docs --fontes programa.cbl \
  --config-dir /config/personalizado \
  --data-dir /dados/personalizados \
  --prompts-file /prompts/personalizados.yaml
```

## Funcionalidades Avançadas

### Análise Consolidada

```bash
# Análise consolidada de todo o sistema
cobol-to-docs --fontes sistema_completo.txt --consolidado

# Relatório único consolidado
cobol-to-docs --fontes sistema_completo.txt --relatorio-unico
```

### Análise Especializada

```bash
# Análise técnica profunda
cobol-to-docs --fontes programa.cbl --analise-especialista

# Análise detalhada da PROCEDURE DIVISION
cobol-to-docs --fontes programa.cbl --procedure-detalhada

# Análise de modernização
cobol-to-docs --fontes programa.cbl --modernizacao
```

### Geração de Relatórios

```bash
# Gerar relatórios HTML/PDF
cobol-to-docs --fontes programa.cbl --pdf

# Análise avançada com relatório HTML profissional
cobol-to-docs --fontes programa.cbl --advanced-analysis
```

## Manutenção do Sistema RAG

### Operações de Manutenção

```bash
# Verificar estatísticas da base RAG
cobol-to-docs --rag-stats

# Reindexar base de conhecimento
cobol-to-docs --rag-reindex

# Criar backup da base RAG
cobol-to-docs --rag-backup

# Limpar duplicatas
cobol-to-docs --rag-clean

# Operação combinada
cobol-to-docs --rag-stats --rag-reindex --rag-backup
```

## Verificação de Status

### Status dos Provedores

```bash
# Verificar status de todos os provedores
cobol-to-docs --status

# Verificar com configuração personalizada
cobol-to-docs --status --config-dir /minha/config
```

## Estrutura de Arquivos de Entrada

### Arquivo de Fontes (fontes.txt)
```
PROGRAMA1.CBL
PROGRAMA2.CBL
/caminho/para/PROGRAMA3.CBL
```

### Arquivo de Books (books.txt)
```
COPYBOOK1.CPY
COPYBOOK2.CPY
/caminho/para/COPYBOOK3.CPY
```

## Estrutura de Saída

### Diretório de Resultados
```
output/
├── PROGRAMA1_analise_funcional.md
├── PROGRAMA2_analise_funcional.md
├── relatorio_comparativo_modelos.md (se múltiplos modelos)
├── relatorio_custos.txt
└── ai_requests/
    ├── PROGRAMA1_ai_request.json
    └── PROGRAMA2_ai_request.json
```

## Configuração de Arquivos

### config.yaml - Exemplo
```yaml
ai:
  prompt:
    prompts_file: "prompts.yaml"

providers:
  enhanced_mock:
    enabled: true
    models:
      gpt-4:
        name: "enhanced_mock"
        max_tokens: 4000

rag:
  enabled: true
  knowledge_base_file: "cobol_knowledge_base.json"
  max_context_items: 5
  similarity_threshold: 0.7
```

### prompts.yaml - Exemplo
```yaml
prompts:
  system_prompt: |
    Você é um especialista em análise de código COBOL com mais de 20 anos de experiência.
    Analise o código fornecido identificando:
    - Estrutura e organização do programa
    - Lógica de negócio implementada
    - Dependências e relacionamentos
    - Pontos críticos e considerações técnicas
```

## Solução de Problemas

### Problemas Comuns

**Erro: Arquivo de configuração não encontrado**
```bash
# Especificar caminho explícito
cobol-to-docs --config-file /caminho/completo/config.yaml
```

**Erro: Base RAG não encontrada**
```bash
# Especificar diretório de dados
cobol-to-docs --data-dir /caminho/para/dados
```

**Erro: Provider não disponível**
```bash
# Verificar status dos providers
cobol-to-docs --status
```

### Logs e Depuração

```bash
# Aumentar nível de log para depuração
cobol-to-docs --fontes programa.cbl --log-level DEBUG
```

## Exemplos Práticos

### Análise Completa de Sistema Bancário
```bash
cobol-to-docs \
  --fontes sistema_bancario/fontes.txt \
  --books sistema_bancario/books.txt \
  --consolidado \
  --pdf \
  --output analise_sistema_bancario \
  --models '["enhanced_mock", "luzia"]'
```

### Análise com Configuração Corporativa
```bash
cobol-to-docs \
  --fontes projetos/cobol/fontes.txt \
  --config-dir /empresa/config/cobol-analyzer \
  --data-dir /empresa/dados/rag-cobol \
  --output /empresa/resultados/analise_$(date +%Y%m%d) \
  --analise-especialista \
  --pdf
```

### Manutenção Programada da Base RAG
```bash
# Script de manutenção diária
cobol-to-docs --rag-backup --rag-clean --rag-reindex --rag-stats
```

## Integração com Pipelines

### Exemplo de Script de Automação
```bash
#!/bin/bash
# Script de análise automatizada

DATA=$(date +%Y%m%d_%H%M%S)
OUTPUT_DIR="/resultados/analise_$DATA"

cobol-to-docs \
  --fontes /fontes/sistema_principal.txt \
  --books /fontes/copybooks.txt \
  --consolidado \
  --pdf \
  --output "$OUTPUT_DIR" \
  --log-level INFO

echo "Análise concluída em: $OUTPUT_DIR"
```

## Suporte

Para problemas ou dúvidas, consulte os logs gerados na pasta `logs/` e verifique a documentação completa no arquivo `README_FINAL.md`.
