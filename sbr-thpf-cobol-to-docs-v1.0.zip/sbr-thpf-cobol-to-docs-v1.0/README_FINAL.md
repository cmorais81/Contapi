# COBOL to Docs v3.0 - Sistema de Análise e Documentação COBOL

## Visão Geral

O COBOL to Docs v3.0 é uma ferramenta avançada de análise e documentação automatizada de programas COBOL que utiliza inteligência artificial e técnicas de RAG (Retrieval Augmented Generation) para gerar documentação técnica profissional.

## Principais Funcionalidades

### Análise Inteligente de Código COBOL
O sistema oferece análise completa de programas COBOL com identificação automática de estruturas, lógica de negócio, dependências e pontos críticos. A análise inclui processamento de múltiplos programas simultaneamente, suporte a copybooks complementares e detecção automática de padrões de código.

### Múltiplos Provedores de IA
A ferramenta suporta diversos modelos de inteligência artificial, incluindo providers locais e em nuvem. O sistema inclui seleção automática de modelos baseada na complexidade do código e comparação de adequação entre diferentes providers.

### Sistema RAG Avançado
Implementa técnicas de Retrieval Augmented Generation com base de conhecimento especializada em COBOL, sistemas bancários e melhores práticas de desenvolvimento. O sistema inclui auto-learning, manutenção automática da base de conhecimento e enriquecimento contextual das análises.

### Geração de Documentação Profissional
Produz documentação em múltiplos formatos (Markdown, HTML, PDF) com relatórios comparativos entre modelos, análises de custos detalhadas e documentação técnica estruturada.

## Métodos de Instalação e Execução

### Instalação via pip
```bash
pip install cobol-to-docs
cobol-to-docs --help
```

### Execução Direta
```bash
python3 cobol_to_docs/runner/main.py --fontes examples/fontes.txt
```

### Interface CLI
```bash
python3 cobol_to_docs/runner/cli.py --fontes examples/fontes.txt --output results
```

## Configuração Personalizada

### Parâmetros de Configuração
O sistema oferece flexibilidade completa para configuração através de parâmetros de linha de comando:

**Configuração de Diretórios**
- `--config-dir`: Especifica diretório de configuração personalizado
- `--data-dir`: Define diretório personalizado para base de conhecimento RAG
- `--config-file`: Arquivo de configuração específico
- `--prompts-file`: Arquivo de prompts personalizado

**Exemplos de Uso**
```bash
# Configuração personalizada completa
cobol-to-docs --fontes programa.cbl --config-dir /custom/config --data-dir /custom/data

# Arquivo de configuração específico
cobol-to-docs --fontes programa.cbl --config-file /path/to/config.yaml

# Prompts personalizados
cobol-to-docs --fontes programa.cbl --prompts-file /path/to/prompts.yaml
```

## Funcionalidades Avançadas

### Análise Consolidada
O sistema oferece análise consolidada sistêmica que processa múltiplos programas simultaneamente, identificando relacionamentos, dependências e padrões arquiteturais em todo o sistema.

### Análise Especializada
Inclui modos especializados de análise com prompts técnicos profundos, análise detalhada da PROCEDURE DIVISION e recomendações de modernização e migração.

### Manutenção RAG
Ferramentas integradas para manutenção da base de conhecimento incluindo reindexação automática, limpeza de duplicatas, backup automático e estatísticas detalhadas.

## Arquitetura e Componentes

### Resolução Robusta de Caminhos
O sistema implementa detecção automática do método de execução (pip install, execução direta, CLI) com resolução inteligente de caminhos para arquivos de configuração, dados e prompts. Inclui fallbacks automáticos e criação de configurações padrão quando necessário.

### Sistema de Configuração Unificado
ConfigManager centralizado que gerencia todas as configurações do sistema com suporte a caminhos personalizados, validação automática e carregamento condicional baseado no método de execução.

### Integração RAG Transparente
Sistema RAG integrado que enriquece automaticamente as análises com conhecimento especializado, mantém histórico de aprendizado e oferece transparência completa sobre o conhecimento utilizado.

## Estrutura do Projeto

### Diretórios Principais
- `cobol_to_docs/`: Pacote principal da aplicação
- `cobol_to_docs/runner/`: Scripts de execução (main.py, cli.py)
- `cobol_to_docs/src/`: Código fonte organizado por módulos
- `cobol_to_docs/config/`: Arquivos de configuração (config.yaml, prompts.yaml)
- `cobol_to_docs/data/`: Base de conhecimento RAG e dados auxiliares

### Módulos Principais
- `core/`: Configuração, processamento principal e gerenciamento
- `providers/`: Integração com diferentes provedores de IA
- `analyzers/`: Analisadores especializados de código COBOL
- `parsers/`: Parsers robustos para código COBOL e copybooks
- `generators/`: Geradores de documentação em múltiplos formatos
- `rag/`: Sistema RAG completo com auto-learning
- `utils/`: Utilitários para HTML, PDF, cálculo de custos

## Compatibilidade e Requisitos

### Requisitos do Sistema
- Python 3.8 ou superior
- Dependências listadas em requirements.txt
- Acesso à internet para provedores de IA em nuvem (opcional)

### Compatibilidade
O sistema foi testado e validado em múltiplos cenários de execução, garantindo funcionamento consistente independentemente do método de instalação ou execução utilizado.

## Testes e Validação

### Testes Implementados
O sistema inclui testes abrangentes para validação de configuração personalizada, execução em diferentes métodos, resolução de caminhos e funcionalidade RAG. Todos os testes foram executados com sucesso, garantindo robustez e confiabilidade.

### Evidências de Funcionamento
Relatórios detalhados de teste demonstram o funcionamento correto de todas as funcionalidades, incluindo resolução de problemas identificados em versões anteriores e implementação de melhorias solicitadas.

## Documentação Adicional

### Arquivos de Documentação
- `ANALISE_PROBLEMAS_ATUAIS.md`: Análise detalhada dos problemas identificados
- `RELATORIO_TESTES_EXECUCAO.md`: Relatório completo dos testes realizados
- `CHANGELOG.md`: Histórico de mudanças e melhorias
- `requirements.txt`: Dependências do projeto

### Configuração e Personalização
O sistema oferece documentação completa sobre configuração, personalização e uso avançado, incluindo exemplos práticos e casos de uso específicos.

## Suporte e Manutenção

### Manutenção da Base RAG
O sistema inclui ferramentas integradas para manutenção automática da base de conhecimento, garantindo qualidade e atualização contínua das informações utilizadas nas análises.

### Monitoramento e Logging
Sistema de logging transparente que permite acompanhar o funcionamento interno, identificar problemas e otimizar performance conforme necessário.

## Conclusão

O COBOL to Docs v3.0 representa uma solução completa e robusta para análise e documentação de sistemas COBOL legados, oferecendo flexibilidade, confiabilidade e resultados profissionais para equipes de desenvolvimento e modernização de sistemas.
