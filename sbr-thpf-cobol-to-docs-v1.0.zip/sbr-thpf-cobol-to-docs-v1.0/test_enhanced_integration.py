#!/usr/bin/env python3
"""
Teste de integração dos Enhanced Handlers
"""

import sys
import os

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'cobol_to_docs', 'src'))

def test_enhanced_integration():
    """Testa se os Enhanced Handlers foram integrados corretamente."""
    
    print("=== TESTE DE INTEGRAÇÃO ENHANCED HANDLERS ===")
    
    try:
        # Testar import do Enhanced Prompt Manager
        from core.enhanced_prompt_manager import EnhancedPromptManager
        print("✅ Enhanced Prompt Manager importado com sucesso")
        
        # Testar import do Enhanced Response Formatter
        from utils.enhanced_response_formatter import EnhancedResponseFormatter
        print("✅ Enhanced Response Formatter importado com sucesso")
        
        # Testar criação dos objetos
        class MockConfigManager:
            pass
        
        config_manager = MockConfigManager()
        prompt_manager = EnhancedPromptManager(config_manager)
        response_formatter = EnhancedResponseFormatter()
        
        print("✅ Objetos criados com sucesso")
        
        # Testar carregamento de prompt
        prompt_config = prompt_manager.load_complete_prompt_file('especialista')
        print(f"✅ Prompt carregado: {len(prompt_config)} seções")
        
        print("\n🎉 INTEGRAÇÃO DOS ENHANCED HANDLERS CONCLUÍDA COM SUCESSO!")
        
    except Exception as e:
        print(f"❌ Erro na integração: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_enhanced_integration()
