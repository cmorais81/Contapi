#!/usr/bin/env python3
"""
COBOL AI Engine v2.0.0 - Documentation Generator
Gerador de documentação otimizado para clareza, rastreabilidade e usabilidade.
"""

import os
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional

try:
    from parsers.cobol_parser import CobolProgram
    from providers.base_provider import AIResponse
except ImportError:
    from parsers.cobol_parser import CobolProgram
    from providers.base_provider import AIResponse

class DocumentationGenerator:
    """Gerador de documentação focado em relatórios funcionais."""

    def __init__(self, output_dir: str = "output"):
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        self.files_generated = 0
        self.total_programs = 0
        
        # Criar diretórios necessários
        os.makedirs(output_dir, exist_ok=True)
        
        # Diretório para JSONs das respostas
        self.json_dir = os.path.join(output_dir, "ai_responses")
        os.makedirs(self.json_dir, exist_ok=True)
        
        # Diretório para JSONs dos requests
        self.request_dir = os.path.join(output_dir, "ai_requests")
        os.makedirs(self.request_dir, exist_ok=True)

    def generate_program_documentation(self, program: CobolProgram, ai_response: AIResponse, phase_info: Optional[Dict[str, Any]] = None) -> str:
        """Gera a documentação funcional aprimorada para um programa."""
        try:
            # Salvar JSONs de auditoria
            self._save_ai_response_json(program, ai_response)
            self._save_ai_request_json(program, ai_response)
            
            # Gerar conteúdo do relatório
            content = self._generate_functional_report(program, ai_response)
            filename = f"{program.name}_analise_funcional.md"
            filepath = os.path.join(self.output_dir, filename)

            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)

            self.files_generated += 1
            self.total_programs += 1
            
            self.logger.info(f"Documentação funcional gerada: {filename}")
            return filepath
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação para {program.name}: {e}")
            raise

    def _generate_functional_report(self, program: CobolProgram, ai_response: AIResponse) -> str:
        """Gera o conteúdo do relatório funcional em Markdown."""
        # Extrair a análise da IA
        analysis_content = ai_response.content

        # Montar o cabeçalho do documento
        header = f"""# Análise Funcional do Programa: {program.name}

**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Modelo de IA:** {ai_response.model}  
**Provedor:** {ai_response.provider}  

---
"""

        # Montar o corpo do documento com a análise da IA
        body = f"""## Análise Detalhada

{analysis_content}
"""

        # Montar a seção de transparência
        transparency = self._generate_transparency_section(program, ai_response)

        # Juntar tudo
        full_content = f"{header}\n{body}\n{transparency}"

        return full_content

    def _generate_transparency_section(self, program: CobolProgram, ai_response: AIResponse) -> str:
        """Gera a seção de transparência e auditoria."""
        prompts = getattr(ai_response, 'prompts_used', {})
        main_prompt = prompts.get('original_prompt', 'Prompt não disponível')
        system_prompt = prompts.get('system_prompt', 'Contexto não disponível')

        return f"""---

## Transparência e Auditoria

### Informações da Análise

| Aspecto | Valor |
|---------|-------|
| **Status da Análise** | {'SUCESSO' if ai_response.success else 'FALHA'} |
| **Provider Utilizado** | {ai_response.provider} |
| **Modelo de IA** | {ai_response.model} |
| **Tokens Utilizados** | {ai_response.tokens_used:,} |
| **Tempo de Resposta** | {getattr(ai_response, 'response_time', 0):.2f} segundos |
| **Tamanho da Resposta** | {len(ai_response.content):,} caracteres |
| **Data/Hora da Análise** | {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')} |

### Detalhes do Provider de IA

- **Provider:** {ai_response.provider}
- **Modelo:** {ai_response.model}
- **Sucesso:** {'Sim' if ai_response.success else 'Não'}
{f"- **Erro:** {ai_response.error_message}" if not ai_response.success else ""}

### Prompt Utilizado

<details>
<summary>Clique para expandir e ver o prompt completo</summary>

**Prompt do Sistema:**
```
{system_prompt}
```

**Prompt Principal (gerado dinamicamente):**
```
{main_prompt}
```

</details>

### Metodologia de Análise

A análise foi realizada utilizando **{ai_response.model}** via **{ai_response.provider}**, seguindo uma metodologia estruturada:

1. **Análise Geral:** O modelo primeiro realiza uma análise holística do programa para entender seu propósito, fluxo e arquitetura
2. **Respostas Estruturadas:** Em seguida, responde a um conjunto de perguntas específicas para extrair informações detalhadas
3. **Rastreabilidade:** Cada informação é vinculada a linhas específicas do código fonte
4. **Validação:** As respostas são estruturadas para facilitar validação com especialistas

### Arquivos de Auditoria

Os seguintes arquivos foram gerados para auditoria completa:

- **`ai_responses/{program.name}_response.json`** - Resposta completa da IA
- **`ai_requests/{program.name}_request.json`** - Request enviado para a IA

### Limitações e Considerações

- A análise é gerada por IA e deve ser usada como um ponto de partida, não como um substituto para a validação humana.
- A precisão da análise depende da qualidade e clareza do código fonte.

---

*Relatório gerado automaticamente pelo COBOL AI Engine v2.0.0*
"""

    def _save_ai_response_json(self, program: CobolProgram, response: AIResponse) -> None:
        """Salva a resposta da IA em formato JSON para auditoria."""
        try:
            # Preparar dados da resposta
            response_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "provider": response.provider,
                "model": response.model,
                "success": response.success,
                "tokens_used": response.tokens_used,
                "response_time": getattr(response, 'response_time', 0),
                "content": response.content,
                "error_message": response.error_message,
                "metadata": response.metadata,
                "pre_analysis": getattr(response, 'pre_analysis', {}),
                "prompts_used": getattr(response, 'prompts_used', {}),
                "quality_score": getattr(response, 'quality_score', 0),
                "analysis_depth": getattr(response, 'analysis_depth', 'standard')
            }
            
            # Salvar JSON
            json_filename = f"{program.name}_ai_response.json"
            json_filepath = os.path.join(self.json_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(response_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON da resposta salvo: {json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON da resposta para {program.name}: {e}")
    
    def _save_ai_request_json(self, program: CobolProgram, response: AIResponse) -> None:
        """Salva o request enviado ao provedor em formato JSON para auditoria."""
        try:
            # Extrair dados do request dos metadados da resposta
            request_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "provider": response.provider,
                "model": response.model,
                "request_payload": getattr(response, 'request_payload', {}),
                "prompts_sent": response.prompts_used if response.prompts_used else {
                    "system_prompt": "Não disponível",
                    "full_prompt": "Não disponível",
                    "program_code": "Não disponível"
                },
                "headers": getattr(response, 'request_headers', {}),
                "endpoint": getattr(response, 'endpoint_used', ''),
                "method": getattr(response, 'http_method', 'POST'),
                "request_size": len(str(getattr(response, 'request_payload', {}))),
                "configuration": {
                    "temperature": getattr(response, 'temperature', 0.1),
                    "max_tokens": getattr(response, 'max_tokens', 4000),
                    "timeout": getattr(response, 'timeout', 120)
                }
            }
            
            # Salvar JSON do request
            json_filename = f"{program.name}_ai_request.json"
            json_filepath = os.path.join(self.request_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(request_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON do request salvo: {json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON do request para {program.name}: {e}")

    def get_generation_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas de geração."""
        return {
            "files_generated": self.files_generated,
            "total_programs": self.total_programs,
            "output_directory": self.output_dir,
            "json_responses_dir": self.json_dir,
            "json_requests_dir": self.request_dir
        }
