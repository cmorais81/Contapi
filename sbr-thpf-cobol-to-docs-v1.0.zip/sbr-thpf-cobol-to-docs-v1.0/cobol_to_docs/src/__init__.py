"""
COBOL AI Engine v2.6.0 - Pacote Principal
Sistema completo de análise de programas COBOL com IA.
"""

__version__ = "2.6.0"
__author__ = "COBOL AI Engine Team"
__description__ = "Sistema de análise de programas COBOL com IA"

