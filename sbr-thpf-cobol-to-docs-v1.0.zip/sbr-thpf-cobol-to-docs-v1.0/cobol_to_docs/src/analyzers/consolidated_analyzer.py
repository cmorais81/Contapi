"""
COBOL to Docs v1.1 - Consolidated Analyzer
Analisador consolidado que processa todo o código COBOL junto.
"""

import logging
from typing import List, Dict, Any
from parsers.cobol_parser_original import CobolProgram, CobolBook
from analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer


class ConsolidatedAnalyzer:
    """
    Analisador consolidado que submete todo o código COBOL junto
    para gerar um relatório único e abrangente.
    """
    
    def __init__(self, provider_manager, prompt_manager):
        """
        Inicializa o analisador consolidado.
        
        Args:
            provider_manager: Gerenciador de provedores de IA
            prompt_manager: Gerenciador de prompts
        """
        self.provider_manager = provider_manager
        self.prompt_manager = prompt_manager
        self.logger = logging.getLogger(__name__)
        
    def analyze_consolidated(self, programs: List[CobolProgram], books: List[CobolBook] = None, model: str = None) -> Dict[str, Any]:
        """
        Analisa todos os programas COBOL juntos para gerar um relatório consolidado.
        
        Args:
            programs: Lista de programas COBOL
            books: Lista de copybooks (opcional)
            model: Modelo de IA a usar
            
        Returns:
            Dict com resultado da análise consolidada
        """
        self.logger.info(f"Iniciando análise consolidada de {len(programs)} programas COBOL")
        
        try:
            # Construir contexto consolidado
            consolidated_context = self._build_consolidated_context(programs, books)
            
            # Gerar prompt consolidado
            consolidated_prompt = self._generate_consolidated_prompt(programs, books)
            
            # Executar análise usando o provider manager
            from providers.base_provider import AIRequest
            request = AIRequest(
                prompt=consolidated_prompt,
                temperature=0.1,
                max_tokens=8000
            )
            
            if model:
                analysis_result = self.provider_manager.analyze_with_model(model, request)
            else:
                analysis_result = self.provider_manager.analyze(request)
            
            if analysis_result.success:
                return {
                    'success': True,
                    'content': analysis_result.content,
                    'tokens_used': analysis_result.tokens_used,
                    'model_used': analysis_result.model,
                    'provider_used': analysis_result.provider,
                    'programs_analyzed': len(programs),
                    'books_analyzed': len(books) if books else 0,
                    'prompt_used': consolidated_prompt
                }
            else:
                return {
                    'success': False,
                    'error': f"Falha na análise: {getattr(analysis_result, 'error', 'Erro desconhecido')}"
                }
                
        except Exception as e:
            self.logger.error(f"Erro na análise consolidada: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    def _build_consolidated_context(self, programs: List[CobolProgram], books: List[CobolBook] = None) -> str:
        """
        Constrói o contexto consolidado com todos os programas e copybooks.
        
        Args:
            programs: Lista de programas COBOL
            books: Lista de copybooks
            
        Returns:
            String com contexto consolidado
        """
        context_parts = []
        
        # Adicionar cabeçalho
        context_parts.append("=" * 80)
        context_parts.append("SISTEMA BANCÁRIO COBOL - ANÁLISE CONSOLIDADA")
        context_parts.append("=" * 80)
        context_parts.append("")
        
        # Adicionar resumo do sistema
        context_parts.append("RESUMO DO SISTEMA:")
        context_parts.append(f"- Total de programas: {len(programs)}")
        context_parts.append(f"- Total de copybooks: {len(books) if books else 0}")
        context_parts.append("")
        
        # Adicionar lista de programas
        context_parts.append("PROGRAMAS DO SISTEMA:")
        for i, program in enumerate(programs, 1):
            context_parts.append(f"{i}. {program.name} - Programa COBOL ({program.line_count} linhas)")
        context_parts.append("")
        
        # Adicionar copybooks se existirem
        if books:
            context_parts.append("COPYBOOKS DO SISTEMA:")
            for i, book in enumerate(books, 1):
                context_parts.append(f"{i}. {book.name}")
            context_parts.append("")
        
        # Adicionar código dos programas
        context_parts.append("CÓDIGO DOS PROGRAMAS:")
        context_parts.append("=" * 50)
        
        for program in programs:
            context_parts.append("")
            context_parts.append(f"PROGRAMA: {program.name}")
            context_parts.append("-" * 40)
            context_parts.append(f"DESCRIÇÃO: Programa COBOL com {program.line_count} linhas de código")
            context_parts.append("")
            context_parts.append("CÓDIGO:")
            context_parts.append(program.content)
            context_parts.append("")
            context_parts.append("=" * 50)
        
        # Adicionar código dos copybooks
        if books:
            context_parts.append("")
            context_parts.append("COPYBOOKS:")
            context_parts.append("=" * 50)
            
            for book in books:
                context_parts.append("")
                context_parts.append(f"COPYBOOK: {book.name}")
                context_parts.append("-" * 40)
                context_parts.append("CÓDIGO:")
                context_parts.append(book.content)
                context_parts.append("")
                context_parts.append("=" * 50)
        
        return "\n".join(context_parts)
    
    def _generate_consolidated_prompt(self, programs: List[CobolProgram], books: List[CobolBook] = None) -> str:
        """
        Gera prompt específico para análise consolidada.
        
        Args:
            programs: Lista de programas COBOL
            books: Lista de copybooks
            
        Returns:
            String com prompt consolidado
        """
        prompt_parts = []
        
        prompt_parts.append("Você está analisando um SISTEMA BANCÁRIO COBOL COMPLETO composto por múltiplos programas interconectados.")
        prompt_parts.append("")
        
        prompt_parts.append("OBJETIVO DA ANÁLISE:")
        prompt_parts.append("Realizar uma análise CONSOLIDADA e ABRANGENTE de todo o sistema, identificando:")
        prompt_parts.append("1. Arquitetura geral do sistema")
        prompt_parts.append("2. Fluxos de dados entre programas")
        prompt_parts.append("3. Interdependências e integrações")
        prompt_parts.append("4. Regras de negócio do sistema bancário")
        prompt_parts.append("5. Pontos de entrada e saída de dados")
        prompt_parts.append("6. Estruturas de dados compartilhadas")
        prompt_parts.append("7. Processos críticos do negócio")
        prompt_parts.append("")
        
        prompt_parts.append("PROGRAMAS A ANALISAR:")
        for i, program in enumerate(programs, 1):
            prompt_parts.append(f"{i}. {program.name} - Programa COBOL ({program.line_count} linhas)")
        prompt_parts.append("")
        
        if books:
            prompt_parts.append("COPYBOOKS DISPONÍVEIS:")
            for i, book in enumerate(books, 1):
                prompt_parts.append(f"{i}. {book.name}")
            prompt_parts.append("")
        
        prompt_parts.append("FORMATO DA RESPOSTA:")
        prompt_parts.append("Gere um relatório consolidado estruturado com as seguintes seções:")
        prompt_parts.append("")
        prompt_parts.append("# ANÁLISE CONSOLIDADA DO SISTEMA BANCÁRIO COBOL")
        prompt_parts.append("")
        prompt_parts.append("## 1. VISÃO GERAL DO SISTEMA")
        prompt_parts.append("- Propósito e escopo do sistema")
        prompt_parts.append("- Principais funcionalidades")
        prompt_parts.append("- Arquitetura geral")
        prompt_parts.append("")
        prompt_parts.append("## 2. MAPA DE PROGRAMAS E FUNCIONALIDADES")
        prompt_parts.append("- Descrição detalhada de cada programa")
        prompt_parts.append("- Responsabilidades específicas")
        prompt_parts.append("- Pontos de integração")
        prompt_parts.append("")
        prompt_parts.append("## 3. FLUXOS DE DADOS E PROCESSOS")
        prompt_parts.append("- Fluxos principais de dados")
        prompt_parts.append("- Sequência de execução")
        prompt_parts.append("- Interdependências entre programas")
        prompt_parts.append("")
        prompt_parts.append("## 4. ESTRUTURAS DE DADOS")
        prompt_parts.append("- Copybooks e suas utilizações")
        prompt_parts.append("- Estruturas compartilhadas")
        prompt_parts.append("- Formatos de arquivos")
        prompt_parts.append("")
        prompt_parts.append("## 5. REGRAS DE NEGÓCIO")
        prompt_parts.append("- Regras bancárias implementadas")
        prompt_parts.append("- Validações e controles")
        prompt_parts.append("- Processos críticos")
        prompt_parts.append("")
        prompt_parts.append("## 6. ANÁLISE TÉCNICA")
        prompt_parts.append("- Qualidade do código")
        prompt_parts.append("- Padrões utilizados")
        prompt_parts.append("- Pontos de atenção")
        prompt_parts.append("")
        prompt_parts.append("## 7. RECOMENDAÇÕES")
        prompt_parts.append("- Melhorias sugeridas")
        prompt_parts.append("- Modernização")
        prompt_parts.append("- Manutenibilidade")
        prompt_parts.append("")
        
        prompt_parts.append("IMPORTANTE: Analise o sistema como um TODO INTEGRADO, não como programas isolados.")
        prompt_parts.append("Foque nas INTERAÇÕES, DEPENDÊNCIAS e FLUXOS entre os componentes.")
        
        return "\n".join(prompt_parts)
