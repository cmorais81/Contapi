import requests
import logging
import time
from typing import Dict, Any, Optional, List
from urllib3.exceptions import InsecureRequestWarning
import warnings

from .base_provider import BaseProvider, AIRequest, AIResponse

# Suprimir warnings de SSL
warnings.filterwarnings("ignore", message="Unverified HTTPS request")
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class LuziaProvider(BaseProvider):
    """
    Provider LuzIA corrigido com URLs e payload corretos da versão funcionando
    """
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.logger = logging.getLogger("LuziaProvider")
        
        # Obter configurações do LuzIA do config.yaml
        self.base_url = config.get("base_url", "https://luzia.chat")
        self.api_key = config.get("api_key", "")
        self.timeout = config.get("timeout", 300)
        self.client_id = config.get("client_id")
        self.client_secret = config.get("client_secret")
        self.logger.info(f"LuziaProvider initialized with client_id: {self.client_id} and client_secret: {self.client_secret}")
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Implementa o método analyze requerido pela interface BaseProvider.
        """
        if not self.validate_request(request):
            return self.create_error_response("Requisição inválida", request)
        
        start_time = time.time()
        
        try:
            # Construir payload no formato LuzIA
            payload = {
                "input": {
                    "query": [
                        {"role": "system", "content": "Você é um especialista em análise de sistemas COBOL."},
                        {"role": "user", "content": request.prompt}
                    ]
                },
                "config": {
                    "catena.llm.LLMRouter": {
                        "temperature": request.temperature,
                        "max_tokens": request.max_tokens,
                        "routing_model": self.model
                    }
                }
            }
            
            self.logger.info(f"Enviando requisição para LuzIA - Programa: {request.program_name}")
            self.logger.info(f"Modelo: {self.model}")
            self.logger.info(f"Tokens máximos: {request.max_tokens}")
            
            # Headers
            headers = {
                "Content-Type": "application/json"
            }
            
            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"
            
            # Fazer requisição
            response = requests.post(
                f"{self.base_url}/api/v1/chat/completions",
                json=payload,
                headers=headers,
                timeout=self.timeout,
                verify=False
            )
            
            response_time = time.time() - start_time
            self.logger.info(f"Status da resposta: {response.status_code}")
            
            if response.status_code == 200:
                response_data = response.json()
                
                # Extrair conteúdo da resposta
                content = ""
                if "choices" in response_data and len(response_data["choices"]) > 0:
                    content = response_data["choices"][0].get("message", {}).get("content", "")
                elif "content" in response_data:
                    content = response_data["content"]
                
                # Extrair tokens usados
                usage = response_data.get("usage", {})
                total_tokens = usage.get("total_tokens", 0)
                
                self.logger.info(f"Resposta recebida com sucesso. Tokens usados: {total_tokens}")
                
                return self.create_success_response(
                    content=content,
                    tokens_used=total_tokens,
                    request=request,
                    metadata={
                        "response_time": response_time,
                        "raw_response": response_data
                    }
                )
            else:
                error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                self.logger.error(error_msg)
                
                # Atualizar estatísticas
                self._update_statistics(False, 0, response_time)
                
                return self.create_error_response(error_msg, request)
                
        except requests.exceptions.Timeout:
            error_msg = f"Timeout na requisição para LuzIA (>{self.timeout}s)"
            self.logger.error(error_msg)
            self._update_statistics(False, 0, time.time() - start_time)
            return self.create_error_response(error_msg, request)
            
        except requests.exceptions.RequestException as e:
            error_msg = f"Erro de conexão com LuzIA: {str(e)}"
            self.logger.error(error_msg)
            self._update_statistics(False, 0, time.time() - start_time)
            return self.create_error_response(error_msg, request)
            
        except Exception as e:
            error_msg = f"Erro inesperado no LuziaProvider: {str(e)}"
            self.logger.error(error_msg)
            self._update_statistics(False, 0, time.time() - start_time)
            return self.create_error_response(error_msg, request)
    
    def send_request(self, request: AIRequest) -> AIResponse:
        """
        Envia requisição para o LuzIA usando o formato correto
        """
        try:
            # Extrair dados da requisição
            program_name = request.data.get("program_name", "UNKNOWN")
            query = request.data.get("input", {}).get("query", [])
            model_config = request.data.get("config", {})
            
            # Construir payload no formato LuzIA
            payload = {
                "input": {
                    "query": query
                },
                "config": {
                    "catena.llm.LLMRouter": {
                        "temperature": model_config.get("temperature", 0.1),
                        "max_tokens": model_config.get("max_tokens", 8000),
                        "routing_model": request.data.get("model", "aws-claude-3-5-sonnet")
                    }
                }
            }
            
            self.logger.info(f"Enviando requisição para LuzIA - Programa: {program_name}")
            self.logger.info(f"Modelo: {payload['config']['catena.llm.LLMRouter']['routing_model']}")
            self.logger.info(f"Tokens máximos: {payload['config']['catena.llm.LLMRouter']['max_tokens']}")
            
            # Headers
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}" if self.api_key else None
            }
            
            # Remover header None
            headers = {k: v for k, v in headers.items() if v is not None}
            
            # Fazer requisição
            response = requests.post(
                f"{self.base_url}/api/v1/chat/completions",
                json=payload,
                headers=headers,
                timeout=self.timeout,
                verify=False
            )
            
            self.logger.info(f"Status da resposta: {response.status_code}")
            
            if response.status_code == 200:
                response_data = response.json()
                
                # Extrair tokens usados
                usage = response_data.get("usage", {})
                total_tokens = usage.get("total_tokens", 0)
                
                self.logger.info(f"Resposta recebida com sucesso. Tokens usados: {total_tokens}")
                
                return AIResponse(
                    success=True,
                    data=response_data,
                    error=None,
                    provider="luzia",
                    model=payload["config"]["catena.llm.LLMRouter"]["routing_model"],
                    tokens_used=total_tokens
                )
            else:
                error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                self.logger.error(error_msg)
                
                return AIResponse(
                    success=False,
                    data=None,
                    error=error_msg,
                    provider="luzia",
                    model=request.data.get("model", "unknown"),
                    tokens_used=0
                )
                
        except requests.exceptions.Timeout:
            error_msg = f"Timeout na requisição para LuzIA (>{self.timeout}s)"
            self.logger.error(error_msg)
            return AIResponse(
                success=False,
                data=None,
                error=error_msg,
                provider="luzia",
                model=request.data.get("model", "unknown"),
                tokens_used=0
            )
            
        except requests.exceptions.RequestException as e:
            error_msg = f"Erro de conexão com LuzIA: {str(e)}"
            self.logger.error(error_msg)
            return AIResponse(
                success=False,
                data=None,
                error=error_msg,
                provider="luzia",
                model=request.data.get("model", "unknown"),
                tokens_used=0
            )
            
        except Exception as e:
            error_msg = f"Erro inesperado no LuziaProvider: {str(e)}"
            self.logger.error(error_msg)
            return AIResponse(
                success=False,
                data=None,
                error=error_msg,
                provider="luzia",
                model=request.data.get("model", "unknown"),
                tokens_used=0
            )
    
    def is_available(self) -> bool:
        """
        Verifica se o LuzIA está disponível
        """
        try:
            health_url = f"{self.base_url}/health"
            self.logger.info(f"Verificando disponibilidade do LuzIA em: {health_url}")
            response = requests.get(
                health_url,
                timeout=10,
                verify=False
            )
            self.logger.info(f"Status da verificação de saúde do LuzIA: {response.status_code}")
            return response.status_code == 200
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro ao verificar disponibilidade do LuzIA: {e}")
            return False
        except Exception as e:
            self.logger.error(f"Erro inesperado ao verificar disponibilidade do LuzIA: {e}")
            return False

