"""
COBOL AI Engine v4.0 - GitHub Copilot Provider
Provedor para integração com GitHub Copilot API.
"""

import logging
import requests
import time
from typing import Dict, Any, Optional
from datetime import datetime

from providers.base_provider import BaseProvider, AIRequest, AIResponse


class GitHubCopilotProvider(BaseProvider):
    """
    Provedor para GitHub Copilot API.
    
    Funcionalidades:
    - Integração com GitHub Copilot Chat API
    - Suporte a modelos GPT-4 via GitHub
    - Análise de código COBOL especializada
    - Rate limiting e retry automático
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor GitHub Copilot.
        
        Args:
            config: Configuração do provedor
        """
        super().__init__(config)
        self.logger = logging.getLogger(__name__)
        
        # Configurações específicas do GitHub Copilot
        self.api_token = config.get('api_token', '')
        self.organization = config.get('organization', '')
        self.base_url = config.get('base_url', 'https://api.github.com/copilot')
        
        # Headers para autenticação
        self.headers = {
            'Authorization': f'Bearer {self.api_token}',
            'Accept': 'application/vnd.github+json',
            'X-GitHub-Api-Version': '2022-11-28',
            'Content-Type': 'application/json'
        }
        
        # Configurações de rate limiting
        self.rate_limit_config = config.get('rate_limit', {})
        self.requests_per_minute = self.rate_limit_config.get('requests_per_minute', 30)
        self.tokens_per_minute = self.rate_limit_config.get('tokens_per_minute', 50000)
        
        # Configurações de retry
        self.retry_config = config.get('retry', {})
        self.max_attempts = self.retry_config.get('max_attempts', 3)
        self.retry_delay = self.retry_config.get('delay', 2)
        self.backoff_factor = self.retry_config.get('backoff_factor', 2)
        
        self.logger.info("GitHub Copilot Provider inicializado")
    
    def is_available(self) -> bool:
        """
        Verifica se o GitHub Copilot está disponível.
        
        Returns:
            bool: True se disponível
        """
        if not self.api_token:
            self.logger.warning("GitHub Copilot API token não configurado")
            return False
        
        try:
            # Verificar status da API
            response = requests.get(
                f"{self.base_url}/billing/usage",
                headers=self.headers,
                timeout=10
            )
            
            if response.status_code == 200:
                self.logger.info("GitHub Copilot está disponível")
                return True
            elif response.status_code == 401:
                self.logger.error("GitHub Copilot: Token de autenticação inválido")
                return False
            elif response.status_code == 403:
                self.logger.error("GitHub Copilot: Acesso negado - verificar permissões")
                return False
            else:
                self.logger.warning(f"GitHub Copilot: Status inesperado {response.status_code}")
                return False
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro ao verificar GitHub Copilot: {e}")
            return False
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando GitHub Copilot.
        
        Args:
            request: Requisição de análise
            
        Returns:
            AIResponse: Resposta da análise
        """
        start_time = time.time()
        
        try:
            self.logger.info(f"Iniciando análise GitHub Copilot para programa: {request.program_name}")
            
            # Preparar payload para GitHub Copilot Chat
            payload = self._prepare_chat_payload(request)
            
            # Fazer requisição com retry
            response_data = self._make_request_with_retry(payload)
            
            if response_data:
                # Processar resposta
                content = self._extract_content(response_data)
                tokens_used = self._calculate_tokens_used(request.prompt, content)
                
                response_time = time.time() - start_time
                
                return AIResponse(
                    success=True,
                    content=content,
                    tokens_used=tokens_used,
                    model="github-copilot-gpt-4",
                    provider="github_copilot",
                    timestamp=datetime.now(),
                    metadata={
                        'organization': self.organization,
                        'api_version': '2022-11-28',
                        'response_time': response_time
                    },
                    raw_response=response_data,
                    response_time=response_time
                )
            else:
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model="github-copilot-gpt-4",
                    provider="github_copilot",
                    error_message="Falha na comunicação com GitHub Copilot"
                )
                
        except Exception as e:
            self.logger.error(f"Erro na análise GitHub Copilot: {e}")
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model="github-copilot-gpt-4",
                provider="github_copilot",
                error_message=str(e)
            )
    
    def _prepare_chat_payload(self, request: AIRequest) -> Dict[str, Any]:
        """
        Prepara payload para GitHub Copilot Chat API.
        
        Args:
            request: Requisição de análise
            
        Returns:
            Dict[str, Any]: Payload preparado
        """
        # Criar contexto específico para COBOL
        system_message = """Você é um especialista em análise de sistemas COBOL com vasta experiência em mainframe.
        Sua tarefa é analisar o código COBOL fornecido e gerar uma documentação técnica detalhada.
        Foque em aspectos técnicos, estruturas de dados, lógica de negócio e recomendações de melhoria."""
        
        # Preparar mensagem do usuário
        user_message = f"""Analise o seguinte programa COBOL:

PROGRAMA: {request.program_name}

CÓDIGO:
{request.program_code}

PROMPT DE ANÁLISE:
{request.prompt}

Por favor, forneça uma análise técnica detalhada seguindo as diretrizes do prompt."""
        
        return {
            "messages": [
                {
                    "role": "system",
                    "content": system_message
                },
                {
                    "role": "user", 
                    "content": user_message
                }
            ],
            "model": "gpt-4",
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
            "stream": False
        }
    
    def _make_request_with_retry(self, payload: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Faz requisição com retry automático.
        
        Args:
            payload: Dados da requisição
            
        Returns:
            Optional[Dict[str, Any]]: Resposta da API ou None se falhou
        """
        for attempt in range(self.max_attempts):
            try:
                self.logger.debug(f"GitHub Copilot: Tentativa {attempt + 1}/{self.max_attempts}")
                
                response = requests.post(
                    f"{self.base_url}/chat/completions",
                    headers=self.headers,
                    json=payload,
                    timeout=120
                )
                
                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 429:
                    # Rate limit - aguardar mais tempo
                    wait_time = self.retry_delay * (self.backoff_factor ** attempt)
                    self.logger.warning(f"GitHub Copilot rate limit - aguardando {wait_time}s")
                    time.sleep(wait_time)
                    continue
                elif response.status_code == 401:
                    self.logger.error("GitHub Copilot: Token inválido")
                    break
                elif response.status_code == 403:
                    self.logger.error("GitHub Copilot: Acesso negado")
                    break
                else:
                    self.logger.error(f"GitHub Copilot: Erro {response.status_code} - {response.text}")
                    if attempt < self.max_attempts - 1:
                        wait_time = self.retry_delay * (self.backoff_factor ** attempt)
                        time.sleep(wait_time)
                        continue
                    break
                    
            except requests.exceptions.RequestException as e:
                self.logger.error(f"GitHub Copilot: Erro de conexão - {e}")
                if attempt < self.max_attempts - 1:
                    wait_time = self.retry_delay * (self.backoff_factor ** attempt)
                    time.sleep(wait_time)
                    continue
                break
        
        return None
    
    def _extract_content(self, response_data: Dict[str, Any]) -> str:
        """
        Extrai conteúdo da resposta do GitHub Copilot.
        
        Args:
            response_data: Dados da resposta
            
        Returns:
            str: Conteúdo extraído
        """
        try:
            choices = response_data.get('choices', [])
            if choices:
                message = choices[0].get('message', {})
                content = message.get('content', '')
                return content.strip()
            else:
                self.logger.warning("GitHub Copilot: Nenhuma escolha na resposta")
                return ""
                
        except Exception as e:
            self.logger.error(f"Erro ao extrair conteúdo GitHub Copilot: {e}")
            return ""
    
    def _calculate_tokens_used(self, prompt: str, response: str) -> int:
        """
        Calcula tokens utilizados (estimativa).
        
        Args:
            prompt: Prompt enviado
            response: Resposta recebida
            
        Returns:
            int: Número estimado de tokens
        """
        # Estimativa: ~4 caracteres por token
        total_chars = len(prompt) + len(response)
        estimated_tokens = total_chars // 4
        return max(1, estimated_tokens)
    
    def get_available_models(self) -> Dict[str, Dict[str, Any]]:
        """
        Retorna modelos disponíveis no GitHub Copilot.
        
        Returns:
            Dict[str, Dict[str, Any]]: Modelos disponíveis
        """
        return {
            "gpt_4_copilot": {
                "name": "gpt-4",
                "description": "GPT-4 via GitHub Copilot",
                "max_tokens": 8192,
                "context_window": 8192,
                "capabilities": ["text_generation", "code_analysis", "documentation"]
            },
            "gpt_3_5_copilot": {
                "name": "gpt-3.5-turbo",
                "description": "GPT-3.5 Turbo via GitHub Copilot",
                "max_tokens": 4096,
                "context_window": 16385,
                "capabilities": ["text_generation", "code_analysis"]
            }
        }
    
    def get_provider_info(self) -> Dict[str, Any]:
        """
        Retorna informações sobre o provedor.
        
        Returns:
            Dict[str, Any]: Informações do provedor
        """
        return {
            "name": "GitHub Copilot",
            "version": "2022-11-28",
            "description": "GitHub Copilot AI Assistant for code analysis and documentation",
            "capabilities": [
                "COBOL code analysis",
                "Technical documentation generation",
                "Code review and recommendations",
                "Business logic extraction"
            ],
            "rate_limits": {
                "requests_per_minute": self.requests_per_minute,
                "tokens_per_minute": self.tokens_per_minute
            },
            "authentication": "GitHub API Token",
            "base_url": self.base_url
        }
