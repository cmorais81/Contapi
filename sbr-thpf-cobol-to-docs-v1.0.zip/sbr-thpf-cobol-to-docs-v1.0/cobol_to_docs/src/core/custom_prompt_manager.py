"""
CustomPromptManager - Gerenciador de prompts customizados via arquivo .txt
"""

import os
import logging
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

class CustomPromptManager:
    """Gerenciador para prompts customizados carregados de arquivos .txt."""
    
    def __init__(self, prompt_file_path: str):
        """
        Inicializa o CustomPromptManager.
        
        Args:
            prompt_file_path: Caminho para o arquivo .txt com o prompt customizado
        """
        self.prompt_file_path = prompt_file_path
        self.custom_prompt_content = None
        self._load_custom_prompt()
    
    def _load_custom_prompt(self) -> None:
        """Carrega o conteúdo do prompt customizado."""
        try:
            if not os.path.exists(self.prompt_file_path):
                logger.error(f"Arquivo de prompt customizado não encontrado: {self.prompt_file_path}")
                return
            
            with open(self.prompt_file_path, 'r', encoding='utf-8') as f:
                self.custom_prompt_content = f.read().strip()
            
            logger.info(f"Prompt customizado carregado: {len(self.custom_prompt_content)} caracteres")
            
        except Exception as e:
            logger.error(f"Erro ao carregar prompt customizado: {e}")
            self.custom_prompt_content = None
    
    def has_custom_prompt(self) -> bool:
        """Verifica se há um prompt customizado carregado."""
        return self.custom_prompt_content is not None and len(self.custom_prompt_content) > 0
    
    def get_prompt_info(self) -> Dict[str, Any]:
        """Retorna informações sobre o prompt customizado."""
        if not self.has_custom_prompt():
            return {
                'file': self.prompt_file_path,
                'size': 0,
                'loaded': False
            }
        
        return {
            'file': self.prompt_file_path,
            'size': len(self.custom_prompt_content),
            'loaded': True
        }
    
    def create_custom_analysis_prompt(
        self, 
        program_name: str, 
        program_code: str, 
        copybooks: List[Any] = None
    ) -> str:
        """
        Cria um prompt de análise usando o template customizado.
        
        Args:
            program_name: Nome do programa COBOL
            program_code: Código fonte do programa
            copybooks: Lista de copybooks relacionados
            
        Returns:
            Prompt formatado para análise
        """
        if not self.has_custom_prompt():
            raise ValueError("Nenhum prompt customizado carregado")
        
        copybooks = copybooks or []
        
        # Preparar informações dos copybooks
        copybooks_info = ""
        if copybooks:
            copybooks_info = "\n".join([
                f"=== COPYBOOK: {cb.name if hasattr(cb, 'name') else str(cb)} ===\n{cb.content if hasattr(cb, 'content') else str(cb)}"
                for cb in copybooks
            ])
        else:
            copybooks_info = "Nenhum copybook disponível."
        
        # Substituir placeholders no template
        try:
            formatted_prompt = self.custom_prompt_content.format(
                program_name=program_name,
                cobol_code=program_code,
                copybooks=copybooks_info
            )
            
            logger.info(f"Prompt customizado formatado: {len(formatted_prompt)} caracteres")
            return formatted_prompt
            
        except KeyError as e:
            logger.warning(f"Placeholder não encontrado no template: {e}")
            # Fallback: usar template simples
            return f"""
{self.custom_prompt_content}

=== PROGRAMA PARA ANÁLISE ===
Nome: {program_name}

=== CÓDIGO COBOL ===
{program_code}

=== COPYBOOKS RELACIONADOS ===
{copybooks_info}
"""
        
        except Exception as e:
            logger.error(f"Erro ao formatar prompt customizado: {e}")
            raise


    def get_custom_prompt(self, cobol_code: str) -> Optional[str]:
        """Retorna o prompt customizado com o código COBOL inserido."""
        if not self.has_custom_prompt():
            return None
        
        return self.custom_prompt_content.replace("{cobol_code}", cobol_code)

