import os
import yaml
import logging
from typing import Dict, Any, Optional, List
from pathlib import Path
import pkg_resources

class ConfigManager:
    """
    Gerenciador de configuração que carrega config.yaml e prompts.yaml dinamicamente
    """
    
    def __init__(self, config_dir: Optional[str] = None, prompts_file: Optional[str] = None):
        """
        Inicializa o ConfigManager com caminhos personalizados
        
        Args:
            config_dir: Diretório contendo config.yaml (prioridade máxima)
            prompts_file: Caminho específico para prompts.yaml (prioridade máxima)
        """
        self.logger = logging.getLogger(__name__)
        self.custom_config_dir = config_dir
        self.custom_prompts_file = prompts_file
        
        # Carregar configurações
        self.config_path = self._find_config_file()
        self.config = self._load_config()
        self.prompts_config = self._load_prompts_config()
        
        self.logger.info(f"Configuração carregada de: {self.config_path}")
        if self.prompts_config:
            self.logger.info(f'Prompts carregados de: {self.prompts_config.get("yaml_file", "N/A")}')

    def _find_config_file(self) -> str:
        """
        Encontra o arquivo config.yaml de forma robusta, priorizando parâmetros customizados
        """
        # 1. PRIORIDADE MÁXIMA: custom_config_dir
        if self.custom_config_dir:
            custom_path = os.path.join(self.custom_config_dir, "config.yaml")
            if os.path.exists(custom_path):
                self.logger.info(f"Config.yaml encontrado via --config-dir: {custom_path}")
                return custom_path
        
        # 2. Lista de possíveis localizações (ordem de prioridade)
        search_paths = [
            # Diretório atual
            "config/config.yaml",
            "cobol_to_docs/config/config.yaml",
            
            # Diretório do projeto
            os.path.join(os.path.dirname(__file__), "..", "..", "config", "config.yaml"),
            
            # Package root
            os.path.join(self._get_package_root() or "", "config", "config.yaml"),
            os.path.join(self._get_package_root() or "", "cobol_to_docs", "config", "config.yaml"),
        ]
        
        # Procurar arquivo
        for path in search_paths:
            abs_path = os.path.abspath(path)
            if os.path.exists(abs_path):
                self.logger.info(f"Config.yaml encontrado em: {abs_path}")
                return abs_path
        
        self.logger.error("config.yaml não encontrado em nenhum local esperado.")
        raise FileNotFoundError("config.yaml não encontrado.")

    def _find_prompts_file(self) -> Optional[str]:
        """
        Encontra o arquivo de prompts de forma robusta, priorizando parâmetros customizados
        """
        # 1. PRIORIDADE MÁXIMA: custom_prompts_file
        if self.custom_prompts_file and os.path.exists(self.custom_prompts_file):
            self.logger.info(f"Prompts.yaml encontrado via --prompts-yaml: {self.custom_prompts_file}")
            return self.custom_prompts_file
        
        # 2. PRIORIDADE ALTA: custom_config_dir
        if self.custom_config_dir:
            custom_path = os.path.join(self.custom_config_dir, "prompts.yaml")
            if os.path.exists(custom_path):
                self.logger.info(f"Prompts.yaml encontrado via --config-dir: {custom_path}")
                return custom_path
        
        # 3. Lista de possíveis localizações (ordem de prioridade)
        search_paths = [
            "config/prompts.yaml",
            "cobol_to_docs/config/prompts.yaml",
            os.path.join(os.path.dirname(__file__), "..", "..", "config", "prompts.yaml"),
            os.path.join(self._get_package_root() or "", "config", "prompts.yaml"),
            os.path.join(self._get_package_root() or "", "cobol_to_docs", "config", "prompts.yaml"),
        ]
        
        # Procurar arquivo
        for path in search_paths:
            abs_path = os.path.abspath(path)
            if os.path.exists(abs_path):
                self.logger.info(f"Prompts.yaml encontrado em: {abs_path}")
                return abs_path
        
        self.logger.warning("Nenhum arquivo de prompts YAML encontrado.")
        return None

    def _get_package_root(self) -> Optional[str]:
        """
        Obtém o diretório raiz do pacote
        """
        try:
            # Tentar via pkg_resources
            return pkg_resources.resource_filename("cobol_to_docs", "")
        except:
            # Fallback: usar diretório do arquivo atual
            current_file = Path(__file__).resolve()
            # Subir até encontrar o diretório que contém cobol_to_docs
            for parent in current_file.parents:
                if (parent / "cobol_to_docs").exists():
                    return str(parent)
            return None

    def _load_config(self) -> Dict[str, Any]:
        """
        Carrega o conteúdo do arquivo de configuração
        """
        with open(self.config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)

    def _load_prompts_config(self) -> Optional[Dict[str, Any]]:
        """
        Carrega o conteúdo do arquivo de prompts YAML
        """
        prompts_file_path = self._find_prompts_file()
        if prompts_file_path:
            with open(prompts_file_path, "r", encoding="utf-8") as f:
                prompts_data = yaml.safe_load(f)
            
            # Extrair o prompt principal (deep_business_analysis)
            if "prompts" in prompts_data and "deep_business_analysis" in prompts_data["prompts"]:
                system_prompt = prompts_data["prompts"]["deep_business_analysis"]["system"]
                user_prompt = prompts_data["prompts"]["deep_business_analysis"]["user"]
                full_prompt = f"{system_prompt}\n\n{user_prompt}"
                
                return {
                    "full_prompt": full_prompt,
                    "system_prompt": system_prompt,
                    "user_prompt": user_prompt,
                    "raw_yaml": prompts_data,
                    "yaml_file": prompts_file_path
                }
            else:
                self.logger.warning(f"Estrutura 'prompts.deep_business_analysis' não encontrada em {prompts_file_path}")
                # Tentar estrutura alternativa (business_rule_extraction)
                if "prompts" in prompts_data and "business_rule_extraction" in prompts_data["prompts"]:
                    system_prompt = prompts_data["prompts"]["business_rule_extraction"]["system"]
                    user_prompt = prompts_data["prompts"]["business_rule_extraction"]["user"]
                    full_prompt = f"{system_prompt}\n\n{user_prompt}"
                    
                    return {
                        "full_prompt": full_prompt,
                        "system_prompt": system_prompt,
                        "user_prompt": user_prompt,
                        "raw_yaml": prompts_data,
                        "yaml_file": prompts_file_path
                    }
                else:
                    self.logger.warning(f"Nenhuma estrutura de prompt válida encontrada em {prompts_file_path}")
                    return None
        return None

    def get_configured_models(self) -> List[Dict[str, str]]:
        """
        Extrai todos os modelos configurados de todos os provedores
        """
        models = []
        self.logger.info(f"Providers in config: {list(self.config.get('providers', {}).keys())}")
        
        # Iterar sobre todos os provedores configurados
        for provider_name, provider_config in self.config.get("providers", {}).items():
            self.logger.info(f"Checking provider: {provider_name}")
            if not provider_config.get("enabled", False):
                self.logger.warning(f"Provider {provider_name} is not enabled.")
                continue
            
            self.logger.info(f"Provider {provider_name} is enabled. Models: {list(provider_config.get('models', {}).keys())}")
            # Iterar sobre todos os modelos do provedor
            for model_name, model_config in provider_config.get("models", {}).items():
                    
                # Criar nome de exibição do modelo
                display_name = f"model_{provider_name}_{model_name}".replace(".", "_").replace("-", "_")
                
                models.append({
                    "provider": provider_name,
                    "name": model_name,
                    "display_name": display_name,
                    "config": model_config
                })
        
        return models

    def get_config(self) -> Dict[str, Any]:
        """
        Retorna a configuração carregada
        """
        return self.config

    def get_prompt_config(self) -> Optional[Dict[str, Any]]:
        """
        Retorna a configuração de prompts carregada
        """
        return self.prompts_config


    
    def get_prompts(self) -> Optional[Dict[str, Any]]:
        """
        Retorna os prompts carregados (alias para get_prompt_config)
        """
        return self.prompts_config
