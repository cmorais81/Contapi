#!/usr/bin/env python3
"""
COBOL AI Engine v3.0.0 - Enhanced Prompt Manager
Gerenciador aprimorado de prompts com suporte a múltiplos modelos e engenharia de prompt dinâmica.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import yaml
import os

class EnhancedPromptManager:
    """
    Gerenciador aprimorado de prompts que adapta dinamicamente os prompts
    baseado no modelo de IA selecionado e no contexto da análise.
    """
    
    def __init__(self, model_name: str = 'default', config_path: str = 'config/prompts.yaml'):
        """
        Inicializa o gerenciador de prompts aprimorado.
        
        Args:
            model_name: Nome do modelo de IA a ser usado
            config_path: Caminho para o arquivo de configuração de prompts
        """
        self.logger = logging.getLogger(__name__)
        self.model_name = model_name
        self.config_path = config_path
        
        # Carregar configuração base
        self.config = self._load_config()
        
        # Configurações específicas por modelo
        self.model_configs = {
            'claude_3_5_sonnet': {
                'persona': 'especialista sênior em COBOL com 20+ anos de experiência',
                'analysis_depth': 'máxima',
                'technical_focus': 'alto',
                'business_context': True,
                'regulatory_emphasis': True
            },
            'luzia': {
                'persona': 'analista experiente em sistemas legados',
                'analysis_depth': 'detalhada',
                'technical_focus': 'médio',
                'business_context': True,
                'regulatory_emphasis': False
            },
            'openai_gpt4': {
                'persona': 'consultor em modernização de sistemas',
                'analysis_depth': 'detalhada',
                'technical_focus': 'alto',
                'business_context': True,
                'regulatory_emphasis': False
            },
            'mock_enhanced': {
                'persona': 'analista de sistemas COBOL',
                'analysis_depth': 'padrão',
                'technical_focus': 'médio',
                'business_context': True,
                'regulatory_emphasis': False
            },
            'default': {
                'persona': 'analista de sistemas COBOL',
                'analysis_depth': 'padrão',
                'technical_focus': 'médio',
                'business_context': True,
                'regulatory_emphasis': False
            }
        }
        
        # Configuração atual do modelo
        self.current_model_config = self.model_configs.get(
            model_name, 
            self.model_configs['default']
        )
        
        self.logger.info(f"Gerenciador de Prompts Aprimorado inicializado para o modelo: {model_name}")
    
    def _load_config(self) -> Dict[str, Any]:
        """
        Carrega configuração de prompts do arquivo YAML.
        
        Returns:
            Dicionário com configurações
        """
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    return yaml.safe_load(f)
            else:
                self.logger.warning(f"Arquivo de configuração não encontrado: {self.config_path}")
                return self._get_default_config()
        except Exception as e:
            self.logger.error(f"Erro ao carregar configuração: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """
        Retorna configuração padrão caso o arquivo não seja encontrado.
        
        Returns:
            Configuração padrão
        """
        return {
            'base_prompts': {
                'system_prompt': 'Você é um especialista em análise de sistemas COBOL.',
                'analysis_questions': [
                    'Analise a funcionalidade do programa',
                    'Identifique as regras de negócio',
                    'Documente as estruturas de dados'
                ]
            }
        }
    
    def generate_base_prompt(self, program_name: str, program_code: str, context: Dict[str, Any] = None) -> str:
        """
        Gera prompt base com análise em duas etapas: primeiro análise geral, depois questões específicas.
        
        Args:
            program_name: Nome do programa COBOL
            program_code: Código fonte do programa
            context: Contexto adicional (books, pré-análise, etc.)
            
        Returns:
            Prompt otimizado para análise em duas etapas
        """
        if context is None:
            context = {}
        
        prompt_parts = []
        
        # ETAPA 1: Análise Geral como Programador COBOL Experiente
        prompt_parts.append(self._generate_expert_analysis_header())
        
        # Informações do programa
        prompt_parts.append(f"\n--- Programa COBOL para Análise ---")
        prompt_parts.append(f"Nome do Programa: {program_name}")
        prompt_parts.append(f"Tamanho do Código: {len(program_code)} caracteres")
        
        # Adicionar informações contextuais
        self._append_contextual_information(prompt_parts, context)
        
        # Código do programa
        prompt_parts.append(f"\n--- Código Fonte ---")
        prompt_parts.append(f"```cobol")
        prompt_parts.append(program_code)
        prompt_parts.append(f"```")
        
        # ETAPA 1: Instrução para análise geral
        prompt_parts.append(self._generate_general_analysis_instruction())
        
        # ETAPA 2: Perguntas específicas detalhadas
        prompt_parts.append(self._generate_detailed_questions_from_config())
        
        # Diretrizes específicas do modelo
        prompt_parts.append(self._generate_two_phase_guidelines())
        
        return '\n'.join(prompt_parts)
    
    def _generate_expert_analysis_header(self) -> str:
        """Gera cabeçalho para análise como programador COBOL experiente."""
        config = self.current_model_config
        
        return f"""VOCÊ É UM PROGRAMADOR COBOL MUITO EXPERIENTE com mais de 20 anos de experiência em sistemas mainframe e aplicações críticas de negócio.

PRIMEIRA ETAPA - ANÁLISE GERAL:
Antes de responder qualquer questão específica, você deve primeiro analisar completamente o programa COBOL como um todo, entendendo:
- A arquitetura geral e propósito do programa
- O fluxo principal de processamento
- As estruturas de dados e suas relações
- As regras de negócio implementadas
- Os pontos críticos e complexidades
- O contexto de uso no sistema maior

Sua experiência permite identificar padrões, boas práticas, problemas potenciais e oportunidades de melhoria que um analista menos experiente poderia não perceber.

SEGUNDA ETAPA - QUESTÕES ESPECÍFICAS:
Após sua análise geral completa, você responderá cada questão específica com base no seu entendimento profundo do programa, fornecendo insights técnicos precisos e recomendações práticas."""
    
    def _generate_general_analysis_instruction(self) -> str:
        """Gera instrução para análise geral do programa."""
        return """

--- ETAPA 1: ANÁLISE GERAL DO PROGRAMA ---

Como programador COBOL experiente, faça primeiro uma análise geral completa do programa:

1. **VISÃO GERAL ARQUITETURAL**
   - Qual é o propósito principal deste programa?
   - Como ele se encaixa no contexto de um sistema maior?
   - Quais são os componentes principais e como se relacionam?

2. **ANÁLISE DO FLUXO DE PROCESSAMENTO**
   - Qual é o fluxo principal de execução?
   - Quais são os pontos de decisão críticos?
   - Como os dados fluem através do programa?

3. **AVALIAÇÃO TÉCNICA EXPERIENTE**
   - Quais padrões de programação COBOL são utilizados?
   - Há evidências de boas ou más práticas?
   - Quais são os pontos de complexidade ou risco?
   - Que melhorias você recomendaria?

4. **CONTEXTO DE NEGÓCIO**
   - Que regras de negócio estão implementadas?
   - Qual é o impacto deste programa no processo de negócio?
   - Há aspectos regulatórios ou de compliance envolvidos?

Forneça esta análise geral ANTES de responder às questões específicas abaixo."""
    
    def _generate_detailed_questions_from_config(self) -> str:
        """Gera seção com questões específicas a partir do arquivo de configuração."""
        questions = self.config.get("analysis_questions", [])
        prompt_parts = ["\n--- ETAPA 2: QUESTÕES ESPECÍFICAS DETALHADAS ---", "\nAgora, com base na sua análise geral como especialista, responda cada questão específica com profundidade técnica:"]
        
        for i, item in enumerate(questions, 1):
            prompt_parts.append(f"\n{i}. **{item['title']}**")
            prompt_parts.append(item['question'])
            
        return "\n".join(prompt_parts)


    
    def _generate_two_phase_guidelines(self) -> str:
        """Gera diretrizes específicas para análise em duas etapas."""
        config = self.current_model_config
        
        return f"""

--- DIRETRIZES DE ANÁLISE EM DUAS ETAPAS ---

**ESTRUTURA DA RESPOSTA:**
1. Comece SEMPRE com a análise geral como programador experiente
2. Depois responda cada questão específica numerada
3. Use sua experiência para fornecer insights que vão além do óbvio
4. Relacione aspectos técnicos com impacto de negócio

**QUALIDADE ESPERADA:**
- Análise {config['analysis_depth']} baseada em experiência prática
- Foco {config['technical_focus']} em aspectos técnicos
- {'Sempre contextualize dentro do domínio de negócio' if config['business_context'] else 'Foque nos aspectos técnicos'}
- {'Considere aspectos regulatórios e de compliance' if config.get('regulatory_emphasis') else 'Foque na funcionalidade e arquitetura'}

**LINGUAGEM E ESTILO:**
- Use linguagem técnica precisa apropriada para programadores COBOL experientes
- Forneça exemplos práticos quando relevante
- Explique o "porquê" além do "o que"
- Estruture a resposta de forma clara e profissional
- Inclua recomendações baseadas em experiência prática

**EXPERIÊNCIA APLICADA:**
- Identifique padrões comuns em sistemas mainframe
- Reconheça boas e más práticas de programação COBOL
- Sugira melhorias baseadas em experiência real
- Antecipe problemas potenciais de manutenção
- Considere o contexto de sistemas legados críticos"""
    
    def _generate_model_specific_header(self) -> str:
        """Gera cabeçalho específico para o modelo."""
        config = self.current_model_config
        
        header = f"""Você é um {config['persona']} especializado na análise de programas COBOL.

Sua tarefa é realizar uma análise {config['analysis_depth']} do programa COBOL fornecido, com foco {config['technical_focus']} em aspectos técnicos."""
        
        if config['business_context']:
            header += " Inclua sempre o contexto de negócio e o impacto funcional."
        
        if config.get('regulatory_emphasis'):
            header += " Considere aspectos regulatórios e de compliance quando relevante."
        
        return header
    
    def _append_contextual_information(self, prompt_parts: List[str], context: Dict[str, Any]) -> None:
        """
        Adiciona informações contextuais ao prompt.
        
        Args:
            prompt_parts: Lista de partes do prompt
            context: Contexto adicional
        """
        # Informações de pré-análise
        if 'pre_analysis' in context:
            pre_analysis = context['pre_analysis']
            
            prompt_parts.append(f"\n--- Insights da Pré-Análise Automática ---")
            
            # Comentários identificados
            if 'enhanced_comments' in pre_analysis and pre_analysis['enhanced_comments']:
                prompt_parts.append("Comentários Identificados:")
                for comment in pre_analysis['enhanced_comments'][:5]:  # Top 5
                    prompt_parts.append(f"- {comment['category']}: {comment['text'][:100]}...")
            
            # Fluxos lógicos
            if 'logic_flows' in pre_analysis and pre_analysis['logic_flows']:
                prompt_parts.append("Fluxos Lógicos Identificados:")
                for flow in pre_analysis['logic_flows'][:5]:  # Top 5
                    prompt_parts.append(f"- {flow['name']}: {flow['type']} (Complexidade: {flow['complexity_score']}/10)")
            
            # Entidades de negócio
            if 'business_entities' in pre_analysis and pre_analysis['business_entities']:
                prompt_parts.append("Entidades de Negócio Identificadas:")
                for entity in pre_analysis['business_entities'][:3]:  # Top 3
                    prompt_parts.append(f"- {entity['name']} ({entity['type']})")
        
        # Informações de copybooks
        if 'books' in context and context['books']:
            books = context['books']
            prompt_parts.append(f"\n--- Copybooks Disponíveis ---")
            prompt_parts.append(f"Total de Copybooks: {len(books)}")
            
            for book in books[:3]:  # Primeiros 3
                if hasattr(book, 'name'):
                    prompt_parts.append(f"- {book.name}: {len(book.content)} caracteres")
                else:
                    # Se books é uma lista de dicionários
                    book_name = book.get('name', 'Unknown')
                    book_content = book.get('content', '')
                    prompt_parts.append(f"- {book_name}: {len(book_content)} caracteres")
    
    def _append_analysis_questions(self, prompt_parts: List[str]) -> None:
        """
        Adiciona perguntas de análise ao prompt.
        
        Args:
            prompt_parts: Lista de partes do prompt
        """
        questions = self.get_analysis_questions_list()
        
        prompt_parts.append(f"\n--- Questões para Análise ---")
        prompt_parts.append("")
        
        for i, question in enumerate(questions, 1):
            prompt_parts.append(f"{i}. {question}")
            prompt_parts.append("")
    
    def get_analysis_questions_list(self) -> List[str]:
        """
        Retorna lista de perguntas de análise baseada no modelo.
        
        Returns:
            Lista de perguntas
        """
        base_questions = [
            "Forneça uma análise funcional completa e detalhada deste programa COBOL, incluindo:\n1) Propósito principal e objetivo de negócio\n2) Fluxo de processamento passo-a-passo\n3) Entradas e saídas esperadas\n4) Condições de execução e critérios de parada\n5) Impacto no processo de negócio geral\n",
            "Descreva detalhadamente a arquitetura técnica do programa, incluindo:\n1) Estrutura das divisões COBOL (IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE)\n2) Organização de seções e parágrafos\n3) Definição e uso de arquivos (FD, SELECT)\n4) Estruturas de dados (WORKING-STORAGE, LINKAGE)\n5) Fluxo de controle e chamadas de programa\n6) Tratamento de erros e exceções\n",
            "Identifique e documente todas as regras de negócio implementadas, incluindo:\n1) Validações de dados e critérios de aceitação\n2) Cálculos e fórmulas utilizadas\n3) Condições de processamento e decisões lógicas\n4) Regras de transformação de dados\n5) Políticas de negócio codificadas\n6) Exceções e tratamentos especiais\n",
            "Analise e documente todas as estruturas de dados, incluindo:\n1) Layouts de registros e campos\n2) Tipos de dados e formatos (PIC clauses)\n3) Relacionamentos entre estruturas\n4) Copybooks utilizados e suas funções\n5) Mapeamento de dados de entrada e saída\n6) Transformações e conversões de dados\n",
            "Documente todas as interfaces e integrações, incluindo:\n1) Arquivos de entrada e saída (formatos, layouts, frequência)\n2) Chamadas para outros programas (CALL statements)\n3) Acesso a bancos de dados (SQL embedded, DB2, etc.)\n4) Interfaces com sistemas externos\n5) Dependências de JCL e jobs\n6) Parâmetros de execução e configuração\n",
            "Analise aspectos de performance e otimização, incluindo:\n1) Pontos críticos de performance no código\n2) Uso de recursos (CPU, memória, I/O)\n3) Algoritmos e estruturas de dados utilizadas\n4) Oportunidades de otimização identificadas\n5) Gargalos potenciais e limitações\n6) Recomendações para melhorias\n",
            "Forneça um guia de manutenção detalhado, incluindo:\n1) Pontos de atenção para modificações\n2) Impactos de mudanças em diferentes seções\n3) Procedimentos de teste recomendados\n4) Documentação de bugs conhecidos ou limitações\n5) Histórico de modificações importantes\n6) Recomendações para futuras melhorias\n",
            "Avalie a qualidade do código, incluindo:\n1) Aderência a padrões de codificação COBOL\n2) Legibilidade e organização do código\n3) Uso de boas práticas de programação\n4) Identificação de code smells ou anti-patterns\n5) Sugestões de refatoração\n6) Avaliação de manutenibilidade\n"
        ]
        
        return base_questions
    
    def get_system_prompt(self) -> str:
        """
        Retorna prompt de sistema baseado no modelo.
        
        Returns:
            Prompt de sistema
        """
        config = self.current_model_config
        return f"Sistema de análise COBOL configurado para modelo {self.model_name} com persona: {config['persona']}"
    
    def get_prompt_strategy(self) -> str:
        """
        Retorna estratégia de prompt utilizada.
        
        Returns:
            Descrição da estratégia
        """
        config = self.current_model_config
        return f"Análise em duas etapas: (1) Análise geral como programador experiente, (2) Questões específicas detalhadas. Profundidade: {config['analysis_depth']}, Foco técnico: {config['technical_focus']}"
    
    def get_prompt_metadata(self) -> Dict[str, Any]:
        """
        Retorna metadados do prompt gerado.
        
        Returns:
            Dicionário com metadados
        """
        return {
            'model_selected': self.model_name,
            'model_configuration': self.current_model_config,
            'analysis_questions': self.get_analysis_questions_list(),
            'prompt_strategy': self.get_prompt_strategy(),
            'system_prompt': self.get_system_prompt(),
            'timestamp': datetime.now().isoformat(),
            'two_phase_analysis': True,
            'expert_analysis_enabled': True
        }
