"""
COBOL AI Engine v2.6.0 - Enhanced Prompt Manager
Gerenciador avançado de prompts com suporte a YAML customizado.
"""

import logging
from typing import Dict, Any, Optional


class EnhancedPromptManager:
    """
    Gerenciador avançado de prompts para análise COBOL.
    Trabalha diretamente com configuração de prompts carregada.
    """
    
    def __init__(self, prompt_config: Dict[str, Any]):
        """
        Inicializa o gerenciador com configuração de prompts já carregada.
        
        Args:
            prompt_config: Dicionário com configuração de prompts do ConfigManager
        """
        self.logger = logging.getLogger(__name__)
        self.prompt_config = prompt_config
        
        if not prompt_config:
            self.logger.error("Configuração de prompts não fornecida")
            raise ValueError("Configuração de prompts é obrigatória")
            
        self.logger.info(f"Enhanced Prompt Manager inicializado com prompt de {len(prompt_config.get('full_prompt', ''))} caracteres")
    
    def create_complete_analysis_prompt(self, program_name: str, cobol_code: str, copybooks_content: str = "") -> str:
        """
        Cria o prompt completo para análise do programa COBOL.
        
        Args:
            program_name: Nome do programa COBOL
            cobol_code: Código fonte do programa
            copybooks_content: Conteúdo dos copybooks relacionados
            
        Returns:
            Prompt completo formatado
        """
        try:
            # Obter o prompt base do usuário
            user_prompt = self.prompt_config.get('user_prompt', self.prompt_config.get('full_prompt', ''))
            
            if not user_prompt:
                self.logger.error("Prompt do usuário não encontrado na configuração")
                raise ValueError("Prompt do usuário não encontrado")
            
            # Substituir placeholders
            formatted_prompt = user_prompt.replace('{cobol_code}', cobol_code)
            formatted_prompt = formatted_prompt.replace('{copybooks}', copybooks_content)
            formatted_prompt = formatted_prompt.replace('{program_name}', program_name)
            
            # Adicionar informações contextuais
            context_info = f"""
=== INFORMAÇÕES DO PROGRAMA ===
Nome do Programa: {program_name}
Tamanho do Código: {len(cobol_code)} caracteres
Copybooks Disponíveis: {len(copybooks_content)} caracteres
Prompt YAML Utilizado: {self.prompt_config.get('yaml_file', 'N/A')}

=== CÓDIGO COBOL ===
{cobol_code}

=== COPYBOOKS ===
{copybooks_content}

=== ANÁLISE SOLICITADA ===
{formatted_prompt}
"""
            
            self.logger.info(f"Prompt completo criado para {program_name}: {len(context_info)} caracteres")
            return context_info
            
        except Exception as e:
            self.logger.error(f"Erro ao criar prompt completo: {e}")
            raise
    
    def get_system_prompt(self) -> str:
        """
        Retorna o prompt do sistema.
        
        Returns:
            Prompt do sistema
        """
        return self.prompt_config.get('system_prompt', 'Você é um especialista em análise de sistemas COBOL.')
    
    def get_user_prompt_template(self) -> str:
        """
        Retorna o template do prompt do usuário.
        
        Returns:
            Template do prompt do usuário
        """
        return self.prompt_config.get('user_prompt', self.prompt_config.get('full_prompt', ''))
    
    def get_prompt_metadata(self) -> Dict[str, Any]:
        """
        Retorna metadados sobre o prompt carregado.
        
        Returns:
            Dicionário com metadados do prompt
        """
        full_prompt = self.prompt_config.get('full_prompt', '')
        
        return {
            'yaml_file': self.prompt_config.get('yaml_file', 'N/A'),
            'prompt_length': len(full_prompt),
            'bian_references': full_prompt.lower().count('bian'),
            'componentization_references': full_prompt.lower().count('component'),
            'has_system_prompt': bool(self.prompt_config.get('system_prompt')),
            'has_user_prompt': bool(self.prompt_config.get('user_prompt')),
            'raw_yaml_available': bool(self.prompt_config.get('raw_yaml'))
        }
    
    def validate_prompt_config(self) -> bool:
        """
        Valida se a configuração de prompts está completa.
        
        Returns:
            True se válida, False caso contrário
        """
        required_fields = ['full_prompt']
        
        for field in required_fields:
            if not self.prompt_config.get(field):
                self.logger.error(f"Campo obrigatório '{field}' não encontrado na configuração de prompts")
                return False
        
        return True
