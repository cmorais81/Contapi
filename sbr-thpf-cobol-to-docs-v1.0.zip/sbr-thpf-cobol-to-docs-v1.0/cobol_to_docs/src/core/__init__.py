"""
COBOL AI Engine v2.6.0 - Módulo Core
Componentes centrais do sistema.
"""

from .config import ConfigManager
from .enhanced_prompt_manager import EnhancedPromptManager

__all__ = ['ConfigManager', 'EnhancedPromptManager']

