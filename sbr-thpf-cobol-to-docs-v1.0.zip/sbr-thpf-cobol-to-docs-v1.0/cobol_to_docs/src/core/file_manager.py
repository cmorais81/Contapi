"""
COBOL AI Engine v4.0 - File Manager
Gerenciador de arquivos seguindo princípios SOLID para leitura e interpretação de arquivos de entrada.
"""

import os
import logging
from typing import List, Dict, Any, Tuple, Optional
from pathlib import Path
from dataclasses import dataclass

from parsers.cobol_parser import COBOLParser, CobolProgram, CobolBook


@dataclass
class FileEntry:
    """Representa uma entrada de arquivo com metadados."""
    path: str
    name: str
    exists: bool
    size: int = 0
    error: Optional[str] = None


class FileManager:
    """
    Gerenciador de arquivos responsável por:
    - Interpretar arquivos de lista (fontes.txt, books.txt)
    - Validar existência de arquivos
    - Coordenar o parsing com COBOLParser
    - Fornecer metadados dos arquivos
    
    Princípios SOLID aplicados:
    - SRP: Responsabilidade única de gerenciar arquivos
    - OCP: Extensível para novos tipos de arquivo
    - LSP: Interface consistente
    - ISP: Interface específica para gerenciamento de arquivos
    - DIP: Depende de abstrações (COBOLParser)
    """
    
    def __init__(self, cobol_parser: Optional[COBOLParser] = None):
        """
        Inicializa o FileManager.
        
        Args:
            cobol_parser: Parser COBOL para processar arquivos (injeção de dependência)
        """
        self.logger = logging.getLogger(__name__)
        self.cobol_parser = cobol_parser or COBOLParser()
        
    def load_programs_from_list(self, sources_file: str) -> Tuple[Dict[str, str], List[FileEntry]]:
        """
        Carrega programas COBOL a partir de um arquivo de lista.
        
        Args:
            sources_file: Caminho para o arquivo fontes.txt
            
        Returns:
            Tuple[Dict[str, str], List[FileEntry]]: Programas carregados e metadados dos arquivos
        """
        programs_data = {}
        file_entries = []
        
        try:
            # Determinar se é arquivo de lista ou arquivo COBOL direto
            if self._is_cobol_list_file(sources_file):
                # Arquivo contém lista de caminhos para arquivos COBOL
                file_paths = self._read_file_list(sources_file)
                
                for file_path in file_paths:
                    entry = self._create_file_entry(file_path, os.path.dirname(sources_file))
                    file_entries.append(entry)
                    
                    if entry.exists:
                        try:
                            programs, _ = self.cobol_parser.parse_file(entry.path)
                            for program in programs:
                                programs_data[program.name] = program.content
                                self.logger.info(f"Programa carregado: {program.name} de {entry.path}")
                        except Exception as e:
                            entry.error = str(e)
                            self.logger.error(f"Erro ao parsear {entry.path}: {e}")
                    else:
                        self.logger.warning(f"Arquivo não encontrado: {entry.path}")
            else:
                # Arquivo é um COBOL empilhado ou único
                entry = self._create_file_entry(sources_file, "")
                file_entries.append(entry)
                
                if entry.exists:
                    try:
                        programs, _ = self.cobol_parser.parse_file(entry.path)
                        for program in programs:
                            programs_data[program.name] = program.content
                            self.logger.info(f"Programa carregado: {program.name} de {entry.path}")
                    except Exception as e:
                        entry.error = str(e)
                        self.logger.error(f"Erro ao parsear {entry.path}: {e}")
                        
        except Exception as e:
            self.logger.error(f"Erro ao carregar programas de {sources_file}: {e}")
            
        return programs_data, file_entries
    
    def load_copybooks_from_list(self, books_file: str) -> Tuple[str, List[FileEntry]]:
        """
        Carrega copybooks a partir de um arquivo de lista.
        
        Args:
            books_file: Caminho para o arquivo books.txt
            
        Returns:
            Tuple[str, List[FileEntry]]: Conteúdo dos copybooks concatenado e metadados
        """
        copybooks_content = ""
        file_entries = []
        
        try:
            # Determinar se é arquivo de lista ou arquivo COBOL direto
            if self._is_cobol_list_file(books_file):
                # Arquivo contém lista de caminhos para copybooks
                file_paths = self._read_file_list(books_file)
                
                for file_path in file_paths:
                    entry = self._create_file_entry(file_path, os.path.dirname(books_file))
                    file_entries.append(entry)
                    
                    if entry.exists:
                        try:
                            _, books = self.cobol_parser.parse_file(entry.path)
                            for book in books:
                                copybooks_content += f"\n=== COPYBOOK {book.name} ===\n{book.content}\n"
                                self.logger.info(f"Copybook carregado: {book.name} de {entry.path}")
                        except Exception as e:
                            entry.error = str(e)
                            self.logger.error(f"Erro ao parsear {entry.path}: {e}")
            else:
                # Arquivo é um copybook empilhado ou único
                entry = self._create_file_entry(books_file, "")
                file_entries.append(entry)
                
                if entry.exists:
                    try:
                        _, books = self.cobol_parser.parse_file(entry.path)
                        for book in books:
                            copybooks_content += f"\n=== COPYBOOK {book.name} ===\n{book.content}\n"
                            self.logger.info(f"Copybook carregado: {book.name} de {entry.path}")
                    except Exception as e:
                        entry.error = str(e)
                        self.logger.error(f"Erro ao parsear {entry.path}: {e}")
                        
        except Exception as e:
            self.logger.error(f"Erro ao carregar copybooks de {books_file}: {e}")
            
        return copybooks_content, file_entries
    
    def _is_cobol_list_file(self, file_path: str) -> bool:
        """
        Determina se o arquivo é uma lista de caminhos ou um arquivo COBOL.
        
        Args:
            file_path: Caminho do arquivo
            
        Returns:
            bool: True se for lista de arquivos, False se for COBOL
        """
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                first_lines = [f.readline().strip() for _ in range(5)]
            
            # Verificar se as primeiras linhas parecem caminhos de arquivo
            path_indicators = 0
            cobol_indicators = 0
            
            for line in first_lines:
                if not line:
                    continue
                    
                # Indicadores de caminho de arquivo
                if ('/' in line or '\\' in line or 
                    line.endswith('.cbl') or line.endswith('.cob') or 
                    line.endswith('.cobol') or line.endswith('.txt')):
                    path_indicators += 1
                
                # Indicadores de código COBOL
                cobol_keywords = ['IDENTIFICATION', 'PROGRAM-ID', 'DATA DIVISION', 
                                'PROCEDURE DIVISION', 'VMEMBER', 'WORKING-STORAGE']
                if any(keyword in line.upper() for keyword in cobol_keywords):
                    cobol_indicators += 1
            
            # Se tem mais indicadores de caminho que de COBOL, é lista
            return path_indicators > cobol_indicators
            
        except Exception as e:
            self.logger.error(f"Erro ao analisar tipo de arquivo {file_path}: {e}")
            return False
    
    def _read_file_list(self, list_file: str) -> List[str]:
        """
        Lê um arquivo de lista e retorna os caminhos.
        
        Args:
            list_file: Caminho do arquivo de lista
            
        Returns:
            List[str]: Lista de caminhos de arquivo
        """
        file_paths = []
        
        try:
            with open(list_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):  # Ignorar comentários
                        file_paths.append(line)
                        
        except Exception as e:
            self.logger.error(f"Erro ao ler arquivo de lista {list_file}: {e}")
            
        return file_paths
    
    def _create_file_entry(self, file_path: str, base_dir: str) -> FileEntry:
        """
        Cria uma entrada de arquivo com metadados.
        
        Args:
            file_path: Caminho do arquivo
            base_dir: Diretório base para caminhos relativos
            
        Returns:
            FileEntry: Entrada com metadados
        """
        # Resolver caminho absoluto
        if not os.path.isabs(file_path) and base_dir:
            full_path = os.path.join(base_dir, file_path)
        else:
            full_path = file_path
        
        # Verificar existência e obter metadados
        exists = os.path.exists(full_path)
        size = 0
        
        if exists:
            try:
                size = os.path.getsize(full_path)
            except Exception:
                pass
        
        return FileEntry(
            path=full_path,
            name=os.path.basename(file_path),
            exists=exists,
            size=size
        )
    
    def get_file_statistics(self, file_entries: List[FileEntry]) -> Dict[str, Any]:
        """
        Gera estatísticas dos arquivos processados.
        
        Args:
            file_entries: Lista de entradas de arquivo
            
        Returns:
            Dict[str, Any]: Estatísticas dos arquivos
        """
        total_files = len(file_entries)
        existing_files = sum(1 for entry in file_entries if entry.exists)
        total_size = sum(entry.size for entry in file_entries if entry.exists)
        files_with_errors = sum(1 for entry in file_entries if entry.error)
        
        return {
            'total_files': total_files,
            'existing_files': existing_files,
            'missing_files': total_files - existing_files,
            'files_with_errors': files_with_errors,
            'total_size_bytes': total_size,
            'total_size_mb': round(total_size / (1024 * 1024), 2),
            'success_rate': round((existing_files - files_with_errors) / total_files * 100, 1) if total_files > 0 else 0
        }
