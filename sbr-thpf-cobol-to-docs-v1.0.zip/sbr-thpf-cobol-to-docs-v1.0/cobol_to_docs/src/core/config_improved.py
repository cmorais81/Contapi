#!/usr/bin/env python3
"""
COBOL AI Engine v3.0 - Improved Configuration Manager
Gerenciador de configuração com resolução robusta de caminhos.
"""

import os
import sys
import yaml
import logging
from typing import Dict, Any, Optional
from pathlib import Path
import pkg_resources


class ImprovedConfigManager:
    """
    Gerenciador de configuração com resolução robusta de caminhos.
    
    Funcionalidades:
    - Resolução automática de caminhos para diferentes métodos de execução
    - Suporte a instalação via pip e execução local
    - Configuração personalizada via parâmetros
    - Fallbacks inteligentes
    """
    
    def __init__(self, config_path: Optional[str] = None, 
                 data_dir: Optional[str] = None,
                 prompts_file: Optional[str] = None):
        """
        Inicializa o gerenciador de configuração.
        
        Args:
            config_path: Caminho personalizado para config.yaml
            data_dir: Diretório personalizado para dados RAG
            prompts_file: Arquivo personalizado de prompts
        """
        self.logger = logging.getLogger(__name__)
        
        # Configurações personalizadas
        self.custom_config_path = config_path
        self.custom_data_dir = data_dir
        self.custom_prompts_file = prompts_file
        
        # Detectar método de execução
        self.execution_method = self._detect_execution_method()
        self.logger.info(f"Método de execução detectado: {self.execution_method}")
        
        # Carregar configurações
        self.config_path = self._find_config_file()
        self.config = self._load_config()
        self.prompts_config = self._load_prompts_config()
        
        self.logger.info(f"Configuração carregada de: {self.config_path}")
    
    def _detect_execution_method(self) -> str:
        """
        Detecta o método de execução atual.
        
        Returns:
            str: 'pip_install', 'main_py', 'cli_py', ou 'unknown'
        """
        try:
            # Verificar se foi instalado via pip
            pkg_resources.get_distribution('cobol-to-docs')
            return 'pip_install'
        except pkg_resources.DistributionNotFound:
            pass
        
        # Verificar script atual
        current_script = os.path.basename(sys.argv[0])
        if 'main.py' in current_script:
            return 'main_py'
        elif 'cli.py' in current_script:
            return 'cli_py'
        elif any(cmd in current_script for cmd in ['cobol-to-docs', 'cobol-docs', 'cobol-analyze']):
            return 'pip_install'
        
        return 'unknown'
    
    def _get_package_root(self) -> Optional[str]:
        """
        Obtém o diretório raiz do pacote.
        
        Returns:
            str: Caminho para o diretório raiz ou None
        """
        try:
            if self.execution_method == 'pip_install':
                # Para instalação via pip, usar pkg_resources
                return pkg_resources.resource_filename('cobol_to_docs', '')
            else:
                # Para execução local, calcular baseado no arquivo atual
                current_file = os.path.abspath(__file__)
                # Subir: config_improved.py -> core -> src -> cobol_to_docs
                return os.path.dirname(os.path.dirname(os.path.dirname(current_file)))
        except Exception as e:
            self.logger.warning(f"Erro ao obter package root: {e}")
            return None
    
    def _find_config_file(self) -> str:
        """
        Encontra o arquivo de configuração de forma robusta.
        
        Returns:
            str: Caminho para config.yaml
        """
        if self.custom_config_path and os.path.exists(self.custom_config_path):
            return self.custom_config_path
        
        # Lista de possíveis localizações
        search_paths = []
        
        # Diretório atual
        search_paths.extend([
            "config/config.yaml",
            "cobol_to_docs/config/config.yaml"
        ])
        
        # Package root
        package_root = self._get_package_root()
        if package_root:
            search_paths.extend([
                os.path.join(package_root, "config", "config.yaml"),
                os.path.join(package_root, "cobol_to_docs", "config", "config.yaml")
            ])
        
        # Caminhos relativos ao arquivo atual
        current_dir = os.path.dirname(os.path.abspath(__file__))
        search_paths.extend([
            os.path.join(current_dir, "..", "..", "config", "config.yaml"),
            os.path.join(current_dir, "..", "..", "..", "config", "config.yaml"),
            os.path.join(current_dir, "..", "..", "..", "cobol_to_docs", "config", "config.yaml")
        ])
        
        # Para instalação via pip, tentar pkg_resources
        if self.execution_method == 'pip_install':
            try:
                config_content = pkg_resources.resource_string('cobol_to_docs', 'config/config.yaml')
                # Criar arquivo temporário
                temp_config = os.path.join(os.path.expanduser("~"), ".cobol_to_docs_config.yaml")
                with open(temp_config, 'wb') as f:
                    f.write(config_content)
                search_paths.insert(0, temp_config)
            except Exception as e:
                self.logger.warning(f"Erro ao acessar config via pkg_resources: {e}")
        
        # Procurar arquivo
        for path in search_paths:
            abs_path = os.path.abspath(path)
            if os.path.exists(abs_path):
                self.logger.info(f"Config encontrado em: {abs_path}")
                return abs_path
        
        # Fallback: criar config padrão
        default_config = os.path.join(os.getcwd(), "config.yaml")
        self._create_default_config(default_config)
        return default_config
    
    def _find_prompts_file(self) -> str:
        """
        Encontra o arquivo de prompts de forma robusta.
        
        Returns:
            str: Caminho para prompts.yaml
        """
        if self.custom_prompts_file and os.path.exists(self.custom_prompts_file):
            return self.custom_prompts_file
        
        # Obter nome do arquivo de prompts da configuração
        prompts_filename = self.config.get('ai', {}).get('prompt', {}).get('prompts_file', 'prompts.yaml')
        
        # Lista de possíveis localizações
        search_paths = []
        
        # Mesmo diretório do config
        config_dir = os.path.dirname(self.config_path)
        search_paths.append(os.path.join(config_dir, prompts_filename))
        
        # Diretório atual
        search_paths.extend([
            f"config/{prompts_filename}",
            f"cobol_to_docs/config/{prompts_filename}"
        ])
        
        # Package root
        package_root = self._get_package_root()
        if package_root:
            search_paths.extend([
                os.path.join(package_root, "config", prompts_filename),
                os.path.join(package_root, "cobol_to_docs", "config", prompts_filename)
            ])
        
        # Caminhos relativos ao arquivo atual
        current_dir = os.path.dirname(os.path.abspath(__file__))
        search_paths.extend([
            os.path.join(current_dir, "..", "..", "config", prompts_filename),
            os.path.join(current_dir, "..", "..", "..", "config", prompts_filename)
        ])
        
        # Para instalação via pip, tentar pkg_resources
        if self.execution_method == 'pip_install':
            try:
                prompts_content = pkg_resources.resource_string('cobol_to_docs', f'config/{prompts_filename}')
                # Criar arquivo temporário
                temp_prompts = os.path.join(os.path.expanduser("~"), f".cobol_to_docs_{prompts_filename}")
                with open(temp_prompts, 'wb') as f:
                    f.write(prompts_content)
                search_paths.insert(0, temp_prompts)
            except Exception as e:
                self.logger.warning(f"Erro ao acessar prompts via pkg_resources: {e}")
        
        # Procurar arquivo
        for path in search_paths:
            abs_path = os.path.abspath(path)
            if os.path.exists(abs_path):
                self.logger.info(f"Prompts encontrado em: {abs_path}")
                return abs_path
        
        # Fallback: criar prompts padrão
        default_prompts = os.path.join(os.getcwd(), prompts_filename)
        self._create_default_prompts(default_prompts)
        return default_prompts
    
    def get_data_directory(self) -> str:
        """
        Retorna o diretório de dados RAG.
        
        Returns:
            str: Caminho para o diretório de dados
        """
        if self.custom_data_dir and os.path.exists(self.custom_data_dir):
            return self.custom_data_dir
        
        # Lista de possíveis localizações
        search_paths = []
        
        # Diretório atual
        search_paths.extend([
            "data",
            "cobol_to_docs/data"
        ])
        
        # Package root
        package_root = self._get_package_root()
        if package_root:
            search_paths.extend([
                os.path.join(package_root, "data"),
                os.path.join(package_root, "cobol_to_docs", "data")
            ])
        
        # Caminhos relativos ao arquivo atual
        current_dir = os.path.dirname(os.path.abspath(__file__))
        search_paths.extend([
            os.path.join(current_dir, "..", "..", "data"),
            os.path.join(current_dir, "..", "..", "..", "data"),
            os.path.join(current_dir, "..", "..", "..", "cobol_to_docs", "data")
        ])
        
        # Para instalação via pip, tentar pkg_resources
        if self.execution_method == 'pip_install':
            try:
                data_dir = pkg_resources.resource_filename('cobol_to_docs', 'data')
                if os.path.exists(data_dir):
                    search_paths.insert(0, data_dir)
            except Exception as e:
                self.logger.warning(f"Erro ao acessar data via pkg_resources: {e}")
        
        # Procurar diretório
        for path in search_paths:
            abs_path = os.path.abspath(path)
            if os.path.exists(abs_path):
                self.logger.info(f"Data directory encontrado em: {abs_path}")
                return abs_path
        
        # Fallback: criar diretório padrão
        default_data_dir = os.path.join(os.getcwd(), "data")
        os.makedirs(default_data_dir, exist_ok=True)
        self.logger.info(f"Criado data directory padrão: {default_data_dir}")
        return default_data_dir
    
    def _load_config(self) -> Dict[str, Any]:
        """Carrega configuração do arquivo."""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            return config or {}
        except Exception as e:
            self.logger.error(f"Erro ao carregar config: {e}")
            return self._get_default_config()
    
    def _load_prompts_config(self) -> Dict[str, Any]:
        """Carrega configuração de prompts."""
        prompts_path = self._find_prompts_file()
        
        try:
            with open(prompts_path, 'r', encoding='utf-8') as f:
                prompts_config = yaml.safe_load(f)
            return prompts_config or {}
        except Exception as e:
            self.logger.error(f"Erro ao carregar prompts: {e}")
            return self._get_default_prompts_config()
    
    def _create_default_config(self, path: str) -> None:
        """Cria arquivo de configuração padrão."""
        default_config = self._get_default_config()
        
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            yaml.dump(default_config, f, default_flow_style=False, allow_unicode=True)
        
        self.logger.info(f"Criado config padrão: {path}")
    
    def _create_default_prompts(self, path: str) -> None:
        """Cria arquivo de prompts padrão."""
        default_prompts = self._get_default_prompts_config()
        
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            yaml.dump(default_prompts, f, default_flow_style=False, allow_unicode=True)
        
        self.logger.info(f"Criado prompts padrão: {path}")
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão."""
        return {
            "ai": {
                "prompt": {
                    "prompts_file": "prompts.yaml"
                }
            },
            "providers": {
                "enhanced_mock": {
                    "enabled": True,
                    "models": {
                        "gpt-4": {
                            "name": "enhanced_mock",
                            "max_tokens": 4000
                        }
                    }
                }
            },
            "rag": {
                "enabled": True,
                "knowledge_base_file": "cobol_knowledge_base.json"
            }
        }
    
    def _get_default_prompts_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão de prompts."""
        return {
            "prompts": {
                "system_prompt": """
Você é um especialista em análise de código COBOL com mais de 20 anos de experiência em sistemas mainframe.
Responda todas as perguntas em português brasileiro de forma clara, técnica e detalhada.

Analise o código fornecido identificando:
- Estrutura e organização do programa
- Lógica de negócio implementada
- Dependências e relacionamentos
- Pontos críticos e considerações técnicas
- Fluxo de dados e processamento

Seja direto e objetivo nas explicações, sem usar formatação especial.
Organize a resposta de forma estruturada e fácil de entender.
""".strip()
            }
        }
    
    def get_system_prompt(self) -> str:
        """
        Retorna o system prompt configurado.
        
        Returns:
            str: System prompt
        """
        return self.prompts_config.get("prompts", {}).get("system_prompt", 
            self._get_default_prompts_config()["prompts"]["system_prompt"])
    
    def get_rag_config(self) -> Dict[str, Any]:
        """
        Retorna configuração RAG.
        
        Returns:
            Dict: Configuração RAG
        """
        return self.config.get("rag", {})
    
    def get_providers_config(self) -> Dict[str, Any]:
        """
        Retorna configuração de providers.
        
        Returns:
            Dict: Configuração de providers
        """
        return self.config.get("providers", {})
    
    def set_custom_paths(self, config_path: Optional[str] = None,
                        data_dir: Optional[str] = None,
                        prompts_file: Optional[str] = None) -> None:
        """
        Define caminhos personalizados e recarrega configurações.
        
        Args:
            config_path: Caminho personalizado para config.yaml
            data_dir: Diretório personalizado para dados RAG
            prompts_file: Arquivo personalizado de prompts
        """
        if config_path:
            self.custom_config_path = config_path
        if data_dir:
            self.custom_data_dir = data_dir
        if prompts_file:
            self.custom_prompts_file = prompts_file
        
        # Recarregar configurações
        self.config_path = self._find_config_file()
        self.config = self._load_config()
        self.prompts_config = self._load_prompts_config()
        
        self.logger.info("Configurações personalizadas aplicadas e recarregadas")
