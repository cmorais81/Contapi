"""
COBOL AI Engine v4.0 - Parser Interfaces
Interfaces para componentes do parser seguindo princípios de design orientado a objetos.
"""

from .parser_interface import (
    ICobolParser,
    IContentDetector,
    IContentCleaner,
    IMemberExtractor,
    ITypeClassifier,
    IParserValidator,
    ContentType,
    MemberType,
    ParseResult,
    ParseStatistics
)

__all__ = [
    'ICobolParser',
    'IContentDetector',
    'IContentCleaner',
    'IMemberExtractor',
    'ITypeClassifier',
    'IParserValidator',
    'ContentType',
    'MemberType',
    'ParseResult',
    'ParseStatistics'
]
