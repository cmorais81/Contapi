"""
COBOL AI Engine v4.0 - Content Cleaner
Limpador robusto para conteúdo COBOL.
"""

import re
import logging
from typing import List

from parsers.interfaces.parser_interface import IContentCleaner


class CobolContentCleaner(IContentCleaner):
    """
    Limpador de conteúdo COBOL.
    
    Responsabilidades:
    - Remover comentários desnecessários
    - Normalizar espaçamento
    - Limpar linhas vazias excessivas
    - Preservar estrutura COBOL
    - Remover caracteres de controle
    """
    
    def __init__(self):
        """Inicializa o limpador de conteúdo."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões para limpeza
        self.comment_patterns = [
            re.compile(r'^\s*\*.*$'),  # Comentários com *
            re.compile(r'^\s*//.*$'),  # Comentários com //
            re.compile(r'^\s*#.*$'),   # Comentários com #
        ]
        
        # Padrões para preservar (comentários importantes)
        self.preserve_patterns = [
            re.compile(r'^\s*\*\s*PROGRAM-ID', re.IGNORECASE),
            re.compile(r'^\s*\*\s*AUTHOR', re.IGNORECASE),
            re.compile(r'^\s*\*\s*DATE', re.IGNORECASE),
            re.compile(r'^\s*\*\s*VMEMBER', re.IGNORECASE),
        ]
        
        self.logger.info("Content Cleaner inicializado")
    
    def clean_content(self, lines: List[str]) -> List[str]:
        """
        Limpa o conteúdo COBOL.
        
        Args:
            lines: Linhas do conteúdo
            
        Returns:
            List[str]: Linhas limpas
        """
        if not lines:
            return []
        
        cleaned_lines = []
        consecutive_empty = 0
        
        for line in lines:
            # Limpar caracteres de controle
            cleaned_line = self._clean_control_characters(line)
            
            # Verificar se é linha vazia
            if not cleaned_line.strip():
                consecutive_empty += 1
                # Permitir no máximo 2 linhas vazias consecutivas
                if consecutive_empty <= 2:
                    cleaned_lines.append('')
                continue
            else:
                consecutive_empty = 0
            
            # Verificar se deve preservar comentário
            if self._should_preserve_comment(cleaned_line):
                cleaned_lines.append(cleaned_line)
                continue
            
            # Verificar se é comentário a remover
            if self._is_removable_comment(cleaned_line):
                continue
            
            # Normalizar espaçamento
            normalized_line = self._normalize_spacing(cleaned_line)
            cleaned_lines.append(normalized_line)
        
        # Remover linhas vazias do final
        while cleaned_lines and not cleaned_lines[-1].strip():
            cleaned_lines.pop()
        
        self.logger.debug(f"Conteúdo limpo: {len(lines)} -> {len(cleaned_lines)} linhas")
        return cleaned_lines
    
    def remove_comments(self, lines: List[str]) -> List[str]:
        """
        Remove comentários do conteúdo.
        
        Args:
            lines: Linhas do conteúdo
            
        Returns:
            List[str]: Linhas sem comentários
        """
        cleaned_lines = []
        
        for line in lines:
            # Preservar comentários importantes
            if self._should_preserve_comment(line):
                cleaned_lines.append(line)
                continue
            
            # Remover comentários
            if not self._is_removable_comment(line):
                cleaned_lines.append(line)
        
        return cleaned_lines
    
    def normalize_spacing(self, lines: List[str]) -> List[str]:
        """
        Normaliza espaçamento das linhas.
        
        Args:
            lines: Linhas do conteúdo
            
        Returns:
            List[str]: Linhas com espaçamento normalizado
        """
        return [self._normalize_spacing(line) for line in lines]
    
    def remove_empty_lines(self, lines: List[str], max_consecutive: int = 2) -> List[str]:
        """
        Remove linhas vazias excessivas.
        
        Args:
            lines: Linhas do conteúdo
            max_consecutive: Máximo de linhas vazias consecutivas
            
        Returns:
            List[str]: Linhas sem vazios excessivos
        """
        cleaned_lines = []
        consecutive_empty = 0
        
        for line in lines:
            if not line.strip():
                consecutive_empty += 1
                if consecutive_empty <= max_consecutive:
                    cleaned_lines.append(line)
            else:
                consecutive_empty = 0
                cleaned_lines.append(line)
        
        return cleaned_lines
    
    def _clean_control_characters(self, line: str) -> str:
        """
        Remove caracteres de controle da linha.
        
        Args:
            line: Linha a limpar
            
        Returns:
            str: Linha limpa
        """
        # Remover caracteres de controle comuns
        cleaned = line.replace('\r', '').replace('\t', '    ')
        
        # Remover caracteres não imprimíveis (exceto espaços e quebras de linha)
        cleaned = ''.join(char for char in cleaned if ord(char) >= 32 or char in '\n ')
        
        return cleaned
    
    def _should_preserve_comment(self, line: str) -> bool:
        """
        Verifica se o comentário deve ser preservado.
        
        Args:
            line: Linha a verificar
            
        Returns:
            bool: True se deve preservar
        """
        return any(pattern.match(line) for pattern in self.preserve_patterns)
    
    def _is_removable_comment(self, line: str) -> bool:
        """
        Verifica se é comentário removível.
        
        Args:
            line: Linha a verificar
            
        Returns:
            bool: True se é comentário removível
        """
        # Não remover se deve preservar
        if self._should_preserve_comment(line):
            return False
        
        # Verificar padrões de comentário
        return any(pattern.match(line) for pattern in self.comment_patterns)
    
    def _normalize_spacing(self, line: str) -> str:
        """
        Normaliza espaçamento da linha.
        
        Args:
            line: Linha a normalizar
            
        Returns:
            str: Linha normalizada
        """
        # Preservar indentação inicial
        leading_spaces = len(line) - len(line.lstrip())
        
        # Normalizar espaços internos (múltiplos espaços -> espaço único)
        # Mas preservar estrutura COBOL (colunas específicas)
        if leading_spaces < 6:  # Área de numeração/indicador
            return line.rstrip()
        else:
            # Área A e B - normalizar espaços internos
            content = line.strip()
            normalized_content = re.sub(r'\s+', ' ', content)
            return ' ' * leading_spaces + normalized_content
    
    def get_cleaning_statistics(self, original_lines: List[str], cleaned_lines: List[str]) -> dict:
        """
        Retorna estatísticas da limpeza.
        
        Args:
            original_lines: Linhas originais
            cleaned_lines: Linhas limpas
            
        Returns:
            dict: Estatísticas da limpeza
        """
        original_count = len(original_lines)
        cleaned_count = len(cleaned_lines)
        
        # Contar comentários removidos
        comments_removed = 0
        for line in original_lines:
            if self._is_removable_comment(line) and not self._should_preserve_comment(line):
                comments_removed += 1
        
        # Contar linhas vazias removidas
        original_empty = sum(1 for line in original_lines if not line.strip())
        cleaned_empty = sum(1 for line in cleaned_lines if not line.strip())
        empty_removed = original_empty - cleaned_empty
        
        return {
            'original_lines': original_count,
            'cleaned_lines': cleaned_count,
            'lines_removed': original_count - cleaned_count,
            'comments_removed': comments_removed,
            'empty_lines_removed': empty_removed,
            'reduction_percentage': round((original_count - cleaned_count) / original_count * 100, 1) if original_count > 0 else 0
        }
