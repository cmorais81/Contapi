"""
COBOL AI Engine v4.0 - Parser Factory
Factory para criação de parsers seguindo princípios de design orientado a objetos.
"""

import logging
from typing import Dict, Any, Optional, Type
from enum import Enum

from interfaces.parser_interface import ICobolParser, IContentDetector, IContentCleaner, IMemberExtractor, ITypeClassifier


class ParserType(Enum):
    """Tipos de parser disponíveis."""
    ENHANCED = "enhanced"
    BASIC = "basic"
    LEGACY = "legacy"
    CUSTOM = "custom"


class ComponentType(Enum):
    """Tipos de componentes disponíveis."""
    DETECTOR = "detector"
    CLEANER = "cleaner"
    EXTRACTOR = "extractor"
    CLASSIFIER = "classifier"
    VALIDATOR = "validator"


class ParserFactory:
    """
    Factory para criação de parsers COBOL.
    
    Responsabilidades:
    - Criar instâncias configuradas de parsers
    - Gerenciar dependências entre componentes
    - Fornecer configurações padrão e customizadas
    - Implementar padrão Factory para extensibilidade
    """
    
    def __init__(self):
        """Inicializa a factory."""
        self.logger = logging.getLogger(__name__)
        self._component_registry = {}
        self._parser_registry = {}
        self._default_configs = {}
        
        # Registrar componentes padrão
        self._register_default_components()
        self._register_default_parsers()
        self._setup_default_configs()
    
    def create_parser(self, parser_type: ParserType = ParserType.ENHANCED, 
                     config: Optional[Dict[str, Any]] = None) -> ICobolParser:
        """
        Cria parser baseado no tipo especificado.
        
        Args:
            parser_type: Tipo de parser a criar
            config: Configuração opcional
            
        Returns:
            ICobolParser: Instância do parser
            
        Raises:
            ValueError: Se tipo de parser não suportado
        """
        try:
            if parser_type not in self._parser_registry:
                raise ValueError(f"Tipo de parser não suportado: {parser_type}")
            
            parser_class = self._parser_registry[parser_type]
            effective_config = self._merge_configs(parser_type, config)
            
            # Criar componentes necessários
            components = self._create_components(effective_config)
            
            # Criar parser com injeção de dependências
            parser = parser_class(**components)
            
            self.logger.info(f"Parser criado: {parser_type.value}")
            return parser
            
        except Exception as e:
            self.logger.error(f"Erro ao criar parser {parser_type}: {e}")
            raise
    
    def create_enhanced_parser(self, config: Optional[Dict[str, Any]] = None) -> ICobolParser:
        """
        Cria parser aprimorado com todos os componentes.
        
        Args:
            config: Configuração opcional
            
        Returns:
            ICobolParser: Parser aprimorado
        """
        return self.create_parser(ParserType.ENHANCED, config)
    
    def create_basic_parser(self, config: Optional[Dict[str, Any]] = None) -> ICobolParser:
        """
        Cria parser básico para compatibilidade.
        
        Args:
            config: Configuração opcional
            
        Returns:
            ICobolParser: Parser básico
        """
        return self.create_parser(ParserType.BASIC, config)
    
    def create_custom_parser(self, components: Dict[str, Any]) -> ICobolParser:
        """
        Cria parser customizado com componentes específicos.
        
        Args:
            components: Dicionário de componentes customizados
            
        Returns:
            ICobolParser: Parser customizado
        """
        try:
            # Validar componentes obrigatórios
            required_components = ['detector', 'cleaner', 'extractor', 'classifier']
            for component in required_components:
                if component not in components:
                    raise ValueError(f"Componente obrigatório ausente: {component}")
            
            # Usar parser enhanced como base
            parser_class = self._parser_registry[ParserType.ENHANCED]
            parser = parser_class(**components)
            
            self.logger.info("Parser customizado criado")
            return parser
            
        except Exception as e:
            self.logger.error(f"Erro ao criar parser customizado: {e}")
            raise
    
    def register_component(self, component_type: ComponentType, 
                          name: str, component_class: Type) -> None:
        """
        Registra novo componente na factory.
        
        Args:
            component_type: Tipo do componente
            name: Nome do componente
            component_class: Classe do componente
        """
        if component_type not in self._component_registry:
            self._component_registry[component_type] = {}
        
        self._component_registry[component_type][name] = component_class
        self.logger.info(f"Componente registrado: {component_type.value}.{name}")
    
    def register_parser(self, parser_type: ParserType, parser_class: Type[ICobolParser]) -> None:
        """
        Registra novo tipo de parser.
        
        Args:
            parser_type: Tipo do parser
            parser_class: Classe do parser
        """
        self._parser_registry[parser_type] = parser_class
        self.logger.info(f"Parser registrado: {parser_type.value}")
    
    def get_available_parsers(self) -> List[str]:
        """
        Retorna lista de parsers disponíveis.
        
        Returns:
            List[str]: Lista de tipos de parser
        """
        return [parser_type.value for parser_type in self._parser_registry.keys()]
    
    def get_available_components(self, component_type: ComponentType) -> List[str]:
        """
        Retorna componentes disponíveis para um tipo.
        
        Args:
            component_type: Tipo de componente
            
        Returns:
            List[str]: Lista de componentes disponíveis
        """
        if component_type not in self._component_registry:
            return []
        
        return list(self._component_registry[component_type].keys())
    
    def _register_default_components(self) -> None:
        """Registra componentes padrão."""
        try:
            # Importar implementações padrão
            from implementations.vmember_detector import VMemberDetector
            from implementations.content_cleaner import CobolContentCleaner
            from implementations.member_extractor import VMemberExtractor
            from implementations.type_classifier import CobolTypeClassifier
            
            # Registrar detectores
            self.register_component(ComponentType.DETECTOR, "vmember", VMemberDetector)
            self.register_component(ComponentType.DETECTOR, "basic", VMemberDetector)
            
            # Registrar limpadores
            self.register_component(ComponentType.CLEANER, "cobol", CobolContentCleaner)
            self.register_component(ComponentType.CLEANER, "basic", CobolContentCleaner)
            
            # Registrar extratores
            self.register_component(ComponentType.EXTRACTOR, "vmember", VMemberExtractor)
            self.register_component(ComponentType.EXTRACTOR, "basic", VMemberExtractor)
            
            # Registrar classificadores
            self.register_component(ComponentType.CLASSIFIER, "cobol", CobolTypeClassifier)
            self.register_component(ComponentType.CLASSIFIER, "basic", CobolTypeClassifier)
            
        except ImportError as e:
            self.logger.warning(f"Erro ao importar componentes padrão: {e}")
    
    def _register_default_parsers(self) -> None:
        """Registra parsers padrão."""
        try:
            # Importar implementações de parser
            from implementations.enhanced_cobol_parser import EnhancedCobolParser
            from implementations.basic_cobol_parser import BasicCobolParser
            
            # Registrar parsers
            self.register_parser(ParserType.ENHANCED, EnhancedCobolParser)
            self.register_parser(ParserType.BASIC, BasicCobolParser)
            
        except ImportError as e:
            self.logger.warning(f"Erro ao importar parsers padrão: {e}")
    
    def _setup_default_configs(self) -> None:
        """Configura configurações padrão."""
        self._default_configs = {
            ParserType.ENHANCED: {
                'detector': 'vmember',
                'cleaner': 'cobol',
                'extractor': 'vmember',
                'classifier': 'cobol',
                'enable_statistics': True,
                'enable_validation': True,
                'strict_mode': False
            },
            ParserType.BASIC: {
                'detector': 'basic',
                'cleaner': 'basic',
                'extractor': 'basic',
                'classifier': 'basic',
                'enable_statistics': False,
                'enable_validation': False,
                'strict_mode': False
            }
        }
    
    def _merge_configs(self, parser_type: ParserType, 
                      user_config: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Mescla configuração padrão com configuração do usuário.
        
        Args:
            parser_type: Tipo de parser
            user_config: Configuração do usuário
            
        Returns:
            Dict[str, Any]: Configuração mesclada
        """
        default_config = self._default_configs.get(parser_type, {})
        
        if user_config:
            merged_config = default_config.copy()
            merged_config.update(user_config)
            return merged_config
        
        return default_config
    
    def _create_components(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Cria componentes baseados na configuração.
        
        Args:
            config: Configuração dos componentes
            
        Returns:
            Dict[str, Any]: Dicionário de componentes criados
        """
        components = {}
        
        # Criar detector
        detector_name = config.get('detector', 'vmember')
        detector_class = self._component_registry[ComponentType.DETECTOR][detector_name]
        components['detector'] = detector_class()
        
        # Criar limpador
        cleaner_name = config.get('cleaner', 'cobol')
        cleaner_class = self._component_registry[ComponentType.CLEANER][cleaner_name]
        components['cleaner'] = cleaner_class()
        
        # Criar extrator
        extractor_name = config.get('extractor', 'vmember')
        extractor_class = self._component_registry[ComponentType.EXTRACTOR][extractor_name]
        components['extractor'] = extractor_class()
        
        # Criar classificador
        classifier_name = config.get('classifier', 'cobol')
        classifier_class = self._component_registry[ComponentType.CLASSIFIER][classifier_name]
        components['classifier'] = classifier_class()
        
        # Adicionar configurações opcionais
        if config.get('enable_statistics', False):
            from implementations.statistics_collector import StatisticsCollector
            components['statistics_collector'] = StatisticsCollector()
        
        if config.get('enable_validation', False):
            from implementations.content_validator import ContentValidator
            components['validator'] = ContentValidator()
        
        return components
    
    def get_factory_info(self) -> Dict[str, Any]:
        """
        Retorna informações sobre a factory.
        
        Returns:
            Dict[str, Any]: Informações da factory
        """
        return {
            'version': '4.0-enhanced',
            'available_parsers': self.get_available_parsers(),
            'available_components': {
                component_type.value: self.get_available_components(component_type)
                for component_type in ComponentType
            },
            'default_configs': {
                parser_type.value: config
                for parser_type, config in self._default_configs.items()
            },
            'features': [
                'Design principles compliance',
                'Dependency injection',
                'Component registration',
                'Configuration management',
                'Extensible architecture'
            ]
        }


# Instância global da factory (Singleton pattern)
_parser_factory_instance = None


def get_parser_factory() -> ParserFactory:
    """
    Retorna instância singleton da factory.
    
    Returns:
        ParserFactory: Instância da factory
    """
    global _parser_factory_instance
    
    if _parser_factory_instance is None:
        _parser_factory_instance = ParserFactory()
    
    return _parser_factory_instance


# Funções de conveniência
def create_enhanced_parser(config: Optional[Dict[str, Any]] = None) -> ICobolParser:
    """Função de conveniência para criar parser aprimorado."""
    factory = get_parser_factory()
    return factory.create_enhanced_parser(config)


def create_basic_parser(config: Optional[Dict[str, Any]] = None) -> ICobolParser:
    """Função de conveniência para criar parser básico."""
    factory = get_parser_factory()
    return factory.create_basic_parser(config)


def create_custom_parser(components: Dict[str, Any]) -> ICobolParser:
    """Função de conveniência para criar parser customizado."""
    factory = get_parser_factory()
    return factory.create_custom_parser(components)
