#!/usr/bin/env python3
"""
Enhanced Response Formatter - Garantir que o relatório mostre TUDO que o provider retornar
"""

import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional

class EnhancedResponseFormatter:
    """
    Formatador de resposta aprimorado que preserva TODA a informação retornada pelo provider.
    """
    
    def __init__(self):
        """Inicializa o formatador de resposta aprimorado."""
        self.logger = logging.getLogger(__name__)
    
    def format_complete_analysis_report(self, 
                                      program_name: str,
                                      response: Any,
                                      request_info: Dict[str, Any] = None,
                                      debug_mode: bool = True) -> str:
        """
        Formata relatório de análise incluindo TODA a resposta do provider.
        
        Args:
            program_name: Nome do programa analisado
            response: Resposta completa do provider
            request_info: Informações do request (opcional)
            debug_mode: Se deve incluir informações de debug
            
        Returns:
            Relatório completo em Markdown
        """
        report_parts = []
        
        # 1. CABEÇALHO DO RELATÓRIO
        report_parts.append(f"# Análise Completa do Programa {program_name}")
        report_parts.append(f"**Data da análise:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_parts.append("")
        
        # 2. METADADOS DO PROVIDER/MODELO
        if hasattr(response, 'model') and response.model:
            report_parts.append(f"**Modelo utilizado:** {response.model}")
        
        if hasattr(response, 'provider') and response.provider:
            report_parts.append(f"**Provider:** {response.provider}")
        
        if hasattr(response, 'tokens_used') and response.tokens_used:
            report_parts.append(f"**Tokens utilizados:** {response.tokens_used:,}")
        
        if hasattr(response, 'response_time') and response.response_time:
            report_parts.append(f"**Tempo de resposta:** {response.response_time:.2f}s")
        
        report_parts.append("")
        
        # 3. RESPOSTA COMPLETA DO MODELO (SEM FILTROS)
        report_parts.append("## Resposta Completa do Modelo")
        report_parts.append("*Esta seção contém EXATAMENTE tudo que o modelo retornou, sem edições ou filtros.*")
        report_parts.append("")
        
        # Extrair conteúdo da resposta
        content = ""
        if hasattr(response, 'content') and response.content:
            content = response.content
        elif hasattr(response, 'text') and response.text:
            content = response.text
        elif isinstance(response, str):
            content = response
        elif isinstance(response, dict) and 'content' in response:
            content = response['content']
        elif isinstance(response, dict) and 'text' in response:
            content = response['text']
        else:
            content = str(response)
        
        # Adicionar conteúdo completo
        report_parts.append(content)
        report_parts.append("")
        
        # 4. INFORMAÇÕES TÉCNICAS DETALHADAS (se debug_mode)
        if debug_mode:
            report_parts.append("## Informações Técnicas Detalhadas")
            report_parts.append("")
            
            # 4.1 Informações do Request
            if request_info:
                report_parts.append("### Request Information")
                for key, value in request_info.items():
                    if isinstance(value, (str, int, float, bool)):
                        report_parts.append(f"- **{key}:** {value}")
                    else:
                        report_parts.append(f"- **{key}:** {type(value).__name__} ({len(str(value))} chars)")
                report_parts.append("")
            
            # 4.2 Informações da Response
            report_parts.append("### Response Information")
            response_attrs = [
                'success', 'model', 'provider', 'tokens_used', 'response_time',
                'prompt_tokens', 'completion_tokens', 'total_tokens',
                'finish_reason', 'stop_reason'
            ]
            
            for attr in response_attrs:
                if hasattr(response, attr):
                    value = getattr(response, attr)
                    if value is not None:
                        report_parts.append(f"- **{attr}:** {value}")
            
            report_parts.append("")
            
            # 4.3 Raw Response (se disponível)
            if hasattr(response, 'raw_response') and response.raw_response:
                report_parts.append("### Raw Response")
                report_parts.append("*Resposta bruta completa do provider (formato JSON):*")
                report_parts.append("")
                report_parts.append("```json")
                
                try:
                    if isinstance(response.raw_response, dict):
                        raw_json = json.dumps(response.raw_response, indent=2, ensure_ascii=False)
                    else:
                        raw_json = str(response.raw_response)
                    report_parts.append(raw_json)
                except Exception as e:
                    report_parts.append(f"Erro ao serializar raw_response: {e}")
                    report_parts.append(str(response.raw_response))
                
                report_parts.append("```")
                report_parts.append("")
            
            # 4.4 Estatísticas de Conteúdo
            report_parts.append("### Estatísticas de Conteúdo")
            report_parts.append(f"- **Tamanho da resposta:** {len(content):,} caracteres")
            report_parts.append(f"- **Linhas na resposta:** {len(content.splitlines()):,}")
            report_parts.append(f"- **Palavras estimadas:** {len(content.split()):,}")
            report_parts.append("")
        
        # 5. RODAPÉ
        report_parts.append("---")
        report_parts.append("*Relatório gerado pelo COBOL-to-Docs v3.0 - Enhanced Response Formatter*")
        report_parts.append(f"*Preserva 100% da resposta original do provider/modelo*")
        
        # Juntar tudo
        complete_report = "\\n".join(report_parts)
        
        # Log para verificar completude
        self.logger.info(f"Relatório completo gerado:")
        self.logger.info(f"  - Tamanho total: {len(complete_report):,} caracteres")
        self.logger.info(f"  - Conteúdo da resposta: {len(content):,} caracteres")
        self.logger.info(f"  - Debug mode: {debug_mode}")
        
        return complete_report
    
    def create_debug_json(self, 
                         program_name: str,
                         request_info: Dict[str, Any],
                         response: Any) -> Dict[str, Any]:
        """
        Cria arquivo JSON de debug com TODAS as informações.
        
        Args:
            program_name: Nome do programa
            request_info: Informações completas do request
            response: Resposta completa do provider
            
        Returns:
            Dicionário com todas as informações para debug
        """
        debug_data = {
            "metadata": {
                "program_name": program_name,
                "timestamp": datetime.now().isoformat(),
                "formatter_version": "enhanced_v1.0"
            },
            "request": {},
            "response": {},
            "statistics": {}
        }
        
        # Request information
        if request_info:
            debug_data["request"] = dict(request_info)
        
        # Response information
        response_data = {}
        
        # Extrair todos os atributos da response
        if hasattr(response, '__dict__'):
            for key, value in response.__dict__.items():
                try:
                    # Tentar serializar para JSON
                    json.dumps(value)
                    response_data[key] = value
                except (TypeError, ValueError):
                    # Se não conseguir serializar, converter para string
                    response_data[key] = str(value)
        elif isinstance(response, dict):
            response_data = response.copy()
        else:
            response_data["content"] = str(response)
        
        debug_data["response"] = response_data
        
        # Statistics
        content = ""
        if hasattr(response, 'content'):
            content = response.content or ""
        elif isinstance(response, str):
            content = response
        elif isinstance(response, dict) and 'content' in response:
            content = response['content'] or ""
        
        debug_data["statistics"] = {
            "response_length_chars": len(content),
            "response_length_lines": len(content.splitlines()),
            "response_length_words": len(content.split()),
            "has_raw_response": hasattr(response, 'raw_response') and response.raw_response is not None,
            "response_type": type(response).__name__
        }
        
        return debug_data

def test_enhanced_response_formatter():
    """Testa o formatador de resposta aprimorado."""
    
    print("=== TESTE DO ENHANCED RESPONSE FORMATTER ===")
    
    # Simular resposta do provider
    class MockResponse:
        def __init__(self):
            self.success = True
            self.model = "enhanced-mock-gpt-4"
            self.provider = "enhanced_mock"
            self.tokens_used = 1250
            self.response_time = 2.34
            self.content = """## Análise Técnica Detalhada

### Estrutura do Programa TESTE001

#### Informações Básicas
- **Linhas de código**: 45
- **Divisões identificadas**: 3 (IDENTIFICATION, DATA, PROCEDURE)
- **Seções encontradas**: 2 (WORKING-STORAGE, PROCEDURE)

#### Análise da PROCEDURE DIVISION
O programa implementa um fluxo simples de processamento:

1. **MAIN-PROGRAMA**: Parágrafo principal
   - Executa display de mensagem
   - Termina execução com STOP RUN

#### Variáveis Identificadas
- **WS-CONTADOR**: Contador numérico (PIC 9(3))
  - Inicializado com ZEROS
  - Não utilizado no código atual

#### Recomendações
1. Remover variável WS-CONTADOR se não utilizada
2. Adicionar tratamento de erros
3. Considerar modularização para programas maiores"""
            
            self.raw_response = {
                "output": {
                    "content": self.content
                },
                "usage": {
                    "total_tokens": 1250,
                    "prompt_tokens": 890,
                    "completion_tokens": 360
                },
                "model": "enhanced-mock-gpt-4",
                "provider": "enhanced_mock"
            }
    
    # Criar formatador
    formatter = EnhancedResponseFormatter()
    
    # Informações do request
    request_info = {
        "program_name": "TESTE001",
        "model": "enhanced-mock-gpt-4",
        "prompt_length": 18268,
        "program_code_length": 234
    }
    
    # Gerar relatório completo
    report = formatter.format_complete_analysis_report(
        program_name="TESTE001",
        response=MockResponse(),
        request_info=request_info,
        debug_mode=True
    )
    
    print(f"\\nRelatório gerado:")
    print(f"  - Tamanho: {len(report):,} caracteres")
    print(f"  - Preview (primeiros 800 chars):")
    print(report[:800] + "...")
    
    # Gerar debug JSON
    debug_json = formatter.create_debug_json(
        program_name="TESTE001",
        request_info=request_info,
        response=MockResponse()
    )
    
    print(f"\\nDebug JSON gerado:")
    print(f"  - Seções: {list(debug_json.keys())}")
    print(f"  - Request keys: {list(debug_json['request'].keys())}")
    print(f"  - Response keys: {list(debug_json['response'].keys())}")
    print(f"  - Statistics: {debug_json['statistics']}")

if __name__ == "__main__":
    test_enhanced_response_formatter()
