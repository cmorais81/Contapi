"""
COBOL AI Engine v2.1.6 - Conversor Markdown para PDF
Utilitário para converter documentação Markdown em PDF sem dependências externas.
"""

import os
import logging
import re
import html
from typing import Optional, Dict, Any
from pathlib import Path


class MarkdownToPDFConverter:
    """Conversor de Markdown para PDF usando HTML e CSS."""
    
    def __init__(self):
        """Inicializa o conversor."""
        self.logger = logging.getLogger(__name__)
        
    def convert_to_pdf(self, markdown_file: str, output_file: str = None) -> str:
        """
        Converte arquivo Markdown para PDF via HTML.
        
        Args:
            markdown_file: Caminho do arquivo Markdown
            output_file: Caminho do arquivo HTML de saída (opcional)
            
        Returns:
            Caminho do arquivo HTML gerado (pronto para impressão em PDF)
        """
        try:
            if not os.path.exists(markdown_file):
                raise FileNotFoundError(f"Arquivo não encontrado: {markdown_file}")
            
            # Definir arquivo de saída
            if output_file is None:
                base_name = os.path.splitext(markdown_file)[0]
                output_file = f"{base_name}.html"
            
            # Ler conteúdo Markdown
            with open(markdown_file, 'r', encoding='utf-8') as f:
                markdown_content = f.read()
            
            # Converter para HTML
            html_content = self._markdown_to_html(markdown_content)
            
            # Gerar HTML completo com CSS para impressão
            full_html = self._create_printable_html(html_content, markdown_file)
            
            # Salvar arquivo HTML
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(full_html)
            
            self.logger.info(f"HTML gerado: {output_file}")
            self.logger.info("Para gerar PDF: Abra o arquivo HTML no navegador e use Ctrl+P -> Salvar como PDF")
            
            return output_file
            
        except Exception as e:
            self.logger.error(f"Erro ao converter para PDF: {e}")
            return ""
    
    def _markdown_to_html(self, markdown_content: str) -> str:
        """Converte Markdown básico para HTML."""
        
        # Escapar HTML primeiro
        content = html.escape(markdown_content)
        
        # Converter headers
        content = self._convert_headers(content)
        
        # Converter listas
        content = self._convert_lists(content)
        
        # Converter negrito e itálico
        content = self._convert_emphasis(content)
        
        # Converter links
        content = self._convert_links(content)
        
        # Converter código
        content = self._convert_code(content)
        
        # Converter tabelas
        content = self._convert_tables(content)
        
        # Converter quebras de linha
        content = content.replace('\n\n', '</p><p>')
        content = content.replace('\n', '<br>')
        
        # Envolver em parágrafos
        content = f'<p>{content}</p>'
        
        # Limpar parágrafos vazios
        content = content.replace('<p></p>', '')
        content = content.replace('<p><br></p>', '')
        
        return content
    
    def _convert_headers(self, content: str) -> str:
        """Converte headers Markdown para HTML."""
        lines = content.split('\n')
        converted_lines = []
        
        for line in lines:
            if line.startswith('######'):
                converted_lines.append(f'<h6>{line[6:].strip()}</h6>')
            elif line.startswith('#####'):
                converted_lines.append(f'<h5>{line[5:].strip()}</h5>')
            elif line.startswith('####'):
                converted_lines.append(f'<h4>{line[4:].strip()}</h4>')
            elif line.startswith('###'):
                converted_lines.append(f'<h3>{line[3:].strip()}</h3>')
            elif line.startswith('##'):
                converted_lines.append(f'<h2>{line[2:].strip()}</h2>')
            elif line.startswith('#'):
                converted_lines.append(f'<h1>{line[1:].strip()}</h1>')
            else:
                converted_lines.append(line)
        
        return '\n'.join(converted_lines)
    
    def _convert_lists(self, content: str) -> str:
        """Converte listas Markdown para HTML."""
        lines = content.split('\n')
        converted_lines = []
        in_list = False
        list_type = None
        
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('- ') or stripped.startswith('* '):
                if not in_list or list_type != 'ul':
                    if in_list:
                        converted_lines.append(f'</{list_type}>')
                    converted_lines.append('<ul>')
                    in_list = True
                    list_type = 'ul'
                converted_lines.append(f'<li>{stripped[2:]}</li>')
            elif re.match(r'^\d+\.\s', stripped):
                if not in_list or list_type != 'ol':
                    if in_list:
                        converted_lines.append(f'</{list_type}>')
                    converted_lines.append('<ol>')
                    in_list = True
                    list_type = 'ol'
                # Extrair texto após o número
                text = re.sub(r'^\d+\.\s', '', stripped)
                converted_lines.append(f'<li>{text}</li>')
            else:
                if in_list:
                    converted_lines.append(f'</{list_type}>')
                    in_list = False
                    list_type = None
                converted_lines.append(line)
        
        if in_list:
            converted_lines.append(f'</{list_type}>')
        
        return '\n'.join(converted_lines)
    
    def _convert_emphasis(self, content: str) -> str:
        """Converte negrito e itálico."""
        # Negrito (**texto**)
        content = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', content)
        # Itálico (*texto*)
        content = re.sub(r'\*(.*?)\*', r'<em>\1</em>', content)
        return content
    
    def _convert_links(self, content: str) -> str:
        """Converte links Markdown para HTML."""
        # Padrão: [texto](url)
        pattern = r'\[([^\]]+)\]\(([^)]+)\)'
        content = re.sub(pattern, r'<a href="\2">\1</a>', content)
        return content
    
    def _convert_code(self, content: str) -> str:
        """Converte código Markdown para HTML."""
        # Blocos de código (```código```)
        content = re.sub(r'```([^`]+)```', r'<pre><code>\1</code></pre>', content, flags=re.DOTALL)
        
        # Código inline (`código`)
        content = re.sub(r'`([^`]+)`', r'<code>\1</code>', content)
        
        return content
    
    def _convert_tables(self, content: str) -> str:
        """Converte tabelas Markdown para HTML."""
        lines = content.split('\n')
        converted_lines = []
        in_table = False
        header_processed = False
        
        for i, line in enumerate(lines):
            if '|' in line and line.strip().startswith('|') and line.strip().endswith('|'):
                if not in_table:
                    converted_lines.append('<table>')
                    in_table = True
                    header_processed = False
                
                # Verificar se é linha de separação (|---|---|)
                if re.match(r'^\|\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|$', line.strip()):
                    continue
                
                # Processar linha da tabela
                cells = [cell.strip() for cell in line.strip().split('|')[1:-1]]
                
                # Primeira linha é header
                if not header_processed:
                    converted_lines.append('<thead><tr>')
                    for cell in cells:
                        converted_lines.append(f'<th>{cell}</th>')
                    converted_lines.append('</tr></thead><tbody>')
                    header_processed = True
                else:
                    converted_lines.append('<tr>')
                    for cell in cells:
                        converted_lines.append(f'<td>{cell}</td>')
                    converted_lines.append('</tr>')
            else:
                if in_table:
                    converted_lines.append('</tbody></table>')
                    in_table = False
                converted_lines.append(line)
        
        if in_table:
            converted_lines.append('</tbody></table>')
        
        return '\n'.join(converted_lines)
    
    def _create_printable_html(self, html_content: str, source_file: str) -> str:
        """Cria HTML completo otimizado para impressão em PDF."""
        
        css_styles = """
        <style>
            @media print {
                @page {
                    margin: 2cm;
                    size: A4;
                }
                body {
                    font-family: 'Times New Roman', serif;
                    font-size: 12pt;
                    line-height: 1.4;
                    color: #000;
                }
                h1, h2, h3, h4, h5, h6 {
                    page-break-after: avoid;
                    margin-top: 1em;
                    margin-bottom: 0.5em;
                }
                h1 { font-size: 18pt; }
                h2 { font-size: 16pt; }
                h3 { font-size: 14pt; }
                h4 { font-size: 13pt; }
                h5 { font-size: 12pt; }
                h6 { font-size: 11pt; }
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin: 1em 0;
                }
                th, td {
                    border: 1px solid #000;
                    padding: 0.3em;
                    text-align: left;
                    vertical-align: top;
                }
                th {
                    background-color: #f0f0f0;
                    font-weight: bold;
                }
                pre, code {
                    font-family: 'Courier New', monospace;
                    font-size: 10pt;
                }
                pre {
                    background-color: #f5f5f5;
                    padding: 0.5em;
                    border: 1px solid #ddd;
                    white-space: pre-wrap;
                    page-break-inside: avoid;
                }
                ul, ol {
                    margin: 0.5em 0;
                    padding-left: 2em;
                }
                li {
                    margin: 0.2em 0;
                }
                .no-print {
                    display: none;
                }
            }
            
            @media screen {
                body {
                    font-family: Arial, sans-serif;
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 2em;
                    background-color: #fff;
                }
                .print-instructions {
                    background-color: #e7f3ff;
                    border: 1px solid #b3d9ff;
                    padding: 1em;
                    margin-bottom: 2em;
                    border-radius: 5px;
                }
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin: 1em 0;
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 0.5em;
                    text-align: left;
                    vertical-align: top;
                }
                th {
                    background-color: #f0f0f0;
                }
                pre {
                    background-color: #f5f5f5;
                    padding: 1em;
                    border-radius: 5px;
                    overflow-x: auto;
                }
                code {
                    background-color: #f0f0f0;
                    padding: 0.2em 0.4em;
                    border-radius: 3px;
                }
            }
        </style>
        """
        
        file_name = os.path.basename(source_file)
        
        html_template = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório COBOL - {file_name}</title>
    {css_styles}
</head>
<body>
    <div class="print-instructions no-print">
        <h3>Instruções para Gerar PDF</h3>
        <p><strong>1.</strong> Pressione <kbd>Ctrl+P</kbd> (Windows/Linux) ou <kbd>Cmd+P</kbd> (Mac)</p>
        <p><strong>2.</strong> Selecione "Salvar como PDF" como destino</p>
        <p><strong>3.</strong> Configure as opções:</p>
        <ul>
            <li>Tamanho: A4</li>
            <li>Margens: Padrão</li>
            <li>Incluir gráficos de fundo: Marcado</li>
        </ul>
        <p><strong>4.</strong> Clique em "Salvar"</p>
        <hr>
    </div>
    
    {html_content}
    
    <div class="no-print" style="margin-top: 2em; padding-top: 1em; border-top: 1px solid #ddd; color: #666; font-size: 0.9em;">
        <p>Documento gerado pelo COBOL AI Engine v2.1.6</p>
        <p>Arquivo fonte: {file_name}</p>
    </div>
</body>
</html>"""
        
        return html_template
    
    def get_status(self) -> Dict[str, Any]:
        """Retorna status dos métodos de conversão."""
        return {
            'html_conversion': True,
            'browser_pdf': True,
            'external_dependencies': False,
            'message': 'Conversão via HTML/CSS - sem dependências externas'
        }


    
    def convert_directory(self, input_dir: str, output_dir: str, pattern: str = "*.md") -> Dict[str, Any]:
        """
        Converte todos os arquivos Markdown de um diretório para HTML.
        
        Args:
            input_dir: Diretório com arquivos Markdown
            output_dir: Diretório para arquivos HTML
            pattern: Padrão de arquivos (ex: "*.md")
            
        Returns:
            Dicionário com resultados da conversão
        """
        import glob
        
        # Criar diretório de saída
        os.makedirs(output_dir, exist_ok=True)
        
        # Encontrar arquivos Markdown
        search_pattern = os.path.join(input_dir, pattern)
        markdown_files = glob.glob(search_pattern)
        
        results = {
            'total_files': len(markdown_files),
            'converted_files': 0,
            'failed_files': 0,
            'html_files': [],
            'errors': []
        }
        
        self.logger.info(f"Convertendo {len(markdown_files)} arquivo(s) Markdown para HTML")
        
        for md_file in markdown_files:
            try:
                # Definir arquivo HTML de saída
                base_name = os.path.splitext(os.path.basename(md_file))[0]
                html_file = os.path.join(output_dir, f"{base_name}.html")
                
                # Converter arquivo
                result_file = self.convert_to_pdf(md_file, html_file)
                
                if result_file:
                    results['converted_files'] += 1
                    results['html_files'].append(result_file)
                    self.logger.info(f"Convertido: {os.path.basename(md_file)} -> {os.path.basename(html_file)}")
                else:
                    results['failed_files'] += 1
                    results['errors'].append(f"Falha ao converter: {md_file}")
                    
            except Exception as e:
                results['failed_files'] += 1
                error_msg = f"Erro ao converter {md_file}: {str(e)}"
                results['errors'].append(error_msg)
                self.logger.error(error_msg)
        
        # Log final
        self.logger.info(f"Conversão concluída: {results['converted_files']} sucessos, {results['failed_files']} falhas")
        
        if results['html_files']:
            self.logger.info("Para gerar PDFs:")
            self.logger.info("1. Abra os arquivos HTML no navegador")
            self.logger.info("2. Use Ctrl+P -> Salvar como PDF")
            self.logger.info("3. Configure: Tamanho A4, Margens padrão, Incluir gráficos")
        
        return results

