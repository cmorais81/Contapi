"""
COBOL to Docs v3.0 - Ferramenta de Análise e Documentação COBOL com IA
"""

__version__ = "3.0.0"
__author__ = "COBOL Analyzer Team"
__email__ = "cobol-analyzer@example.com"
__description__ = "Ferramenta avançada de análise e documentação automatizada de programas COBOL com IA e RAG"

from .runner import main

__all__ = ["main"]
