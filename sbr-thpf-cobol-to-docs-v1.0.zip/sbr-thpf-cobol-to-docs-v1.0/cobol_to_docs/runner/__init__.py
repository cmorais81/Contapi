"""
COBOL to Docs - Runner Module
Módulo principal de execução da aplicação
"""

from .main import main

__all__ = ["main"]
