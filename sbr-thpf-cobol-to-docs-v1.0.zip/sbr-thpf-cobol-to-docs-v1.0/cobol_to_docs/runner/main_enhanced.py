"""
COBOL AI Engine v4.0 - Main Enhanced
Versão aprimorada do main.py mantendo compatibilidade total com o sistema existente.
"""

import argparse
import logging
import os
import sys
import time
from pathlib import Path

# Adicionar src ao path para imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# Imports do sistema existente (compatibilidade)
from core.config import ConfigManager
from core.enhanced_prompt_manager import EnhancedPromptManager
from providers.provider_manager import ProviderManager
from providers.base_provider import AIRequest

# Imports da nova arquitetura (com fallback)
try:
    from core.enhanced_file_manager import EnhancedFileManager
    from parsers.implementations.enhanced_cobol_parser import EnhancedCobolParser
    ENHANCED_AVAILABLE = True
except ImportError:
    from core.file_manager import FileManager
    ENHANCED_AVAILABLE = False

# Imports para compatibilidade com sistema original
from core.file_manager import FileManager as OriginalFileManager
from parsers.cobol_parser import COBOLParser


def setup_logging(log_level: str = "INFO") -> None:
    """
    Configura o sistema de logging.
    
    Args:
        log_level: Nível de log (DEBUG, INFO, WARNING, ERROR)
    """
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler('cobol_ai_engine.log', encoding='utf-8')
        ]
    )


def create_file_manager(use_enhanced: bool = True) -> object:
    """
    Cria FileManager com fallback automático.
    
    Args:
        use_enhanced: Se deve tentar usar versão aprimorada
        
    Returns:
        object: FileManager (enhanced ou original)
    """
    logger = logging.getLogger(__name__)
    
    if use_enhanced and ENHANCED_AVAILABLE:
        try:
            # Tentar criar FileManager aprimorado
            enhanced_parser = EnhancedCobolParser()
            file_manager = EnhancedFileManager(enhanced_parser)
            logger.info("FileManager aprimorado inicializado com sucesso")
            return file_manager
        except Exception as e:
            logger.warning(f"Erro ao inicializar FileManager aprimorado: {e}")
            logger.info("Fazendo fallback para FileManager original")
    
    # Fallback para FileManager original
    original_parser = COBOLParser()
    file_manager = OriginalFileManager(original_parser)
    logger.info("FileManager original inicializado")
    return file_manager


def load_programs_and_books(file_manager: object, fontes_file: str, books_file: str) -> tuple:
    """
    Carrega programas e copybooks usando FileManager.
    
    Args:
        file_manager: FileManager a usar
        fontes_file: Arquivo de fontes
        books_file: Arquivo de books
        
    Returns:
        tuple: (programs_data, copybooks_content, file_entries)
    """
    logger = logging.getLogger(__name__)
    
    # Carregar programas
    logger.info("Carregando programas COBOL...")
    programs_data, program_entries = file_manager.load_programs_from_list(fontes_file)
    
    # Carregar copybooks
    copybooks_content = ""
    copybook_entries = []
    
    if books_file and os.path.exists(books_file):
        logger.info("Carregando copybooks...")
        copybooks_content, copybook_entries = file_manager.load_copybooks_from_list(books_file)
    else:
        logger.info("Arquivo de copybooks não fornecido ou não encontrado")
    
    # Combinar entradas para estatísticas
    all_entries = program_entries + copybook_entries
    
    # Exibir estatísticas
    if hasattr(file_manager, 'get_enhanced_statistics'):
        # FileManager aprimorado
        stats = file_manager.get_enhanced_statistics(all_entries)
        logger.info("Estatísticas aprimoradas:")
        logger.info(f"  Arquivos processados: {stats.get('total_files', 0)}")
        logger.info(f"  Taxa de sucesso: {stats.get('success_rate', 0)}%")
        logger.info(f"  Parser usado: {stats.get('parser_info', {}).get('parser_version', 'unknown')}")
    else:
        # FileManager original
        stats = file_manager.get_file_statistics(all_entries)
        logger.info("Estatísticas básicas:")
        logger.info(f"  Arquivos processados: {stats.get('total_files', 0)}")
        logger.info(f"  Taxa de sucesso: {stats.get('success_rate', 0)}%")
    
    return programs_data, copybooks_content, all_entries


def process_with_providers(programs_data: dict, copybooks_content: str, 
                         config_manager: ConfigManager, prompt_manager: EnhancedPromptManager,
                         output_dir: str) -> None:
    """
    Processa programas com provedores de IA.
    
    Args:
        programs_data: Dados dos programas
        copybooks_content: Conteúdo dos copybooks
        config_manager: Gerenciador de configuração
        prompt_manager: Gerenciador de prompts
        output_dir: Diretório de saída
    """
    logger = logging.getLogger(__name__)
    
    if not programs_data:
        logger.warning("Nenhum programa carregado para processar")
        return
    
    # Inicializar ProviderManager
    provider_manager = ProviderManager(config_manager.config)
    
    # Obter modelos configurados
    models = config_manager.get_configured_models()
    logger.info(f"Modelos configurados: {len(models)}")
    
    if not models:
        logger.error("Nenhum modelo configurado. Verifique o arquivo de configuração.")
        return
    
    # Processar cada programa
    for program_name, program_content in programs_data.items():
        logger.info(f"Processando programa: {program_name}")
        
        try:
            # Criar prompt aprimorado
            enhanced_prompt = prompt_manager.create_complete_analysis_prompt(
                program_content, copybooks_content
            )
            
            # Processar com cada modelo configurado
            for model_info in models:
                provider_name = model_info['provider']
                model_name = model_info['name']
                
                logger.info(f"Analisando com {provider_name}/{model_name}")
                
                try:
                    # Criar request com assinatura correta
                    ai_request = AIRequest(
                        prompt=enhanced_prompt,
                        program_name=program_name,
                        program_code=program_content,
                        max_tokens=4000,
                        temperature=0.1
                    )
                    
                    # Fazer análise
                    response = provider_manager.analyze_with_specific_provider(
                        provider_name, ai_request
                    )
                    
                    if response and response.success:
                        # Salvar resultado
                        output_path = os.path.join(
                            output_dir, 
                            'analise_geral',
                            f'model_{provider_name}_{model_name}',
                            f'{program_name}_analise_funcional.md'
                        )
                        
                        os.makedirs(os.path.dirname(output_path), exist_ok=True)
                        
                        with open(output_path, 'w', encoding='utf-8') as f:
                            f.write(response.content)
                        
                        # Salvar metadados
                        metadata_path = output_path.replace('.md', '_metadata.json')
                        import json
                        
                        metadata = {
                            'program_name': program_name,
                            'provider': provider_name,
                            'model': model_name,
                            'tokens_used': response.tokens_used,
                            'processing_time': getattr(response, 'response_time', 0),
                            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
                        }
                        
                        with open(metadata_path, 'w', encoding='utf-8') as f:
                            json.dump(metadata, f, indent=2, ensure_ascii=False)
                        
                        logger.info(f"Análise salva: {output_path}")
                        logger.info(f"Tokens utilizados: {response.tokens_used}")
                        
                    else:
                        error_msg = response.error_message if response else "Resposta vazia"
                        logger.error(f"Erro na análise com {provider_name}/{model_name}: {error_msg}")
                        
                except Exception as e:
                    logger.error(f"Erro ao processar com {provider_name}/{model_name}: {e}")
                    
        except Exception as e:
            logger.error(f"Erro ao processar programa {program_name}: {e}")


def main():
    """Função principal do sistema."""
    
    # Configurar argumentos
    parser = argparse.ArgumentParser(description='COBOL AI Engine v4.0 - Enhanced')
    parser.add_argument('--fontes', required=True, help='Arquivo com lista de programas COBOL')
    parser.add_argument('--books', help='Arquivo com lista de copybooks')
    parser.add_argument('--output-dir', required=True, help='Diretório de saída')
    parser.add_argument('--config-dir', help='Diretório de configuração customizado')
    parser.add_argument('--prompts-file', help='Arquivo de prompts customizado')
    parser.add_argument('--log-level', default='INFO', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'])
    parser.add_argument('--use-enhanced', action='store_true', default=True, 
                       help='Usar componentes aprimorados (padrão: True)')
    parser.add_argument('--fallback-enabled', action='store_true', default=True,
                       help='Habilitar fallback para componentes originais (padrão: True)')
    
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    logger.info("="*60)
    logger.info("COBOL AI Engine v4.0 - Enhanced Edition")
    logger.info("="*60)
    logger.info(f"Componentes aprimorados disponíveis: {ENHANCED_AVAILABLE}")
    logger.info(f"Usar componentes aprimorados: {args.use_enhanced}")
    logger.info(f"Fallback habilitado: {args.fallback_enabled}")
    
    try:
        # Inicializar ConfigManager
        logger.info("Inicializando ConfigManager...")
        config_manager = ConfigManager(
            config_dir=args.config_dir,
            prompts_file=args.prompts_file
        )
        
        # Inicializar PromptManager
        logger.info("Inicializando PromptManager...")
        prompts = config_manager.get_prompts()
        prompt_manager = EnhancedPromptManager(prompts)
        
        # Criar FileManager
        logger.info("Inicializando FileManager...")
        file_manager = create_file_manager(args.use_enhanced)
        
        # Carregar programas e copybooks
        logger.info("Carregando programas e copybooks...")
        programs_data, copybooks_content, file_entries = load_programs_and_books(
            file_manager, args.fontes, args.books
        )
        
        if not programs_data:
            logger.error("Nenhum programa foi carregado. Verifique os arquivos de entrada.")
            sys.exit(1)
        
        logger.info(f"Programas carregados: {len(programs_data)}")
        logger.info(f"Copybooks carregados: {'Sim' if copybooks_content else 'Não'}")
        
        # Criar diretório de saída
        os.makedirs(args.output_dir, exist_ok=True)
        
        # Processar com provedores
        logger.info("Iniciando processamento com provedores de IA...")
        process_with_providers(
            programs_data, copybooks_content, 
            config_manager, prompt_manager, 
            args.output_dir
        )
        
        logger.info("Processamento concluído com sucesso!")
        
        # Exibir estatísticas finais
        if hasattr(file_manager, 'get_manager_info'):
            manager_info = file_manager.get_manager_info()
            logger.info("Informações do FileManager:")
            logger.info(f"  Versão: {manager_info.get('version', 'unknown')}")
            logger.info(f"  Recursos: {len(manager_info.get('enhanced_features', []))}")
        
    except KeyboardInterrupt:
        logger.info("Processamento interrompido pelo usuário")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Erro durante execução: {e}")
        logger.exception("Detalhes do erro:")
        sys.exit(1)


if __name__ == "__main__":
    main()
