# 📊 Base de Conhecimento COBOL

Esta pasta contém a base de conhecimento do sistema RAG (Retrieval-Augmented Generation) que permite ao COBOL Analyzer aprender e melhorar suas análises ao longo do tempo.

## 📁 Arquivos da Base de Conhecimento

### `cobol_knowledge_base.json`
Base de conhecimento principal contendo análises e padrões COBOL identificados.

### `cobol_embeddings.pkl`
Cache de embeddings vetoriais para busca semântica rápida na base de conhecimento.

### `cobol_knowledge_base_backup.json`
Backup automático da base de conhecimento.

### `cobol_knowledge_base_cadoc_expanded.json`
Base expandida com documentação CADOC e padrões específicos do Santander.

### `cobol_knowledge_base_consolidated.json`
Base consolidada com conhecimentos validados e refinados.

## 🔄 Como Funciona

1. **Auto-Learning**: A cada análise individual, o sistema adiciona novos conhecimentos à base
2. **Busca Semântica**: Utiliza embeddings para encontrar padrões similares
3. **Melhoria Contínua**: A base cresce e se refina com o uso da aplicação

## 🚀 Para Novos Usuários

A base inicial já contém conhecimentos fundamentais sobre:
- Padrões COBOL comuns
- Estruturas de dados bancárias
- Regras de negócio típicas
- Boas práticas de documentação

## 🔧 Manutenção

- **Backup automático**: Criado a cada 100 análises
- **Limpeza**: Remoção automática de conhecimentos duplicados
- **Otimização**: Reindexação periódica dos embeddings

---
*Esta base de conhecimento é o coração do sistema de aprendizado do COBOL Analyzer*
