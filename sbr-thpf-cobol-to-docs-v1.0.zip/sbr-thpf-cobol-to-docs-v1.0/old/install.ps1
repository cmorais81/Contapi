# Script de Instalação - COBOL to Docs v1.0
# Autor: Carlos Morais
# Compatível com Windows PowerShell

Write-Host "==================================================" -ForegroundColor Cyan
Write-Host "COBOL to Docs v1.0 - Instalação Automática" -ForegroundColor Cyan
Write-Host "Autor: Carlos Morais" -ForegroundColor Cyan
Write-Host "==================================================" -ForegroundColor Cyan
Write-Host

# Verificar Python
Write-Host "Verificando Python..." -ForegroundColor Yellow
try {
    $pythonVersion = python --version 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ Python encontrado: $pythonVersion" -ForegroundColor Green
    } else {
        throw "Python não encontrado"
    }
} catch {
    Write-Host "❌ Python não encontrado!" -ForegroundColor Red
    Write-Host "   Instale Python 3.11+ de https://python.org" -ForegroundColor Yellow
    Write-Host "   Certifique-se de marcar 'Add Python to PATH'" -ForegroundColor Yellow
    Write-Host
    Write-Host "   Ou tente usar 'py' ao invés de 'python':" -ForegroundColor Yellow
    Write-Host "   py --version" -ForegroundColor Yellow
    exit 1
}

# Verificar versão mínima
$versionString = $pythonVersion -replace "Python ", ""
$versionParts = $versionString.Split('.')
$major = [int]$versionParts[0]
$minor = [int]$versionParts[1]

if ($major -lt 3 -or ($major -eq 3 -and $minor -lt 11)) {
    Write-Host "⚠️  Versão do Python muito antiga: $pythonVersion" -ForegroundColor Yellow
    Write-Host "   Recomendado: Python 3.11+" -ForegroundColor Yellow
    Write-Host "   Continuando mesmo assim..." -ForegroundColor Yellow
}

Write-Host

# Instalar dependências
Write-Host "Instalando dependências Python..." -ForegroundColor Yellow
try {
    pip install pyyaml requests beautifulsoup4 markdown
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ Dependências instaladas com sucesso" -ForegroundColor Green
    } else {
        throw "Erro ao instalar dependências"
    }
} catch {
    Write-Host "❌ Erro ao instalar dependências" -ForegroundColor Red
    Write-Host "   Tente executar como Administrador" -ForegroundColor Yellow
    Write-Host "   Ou use: pip install --user pyyaml requests beautifulsoup4 markdown" -ForegroundColor Yellow
    exit 1
}

Write-Host

# Verificar se já está extraído
if (-not (Test-Path "cobol_to_docs_v1")) {
    # Procurar arquivo tar.gz
    if (Test-Path "cobol_to_docs_v1.0_FINAL.tar.gz") {
        Write-Host "Extraindo arquivos..." -ForegroundColor Yellow
        
        # Tentar usar tar (disponível no Windows 10+)
        try {
            tar -xzf cobol_to_docs_v1.0_FINAL.tar.gz
            Write-Host "✅ Arquivos extraídos com tar" -ForegroundColor Green
        } catch {
            Write-Host "❌ Erro ao extrair com tar" -ForegroundColor Red
            Write-Host "   Use 7-Zip, WinRAR ou outro programa para extrair:" -ForegroundColor Yellow
            Write-Host "   cobol_to_docs_v1.0_FINAL.tar.gz" -ForegroundColor Yellow
            Write-Host "   Depois execute este script novamente" -ForegroundColor Yellow
            exit 1
        }
    } else {
        Write-Host "❌ Arquivo cobol_to_docs_v1.0_FINAL.tar.gz não encontrado" -ForegroundColor Red
        Write-Host "   Certifique-se de que o arquivo está no diretório atual" -ForegroundColor Yellow
        exit 1
    }
} else {
    Write-Host "✅ Diretório cobol_to_docs_v1 já existe" -ForegroundColor Green
}

Write-Host

# Entrar no diretório
Set-Location cobol_to_docs_v1

# Testar instalação
Write-Host "Testando instalação..." -ForegroundColor Yellow
try {
    python main.py --status
    if ($LASTEXITCODE -eq 0) {
        Write-Host
        Write-Host "==================================================" -ForegroundColor Green
        Write-Host "✅ INSTALAÇÃO CONCLUÍDA COM SUCESSO!" -ForegroundColor Green
        Write-Host "==================================================" -ForegroundColor Green
        Write-Host
        Write-Host "PRÓXIMOS PASSOS:" -ForegroundColor Cyan
        Write-Host
        Write-Host "1. Testar com exemplo:" -ForegroundColor White
        Write-Host "   python main.py --fontes examples/fontes.txt" -ForegroundColor Yellow
        Write-Host
        Write-Host "2. Gerar prompts personalizados:" -ForegroundColor White
        Write-Host "   python generate_prompts.py --interactive" -ForegroundColor Yellow
        Write-Host
        Write-Host "3. Ver documentação completa:" -ForegroundColor White
        Write-Host "   Get-Content docs/GUIA_COMPLETO_USO.md" -ForegroundColor Yellow
        Write-Host
        Write-Host "4. Configurar credenciais LuzIA (opcional):" -ForegroundColor White
        Write-Host "   `$env:LUZIA_CLIENT_ID='seu_id'" -ForegroundColor Yellow
        Write-Host "   `$env:LUZIA_CLIENT_SECRET='seu_secret'" -ForegroundColor Yellow
        Write-Host
        Write-Host "Sistema desenvolvido por Carlos Morais" -ForegroundColor Cyan
        Write-Host "==================================================" -ForegroundColor Green
    } else {
        throw "Erro no teste"
    }
} catch {
    Write-Host
    Write-Host "❌ Erro no teste da instalação" -ForegroundColor Red
    Write-Host "   Verifique os logs acima para mais detalhes" -ForegroundColor Yellow
    Write-Host "   Tente executar manualmente:" -ForegroundColor Yellow
    Write-Host "   python main.py --status" -ForegroundColor Yellow
    exit 1
}
