# Guia Completo de Uso - COBOL to Docs v1.1

**Autor:** Carlos Morais  
**Versão:** 1.1  
**Data:** Setembro 2025

## Índice

1. [Introdução](#introdução)
2. [Instalação e Configuração](#instalação-e-configuração)
3. [Uso Básico](#uso-básico)
4. [Funcionalidades Avançadas](#funcionalidades-avançadas)
5. [Geração de Prompts Personalizados](#geração-de-prompts-personalizados)
6. [Análise Multi-Modelo](#análise-multi-modelo)
7. [Configuração Avançada](#configuração-avançada)
8. [Solução de Problemas](#solução-de-problemas)
9. [Exemplos Práticos](#exemplos-práticos)

## Introdução

COBOL to Docs v1.1 é um sistema completo para análise automatizada de programas COBOL usando Inteligência Artificial. O sistema foi desenvolvido por Carlos Morais para facilitar a documentação e análise de sistemas legados COBOL.

### Principais Benefícios

- **Automatização Completa**: Elimina trabalho manual de documentação
- **Análise Profunda**: IA identifica regras de negócio complexas
- **Múltiplas Perspectivas**: Suporte a diferentes modelos de IA
- **Personalização**: Prompts adaptáveis para diferentes domínios
- **Qualidade Profissional**: Relatórios adequados para apresentação corporativa

## Instalação e Configuração

### Pré-requisitos

#### Sistema Operacional
- Linux (Ubuntu 22.04+ recomendado)
- Windows 10+ (com WSL recomendado)
- macOS 10.15+

#### Python
- Python 3.11 ou superior
- pip (gerenciador de pacotes Python)

#### Bibliotecas Python Necessárias
```bash
pip install pyyaml requests beautifulsoup4 markdown
```

### Configuração Inicial

#### 1. Verificar Instalação
```bash
python3 main.py --status
```

#### 2. Configurar Credenciais LuzIA (Opcional)
```bash
export LUZIA_CLIENT_ID='seu_client_id'
export LUZIA_CLIENT_SECRET='seu_client_secret'
```

#### 3. Testar com Exemplo
```bash
python3 main.py --fontes examples/fontes.txt
```

### Estrutura de Arquivos

```
cobol_to_docs_v1/
├── main.py                    # Script principal
├── generate_prompts.py        # Gerador de prompts
├── config/
│   ├── config.yaml           # Configuração principal
│   └── prompts_*.yaml        # Arquivos de prompts
├── examples/
│   ├── programa_exemplo.cbl  # Programa de exemplo
│   ├── fontes.txt           # Lista de arquivos
│   └── requisitos_exemplo.txt # Exemplo de requisitos
└── src/                      # Código fonte do sistema
```

## Uso Básico

### Comando Básico

```bash
python3 main.py --fontes ARQUIVO_FONTES
```

**Exemplo:**
```bash
python3 main.py --fontes examples/fontes.txt
```

### Formato do Arquivo de Fontes

O arquivo de fontes deve conter um caminho de arquivo COBOL por linha:

```
# Lista de programas COBOL
# Linhas com # são comentários

examples/programa_exemplo.cbl
/caminho/para/outro_programa.cbl
```

### Saída Básica

O sistema gera:
- **Pasta output/**: Contém toda a documentação gerada
- **Arquivo .md**: Documentação em Markdown
- **Logs**: Informações de processamento

### Verificar Status do Sistema

```bash
python3 main.py --status
```

Mostra:
- Status dos provedores de IA
- Conectividade
- Configuração atual

## Funcionalidades Avançadas

### Geração de PDF

```bash
python3 main.py --fontes examples/fontes.txt --pdf
```

**Benefícios:**
- HTML otimizado para conversão PDF
- Design profissional
- Formatação corporativa
- Tabelas e gráficos bem estruturados

**Como converter para PDF:**
1. Abra o arquivo HTML gerado no navegador
2. Pressione Ctrl+P (Windows/Linux) ou Cmd+P (Mac)
3. Selecione "Salvar como PDF"
4. Configure margens e ative "Gráficos de fundo"
5. Salve o arquivo

### Diferentes Conjuntos de Prompts

#### Prompts Originais (Padrão)
```bash
python3 main.py --fontes examples/fontes.txt --prompt-set original
```
- Análise técnica tradicional
- Foco em aspectos técnicos
- Adequado para desenvolvedores

#### Prompts DOC-LEGADO PRO
```bash
python3 main.py --fontes examples/fontes.txt --prompt-set doc_legado_pro
```
- Documentação de sistemas legados
- Foco em regras de negócio
- Adequado para analistas de negócio

### Configuração de Logs

```bash
# Log detalhado
python3 main.py --fontes examples/fontes.txt --log DEBUG

# Log mínimo
python3 main.py --fontes examples/fontes.txt --log ERROR
```

**Níveis disponíveis:**
- **DEBUG**: Informações detalhadas
- **INFO**: Informações gerais (padrão)
- **WARNING**: Apenas avisos
- **ERROR**: Apenas erros

## Geração de Prompts Personalizados

### Conceito

O sistema permite criar prompts YAML personalizados a partir de texto livre, aplicando automaticamente boas práticas de engenharia de prompt.

### Geração a partir de Arquivo

```bash
python3 generate_prompts.py --input requisitos.txt --output meus_prompts.yaml
```

**Exemplo de arquivo de requisitos:**
```
Análise Focada em Sistemas Bancários

Preciso de análise detalhada para programas COBOL bancários com foco em:
- Validações de segurança
- Cálculos financeiros
- Conformidade regulatória
- Auditoria e controles
```

### Modo Interativo

```bash
python3 generate_prompts.py --interactive
```

1. Digite ou cole seu texto
2. Digite "FIM" para finalizar
3. Sistema gera arquivo YAML automaticamente

### Usar Prompts Personalizados

```bash
python3 main.py --fontes examples/fontes.txt --prompts-file meus_prompts.yaml
```

### Validar Prompts Gerados

```bash
python3 generate_prompts.py --validate meus_prompts.yaml
```

Verifica:
- Estrutura YAML válida
- Seções obrigatórias
- Compatibilidade com sistema

### Geração Integrada no CLI Principal

```bash
# Gerar prompts diretamente
python3 main.py --generate-prompts requisitos.txt

# Modo interativo
python3 main.py --generate-prompts-interactive
```

## Análise Multi-Modelo

### Conceito

Permite analisar o mesmo programa com múltiplos modelos de IA e gerar relatório comparativo.

### Uso Básico

```bash
python3 main.py --fontes examples/fontes.txt --models '["aws-claude-3.7","gpt-4"]'
```

### Modelos Suportados

- **aws-claude-3.7**: Claude 3.7 via AWS
- **gpt-4**: GPT-4 via OpenAI
- **claude-3**: Claude 3 direto
- **enhanced_mock**: Simulador para testes

### Formato de Especificação

**Modelo único:**
```bash
--models "aws-claude-3.7"
```

**Múltiplos modelos:**
```bash
--models '["aws-claude-3.7","gpt-4","claude-3"]'
```

### Saída Multi-Modelo

```
output/
├── model_aws_claude_3_7/     # Análise do Claude 3.7
│   ├── documentacao.md
│   └── relatorio.html
├── model_gpt_4/              # Análise do GPT-4
│   ├── documentacao.md
│   └── relatorio.html
└── relatorio_comparativo_modelos.md  # Comparação
```

### Relatório Comparativo

O relatório inclui:
- **Estatísticas por modelo**: Tokens, tempo, sucesso
- **Comparação qualitativa**: Diferenças nas análises
- **Recomendações**: Melhor modelo para cada caso
- **Métricas de performance**: Eficiência e qualidade

## Configuração Avançada

### Arquivo config/config.yaml

```yaml
# Configuração de IA
ai:
  primary_provider: "luzia"
  default_models: ["aws-claude-3.7"]
  
# Configuração de provedores
providers:
  luzia:
    base_url: "https://api.luzia.com"
    model: "aws-claude-3.7"
    max_tokens: 200000
    temperature: 0.1
    
  enhanced_mock:
    enabled: true
    response_delay: 1.0
```

### Personalização de Prompts

#### Estrutura de Arquivo YAML de Prompts

```yaml
version: "1.0"

system_prompt: |
  Você é um analista especializado...

model_prompts:
  luzia_standard:
    system_prompt: |
      Prompt específico para LuzIA...
    persona: "analista senior"
    analysis_depth: "detailed"

analysis_questions:
  functional:
    priority: 1
    required: true
    context: "Análise funcional"
    question: |
      Descreva a funcionalidade...
```

### Configuração de Saída

```yaml
output:
  base_directory: "output"
  generate_html: true
  generate_pdf: false
  include_source_code: true
```

## Solução de Problemas

### Problemas Comuns

#### 1. Erro "Provider não disponível"

**Sintoma:**
```
Erro: Provider LuzIA não disponível
```

**Solução:**
```bash
# Verificar credenciais
echo $LUZIA_CLIENT_ID
echo $LUZIA_CLIENT_SECRET

# Configurar se necessário
export LUZIA_CLIENT_ID='seu_id'
export LUZIA_CLIENT_SECRET='seu_secret'

# Testar conectividade
python3 main.py --status
```

#### 2. Arquivo de fontes não encontrado

**Sintoma:**
```
Erro: Arquivo não encontrado: fontes.txt
```

**Solução:**
```bash
# Verificar se arquivo existe
ls -la fontes.txt

# Usar caminho absoluto
python3 main.py --fontes /caminho/completo/fontes.txt
```

#### 3. Programa COBOL não pode ser lido

**Sintoma:**
```
Aviso: Arquivo vazio ou não legível
```

**Solução:**
```bash
# Verificar encoding do arquivo
file programa.cbl

# Converter encoding se necessário
iconv -f ISO-8859-1 -t UTF-8 programa.cbl > programa_utf8.cbl
```

#### 4. Erro de parsing YAML

**Sintoma:**
```
Erro: YAML inválido
```

**Solução:**
```bash
# Validar arquivo YAML
python3 -c "import yaml; yaml.safe_load(open('arquivo.yaml'))"

# Regenerar prompts se necessário
python3 generate_prompts.py --input requisitos.txt --output novo_prompts.yaml
```

### Logs e Diagnóstico

#### Ativar Log Detalhado
```bash
python3 main.py --fontes examples/fontes.txt --log DEBUG
```

#### Localização dos Logs
```
logs/
├── cobol_to_docs_YYYYMMDD_HHMMSS.log
└── prompt_generator_YYYYMMDD_HHMMSS.log
```

#### Verificar Status Completo
```bash
python3 main.py --status --log DEBUG
```

## Exemplos Práticos

### Exemplo 1: Análise Básica

```bash
# Preparar arquivo de fontes
echo "examples/programa_exemplo.cbl" > meus_programas.txt

# Executar análise
python3 main.py --fontes meus_programas.txt --pdf

# Resultado em: output/programa_exemplo/
```

### Exemplo 2: Prompts Personalizados para Banco

```bash
# Criar requisitos específicos
cat > requisitos_banco.txt << EOF
Análise para Sistema Bancário

Foco em:
- Cálculos de juros e taxas
- Validações de CPF/CNPJ
- Controles de auditoria
- Conformidade BACEN
EOF

# Gerar prompts
python3 generate_prompts.py --input requisitos_banco.txt --output prompts_banco.yaml

# Usar na análise
python3 main.py --fontes meus_programas.txt --prompts-file prompts_banco.yaml --pdf
```

### Exemplo 3: Análise Comparativa

```bash
# Análise com múltiplos modelos
python3 main.py --fontes meus_programas.txt \
  --models '["aws-claude-3.7","enhanced_mock"]' \
  --pdf

# Verificar relatório comparativo
cat output/relatorio_comparativo_modelos.md
```

### Exemplo 4: Workflow Completo

```bash
#!/bin/bash
# Script completo de análise

# 1. Verificar sistema
echo "Verificando status..."
python3 main.py --status

# 2. Gerar prompts específicos
echo "Gerando prompts personalizados..."
python3 generate_prompts.py --input requisitos_especificos.txt --output prompts_custom.yaml

# 3. Validar prompts
echo "Validando prompts..."
python3 generate_prompts.py --validate prompts_custom.yaml

# 4. Executar análise
echo "Executando análise..."
python3 main.py --fontes lista_programas.txt \
  --prompts-file prompts_custom.yaml \
  --pdf \
  --output resultado_$(date +%Y%m%d)

echo "Análise concluída!"
```

### Exemplo 5: Análise de Sistema Legado

```bash
# Para sistemas legados complexos
python3 main.py --fontes sistema_legado.txt \
  --prompt-set doc_legado_pro \
  --models '["aws-claude-3.7"]' \
  --pdf \
  --log INFO \
  --output documentacao_legado
```

---

**Autor:** Carlos Morais  
**Sistema:** COBOL to Docs v1.1  
**Data:** Setembro 2025

Para suporte adicional, consulte os logs do sistema ou entre em contato com o desenvolvedor.
