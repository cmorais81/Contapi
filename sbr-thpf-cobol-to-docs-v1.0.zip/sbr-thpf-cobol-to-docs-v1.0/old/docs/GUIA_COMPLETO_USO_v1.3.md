# Guia Completo de Uso - COBOL to Docs v1.3

## 1. Introdução

O **COBOL to Docs v1.3** é uma ferramenta avançada para análise e documentação de programas COBOL, projetada para acelerar a modernização e manutenção de sistemas legados. Utilizando um sistema de **Geração Aumentada por Recuperação (RAG)**, a ferramenta enriquece as análises com uma base de conhecimento especializada em COBOL, DB2, CICS e práticas bancárias.

Este guia detalha todas as funcionalidades, desde a instalação até os comandos mais avançados.

## 2. Instalação

### Pré-requisitos
- Python 3.9 ou superior
- `pip` (gerenciador de pacotes Python)

### Passos de Instalação

1. **Extraia o pacote:**
   ```bash
   tar -xzf cobol_to_docs_v1.3.tar.gz
   cd cobol_to_docs_v1.3
   ```

2. **Instale as dependências:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure as variáveis de ambiente (Opcional):**
   Para usar provedores como LuzIA ou OpenAI, configure as credenciais no arquivo `config/config.yaml` ou através de variáveis de ambiente.

   ```bash
   export LUZIA_CLIENT_ID="seu_client_id"
   export LUZIA_CLIENT_SECRET="seu_client_secret"
   export OPENAI_API_KEY="sua_chave_openai"
   ```

## 3. Estrutura do Projeto

```
cobol_to_docs_v1.3/
├── main.py                 # Ponto de entrada principal
├── config/                   # Arquivos de configuração
│   ├── config.yaml           # Configuração principal (providers, RAG)
│   └── prompts_especialista.yaml # Prompts para análises especializadas
├── data/
│   └── cobol_knowledge_base.json # Base de conhecimento RAG
├── docs/                     # Documentação do projeto
├── examples/                 # Arquivos de exemplo (COBOL e Books)
├── src/                      # Código fonte
│   ├── analyzers/            # Lógica de análise
│   ├── core/                 # Componentes centrais
│   ├── generators/           # Geradores de documentação
│   ├── parsers/              # Parsers de código COBOL
│   ├── providers/            # Provedores de IA (LuzIA, OpenAI, etc.)
│   └── rag/                  # Sistema RAG
└── requirements.txt          # Dependências do projeto
```

## 4. Funcionalidades Principais

O sistema oferece uma gama de análises, controladas por flags na linha de comando.

| Funcionalidade | Flag | Descrição |
| :--- | :--- | :--- |
| **Análise Individual** | (padrão) | Gera uma análise funcional para cada programa COBOL fornecido. |
| **Análise Consolidada** | `--consolidado` | Analisa todos os programas em conjunto, gerando uma visão sistêmica. |
| **Relatório Único** | `--relatorio-unico` | Gera um único arquivo de documentação para todos os programas. |
| **Análise Especialista** | `--analise-especialista` | Utiliza prompts especializados para uma análise técnica profunda. |
| **Procedure Detalhada** | `--procedure-detalhada` | Foca a análise exclusivamente na `PROCEDURE DIVISION`. |
| **Análise de Modernização** | `--modernizacao` | Gera recomendações para modernização e tradução para Python. |
| **Geração de PDF** | `--pdf` | Converte a saída Markdown para formato PDF. |
| **Status dos Providers** | `--status` | Verifica a conectividade e configuração dos provedores de IA. |

## 5. Sistema RAG (Retrieval-Augmented Generation)

O grande diferencial da v1.3 é o sistema RAG, que funciona de forma automática e transparente para enriquecer as análises.

### Como Funciona

1.  **Análise Automática**: Ao executar uma análise, o RAG examina o código COBOL.
2.  **Busca Semântica**: O sistema busca em sua base de conhecimento consolidada (`data/cobol_knowledge_base_consolidated.json`) por padrões, regras e práticas relevantes.
3.  **Enriquecimento de Prompt**: O prompt enviado ao modelo de IA é enriquecido com o contexto encontrado.
4.  **Análise Aprofundada**: O modelo de IA gera uma análise muito mais rica e contextualizada.

### Base de Conhecimento Consolidada

A v1.3 utiliza uma **base de conhecimento única e consolidada**, que unifica o conhecimento de múltiplas fontes, incluindo padrões de mainframe, regras de negócio bancárias e técnicas de modernização. Para contribuir, edite o arquivo `data/cobol_knowledge_base_consolidated.json`.

### Auto-Learning

A base de conhecimento **se enriquece automaticamente** a cada análise bem-sucedida. O sistema extrai novos padrões e regras da resposta da IA e os adiciona à base, tornando as futuras análises ainda mais inteligentes.

### Logging Transparente

Uma das principais melhorias da v1.3 é o **logging transparente** de todas as operações do RAG. Ao final de cada execução, um relatório detalhado é gerado no diretório `logs/`, permitindo auditoria completa e análise de performance.

- **Relatório da Sessão (`rag_session_report_*.txt`)**: Um resumo legível com estatísticas completas.
- **Logs Detalhados (`rag_detailed_log_*.json`)**: Um JSON com todas as operações para análise programática.

Você pode controlar o RAG e o logging através do `config/config.yaml`:

```yaml
rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base_consolidated.json"
  auto_learn: true
  similarity_threshold: 0.6
  log_dir: "logs"  # Diretório para logs RAG
  enable_console_logs: true # Exibir logs RAG no console
```

## 6. Provedores de IA

O sistema suporta múltiplos provedores de IA, configuráveis em `config/config.yaml`.

- **LuzIA**: Provedor primário, utiliza o modelo `aws-claude-3-5-sonnet`.
- **OpenAI**: Suporte para modelos como `gpt-4`.
- **Bedrock**: Suporte para modelos da AWS Bedrock.
- **Databricks**: Suporte para modelos hospedados no Databricks.
- **Enhanced Mock**: Provedor de simulação para testes offline, gera respostas estruturadas.
- **Basic**: Provedor básico para testes, retorna uma resposta fixa.

O sistema possui um mecanismo de **fallback automático**. Se o provedor primário (LuzIA) falhar, ele tentará os provedores de fallback em ordem.

## 7. Exemplos de Comandos

Consulte o documento `GUIA_DE_COMANDOS.md` para uma lista completa de exemplos, do básico ao avançado.

## 8. Contribuindo

Para contribuir com o projeto, siga os seguintes passos:

1. **Adicionar Conhecimento**: Edite o arquivo `data/cobol_knowledge_base.json` para adicionar novos padrões, regras ou melhores práticas.
2. **Criar Novos Prompts**: Adicione novos conjuntos de prompts em `config/prompts_especialista.yaml`.
3. **Desenvolver Novos Providers**: Crie uma nova classe em `src/providers/` herdando de `BaseProvider`.

## 9. Troubleshooting

- **Erro de Conexão com Provider**: Verifique suas credenciais e a conectividade de rede. Use `python main.py --status` para diagnosticar.
- **Análise Superficial**: Verifique se o RAG está habilitado no `config.yaml`. Considere enriquecer a base de conhecimento.
- **Nenhum Arquivo Gerado**: Verifique as permissões de escrita no diretório de saída.

Para mais informações, consulte a `DOCUMENTACAO_TECNICA.md`.

