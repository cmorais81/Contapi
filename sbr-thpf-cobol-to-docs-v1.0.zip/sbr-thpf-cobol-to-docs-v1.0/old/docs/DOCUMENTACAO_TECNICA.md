# Documentação Técnica - COBOL to Docs v1.3

**Autor:** Carlos Morais  
**Versão:** 1.3  
**Data:** Setembro 2025

## Arquitetura do Sistema

### Visão Geral

COBOL to Docs v1.3 é um sistema modular que integra um poderoso mecanismo de **Geração Aumentada por Recuperação (RAG)** para enriquecer a análise de programas COBOL. A arquitetura é projetada para ser extensível, desacoplada e resiliente.

### Componentes Principais

```
┌─────────────────────────────────────────────────────────┐
│                    CLI Interface (main.py)              │
└─────────────────────┬───────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────┐
│                Core Components                          │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────┐   │
│  │   Config    │ │   Prompts   │ │   Cost Calc     │   │
│  │  Manager    │ │  Manager    │ │                 │   │
│  └─────────────┘ └─────────────┘ └─────────────────┘   │
└─────────────────────┬───────────────────────────────────┘
                      │
┌─────────────────────▼───────────────────────────────────┐
│              Processing Layer                           │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────┐   │
│  │   COBOL     │ │   Enhanced  │ │   Documentation │   │
│  │   Parser    │ │  Analyzer   │ │   Generator     │   │
│  └─────────────┘ └─────────────┘ └─────────────────┘   │
└─────────────────────┬────────────────────┬──────────────┘
                      │                    │
┌─────────────────────▼──────────┐  ┌──────▼──────────────┐
│         AI Providers           │  │      RAG System       │
│  ┌──────────┐ ┌──────────┐    │  │  ┌─────────────────┐  │
│  │  LuzIA   │ │ Enhanced │    │  │  │ RAG Integration │  │
│  │ Provider │ │   Mock   │    │  │  └───────┬─────────┘  │
│  └──────────┘ └──────────┘    │  │          │            │
│  ┌──────────┐ ┌──────────┐    │  │  ┌───────▼─────────┐  │
│  │  OpenAI  │ │  Bedrock │    │  │  │ CobolRAGSystem  │  │
│  │ Provider │ │ Provider │    │  │  └───────┬─────────┘  │
│  └──────────┘ └──────────┘    │  │          │            │
└────────────────────────────────┘  │  ┌───────▼─────────┐  │
                                    │  │ Knowledge Base  │  │
                                    │  │ (JSON)          │  │
                                    │  └─────────────────┘  │
                                    └──────────┬────────────┘
                                               │
                                    ┌──────────▼────────────┐
                                    │   RAG Logger          │
                                    │ ┌─────────┐ ┌───────┐ │
                                    │ │  JSON   │ │  TXT  │ │
                                    │ │  Logs   │ │ Report│ │
                                    │ └─────────┘ └───────┘ │
                                    └───────────────────────┘
```

## Estrutura de Código

### Diretório src/

#### core/
- **config.py**: Gerenciamento de configuração YAML
- **prompt_manager_dual.py**: Gerenciamento de prompts com suporte a múltiplos conjuntos
- **token_manager.py**: Controle de uso de tokens
- **exceptions.py**: Exceções personalizadas do sistema

#### providers/
- **base_provider.py**: Classe base para provedores de IA
- **luzia_provider.py**: Integração com API LuzIA
- **openai_provider.py**: Integração com OpenAI
- **enhanced_provider_manager.py**: Gerenciamento de múltiplos provedores

#### rag/
- **cobol_rag_system.py**: Implementação central do sistema RAG, incluindo busca semântica e enriquecimento.
- **rag_integration.py**: Interface de integração do RAG com o fluxo de análise principal.
- **rag_logger.py**: Sistema de logging transparente para todas as operações RAG.
- **auto_learning_enhancement.py**: Lógica para o aprendizado automático e enriquecimento da base de conhecimento.
- **intelligent_learning_system.py**: Sistema de aprendizado inteligente para extrair conhecimento das análises e padrões.

#### parsers/
- **cobol_parser.py**: Análise sintática de programas COBOL
- **cobol_structures.py**: Estruturas de dados para representar código COBOL

#### analyzers/
- **enhanced_cobol_analyzer.py**: Análise de código COBOL usando IA

#### generators/
- **documentation_generator.py**: Geração de documentação
- **prompt_generator.py**: Geração de prompts personalizados

#### utils/
- **html_generator.py**: Geração de relatórios HTML otimizados

### Fluxo de Processamento com RAG

```
1. Entrada
   ├── Arquivos COBOL e Copybooks
   ├── Configuração (config.yaml)
   └── Prompts (prompts_especialista.yaml)

2. Parsing
   ├── Leitura e pré-processamento dos fontes
   ├── Análise sintática e estruturação dos dados

3. Enriquecimento com RAG (se habilitado)
   ├── Extração de características do código
   ├── Geração de query para a base de conhecimento
   ├── **Busca semântica** na base consolidada
   ├── Recuperação de conhecimento relevante (padrões, regras, etc.)
   ├── **Enriquecimento do prompt** para a IA
   └── **Logging da operação RAG**

4. Análise com IA
   ├── Seleção do provedor (LuzIA, OpenAI, etc.)
   ├── Chamada para a API de IA com o prompt enriquecido
   ├── Tratamento de fallback em caso de falha
   └── Processamento da resposta da IA

5. Pós-processamento e Aprendizado
   ├── Extração da análise estruturada
   ├── **Auto-Learning**: Extração de novo conhecimento da análise
   ├── **Atualização da base RAG** (se habilitado)
   └── **Logging da operação de aprendizado**

6. Geração de Saída
   ├── Documentação final em Markdown
   ├── Conversão para PDF (opcional)
   ├── Relatórios consolidados e comparativos

7. Finalização
   ├── Geração do **relatório de sessão RAG**
   ├── Logs de processamento
   └── Métricas de custo e uso
```

## APIs e Interfaces

### ConfigManager

```python
class ConfigManager:
    def __init__(self, config_path: str)
    def load_config(self) -> Dict[str, Any]
    def get_provider_config(self, provider_name: str) -> Dict[str, Any]
    def get_ai_config(self) -> Dict[str, Any]
```

### DualPromptManager

```python
class DualPromptManager:
    def __init__(self, config: Dict[str, Any], prompt_set: str = None, 
                 custom_prompts_file: str = None)
    def get_system_prompt(self, model: str) -> str
    def get_analysis_questions(self) -> Dict[str, Any]
    def format_prompt(self, template: str, **kwargs) -> str
```

### EnhancedProviderManager

```python
class EnhancedProviderManager:
    def __init__(self, config: Dict[str, Any])
    def get_available_providers(self) -> List[str]
    def get_provider(self, provider_name: str) -> BaseProvider
    def analyze_with_fallback(self, request: AIRequest) -> AIResponse
```

### BaseProvider

```python
class BaseProvider:
    def analyze(self, request: AIRequest) -> AIResponse
    def is_available(self) -> bool
    def get_models(self) -> List[str]
    def get_status(self) -> Dict[str, Any]
```

## Configuração

### Arquivo config/config.yaml

```yaml
# Configuração principal do sistema
system:
  name: "COBOL to Docs"
  version: "1.0"
  author: "Carlos Morais"

# Configuração de IA
ai:
  primary_provider: "luzia"
  default_models: ["aws-claude-3.7"]
  fallback_providers: ["enhanced_mock"]
  
  prompt:
    prompts_file: "config/prompts_original.yaml"
    max_tokens: 200000
    temperature: 0.1

# Provedores de IA
providers:
  luzia:
    base_url: "https://api.luzia.com"
    auth_url: "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
    model: "aws-claude-3.7"
    max_tokens: 200000
    temperature: 0.1
    timeout: 300
    
  enhanced_mock:
    enabled: true
    response_delay: 1.0
    simulate_tokens: true
    
# Configuração de saída
output:
  base_directory: "output"
  generate_html: true
  html_template: "professional"
  include_timestamps: true
  
# Configuração de logs
logging:
  level: "INFO"
  file_rotation: true
  max_file_size: "10MB"
  backup_count: 5
```

### Estrutura de Prompts YAML

```yaml
version: "1.0"

# Prompt base do sistema
system_prompt: |
  Você é um analista especializado em sistemas COBOL...

# Prompts específicos por modelo
model_prompts:
  luzia_standard:
    system_prompt: |
      Prompt específico para LuzIA...
    persona: "analista senior COBOL"
    analysis_depth: "detailed"
    
# Template base para análise
base_template: |
  Programa: {program_name}
  Código: {program_code}
  Contexto: {context_info}

# Questões de análise organizadas
analysis_questions:
  functional:
    priority: 1
    required: true
    context: "Análise funcional do programa"
    focus: "Identificação de funcionalidades e regras de negócio"
    question: |
      Analise a funcionalidade do programa...
```

## Protocolo de Comunicação com IA

### Estrutura de Request

```python
@dataclass
class AIRequest:
    prompt: str
    max_tokens: int = 4000
    temperature: float = 0.1
    model: str = None
    context: Dict[str, Any] = None
```

### Estrutura de Response

```python
@dataclass
class AIResponse:
    success: bool
    content: str
    tokens_used: int
    response_time: float
    model_used: str
    error_message: str = None
    metadata: Dict[str, Any] = None
```

### Protocolo LuzIA

```python
# Autenticação OAuth2
POST /auth/realms/corp/protocol/openid-connect/token
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials&client_id={id}&client_secret={secret}

# Análise
POST /v1/chat/completions
Authorization: Bearer {token}
Content-Type: application/json

{
    "model": "aws-claude-3.7",
    "messages": [{"role": "user", "content": "..."}],
    "max_tokens": 200000,
    "temperature": 0.1,
    "config": [{"key": "value"}]
}
```

## Tratamento de Erros

### Hierarquia de Exceções

```python
class COBOLToDocsException(Exception):
    """Exceção base do sistema"""
    pass

class ConfigurationError(COBOLToDocsException):
    """Erro de configuração"""
    pass

class ProviderError(COBOLToDocsException):
    """Erro de provider de IA"""
    pass

class ParsingError(COBOLToDocsException):
    """Erro de parsing COBOL"""
    pass

class AnalysisError(COBOLToDocsException):
    """Erro de análise"""
    pass
```

### Estratégias de Fallback

1. **Provider Fallback**: Se LuzIA falha, usa enhanced_mock
2. **Token Retry**: Renovação automática de tokens expirados
3. **Request Retry**: Retry automático para erros temporários
4. **Graceful Degradation**: Continua processamento mesmo com falhas parciais

## Performance e Otimização

### Métricas Coletadas

- **Tempo de resposta** por provider
- **Uso de tokens** por análise
- **Taxa de sucesso** por modelo
- **Tempo de parsing** COBOL
- **Tamanho de saída** gerada

### Otimizações Implementadas

1. **Cache de Tokens**: Reutilização de tokens OAuth2
2. **Parsing Eficiente**: Parser otimizado para COBOL
3. **Geração Assíncrona**: Processamento paralelo quando possível
4. **Compressão de Saída**: HTML otimizado para tamanho

### Limites e Restrições

- **Tamanho máximo de arquivo COBOL**: 1MB
- **Tokens máximos por request**: 200,000
- **Timeout de request**: 300 segundos
- **Arquivos simultâneos**: Limitado pela memória disponível

## Segurança

### Tratamento de Credenciais

- **Variáveis de ambiente**: Credenciais nunca em código
- **Logs sanitizados**: Credenciais não aparecem em logs
- **Timeout de tokens**: Renovação automática de tokens

### Validação de Entrada

- **Sanitização de arquivos**: Validação de encoding e conteúdo
- **Validação YAML**: Parser seguro para configurações
- **Path traversal**: Proteção contra ataques de diretório

### Auditoria

- **Logs completos**: Todas as operações são logadas
- **Métricas de uso**: Tracking de uso de recursos
- **Rastreabilidade**: ID único para cada análise

## Extensibilidade

### Adicionando Novos Providers

```python
class NovoProvider(BaseProvider):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        # Inicialização específica
        
    def analyze(self, request: AIRequest) -> AIResponse:
        # Implementação específica
        pass
        
    def is_available(self) -> bool:
        # Verificação de disponibilidade
        pass
```

### Adicionando Novos Formatos de Saída

```python
class NovoGenerator:
    def __init__(self, output_dir: str):
        self.output_dir = output_dir
        
    def generate(self, analysis: str, metadata: Dict[str, Any]) -> str:
        # Geração do novo formato
        pass
```

### Customização de Prompts

O sistema suporta prompts completamente personalizados através de:
1. **Arquivos YAML customizados**
2. **Geração automática via IA**
3. **Templates parametrizáveis**
4. **Validação automática de estrutura**

---

**Autor:** Carlos Morais  
**Sistema:** COBOL to Docs v1.1  
**Data:** Setembro 2025

Esta documentação técnica serve como referência para desenvolvedores que desejam entender, modificar ou estender o sistema.
