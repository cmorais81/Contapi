#!/usr/bin/env python3
"""
Script de Análise Profissional COBOL
Integra o sistema de análise profissional com cálculo de custos detalhado
"""

import os
import sys
import logging
import argparse
from datetime import datetime
from pathlib import Path

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from parsers.cobol_parser_original import COBOLParser
from generators.professional_report_generator import ProfessionalReportGenerator
from utils.enhanced_cost_calculator import EnhancedCostCalculator
from providers.enhanced_provider_manager import EnhancedProviderManager

def setup_logging(output_dir: str) -> logging.Logger:
    """Configura logging para a análise profissional"""
    log_dir = Path(output_dir) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = log_dir / f"professional_analysis_{timestamp}.log"
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    return logging.getLogger(__name__)

def load_programs(fontes_file: str) -> list:
    """Carrega programas COBOL do arquivo de fontes"""
    parser = COBOLParser()
    programs = []
    
    with open(fontes_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Dividir por programas (assumindo separação por nome do programa)
    program_sections = content.split('PROGRAM-ID.')
    
    for i, section in enumerate(program_sections[1:], 1):  # Pular primeira seção vazia
        lines = section.strip().split('\n')
        if lines:
            program_name = lines[0].strip().split('.')[0].strip()
            program_content = 'PROGRAM-ID. ' + section
            
            program = type('Program', (), {
                'name': program_name,
                'content': program_content
            })()
            
            programs.append(program)
    
    return programs

def load_copybooks(books_file: str) -> dict:
    """Carrega copybooks do arquivo BOOKS"""
    copybooks = {}
    
    if os.path.exists(books_file):
        with open(books_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Processar copybooks (implementação simplificada)
        # Em um cenário real, seria necessário parsear adequadamente
        copybooks['GENERIC_COPYBOOK'] = content
    
    return copybooks

def analyze_with_ai(programs: list, model: str, cost_calculator: EnhancedCostCalculator) -> list:
    """Analisa programas usando IA"""
    # Configuração básica para o provider manager
    config = {
        'ai': {
            'primary_provider': model,
            'fallback_providers': ['enhanced_mock'],
            'model_configurations': {
                model: {
                    'max_tokens': 4000,
                    'temperature': 0.1
                }
            }
        },
        'providers': {
            'luzia': {},
            'enhanced_mock': {},
            'openai': {},
            'aws': {},
            'databricks': {}
        }
    }
    
    provider_manager = EnhancedProviderManager(config)
    analysis_results = []
    
    for program in programs:
        try:
            # Prompt profissional para análise
            prompt = f"""
Analise o seguinte programa COBOL de forma profissional e detalhada:

PROGRAMA: {program.name}

CÓDIGO:
{program.content[:2000]}...

Forneça uma análise técnica abrangente incluindo:
1. Regras de negócio identificadas
2. Estruturas de dados utilizadas
3. Integrações e interfaces
4. Operações de arquivo e banco de dados
5. Lógica condicional complexa
6. Cálculos e fórmulas
7. Tratamento de erros
8. Considerações de performance
9. Avaliação de modernização
10. Débito técnico identificado

Seja específico e técnico na análise.
"""
            
            # Executar análise
            response = provider_manager.analyze(prompt, model)
            
            if response.get('success'):
                # Calcular custos
                tokens_info = cost_calculator.tokens_analytics(
                    response.get('metadata', {}), 
                    model
                )
                
                analysis_results.append({
                    'program': program.name,
                    'success': True,
                    'analysis': response.get('content', ''),
                    'tokens_used': tokens_info.get('total_tokens', 0),
                    'cost': tokens_info.get('cost', 0.0),
                    'cost_brl': tokens_info.get('cost_brl', 0.0),
                    'model': model
                })
            else:
                analysis_results.append({
                    'program': program.name,
                    'success': False,
                    'error': response.get('error', 'Erro desconhecido'),
                    'tokens_used': 0,
                    'cost': 0.0,
                    'model': model
                })
        
        except Exception as e:
            logging.error(f"Erro ao analisar programa {program.name}: {e}")
            analysis_results.append({
                'program': program.name,
                'success': False,
                'error': str(e),
                'tokens_used': 0,
                'cost': 0.0,
                'model': model
            })
    
    return analysis_results

def main():
    parser = argparse.ArgumentParser(description='Análise Profissional de Sistemas COBOL')
    parser.add_argument('--fontes', required=True, help='Arquivo com programas COBOL')
    parser.add_argument('--books', help='Arquivo com copybooks')
    parser.add_argument('--output', required=True, help='Diretório de saída')
    parser.add_argument('--model', default='luzia', help='Modelo de IA a usar')
    parser.add_argument('--estimate-only', action='store_true', help='Apenas estimar custos')
    
    args = parser.parse_args()
    
    # Criar diretório de saída com timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(args.output) / f"professional_analysis_{timestamp}"
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Setup logging
    logger = setup_logging(str(output_dir))
    logger.info("Iniciando análise profissional de sistemas COBOL")
    
    try:
        # Carregar programas e copybooks
        logger.info(f"Carregando programas de {args.fontes}")
        programs = load_programs(args.fontes)
        logger.info(f"Carregados {len(programs)} programas")
        
        copybooks = {}
        if args.books:
            logger.info(f"Carregando copybooks de {args.books}")
            copybooks = load_copybooks(args.books)
            logger.info(f"Carregados {len(copybooks)} copybooks")
        
        # Inicializar calculadora de custos
        cost_calculator = EnhancedCostCalculator()
        
        # Estimar custos se solicitado
        if args.estimate_only:
            logger.info("Gerando estimativa de custos...")
            estimate = cost_calculator.get_cost_estimate_for_analysis(programs, args.model)
            
            print("\n" + "="*60)
            print("ESTIMATIVA DE CUSTOS PARA ANÁLISE")
            print("="*60)
            print(f"Programas a analisar: {estimate['programs_count']}")
            print(f"Total de linhas: {estimate['total_lines']:,}")
            print(f"Tokens estimados: {estimate['estimated_tokens']['total_tokens']:,}")
            print(f"Custo estimado: R$ {estimate['estimated_cost_brl']:.4f} (${estimate['estimated_cost_usd']:.4f})")
            print(f"Modelo: {estimate['model']}")
            print(f"Nota: {estimate['note']}")
            print("="*60)
            
            return
        
        # Executar análise com IA
        logger.info(f"Iniciando análise com modelo {args.model}")
        analysis_results = analyze_with_ai(programs, args.model, cost_calculator)
        
        # Gerar relatórios profissionais
        logger.info("Gerando relatórios profissionais...")
        report_generator = ProfessionalReportGenerator(str(output_dir))
        
        # Dados detalhados simulados (em produção viriam da análise real)
        detailed_analysis = {
            'total_business_rules': sum(1 for r in analysis_results if r.get('success')),
            'complexity_analysis': 'Média',
            'modernization_priority': 'Alta'
        }
        
        report_paths = report_generator.generate_comprehensive_report(
            programs, analysis_results, detailed_analysis, copybooks
        )
        
        # Resumo da sessão de custos
        cost_summary = cost_calculator.get_session_summary()
        
        # Exibir resultados
        print("\n" + "="*80)
        print("ANÁLISE PROFISSIONAL CONCLUÍDA COM SUCESSO")
        print("="*80)
        print(f"Programas analisados: {len(programs)}")
        print(f"Análises bem-sucedidas: {len([r for r in analysis_results if r.get('success')])}")
        print(f"Total de tokens processados: {cost_summary['total_tokens']:,}")
        print(f"Custo total: R$ {cost_summary['total_cost_brl']:.4f} (${cost_summary['total_cost_usd']:.4f})")
        print(f"Custo médio por programa: R$ {cost_summary['total_cost_brl']/len(programs):.4f}")
        
        print("\nRELATÓRIOS GERADOS:")
        print("-" * 40)
        for report_type, path in report_paths.items():
            print(f"{report_type}: {path}")
        
        print("\nBREAKDOWN DE CUSTOS POR MODELO:")
        print("-" * 40)
        for model, breakdown in cost_summary['cost_breakdown'].items():
            print(f"{model}:")
            print(f"  - Requisições: {breakdown['requests']}")
            print(f"  - Tokens: {breakdown['tokens']:,}")
            print(f"  - Custo: R$ {breakdown['cost_brl']:.4f}")
        
        print("\n" + "="*80)
        print("ANÁLISE CONCLUÍDA - Verifique os relatórios gerados")
        print("="*80)
        
        logger.info(f"Análise profissional concluída com sucesso. Relatórios em: {output_dir}")
        
    except Exception as e:
        logger.error(f"Erro durante análise profissional: {e}", exc_info=True)
        print(f"\nERRO: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
