#!/usr/bin/env python3
"""
Função de Análise Avançada Consolidada
Integra com o main.py para executar análise completa com relatório HTML
"""

import os
import sys
import logging
from datetime import datetime
from pathlib import Path

# Adicionar src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from process_advanced_analysis import process_advanced_analysis
from parsers.cobol_parser_original import COBOLParser, CobolProgram

def process_advanced_consolidated_analysis(args, config_manager, cost_calculator, parser, models):
    """
    Processa análise avançada consolidada integrada ao main.py
    """
    
    logger = logging.getLogger(__name__)
    logger.info("Iniciando análise avançada consolidada")
    
    try:
        # Parse dos arquivos COBOL
        logger.info(f"Fazendo parse do arquivo: {args.fontes}")
        programs, books = parser.parse_file(args.fontes)
        
        # Converter books para programs se necessário
        if books and not programs:
            programs = [CobolProgram(name=book.name, content=book.content, divisions={}, sections=[]) for book in books]
        
        if not programs:
            logger.error("Nenhum programa COBOL encontrado para análise")
            print("Erro: Nenhum programa COBOL válido encontrado")
            return
        
        logger.info(f"Programas encontrados: {[p.name for p in programs]}")
        
        # Preparar diretório de saída
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = f"{args.output}_advanced_{timestamp}"
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Diretório de saída: {output_dir}")
        
        # Executar análise avançada
        result = process_advanced_analysis(
            programs=programs,
            models=models,
            output_dir=output_dir,
            config=config_manager.config
        )
        
        if result['success']:
            logger.info("Análise avançada concluída com sucesso!")
            
            # Exibir resumo
            summary = result['summary']
            print("\n" + "="*60)
            print("ANÁLISE AVANÇADA CONCLUÍDA COM SUCESSO")
            print("="*60)
            print(f"Programas analisados: {summary['programs_analyzed']}")
            print(f"Modelos LLM utilizados: {summary['models_used']}")
            print(f"Regras de negócio extraídas: {summary['total_rules_extracted']}")
            print(f"Tempo de processamento: {summary['processing_time']:.2f} segundos")
            print(f"Custo total estimado: R$ {summary['total_cost']:.4f}")
            print()
            
            # Exibir arquivos gerados
            report_files = result.get('report_files', {})
            if report_files:
                print("RELATÓRIOS GERADOS:")
                print("-" * 30)
                
                if 'html_report' in report_files:
                    print(f"Relatório HTML Profissional: {report_files['html_report']}")
                
                if 'detailed_report' in report_files:
                    print(f"Relatório Detalhado: {report_files['detailed_report']}")
                
                if 'consolidated_data' in report_files:
                    print(f"Dados Consolidados: {report_files['consolidated_data']}")
                
                print()
            
            # Exibir estatísticas RAG se disponível
            consolidated_results = result.get('consolidated_results', {})
            rag_stats = consolidated_results.get('rag_stats', {})
            
            if rag_stats:
                print("ESTATÍSTICAS RAG:")
                print("-" * 20)
                print(f"Operações RAG realizadas: {rag_stats.get('total_operations', 0)}")
                print(f"Itens de conhecimento utilizados: {rag_stats.get('knowledge_items_used', 0)}")
                print(f"Contexto aplicado: {rag_stats.get('context_applied', 'N/A')}")
                print()
            
            # Exibir métricas de performance
            performance = consolidated_results.get('performance_metrics', {})
            if performance:
                print("MÉTRICAS DE PERFORMANCE:")
                print("-" * 25)
                print(f"Taxa de sucesso: {performance.get('success_rate', 0):.1f}%")
                print(f"Total de tokens processados: {performance.get('total_tokens', 0):,}")
                print(f"Programas processados: {performance.get('programs_processed', 0)}")
                print()
            
            print("="*60)
            print("ANÁLISE CONCLUÍDA - Verifique os relatórios gerados")
            print("="*60)
            
        else:
            logger.error(f"Falha na análise avançada: {result.get('error', 'Erro desconhecido')}")
            print(f"Erro na análise avançada: {result.get('error', 'Erro desconhecido')}")
            
            # Tentar salvar resultados parciais se disponível
            consolidated_results = result.get('consolidated_results')
            if consolidated_results:
                partial_file = Path(output_dir) / "resultados_parciais.json"
                try:
                    import json
                    with open(partial_file, 'w', encoding='utf-8') as f:
                        json.dump(consolidated_results, f, indent=2, ensure_ascii=False, default=str)
                    print(f"Resultados parciais salvos em: {partial_file}")
                except Exception as e:
                    logger.error(f"Erro ao salvar resultados parciais: {e}")
    
    except Exception as e:
        logger.error(f"Erro na análise avançada consolidada: {e}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        print(f"Erro fatal na análise avançada: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    print("Este módulo deve ser importado pelo main.py")
    print("Use: python main.py --advanced-analysis --fontes programa.cbl")
