import os
import re

def fix_init_imports(file_path):
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Get the directory name to prefix imports
    dir_name = os.path.basename(os.path.dirname(file_path))
    
    # Fix imports like "from config import" to "from core.config import" 
    lines = content.split('\n')
    fixed_lines = []
    
    for line in lines:
        if line.startswith('from ') and ' import ' in line and not line.startswith('from ' + dir_name + '.'):
            # Extract module name
            match = re.match(r'from ([a-zA-Z_][a-zA-Z0-9_]*) import', line)
            if match:
                module = match.group(1)
                line = line.replace(f'from {module} import', f'from {dir_name}.{module} import')
        fixed_lines.append(line)
    
    content = '\n'.join(fixed_lines)
    
    with open(file_path, 'w') as f:
        f.write(content)
    print(f"Fixed init imports in {file_path}")

# Fix all __init__.py files
init_files = [
    'src/core/__init__.py',
    'src/providers/__init__.py', 
    'src/rag/__init__.py',
    'src/utils/__init__.py'
]

for file_path in init_files:
    if os.path.exists(file_path):
        fix_init_imports(file_path)

print("All __init__.py files fixed!")
