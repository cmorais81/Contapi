# 🚀 Instruções para Teste - COBOL_ANALYZER v4.0

**Data:** 13 de Outubro de 2025  
**Versão:** 4.0 Final - Múltiplos Programas

## 📋 Pré-requisitos

- Python 3.11+
- Sistema operacional: Linux/Ubuntu (recomendado)
- Memória: Mínimo 2GB RAM
- Espaço em disco: 500MB livres

## 🔧 Instalação Rápida

```bash
# 1. Extrair o pacote
tar -xzf COBOL_TO_DOCS_v4.0_MULTIPROGRAMAS_FINAL.tar.gz
cd sbr-thpf-cobol-to-docs-v4-corrigido

# 2. Instalar dependências (opcional - já incluídas)
pip3 install -r requirements.txt

# 3. Verificar estrutura
ls -la
```

## 🧪 Testes Disponíveis

### Teste 1: Processamento de Múltiplos Programas (Padrão)
```bash
python3 cobol_to_docs/runner/main.py \
    --fontes fontes.txt \
    --books BOOKS.txt \
    --output teste_multiprogramas
```

**Resultado Esperado:**
- ✅ 5 programas processados: LHAN0542, LHAN0705, LHAN0706, LHBR0700, MZAN6056
- ✅ 11 copybooks carregados
- ✅ ~160.000 tokens utilizados
- ✅ 15 arquivos gerados (5 análises + 5 requests + 5 responses)

### Teste 2: Com Prompt Customizado
```bash
python3 cobol_to_docs/runner/main.py \
    --fontes fontes.txt \
    --books BOOKS.txt \
    --custom-prompt minato_promt.txt \
    --output teste_prompt_customizado
```

**Resultado Esperado:**
- ✅ 5 programas processados com prompt customizado
- ✅ ~95.000 tokens utilizados (mais eficiente)
- ✅ Flag `custom_prompt_used: true` nos arquivos JSON

### Teste 3: Verificação de Logs Detalhados
```bash
python3 cobol_to_docs/runner/main.py \
    --fontes fontes.txt \
    --books BOOKS.txt \
    --log-level DEBUG \
    --output teste_debug
```

## 📁 Estrutura de Saída Esperada

```
output/
└── model_enhanced_mock/
    ├── LHAN0542_analise_funcional.md
    ├── LHAN0705_analise_funcional.md
    ├── LHAN0706_analise_funcional.md
    ├── LHBR0700_analise_funcional.md
    ├── MZAN6056_analise_funcional.md
    ├── ai_requests/
    │   ├── LHAN0542_ai_request.json
    │   ├── LHAN0705_ai_request.json
    │   ├── LHAN0706_ai_request.json
    │   ├── LHBR0700_ai_request.json
    │   └── MZAN6056_ai_request.json
    └── ai_responses/
        ├── LHAN0542_ai_response.json
        ├── LHAN0705_ai_response.json
        ├── LHAN0706_ai_response.json
        ├── LHBR0700_ai_response.json
        └── MZAN6056_ai_response.json
```

## 🔍 Verificações de Qualidade

### 1. Verificar Múltiplos Programas
```bash
# Contar programas processados
find output -name "*_analise_funcional.md" | wc -l
# Deve retornar: 5
```

### 2. Verificar Estrutura de Pastas
```bash
# Verificar pastas ai_requests e ai_responses
ls -la output/model_enhanced_mock/
# Deve mostrar: ai_requests/ e ai_responses/
```

### 3. Verificar Prompt Customizado
```bash
# Verificar se prompt customizado foi usado
grep -r "custom_prompt_used.*true" output/
# Deve encontrar ocorrências se --custom-prompt foi usado
```

### 4. Verificar Logs
```bash
# Verificar logs gerados
ls -la logs/
tail -20 logs/cobol_analyzer_*.log
```

## 📊 Métricas de Sucesso

| Métrica | Valor Esperado | Como Verificar |
|---------|----------------|----------------|
| Programas processados | 5 | Contar arquivos `*_analise_funcional.md` |
| Copybooks carregados | 11 | Verificar logs: "Copybook X extraído" |
| Arquivos gerados | 15 | Contar todos os arquivos em `output/` |
| Tempo de processamento | < 5 segundos | Verificar saída do console |
| Tokens utilizados | 95k-160k | Verificar saída final |

## 🐛 Solução de Problemas

### Erro: "Arquivo não encontrado"
```bash
# Verificar se os arquivos existem
ls -la fontes.txt BOOKS.txt minato_promt.txt
```

### Erro: "Módulo não encontrado"
```bash
# Instalar dependências
pip3 install -r requirements.txt
```

### Erro: "Provider falhou"
```bash
# Normal - sistema usa fallback enhanced_mock
# Verificar se análise foi concluída mesmo assim
```

## 📞 Suporte

Se encontrar problemas:

1. **Verificar logs:** `tail -50 logs/cobol_analyzer_*.log`
2. **Verificar estrutura:** `tree output/` ou `find output -type f`
3. **Testar com log DEBUG:** `--log-level DEBUG`

## ✅ Checklist de Teste

- [ ] Teste 1: Múltiplos programas processados
- [ ] Teste 2: Prompt customizado aplicado
- [ ] Teste 3: Estrutura de saída correta
- [ ] Teste 4: Arquivos JSON gerados
- [ ] Teste 5: Logs detalhados funcionando
- [ ] Teste 6: Métricas de performance adequadas

**🎯 Se todos os testes passarem, a aplicação está funcionando perfeitamente!**
