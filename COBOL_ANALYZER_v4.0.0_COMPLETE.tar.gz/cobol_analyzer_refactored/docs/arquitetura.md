"""# Arquitetura da Aplicação - COBOL Analyzer

## 1. Visão Geral

Este documento descreve a arquitetura da aplicação COBOL Analyzer, que foi refatorada para seguir as melhores práticas de desenvolvimento de software, incluindo os princípios SOLID, arquitetura em camadas e orientação a objetos. O objetivo da refatoração foi aumentar a manutenibilidade, testabilidade e extensibilidade da aplicação.

## 2. Arquitetura em Camadas

A aplicação foi estruturada em três camadas principais, cada uma com responsabilidades bem definidas:

- **Camada de Domínio (`src/domain`):** O coração da aplicação. Contém a lógica de negócio principal e os modelos de dados que representam os conceitos fundamentais do sistema (ex: `CobolProgram`, `AnalysisResult`). Esta camada é completamente independente de detalhes de implementação, como frameworks ou bancos de dados.

- **Camada de Aplicação (`src/application`):** Orquestra os casos de uso (use cases) da aplicação. Ela coordena a interação entre a camada de domínio e a camada de infraestrutura para executar as funcionalidades do sistema, como a análise de um programa COBOL. Não contém lógica de negócio, apenas fluxo de controle.

- **Camada de Infraestrutura (`src/infrastructure`):** Contém os detalhes técnicos e as implementações de interfaces definidas na camada de domínio. Isso inclui a comunicação com serviços externos (como provedores de IA), persistência de dados (como o repositório de conhecimento do RAG em arquivo) e a interface com o usuário (CLI).

```
+----------------------------------------------------+
| Camada de Infraestrutura (CLI, Provedores de IA)    |
+-----------------------^----------------------------+
                        | (Injeção de Dependência)
+-----------------------v----------------------------+
| Camada de Aplicação (Casos de Uso)                 |
+-----------------------^----------------------------+
                        | (Usa)
+-----------------------v----------------------------+
| Camada de Domínio (Modelos, Lógica de Negócio)     |
+----------------------------------------------------+
```

## 3. Componentes Principais

- **`src/cli.py`:** Ponto de entrada da aplicação. Define a interface de linha de comando (CLI) usando a biblioteca `click` e delega a execução para os casos de uso da camada de aplicação.

- **`src/config.py` (`ConfigManager`):** Responsável por carregar e gerenciar as configurações da aplicação a partir de um arquivo YAML, com suporte a variáveis de ambiente.

- **`src/domain/models.py`:** Define as estruturas de dados centrais da aplicação, como `CobolProgram`, `AnalysisResult` e `KnowledgeItem`, utilizando `dataclasses`.

- **`src/application/use_cases/`:** Contém os casos de uso da aplicação, como `AnalyzeProgramsUseCase` e os casos de uso do RAG. Cada caso de uso encapsula uma funcionalidade completa do sistema.

- **`src/infrastructure/providers/`:** Implementa a comunicação com os diferentes provedores de IA. A classe `EnhancedProviderManager` gerencia múltiplos provedores, com lógica de fallback e seleção de modelos.

- **`src/infrastructure/persistence/`:** Implementa a persistência de dados. `FileKnowledgeRepository` é um exemplo que implementa a interface de repositório para o sistema RAG, salvando os dados em arquivos JSON.

- **`src/rag/`:** Contém a lógica para o sistema de Retrieval-Augmented Generation (RAG), que enriquece as análises com conhecimento prévio.

- **`tests/`:** Contém os testes unitários da aplicação, utilizando o framework `pytest`.

## 4. Princípios de Design

- **Inversão de Dependência (DIP):** As camadas superiores (aplicação) dependem de abstrações (interfaces) definidas nas camadas inferiores (domínio), e não de implementações concretas. As implementações são injetadas pela camada de infraestrutura, o que facilita a troca de componentes (ex: trocar um provedor de IA por outro).

- **Princípio da Responsabilidade Única (SRP):** Cada classe e módulo tem uma única responsabilidade bem definida. Por exemplo, `ConfigManager` lida apenas com configuração, e `EnhancedProviderManager` lida apenas com a lógica de provedores de IA.

- **Aberto/Fechado (OCP):** A arquitetura é projetada para ser aberta para extensão, mas fechada para modificação. É possível adicionar novos provedores de IA ou novos casos de uso sem modificar o código existente, apenas adicionando novas classes.

## 5. Fluxo de Análise

1.  O usuário executa o comando `analyze` na CLI.
2.  O `cli.py` instancia o `ConfigManager`, o `EnhancedProviderManager` e outras dependências.
3.  O `AnalyzeProgramsUseCase` é instanciado e executado.
4.  O caso de uso lê os programas COBOL, itera sobre eles e, para cada um, chama o `AnalyzeSingleProgramUseCase`.
5.  O `AnalyzeSingleProgramUseCase` utiliza o `EnhancedCOBOLAnalyzer` para realizar a análise.
6.  O `EnhancedCOBOLAnalyzer` prepara o prompt, o enriquece com o sistema RAG e chama o `EnhancedProviderManager` para obter a análise do modelo de IA.
7.  O resultado é encapsulado em um objeto `AnalysisResult` e retornado.
8.  O `DocumentationGenerator` utiliza o `AnalysisResult` para criar os arquivos de documentação no diretório de saída.

"""
