"""
Use Case: Analyze Multiple COBOL Programs
"""

import logging
from typing import Dict, Any, List

from src.config import ConfigManager
from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration import RAGIntegration
from src.infrastructure.providers.enhanced_provider_manager import EnhancedProviderManager
from .analyze_single_program import AnalyzeSingleProgramUseCase

logger = logging.getLogger(__name__)

class AnalyzeProgramsUseCase:
    def __init__(
        self,
        config_manager: ConfigManager,
        cost_calculator: CostCalculator,
        rag_integration: RAGIntegration,
        parser: COBOLParser,
        provider_manager: EnhancedProviderManager,
    ):
        self.config_manager = config_manager
        self.cost_calculator = cost_calculator
        self.rag_integration = rag_integration
        self.parser = parser
        self.provider_manager = provider_manager

    def execute(self, args: Dict[str, Any]):
        """Orchestrates the analysis of multiple COBOL programs."""
        
        # Carregar programas e copybooks
        programs, _ = self.parser.parse_file(args["fontes"])
        books = []
        if args.get("books"):
            _, books = self.parser.parse_file(args.get("books"))

        # Determinar modelos
        models_to_use = self._get_models_to_use(args)
        is_multi_model = len(models_to_use) > 1

        all_results = []
        for program in programs:
            for model in models_to_use:
                use_case = AnalyzeSingleProgramUseCase(self.config_manager, self.cost_calculator, self.rag_integration, self.provider_manager)
                result = use_case.execute(program, books, model, args["output"], is_multi_model, args)
                all_results.append(result)

        if is_multi_model:
            self._generate_comparative_report(programs, all_results, args["output"])

    def _get_models_to_use(self, args: Dict[str, Any]) -> List[str]:
        """Determines the list of AI models to use for the analysis."""
        if args.get("models"):
            # Lógica para parsear o argumento 'models'
            return args["models"].split(",") # Simplificado
        
        # Lógica para obter modelos da configuração
        return self.config_manager.get("ai", {}).get("default_models", ["enhanced_mock"])

    def _generate_comparative_report(self, programs: List[CobolProgram], results: List[Dict[str, Any]], output_dir: str):
        """Generates a comparative report of the analysis results."""
        # Lógica para gerar o relatório comparativo (a ser movida do main.py original)
        logger.info("Comparative report generation is not yet implemented in the refactored structure.")

