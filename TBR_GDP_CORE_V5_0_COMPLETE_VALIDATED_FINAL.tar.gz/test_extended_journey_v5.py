"""
TBR GDP Core v5.0 - Teste da Jornada Estendida
Author: Carlos Morais <carlos.morais@f1rst.com.br>

Teste end-to-end com múltiplos contratos, versões e cenários complexos.
"""

import requests
import json
import time
from datetime import datetime
from typing import Dict, Any, List

# Configurações
BASE_URL = "http://localhost:8002"
TIMEOUT = 30

class ExtendedJourneyTester:
    """Testador da jornada estendida"""
    
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.session = requests.Session()
        self.results = {
            "start_time": datetime.now().isoformat(),
            "scenarios": [],
            "entities": [],
            "contracts": [],
            "executions": [],
            "summary": {},
            "success": False
        }
    
    def log_step(self, scenario: str, step_name: str, success: bool, data: Dict[str, Any] = None, error: str = None):
        """Registrar passo da jornada"""
        step = {
            "scenario": scenario,
            "step": step_name,
            "timestamp": datetime.now().isoformat(),
            "success": success,
            "data": data,
            "error": error
        }
        self.results["scenarios"].append(step)
        
        status = "✅" if success else "❌"
        print(f"{status} [{scenario}] {step_name}")
        if data and isinstance(data, dict):
            # Mostrar apenas campos principais para não poluir o log
            summary_data = {}
            if "id" in data:
                summary_data["id"] = data["id"]
            if "name" in data:
                summary_data["name"] = data["name"]
            if "status" in data:
                summary_data["status"] = data["status"]
            if "version" in data:
                summary_data["version"] = data["version"]
            print(f"   Data: {json.dumps(summary_data, indent=2, default=str)}")
        if error:
            print(f"   Error: {error}")
        print()
    
    def create_entity(self, scenario: str, entity_data: Dict[str, Any]) -> Dict[str, Any]:
        """Criar entidade de dados"""
        try:
            response = self.session.post(
                f"{self.base_url}/api/v4/entities",
                json=entity_data,
                timeout=TIMEOUT
            )
            
            if response.status_code == 201:
                entity = response.json()
                self.log_step(scenario, f"Criar Entidade: {entity_data['name']}", True, entity)
                self.results["entities"].append(entity)
                return entity
            else:
                self.log_step(scenario, f"Criar Entidade: {entity_data['name']}", False, 
                            error=f"Status: {response.status_code}")
                return None
        except Exception as e:
            self.log_step(scenario, f"Criar Entidade: {entity_data['name']}", False, error=str(e))
            return None
    
    def create_contract(self, scenario: str, contract_data: Dict[str, Any]) -> Dict[str, Any]:
        """Criar contrato de dados"""
        try:
            response = self.session.post(
                f"{self.base_url}/api/v4/contracts",
                json=contract_data,
                timeout=TIMEOUT
            )
            
            if response.status_code == 201:
                contract = response.json()
                self.log_step(scenario, f"Criar Contrato: {contract_data['name']}", True, contract)
                self.results["contracts"].append(contract)
                return contract
            else:
                self.log_step(scenario, f"Criar Contrato: {contract_data['name']}", False,
                            error=f"Status: {response.status_code}")
                return None
        except Exception as e:
            self.log_step(scenario, f"Criar Contrato: {contract_data['name']}", False, error=str(e))
            return None
    
    def activate_contract(self, scenario: str, contract_id: int, contract_name: str) -> bool:
        """Ativar contrato"""
        try:
            response = self.session.put(
                f"{self.base_url}/api/v4/contracts/{contract_id}/activate",
                timeout=TIMEOUT
            )
            
            if response.status_code == 200:
                result = response.json()
                self.log_step(scenario, f"Ativar Contrato: {contract_name}", True, result)
                return True
            else:
                self.log_step(scenario, f"Ativar Contrato: {contract_name}", False,
                            error=f"Status: {response.status_code}")
                return False
        except Exception as e:
            self.log_step(scenario, f"Ativar Contrato: {contract_name}", False, error=str(e))
            return False
    
    def execute_contract(self, scenario: str, contract_id: int, contract_name: str, execution_type: str) -> Dict[str, Any]:
        """Executar contrato"""
        try:
            execution_data = {"execution_type": execution_type}
            
            response = self.session.post(
                f"{self.base_url}/api/v4/contracts/{contract_id}/execute",
                json=execution_data,
                timeout=TIMEOUT
            )
            
            if response.status_code == 201:
                execution = response.json()
                self.log_step(scenario, f"Executar Contrato: {contract_name} ({execution_type})", True, execution)
                self.results["executions"].append(execution)
                return execution
            else:
                self.log_step(scenario, f"Executar Contrato: {contract_name} ({execution_type})", False,
                            error=f"Status: {response.status_code}")
                return None
        except Exception as e:
            self.log_step(scenario, f"Executar Contrato: {contract_name} ({execution_type})", False, error=str(e))
            return None
    
    def validate_contract(self, scenario: str, contract_id: int, contract_name: str) -> Dict[str, Any]:
        """Validar contrato"""
        try:
            response = self.session.get(
                f"{self.base_url}/api/v4/contracts/{contract_id}/validate",
                timeout=TIMEOUT
            )
            
            if response.status_code == 200:
                validation = response.json()
                self.log_step(scenario, f"Validar Contrato: {contract_name}", True, validation)
                return validation
            else:
                self.log_step(scenario, f"Validar Contrato: {contract_name}", False,
                            error=f"Status: {response.status_code}")
                return None
        except Exception as e:
            self.log_step(scenario, f"Validar Contrato: {contract_name}", False, error=str(e))
            return None
    
    def scenario_customer_analytics(self):
        """Cenário 1: Análise de Clientes"""
        scenario = "CUSTOMER_ANALYTICS"
        print(f"\n🎯 CENÁRIO 1: {scenario}")
        print("-" * 50)
        
        # Criar entidade de clientes
        entity_data = {
            "name": "customer_profiles",
            "description": "Perfis consolidados de clientes para análise de comportamento",
            "domain_id": 1,
            "entity_type": "table",
            "classification": "confidential"
        }
        entity = self.create_entity(scenario, entity_data)
        if not entity:
            return False
        
        # Contrato v1.0.0 - Análise Básica
        contract_v1_data = {
            "name": "Contrato de Análise de Clientes v1",
            "description": "Contrato inicial para análise básica de comportamento de clientes",
            "entity_id": entity["id"],
            "contract_type": "data_analysis",
            "schema_definition": {
                "fields": [
                    {"name": "customer_id", "type": "integer", "required": True},
                    {"name": "name", "type": "string", "required": True},
                    {"name": "email", "type": "string", "required": True},
                    {"name": "age", "type": "integer", "required": False}
                ],
                "constraints": {
                    "unique_keys": ["customer_id"],
                    "not_null": ["customer_id", "name", "email"]
                }
            },
            "quality_requirements": {
                "completeness": {"threshold": 90.0, "critical": True},
                "accuracy": {"threshold": 85.0, "critical": True}
            },
            "sla_requirements": {
                "availability": {"threshold": 99.0, "unit": "percent"},
                "response_time": {"threshold": 3000, "unit": "milliseconds"}
            }
        }
        contract_v1 = self.create_contract(scenario, contract_v1_data)
        if not contract_v1:
            return False
        
        # Ativar e executar v1
        self.activate_contract(scenario, contract_v1["id"], contract_v1["name"])
        self.validate_contract(scenario, contract_v1["id"], contract_v1["name"])
        self.execute_contract(scenario, contract_v1["id"], contract_v1["name"], "basic_analysis")
        
        # Contrato v2.0.0 - Análise Avançada
        contract_v2_data = {
            "name": "Contrato de Análise de Clientes v2",
            "description": "Contrato avançado com segmentação e personalização",
            "entity_id": entity["id"],
            "contract_type": "advanced_analysis",
            "schema_definition": {
                "fields": [
                    {"name": "customer_id", "type": "integer", "required": True},
                    {"name": "name", "type": "string", "required": True},
                    {"name": "email", "type": "string", "required": True},
                    {"name": "age", "type": "integer", "required": False},
                    {"name": "segment", "type": "string", "required": False},
                    {"name": "lifetime_value", "type": "decimal", "required": False},
                    {"name": "last_purchase_date", "type": "date", "required": False}
                ],
                "constraints": {
                    "unique_keys": ["customer_id"],
                    "not_null": ["customer_id", "name", "email"]
                }
            },
            "quality_requirements": {
                "completeness": {"threshold": 95.0, "critical": True},
                "accuracy": {"threshold": 90.0, "critical": True},
                "consistency": {"threshold": 85.0, "critical": False},
                "timeliness": {"max_age_hours": 24, "critical": True}
            },
            "sla_requirements": {
                "availability": {"threshold": 99.5, "unit": "percent"},
                "response_time": {"threshold": 2000, "unit": "milliseconds"},
                "throughput": {"min_records_per_hour": 10000}
            }
        }
        contract_v2 = self.create_contract(scenario, contract_v2_data)
        if not contract_v2:
            return False
        
        # Ativar e executar v2
        self.activate_contract(scenario, contract_v2["id"], contract_v2["name"])
        self.validate_contract(scenario, contract_v2["id"], contract_v2["name"])
        self.execute_contract(scenario, contract_v2["id"], contract_v2["name"], "advanced_analysis")
        self.execute_contract(scenario, contract_v2["id"], contract_v2["name"], "segmentation")
        
        return True
    
    def scenario_financial_reporting(self):
        """Cenário 2: Relatórios Financeiros"""
        scenario = "FINANCIAL_REPORTING"
        print(f"\n🎯 CENÁRIO 2: {scenario}")
        print("-" * 50)
        
        # Criar entidade de transações financeiras
        entity_data = {
            "name": "financial_transactions",
            "description": "Transações financeiras para relatórios regulatórios",
            "domain_id": 2,
            "entity_type": "table",
            "classification": "restricted"
        }
        entity = self.create_entity(scenario, entity_data)
        if not entity:
            return False
        
        # Contrato de Compliance
        contract_data = {
            "name": "Contrato de Compliance Financeiro",
            "description": "Contrato para geração de relatórios regulatórios",
            "entity_id": entity["id"],
            "contract_type": "compliance_reporting",
            "schema_definition": {
                "fields": [
                    {"name": "transaction_id", "type": "string", "required": True},
                    {"name": "account_id", "type": "string", "required": True},
                    {"name": "amount", "type": "decimal", "required": True},
                    {"name": "currency", "type": "string", "required": True},
                    {"name": "transaction_date", "type": "datetime", "required": True},
                    {"name": "transaction_type", "type": "string", "required": True},
                    {"name": "counterparty", "type": "string", "required": False}
                ],
                "constraints": {
                    "unique_keys": ["transaction_id"],
                    "not_null": ["transaction_id", "account_id", "amount", "currency", "transaction_date"]
                }
            },
            "quality_requirements": {
                "completeness": {"threshold": 99.0, "critical": True},
                "accuracy": {"threshold": 99.5, "critical": True},
                "consistency": {"threshold": 95.0, "critical": True},
                "timeliness": {"max_age_hours": 1, "critical": True}
            },
            "sla_requirements": {
                "availability": {"threshold": 99.9, "unit": "percent"},
                "response_time": {"threshold": 1000, "unit": "milliseconds"},
                "throughput": {"min_records_per_hour": 50000}
            }
        }
        contract = self.create_contract(scenario, contract_data)
        if not contract:
            return False
        
        # Ativar e executar múltiplas vezes
        self.activate_contract(scenario, contract["id"], contract["name"])
        self.validate_contract(scenario, contract["id"], contract["name"])
        self.execute_contract(scenario, contract["id"], contract["name"], "daily_report")
        self.execute_contract(scenario, contract["id"], contract["name"], "regulatory_report")
        self.execute_contract(scenario, contract["id"], contract["name"], "audit_trail")
        
        return True
    
    def scenario_product_catalog(self):
        """Cenário 3: Catálogo de Produtos"""
        scenario = "PRODUCT_CATALOG"
        print(f"\n🎯 CENÁRIO 3: {scenario}")
        print("-" * 50)
        
        # Criar entidade de produtos
        entity_data = {
            "name": "product_catalog",
            "description": "Catálogo de produtos para e-commerce",
            "domain_id": 3,
            "entity_type": "collection",
            "classification": "public"
        }
        entity = self.create_entity(scenario, entity_data)
        if not entity:
            return False
        
        # Contrato de Sincronização
        contract_sync_data = {
            "name": "Contrato de Sincronização de Produtos",
            "description": "Sincronização de catálogo entre sistemas",
            "entity_id": entity["id"],
            "contract_type": "data_synchronization",
            "schema_definition": {
                "fields": [
                    {"name": "product_id", "type": "string", "required": True},
                    {"name": "name", "type": "string", "required": True},
                    {"name": "description", "type": "text", "required": False},
                    {"name": "price", "type": "decimal", "required": True},
                    {"name": "category", "type": "string", "required": True},
                    {"name": "stock_quantity", "type": "integer", "required": True},
                    {"name": "is_active", "type": "boolean", "required": True}
                ]
            },
            "quality_requirements": {
                "completeness": {"threshold": 98.0, "critical": True},
                "accuracy": {"threshold": 95.0, "critical": True}
            },
            "sla_requirements": {
                "availability": {"threshold": 99.0, "unit": "percent"},
                "response_time": {"threshold": 5000, "unit": "milliseconds"}
            }
        }
        contract_sync = self.create_contract(scenario, contract_sync_data)
        if not contract_sync:
            return False
        
        # Contrato de Analytics
        contract_analytics_data = {
            "name": "Contrato de Analytics de Produtos",
            "description": "Análise de performance de produtos",
            "entity_id": entity["id"],
            "contract_type": "product_analytics",
            "schema_definition": {
                "fields": [
                    {"name": "product_id", "type": "string", "required": True},
                    {"name": "views", "type": "integer", "required": False},
                    {"name": "purchases", "type": "integer", "required": False},
                    {"name": "conversion_rate", "type": "decimal", "required": False},
                    {"name": "revenue", "type": "decimal", "required": False}
                ]
            },
            "quality_requirements": {
                "completeness": {"threshold": 85.0, "critical": False},
                "accuracy": {"threshold": 90.0, "critical": True}
            },
            "sla_requirements": {
                "availability": {"threshold": 95.0, "unit": "percent"},
                "response_time": {"threshold": 10000, "unit": "milliseconds"}
            }
        }
        contract_analytics = self.create_contract(scenario, contract_analytics_data)
        if not contract_analytics:
            return False
        
        # Ativar e executar ambos contratos
        for contract in [contract_sync, contract_analytics]:
            self.activate_contract(scenario, contract["id"], contract["name"])
            self.validate_contract(scenario, contract["id"], contract["name"])
            
            if "sync" in contract["name"].lower():
                self.execute_contract(scenario, contract["id"], contract["name"], "full_sync")
                self.execute_contract(scenario, contract["id"], contract["name"], "incremental_sync")
            else:
                self.execute_contract(scenario, contract["id"], contract["name"], "daily_analytics")
                self.execute_contract(scenario, contract["id"], contract["name"], "weekly_report")
        
        return True
    
    def get_final_dashboard(self) -> Dict[str, Any]:
        """Obter dashboard final"""
        try:
            response = self.session.get(f"{self.base_url}/api/v4/dashboard", timeout=TIMEOUT)
            if response.status_code == 200:
                dashboard = response.json()
                print("\n📊 DASHBOARD FINAL:")
                print(json.dumps(dashboard, indent=2, default=str))
                return dashboard
            return None
        except Exception as e:
            print(f"Erro ao obter dashboard: {e}")
            return None
    
    def run_extended_journey(self) -> bool:
        """Executar jornada estendida"""
        print("🚀 INICIANDO JORNADA ESTENDIDA - MÚLTIPLOS CONTRATOS E VERSÕES")
        print("=" * 70)
        
        success = True
        
        # Executar cenários
        if not self.scenario_customer_analytics():
            success = False
        
        if not self.scenario_financial_reporting():
            success = False
        
        if not self.scenario_product_catalog():
            success = False
        
        # Dashboard final
        dashboard = self.get_final_dashboard()
        
        # Resumo final
        self.results["end_time"] = datetime.now().isoformat()
        self.results["success"] = success
        self.results["summary"] = {
            "total_entities": len(self.results["entities"]),
            "total_contracts": len(self.results["contracts"]),
            "total_executions": len(self.results["executions"]),
            "scenarios_completed": len(set(s["scenario"] for s in self.results["scenarios"] if s["success"])),
            "final_dashboard": dashboard
        }
        
        print("\n" + "=" * 70)
        if success:
            print("🎉 JORNADA ESTENDIDA EXECUTADA COM SUCESSO!")
        else:
            print("⚠️ JORNADA ESTENDIDA COMPLETADA COM ALGUNS PROBLEMAS")
        print("=" * 70)
        
        return success
    
    def save_results(self, filename: str = "extended_journey_results.json"):
        """Salvar resultados em arquivo"""
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False, default=str)
        print(f"📄 Resultados salvos em: {filename}")


def main():
    """Função principal"""
    tester = ExtendedJourneyTester(BASE_URL)
    
    try:
        success = tester.run_extended_journey()
        tester.save_results("extended_journey_results_v5.json")
        
        print(f"\n📊 RESUMO FINAL:")
        print(f"   Entidades criadas: {len(tester.results['entities'])}")
        print(f"   Contratos criados: {len(tester.results['contracts'])}")
        print(f"   Execuções realizadas: {len(tester.results['executions'])}")
        print(f"   Cenários testados: {len(set(s['scenario'] for s in tester.results['scenarios']))}")
        
        if success:
            print("\n✅ JORNADA ESTENDIDA EXECUTADA COM SUCESSO!")
            print("📊 Todos os cenários foram concluídos corretamente")
        else:
            print("\n⚠️ JORNADA COMPLETADA COM ALGUNS PROBLEMAS")
            print("🔍 Verifique os logs para identificar issues")
        
        return success
        
    except KeyboardInterrupt:
        print("\n⏹️ Jornada interrompida pelo usuário")
        return False
    except Exception as e:
        print(f"\n💥 Erro fatal: {str(e)}")
        return False


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)

