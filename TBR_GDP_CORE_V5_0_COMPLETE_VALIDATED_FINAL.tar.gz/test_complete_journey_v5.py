"""
TBR GDP Core v5.0 - Teste da Jornada Completa
Author: Carlos Morais <carlos.morais@f1rst.com.br>

Teste end-to-end da jornada completa de contratos de dados.
"""

import requests
import json
import time
from datetime import datetime
from typing import Dict, Any, List

# Configurações
BASE_URL = "http://localhost:8002"
TIMEOUT = 30

class JourneyTester:
    """Testador da jornada completa"""
    
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.session = requests.Session()
        self.results = {
            "start_time": datetime.now().isoformat(),
            "steps": [],
            "summary": {},
            "success": False
        }
    
    def log_step(self, step_name: str, success: bool, data: Dict[str, Any] = None, error: str = None):
        """Registrar passo da jornada"""
        step = {
            "step": step_name,
            "timestamp": datetime.now().isoformat(),
            "success": success,
            "data": data,
            "error": error
        }
        self.results["steps"].append(step)
        
        status = "✅" if success else "❌"
        print(f"{status} {step_name}")
        if data:
            print(f"   Data: {json.dumps(data, indent=2, default=str)}")
        if error:
            print(f"   Error: {error}")
        print()
    
    def test_health_check(self) -> bool:
        """Testar health check"""
        try:
            response = self.session.get(f"{self.base_url}/health", timeout=TIMEOUT)
            if response.status_code == 200:
                data = response.json()
                self.log_step("Health Check", True, data)
                return True
            else:
                self.log_step("Health Check", False, error=f"Status: {response.status_code}")
                return False
        except Exception as e:
            self.log_step("Health Check", False, error=str(e))
            return False
    
    def create_entity(self) -> Dict[str, Any]:
        """Criar entidade de dados"""
        try:
            entity_data = {
                "name": "customer_profiles",
                "description": "Perfis consolidados de clientes para análise de comportamento",
                "domain_id": 1,
                "entity_type": "table",
                "classification": "confidential"
            }
            
            response = self.session.post(
                f"{self.base_url}/api/v4/entities",
                json=entity_data,
                timeout=TIMEOUT
            )
            
            if response.status_code == 201:
                entity = response.json()
                self.log_step("Criar Entidade", True, entity)
                return entity
            else:
                self.log_step("Criar Entidade", False, error=f"Status: {response.status_code}, Response: {response.text}")
                return None
        except Exception as e:
            self.log_step("Criar Entidade", False, error=str(e))
            return None
    
    def create_contract(self, entity_id: int) -> Dict[str, Any]:
        """Criar contrato de dados"""
        try:
            contract_data = {
                "name": "Contrato de Análise de Clientes",
                "description": "Contrato para análise de comportamento de clientes com foco em segmentação e personalização",
                "entity_id": entity_id,
                "contract_type": "data_analysis",
                "schema_definition": {
                    "fields": [
                        {"name": "customer_id", "type": "integer", "required": True},
                        {"name": "name", "type": "string", "required": True},
                        {"name": "email", "type": "string", "required": True},
                        {"name": "age", "type": "integer", "required": False},
                        {"name": "segment", "type": "string", "required": False}
                    ],
                    "constraints": {
                        "unique_keys": ["customer_id"],
                        "not_null": ["customer_id", "name", "email"]
                    }
                },
                "quality_requirements": {
                    "completeness": {"threshold": 95.0, "critical": True},
                    "accuracy": {"threshold": 90.0, "critical": True},
                    "consistency": {"threshold": 85.0, "critical": False},
                    "timeliness": {"max_age_hours": 24, "critical": True}
                },
                "sla_requirements": {
                    "availability": {"threshold": 99.5, "unit": "percent"},
                    "response_time": {"threshold": 2000, "unit": "milliseconds"},
                    "throughput": {"min_records_per_hour": 10000}
                }
            }
            
            response = self.session.post(
                f"{self.base_url}/api/v4/contracts",
                json=contract_data,
                timeout=TIMEOUT
            )
            
            if response.status_code == 201:
                contract = response.json()
                self.log_step("Criar Contrato", True, contract)
                return contract
            else:
                self.log_step("Criar Contrato", False, error=f"Status: {response.status_code}, Response: {response.text}")
                return None
        except Exception as e:
            self.log_step("Criar Contrato", False, error=str(e))
            return None
    
    def activate_contract(self, contract_id: int) -> bool:
        """Ativar contrato"""
        try:
            response = self.session.put(
                f"{self.base_url}/api/v4/contracts/{contract_id}/activate",
                timeout=TIMEOUT
            )
            
            if response.status_code == 200:
                result = response.json()
                self.log_step("Ativar Contrato", True, result)
                return True
            else:
                self.log_step("Ativar Contrato", False, error=f"Status: {response.status_code}, Response: {response.text}")
                return False
        except Exception as e:
            self.log_step("Ativar Contrato", False, error=str(e))
            return False
    
    def execute_contract(self, contract_id: int) -> Dict[str, Any]:
        """Executar contrato"""
        try:
            execution_data = {
                "execution_type": "data_analysis"
            }
            
            response = self.session.post(
                f"{self.base_url}/api/v4/contracts/{contract_id}/execute",
                json=execution_data,
                timeout=TIMEOUT
            )
            
            if response.status_code == 201:
                execution = response.json()
                self.log_step("Executar Contrato", True, execution)
                return execution
            else:
                self.log_step("Executar Contrato", False, error=f"Status: {response.status_code}, Response: {response.text}")
                return None
        except Exception as e:
            self.log_step("Executar Contrato", False, error=str(e))
            return None
    
    def validate_contract(self, contract_id: int) -> Dict[str, Any]:
        """Validar contrato"""
        try:
            response = self.session.get(
                f"{self.base_url}/api/v4/contracts/{contract_id}/validate",
                timeout=TIMEOUT
            )
            
            if response.status_code == 200:
                validation = response.json()
                self.log_step("Validar Contrato", True, validation)
                return validation
            else:
                self.log_step("Validar Contrato", False, error=f"Status: {response.status_code}, Response: {response.text}")
                return None
        except Exception as e:
            self.log_step("Validar Contrato", False, error=str(e))
            return None
    
    def list_executions(self, contract_id: int) -> List[Dict[str, Any]]:
        """Listar execuções do contrato"""
        try:
            response = self.session.get(
                f"{self.base_url}/api/v4/contracts/{contract_id}/executions",
                timeout=TIMEOUT
            )
            
            if response.status_code == 200:
                executions = response.json()
                self.log_step("Listar Execuções", True, {"count": len(executions), "executions": executions})
                return executions
            else:
                self.log_step("Listar Execuções", False, error=f"Status: {response.status_code}, Response: {response.text}")
                return []
        except Exception as e:
            self.log_step("Listar Execuções", False, error=str(e))
            return []
    
    def get_dashboard(self) -> Dict[str, Any]:
        """Obter dashboard"""
        try:
            response = self.session.get(
                f"{self.base_url}/api/v4/dashboard",
                timeout=TIMEOUT
            )
            
            if response.status_code == 200:
                dashboard = response.json()
                self.log_step("Dashboard", True, dashboard)
                return dashboard
            else:
                self.log_step("Dashboard", False, error=f"Status: {response.status_code}, Response: {response.text}")
                return None
        except Exception as e:
            self.log_step("Dashboard", False, error=str(e))
            return None
    
    def run_complete_journey(self) -> bool:
        """Executar jornada completa"""
        print("🚀 INICIANDO JORNADA COMPLETA DE CONTRATOS DE DADOS")
        print("=" * 60)
        
        # 1. Health Check
        if not self.test_health_check():
            return False
        
        # 2. Criar Entidade
        entity = self.create_entity()
        if not entity:
            return False
        
        # 3. Criar Contrato
        contract = self.create_contract(entity["id"])
        if not contract:
            return False
        
        # 4. Ativar Contrato
        if not self.activate_contract(contract["id"]):
            return False
        
        # 5. Validar Contrato
        validation = self.validate_contract(contract["id"])
        if not validation:
            return False
        
        # 6. Executar Contrato
        execution = self.execute_contract(contract["id"])
        if not execution:
            return False
        
        # 7. Listar Execuções
        executions = self.list_executions(contract["id"])
        
        # 8. Dashboard
        dashboard = self.get_dashboard()
        
        # Resumo final
        self.results["end_time"] = datetime.now().isoformat()
        self.results["success"] = True
        self.results["summary"] = {
            "entity_created": entity,
            "contract_created": contract,
            "execution_completed": execution,
            "validation_passed": validation.get("is_valid", False) if validation else False,
            "total_executions": len(executions),
            "dashboard_metrics": dashboard
        }
        
        print("=" * 60)
        print("🎉 JORNADA COMPLETA EXECUTADA COM SUCESSO!")
        print("=" * 60)
        
        return True
    
    def save_results(self, filename: str = "journey_results.json"):
        """Salvar resultados em arquivo"""
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False, default=str)
        print(f"📄 Resultados salvos em: {filename}")


def main():
    """Função principal"""
    tester = JourneyTester(BASE_URL)
    
    try:
        success = tester.run_complete_journey()
        tester.save_results("journey_results_v5.json")
        
        if success:
            print("\n✅ JORNADA COMPLETA EXECUTADA COM SUCESSO!")
            print("📊 Todos os passos foram concluídos corretamente")
            print("📄 Resultados detalhados salvos em journey_results_v5.json")
        else:
            print("\n❌ JORNADA FALHOU")
            print("🔍 Verifique os logs para identificar problemas")
        
        return success
        
    except KeyboardInterrupt:
        print("\n⏹️ Jornada interrompida pelo usuário")
        return False
    except Exception as e:
        print(f"\n💥 Erro fatal: {str(e)}")
        return False


if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)

