# 🛠️ Guia de Instalação - TBR GDP Core v4.0

**Autor:** Carlos Morais <carlos.morais@f1rst.com.br>  
**Versão:** 4.0.0  
**Data:** Janeiro 2024  

---

## 📋 Pré-requisitos

### Sistema Operacional
- Ubuntu 22.04+ (recomendado)
- CentOS 8+ ou RHEL 8+
- macOS 12+ (desenvolvimento)
- Windows 11 com WSL2

### Software Base
```bash
# Python 3.11+
python3.11 --version

# PostgreSQL 14+
psql --version

# Git
git --version

# Docker (opcional)
docker --version
```

---

## 🚀 Instalação Passo a Passo

### 1️⃣ Preparação do Ambiente

```bash
# Navegar para o diretório da aplicação
cd tbr-gdpcore-v4-api

# Criar ambiente virtual
python3.11 -m venv venv

# Ativar ambiente virtual
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows

# Verificar ativação
which python  # Deve apontar para o venv
```

### 2️⃣ Instalação do PostgreSQL

#### Ubuntu/Debian
```bash
# Atualizar repositórios
sudo apt update

# Instalar PostgreSQL
sudo apt install -y postgresql postgresql-contrib python3-psycopg2

# Iniciar e habilitar serviço
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Verificar status
sudo systemctl status postgresql
```

#### CentOS/RHEL
```bash
# Instalar PostgreSQL
sudo dnf install -y postgresql postgresql-server python3-psycopg2

# Inicializar banco
sudo postgresql-setup --initdb

# Iniciar e habilitar serviço
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

#### macOS
```bash
# Usando Homebrew
brew install postgresql

# Iniciar serviço
brew services start postgresql
```

### 3️⃣ Configuração do PostgreSQL

```bash
# Criar database
sudo -u postgres createdb tbr_gdp_core_v4

# Criar usuário
sudo -u postgres psql -c "CREATE USER tbr_user WITH PASSWORD 'tbr_password';"

# Conceder privilégios
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE tbr_gdp_core_v4 TO tbr_user;"

# Verificar conexão
psql -h localhost -U tbr_user -d tbr_gdp_core_v4 -c "SELECT version();"
```

### 4️⃣ Instalação de Dependências Python

```bash
# Atualizar pip
pip install --upgrade pip

# Instalar dependências
pip install -r requirements.txt

# Verificar instalações principais
pip show fastapi
pip show psycopg2-binary
pip show uvicorn
```

### 5️⃣ Configuração do Banco de Dados

```bash
# Criar schema das tabelas
python3.11 create_database_schema.py

# Carregar dados de exemplo (828 registros)
python3.11 create_mock_data.py

# Verificar dados carregados
psql -h localhost -U tbr_user -d tbr_gdp_core_v4 -c "
SELECT 
  schemaname,
  tablename,
  n_tup_ins as records
FROM pg_stat_user_tables 
ORDER BY n_tup_ins DESC;"
```

### 6️⃣ Configuração da Aplicação

#### Variáveis de Ambiente
```bash
# Configurar PYTHONPATH
export PYTHONPATH=$(pwd)

# Configurar URL do banco
export DATABASE_URL="postgresql://tbr_user:tbr_password@localhost/tbr_gdp_core_v4"

# Configurar chave JWT (gerar uma segura)
export JWT_SECRET_KEY="your-super-secret-jwt-key-here"

# Configurar ambiente
export ENVIRONMENT="development"
export LOG_LEVEL="INFO"
```

#### Arquivo .env (Alternativa)
```bash
# Criar arquivo de configuração
cat > .env << EOF
DATABASE_URL=postgresql://tbr_user:tbr_password@localhost/tbr_gdp_core_v4
JWT_SECRET_KEY=your-super-secret-jwt-key-here
ENVIRONMENT=development
LOG_LEVEL=INFO
CORS_ORIGINS=["http://localhost:3000", "http://localhost:8080"]
EOF
```

### 7️⃣ Inicialização da Aplicação

```bash
# Iniciar aplicação em modo desenvolvimento
python3.11 -m uvicorn src.governance_api.main:app --host 0.0.0.0 --port 8004 --reload

# Aguardar inicialização (5-10 segundos)
# Verificar logs para confirmar startup
```

---

## ✅ Verificação da Instalação

### 1️⃣ Health Check
```bash
# Testar endpoint de saúde
curl http://localhost:8004/health

# Resposta esperada:
# {"status": "healthy", "timestamp": "2024-01-15T10:30:00Z"}
```

### 2️⃣ Documentação da API
```bash
# Acessar documentação interativa
open http://localhost:8004/docs

# Ou via curl
curl -s http://localhost:8004/docs | head -20
```

### 3️⃣ Teste de Endpoints
```bash
# Testar busca de entidades
curl -s "http://localhost:8004/api/v4/entities/search?limit=5" | jq

# Testar dashboard de qualidade
curl -s "http://localhost:8004/api/v4/quality/dashboard" | jq
```

### 4️⃣ Executar Testes Automatizados
```bash
# Teste completo do sistema
python3.11 test_complete_system_v3_final.py

# Resultado esperado: > 95% de sucesso
```

---

## 🐳 Instalação com Docker

### Dockerfile
```dockerfile
FROM python:3.11-slim

# Instalar dependências do sistema
RUN apt-get update && apt-get install -y \
    postgresql-client \
    && rm -rf /var/lib/apt/lists/*

# Configurar diretório de trabalho
WORKDIR /app

# Copiar e instalar dependências Python
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copiar código da aplicação
COPY . .

# Expor porta
EXPOSE 8004

# Comando de inicialização
CMD ["uvicorn", "src.governance_api.main:app", "--host", "0.0.0.0", "--port", "8004"]
```

### Docker Compose
```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "8004:8004"
    environment:
      - DATABASE_URL=postgresql://tbr_user:tbr_password@db/tbr_gdp_core_v4
      - JWT_SECRET_KEY=your-super-secret-jwt-key-here
      - ENVIRONMENT=production
    depends_on:
      - db
    restart: unless-stopped

  db:
    image: postgres:14
    environment:
      - POSTGRES_DB=tbr_gdp_core_v4
      - POSTGRES_USER=tbr_user
      - POSTGRES_PASSWORD=tbr_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./modelo_governanca_v4_0_final.dbml:/docker-entrypoint-initdb.d/schema.dbml
    ports:
      - "5432:5432"
    restart: unless-stopped

volumes:
  postgres_data:
```

### Comandos Docker
```bash
# Construir e iniciar
docker-compose up -d

# Verificar logs
docker-compose logs -f app

# Parar serviços
docker-compose down

# Rebuild completo
docker-compose down -v && docker-compose up --build -d
```

---

## ⚙️ Configuração para Produção

### 1️⃣ Configurações de Segurança
```bash
# Gerar chave JWT segura
python3 -c "import secrets; print(secrets.token_urlsafe(32))"

# Configurar HTTPS (nginx)
sudo apt install nginx certbot python3-certbot-nginx

# Configurar firewall
sudo ufw allow 80
sudo ufw allow 443
sudo ufw allow 22
sudo ufw enable
```

### 2️⃣ Otimizações de Performance
```bash
# PostgreSQL - editar postgresql.conf
sudo nano /etc/postgresql/14/main/postgresql.conf

# Configurações recomendadas:
shared_buffers = 256MB          # 25% da RAM
work_mem = 4MB
maintenance_work_mem = 64MB
max_connections = 100
effective_cache_size = 1GB      # 75% da RAM
```

### 3️⃣ Configuração de Logs
```bash
# Criar diretório de logs
mkdir -p logs

# Configurar rotação de logs
sudo nano /etc/logrotate.d/tbr-gdp-core

# Conteúdo:
/path/to/tbr-gdpcore-v4-api/logs/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 ubuntu ubuntu
}
```

### 4️⃣ Monitoramento
```bash
# Instalar ferramentas de monitoramento
pip install prometheus-client
pip install psutil

# Configurar alertas básicos
# (implementar conforme necessidade)
```

---

## 🚨 Troubleshooting

### Problema: API não inicia
```bash
# Verificar porta ocupada
lsof -i :8004

# Matar processo se necessário
pkill -f uvicorn

# Verificar logs
tail -f logs/app.log
```

### Problema: Erro de conexão com banco
```bash
# Verificar status do PostgreSQL
sudo systemctl status postgresql

# Reiniciar se necessário
sudo systemctl restart postgresql

# Testar conexão manual
psql -h localhost -U tbr_user -d tbr_gdp_core_v4
```

### Problema: Dependências não instalam
```bash
# Atualizar pip
pip install --upgrade pip

# Limpar cache
pip cache purge

# Instalar com verbose
pip install -r requirements.txt -v
```

### Problema: Performance lenta
```bash
# Verificar queries lentas
sudo -u postgres psql -d tbr_gdp_core_v4 -c "
SELECT query, mean_time, calls 
FROM pg_stat_statements 
WHERE mean_time > 1000 
ORDER BY mean_time DESC 
LIMIT 10;"

# Analisar uso de recursos
top -p $(pgrep -f uvicorn)
```

---

## 📋 Checklist de Instalação

### Pré-instalação
- [ ] Sistema operacional compatível
- [ ] Python 3.11+ instalado
- [ ] PostgreSQL 14+ instalado
- [ ] Portas 8004 e 5432 disponíveis

### Instalação
- [ ] Ambiente virtual criado e ativado
- [ ] Dependências Python instaladas
- [ ] Database e usuário criados
- [ ] Schema do banco criado
- [ ] Dados mocados carregados
- [ ] Variáveis de ambiente configuradas

### Verificação
- [ ] Health check respondendo (200 OK)
- [ ] Documentação acessível (/docs)
- [ ] Endpoints principais funcionando
- [ ] Testes automatizados passando (> 95%)
- [ ] Logs sendo gerados corretamente

### Produção (Opcional)
- [ ] HTTPS configurado
- [ ] Firewall configurado
- [ ] Backup automático configurado
- [ ] Monitoramento implementado
- [ ] Rotação de logs configurada

---

## 📞 Suporte

### Contato
- **Email:** carlos.morais@f1rst.com.br
- **Organização:** F1rst Technology Solutions

### Informações para Suporte
Ao solicitar suporte, inclua:
- Versão do sistema operacional
- Versão do Python e PostgreSQL
- Logs da aplicação (últimas 50 linhas)
- Passos executados antes do problema
- Mensagens de erro completas

### Logs Importantes
```bash
# Logs da aplicação
tail -f logs/app.log

# Logs do PostgreSQL
sudo tail -f /var/log/postgresql/postgresql-14-main.log

# Logs do sistema
journalctl -u postgresql -f
```

---

**🎯 Instalação concluída com sucesso! A plataforma TBR GDP Core v4.0 está pronta para transformar a governança de dados da sua organização!**

