#!/usr/bin/env python3
"""
TBR GDP Core v3.0 - Teste Completo da API
Testes automatizados para todas as funcionalidades avançadas
"""

import requests
import json
import time
import sys
from datetime import datetime
from typing import Dict, List, Any

class TBRGDPCoreV3Tester:
    """Classe para testar todas as funcionalidades da API v3.0"""
    
    def __init__(self, base_url: str = "http://localhost:8003"):
        self.base_url = base_url
        self.session = requests.Session()
        self.test_results = []
        self.start_time = datetime.now()
        
    def log_test(self, test_name: str, success: bool, response_time: float, details: Dict = None):
        """Registrar resultado do teste"""
        result = {
            "test_name": test_name,
            "success": success,
            "response_time_ms": round(response_time * 1000, 2),
            "timestamp": datetime.now().isoformat(),
            "details": details or {}
        }
        self.test_results.append(result)
        
        status = "✅ PASS" if success else "❌ FAIL"
        print(f"{status} {test_name} ({result['response_time_ms']}ms)")
        
        if not success and details:
            print(f"   Error: {details.get('error', 'Unknown error')}")
    
    def test_health_check(self):
        """Testar endpoint de health check"""
        try:
            start = time.time()
            response = self.session.get(f"{self.base_url}/health")
            end = time.time()
            
            success = response.status_code == 200
            data = response.json() if success else None
            
            details = {
                "status_code": response.status_code,
                "response": data
            }
            
            if success:
                details["version"] = data.get("version")
                details["architecture"] = data.get("architecture")
                details["databases"] = data.get("databases")
            else:
                details["error"] = f"HTTP {response.status_code}"
                
            self.log_test("Health Check", success, end - start, details)
            return success
            
        except Exception as e:
            self.log_test("Health Check", False, 0, {"error": str(e)})
            return False
    
    def test_root_endpoint(self):
        """Testar endpoint raiz"""
        try:
            start = time.time()
            response = self.session.get(f"{self.base_url}/")
            end = time.time()
            
            success = response.status_code == 200
            data = response.json() if success else None
            
            details = {
                "status_code": response.status_code,
                "response": data
            }
            
            if success:
                details["version"] = data.get("version")
                details["features"] = data.get("features")
                details["domains_count"] = len(data.get("domains", {}))
            else:
                details["error"] = f"HTTP {response.status_code}"
                
            self.log_test("Root Endpoint", success, end - start, details)
            return success
            
        except Exception as e:
            self.log_test("Root Endpoint", False, 0, {"error": str(e)})
            return False
    
    def test_entities_endpoints(self):
        """Testar endpoints de entidades"""
        endpoints = [
            ("GET", "/api/v3/entities", "List Entities"),
            ("GET", "/api/v3/entities/1", "Get Entity"),
            ("GET", "/api/v3/entities/1/lineage", "Get Entity Lineage"),
            ("GET", "/api/v3/entities/search", "Search Entities"),
            ("GET", "/api/v3/entities/1/access-log", "Get Access Log")
        ]
        
        results = []
        for method, endpoint, test_name in endpoints:
            try:
                start = time.time()
                if method == "GET":
                    response = self.session.get(f"{self.base_url}{endpoint}")
                end = time.time()
                
                success = response.status_code == 200
                details = {
                    "status_code": response.status_code,
                    "endpoint": endpoint
                }
                
                if success:
                    data = response.json()
                    if isinstance(data, list):
                        details["items_count"] = len(data)
                    elif isinstance(data, dict):
                        details["response_keys"] = list(data.keys())
                else:
                    details["error"] = f"HTTP {response.status_code}"
                
                self.log_test(f"Entities - {test_name}", success, end - start, details)
                results.append(success)
                
            except Exception as e:
                self.log_test(f"Entities - {test_name}", False, 0, {"error": str(e)})
                results.append(False)
        
        return all(results)
    
    def test_contracts_endpoints(self):
        """Testar endpoints avançados de contratos"""
        endpoints = [
            ("GET", "/api/v3/contracts", "List Contracts"),
            ("GET", "/api/v3/contracts/1", "Get Contract"),
            ("GET", "/api/v3/contracts/1/violations", "Get Contract Violations"),
            ("GET", "/api/v3/contracts/1/metrics", "Get Contract Metrics"),
            ("GET", "/api/v3/contracts/1/lineage", "Get Contract Lineage"),
            ("GET", "/api/v3/contracts/1/masking/preview?user_role=admin", "Preview Data Masking Admin"),
            ("GET", "/api/v3/contracts/1/masking/preview?user_role=data_analyst", "Preview Data Masking Analyst")
        ]
        
        results = []
        for method, endpoint, test_name in endpoints:
            try:
                start = time.time()
                response = self.session.get(f"{self.base_url}{endpoint}")
                end = time.time()
                
                success = response.status_code == 200
                details = {
                    "status_code": response.status_code,
                    "endpoint": endpoint
                }
                
                if success:
                    data = response.json()
                    if isinstance(data, list):
                        details["items_count"] = len(data)
                    elif isinstance(data, dict):
                        details["response_keys"] = list(data.keys())
                        # Verificar funcionalidades específicas
                        if "masking_rules_applied" in data:
                            details["masking_rules"] = len(data.get("masking_rules_applied", []))
                        if "sla_compliance" in data:
                            details["sla_metrics"] = list(data["sla_compliance"].keys())
                        if "lineage" in endpoint and "upstream_lineage" in data:
                            details["lineage_levels"] = len(data.get("upstream_lineage", []))
                else:
                    details["error"] = f"HTTP {response.status_code}"
                
                self.log_test(f"Contracts - {test_name}", success, end - start, details)
                results.append(success)
                
            except Exception as e:
                self.log_test(f"Contracts - {test_name}", False, 0, {"error": str(e)})
                results.append(False)
        
        return all(results)
    
    def test_quality_endpoints(self):
        """Testar endpoints avançados de qualidade"""
        endpoints = [
            ("GET", "/api/v3/quality/rules", "List Quality Rules"),
            ("GET", "/api/v3/quality/rules/1", "Get Quality Rule"),
            ("GET", "/api/v3/quality/checks", "List Quality Checks"),
            ("GET", "/api/v3/quality/checks/1", "Get Quality Check"),
            ("GET", "/api/v3/quality/issues", "List Quality Issues"),
            ("GET", "/api/v3/quality/dashboard", "Quality Dashboard")
        ]
        
        results = []
        for method, endpoint, test_name in endpoints:
            try:
                start = time.time()
                response = self.session.get(f"{self.base_url}{endpoint}")
                end = time.time()
                
                success = response.status_code == 200
                details = {
                    "status_code": response.status_code,
                    "endpoint": endpoint
                }
                
                if success:
                    data = response.json()
                    if isinstance(data, list):
                        details["items_count"] = len(data)
                    elif isinstance(data, dict):
                        details["response_keys"] = list(data.keys())
                        # Verificar funcionalidades específicas
                        if "quality_dimensions" in data:
                            details["quality_dimensions"] = list(data["quality_dimensions"].keys())
                        if "rule_definition" in data:
                            details["rule_type"] = data.get("rule_type")
                        if "overall_quality_score" in data:
                            details["quality_score"] = data.get("overall_quality_score")
                else:
                    details["error"] = f"HTTP {response.status_code}"
                
                self.log_test(f"Quality - {test_name}", success, end - start, details)
                results.append(success)
                
            except Exception as e:
                self.log_test(f"Quality - {test_name}", False, 0, {"error": str(e)})
                results.append(False)
        
        return all(results)
    
    def test_create_contract(self):
        """Testar criação de contrato"""
        try:
            contract_data = {
                "name": "Contrato de Teste Automatizado",
                "description": "Contrato criado durante teste automatizado",
                "entity_id": 1,
                "provider": "Sistema de Teste",
                "consumer": "Aplicação de Teste",
                "sla_requirements": {
                    "availability": "99.9%",
                    "latency_max": "100ms"
                },
                "quality_rules": [
                    {"field": "test_field", "rule": "not_null", "threshold": 100}
                ],
                "access_permissions": [
                    {"role": "test_user", "permissions": ["read"]}
                ],
                "masking_rules": [
                    {"field": "sensitive_field", "mask_type": "partial"}
                ]
            }
            
            start = time.time()
            response = self.session.post(
                f"{self.base_url}/api/v3/contracts",
                json=contract_data
            )
            end = time.time()
            
            success = response.status_code == 200
            details = {
                "status_code": response.status_code,
                "contract_data": contract_data
            }
            
            if success:
                data = response.json()
                details["created_contract_id"] = data.get("id")
                details["contract_status"] = data.get("status")
            else:
                details["error"] = f"HTTP {response.status_code}"
                if response.text:
                    details["error_detail"] = response.text
            
            self.log_test("Create Contract", success, end - start, details)
            return success
            
        except Exception as e:
            self.log_test("Create Contract", False, 0, {"error": str(e)})
            return False
    
    def test_create_quality_rule(self):
        """Testar criação de regra de qualidade"""
        try:
            rule_data = {
                "name": "Regra de Teste Automatizada",
                "description": "Regra criada durante teste automatizado",
                "entity_id": 1,
                "field_name": "test_field",
                "rule_type": "not_null",
                "rule_definition": {
                    "condition": "IS NOT NULL",
                    "threshold": 100,
                    "threshold_type": "percentage"
                },
                "severity": "high",
                "category": "completeness",
                "automated": True,
                "schedule": "daily"
            }
            
            start = time.time()
            response = self.session.post(
                f"{self.base_url}/api/v3/quality/rules",
                json=rule_data
            )
            end = time.time()
            
            success = response.status_code == 200
            details = {
                "status_code": response.status_code,
                "rule_data": rule_data
            }
            
            if success:
                data = response.json()
                details["created_rule_id"] = data.get("id")
                details["rule_type"] = data.get("rule_type")
            else:
                details["error"] = f"HTTP {response.status_code}"
                if response.text:
                    details["error_detail"] = response.text
            
            self.log_test("Create Quality Rule", success, end - start, details)
            return success
            
        except Exception as e:
            self.log_test("Create Quality Rule", False, 0, {"error": str(e)})
            return False
    
    def test_permission_validation(self):
        """Testar validação de permissões"""
        try:
            permission_request = {
                "user_role": "data_analyst",
                "operation": "read",
                "context": {
                    "time": "business_hours",
                    "purpose": "analysis"
                }
            }
            
            start = time.time()
            response = self.session.post(
                f"{self.base_url}/api/v3/contracts/1/permissions/validate",
                json=permission_request
            )
            end = time.time()
            
            success = response.status_code == 200
            details = {
                "status_code": response.status_code,
                "permission_request": permission_request
            }
            
            if success:
                data = response.json()
                details["access_granted"] = data.get("access_granted")
                details["permissions"] = data.get("permissions")
                details["masking_applied"] = data.get("masking_applied")
            else:
                details["error"] = f"HTTP {response.status_code}"
            
            self.log_test("Permission Validation", success, end - start, details)
            return success
            
        except Exception as e:
            self.log_test("Permission Validation", False, 0, {"error": str(e)})
            return False
    
    def test_execute_quality_check(self):
        """Testar execução de verificação de qualidade"""
        try:
            check_request = {
                "rule_id": 1,
                "entity_id": 1
            }
            
            start = time.time()
            response = self.session.post(
                f"{self.base_url}/api/v3/quality/checks/execute",
                json=check_request
            )
            end = time.time()
            
            success = response.status_code == 200
            details = {
                "status_code": response.status_code,
                "check_request": check_request
            }
            
            if success:
                data = response.json()
                details["check_id"] = data.get("check_id")
                details["status"] = data.get("status")
                details["progress"] = data.get("progress")
            else:
                details["error"] = f"HTTP {response.status_code}"
            
            self.log_test("Execute Quality Check", success, end - start, details)
            return success
            
        except Exception as e:
            self.log_test("Execute Quality Check", False, 0, {"error": str(e)})
            return False
    
    def run_all_tests(self):
        """Executar todos os testes"""
        print("🚀 Iniciando Testes Completos do TBR GDP Core v3.0")
        print("=" * 60)
        
        # Testes básicos
        print("\n📋 Testes Básicos:")
        basic_tests = [
            self.test_health_check(),
            self.test_root_endpoint()
        ]
        
        # Testes de domínios
        print("\n🏗️ Testes de Domínios:")
        domain_tests = [
            self.test_entities_endpoints(),
            self.test_contracts_endpoints(),
            self.test_quality_endpoints()
        ]
        
        # Testes de funcionalidades avançadas
        print("\n⚡ Testes de Funcionalidades Avançadas:")
        advanced_tests = [
            self.test_create_contract(),
            self.test_create_quality_rule(),
            self.test_permission_validation(),
            self.test_execute_quality_check()
        ]
        
        # Calcular estatísticas
        all_tests = basic_tests + domain_tests + advanced_tests
        total_tests = len(self.test_results)
        passed_tests = sum(1 for result in self.test_results if result["success"])
        failed_tests = total_tests - passed_tests
        success_rate = (passed_tests / total_tests * 100) if total_tests > 0 else 0
        
        # Calcular tempo total
        end_time = datetime.now()
        total_time = (end_time - self.start_time).total_seconds()
        
        # Calcular tempo médio de resposta
        response_times = [result["response_time_ms"] for result in self.test_results if result["response_time_ms"] > 0]
        avg_response_time = sum(response_times) / len(response_times) if response_times else 0
        
        # Resumo final
        print("\n" + "=" * 60)
        print("📊 RESUMO DOS TESTES")
        print("=" * 60)
        print(f"✅ Testes Executados: {total_tests}")
        print(f"✅ Testes Aprovados: {passed_tests}")
        print(f"❌ Testes Falharam: {failed_tests}")
        print(f"📈 Taxa de Sucesso: {success_rate:.1f}%")
        print(f"⏱️ Tempo Total: {total_time:.2f}s")
        print(f"⚡ Tempo Médio de Resposta: {avg_response_time:.1f}ms")
        
        # Status final
        if success_rate >= 80:
            print(f"\n🎉 TESTES APROVADOS! Taxa de sucesso: {success_rate:.1f}%")
            status = "PASSED"
        else:
            print(f"\n⚠️ TESTES COM PROBLEMAS! Taxa de sucesso: {success_rate:.1f}%")
            status = "FAILED"
        
        # Salvar resultados
        results_summary = {
            "test_suite": "TBR GDP Core v3.0 Complete Test",
            "execution_time": self.start_time.isoformat(),
            "total_duration_seconds": total_time,
            "summary": {
                "total_tests": total_tests,
                "passed_tests": passed_tests,
                "failed_tests": failed_tests,
                "success_rate": success_rate,
                "avg_response_time_ms": avg_response_time,
                "status": status
            },
            "test_categories": {
                "basic_tests": {
                    "count": len(basic_tests),
                    "passed": sum(basic_tests),
                    "success_rate": sum(basic_tests) / len(basic_tests) * 100 if basic_tests else 0
                },
                "domain_tests": {
                    "count": len(domain_tests),
                    "passed": sum(domain_tests),
                    "success_rate": sum(domain_tests) / len(domain_tests) * 100 if domain_tests else 0
                },
                "advanced_tests": {
                    "count": len(advanced_tests),
                    "passed": sum(advanced_tests),
                    "success_rate": sum(advanced_tests) / len(advanced_tests) * 100 if advanced_tests else 0
                }
            },
            "detailed_results": self.test_results
        }
        
        # Salvar em arquivo
        with open("test_results_v3_complete.json", "w", encoding="utf-8") as f:
            json.dump(results_summary, f, indent=2, ensure_ascii=False)
        
        print(f"\n💾 Resultados salvos em: test_results_v3_complete.json")
        
        return success_rate >= 80

def main():
    """Função principal"""
    if len(sys.argv) > 1:
        base_url = sys.argv[1]
    else:
        base_url = "http://localhost:8003"
    
    print(f"🔗 URL Base: {base_url}")
    
    tester = TBRGDPCoreV3Tester(base_url)
    success = tester.run_all_tests()
    
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()

