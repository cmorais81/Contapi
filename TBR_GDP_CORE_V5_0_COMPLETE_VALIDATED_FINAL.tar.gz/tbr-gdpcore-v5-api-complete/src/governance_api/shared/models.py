"""
TBR GDP Core v1.0 - Modelos Base Compartilhados
Modelos SQLAlchemy e Pydantic base para todos os domínios
"""

from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, Dict, Any, List
import uuid

Base = declarative_base()

class BaseEntity(Base):
    """Modelo base para todas as entidades SQLAlchemy"""
    __abstract__ = True
    
    id = Column(Integer, primary_key=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    created_by = Column(String(100))
    updated_by = Column(String(100))
    is_active = Column(Boolean, default=True, nullable=False)

class AuditableEntity(BaseEntity):
    """Modelo base com auditoria completa"""
    __abstract__ = True
    
    version = Column(Integer, default=1, nullable=False)
    is_deleted = Column(Boolean, default=False, nullable=False)
    deleted_at = Column(DateTime)
    deleted_by = Column(String(100))

class MetadataEntity(AuditableEntity):
    """Modelo base com metadados flexíveis"""
    __abstract__ = True
    
    meta_data = Column(JSON)
    tags = Column(JSON)

# Schemas Pydantic Base
class BaseSchema(BaseModel):
    """Schema base para validação"""
    
    class Config:
        from_attributes = True
        validate_assignment = True
        use_enum_values = True

class TimestampSchema(BaseSchema):
    """Schema com timestamps"""
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

class AuditSchema(BaseSchema):
    """Schema com auditoria"""
    created_by: Optional[str] = None
    updated_by: Optional[str] = None
    version: Optional[int] = 1
    is_active: Optional[bool] = True

class MetadataSchema(BaseSchema):
    """Schema com metadados"""
    meta_data: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = None

class CreateSchema(BaseSchema):
    """Schema base para criação"""
    pass

class UpdateSchema(BaseSchema):
    """Schema base para atualização"""
    pass

class ResponseSchema(BaseSchema):
    """Schema base para resposta"""
    id: int
    created_at: datetime
    updated_at: datetime
    created_by: Optional[str] = None
    updated_by: Optional[str] = None
    is_active: bool = True

class PaginationSchema(BaseSchema):
    """Schema para paginação"""
    page: int = Field(default=1, ge=1)
    size: int = Field(default=20, ge=1, le=100)
    total: Optional[int] = None
    pages: Optional[int] = None

class FilterSchema(BaseSchema):
    """Schema base para filtros"""
    search: Optional[str] = None
    is_active: Optional[bool] = None
    created_after: Optional[datetime] = None
    created_before: Optional[datetime] = None

class ErrorSchema(BaseSchema):
    """Schema para erros"""
    error: str
    message: str
    details: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class SuccessSchema(BaseSchema):
    """Schema para sucesso"""
    success: bool = True
    message: str
    data: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)

# Utilitários
def generate_uuid() -> str:
    """Gerar UUID único"""
    return str(uuid.uuid4())

def get_current_timestamp() -> datetime:
    """Obter timestamp atual"""
    return datetime.utcnow()

class StatusEnum:
    """Enums de status comuns"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    DRAFT = "draft"
    PUBLISHED = "published"
    ARCHIVED = "archived"

class SeverityEnum:
    """Enums de severidade"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class ClassificationEnum:
    """Enums de classificação"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"

