"""
TBR GDP Core v1.0 - Configurações Centrais
Configurações da aplicação e ambiente
"""

from pydantic_settings import BaseSettings
from typing import Optional
import os

class Settings(BaseSettings):
    """Configurações da aplicação"""
    
    # Informações da aplicação
    app_name: str = "TBR GDP Core"
    app_version: str = "1.0.0"
    app_description: str = "Plataforma de Governança de Dados"
    
    # Configurações do servidor
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False
    
    # Database
    database_url: str = "postgresql://user:password@localhost:5432/governance_db"
    database_echo: bool = False
    
    # Segurança
    secret_key: str = "your-secret-key-here"
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # CORS
    cors_origins: list = ["*"]
    
    # Logging
    log_level: str = "INFO"
    
    # Cache
    redis_url: Optional[str] = None
    cache_ttl: int = 3600
    
    # Monitoramento
    enable_metrics: bool = True
    metrics_port: int = 9090
    
    # Integração
    external_api_timeout: int = 30
    max_retries: int = 3
    
    class Config:
        env_file = ".env"
        case_sensitive = False

# Instância global das configurações
settings = Settings()

# Configurações específicas por ambiente
def get_database_url() -> str:
    """Retorna URL do banco de dados"""
    return settings.database_url

def get_cors_origins() -> list:
    """Retorna origens permitidas para CORS"""
    if isinstance(settings.cors_origins, str):
        return [origin.strip() for origin in settings.cors_origins.split(",")]
    return settings.cors_origins

def is_development() -> bool:
    """Verifica se está em ambiente de desenvolvimento"""
    return settings.debug

def is_production() -> bool:
    """Verifica se está em ambiente de produção"""
    return not settings.debug

