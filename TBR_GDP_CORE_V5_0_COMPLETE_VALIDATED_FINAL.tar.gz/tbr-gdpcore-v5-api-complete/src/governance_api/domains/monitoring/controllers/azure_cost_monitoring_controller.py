"""
TBR GDP Core v3.0 - Controller de Monitoramento de Custos Azure
Monitoramento de custos, otimização e alertas para recursos Azure
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Path, Body
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
import logging
from datetime import datetime, timedelta
import uuid
from decimal import Decimal

from governance_api.core.database import get_db
from governance_api.shared.models import PaginationSchema, FilterSchema, SuccessSchema

# Configurar logging
logger = logging.getLogger(__name__)

# Criar router
router = APIRouter()

# Simulador de dados de custos Azure (usando metadata das tabelas existentes)
azure_cost_data = {
    "subscriptions": [
        {
            "subscription_id": "12345678-1234-1234-1234-123456789012",
            "subscription_name": "TBR-GDP-Core-Production",
            "resource_group": "rg-tbr-gdp-core-prod"
        },
        {
            "subscription_id": "87654321-4321-4321-4321-210987654321", 
            "subscription_name": "TBR-GDP-Core-Development",
            "resource_group": "rg-tbr-gdp-core-dev"
        }
    ],
    "cost_centers": ["Data Platform", "Analytics", "Governance", "Infrastructure"]
}

class AzureCostMonitor:
    """Monitor de custos Azure usando tabelas existentes para armazenar métricas"""
    
    def __init__(self):
        self.cost_alerts = []
        self.budget_thresholds = {
            "monthly_budget": 10000.00,
            "daily_budget": 333.33,
            "alert_threshold_percent": 80
        }
        self.cost_optimization_enabled = True
    
    def calculate_cost_trends(self, period_days: int = 30):
        """Calcular tendências de custo"""
        base_daily_cost = 285.50
        trend_data = []
        
        for i in range(period_days):
            date = datetime.utcnow() - timedelta(days=period_days - i - 1)
            # Simular variação de custos
            daily_variation = (i % 7) * 15.25 + (i % 3) * 8.75
            daily_cost = base_daily_cost + daily_variation
            
            trend_data.append({
                "date": date.strftime("%Y-%m-%d"),
                "cost_usd": round(daily_cost, 2),
                "cost_brl": round(daily_cost * 5.25, 2),
                "resource_breakdown": {
                    "compute": round(daily_cost * 0.45, 2),
                    "storage": round(daily_cost * 0.25, 2),
                    "networking": round(daily_cost * 0.15, 2),
                    "database": round(daily_cost * 0.10, 2),
                    "other": round(daily_cost * 0.05, 2)
                }
            })
        
        return trend_data

# Instância global do monitor
azure_cost_monitor = AzureCostMonitor()

@router.get("/costs/current", response_model=Dict)
async def get_current_costs(
    subscription_id: Optional[str] = Query(None, description="ID da subscription Azure"),
    resource_group: Optional[str] = Query(None, description="Grupo de recursos"),
    cost_center: Optional[str] = Query(None, description="Centro de custo"),
    currency: str = Query("USD", description="Moeda (USD, BRL)"),
    db: Session = Depends(get_db)
):
    """Obter custos atuais dos recursos Azure"""
    logger.info(f"Obtendo custos atuais - subscription: {subscription_id}")
    
    current_costs = {
        "timestamp": datetime.utcnow().isoformat(),
        "currency": currency,
        "billing_period": {
            "start_date": datetime.utcnow().replace(day=1).strftime("%Y-%m-%d"),
            "end_date": datetime.utcnow().strftime("%Y-%m-%d"),
            "days_in_period": datetime.utcnow().day
        },
        "total_cost": {
            "current_month": 8567.45 if currency == "USD" else 44979.11,
            "yesterday": 285.50 if currency == "USD" else 1498.88,
            "today_so_far": 156.75 if currency == "USD" else 822.94
        },
        "cost_by_service": [
            {
                "service_name": "Azure Database for PostgreSQL",
                "cost": 2890.25 if currency == "USD" else 15174.81,
                "percentage": 33.7,
                "trend": "stable",
                "optimization_potential": "medium"
            },
            {
                "service_name": "Azure Kubernetes Service",
                "cost": 2145.80 if currency == "USD" else 11265.45,
                "percentage": 25.1,
                "trend": "increasing",
                "optimization_potential": "high"
            },
            {
                "service_name": "Azure Storage",
                "cost": 1567.30 if currency == "USD" else 8228.33,
                "percentage": 18.3,
                "trend": "stable",
                "optimization_potential": "low"
            },
            {
                "service_name": "Azure Application Gateway",
                "cost": 1234.10 if currency == "USD" else 6479.03,
                "percentage": 14.4,
                "trend": "decreasing",
                "optimization_potential": "medium"
            },
            {
                "service_name": "Azure Monitor",
                "cost": 730.00 if currency == "USD" else 3832.50,
                "percentage": 8.5,
                "trend": "stable",
                "optimization_potential": "low"
            }
        ],
        "cost_by_resource_group": [
            {
                "resource_group": "rg-tbr-gdp-core-prod",
                "cost": 6854.96 if currency == "USD" else 35988.54,
                "percentage": 80.0,
                "resource_count": 45
            },
            {
                "resource_group": "rg-tbr-gdp-core-dev",
                "cost": 1712.49 if currency == "USD" else 8990.57,
                "percentage": 20.0,
                "resource_count": 23
            }
        ],
        "budget_status": {
            "monthly_budget": 10000.00 if currency == "USD" else 52500.00,
            "spent_amount": 8567.45 if currency == "USD" else 44979.11,
            "remaining_amount": 1432.55 if currency == "USD" else 7520.89,
            "percentage_used": 85.67,
            "projected_month_end": 9234.78 if currency == "USD" else 48482.60,
            "budget_status": "warning",
            "days_remaining": 30 - datetime.utcnow().day
        }
    }
    
    # Aplicar filtros se especificados
    if subscription_id:
        current_costs["filtered_by"] = {"subscription_id": subscription_id}
    
    if resource_group:
        current_costs["filtered_by"] = current_costs.get("filtered_by", {})
        current_costs["filtered_by"]["resource_group"] = resource_group
        # Filtrar custos por resource group
        rg_cost = next((rg for rg in current_costs["cost_by_resource_group"] 
                       if rg["resource_group"] == resource_group), None)
        if rg_cost:
            current_costs["total_cost"]["current_month"] = rg_cost["cost"]
    
    return current_costs

@router.get("/costs/trends", response_model=Dict)
async def get_cost_trends(
    period: str = Query("30d", description="Período: 7d, 30d, 90d"),
    granularity: str = Query("daily", description="Granularidade: daily, weekly, monthly"),
    service_name: Optional[str] = Query(None, description="Filtrar por serviço específico"),
    currency: str = Query("USD", description="Moeda (USD, BRL)"),
    db: Session = Depends(get_db)
):
    """Obter tendências de custos ao longo do tempo"""
    logger.info(f"Obtendo tendências de custos - período: {period}")
    
    period_days = {"7d": 7, "30d": 30, "90d": 90}[period]
    trend_data = azure_cost_monitor.calculate_cost_trends(period_days)
    
    # Converter para BRL se necessário
    if currency == "BRL":
        for day in trend_data:
            day["cost_usd"] = day["cost_brl"]
            for service, cost in day["resource_breakdown"].items():
                day["resource_breakdown"][service] = round(cost * 5.25, 2)
    
    # Calcular estatísticas
    costs = [day["cost_usd"] for day in trend_data]
    avg_cost = sum(costs) / len(costs)
    min_cost = min(costs)
    max_cost = max(costs)
    
    # Calcular tendência
    if len(costs) >= 2:
        recent_avg = sum(costs[-7:]) / min(7, len(costs))
        older_avg = sum(costs[:-7]) / max(1, len(costs) - 7) if len(costs) > 7 else avg_cost
        trend_direction = "increasing" if recent_avg > older_avg * 1.05 else "decreasing" if recent_avg < older_avg * 0.95 else "stable"
        trend_percentage = ((recent_avg - older_avg) / older_avg * 100) if older_avg > 0 else 0
    else:
        trend_direction = "stable"
        trend_percentage = 0
    
    trends = {
        "period": period,
        "granularity": granularity,
        "currency": currency,
        "data_points": trend_data,
        "statistics": {
            "average_daily_cost": round(avg_cost, 2),
            "minimum_daily_cost": round(min_cost, 2),
            "maximum_daily_cost": round(max_cost, 2),
            "total_period_cost": round(sum(costs), 2),
            "trend_direction": trend_direction,
            "trend_percentage": round(trend_percentage, 2)
        },
        "forecasting": {
            "next_30_days_projected": round(avg_cost * 30, 2),
            "month_end_projection": round(sum(costs) + (avg_cost * (30 - len(costs))), 2),
            "confidence_level": 85.5
        },
        "cost_drivers": [
            {
                "factor": "Increased database usage",
                "impact_percentage": 15.2,
                "recommendation": "Consider read replicas for analytics workloads"
            },
            {
                "factor": "Additional compute resources",
                "impact_percentage": 12.8,
                "recommendation": "Implement auto-scaling policies"
            },
            {
                "factor": "Storage growth",
                "impact_percentage": 8.5,
                "recommendation": "Archive old data to cheaper storage tiers"
            }
        ]
    }
    
    return trends

@router.get("/costs/optimization", response_model=Dict)
async def get_cost_optimization_recommendations(
    subscription_id: Optional[str] = Query(None, description="ID da subscription"),
    min_savings_usd: float = Query(50.0, ge=0, description="Economia mínima em USD"),
    db: Session = Depends(get_db)
):
    """Obter recomendações de otimização de custos"""
    logger.info("Obtendo recomendações de otimização de custos")
    
    recommendations = {
        "analysis_timestamp": datetime.utcnow().isoformat(),
        "total_potential_savings": {
            "monthly_usd": 1847.50,
            "monthly_brl": 9699.38,
            "annual_usd": 22170.00,
            "annual_brl": 116392.50
        },
        "recommendations": [
            {
                "id": "opt_001",
                "category": "Compute Optimization",
                "title": "Resize underutilized VMs",
                "description": "3 VMs estão com utilização média abaixo de 20%",
                "potential_savings": {
                    "monthly_usd": 567.80,
                    "monthly_brl": 2981.01
                },
                "effort_level": "low",
                "implementation_time": "1-2 hours",
                "risk_level": "low",
                "affected_resources": [
                    "vm-tbr-gdp-worker-01",
                    "vm-tbr-gdp-worker-02", 
                    "vm-tbr-gdp-analytics-01"
                ],
                "action_required": "Resize from Standard_D4s_v3 to Standard_D2s_v3",
                "priority": "high"
            },
            {
                "id": "opt_002",
                "category": "Storage Optimization",
                "title": "Move old data to Archive tier",
                "description": "1.2TB de dados não acessados há mais de 90 dias",
                "potential_savings": {
                    "monthly_usd": 234.60,
                    "monthly_brl": 1231.65
                },
                "effort_level": "medium",
                "implementation_time": "4-6 hours",
                "risk_level": "low",
                "affected_resources": [
                    "storage-tbr-gdp-logs",
                    "storage-tbr-gdp-backup"
                ],
                "action_required": "Configure lifecycle management policies",
                "priority": "medium"
            },
            {
                "id": "opt_003",
                "category": "Database Optimization",
                "title": "Implement read replicas",
                "description": "Reduzir carga no banco principal com read replicas",
                "potential_savings": {
                    "monthly_usd": 445.20,
                    "monthly_brl": 2337.30
                },
                "effort_level": "high",
                "implementation_time": "1-2 days",
                "risk_level": "medium",
                "affected_resources": [
                    "postgres-tbr-gdp-core-prod"
                ],
                "action_required": "Deploy read replica and update application configuration",
                "priority": "medium"
            },
            {
                "id": "opt_004",
                "category": "Reserved Instances",
                "title": "Purchase Reserved Instances",
                "description": "Commit to 1-year term for stable workloads",
                "potential_savings": {
                    "monthly_usd": 599.90,
                    "monthly_brl": 3149.48
                },
                "effort_level": "low",
                "implementation_time": "30 minutes",
                "risk_level": "low",
                "affected_resources": [
                    "vm-tbr-gdp-core-prod",
                    "postgres-tbr-gdp-core-prod"
                ],
                "action_required": "Purchase 1-year Reserved Instances",
                "priority": "high"
            }
        ],
        "quick_wins": [
            {
                "action": "Delete unused snapshots",
                "savings_usd": 45.30,
                "effort": "5 minutes"
            },
            {
                "action": "Stop dev environment VMs overnight",
                "savings_usd": 156.80,
                "effort": "Configure auto-shutdown"
            }
        ],
        "optimization_score": 72.5,
        "next_review_date": (datetime.utcnow() + timedelta(days=7)).strftime("%Y-%m-%d")
    }
    
    # Filtrar por economia mínima
    recommendations["recommendations"] = [
        rec for rec in recommendations["recommendations"] 
        if rec["potential_savings"]["monthly_usd"] >= min_savings_usd
    ]
    
    return recommendations

@router.post("/costs/alerts", response_model=Dict)
async def create_cost_alert(
    alert_config: Dict = Body(...),
    db: Session = Depends(get_db)
):
    """Criar alerta de custo personalizado"""
    logger.info("Criando alerta de custo")
    
    alert_id = f"alert_{uuid.uuid4().hex[:8]}"
    
    alert = {
        "alert_id": alert_id,
        "name": alert_config.get("name", "Cost Alert"),
        "description": alert_config.get("description", ""),
        "threshold_type": alert_config.get("threshold_type", "absolute"),  # absolute, percentage
        "threshold_value": alert_config.get("threshold_value", 1000.0),
        "currency": alert_config.get("currency", "USD"),
        "period": alert_config.get("period", "monthly"),  # daily, weekly, monthly
        "scope": {
            "subscription_id": alert_config.get("subscription_id"),
            "resource_group": alert_config.get("resource_group"),
            "service_name": alert_config.get("service_name")
        },
        "notification": {
            "email": alert_config.get("notification_email", []),
            "webhook": alert_config.get("webhook_url"),
            "enabled": alert_config.get("notifications_enabled", True)
        },
        "status": "active",
        "created_at": datetime.utcnow().isoformat(),
        "created_by": alert_config.get("created_by", "system"),
        "last_triggered": None,
        "trigger_count": 0
    }
    
    # Simular salvamento
    azure_cost_monitor.cost_alerts.append(alert)
    
    return {
        "message": "Alerta de custo criado com sucesso",
        "alert": alert
    }

@router.get("/costs/alerts", response_model=List[Dict])
async def list_cost_alerts(
    status: Optional[str] = Query(None, description="Filtrar por status"),
    db: Session = Depends(get_db)
):
    """Listar alertas de custo configurados"""
    logger.info("Listando alertas de custo")
    
    # Simular alertas existentes
    alerts = [
        {
            "alert_id": "alert_12345678",
            "name": "Monthly Budget Alert",
            "description": "Alerta quando custo mensal excede 80% do orçamento",
            "threshold_type": "percentage",
            "threshold_value": 80.0,
            "currency": "USD",
            "period": "monthly",
            "current_value": 85.67,
            "status": "triggered",
            "last_triggered": (datetime.utcnow() - timedelta(hours=2)).isoformat(),
            "trigger_count": 3
        },
        {
            "alert_id": "alert_87654321",
            "name": "Daily Spend Alert",
            "description": "Alerta quando gasto diário excede $400",
            "threshold_type": "absolute",
            "threshold_value": 400.0,
            "currency": "USD",
            "period": "daily",
            "current_value": 285.50,
            "status": "active",
            "last_triggered": None,
            "trigger_count": 0
        }
    ] + azure_cost_monitor.cost_alerts
    
    # Aplicar filtro de status
    if status:
        alerts = [alert for alert in alerts if alert["status"] == status]
    
    return alerts

@router.get("/costs/dashboard", response_model=Dict)
async def get_cost_dashboard(
    currency: str = Query("USD", description="Moeda para exibição"),
    db: Session = Depends(get_db)
):
    """Dashboard consolidado de custos Azure"""
    logger.info("Obtendo dashboard de custos")
    
    dashboard = {
        "timestamp": datetime.utcnow().isoformat(),
        "currency": currency,
        "summary": {
            "current_month_spend": 8567.45 if currency == "USD" else 44979.11,
            "daily_average": 285.50 if currency == "USD" else 1498.88,
            "budget_utilization": 85.67,
            "projected_month_end": 9234.78 if currency == "USD" else 48482.60,
            "vs_last_month": {
                "amount": 7892.30 if currency == "USD" else 41434.58,
                "change_percentage": 8.5,
                "trend": "increasing"
            }
        },
        "top_cost_drivers": [
            {
                "service": "Azure Database for PostgreSQL",
                "cost": 2890.25 if currency == "USD" else 15174.81,
                "percentage": 33.7,
                "trend": "stable"
            },
            {
                "service": "Azure Kubernetes Service", 
                "cost": 2145.80 if currency == "USD" else 11265.45,
                "percentage": 25.1,
                "trend": "increasing"
            },
            {
                "service": "Azure Storage",
                "cost": 1567.30 if currency == "USD" else 8228.33,
                "percentage": 18.3,
                "trend": "stable"
            }
        ],
        "optimization_opportunities": {
            "total_potential_savings": 1847.50 if currency == "USD" else 9699.38,
            "high_priority_count": 2,
            "quick_wins_count": 2,
            "optimization_score": 72.5
        },
        "alerts": {
            "active_alerts": len([a for a in azure_cost_monitor.cost_alerts if a["status"] == "active"]),
            "triggered_alerts": 1,
            "last_alert": "Monthly budget threshold exceeded"
        },
        "forecasting": {
            "next_7_days": 1998.50 if currency == "USD" else 10492.25,
            "next_30_days": 8565.00 if currency == "USD" else 44966.25,
            "confidence": 87.2
        },
        "cost_efficiency": {
            "cost_per_transaction": 0.0045 if currency == "USD" else 0.0236,
            "cost_per_user": 12.34 if currency == "USD" else 64.79,
            "efficiency_score": 78.5,
            "benchmark_comparison": "Above average"
        }
    }
    
    return dashboard

@router.post("/costs/budget", response_model=Dict)
async def set_budget(
    budget_config: Dict = Body(...),
    db: Session = Depends(get_db)
):
    """Configurar orçamento e alertas"""
    logger.info("Configurando orçamento")
    
    # Atualizar configurações de orçamento
    azure_cost_monitor.budget_thresholds.update({
        "monthly_budget": budget_config.get("monthly_budget", 10000.00),
        "daily_budget": budget_config.get("daily_budget", 333.33),
        "alert_threshold_percent": budget_config.get("alert_threshold_percent", 80)
    })
    
    budget_response = {
        "budget_id": f"budget_{uuid.uuid4().hex[:8]}",
        "monthly_budget": azure_cost_monitor.budget_thresholds["monthly_budget"],
        "daily_budget": azure_cost_monitor.budget_thresholds["daily_budget"],
        "alert_thresholds": [
            {"percentage": 50, "enabled": True},
            {"percentage": 80, "enabled": True},
            {"percentage": 100, "enabled": True}
        ],
        "scope": budget_config.get("scope", "subscription"),
        "currency": budget_config.get("currency", "USD"),
        "effective_date": budget_config.get("effective_date", datetime.utcnow().strftime("%Y-%m-%d")),
        "notifications": {
            "email_enabled": budget_config.get("email_notifications", True),
            "webhook_enabled": budget_config.get("webhook_notifications", False)
        },
        "status": "active",
        "created_at": datetime.utcnow().isoformat()
    }
    
    return {
        "message": "Orçamento configurado com sucesso",
        "budget": budget_response
    }

