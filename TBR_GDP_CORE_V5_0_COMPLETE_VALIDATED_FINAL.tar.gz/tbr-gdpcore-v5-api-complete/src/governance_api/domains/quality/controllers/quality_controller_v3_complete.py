"""
TBR GDP Core v3.0 - Controller de Qualidade de Dados COMPLETO
Endpoints completos para gestão de qualidade de dados
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Body
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta

from governance_api.core.database import get_db
from governance_api.domains.quality.services.quality_service import QualityService
from governance_api.domains.quality.schemas.quality_schemas import (
    QualityRuleCreate, QualityRuleUpdate, QualityRuleResponse,
    QualityCheckCreate, QualityCheckResponse,
    QualityIssueCreate, QualityIssueUpdate, QualityIssueResponse,
    QualityMetricCreate, QualityMetricResponse,
    QualityDashboardCreate, QualityDashboardUpdate, QualityDashboardResponse,
    QualityAlertCreate, QualityAlertUpdate, QualityAlertResponse,
    QualityRemediationCreate, QualityRemediationUpdate, QualityRemediationResponse,
    QualityReportRequest, QualityReportResponse,
    QualityCheckExecutionRequest, QualityCheckExecutionResponse
)

router = APIRouter(prefix="/api/v3/quality", tags=["Quality"])

def get_quality_service(db: Session = Depends(get_db)) -> QualityService:
    return QualityService(db)

# === QUALITY RULES ===

@router.post("/rules", response_model=QualityRuleResponse)
async def create_quality_rule(
    rule_data: QualityRuleCreate,
    service: QualityService = Depends(get_quality_service)
):
    """Criar nova regra de qualidade"""
    return service.create_quality_rule(rule_data)

@router.get("/rules", response_model=List[QualityRuleResponse])
async def list_quality_rules(
    entity_ids: Optional[str] = Query(None, description="IDs das entidades separados por vírgula"),
    rule_types: Optional[str] = Query(None, description="Tipos de regras separados por vírgula"),
    severities: Optional[str] = Query(None, description="Severidades separadas por vírgula"),
    is_active: Optional[bool] = Query(None),
    service: QualityService = Depends(get_quality_service)
):
    """Listar regras de qualidade com filtros"""
    entity_ids_list = [int(x.strip()) for x in entity_ids.split(",")] if entity_ids else None
    rule_types_list = [x.strip() for x in rule_types.split(",")] if rule_types else None
    severities_list = [x.strip() for x in severities.split(",")] if severities else None
    
    return service.list_quality_rules(entity_ids_list, rule_types_list, severities_list, is_active)

@router.get("/rules/{rule_id}", response_model=QualityRuleResponse)
async def get_quality_rule(
    rule_id: int,
    service: QualityService = Depends(get_quality_service)
):
    """Obter regra de qualidade por ID"""
    rule = service.get_quality_rule(rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Quality rule not found")
    return rule

@router.put("/rules/{rule_id}", response_model=QualityRuleResponse)
async def update_quality_rule(
    rule_id: int,
    rule_data: QualityRuleUpdate,
    service: QualityService = Depends(get_quality_service)
):
    """Atualizar regra de qualidade"""
    rule = service.update_quality_rule(rule_id, rule_data)
    if not rule:
        raise HTTPException(status_code=404, detail="Quality rule not found")
    return rule

@router.delete("/rules/{rule_id}")
async def delete_quality_rule(
    rule_id: int,
    service: QualityService = Depends(get_quality_service)
):
    """Deletar regra de qualidade"""
    success = service.delete_quality_rule(rule_id)
    if not success:
        raise HTTPException(status_code=404, detail="Quality rule not found")
    return {"message": "Quality rule deleted successfully"}

@router.get("/entities/{entity_id}/rules", response_model=List[QualityRuleResponse])
async def get_rules_by_entity(
    entity_id: int,
    service: QualityService = Depends(get_quality_service)
):
    """Obter regras de qualidade por entidade"""
    return service.get_rules_by_entity(entity_id)

# === QUALITY CHECKS ===

@router.post("/checks", response_model=QualityCheckResponse)
async def execute_quality_check(
    check_data: QualityCheckCreate,
    service: QualityService = Depends(get_quality_service)
):
    """Executar verificação de qualidade"""
    return service.execute_quality_check(check_data)

@router.get("/checks", response_model=List[QualityCheckResponse])
async def list_quality_checks(
    rule_id: Optional[int] = Query(None),
    entity_id: Optional[int] = Query(None),
    limit: int = Query(100, le=1000),
    service: QualityService = Depends(get_quality_service)
):
    """Listar verificações de qualidade"""
    return service.list_quality_checks(rule_id, entity_id, limit)

@router.get("/checks/{check_id}", response_model=QualityCheckResponse)
async def get_quality_check(
    check_id: int,
    service: QualityService = Depends(get_quality_service)
):
    """Obter verificação de qualidade por ID"""
    check = service.get_quality_check(check_id)
    if not check:
        raise HTTPException(status_code=404, detail="Quality check not found")
    return check

@router.post("/checks/batch", response_model=QualityCheckExecutionResponse)
async def execute_quality_checks_batch(
    request: QualityCheckExecutionRequest,
    service: QualityService = Depends(get_quality_service)
):
    """Executar verificações de qualidade em lote"""
    return service.execute_quality_checks_batch(request)

@router.get("/trends")
async def get_quality_trends(
    entity_id: Optional[int] = Query(None),
    days: int = Query(30, le=365),
    service: QualityService = Depends(get_quality_service)
):
    """Obter tendências de qualidade"""
    trends = service.get_quality_trends(entity_id, days)
    return {
        "entity_id": entity_id,
        "period_days": days,
        "trends": trends,
        "generated_at": datetime.utcnow()
    }

# === QUALITY ISSUES ===

@router.post("/issues", response_model=QualityIssueResponse)
async def create_quality_issue(
    issue_data: QualityIssueCreate,
    service: QualityService = Depends(get_quality_service)
):
    """Criar problema de qualidade"""
    return service.create_quality_issue(issue_data)

@router.get("/issues", response_model=List[QualityIssueResponse])
async def list_quality_issues(
    entity_id: Optional[int] = Query(None),
    severity: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    assigned_to: Optional[str] = Query(None),
    service: QualityService = Depends(get_quality_service)
):
    """Listar problemas de qualidade"""
    return service.list_quality_issues(entity_id, severity, status, assigned_to)

@router.get("/issues/{issue_id}", response_model=QualityIssueResponse)
async def get_quality_issue(
    issue_id: int,
    service: QualityService = Depends(get_quality_service)
):
    """Obter problema de qualidade por ID"""
    issue = service.get_quality_issue(issue_id)
    if not issue:
        raise HTTPException(status_code=404, detail="Quality issue not found")
    return issue

@router.put("/issues/{issue_id}", response_model=QualityIssueResponse)
async def update_quality_issue(
    issue_id: int,
    issue_data: QualityIssueUpdate,
    service: QualityService = Depends(get_quality_service)
):
    """Atualizar problema de qualidade"""
    issue = service.update_quality_issue(issue_id, issue_data)
    if not issue:
        raise HTTPException(status_code=404, detail="Quality issue not found")
    return issue

@router.get("/issues/statistics")
async def get_issue_statistics(
    service: QualityService = Depends(get_quality_service)
):
    """Obter estatísticas de problemas de qualidade"""
    return service.get_issue_statistics()

# === QUALITY METRICS ===

@router.post("/metrics", response_model=QualityMetricResponse)
async def create_quality_metric(
    metric_data: QualityMetricCreate,
    service: QualityService = Depends(get_quality_service)
):
    """Criar métrica de qualidade"""
    return service.create_quality_metric(metric_data)

@router.get("/metrics", response_model=List[QualityMetricResponse])
async def get_latest_metrics(
    entity_id: Optional[int] = Query(None),
    service: QualityService = Depends(get_quality_service)
):
    """Obter métricas mais recentes"""
    return service.get_latest_metrics(entity_id)

@router.get("/metrics/period", response_model=List[QualityMetricResponse])
async def get_metrics_by_period(
    start_date: datetime = Query(...),
    end_date: datetime = Query(...),
    entity_id: Optional[int] = Query(None),
    service: QualityService = Depends(get_quality_service)
):
    """Obter métricas por período"""
    return service.get_metrics_by_period(start_date, end_date, entity_id)

@router.get("/metrics/aggregated")
async def get_aggregated_metrics(
    entity_ids: Optional[str] = Query(None, description="IDs das entidades separados por vírgula"),
    service: QualityService = Depends(get_quality_service)
):
    """Obter métricas agregadas"""
    entity_ids_list = [int(x.strip()) for x in entity_ids.split(",")] if entity_ids else None
    return service.get_aggregated_metrics(entity_ids_list)

# === QUALITY DASHBOARDS ===

@router.post("/dashboards", response_model=QualityDashboardResponse)
async def create_dashboard(
    dashboard_data: QualityDashboardCreate,
    service: QualityService = Depends(get_quality_service)
):
    """Criar dashboard de qualidade"""
    return service.create_dashboard(dashboard_data)

@router.get("/dashboards", response_model=List[QualityDashboardResponse])
async def list_dashboards(
    owner: Optional[str] = Query(None),
    public_only: bool = Query(False),
    service: QualityService = Depends(get_quality_service)
):
    """Listar dashboards de qualidade"""
    return service.list_dashboards(owner, public_only)

@router.get("/dashboards/{dashboard_id}", response_model=QualityDashboardResponse)
async def get_dashboard(
    dashboard_id: int,
    service: QualityService = Depends(get_quality_service)
):
    """Obter dashboard por ID"""
    dashboard = service.get_dashboard(dashboard_id)
    if not dashboard:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    return dashboard

@router.put("/dashboards/{dashboard_id}", response_model=QualityDashboardResponse)
async def update_dashboard(
    dashboard_id: int,
    dashboard_data: QualityDashboardUpdate,
    service: QualityService = Depends(get_quality_service)
):
    """Atualizar dashboard"""
    dashboard = service.update_dashboard(dashboard_id, dashboard_data)
    if not dashboard:
        raise HTTPException(status_code=404, detail="Dashboard not found")
    return dashboard

# === QUALITY ALERTS ===

@router.post("/alerts", response_model=QualityAlertResponse)
async def create_alert(
    alert_data: QualityAlertCreate,
    service: QualityService = Depends(get_quality_service)
):
    """Criar alerta de qualidade"""
    return service.create_alert(alert_data)

@router.get("/alerts", response_model=List[QualityAlertResponse])
async def list_alerts(
    entity_id: Optional[int] = Query(None),
    active_only: bool = Query(True),
    service: QualityService = Depends(get_quality_service)
):
    """Listar alertas de qualidade"""
    return service.list_alerts(entity_id, active_only)

@router.get("/alerts/{alert_id}", response_model=QualityAlertResponse)
async def get_alert(
    alert_id: int,
    service: QualityService = Depends(get_quality_service)
):
    """Obter alerta por ID"""
    alert = service.get_alert(alert_id)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    return alert

@router.put("/alerts/{alert_id}", response_model=QualityAlertResponse)
async def update_alert(
    alert_id: int,
    alert_data: QualityAlertUpdate,
    service: QualityService = Depends(get_quality_service)
):
    """Atualizar alerta"""
    alert = service.update_alert(alert_id, alert_data)
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    return alert

@router.get("/alerts/recent")
async def get_recent_alerts(
    hours: int = Query(24, le=168),
    service: QualityService = Depends(get_quality_service)
):
    """Obter alertas disparados recentemente"""
    alerts = service.get_recently_triggered_alerts(hours)
    return {
        "alerts": alerts,
        "period_hours": hours,
        "total": len(alerts),
        "generated_at": datetime.utcnow()
    }

# === QUALITY REMEDIATION ===

@router.post("/remediations", response_model=QualityRemediationResponse)
async def create_remediation(
    remediation_data: QualityRemediationCreate,
    service: QualityService = Depends(get_quality_service)
):
    """Criar remediação de qualidade"""
    return service.create_remediation(remediation_data)

@router.get("/remediations", response_model=List[QualityRemediationResponse])
async def list_remediations(
    issue_id: Optional[int] = Query(None),
    status: Optional[str] = Query(None),
    service: QualityService = Depends(get_quality_service)
):
    """Listar remediações"""
    return service.list_remediations(issue_id, status)

@router.get("/remediations/{remediation_id}", response_model=QualityRemediationResponse)
async def get_remediation(
    remediation_id: int,
    service: QualityService = Depends(get_quality_service)
):
    """Obter remediação por ID"""
    remediation = service.get_remediation(remediation_id)
    if not remediation:
        raise HTTPException(status_code=404, detail="Remediation not found")
    return remediation

@router.put("/remediations/{remediation_id}", response_model=QualityRemediationResponse)
async def update_remediation(
    remediation_id: int,
    remediation_data: QualityRemediationUpdate,
    service: QualityService = Depends(get_quality_service)
):
    """Atualizar remediação"""
    remediation = service.update_remediation(remediation_id, remediation_data)
    if not remediation:
        raise HTTPException(status_code=404, detail="Remediation not found")
    return remediation

# === REPORTS AND ANALYTICS ===

@router.post("/reports", response_model=QualityReportResponse)
async def generate_quality_report(
    request: QualityReportRequest,
    service: QualityService = Depends(get_quality_service)
):
    """Gerar relatório de qualidade"""
    return service.generate_quality_report(request)

@router.get("/dashboard")
async def get_quality_dashboard(
    service: QualityService = Depends(get_quality_service)
):
    """Dashboard executivo de qualidade"""
    return service.get_quality_dashboard_data()

# === LEGACY ENDPOINTS (para compatibilidade) ===

@router.get("/rules/legacy")
async def list_quality_rules_legacy(
    entity_id: Optional[int] = Query(None),
    rule_type: Optional[str] = Query(None),
    service: QualityService = Depends(get_quality_service)
):
    """Listar regras de qualidade (endpoint legado)"""
    entity_ids = [entity_id] if entity_id else None
    rule_types = [rule_type] if rule_type else None
    
    rules = service.list_quality_rules(entity_ids, rule_types)
    
    return {
        "rules": [
            {
                "id": rule.id,
                "name": rule.name,
                "description": rule.description,
                "rule_type": rule.rule_type,
                "entity_id": rule.entity_id,
                "threshold": rule.threshold,
                "severity": rule.severity,
                "is_active": rule.is_active,
                "created_at": rule.created_at.isoformat() + "Z"
            }
            for rule in rules
        ],
        "total": len(rules),
        "filters_applied": {
            "entity_id": entity_id,
            "rule_type": rule_type
        }
    }

@router.get("/checks/legacy")
async def list_quality_checks_legacy(
    rule_id: Optional[int] = Query(None),
    entity_id: Optional[int] = Query(None),
    limit: int = Query(50, le=100),
    service: QualityService = Depends(get_quality_service)
):
    """Listar verificações de qualidade (endpoint legado)"""
    checks = service.list_quality_checks(rule_id, entity_id, limit)
    
    return {
        "checks": [
            {
                "id": check.id,
                "rule_id": check.rule_id,
                "entity_id": check.entity_id,
                "execution_timestamp": check.execution_timestamp.isoformat() + "Z",
                "status": check.status,
                "records_checked": check.records_checked,
                "records_passed": check.records_passed,
                "records_failed": check.records_failed,
                "quality_score": check.quality_score,
                "execution_time_ms": check.execution_time_ms,
                "error_message": check.error_message
            }
            for check in checks
        ],
        "total": len(checks),
        "filters_applied": {
            "rule_id": rule_id,
            "entity_id": entity_id,
            "limit": limit
        }
    }

@router.get("/issues/legacy")
async def list_quality_issues_legacy(
    entity_id: Optional[int] = Query(None),
    severity: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    service: QualityService = Depends(get_quality_service)
):
    """Listar problemas de qualidade (endpoint legado)"""
    issues = service.list_quality_issues(entity_id, severity, status)
    
    return {
        "issues": [
            {
                "id": issue.id,
                "rule_id": issue.rule_id,
                "entity_id": issue.entity_id,
                "issue_type": issue.issue_type,
                "severity": issue.severity,
                "description": issue.description,
                "affected_records": issue.affected_records,
                "status": issue.status,
                "assigned_to": issue.assigned_to,
                "created_at": issue.created_at.isoformat() + "Z",
                "resolved_at": issue.resolved_at.isoformat() + "Z" if issue.resolved_at else None,
                "sample_values": issue.sample_values
            }
            for issue in issues
        ],
        "total": len(issues),
        "filters_applied": {
            "entity_id": entity_id,
            "severity": severity,
            "status": status
        }
    }

@router.get("/metrics/legacy")
async def get_quality_metrics_legacy(
    entity_id: Optional[int] = Query(None),
    period_days: int = Query(30, le=365),
    service: QualityService = Depends(get_quality_service)
):
    """Obter métricas de qualidade (endpoint legado)"""
    # Obter métricas agregadas
    aggregated = service.get_aggregated_metrics([entity_id] if entity_id else None)
    
    # Obter tendências
    trends = service.get_quality_trends(entity_id, min(period_days, 7))
    
    return {
        "entity_id": entity_id,
        "period_days": period_days,
        "metrics": aggregated,
        "trends": [
            {
                "date": trend.date.strftime("%Y-%m-%d"),
                "overall_score": round(trend.overall_score, 1),
                "issues_count": trend.issues_count
            }
            for trend in trends
        ],
        "last_updated": datetime.utcnow().isoformat() + "Z"
    }

