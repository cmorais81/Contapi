"""
TBR GDP Core v3.0 - Repository de Qualidade de Dados
Implementação completa do repository para acesso aos dados
"""

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func, desc, asc
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta

from governance_api.domains.quality.models.quality_models import (
    QualityRule, QualityCheck, QualityIssue, QualityMetric,
    QualityDashboard, QualityAlert, QualityRemediation
)
from governance_api.domains.quality.schemas.quality_schemas import (
    QualityRuleCreate, QualityRuleUpdate,
    QualityCheckCreate, QualityIssueCreate, QualityIssueUpdate,
    QualityMetricCreate, QualityDashboardCreate, QualityDashboardUpdate,
    QualityAlertCreate, QualityAlertUpdate,
    QualityRemediationCreate, QualityRemediationUpdate
)
from governance_api.shared.repositories import BaseRepository

class QualityRuleRepository(BaseRepository[QualityRule, QualityRuleCreate, QualityRuleUpdate]):
    def __init__(self, db: Session):
        super().__init__(QualityRule, db)
    
    def get_by_entity(self, entity_id: int) -> List[QualityRule]:
        """Obter regras por entidade"""
        return self.db.query(QualityRule).filter(
            QualityRule.entity_id == entity_id,
            QualityRule.is_active == True
        ).all()
    
    def get_by_type(self, rule_type: str) -> List[QualityRule]:
        """Obter regras por tipo"""
        return self.db.query(QualityRule).filter(
            QualityRule.rule_type == rule_type,
            QualityRule.is_active == True
        ).all()
    
    def get_by_severity(self, severity: str) -> List[QualityRule]:
        """Obter regras por severidade"""
        return self.db.query(QualityRule).filter(
            QualityRule.severity == severity,
            QualityRule.is_active == True
        ).all()
    
    def search_rules(self, 
                    entity_ids: Optional[List[int]] = None,
                    rule_types: Optional[List[str]] = None,
                    severities: Optional[List[str]] = None,
                    is_active: Optional[bool] = None) -> List[QualityRule]:
        """Busca avançada de regras"""
        query = self.db.query(QualityRule)
        
        if entity_ids:
            query = query.filter(QualityRule.entity_id.in_(entity_ids))
        
        if rule_types:
            query = query.filter(QualityRule.rule_type.in_(rule_types))
        
        if severities:
            query = query.filter(QualityRule.severity.in_(severities))
        
        if is_active is not None:
            query = query.filter(QualityRule.is_active == is_active)
        
        return query.order_by(QualityRule.created_at.desc()).all()

class QualityCheckRepository(BaseRepository[QualityCheck, QualityCheckCreate, dict]):
    def __init__(self, db: Session):
        super().__init__(QualityCheck, db)
    
    def get_by_rule(self, rule_id: int, limit: int = 100) -> List[QualityCheck]:
        """Obter verificações por regra"""
        return self.db.query(QualityCheck).filter(
            QualityCheck.rule_id == rule_id
        ).order_by(QualityCheck.execution_timestamp.desc()).limit(limit).all()
    
    def get_by_entity(self, entity_id: int, limit: int = 100) -> List[QualityCheck]:
        """Obter verificações por entidade"""
        return self.db.query(QualityCheck).filter(
            QualityCheck.entity_id == entity_id
        ).order_by(QualityCheck.execution_timestamp.desc()).limit(limit).all()
    
    def get_recent_checks(self, hours: int = 24) -> List[QualityCheck]:
        """Obter verificações recentes"""
        since = datetime.utcnow() - timedelta(hours=hours)
        return self.db.query(QualityCheck).filter(
            QualityCheck.execution_timestamp >= since
        ).order_by(QualityCheck.execution_timestamp.desc()).all()
    
    def get_failed_checks(self, limit: int = 50) -> List[QualityCheck]:
        """Obter verificações falhadas"""
        return self.db.query(QualityCheck).filter(
            QualityCheck.status == "failed"
        ).order_by(QualityCheck.execution_timestamp.desc()).limit(limit).all()
    
    def get_quality_trends(self, entity_id: Optional[int] = None, days: int = 30) -> List[Dict]:
        """Obter tendências de qualidade"""
        since = datetime.utcnow() - timedelta(days=days)
        query = self.db.query(
            func.date(QualityCheck.execution_timestamp).label('date'),
            func.avg(QualityCheck.quality_score).label('avg_score'),
            func.count(QualityCheck.id).label('check_count')
        ).filter(QualityCheck.execution_timestamp >= since)
        
        if entity_id:
            query = query.filter(QualityCheck.entity_id == entity_id)
        
        return query.group_by(func.date(QualityCheck.execution_timestamp)).all()

class QualityIssueRepository(BaseRepository[QualityIssue, QualityIssueCreate, QualityIssueUpdate]):
    def __init__(self, db: Session):
        super().__init__(QualityIssue, db)
    
    def get_open_issues(self) -> List[QualityIssue]:
        """Obter problemas em aberto"""
        return self.db.query(QualityIssue).filter(
            QualityIssue.status == "open"
        ).order_by(QualityIssue.created_at.desc()).all()
    
    def get_by_severity(self, severity: str) -> List[QualityIssue]:
        """Obter problemas por severidade"""
        return self.db.query(QualityIssue).filter(
            QualityIssue.severity == severity
        ).order_by(QualityIssue.created_at.desc()).all()
    
    def get_by_entity(self, entity_id: int) -> List[QualityIssue]:
        """Obter problemas por entidade"""
        return self.db.query(QualityIssue).filter(
            QualityIssue.entity_id == entity_id
        ).order_by(QualityIssue.created_at.desc()).all()
    
    def get_by_assignee(self, assigned_to: str) -> List[QualityIssue]:
        """Obter problemas por responsável"""
        return self.db.query(QualityIssue).filter(
            QualityIssue.assigned_to == assigned_to,
            QualityIssue.status.in_(["open", "in_progress"])
        ).order_by(QualityIssue.created_at.desc()).all()
    
    def get_issue_statistics(self) -> Dict[str, Any]:
        """Obter estatísticas de problemas"""
        total = self.db.query(QualityIssue).count()
        open_issues = self.db.query(QualityIssue).filter(QualityIssue.status == "open").count()
        in_progress = self.db.query(QualityIssue).filter(QualityIssue.status == "in_progress").count()
        resolved = self.db.query(QualityIssue).filter(QualityIssue.status == "resolved").count()
        
        # Estatísticas por severidade
        severity_stats = self.db.query(
            QualityIssue.severity,
            func.count(QualityIssue.id).label('count')
        ).group_by(QualityIssue.severity).all()
        
        return {
            "total": total,
            "open": open_issues,
            "in_progress": in_progress,
            "resolved": resolved,
            "by_severity": {stat.severity: stat.count for stat in severity_stats}
        }

class QualityMetricRepository(BaseRepository[QualityMetric, QualityMetricCreate, dict]):
    def __init__(self, db: Session):
        super().__init__(QualityMetric, db)
    
    def get_latest_metrics(self, entity_id: Optional[int] = None) -> List[QualityMetric]:
        """Obter métricas mais recentes"""
        query = self.db.query(QualityMetric)
        
        if entity_id:
            query = query.filter(QualityMetric.entity_id == entity_id)
        
        return query.order_by(QualityMetric.metric_date.desc()).limit(100).all()
    
    def get_metrics_by_period(self, 
                             start_date: datetime, 
                             end_date: datetime,
                             entity_id: Optional[int] = None) -> List[QualityMetric]:
        """Obter métricas por período"""
        query = self.db.query(QualityMetric).filter(
            QualityMetric.metric_date >= start_date,
            QualityMetric.metric_date <= end_date
        )
        
        if entity_id:
            query = query.filter(QualityMetric.entity_id == entity_id)
        
        return query.order_by(QualityMetric.metric_date.asc()).all()
    
    def get_aggregated_metrics(self, entity_ids: Optional[List[int]] = None) -> Dict[str, Any]:
        """Obter métricas agregadas"""
        query = self.db.query(
            func.avg(QualityMetric.overall_score).label('avg_overall'),
            func.avg(QualityMetric.completeness_score).label('avg_completeness'),
            func.avg(QualityMetric.accuracy_score).label('avg_accuracy'),
            func.avg(QualityMetric.consistency_score).label('avg_consistency'),
            func.avg(QualityMetric.timeliness_score).label('avg_timeliness'),
            func.avg(QualityMetric.validity_score).label('avg_validity'),
            func.avg(QualityMetric.uniqueness_score).label('avg_uniqueness'),
            func.sum(QualityMetric.total_records).label('total_records'),
            func.sum(QualityMetric.issues_count).label('total_issues')
        )
        
        if entity_ids:
            query = query.filter(QualityMetric.entity_id.in_(entity_ids))
        
        result = query.first()
        
        return {
            "overall_score": float(result.avg_overall or 0),
            "completeness_score": float(result.avg_completeness or 0),
            "accuracy_score": float(result.avg_accuracy or 0),
            "consistency_score": float(result.avg_consistency or 0),
            "timeliness_score": float(result.avg_timeliness or 0),
            "validity_score": float(result.avg_validity or 0),
            "uniqueness_score": float(result.avg_uniqueness or 0),
            "total_records": int(result.total_records or 0),
            "total_issues": int(result.total_issues or 0)
        }

class QualityDashboardRepository(BaseRepository[QualityDashboard, QualityDashboardCreate, QualityDashboardUpdate]):
    def __init__(self, db: Session):
        super().__init__(QualityDashboard, db)
    
    def get_by_owner(self, owner: str) -> List[QualityDashboard]:
        """Obter dashboards por proprietário"""
        return self.db.query(QualityDashboard).filter(
            QualityDashboard.owner == owner,
            QualityDashboard.is_active == True
        ).order_by(QualityDashboard.created_at.desc()).all()
    
    def get_public_dashboards(self) -> List[QualityDashboard]:
        """Obter dashboards públicos"""
        return self.db.query(QualityDashboard).filter(
            QualityDashboard.is_public == True,
            QualityDashboard.is_active == True
        ).order_by(QualityDashboard.created_at.desc()).all()

class QualityAlertRepository(BaseRepository[QualityAlert, QualityAlertCreate, QualityAlertUpdate]):
    def __init__(self, db: Session):
        super().__init__(QualityAlert, db)
    
    def get_active_alerts(self) -> List[QualityAlert]:
        """Obter alertas ativos"""
        return self.db.query(QualityAlert).filter(
            QualityAlert.is_active == True
        ).order_by(QualityAlert.created_at.desc()).all()
    
    def get_by_entity(self, entity_id: int) -> List[QualityAlert]:
        """Obter alertas por entidade"""
        return self.db.query(QualityAlert).filter(
            QualityAlert.entity_id == entity_id,
            QualityAlert.is_active == True
        ).all()
    
    def get_recently_triggered(self, hours: int = 24) -> List[QualityAlert]:
        """Obter alertas disparados recentemente"""
        since = datetime.utcnow() - timedelta(hours=hours)
        return self.db.query(QualityAlert).filter(
            QualityAlert.last_triggered >= since
        ).order_by(QualityAlert.last_triggered.desc()).all()

class QualityRemediationRepository(BaseRepository[QualityRemediation, QualityRemediationCreate, QualityRemediationUpdate]):
    def __init__(self, db: Session):
        super().__init__(QualityRemediation, db)
    
    def get_by_issue(self, issue_id: int) -> List[QualityRemediation]:
        """Obter remediações por problema"""
        return self.db.query(QualityRemediation).filter(
            QualityRemediation.issue_id == issue_id
        ).order_by(QualityRemediation.created_at.desc()).all()
    
    def get_pending_remediations(self) -> List[QualityRemediation]:
        """Obter remediações pendentes"""
        return self.db.query(QualityRemediation).filter(
            QualityRemediation.execution_status == "pending"
        ).order_by(QualityRemediation.created_at.asc()).all()
    
    def get_by_status(self, status: str) -> List[QualityRemediation]:
        """Obter remediações por status"""
        return self.db.query(QualityRemediation).filter(
            QualityRemediation.execution_status == status
        ).order_by(QualityRemediation.created_at.desc()).all()

