"""
TBR GDP Core v3.0 - Models de Qualidade de Dados
Implementação completa dos modelos para gestão de qualidade
"""

from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()

class QualityRule(Base):
    """Modelo para regras de qualidade de dados"""
    __tablename__ = "quality_rules"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text)
    rule_type = Column(String(100), nullable=False)  # not_null, data_type, format, range, custom
    entity_id = Column(Integer, ForeignKey("entities.id"))
    column_name = Column(String(255))
    rule_definition = Column(JSON)  # Definição da regra em JSON
    threshold = Column(Float, default=100.0)  # Threshold de qualidade (%)
    severity = Column(String(50), default="medium")  # low, medium, high, critical
    is_active = Column(Boolean, default=True)
    created_by = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    quality_checks = relationship("QualityCheck", back_populates="rule")
    quality_issues = relationship("QualityIssue", back_populates="rule")

class QualityCheck(Base):
    """Modelo para execuções de verificação de qualidade"""
    __tablename__ = "quality_checks"
    
    id = Column(Integer, primary_key=True, index=True)
    rule_id = Column(Integer, ForeignKey("quality_rules.id"), nullable=False)
    entity_id = Column(Integer, ForeignKey("entities.id"))
    execution_timestamp = Column(DateTime, default=datetime.utcnow)
    status = Column(String(50), nullable=False)  # running, completed, failed
    records_checked = Column(Integer, default=0)
    records_passed = Column(Integer, default=0)
    records_failed = Column(Integer, default=0)
    quality_score = Column(Float)  # Percentual de qualidade
    execution_time_ms = Column(Integer)
    error_message = Column(Text)
    check_details = Column(JSON)  # Detalhes da verificação
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    rule = relationship("QualityRule", back_populates="quality_checks")
    issues = relationship("QualityIssue", back_populates="check")

class QualityIssue(Base):
    """Modelo para problemas de qualidade identificados"""
    __tablename__ = "quality_issues"
    
    id = Column(Integer, primary_key=True, index=True)
    rule_id = Column(Integer, ForeignKey("quality_rules.id"), nullable=False)
    check_id = Column(Integer, ForeignKey("quality_checks.id"))
    entity_id = Column(Integer, ForeignKey("entities.id"))
    issue_type = Column(String(100), nullable=False)
    severity = Column(String(50), nullable=False)
    description = Column(Text)
    affected_records = Column(Integer, default=1)
    sample_values = Column(JSON)  # Exemplos de valores problemáticos
    suggested_fix = Column(Text)
    status = Column(String(50), default="open")  # open, in_progress, resolved, ignored
    assigned_to = Column(String(255))
    resolved_at = Column(DateTime)
    resolution_notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    rule = relationship("QualityRule", back_populates="quality_issues")
    check = relationship("QualityCheck", back_populates="issues")

class QualityMetric(Base):
    """Modelo para métricas agregadas de qualidade"""
    __tablename__ = "quality_metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    entity_id = Column(Integer, ForeignKey("entities.id"))
    metric_date = Column(DateTime, nullable=False)
    overall_score = Column(Float)  # Score geral de qualidade
    completeness_score = Column(Float)
    accuracy_score = Column(Float)
    consistency_score = Column(Float)
    timeliness_score = Column(Float)
    validity_score = Column(Float)
    uniqueness_score = Column(Float)
    total_records = Column(Integer)
    total_rules = Column(Integer)
    rules_passed = Column(Integer)
    rules_failed = Column(Integer)
    issues_count = Column(Integer)
    critical_issues = Column(Integer)
    high_issues = Column(Integer)
    medium_issues = Column(Integer)
    low_issues = Column(Integer)
    trend_direction = Column(String(20))  # improving, stable, degrading
    created_at = Column(DateTime, default=datetime.utcnow)

class QualityDashboard(Base):
    """Modelo para configuração de dashboards de qualidade"""
    __tablename__ = "quality_dashboards"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    owner = Column(String(255), nullable=False)
    dashboard_config = Column(JSON)  # Configuração do dashboard
    entities_filter = Column(JSON)  # Filtros de entidades
    metrics_config = Column(JSON)  # Configuração de métricas
    alert_config = Column(JSON)  # Configuração de alertas
    is_public = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class QualityAlert(Base):
    """Modelo para alertas de qualidade"""
    __tablename__ = "quality_alerts"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text)
    alert_type = Column(String(100), nullable=False)  # threshold, trend, anomaly
    entity_id = Column(Integer, ForeignKey("entities.id"))
    rule_id = Column(Integer, ForeignKey("quality_rules.id"))
    condition_config = Column(JSON)  # Condições do alerta
    notification_config = Column(JSON)  # Configuração de notificações
    is_active = Column(Boolean, default=True)
    last_triggered = Column(DateTime)
    trigger_count = Column(Integer, default=0)
    created_by = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class QualityRemediation(Base):
    """Modelo para ações de remediação de qualidade"""
    __tablename__ = "quality_remediations"
    
    id = Column(Integer, primary_key=True, index=True)
    issue_id = Column(Integer, ForeignKey("quality_issues.id"), nullable=False)
    remediation_type = Column(String(100), nullable=False)  # automatic, manual, workflow
    action_description = Column(Text)
    action_script = Column(Text)  # Script de remediação
    execution_status = Column(String(50), default="pending")  # pending, running, completed, failed
    execution_result = Column(JSON)  # Resultado da execução
    records_affected = Column(Integer)
    execution_time_ms = Column(Integer)
    executed_by = Column(String(255))
    executed_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

