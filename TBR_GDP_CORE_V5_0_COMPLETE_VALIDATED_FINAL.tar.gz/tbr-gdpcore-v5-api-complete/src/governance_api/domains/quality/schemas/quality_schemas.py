"""
TBR GDP Core v3.0 - Schemas de Qualidade de Dados
Implementação completa dos schemas Pydantic para validação
"""

from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any, Union
from datetime import datetime
from enum import Enum

# Enums para validação
class RuleType(str, Enum):
    NOT_NULL = "not_null"
    DATA_TYPE = "data_type"
    FORMAT = "format"
    RANGE = "range"
    CUSTOM = "custom"
    UNIQUENESS = "uniqueness"
    REFERENTIAL = "referential"

class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class CheckStatus(str, Enum):
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"

class IssueStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    IGNORED = "ignored"

class TrendDirection(str, Enum):
    IMPROVING = "improving"
    STABLE = "stable"
    DEGRADING = "degrading"

# Schemas Base
class QualityRuleBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    rule_type: RuleType
    entity_id: Optional[int] = None
    column_name: Optional[str] = None
    rule_definition: Dict[str, Any] = Field(default_factory=dict)
    threshold: float = Field(default=100.0, ge=0, le=100)
    severity: Severity = Severity.MEDIUM
    is_active: bool = True

class QualityRuleCreate(QualityRuleBase):
    created_by: str = Field(..., min_length=1)

class QualityRuleUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    rule_definition: Optional[Dict[str, Any]] = None
    threshold: Optional[float] = Field(None, ge=0, le=100)
    severity: Optional[Severity] = None
    is_active: Optional[bool] = None

class QualityRuleResponse(QualityRuleBase):
    id: int
    created_by: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

# Schemas para Quality Check
class QualityCheckBase(BaseModel):
    rule_id: int
    entity_id: Optional[int] = None

class QualityCheckCreate(QualityCheckBase):
    pass

class QualityCheckResponse(QualityCheckBase):
    id: int
    execution_timestamp: datetime
    status: CheckStatus
    records_checked: int = 0
    records_passed: int = 0
    records_failed: int = 0
    quality_score: Optional[float] = None
    execution_time_ms: Optional[int] = None
    error_message: Optional[str] = None
    check_details: Dict[str, Any] = Field(default_factory=dict)
    created_at: datetime
    
    class Config:
        from_attributes = True

# Schemas para Quality Issue
class QualityIssueBase(BaseModel):
    rule_id: int
    check_id: Optional[int] = None
    entity_id: Optional[int] = None
    issue_type: str = Field(..., min_length=1)
    severity: Severity
    description: Optional[str] = None
    affected_records: int = Field(default=1, ge=1)
    sample_values: List[Any] = Field(default_factory=list)
    suggested_fix: Optional[str] = None

class QualityIssueCreate(QualityIssueBase):
    pass

class QualityIssueUpdate(BaseModel):
    status: Optional[IssueStatus] = None
    assigned_to: Optional[str] = None
    resolution_notes: Optional[str] = None

class QualityIssueResponse(QualityIssueBase):
    id: int
    status: IssueStatus
    assigned_to: Optional[str] = None
    resolved_at: Optional[datetime] = None
    resolution_notes: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

# Schemas para Quality Metric
class QualityMetricBase(BaseModel):
    entity_id: Optional[int] = None
    metric_date: datetime
    overall_score: Optional[float] = Field(None, ge=0, le=100)
    completeness_score: Optional[float] = Field(None, ge=0, le=100)
    accuracy_score: Optional[float] = Field(None, ge=0, le=100)
    consistency_score: Optional[float] = Field(None, ge=0, le=100)
    timeliness_score: Optional[float] = Field(None, ge=0, le=100)
    validity_score: Optional[float] = Field(None, ge=0, le=100)
    uniqueness_score: Optional[float] = Field(None, ge=0, le=100)

class QualityMetricCreate(QualityMetricBase):
    total_records: int = Field(default=0, ge=0)
    total_rules: int = Field(default=0, ge=0)
    rules_passed: int = Field(default=0, ge=0)
    rules_failed: int = Field(default=0, ge=0)
    issues_count: int = Field(default=0, ge=0)
    critical_issues: int = Field(default=0, ge=0)
    high_issues: int = Field(default=0, ge=0)
    medium_issues: int = Field(default=0, ge=0)
    low_issues: int = Field(default=0, ge=0)
    trend_direction: Optional[TrendDirection] = None

class QualityMetricResponse(QualityMetricCreate):
    id: int
    created_at: datetime
    
    class Config:
        from_attributes = True

# Schemas para Dashboard
class QualityDashboardBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    dashboard_config: Dict[str, Any] = Field(default_factory=dict)
    entities_filter: List[int] = Field(default_factory=list)
    metrics_config: Dict[str, Any] = Field(default_factory=dict)
    alert_config: Dict[str, Any] = Field(default_factory=dict)
    is_public: bool = False
    is_active: bool = True

class QualityDashboardCreate(QualityDashboardBase):
    owner: str = Field(..., min_length=1)

class QualityDashboardUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    dashboard_config: Optional[Dict[str, Any]] = None
    entities_filter: Optional[List[int]] = None
    metrics_config: Optional[Dict[str, Any]] = None
    alert_config: Optional[Dict[str, Any]] = None
    is_public: Optional[bool] = None
    is_active: Optional[bool] = None

class QualityDashboardResponse(QualityDashboardBase):
    id: int
    owner: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

# Schemas para Alertas
class QualityAlertBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    alert_type: str = Field(..., min_length=1)
    entity_id: Optional[int] = None
    rule_id: Optional[int] = None
    condition_config: Dict[str, Any] = Field(default_factory=dict)
    notification_config: Dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True

class QualityAlertCreate(QualityAlertBase):
    created_by: str = Field(..., min_length=1)

class QualityAlertUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    condition_config: Optional[Dict[str, Any]] = None
    notification_config: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None

class QualityAlertResponse(QualityAlertBase):
    id: int
    last_triggered: Optional[datetime] = None
    trigger_count: int = 0
    created_by: str
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

# Schemas para Remediação
class QualityRemediationBase(BaseModel):
    issue_id: int
    remediation_type: str = Field(..., min_length=1)
    action_description: Optional[str] = None
    action_script: Optional[str] = None

class QualityRemediationCreate(QualityRemediationBase):
    pass

class QualityRemediationUpdate(BaseModel):
    execution_status: Optional[str] = None
    execution_result: Optional[Dict[str, Any]] = None
    records_affected: Optional[int] = None

class QualityRemediationResponse(QualityRemediationBase):
    id: int
    execution_status: str
    execution_result: Dict[str, Any] = Field(default_factory=dict)
    records_affected: Optional[int] = None
    execution_time_ms: Optional[int] = None
    executed_by: Optional[str] = None
    executed_at: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

# Schemas para Relatórios e Analytics
class QualityReportRequest(BaseModel):
    entity_ids: Optional[List[int]] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    include_trends: bool = True
    include_issues: bool = True
    group_by: Optional[str] = Field(None, regex="^(entity|rule_type|severity|date)$")

class QualityTrendData(BaseModel):
    date: datetime
    overall_score: float
    completeness_score: float
    accuracy_score: float
    consistency_score: float
    timeliness_score: float
    validity_score: float
    uniqueness_score: float
    issues_count: int

class QualityReportResponse(BaseModel):
    report_id: str
    generated_at: datetime
    period: Dict[str, Any]
    summary: Dict[str, Any]
    entities_summary: List[Dict[str, Any]]
    trends: List[QualityTrendData]
    top_issues: List[QualityIssueResponse]
    recommendations: List[str]

# Schemas para Execução de Verificações
class QualityCheckExecutionRequest(BaseModel):
    rule_ids: Optional[List[int]] = None
    entity_ids: Optional[List[int]] = None
    execution_mode: str = Field(default="async", regex="^(sync|async)$")
    notification_config: Dict[str, Any] = Field(default_factory=dict)

class QualityCheckExecutionResponse(BaseModel):
    execution_id: str
    status: str
    rules_scheduled: int
    estimated_duration: Optional[int] = None
    started_at: datetime
    
# Schemas para Configuração de Regras
class RuleDefinitionConfig(BaseModel):
    """Configuração específica para diferentes tipos de regras"""
    # Para regras NOT_NULL
    allow_empty_strings: Optional[bool] = None
    
    # Para regras DATA_TYPE
    expected_type: Optional[str] = None
    allow_null: Optional[bool] = None
    
    # Para regras FORMAT
    pattern: Optional[str] = None
    format_type: Optional[str] = None  # email, phone, date, etc.
    
    # Para regras RANGE
    min_value: Optional[Union[int, float]] = None
    max_value: Optional[Union[int, float]] = None
    
    # Para regras CUSTOM
    sql_expression: Optional[str] = None
    python_function: Optional[str] = None
    
    # Para regras UNIQUENESS
    columns: Optional[List[str]] = None
    scope: Optional[str] = None  # table, partition, etc.
    
    # Para regras REFERENTIAL
    reference_table: Optional[str] = None
    reference_column: Optional[str] = None

