"""
TBR GDP Core v1.0 - Schemas de Entidades
Schemas Pydantic para validação de dados de entidades
"""

from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime

from ....shared.models import (
    BaseSchema, 
    CreateSchema, 
    UpdateSchema, 
    ResponseSchema,
    TimestampSchema,
    AuditSchema,
    MetadataSchema
)

class EntityBaseSchema(BaseSchema):
    """Schema base para entidades"""
    name: str = Field(..., min_length=1, max_length=255, description="Nome técnico da entidade")
    display_name: Optional[str] = Field(None, max_length=255, description="Nome amigável")
    description: Optional[str] = Field(None, description="Descrição da entidade")
    domain_id: int = Field(..., description="ID do domínio")
    entity_type: str = Field(..., description="Tipo da entidade")
    classification: str = Field(..., description="Classificação de segurança")
    
    @validator('name')
    def validate_name(cls, v):
        if not v.replace('_', '').replace('-', '').isalnum():
            raise ValueError('Nome deve conter apenas letras, números, _ e -')
        return v.lower()
    
    @validator('entity_type')
    def validate_entity_type(cls, v):
        allowed_types = ['table', 'view', 'file', 'api', 'stream', 'dataset']
        if v not in allowed_types:
            raise ValueError(f'Tipo deve ser um de: {", ".join(allowed_types)}')
        return v
    
    @validator('classification')
    def validate_classification(cls, v):
        allowed_classifications = ['public', 'internal', 'confidential', 'restricted']
        if v not in allowed_classifications:
            raise ValueError(f'Classificação deve ser uma de: {", ".join(allowed_classifications)}')
        return v

class EntityCreateSchema(EntityBaseSchema, CreateSchema):
    """Schema para criação de entidades"""
    owner_id: int = Field(..., description="ID do proprietário")
    steward_id: Optional[int] = Field(None, description="ID do data steward")
    sensitivity_level: Optional[str] = Field("medium", description="Nível de sensibilidade")
    business_criticality: Optional[str] = Field("medium", description="Criticidade para o negócio")
    source_system: Optional[str] = Field(None, description="Sistema de origem")
    physical_location: Optional[str] = Field(None, description="Localização física")
    business_purpose: Optional[str] = Field(None, description="Propósito de negócio")
    usage_guidelines: Optional[str] = Field(None, description="Diretrizes de uso")
    retention_period: Optional[int] = Field(None, description="Período de retenção em dias")
    tags: Optional[List[str]] = Field(None, description="Tags para categorização")
    meta_data: Optional[Dict[str, Any]] = Field(None, description="Metadados adicionais")

class EntityUpdateSchema(UpdateSchema):
    """Schema para atualização de entidades"""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    display_name: Optional[str] = Field(None, max_length=255)
    description: Optional[str] = None
    domain_id: Optional[int] = None
    entity_type: Optional[str] = None
    classification: Optional[str] = None
    owner_id: Optional[int] = None
    steward_id: Optional[int] = None
    sensitivity_level: Optional[str] = None
    business_criticality: Optional[str] = None
    source_system: Optional[str] = None
    physical_location: Optional[str] = None
    business_purpose: Optional[str] = None
    usage_guidelines: Optional[str] = None
    retention_period: Optional[int] = None
    tags: Optional[List[str]] = None
    meta_data: Optional[Dict[str, Any]] = None
    is_deprecated: Optional[bool] = None

class EntityResponseSchema(EntityBaseSchema, ResponseSchema, TimestampSchema, AuditSchema):
    """Schema para resposta de entidades"""
    owner_id: int
    steward_id: Optional[int] = None
    sensitivity_level: Optional[str] = None
    business_criticality: Optional[str] = None
    source_system: Optional[str] = None
    physical_location: Optional[str] = None
    business_purpose: Optional[str] = None
    usage_guidelines: Optional[str] = None
    
    # Scores de qualidade
    quality_score: Optional[int] = Field(None, ge=0, le=100)
    completeness_score: Optional[int] = Field(None, ge=0, le=100)
    accuracy_score: Optional[int] = Field(None, ge=0, le=100)
    consistency_score: Optional[int] = Field(None, ge=0, le=100)
    
    # Métricas de uso
    access_count: Optional[int] = Field(0, ge=0)
    last_accessed: Optional[datetime] = None
    access_frequency: Optional[str] = None
    
    # Ciclo de vida
    retention_period: Optional[int] = None
    archival_date: Optional[datetime] = None
    deletion_date: Optional[datetime] = None
    
    # Metadados
    tags: Optional[List[str]] = None
    meta_data: Optional[Dict[str, Any]] = None
    
    # Status
    is_deprecated: Optional[bool] = False
    deprecation_date: Optional[datetime] = None

class EntityFilterSchema(BaseSchema):
    """Schema para filtros de entidades"""
    search: Optional[str] = Field(None, description="Termo de busca")
    domain_id: Optional[int] = Field(None, description="Filtrar por domínio")
    entity_type: Optional[str] = Field(None, description="Filtrar por tipo")
    classification: Optional[str] = Field(None, description="Filtrar por classificação")
    owner_id: Optional[int] = Field(None, description="Filtrar por proprietário")
    steward_id: Optional[int] = Field(None, description="Filtrar por steward")
    sensitivity_level: Optional[str] = Field(None, description="Filtrar por sensibilidade")
    business_criticality: Optional[str] = Field(None, description="Filtrar por criticidade")
    is_active: Optional[bool] = Field(True, description="Filtrar por status ativo")
    is_deprecated: Optional[bool] = Field(None, description="Filtrar por depreciação")
    min_quality_score: Optional[int] = Field(None, ge=0, le=100, description="Score mínimo de qualidade")
    tags: Optional[List[str]] = Field(None, description="Filtrar por tags")

class LineageEntitySchema(BaseSchema):
    """Schema para entidades na linhagem"""
    id: int
    name: str
    display_name: Optional[str] = None
    entity_type: str
    relationship_type: str
    transformation_logic: Optional[str] = None
    confidence_score: Optional[int] = Field(None, ge=0, le=100)

class LineageResponseSchema(BaseSchema):
    """Schema para resposta de linhagem"""
    entity_id: int
    entity_name: str
    upstream_entities: List[LineageEntitySchema] = []
    downstream_entities: List[LineageEntitySchema] = []
    lineage_depth: int
    total_relationships: int
    last_updated: datetime

class EntityAttributeSchema(BaseSchema):
    """Schema para atributos de entidades"""
    id: Optional[int] = None
    attribute_name: str = Field(..., description="Nome do atributo")
    display_name: Optional[str] = Field(None, description="Nome amigável")
    description: Optional[str] = Field(None, description="Descrição do atributo")
    data_type: str = Field(..., description="Tipo de dados")
    data_format: Optional[str] = Field(None, description="Formato específico")
    max_length: Optional[int] = Field(None, description="Comprimento máximo")
    classification: Optional[str] = Field(None, description="Classificação do atributo")
    is_pii: Optional[bool] = Field(False, description="É PII?")
    is_sensitive: Optional[bool] = Field(False, description="É sensível?")
    is_nullable: Optional[bool] = Field(True, description="Pode ser nulo?")
    is_unique: Optional[bool] = Field(False, description="É único?")
    validation_rules: Optional[Dict[str, Any]] = Field(None, description="Regras de validação")
    business_rules: Optional[str] = Field(None, description="Regras de negócio")
    allowed_values: Optional[List[str]] = Field(None, description="Valores permitidos")
    default_value: Optional[str] = Field(None, description="Valor padrão")

class EntityStatsSchema(BaseSchema):
    """Schema para estatísticas de entidades"""
    total_entities: int
    entities_by_type: Dict[str, int]
    entities_by_classification: Dict[str, int]
    entities_by_domain: Dict[str, int]
    avg_quality_score: Optional[float] = None
    entities_with_issues: int
    deprecated_entities: int
    recently_accessed: int

