"""
TBR GDP Core v1.0 - Controller de Entidades
Endpoints REST para gerenciamento de entidades de dados
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Path, Body
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
import logging

from governance_api.core.database import get_db
from governance_api.shared.models import PaginationSchema, FilterSchema, SuccessSchema
from ..schemas.entity_schemas import (
    EntityCreateSchema,
    EntityUpdateSchema,
    EntityResponseSchema,
    EntityFilterSchema,
    LineageResponseSchema
)

router = APIRouter()
logger = logging.getLogger(__name__)

@router.get("/", response_model=List[EntityResponseSchema])
async def list_entities(
    skip: int = Query(0, ge=0, description="Número de registros para pular"),
    limit: int = Query(20, ge=1, le=100, description="Número máximo de registros"),
    search: Optional[str] = Query(None, description="Termo de busca"),
    domain_id: Optional[int] = Query(None, description="Filtrar por domínio"),
    entity_type: Optional[str] = Query(None, description="Filtrar por tipo"),
    classification: Optional[str] = Query(None, description="Filtrar por classificação"),
    is_active: Optional[bool] = Query(True, description="Filtrar por status ativo"),
    db: Session = Depends(get_db)
):
    """Listar entidades com filtros e paginação"""
    try:
        # Mock data para demonstração
        entities = [
            {
                "id": 1,
                "name": "customer_profiles",
                "display_name": "Perfis de Clientes",
                "description": "Dados consolidados de perfis de clientes",
                "domain_id": 1,
                "entity_type": "table",
                "classification": "confidential",
                "owner_id": 1,
                "quality_score": 95,
                "is_active": True,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00"
            },
            {
                "id": 2,
                "name": "order_transactions",
                "display_name": "Transações de Pedidos",
                "description": "Histórico de transações de pedidos",
                "domain_id": 2,
                "entity_type": "table",
                "classification": "internal",
                "owner_id": 2,
                "quality_score": 88,
                "is_active": True,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00"
            }
        ]
        
        # Aplicar filtros básicos
        if search:
            entities = [e for e in entities if search.lower() in e["name"].lower() or search.lower() in e["display_name"].lower()]
        
        if domain_id:
            entities = [e for e in entities if e["domain_id"] == domain_id]
            
        if entity_type:
            entities = [e for e in entities if e["entity_type"] == entity_type]
            
        if classification:
            entities = [e for e in entities if e["classification"] == classification]
        
        # Aplicar paginação
        total = len(entities)
        entities = entities[skip:skip + limit]
        
        logger.info(f"Listando {len(entities)} entidades (total: {total})")
        return entities
        
    except Exception as e:
        logger.error(f"Erro ao listar entidades: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/{entity_id}", response_model=EntityResponseSchema)
async def get_entity(
    entity_id: int = Path(..., description="ID da entidade"),
    db: Session = Depends(get_db)
):
    """Obter entidade por ID"""
    try:
        # Mock data
        if entity_id == 1:
            entity = {
                "id": 1,
                "name": "customer_profiles",
                "display_name": "Perfis de Clientes",
                "description": "Dados consolidados de perfis de clientes com informações demográficas e comportamentais",
                "domain_id": 1,
                "entity_type": "table",
                "classification": "confidential",
                "sensitivity_level": "high",
                "business_criticality": "high",
                "source_system": "CRM_System",
                "physical_location": "database.customer.profiles",
                "owner_id": 1,
                "steward_id": 1,
                "quality_score": 95,
                "completeness_score": 98,
                "accuracy_score": 94,
                "consistency_score": 92,
                "access_count": 1250,
                "retention_period": 2555,
                "business_purpose": "Análise de comportamento e segmentação de clientes",
                "usage_guidelines": "Uso restrito para análises internas e campanhas de marketing",
                "tags": ["customer", "pii", "marketing", "analytics"],
                "meta_data": {
                    "schema_version": "2.1",
                    "last_schema_change": "2024-12-15",
                    "data_lineage_verified": True
                },
                "is_active": True,
                "is_deprecated": False,
                "created_at": "2025-01-01T00:00:00",
                "updated_at": "2025-01-01T00:00:00",
                "created_by": "admin",
                "updated_by": "data_steward"
            }
        else:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        logger.info(f"Obtendo entidade {entity_id}")
        return entity
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/", response_model=EntityResponseSchema, status_code=201)
async def create_entity(
    entity: EntityCreateSchema,
    db: Session = Depends(get_db),
    user_id: Optional[str] = Query(None, description="ID do usuário")
):
    """Criar nova entidade"""
    try:
        # Mock creation
        new_entity = {
            "id": 999,
            "name": entity.name,
            "display_name": entity.display_name,
            "description": entity.description,
            "domain_id": entity.domain_id,
            "entity_type": entity.entity_type,
            "classification": entity.classification,
            "owner_id": entity.owner_id,
            "quality_score": 0,
            "is_active": True,
            "created_at": "2025-01-11T00:00:00",
            "updated_at": "2025-01-11T00:00:00",
            "created_by": user_id or "system"
        }
        
        logger.info(f"Entidade criada: {entity.name}")
        return new_entity
        
    except Exception as e:
        logger.error(f"Erro ao criar entidade: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/{entity_id}", response_model=EntityResponseSchema)
async def update_entity(
    entity_id: int = Path(..., description="ID da entidade"),
    entity: EntityUpdateSchema = Body(...),
    db: Session = Depends(get_db),
    user_id: Optional[str] = Query(None, description="ID do usuário")
):
    """Atualizar entidade existente"""
    try:
        # Mock update
        if entity_id != 1:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        updated_entity = {
            "id": entity_id,
            "name": entity.name or "customer_profiles",
            "display_name": entity.display_name or "Perfis de Clientes",
            "description": entity.description or "Dados consolidados de perfis de clientes",
            "domain_id": entity.domain_id or 1,
            "entity_type": entity.entity_type or "table",
            "classification": entity.classification or "confidential",
            "owner_id": entity.owner_id or 1,
            "quality_score": 95,
            "is_active": True,
            "created_at": "2025-01-01T00:00:00",
            "updated_at": "2025-01-11T00:00:00",
            "updated_by": user_id or "system"
        }
        
        logger.info(f"Entidade {entity_id} atualizada")
        return updated_entity
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao atualizar entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.delete("/{entity_id}", response_model=SuccessSchema)
async def delete_entity(
    entity_id: int = Path(..., description="ID da entidade"),
    db: Session = Depends(get_db),
    user_id: Optional[str] = Query(None, description="ID do usuário")
):
    """Excluir entidade (soft delete)"""
    try:
        if entity_id not in [1, 2]:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        logger.info(f"Entidade {entity_id} excluída por {user_id}")
        return SuccessSchema(message=f"Entidade {entity_id} excluída com sucesso")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao excluir entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/{entity_id}/lineage", response_model=LineageResponseSchema)
async def get_entity_lineage(
    entity_id: int = Path(..., description="ID da entidade"),
    max_depth: int = Query(3, ge=1, le=10, description="Profundidade máxima da linhagem"),
    db: Session = Depends(get_db)
):
    """Obter linhagem de dados da entidade"""
    try:
        if entity_id not in [1, 2]:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        # Mock lineage data
        lineage = {
            "entity_id": entity_id,
            "entity_name": "customer_profiles" if entity_id == 1 else "order_transactions",
            "upstream_entities": [
                {
                    "id": 3,
                    "name": "raw_customer_data",
                    "relationship_type": "derives_from",
                    "transformation_logic": "Data cleansing and normalization"
                }
            ] if entity_id == 1 else [],
            "downstream_entities": [
                {
                    "id": 4,
                    "name": "customer_analytics",
                    "relationship_type": "feeds_into",
                    "transformation_logic": "Aggregation for analytics"
                }
            ] if entity_id == 1 else [],
            "lineage_depth": max_depth,
            "total_relationships": 2 if entity_id == 1 else 0,
            "last_updated": "2025-01-11T00:00:00"
        }
        
        logger.info(f"Obtendo linhagem da entidade {entity_id}")
        return lineage
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter linhagem da entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/{entity_id}/lineage/{target_id}", status_code=201)
async def add_lineage_relationship(
    entity_id: int = Path(..., description="ID da entidade origem"),
    target_id: int = Path(..., description="ID da entidade destino"),
    relationship_type: str = Body("derives_from", description="Tipo de relacionamento"),
    db: Session = Depends(get_db),
    user_id: Optional[str] = Query(None, description="ID do usuário")
):
    """Adicionar relacionamento de linhagem"""
    try:
        if entity_id == target_id:
            raise HTTPException(status_code=400, detail="Entidade não pode ter relacionamento consigo mesma")
        
        if entity_id not in [1, 2] or target_id not in [1, 2, 3, 4]:
            raise HTTPException(status_code=404, detail="Uma ou ambas entidades não encontradas")
        
        logger.info(f"Relacionamento de linhagem adicionado: {entity_id} -> {target_id}")
        return SuccessSchema(message="Relacionamento de linhagem adicionado com sucesso")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao adicionar linhagem: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/{entity_id}/quality", response_model=SuccessSchema)
async def update_quality_score(
    entity_id: int = Path(..., description="ID da entidade"),
    score: int = Body(..., ge=0, le=100, description="Score de qualidade"),
    issues_count: int = Body(0, ge=0, description="Número de problemas"),
    db: Session = Depends(get_db),
    user_id: Optional[str] = Query(None, description="ID do usuário")
):
    """Atualizar score de qualidade da entidade"""
    try:
        if entity_id not in [1, 2]:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        logger.info(f"Score de qualidade da entidade {entity_id} atualizado para {score}")
        return SuccessSchema(message=f"Score de qualidade atualizado para {score}")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao atualizar qualidade da entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/{entity_id}/access", status_code=201)
async def record_access(
    entity_id: int = Path(..., description="ID da entidade"),
    access_type: str = Body(..., description="Tipo de acesso"),
    user_id: Optional[str] = Query(None, description="ID do usuário"),
    db: Session = Depends(get_db)
):
    """Registrar acesso à entidade"""
    try:
        if entity_id not in [1, 2]:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        logger.info(f"Acesso registrado: entidade {entity_id}, tipo {access_type}, usuário {user_id}")
        return SuccessSchema(message="Acesso registrado com sucesso")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao registrar acesso: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

