"""
TBR GDP Core v4.0 - Main Application
Author: Carlos Morais <carlos.morais@f1rst.com.br>

FastAPI application with complete governance domains implementation.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
from datetime import datetime
import psycopg2
from typing import Dict, Any

# Importar routers dos domínios
from .domains.entities.controllers.entities_controller import router as entities_router
from .domains.contracts.controllers.contracts_controller import router as contracts_router
from .domains.quality.controllers.quality_controller import router as quality_router
from .domains.analytics.controllers.analytics_controller import router as analytics_router
from .domains.governance.controllers.governance_controller import router as governance_router
from .domains.monitoring.controllers.monitoring_controller import router as monitoring_router
from .domains.marketplace.controllers.marketplace_controller import router as marketplace_router
from .domains.policies.controllers.policies_controller import router as policies_router
from .domains.integrations.controllers.integrations_controller import router as integrations_router
from .domains.automation.controllers.automation_controller import router as automation_router

# Configuração da aplicação
app = FastAPI(
    title="TBR GDP Core v4.0",
    description="Plataforma Completa de Governança de Dados",
    version="4.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Incluir routers dos domínios
app.include_router(entities_router, prefix="/api/v4/entities", tags=["Entities"])
app.include_router(contracts_router, prefix="/api/v4/contracts", tags=["Contracts"])
app.include_router(quality_router, prefix="/api/v4", tags=["Quality"])
app.include_router(analytics_router, prefix="/api/v4", tags=["Analytics"])
app.include_router(governance_router, prefix="/api/v4", tags=["Governance"])
app.include_router(monitoring_router, prefix="/api/v4", tags=["Monitoring"])
app.include_router(marketplace_router, prefix="/api/v4", tags=["Marketplace"])
app.include_router(policies_router, prefix="/api/v4", tags=["Policies"])
app.include_router(integrations_router, prefix="/api/v4", tags=["Integrations"])
app.include_router(automation_router, prefix="/api/v4", tags=["Automation"])

def check_database_connection() -> bool:
    """Verificar conexão com PostgreSQL"""
    try:
        conn = psycopg2.connect(
            host="localhost",
            database="tbr_gdp_core_v4",
            user="tbr_user",
            password="tbr_password"
        )
        conn.close()
        return True
    except:
        return False

@app.get("/")
async def root() -> Dict[str, Any]:
    """Endpoint raiz com informações da API"""
    return {
        "message": "TBR GDP Core v4.0 - Plataforma de Governança de Dados",
        "version": "4.0.0",
        "author": "Carlos Morais <carlos.morais@f1rst.com.br>",
        "timestamp": datetime.utcnow().isoformat(),
        "status": "operational",
        "domains": {
            "entities": "Catálogo de entidades e metadados",
            "contracts": "Contratos de dados com versionamento",
            "quality": "Sistema de qualidade de dados",
            "permissions": "Controle de acesso RBAC/ABAC",
            "analytics": "Analytics de uso e performance",
            "governance": "Framework de governança",
            "monitoring": "Monitoramento de performance e custos",
            "marketplace": "Marketplace self-service",
            "policies": "Políticas organizacionais",
            "integrations": "Integrações com sistemas externos",
            "automation": "Automação inteligente"
        },
        "endpoints": {
            "total": "80+",
            "documentation": "/docs",
            "health_check": "/health"
        }
    }

@app.get("/health")
async def health_check() -> Dict[str, Any]:
    """Health check endpoint"""
    db_status = "connected" if check_database_connection() else "disconnected"
    
    return {
        "status": "healthy" if db_status == "connected" else "unhealthy",
        "timestamp": datetime.utcnow().isoformat(),
        "database": db_status,
        "version": "4.0.0",
        "uptime": "operational"
    }

@app.exception_handler(404)
async def not_found_handler(request, exc):
    """Handler para endpoints não encontrados"""
    return JSONResponse(
        status_code=404,
        content={
            "error": "Endpoint não encontrado",
            "message": f"O endpoint {request.url.path} não existe",
            "available_docs": "/docs",
            "timestamp": datetime.utcnow().isoformat()
        }
    )

@app.exception_handler(500)
async def internal_error_handler(request, exc):
    """Handler para erros internos"""
    return JSONResponse(
        status_code=500,
        content={
            "error": "Erro interno do servidor",
            "message": "Ocorreu um erro inesperado",
            "timestamp": datetime.utcnow().isoformat()
        }
    )

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8004,
        reload=True,
        log_level="info"
    )

