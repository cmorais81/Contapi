"""
Data Models for Data Governance API
Following SOLID principles and clean architecture
Names in English, audit columns included, Databricks integration ready

Author: Carlos Morais
"""

from sqlalchemy import (
    Column, Integer, String, Text, DateTime, Boolean, Float, 
    ForeignKey, JSON, Enum, Index, UniqueConstraint, BigInteger
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from datetime import datetime
from typing import Optional, Dict, Any, List
import enum
from uuid import uuid4


# Base class for all models
Base = declarative_base()


class TimestampMixin:
    """
    Mixin for audit columns (required by preferences).
    
    Following SOLID principles:
    - SRP: Single responsibility for timestamp management
    - DRY: Don't repeat yourself
    """
    id = Column(Integer, primary_key=True, index=True)
    data_criacao = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    data_atualizacao = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)


# Enums for data classification
class SecurityClassificationEnum(enum.Enum):
    """Security classification levels."""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"


class SensitivityLevelEnum(enum.Enum):
    """Data sensitivity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class DataObjectStatusEnum(enum.Enum):
    """Data object status."""
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"


class QualityStatusEnum(enum.Enum):
    """Quality status."""
    EXCELLENT = "excellent"
    GOOD = "good"
    FAIR = "fair"
    POOR = "poor"
    UNKNOWN = "unknown"


class ContractStatusEnum(enum.Enum):
    """Contract status."""
    DRAFT = "draft"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    EXPIRED = "expired"


class PolicyTypeEnum(enum.Enum):
    """Policy types."""
    RBAC = "rbac"
    ABAC = "abac"
    MASKING = "masking"
    RETENTION = "retention"


# Core Models

class DataObject(Base, TimestampMixin):
    """
    Data Object model representing datasets, tables, files, etc.
    Includes Databricks Unity Catalog integration fields.
    
    Following SOLID principles:
    - SRP: Single responsibility for data object representation
    - OCP: Open for extension with new attributes
    """
    __tablename__ = "data_objects"
    
    # Basic Information
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text)
    object_type = Column(String(100), nullable=False, index=True)  # table, view, file, api, etc.
    
    # Location and Source (Unity Catalog compatible)
    catalog_name = Column(String(255), index=True)  # Unity Catalog catalog
    database_name = Column(String(255), index=True)  # Unity Catalog schema
    schema_name = Column(String(255), index=True)    # Legacy support
    table_name = Column(String(255), index=True)
    full_path = Column(String(1000), index=True)
    source_system = Column(String(255), index=True)
    
    # Unity Catalog Integration
    unity_catalog_id = Column(String(255), index=True)
    unity_catalog_metastore = Column(String(255))
    unity_catalog_workspace = Column(String(255))
    
    # Governance
    owner_id = Column(Integer, ForeignKey("users.id"))
    steward_id = Column(Integer, ForeignKey("users.id"))
    security_classification = Column(Enum(SecurityClassificationEnum), default=SecurityClassificationEnum.INTERNAL)
    sensitivity_level = Column(Enum(SensitivityLevelEnum), default=SensitivityLevelEnum.LOW)
    
    # Status and Quality
    status = Column(Enum(DataObjectStatusEnum), default=DataObjectStatusEnum.ACTIVE)
    quality_score = Column(Float, default=0.0)
    quality_status = Column(Enum(QualityStatusEnum), default=QualityStatusEnum.UNKNOWN)
    
    # Metadata
    schema_definition = Column(JSON)  # Column definitions, data types, etc.
    business_metadata = Column(JSON)  # Business context, purpose, etc.
    technical_metadata = Column(JSON)  # Technical details, performance, etc.
    
    # Usage and Popularity
    access_count = Column(BigInteger, default=0)
    last_accessed = Column(DateTime(timezone=True))
    popularity_score = Column(Float, default=0.0)
    
    # Data Lifecycle and Retention (as per preferences)
    retention_days = Column(Integer, default=2555)  # 7 years default
    expiration_date = Column(DateTime(timezone=True))
    lifecycle_stage = Column(String(50))  # raw, processed, curated, archived
    
    # Size and Performance
    size_bytes = Column(BigInteger)
    row_count = Column(BigInteger)
    column_count = Column(Integer)
    
    # Relationships
    owner = relationship("User", foreign_keys=[owner_id], back_populates="owned_objects")
    steward = relationship("User", foreign_keys=[steward_id], back_populates="stewarded_objects")
    contracts = relationship("DataContract", back_populates="data_object")
    quality_metrics = relationship("QualityMetric", back_populates="data_object")
    lineage_upstream = relationship("DataLineage", foreign_keys="DataLineage.downstream_object_id", back_populates="downstream_object")
    lineage_downstream = relationship("DataLineage", foreign_keys="DataLineage.upstream_object_id", back_populates="upstream_object")
    access_policies = relationship("AccessPolicy", back_populates="data_object")
    
    # Indexes
    __table_args__ = (
        Index('idx_data_object_name_type', 'name', 'object_type'),
        Index('idx_data_object_unity_catalog', 'catalog_name', 'database_name', 'table_name'),
        Index('idx_data_object_classification', 'security_classification', 'sensitivity_level'),
        Index('idx_data_object_quality', 'quality_score', 'quality_status'),
        Index('idx_data_object_unity_id', 'unity_catalog_id'),
    )


class DataContract(Base, TimestampMixin):
    """
    Data Contract model for defining data agreements.
    Supports schema, quality, and SLA contracts.
    
    Following SOLID principles:
    - SRP: Single responsibility for contract management
    - OCP: Open for extension with new contract types
    """
    __tablename__ = "data_contracts"
    
    # Basic Information
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text)
    version = Column(String(50), nullable=False, default="1.0.0")
    
    # Contract Details
    data_object_id = Column(Integer, ForeignKey("data_objects.id"), nullable=False)
    contract_type = Column(String(100), nullable=False)  # schema, quality, sla, etc.
    status = Column(Enum(ContractStatusEnum), default=ContractStatusEnum.DRAFT)
    
    # Schema Contract
    schema_definition = Column(JSON)  # Expected schema
    schema_validation_rules = Column(JSON)  # Validation rules
    
    # Quality Contract
    quality_rules = Column(JSON)  # Quality expectations
    quality_thresholds = Column(JSON)  # Acceptable thresholds
    
    # SLA Contract
    availability_sla = Column(Float)  # Availability percentage
    latency_sla = Column(Integer)  # Max latency in ms
    freshness_sla = Column(Integer)  # Max data age in minutes
    
    # Governance
    owner_id = Column(Integer, ForeignKey("users.id"))
    approver_id = Column(Integer, ForeignKey("users.id"))
    
    # Validation
    last_validation = Column(DateTime(timezone=True))
    validation_status = Column(String(50))  # passed, failed, pending
    validation_results = Column(JSON)
    
    # Lifecycle
    effective_from = Column(DateTime(timezone=True))
    effective_until = Column(DateTime(timezone=True))
    
    # Relationships
    data_object = relationship("DataObject", back_populates="contracts")
    owner = relationship("User", foreign_keys=[owner_id])
    approver = relationship("User", foreign_keys=[approver_id])
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('data_object_id', 'name', 'version', name='uq_contract_version'),
        Index('idx_contract_status', 'status'),
        Index('idx_contract_validation', 'validation_status', 'last_validation'),
        Index('idx_contract_effective', 'effective_from', 'effective_until'),
    )


class DataLineage(Base, TimestampMixin):
    """
    Data Lineage model for tracking data flow.
    Supports column-level lineage and transformation tracking.
    
    Following SOLID principles:
    - SRP: Single responsibility for lineage tracking
    - OCP: Open for extension with new lineage types
    """
    __tablename__ = "data_lineage"
    
    # Lineage Relationship
    upstream_object_id = Column(Integer, ForeignKey("data_objects.id"), nullable=False)
    downstream_object_id = Column(Integer, ForeignKey("data_objects.id"), nullable=False)
    
    # Lineage Details
    lineage_type = Column(String(100), nullable=False)  # direct, derived, aggregated, etc.
    transformation_logic = Column(Text)  # SQL, code, description
    transformation_type = Column(String(100))  # etl, elt, streaming, batch
    
    # Process Information
    process_name = Column(String(255))
    process_id = Column(String(255))
    job_name = Column(String(255))
    job_id = Column(String(255))
    
    # Databricks Integration
    databricks_job_id = Column(String(255))
    databricks_run_id = Column(String(255))
    databricks_notebook_path = Column(String(1000))
    
    # Confidence and Quality
    confidence_score = Column(Float, default=1.0)  # 0-1 confidence in lineage
    lineage_source = Column(String(100))  # manual, automated, inferred
    
    # Metadata
    column_mapping = Column(JSON)  # Column-level lineage
    business_context = Column(Text)
    technical_details = Column(JSON)
    
    # Relationships
    upstream_object = relationship("DataObject", foreign_keys=[upstream_object_id], back_populates="lineage_downstream")
    downstream_object = relationship("DataObject", foreign_keys=[downstream_object_id], back_populates="lineage_upstream")
    
    # Constraints
    __table_args__ = (
        UniqueConstraint('upstream_object_id', 'downstream_object_id', 'lineage_type', name='uq_lineage_relationship'),
        Index('idx_lineage_upstream', 'upstream_object_id'),
        Index('idx_lineage_downstream', 'downstream_object_id'),
        Index('idx_lineage_type', 'lineage_type'),
        Index('idx_lineage_databricks', 'databricks_job_id', 'databricks_run_id'),
    )


class QualityMetric(Base, TimestampMixin):
    """
    Quality Metric model for data quality tracking.
    Stores historical results as per preferences.
    
    Following SOLID principles:
    - SRP: Single responsibility for quality metrics
    - OCP: Open for extension with new metric types
    """
    __tablename__ = "quality_metrics"
    
    # Basic Information
    data_object_id = Column(Integer, ForeignKey("data_objects.id"), nullable=False)
    metric_name = Column(String(255), nullable=False)
    metric_type = Column(String(100), nullable=False)  # completeness, accuracy, consistency, etc.
    
    # Metric Values
    metric_value = Column(Float, nullable=False)
    threshold_value = Column(Float)
    status = Column(String(50))  # passed, failed, warning
    
    # Execution Details
    execution_id = Column(String(255))
    execution_timestamp = Column(DateTime(timezone=True), nullable=False)
    execution_duration = Column(Integer)  # in milliseconds
    
    # Rule Definition
    rule_definition = Column(JSON)
    rule_sql = Column(Text)
    
    # Context
    dimension = Column(String(100))  # completeness, accuracy, consistency, timeliness, validity, uniqueness
    business_impact = Column(String(100))  # low, medium, high, critical
    
    # Databricks Integration
    databricks_job_id = Column(String(255))
    databricks_run_id = Column(String(255))
    
    # Metadata
    details = Column(JSON)  # Additional metric details
    error_details = Column(JSON)  # Error information if failed
    
    # Relationships
    data_object = relationship("DataObject", back_populates="quality_metrics")
    
    # Indexes
    __table_args__ = (
        Index('idx_quality_object_metric', 'data_object_id', 'metric_name'),
        Index('idx_quality_execution', 'execution_timestamp', 'status'),
        Index('idx_quality_type_dimension', 'metric_type', 'dimension'),
        Index('idx_quality_databricks', 'databricks_job_id', 'databricks_run_id'),
    )


class QualityRule(Base, TimestampMixin):
    """
    Quality Rule model for defining quality checks.
    
    Following SOLID principles:
    - SRP: Single responsibility for quality rule definition
    """
    __tablename__ = "quality_rules"
    
    # Basic Information
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text)
    rule_type = Column(String(100), nullable=False)
    
    # Rule Definition
    rule_sql = Column(Text)
    rule_config = Column(JSON)
    threshold_value = Column(Float)
    
    # Target
    data_object_id = Column(Integer, ForeignKey("data_objects.id"))
    column_name = Column(String(255))
    
    # Status
    is_active = Column(Boolean, default=True)
    severity = Column(String(50))  # low, medium, high, critical
    
    # Schedule
    schedule_cron = Column(String(100))
    last_execution = Column(DateTime(timezone=True))
    next_execution = Column(DateTime(timezone=True))
    
    # Relationships
    data_object = relationship("DataObject")
    
    # Indexes
    __table_args__ = (
        Index('idx_quality_rule_object', 'data_object_id', 'is_active'),
        Index('idx_quality_rule_schedule', 'next_execution', 'is_active'),
    )


class User(Base, TimestampMixin):
    """
    User model for governance roles.
    
    Following SOLID principles:
    - SRP: Single responsibility for user management
    - OCP: Open for extension with new user attributes
    """
    __tablename__ = "users"
    
    # Basic Information
    username = Column(String(100), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    full_name = Column(String(255))
    
    # Authentication
    hashed_password = Column(String(255))
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)
    
    # Profile
    department = Column(String(100))
    role = Column(String(100))
    phone = Column(String(50))
    
    # Governance Roles
    is_data_owner = Column(Boolean, default=False)
    is_data_steward = Column(Boolean, default=False)
    is_data_analyst = Column(Boolean, default=False)
    
    # Preferences
    preferences = Column(JSON)
    
    # Last Activity
    last_login = Column(DateTime(timezone=True))
    last_activity = Column(DateTime(timezone=True))
    
    # Relationships
    owned_objects = relationship("DataObject", foreign_keys="DataObject.owner_id", back_populates="owner")
    stewarded_objects = relationship("DataObject", foreign_keys="DataObject.steward_id", back_populates="steward")
    
    # Indexes
    __table_args__ = (
        Index('idx_user_role', 'role', 'department'),
        Index('idx_user_governance', 'is_data_owner', 'is_data_steward'),
    )


class AccessPolicy(Base, TimestampMixin):
    """
    Access Policy model for data access control.
    Supports masking policies as per preferences.
    
    Following SOLID principles:
    - SRP: Single responsibility for access control
    - OCP: Open for extension with new policy types
    """
    __tablename__ = "access_policies"
    
    # Basic Information
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text)
    policy_type = Column(Enum(PolicyTypeEnum), nullable=False)
    
    # Target
    data_object_id = Column(Integer, ForeignKey("data_objects.id"))
    resource_pattern = Column(String(500))  # Pattern for multiple resources
    
    # Policy Definition
    policy_definition = Column(JSON, nullable=False)
    conditions = Column(JSON)  # Access conditions
    
    # Actions
    allowed_actions = Column(JSON)  # read, write, delete, etc.
    denied_actions = Column(JSON)
    
    # Subjects
    users = Column(JSON)  # User IDs or patterns
    groups = Column(JSON)  # Group names or patterns
    roles = Column(JSON)  # Role names or patterns
    
    # Masking Rules (as per preferences)
    masking_rules = Column(JSON)  # Column masking rules for Databricks
    masking_fields = Column(JSON)  # Fields to be masked
    
    # Status and Lifecycle
    is_active = Column(Boolean, default=True)
    priority = Column(Integer, default=100)
    effective_from = Column(DateTime(timezone=True))
    effective_until = Column(DateTime(timezone=True))
    
    # Governance
    created_by = Column(Integer, ForeignKey("users.id"))
    approved_by = Column(Integer, ForeignKey("users.id"))
    
    # Relationships
    data_object = relationship("DataObject", back_populates="access_policies")
    creator = relationship("User", foreign_keys=[created_by])
    approver = relationship("User", foreign_keys=[approved_by])
    
    # Indexes
    __table_args__ = (
        Index('idx_policy_object', 'data_object_id', 'is_active'),
        Index('idx_policy_type', 'policy_type', 'is_active'),
        Index('idx_policy_effective', 'effective_from', 'effective_until'),
    )


class AuditLog(Base, TimestampMixin):
    """
    Audit Log model for tracking all activities.
    Includes retention policy as per preferences.
    
    Following SOLID principles:
    - SRP: Single responsibility for audit logging
    - OCP: Open for extension with new event types
    """
    __tablename__ = "audit_logs"
    
    # Event Information
    event_type = Column(String(100), nullable=False, index=True)
    event_action = Column(String(100), nullable=False)
    event_source = Column(String(100))  # api, ui, system, etc.
    
    # Subject
    user_id = Column(Integer, ForeignKey("users.id"))
    session_id = Column(String(255))
    ip_address = Column(String(45))
    user_agent = Column(String(500))
    
    # Object
    resource_type = Column(String(100))
    resource_id = Column(String(255))
    resource_name = Column(String(255))
    
    # Details
    event_details = Column(JSON)
    before_state = Column(JSON)
    after_state = Column(JSON)
    
    # Result
    success = Column(Boolean, nullable=False)
    error_message = Column(Text)
    
    # Context
    business_context = Column(String(255))
    compliance_tags = Column(JSON)
    
    # Retention (as per preferences)
    retention_until = Column(DateTime(timezone=True))
    
    # Relationships
    user = relationship("User")
    
    # Indexes
    __table_args__ = (
        Index('idx_audit_event', 'event_type', 'event_action'),
        Index('idx_audit_user', 'user_id', 'data_criacao'),
        Index('idx_audit_resource', 'resource_type', 'resource_id'),
        Index('idx_audit_timestamp', 'data_criacao'),
        Index('idx_audit_retention', 'retention_until'),
    )


class MetadataManagement(Base, TimestampMixin):
    """
    Metadata Management model for managing metadata lifecycle.
    As per preferences for governance themes.
    
    Following SOLID principles:
    - SRP: Single responsibility for metadata management
    """
    __tablename__ = "metadata_management"
    
    # Basic Information
    data_object_id = Column(Integer, ForeignKey("data_objects.id"), nullable=False)
    metadata_type = Column(String(100), nullable=False)  # business, technical, operational
    
    # Metadata Content
    metadata_key = Column(String(255), nullable=False)
    metadata_value = Column(JSON)
    metadata_source = Column(String(100))  # manual, automated, inferred
    
    # Lifecycle
    version = Column(String(50))
    is_current = Column(Boolean, default=True)
    superseded_by = Column(Integer, ForeignKey("metadata_management.id"))
    
    # Governance
    created_by = Column(Integer, ForeignKey("users.id"))
    approved_by = Column(Integer, ForeignKey("users.id"))
    
    # Relationships
    data_object = relationship("DataObject")
    creator = relationship("User", foreign_keys=[created_by])
    approver = relationship("User", foreign_keys=[approved_by])
    
    # Indexes
    __table_args__ = (
        Index('idx_metadata_object_type', 'data_object_id', 'metadata_type'),
        Index('idx_metadata_key', 'metadata_key', 'is_current'),
        UniqueConstraint('data_object_id', 'metadata_key', 'version', name='uq_metadata_version'),
    )

