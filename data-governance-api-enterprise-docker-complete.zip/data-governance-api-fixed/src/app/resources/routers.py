"""
Main API Router
Following SOLID principles - Simplified version with existing endpoints

Author: Carlos Morais
"""

from fastapi import APIRouter
from .endpoints import data_objects

# Create main API router
api_router = APIRouter()

# Include endpoint routers
api_router.include_router(
    data_objects.router,
    prefix="/data-objects",
    tags=["Data Objects"]
)

# Health check endpoint
@api_router.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Data Governance API",
        "version": "1.0.0"
    }

# Metrics endpoint
@api_router.get("/metrics")
async def get_metrics():
    """Get API metrics"""
    return {
        "endpoints": 2,
        "status": "operational",
        "uptime": "running"
    }

