"""
Custom Exceptions for Data Governance API
Following SOLID principles and providing structured error handling

Author: Carlos Morais
"""

from typing import Optional, Dict, Any, List
import uuid
from datetime import datetime


class BaseDataGovernanceException(Exception):
    """
    Base exception for all data governance errors.
    
    Following SOLID principles:
    - SRP: Single responsibility for base exception behavior
    - OCP: Open for extension by specific exception types
    """
    
    def __init__(
        self, 
        message: str, 
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        user_message: Optional[str] = None
    ):
        super().__init__(message)
        self.message = message
        self.error_code = error_code or self.__class__.__name__
        self.details = details or {}
        self.user_message = user_message or message
        self.error_id = str(uuid.uuid4())
        self.timestamp = datetime.utcnow()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        return {
            "error_id": self.error_id,
            "error_code": self.error_code,
            "message": self.message,
            "user_message": self.user_message,
            "details": self.details,
            "timestamp": self.timestamp.isoformat()
        }


class ValidationError(BaseDataGovernanceException):
    """Exception for validation errors."""
    
    def __init__(
        self, 
        message: str, 
        field: Optional[str] = None,
        value: Optional[Any] = None,
        validation_rules: Optional[Dict[str, Any]] = None
    ):
        details = {
            "field": field,
            "value": value,
            "validation_rules": validation_rules
        }
        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            details=details,
            user_message=f"Validation failed: {message}"
        )


class EntityNotFoundError(BaseDataGovernanceException):
    """Exception for entity not found errors."""
    
    def __init__(
        self, 
        message: str, 
        entity_type: Optional[str] = None,
        entity_id: Optional[str] = None
    ):
        details = {
            "entity_type": entity_type,
            "entity_id": entity_id
        }
        super().__init__(
            message=message,
            error_code="ENTITY_NOT_FOUND",
            details=details,
            user_message=f"The requested {entity_type or 'resource'} was not found"
        )


class BusinessRuleViolationError(BaseDataGovernanceException):
    """Exception for business rule violations."""
    
    def __init__(
        self, 
        message: str, 
        rule_name: Optional[str] = None,
        rule_details: Optional[Dict[str, Any]] = None
    ):
        details = {
            "rule_name": rule_name,
            "rule_details": rule_details
        }
        super().__init__(
            message=message,
            error_code="BUSINESS_RULE_VIOLATION",
            details=details,
            user_message=f"Business rule violation: {message}"
        )


class AuthenticationError(BaseDataGovernanceException):
    """Exception for authentication errors."""
    
    def __init__(
        self, 
        message: str = "Authentication failed",
        auth_method: Optional[str] = None,
        reason: Optional[str] = None
    ):
        details = {
            "auth_method": auth_method,
            "reason": reason
        }
        super().__init__(
            message=message,
            error_code="AUTHENTICATION_ERROR",
            details=details,
            user_message="Authentication is required to access this resource"
        )


class AuthorizationError(BaseDataGovernanceException):
    """Exception for authorization errors."""
    
    def __init__(
        self, 
        message: str = "Access denied",
        required_permission: Optional[str] = None,
        resource: Optional[str] = None
    ):
        details = {
            "required_permission": required_permission,
            "resource": resource
        }
        super().__init__(
            message=message,
            error_code="AUTHORIZATION_ERROR",
            details=details,
            user_message="You don't have permission to access this resource"
        )


class DatabaseError(BaseDataGovernanceException):
    """Exception for database-related errors."""
    
    def __init__(
        self, 
        message: str,
        operation: Optional[str] = None,
        table: Optional[str] = None
    ):
        details = {
            "operation": operation,
            "table": table
        }
        super().__init__(
            message=message,
            error_code="DATABASE_ERROR",
            details=details,
            user_message="A database error occurred. Please try again later."
        )


class ExternalServiceError(BaseDataGovernanceException):
    """Exception for external service errors."""
    
    def __init__(
        self, 
        message: str,
        service_name: Optional[str] = None,
        status_code: Optional[int] = None
    ):
        details = {
            "service_name": service_name,
            "status_code": status_code
        }
        super().__init__(
            message=message,
            error_code="EXTERNAL_SERVICE_ERROR",
            details=details,
            user_message="An external service is temporarily unavailable. Please try again later."
        )


# Exception mapping for HTTP status codes
EXCEPTION_STATUS_MAP = {
    ValidationError: 400,
    AuthenticationError: 401,
    AuthorizationError: 403,
    EntityNotFoundError: 404,
    BusinessRuleViolationError: 422,
    DatabaseError: 500,
    ExternalServiceError: 502,
    BaseDataGovernanceException: 500
}


def get_http_status_for_exception(exception: Exception) -> int:
    """Get appropriate HTTP status code for exception."""
    for exc_type, status_code in EXCEPTION_STATUS_MAP.items():
        if isinstance(exception, exc_type):
            return status_code
    return 500  # Default to internal server error

