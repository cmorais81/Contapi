"""
Pagination utilities for API responses
Following SOLID principles

Author: Carlos Morais
"""

from typing import List, Dict, Any, Optional, TypeVar, Generic
from pydantic import BaseModel, Field
from fastapi import Query

T = TypeVar('T')


class PaginationParams(BaseModel):
    """
    Pagination parameters for API requests.
    
    Following SOLID principles:
    - SRP: Single responsibility for pagination parameters
    """
    page: int = Field(default=1, ge=1, description="Page number (1-based)")
    size: int = Field(default=20, ge=1, le=100, description="Page size (max 100)")
    
    @classmethod
    def as_query(
        cls,
        page: int = Query(1, ge=1, description="Page number (1-based)"),
        size: int = Query(20, ge=1, le=100, description="Page size (max 100)")
    ) -> "PaginationParams":
        """Create pagination params from query parameters."""
        return cls(page=page, size=size)


class PaginatedResponse(BaseModel, Generic[T]):
    """
    Paginated response model.
    
    Following SOLID principles:
    - SRP: Single responsibility for paginated responses
    - OCP: Open for extension with different item types
    """
    items: List[T] = Field(description="List of items")
    total: int = Field(description="Total number of items")
    page: int = Field(description="Current page number")
    size: int = Field(description="Page size")
    pages: int = Field(description="Total number of pages")
    has_next: bool = Field(description="Whether there is a next page")
    has_prev: bool = Field(description="Whether there is a previous page")
    
    @classmethod
    def create(
        cls,
        items: List[T],
        total: int,
        page: int,
        size: int
    ) -> "PaginatedResponse[T]":
        """
        Create paginated response.
        
        Following SOLID principles:
        - SRP: Single responsibility for response creation
        """
        pages = (total + size - 1) // size if total > 0 else 0
        
        return cls(
            items=items,
            total=total,
            page=page,
            size=size,
            pages=pages,
            has_next=page < pages,
            has_prev=page > 1
        )


def paginate_query(query, page: int, size: int) -> Dict[str, Any]:
    """
    Apply pagination to SQLAlchemy query.
    
    Following SOLID principles:
    - SRP: Single responsibility for query pagination
    """
    # Get total count
    total = query.count()
    
    # Apply pagination
    offset = (page - 1) * size
    items = query.offset(offset).limit(size).all()
    
    return {
        "items": items,
        "total": total,
        "page": page,
        "size": size,
        "pages": (total + size - 1) // size if total > 0 else 0
    }

