"""
Authentication utilities for API
Following SOLID principles

Author: Carlos Morais
"""

from typing import Optional, Dict, Any, List
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from jose import jwt, JWTError
from datetime import datetime, timedelta

from ..config.global_config import settings
from ..utils.exceptions import AuthenticationError, AuthorizationError

security = HTTPBearer()


class User(BaseModel):
    """User model for authentication."""
    id: int
    username: str
    email: str
    roles: List[str] = []
    is_active: bool = True


class TokenData(BaseModel):
    """Token data model."""
    user_id: int
    username: str
    roles: List[str] = []
    exp: datetime


def create_access_token(user: User, expires_delta: Optional[timedelta] = None) -> str:
    """Create JWT access token."""
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(hours=24)  # Default 24 hours
    
    to_encode = {
        "user_id": user.id,
        "username": user.username,
        "roles": user.roles,
        "exp": expire
    }
    
    encoded_jwt = jwt.encode(to_encode, "secret_key", algorithm="HS256")
    return encoded_jwt


def verify_token(token: str) -> TokenData:
    """Verify JWT token."""
    try:
        payload = jwt.decode(token, "secret_key", algorithms=["HS256"])
        user_id: int = payload.get("user_id")
        username: str = payload.get("username")
        roles: List[str] = payload.get("roles", [])
        exp: datetime = datetime.fromtimestamp(payload.get("exp"))
        
        if user_id is None or username is None:
            raise AuthenticationError("Invalid token payload")
        
        if datetime.utcnow() > exp:
            raise AuthenticationError("Token has expired")
        
        return TokenData(user_id=user_id, username=username, roles=roles, exp=exp)
    
    except JWTError:
        raise AuthenticationError("Invalid token")


async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> User:
    """Get current authenticated user."""
    try:
        token_data = verify_token(credentials.credentials)
        
        # Mock user for testing
        user = User(
            id=token_data.user_id,
            username=token_data.username,
            email=f"{token_data.username}@example.com",
            roles=token_data.roles,
            is_active=True
        )
        
        return user
    
    except AuthenticationError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )


# Mock authentication for testing
async def get_mock_user() -> User:
    """Get mock user for testing."""
    return User(
        id=1,
        username="test_user",
        email="test@example.com",
        roles=["admin", "data_steward"],
        is_active=True
    )

