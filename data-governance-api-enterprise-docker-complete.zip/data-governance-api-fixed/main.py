#!/usr/bin/env python3
"""
Data Governance API - Main Application
Enterprise-ready FastAPI application with Docker support

Author: Carlos Morais
"""

import uvicorn
from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging
import time

# Import configurations and routers
from src.app.config.global_config import Settings
from src.app.resources.routers import api_router
from src.app.utils.exceptions import (
    BaseDataGovernanceException,
    get_http_status_for_exception
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize settings
settings = Settings()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    # Startup
    logger.info("Starting Data Governance API...")
    logger.info(f"Environment: {settings.ENVIRONMENT}")
    logger.info(f"Debug mode: {settings.DEBUG}")
    
    yield
    
    # Shutdown
    logger.info("Shutting down Data Governance API...")

# Create FastAPI application
app = FastAPI(
    title="Data Governance API",
    description="""
    Enterprise Data Governance API following SOLID principles.
    
    This API provides comprehensive data governance capabilities including:
    - Data Objects Management
    - Data Contracts
    - Quality Metrics
    - Data Lineage
    - Access Policies
    - Audit Logging
    """,
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan
)

# Add middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["*"]  # Configure appropriately for production
)

# Request timing middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response

# Exception handlers
@app.exception_handler(BaseDataGovernanceException)
async def data_governance_exception_handler(request: Request, exc: BaseDataGovernanceException):
    """Handle custom data governance exceptions"""
    status_code = get_http_status_for_exception(exc)
    
    logger.error(f"Data Governance Exception: {exc.error_code} - {exc.message}")
    
    return JSONResponse(
        status_code=status_code,
        content=exc.to_dict()
    )

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions"""
    logger.error(f"HTTP Exception: {exc.status_code} - {exc.detail}")
    
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error_code": f"HTTP_{exc.status_code}",
            "message": exc.detail,
            "user_message": exc.detail
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions"""
    logger.error(f"Unhandled Exception: {type(exc).__name__} - {str(exc)}")
    
    return JSONResponse(
        status_code=500,
        content={
            "error_code": "INTERNAL_SERVER_ERROR",
            "message": "An internal server error occurred",
            "user_message": "Something went wrong. Please try again later."
        }
    )

# Include routers
app.include_router(api_router, prefix="/api/v1")

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Data Governance API",
        "version": "1.0.0",
        "status": "operational",
        "docs": "/docs",
        "redoc": "/redoc"
    }

# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Data Governance API",
        "version": "1.0.0",
        "environment": settings.ENVIRONMENT
    }

# Metrics endpoint
@app.get("/metrics")
async def get_metrics():
    """Get API metrics"""
    return {
        "service": "Data Governance API",
        "version": "1.0.0",
        "status": "operational",
        "endpoints": {
            "total": 5,
            "data_objects": 10,
            "health": 1,
            "metrics": 1
        }
    }

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

