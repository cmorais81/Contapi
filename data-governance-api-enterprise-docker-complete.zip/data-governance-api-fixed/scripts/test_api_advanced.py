#!/usr/bin/env python3
"""
Data Governance API - Advanced Test Suite
Comprehensive testing including authentication, data validation, and load testing
"""

import asyncio
import json
import time
import requests
import pytest
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class TestConfig:
    """Test configuration"""
    base_url: str = "http://localhost:8000"
    db_host: str = "localhost"
    db_port: int = 5432
    db_name: str = "data_governance"
    db_user: str = "postgres"
    db_password: str = "postgres123"
    timeout: int = 30
    max_workers: int = 10

@dataclass
class TestResult:
    """Test result container"""
    name: str
    passed: bool
    duration: float
    message: str
    details: Optional[Dict[str, Any]] = None

class DataGovernanceAPITester:
    """Comprehensive API tester"""
    
    def __init__(self, config: TestConfig):
        self.config = config
        self.session = requests.Session()
        self.session.timeout = config.timeout
        self.results: List[TestResult] = []
        
    def add_result(self, name: str, passed: bool, duration: float, message: str, details: Optional[Dict] = None):
        """Add test result"""
        self.results.append(TestResult(name, passed, duration, message, details))
        status = "PASS" if passed else "FAIL"
        logger.info(f"{status}: {name} ({duration:.2f}s) - {message}")
    
    def test_health_endpoint(self) -> bool:
        """Test health endpoint"""
        start_time = time.time()
        try:
            response = self.session.get(f"{self.config.base_url}/health")
            duration = time.time() - start_time
            
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "healthy":
                    self.add_result("Health Check", True, duration, "API is healthy")
                    return True
                else:
                    self.add_result("Health Check", False, duration, f"Unhealthy status: {data}")
                    return False
            else:
                self.add_result("Health Check", False, duration, f"HTTP {response.status_code}")
                return False
                
        except Exception as e:
            duration = time.time() - start_time
            self.add_result("Health Check", False, duration, f"Exception: {str(e)}")
            return False
    
    def test_openapi_spec(self) -> bool:
        """Test OpenAPI specification"""
        start_time = time.time()
        try:
            response = self.session.get(f"{self.config.base_url}/openapi.json")
            duration = time.time() - start_time
            
            if response.status_code == 200:
                spec = response.json()
                required_fields = ["openapi", "info", "paths"]
                
                for field in required_fields:
                    if field not in spec:
                        self.add_result("OpenAPI Spec", False, duration, f"Missing field: {field}")
                        return False
                
                paths_count = len(spec.get("paths", {}))
                self.add_result("OpenAPI Spec", True, duration, f"Valid spec with {paths_count} paths")
                return True
            else:
                self.add_result("OpenAPI Spec", False, duration, f"HTTP {response.status_code}")
                return False
                
        except Exception as e:
            duration = time.time() - start_time
            self.add_result("OpenAPI Spec", False, duration, f"Exception: {str(e)}")
            return False
    
    def test_data_objects_crud(self) -> bool:
        """Test Data Objects CRUD operations"""
        start_time = time.time()
        try:
            # Test GET list
            response = self.session.get(f"{self.config.base_url}/api/v1/data-objects/")
            if response.status_code != 200:
                duration = time.time() - start_time
                self.add_result("Data Objects CRUD", False, duration, f"List failed: HTTP {response.status_code}")
                return False
            
            data = response.json()
            if not isinstance(data, dict) or "items" not in data:
                duration = time.time() - start_time
                self.add_result("Data Objects CRUD", False, duration, "Invalid response format")
                return False
            
            items_count = len(data["items"])
            
            # Test pagination
            response = self.session.get(f"{self.config.base_url}/api/v1/data-objects/?page=1&size=2")
            if response.status_code != 200:
                duration = time.time() - start_time
                self.add_result("Data Objects CRUD", False, duration, f"Pagination failed: HTTP {response.status_code}")
                return False
            
            paginated_data = response.json()
            paginated_count = len(paginated_data["items"])
            
            if paginated_count > 2:
                duration = time.time() - start_time
                self.add_result("Data Objects CRUD", False, duration, f"Pagination not working: got {paginated_count} items")
                return False
            
            # Test search
            response = self.session.get(f"{self.config.base_url}/api/v1/data-objects/search?q=customer")
            if response.status_code != 200:
                duration = time.time() - start_time
                self.add_result("Data Objects CRUD", False, duration, f"Search failed: HTTP {response.status_code}")
                return False
            
            duration = time.time() - start_time
            self.add_result("Data Objects CRUD", True, duration, f"CRUD operations successful ({items_count} items)")
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.add_result("Data Objects CRUD", False, duration, f"Exception: {str(e)}")
            return False
    
    def test_data_contracts(self) -> bool:
        """Test Data Contracts endpoints"""
        start_time = time.time()
        try:
            response = self.session.get(f"{self.config.base_url}/api/v1/data-contracts/")
            duration = time.time() - start_time
            
            if response.status_code == 200:
                data = response.json()
                contracts_count = len(data.get("items", []))
                self.add_result("Data Contracts", True, duration, f"Retrieved {contracts_count} contracts")
                return True
            else:
                self.add_result("Data Contracts", False, duration, f"HTTP {response.status_code}")
                return False
                
        except Exception as e:
            duration = time.time() - start_time
            self.add_result("Data Contracts", False, duration, f"Exception: {str(e)}")
            return False
    
    def test_quality_metrics(self) -> bool:
        """Test Quality Metrics endpoints"""
        start_time = time.time()
        try:
            # Test list endpoint
            response = self.session.get(f"{self.config.base_url}/api/v1/quality/metrics/")
            if response.status_code != 200:
                duration = time.time() - start_time
                self.add_result("Quality Metrics", False, duration, f"List failed: HTTP {response.status_code}")
                return False
            
            data = response.json()
            metrics_count = len(data.get("items", []))
            
            # Test filtering by metric type
            response = self.session.get(f"{self.config.base_url}/api/v1/quality/metrics/?metric_type=completeness")
            if response.status_code != 200:
                duration = time.time() - start_time
                self.add_result("Quality Metrics", False, duration, f"Filter failed: HTTP {response.status_code}")
                return False
            
            filtered_data = response.json()
            filtered_count = len(filtered_data.get("items", []))
            
            duration = time.time() - start_time
            self.add_result("Quality Metrics", True, duration, f"Retrieved {metrics_count} metrics, {filtered_count} filtered")
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.add_result("Quality Metrics", False, duration, f"Exception: {str(e)}")
            return False
    
    def test_data_lineage(self) -> bool:
        """Test Data Lineage endpoints"""
        start_time = time.time()
        try:
            response = self.session.get(f"{self.config.base_url}/api/v1/lineage/")
            duration = time.time() - start_time
            
            if response.status_code == 200:
                data = response.json()
                lineage_count = len(data.get("items", []))
                self.add_result("Data Lineage", True, duration, f"Retrieved {lineage_count} lineage relationships")
                return True
            else:
                self.add_result("Data Lineage", False, duration, f"HTTP {response.status_code}")
                return False
                
        except Exception as e:
            duration = time.time() - start_time
            self.add_result("Data Lineage", False, duration, f"Exception: {str(e)}")
            return False
    
    def test_access_policies(self) -> bool:
        """Test Access Policies endpoints"""
        start_time = time.time()
        try:
            response = self.session.get(f"{self.config.base_url}/api/v1/access-policies/")
            duration = time.time() - start_time
            
            if response.status_code == 200:
                data = response.json()
                policies_count = len(data.get("items", []))
                self.add_result("Access Policies", True, duration, f"Retrieved {policies_count} policies")
                return True
            else:
                self.add_result("Access Policies", False, duration, f"HTTP {response.status_code}")
                return False
                
        except Exception as e:
            duration = time.time() - start_time
            self.add_result("Access Policies", False, duration, f"Exception: {str(e)}")
            return False
    
    def test_response_times(self) -> bool:
        """Test API response times"""
        endpoints = [
            "/health",
            "/metrics",
            "/api/v1/data-objects/",
            "/api/v1/data-contracts/",
            "/api/v1/quality/metrics/",
            "/api/v1/lineage/",
            "/api/v1/access-policies/"
        ]
        
        total_time = 0
        slow_endpoints = []
        
        for endpoint in endpoints:
            start_time = time.time()
            try:
                response = self.session.get(f"{self.config.base_url}{endpoint}")
                duration = time.time() - start_time
                total_time += duration
                
                if duration > 2.0:  # Slow if > 2 seconds
                    slow_endpoints.append(f"{endpoint} ({duration:.2f}s)")
                    
            except Exception as e:
                duration = time.time() - start_time
                total_time += duration
                slow_endpoints.append(f"{endpoint} (error: {str(e)})")
        
        avg_time = total_time / len(endpoints)
        
        if avg_time < 1.0 and not slow_endpoints:
            self.add_result("Response Times", True, total_time, f"Average: {avg_time:.2f}s")
            return True
        else:
            message = f"Average: {avg_time:.2f}s"
            if slow_endpoints:
                message += f", Slow endpoints: {', '.join(slow_endpoints)}"
            self.add_result("Response Times", False, total_time, message)
            return False
    
    def test_concurrent_requests(self) -> bool:
        """Test concurrent request handling"""
        start_time = time.time()
        
        def make_request():
            try:
                response = self.session.get(f"{self.config.base_url}/health")
                return response.status_code == 200
            except:
                return False
        
        try:
            with ThreadPoolExecutor(max_workers=self.config.max_workers) as executor:
                futures = [executor.submit(make_request) for _ in range(20)]
                results = [future.result() for future in futures]
            
            duration = time.time() - start_time
            success_count = sum(results)
            success_rate = (success_count / len(results)) * 100
            
            if success_rate >= 95:
                self.add_result("Concurrent Requests", True, duration, f"{success_count}/{len(results)} successful ({success_rate:.1f}%)")
                return True
            else:
                self.add_result("Concurrent Requests", False, duration, f"Only {success_count}/{len(results)} successful ({success_rate:.1f}%)")
                return False
                
        except Exception as e:
            duration = time.time() - start_time
            self.add_result("Concurrent Requests", False, duration, f"Exception: {str(e)}")
            return False
    
    def test_data_validation(self) -> bool:
        """Test data validation and schema compliance"""
        start_time = time.time()
        try:
            # Test data objects schema
            response = self.session.get(f"{self.config.base_url}/api/v1/data-objects/")
            if response.status_code != 200:
                duration = time.time() - start_time
                self.add_result("Data Validation", False, duration, "Failed to get data objects")
                return False
            
            data = response.json()
            items = data.get("items", [])
            
            if not items:
                duration = time.time() - start_time
                self.add_result("Data Validation", False, duration, "No data objects found")
                return False
            
            # Validate first item schema
            first_item = items[0]
            required_fields = ["id", "name", "object_type", "created_at", "updated_at"]
            
            for field in required_fields:
                if field not in first_item:
                    duration = time.time() - start_time
                    self.add_result("Data Validation", False, duration, f"Missing required field: {field}")
                    return False
            
            # Validate data types
            if not isinstance(first_item["id"], str):
                duration = time.time() - start_time
                self.add_result("Data Validation", False, duration, "ID field is not a string")
                return False
            
            duration = time.time() - start_time
            self.add_result("Data Validation", True, duration, f"Schema validation passed for {len(items)} items")
            return True
            
        except Exception as e:
            duration = time.time() - start_time
            self.add_result("Data Validation", False, duration, f"Exception: {str(e)}")
            return False
    
    def run_all_tests(self) -> Dict[str, Any]:
        """Run all tests and return summary"""
        logger.info("Starting comprehensive API tests...")
        
        tests = [
            self.test_health_endpoint,
            self.test_openapi_spec,
            self.test_data_objects_crud,
            self.test_data_contracts,
            self.test_quality_metrics,
            self.test_data_lineage,
            self.test_access_policies,
            self.test_response_times,
            self.test_concurrent_requests,
            self.test_data_validation
        ]
        
        passed = 0
        failed = 0
        total_duration = 0
        
        for test in tests:
            try:
                result = test()
                if result:
                    passed += 1
                else:
                    failed += 1
            except Exception as e:
                logger.error(f"Test {test.__name__} failed with exception: {str(e)}")
                failed += 1
        
        # Calculate total duration
        total_duration = sum(result.duration for result in self.results)
        
        summary = {
            "total_tests": len(tests),
            "passed": passed,
            "failed": failed,
            "success_rate": (passed / len(tests)) * 100 if tests else 0,
            "total_duration": total_duration,
            "results": [
                {
                    "name": result.name,
                    "passed": result.passed,
                    "duration": result.duration,
                    "message": result.message,
                    "details": result.details
                }
                for result in self.results
            ]
        }
        
        return summary
    
    def generate_report(self, summary: Dict[str, Any]) -> str:
        """Generate detailed test report"""
        report = []
        report.append("=" * 60)
        report.append("           DATA GOVERNANCE API TEST REPORT")
        report.append("=" * 60)
        report.append(f"Total Tests: {summary['total_tests']}")
        report.append(f"Passed: {summary['passed']}")
        report.append(f"Failed: {summary['failed']}")
        report.append(f"Success Rate: {summary['success_rate']:.1f}%")
        report.append(f"Total Duration: {summary['total_duration']:.2f}s")
        report.append("")
        
        if summary['failed'] == 0:
            report.append("🎉 ALL TESTS PASSED! API is ready for production use.")
        else:
            report.append("❌ Some tests failed. Please review the issues below.")
        
        report.append("")
        report.append("Detailed Results:")
        report.append("-" * 40)
        
        for result in summary['results']:
            status = "PASS" if result['passed'] else "FAIL"
            report.append(f"{status}: {result['name']} ({result['duration']:.2f}s)")
            report.append(f"      {result['message']}")
            if result['details']:
                report.append(f"      Details: {json.dumps(result['details'], indent=2)}")
            report.append("")
        
        return "\n".join(report)

def main():
    """Main test execution"""
    config = TestConfig()
    tester = DataGovernanceAPITester(config)
    
    # Run all tests
    summary = tester.run_all_tests()
    
    # Generate and display report
    report = tester.generate_report(summary)
    print(report)
    
    # Save report to file
    with open("api_test_report.txt", "w") as f:
        f.write(report)
    
    logger.info("Test report saved to api_test_report.txt")
    
    # Exit with appropriate code
    if summary['failed'] == 0:
        exit(0)
    else:
        exit(1)

if __name__ == "__main__":
    main()

