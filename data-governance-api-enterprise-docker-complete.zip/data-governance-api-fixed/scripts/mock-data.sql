-- Data Governance API - Mock Data Script
-- Realistic test data for comprehensive testing

-- Set search path
SET search_path TO governance, quality, lineage, security, audit, public;

-- =====================================================
-- USERS (for authentication and ownership)
-- =====================================================

INSERT INTO security.users (id, username, email, full_name, roles, permissions, department, is_active) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'admin', 'admin@datagovernance.com', 'System Administrator', '["admin", "data_steward"]', '["read", "write", "delete", "admin"]', 'IT', true),
('550e8400-e29b-41d4-a716-446655440002', 'data_steward', 'steward@datagovernance.com', 'Data Steward', '["data_steward"]', '["read", "write"]', 'Data Management', true),
('550e8400-e29b-41d4-a716-446655440003', 'analyst', 'analyst@datagovernance.com', 'Data Analyst', '["analyst"]', '["read"]', 'Analytics', true),
('550e8400-e29b-41d4-a716-446655440004', 'engineer', 'engineer@datagovernance.com', 'Data Engineer', '["engineer"]', '["read", "write"]', 'Engineering', true),
('550e8400-e29b-41d4-a716-446655440005', 'scientist', 'scientist@datagovernance.com', 'Data Scientist', '["scientist"]', '["read"]', 'Data Science', true);

-- =====================================================
-- DATA OBJECTS (comprehensive test data)
-- =====================================================

-- Customer Data Objects
INSERT INTO governance.data_objects (id, name, description, object_type, catalog_name, database_name, schema_name, table_name, location, format, size_bytes, row_count, column_count, classification, sensitivity_level, owner_user, owner_team, steward_user, steward_team, business_domain, technical_domain, tags, properties, schema_definition) VALUES
('550e8400-e29b-41d4-a716-446655440010', 'Customer Master Data', 'Master customer data with complete profile information', 'table', 'production', 'crm', 'master', 'customers', 's3://data-lake/crm/master/customers/', 'delta', 2147483648, 1500000, 25, 'confidential', 'high', 'data_steward', 'Data Management', 'data_steward', 'Data Management', 'Customer', 'CRM', '["pii", "master_data", "customer"]', '{"retention_years": 7, "backup_frequency": "daily", "encryption": true}', '{"columns": [{"name": "customer_id", "type": "string", "nullable": false, "primary_key": true}, {"name": "first_name", "type": "string", "nullable": false, "pii": true}, {"name": "last_name", "type": "string", "nullable": false, "pii": true}, {"name": "email", "type": "string", "nullable": false, "pii": true}, {"name": "phone", "type": "string", "nullable": true, "pii": true}, {"name": "birth_date", "type": "date", "nullable": true, "pii": true}, {"name": "address", "type": "string", "nullable": true, "pii": true}, {"name": "city", "type": "string", "nullable": true}, {"name": "state", "type": "string", "nullable": true}, {"name": "country", "type": "string", "nullable": false}, {"name": "postal_code", "type": "string", "nullable": true}, {"name": "customer_segment", "type": "string", "nullable": true}, {"name": "registration_date", "type": "timestamp", "nullable": false}, {"name": "last_activity_date", "type": "timestamp", "nullable": true}, {"name": "is_active", "type": "boolean", "nullable": false}]}'),

('550e8400-e29b-41d4-a716-446655440011', 'Customer Transactions', 'All customer transaction history', 'table', 'production', 'finance', 'transactions', 'customer_transactions', 's3://data-lake/finance/transactions/customer_transactions/', 'delta', 5368709120, 25000000, 15, 'internal', 'medium', 'engineer', 'Engineering', 'data_steward', 'Data Management', 'Finance', 'Transactions', '["transactions", "finance", "customer"]', '{"retention_years": 10, "backup_frequency": "hourly", "encryption": true}', '{"columns": [{"name": "transaction_id", "type": "string", "nullable": false, "primary_key": true}, {"name": "customer_id", "type": "string", "nullable": false, "foreign_key": "customers.customer_id"}, {"name": "transaction_date", "type": "timestamp", "nullable": false}, {"name": "amount", "type": "decimal", "nullable": false}, {"name": "currency", "type": "string", "nullable": false}, {"name": "transaction_type", "type": "string", "nullable": false}, {"name": "payment_method", "type": "string", "nullable": false}, {"name": "merchant_id", "type": "string", "nullable": true}, {"name": "description", "type": "string", "nullable": true}, {"name": "status", "type": "string", "nullable": false}, {"name": "created_at", "type": "timestamp", "nullable": false}]}'),

-- Product Data Objects
('550e8400-e29b-41d4-a716-446655440012', 'Product Catalog', 'Complete product catalog with pricing and inventory', 'table', 'production', 'inventory', 'catalog', 'products', 's3://data-lake/inventory/catalog/products/', 'delta', 1073741824, 500000, 20, 'internal', 'low', 'analyst', 'Analytics', 'data_steward', 'Data Management', 'Product', 'Inventory', '["products", "catalog", "inventory"]', '{"retention_years": 5, "backup_frequency": "daily", "encryption": false}', '{"columns": [{"name": "product_id", "type": "string", "nullable": false, "primary_key": true}, {"name": "product_name", "type": "string", "nullable": false}, {"name": "description", "type": "string", "nullable": true}, {"name": "category", "type": "string", "nullable": false}, {"name": "subcategory", "type": "string", "nullable": true}, {"name": "brand", "type": "string", "nullable": true}, {"name": "price", "type": "decimal", "nullable": false}, {"name": "cost", "type": "decimal", "nullable": false}, {"name": "currency", "type": "string", "nullable": false}, {"name": "stock_quantity", "type": "integer", "nullable": false}, {"name": "reorder_level", "type": "integer", "nullable": false}, {"name": "supplier_id", "type": "string", "nullable": true}, {"name": "created_at", "type": "timestamp", "nullable": false}, {"name": "updated_at", "type": "timestamp", "nullable": false}]}'),

-- Analytics Data Objects
('550e8400-e29b-41d4-a716-446655440013', 'Customer Analytics Summary', 'Aggregated customer analytics and KPIs', 'view', 'analytics', 'reporting', 'customer', 'customer_summary', 's3://data-lake/analytics/reporting/customer_summary/', 'delta', 536870912, 150000, 30, 'internal', 'medium', 'scientist', 'Data Science', 'analyst', 'Analytics', 'Customer', 'Analytics', '["analytics", "kpi", "customer", "summary"]', '{"refresh_frequency": "daily", "materialized": true, "encryption": false}', '{"columns": [{"name": "customer_id", "type": "string", "nullable": false}, {"name": "total_transactions", "type": "integer", "nullable": false}, {"name": "total_amount", "type": "decimal", "nullable": false}, {"name": "avg_transaction_amount", "type": "decimal", "nullable": false}, {"name": "first_transaction_date", "type": "date", "nullable": false}, {"name": "last_transaction_date", "type": "date", "nullable": true}, {"name": "customer_lifetime_value", "type": "decimal", "nullable": false}, {"name": "customer_segment", "type": "string", "nullable": true}, {"name": "risk_score", "type": "decimal", "nullable": true}, {"name": "churn_probability", "type": "decimal", "nullable": true}]}'),

-- External Data Objects
('550e8400-e29b-41d4-a716-446655440014', 'External Market Data', 'External market data from third-party providers', 'dataset', 'external', 'market_data', 'feeds', 'market_prices', 's3://external-data/market/prices/', 'parquet', 268435456, 1000000, 10, 'public', 'low', 'engineer', 'Engineering', 'analyst', 'Analytics', 'Market', 'External', '["external", "market", "prices", "reference"]', '{"source": "Bloomberg", "update_frequency": "real-time", "encryption": false}', '{"columns": [{"name": "symbol", "type": "string", "nullable": false}, {"name": "price", "type": "decimal", "nullable": false}, {"name": "volume", "type": "integer", "nullable": false}, {"name": "timestamp", "type": "timestamp", "nullable": false}, {"name": "exchange", "type": "string", "nullable": false}]}'),

-- Streaming Data Objects
('550e8400-e29b-41d4-a716-446655440015', 'Real-time Events Stream', 'Real-time customer behavior events', 'stream', 'streaming', 'events', 'realtime', 'customer_events', 'kafka://events-cluster/customer-events', 'json', 0, 0, 8, 'internal', 'medium', 'engineer', 'Engineering', 'engineer', 'Engineering', 'Events', 'Streaming', '["streaming", "events", "realtime", "customer"]', '{"retention_hours": 168, "partitions": 12, "replication_factor": 3}', '{"columns": [{"name": "event_id", "type": "string", "nullable": false}, {"name": "customer_id", "type": "string", "nullable": false}, {"name": "event_type", "type": "string", "nullable": false}, {"name": "event_data", "type": "json", "nullable": false}, {"name": "timestamp", "type": "timestamp", "nullable": false}, {"name": "session_id", "type": "string", "nullable": true}, {"name": "user_agent", "type": "string", "nullable": true}, {"name": "ip_address", "type": "string", "nullable": true}]}');

-- =====================================================
-- DATA CONTRACTS
-- =====================================================

INSERT INTO governance.data_contracts (id, name, description, version, data_object_id, contract_type, status, schema_definition, quality_rules, sla_requirements, usage_policies, retention_policy, validation_rules, business_rules, owner_user, owner_team, approver_user, approved_at, effective_from) VALUES
('550e8400-e29b-41d4-a716-446655440020', 'Customer Master Data Contract', 'Data contract for customer master data ensuring PII protection and quality', '2.1.0', '550e8400-e29b-41d4-a716-446655440010', 'schema', 'active', '{"schema_version": "2.1.0", "required_fields": ["customer_id", "first_name", "last_name", "email", "country"], "optional_fields": ["phone", "birth_date", "address"], "data_types": {"customer_id": "string", "email": "email_format"}}', '[{"rule": "email_format_validation", "field": "email", "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"}, {"rule": "completeness_check", "field": "customer_id", "threshold": 100}, {"rule": "uniqueness_check", "field": "customer_id", "threshold": 100}]', '{"availability": 99.9, "response_time_ms": 500, "data_freshness_hours": 1}', '{"access_control": "rbac", "masking_required": ["email", "phone", "birth_date", "address"], "export_restrictions": ["gdpr_compliance"]}', '{"retention_period_years": 7, "deletion_method": "secure_wipe", "archive_after_years": 5}', '[{"field": "email", "validation": "email_format"}, {"field": "country", "validation": "iso_country_code"}]', '[{"rule": "customer_age_validation", "description": "Customer must be at least 18 years old"}, {"rule": "unique_email", "description": "Email must be unique across all customers"}]', 'data_steward', 'Data Management', 'admin', '2024-01-15 10:00:00+00', '2024-01-15 00:00:00+00'),

('550e8400-e29b-41d4-a716-446655440021', 'Transaction Data Contract', 'Data contract for financial transaction data', '1.5.0', '550e8400-e29b-41d4-a716-446655440011', 'quality', 'active', '{"schema_version": "1.5.0", "required_fields": ["transaction_id", "customer_id", "amount", "currency", "transaction_date"], "data_types": {"amount": "decimal(15,2)", "currency": "iso_currency_code"}}', '[{"rule": "amount_validation", "field": "amount", "min_value": 0.01, "max_value": 1000000}, {"rule": "currency_validation", "field": "currency", "allowed_values": ["USD", "EUR", "GBP", "JPY"]}, {"rule": "completeness_check", "field": "transaction_id", "threshold": 100}]', '{"availability": 99.95, "response_time_ms": 200, "data_freshness_minutes": 5}', '{"access_control": "rbac", "audit_required": true, "export_restrictions": ["financial_compliance"]}', '{"retention_period_years": 10, "deletion_method": "secure_wipe", "archive_after_years": 7}', '[{"field": "amount", "validation": "positive_decimal"}, {"field": "currency", "validation": "iso_currency"}]', '[{"rule": "transaction_limit", "description": "Single transaction cannot exceed $1M"}, {"rule": "customer_exists", "description": "Customer must exist in customer master data"}]', 'engineer', 'Engineering', 'data_steward', '2024-02-01 14:30:00+00', '2024-02-01 00:00:00+00');

-- =====================================================
-- ENTITIES
-- =====================================================

INSERT INTO governance.entities (id, name, description, entity_type, business_domain, attributes, relationships, business_rules, owner_user, owner_team) VALUES
('550e8400-e29b-41d4-a716-446655440030', 'Customer', 'Core customer business entity', 'customer', 'Customer', '[{"name": "customer_id", "type": "identifier", "required": true}, {"name": "personal_info", "type": "object", "pii": true}, {"name": "preferences", "type": "object"}, {"name": "status", "type": "enum", "values": ["active", "inactive", "suspended"]}]', '[{"entity": "Transaction", "type": "one_to_many", "description": "Customer can have multiple transactions"}, {"entity": "Product", "type": "many_to_many", "description": "Customer can purchase multiple products"}]', '[{"rule": "age_requirement", "description": "Customer must be at least 18 years old"}, {"rule": "unique_email", "description": "Email must be unique"}]', 'data_steward', 'Data Management'),

('550e8400-e29b-41d4-a716-446655440031', 'Transaction', 'Financial transaction business entity', 'transaction', 'Finance', '[{"name": "transaction_id", "type": "identifier", "required": true}, {"name": "amount", "type": "monetary", "required": true}, {"name": "currency", "type": "currency_code", "required": true}, {"name": "type", "type": "enum", "values": ["purchase", "refund", "transfer"]}]', '[{"entity": "Customer", "type": "many_to_one", "description": "Transaction belongs to one customer"}, {"entity": "Product", "type": "many_to_many", "description": "Transaction can include multiple products"}]', '[{"rule": "positive_amount", "description": "Transaction amount must be positive"}, {"rule": "valid_currency", "description": "Currency must be supported"}]', 'engineer', 'Engineering'),

('550e8400-e29b-41d4-a716-446655440032', 'Product', 'Product catalog business entity', 'product', 'Product', '[{"name": "product_id", "type": "identifier", "required": true}, {"name": "name", "type": "string", "required": true}, {"name": "price", "type": "monetary", "required": true}, {"name": "category", "type": "string", "required": true}]', '[{"entity": "Customer", "type": "many_to_many", "description": "Product can be purchased by multiple customers"}, {"entity": "Transaction", "type": "many_to_many", "description": "Product can be in multiple transactions"}]', '[{"rule": "positive_price", "description": "Product price must be positive"}, {"rule": "valid_category", "description": "Product must belong to valid category"}]', 'analyst', 'Analytics');

-- =====================================================
-- QUALITY RULES
-- =====================================================

INSERT INTO quality.quality_rules (id, name, description, rule_type, data_object_id, column_name, rule_definition, threshold_min, threshold_max, severity, is_active, schedule_cron, owner_user) VALUES
('550e8400-e29b-41d4-a716-446655440040', 'Customer Email Completeness', 'Ensure customer email field is not null', 'completeness', '550e8400-e29b-41d4-a716-446655440010', 'email', '{"check_type": "not_null", "field": "email"}', 95.0, 100.0, 'high', true, '0 0 * * *', 'data_steward'),

('550e8400-e29b-41d4-a716-446655440041', 'Customer Email Format Validation', 'Validate email format using regex', 'validity', '550e8400-e29b-41d4-a716-446655440010', 'email', '{"check_type": "regex", "field": "email", "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"}', 98.0, 100.0, 'high', true, '0 2 * * *', 'data_steward'),

('550e8400-e29b-41d4-a716-446655440042', 'Customer ID Uniqueness', 'Ensure customer IDs are unique', 'uniqueness', '550e8400-e29b-41d4-a716-446655440010', 'customer_id', '{"check_type": "unique", "field": "customer_id"}', 100.0, 100.0, 'critical', true, '0 1 * * *', 'data_steward'),

('550e8400-e29b-41d4-a716-446655440043', 'Transaction Amount Validity', 'Ensure transaction amounts are positive', 'validity', '550e8400-e29b-41d4-a716-446655440011', 'amount', '{"check_type": "range", "field": "amount", "min_value": 0.01, "max_value": 1000000}', 99.0, 100.0, 'high', true, '0 */6 * * *', 'engineer'),

('550e8400-e29b-41d4-a716-446655440044', 'Transaction Currency Consistency', 'Validate currency codes against ISO standards', 'consistency', '550e8400-e29b-41d4-a716-446655440011', 'currency', '{"check_type": "allowed_values", "field": "currency", "allowed_values": ["USD", "EUR", "GBP", "JPY", "CAD", "AUD"]}', 99.5, 100.0, 'medium', true, '0 4 * * *', 'engineer'),

('550e8400-e29b-41d4-a716-446655440045', 'Product Price Accuracy', 'Ensure product prices are reasonable', 'accuracy', '550e8400-e29b-41d4-a716-446655440012', 'price', '{"check_type": "range", "field": "price", "min_value": 0.01, "max_value": 100000}', 95.0, 100.0, 'medium', true, '0 3 * * *', 'analyst');

-- =====================================================
-- QUALITY METRICS (historical data)
-- =====================================================

INSERT INTO quality.quality_metrics (id, data_object_id, metric_name, metric_type, metric_value, metric_unit, threshold_min, threshold_max, status, execution_time, execution_duration_ms, rule_definition, result_details) VALUES
-- Customer data quality metrics
('550e8400-e29b-41d4-a716-446655440050', '550e8400-e29b-41d4-a716-446655440010', 'Email Completeness', 'completeness', 98.5, 'percentage', 95.0, 100.0, 'passed', '2024-06-25 02:00:00+00', 1250, '{"check_type": "not_null", "field": "email"}', '{"total_records": 1500000, "null_records": 22500, "completeness_rate": 98.5}'),

('550e8400-e29b-41d4-a716-446655440051', '550e8400-e29b-41d4-a716-446655440010', 'Email Format Validity', 'validity', 99.2, 'percentage', 98.0, 100.0, 'passed', '2024-06-25 02:05:00+00', 2100, '{"check_type": "regex", "field": "email", "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"}', '{"total_records": 1477500, "invalid_records": 11820, "validity_rate": 99.2}'),

('550e8400-e29b-41d4-a716-446655440052', '550e8400-e29b-41d4-a716-446655440010', 'Customer ID Uniqueness', 'uniqueness', 100.0, 'percentage', 100.0, 100.0, 'passed', '2024-06-25 01:30:00+00', 3200, '{"check_type": "unique", "field": "customer_id"}', '{"total_records": 1500000, "duplicate_records": 0, "uniqueness_rate": 100.0}'),

-- Transaction data quality metrics
('550e8400-e29b-41d4-a716-446655440053', '550e8400-e29b-41d4-a716-446655440011', 'Amount Validity', 'validity', 99.8, 'percentage', 99.0, 100.0, 'passed', '2024-06-25 06:00:00+00', 5400, '{"check_type": "range", "field": "amount", "min_value": 0.01, "max_value": 1000000}', '{"total_records": 25000000, "invalid_records": 50000, "validity_rate": 99.8}'),

('550e8400-e29b-41d4-a716-446655440054', '550e8400-e29b-41d4-a716-446655440011', 'Currency Consistency', 'consistency', 99.9, 'percentage', 99.5, 100.0, 'passed', '2024-06-25 04:00:00+00', 1800, '{"check_type": "allowed_values", "field": "currency", "allowed_values": ["USD", "EUR", "GBP", "JPY", "CAD", "AUD"]}', '{"total_records": 25000000, "inconsistent_records": 25000, "consistency_rate": 99.9}'),

-- Product data quality metrics
('550e8400-e29b-41d4-a716-446655440055', '550e8400-e29b-41d4-a716-446655440012', 'Price Accuracy', 'accuracy', 97.2, 'percentage', 95.0, 100.0, 'passed', '2024-06-25 03:00:00+00', 900, '{"check_type": "range", "field": "price", "min_value": 0.01, "max_value": 100000}', '{"total_records": 500000, "inaccurate_records": 14000, "accuracy_rate": 97.2}');

-- =====================================================
-- DATA LINEAGE
-- =====================================================

INSERT INTO lineage.data_lineage (id, source_object_id, target_object_id, lineage_type, transformation_logic, transformation_type, job_name, job_id, pipeline_name, pipeline_id, confidence_score, discovered_method, last_verified) VALUES
-- Customer data lineage
('550e8400-e29b-41d4-a716-446655440060', '550e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440013', 'aggregated', 'SELECT customer_id, COUNT(*) as total_transactions, SUM(amount) as total_amount, AVG(amount) as avg_transaction_amount FROM customer_transactions GROUP BY customer_id', 'aggregation', 'customer_analytics_etl', 'job_12345', 'customer_analytics_pipeline', 'pipeline_67890', 0.95, 'automatic', '2024-06-20 10:00:00+00'),

-- Transaction data lineage
('550e8400-e29b-41d4-a716-446655440061', '550e8400-e29b-41d4-a716-446655440011', '550e8400-e29b-41d4-a716-446655440013', 'direct', 'Direct aggregation of transaction data for customer analytics', 'aggregation', 'customer_analytics_etl', 'job_12345', 'customer_analytics_pipeline', 'pipeline_67890', 0.98, 'automatic', '2024-06-20 10:00:00+00'),

-- External data lineage
('550e8400-e29b-41d4-a716-446655440062', '550e8400-e29b-41d4-a716-446655440014', '550e8400-e29b-41d4-a716-446655440013', 'derived', 'Market data used for customer risk scoring and segmentation', 'enrichment', 'risk_scoring_job', 'job_54321', 'risk_analytics_pipeline', 'pipeline_09876', 0.85, 'manual', '2024-06-15 15:30:00+00'),

-- Streaming data lineage
('550e8400-e29b-41d4-a716-446655440063', '550e8400-e29b-41d4-a716-446655440015', '550e8400-e29b-41d4-a716-446655440011', 'transformed', 'Real-time events processed and converted to transaction records', 'stream_processing', 'event_processing_job', 'job_98765', 'realtime_pipeline', 'pipeline_13579', 0.90, 'automatic', '2024-06-24 08:00:00+00');

-- =====================================================
-- ACCESS POLICIES
-- =====================================================

INSERT INTO security.access_policies (id, name, description, policy_type, data_object_id, principal_type, principal_name, permission, conditions, masking_rules, filter_conditions, priority, effective_from) VALUES
-- Customer data access policies
('550e8400-e29b-41d4-a716-446655440070', 'Customer Data - Admin Access', 'Full access to customer data for administrators', 'read', '550e8400-e29b-41d4-a716-446655440010', 'role', 'admin', 'allow', '{"time_restriction": false, "ip_restriction": false}', '[]', '{}', 100, '2024-01-01 00:00:00+00'),

('550e8400-e29b-41d4-a716-446655440071', 'Customer Data - Data Steward Access', 'Full access to customer data for data stewards', 'read', '550e8400-e29b-41d4-a716-446655440010', 'role', 'data_steward', 'allow', '{"time_restriction": false, "ip_restriction": false}', '[]', '{}', 90, '2024-01-01 00:00:00+00'),

('550e8400-e29b-41d4-a716-446655440072', 'Customer Data - Analyst Masked Access', 'Masked access to customer data for analysts', 'mask', '550e8400-e29b-41d4-a716-446655440010', 'role', 'analyst', 'allow', '{"time_restriction": true, "business_hours_only": true}', '[{"field": "email", "mask_type": "email_domain"}, {"field": "phone", "mask_type": "partial"}, {"field": "address", "mask_type": "city_only"}]', '{}', 80, '2024-01-01 00:00:00+00'),

-- Transaction data access policies
('550e8400-e29b-41d4-a716-446655440073', 'Transaction Data - Engineer Access', 'Full access to transaction data for engineers', 'read', '550e8400-e29b-41d4-a716-446655440011', 'role', 'engineer', 'allow', '{"time_restriction": false, "ip_restriction": false}', '[]', '{}', 100, '2024-01-01 00:00:00+00'),

('550e8400-e29b-41d4-a716-446655440074', 'Transaction Data - Scientist Filtered Access', 'Filtered access to transaction data for data scientists', 'filter', '550e8400-e29b-41d4-a716-446655440011', 'role', 'scientist', 'allow', '{"time_restriction": true, "business_hours_only": true}', '[]', '{"amount_limit": 10000, "exclude_refunds": true}', 70, '2024-01-01 00:00:00+00'),

-- Product data access policies
('550e8400-e29b-41d4-a716-446655440075', 'Product Data - Public Access', 'Public read access to product catalog', 'read', '550e8400-e29b-41d4-a716-446655440012', 'role', 'public', 'allow', '{"time_restriction": false, "ip_restriction": false}', '[{"field": "cost", "mask_type": "hide"}]', '{}', 50, '2024-01-01 00:00:00+00'),

-- External data access policies
('550e8400-e29b-41d4-a716-446655440076', 'External Data - Restricted Access', 'Restricted access to external market data', 'read', '550e8400-e29b-41d4-a716-446655440014', 'role', 'analyst', 'allow', '{"time_restriction": true, "business_hours_only": true, "ip_restriction": true, "allowed_ips": ["10.0.0.0/8", "192.168.0.0/16"]}', '[]', '{}', 60, '2024-01-01 00:00:00+00');

-- =====================================================
-- AUDIT LOGS (sample historical data)
-- =====================================================

INSERT INTO audit.audit_logs (id, event_type, resource_type, resource_id, resource_name, user_id, user_name, session_id, ip_address, user_agent, action_details, success, duration_ms, created_at) VALUES
('550e8400-e29b-41d4-a716-446655440080', 'read', 'data_object', '550e8400-e29b-41d4-a716-446655440010', 'Customer Master Data', 'analyst', 'Data Analyst', 'session_12345', '192.168.1.100', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', '{"query": "SELECT * FROM customers LIMIT 100", "masked_fields": ["email", "phone"]}', true, 250, '2024-06-25 09:15:00+00'),

('550e8400-e29b-41d4-a716-446655440081', 'update', 'data_contract', '550e8400-e29b-41d4-a716-446655440020', 'Customer Master Data Contract', 'data_steward', 'Data Steward', 'session_67890', '192.168.1.101', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36', '{"field_updated": "quality_rules", "new_threshold": 95.0}', true, 180, '2024-06-25 08:30:00+00'),

('550e8400-e29b-41d4-a716-446655440082', 'create', 'quality_rule', '550e8400-e29b-41d4-a716-446655440045', 'Product Price Accuracy', 'analyst', 'Data Analyst', 'session_13579', '192.168.1.102', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36', '{"rule_type": "accuracy", "threshold": 95.0, "severity": "medium"}', true, 320, '2024-06-25 07:45:00+00'),

('550e8400-e29b-41d4-a716-446655440083', 'access', 'data_object', '550e8400-e29b-41d4-a716-446655440011', 'Customer Transactions', 'engineer', 'Data Engineer', 'session_24680', '192.168.1.103', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', '{"export_format": "csv", "record_count": 50000, "date_range": "2024-06-01 to 2024-06-25"}', true, 1200, '2024-06-25 06:20:00+00'),

('550e8400-e29b-41d4-a716-446655440084', 'delete', 'access_policy', '550e8400-e29b-41d4-a716-446655440999', 'Deprecated Policy', 'admin', 'System Administrator', 'session_97531', '192.168.1.104', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36', '{"reason": "policy_deprecated", "replacement_policy": "550e8400-e29b-41d4-a716-446655440072"}', true, 95, '2024-06-24 16:00:00+00');

-- =====================================================
-- UPDATE STATISTICS
-- =====================================================

-- Update table statistics for better query performance
ANALYZE governance.data_objects;
ANALYZE governance.data_contracts;
ANALYZE governance.entities;
ANALYZE quality.quality_metrics;
ANALYZE quality.quality_rules;
ANALYZE lineage.data_lineage;
ANALYZE security.access_policies;
ANALYZE audit.audit_logs;
ANALYZE security.users;

-- =====================================================
-- SUMMARY INFORMATION
-- =====================================================

-- Display summary of inserted data
DO $$
BEGIN
    RAISE NOTICE 'Mock data insertion completed successfully!';
    RAISE NOTICE 'Data Objects: %', (SELECT COUNT(*) FROM governance.data_objects);
    RAISE NOTICE 'Data Contracts: %', (SELECT COUNT(*) FROM governance.data_contracts);
    RAISE NOTICE 'Entities: %', (SELECT COUNT(*) FROM governance.entities);
    RAISE NOTICE 'Quality Rules: %', (SELECT COUNT(*) FROM quality.quality_rules);
    RAISE NOTICE 'Quality Metrics: %', (SELECT COUNT(*) FROM quality.quality_metrics);
    RAISE NOTICE 'Data Lineage: %', (SELECT COUNT(*) FROM lineage.data_lineage);
    RAISE NOTICE 'Access Policies: %', (SELECT COUNT(*) FROM security.access_policies);
    RAISE NOTICE 'Audit Logs: %', (SELECT COUNT(*) FROM audit.audit_logs);
    RAISE NOTICE 'Users: %', (SELECT COUNT(*) FROM security.users);
END $$;

