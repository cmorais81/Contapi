-- Data Governance API - Database Initialization Script
-- Following SOLID principles and enterprise best practices

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create schemas for organization
CREATE SCHEMA IF NOT EXISTS governance;
CREATE SCHEMA IF NOT EXISTS quality;
CREATE SCHEMA IF NOT EXISTS lineage;
CREATE SCHEMA IF NOT EXISTS security;
CREATE SCHEMA IF NOT EXISTS audit;

-- Set search path
SET search_path TO governance, quality, lineage, security, audit, public;

-- =====================================================
-- GOVERNANCE SCHEMA TABLES
-- =====================================================

-- Data Objects table (core entity)
CREATE TABLE IF NOT EXISTS governance.data_objects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    object_type VARCHAR(50) NOT NULL CHECK (object_type IN ('table', 'view', 'dataset', 'file', 'stream', 'api')),
    catalog_name VARCHAR(100),
    database_name VARCHAR(100),
    schema_name VARCHAR(100),
    table_name VARCHAR(100),
    full_name VARCHAR(500) GENERATED ALWAYS AS (
        CASE 
            WHEN catalog_name IS NOT NULL AND database_name IS NOT NULL AND schema_name IS NOT NULL AND table_name IS NOT NULL 
            THEN catalog_name || '.' || database_name || '.' || schema_name || '.' || table_name
            ELSE name
        END
    ) STORED,
    location VARCHAR(500),
    format VARCHAR(50),
    size_bytes BIGINT DEFAULT 0,
    row_count BIGINT DEFAULT 0,
    column_count INTEGER DEFAULT 0,
    classification VARCHAR(50) DEFAULT 'unclassified' CHECK (classification IN ('public', 'internal', 'confidential', 'restricted', 'unclassified')),
    sensitivity_level VARCHAR(20) DEFAULT 'low' CHECK (sensitivity_level IN ('low', 'medium', 'high', 'critical')),
    owner_user VARCHAR(100),
    owner_team VARCHAR(100),
    steward_user VARCHAR(100),
    steward_team VARCHAR(100),
    business_domain VARCHAR(100),
    technical_domain VARCHAR(100),
    tags JSONB DEFAULT '[]',
    properties JSONB DEFAULT '{}',
    schema_definition JSONB,
    is_active BOOLEAN DEFAULT true,
    is_deleted BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100) DEFAULT 'system',
    updated_by VARCHAR(100) DEFAULT 'system',
    
    -- Indexes for performance
    CONSTRAINT unique_full_name UNIQUE (catalog_name, database_name, schema_name, table_name)
);

-- Data Contracts table
CREATE TABLE IF NOT EXISTS governance.data_contracts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    version VARCHAR(20) NOT NULL DEFAULT '1.0.0',
    data_object_id UUID REFERENCES governance.data_objects(id) ON DELETE CASCADE,
    contract_type VARCHAR(50) DEFAULT 'schema' CHECK (contract_type IN ('schema', 'quality', 'sla', 'usage', 'retention')),
    status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'deprecated', 'retired')),
    schema_definition JSONB NOT NULL DEFAULT '{}',
    quality_rules JSONB DEFAULT '[]',
    sla_requirements JSONB DEFAULT '{}',
    usage_policies JSONB DEFAULT '{}',
    retention_policy JSONB DEFAULT '{}',
    validation_rules JSONB DEFAULT '[]',
    business_rules JSONB DEFAULT '[]',
    owner_user VARCHAR(100),
    owner_team VARCHAR(100),
    approver_user VARCHAR(100),
    approved_at TIMESTAMP WITH TIME ZONE,
    effective_from TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    effective_to TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100) DEFAULT 'system',
    updated_by VARCHAR(100) DEFAULT 'system'
);

-- Entities table (business entities)
CREATE TABLE IF NOT EXISTS governance.entities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    entity_type VARCHAR(50) NOT NULL CHECK (entity_type IN ('customer', 'product', 'transaction', 'event', 'reference', 'master')),
    business_domain VARCHAR(100),
    attributes JSONB DEFAULT '[]',
    relationships JSONB DEFAULT '[]',
    business_rules JSONB DEFAULT '[]',
    owner_user VARCHAR(100),
    owner_team VARCHAR(100),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100) DEFAULT 'system',
    updated_by VARCHAR(100) DEFAULT 'system'
);

-- =====================================================
-- QUALITY SCHEMA TABLES
-- =====================================================

-- Quality Metrics table
CREATE TABLE IF NOT EXISTS quality.quality_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    data_object_id UUID REFERENCES governance.data_objects(id) ON DELETE CASCADE,
    metric_name VARCHAR(100) NOT NULL,
    metric_type VARCHAR(50) NOT NULL CHECK (metric_type IN ('completeness', 'accuracy', 'consistency', 'validity', 'uniqueness', 'timeliness', 'integrity')),
    metric_value DECIMAL(10,4),
    metric_unit VARCHAR(20) DEFAULT 'percentage',
    threshold_min DECIMAL(10,4),
    threshold_max DECIMAL(10,4),
    status VARCHAR(20) DEFAULT 'unknown' CHECK (status IN ('passed', 'failed', 'warning', 'unknown')),
    execution_time TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    execution_duration_ms INTEGER,
    rule_definition JSONB,
    result_details JSONB DEFAULT '{}',
    error_message TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100) DEFAULT 'system'
);

-- Quality Rules table
CREATE TABLE IF NOT EXISTS quality.quality_rules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    rule_type VARCHAR(50) NOT NULL CHECK (rule_type IN ('completeness', 'accuracy', 'consistency', 'validity', 'uniqueness', 'timeliness', 'integrity', 'custom')),
    data_object_id UUID REFERENCES governance.data_objects(id) ON DELETE CASCADE,
    column_name VARCHAR(100),
    rule_definition JSONB NOT NULL,
    threshold_min DECIMAL(10,4),
    threshold_max DECIMAL(10,4),
    severity VARCHAR(20) DEFAULT 'medium' CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    is_active BOOLEAN DEFAULT true,
    schedule_cron VARCHAR(100),
    last_execution TIMESTAMP WITH TIME ZONE,
    next_execution TIMESTAMP WITH TIME ZONE,
    owner_user VARCHAR(100),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100) DEFAULT 'system',
    updated_by VARCHAR(100) DEFAULT 'system'
);

-- =====================================================
-- LINEAGE SCHEMA TABLES
-- =====================================================

-- Data Lineage table
CREATE TABLE IF NOT EXISTS lineage.data_lineage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_object_id UUID REFERENCES governance.data_objects(id) ON DELETE CASCADE,
    target_object_id UUID REFERENCES governance.data_objects(id) ON DELETE CASCADE,
    lineage_type VARCHAR(50) DEFAULT 'direct' CHECK (lineage_type IN ('direct', 'derived', 'aggregated', 'transformed', 'copied')),
    transformation_logic TEXT,
    transformation_type VARCHAR(50),
    job_name VARCHAR(255),
    job_id VARCHAR(255),
    pipeline_name VARCHAR(255),
    pipeline_id VARCHAR(255),
    confidence_score DECIMAL(3,2) DEFAULT 1.0 CHECK (confidence_score >= 0 AND confidence_score <= 1),
    discovered_method VARCHAR(50) DEFAULT 'manual' CHECK (discovered_method IN ('manual', 'automatic', 'inferred', 'metadata')),
    last_verified TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100) DEFAULT 'system',
    updated_by VARCHAR(100) DEFAULT 'system',
    
    -- Prevent self-referencing lineage
    CONSTRAINT no_self_lineage CHECK (source_object_id != target_object_id)
);

-- =====================================================
-- SECURITY SCHEMA TABLES
-- =====================================================

-- Access Policies table
CREATE TABLE IF NOT EXISTS security.access_policies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    policy_type VARCHAR(50) NOT NULL CHECK (policy_type IN ('read', 'write', 'delete', 'admin', 'mask', 'filter')),
    data_object_id UUID REFERENCES governance.data_objects(id) ON DELETE CASCADE,
    principal_type VARCHAR(50) NOT NULL CHECK (principal_type IN ('user', 'group', 'role', 'service_account')),
    principal_name VARCHAR(255) NOT NULL,
    permission VARCHAR(50) NOT NULL CHECK (permission IN ('allow', 'deny')),
    conditions JSONB DEFAULT '{}',
    masking_rules JSONB DEFAULT '[]',
    filter_conditions JSONB DEFAULT '{}',
    priority INTEGER DEFAULT 100,
    effective_from TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    effective_to TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100) DEFAULT 'system',
    updated_by VARCHAR(100) DEFAULT 'system'
);

-- =====================================================
-- AUDIT SCHEMA TABLES
-- =====================================================

-- Audit Logs table
CREATE TABLE IF NOT EXISTS audit.audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type VARCHAR(50) NOT NULL CHECK (event_type IN ('create', 'read', 'update', 'delete', 'access', 'export', 'import', 'transform')),
    resource_type VARCHAR(50) NOT NULL,
    resource_id UUID,
    resource_name VARCHAR(255),
    user_id VARCHAR(100),
    user_name VARCHAR(255),
    session_id VARCHAR(255),
    ip_address INET,
    user_agent TEXT,
    action_details JSONB DEFAULT '{}',
    before_state JSONB,
    after_state JSONB,
    success BOOLEAN DEFAULT true,
    error_message TEXT,
    duration_ms INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Users table (for authentication and authorization)
CREATE TABLE IF NOT EXISTS security.users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    full_name VARCHAR(255),
    password_hash VARCHAR(255),
    roles JSONB DEFAULT '[]',
    permissions JSONB DEFAULT '[]',
    department VARCHAR(100),
    manager_id UUID REFERENCES security.users(id),
    is_active BOOLEAN DEFAULT true,
    last_login TIMESTAMP WITH TIME ZONE,
    password_changed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100) DEFAULT 'system',
    updated_by VARCHAR(100) DEFAULT 'system'
);

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- Data Objects indexes
CREATE INDEX IF NOT EXISTS idx_data_objects_type ON governance.data_objects(object_type);
CREATE INDEX IF NOT EXISTS idx_data_objects_catalog ON governance.data_objects(catalog_name);
CREATE INDEX IF NOT EXISTS idx_data_objects_database ON governance.data_objects(database_name);
CREATE INDEX IF NOT EXISTS idx_data_objects_schema ON governance.data_objects(schema_name);
CREATE INDEX IF NOT EXISTS idx_data_objects_classification ON governance.data_objects(classification);
CREATE INDEX IF NOT EXISTS idx_data_objects_owner ON governance.data_objects(owner_user);
CREATE INDEX IF NOT EXISTS idx_data_objects_domain ON governance.data_objects(business_domain);
CREATE INDEX IF NOT EXISTS idx_data_objects_active ON governance.data_objects(is_active);
CREATE INDEX IF NOT EXISTS idx_data_objects_created ON governance.data_objects(created_at);

-- Data Contracts indexes
CREATE INDEX IF NOT EXISTS idx_data_contracts_object ON governance.data_contracts(data_object_id);
CREATE INDEX IF NOT EXISTS idx_data_contracts_status ON governance.data_contracts(status);
CREATE INDEX IF NOT EXISTS idx_data_contracts_type ON governance.data_contracts(contract_type);

-- Quality Metrics indexes
CREATE INDEX IF NOT EXISTS idx_quality_metrics_object ON quality.quality_metrics(data_object_id);
CREATE INDEX IF NOT EXISTS idx_quality_metrics_type ON quality.quality_metrics(metric_type);
CREATE INDEX IF NOT EXISTS idx_quality_metrics_execution ON quality.quality_metrics(execution_time);
CREATE INDEX IF NOT EXISTS idx_quality_metrics_status ON quality.quality_metrics(status);

-- Quality Rules indexes
CREATE INDEX IF NOT EXISTS idx_quality_rules_object ON quality.quality_rules(data_object_id);
CREATE INDEX IF NOT EXISTS idx_quality_rules_active ON quality.quality_rules(is_active);
CREATE INDEX IF NOT EXISTS idx_quality_rules_execution ON quality.quality_rules(next_execution);

-- Lineage indexes
CREATE INDEX IF NOT EXISTS idx_lineage_source ON lineage.data_lineage(source_object_id);
CREATE INDEX IF NOT EXISTS idx_lineage_target ON lineage.data_lineage(target_object_id);
CREATE INDEX IF NOT EXISTS idx_lineage_type ON lineage.data_lineage(lineage_type);
CREATE INDEX IF NOT EXISTS idx_lineage_active ON lineage.data_lineage(is_active);

-- Access Policies indexes
CREATE INDEX IF NOT EXISTS idx_access_policies_object ON security.access_policies(data_object_id);
CREATE INDEX IF NOT EXISTS idx_access_policies_principal ON security.access_policies(principal_type, principal_name);
CREATE INDEX IF NOT EXISTS idx_access_policies_active ON security.access_policies(is_active);

-- Audit Logs indexes
CREATE INDEX IF NOT EXISTS idx_audit_logs_event_type ON audit.audit_logs(event_type);
CREATE INDEX IF NOT EXISTS idx_audit_logs_resource ON audit.audit_logs(resource_type, resource_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user ON audit.audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit.audit_logs(created_at);

-- Users indexes
CREATE INDEX IF NOT EXISTS idx_users_username ON security.users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON security.users(email);
CREATE INDEX IF NOT EXISTS idx_users_active ON security.users(is_active);

-- =====================================================
-- TRIGGERS FOR AUDIT AND TIMESTAMPS
-- =====================================================

-- Function to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply timestamp triggers to all tables with updated_at
CREATE TRIGGER update_data_objects_updated_at BEFORE UPDATE ON governance.data_objects FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_contracts_updated_at BEFORE UPDATE ON governance.data_contracts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_entities_updated_at BEFORE UPDATE ON governance.entities FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_quality_rules_updated_at BEFORE UPDATE ON quality.quality_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_lineage_updated_at BEFORE UPDATE ON lineage.data_lineage FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_access_policies_updated_at BEFORE UPDATE ON security.access_policies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON security.users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =====================================================
-- VIEWS FOR COMMON QUERIES
-- =====================================================

-- Data Objects with Quality Summary
CREATE OR REPLACE VIEW governance.data_objects_with_quality AS
SELECT 
    do.*,
    COALESCE(qm.avg_quality_score, 0) as avg_quality_score,
    COALESCE(qm.total_metrics, 0) as total_quality_metrics,
    COALESCE(qm.passed_metrics, 0) as passed_quality_metrics,
    COALESCE(qm.failed_metrics, 0) as failed_quality_metrics
FROM governance.data_objects do
LEFT JOIN (
    SELECT 
        data_object_id,
        AVG(metric_value) as avg_quality_score,
        COUNT(*) as total_metrics,
        COUNT(CASE WHEN status = 'passed' THEN 1 END) as passed_metrics,
        COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_metrics
    FROM quality.quality_metrics 
    WHERE execution_time >= CURRENT_DATE - INTERVAL '7 days'
    GROUP BY data_object_id
) qm ON do.id = qm.data_object_id;

-- Data Lineage Graph View
CREATE OR REPLACE VIEW lineage.lineage_graph AS
SELECT 
    dl.id,
    dl.lineage_type,
    dl.transformation_logic,
    dl.confidence_score,
    so.name as source_name,
    so.full_name as source_full_name,
    so.object_type as source_type,
    to_.name as target_name,
    to_.full_name as target_full_name,
    to_.object_type as target_type,
    dl.created_at,
    dl.is_active
FROM lineage.data_lineage dl
JOIN governance.data_objects so ON dl.source_object_id = so.id
JOIN governance.data_objects to_ ON dl.target_object_id = to_.id
WHERE dl.is_active = true;

-- Grant permissions
GRANT USAGE ON SCHEMA governance, quality, lineage, security, audit TO PUBLIC;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA governance, quality, lineage, security, audit TO PUBLIC;
GRANT SELECT ON ALL VIEWS IN SCHEMA governance, lineage TO PUBLIC;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA governance, quality, lineage, security, audit TO PUBLIC;

