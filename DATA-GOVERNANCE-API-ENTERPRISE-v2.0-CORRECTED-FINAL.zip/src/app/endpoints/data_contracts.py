"""
Endpoints para DataContracts seguindo modelo_estendido.dbml original
Autor: Carlos Morais
"""

from typing import Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from ..core.dependencies import get_db
from ..repositories.data_contracts import DataContractsRepository
from ..services.data_contracts import DataContractsService
from ..schemas.data_contracts import (
    DataContract,
    DataContractCreate,
    DataContractSummary,
    DataContractUpdate
)
from ..schemas.base import PaginatedResponse, PaginationParams
from ..utils.exceptions import EntityNotFoundError, ValidationError

router = APIRouter(prefix="/data-contracts", tags=["Data Contracts"])


def get_data_contracts_service(db: AsyncSession = Depends(get_db)) -> DataContractsService:
    """Dependency para obter service de contratos"""
    repository = DataContractsRepository(db)
    return DataContractsService(repository)


@router.get("/", response_model=PaginatedResponse)
async def list_contracts(
    pagination: PaginationParams = Depends(),
    domain: Optional[str] = Query(None, description="Filtrar por domínio de negócio"),
    owner: Optional[str] = Query(None, description="Filtrar por proprietário"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    abac_enabled: Optional[bool] = Query(None, description="Filtrar por ABAC habilitado"),
    monitoring_enabled: Optional[bool] = Query(None, description="Filtrar por monitoramento habilitado"),
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Lista contratos de dados com filtros opcionais"""
    try:
        filters = {}
        
        if domain:
            filters['business_domain'] = domain
        if owner:
            filters['contract_owner'] = owner
        if status:
            filters['contract_status'] = status
        if abac_enabled is not None:
            filters['abac_enabled'] = abac_enabled
        if monitoring_enabled is not None:
            filters['monitoring_enabled'] = monitoring_enabled
        
        result = await service.get_all_paginated(
            pagination=pagination,
            filters=filters,
            order_by='-data_criacao'
        )
        
        return result
        
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/search", response_model=PaginatedResponse)
async def search_contracts(
    q: str = Query(..., min_length=2, description="Termo de busca"),
    pagination: PaginationParams = Depends(),
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Busca contratos por termo"""
    try:
        result = await service.search(
            search_term=q,
            pagination=pagination
        )
        
        return result
        
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/stats", response_model=Dict[str, int])
async def get_contracts_stats(
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Estatísticas dos contratos"""
    try:
        return await service.get_contracts_stats()
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/by-domain/{domain}", response_model=List[DataContractSummary])
async def get_contracts_by_domain(
    domain: str,
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Busca contratos por domínio de negócio"""
    try:
        contracts = await service.get_by_domain(domain)
        return contracts
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/by-owner/{owner}", response_model=List[DataContractSummary])
async def get_contracts_by_owner(
    owner: str,
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Busca contratos por proprietário"""
    try:
        contracts = await service.get_by_owner(owner)
        return contracts
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/by-status/{status}", response_model=List[DataContractSummary])
async def get_contracts_by_status(
    status: str,
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Busca contratos por status"""
    try:
        contracts = await service.get_by_status(status)
        return contracts
        
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/active-versions", response_model=List[DataContractSummary])
async def get_contracts_with_active_versions(
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Busca contratos que têm versões ativas"""
    try:
        contracts = await service.get_with_active_versions()
        return contracts
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/unity-catalog", response_model=List[DataContractSummary])
async def get_unity_catalog_contracts(
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Busca contratos integrados com Unity Catalog"""
    try:
        contracts = await service.get_unity_catalog_contracts()
        return contracts
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/abac-enabled", response_model=List[DataContractSummary])
async def get_abac_enabled_contracts(
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Busca contratos com ABAC habilitado"""
    try:
        contracts = await service.get_abac_enabled_contracts()
        return contracts
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/monitoring-enabled", response_model=List[DataContractSummary])
async def get_monitoring_enabled_contracts(
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Busca contratos com monitoramento habilitado"""
    try:
        contracts = await service.get_monitoring_enabled_contracts()
        return contracts
        
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.post("/", response_model=DataContract, status_code=status.HTTP_201_CREATED)
async def create_contract(
    contract_data: DataContractCreate,
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Cria novo contrato de dados"""
    try:
        contract = await service.create(contract_data.dict(exclude_unset=True))
        return contract
        
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/{contract_id}", response_model=DataContract)
async def get_contract(
    contract_id: UUID,
    include_versions: bool = Query(False, description="Incluir versões do contrato"),
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Busca contrato por ID"""
    try:
        if include_versions:
            contract = await service.get_with_versions(contract_id)
        else:
            contract = await service.get_by_id(contract_id)
        
        return contract
        
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/name/{contract_name}", response_model=DataContract)
async def get_contract_by_name(
    contract_name: str,
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Busca contrato por nome"""
    try:
        contract = await service.get_by_name(contract_name)
        return contract
        
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.put("/{contract_id}", response_model=DataContract)
async def update_contract(
    contract_id: UUID,
    contract_data: DataContractUpdate,
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Atualiza contrato existente"""
    try:
        contract = await service.update(contract_id, contract_data.dict(exclude_unset=True))
        return contract
        
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.post("/{contract_id}/activate", response_model=DataContract)
async def activate_contract(
    contract_id: UUID,
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Ativa um contrato"""
    try:
        contract = await service.activate_contract(contract_id)
        return contract
        
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.post("/{contract_id}/deprecate", response_model=DataContract)
async def deprecate_contract(
    contract_id: UUID,
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Deprecia um contrato"""
    try:
        contract = await service.deprecate_contract(contract_id)
        return contract
        
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.post("/{contract_id}/archive", response_model=DataContract)
async def archive_contract(
    contract_id: UUID,
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Arquiva um contrato"""
    try:
        contract = await service.archive_contract(contract_id)
        return contract
        
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.delete("/{contract_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_contract(
    contract_id: UUID,
    service: DataContractsService = Depends(get_data_contracts_service)
):
    """Remove contrato"""
    try:
        await service.delete(contract_id)
        
    except EntityNotFoundError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except ValidationError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

