"""
Modelo QueryMetrics para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import BigInteger, Column, ForeignKey, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class QueryMetrics(BaseEntity):
    """
    Métricas de performance em nível de query para otimização
    """
    
    __tablename__ = "QueryMetrics"
    
    # Chave primária UUID conforme modelo original
    query_id = Column(
        Text,
        primary_key=True,
        nullable=False,
        comment='Identificador único da query'
    )
    
    # Informações da query
    query_text_hash = Column(
        Text,
        nullable=False,
        comment='Hash do texto da query para privacidade'
    )
    
    contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataContracts.contract_id'),
        comment='Contrato de dados associado'
    )
    
    quality_rule_id = Column(
        UUID(as_uuid=True),
        ForeignKey('QualityRules.quality_rule_id'),
        comment='Regra de qualidade associada'
    )
    
    # Métricas de execução de query
    execution_timestamp = Column(
        func.timestamptz(),
        nullable=False,
        comment='Timestamp da execução'
    )
    
    compilation_time_ms = Column(
        Numeric,
        comment='Tempo de compilação da query'
    )
    
    execution_time_ms = Column(
        Numeric,
        comment='Tempo de execução da query'
    )
    
    total_time_ms = Column(
        Numeric,
        comment='Tempo total incluindo compilação'
    )
    
    # Métricas de escaneamento de dados
    rows_scanned = Column(
        BigInteger,
        comment='Número de linhas escaneadas'
    )
    
    rows_returned = Column(
        BigInteger,
        comment='Número de linhas retornadas'
    )
    
    bytes_scanned = Column(
        BigInteger,
        comment='Bytes escaneados do armazenamento'
    )
    
    bytes_returned = Column(
        BigInteger,
        comment='Bytes retornados ao cliente'
    )
    
    # Métricas de otimização de performance
    cache_hit_ratio = Column(
        Numeric,
        comment='Taxa de acerto do cache em porcentagem'
    )
    
    data_skipping_ratio = Column(
        Numeric,
        comment='Efetividade do data skipping'
    )
    
    optimization_applied = Column(
        Text,
        comment='Otimizações aplicadas pelo engine'
    )
    
    execution_plan_hash = Column(
        Text,
        comment='Hash do plano de execução'
    )
    
    # Relacionamentos
    contract = relationship("DataContracts", back_populates="query_metrics")
    quality_rule = relationship("QualityRules", back_populates="query_metrics")
    
    def __repr__(self):
        return f"<QueryMetrics(query_id={self.query_id}, timestamp={self.execution_timestamp})>"

