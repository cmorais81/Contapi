"""
Modelo SyncExecutions para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Integer, Text
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class SyncExecutions(BaseEntity):
    """
    Rastreamento de execução de sincronização com métricas detalhadas
    """
    
    __tablename__ = "SyncExecutions"
    
    # Chave primária UUID conforme modelo original
    execution_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da execução'
    )
    
    # Relacionamento com integração
    integration_id = Column(
        UUID(as_uuid=True),
        ForeignKey('ToolIntegrations.integration_id'),
        nullable=False,
        comment='Referência à integração'
    )
    
    # Tipo de execução
    execution_type = Column(
        Text,
        comment='Tipo: agendado, manual, acionado'
    )
    
    # Detalhes da execução
    start_time = Column(
        func.timestamptz(),
        nullable=False,
        default=func.now(),
        comment='Hora de início'
    )
    
    end_time = Column(
        func.timestamptz(),
        comment='Hora de término (nulo se ainda executando)'
    )
    
    execution_status = Column(
        Text,
        nullable=False,
        comment='Status: executando, sucesso, falhou, cancelado'
    )
    
    triggered_by = Column(
        UUID(as_uuid=True),
        ForeignKey('Users.user_id'),
        comment='Usuário ou sistema que acionou a sincronização'
    )
    
    # Métricas de sincronização
    records_processed = Column(
        Integer,
        comment='Número de registros processados'
    )
    
    records_created = Column(
        Integer,
        comment='Número de registros criados'
    )
    
    records_updated = Column(
        Integer,
        comment='Número de registros atualizados'
    )
    
    records_deleted = Column(
        Integer,
        comment='Número de registros deletados'
    )
    
    records_failed = Column(
        Integer,
        comment='Número de registros que falharam na sincronização'
    )
    
    # Detalhes adicionais
    execution_notes = Column(
        Text,
        comment='Notas e detalhes da execução'
    )
    
    performance_metrics = Column(
        JSON,
        comment='Métricas detalhadas de performance'
    )
    
    # Relacionamentos
    integration = relationship("ToolIntegrations", back_populates="sync_executions")
    triggered_by_user = relationship("Users", back_populates="triggered_sync_executions")
    sync_errors = relationship("SyncErrors", back_populates="execution")
    
    def __repr__(self):
        return f"<SyncExecutions(execution_id={self.execution_id}, status={self.execution_status})>"

