"""
Modelos para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original com 36 tabelas
Autor: Carlos Morais
"""

# Modelo base
from .base import BaseEntity

# Contratos e Versionamento (4 tabelas)
from .data_contracts import DataContracts
from .contract_versions import ContractVersions
from .contract_layouts import ContractLayouts
from .contract_custom_properties import ContractCustomProperties

# Componentes Modulares (5 tabelas)
from .contract_fundamentals import ContractFundamentals
from .contract_team_definitions import ContractTeamDefinitions
from .contract_sla_definitions import ContractSLADefinitions
from .contract_pricing_definitions import ContractPricingDefinitions
from .contract_schema_definitions import ContractSchemaDefinitions

# Objetos de Dados (2 tabelas)
from .data_objects import DataObjects
from .data_object_properties import DataObjectProperties

# Qualidade de Dados (4 tabelas)
from .contract_quality_definitions import ContractQualityDefinitions
from .quality_rules import QualityRules
from .property_quality_rule_links import PropertyQualityRuleLinks
from .quality_execution_results import QualityExecutionResults

# Métricas de Monitoramento (4 tabelas)
from .cluster_metrics import ClusterMetrics
from .job_metrics import JobMetrics
from .query_metrics import QueryMetrics
from .storage_metrics import StorageMetrics

# Linhagem de Dados (1 tabela)
from .data_lineage import DataLineage

# Usuários e Permissões (5 tabelas)
from .users import Users
from .groups import Groups
from .user_groups import UserGroups
from .permissions import Permissions
from .group_permissions import GroupPermissions

# Tags e Entidades (3 tabelas)
from .entity import Entity
from .tag import Tag
from .tagged import Tagged

# Governança e Conformidade (2 tabelas)
from .abac_policy_evaluations import ABACPolicyEvaluations
from .data_classification_results import DataClassificationResults

# Integração e Sincronização (3 tabelas)
from .tool_integrations import ToolIntegrations
from .sync_executions import SyncExecutions
from .sync_errors import SyncErrors

# Auditoria e Analytics (3 tabelas)
from .audit_log import AuditLog
from .data_quality_aggregates import DataQualityAggregates
from .data_anomaly_detection import DataAnomalyDetection

__all__ = [
    # Base
    "BaseEntity",
    
    # Contratos e Versionamento (4)
    "DataContracts",
    "ContractVersions", 
    "ContractLayouts",
    "ContractCustomProperties",
    
    # Componentes Modulares (5)
    "ContractFundamentals",
    "ContractTeamDefinitions",
    "ContractSLADefinitions",
    "ContractPricingDefinitions",
    "ContractSchemaDefinitions",
    
    # Objetos de Dados (2)
    "DataObjects",
    "DataObjectProperties",
    
    # Qualidade de Dados (4)
    "ContractQualityDefinitions",
    "QualityRules",
    "PropertyQualityRuleLinks",
    "QualityExecutionResults",
    
    # Métricas de Monitoramento (4)
    "ClusterMetrics",
    "JobMetrics",
    "QueryMetrics",
    "StorageMetrics",
    
    # Linhagem de Dados (1)
    "DataLineage",
    
    # Usuários e Permissões (5)
    "Users",
    "Groups",
    "UserGroups",
    "Permissions",
    "GroupPermissions",
    
    # Tags e Entidades (3)
    "Entity",
    "Tag",
    "Tagged",
    
    # Governança e Conformidade (2)
    "ABACPolicyEvaluations",
    "DataClassificationResults",
    
    # Integração e Sincronização (3)
    "ToolIntegrations",
    "SyncExecutions",
    "SyncErrors",
    
    # Auditoria e Analytics (3)
    "AuditLog",
    "DataQualityAggregates",
    "DataAnomalyDetection",
]

# Total: 36 tabelas conforme modelo_estendido.dbml original

