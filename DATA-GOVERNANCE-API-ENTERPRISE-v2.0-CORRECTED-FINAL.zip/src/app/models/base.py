"""
Modelo base para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from datetime import datetime
from typing import Any, Dict
from uuid import uuid4

from sqlalchemy import Column, DateTime, MetaData, text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

# Metadata para todas as tabelas
metadata = MetaData()

# Base class para todos os modelos
Base = declarative_base(metadata=metadata)


class BaseEntity(Base):
    """
    Classe base para todas as entidades do sistema
    Seguindo o padrão do modelo_estendido.dbml:
    - Campos UUID como chave primária
    - Campos de auditoria data_criacao e data_atualizacao
    - Sem campo id sequencial
    """
    
    __abstract__ = True
    
    # Campos de auditoria obrigatórios conforme modelo original
    data_criacao = Column(
        DateTime(timezone=True),
        nullable=False,
        default=func.now(),
        server_default=text('now()'),
        comment='Data de criação do registro'
    )
    
    data_atualizacao = Column(
        DateTime(timezone=True),
        nullable=False,
        default=func.now(),
        onupdate=func.now(),
        server_default=text('now()'),
        comment='Data da última atualização do registro'
    )
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte o modelo para dicionário"""
        result = {}
        for column in self.__table__.columns:
            value = getattr(self, column.name)
            if isinstance(value, datetime):
                result[column.name] = value.isoformat()
            else:
                result[column.name] = value
        return result
    
    def __repr__(self) -> str:
        """Representação string do modelo"""
        class_name = self.__class__.__name__
        # Pega o primeiro campo UUID como identificador
        for column in self.__table__.columns:
            if str(column.type) == 'UUID':
                id_value = getattr(self, column.name)
                return f"<{class_name}({column.name}={id_value})>"
        return f"<{class_name}()>"

