"""
Modelo DataQualityAggregates para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import BigInteger, Column, ForeignKey, Integer, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class DataQualityAggregates(BaseEntity):
    """
    Métricas agregadas de qualidade para análise de tendências e relatórios
    """
    
    __tablename__ = "DataQualityAggregates"
    
    # Chave primária composta conforme modelo original
    contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataContracts.contract_id'),
        primary_key=True,
        comment='Referência ao contrato'
    )
    
    aggregation_period = Column(
        Text,
        primary_key=True,
        nullable=False,
        comment='Período: horario, diario, semanal, mensal'
    )
    
    aggregation_timestamp = Column(
        func.timestamptz(),
        primary_key=True,
        nullable=False,
        comment='Início do período de agregação'
    )
    
    # Métricas agregadas de qualidade
    total_executions = Column(
        Integer,
        comment='Total de execuções de qualidade no período'
    )
    
    successful_executions = Column(
        Integer,
        comment='Execuções bem-sucedidas'
    )
    
    failed_executions = Column(
        Integer,
        comment='Execuções que falharam'
    )
    
    avg_quality_score = Column(
        Numeric,
        comment='Pontuação média de qualidade'
    )
    
    min_quality_score = Column(
        Numeric,
        comment='Pontuação mínima de qualidade'
    )
    
    max_quality_score = Column(
        Numeric,
        comment='Pontuação máxima de qualidade'
    )
    
    quality_trend = Column(
        Text,
        comment='Tendência: melhorando, estavel, degradando'
    )
    
    # Métricas de conformidade de SLA
    sla_target_percent = Column(
        Numeric,
        comment='Porcentagem alvo do SLA'
    )
    
    sla_actual_percent = Column(
        Numeric,
        comment='Alcance real do SLA'
    )
    
    sla_compliance_status = Column(
        Text,
        comment='Status: conforme, em_risco, violado'
    )
    
    # Métricas de volume
    total_records_processed = Column(
        BigInteger,
        comment='Total de registros processados no período'
    )
    
    avg_records_per_execution = Column(
        BigInteger,
        comment='Média de registros por execução'
    )
    
    # Relacionamentos
    contract = relationship("DataContracts", back_populates="quality_aggregates")
    
    def __repr__(self):
        return f"<DataQualityAggregates(contract_id={self.contract_id}, period={self.aggregation_period})>"

