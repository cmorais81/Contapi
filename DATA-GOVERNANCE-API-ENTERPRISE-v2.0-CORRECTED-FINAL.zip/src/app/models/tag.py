"""
Modelo Tag para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class Tag(BaseEntity):
    """
    Sistema flexível de tagueamento com propriedades visuais e hierarquia
    """
    
    __tablename__ = "Tag"
    
    # Chave primária UUID conforme modelo original
    tag_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da tag'
    )
    
    # Informações básicas da tag
    tag_name = Column(
        Text,
        nullable=False,
        comment='Nome da tag'
    )
    
    tag_display_name = Column(
        Text,
        comment='Nome de exibição para UI'
    )
    
    tag_description = Column(
        Text,
        comment='Descrição da tag'
    )
    
    tag_category = Column(
        Text,
        comment='Categoria da tag (negocio, tecnico, conformidade, qualidade)'
    )
    
    # Propriedades visuais
    icon_code = Column(
        Text,
        comment='Código do ícone para exibição na UI'
    )
    
    hex_color = Column(
        Text,
        comment='Código de cor hexadecimal para exibição na UI'
    )
    
    # Integração com plataforma
    unity_catalog_tag_id = Column(
        UUID(as_uuid=True),
        comment='Referência da tag do Unity Catalog'
    )
    
    tag_policy_id = Column(
        UUID(as_uuid=True),
        comment='ID da política de tag associada'
    )
    
    # Hierarquia e relacionamentos
    parent_tag_id = Column(
        UUID(as_uuid=True),
        ForeignKey('Tag.tag_id'),
        comment='Tag pai para hierarquia'
    )
    
    # Relacionamentos
    parent_tag = relationship("Tag", remote_side=[tag_id], back_populates="child_tags")
    child_tags = relationship("Tag", back_populates="parent_tag")
    tagged_entities = relationship("Tagged", back_populates="tag")
    
    def __repr__(self):
        return f"<Tag(tag_id={self.tag_id}, name={self.tag_name})>"

