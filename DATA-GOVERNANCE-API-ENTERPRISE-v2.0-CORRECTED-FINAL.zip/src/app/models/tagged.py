"""
Modelo Tagged para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class Tagged(BaseEntity):
    """
    Relacionamento muitos-para-muitos entre tags e entidades
    """
    
    __tablename__ = "Tagged"
    
    # Chave primária UUID conforme modelo original
    tagged_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do relacionamento de tag'
    )
    
    # Relacionamentos
    tag_id = Column(
        UUID(as_uuid=True),
        ForeignKey('Tag.tag_id'),
        nullable=False,
        comment='Referência à tag'
    )
    
    entity_id = Column(
        UUID(as_uuid=True),
        ForeignKey('Entity.entity_id'),
        nullable=False,
        comment='Referência à entidade'
    )
    
    # Informações do tagueamento
    entity_type = Column(
        Text,
        nullable=False,
        comment='Tipo da entidade tagueada'
    )
    
    tagged_by = Column(
        UUID(as_uuid=True),
        ForeignKey('Users.user_id'),
        comment='Usuário que aplicou a tag'
    )
    
    tag_value = Column(
        Text,
        comment='Valor da tag se a tag suportar valores'
    )
    
    # Relacionamentos
    tag = relationship("Tag", back_populates="tagged_entities")
    entity = relationship("Entity", back_populates="tagged_entities")
    user = relationship("Users", back_populates="tagged_entities")
    
    def __repr__(self):
        return f"<Tagged(tagged_id={self.tagged_id}, tag_id={self.tag_id}, entity_id={self.entity_id})>"

