"""
Modelo ToolIntegrations para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Integer, Text
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class ToolIntegrations(BaseEntity):
    """
    Integrações de ferramentas externas com monitoramento de saúde
    """
    
    __tablename__ = "ToolIntegrations"
    
    # Chave primária UUID conforme modelo original
    integration_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da integração'
    )
    
    # Relacionamento com contrato
    contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataContracts.contract_id'),
        nullable=False,
        comment='Referência ao contrato'
    )
    
    # Informações da integração
    tool_name = Column(
        Text,
        nullable=False,
        comment='Nome da ferramenta (Informatica Axon, Unity Catalog, Collibra)'
    )
    
    integration_type = Column(
        Text,
        nullable=False,
        comment='Tipo: exportacao, importacao, sincronizacao_bidirecional'
    )
    
    integration_config = Column(
        JSON,
        comment='Configuração JSON para integração'
    )
    
    # Status e saúde
    integration_status = Column(
        Text,
        comment='Status: ativo, inativo, erro, manutencao'
    )
    
    last_sync_timestamp = Column(
        func.timestamptz(),
        comment='Timestamp da última sincronização bem-sucedida'
    )
    
    last_sync_status = Column(
        Text,
        comment='Status da última sincronização: sucesso, falhou, parcial'
    )
    
    next_sync_timestamp = Column(
        func.timestamptz(),
        comment='Próxima sincronização agendada'
    )
    
    # Tratamento de erros
    error_count = Column(
        Integer,
        default=0,
        comment='Número de erros consecutivos'
    )
    
    last_error_message = Column(
        Text,
        comment='Última mensagem de erro'
    )
    
    last_error_timestamp = Column(
        func.timestamptz(),
        comment='Timestamp do último erro'
    )
    
    # Relacionamentos
    contract = relationship("DataContracts", back_populates="tool_integrations")
    sync_executions = relationship("SyncExecutions", back_populates="integration")
    
    def __repr__(self):
        return f"<ToolIntegrations(integration_id={self.integration_id}, tool={self.tool_name})>"

