"""
Modelo ClusterMetrics para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import BigInteger, Column, ForeignKey, Integer, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class ClusterMetrics(BaseEntity):
    """
    Métricas abrangentes de performance e utilização do cluster
    """
    
    __tablename__ = "ClusterMetrics"
    
    # Chave primária composta conforme modelo original
    cluster_id = Column(
        Text,
        primary_key=True,
        nullable=False,
        comment='Identificador do cluster da plataforma'
    )
    
    measurement_timestamp = Column(
        func.timestamptz(),
        primary_key=True,
        nullable=False,
        comment='Timestamp da coleta de métricas'
    )
    
    # Informações do cluster
    cluster_name = Column(
        Text,
        nullable=False,
        comment='Nome do cluster'
    )
    
    cluster_type = Column(
        Text,
        nullable=False,
        comment='Tipo: interativo, job, serverless'
    )
    
    contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataContracts.contract_id'),
        comment='Contrato de dados associado'
    )
    
    # Métricas de utilização de recursos
    node_count = Column(
        Integer,
        comment='Número de nós no cluster'
    )
    
    cpu_utilization_percent = Column(
        Numeric,
        comment='Porcentagem de utilização de CPU'
    )
    
    memory_utilization_percent = Column(
        Numeric,
        comment='Porcentagem de utilização de memória'
    )
    
    disk_io_read_bytes = Column(
        BigInteger,
        comment='Bytes de leitura de disco'
    )
    
    disk_io_write_bytes = Column(
        BigInteger,
        comment='Bytes de escrita de disco'
    )
    
    network_in_bytes = Column(
        BigInteger,
        comment='Bytes de entrada de rede'
    )
    
    network_out_bytes = Column(
        BigInteger,
        comment='Bytes de saída de rede'
    )
    
    # Métricas de auto-scaling
    auto_scaling_events = Column(
        Integer,
        comment='Número de eventos de auto-scaling'
    )
    
    scaling_latency_seconds = Column(
        Numeric,
        comment='Latência média de scaling'
    )
    
    # Métricas de custo
    cost_per_hour = Column(
        Numeric,
        comment='Custo por hora em USD'
    )
    
    # Relacionamentos
    contract = relationship("DataContracts", back_populates="cluster_metrics")
    
    def __repr__(self):
        return f"<ClusterMetrics(cluster_id={self.cluster_id}, timestamp={self.measurement_timestamp})>"

