"""
Modelo DataLineage para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import BigInteger, Column, ForeignKey, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class DataLineage(BaseEntity):
    """
    Lineage granular de dados com detalhes de transformação e validação
    """
    
    __tablename__ = "DataLineage"
    
    # Chave primária UUID conforme modelo original
    lineage_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do lineage'
    )
    
    # Relacionamento com propriedade de destino
    target_property_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataObjectProperties.property_id'),
        nullable=False,
        comment='Propriedade de destino'
    )
    
    # Informações da origem
    source_namespace = Column(
        Text,
        comment='Namespace da origem (ex: com.exemplo.servico.checkout)'
    )
    
    source_object_name = Column(
        Text,
        nullable=False,
        comment='Nome do objeto de dados de origem (ex: checkout_db.pedidos)'
    )
    
    source_property_name = Column(
        Text,
        nullable=False,
        comment='Nome da propriedade de origem (ex: endereco_email)'
    )
    
    # Detalhes da transformação
    transformation_type = Column(
        Text,
        comment='Tipo de transformação (copia_direta, agregacao, juncao, calculo, predicao_ml)'
    )
    
    transformation_description = Column(
        Text,
        comment='Descrição detalhada da transformação aplicada'
    )
    
    transformation_sql = Column(
        Text,
        comment='Lógica de transformação SQL se aplicável'
    )
    
    transformation_code = Column(
        Text,
        comment='Código para transformações complexas (Python, Scala, etc.)'
    )
    
    # Integração com Plataforma de Dados
    unity_catalog_lineage_id = Column(
        UUID(as_uuid=True),
        comment='Referência do lineage do Unity Catalog'
    )
    
    spark_plan_hash = Column(
        Text,
        comment='Hash do plano de execução Spark'
    )
    
    delta_table_version = Column(
        BigInteger,
        comment='Versão da tabela Delta quando o lineage foi capturado'
    )
    
    # Qualidade e confiança
    lineage_confidence_score = Column(
        Numeric,
        comment='Pontuação de confiança para precisão do lineage (0-1)'
    )
    
    lineage_method = Column(
        Text,
        comment='Como o lineage foi capturado (automatico, manual, inferido)'
    )
    
    validation_status = Column(
        Text,
        comment='Status de validação (validado, pendente, contestado)'
    )
    
    validated_by = Column(
        UUID(as_uuid=True),
        ForeignKey('Users.user_id'),
        comment='Usuário que validou o lineage'
    )
    
    validation_timestamp = Column(
        func.timestamptz(),
        comment='Timestamp da validação'
    )
    
    # Relacionamentos
    target_property = relationship("DataObjectProperties", back_populates="lineage_targets")
    validator = relationship("Users", back_populates="validated_lineages")
    
    def __repr__(self):
        return f"<DataLineage(lineage_id={self.lineage_id}, source={self.source_object_name}.{self.source_property_name})>"

