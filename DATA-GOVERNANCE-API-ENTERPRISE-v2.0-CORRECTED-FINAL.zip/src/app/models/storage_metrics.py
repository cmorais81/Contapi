"""
Modelo StorageMetrics para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import BigInteger, Column, ForeignKey, Integer, Numeric, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class StorageMetrics(BaseEntity):
    """
    Métricas de performance e custo de armazenamento para otimização
    """
    
    __tablename__ = "StorageMetrics"
    
    # Chave primária composta conforme modelo original
    storage_location = Column(
        Text,
        primary_key=True,
        nullable=False,
        comment='Caminho de armazenamento ou nome da tabela'
    )
    
    measurement_timestamp = Column(
        func.timestamptz(),
        primary_key=True,
        nullable=False,
        comment='Timestamp da medição'
    )
    
    # Informações do armazenamento
    storage_type = Column(
        Text,
        nullable=False,
        comment='Tipo: delta, iceberg, parquet, json'
    )
    
    contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataContracts.contract_id'),
        comment='Contrato de dados associado'
    )
    
    data_object_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataObjects.data_object_id'),
        comment='Objeto de dados associado'
    )
    
    # Métricas de tamanho de armazenamento
    total_size_bytes = Column(
        BigInteger,
        comment='Tamanho total de armazenamento em bytes'
    )
    
    file_count = Column(
        Integer,
        comment='Número de arquivos'
    )
    
    avg_file_size_bytes = Column(
        BigInteger,
        comment='Tamanho médio do arquivo'
    )
    
    # Métricas específicas do Delta Lake
    delta_version = Column(
        BigInteger,
        comment='Versão atual da tabela Delta'
    )
    
    delta_files_added = Column(
        Integer,
        comment='Arquivos adicionados na última operação'
    )
    
    delta_files_removed = Column(
        Integer,
        comment='Arquivos removidos na última operação'
    )
    
    compaction_ratio = Column(
        Numeric,
        comment='Taxa de efetividade da compactação'
    )
    
    # Métricas específicas do Iceberg
    iceberg_snapshot_id = Column(
        UUID(as_uuid=True),
        comment='ID do snapshot atual do Iceberg'
    )
    
    iceberg_manifest_count = Column(
        Integer,
        comment='Número de arquivos de manifesto'
    )
    
    iceberg_data_files_count = Column(
        Integer,
        comment='Número de arquivos de dados'
    )
    
    # Métricas de performance
    read_throughput_mbps = Column(
        Numeric,
        comment='Throughput de leitura em MB/s'
    )
    
    write_throughput_mbps = Column(
        Numeric,
        comment='Throughput de escrita em MB/s'
    )
    
    # Métricas de custo
    storage_cost_usd = Column(
        Numeric,
        comment='Custo de armazenamento em USD'
    )
    
    # Relacionamentos
    contract = relationship("DataContracts", back_populates="storage_metrics")
    data_object = relationship("DataObjects", back_populates="storage_metrics")
    
    def __repr__(self):
        return f"<StorageMetrics(location={self.storage_location}, timestamp={self.measurement_timestamp})>"

