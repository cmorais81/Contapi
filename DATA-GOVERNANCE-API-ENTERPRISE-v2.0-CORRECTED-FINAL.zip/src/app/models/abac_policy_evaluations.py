"""
Modelo ABACPolicyEvaluations para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Numeric, Text
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class ABACPolicyEvaluations(BaseEntity):
    """
    Trilha de auditoria completa das avaliações de política ABAC
    """
    
    __tablename__ = "ABACPolicyEvaluations"
    
    # Chave primária UUID conforme modelo original
    evaluation_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da avaliação'
    )
    
    # Relacionamento opcional com contrato
    contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataContracts.contract_id'),
        comment='Referência ao contrato'
    )
    
    # Detalhes da solicitação de acesso
    user_id = Column(
        UUID(as_uuid=True),
        ForeignKey('Users.user_id'),
        nullable=False,
        comment='Usuário solicitando acesso'
    )
    
    resource_id = Column(
        UUID(as_uuid=True),
        nullable=False,
        comment='Recurso sendo acessado'
    )
    
    resource_type = Column(
        Text,
        nullable=False,
        comment='Tipo: tabela, coluna, view, funcao'
    )
    
    action_requested = Column(
        Text,
        nullable=False,
        comment='Ação: ler, escrever, deletar, executar'
    )
    
    # Avaliação da política
    policy_id = Column(
        UUID(as_uuid=True),
        comment='Identificador da política ABAC'
    )
    
    policy_name = Column(
        Text,
        comment='Nome legível da política'
    )
    
    attributes_evaluated = Column(
        JSON,
        comment='Atributos de usuário e contexto avaliados'
    )
    
    evaluation_timestamp = Column(
        func.timestamptz(),
        nullable=False,
        comment='Timestamp da avaliação'
    )
    
    evaluation_duration_ms = Column(
        Numeric,
        comment='Tempo de avaliação da política'
    )
    
    # Decisão e raciocínio
    decision = Column(
        Text,
        nullable=False,
        comment='Decisão: permitir, negar, condicional'
    )
    
    decision_reason = Column(
        Text,
        comment='Raciocínio detalhado para a decisão'
    )
    
    conditions_applied = Column(
        Text,
        comment='Condições adicionais se acesso condicional'
    )
    
    # Informações de contexto
    request_timestamp = Column(
        func.timestamptz(),
        nullable=False,
        comment='Timestamp da solicitação'
    )
    
    client_ip = Column(
        Text,
        comment='Endereço IP do cliente'
    )
    
    user_agent = Column(
        Text,
        comment='String do user agent'
    )
    
    session_id = Column(
        UUID(as_uuid=True),
        comment='Identificador da sessão do usuário'
    )
    
    # Relacionamentos
    contract = relationship("DataContracts", back_populates="abac_evaluations")
    user = relationship("Users", back_populates="abac_evaluations")
    
    def __repr__(self):
        return f"<ABACPolicyEvaluations(evaluation_id={self.evaluation_id}, decision={self.decision})>"

