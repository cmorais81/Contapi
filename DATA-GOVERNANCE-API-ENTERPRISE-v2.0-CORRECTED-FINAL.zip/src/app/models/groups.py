"""
Modelo Groups para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class Groups(BaseEntity):
    """
    Gerenciamento de grupos com suporte a hierarquia
    """
    
    __tablename__ = "Groups"
    
    # Chave primária UUID conforme modelo original
    group_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do grupo'
    )
    
    # Informações básicas do grupo
    group_name = Column(
        Text,
        unique=True,
        nullable=False,
        comment='Nome do grupo'
    )
    
    group_description = Column(
        Text,
        comment='Descrição do grupo'
    )
    
    group_type = Column(
        Text,
        comment='Tipo do grupo (departamento, projeto, funcao)'
    )
    
    # Integração com plataforma
    platform_group_id = Column(
        Text,
        comment='ID do grupo na plataforma de dados'
    )
    
    unity_catalog_group = Column(
        Text,
        comment='Grupo do Unity Catalog'
    )
    
    # Hierarquia
    parent_group_id = Column(
        UUID(as_uuid=True),
        ForeignKey('Groups.group_id'),
        comment='Grupo pai para hierarquia'
    )
    
    # Relacionamentos
    parent_group = relationship("Groups", remote_side=[group_id], back_populates="child_groups")
    child_groups = relationship("Groups", back_populates="parent_group")
    user_groups = relationship("UserGroups", back_populates="group")
    group_permissions = relationship("GroupPermissions", back_populates="group")
    
    def __repr__(self):
        return f"<Groups(group_id={self.group_id}, name={self.group_name})>"

