"""
Modelo DataContracts para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Boolean, Column, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func

from .base import BaseEntity


class DataContracts(BaseEntity):
    """
    Contratos de dados aprimorados com integração nativa e estrutura modular
    Tabela central do sistema de governança de dados
    """
    
    __tablename__ = "DataContracts"
    
    # Chave primária UUID conforme modelo original
    contract_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do contrato'
    )
    
    # Campos básicos do contrato
    contract_name = Column(
        Text,
        nullable=False,
        comment='Nome do contrato de dados'
    )
    
    contract_description = Column(
        Text,
        comment='Descrição detalhada do contrato'
    )
    
    contract_status = Column(
        Text,
        nullable=False,
        comment='Status: rascunho, ativo, depreciado, aposentado'
    )
    
    # Produto de dados
    data_product_name = Column(
        Text,
        nullable=False,
        comment='Nome do produto de dados'
    )
    
    data_product_owner = Column(
        Text,
        nullable=False,
        comment='Proprietário do produto de dados'
    )
    
    data_product_domain = Column(
        Text,
        comment='Domínio de negócio'
    )
    
    # Melhorias V4.0 - Layout e Versão Atual
    layout_id = Column(
        UUID(as_uuid=True),
        comment='Referência do layout atual'
    )
    
    current_version_id = Column(
        UUID(as_uuid=True),
        comment='Versão ativa atual'
    )
    
    # Integração com Plataforma de Dados
    unity_catalog_name = Column(
        Text,
        comment='Referência do Unity Catalog'
    )
    
    unity_catalog_schema = Column(
        Text,
        comment='Schema do Unity Catalog'
    )
    
    iceberg_table_uuid = Column(
        UUID(as_uuid=True),
        comment='UUID da tabela Iceberg para compatibilidade cross-engine'
    )
    
    auto_monitoring_enabled = Column(
        Boolean,
        nullable=False,
        default=True,
        comment='Monitoramento automático habilitado'
    )
    
    abac_policy_id = Column(
        UUID(as_uuid=True),
        comment='Referência da política de Controle de Acesso Baseado em Atributos'
    )
    
    def __repr__(self):
        return f"<DataContracts(contract_id={self.contract_id}, name={self.contract_name})>"

