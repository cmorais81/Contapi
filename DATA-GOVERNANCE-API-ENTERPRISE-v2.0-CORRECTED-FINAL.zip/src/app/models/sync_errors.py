"""
Modelo SyncErrors para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class SyncErrors(BaseEntity):
    """
    Erros de sincronização com rastreamento de resolução
    """
    
    __tablename__ = "SyncErrors"
    
    # Chave primária UUID conforme modelo original
    error_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do erro'
    )
    
    # Relacionamento com execução
    execution_id = Column(
        UUID(as_uuid=True),
        ForeignKey('SyncExecutions.execution_id'),
        nullable=False,
        comment='Referência à execução'
    )
    
    # Detalhes do erro
    error_timestamp = Column(
        func.timestamptz(),
        nullable=False,
        default=func.now(),
        comment='Timestamp do erro'
    )
    
    error_code = Column(
        Text,
        comment='Código do erro'
    )
    
    error_message = Column(
        Text,
        comment='Mensagem do erro'
    )
    
    stack_trace = Column(
        Text,
        comment='Stack trace completo'
    )
    
    affected_object = Column(
        Text,
        comment='Objeto que causou o erro'
    )
    
    error_severity = Column(
        Text,
        comment='Severidade: baixa, media, alta, critica'
    )
    
    # Rastreamento de resolução
    resolution_status = Column(
        Text,
        comment='Status: aberto, investigando, resolvido, ignorado'
    )
    
    resolved_by = Column(
        UUID(as_uuid=True),
        ForeignKey('Users.user_id'),
        comment='Usuário que resolveu o erro'
    )
    
    resolution_timestamp = Column(
        func.timestamptz(),
        comment='Timestamp da resolução'
    )
    
    resolution_notes = Column(
        Text,
        comment='Notas da resolução'
    )
    
    # Relacionamentos
    execution = relationship("SyncExecutions", back_populates="sync_errors")
    resolver = relationship("Users", back_populates="resolved_sync_errors")
    
    def __repr__(self):
        return f"<SyncErrors(error_id={self.error_id}, severity={self.error_severity})>"

