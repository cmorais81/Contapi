"""
Modelo PropertyQualityRuleLinks para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import Column, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class PropertyQualityRuleLinks(BaseEntity):
    """
    Relacionamento muitos-para-muitos entre propriedades e regras de qualidade
    """
    
    __tablename__ = "PropertyQualityRuleLinks"
    
    # Chave primária UUID conforme modelo original
    link_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único do link'
    )
    
    # Relacionamentos
    property_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataObjectProperties.property_id'),
        nullable=False,
        comment='Referência à propriedade'
    )
    
    quality_rule_id = Column(
        UUID(as_uuid=True),
        ForeignKey('QualityRules.quality_rule_id'),
        nullable=False,
        comment='Referência à regra de qualidade'
    )
    
    # Contexto do relacionamento
    rule_context = Column(
        Text,
        comment='Contexto de como a regra se aplica a esta propriedade específica'
    )
    
    # Relacionamentos
    property = relationship("DataObjectProperties", back_populates="quality_rule_links")
    quality_rule = relationship("QualityRules", back_populates="property_links")
    
    def __repr__(self):
        return f"<PropertyQualityRuleLinks(link_id={self.link_id})>"

