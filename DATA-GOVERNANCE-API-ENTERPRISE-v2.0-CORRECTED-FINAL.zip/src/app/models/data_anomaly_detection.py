"""
Modelo DataAnomalyDetection para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from sqlalchemy import BigInteger, Boolean, Column, ForeignKey, Numeric, Text
from sqlalchemy.dialects.postgresql import JSON, UUID
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship

from .base import BaseEntity


class DataAnomalyDetection(BaseEntity):
    """
    Resultados de detecção de anomalias com rastreamento de resolução
    """
    
    __tablename__ = "DataAnomalyDetection"
    
    # Chave primária UUID conforme modelo original
    anomaly_id = Column(
        UUID(as_uuid=True),
        primary_key=True,
        default=func.gen_random_uuid(),
        nullable=False,
        comment='Identificador único da anomalia'
    )
    
    # Relacionamentos opcionais
    contract_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataContracts.contract_id'),
        comment='Referência ao contrato'
    )
    
    property_id = Column(
        UUID(as_uuid=True),
        ForeignKey('DataObjectProperties.property_id'),
        comment='Referência à propriedade'
    )
    
    # Timestamp da detecção
    detection_timestamp = Column(
        func.timestamptz(),
        nullable=False,
        comment='Timestamp da detecção'
    )
    
    # Classificação da anomalia
    anomaly_type = Column(
        Text,
        nullable=False,
        comment='Tipo: estatistica, padrao, regra_negocio, detectada_ml'
    )
    
    anomaly_severity = Column(
        Text,
        nullable=False,
        comment='Severidade: baixa, media, alta, critica'
    )
    
    anomaly_category = Column(
        Text,
        comment='Categoria: volume, distribuicao, padrao, outlier'
    )
    
    # Dados afetados
    affected_columns = Column(
        Text,
        comment='Lista separada por vírgulas das colunas afetadas'
    )
    
    affected_records_count = Column(
        BigInteger,
        comment='Número de registros afetados'
    )
    
    affected_data_sample = Column(
        JSON,
        comment='Amostra dos dados afetados'
    )
    
    # Detalhes da detecção
    detection_method = Column(
        Text,
        comment='Método: estatistico, modelo_ml, baseado_regras'
    )
    
    confidence_score = Column(
        Numeric,
        comment='Pontuação de confiança (0-1)'
    )
    
    anomaly_description = Column(
        Text,
        comment='Descrição legível da anomalia'
    )
    
    baseline_comparison = Column(
        JSON,
        comment='Comparação com métricas de baseline'
    )
    
    # Rastreamento de resolução
    resolution_status = Column(
        Text,
        comment='Status: aberto, investigando, resolvido, falso_positivo'
    )
    
    assigned_to = Column(
        UUID(as_uuid=True),
        ForeignKey('Users.user_id'),
        comment='Pessoa designada para investigar'
    )
    
    resolution_notes = Column(
        Text,
        comment='Notas de resolução e ações tomadas'
    )
    
    resolved_timestamp = Column(
        func.timestamptz(),
        comment='Timestamp da resolução'
    )
    
    # Feedback para melhoria de ML
    false_positive_feedback = Column(
        Boolean,
        comment='Feedback do usuário para melhoria do modelo ML'
    )
    
    feedback_notes = Column(
        Text,
        comment='Notas adicionais de feedback'
    )
    
    # Relacionamentos
    contract = relationship("DataContracts", back_populates="anomaly_detections")
    property = relationship("DataObjectProperties", back_populates="anomaly_detections")
    assignee = relationship("Users", back_populates="assigned_anomalies")
    
    def __repr__(self):
        return f"<DataAnomalyDetection(anomaly_id={self.anomaly_id}, type={self.anomaly_type}, severity={self.anomaly_severity})>"

