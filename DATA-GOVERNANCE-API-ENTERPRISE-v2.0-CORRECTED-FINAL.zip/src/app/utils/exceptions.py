"""
Exceções customizadas para Data Governance API
Autor: Carlos Morais

Módulo com exceções específicas para diferentes tipos de erros
na aplicação de governança de dados.
"""

from typing import Any, Dict, List, Optional
from fastapi import HTTPException, status


class DataGovernanceException(Exception):
    """Exceção base para Data Governance API"""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


class ValidationError(DataGovernanceException):
    """Erro de validação de dados"""
    
    def __init__(self, message: str, field: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        self.field = field
        super().__init__(message, details)


class AuthenticationError(DataGovernanceException):
    """Erro de autenticação"""
    
    def __init__(self, message: str = "Falha na autenticação", details: Optional[Dict[str, Any]] = None):
        super().__init__(message, details)


class AuthorizationError(DataGovernanceException):
    """Erro de autorização"""
    
    def __init__(self, message: str = "Acesso negado", resource: Optional[str] = None, action: Optional[str] = None):
        self.resource = resource
        self.action = action
        details = {}
        if resource:
            details["resource"] = resource
        if action:
            details["action"] = action
        super().__init__(message, details)


class EntityNotFoundError(DataGovernanceException):
    """Entidade não encontrada"""
    
    def __init__(self, entity_type: str, entity_id: str, details: Optional[Dict[str, Any]] = None):
        self.entity_type = entity_type
        self.entity_id = entity_id
        message = f"{entity_type} não encontrado: {entity_id}"
        super().__init__(message, details)


class EntityAlreadyExistsError(DataGovernanceException):
    """Entidade já existe"""
    
    def __init__(self, entity_type: str, identifier: str, details: Optional[Dict[str, Any]] = None):
        self.entity_type = entity_type
        self.identifier = identifier
        message = f"{entity_type} já existe: {identifier}"
        super().__init__(message, details)


class BusinessRuleViolationError(DataGovernanceException):
    """Violação de regra de negócio"""
    
    def __init__(self, rule: str, message: str, details: Optional[Dict[str, Any]] = None):
        self.rule = rule
        full_message = f"Violação da regra '{rule}': {message}"
        super().__init__(full_message, details)


class DataQualityError(DataGovernanceException):
    """Erro de qualidade de dados"""
    
    def __init__(self, rule_name: str, threshold: float, actual_value: float, details: Optional[Dict[str, Any]] = None):
        self.rule_name = rule_name
        self.threshold = threshold
        self.actual_value = actual_value
        message = f"Falha na qualidade '{rule_name}': {actual_value}% < {threshold}%"
        super().__init__(message, details)


class LineageError(DataGovernanceException):
    """Erro de lineage de dados"""
    
    def __init__(self, message: str, source: Optional[str] = None, target: Optional[str] = None):
        self.source = source
        self.target = target
        details = {}
        if source:
            details["source"] = source
        if target:
            details["target"] = target
        super().__init__(message, details)


class ComplianceError(DataGovernanceException):
    """Erro de compliance"""
    
    def __init__(self, framework: str, violation: str, details: Optional[Dict[str, Any]] = None):
        self.framework = framework
        self.violation = violation
        message = f"Violação de compliance {framework}: {violation}"
        super().__init__(message, details)


class IntegrationError(DataGovernanceException):
    """Erro de integração com sistemas externos"""
    
    def __init__(self, system: str, operation: str, error_details: str):
        self.system = system
        self.operation = operation
        self.error_details = error_details
        message = f"Erro de integração com {system} na operação {operation}: {error_details}"
        super().__init__(message, {"system": system, "operation": operation})


class ConfigurationError(DataGovernanceException):
    """Erro de configuração"""
    
    def __init__(self, config_key: str, message: str):
        self.config_key = config_key
        full_message = f"Erro de configuração '{config_key}': {message}"
        super().__init__(full_message, {"config_key": config_key})


class PerformanceError(DataGovernanceException):
    """Erro de performance"""
    
    def __init__(self, operation: str, duration: float, threshold: float):
        self.operation = operation
        self.duration = duration
        self.threshold = threshold
        message = f"Performance degradada na operação '{operation}': {duration}s > {threshold}s"
        super().__init__(message, {"operation": operation, "duration": duration, "threshold": threshold})


class SecurityError(DataGovernanceException):
    """Erro de segurança"""
    
    def __init__(self, threat_type: str, message: str, details: Optional[Dict[str, Any]] = None):
        self.threat_type = threat_type
        full_message = f"Ameaça de segurança '{threat_type}': {message}"
        super().__init__(full_message, details)


class RateLimitError(DataGovernanceException):
    """Erro de rate limiting"""
    
    def __init__(self, limit: int, window: int, current_count: int):
        self.limit = limit
        self.window = window
        self.current_count = current_count
        message = f"Rate limit excedido: {current_count}/{limit} em {window}s"
        super().__init__(message, {"limit": limit, "window": window, "current_count": current_count})


class CacheError(DataGovernanceException):
    """Erro de cache"""
    
    def __init__(self, operation: str, key: str, error_details: str):
        self.operation = operation
        self.key = key
        self.error_details = error_details
        message = f"Erro de cache na operação '{operation}' para chave '{key}': {error_details}"
        super().__init__(message, {"operation": operation, "key": key})


class EncryptionError(DataGovernanceException):
    """Erro de criptografia"""
    
    def __init__(self, operation: str, message: str):
        self.operation = operation
        full_message = f"Erro de criptografia na operação '{operation}': {message}"
        super().__init__(full_message, {"operation": operation})


# Mapeamento de exceções para códigos HTTP
EXCEPTION_STATUS_MAP = {
    ValidationError: status.HTTP_400_BAD_REQUEST,
    AuthenticationError: status.HTTP_401_UNAUTHORIZED,
    AuthorizationError: status.HTTP_403_FORBIDDEN,
    EntityNotFoundError: status.HTTP_404_NOT_FOUND,
    EntityAlreadyExistsError: status.HTTP_409_CONFLICT,
    BusinessRuleViolationError: status.HTTP_422_UNPROCESSABLE_ENTITY,
    DataQualityError: status.HTTP_422_UNPROCESSABLE_ENTITY,
    ComplianceError: status.HTTP_422_UNPROCESSABLE_ENTITY,
    RateLimitError: status.HTTP_429_TOO_MANY_REQUESTS,
    IntegrationError: status.HTTP_502_BAD_GATEWAY,
    ConfigurationError: status.HTTP_500_INTERNAL_SERVER_ERROR,
    PerformanceError: status.HTTP_503_SERVICE_UNAVAILABLE,
    SecurityError: status.HTTP_403_FORBIDDEN,
    CacheError: status.HTTP_500_INTERNAL_SERVER_ERROR,
    EncryptionError: status.HTTP_500_INTERNAL_SERVER_ERROR,
}


def create_http_exception(exception: DataGovernanceException) -> HTTPException:
    """
    Converte exceção customizada em HTTPException
    
    Args:
        exception: Exceção customizada
        
    Returns:
        HTTPException correspondente
    """
    status_code = EXCEPTION_STATUS_MAP.get(type(exception), status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    detail = {
        "error": type(exception).__name__,
        "message": exception.message,
        "details": exception.details
    }
    
    return HTTPException(status_code=status_code, detail=detail)


def handle_database_error(error: Exception) -> DataGovernanceException:
    """
    Converte erros de banco de dados em exceções customizadas
    
    Args:
        error: Erro original do banco
        
    Returns:
        Exceção customizada correspondente
    """
    error_str = str(error).lower()
    
    if "unique constraint" in error_str or "duplicate key" in error_str:
        return EntityAlreadyExistsError("Entity", "duplicate_key")
    elif "foreign key constraint" in error_str:
        return BusinessRuleViolationError("foreign_key", "Referência inválida")
    elif "not null constraint" in error_str:
        return ValidationError("Campo obrigatório não pode ser nulo")
    elif "check constraint" in error_str:
        return ValidationError("Valor não atende às restrições definidas")
    else:
        return DataGovernanceException(f"Erro de banco de dados: {str(error)}")


def handle_external_api_error(system: str, status_code: int, response_text: str) -> DataGovernanceException:
    """
    Converte erros de APIs externas em exceções customizadas
    
    Args:
        system: Nome do sistema externo
        status_code: Código de status HTTP
        response_text: Texto da resposta
        
    Returns:
        Exceção customizada correspondente
    """
    if status_code == 401:
        return AuthenticationError(f"Falha na autenticação com {system}")
    elif status_code == 403:
        return AuthorizationError(f"Acesso negado ao {system}")
    elif status_code == 404:
        return EntityNotFoundError(system, "resource_not_found")
    elif status_code == 429:
        return RateLimitError(100, 60, 101)  # Valores padrão
    elif status_code >= 500:
        return IntegrationError(system, "api_call", f"Erro do servidor: {response_text}")
    else:
        return IntegrationError(system, "api_call", f"Erro HTTP {status_code}: {response_text}")


class ExceptionContext:
    """Context manager para captura e tratamento de exceções"""
    
    def __init__(self, operation: str, entity_type: Optional[str] = None):
        self.operation = operation
        self.entity_type = entity_type
        
    def __enter__(self):
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            return False
            
        # Log da exceção
        print(f"Exceção capturada na operação '{self.operation}': {exc_type.__name__}: {exc_val}")
        
        # Não suprimir a exceção
        return False


def validate_and_raise(condition: bool, exception: DataGovernanceException):
    """
    Valida condição e levanta exceção se falsa
    
    Args:
        condition: Condição a ser validada
        exception: Exceção a ser levantada se condição for falsa
        
    Raises:
        DataGovernanceException: Se condição for falsa
    """
    if not condition:
        raise exception

