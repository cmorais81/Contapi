"""
Sistema de Auditoria para Data Governance API
Autor: Carlos Morais

Sistema completo de auditoria com rastreamento de ações,
compliance e trilhas de auditoria detalhadas.
"""

import json
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Union
from enum import Enum
from dataclasses import dataclass, asdict
from functools import wraps
import uuid

from .exceptions import DataGovernanceException
from .monitoring import metrics_collector


class AuditEventType(Enum):
    """Tipos de eventos de auditoria"""
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    EXECUTE = "execute"
    LOGIN = "login"
    LOGOUT = "logout"
    ACCESS_DENIED = "access_denied"
    PERMISSION_CHANGE = "permission_change"
    DATA_EXPORT = "data_export"
    POLICY_VIOLATION = "policy_violation"
    QUALITY_CHECK = "quality_check"
    LINEAGE_UPDATE = "lineage_update"
    CONTRACT_APPROVAL = "contract_approval"
    ALERT_TRIGGERED = "alert_triggered"


class AuditSeverity(Enum):
    """Severidade dos eventos de auditoria"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class AuditEvent:
    """Evento de auditoria"""
    id: str
    timestamp: datetime
    event_type: AuditEventType
    severity: AuditSeverity
    user_id: Optional[str]
    session_id: Optional[str]
    ip_address: Optional[str]
    user_agent: Optional[str]
    resource_type: str
    resource_id: Optional[str]
    action: str
    details: Dict[str, Any]
    before_state: Optional[Dict[str, Any]]
    after_state: Optional[Dict[str, Any]]
    success: bool
    error_message: Optional[str]
    compliance_frameworks: List[str]
    tags: Dict[str, str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte evento para dicionário"""
        data = asdict(self)
        data['timestamp'] = self.timestamp.isoformat()
        data['event_type'] = self.event_type.value
        data['severity'] = self.severity.value
        return data


class AuditLogger:
    """Logger de auditoria"""
    
    def __init__(self):
        self.events = []  # Em produção, seria persistido em banco
        self.retention_days = 2555  # 7 anos para compliance
        self.max_events_memory = 10000
    
    def log_event(self, event: AuditEvent):
        """
        Registra evento de auditoria
        
        Args:
            event: Evento para registrar
        """
        # Adicionar à lista em memória
        self.events.append(event)
        
        # Limitar eventos em memória
        if len(self.events) > self.max_events_memory:
            self.events = self.events[-self.max_events_memory:]
        
        # Registrar métricas
        metrics_collector.increment_counter(
            "audit.events",
            tags={
                "event_type": event.event_type.value,
                "severity": event.severity.value,
                "success": str(event.success)
            }
        )
        
        # Em produção, persistir em banco de dados
        self._persist_event(event)
    
    def _persist_event(self, event: AuditEvent):
        """
        Persiste evento (implementação simulada)
        
        Args:
            event: Evento para persistir
        """
        # Simular persistência
        print(f"AUDIT: {event.event_type.value} - {event.action} by {event.user_id}")
    
    def get_events(self, 
                   start_date: Optional[datetime] = None,
                   end_date: Optional[datetime] = None,
                   event_types: Optional[List[AuditEventType]] = None,
                   user_id: Optional[str] = None,
                   resource_type: Optional[str] = None,
                   severity: Optional[AuditSeverity] = None,
                   limit: int = 100) -> List[AuditEvent]:
        """
        Obtém eventos de auditoria com filtros
        
        Args:
            start_date: Data inicial
            end_date: Data final
            event_types: Tipos de evento para filtrar
            user_id: ID do usuário
            resource_type: Tipo de recurso
            severity: Severidade
            limit: Limite de eventos
            
        Returns:
            Lista de eventos filtrados
        """
        filtered_events = self.events
        
        # Aplicar filtros
        if start_date:
            filtered_events = [e for e in filtered_events if e.timestamp >= start_date]
        
        if end_date:
            filtered_events = [e for e in filtered_events if e.timestamp <= end_date]
        
        if event_types:
            filtered_events = [e for e in filtered_events if e.event_type in event_types]
        
        if user_id:
            filtered_events = [e for e in filtered_events if e.user_id == user_id]
        
        if resource_type:
            filtered_events = [e for e in filtered_events if e.resource_type == resource_type]
        
        if severity:
            filtered_events = [e for e in filtered_events if e.severity == severity]
        
        # Ordenar por timestamp (mais recente primeiro)
        filtered_events.sort(key=lambda x: x.timestamp, reverse=True)
        
        return filtered_events[:limit]
    
    def get_audit_trail(self, resource_type: str, resource_id: str) -> List[AuditEvent]:
        """
        Obtém trilha de auditoria para um recurso específico
        
        Args:
            resource_type: Tipo do recurso
            resource_id: ID do recurso
            
        Returns:
            Trilha de auditoria ordenada cronologicamente
        """
        trail = [
            event for event in self.events
            if event.resource_type == resource_type and event.resource_id == resource_id
        ]
        
        # Ordenar cronologicamente
        trail.sort(key=lambda x: x.timestamp)
        
        return trail
    
    def get_user_activity(self, user_id: str, days: int = 30) -> Dict[str, Any]:
        """
        Obtém atividade de um usuário
        
        Args:
            user_id: ID do usuário
            days: Período em dias
            
        Returns:
            Resumo da atividade do usuário
        """
        start_date = datetime.utcnow() - timedelta(days=days)
        user_events = self.get_events(
            start_date=start_date,
            user_id=user_id,
            limit=1000
        )
        
        # Estatísticas
        total_events = len(user_events)
        successful_events = len([e for e in user_events if e.success])
        failed_events = total_events - successful_events
        
        # Eventos por tipo
        events_by_type = {}
        for event in user_events:
            event_type = event.event_type.value
            events_by_type[event_type] = events_by_type.get(event_type, 0) + 1
        
        # Recursos acessados
        resources_accessed = set()
        for event in user_events:
            if event.resource_id:
                resources_accessed.add(f"{event.resource_type}:{event.resource_id}")
        
        return {
            "user_id": user_id,
            "period_days": days,
            "total_events": total_events,
            "successful_events": successful_events,
            "failed_events": failed_events,
            "success_rate": (successful_events / total_events * 100) if total_events > 0 else 0,
            "events_by_type": events_by_type,
            "unique_resources_accessed": len(resources_accessed),
            "most_recent_activity": user_events[0].timestamp.isoformat() if user_events else None,
            "risk_score": self._calculate_risk_score(user_events)
        }
    
    def _calculate_risk_score(self, events: List[AuditEvent]) -> float:
        """
        Calcula score de risco baseado nos eventos
        
        Args:
            events: Lista de eventos
            
        Returns:
            Score de risco (0-100)
        """
        if not events:
            return 0.0
        
        risk_score = 0.0
        
        # Fatores de risco
        failed_events = len([e for e in events if not e.success])
        critical_events = len([e for e in events if e.severity == AuditSeverity.CRITICAL])
        access_denied_events = len([e for e in events if e.event_type == AuditEventType.ACCESS_DENIED])
        
        # Calcular score
        if len(events) > 0:
            failure_rate = failed_events / len(events)
            risk_score += failure_rate * 30
            
            critical_rate = critical_events / len(events)
            risk_score += critical_rate * 40
            
            access_denied_rate = access_denied_events / len(events)
            risk_score += access_denied_rate * 30
        
        return min(risk_score, 100.0)
    
    def generate_compliance_report(self, 
                                 framework: str,
                                 start_date: datetime,
                                 end_date: datetime) -> Dict[str, Any]:
        """
        Gera relatório de compliance
        
        Args:
            framework: Framework de compliance (GDPR, LGPD, SOX, etc.)
            start_date: Data inicial
            end_date: Data final
            
        Returns:
            Relatório de compliance
        """
        # Filtrar eventos relevantes para o framework
        relevant_events = [
            event for event in self.events
            if framework in event.compliance_frameworks
            and start_date <= event.timestamp <= end_date
        ]
        
        # Análise de compliance
        total_events = len(relevant_events)
        violations = [e for e in relevant_events if e.event_type == AuditEventType.POLICY_VIOLATION]
        access_events = [e for e in relevant_events if e.event_type == AuditEventType.READ]
        data_exports = [e for e in relevant_events if e.event_type == AuditEventType.DATA_EXPORT]
        
        # Usuários únicos
        unique_users = set(e.user_id for e in relevant_events if e.user_id)
        
        return {
            "framework": framework,
            "period": {
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat()
            },
            "summary": {
                "total_events": total_events,
                "policy_violations": len(violations),
                "data_access_events": len(access_events),
                "data_exports": len(data_exports),
                "unique_users": len(unique_users)
            },
            "compliance_score": self._calculate_compliance_score(relevant_events),
            "violations": [v.to_dict() for v in violations[:10]],  # Top 10 violações
            "recommendations": self._generate_compliance_recommendations(relevant_events)
        }
    
    def _calculate_compliance_score(self, events: List[AuditEvent]) -> float:
        """
        Calcula score de compliance
        
        Args:
            events: Lista de eventos
            
        Returns:
            Score de compliance (0-100)
        """
        if not events:
            return 100.0
        
        violations = len([e for e in events if e.event_type == AuditEventType.POLICY_VIOLATION])
        failed_events = len([e for e in events if not e.success])
        
        # Score baseado em violações e falhas
        violation_penalty = (violations / len(events)) * 50
        failure_penalty = (failed_events / len(events)) * 30
        
        score = 100.0 - violation_penalty - failure_penalty
        return max(score, 0.0)
    
    def _generate_compliance_recommendations(self, events: List[AuditEvent]) -> List[str]:
        """
        Gera recomendações de compliance
        
        Args:
            events: Lista de eventos
            
        Returns:
            Lista de recomendações
        """
        recommendations = []
        
        violations = [e for e in events if e.event_type == AuditEventType.POLICY_VIOLATION]
        if violations:
            recommendations.append("Revisar e reforçar políticas de acesso a dados")
        
        failed_logins = [e for e in events if e.event_type == AuditEventType.LOGIN and not e.success]
        if len(failed_logins) > 10:
            recommendations.append("Implementar controles adicionais de autenticação")
        
        data_exports = [e for e in events if e.event_type == AuditEventType.DATA_EXPORT]
        if len(data_exports) > 50:
            recommendations.append("Revisar políticas de exportação de dados")
        
        return recommendations


class AuditDecorator:
    """Decorator para auditoria automática"""
    
    def __init__(self, audit_logger: AuditLogger):
        self.audit_logger = audit_logger
    
    def audit(self, 
              event_type: AuditEventType,
              resource_type: str,
              action: str,
              severity: AuditSeverity = AuditSeverity.MEDIUM,
              compliance_frameworks: List[str] = None):
        """
        Decorator para auditoria automática de funções
        
        Args:
            event_type: Tipo do evento
            resource_type: Tipo do recurso
            action: Ação realizada
            severity: Severidade do evento
            compliance_frameworks: Frameworks de compliance aplicáveis
        """
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Extrair contexto (simulado)
                user_id = kwargs.get('user_id') or 'system'
                resource_id = kwargs.get('resource_id') or kwargs.get('id')
                
                # Estado antes da operação
                before_state = None
                if event_type in [AuditEventType.UPDATE, AuditEventType.DELETE]:
                    before_state = {"note": "Estado anterior seria capturado aqui"}
                
                success = True
                error_message = None
                after_state = None
                
                try:
                    result = func(*args, **kwargs)
                    
                    # Estado após a operação
                    if event_type in [AuditEventType.CREATE, AuditEventType.UPDATE]:
                        after_state = {"note": "Estado posterior seria capturado aqui"}
                    
                    return result
                    
                except Exception as e:
                    success = False
                    error_message = str(e)
                    raise
                    
                finally:
                    # Registrar evento de auditoria
                    event = AuditEvent(
                        id=str(uuid.uuid4()),
                        timestamp=datetime.utcnow(),
                        event_type=event_type,
                        severity=severity,
                        user_id=user_id,
                        session_id=None,  # Seria extraído do contexto
                        ip_address=None,  # Seria extraído do request
                        user_agent=None,  # Seria extraído do request
                        resource_type=resource_type,
                        resource_id=resource_id,
                        action=action,
                        details={
                            "function": func.__name__,
                            "args": str(args)[:200],  # Limitar tamanho
                            "kwargs": str(kwargs)[:200]
                        },
                        before_state=before_state,
                        after_state=after_state,
                        success=success,
                        error_message=error_message,
                        compliance_frameworks=compliance_frameworks or [],
                        tags={}
                    )
                    
                    self.audit_logger.log_event(event)
            
            return wrapper
        return decorator


class ComplianceMonitor:
    """Monitor de compliance em tempo real"""
    
    def __init__(self, audit_logger: AuditLogger):
        self.audit_logger = audit_logger
        self.compliance_rules = []
    
    def add_compliance_rule(self, 
                          name: str,
                          framework: str,
                          condition: callable,
                          severity: AuditSeverity = AuditSeverity.HIGH):
        """
        Adiciona regra de compliance
        
        Args:
            name: Nome da regra
            framework: Framework de compliance
            condition: Função que verifica violação
            severity: Severidade da violação
        """
        rule = {
            "name": name,
            "framework": framework,
            "condition": condition,
            "severity": severity
        }
        self.compliance_rules.append(rule)
    
    def check_compliance(self, event: AuditEvent) -> List[Dict[str, Any]]:
        """
        Verifica compliance de um evento
        
        Args:
            event: Evento para verificar
            
        Returns:
            Lista de violações encontradas
        """
        violations = []
        
        for rule in self.compliance_rules:
            try:
                if rule["condition"](event):
                    violation = {
                        "rule_name": rule["name"],
                        "framework": rule["framework"],
                        "severity": rule["severity"].value,
                        "event_id": event.id,
                        "timestamp": event.timestamp.isoformat(),
                        "description": f"Violação da regra '{rule['name']}' detectada"
                    }
                    violations.append(violation)
                    
                    # Registrar violação como evento de auditoria
                    violation_event = AuditEvent(
                        id=str(uuid.uuid4()),
                        timestamp=datetime.utcnow(),
                        event_type=AuditEventType.POLICY_VIOLATION,
                        severity=rule["severity"],
                        user_id=event.user_id,
                        session_id=event.session_id,
                        ip_address=event.ip_address,
                        user_agent=event.user_agent,
                        resource_type="compliance_rule",
                        resource_id=rule["name"],
                        action="violation_detected",
                        details={
                            "original_event_id": event.id,
                            "rule_name": rule["name"],
                            "framework": rule["framework"]
                        },
                        before_state=None,
                        after_state=None,
                        success=True,
                        error_message=None,
                        compliance_frameworks=[rule["framework"]],
                        tags={"violation": "true"}
                    )
                    
                    self.audit_logger.log_event(violation_event)
                    
            except Exception as e:
                print(f"Erro ao verificar regra de compliance '{rule['name']}': {e}")
        
        return violations


# Instâncias globais
audit_logger = AuditLogger()
audit_decorator = AuditDecorator(audit_logger)
compliance_monitor = ComplianceMonitor(audit_logger)


# Configurar regras de compliance padrão
def setup_default_compliance_rules():
    """Configura regras de compliance padrão"""
    
    # LGPD - Acesso a dados pessoais
    compliance_monitor.add_compliance_rule(
        name="lgpd_personal_data_access",
        framework="LGPD",
        condition=lambda event: (
            event.event_type == AuditEventType.READ and
            "pii" in event.details.get("data_classification", "").lower()
        ),
        severity=AuditSeverity.HIGH
    )
    
    # GDPR - Exportação de dados
    compliance_monitor.add_compliance_rule(
        name="gdpr_data_export_tracking",
        framework="GDPR",
        condition=lambda event: (
            event.event_type == AuditEventType.DATA_EXPORT and
            not event.details.get("consent_verified", False)
        ),
        severity=AuditSeverity.CRITICAL
    )
    
    # SOX - Alterações em dados financeiros
    compliance_monitor.add_compliance_rule(
        name="sox_financial_data_changes",
        framework="SOX",
        condition=lambda event: (
            event.event_type in [AuditEventType.UPDATE, AuditEventType.DELETE] and
            "financial" in event.resource_type.lower()
        ),
        severity=AuditSeverity.HIGH
    )


# Configurar regras padrão
setup_default_compliance_rules()


# Funções de conveniência
def audit_log(event_type: AuditEventType, resource_type: str, action: str, **kwargs):
    """
    Função de conveniência para log de auditoria
    
    Args:
        event_type: Tipo do evento
        resource_type: Tipo do recurso
        action: Ação realizada
        **kwargs: Argumentos adicionais
    """
    return audit_decorator.audit(event_type, resource_type, action, **kwargs)


def create_audit_entry(user_id: str, action: str, resource_type: str, 
                      resource_id: str = None, details: Dict[str, Any] = None):
    """
    Cria entrada de auditoria manual
    
    Args:
        user_id: ID do usuário
        action: Ação realizada
        resource_type: Tipo do recurso
        resource_id: ID do recurso
        details: Detalhes adicionais
    """
    event = AuditEvent(
        id=str(uuid.uuid4()),
        timestamp=datetime.utcnow(),
        event_type=AuditEventType.READ,  # Padrão
        severity=AuditSeverity.MEDIUM,
        user_id=user_id,
        session_id=None,
        ip_address=None,
        user_agent=None,
        resource_type=resource_type,
        resource_id=resource_id,
        action=action,
        details=details or {},
        before_state=None,
        after_state=None,
        success=True,
        error_message=None,
        compliance_frameworks=[],
        tags={}
    )
    
    audit_logger.log_event(event)


def get_audit_trail(resource_type: str, resource_id: str) -> List[Dict[str, Any]]:
    """
    Obtém trilha de auditoria para um recurso
    
    Args:
        resource_type: Tipo do recurso
        resource_id: ID do recurso
        
    Returns:
        Trilha de auditoria
    """
    events = audit_logger.get_audit_trail(resource_type, resource_id)
    return [event.to_dict() for event in events]

