"""
Sistema de Privacidade e Proteção de Dados
Autor: Carlos Morais

Sistema completo para proteção de dados pessoais,
mascaramento, anonimização e compliance com LGPD/GDPR.
"""

import re
import hashlib
import secrets
import json
from typing import Any, Dict, List, Optional, Union, Callable
from enum import Enum
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
import uuid

from .exceptions import DataGovernanceException
from .audit import audit_logger, AuditEventType, AuditSeverity


class DataClassification(Enum):
    """Classificação de dados"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"
    PII = "pii"
    SENSITIVE_PII = "sensitive_pii"


class MaskingType(Enum):
    """Tipos de mascaramento"""
    FULL_MASK = "full_mask"
    PARTIAL_MASK = "partial_mask"
    HASH = "hash"
    TOKENIZATION = "tokenization"
    ENCRYPTION = "encryption"
    REDACTION = "redaction"
    SUBSTITUTION = "substitution"
    SHUFFLING = "shuffling"
    DATE_SHIFTING = "date_shifting"
    NULL_OUT = "null_out"


class PrivacyRegulation(Enum):
    """Regulamentações de privacidade"""
    LGPD = "lgpd"
    GDPR = "gdpr"
    CCPA = "ccpa"
    PIPEDA = "pipeda"
    SOX = "sox"
    HIPAA = "hipaa"


@dataclass
class DataElement:
    """Elemento de dados com classificação"""
    field_name: str
    data_type: str
    classification: DataClassification
    is_pii: bool
    is_sensitive: bool
    regulations: List[PrivacyRegulation]
    masking_rules: List[Dict[str, Any]]
    retention_days: Optional[int]
    purpose: str
    legal_basis: Optional[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        data = asdict(self)
        data['classification'] = self.classification.value
        data['regulations'] = [r.value for r in self.regulations]
        return data


class DataMasker:
    """Mascarador de dados"""
    
    def __init__(self):
        self.masking_functions = {
            MaskingType.FULL_MASK: self._full_mask,
            MaskingType.PARTIAL_MASK: self._partial_mask,
            MaskingType.HASH: self._hash_value,
            MaskingType.TOKENIZATION: self._tokenize,
            MaskingType.ENCRYPTION: self._encrypt,
            MaskingType.REDACTION: self._redact,
            MaskingType.SUBSTITUTION: self._substitute,
            MaskingType.SHUFFLING: self._shuffle,
            MaskingType.DATE_SHIFTING: self._shift_date,
            MaskingType.NULL_OUT: self._null_out
        }
        self.token_mapping = {}  # Para tokenização consistente
        self.encryption_key = secrets.token_bytes(32)  # Chave de 256 bits
    
    def mask_value(self, 
                   value: Any, 
                   masking_type: MaskingType,
                   **kwargs) -> Any:
        """
        Mascara valor usando tipo especificado
        
        Args:
            value: Valor para mascarar
            masking_type: Tipo de mascaramento
            **kwargs: Parâmetros adicionais
            
        Returns:
            Valor mascarado
        """
        if value is None:
            return None
        
        masking_func = self.masking_functions.get(masking_type)
        if not masking_func:
            raise DataGovernanceException(f"Tipo de mascaramento não suportado: {masking_type}")
        
        return masking_func(value, **kwargs)
    
    def _full_mask(self, value: Any, mask_char: str = "*", **kwargs) -> str:
        """Mascaramento completo"""
        return mask_char * len(str(value))
    
    def _partial_mask(self, 
                     value: Any, 
                     mask_char: str = "*",
                     preserve_start: int = 2,
                     preserve_end: int = 2,
                     **kwargs) -> str:
        """Mascaramento parcial"""
        str_value = str(value)
        if len(str_value) <= preserve_start + preserve_end:
            return self._full_mask(value, mask_char)
        
        start = str_value[:preserve_start]
        end = str_value[-preserve_end:] if preserve_end > 0 else ""
        middle_length = len(str_value) - preserve_start - preserve_end
        middle = mask_char * middle_length
        
        return start + middle + end
    
    def _hash_value(self, value: Any, algorithm: str = "sha256", **kwargs) -> str:
        """Hash do valor"""
        str_value = str(value)
        if algorithm == "sha256":
            return hashlib.sha256(str_value.encode()).hexdigest()
        elif algorithm == "md5":
            return hashlib.md5(str_value.encode()).hexdigest()
        else:
            raise DataGovernanceException(f"Algoritmo de hash não suportado: {algorithm}")
    
    def _tokenize(self, value: Any, **kwargs) -> str:
        """Tokenização consistente"""
        str_value = str(value)
        
        # Verificar se já existe token para este valor
        if str_value in self.token_mapping:
            return self.token_mapping[str_value]
        
        # Gerar novo token
        token = f"TOKEN_{uuid.uuid4().hex[:8].upper()}"
        self.token_mapping[str_value] = token
        
        return token
    
    def _encrypt(self, value: Any, **kwargs) -> str:
        """Criptografia simples (para demonstração)"""
        # Em produção, usar biblioteca de criptografia robusta
        str_value = str(value)
        encrypted = hashlib.pbkdf2_hmac('sha256', 
                                       str_value.encode(), 
                                       self.encryption_key, 
                                       100000)
        return encrypted.hex()
    
    def _redact(self, value: Any, replacement: str = "[REDACTED]", **kwargs) -> str:
        """Redação completa"""
        return replacement
    
    def _substitute(self, 
                   value: Any, 
                   substitution_map: Dict[str, str] = None,
                   **kwargs) -> str:
        """Substituição por mapeamento"""
        str_value = str(value)
        if substitution_map and str_value in substitution_map:
            return substitution_map[str_value]
        
        # Substituição padrão por tipo
        if isinstance(value, str):
            if re.match(r'^[\w\.-]+@[\w\.-]+\.\w+$', str_value):  # Email
                return "user@example.com"
            elif re.match(r'^\d{11}$', str_value):  # CPF
                return "12345678901"
            elif re.match(r'^\(\d{2}\)\s\d{4,5}-\d{4}$', str_value):  # Telefone
                return "(11) 99999-9999"
        
        return f"SUBSTITUTE_{type(value).__name__.upper()}"
    
    def _shuffle(self, value: Any, **kwargs) -> str:
        """Embaralhamento de caracteres"""
        str_value = str(value)
        char_list = list(str_value)
        
        # Usar seed para embaralhamento consistente
        import random
        random.seed(hash(str_value))
        random.shuffle(char_list)
        
        return ''.join(char_list)
    
    def _shift_date(self, 
                   value: Any, 
                   shift_days: int = None,
                   **kwargs) -> str:
        """Deslocamento de data"""
        if shift_days is None:
            # Deslocamento aleatório mas consistente
            shift_days = hash(str(value)) % 365 - 182  # -182 a +182 dias
        
        try:
            if isinstance(value, datetime):
                shifted = value + timedelta(days=shift_days)
                return shifted.isoformat()
            elif isinstance(value, str):
                # Tentar parsear como data
                dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
                shifted = dt + timedelta(days=shift_days)
                return shifted.isoformat()
        except:
            pass
        
        return str(value)  # Retornar original se não for data
    
    def _null_out(self, value: Any, **kwargs) -> None:
        """Anular valor"""
        return None


class PIIDetector:
    """Detector de informações pessoais identificáveis"""
    
    def __init__(self):
        self.patterns = {
            'cpf': r'\d{3}\.?\d{3}\.?\d{3}-?\d{2}',
            'cnpj': r'\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}',
            'email': r'[\w\.-]+@[\w\.-]+\.\w+',
            'phone': r'(\(?\d{2}\)?\s?)?\d{4,5}-?\d{4}',
            'credit_card': r'\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}',
            'rg': r'\d{1,2}\.?\d{3}\.?\d{3}-?[\dX]',
            'cep': r'\d{5}-?\d{3}',
            'ip_address': r'\b(?:\d{1,3}\.){3}\d{1,3}\b',
            'passport': r'[A-Z]{2}\d{6,7}',
            'bank_account': r'\d{4,6}-?\d{1,2}'
        }
    
    def detect_pii(self, text: str) -> Dict[str, List[str]]:
        """
        Detecta PII em texto
        
        Args:
            text: Texto para analisar
            
        Returns:
            Dicionário com tipos de PII encontrados
        """
        detected = {}
        
        for pii_type, pattern in self.patterns.items():
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                detected[pii_type] = matches
        
        return detected
    
    def classify_field(self, field_name: str, sample_values: List[str]) -> DataClassification:
        """
        Classifica campo baseado no nome e valores de exemplo
        
        Args:
            field_name: Nome do campo
            sample_values: Valores de exemplo
            
        Returns:
            Classificação do campo
        """
        field_lower = field_name.lower()
        
        # Verificar nome do campo
        sensitive_keywords = ['password', 'senha', 'secret', 'token', 'key']
        pii_keywords = ['cpf', 'cnpj', 'email', 'phone', 'telefone', 'rg', 'passport']
        
        if any(keyword in field_lower for keyword in sensitive_keywords):
            return DataClassification.SENSITIVE_PII
        
        if any(keyword in field_lower for keyword in pii_keywords):
            return DataClassification.PII
        
        # Verificar valores de exemplo
        pii_detected = False
        for value in sample_values[:10]:  # Analisar até 10 valores
            if self.detect_pii(str(value)):
                pii_detected = True
                break
        
        if pii_detected:
            return DataClassification.PII
        
        # Classificação padrão baseada no nome
        if any(keyword in field_lower for keyword in ['internal', 'private']):
            return DataClassification.INTERNAL
        elif any(keyword in field_lower for keyword in ['confidential', 'restricted']):
            return DataClassification.CONFIDENTIAL
        
        return DataClassification.PUBLIC


class PrivacyPolicyEngine:
    """Engine de políticas de privacidade"""
    
    def __init__(self):
        self.policies = {}
        self.masker = DataMasker()
        self.pii_detector = PIIDetector()
    
    def register_policy(self, 
                       policy_id: str,
                       name: str,
                       regulation: PrivacyRegulation,
                       data_elements: List[DataElement],
                       retention_policy: Dict[str, Any],
                       access_controls: Dict[str, Any]):
        """
        Registra política de privacidade
        
        Args:
            policy_id: ID da política
            name: Nome da política
            regulation: Regulamentação aplicável
            data_elements: Elementos de dados cobertos
            retention_policy: Política de retenção
            access_controls: Controles de acesso
        """
        policy = {
            "id": policy_id,
            "name": name,
            "regulation": regulation,
            "data_elements": data_elements,
            "retention_policy": retention_policy,
            "access_controls": access_controls,
            "created_at": datetime.utcnow(),
            "active": True
        }
        
        self.policies[policy_id] = policy
        
        # Registrar evento de auditoria
        audit_logger.log_event({
            "event_type": AuditEventType.CREATE,
            "resource_type": "privacy_policy",
            "resource_id": policy_id,
            "action": "policy_registered",
            "details": {"policy_name": name, "regulation": regulation.value},
            "compliance_frameworks": [regulation.value]
        })
    
    def apply_masking(self, 
                     data: Dict[str, Any],
                     context: Dict[str, Any],
                     user_permissions: List[str]) -> Dict[str, Any]:
        """
        Aplica mascaramento baseado em políticas
        
        Args:
            data: Dados para mascarar
            context: Contexto da operação
            user_permissions: Permissões do usuário
            
        Returns:
            Dados mascarados
        """
        masked_data = data.copy()
        
        for field_name, value in data.items():
            # Encontrar elemento de dados correspondente
            data_element = self._find_data_element(field_name)
            
            if data_element and self._should_mask(data_element, context, user_permissions):
                # Aplicar regras de mascaramento
                for rule in data_element.masking_rules:
                    masking_type = MaskingType(rule["type"])
                    masked_value = self.masker.mask_value(
                        value, 
                        masking_type, 
                        **rule.get("parameters", {})
                    )
                    masked_data[field_name] = masked_value
                    break  # Aplicar apenas primeira regra aplicável
        
        return masked_data
    
    def _find_data_element(self, field_name: str) -> Optional[DataElement]:
        """Encontra elemento de dados por nome do campo"""
        for policy in self.policies.values():
            for element in policy["data_elements"]:
                if element.field_name == field_name:
                    return element
        return None
    
    def _should_mask(self, 
                    data_element: DataElement,
                    context: Dict[str, Any],
                    user_permissions: List[str]) -> bool:
        """
        Determina se campo deve ser mascarado
        
        Args:
            data_element: Elemento de dados
            context: Contexto da operação
            user_permissions: Permissões do usuário
            
        Returns:
            True se deve mascarar
        """
        # Verificar se usuário tem permissão para ver dados não mascarados
        required_permission = f"view_unmasked_{data_element.classification.value}"
        if required_permission in user_permissions:
            return False
        
        # Verificar contexto da operação
        operation_type = context.get("operation_type", "read")
        if operation_type == "export" and data_element.is_pii:
            return True
        
        # Verificar classificação
        if data_element.classification in [DataClassification.PII, DataClassification.SENSITIVE_PII]:
            return True
        
        return False
    
    def check_retention_compliance(self, 
                                 data_records: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Verifica compliance de retenção de dados
        
        Args:
            data_records: Registros de dados para verificar
            
        Returns:
            Resultado da verificação
        """
        compliance_result = {
            "total_records": len(data_records),
            "compliant_records": 0,
            "expired_records": 0,
            "expiring_soon": 0,
            "violations": []
        }
        
        current_date = datetime.utcnow()
        
        for record in data_records:
            created_at = record.get("created_at")
            if not created_at:
                continue
            
            if isinstance(created_at, str):
                created_at = datetime.fromisoformat(created_at.replace('Z', '+00:00'))
            
            # Verificar cada campo do registro
            for field_name, value in record.items():
                data_element = self._find_data_element(field_name)
                
                if data_element and data_element.retention_days:
                    retention_date = created_at + timedelta(days=data_element.retention_days)
                    days_until_expiry = (retention_date - current_date).days
                    
                    if days_until_expiry < 0:
                        # Dados expirados
                        compliance_result["expired_records"] += 1
                        compliance_result["violations"].append({
                            "record_id": record.get("id", "unknown"),
                            "field": field_name,
                            "violation_type": "retention_expired",
                            "expired_days": abs(days_until_expiry),
                            "retention_policy": data_element.retention_days
                        })
                    elif days_until_expiry <= 30:
                        # Expirando em breve
                        compliance_result["expiring_soon"] += 1
                    else:
                        # Compliant
                        compliance_result["compliant_records"] += 1
        
        return compliance_result
    
    def generate_privacy_report(self, 
                              regulation: PrivacyRegulation,
                              start_date: datetime,
                              end_date: datetime) -> Dict[str, Any]:
        """
        Gera relatório de privacidade
        
        Args:
            regulation: Regulamentação para relatório
            start_date: Data inicial
            end_date: Data final
            
        Returns:
            Relatório de privacidade
        """
        # Filtrar políticas por regulamentação
        relevant_policies = [
            policy for policy in self.policies.values()
            if policy["regulation"] == regulation
        ]
        
        report = {
            "regulation": regulation.value,
            "period": {
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat()
            },
            "policies": {
                "total_policies": len(relevant_policies),
                "active_policies": len([p for p in relevant_policies if p["active"]]),
                "policies_detail": [
                    {
                        "id": p["id"],
                        "name": p["name"],
                        "data_elements_count": len(p["data_elements"]),
                        "pii_elements": len([e for e in p["data_elements"] if e.is_pii])
                    }
                    for p in relevant_policies
                ]
            },
            "data_protection": {
                "total_pii_fields": sum(len([e for e in p["data_elements"] if e.is_pii]) for p in relevant_policies),
                "masking_rules_applied": sum(len(e.masking_rules) for p in relevant_policies for e in p["data_elements"]),
                "retention_policies": len([p for p in relevant_policies if p["retention_policy"]])
            },
            "compliance_score": self._calculate_privacy_compliance_score(relevant_policies),
            "recommendations": self._generate_privacy_recommendations(relevant_policies)
        }
        
        return report
    
    def _calculate_privacy_compliance_score(self, policies: List[Dict[str, Any]]) -> float:
        """Calcula score de compliance de privacidade"""
        if not policies:
            return 0.0
        
        score = 100.0
        
        # Verificar se todas as políticas estão ativas
        inactive_policies = len([p for p in policies if not p["active"]])
        score -= (inactive_policies / len(policies)) * 20
        
        # Verificar cobertura de PII
        total_elements = sum(len(p["data_elements"]) for p in policies)
        pii_elements = sum(len([e for e in p["data_elements"] if e.is_pii]) for p in policies)
        
        if total_elements > 0:
            pii_coverage = pii_elements / total_elements
            if pii_coverage < 0.5:  # Menos de 50% de cobertura PII
                score -= 30
        
        # Verificar políticas de retenção
        policies_with_retention = len([p for p in policies if p["retention_policy"]])
        if policies_with_retention / len(policies) < 0.8:  # Menos de 80% com retenção
            score -= 25
        
        return max(score, 0.0)
    
    def _generate_privacy_recommendations(self, policies: List[Dict[str, Any]]) -> List[str]:
        """Gera recomendações de privacidade"""
        recommendations = []
        
        # Verificar políticas inativas
        inactive_policies = [p for p in policies if not p["active"]]
        if inactive_policies:
            recommendations.append(f"Ativar {len(inactive_policies)} políticas de privacidade inativas")
        
        # Verificar elementos sem mascaramento
        elements_without_masking = []
        for policy in policies:
            for element in policy["data_elements"]:
                if element.is_pii and not element.masking_rules:
                    elements_without_masking.append(element.field_name)
        
        if elements_without_masking:
            recommendations.append(f"Implementar mascaramento para {len(elements_without_masking)} campos PII")
        
        # Verificar políticas de retenção
        policies_without_retention = [p for p in policies if not p["retention_policy"]]
        if policies_without_retention:
            recommendations.append(f"Definir políticas de retenção para {len(policies_without_retention)} políticas")
        
        return recommendations


class ConsentManager:
    """Gerenciador de consentimento"""
    
    def __init__(self):
        self.consents = {}
    
    def record_consent(self, 
                      user_id: str,
                      purpose: str,
                      data_types: List[str],
                      consent_given: bool,
                      legal_basis: str,
                      expiry_date: Optional[datetime] = None):
        """
        Registra consentimento do usuário
        
        Args:
            user_id: ID do usuário
            purpose: Finalidade do processamento
            data_types: Tipos de dados
            consent_given: Se consentimento foi dado
            legal_basis: Base legal
            expiry_date: Data de expiração
        """
        consent_id = str(uuid.uuid4())
        
        consent = {
            "id": consent_id,
            "user_id": user_id,
            "purpose": purpose,
            "data_types": data_types,
            "consent_given": consent_given,
            "legal_basis": legal_basis,
            "granted_at": datetime.utcnow(),
            "expiry_date": expiry_date,
            "withdrawn_at": None,
            "active": consent_given
        }
        
        self.consents[consent_id] = consent
        
        # Registrar evento de auditoria
        audit_logger.log_event({
            "event_type": AuditEventType.CREATE,
            "resource_type": "consent",
            "resource_id": consent_id,
            "action": "consent_recorded",
            "details": {
                "user_id": user_id,
                "purpose": purpose,
                "consent_given": consent_given
            },
            "compliance_frameworks": ["lgpd", "gdpr"]
        })
        
        return consent_id
    
    def withdraw_consent(self, consent_id: str, user_id: str):
        """
        Retira consentimento
        
        Args:
            consent_id: ID do consentimento
            user_id: ID do usuário
        """
        consent = self.consents.get(consent_id)
        
        if not consent or consent["user_id"] != user_id:
            raise DataGovernanceException("Consentimento não encontrado ou não autorizado")
        
        consent["withdrawn_at"] = datetime.utcnow()
        consent["active"] = False
        
        # Registrar evento de auditoria
        audit_logger.log_event({
            "event_type": AuditEventType.UPDATE,
            "resource_type": "consent",
            "resource_id": consent_id,
            "action": "consent_withdrawn",
            "details": {"user_id": user_id},
            "compliance_frameworks": ["lgpd", "gdpr"]
        })
    
    def check_consent(self, user_id: str, purpose: str, data_types: List[str]) -> bool:
        """
        Verifica se há consentimento válido
        
        Args:
            user_id: ID do usuário
            purpose: Finalidade
            data_types: Tipos de dados
            
        Returns:
            True se há consentimento válido
        """
        user_consents = [c for c in self.consents.values() if c["user_id"] == user_id]
        
        for consent in user_consents:
            if (consent["active"] and 
                consent["purpose"] == purpose and
                all(dt in consent["data_types"] for dt in data_types)):
                
                # Verificar expiração
                if consent["expiry_date"] and datetime.utcnow() > consent["expiry_date"]:
                    consent["active"] = False
                    continue
                
                return True
        
        return False


# Instâncias globais
privacy_policy_engine = PrivacyPolicyEngine()
consent_manager = ConsentManager()
pii_detector = PIIDetector()
data_masker = DataMasker()


# Funções de conveniência
def mask_data(data: Dict[str, Any], 
              context: Dict[str, Any] = None,
              user_permissions: List[str] = None) -> Dict[str, Any]:
    """
    Mascara dados baseado em políticas
    
    Args:
        data: Dados para mascarar
        context: Contexto da operação
        user_permissions: Permissões do usuário
        
    Returns:
        Dados mascarados
    """
    return privacy_policy_engine.apply_masking(
        data, 
        context or {}, 
        user_permissions or []
    )


def detect_pii_in_text(text: str) -> Dict[str, List[str]]:
    """
    Detecta PII em texto
    
    Args:
        text: Texto para analisar
        
    Returns:
        PII detectado
    """
    return pii_detector.detect_pii(text)


def classify_data_field(field_name: str, sample_values: List[str]) -> DataClassification:
    """
    Classifica campo de dados
    
    Args:
        field_name: Nome do campo
        sample_values: Valores de exemplo
        
    Returns:
        Classificação do campo
    """
    return pii_detector.classify_field(field_name, sample_values)


def check_user_consent(user_id: str, purpose: str, data_types: List[str]) -> bool:
    """
    Verifica consentimento do usuário
    
    Args:
        user_id: ID do usuário
        purpose: Finalidade
        data_types: Tipos de dados
        
    Returns:
        True se há consentimento
    """
    return consent_manager.check_consent(user_id, purpose, data_types)

