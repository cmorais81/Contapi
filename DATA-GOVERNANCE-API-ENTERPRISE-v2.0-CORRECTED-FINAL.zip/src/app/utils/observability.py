"""
Sistema de Observabilidade para Data Governance API
Autor: Carlos Morais

Sistema completo de observabilidade com tracing distribuído,
métricas customizadas e logging estruturado.
"""

import time
import json
import uuid
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Callable
from functools import wraps
from contextlib import contextmanager
from dataclasses import dataclass, asdict
from enum import Enum
import threading
from collections import defaultdict, deque

from .exceptions import DataGovernanceException


class LogLevel(Enum):
    """Níveis de log"""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class SpanStatus(Enum):
    """Status de span de tracing"""
    OK = "OK"
    ERROR = "ERROR"
    TIMEOUT = "TIMEOUT"
    CANCELLED = "CANCELLED"


@dataclass
class Span:
    """Span de tracing distribuído"""
    trace_id: str
    span_id: str
    parent_span_id: Optional[str]
    operation_name: str
    start_time: datetime
    end_time: Optional[datetime]
    duration_ms: Optional[float]
    status: SpanStatus
    tags: Dict[str, Any]
    logs: List[Dict[str, Any]]
    baggage: Dict[str, str]
    
    def finish(self, status: SpanStatus = SpanStatus.OK):
        """Finaliza o span"""
        self.end_time = datetime.utcnow()
        self.duration_ms = (self.end_time - self.start_time).total_seconds() * 1000
        self.status = status
    
    def add_tag(self, key: str, value: Any):
        """Adiciona tag ao span"""
        self.tags[key] = value
    
    def add_log(self, message: str, level: LogLevel = LogLevel.INFO, **kwargs):
        """Adiciona log ao span"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": level.value,
            "message": message,
            **kwargs
        }
        self.logs.append(log_entry)
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte span para dicionário"""
        data = asdict(self)
        data['start_time'] = self.start_time.isoformat()
        data['end_time'] = self.end_time.isoformat() if self.end_time else None
        data['status'] = self.status.value
        return data


class Tracer:
    """Tracer para spans distribuídos"""
    
    def __init__(self):
        self.spans = {}
        self.active_spans = {}  # Por thread
        self._lock = threading.Lock()
    
    def start_span(self, 
                   operation_name: str,
                   parent_span: Optional[Span] = None,
                   tags: Dict[str, Any] = None) -> Span:
        """
        Inicia novo span
        
        Args:
            operation_name: Nome da operação
            parent_span: Span pai
            tags: Tags iniciais
            
        Returns:
            Novo span
        """
        thread_id = threading.get_ident()
        
        # Determinar trace_id e parent
        if parent_span:
            trace_id = parent_span.trace_id
            parent_span_id = parent_span.span_id
        else:
            # Verificar se há span ativo na thread
            active_span = self.active_spans.get(thread_id)
            if active_span:
                trace_id = active_span.trace_id
                parent_span_id = active_span.span_id
            else:
                trace_id = str(uuid.uuid4())
                parent_span_id = None
        
        span = Span(
            trace_id=trace_id,
            span_id=str(uuid.uuid4()),
            parent_span_id=parent_span_id,
            operation_name=operation_name,
            start_time=datetime.utcnow(),
            end_time=None,
            duration_ms=None,
            status=SpanStatus.OK,
            tags=tags or {},
            logs=[],
            baggage={}
        )
        
        with self._lock:
            self.spans[span.span_id] = span
            self.active_spans[thread_id] = span
        
        return span
    
    def finish_span(self, span: Span, status: SpanStatus = SpanStatus.OK):
        """
        Finaliza span
        
        Args:
            span: Span para finalizar
            status: Status final
        """
        span.finish(status)
        
        thread_id = threading.get_ident()
        with self._lock:
            # Remover como span ativo se for o atual
            if self.active_spans.get(thread_id) == span:
                # Restaurar span pai como ativo
                parent_span = self.get_span(span.parent_span_id) if span.parent_span_id else None
                if parent_span:
                    self.active_spans[thread_id] = parent_span
                else:
                    self.active_spans.pop(thread_id, None)
    
    def get_span(self, span_id: str) -> Optional[Span]:
        """
        Obtém span por ID
        
        Args:
            span_id: ID do span
            
        Returns:
            Span ou None se não encontrado
        """
        return self.spans.get(span_id)
    
    def get_active_span(self) -> Optional[Span]:
        """
        Obtém span ativo da thread atual
        
        Returns:
            Span ativo ou None
        """
        thread_id = threading.get_ident()
        return self.active_spans.get(thread_id)
    
    def get_trace(self, trace_id: str) -> List[Span]:
        """
        Obtém todos os spans de um trace
        
        Args:
            trace_id: ID do trace
            
        Returns:
            Lista de spans do trace
        """
        return [span for span in self.spans.values() if span.trace_id == trace_id]
    
    @contextmanager
    def span(self, operation_name: str, tags: Dict[str, Any] = None):
        """
        Context manager para spans
        
        Args:
            operation_name: Nome da operação
            tags: Tags iniciais
        """
        span = self.start_span(operation_name, tags=tags)
        try:
            yield span
        except Exception as e:
            span.add_tag("error", True)
            span.add_tag("error.message", str(e))
            span.add_log(f"Exception: {str(e)}", LogLevel.ERROR)
            self.finish_span(span, SpanStatus.ERROR)
            raise
        else:
            self.finish_span(span, SpanStatus.OK)


class MetricsCollector:
    """Coletor de métricas customizadas"""
    
    def __init__(self):
        self.counters = defaultdict(int)
        self.gauges = defaultdict(float)
        self.histograms = defaultdict(list)
        self.timers = defaultdict(list)
        self._lock = threading.Lock()
    
    def increment_counter(self, name: str, value: int = 1, tags: Dict[str, str] = None):
        """
        Incrementa contador
        
        Args:
            name: Nome da métrica
            value: Valor para incrementar
            tags: Tags da métrica
        """
        metric_key = self._build_metric_key(name, tags)
        with self._lock:
            self.counters[metric_key] += value
    
    def set_gauge(self, name: str, value: float, tags: Dict[str, str] = None):
        """
        Define valor de gauge
        
        Args:
            name: Nome da métrica
            value: Valor do gauge
            tags: Tags da métrica
        """
        metric_key = self._build_metric_key(name, tags)
        with self._lock:
            self.gauges[metric_key] = value
    
    def record_histogram(self, name: str, value: float, tags: Dict[str, str] = None):
        """
        Registra valor em histograma
        
        Args:
            name: Nome da métrica
            value: Valor para registrar
            tags: Tags da métrica
        """
        metric_key = self._build_metric_key(name, tags)
        with self._lock:
            self.histograms[metric_key].append(value)
            # Manter apenas últimos 1000 valores
            if len(self.histograms[metric_key]) > 1000:
                self.histograms[metric_key] = self.histograms[metric_key][-1000:]
    
    def record_timer(self, name: str, duration_ms: float, tags: Dict[str, str] = None):
        """
        Registra tempo de execução
        
        Args:
            name: Nome da métrica
            duration_ms: Duração em milissegundos
            tags: Tags da métrica
        """
        metric_key = self._build_metric_key(name, tags)
        with self._lock:
            self.timers[metric_key].append(duration_ms)
            # Manter apenas últimos 1000 valores
            if len(self.timers[metric_key]) > 1000:
                self.timers[metric_key] = self.timers[metric_key][-1000:]
    
    def _build_metric_key(self, name: str, tags: Dict[str, str] = None) -> str:
        """
        Constrói chave da métrica com tags
        
        Args:
            name: Nome da métrica
            tags: Tags da métrica
            
        Returns:
            Chave da métrica
        """
        if not tags:
            return name
        
        tag_str = ",".join(f"{k}={v}" for k, v in sorted(tags.items()))
        return f"{name}[{tag_str}]"
    
    def get_metrics(self) -> Dict[str, Any]:
        """
        Obtém todas as métricas
        
        Returns:
            Dicionário com todas as métricas
        """
        with self._lock:
            metrics = {
                "counters": dict(self.counters),
                "gauges": dict(self.gauges),
                "histograms": {},
                "timers": {}
            }
            
            # Calcular estatísticas para histogramas
            for key, values in self.histograms.items():
                if values:
                    sorted_values = sorted(values)
                    metrics["histograms"][key] = {
                        "count": len(values),
                        "min": min(values),
                        "max": max(values),
                        "mean": sum(values) / len(values),
                        "p50": self._percentile(sorted_values, 50),
                        "p95": self._percentile(sorted_values, 95),
                        "p99": self._percentile(sorted_values, 99)
                    }
            
            # Calcular estatísticas para timers
            for key, values in self.timers.items():
                if values:
                    sorted_values = sorted(values)
                    metrics["timers"][key] = {
                        "count": len(values),
                        "min_ms": min(values),
                        "max_ms": max(values),
                        "mean_ms": sum(values) / len(values),
                        "p50_ms": self._percentile(sorted_values, 50),
                        "p95_ms": self._percentile(sorted_values, 95),
                        "p99_ms": self._percentile(sorted_values, 99)
                    }
        
        return metrics
    
    def _percentile(self, sorted_values: List[float], percentile: int) -> float:
        """
        Calcula percentil
        
        Args:
            sorted_values: Valores ordenados
            percentile: Percentil desejado
            
        Returns:
            Valor do percentil
        """
        if not sorted_values:
            return 0.0
        
        index = int((percentile / 100.0) * (len(sorted_values) - 1))
        return sorted_values[index]


class StructuredLogger:
    """Logger estruturado"""
    
    def __init__(self):
        self.logs = deque(maxlen=10000)  # Manter últimos 10k logs
        self._lock = threading.Lock()
    
    def log(self, 
            level: LogLevel,
            message: str,
            component: str = "unknown",
            **kwargs):
        """
        Registra log estruturado
        
        Args:
            level: Nível do log
            message: Mensagem
            component: Componente que gerou o log
            **kwargs: Campos adicionais
        """
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": level.value,
            "component": component,
            "message": message,
            "trace_id": None,
            "span_id": None,
            **kwargs
        }
        
        # Adicionar informações de tracing se disponível
        active_span = tracer.get_active_span()
        if active_span:
            log_entry["trace_id"] = active_span.trace_id
            log_entry["span_id"] = active_span.span_id
        
        with self._lock:
            self.logs.append(log_entry)
        
        # Em produção, enviar para sistema de logging
        self._emit_log(log_entry)
    
    def _emit_log(self, log_entry: Dict[str, Any]):
        """
        Emite log (implementação simulada)
        
        Args:
            log_entry: Entrada de log
        """
        # Simular envio para sistema de logging
        print(f"[{log_entry['level']}] {log_entry['component']}: {log_entry['message']}")
    
    def debug(self, message: str, component: str = "unknown", **kwargs):
        """Log de debug"""
        self.log(LogLevel.DEBUG, message, component, **kwargs)
    
    def info(self, message: str, component: str = "unknown", **kwargs):
        """Log de info"""
        self.log(LogLevel.INFO, message, component, **kwargs)
    
    def warning(self, message: str, component: str = "unknown", **kwargs):
        """Log de warning"""
        self.log(LogLevel.WARNING, message, component, **kwargs)
    
    def error(self, message: str, component: str = "unknown", **kwargs):
        """Log de error"""
        self.log(LogLevel.ERROR, message, component, **kwargs)
    
    def critical(self, message: str, component: str = "unknown", **kwargs):
        """Log crítico"""
        self.log(LogLevel.CRITICAL, message, component, **kwargs)
    
    def get_logs(self, 
                 level: Optional[LogLevel] = None,
                 component: Optional[str] = None,
                 limit: int = 100) -> List[Dict[str, Any]]:
        """
        Obtém logs com filtros
        
        Args:
            level: Nível para filtrar
            component: Componente para filtrar
            limit: Limite de logs
            
        Returns:
            Lista de logs filtrados
        """
        with self._lock:
            logs = list(self.logs)
        
        # Aplicar filtros
        if level:
            logs = [log for log in logs if log["level"] == level.value]
        
        if component:
            logs = [log for log in logs if log["component"] == component]
        
        # Ordenar por timestamp (mais recente primeiro)
        logs.sort(key=lambda x: x["timestamp"], reverse=True)
        
        return logs[:limit]


class PerformanceMonitor:
    """Monitor de performance"""
    
    def __init__(self):
        self.metrics_collector = MetricsCollector()
        self.alert_thresholds = {
            "response_time_ms": 5000,
            "error_rate_percent": 5.0,
            "cpu_usage_percent": 80.0,
            "memory_usage_percent": 85.0
        }
    
    def record_request(self, 
                      endpoint: str,
                      method: str,
                      status_code: int,
                      duration_ms: float,
                      user_id: Optional[str] = None):
        """
        Registra métricas de request
        
        Args:
            endpoint: Endpoint acessado
            method: Método HTTP
            status_code: Código de status
            duration_ms: Duração em milissegundos
            user_id: ID do usuário
        """
        tags = {
            "endpoint": endpoint,
            "method": method,
            "status_code": str(status_code)
        }
        
        if user_id:
            tags["user_id"] = user_id
        
        # Registrar métricas
        self.metrics_collector.increment_counter("http.requests", tags=tags)
        self.metrics_collector.record_timer("http.response_time", duration_ms, tags=tags)
        
        # Registrar erro se necessário
        if status_code >= 400:
            self.metrics_collector.increment_counter("http.errors", tags=tags)
        
        # Verificar alertas
        self._check_performance_alerts(duration_ms, status_code)
    
    def record_database_query(self, 
                             query_type: str,
                             table: str,
                             duration_ms: float,
                             rows_affected: int = 0):
        """
        Registra métricas de query de banco
        
        Args:
            query_type: Tipo da query (SELECT, INSERT, etc.)
            table: Tabela acessada
            duration_ms: Duração em milissegundos
            rows_affected: Linhas afetadas
        """
        tags = {
            "query_type": query_type,
            "table": table
        }
        
        self.metrics_collector.increment_counter("db.queries", tags=tags)
        self.metrics_collector.record_timer("db.query_time", duration_ms, tags=tags)
        self.metrics_collector.record_histogram("db.rows_affected", rows_affected, tags=tags)
    
    def record_cache_operation(self, 
                              operation: str,
                              hit: bool,
                              duration_ms: float):
        """
        Registra métricas de cache
        
        Args:
            operation: Operação (get, set, delete)
            hit: Se foi hit ou miss
            duration_ms: Duração em milissegundos
        """
        tags = {
            "operation": operation,
            "result": "hit" if hit else "miss"
        }
        
        self.metrics_collector.increment_counter("cache.operations", tags=tags)
        self.metrics_collector.record_timer("cache.operation_time", duration_ms, tags=tags)
    
    def get_system_metrics(self) -> Dict[str, Any]:
        """
        Obtém métricas do sistema
        
        Returns:
            Métricas do sistema
        """
        # Simular métricas do sistema
        import psutil
        
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            return {
                "cpu_usage_percent": cpu_percent,
                "memory_usage_percent": memory.percent,
                "memory_available_mb": memory.available / 1024 / 1024,
                "disk_usage_percent": disk.percent,
                "disk_free_gb": disk.free / 1024 / 1024 / 1024
            }
        except ImportError:
            # Fallback se psutil não estiver disponível
            return {
                "cpu_usage_percent": 45.2,
                "memory_usage_percent": 67.8,
                "memory_available_mb": 2048,
                "disk_usage_percent": 35.5,
                "disk_free_gb": 50.2
            }
    
    def check_health(self) -> Dict[str, Any]:
        """
        Verifica saúde do sistema
        
        Returns:
            Status de saúde
        """
        system_metrics = self.get_system_metrics()
        app_metrics = self.metrics_collector.get_metrics()
        
        # Calcular score de saúde
        health_score = 100.0
        issues = []
        
        # Verificar CPU
        if system_metrics["cpu_usage_percent"] > self.alert_thresholds["cpu_usage_percent"]:
            health_score -= 20
            issues.append(f"Alto uso de CPU: {system_metrics['cpu_usage_percent']:.1f}%")
        
        # Verificar memória
        if system_metrics["memory_usage_percent"] > self.alert_thresholds["memory_usage_percent"]:
            health_score -= 20
            issues.append(f"Alto uso de memória: {system_metrics['memory_usage_percent']:.1f}%")
        
        # Verificar taxa de erro
        total_requests = sum(v for k, v in app_metrics["counters"].items() if "http.requests" in k)
        total_errors = sum(v for k, v in app_metrics["counters"].items() if "http.errors" in k)
        
        if total_requests > 0:
            error_rate = (total_errors / total_requests) * 100
            if error_rate > self.alert_thresholds["error_rate_percent"]:
                health_score -= 30
                issues.append(f"Alta taxa de erro: {error_rate:.1f}%")
        
        # Determinar status
        if health_score >= 80:
            status = "healthy"
        elif health_score >= 60:
            status = "degraded"
        else:
            status = "unhealthy"
        
        return {
            "status": status,
            "score": health_score,
            "timestamp": datetime.utcnow().isoformat(),
            "issues": issues,
            "system_metrics": system_metrics
        }
    
    def _check_performance_alerts(self, duration_ms: float, status_code: int):
        """
        Verifica alertas de performance
        
        Args:
            duration_ms: Duração da request
            status_code: Código de status
        """
        # Verificar tempo de resposta
        if duration_ms > self.alert_thresholds["response_time_ms"]:
            logger.warning(
                f"Slow request detected: {duration_ms:.1f}ms",
                component="performance_monitor",
                duration_ms=duration_ms,
                threshold_ms=self.alert_thresholds["response_time_ms"]
            )


class ObservabilityDecorator:
    """Decorator para observabilidade automática"""
    
    def __init__(self, 
                 tracer: Tracer,
                 metrics_collector: MetricsCollector,
                 logger: StructuredLogger):
        self.tracer = tracer
        self.metrics_collector = metrics_collector
        self.logger = logger
    
    def observe(self, 
                operation_name: Optional[str] = None,
                component: str = "unknown",
                record_metrics: bool = True):
        """
        Decorator para observabilidade automática
        
        Args:
            operation_name: Nome da operação (usa nome da função se None)
            component: Componente que executa a operação
            record_metrics: Se deve registrar métricas
        """
        def decorator(func: Callable):
            @wraps(func)
            def wrapper(*args, **kwargs):
                op_name = operation_name or f"{component}.{func.__name__}"
                
                with self.tracer.span(op_name) as span:
                    span.add_tag("component", component)
                    span.add_tag("function", func.__name__)
                    
                    start_time = time.time()
                    
                    try:
                        self.logger.debug(
                            f"Starting {op_name}",
                            component=component,
                            operation=op_name
                        )
                        
                        result = func(*args, **kwargs)
                        
                        duration_ms = (time.time() - start_time) * 1000
                        
                        span.add_tag("success", True)
                        span.add_tag("duration_ms", duration_ms)
                        
                        if record_metrics:
                            self.metrics_collector.record_timer(
                                f"{component}.execution_time",
                                duration_ms,
                                tags={"operation": op_name}
                            )
                            self.metrics_collector.increment_counter(
                                f"{component}.operations",
                                tags={"operation": op_name, "status": "success"}
                            )
                        
                        self.logger.info(
                            f"Completed {op_name}",
                            component=component,
                            operation=op_name,
                            duration_ms=duration_ms
                        )
                        
                        return result
                        
                    except Exception as e:
                        duration_ms = (time.time() - start_time) * 1000
                        
                        span.add_tag("success", False)
                        span.add_tag("error", str(e))
                        span.add_tag("duration_ms", duration_ms)
                        
                        if record_metrics:
                            self.metrics_collector.increment_counter(
                                f"{component}.operations",
                                tags={"operation": op_name, "status": "error"}
                            )
                        
                        self.logger.error(
                            f"Failed {op_name}: {str(e)}",
                            component=component,
                            operation=op_name,
                            duration_ms=duration_ms,
                            error=str(e)
                        )
                        
                        raise
            
            return wrapper
        return decorator


# Instâncias globais
tracer = Tracer()
metrics_collector = MetricsCollector()
logger = StructuredLogger()
performance_monitor = PerformanceMonitor()
observability_decorator = ObservabilityDecorator(tracer, metrics_collector, logger)


# Funções de conveniência
def trace_operation(operation_name: str = None, component: str = "unknown"):
    """
    Decorator para tracing de operação
    
    Args:
        operation_name: Nome da operação
        component: Componente
    """
    return observability_decorator.observe(operation_name, component)


def get_trace_context() -> Optional[Dict[str, str]]:
    """
    Obtém contexto de tracing atual
    
    Returns:
        Contexto de tracing ou None
    """
    active_span = tracer.get_active_span()
    if active_span:
        return {
            "trace_id": active_span.trace_id,
            "span_id": active_span.span_id
        }
    return None


def record_business_metric(name: str, value: float, tags: Dict[str, str] = None):
    """
    Registra métrica de negócio
    
    Args:
        name: Nome da métrica
        value: Valor da métrica
        tags: Tags da métrica
    """
    metrics_collector.record_histogram(f"business.{name}", value, tags)


def get_observability_summary() -> Dict[str, Any]:
    """
    Obtém resumo de observabilidade
    
    Returns:
        Resumo de observabilidade
    """
    return {
        "health": performance_monitor.check_health(),
        "metrics": metrics_collector.get_metrics(),
        "active_traces": len(tracer.active_spans),
        "total_spans": len(tracer.spans),
        "recent_logs": logger.get_logs(limit=10)
    }

