"""
Paginação para Data Governance API
Autor: Carlos Morais

Módulo com utilitários para paginação de resultados,
ordenação e filtragem de dados.
"""

from typing import Any, Dict, List, Optional, Tuple, TypeVar, Generic
from pydantic import BaseModel, Field
from sqlalchemy.orm import Query
from sqlalchemy import func, desc, asc
import math

T = TypeVar('T')


class PaginationParams(BaseModel):
    """Parâmetros de paginação"""
    
    page: int = Field(default=1, ge=1, description="Número da página (1-based)")
    page_size: int = Field(default=20, ge=1, le=100, description="Tamanho da página")
    sort_by: Optional[str] = Field(default=None, description="Campo para ordenação")
    sort_order: str = Field(default="asc", regex="^(asc|desc)$", description="Ordem de classificação")
    search: Optional[str] = Field(default=None, description="Termo de busca")
    filters: Optional[Dict[str, Any]] = Field(default=None, description="Filtros adicionais")
    
    @property
    def offset(self) -> int:
        """Calcula offset para a página"""
        return (self.page - 1) * self.page_size
    
    @property
    def limit(self) -> int:
        """Retorna limite de itens"""
        return self.page_size


class PaginationMeta(BaseModel):
    """Metadados de paginação"""
    
    page: int = Field(description="Página atual")
    page_size: int = Field(description="Tamanho da página")
    total_items: int = Field(description="Total de itens")
    total_pages: int = Field(description="Total de páginas")
    has_next: bool = Field(description="Tem próxima página")
    has_previous: bool = Field(description="Tem página anterior")
    next_page: Optional[int] = Field(description="Número da próxima página")
    previous_page: Optional[int] = Field(description="Número da página anterior")
    
    @classmethod
    def create(cls, page: int, page_size: int, total_items: int) -> "PaginationMeta":
        """
        Cria metadados de paginação
        
        Args:
            page: Página atual
            page_size: Tamanho da página
            total_items: Total de itens
            
        Returns:
            Metadados de paginação
        """
        total_pages = math.ceil(total_items / page_size) if page_size > 0 else 0
        has_next = page < total_pages
        has_previous = page > 1
        
        return cls(
            page=page,
            page_size=page_size,
            total_items=total_items,
            total_pages=total_pages,
            has_next=has_next,
            has_previous=has_previous,
            next_page=page + 1 if has_next else None,
            previous_page=page - 1 if has_previous else None
        )


class PaginatedResponse(BaseModel, Generic[T]):
    """Resposta paginada genérica"""
    
    items: List[T] = Field(description="Lista de itens")
    meta: PaginationMeta = Field(description="Metadados de paginação")
    
    @classmethod
    def create(cls, items: List[T], page: int, page_size: int, total_items: int) -> "PaginatedResponse[T]":
        """
        Cria resposta paginada
        
        Args:
            items: Lista de itens
            page: Página atual
            page_size: Tamanho da página
            total_items: Total de itens
            
        Returns:
            Resposta paginada
        """
        meta = PaginationMeta.create(page, page_size, total_items)
        return cls(items=items, meta=meta)


class QueryPaginator:
    """Paginador para queries SQLAlchemy"""
    
    @staticmethod
    def paginate_query(query: Query, params: PaginationParams) -> Tuple[List[Any], PaginationMeta]:
        """
        Pagina query SQLAlchemy
        
        Args:
            query: Query para paginar
            params: Parâmetros de paginação
            
        Returns:
            Tupla com (itens, metadados)
        """
        # Contar total de itens
        total_items = query.count()
        
        # Aplicar ordenação se especificada
        if params.sort_by:
            column = getattr(query.column_descriptions[0]['type'], params.sort_by, None)
            if column is not None:
                if params.sort_order == "desc":
                    query = query.order_by(desc(column))
                else:
                    query = query.order_by(asc(column))
        
        # Aplicar paginação
        items = query.offset(params.offset).limit(params.limit).all()
        
        # Criar metadados
        meta = PaginationMeta.create(params.page, params.page_size, total_items)
        
        return items, meta
    
    @staticmethod
    def paginate_with_search(query: Query, params: PaginationParams, 
                           search_columns: List[str]) -> Tuple[List[Any], PaginationMeta]:
        """
        Pagina query com busca em colunas específicas
        
        Args:
            query: Query para paginar
            params: Parâmetros de paginação
            search_columns: Colunas para busca
            
        Returns:
            Tupla com (itens, metadados)
        """
        # Aplicar busca se especificada
        if params.search and search_columns:
            search_term = f"%{params.search}%"
            model = query.column_descriptions[0]['type']
            
            search_conditions = []
            for column_name in search_columns:
                column = getattr(model, column_name, None)
                if column is not None:
                    search_conditions.append(column.ilike(search_term))
            
            if search_conditions:
                from sqlalchemy import or_
                query = query.filter(or_(*search_conditions))
        
        return QueryPaginator.paginate_query(query, params)
    
    @staticmethod
    def paginate_with_filters(query: Query, params: PaginationParams, 
                            allowed_filters: Dict[str, str]) -> Tuple[List[Any], PaginationMeta]:
        """
        Pagina query com filtros
        
        Args:
            query: Query para paginar
            params: Parâmetros de paginação
            allowed_filters: Mapa de filtros permitidos (nome_filtro -> nome_coluna)
            
        Returns:
            Tupla com (itens, metadados)
        """
        # Aplicar filtros se especificados
        if params.filters and allowed_filters:
            model = query.column_descriptions[0]['type']
            
            for filter_name, filter_value in params.filters.items():
                if filter_name in allowed_filters:
                    column_name = allowed_filters[filter_name]
                    column = getattr(model, column_name, None)
                    
                    if column is not None and filter_value is not None:
                        if isinstance(filter_value, list):
                            query = query.filter(column.in_(filter_value))
                        elif isinstance(filter_value, dict):
                            # Filtros complexos (range, etc.)
                            if 'gte' in filter_value:
                                query = query.filter(column >= filter_value['gte'])
                            if 'lte' in filter_value:
                                query = query.filter(column <= filter_value['lte'])
                            if 'eq' in filter_value:
                                query = query.filter(column == filter_value['eq'])
                            if 'ne' in filter_value:
                                query = query.filter(column != filter_value['ne'])
                            if 'like' in filter_value:
                                query = query.filter(column.ilike(f"%{filter_value['like']}%"))
                        else:
                            query = query.filter(column == filter_value)
        
        return QueryPaginator.paginate_query(query, params)


class ListPaginator:
    """Paginador para listas em memória"""
    
    @staticmethod
    def paginate_list(items: List[T], params: PaginationParams) -> PaginatedResponse[T]:
        """
        Pagina lista em memória
        
        Args:
            items: Lista para paginar
            params: Parâmetros de paginação
            
        Returns:
            Resposta paginada
        """
        total_items = len(items)
        
        # Aplicar ordenação se especificada
        if params.sort_by:
            reverse = params.sort_order == "desc"
            try:
                items = sorted(items, key=lambda x: getattr(x, params.sort_by, ''), reverse=reverse)
            except AttributeError:
                # Se não conseguir ordenar por atributo, tenta por chave de dict
                try:
                    items = sorted(items, key=lambda x: x.get(params.sort_by, ''), reverse=reverse)
                except (AttributeError, TypeError):
                    pass  # Mantém ordem original se não conseguir ordenar
        
        # Aplicar paginação
        start_index = params.offset
        end_index = start_index + params.page_size
        paginated_items = items[start_index:end_index]
        
        return PaginatedResponse.create(paginated_items, params.page, params.page_size, total_items)
    
    @staticmethod
    def paginate_with_search(items: List[T], params: PaginationParams, 
                           search_fields: List[str]) -> PaginatedResponse[T]:
        """
        Pagina lista com busca
        
        Args:
            items: Lista para paginar
            params: Parâmetros de paginação
            search_fields: Campos para busca
            
        Returns:
            Resposta paginada
        """
        # Aplicar busca se especificada
        if params.search and search_fields:
            search_term = params.search.lower()
            filtered_items = []
            
            for item in items:
                for field in search_fields:
                    try:
                        # Tenta acessar como atributo
                        value = str(getattr(item, field, '')).lower()
                    except AttributeError:
                        try:
                            # Tenta acessar como chave de dict
                            value = str(item.get(field, '')).lower()
                        except (AttributeError, TypeError):
                            value = ''
                    
                    if search_term in value:
                        filtered_items.append(item)
                        break
            
            items = filtered_items
        
        return ListPaginator.paginate_list(items, params)
    
    @staticmethod
    def paginate_with_filters(items: List[T], params: PaginationParams, 
                            filter_functions: Dict[str, callable]) -> PaginatedResponse[T]:
        """
        Pagina lista com filtros customizados
        
        Args:
            items: Lista para paginar
            params: Parâmetros de paginação
            filter_functions: Funções de filtro (nome_filtro -> função)
            
        Returns:
            Resposta paginada
        """
        # Aplicar filtros se especificados
        if params.filters and filter_functions:
            for filter_name, filter_value in params.filters.items():
                if filter_name in filter_functions and filter_value is not None:
                    filter_func = filter_functions[filter_name]
                    items = [item for item in items if filter_func(item, filter_value)]
        
        return ListPaginator.paginate_list(items, params)


class SortingHelper:
    """Helper para ordenação de dados"""
    
    @staticmethod
    def sort_by_multiple_fields(items: List[Dict[str, Any]], 
                              sort_fields: List[Tuple[str, str]]) -> List[Dict[str, Any]]:
        """
        Ordena lista por múltiplos campos
        
        Args:
            items: Lista para ordenar
            sort_fields: Lista de tuplas (campo, ordem)
            
        Returns:
            Lista ordenada
        """
        sorted_items = items.copy()
        
        # Ordena por cada campo em ordem reversa
        for field, order in reversed(sort_fields):
            reverse = order.lower() == "desc"
            sorted_items.sort(key=lambda x: x.get(field, ''), reverse=reverse)
        
        return sorted_items
    
    @staticmethod
    def sort_by_nested_field(items: List[Dict[str, Any]], 
                           field_path: str, order: str = "asc") -> List[Dict[str, Any]]:
        """
        Ordena lista por campo aninhado
        
        Args:
            items: Lista para ordenar
            field_path: Caminho do campo (ex: "user.profile.name")
            order: Ordem de classificação
            
        Returns:
            Lista ordenada
        """
        def get_nested_value(item: Dict[str, Any], path: str) -> Any:
            """Obtém valor de campo aninhado"""
            keys = path.split('.')
            value = item
            
            for key in keys:
                if isinstance(value, dict) and key in value:
                    value = value[key]
                else:
                    return ''
            
            return value
        
        reverse = order.lower() == "desc"
        return sorted(items, key=lambda x: get_nested_value(x, field_path), reverse=reverse)


class FilterHelper:
    """Helper para filtragem de dados"""
    
    @staticmethod
    def filter_by_date_range(items: List[Dict[str, Any]], 
                           date_field: str, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        """
        Filtra lista por range de datas
        
        Args:
            items: Lista para filtrar
            date_field: Campo de data
            start_date: Data inicial (ISO format)
            end_date: Data final (ISO format)
            
        Returns:
            Lista filtrada
        """
        from datetime import datetime
        
        try:
            start = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            end = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
        except ValueError:
            return items
        
        filtered_items = []
        for item in items:
            try:
                item_date_str = item.get(date_field)
                if item_date_str:
                    item_date = datetime.fromisoformat(item_date_str.replace('Z', '+00:00'))
                    if start <= item_date <= end:
                        filtered_items.append(item)
            except (ValueError, TypeError):
                continue
        
        return filtered_items
    
    @staticmethod
    def filter_by_numeric_range(items: List[Dict[str, Any]], 
                              numeric_field: str, min_value: float, max_value: float) -> List[Dict[str, Any]]:
        """
        Filtra lista por range numérico
        
        Args:
            items: Lista para filtrar
            numeric_field: Campo numérico
            min_value: Valor mínimo
            max_value: Valor máximo
            
        Returns:
            Lista filtrada
        """
        filtered_items = []
        for item in items:
            try:
                value = float(item.get(numeric_field, 0))
                if min_value <= value <= max_value:
                    filtered_items.append(item)
            except (ValueError, TypeError):
                continue
        
        return filtered_items
    
    @staticmethod
    def filter_by_text_contains(items: List[Dict[str, Any]], 
                              text_field: str, search_text: str, case_sensitive: bool = False) -> List[Dict[str, Any]]:
        """
        Filtra lista por texto contido
        
        Args:
            items: Lista para filtrar
            text_field: Campo de texto
            search_text: Texto para buscar
            case_sensitive: Se busca é case sensitive
            
        Returns:
            Lista filtrada
        """
        if not case_sensitive:
            search_text = search_text.lower()
        
        filtered_items = []
        for item in items:
            field_value = str(item.get(text_field, ''))
            if not case_sensitive:
                field_value = field_value.lower()
            
            if search_text in field_value:
                filtered_items.append(item)
        
        return filtered_items


# Funções de conveniência
def paginate_query(query: Query, params: PaginationParams) -> Tuple[List[Any], PaginationMeta]:
    """Função de conveniência para paginar query"""
    return QueryPaginator.paginate_query(query, params)


def paginate_list(items: List[T], params: PaginationParams) -> PaginatedResponse[T]:
    """Função de conveniência para paginar lista"""
    return ListPaginator.paginate_list(items, params)


def create_pagination_params(page: int = 1, page_size: int = 20, 
                           sort_by: str = None, sort_order: str = "asc",
                           search: str = None, filters: Dict[str, Any] = None) -> PaginationParams:
    """
    Cria parâmetros de paginação
    
    Args:
        page: Número da página
        page_size: Tamanho da página
        sort_by: Campo para ordenação
        sort_order: Ordem de classificação
        search: Termo de busca
        filters: Filtros adicionais
        
    Returns:
        Parâmetros de paginação
    """
    return PaginationParams(
        page=page,
        page_size=page_size,
        sort_by=sort_by,
        sort_order=sort_order,
        search=search,
        filters=filters
    )

