"""
Utilitários para Data Governance API
Autor: Carlos Morais

Módulo de utilitários com funções auxiliares, validadores,
formatadores e helpers para toda a aplicação.
"""

from .validators import *
from .formatters import *
from .helpers import *
from .security import *
from .monitoring import *
from .exceptions import *
from .pagination import *
from .cache import *
from .encryption import *
from .audit import *

__all__ = [
    # Validators
    "validate_email",
    "validate_uuid",
    "validate_json_schema",
    "validate_data_contract",
    "validate_lineage_path",
    
    # Formatters
    "format_datetime",
    "format_currency",
    "format_percentage",
    "format_file_size",
    "format_duration",
    
    # Helpers
    "generate_uuid",
    "calculate_hash",
    "deep_merge_dict",
    "flatten_dict",
    "sanitize_string",
    
    # Security
    "hash_password",
    "verify_password",
    "generate_token",
    "verify_token",
    "mask_sensitive_data",
    
    # Monitoring
    "log_performance",
    "track_metric",
    "create_alert",
    "health_check",
    
    # Exceptions
    "DataGovernanceException",
    "ValidationError",
    "AuthenticationError",
    "AuthorizationError",
    "DataQualityError",
    
    # Pagination
    "PaginationParams",
    "PaginatedResponse",
    "paginate_query",
    
    # Cache
    "cache_key",
    "cache_result",
    "invalidate_cache",
    
    # Encryption
    "encrypt_data",
    "decrypt_data",
    "generate_key",
    
    # Audit
    "audit_log",
    "create_audit_entry",
    "get_audit_trail"
]

