"""
Sistema Avançado de Qualidade de Dados
Autor: Carlos Morais

Sistema completo para avaliação, monitoramento e melhoria
da qualidade de dados com integração Databricks.
"""

import re
import json
import statistics
from typing import Any, Dict, List, Optional, Union, Callable, Tuple
from enum import Enum
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
import uuid
import math
from collections import defaultdict, Counter

from .exceptions import DataGovernanceException
from .audit import audit_logger, AuditEventType
from .observability import record_business_metric, trace_operation


class QualityDimension(Enum):
    """Dimensões de qualidade de dados"""
    COMPLETENESS = "completeness"
    ACCURACY = "accuracy"
    CONSISTENCY = "consistency"
    VALIDITY = "validity"
    UNIQUENESS = "uniqueness"
    TIMELINESS = "timeliness"
    INTEGRITY = "integrity"
    CONFORMITY = "conformity"


class QualityRuleType(Enum):
    """Tipos de regras de qualidade"""
    NULL_CHECK = "null_check"
    RANGE_CHECK = "range_check"
    FORMAT_CHECK = "format_check"
    UNIQUENESS_CHECK = "uniqueness_check"
    REFERENTIAL_INTEGRITY = "referential_integrity"
    BUSINESS_RULE = "business_rule"
    STATISTICAL_OUTLIER = "statistical_outlier"
    PATTERN_MATCH = "pattern_match"
    CROSS_FIELD_VALIDATION = "cross_field_validation"
    TEMPORAL_CONSISTENCY = "temporal_consistency"


class QualityStatus(Enum):
    """Status de qualidade"""
    EXCELLENT = "excellent"
    GOOD = "good"
    FAIR = "fair"
    POOR = "poor"
    CRITICAL = "critical"


class AnomalyType(Enum):
    """Tipos de anomalias"""
    STATISTICAL_OUTLIER = "statistical_outlier"
    PATTERN_DEVIATION = "pattern_deviation"
    VOLUME_ANOMALY = "volume_anomaly"
    FRESHNESS_ISSUE = "freshness_issue"
    SCHEMA_DRIFT = "schema_drift"
    DATA_DRIFT = "data_drift"
    QUALITY_DEGRADATION = "quality_degradation"


@dataclass
class QualityRule:
    """Regra de qualidade de dados"""
    id: str
    name: str
    description: str
    rule_type: QualityRuleType
    dimension: QualityDimension
    table_name: str
    column_name: Optional[str]
    rule_definition: Dict[str, Any]
    threshold: float
    severity: str
    active: bool
    created_at: datetime
    created_by: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        data = asdict(self)
        data['rule_type'] = self.rule_type.value
        data['dimension'] = self.dimension.value
        data['created_at'] = self.created_at.isoformat()
        return data


@dataclass
class QualityResult:
    """Resultado de execução de regra de qualidade"""
    id: str
    rule_id: str
    execution_id: str
    table_name: str
    column_name: Optional[str]
    total_records: int
    passed_records: int
    failed_records: int
    pass_rate: float
    quality_score: float
    status: QualityStatus
    details: Dict[str, Any]
    executed_at: datetime
    execution_time_ms: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        data = asdict(self)
        data['status'] = self.status.value
        data['executed_at'] = self.executed_at.isoformat()
        return data


@dataclass
class DataProfile:
    """Perfil de dados de uma coluna"""
    table_name: str
    column_name: str
    data_type: str
    total_count: int
    null_count: int
    unique_count: int
    min_value: Optional[Any]
    max_value: Optional[Any]
    mean_value: Optional[float]
    median_value: Optional[float]
    std_deviation: Optional[float]
    percentiles: Dict[str, Any]
    top_values: List[Tuple[Any, int]]
    pattern_analysis: Dict[str, Any]
    quality_indicators: Dict[str, float]
    profiled_at: datetime
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        data = asdict(self)
        data['profiled_at'] = self.profiled_at.isoformat()
        return data


class QualityRuleEngine:
    """Engine de execução de regras de qualidade"""
    
    def __init__(self):
        self.rules = {}
        self.rule_executors = {
            QualityRuleType.NULL_CHECK: self._execute_null_check,
            QualityRuleType.RANGE_CHECK: self._execute_range_check,
            QualityRuleType.FORMAT_CHECK: self._execute_format_check,
            QualityRuleType.UNIQUENESS_CHECK: self._execute_uniqueness_check,
            QualityRuleType.REFERENTIAL_INTEGRITY: self._execute_referential_integrity,
            QualityRuleType.BUSINESS_RULE: self._execute_business_rule,
            QualityRuleType.STATISTICAL_OUTLIER: self._execute_statistical_outlier,
            QualityRuleType.PATTERN_MATCH: self._execute_pattern_match,
            QualityRuleType.CROSS_FIELD_VALIDATION: self._execute_cross_field_validation,
            QualityRuleType.TEMPORAL_CONSISTENCY: self._execute_temporal_consistency
        }
    
    def register_rule(self, rule: QualityRule):
        """
        Registra nova regra de qualidade
        
        Args:
            rule: Regra de qualidade
        """
        self.rules[rule.id] = rule
        
        # Registrar evento de auditoria
        audit_logger.log_event({
            "event_type": AuditEventType.CREATE,
            "resource_type": "quality_rule",
            "resource_id": rule.id,
            "action": "rule_registered",
            "details": {
                "rule_name": rule.name,
                "table": rule.table_name,
                "dimension": rule.dimension.value
            }
        })
    
    @trace_operation("quality_engine.execute_rule", "data_quality")
    def execute_rule(self, rule_id: str, data: List[Dict[str, Any]]) -> QualityResult:
        """
        Executa regra de qualidade
        
        Args:
            rule_id: ID da regra
            data: Dados para validar
            
        Returns:
            Resultado da execução
        """
        rule = self.rules.get(rule_id)
        if not rule:
            raise DataGovernanceException(f"Regra não encontrada: {rule_id}")
        
        if not rule.active:
            raise DataGovernanceException(f"Regra inativa: {rule_id}")
        
        start_time = datetime.utcnow()
        
        # Executar regra específica
        executor = self.rule_executors.get(rule.rule_type)
        if not executor:
            raise DataGovernanceException(f"Executor não encontrado para tipo: {rule.rule_type}")
        
        try:
            passed_records, failed_records, details = executor(rule, data)
            
            total_records = len(data)
            pass_rate = (passed_records / total_records * 100) if total_records > 0 else 0
            
            # Calcular score de qualidade
            quality_score = self._calculate_quality_score(pass_rate, rule.threshold)
            
            # Determinar status
            status = self._determine_quality_status(quality_score)
            
            execution_time = (datetime.utcnow() - start_time).total_seconds() * 1000
            
            result = QualityResult(
                id=str(uuid.uuid4()),
                rule_id=rule_id,
                execution_id=str(uuid.uuid4()),
                table_name=rule.table_name,
                column_name=rule.column_name,
                total_records=total_records,
                passed_records=passed_records,
                failed_records=failed_records,
                pass_rate=pass_rate,
                quality_score=quality_score,
                status=status,
                details=details,
                executed_at=start_time,
                execution_time_ms=execution_time
            )
            
            # Registrar métricas
            record_business_metric(
                "quality_rule_execution",
                quality_score,
                tags={
                    "rule_type": rule.rule_type.value,
                    "dimension": rule.dimension.value,
                    "table": rule.table_name
                }
            )
            
            return result
            
        except Exception as e:
            # Registrar erro
            audit_logger.log_event({
                "event_type": AuditEventType.ERROR,
                "resource_type": "quality_rule",
                "resource_id": rule_id,
                "action": "rule_execution_failed",
                "details": {"error": str(e)}
            })
            raise
    
    def _execute_null_check(self, rule: QualityRule, data: List[Dict[str, Any]]) -> Tuple[int, int, Dict[str, Any]]:
        """Executa verificação de nulos"""
        column = rule.column_name
        if not column:
            raise DataGovernanceException("Coluna não especificada para null check")
        
        passed = 0
        failed = 0
        null_positions = []
        
        for i, record in enumerate(data):
            value = record.get(column)
            if value is None or value == "" or (isinstance(value, str) and value.strip() == ""):
                failed += 1
                null_positions.append(i)
            else:
                passed += 1
        
        details = {
            "null_count": failed,
            "null_percentage": (failed / len(data) * 100) if data else 0,
            "null_positions": null_positions[:100]  # Limitar a 100 posições
        }
        
        return passed, failed, details
    
    def _execute_range_check(self, rule: QualityRule, data: List[Dict[str, Any]]) -> Tuple[int, int, Dict[str, Any]]:
        """Executa verificação de faixa de valores"""
        column = rule.column_name
        rule_def = rule.rule_definition
        
        min_val = rule_def.get("min_value")
        max_val = rule_def.get("max_value")
        
        passed = 0
        failed = 0
        violations = []
        
        for record in data:
            value = record.get(column)
            
            if value is None:
                continue  # Pular valores nulos
            
            try:
                numeric_value = float(value)
                
                is_valid = True
                if min_val is not None and numeric_value < min_val:
                    is_valid = False
                if max_val is not None and numeric_value > max_val:
                    is_valid = False
                
                if is_valid:
                    passed += 1
                else:
                    failed += 1
                    violations.append({
                        "value": value,
                        "min_allowed": min_val,
                        "max_allowed": max_val
                    })
                    
            except (ValueError, TypeError):
                failed += 1
                violations.append({
                    "value": value,
                    "error": "Non-numeric value"
                })
        
        details = {
            "range": {"min": min_val, "max": max_val},
            "violations": violations[:50],  # Limitar a 50 violações
            "violation_count": len(violations)
        }
        
        return passed, failed, details
    
    def _execute_format_check(self, rule: QualityRule, data: List[Dict[str, Any]]) -> Tuple[int, int, Dict[str, Any]]:
        """Executa verificação de formato"""
        column = rule.column_name
        pattern = rule.rule_definition.get("pattern")
        
        if not pattern:
            raise DataGovernanceException("Padrão não especificado para format check")
        
        regex = re.compile(pattern)
        passed = 0
        failed = 0
        violations = []
        
        for record in data:
            value = record.get(column)
            
            if value is None:
                continue
            
            str_value = str(value)
            if regex.match(str_value):
                passed += 1
            else:
                failed += 1
                violations.append({
                    "value": str_value,
                    "expected_pattern": pattern
                })
        
        details = {
            "pattern": pattern,
            "violations": violations[:50],
            "violation_count": len(violations)
        }
        
        return passed, failed, details
    
    def _execute_uniqueness_check(self, rule: QualityRule, data: List[Dict[str, Any]]) -> Tuple[int, int, Dict[str, Any]]:
        """Executa verificação de unicidade"""
        column = rule.column_name
        
        values = []
        for record in data:
            value = record.get(column)
            if value is not None:
                values.append(value)
        
        value_counts = Counter(values)
        duplicates = {k: v for k, v in value_counts.items() if v > 1}
        
        unique_values = len(value_counts)
        total_values = len(values)
        duplicate_count = sum(count - 1 for count in duplicates.values())
        
        passed = total_values - duplicate_count
        failed = duplicate_count
        
        details = {
            "total_values": total_values,
            "unique_values": unique_values,
            "duplicate_values": list(duplicates.keys())[:20],
            "uniqueness_percentage": (unique_values / total_values * 100) if total_values > 0 else 0
        }
        
        return passed, failed, details
    
    def _execute_referential_integrity(self, rule: QualityRule, data: List[Dict[str, Any]]) -> Tuple[int, int, Dict[str, Any]]:
        """Executa verificação de integridade referencial"""
        column = rule.column_name
        reference_values = set(rule.rule_definition.get("reference_values", []))
        
        passed = 0
        failed = 0
        orphaned_values = []
        
        for record in data:
            value = record.get(column)
            
            if value is None:
                continue
            
            if value in reference_values:
                passed += 1
            else:
                failed += 1
                orphaned_values.append(value)
        
        details = {
            "reference_count": len(reference_values),
            "orphaned_values": list(set(orphaned_values))[:50],
            "orphaned_count": len(set(orphaned_values))
        }
        
        return passed, failed, details
    
    def _execute_business_rule(self, rule: QualityRule, data: List[Dict[str, Any]]) -> Tuple[int, int, Dict[str, Any]]:
        """Executa regra de negócio customizada"""
        rule_expression = rule.rule_definition.get("expression")
        
        if not rule_expression:
            raise DataGovernanceException("Expressão não especificada para business rule")
        
        passed = 0
        failed = 0
        violations = []
        
        for record in data:
            try:
                # Avaliar expressão (implementação simplificada)
                # Em produção, usar parser seguro
                result = self._evaluate_business_rule(rule_expression, record)
                
                if result:
                    passed += 1
                else:
                    failed += 1
                    violations.append({
                        "record": record,
                        "expression": rule_expression
                    })
                    
            except Exception as e:
                failed += 1
                violations.append({
                    "record": record,
                    "error": str(e)
                })
        
        details = {
            "expression": rule_expression,
            "violations": violations[:20],
            "violation_count": len(violations)
        }
        
        return passed, failed, details
    
    def _execute_statistical_outlier(self, rule: QualityRule, data: List[Dict[str, Any]]) -> Tuple[int, int, Dict[str, Any]]:
        """Executa detecção de outliers estatísticos"""
        column = rule.column_name
        method = rule.rule_definition.get("method", "iqr")
        
        values = []
        for record in data:
            value = record.get(column)
            if value is not None:
                try:
                    values.append(float(value))
                except (ValueError, TypeError):
                    continue
        
        if len(values) < 4:
            return len(data), 0, {"error": "Dados insuficientes para análise estatística"}
        
        outliers = self._detect_outliers(values, method)
        
        passed = len(values) - len(outliers)
        failed = len(outliers)
        
        details = {
            "method": method,
            "outlier_values": outliers[:50],
            "outlier_count": len(outliers),
            "statistics": {
                "mean": statistics.mean(values),
                "median": statistics.median(values),
                "std_dev": statistics.stdev(values) if len(values) > 1 else 0
            }
        }
        
        return passed, failed, details
    
    def _execute_pattern_match(self, rule: QualityRule, data: List[Dict[str, Any]]) -> Tuple[int, int, Dict[str, Any]]:
        """Executa verificação de padrão"""
        return self._execute_format_check(rule, data)  # Mesmo que format check
    
    def _execute_cross_field_validation(self, rule: QualityRule, data: List[Dict[str, Any]]) -> Tuple[int, int, Dict[str, Any]]:
        """Executa validação entre campos"""
        validation_rules = rule.rule_definition.get("validations", [])
        
        passed = 0
        failed = 0
        violations = []
        
        for record in data:
            record_valid = True
            record_violations = []
            
            for validation in validation_rules:
                field1 = validation.get("field1")
                field2 = validation.get("field2")
                operator = validation.get("operator")
                
                value1 = record.get(field1)
                value2 = record.get(field2)
                
                if not self._compare_values(value1, value2, operator):
                    record_valid = False
                    record_violations.append({
                        "field1": field1,
                        "value1": value1,
                        "field2": field2,
                        "value2": value2,
                        "operator": operator
                    })
            
            if record_valid:
                passed += 1
            else:
                failed += 1
                violations.extend(record_violations)
        
        details = {
            "validations": validation_rules,
            "violations": violations[:50],
            "violation_count": len(violations)
        }
        
        return passed, failed, details
    
    def _execute_temporal_consistency(self, rule: QualityRule, data: List[Dict[str, Any]]) -> Tuple[int, int, Dict[str, Any]]:
        """Executa verificação de consistência temporal"""
        date_field = rule.rule_definition.get("date_field")
        max_age_days = rule.rule_definition.get("max_age_days", 365)
        
        current_date = datetime.utcnow()
        passed = 0
        failed = 0
        violations = []
        
        for record in data:
            date_value = record.get(date_field)
            
            if date_value is None:
                continue
            
            try:
                if isinstance(date_value, str):
                    record_date = datetime.fromisoformat(date_value.replace('Z', '+00:00'))
                elif isinstance(date_value, datetime):
                    record_date = date_value
                else:
                    failed += 1
                    violations.append({
                        "value": date_value,
                        "error": "Invalid date format"
                    })
                    continue
                
                age_days = (current_date - record_date).days
                
                if age_days <= max_age_days:
                    passed += 1
                else:
                    failed += 1
                    violations.append({
                        "date": date_value,
                        "age_days": age_days,
                        "max_allowed": max_age_days
                    })
                    
            except Exception as e:
                failed += 1
                violations.append({
                    "value": date_value,
                    "error": str(e)
                })
        
        details = {
            "max_age_days": max_age_days,
            "violations": violations[:50],
            "violation_count": len(violations)
        }
        
        return passed, failed, details
    
    def _evaluate_business_rule(self, expression: str, record: Dict[str, Any]) -> bool:
        """Avalia regra de negócio (implementação simplificada)"""
        # Implementação simplificada - em produção usar parser seguro
        try:
            # Substituir variáveis na expressão
            for key, value in record.items():
                if isinstance(value, str):
                    expression = expression.replace(f"{{{key}}}", f"'{value}'")
                else:
                    expression = expression.replace(f"{{{key}}}", str(value))
            
            # Avaliar expressão simples
            return eval(expression)
        except:
            return False
    
    def _detect_outliers(self, values: List[float], method: str) -> List[float]:
        """Detecta outliers usando método especificado"""
        if method == "iqr":
            q1 = statistics.quantiles(values, n=4)[0]
            q3 = statistics.quantiles(values, n=4)[2]
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            
            return [v for v in values if v < lower_bound or v > upper_bound]
        
        elif method == "zscore":
            mean = statistics.mean(values)
            std_dev = statistics.stdev(values) if len(values) > 1 else 0
            
            if std_dev == 0:
                return []
            
            return [v for v in values if abs((v - mean) / std_dev) > 3]
        
        return []
    
    def _compare_values(self, value1: Any, value2: Any, operator: str) -> bool:
        """Compara valores usando operador especificado"""
        try:
            if operator == "eq":
                return value1 == value2
            elif operator == "ne":
                return value1 != value2
            elif operator == "gt":
                return float(value1) > float(value2)
            elif operator == "gte":
                return float(value1) >= float(value2)
            elif operator == "lt":
                return float(value1) < float(value2)
            elif operator == "lte":
                return float(value1) <= float(value2)
            else:
                return False
        except:
            return False
    
    def _calculate_quality_score(self, pass_rate: float, threshold: float) -> float:
        """Calcula score de qualidade"""
        if pass_rate >= threshold:
            # Score entre 70-100 para dados que passam no threshold
            return 70 + (pass_rate - threshold) / (100 - threshold) * 30
        else:
            # Score entre 0-70 para dados que não passam no threshold
            return (pass_rate / threshold) * 70
    
    def _determine_quality_status(self, quality_score: float) -> QualityStatus:
        """Determina status de qualidade baseado no score"""
        if quality_score >= 90:
            return QualityStatus.EXCELLENT
        elif quality_score >= 80:
            return QualityStatus.GOOD
        elif quality_score >= 60:
            return QualityStatus.FAIR
        elif quality_score >= 40:
            return QualityStatus.POOR
        else:
            return QualityStatus.CRITICAL


class DataProfiler:
    """Profiler de dados para análise automática"""
    
    @trace_operation("data_profiler.profile_data", "data_quality")
    def profile_data(self, 
                    table_name: str,
                    data: List[Dict[str, Any]],
                    columns: Optional[List[str]] = None) -> List[DataProfile]:
        """
        Perfila dados de uma tabela
        
        Args:
            table_name: Nome da tabela
            data: Dados para perfilar
            columns: Colunas específicas (todas se None)
            
        Returns:
            Lista de perfis de dados
        """
        if not data:
            return []
        
        # Determinar colunas para perfilar
        if columns is None:
            columns = list(data[0].keys())
        
        profiles = []
        
        for column in columns:
            profile = self._profile_column(table_name, column, data)
            profiles.append(profile)
        
        return profiles
    
    def _profile_column(self, 
                       table_name: str,
                       column_name: str,
                       data: List[Dict[str, Any]]) -> DataProfile:
        """Perfila uma coluna específica"""
        values = [record.get(column_name) for record in data]
        non_null_values = [v for v in values if v is not None]
        
        # Estatísticas básicas
        total_count = len(values)
        null_count = total_count - len(non_null_values)
        unique_values = list(set(non_null_values))
        unique_count = len(unique_values)
        
        # Determinar tipo de dados
        data_type = self._infer_data_type(non_null_values)
        
        # Estatísticas numéricas
        min_value = None
        max_value = None
        mean_value = None
        median_value = None
        std_deviation = None
        percentiles = {}
        
        if data_type in ["integer", "float"] and non_null_values:
            try:
                numeric_values = [float(v) for v in non_null_values if v is not None]
                if numeric_values:
                    min_value = min(numeric_values)
                    max_value = max(numeric_values)
                    mean_value = statistics.mean(numeric_values)
                    median_value = statistics.median(numeric_values)
                    
                    if len(numeric_values) > 1:
                        std_deviation = statistics.stdev(numeric_values)
                    
                    # Calcular percentis
                    if len(numeric_values) >= 4:
                        quantiles = statistics.quantiles(numeric_values, n=100)
                        percentiles = {
                            "p25": quantiles[24],
                            "p50": median_value,
                            "p75": quantiles[74],
                            "p90": quantiles[89],
                            "p95": quantiles[94],
                            "p99": quantiles[98]
                        }
            except:
                pass
        
        # Valores mais frequentes
        value_counts = Counter(non_null_values)
        top_values = value_counts.most_common(10)
        
        # Análise de padrões
        pattern_analysis = self._analyze_patterns(non_null_values, data_type)
        
        # Indicadores de qualidade
        quality_indicators = self._calculate_quality_indicators(
            total_count, null_count, unique_count, non_null_values, data_type
        )
        
        return DataProfile(
            table_name=table_name,
            column_name=column_name,
            data_type=data_type,
            total_count=total_count,
            null_count=null_count,
            unique_count=unique_count,
            min_value=min_value,
            max_value=max_value,
            mean_value=mean_value,
            median_value=median_value,
            std_deviation=std_deviation,
            percentiles=percentiles,
            top_values=top_values,
            pattern_analysis=pattern_analysis,
            quality_indicators=quality_indicators,
            profiled_at=datetime.utcnow()
        )
    
    def _infer_data_type(self, values: List[Any]) -> str:
        """Infere tipo de dados baseado nos valores"""
        if not values:
            return "unknown"
        
        # Verificar se todos são números
        numeric_count = 0
        integer_count = 0
        
        for value in values[:100]:  # Analisar até 100 valores
            if value is None:
                continue
            
            try:
                float_val = float(value)
                numeric_count += 1
                
                if float_val.is_integer():
                    integer_count += 1
            except:
                pass
        
        total_checked = min(len(values), 100)
        
        if numeric_count / total_checked > 0.8:
            if integer_count / numeric_count > 0.9:
                return "integer"
            else:
                return "float"
        
        # Verificar se são datas
        date_count = 0
        for value in values[:50]:
            if self._is_date_like(str(value)):
                date_count += 1
        
        if date_count / min(len(values), 50) > 0.8:
            return "datetime"
        
        # Verificar se são booleanos
        boolean_values = {"true", "false", "1", "0", "yes", "no", "y", "n"}
        boolean_count = 0
        
        for value in values[:50]:
            if str(value).lower() in boolean_values:
                boolean_count += 1
        
        if boolean_count / min(len(values), 50) > 0.8:
            return "boolean"
        
        return "string"
    
    def _is_date_like(self, value: str) -> bool:
        """Verifica se valor parece uma data"""
        date_patterns = [
            r'\d{4}-\d{2}-\d{2}',
            r'\d{2}/\d{2}/\d{4}',
            r'\d{2}-\d{2}-\d{4}',
            r'\d{4}/\d{2}/\d{2}'
        ]
        
        for pattern in date_patterns:
            if re.match(pattern, value):
                return True
        
        return False
    
    def _analyze_patterns(self, values: List[Any], data_type: str) -> Dict[str, Any]:
        """Analisa padrões nos dados"""
        if not values:
            return {}
        
        analysis = {}
        
        if data_type == "string":
            # Análise de comprimento
            lengths = [len(str(v)) for v in values if v is not None]
            if lengths:
                analysis["length"] = {
                    "min": min(lengths),
                    "max": max(lengths),
                    "avg": sum(lengths) / len(lengths),
                    "most_common": Counter(lengths).most_common(5)
                }
            
            # Análise de padrões comuns
            patterns = {
                "email": r'^[\w\.-]+@[\w\.-]+\.\w+$',
                "phone": r'^\(?\d{2}\)?\s?\d{4,5}-?\d{4}$',
                "cpf": r'^\d{3}\.?\d{3}\.?\d{3}-?\d{2}$',
                "cnpj": r'^\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}$',
                "cep": r'^\d{5}-?\d{3}$'
            }
            
            pattern_matches = {}
            for pattern_name, pattern in patterns.items():
                matches = sum(1 for v in values[:100] if re.match(pattern, str(v)))
                if matches > 0:
                    pattern_matches[pattern_name] = {
                        "matches": matches,
                        "percentage": matches / min(len(values), 100) * 100
                    }
            
            analysis["patterns"] = pattern_matches
        
        elif data_type in ["integer", "float"]:
            # Análise de distribuição
            try:
                numeric_values = [float(v) for v in values if v is not None]
                if len(numeric_values) > 1:
                    analysis["distribution"] = {
                        "skewness": self._calculate_skewness(numeric_values),
                        "kurtosis": self._calculate_kurtosis(numeric_values)
                    }
            except:
                pass
        
        return analysis
    
    def _calculate_quality_indicators(self, 
                                    total_count: int,
                                    null_count: int,
                                    unique_count: int,
                                    non_null_values: List[Any],
                                    data_type: str) -> Dict[str, float]:
        """Calcula indicadores de qualidade"""
        indicators = {}
        
        # Completude
        indicators["completeness"] = ((total_count - null_count) / total_count * 100) if total_count > 0 else 0
        
        # Unicidade
        indicators["uniqueness"] = (unique_count / len(non_null_values) * 100) if non_null_values else 0
        
        # Consistência (baseada em padrões)
        if data_type == "string" and non_null_values:
            # Verificar consistência de formato
            lengths = [len(str(v)) for v in non_null_values]
            length_consistency = 1 - (statistics.stdev(lengths) / statistics.mean(lengths)) if len(lengths) > 1 and statistics.mean(lengths) > 0 else 1
            indicators["consistency"] = max(0, length_consistency * 100)
        else:
            indicators["consistency"] = 100  # Assumir consistente para tipos não-string
        
        # Validade (baseada em tipo de dados)
        if data_type in ["integer", "float"]:
            # Para numéricos, verificar se todos são válidos
            valid_count = 0
            for value in non_null_values:
                try:
                    float(value)
                    valid_count += 1
                except:
                    pass
            indicators["validity"] = (valid_count / len(non_null_values) * 100) if non_null_values else 0
        else:
            indicators["validity"] = 100  # Assumir válido para outros tipos
        
        return indicators
    
    def _calculate_skewness(self, values: List[float]) -> float:
        """Calcula assimetria da distribuição"""
        if len(values) < 3:
            return 0
        
        mean = statistics.mean(values)
        std_dev = statistics.stdev(values)
        
        if std_dev == 0:
            return 0
        
        n = len(values)
        skewness = sum(((x - mean) / std_dev) ** 3 for x in values) / n
        
        return skewness
    
    def _calculate_kurtosis(self, values: List[float]) -> float:
        """Calcula curtose da distribuição"""
        if len(values) < 4:
            return 0
        
        mean = statistics.mean(values)
        std_dev = statistics.stdev(values)
        
        if std_dev == 0:
            return 0
        
        n = len(values)
        kurtosis = sum(((x - mean) / std_dev) ** 4 for x in values) / n - 3
        
        return kurtosis


class AnomalyDetector:
    """Detector de anomalias em dados"""
    
    def __init__(self):
        self.baseline_profiles = {}
    
    @trace_operation("anomaly_detector.detect_anomalies", "data_quality")
    def detect_anomalies(self, 
                        table_name: str,
                        current_profile: DataProfile,
                        baseline_profile: Optional[DataProfile] = None) -> List[Dict[str, Any]]:
        """
        Detecta anomalias comparando perfis
        
        Args:
            table_name: Nome da tabela
            current_profile: Perfil atual
            baseline_profile: Perfil de baseline
            
        Returns:
            Lista de anomalias detectadas
        """
        anomalies = []
        
        if baseline_profile is None:
            baseline_profile = self.baseline_profiles.get(f"{table_name}.{current_profile.column_name}")
        
        if baseline_profile is None:
            # Primeira execução - salvar como baseline
            self.baseline_profiles[f"{table_name}.{current_profile.column_name}"] = current_profile
            return anomalies
        
        # Detectar anomalias de volume
        volume_anomalies = self._detect_volume_anomalies(current_profile, baseline_profile)
        anomalies.extend(volume_anomalies)
        
        # Detectar anomalias de qualidade
        quality_anomalies = self._detect_quality_anomalies(current_profile, baseline_profile)
        anomalies.extend(quality_anomalies)
        
        # Detectar anomalias estatísticas
        statistical_anomalies = self._detect_statistical_anomalies(current_profile, baseline_profile)
        anomalies.extend(statistical_anomalies)
        
        # Detectar drift de dados
        drift_anomalies = self._detect_data_drift(current_profile, baseline_profile)
        anomalies.extend(drift_anomalies)
        
        return anomalies
    
    def _detect_volume_anomalies(self, current: DataProfile, baseline: DataProfile) -> List[Dict[str, Any]]:
        """Detecta anomalias de volume"""
        anomalies = []
        
        # Verificar mudança significativa no volume
        volume_change = abs(current.total_count - baseline.total_count) / baseline.total_count if baseline.total_count > 0 else 0
        
        if volume_change > 0.5:  # Mudança de mais de 50%
            anomalies.append({
                "type": AnomalyType.VOLUME_ANOMALY.value,
                "severity": "high" if volume_change > 0.8 else "medium",
                "description": f"Volume de dados mudou {volume_change:.1%}",
                "current_value": current.total_count,
                "baseline_value": baseline.total_count,
                "change_percentage": volume_change * 100
            })
        
        return anomalies
    
    def _detect_quality_anomalies(self, current: DataProfile, baseline: DataProfile) -> List[Dict[str, Any]]:
        """Detecta anomalias de qualidade"""
        anomalies = []
        
        # Verificar degradação de completude
        current_completeness = current.quality_indicators.get("completeness", 0)
        baseline_completeness = baseline.quality_indicators.get("completeness", 0)
        
        completeness_drop = baseline_completeness - current_completeness
        
        if completeness_drop > 10:  # Queda de mais de 10%
            anomalies.append({
                "type": AnomalyType.QUALITY_DEGRADATION.value,
                "severity": "high" if completeness_drop > 25 else "medium",
                "description": f"Completude caiu {completeness_drop:.1f}%",
                "metric": "completeness",
                "current_value": current_completeness,
                "baseline_value": baseline_completeness
            })
        
        # Verificar mudança na unicidade
        current_uniqueness = current.quality_indicators.get("uniqueness", 0)
        baseline_uniqueness = baseline.quality_indicators.get("uniqueness", 0)
        
        uniqueness_change = abs(current_uniqueness - baseline_uniqueness)
        
        if uniqueness_change > 15:  # Mudança de mais de 15%
            anomalies.append({
                "type": AnomalyType.QUALITY_DEGRADATION.value,
                "severity": "medium",
                "description": f"Unicidade mudou {uniqueness_change:.1f}%",
                "metric": "uniqueness",
                "current_value": current_uniqueness,
                "baseline_value": baseline_uniqueness
            })
        
        return anomalies
    
    def _detect_statistical_anomalies(self, current: DataProfile, baseline: DataProfile) -> List[Dict[str, Any]]:
        """Detecta anomalias estatísticas"""
        anomalies = []
        
        # Verificar mudanças em estatísticas numéricas
        if current.mean_value is not None and baseline.mean_value is not None:
            mean_change = abs(current.mean_value - baseline.mean_value) / abs(baseline.mean_value) if baseline.mean_value != 0 else 0
            
            if mean_change > 0.3:  # Mudança de mais de 30%
                anomalies.append({
                    "type": AnomalyType.STATISTICAL_OUTLIER.value,
                    "severity": "medium",
                    "description": f"Média mudou {mean_change:.1%}",
                    "metric": "mean",
                    "current_value": current.mean_value,
                    "baseline_value": baseline.mean_value
                })
        
        # Verificar mudanças no desvio padrão
        if current.std_deviation is not None and baseline.std_deviation is not None:
            std_change = abs(current.std_deviation - baseline.std_deviation) / baseline.std_deviation if baseline.std_deviation != 0 else 0
            
            if std_change > 0.5:  # Mudança de mais de 50%
                anomalies.append({
                    "type": AnomalyType.STATISTICAL_OUTLIER.value,
                    "severity": "medium",
                    "description": f"Desvio padrão mudou {std_change:.1%}",
                    "metric": "std_deviation",
                    "current_value": current.std_deviation,
                    "baseline_value": baseline.std_deviation
                })
        
        return anomalies
    
    def _detect_data_drift(self, current: DataProfile, baseline: DataProfile) -> List[Dict[str, Any]]:
        """Detecta drift de dados"""
        anomalies = []
        
        # Verificar mudança nos valores mais frequentes
        current_top = dict(current.top_values[:5])
        baseline_top = dict(baseline.top_values[:5])
        
        # Calcular sobreposição
        common_values = set(current_top.keys()) & set(baseline_top.keys())
        total_unique = set(current_top.keys()) | set(baseline_top.keys())
        
        if total_unique:
            overlap_ratio = len(common_values) / len(total_unique)
            
            if overlap_ratio < 0.5:  # Menos de 50% de sobreposição
                anomalies.append({
                    "type": AnomalyType.DATA_DRIFT.value,
                    "severity": "high" if overlap_ratio < 0.3 else "medium",
                    "description": f"Drift detectado: {overlap_ratio:.1%} de sobreposição nos valores frequentes",
                    "overlap_ratio": overlap_ratio,
                    "current_top_values": list(current_top.keys()),
                    "baseline_top_values": list(baseline_top.keys())
                })
        
        return anomalies


# Instâncias globais
quality_rule_engine = QualityRuleEngine()
data_profiler = DataProfiler()
anomaly_detector = AnomalyDetector()


# Funções de conveniência
def create_quality_rule(name: str,
                       rule_type: QualityRuleType,
                       dimension: QualityDimension,
                       table_name: str,
                       column_name: str,
                       rule_definition: Dict[str, Any],
                       threshold: float = 95.0,
                       severity: str = "medium") -> str:
    """
    Cria nova regra de qualidade
    
    Args:
        name: Nome da regra
        rule_type: Tipo da regra
        dimension: Dimensão de qualidade
        table_name: Nome da tabela
        column_name: Nome da coluna
        rule_definition: Definição da regra
        threshold: Threshold de aprovação
        severity: Severidade
        
    Returns:
        ID da regra criada
    """
    rule_id = str(uuid.uuid4())
    
    rule = QualityRule(
        id=rule_id,
        name=name,
        description=f"Regra de {dimension.value} para {table_name}.{column_name}",
        rule_type=rule_type,
        dimension=dimension,
        table_name=table_name,
        column_name=column_name,
        rule_definition=rule_definition,
        threshold=threshold,
        severity=severity,
        active=True,
        created_at=datetime.utcnow(),
        created_by="system"
    )
    
    quality_rule_engine.register_rule(rule)
    return rule_id


def execute_quality_check(rule_id: str, data: List[Dict[str, Any]]) -> QualityResult:
    """
    Executa verificação de qualidade
    
    Args:
        rule_id: ID da regra
        data: Dados para verificar
        
    Returns:
        Resultado da verificação
    """
    return quality_rule_engine.execute_rule(rule_id, data)


def profile_table_data(table_name: str, 
                      data: List[Dict[str, Any]],
                      columns: Optional[List[str]] = None) -> List[DataProfile]:
    """
    Perfila dados de uma tabela
    
    Args:
        table_name: Nome da tabela
        data: Dados para perfilar
        columns: Colunas específicas
        
    Returns:
        Lista de perfis
    """
    return data_profiler.profile_data(table_name, data, columns)


def detect_data_anomalies(table_name: str, 
                         current_profile: DataProfile,
                         baseline_profile: Optional[DataProfile] = None) -> List[Dict[str, Any]]:
    """
    Detecta anomalias nos dados
    
    Args:
        table_name: Nome da tabela
        current_profile: Perfil atual
        baseline_profile: Perfil de baseline
        
    Returns:
        Lista de anomalias
    """
    return anomaly_detector.detect_anomalies(table_name, current_profile, baseline_profile)

