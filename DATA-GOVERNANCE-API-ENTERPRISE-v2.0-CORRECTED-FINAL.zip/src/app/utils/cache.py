"""
Sistema de Cache para Data Governance API
Autor: Carlos Morais

Sistema de cache distribuído com suporte a Redis,
invalidação inteligente e métricas de performance.
"""

import json
import hashlib
import time
from typing import Any, Dict, List, Optional, Union, Callable
from datetime import datetime, timedelta
from functools import wraps
import redis
from redis.exceptions import ConnectionError, TimeoutError

from .exceptions import CacheError
from .monitoring import metrics_collector


class CacheManager:
    """Gerenciador de cache distribuído"""
    
    def __init__(self, redis_url: str = "redis://localhost:6379", default_ttl: int = 3600):
        """
        Inicializa gerenciador de cache
        
        Args:
            redis_url: URL do Redis
            default_ttl: TTL padrão em segundos
        """
        self.default_ttl = default_ttl
        self.redis_client = None
        self.fallback_cache = {}  # Cache em memória como fallback
        
        try:
            self.redis_client = redis.from_url(redis_url, decode_responses=True)
            # Testar conexão
            self.redis_client.ping()
        except (ConnectionError, TimeoutError):
            print("Warning: Redis não disponível, usando cache em memória")
    
    def _get_key(self, namespace: str, key: str) -> str:
        """
        Gera chave completa do cache
        
        Args:
            namespace: Namespace do cache
            key: Chave específica
            
        Returns:
            Chave completa
        """
        return f"dg_cache:{namespace}:{key}"
    
    def _serialize_value(self, value: Any) -> str:
        """
        Serializa valor para armazenamento
        
        Args:
            value: Valor para serializar
            
        Returns:
            Valor serializado
        """
        return json.dumps(value, default=str, ensure_ascii=False)
    
    def _deserialize_value(self, value: str) -> Any:
        """
        Deserializa valor do cache
        
        Args:
            value: Valor serializado
            
        Returns:
            Valor deserializado
        """
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    
    def get(self, namespace: str, key: str) -> Optional[Any]:
        """
        Obtém valor do cache
        
        Args:
            namespace: Namespace do cache
            key: Chave do valor
            
        Returns:
            Valor do cache ou None se não encontrado
        """
        cache_key = self._get_key(namespace, key)
        
        try:
            if self.redis_client:
                value = self.redis_client.get(cache_key)
                if value is not None:
                    metrics_collector.increment_counter("cache.hit", tags={"namespace": namespace})
                    return self._deserialize_value(value)
            else:
                # Fallback para cache em memória
                cache_entry = self.fallback_cache.get(cache_key)
                if cache_entry and cache_entry["expires_at"] > time.time():
                    metrics_collector.increment_counter("cache.hit", tags={"namespace": namespace})
                    return cache_entry["value"]
                elif cache_entry:
                    # Remover entrada expirada
                    del self.fallback_cache[cache_key]
            
            metrics_collector.increment_counter("cache.miss", tags={"namespace": namespace})
            return None
            
        except Exception as e:
            metrics_collector.increment_counter("cache.error", tags={"namespace": namespace})
            raise CacheError("get", cache_key, str(e))
    
    def set(self, namespace: str, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """
        Define valor no cache
        
        Args:
            namespace: Namespace do cache
            key: Chave do valor
            value: Valor para armazenar
            ttl: TTL em segundos (usa padrão se None)
            
        Returns:
            True se sucesso
        """
        cache_key = self._get_key(namespace, key)
        ttl = ttl or self.default_ttl
        
        try:
            serialized_value = self._serialize_value(value)
            
            if self.redis_client:
                result = self.redis_client.setex(cache_key, ttl, serialized_value)
                metrics_collector.increment_counter("cache.set", tags={"namespace": namespace})
                return result
            else:
                # Fallback para cache em memória
                self.fallback_cache[cache_key] = {
                    "value": value,
                    "expires_at": time.time() + ttl
                }
                metrics_collector.increment_counter("cache.set", tags={"namespace": namespace})
                return True
                
        except Exception as e:
            metrics_collector.increment_counter("cache.error", tags={"namespace": namespace})
            raise CacheError("set", cache_key, str(e))
    
    def delete(self, namespace: str, key: str) -> bool:
        """
        Remove valor do cache
        
        Args:
            namespace: Namespace do cache
            key: Chave do valor
            
        Returns:
            True se removido
        """
        cache_key = self._get_key(namespace, key)
        
        try:
            if self.redis_client:
                result = self.redis_client.delete(cache_key) > 0
            else:
                result = cache_key in self.fallback_cache
                if result:
                    del self.fallback_cache[cache_key]
            
            if result:
                metrics_collector.increment_counter("cache.delete", tags={"namespace": namespace})
            
            return result
            
        except Exception as e:
            metrics_collector.increment_counter("cache.error", tags={"namespace": namespace})
            raise CacheError("delete", cache_key, str(e))
    
    def invalidate_pattern(self, namespace: str, pattern: str) -> int:
        """
        Invalida chaves que correspondem ao padrão
        
        Args:
            namespace: Namespace do cache
            pattern: Padrão para busca (ex: "user:*")
            
        Returns:
            Número de chaves removidas
        """
        search_pattern = self._get_key(namespace, pattern)
        
        try:
            if self.redis_client:
                keys = self.redis_client.keys(search_pattern)
                if keys:
                    deleted = self.redis_client.delete(*keys)
                    metrics_collector.increment_counter("cache.invalidate", 
                                                      value=deleted, 
                                                      tags={"namespace": namespace})
                    return deleted
                return 0
            else:
                # Fallback para cache em memória
                prefix = self._get_key(namespace, "")
                pattern_key = pattern.replace("*", "")
                keys_to_delete = [
                    key for key in self.fallback_cache.keys()
                    if key.startswith(prefix) and pattern_key in key
                ]
                
                for key in keys_to_delete:
                    del self.fallback_cache[key]
                
                metrics_collector.increment_counter("cache.invalidate", 
                                                  value=len(keys_to_delete), 
                                                  tags={"namespace": namespace})
                return len(keys_to_delete)
                
        except Exception as e:
            metrics_collector.increment_counter("cache.error", tags={"namespace": namespace})
            raise CacheError("invalidate_pattern", search_pattern, str(e))
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Obtém estatísticas do cache
        
        Returns:
            Estatísticas do cache
        """
        try:
            if self.redis_client:
                info = self.redis_client.info()
                return {
                    "type": "redis",
                    "connected": True,
                    "memory_usage_mb": info.get("used_memory", 0) / 1024 / 1024,
                    "total_keys": info.get("db0", {}).get("keys", 0),
                    "hit_rate": self._calculate_hit_rate(),
                    "uptime_seconds": info.get("uptime_in_seconds", 0)
                }
            else:
                return {
                    "type": "memory",
                    "connected": True,
                    "total_keys": len(self.fallback_cache),
                    "hit_rate": self._calculate_hit_rate(),
                    "memory_usage_mb": 0  # Não calculado para cache em memória
                }
                
        except Exception as e:
            return {
                "type": "unknown",
                "connected": False,
                "error": str(e),
                "hit_rate": 0
            }
    
    def _calculate_hit_rate(self) -> float:
        """
        Calcula taxa de hit do cache
        
        Returns:
            Taxa de hit em percentual
        """
        metrics = metrics_collector.get_metrics()
        counters = metrics.get("counters", {})
        
        total_hits = sum(v for k, v in counters.items() if "cache.hit" in k)
        total_misses = sum(v for k, v in counters.items() if "cache.miss" in k)
        total_requests = total_hits + total_misses
        
        if total_requests == 0:
            return 0.0
        
        return (total_hits / total_requests) * 100


class CacheDecorator:
    """Decorator para cache automático de funções"""
    
    def __init__(self, cache_manager: CacheManager):
        self.cache_manager = cache_manager
    
    def cached(self, namespace: str, ttl: Optional[int] = None, 
               key_func: Optional[Callable] = None):
        """
        Decorator para cache de função
        
        Args:
            namespace: Namespace do cache
            ttl: TTL em segundos
            key_func: Função para gerar chave customizada
        """
        def decorator(func: Callable):
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Gerar chave do cache
                if key_func:
                    cache_key = key_func(*args, **kwargs)
                else:
                    cache_key = self._generate_key(func.__name__, args, kwargs)
                
                # Tentar obter do cache
                cached_result = self.cache_manager.get(namespace, cache_key)
                if cached_result is not None:
                    return cached_result
                
                # Executar função e armazenar resultado
                result = func(*args, **kwargs)
                self.cache_manager.set(namespace, cache_key, result, ttl)
                
                return result
            
            return wrapper
        return decorator
    
    def _generate_key(self, func_name: str, args: tuple, kwargs: dict) -> str:
        """
        Gera chave do cache baseada nos argumentos
        
        Args:
            func_name: Nome da função
            args: Argumentos posicionais
            kwargs: Argumentos nomeados
            
        Returns:
            Chave do cache
        """
        # Criar string única baseada nos argumentos
        key_data = {
            "func": func_name,
            "args": args,
            "kwargs": sorted(kwargs.items())
        }
        
        key_str = json.dumps(key_data, default=str, sort_keys=True)
        return hashlib.md5(key_str.encode()).hexdigest()


class SmartCache:
    """Cache inteligente com invalidação automática"""
    
    def __init__(self, cache_manager: CacheManager):
        self.cache_manager = cache_manager
        self.dependencies = {}  # Mapeamento de dependências
    
    def set_with_dependencies(self, namespace: str, key: str, value: Any, 
                            dependencies: List[str], ttl: Optional[int] = None):
        """
        Define valor com dependências para invalidação automática
        
        Args:
            namespace: Namespace do cache
            key: Chave do valor
            value: Valor para armazenar
            dependencies: Lista de dependências
            ttl: TTL em segundos
        """
        # Armazenar valor
        self.cache_manager.set(namespace, key, value, ttl)
        
        # Registrar dependências
        cache_key = self.cache_manager._get_key(namespace, key)
        self.dependencies[cache_key] = dependencies
    
    def invalidate_by_dependency(self, dependency: str):
        """
        Invalida todas as chaves que dependem de um recurso
        
        Args:
            dependency: Dependência que mudou
        """
        keys_to_invalidate = []
        
        for cache_key, deps in self.dependencies.items():
            if dependency in deps:
                keys_to_invalidate.append(cache_key)
        
        # Invalidar chaves
        for cache_key in keys_to_invalidate:
            # Extrair namespace e key da chave completa
            parts = cache_key.split(":", 2)
            if len(parts) == 3:
                namespace = parts[1]
                key = parts[2]
                self.cache_manager.delete(namespace, key)
                del self.dependencies[cache_key]


class CacheWarmer:
    """Aquecedor de cache para dados frequentemente acessados"""
    
    def __init__(self, cache_manager: CacheManager):
        self.cache_manager = cache_manager
        self.warming_tasks = []
    
    def add_warming_task(self, namespace: str, key_generator: Callable, 
                        value_generator: Callable, interval_seconds: int = 3600):
        """
        Adiciona tarefa de aquecimento do cache
        
        Args:
            namespace: Namespace do cache
            key_generator: Função que gera chaves para aquecer
            value_generator: Função que gera valores
            interval_seconds: Intervalo entre aquecimentos
        """
        task = {
            "namespace": namespace,
            "key_generator": key_generator,
            "value_generator": value_generator,
            "interval": interval_seconds,
            "last_run": 0
        }
        self.warming_tasks.append(task)
    
    def warm_cache(self):
        """
        Executa aquecimento do cache para tarefas pendentes
        """
        current_time = time.time()
        
        for task in self.warming_tasks:
            if current_time - task["last_run"] >= task["interval"]:
                try:
                    # Gerar chaves e valores
                    keys = task["key_generator"]()
                    
                    for key in keys:
                        value = task["value_generator"](key)
                        self.cache_manager.set(task["namespace"], key, value)
                    
                    task["last_run"] = current_time
                    
                    metrics_collector.increment_counter("cache.warmed", 
                                                      value=len(keys),
                                                      tags={"namespace": task["namespace"]})
                    
                except Exception as e:
                    print(f"Erro no aquecimento do cache: {e}")


# Instâncias globais
cache_manager = CacheManager()
cache_decorator = CacheDecorator(cache_manager)
smart_cache = SmartCache(cache_manager)
cache_warmer = CacheWarmer(cache_manager)


# Funções de conveniência
def cache_key(*args, **kwargs) -> str:
    """
    Gera chave de cache baseada nos argumentos
    
    Args:
        *args: Argumentos posicionais
        **kwargs: Argumentos nomeados
        
    Returns:
        Chave de cache
    """
    key_data = {"args": args, "kwargs": sorted(kwargs.items())}
    key_str = json.dumps(key_data, default=str, sort_keys=True)
    return hashlib.md5(key_str.encode()).hexdigest()


def cache_result(namespace: str, ttl: int = 3600):
    """
    Decorator simples para cache de resultado
    
    Args:
        namespace: Namespace do cache
        ttl: TTL em segundos
    """
    return cache_decorator.cached(namespace, ttl)


def invalidate_cache(namespace: str, pattern: str = "*") -> int:
    """
    Invalida cache por padrão
    
    Args:
        namespace: Namespace do cache
        pattern: Padrão para invalidação
        
    Returns:
        Número de chaves removidas
    """
    return cache_manager.invalidate_pattern(namespace, pattern)


def get_cache_stats() -> Dict[str, Any]:
    """
    Obtém estatísticas do cache
    
    Returns:
        Estatísticas do cache
    """
    return cache_manager.get_stats()

