"""
Machine Learning para Data Governance
Autor: Carlos Morais

Módulo para funcionalidades de ML aplicadas à governança de dados.
"""

from .anomaly_detection import AnomalyDetectionML
from .quality_prediction import QualityPredictionML
from .classification import DataClassificationML

__all__ = [
    "AnomalyDetectionML",
    "QualityPredictionML", 
    "DataClassificationML"
]

