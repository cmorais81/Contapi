"""
Machine Learning para Detecção de Anomalias
Autor: Carlos Morais

Sistema de ML para detecção automática de anomalias
em dados e padrões de governança.
"""

import numpy as np
import json
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
from enum import Enum
import statistics
import math

from ..utils.exceptions import DataGovernanceException
from ..utils.observability import trace_operation
from ..utils.audit import audit_logger, AuditEventType


class AnomalyType(Enum):
    """Tipos de anomalias detectáveis"""
    STATISTICAL_OUTLIER = "statistical_outlier"
    PATTERN_DEVIATION = "pattern_deviation"
    VOLUME_ANOMALY = "volume_anomaly"
    QUALITY_DEGRADATION = "quality_degradation"
    USAGE_ANOMALY = "usage_anomaly"
    SCHEMA_DRIFT = "schema_drift"
    TEMPORAL_ANOMALY = "temporal_anomaly"


class AnomalyMethod(Enum):
    """Métodos de detecção"""
    ISOLATION_FOREST = "isolation_forest"
    Z_SCORE = "z_score"
    IQR = "iqr"
    LSTM = "lstm"
    AUTOENCODER = "autoencoder"
    ENSEMBLE = "ensemble"


@dataclass
class AnomalyResult:
    """Resultado de detecção de anomalia"""
    id: str
    anomaly_type: AnomalyType
    method: AnomalyMethod
    score: float
    threshold: float
    is_anomaly: bool
    confidence: float
    description: str
    affected_resource: str
    detected_at: datetime
    metadata: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário"""
        data = {
            "id": self.id,
            "anomaly_type": self.anomaly_type.value,
            "method": self.method.value,
            "score": self.score,
            "threshold": self.threshold,
            "is_anomaly": self.is_anomaly,
            "confidence": self.confidence,
            "description": self.description,
            "affected_resource": self.affected_resource,
            "detected_at": self.detected_at.isoformat(),
            "metadata": self.metadata
        }
        return data


class AnomalyDetectionML:
    """Sistema de ML para detecção de anomalias"""
    
    def __init__(self):
        self.models = {}
        self.baselines = {}
        self.detection_history = []
        self.thresholds = {
            AnomalyType.STATISTICAL_OUTLIER: 0.8,
            AnomalyType.PATTERN_DEVIATION: 0.7,
            AnomalyType.VOLUME_ANOMALY: 0.75,
            AnomalyType.QUALITY_DEGRADATION: 0.85,
            AnomalyType.USAGE_ANOMALY: 0.7,
            AnomalyType.SCHEMA_DRIFT: 0.9,
            AnomalyType.TEMPORAL_ANOMALY: 0.8
        }
    
    @trace_operation("ml.train_anomaly_model", "ml")
    def train_anomaly_model(self, 
                           data: List[Dict[str, Any]],
                           anomaly_type: AnomalyType,
                           method: AnomalyMethod = AnomalyMethod.ENSEMBLE) -> Dict[str, Any]:
        """
        Treina modelo de detecção de anomalias
        
        Args:
            data: Dados de treinamento
            anomaly_type: Tipo de anomalia
            method: Método de detecção
            
        Returns:
            Resultado do treinamento
        """
        try:
            model_key = f"{anomaly_type.value}_{method.value}"
            
            # Preparar dados
            features = self._extract_features(data, anomaly_type)
            
            # Treinar modelo baseado no método
            if method == AnomalyMethod.ISOLATION_FOREST:
                model = self._train_isolation_forest(features)
            elif method == AnomalyMethod.Z_SCORE:
                model = self._train_z_score(features)
            elif method == AnomalyMethod.IQR:
                model = self._train_iqr(features)
            elif method == AnomalyMethod.LSTM:
                model = self._train_lstm(features)
            elif method == AnomalyMethod.AUTOENCODER:
                model = self._train_autoencoder(features)
            else:  # ENSEMBLE
                model = self._train_ensemble(features)
            
            # Salvar modelo
            self.models[model_key] = {
                "model": model,
                "anomaly_type": anomaly_type,
                "method": method,
                "trained_at": datetime.utcnow(),
                "training_samples": len(data),
                "feature_count": len(features[0]) if features else 0
            }
            
            # Registrar auditoria
            audit_logger.log_event({
                "event_type": AuditEventType.TRAIN,
                "resource_type": "ml_model",
                "resource_id": model_key,
                "action": "model_trained",
                "details": {
                    "anomaly_type": anomaly_type.value,
                    "method": method.value,
                    "samples": len(data)
                }
            })
            
            return {
                "model_key": model_key,
                "training_samples": len(data),
                "feature_count": len(features[0]) if features else 0,
                "status": "success"
            }
            
        except Exception as e:
            raise DataGovernanceException(f"Erro no treinamento: {str(e)}")
    
    @trace_operation("ml.detect_anomalies", "ml")
    def detect_anomalies(self,
                        data: List[Dict[str, Any]],
                        anomaly_type: AnomalyType,
                        method: AnomalyMethod = AnomalyMethod.ENSEMBLE) -> List[AnomalyResult]:
        """
        Detecta anomalias nos dados
        
        Args:
            data: Dados para análise
            anomaly_type: Tipo de anomalia
            method: Método de detecção
            
        Returns:
            Lista de anomalias detectadas
        """
        try:
            model_key = f"{anomaly_type.value}_{method.value}"
            
            # Verificar se modelo existe
            if model_key not in self.models:
                # Treinar modelo automaticamente se não existir
                self.train_anomaly_model(data, anomaly_type, method)
            
            model_info = self.models[model_key]
            model = model_info["model"]
            
            # Extrair features
            features = self._extract_features(data, anomaly_type)
            
            # Detectar anomalias
            anomaly_scores = self._predict_anomalies(model, features, method)
            
            # Gerar resultados
            results = []
            threshold = self.thresholds[anomaly_type]
            
            for i, (score, data_point) in enumerate(zip(anomaly_scores, data)):
                is_anomaly = score > threshold
                confidence = min(score / threshold, 1.0) if is_anomaly else 1.0 - (score / threshold)
                
                if is_anomaly:
                    result = AnomalyResult(
                        id=f"anomaly_{datetime.utcnow().timestamp()}_{i}",
                        anomaly_type=anomaly_type,
                        method=method,
                        score=score,
                        threshold=threshold,
                        is_anomaly=is_anomaly,
                        confidence=confidence,
                        description=self._generate_anomaly_description(anomaly_type, score, data_point),
                        affected_resource=data_point.get("resource_id", f"data_point_{i}"),
                        detected_at=datetime.utcnow(),
                        metadata={
                            "data_point": data_point,
                            "feature_values": features[i] if i < len(features) else None
                        }
                    )
                    results.append(result)
            
            # Salvar histórico
            self.detection_history.extend(results)
            
            return results
            
        except Exception as e:
            raise DataGovernanceException(f"Erro na detecção: {str(e)}")
    
    def _extract_features(self, data: List[Dict[str, Any]], anomaly_type: AnomalyType) -> List[List[float]]:
        """Extrai features baseado no tipo de anomalia"""
        features = []
        
        for item in data:
            if anomaly_type == AnomalyType.STATISTICAL_OUTLIER:
                # Features numéricas básicas
                feature_vector = [
                    float(item.get("value", 0)),
                    float(item.get("count", 0)),
                    float(item.get("size", 0))
                ]
            
            elif anomaly_type == AnomalyType.VOLUME_ANOMALY:
                # Features de volume
                feature_vector = [
                    float(item.get("record_count", 0)),
                    float(item.get("file_size", 0)),
                    float(item.get("processing_time", 0))
                ]
            
            elif anomaly_type == AnomalyType.QUALITY_DEGRADATION:
                # Features de qualidade
                feature_vector = [
                    float(item.get("completeness", 0)),
                    float(item.get("accuracy", 0)),
                    float(item.get("consistency", 0)),
                    float(item.get("validity", 0))
                ]
            
            elif anomaly_type == AnomalyType.USAGE_ANOMALY:
                # Features de uso
                feature_vector = [
                    float(item.get("query_count", 0)),
                    float(item.get("user_count", 0)),
                    float(item.get("access_frequency", 0))
                ]
            
            elif anomaly_type == AnomalyType.TEMPORAL_ANOMALY:
                # Features temporais
                timestamp = item.get("timestamp", datetime.utcnow())
                if isinstance(timestamp, str):
                    timestamp = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
                
                feature_vector = [
                    float(timestamp.hour),
                    float(timestamp.weekday()),
                    float(timestamp.day),
                    float(item.get("value", 0))
                ]
            
            else:
                # Features genéricas
                feature_vector = [
                    float(item.get("metric1", 0)),
                    float(item.get("metric2", 0)),
                    float(item.get("metric3", 0))
                ]
            
            features.append(feature_vector)
        
        return features
    
    def _train_isolation_forest(self, features: List[List[float]]) -> Dict[str, Any]:
        """Treina modelo Isolation Forest simplificado"""
        if not features:
            return {"type": "isolation_forest", "trees": []}
        
        # Implementação simplificada do Isolation Forest
        n_trees = 10
        trees = []
        
        for _ in range(n_trees):
            tree = self._build_isolation_tree(features, max_depth=8)
            trees.append(tree)
        
        return {
            "type": "isolation_forest",
            "trees": trees,
            "n_features": len(features[0])
        }
    
    def _build_isolation_tree(self, data: List[List[float]], max_depth: int, current_depth: int = 0) -> Dict[str, Any]:
        """Constrói árvore de isolamento"""
        if current_depth >= max_depth or len(data) <= 1:
            return {"type": "leaf", "size": len(data)}
        
        # Selecionar feature aleatória
        n_features = len(data[0])
        feature_idx = np.random.randint(0, n_features)
        
        # Selecionar ponto de divisão aleatório
        feature_values = [row[feature_idx] for row in data]
        min_val, max_val = min(feature_values), max(feature_values)
        
        if min_val == max_val:
            return {"type": "leaf", "size": len(data)}
        
        split_value = np.random.uniform(min_val, max_val)
        
        # Dividir dados
        left_data = [row for row in data if row[feature_idx] < split_value]
        right_data = [row for row in data if row[feature_idx] >= split_value]
        
        return {
            "type": "node",
            "feature_idx": feature_idx,
            "split_value": split_value,
            "left": self._build_isolation_tree(left_data, max_depth, current_depth + 1),
            "right": self._build_isolation_tree(right_data, max_depth, current_depth + 1)
        }
    
    def _train_z_score(self, features: List[List[float]]) -> Dict[str, Any]:
        """Treina modelo Z-Score"""
        if not features:
            return {"type": "z_score", "means": [], "stds": []}
        
        n_features = len(features[0])
        means = []
        stds = []
        
        for i in range(n_features):
            feature_values = [row[i] for row in features]
            mean_val = statistics.mean(feature_values)
            std_val = statistics.stdev(feature_values) if len(feature_values) > 1 else 1.0
            
            means.append(mean_val)
            stds.append(std_val)
        
        return {
            "type": "z_score",
            "means": means,
            "stds": stds
        }
    
    def _train_iqr(self, features: List[List[float]]) -> Dict[str, Any]:
        """Treina modelo IQR"""
        if not features:
            return {"type": "iqr", "q1s": [], "q3s": []}
        
        n_features = len(features[0])
        q1s = []
        q3s = []
        
        for i in range(n_features):
            feature_values = sorted([row[i] for row in features])
            n = len(feature_values)
            
            if n >= 4:
                q1 = feature_values[n // 4]
                q3 = feature_values[3 * n // 4]
            else:
                q1 = min(feature_values)
                q3 = max(feature_values)
            
            q1s.append(q1)
            q3s.append(q3)
        
        return {
            "type": "iqr",
            "q1s": q1s,
            "q3s": q3s
        }
    
    def _train_lstm(self, features: List[List[float]]) -> Dict[str, Any]:
        """Treina modelo LSTM simplificado"""
        # Implementação simplificada - em produção usar TensorFlow/PyTorch
        return {
            "type": "lstm",
            "weights": np.random.randn(10, len(features[0]) if features else 3).tolist(),
            "sequence_length": 10
        }
    
    def _train_autoencoder(self, features: List[List[float]]) -> Dict[str, Any]:
        """Treina autoencoder simplificado"""
        # Implementação simplificada - em produção usar TensorFlow/PyTorch
        n_features = len(features[0]) if features else 3
        
        return {
            "type": "autoencoder",
            "encoder_weights": np.random.randn(n_features, n_features // 2).tolist(),
            "decoder_weights": np.random.randn(n_features // 2, n_features).tolist(),
            "threshold": 0.1
        }
    
    def _train_ensemble(self, features: List[List[float]]) -> Dict[str, Any]:
        """Treina ensemble de modelos"""
        models = {
            "isolation_forest": self._train_isolation_forest(features),
            "z_score": self._train_z_score(features),
            "iqr": self._train_iqr(features)
        }
        
        return {
            "type": "ensemble",
            "models": models,
            "weights": [0.4, 0.3, 0.3]  # Pesos para cada modelo
        }
    
    def _predict_anomalies(self, model: Dict[str, Any], features: List[List[float]], method: AnomalyMethod) -> List[float]:
        """Prediz scores de anomalia"""
        if method == AnomalyMethod.ISOLATION_FOREST:
            return self._predict_isolation_forest(model, features)
        elif method == AnomalyMethod.Z_SCORE:
            return self._predict_z_score(model, features)
        elif method == AnomalyMethod.IQR:
            return self._predict_iqr(model, features)
        elif method == AnomalyMethod.LSTM:
            return self._predict_lstm(model, features)
        elif method == AnomalyMethod.AUTOENCODER:
            return self._predict_autoencoder(model, features)
        else:  # ENSEMBLE
            return self._predict_ensemble(model, features)
    
    def _predict_isolation_forest(self, model: Dict[str, Any], features: List[List[float]]) -> List[float]:
        """Prediz com Isolation Forest"""
        scores = []
        
        for feature_vector in features:
            path_lengths = []
            
            for tree in model["trees"]:
                path_length = self._get_path_length(tree, feature_vector)
                path_lengths.append(path_length)
            
            avg_path_length = statistics.mean(path_lengths)
            # Normalizar score (menor path length = maior anomalia)
            score = 1.0 / (1.0 + avg_path_length)
            scores.append(score)
        
        return scores
    
    def _get_path_length(self, tree: Dict[str, Any], feature_vector: List[float], depth: int = 0) -> int:
        """Calcula comprimento do caminho na árvore"""
        if tree["type"] == "leaf":
            return depth
        
        feature_idx = tree["feature_idx"]
        split_value = tree["split_value"]
        
        if feature_vector[feature_idx] < split_value:
            return self._get_path_length(tree["left"], feature_vector, depth + 1)
        else:
            return self._get_path_length(tree["right"], feature_vector, depth + 1)
    
    def _predict_z_score(self, model: Dict[str, Any], features: List[List[float]]) -> List[float]:
        """Prediz com Z-Score"""
        scores = []
        
        for feature_vector in features:
            z_scores = []
            
            for i, value in enumerate(feature_vector):
                mean_val = model["means"][i]
                std_val = model["stds"][i]
                
                if std_val > 0:
                    z_score = abs((value - mean_val) / std_val)
                else:
                    z_score = 0
                
                z_scores.append(z_score)
            
            # Score baseado no maior Z-Score
            max_z_score = max(z_scores)
            score = min(max_z_score / 3.0, 1.0)  # Normalizar para 0-1
            scores.append(score)
        
        return scores
    
    def _predict_iqr(self, model: Dict[str, Any], features: List[List[float]]) -> List[float]:
        """Prediz com IQR"""
        scores = []
        
        for feature_vector in features:
            outlier_scores = []
            
            for i, value in enumerate(feature_vector):
                q1 = model["q1s"][i]
                q3 = model["q3s"][i]
                iqr = q3 - q1
                
                if iqr > 0:
                    lower_bound = q1 - 1.5 * iqr
                    upper_bound = q3 + 1.5 * iqr
                    
                    if value < lower_bound:
                        outlier_score = (lower_bound - value) / iqr
                    elif value > upper_bound:
                        outlier_score = (value - upper_bound) / iqr
                    else:
                        outlier_score = 0
                else:
                    outlier_score = 0
                
                outlier_scores.append(outlier_score)
            
            # Score baseado no maior outlier score
            max_outlier_score = max(outlier_scores)
            score = min(max_outlier_score, 1.0)
            scores.append(score)
        
        return scores
    
    def _predict_lstm(self, model: Dict[str, Any], features: List[List[float]]) -> List[float]:
        """Prediz com LSTM (simplificado)"""
        # Implementação simplificada
        scores = []
        weights = np.array(model["weights"])
        
        for feature_vector in features:
            # Simulação de predição LSTM
            prediction_error = np.random.random() * 0.5
            score = min(prediction_error * 2, 1.0)
            scores.append(score)
        
        return scores
    
    def _predict_autoencoder(self, model: Dict[str, Any], features: List[List[float]]) -> List[float]:
        """Prediz com Autoencoder (simplificado)"""
        # Implementação simplificada
        scores = []
        
        for feature_vector in features:
            # Simulação de erro de reconstrução
            reconstruction_error = np.random.random() * 0.3
            score = min(reconstruction_error * 3, 1.0)
            scores.append(score)
        
        return scores
    
    def _predict_ensemble(self, model: Dict[str, Any], features: List[List[float]]) -> List[float]:
        """Prediz com ensemble"""
        models = model["models"]
        weights = model["weights"]
        
        # Obter predições de cada modelo
        if_scores = self._predict_isolation_forest(models["isolation_forest"], features)
        z_scores = self._predict_z_score(models["z_score"], features)
        iqr_scores = self._predict_iqr(models["iqr"], features)
        
        # Combinar com pesos
        ensemble_scores = []
        for i in range(len(features)):
            weighted_score = (
                if_scores[i] * weights[0] +
                z_scores[i] * weights[1] +
                iqr_scores[i] * weights[2]
            )
            ensemble_scores.append(weighted_score)
        
        return ensemble_scores
    
    def _generate_anomaly_description(self, anomaly_type: AnomalyType, score: float, data_point: Dict[str, Any]) -> str:
        """Gera descrição da anomalia"""
        descriptions = {
            AnomalyType.STATISTICAL_OUTLIER: f"Outlier estatístico detectado com score {score:.2f}",
            AnomalyType.PATTERN_DEVIATION: f"Desvio de padrão detectado com score {score:.2f}",
            AnomalyType.VOLUME_ANOMALY: f"Anomalia de volume detectada com score {score:.2f}",
            AnomalyType.QUALITY_DEGRADATION: f"Degradação de qualidade detectada com score {score:.2f}",
            AnomalyType.USAGE_ANOMALY: f"Anomalia de uso detectada com score {score:.2f}",
            AnomalyType.SCHEMA_DRIFT: f"Drift de schema detectado com score {score:.2f}",
            AnomalyType.TEMPORAL_ANOMALY: f"Anomalia temporal detectada com score {score:.2f}"
        }
        
        base_description = descriptions.get(anomaly_type, f"Anomalia detectada com score {score:.2f}")
        
        # Adicionar contexto específico
        if "resource_name" in data_point:
            base_description += f" no recurso {data_point['resource_name']}"
        
        return base_description
    
    @trace_operation("ml.get_anomaly_insights", "ml")
    def get_anomaly_insights(self, time_window_hours: int = 24) -> Dict[str, Any]:
        """
        Obtém insights sobre anomalias detectadas
        
        Args:
            time_window_hours: Janela de tempo em horas
            
        Returns:
            Insights sobre anomalias
        """
        cutoff_time = datetime.utcnow() - timedelta(hours=time_window_hours)
        recent_anomalies = [
            a for a in self.detection_history 
            if a.detected_at >= cutoff_time
        ]
        
        if not recent_anomalies:
            return {
                "total_anomalies": 0,
                "insights": ["Nenhuma anomalia detectada no período"],
                "recommendations": []
            }
        
        # Análise por tipo
        anomalies_by_type = {}
        for anomaly in recent_anomalies:
            anomaly_type = anomaly.anomaly_type.value
            if anomaly_type not in anomalies_by_type:
                anomalies_by_type[anomaly_type] = []
            anomalies_by_type[anomaly_type].append(anomaly)
        
        # Gerar insights
        insights = []
        recommendations = []
        
        for anomaly_type, anomalies in anomalies_by_type.items():
            count = len(anomalies)
            avg_score = statistics.mean([a.score for a in anomalies])
            
            insights.append(f"{count} anomalias do tipo {anomaly_type} com score médio {avg_score:.2f}")
            
            if count > 5:
                recommendations.append(f"Investigar padrão recorrente de {anomaly_type}")
            
            if avg_score > 0.9:
                recommendations.append(f"Anomalias de {anomaly_type} com alta severidade requerem atenção imediata")
        
        # Recursos mais afetados
        affected_resources = {}
        for anomaly in recent_anomalies:
            resource = anomaly.affected_resource
            if resource not in affected_resources:
                affected_resources[resource] = 0
            affected_resources[resource] += 1
        
        top_affected = sorted(affected_resources.items(), key=lambda x: x[1], reverse=True)[:5]
        
        return {
            "time_window_hours": time_window_hours,
            "total_anomalies": len(recent_anomalies),
            "anomalies_by_type": {k: len(v) for k, v in anomalies_by_type.items()},
            "top_affected_resources": top_affected,
            "insights": insights,
            "recommendations": recommendations,
            "average_confidence": statistics.mean([a.confidence for a in recent_anomalies])
        }
    
    def update_threshold(self, anomaly_type: AnomalyType, new_threshold: float):
        """
        Atualiza threshold para tipo de anomalia
        
        Args:
            anomaly_type: Tipo de anomalia
            new_threshold: Novo threshold
        """
        if 0 <= new_threshold <= 1:
            self.thresholds[anomaly_type] = new_threshold
            
            # Registrar auditoria
            audit_logger.log_event({
                "event_type": AuditEventType.UPDATE,
                "resource_type": "ml_threshold",
                "resource_id": anomaly_type.value,
                "action": "threshold_updated",
                "details": {"new_threshold": new_threshold}
            })
        else:
            raise DataGovernanceException("Threshold deve estar entre 0 e 1")
    
    def get_model_performance(self) -> Dict[str, Any]:
        """
        Obtém métricas de performance dos modelos
        
        Returns:
            Métricas de performance
        """
        performance = {}
        
        for model_key, model_info in self.models.items():
            performance[model_key] = {
                "trained_at": model_info["trained_at"].isoformat(),
                "training_samples": model_info["training_samples"],
                "feature_count": model_info["feature_count"],
                "anomaly_type": model_info["anomaly_type"].value,
                "method": model_info["method"].value
            }
        
        return {
            "total_models": len(self.models),
            "models": performance,
            "detection_history_size": len(self.detection_history),
            "thresholds": {k.value: v for k, v in self.thresholds.items()}
        }


# Instância global
anomaly_detection_ml = AnomalyDetectionML()


# Funções de conveniência
def detect_data_anomalies(data: List[Dict[str, Any]], 
                         anomaly_type: AnomalyType = AnomalyType.STATISTICAL_OUTLIER) -> List[AnomalyResult]:
    """
    Detecta anomalias nos dados
    
    Args:
        data: Dados para análise
        anomaly_type: Tipo de anomalia
        
    Returns:
        Lista de anomalias
    """
    return anomaly_detection_ml.detect_anomalies(data, anomaly_type)


def train_anomaly_detector(data: List[Dict[str, Any]], 
                          anomaly_type: AnomalyType) -> Dict[str, Any]:
    """
    Treina detector de anomalias
    
    Args:
        data: Dados de treinamento
        anomaly_type: Tipo de anomalia
        
    Returns:
        Resultado do treinamento
    """
    return anomaly_detection_ml.train_anomaly_model(data, anomaly_type)


def get_anomaly_insights(hours: int = 24) -> Dict[str, Any]:
    """
    Obtém insights sobre anomalias
    
    Args:
        hours: Janela de tempo em horas
        
    Returns:
        Insights sobre anomalias
    """
    return anomaly_detection_ml.get_anomaly_insights(hours)

