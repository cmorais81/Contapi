"""
Repository base para Data Governance API
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

from typing import Any, Dict, Generic, List, Optional, Type, TypeVar
from uuid import UUID

from sqlalchemy import and_, func, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload

from ..models.base import BaseEntity

ModelType = TypeVar("ModelType", bound=BaseEntity)


class BaseRepository(Generic[ModelType]):
    """Repository base com operações CRUD padrão"""
    
    def __init__(self, model: Type[ModelType], db: AsyncSession):
        self.model = model
        self.db = db
    
    async def get_by_id(self, id: UUID) -> Optional[ModelType]:
        """Busca entidade por ID"""
        result = await self.db.execute(
            select(self.model).where(self.model.get_primary_key() == id)
        )
        return result.scalar_one_or_none()
    
    async def get_all(
        self,
        skip: int = 0,
        limit: int = 100,
        filters: Optional[Dict[str, Any]] = None,
        order_by: Optional[str] = None
    ) -> List[ModelType]:
        """Busca todas as entidades com filtros opcionais"""
        query = select(self.model)
        
        # Aplicar filtros
        if filters:
            conditions = []
            for field, value in filters.items():
                if hasattr(self.model, field):
                    attr = getattr(self.model, field)
                    if isinstance(value, list):
                        conditions.append(attr.in_(value))
                    elif isinstance(value, str) and value.startswith('%'):
                        conditions.append(attr.ilike(value))
                    else:
                        conditions.append(attr == value)
            
            if conditions:
                query = query.where(and_(*conditions))
        
        # Aplicar ordenação
        if order_by:
            if order_by.startswith('-'):
                field = order_by[1:]
                if hasattr(self.model, field):
                    query = query.order_by(getattr(self.model, field).desc())
            else:
                if hasattr(self.model, order_by):
                    query = query.order_by(getattr(self.model, order_by))
        else:
            # Ordenação padrão por data_criacao
            query = query.order_by(self.model.data_criacao.desc())
        
        # Aplicar paginação
        query = query.offset(skip).limit(limit)
        
        result = await self.db.execute(query)
        return result.scalars().all()
    
    async def count(self, filters: Optional[Dict[str, Any]] = None) -> int:
        """Conta o número de entidades com filtros opcionais"""
        query = select(func.count(self.model.get_primary_key()))
        
        # Aplicar filtros
        if filters:
            conditions = []
            for field, value in filters.items():
                if hasattr(self.model, field):
                    attr = getattr(self.model, field)
                    if isinstance(value, list):
                        conditions.append(attr.in_(value))
                    elif isinstance(value, str) and value.startswith('%'):
                        conditions.append(attr.ilike(value))
                    else:
                        conditions.append(attr == value)
            
            if conditions:
                query = query.where(and_(*conditions))
        
        result = await self.db.execute(query)
        return result.scalar()
    
    async def create(self, obj_in: Dict[str, Any]) -> ModelType:
        """Cria nova entidade"""
        db_obj = self.model(**obj_in)
        self.db.add(db_obj)
        await self.db.commit()
        await self.db.refresh(db_obj)
        return db_obj
    
    async def update(self, id: UUID, obj_in: Dict[str, Any]) -> Optional[ModelType]:
        """Atualiza entidade existente"""
        db_obj = await self.get_by_id(id)
        if not db_obj:
            return None
        
        for field, value in obj_in.items():
            if hasattr(db_obj, field) and value is not None:
                setattr(db_obj, field, value)
        
        # Atualizar timestamp de atualização
        db_obj.data_atualizacao = func.now()
        
        await self.db.commit()
        await self.db.refresh(db_obj)
        return db_obj
    
    async def delete(self, id: UUID) -> bool:
        """Remove entidade"""
        db_obj = await self.get_by_id(id)
        if not db_obj:
            return False
        
        await self.db.delete(db_obj)
        await self.db.commit()
        return True
    
    async def search(
        self,
        search_term: str,
        search_fields: List[str],
        skip: int = 0,
        limit: int = 100
    ) -> List[ModelType]:
        """Busca textual em múltiplos campos"""
        conditions = []
        
        for field in search_fields:
            if hasattr(self.model, field):
                attr = getattr(self.model, field)
                conditions.append(attr.ilike(f"%{search_term}%"))
        
        if not conditions:
            return []
        
        query = select(self.model).where(or_(*conditions))
        query = query.order_by(self.model.data_criacao.desc())
        query = query.offset(skip).limit(limit)
        
        result = await self.db.execute(query)
        return result.scalars().all()
    
    async def exists(self, **kwargs) -> bool:
        """Verifica se entidade existe com os critérios fornecidos"""
        conditions = []
        for field, value in kwargs.items():
            if hasattr(self.model, field):
                attr = getattr(self.model, field)
                conditions.append(attr == value)
        
        if not conditions:
            return False
        
        query = select(func.count(self.model.get_primary_key())).where(and_(*conditions))
        result = await self.db.execute(query)
        count = result.scalar()
        return count > 0

