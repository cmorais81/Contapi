"""
Repository para DataContracts seguindo modelo_estendido.dbml original
Autor: Carlos Morais
"""

from typing import Dict, List, Optional
from uuid import UUID

from sqlalchemy import and_, func, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload

from ..models.data_contracts import DataContracts
from ..models.contract_versions import ContractVersions
from .base import BaseRepository


class DataContractsRepository(BaseRepository[DataContracts]):
    """Repository para contratos de dados"""
    
    def __init__(self, db: AsyncSession):
        super().__init__(DataContracts, db)
    
    async def get_by_name(self, contract_name: str) -> Optional[DataContracts]:
        """Busca contrato por nome"""
        result = await self.db.execute(
            select(DataContracts).where(DataContracts.contract_name == contract_name)
        )
        return result.scalar_one_or_none()
    
    async def get_with_versions(self, contract_id: UUID) -> Optional[DataContracts]:
        """Busca contrato com suas versões"""
        result = await self.db.execute(
            select(DataContracts)
            .options(selectinload(DataContracts.versions))
            .where(DataContracts.contract_id == contract_id)
        )
        return result.scalar_one_or_none()
    
    async def get_by_domain(self, business_domain: str) -> List[DataContracts]:
        """Busca contratos por domínio de negócio"""
        result = await self.db.execute(
            select(DataContracts)
            .where(DataContracts.business_domain == business_domain)
            .order_by(DataContracts.contract_name)
        )
        return result.scalars().all()
    
    async def get_by_owner(self, contract_owner: str) -> List[DataContracts]:
        """Busca contratos por proprietário"""
        result = await self.db.execute(
            select(DataContracts)
            .where(DataContracts.contract_owner == contract_owner)
            .order_by(DataContracts.contract_name)
        )
        return result.scalars().all()
    
    async def get_by_status(self, status: str) -> List[DataContracts]:
        """Busca contratos por status"""
        result = await self.db.execute(
            select(DataContracts)
            .where(DataContracts.contract_status == status)
            .order_by(DataContracts.data_criacao.desc())
        )
        return result.scalars().all()
    
    async def get_with_active_versions(self) -> List[DataContracts]:
        """Busca contratos que têm versões ativas"""
        result = await self.db.execute(
            select(DataContracts)
            .join(ContractVersions)
            .where(ContractVersions.version_status == 'active')
            .distinct()
            .order_by(DataContracts.contract_name)
        )
        return result.scalars().all()
    
    async def get_unity_catalog_contracts(self) -> List[DataContracts]:
        """Busca contratos integrados com Unity Catalog"""
        result = await self.db.execute(
            select(DataContracts)
            .where(
                and_(
                    DataContracts.unity_catalog_name.isnot(None),
                    DataContracts.unity_catalog_schema.isnot(None),
                    DataContracts.unity_catalog_table.isnot(None)
                )
            )
            .order_by(DataContracts.unity_catalog_name, DataContracts.unity_catalog_schema)
        )
        return result.scalars().all()
    
    async def get_abac_enabled_contracts(self) -> List[DataContracts]:
        """Busca contratos com ABAC habilitado"""
        result = await self.db.execute(
            select(DataContracts)
            .where(DataContracts.abac_enabled == True)
            .order_by(DataContracts.contract_name)
        )
        return result.scalars().all()
    
    async def get_monitoring_enabled_contracts(self) -> List[DataContracts]:
        """Busca contratos com monitoramento habilitado"""
        result = await self.db.execute(
            select(DataContracts)
            .where(DataContracts.monitoring_enabled == True)
            .order_by(DataContracts.contract_name)
        )
        return result.scalars().all()
    
    async def search_contracts(
        self,
        search_term: str,
        skip: int = 0,
        limit: int = 100
    ) -> List[DataContracts]:
        """Busca contratos por termo"""
        search_pattern = f"%{search_term}%"
        
        result = await self.db.execute(
            select(DataContracts)
            .where(
                or_(
                    DataContracts.contract_name.ilike(search_pattern),
                    DataContracts.contract_description.ilike(search_pattern),
                    DataContracts.business_domain.ilike(search_pattern),
                    DataContracts.contract_owner.ilike(search_pattern)
                )
            )
            .order_by(DataContracts.contract_name)
            .offset(skip)
            .limit(limit)
        )
        return result.scalars().all()
    
    async def get_contracts_stats(self) -> Dict[str, int]:
        """Estatísticas dos contratos"""
        
        # Total de contratos
        total_result = await self.db.execute(
            select(func.count(DataContracts.contract_id))
        )
        total = total_result.scalar()
        
        # Contratos por status
        status_result = await self.db.execute(
            select(
                DataContracts.contract_status,
                func.count(DataContracts.contract_id)
            )
            .group_by(DataContracts.contract_status)
        )
        status_counts = {status: count for status, count in status_result.all()}
        
        # Contratos com ABAC
        abac_result = await self.db.execute(
            select(func.count(DataContracts.contract_id))
            .where(DataContracts.abac_enabled == True)
        )
        abac_count = abac_result.scalar()
        
        # Contratos com monitoramento
        monitoring_result = await self.db.execute(
            select(func.count(DataContracts.contract_id))
            .where(DataContracts.monitoring_enabled == True)
        )
        monitoring_count = monitoring_result.scalar()
        
        return {
            'total': total,
            'by_status': status_counts,
            'abac_enabled': abac_count,
            'monitoring_enabled': monitoring_count
        }

