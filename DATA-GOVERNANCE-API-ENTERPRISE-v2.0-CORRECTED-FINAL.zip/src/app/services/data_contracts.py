"""
Service para DataContracts seguindo modelo_estendido.dbml original
Autor: Carlos Morais
"""

from typing import Dict, List, Optional
from uuid import UUID

from ..models.data_contracts import DataContracts
from ..repositories.data_contracts import DataContractsRepository
from ..utils.exceptions import ValidationError, EntityNotFoundError
from .base import BaseService


class DataContractsService(BaseService[DataContracts, DataContractsRepository]):
    """Service para contratos de dados"""
    
    def __init__(self, repository: DataContractsRepository):
        super().__init__(repository)
    
    async def get_by_name(self, contract_name: str) -> DataContracts:
        """Busca contrato por nome"""
        contract = await self.repository.get_by_name(contract_name)
        if not contract:
            raise EntityNotFoundError(f"Contrato '{contract_name}' não encontrado")
        return contract
    
    async def get_with_versions(self, contract_id: UUID) -> DataContracts:
        """Busca contrato com suas versões"""
        contract = await self.repository.get_with_versions(contract_id)
        if not contract:
            raise EntityNotFoundError(f"Contrato com ID {contract_id} não encontrado")
        return contract
    
    async def get_by_domain(self, business_domain: str) -> List[DataContracts]:
        """Busca contratos por domínio de negócio"""
        return await self.repository.get_by_domain(business_domain)
    
    async def get_by_owner(self, contract_owner: str) -> List[DataContracts]:
        """Busca contratos por proprietário"""
        return await self.repository.get_by_owner(contract_owner)
    
    async def get_by_status(self, status: str) -> List[DataContracts]:
        """Busca contratos por status"""
        valid_statuses = ['draft', 'active', 'deprecated', 'archived']
        if status not in valid_statuses:
            raise ValidationError(f"Status inválido: {status}. Opções válidas: {valid_statuses}")
        
        return await self.repository.get_by_status(status)
    
    async def get_with_active_versions(self) -> List[DataContracts]:
        """Busca contratos que têm versões ativas"""
        return await self.repository.get_with_active_versions()
    
    async def get_unity_catalog_contracts(self) -> List[DataContracts]:
        """Busca contratos integrados com Unity Catalog"""
        return await self.repository.get_unity_catalog_contracts()
    
    async def get_abac_enabled_contracts(self) -> List[DataContracts]:
        """Busca contratos com ABAC habilitado"""
        return await self.repository.get_abac_enabled_contracts()
    
    async def get_monitoring_enabled_contracts(self) -> List[DataContracts]:
        """Busca contratos com monitoramento habilitado"""
        return await self.repository.get_monitoring_enabled_contracts()
    
    async def search_contracts(
        self,
        search_term: str,
        skip: int = 0,
        limit: int = 100
    ) -> List[DataContracts]:
        """Busca contratos por termo"""
        if not search_term or len(search_term.strip()) < 2:
            raise ValidationError("Termo de busca deve ter pelo menos 2 caracteres")
        
        return await self.repository.search_contracts(search_term.strip(), skip, limit)
    
    async def get_contracts_stats(self) -> Dict[str, int]:
        """Estatísticas dos contratos"""
        return await self.repository.get_contracts_stats()
    
    async def activate_contract(self, contract_id: UUID) -> DataContracts:
        """Ativa um contrato"""
        contract = await self.repository.get_by_id(contract_id)
        if not contract:
            raise EntityNotFoundError(f"Contrato com ID {contract_id} não encontrado")
        
        if contract.contract_status == 'active':
            raise ValidationError("Contrato já está ativo")
        
        # Validar se contrato pode ser ativado
        await self._validate_contract_activation(contract)
        
        # Ativar contrato
        updated = await self.repository.update(contract_id, {'contract_status': 'active'})
        return updated
    
    async def deprecate_contract(self, contract_id: UUID) -> DataContracts:
        """Deprecia um contrato"""
        contract = await self.repository.get_by_id(contract_id)
        if not contract:
            raise EntityNotFoundError(f"Contrato com ID {contract_id} não encontrado")
        
        if contract.contract_status == 'deprecated':
            raise ValidationError("Contrato já está depreciado")
        
        if contract.contract_status == 'archived':
            raise ValidationError("Contrato arquivado não pode ser depreciado")
        
        # Depreciar contrato
        updated = await self.repository.update(contract_id, {'contract_status': 'deprecated'})
        return updated
    
    async def archive_contract(self, contract_id: UUID) -> DataContracts:
        """Arquiva um contrato"""
        contract = await self.repository.get_by_id(contract_id)
        if not contract:
            raise EntityNotFoundError(f"Contrato com ID {contract_id} não encontrado")
        
        if contract.contract_status == 'archived':
            raise ValidationError("Contrato já está arquivado")
        
        # Arquivar contrato
        updated = await self.repository.update(contract_id, {'contract_status': 'archived'})
        return updated
    
    # Métodos de validação específicos
    
    async def _validate_create_data(self, data: Dict[str, any]) -> None:
        """Valida dados para criação de contrato"""
        
        # Campos obrigatórios
        required_fields = ['contract_name']
        self._validate_required_fields(data, required_fields)
        
        # Validar valores de campos
        field_validations = {
            'contract_status': {
                'choices': ['draft', 'active', 'deprecated', 'archived']
            },
            'data_format': {
                'choices': ['delta', 'iceberg', 'parquet', 'json', 'csv', 'avro']
            },
            'table_format': {
                'choices': ['delta', 'iceberg', 'hudi']
            }
        }
        self._validate_field_values(data, field_validations)
        
        # Verificar se nome já existe
        if await self.repository.exists(contract_name=data['contract_name']):
            raise ValidationError(f"Contrato com nome '{data['contract_name']}' já existe")
        
        # Validar integração Unity Catalog
        await self._validate_unity_catalog_integration(data)
    
    async def _validate_update_data(self, id: UUID, data: Dict[str, any]) -> None:
        """Valida dados para atualização de contrato"""
        
        # Validar valores de campos
        field_validations = {
            'contract_status': {
                'choices': ['draft', 'active', 'deprecated', 'archived']
            },
            'data_format': {
                'choices': ['delta', 'iceberg', 'parquet', 'json', 'csv', 'avro']
            },
            'table_format': {
                'choices': ['delta', 'iceberg', 'hudi']
            }
        }
        self._validate_field_values(data, field_validations)
        
        # Verificar se nome já existe (se alterando nome)
        if 'contract_name' in data:
            existing = await self.repository.get_by_name(data['contract_name'])
            if existing and existing.contract_id != id:
                raise ValidationError(f"Contrato com nome '{data['contract_name']}' já existe")
        
        # Validar integração Unity Catalog
        await self._validate_unity_catalog_integration(data)
    
    async def _validate_delete(self, id: UUID) -> None:
        """Valida se contrato pode ser removido"""
        contract = await self.repository.get_with_versions(id)
        
        # Verificar se tem versões ativas
        active_versions = [v for v in contract.versions if v.version_status == 'active']
        if active_versions:
            raise ValidationError("Não é possível remover contrato com versões ativas")
    
    def _get_default_search_fields(self) -> List[str]:
        """Campos padrão para busca textual"""
        return ['contract_name', 'contract_description', 'business_domain', 'contract_owner']
    
    async def _validate_unity_catalog_integration(self, data: Dict[str, any]) -> None:
        """Valida integração com Unity Catalog"""
        unity_fields = ['unity_catalog_name', 'unity_catalog_schema', 'unity_catalog_table']
        unity_values = [data.get(field) for field in unity_fields]
        
        # Se algum campo Unity Catalog está preenchido, todos devem estar
        if any(unity_values) and not all(unity_values):
            raise ValidationError("Para integração Unity Catalog, todos os campos (catalog, schema, table) devem ser preenchidos")
    
    async def _validate_contract_activation(self, contract: DataContracts) -> None:
        """Valida se contrato pode ser ativado"""
        
        # Verificar se tem informações mínimas
        if not contract.contract_description:
            raise ValidationError("Contrato deve ter descrição para ser ativado")
        
        if not contract.contract_owner:
            raise ValidationError("Contrato deve ter proprietário para ser ativado")
        
        if not contract.business_domain:
            raise ValidationError("Contrato deve ter domínio de negócio para ser ativado")

