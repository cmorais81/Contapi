"""
Schemas para DataContracts seguindo modelo_estendido.dbml original
Autor: Carlos Morais
"""

from datetime import datetime
from typing import Dict, List, Optional
from uuid import UUID

from pydantic import Field

from .base import BaseCreateSchema, BaseSchema, BaseUpdateSchema


class DataContractBase(BaseCreateSchema):
    """Schema base para contratos de dados"""
    
    contract_name: str = Field(..., description="Nome do contrato")
    contract_description: Optional[str] = Field(None, description="Descrição do contrato")
    contract_owner: Optional[str] = Field(None, description="Proprietário do contrato")
    business_domain: Optional[str] = Field(None, description="Domínio de negócio")
    
    # Integração Unity Catalog
    unity_catalog_name: Optional[str] = Field(None, description="Nome do catálogo Unity")
    unity_catalog_schema: Optional[str] = Field(None, description="Schema Unity Catalog")
    unity_catalog_table: Optional[str] = Field(None, description="Tabela Unity Catalog")
    
    # Configuração de dados
    data_location: Optional[str] = Field(None, description="Localização dos dados")
    data_format: Optional[str] = Field(None, description="Formato dos dados")
    table_format: Optional[str] = Field(None, description="Formato da tabela")
    
    # Configuração ABAC
    abac_enabled: Optional[bool] = Field(False, description="ABAC habilitado")
    abac_policy_id: Optional[UUID] = Field(None, description="ID da política ABAC")
    
    # Monitoramento
    monitoring_enabled: Optional[bool] = Field(True, description="Monitoramento habilitado")
    alert_threshold_percent: Optional[float] = Field(None, description="Threshold de alerta")
    
    # Status
    contract_status: Optional[str] = Field("draft", description="Status do contrato")


class DataContractCreate(DataContractBase):
    """Schema para criação de contrato de dados"""
    pass


class DataContractUpdate(BaseUpdateSchema):
    """Schema para atualização de contrato de dados"""
    
    contract_name: Optional[str] = Field(None, description="Nome do contrato")
    contract_description: Optional[str] = Field(None, description="Descrição do contrato")
    contract_owner: Optional[str] = Field(None, description="Proprietário do contrato")
    business_domain: Optional[str] = Field(None, description="Domínio de negócio")
    
    # Integração Unity Catalog
    unity_catalog_name: Optional[str] = Field(None, description="Nome do catálogo Unity")
    unity_catalog_schema: Optional[str] = Field(None, description="Schema Unity Catalog")
    unity_catalog_table: Optional[str] = Field(None, description="Tabela Unity Catalog")
    
    # Configuração de dados
    data_location: Optional[str] = Field(None, description="Localização dos dados")
    data_format: Optional[str] = Field(None, description="Formato dos dados")
    table_format: Optional[str] = Field(None, description="Formato da tabela")
    
    # Configuração ABAC
    abac_enabled: Optional[bool] = Field(None, description="ABAC habilitado")
    abac_policy_id: Optional[UUID] = Field(None, description="ID da política ABAC")
    
    # Monitoramento
    monitoring_enabled: Optional[bool] = Field(None, description="Monitoramento habilitado")
    alert_threshold_percent: Optional[float] = Field(None, description="Threshold de alerta")
    
    # Status
    contract_status: Optional[str] = Field(None, description="Status do contrato")


class DataContract(DataContractBase, BaseSchema):
    """Schema completo para contrato de dados"""
    
    contract_id: UUID = Field(..., description="ID único do contrato")
    
    # Relacionamentos
    versions: Optional[List["ContractVersion"]] = Field(None, description="Versões do contrato")
    layouts: Optional[List["ContractLayout"]] = Field(None, description="Layouts do contrato")
    custom_properties: Optional[List["ContractCustomProperty"]] = Field(None, description="Propriedades customizadas")


class DataContractSummary(BaseSchema):
    """Schema resumido para listagem de contratos"""
    
    contract_id: UUID = Field(..., description="ID único do contrato")
    contract_name: str = Field(..., description="Nome do contrato")
    contract_description: Optional[str] = Field(None, description="Descrição do contrato")
    contract_owner: Optional[str] = Field(None, description="Proprietário do contrato")
    business_domain: Optional[str] = Field(None, description="Domínio de negócio")
    contract_status: Optional[str] = Field(None, description="Status do contrato")
    
    # Contadores
    versions_count: Optional[int] = Field(0, description="Número de versões")
    active_versions_count: Optional[int] = Field(0, description="Versões ativas")


# Forward references para evitar imports circulares
from .contract_versions import ContractVersion
from .contract_layouts import ContractLayout
from .contract_custom_properties import ContractCustomProperty

DataContract.model_rebuild()

