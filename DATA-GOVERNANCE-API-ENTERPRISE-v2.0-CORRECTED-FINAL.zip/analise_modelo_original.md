# Análise do Modelo Original - 36 Tabelas

## Tabelas Identificadas no modelo_estendido.dbml

### 1. **Contratos e Versionamento (4 tabelas)**
- `DataContracts` - Contratos principais
- `ContractVersions` - Versionamento de contratos  
- `ContractLayouts` - Layouts customizáveis
- `ContractCustomProperties` - Propriedades customizadas

### 2. **Componentes Modulares (5 tabelas)**
- `ContractFundamentals` - Informações fundamentais
- `ContractTeamDefinitions` - Definições de equipe
- `ContractSLADefinitions` - Definições de SLA
- `ContractPricingDefinitions` - Definições de precificação
- `ContractSchemaDefinitions` - Definições de schema

### 3. **Objetos e Propriedades de Dados (2 tabelas)**
- `DataObjects` - Objetos de dados
- `DataObjectProperties` - Propriedades dos objetos

### 4. **Qualidade de Dados (4 tabelas)**
- `ContractQualityDefinitions` - Definições de qualidade
- `QualityRules` - Regras de qualidade
- `PropertyQualityRuleLinks` - Links propriedades-regras
- `QualityExecutionResults` - Resultados de execução

### 5. **Métricas de Monitoramento (4 tabelas)**
- `ClusterMetrics` - Métricas de cluster
- `JobMetrics` - Métricas de jobs
- `QueryMetrics` - Métricas de queries
- `StorageMetrics` - Métricas de armazenamento

### 6. **Linhagem de Dados (1 tabela)**
- `DataLineage` - Linhagem de dados

### 7. **Usuários e Permissões (5 tabelas)**
- `Users` - Usuários
- `Groups` - Grupos
- `UserGroups` - Associação usuário-grupo
- `Permissions` - Permissões
- `GroupPermissions` - Permissões de grupo

### 8. **Tags e Entidades (3 tabelas)**
- `Entity` - Entidades genéricas
- `Tag` - Tags
- `Tagged` - Relacionamento tag-entidade

### 9. **Governança e Conformidade (2 tabelas)**
- `ABACPolicyEvaluations` - Avaliações de política ABAC
- `DataClassificationResults` - Resultados de classificação

### 10. **Integração e Sincronização (3 tabelas)**
- `ToolIntegrations` - Integrações de ferramentas
- `SyncExecutions` - Execuções de sincronização
- `SyncErrors` - Erros de sincronização

### 11. **Auditoria e Analytics (3 tabelas)**
- `AuditLog` - Log de auditoria
- `DataQualityAggregates` - Agregados de qualidade
- `DataAnomalyDetection` - Detecção de anomalias

## Total: 36 Tabelas

## Características Principais do Modelo Original

### Campos Padrão
- Todas as tabelas usam `uuid` como chave primária
- Campos de auditoria: `data_criacao` e `data_atualizacao` (timestamptz)
- Sem campo `id` sequencial

### Integração Databricks/Unity Catalog
- Campos específicos para Unity Catalog em várias tabelas
- Suporte a Delta Lake e Iceberg
- Métricas específicas da plataforma

### Governança Avançada
- Sistema ABAC (Attribute-Based Access Control)
- Classificação automática de dados
- Conformidade regulatória (LGPD, GDPR, HIPAA, etc.)

### Qualidade e Monitoramento
- Sistema robusto de regras de qualidade
- Métricas detalhadas de performance
- Detecção de anomalias com ML

### Flexibilidade
- Sistema de tags hierárquico
- Propriedades customizadas
- Layouts configuráveis
- Integrações extensíveis

## Divergências Identificadas na Implementação Atual

1. **Modelos faltantes**: Várias tabelas não foram implementadas
2. **Campos incorretos**: Uso de `id` ao invés de campos UUID específicos
3. **Relacionamentos**: Não seguem exatamente o modelo original
4. **Nomenclatura**: Alguns nomes de campos diferentes
5. **Estrutura**: Falta de componentes modulares completos

## Ação Necessária

Recriar TODOS os modelos SQLAlchemy seguindo exatamente:
- Nomes de tabelas e campos do DBML
- Tipos de dados corretos (uuid, text, timestamptz)
- Relacionamentos conforme especificado
- Todas as 36 tabelas implementadas

