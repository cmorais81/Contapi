# Guia de Instalação e Deployment
**Data Governance API Enterprise v2.0**

## 📋 Pré-requisitos

### Ambiente de Desenvolvimento
- **Python 3.11+** com pip
- **Docker 24+** e Docker Compose 2.0+
- **Git** para controle de versão
- **PostgreSQL 15+** (local ou container)
- **Redis 7.0+** (local ou container)

### Ambiente de Produção
- **Kubernetes 1.28+** com Helm 3.0+
- **PostgreSQL 15+** com alta disponibilidade
- **Redis 7.0+** em cluster
- **Load Balancer** (NGINX, HAProxy, ou cloud)
- **Monitoramento** (Prometheus, Grafana, Jaeger)

## 🚀 Instalação Local

### 1. Preparação do Ambiente

```bash
# Clone o repositório
git clone <repository-url>
cd data-governance-api-final

# Crie ambiente virtual Python
python3.11 -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows

# Instale dependências
pip install -r requirements.txt
```

### 2. Configuração de Banco de Dados

#### Opção A: PostgreSQL Local
```bash
# Instale PostgreSQL
sudo apt-get install postgresql postgresql-contrib  # Ubuntu
# ou
brew install postgresql  # macOS

# Crie banco de dados
sudo -u postgres createdb data_governance
sudo -u postgres createuser -s governance_user
sudo -u postgres psql -c "ALTER USER governance_user PASSWORD 'governance_pass';"
```

#### Opção B: PostgreSQL com Docker
```bash
# Inicie PostgreSQL
docker run -d \
  --name postgres-governance \
  -e POSTGRES_DB=data_governance \
  -e POSTGRES_USER=governance_user \
  -e POSTGRES_PASSWORD=governance_pass \
  -p 5432:5432 \
  postgres:15
```

### 3. Configuração de Redis

#### Opção A: Redis Local
```bash
# Instale Redis
sudo apt-get install redis-server  # Ubuntu
# ou
brew install redis  # macOS

# Inicie Redis
redis-server
```

#### Opção B: Redis com Docker
```bash
# Inicie Redis
docker run -d \
  --name redis-governance \
  -p 6379:6379 \
  redis:7-alpine
```

### 4. Configuração da Aplicação

```bash
# Copie arquivo de configuração
cp .env.example .env

# Edite configurações
nano .env
```

Exemplo de `.env`:
```bash
# Database
DATABASE_URL=postgresql+asyncpg://governance_user:governance_pass@localhost:5432/data_governance
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=30

# Redis
REDIS_URL=redis://localhost:6379/0

# Security
SECRET_KEY=your-super-secret-key-here-change-in-production
JWT_ALGORITHM=HS256
JWT_EXPIRE_MINUTES=1440

# API Configuration
API_V1_STR=/api/v1
PROJECT_NAME=Data Governance API
VERSION=2.0.0
DEBUG=true

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json

# Monitoring (opcional para desenvolvimento)
JAEGER_AGENT_HOST=localhost
JAEGER_AGENT_PORT=6831
PROMETHEUS_GATEWAY=localhost:9091
```

### 5. Inicialização do Banco

```bash
# Execute migrações
alembic upgrade head

# (Opcional) Popule dados de exemplo
python scripts/populate_database.py
```

### 6. Iniciar Aplicação

```bash
# Desenvolvimento
uvicorn src.app.main:app --reload --host 0.0.0.0 --port 8000

# Produção local
gunicorn src.app.main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

### 7. Verificação

```bash
# Health check
curl http://localhost:8000/health

# Documentação da API
open http://localhost:8000/docs
```

## 🐳 Instalação com Docker

### 1. Docker Compose Simples

```bash
# Inicie todos os serviços
docker-compose up -d

# Verifique logs
docker-compose logs -f api

# Execute migrações
docker-compose exec api alembic upgrade head

# Popule dados de exemplo
docker-compose exec api python scripts/populate_database.py
```

### 2. Docker Compose com Monitoramento

```bash
# Use compose com monitoramento completo
docker-compose -f docker-compose.yml -f docker-compose.monitoring.yml up -d

# Acesse serviços
# API: http://localhost:8000
# Grafana: http://localhost:3000 (admin/admin)
# Prometheus: http://localhost:9090
# Jaeger: http://localhost:16686
```

## ☸️ Deployment em Kubernetes

### 1. Preparação do Cluster

```bash
# Verifique cluster
kubectl cluster-info

# Crie namespace
kubectl create namespace data-governance

# Configure contexto
kubectl config set-context --current --namespace=data-governance
```

### 2. Configuração de Secrets

```bash
# Crie secret para banco de dados
kubectl create secret generic db-secret \
  --from-literal=url="postgresql+asyncpg://user:pass@postgres:5432/governance"

# Crie secret para Redis
kubectl create secret generic redis-secret \
  --from-literal=url="redis://redis:6379/0"

# Crie secret para JWT
kubectl create secret generic jwt-secret \
  --from-literal=secret-key="your-super-secret-key"
```

### 3. Deploy com Helm

```bash
# Adicione repositório Helm (se necessário)
helm repo add bitnami https://charts.bitnami.com/bitnami

# Instale PostgreSQL
helm install postgres bitnami/postgresql \
  --set auth.database=data_governance \
  --set auth.username=governance_user \
  --set auth.password=governance_pass

# Instale Redis
helm install redis bitnami/redis \
  --set auth.enabled=false

# Deploy da aplicação
helm install data-governance ./helm-chart \
  --values ./helm-chart/values.prod.yaml
```

### 4. Verificação do Deployment

```bash
# Verifique pods
kubectl get pods

# Verifique serviços
kubectl get services

# Verifique logs
kubectl logs -f deployment/data-governance-api

# Port forward para teste
kubectl port-forward service/data-governance-api 8000:8000
```

## 🌐 Deployment em Cloud

### AWS EKS

```bash
# Crie cluster EKS
eksctl create cluster --name data-governance --region us-west-2

# Configure kubectl
aws eks update-kubeconfig --region us-west-2 --name data-governance

# Deploy aplicação
kubectl apply -f k8s/aws/
```

### Azure AKS

```bash
# Crie cluster AKS
az aks create --resource-group myResourceGroup --name data-governance

# Configure kubectl
az aks get-credentials --resource-group myResourceGroup --name data-governance

# Deploy aplicação
kubectl apply -f k8s/azure/
```

### Google GKE

```bash
# Crie cluster GKE
gcloud container clusters create data-governance --zone us-central1-a

# Configure kubectl
gcloud container clusters get-credentials data-governance --zone us-central1-a

# Deploy aplicação
kubectl apply -f k8s/gcp/
```

## 🔧 Configuração Avançada

### 1. Alta Disponibilidade

#### PostgreSQL Master-Slave
```yaml
# postgresql-ha.yaml
apiVersion: postgresql.cnpg.io/v1
kind: Cluster
metadata:
  name: postgres-cluster
spec:
  instances: 3
  postgresql:
    parameters:
      max_connections: "200"
      shared_preload_libraries: "pg_stat_statements"
```

#### Redis Cluster
```yaml
# redis-cluster.yaml
apiVersion: redis.redis.opstreelabs.in/v1beta1
kind: RedisCluster
metadata:
  name: redis-cluster
spec:
  clusterSize: 6
  redisExporter:
    enabled: true
```

### 2. Monitoramento Completo

#### Prometheus Configuration
```yaml
# prometheus-config.yaml
global:
  scrape_interval: 15s
scrape_configs:
  - job_name: 'data-governance-api'
    static_configs:
      - targets: ['data-governance-api:8000']
    metrics_path: /metrics
```

#### Grafana Dashboards
```bash
# Importe dashboards pré-configurados
kubectl apply -f monitoring/grafana-dashboards.yaml
```

### 3. Backup e Recovery

#### Backup Automático
```bash
# Script de backup
#!/bin/bash
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d_%H%M%S).sql
aws s3 cp backup_*.sql s3://governance-backups/
```

#### Recovery
```bash
# Restore do backup
psql $DATABASE_URL < backup_20241201_120000.sql
```

## 🔒 Configuração de Segurança

### 1. SSL/TLS

```yaml
# tls-secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: tls-secret
type: kubernetes.io/tls
data:
  tls.crt: <base64-encoded-cert>
  tls.key: <base64-encoded-key>
```

### 2. Network Policies

```yaml
# network-policy.yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: data-governance-netpol
spec:
  podSelector:
    matchLabels:
      app: data-governance-api
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - podSelector:
        matchLabels:
          app: nginx-ingress
    ports:
    - protocol: TCP
      port: 8000
```

### 3. RBAC

```yaml
# rbac.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  name: data-governance-role
rules:
- apiGroups: [""]
  resources: ["secrets", "configmaps"]
  verbs: ["get", "list"]
```

## 📊 Configuração de Monitoramento

### 1. Métricas Customizadas

```python
# metrics.py
from prometheus_client import Counter, Histogram, Gauge

api_requests = Counter('api_requests_total', 'Total API requests', ['method', 'endpoint'])
request_duration = Histogram('request_duration_seconds', 'Request duration')
active_connections = Gauge('active_connections', 'Active database connections')
```

### 2. Alertas

```yaml
# alerts.yaml
groups:
- name: data-governance
  rules:
  - alert: HighErrorRate
    expr: rate(api_requests_total{status=~"5.."}[5m]) > 0.1
    for: 5m
    labels:
      severity: critical
    annotations:
      summary: High error rate detected
```

## 🧪 Testes de Deployment

### 1. Smoke Tests

```bash
#!/bin/bash
# smoke-test.sh

# Health check
curl -f http://localhost:8000/health || exit 1

# API test
curl -f http://localhost:8000/api/v1/data-contracts || exit 1

# Database connectivity
curl -f http://localhost:8000/health/db || exit 1

echo "All smoke tests passed!"
```

### 2. Load Tests

```bash
# Instale k6
sudo apt-get install k6

# Execute teste de carga
k6 run tests/load/api-load-test.js
```

## 🔄 CI/CD Pipeline

### 1. GitHub Actions

```yaml
# .github/workflows/deploy.yml
name: Deploy
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Build and push Docker image
      run: |
        docker build -t data-governance-api:${{ github.sha }} .
        docker push data-governance-api:${{ github.sha }}
    - name: Deploy to Kubernetes
      run: |
        kubectl set image deployment/data-governance-api \
          api=data-governance-api:${{ github.sha }}
```

### 2. GitLab CI

```yaml
# .gitlab-ci.yml
stages:
  - build
  - test
  - deploy

build:
  stage: build
  script:
    - docker build -t $CI_REGISTRY_IMAGE:$CI_COMMIT_SHA .
    - docker push $CI_REGISTRY_IMAGE:$CI_COMMIT_SHA

deploy:
  stage: deploy
  script:
    - helm upgrade --install data-governance ./helm-chart
  only:
    - main
```

## 🚨 Troubleshooting

### Problemas Comuns

#### 1. Erro de Conexão com Banco
```bash
# Verifique conectividade
pg_isready -h localhost -p 5432

# Verifique logs
docker logs postgres-governance
```

#### 2. Erro de Permissão
```bash
# Verifique permissões do usuário
sudo -u postgres psql -c "\du"

# Conceda permissões
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE data_governance TO governance_user;"
```

#### 3. Erro de Memória
```bash
# Verifique uso de memória
docker stats

# Ajuste limites
docker-compose up -d --scale api=2
```

### Logs e Debugging

```bash
# Logs da aplicação
kubectl logs -f deployment/data-governance-api

# Logs do banco
kubectl logs -f statefulset/postgres

# Logs do Redis
kubectl logs -f deployment/redis

# Debug de rede
kubectl exec -it pod/data-governance-api-xxx -- nslookup postgres
```

## 📞 Suporte

### Documentação Adicional
- **[DOCUMENTATION_COMPLETE.md](DOCUMENTATION_COMPLETE.md)** - Documentação completa
- **[TECHNICAL_GUIDE_UPDATED.md](TECHNICAL_GUIDE_UPDATED.md)** - Guia técnico
- **API Docs:** http://localhost:8000/docs

### Contato
- **Issues:** Use o sistema de issues do repositório
- **Documentação:** Consulte os arquivos de documentação
- **Comunidade:** Participe das discussões

---

*Guia de Instalação e Deployment - Data Governance API Enterprise v2.0*  
*Desenvolvido por Carlos Morais - Dezembro 2024*

