"""
Testes de integração para endpoints
Autor: Carlos Morais

Testes end-to-end para validação dos endpoints da API.
"""

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, AsyncMock
import json


class TestDataContractEndpoints:
    """Testes de integração para endpoints de contratos de dados"""
    
    def test_health_check(self, client: TestClient):
        """Teste do endpoint de health check"""
        # Act
        response = client.get("/api/v1/health")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "timestamp" in data
        assert "version" in data
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_create_contract_success(self, mock_service, client: TestClient, sample_data_contract_data):
        """Teste de criação bem-sucedida de contrato"""
        # Arrange
        mock_contract = {
            "id": "12345678-1234-5678-9012-123456789012",
            **sample_data_contract_data
        }
        mock_service.return_value.create = AsyncMock(return_value=mock_contract)
        
        # Act
        response = client.post("/api/v1/contracts", json=sample_data_contract_data)
        
        # Assert
        assert response.status_code == 201
        data = response.json()
        assert data["contract_name"] == sample_data_contract_data["contract_name"]
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_create_contract_validation_error(self, mock_service, client: TestClient):
        """Teste de erro de validação na criação"""
        # Arrange
        invalid_data = {"contract_name": ""}  # Nome vazio
        
        # Act
        response = client.post("/api/v1/contracts", json=invalid_data)
        
        # Assert
        assert response.status_code == 422  # Validation error
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_get_contract_success(self, mock_service, client: TestClient):
        """Teste de busca bem-sucedida de contrato"""
        # Arrange
        contract_id = "12345678-1234-5678-9012-123456789012"
        mock_contract = {
            "id": contract_id,
            "contract_name": "Test Contract",
            "contract_status": "ativo"
        }
        mock_service.return_value.get = AsyncMock(return_value=mock_contract)
        
        # Act
        response = client.get(f"/api/v1/contracts/{contract_id}")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["id"] == contract_id
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_get_contract_not_found(self, mock_service, client: TestClient):
        """Teste de contrato não encontrado"""
        # Arrange
        contract_id = "12345678-1234-5678-9012-123456789012"
        mock_service.return_value.get = AsyncMock(side_effect=Exception("Not found"))
        
        # Act
        response = client.get(f"/api/v1/contracts/{contract_id}")
        
        # Assert
        assert response.status_code == 404
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_list_contracts(self, mock_service, client: TestClient):
        """Teste de listagem de contratos"""
        # Arrange
        mock_contracts = [
            {"id": "1", "contract_name": "Contract 1"},
            {"id": "2", "contract_name": "Contract 2"}
        ]
        mock_service.return_value.get_multi = AsyncMock(return_value=mock_contracts)
        
        # Act
        response = client.get("/api/v1/contracts")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2
        assert data[0]["contract_name"] == "Contract 1"
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_list_contracts_with_pagination(self, mock_service, client: TestClient):
        """Teste de listagem com paginação"""
        # Arrange
        mock_contracts = [{"id": "1", "contract_name": "Contract 1"}]
        mock_service.return_value.get_multi = AsyncMock(return_value=mock_contracts)
        
        # Act
        response = client.get("/api/v1/contracts?skip=10&limit=5")
        
        # Assert
        assert response.status_code == 200
        # Verificar se os parâmetros foram passados corretamente
        mock_service.return_value.get_multi.assert_called_with(skip=10, limit=5, filters=None)
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_update_contract_success(self, mock_service, client: TestClient):
        """Teste de atualização bem-sucedida"""
        # Arrange
        contract_id = "12345678-1234-5678-9012-123456789012"
        update_data = {"contract_description": "Updated description"}
        mock_contract = {
            "id": contract_id,
            "contract_name": "Test Contract",
            "contract_description": "Updated description"
        }
        mock_service.return_value.update = AsyncMock(return_value=mock_contract)
        
        # Act
        response = client.put(f"/api/v1/contracts/{contract_id}", json=update_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["contract_description"] == "Updated description"
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_delete_contract_success(self, mock_service, client: TestClient):
        """Teste de remoção bem-sucedida"""
        # Arrange
        contract_id = "12345678-1234-5678-9012-123456789012"
        mock_service.return_value.delete = AsyncMock(return_value=True)
        
        # Act
        response = client.delete(f"/api/v1/contracts/{contract_id}")
        
        # Assert
        assert response.status_code == 204
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_activate_contract(self, mock_service, client: TestClient):
        """Teste de ativação de contrato"""
        # Arrange
        contract_id = "12345678-1234-5678-9012-123456789012"
        mock_contract = {
            "id": contract_id,
            "contract_status": "ativo"
        }
        mock_service.return_value.activate_contract = AsyncMock(return_value=mock_contract)
        
        # Act
        response = client.post(f"/api/v1/contracts/{contract_id}/activate")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["contract_status"] == "ativo"
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_deactivate_contract(self, mock_service, client: TestClient):
        """Teste de desativação de contrato"""
        # Arrange
        contract_id = "12345678-1234-5678-9012-123456789012"
        mock_contract = {
            "id": contract_id,
            "contract_status": "inativo"
        }
        mock_service.return_value.deactivate_contract = AsyncMock(return_value=mock_contract)
        
        # Act
        response = client.post(f"/api/v1/contracts/{contract_id}/deactivate")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["contract_status"] == "inativo"
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_duplicate_contract(self, mock_service, client: TestClient):
        """Teste de duplicação de contrato"""
        # Arrange
        contract_id = "12345678-1234-5678-9012-123456789012"
        new_contract_id = "87654321-4321-8765-2109-876543210987"
        duplicate_data = {"new_name": "Duplicated Contract"}
        
        mock_contract = {
            "id": new_contract_id,
            "contract_name": "Duplicated Contract"
        }
        mock_service.return_value.duplicate_contract = AsyncMock(return_value=mock_contract)
        
        # Act
        response = client.post(f"/api/v1/contracts/{contract_id}/duplicate", json=duplicate_data)
        
        # Assert
        assert response.status_code == 201
        data = response.json()
        assert data["contract_name"] == "Duplicated Contract"
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_get_contract_health(self, mock_service, client: TestClient):
        """Teste de obtenção de saúde do contrato"""
        # Arrange
        contract_id = "12345678-1234-5678-9012-123456789012"
        mock_health = {
            "overall_score": 85.5,
            "quality_score": 90.0,
            "usage_score": 80.0,
            "compliance_score": 87.0
        }
        mock_service.return_value.calculate_health_score = AsyncMock(return_value=mock_health)
        
        # Act
        response = client.get(f"/api/v1/contracts/{contract_id}/health")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["overall_score"] == 85.5
        assert "quality_score" in data
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_get_contract_metrics(self, mock_service, client: TestClient):
        """Teste de obtenção de métricas do contrato"""
        # Arrange
        contract_id = "12345678-1234-5678-9012-123456789012"
        mock_metrics = {
            "usage_statistics": {"total_queries": 1000},
            "quality_trends": {"trend": "improving"},
            "performance_metrics": {"avg_response_time": 150}
        }
        mock_service.return_value.get_contract_metrics = AsyncMock(return_value=mock_metrics)
        
        # Act
        response = client.get(f"/api/v1/contracts/{contract_id}/metrics")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert "usage_statistics" in data
        assert "quality_trends" in data
    
    @patch('src.app.services.data_contracts.DataContractService')
    def test_search_contracts(self, mock_service, client: TestClient):
        """Teste de busca de contratos"""
        # Arrange
        search_term = "test contract"
        mock_contracts = [
            {"id": "1", "contract_name": "Test Contract 1"},
            {"id": "2", "contract_name": "Test Contract 2"}
        ]
        mock_service.return_value.search = AsyncMock(return_value=mock_contracts)
        
        # Act
        response = client.get(f"/api/v1/contracts/search?q={search_term}")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert len(data) == 2
        assert "Test Contract" in data[0]["contract_name"]


class TestDataLineageEndpoints:
    """Testes de integração para endpoints de lineage"""
    
    @patch('src.app.services.data_lineage.DataLineageService')
    def test_create_lineage(self, mock_service, client: TestClient, sample_data_lineage_data):
        """Teste de criação de lineage"""
        # Arrange
        mock_lineage = {
            "id": "12345678-1234-5678-9012-123456789012",
            **sample_data_lineage_data
        }
        mock_service.return_value.create = AsyncMock(return_value=mock_lineage)
        
        # Act
        response = client.post("/api/v1/lineage", json=sample_data_lineage_data)
        
        # Assert
        assert response.status_code == 201
        data = response.json()
        assert data["source_object_name"] == sample_data_lineage_data["source_object_name"]
    
    @patch('src.app.services.data_lineage.DataLineageService')
    def test_get_lineage_graph(self, mock_service, client: TestClient):
        """Teste de obtenção do grafo de lineage"""
        # Arrange
        object_name = "test_table"
        mock_graph = {
            "nodes": [
                {"id": "table1", "type": "table"},
                {"id": "table2", "type": "table"}
            ],
            "edges": [
                {"source": "table1", "target": "table2", "type": "direct"}
            ]
        }
        mock_service.return_value.get_lineage_graph = AsyncMock(return_value=mock_graph)
        
        # Act
        response = client.get(f"/api/v1/lineage/graph/{object_name}")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert "nodes" in data
        assert "edges" in data
        assert len(data["nodes"]) == 2
    
    @patch('src.app.services.data_lineage.DataLineageService')
    def test_impact_analysis(self, mock_service, client: TestClient):
        """Teste de análise de impacto"""
        # Arrange
        analysis_data = {
            "object_name": "source_table",
            "change_type": "schema_change",
            "depth": 3
        }
        mock_impact = {
            "affected_objects": ["table1", "table2", "view1"],
            "impact_score": "HIGH",
            "recommendations": ["Update downstream views", "Notify data consumers"]
        }
        mock_service.return_value.analyze_impact = AsyncMock(return_value=mock_impact)
        
        # Act
        response = client.post("/api/v1/lineage/impact-analysis", json=analysis_data)
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert "affected_objects" in data
        assert "impact_score" in data
        assert data["impact_score"] == "HIGH"


class TestAlertEndpoints:
    """Testes de integração para endpoints de alertas"""
    
    @patch('src.app.services.alerts.AlertService')
    def test_create_alert(self, mock_service, client: TestClient, sample_alert_data):
        """Teste de criação de alerta"""
        # Arrange
        mock_alert = {
            "id": "12345678-1234-5678-9012-123456789012",
            **sample_alert_data
        }
        mock_service.return_value.create = AsyncMock(return_value=mock_alert)
        
        # Act
        response = client.post("/api/v1/alerts", json=sample_alert_data)
        
        # Assert
        assert response.status_code == 201
        data = response.json()
        assert data["alert_name"] == sample_alert_data["alert_name"]
    
    @patch('src.app.services.alerts.AlertService')
    def test_trigger_alert(self, mock_service, client: TestClient):
        """Teste de disparo de alerta"""
        # Arrange
        trigger_data = {
            "alert_type": "quality",
            "severity": "high",
            "message": "Quality threshold exceeded",
            "source_object": "test_table"
        }
        mock_alert_instance = {
            "id": "12345678-1234-5678-9012-123456789012",
            "status": "triggered",
            **trigger_data
        }
        mock_service.return_value.trigger_alert = AsyncMock(return_value=mock_alert_instance)
        
        # Act
        response = client.post("/api/v1/alerts/trigger", json=trigger_data)
        
        # Assert
        assert response.status_code == 201
        data = response.json()
        assert data["status"] == "triggered"
        assert data["severity"] == "high"
    
    @patch('src.app.services.alerts.AlertService')
    def test_get_alert_dashboard(self, mock_service, client: TestClient):
        """Teste do dashboard de alertas"""
        # Arrange
        mock_dashboard = {
            "total_alerts": 150,
            "active_alerts": 12,
            "critical_alerts": 3,
            "alerts_by_type": {
                "quality": 8,
                "performance": 3,
                "security": 1
            },
            "recent_alerts": []
        }
        mock_service.return_value.get_dashboard = AsyncMock(return_value=mock_dashboard)
        
        # Act
        response = client.get("/api/v1/alerts/dashboard")
        
        # Assert
        assert response.status_code == 200
        data = response.json()
        assert data["total_alerts"] == 150
        assert data["active_alerts"] == 12
        assert "alerts_by_type" in data


class TestErrorHandling:
    """Testes de tratamento de erros"""
    
    def test_invalid_uuid_format(self, client: TestClient):
        """Teste de formato UUID inválido"""
        # Act
        response = client.get("/api/v1/contracts/invalid-uuid")
        
        # Assert
        assert response.status_code == 422  # Validation error
    
    def test_method_not_allowed(self, client: TestClient):
        """Teste de método não permitido"""
        # Act
        response = client.patch("/api/v1/health")  # PATCH não é permitido
        
        # Assert
        assert response.status_code == 405
    
    def test_not_found_endpoint(self, client: TestClient):
        """Teste de endpoint não encontrado"""
        # Act
        response = client.get("/api/v1/nonexistent")
        
        # Assert
        assert response.status_code == 404
    
    def test_invalid_json_payload(self, client: TestClient):
        """Teste de payload JSON inválido"""
        # Act
        response = client.post(
            "/api/v1/contracts",
            data="invalid json",
            headers={"Content-Type": "application/json"}
        )
        
        # Assert
        assert response.status_code == 422


class TestAuthentication:
    """Testes de autenticação (quando implementada)"""
    
    @pytest.mark.skip(reason="Authentication not implemented yet")
    def test_unauthorized_access(self, client: TestClient):
        """Teste de acesso não autorizado"""
        # Act
        response = client.get("/api/v1/contracts")
        
        # Assert
        assert response.status_code == 401
    
    @pytest.mark.skip(reason="Authentication not implemented yet")
    def test_forbidden_access(self, client: TestClient):
        """Teste de acesso proibido"""
        # Arrange - simular token com permissões insuficientes
        headers = {"Authorization": "Bearer invalid-token"}
        
        # Act
        response = client.delete("/api/v1/contracts/123", headers=headers)
        
        # Assert
        assert response.status_code == 403


class TestCORS:
    """Testes de CORS"""
    
    def test_cors_preflight(self, client: TestClient):
        """Teste de preflight CORS"""
        # Act
        response = client.options(
            "/api/v1/contracts",
            headers={
                "Origin": "http://localhost:3000",
                "Access-Control-Request-Method": "POST",
                "Access-Control-Request-Headers": "Content-Type"
            }
        )
        
        # Assert
        assert response.status_code == 200
        assert "Access-Control-Allow-Origin" in response.headers
    
    def test_cors_actual_request(self, client: TestClient):
        """Teste de requisição CORS real"""
        # Act
        response = client.get(
            "/api/v1/health",
            headers={"Origin": "http://localhost:3000"}
        )
        
        # Assert
        assert response.status_code == 200
        assert "Access-Control-Allow-Origin" in response.headers

