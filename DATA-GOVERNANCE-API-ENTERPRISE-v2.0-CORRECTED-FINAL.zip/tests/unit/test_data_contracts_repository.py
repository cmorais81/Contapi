"""
Testes unitários para DataContractsRepository
Seguindo exatamente o modelo_estendido.dbml original
Autor: Carlos Morais
"""

import pytest
from uuid import uuid4

from src.app.repositories.data_contracts import DataContractsRepository
from src.app.models.data_contracts import DataContracts
from tests.conftest import TestDataFactory


@pytest.mark.unit
@pytest.mark.database
class TestDataContractsRepository:
    """Testes para DataContractsRepository"""
    
    @pytest.mark.asyncio
    async def test_create_contract(self, db_session):
        """Testa criação de contrato"""
        repository = DataContractsRepository(db_session)
        
        contract_data = TestDataFactory.create_contract_data()
        contract = await repository.create(contract_data)
        
        assert contract.contract_id is not None
        assert contract.contract_name == contract_data["contract_name"]
        assert contract.contract_description == contract_data["contract_description"]
        assert contract.contract_owner == contract_data["contract_owner"]
        assert contract.business_domain == contract_data["business_domain"]
        assert contract.contract_status == contract_data["contract_status"]
        assert contract.data_criacao is not None
    
    @pytest.mark.asyncio
    async def test_get_by_id(self, db_session):
        """Testa busca por ID"""
        repository = DataContractsRepository(db_session)
        
        # Criar contrato
        contract_data = TestDataFactory.create_contract_data()
        created_contract = await repository.create(contract_data)
        
        # Buscar por ID
        found_contract = await repository.get_by_id(created_contract.contract_id)
        
        assert found_contract is not None
        assert found_contract.contract_id == created_contract.contract_id
        assert found_contract.contract_name == created_contract.contract_name
    
    @pytest.mark.asyncio
    async def test_get_by_id_not_found(self, db_session):
        """Testa busca por ID inexistente"""
        repository = DataContractsRepository(db_session)
        
        non_existent_id = uuid4()
        contract = await repository.get_by_id(non_existent_id)
        
        assert contract is None
    
    @pytest.mark.asyncio
    async def test_get_by_name(self, db_session):
        """Testa busca por nome"""
        repository = DataContractsRepository(db_session)
        
        # Criar contrato
        contract_data = TestDataFactory.create_contract_data()
        created_contract = await repository.create(contract_data)
        
        # Buscar por nome
        found_contract = await repository.get_by_name(created_contract.contract_name)
        
        assert found_contract is not None
        assert found_contract.contract_name == created_contract.contract_name
        assert found_contract.contract_id == created_contract.contract_id
    
    @pytest.mark.asyncio
    async def test_get_by_name_not_found(self, db_session):
        """Testa busca por nome inexistente"""
        repository = DataContractsRepository(db_session)
        
        contract = await repository.get_by_name("non_existent_contract")
        
        assert contract is None
    
    @pytest.mark.asyncio
    async def test_get_by_domain(self, db_session):
        """Testa busca por domínio"""
        repository = DataContractsRepository(db_session)
        
        domain = "test_domain"
        
        # Criar contratos no mesmo domínio
        contract1_data = TestDataFactory.create_contract_data(business_domain=domain)
        contract2_data = TestDataFactory.create_contract_data(business_domain=domain)
        
        await repository.create(contract1_data)
        await repository.create(contract2_data)
        
        # Criar contrato em domínio diferente
        other_contract_data = TestDataFactory.create_contract_data(business_domain="other_domain")
        await repository.create(other_contract_data)
        
        # Buscar por domínio
        contracts = await repository.get_by_domain(domain)
        
        assert len(contracts) == 2
        assert all(c.business_domain == domain for c in contracts)
    
    @pytest.mark.asyncio
    async def test_get_by_owner(self, db_session):
        """Testa busca por proprietário"""
        repository = DataContractsRepository(db_session)
        
        owner = "test_owner"
        
        # Criar contratos do mesmo proprietário
        contract1_data = TestDataFactory.create_contract_data(contract_owner=owner)
        contract2_data = TestDataFactory.create_contract_data(contract_owner=owner)
        
        await repository.create(contract1_data)
        await repository.create(contract2_data)
        
        # Criar contrato de proprietário diferente
        other_contract_data = TestDataFactory.create_contract_data(contract_owner="other_owner")
        await repository.create(other_contract_data)
        
        # Buscar por proprietário
        contracts = await repository.get_by_owner(owner)
        
        assert len(contracts) == 2
        assert all(c.contract_owner == owner for c in contracts)
    
    @pytest.mark.asyncio
    async def test_get_by_status(self, db_session):
        """Testa busca por status"""
        repository = DataContractsRepository(db_session)
        
        status = "active"
        
        # Criar contratos com mesmo status
        contract1_data = TestDataFactory.create_contract_data(contract_status=status)
        contract2_data = TestDataFactory.create_contract_data(contract_status=status)
        
        await repository.create(contract1_data)
        await repository.create(contract2_data)
        
        # Criar contrato com status diferente
        other_contract_data = TestDataFactory.create_contract_data(contract_status="draft")
        await repository.create(other_contract_data)
        
        # Buscar por status
        contracts = await repository.get_by_status(status)
        
        assert len(contracts) == 2
        assert all(c.contract_status == status for c in contracts)
    
    @pytest.mark.asyncio
    async def test_get_unity_catalog_contracts(self, db_session):
        """Testa busca de contratos Unity Catalog"""
        repository = DataContractsRepository(db_session)
        
        # Criar contrato com Unity Catalog
        unity_contract_data = TestDataFactory.create_contract_data(
            unity_catalog_name="test_catalog",
            unity_catalog_schema="test_schema",
            unity_catalog_table="test_table"
        )
        await repository.create(unity_contract_data)
        
        # Criar contrato sem Unity Catalog
        regular_contract_data = TestDataFactory.create_contract_data()
        await repository.create(regular_contract_data)
        
        # Buscar contratos Unity Catalog
        unity_contracts = await repository.get_unity_catalog_contracts()
        
        assert len(unity_contracts) == 1
        assert unity_contracts[0].unity_catalog_name == "test_catalog"
        assert unity_contracts[0].unity_catalog_schema == "test_schema"
        assert unity_contracts[0].unity_catalog_table == "test_table"
    
    @pytest.mark.asyncio
    async def test_get_abac_enabled_contracts(self, db_session):
        """Testa busca de contratos com ABAC"""
        repository = DataContractsRepository(db_session)
        
        # Criar contrato com ABAC
        abac_contract_data = TestDataFactory.create_contract_data(abac_enabled=True)
        await repository.create(abac_contract_data)
        
        # Criar contrato sem ABAC
        regular_contract_data = TestDataFactory.create_contract_data(abac_enabled=False)
        await repository.create(regular_contract_data)
        
        # Buscar contratos ABAC
        abac_contracts = await repository.get_abac_enabled_contracts()
        
        assert len(abac_contracts) == 1
        assert abac_contracts[0].abac_enabled is True
    
    @pytest.mark.asyncio
    async def test_get_monitoring_enabled_contracts(self, db_session):
        """Testa busca de contratos com monitoramento"""
        repository = DataContractsRepository(db_session)
        
        # Criar contrato com monitoramento
        monitoring_contract_data = TestDataFactory.create_contract_data(monitoring_enabled=True)
        await repository.create(monitoring_contract_data)
        
        # Criar contrato sem monitoramento
        regular_contract_data = TestDataFactory.create_contract_data(monitoring_enabled=False)
        await repository.create(regular_contract_data)
        
        # Buscar contratos com monitoramento
        monitoring_contracts = await repository.get_monitoring_enabled_contracts()
        
        assert len(monitoring_contracts) == 1
        assert monitoring_contracts[0].monitoring_enabled is True
    
    @pytest.mark.asyncio
    async def test_search_contracts(self, db_session):
        """Testa busca textual de contratos"""
        repository = DataContractsRepository(db_session)
        
        # Criar contratos com termos específicos
        contract1_data = TestDataFactory.create_contract_data(
            contract_name="customer_data_contract",
            contract_description="Contrato para dados de clientes"
        )
        contract2_data = TestDataFactory.create_contract_data(
            contract_name="product_data_contract", 
            contract_description="Contrato para dados de produtos"
        )
        contract3_data = TestDataFactory.create_contract_data(
            contract_name="sales_contract",
            contract_description="Contrato para vendas"
        )
        
        await repository.create(contract1_data)
        await repository.create(contract2_data)
        await repository.create(contract3_data)
        
        # Buscar por "customer"
        customer_contracts = await repository.search_contracts("customer")
        assert len(customer_contracts) == 1
        assert "customer" in customer_contracts[0].contract_name.lower()
        
        # Buscar por "contract"
        all_contracts = await repository.search_contracts("contract")
        assert len(all_contracts) == 3
        
        # Buscar por "dados"
        data_contracts = await repository.search_contracts("dados")
        assert len(data_contracts) == 2
    
    @pytest.mark.asyncio
    async def test_update_contract(self, db_session):
        """Testa atualização de contrato"""
        repository = DataContractsRepository(db_session)
        
        # Criar contrato
        contract_data = TestDataFactory.create_contract_data()
        created_contract = await repository.create(contract_data)
        
        # Atualizar contrato
        update_data = {
            "contract_description": "Descrição atualizada",
            "contract_status": "active"
        }
        updated_contract = await repository.update(created_contract.contract_id, update_data)
        
        assert updated_contract is not None
        assert updated_contract.contract_description == "Descrição atualizada"
        assert updated_contract.contract_status == "active"
        assert updated_contract.data_atualizacao is not None
    
    @pytest.mark.asyncio
    async def test_delete_contract(self, db_session):
        """Testa remoção de contrato"""
        repository = DataContractsRepository(db_session)
        
        # Criar contrato
        contract_data = TestDataFactory.create_contract_data()
        created_contract = await repository.create(contract_data)
        
        # Verificar que existe
        found_contract = await repository.get_by_id(created_contract.contract_id)
        assert found_contract is not None
        
        # Remover contrato
        deleted = await repository.delete(created_contract.contract_id)
        assert deleted is True
        
        # Verificar que foi removido
        found_contract = await repository.get_by_id(created_contract.contract_id)
        assert found_contract is None
    
    @pytest.mark.asyncio
    async def test_exists(self, db_session):
        """Testa verificação de existência"""
        repository = DataContractsRepository(db_session)
        
        # Criar contrato
        contract_data = TestDataFactory.create_contract_data()
        created_contract = await repository.create(contract_data)
        
        # Verificar existência por nome
        exists = await repository.exists(contract_name=created_contract.contract_name)
        assert exists is True
        
        # Verificar inexistência
        not_exists = await repository.exists(contract_name="non_existent_contract")
        assert not_exists is False
    
    @pytest.mark.asyncio
    async def test_get_contracts_stats(self, db_session):
        """Testa estatísticas de contratos"""
        repository = DataContractsRepository(db_session)
        
        # Criar contratos com diferentes configurações
        await repository.create(TestDataFactory.create_contract_data(
            contract_status="active",
            abac_enabled=True,
            monitoring_enabled=True
        ))
        await repository.create(TestDataFactory.create_contract_data(
            contract_status="draft",
            abac_enabled=False,
            monitoring_enabled=True
        ))
        await repository.create(TestDataFactory.create_contract_data(
            contract_status="active",
            abac_enabled=True,
            monitoring_enabled=False
        ))
        
        # Obter estatísticas
        stats = await repository.get_contracts_stats()
        
        assert stats["total"] == 3
        assert stats["by_status"]["active"] == 2
        assert stats["by_status"]["draft"] == 1
        assert stats["abac_enabled"] == 2
        assert stats["monitoring_enabled"] == 2

