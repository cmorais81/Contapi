"""
Testes unitários para DataLineageService
Autor: Carlos Morais
"""

import pytest
from unittest.mock import Mock, patch, AsyncMock
from uuid import uuid4
from datetime import datetime

from src.app.services.data_lineage import DataLineageService
from src.app.schemas.data_lineage import DataLineageCreate, DataLineageImpactAnalysis
from src.app.core.exceptions import ValidationError, NotFoundError


class TestDataLineageService:
    """Testes para DataLineageService"""
    
    @pytest.fixture
    def mock_db(self):
        """Mock da sessão do banco"""
        return Mock()
    
    @pytest.fixture
    def lineage_service(self, mock_db):
        """Instância do serviço com mocks"""
        with patch('src.app.services.data_lineage.DataLineageRepository') as mock_repo:
            service = DataLineageService(mock_db)
            service.lineage_repo = mock_repo.return_value
            return service
    
    @pytest.fixture
    def sample_lineage_data(self):
        """Dados de exemplo para linhagem"""
        return DataLineageCreate(
            source_catalog="catalog1",
            source_schema="schema1",
            source_table="table1",
            target_catalog="catalog2",
            target_schema="schema2",
            target_table="table2",
            transformation_type="ETL",
            transformation_description="Transformação de dados de vendas",
            lineage_level="table",
            confidence_score=0.95
        )
    
    @pytest.mark.asyncio
    async def test_create_lineage_success(self, lineage_service, sample_lineage_data):
        """Testa criação bem-sucedida de linhagem"""
        # Arrange
        user_id = uuid4()
        expected_lineage = Mock()
        expected_lineage.id = uuid4()
        
        lineage_service.lineage_repo.create.return_value = expected_lineage
        lineage_service.lineage_repo.exists_lineage.return_value = False
        
        # Act
        result = await lineage_service.create_lineage(sample_lineage_data, user_id)
        
        # Assert
        assert result == expected_lineage
        lineage_service.lineage_repo.exists_lineage.assert_called_once()
        lineage_service.lineage_repo.create.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_create_lineage_duplicate(self, lineage_service, sample_lineage_data):
        """Testa criação de linhagem duplicada"""
        # Arrange
        user_id = uuid4()
        lineage_service.lineage_repo.exists_lineage.return_value = True
        
        # Act & Assert
        with pytest.raises(ValidationError, match="Linhagem já existe"):
            await lineage_service.create_lineage(sample_lineage_data, user_id)
    
    @pytest.mark.asyncio
    async def test_analyze_impact_downstream(self, lineage_service):
        """Testa análise de impacto downstream"""
        # Arrange
        analysis_params = DataLineageImpactAnalysis(
            object_identifier="catalog.schema.table",
            analysis_type="downstream",
            max_depth=3,
            include_columns=False
        )
        
        mock_downstream = [
            {"target_full_name": "catalog.schema.table2", "transformation_type": "ETL"},
            {"target_full_name": "catalog.schema.table3", "transformation_type": "VIEW"}
        ]
        
        lineage_service.lineage_repo.get_downstream_lineage.return_value = mock_downstream
        
        # Act
        result = await lineage_service.analyze_impact(analysis_params)
        
        # Assert
        assert result.object_identifier == analysis_params.object_identifier
        assert result.analysis_type == "downstream"
        assert len(result.affected_objects) == 2
        assert result.impact_summary["total_affected"] == 2
    
    @pytest.mark.asyncio
    async def test_get_lineage_graph(self, lineage_service):
        """Testa geração de grafo de linhagem"""
        # Arrange
        center_identifier = "catalog.schema.table"
        max_depth = 2
        
        mock_upstream = [{"source_full_name": "catalog.schema.source1"}]
        mock_downstream = [{"target_full_name": "catalog.schema.target1"}]
        
        lineage_service.lineage_repo.get_upstream_lineage.return_value = mock_upstream
        lineage_service.lineage_repo.get_downstream_lineage.return_value = mock_downstream
        
        # Act
        result = await lineage_service.get_lineage_graph(center_identifier, max_depth)
        
        # Assert
        assert result.center_object == center_identifier
        assert len(result.nodes) >= 3  # center + upstream + downstream
        assert len(result.edges) >= 2  # connections
    
    @pytest.mark.asyncio
    async def test_validate_lineage_integrity(self, lineage_service):
        """Testa validação de integridade"""
        # Arrange
        mock_orphans = [{"id": uuid4(), "issue": "Missing source"}]
        mock_cycles = []
        mock_duplicates = []
        
        lineage_service.lineage_repo.find_orphan_lineages.return_value = mock_orphans
        lineage_service.lineage_repo.find_circular_dependencies.return_value = mock_cycles
        lineage_service.lineage_repo.find_duplicate_lineages.return_value = mock_duplicates
        
        # Act
        result = await lineage_service.validate_lineage_integrity()
        
        # Assert
        assert "orphan_lineages" in result
        assert "circular_dependencies" in result
        assert "duplicate_lineages" in result
        assert result["health_score"] < 100  # Tem problemas
    
    @pytest.mark.asyncio
    async def test_get_lineage_statistics(self, lineage_service):
        """Testa obtenção de estatísticas"""
        # Arrange
        lineage_service.lineage_repo.count.return_value = 100
        lineage_service.lineage_repo.count_by_type.return_value = {
            "ETL": 60,
            "VIEW": 30,
            "COPY": 10
        }
        lineage_service.lineage_repo.get_coverage_stats.return_value = {
            "total_objects": 500,
            "objects_with_lineage": 300
        }
        
        # Act
        result = await lineage_service.get_lineage_statistics()
        
        # Assert
        assert result["total_lineages"] == 100
        assert result["by_transformation_type"]["ETL"] == 60
        assert result["coverage"]["percentage"] == 60.0
    
    def test_calculate_full_name(self, lineage_service):
        """Testa cálculo de nome completo"""
        # Test cases
        test_cases = [
            ("cat", "sch", "tbl", "cat.sch.tbl"),
            (None, "sch", "tbl", "sch.tbl"),
            (None, None, "tbl", "tbl"),
            ("", "sch", "tbl", "sch.tbl")
        ]
        
        for catalog, schema, table, expected in test_cases:
            result = lineage_service._calculate_full_name(catalog, schema, table)
            assert result == expected
    
    def test_validate_lineage_data(self, lineage_service, sample_lineage_data):
        """Testa validação de dados de linhagem"""
        # Valid data should not raise
        lineage_service._validate_lineage_data(sample_lineage_data)
        
        # Invalid confidence score
        sample_lineage_data.confidence_score = 1.5
        with pytest.raises(ValidationError, match="Score de confiança deve estar entre 0 e 1"):
            lineage_service._validate_lineage_data(sample_lineage_data)
        
        # Same source and target
        sample_lineage_data.confidence_score = 0.95
        sample_lineage_data.target_catalog = sample_lineage_data.source_catalog
        sample_lineage_data.target_schema = sample_lineage_data.source_schema
        sample_lineage_data.target_table = sample_lineage_data.source_table
        
        with pytest.raises(ValidationError, match="Fonte e destino não podem ser iguais"):
            lineage_service._validate_lineage_data(sample_lineage_data)
    
    @pytest.mark.asyncio
    async def test_refresh_lineage_metadata(self, lineage_service):
        """Testa atualização de metadados"""
        # Arrange
        lineage_id = uuid4()
        mock_lineage = Mock()
        mock_lineage.id = lineage_id
        mock_lineage.confidence_score = 0.8
        
        lineage_service.lineage_repo.get.return_value = mock_lineage
        lineage_service.lineage_repo.update.return_value = mock_lineage
        
        # Act
        result = await lineage_service.refresh_lineage_metadata(lineage_id)
        
        # Assert
        assert result == mock_lineage
        lineage_service.lineage_repo.get.assert_called_once_with(lineage_id)
        lineage_service.lineage_repo.update.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_refresh_lineage_metadata_not_found(self, lineage_service):
        """Testa atualização de metadados - linhagem não encontrada"""
        # Arrange
        lineage_id = uuid4()
        lineage_service.lineage_repo.get.return_value = None
        
        # Act & Assert
        with pytest.raises(NotFoundError, match="Linhagem não encontrada"):
            await lineage_service.refresh_lineage_metadata(lineage_id)


class TestDataLineageIntegration:
    """Testes de integração para Data Lineage"""
    
    @pytest.mark.asyncio
    async def test_full_lineage_workflow(self):
        """Testa fluxo completo de linhagem"""
        # Este teste seria executado com banco real em ambiente de teste
        pass
    
    @pytest.mark.asyncio
    async def test_complex_impact_analysis(self):
        """Testa análise de impacto complexa"""
        # Este teste seria executado com dados reais
        pass

