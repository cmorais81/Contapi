#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adicionar src ao path
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(script_dir, '..', '..'))

# Adiciona o diretório raiz do projeto (sbr-thpf-cobol-to-docs) ao PYTHONPATH
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# Adiciona o diretório da aplicação (cobol_to_docs) ao PYTHONPATH
cobol_to_docs_path = os.path.join(project_root, 'cobol_to_docs')
if cobol_to_docs_path not in sys.path:
    sys.path.insert(0, cobol_to_docs_path)

# Adiciona o diretório src ao PYTHONPATH
src_path = os.path.join(cobol_to_docs_path, 'src')
if src_path not in sys.path:
    sys.path.insert(0, src_path)

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser import COBOLParser, CobolProgram, CobolBook
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration import RAGIntegration
from src.core.intelligent_model_selector import IntelligentModelSelector
from src.analytics.consolidated_analysis import (
    process_advanced_consolidated_analysis,
    process_detailed_business_analysis
)

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        # String simples
        return [models_str]

def analyze_program_with_model(program: CobolProgram, books: List[CobolBook], model: str, output_dir: str, config_manager: ConfigManager, is_multi_model: bool, prompt_set: str, cost_calculator: CostCalculator, rag_integration=None, args=None, jcl_content: Optional[str] = None, all_copybook_contents: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)
    
    # Criar diretório específico do modelo se multi-modelo
    if is_multi_model:
        model_output_dir = os.path.join(output_dir, f"model_{model.replace('/', '_').replace('-', '_')}")
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = output_dir
    
    try:
        # Inicializar componentes específicos para o modelo
        prompt_manager = DualPromptManager(config_manager.config, prompt_set, custom_prompts_file=args.custom_prompt_file)
        provider_manager = EnhancedProviderManager(config_manager.get_config())
        doc_generator = DocumentationGenerator(model_output_dir)
        
        # Análise com IA (passando RAG integration)
        # Inicializar analisador
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager, rag_integration)
    
        # Remoção de comentários se solicitado ou se há muitos comentários
        if args:
            from src.utils.cobol_preprocessor import COBOLPreprocessor
            preprocessor = COBOLPreprocessor()
            
            has_many_comments = preprocessor.has_comments(program.content)
            logger.info(f"Verificando comentários em {program.name}: no_comments={getattr(args, 'no_comments', False)}, has_many_comments={has_many_comments}")
            
            if hasattr(args, 'no_comments') and (args.no_comments or has_many_comments):
                if args.no_comments:
                    logger.info(f"Remoção de comentários solicitada para {program.name}")
                else:
                    logger.info(f"Muitos comentários detectados em {program.name} - removendo para análise focada")
                
                original_content = program.content
                program.content, removed_comments = preprocessor.remove_comments(program.content)
                logger.info(f"Removidos {removed_comments} comentários de {program.name}")
            else:
                logger.info(f"Mantendo comentários em {program.name}")
        
        start_time = time.time()
        
        # Log do provider que será usado
        logger.info(f"*** PROVIDER SELECIONADO: {model} ***")
        logger.info(f"Iniciando análise de {program.name} com provider {model}")
        
        analysis_result = analyzer.analyze_program(program, model, books=books, jcl_content=jcl_content, all_copybook_contents=all_copybook_contents)
        analysis_time = time.time() - start_time
        
        # Log do provider efetivamente usado
        provider_usado = getattr(analysis_result, 'provider_used', model)
        logger.info(f"*** ANÁLISE CONCLUÍDA COM PROVIDER: {provider_usado} ***")
        
        if not analysis_result.success:
            error_msg = f"ERRO na análise de {program.name} com modelo {model}: {analysis_result.error_message}"
            logger.error(error_msg)
            print(f"\n {error_msg}")
            print(f"   Programa: {program.name}")
            print(f"   Modelo solicitado: {model}")
            print(f"   Tempo decorrido: {analysis_time:.2f}s")
            print(f"   Detalhes do erro: {analysis_result.error_message}")
            return {
                'success': False,
                'program_name': program.name,
                'model': model,
                'error': analysis_result.error_message,
                'tokens_used': 0,
                'analysis_time': analysis_time,
                'output_dir': model_output_dir
            }
        
        # Calcular custos
        cost_info = cost_calculator.tokens_analytics(
            {'usage': [{'total_tokens': analysis_result.tokens_used}]},
            analysis_result.model_used
        )
        
        # Gerar documentação
        from src.providers.base_provider import AIResponse
        
        # Obter prompts utilizados do prompt_manager
        prompts_used = {
            'system_prompt': prompt_manager.get_system_prompt(),
            'original_prompt': getattr(analysis_result, 'original_prompt', 'Prompt gerado dinamicamente'),
            'main_prompt': getattr(analysis_result, 'prompt_used', 'Prompt principal não disponível')
        }
        
        ai_response = AIResponse(
            success=True,
            content=analysis_result.content,
            tokens_used=analysis_result.tokens_used,
            model=analysis_result.model_used,
            provider=getattr(analysis_result, 'provider_used', 'enhanced_mock'),
            prompts_used=prompts_used,
            response_time=analysis_time
        )
        
        doc_result = doc_generator.generate_program_documentation(program, ai_response)
        
        logger.info(f"Análise de {program.name} com {model} bem-sucedida.")
        logger.info(f"Tokens utilizados: {analysis_result.tokens_used:,}")
        logger.info(f"Custo: ${cost_info['cost']:.4f}")
        logger.info(f"Modelo utilizado: {analysis_result.model_used}")
        
        # Auto-learning: Adicionar análise bem-sucedida à base de conhecimento
        if rag_integration and hasattr(rag_integration, 'add_program_analysis_to_knowledge_base'):
            try:
                rag_integration.add_program_analysis_to_knowledge_base(
                    program.name,
                    analysis_result.content,
                    program.content
                )
                logger.info(f"Auto-learning: Conhecimento do programa {program.name} adicionado à base RAG")
            except Exception as e:
                logger.warning(f"Auto-learning falhou para {program.name}: {e}")
        
        return {
            'success': True,
            'program_name': program.name,
            'model': model,
            'tokens_used': analysis_result.tokens_used,
            'analysis_time': analysis_time,
            'output_dir': model_output_dir,
            'files_generated': [doc_result] if doc_result else [],
            'response': analysis_result
        }
        
    except Exception as e:
        logger.error(f"Erro na análise de {program.name} com modelo {model}: {str(e)}")
        return {
            'success': False,
            'program_name': program.name,
            'model': model,
            'error': str(e),
            'tokens_used': 0,
            'analysis_time': 0,
            'output_dir': model_output_dir
        }

def generate_comparative_report(programs: List[CobolProgram], all_results: List[Dict[str, Any]], output_dir: str) -> None:
    """Gera relatório comparativo entre modelos."""
    logger = logging.getLogger(__name__)
    
    try:
        report_path = os.path.join(output_dir, "relatorio_comparativo_modelos.md")
        
        # Agrupar resultados por modelo
        models_used = list(set(r['model'] for r in all_results))
        results_by_model = {model: [r for r in all_results if r['model'] == model] for model in models_used}
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Comparativo de Modelos\n\n")
            f.write(f"**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Programas Analisados:** {len(programs)}\n")
            f.write(f"**Modelos Utilizados:** {len(models_used)}\n\n")
            
            # Resumo geral
            f.write("## Resumo Geral\n\n")
            f.write("| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios |\n")
            f.write("|--------|----------|--------|-----------------|---------------|\n")
            
            for model in models_used:
                model_results = results_by_model[model]
                successes = sum(1 for r in model_results if r['success'])
                failures = len(model_results) - successes
                success_rate = (successes / len(model_results) * 100) if len(model_results) > 0 else 0
                avg_tokens = sum(r['tokens_used'] for r in model_results) / successes if successes > 0 else 0
                f.write(f"| {model} | {successes} | {failures} | {success_rate:.2f}% | {avg_tokens:,.0f} |\n")
            
            f.write("\n\n")
            
            # Detalhes por programa
            f.write("## Detalhes por Programa\n\n")
            for program in programs:
                f.write(f"### Programa: {program.name}\n\n")
                f.write("| Modelo | Status | Tokens | Tempo (s) |\n")
                f.write("|--------|--------|--------|-----------|\n")
                
                program_results = [r for r in all_results if r['program_name'] == program.name]
                for result in program_results:
                    status = "Sucesso" if result['success'] else "Falha"
                    f.write(f"| {result['model']} | {status} | {result['tokens_used']:,} | {result['analysis_time']:.2f} |\n")
                f.write("\n")
                
    except Exception as e:
        logger.error(f"Erro ao gerar relatório comparativo: {e}")

def process_single_program(program: CobolProgram, books: List[CobolBook], models: List[str], output_dir: str, config_manager: ConfigManager, prompt_set: str, cost_calculator: CostCalculator, rag_integration=None, args=None, jcl_content: Optional[str] = None, all_copybook_contents: Optional[Dict[str, str]] = None) -> List[Dict[str, Any]]:
    """Processa um único programa com múltiplos modelos."""
    logger = logging.getLogger(__name__)
    
    all_results = []
    is_multi_model = len(models) > 1
    
    for model in models:
        result = analyze_program_with_model(program, books, model, output_dir, config_manager, is_multi_model, prompt_set, cost_calculator, rag_integration, args, jcl_content, all_copybook_contents)
        all_results.append(result)
    
    return all_results

def process_programs(programs: List[CobolProgram], books: List[CobolBook], models: List[str], output_dir: str, config_manager: ConfigManager, prompt_set: str, cost_calculator: CostCalculator, rag_integration=None, args=None, jcl_content: Optional[str] = None, all_copybook_contents: Optional[Dict[str, str]] = None) -> None:
    """Processa uma lista de programas COBOL."""
    logger = logging.getLogger(__name__)
    
    all_results = []
    total_programs = len(programs)
    
    for i, program in enumerate(programs):
        logger.info(f"Processando programa {i+1}/{total_programs}: {program.name}")
        program_output_dir = os.path.join(output_dir, program.name)
        os.makedirs(program_output_dir, exist_ok=True)
        
        results = process_single_program(program, books, models, program_output_dir, config_manager, prompt_set, cost_calculator, rag_integration, args, jcl_content, all_copybook_contents)
        all_results.extend(results)
    
    # Gerar relatório comparativo se múltiplos modelos foram usados
    if len(models) > 1:
        generate_comparative_report(programs, all_results, output_dir)

def main():
    """Função principal para execução do sistema."""
    parser = argparse.ArgumentParser(description="COBOL to Docs - Análise e Documentação de COBOL com IA")
    
    # Argumentos principais
    parser.add_argument('--program-path', type=str, help='Caminho para um único arquivo de programa COBOL')
    parser.add_argument('--fontes', type=str, help='Arquivo com programas COBOL')
    parser.add_argument('--books', type=str, help='Arquivo com copybooks COBOL (lista de paths)')
    parser.add_argument('--copybook-dirs', type=str, nargs='*', help='Diretórios para procurar copybooks (pode ser múltiplos)')
    parser.add_argument('--output', type=str, default='output', help='Diretório de saída')
    parser.add_argument('--models', type=str, help='Modelos de IA (string ou JSON array)')
    parser.add_argument('--prompt-set', type=str, default='original', help='Conjunto de prompts')
    parser.add_argument('--log-level', type=str, default='INFO', help='Nível de log')
    parser.add_argument('--pdf', action='store_true', help='Gerar relatórios HTML/PDF')
    parser.add_argument('--relatorio-unico', action='store_true',
                        help='Gera relatório único consolidado de todo o sistema')
    parser.add_argument('--consolidado', action='store_true',
                        help='Análise consolidada sistêmica de todos os programas simultaneamente')
    parser.add_argument('--analise-especialista', action='store_true',
                        help='Usa prompts especializados para análise técnica profunda')

    parser.add_argument('--procedure-detalhada', action='store_true',
                        help='Foca na análise detalhada da PROCEDURE DIVISION')
    parser.add_argument('--modernizacao', action='store_true',
                        help='Inclui análise de modernização e migração')
    parser.add_argument('--init', action='store_true', help='Inicializar ambiente local')
    parser.add_argument('--status', action='store_true', help='Verificar status dos provedores')
    parser.add_argument('--auto-model', action='store_true', 
                        help='Seleção automática de modelo baseada na complexidade do código')
    parser.add_argument('--model-comparison', action='store_true',
                        help='Exibir comparação de adequação de modelos para o código')
    parser.add_argument('--deep-analysis', action='store_true',
                        help='Análise detalhada de regras de negócio com valores específicos')
    parser.add_argument('--extract-formulas', action='store_true',
                        help='Extrair fórmulas matemáticas e cálculos específicos do código')
    parser.add_argument('--no-comments', action='store_true', help='Remover comentários do código antes da análise')
    parser.add_argument('--custom-prompt-file', type=str, help='Caminho para um arquivo YAML de prompts personalizado.')
    parser.add_argument('--custom-config-file', type=str, help='Caminho para um arquivo YAML de configuração personalizado (substitui o config.yaml padrão).')
    parser.add_argument('--jcl-file', type=str, help='Caminho para um arquivo JCL (Job Control Language) para incluir na análise.')

    args = parser.parse_args()
    
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    logger.info("Iniciando COBOL to Docs v1.0")
    
    # Carregar configurações
    config_file_to_load = args.custom_config_file if args.custom_config_file else os.path.join(os.path.dirname(__file__), '..', 'config', 'config.yaml')
    config_manager = ConfigManager(config_path=config_file_to_load)
    config = config_manager.get_config()
    logging.info(f"DEBUG: Configuração carregada (seção de provedores):\n{json.dumps(config.get('providers', {}), indent=2)}")
    if args.custom_config_file:
        logging.info(f"Usando arquivo de configuração personalizado: {args.custom_config_file}")

    # Carregar conteúdo do JCL se fornecido
    jcl_content = None
    if args.jcl_file:
        try:
            with open(args.jcl_file, 'r', encoding='utf-8') as f:
                jcl_content = f.read()
            logger.info(f"Conteúdo do JCL carregado de: {args.jcl_file}")
        except FileNotFoundError:
            logger.error(f"Erro: Arquivo JCL não encontrado em {args.jcl_file}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"Erro ao ler arquivo JCL {args.jcl_file}: {e}")
            sys.exit(1)

    # Inicializar RAG
    rag_integration = RAGIntegration(config_manager.config)
    
    # Inicializar CostCalculator
    cost_calculator = CostCalculator(config_manager.config.get('api_costs', {}))
    
    # Status dos provedores
    if args.status:
        provider_manager = EnhancedProviderManager(config_manager.get_config())
    
        return

    # Inicialização do ambiente
    if args.init:
        from src.utils.environment_setup import initialize_environment
        initialize_environment()
        return

    # Validação de argumentos
    if not args.program_path and not args.fontes:
        logger.error("Erro: É necessário especificar --program-path ou --fontes.")
        sys.exit(1)

    # Carregar programas e copybooks
    parser = COBOLParser()
    programs = []
    books = []

    all_copybook_contents: Dict[str, str] = {}

    if args.copybook_dirs:
        for c_dir in args.copybook_dirs:
            if os.path.isdir(c_dir):
                for root, _, files in os.walk(c_dir):
                    for f_name in files:
                        if f_name.upper().endswith((".CPY", ".CBL")):
                            c_name = os.path.splitext(f_name)[0].upper()
                            try:
                                with open(os.path.join(root, f_name), 'r', encoding='utf-8', errors='ignore') as cb_f:
                                    all_copybook_contents[c_name] = cb_f.read()
                                logger.debug(f"Copybook externo carregado: {c_name} de {os.path.join(root, f_name)}")
                            except Exception as cb_e:
                                logger.error(f"Erro ao ler copybook externo {c_name} em {os.path.join(root, f_name)}: {str(cb_e)}")
            else:
                logger.warning(f"Diretório de copybook não encontrado: {c_dir}")

    if args.program_path:
        # Se um único arquivo é fornecido, tentar parsear como programa + includes
        parsed_programs, parsed_books = parser.parse_file(args.program_path, copybook_dirs=args.copybook_dirs)
        programs.extend(parsed_programs)
        books.extend(parsed_books)
    elif args.fontes:
        # Se um arquivo de lista de fontes é fornecido, processar cada um
        with open(args.fontes, 'r', encoding='utf-8', errors='ignore') as f:
            program_paths = [line.strip() for line in f if line.strip()]
        
        for p_path in program_paths:
            if os.path.exists(p_path):
                parsed_programs, parsed_books = parser.parse_file(p_path, copybook_dirs=args.copybook_dirs)
                programs.extend(parsed_programs)
                books.extend(parsed_books)
            else:
                logger.warning(f"Arquivo de programa não encontrado: {p_path}")

    # Se copybooks foram fornecidos separadamente via --books, processá-los
    if args.books:
        with open(args.books, 'r', encoding='utf-8', errors='ignore') as f:
            book_paths = [line.strip() for line in f if line.strip()]
        
        for b_path in book_paths:
            if os.path.exists(b_path):
                # parse_file já lida com a detecção de programas/copybooks e inlining
                # Mas aqui, queremos garantir que copybooks listados em --books sejam adicionados ao mapa
                # e que seus conteúdos sejam lidos.
                # Para evitar duplicação, vamos apenas ler o conteúdo e adicionar ao all_copybook_contents
                # se ainda não estiver lá.
                book_name = os.path.splitext(os.path.basename(b_path))[0].upper()
                if book_name not in all_copybook_contents:
                    try:
                        with open(b_path, 'r', encoding='utf-8', errors='ignore') as cb_f:
                            all_copybook_contents[book_name] = cb_f.read()
                        logger.debug(f"Copybook carregado de --books: {book_name} de {b_path}")
                    except Exception as cb_e:
                        logger.error(f"Erro ao ler copybook de --books {book_name} em {b_path}: {str(cb_e)}")
            else:
                logger.warning(f"Arquivo de copybook não encontrado: {b_path}")

    # Agora, se houver programas e copybooks, passamos os copybook_contents para o analyze_program_with_model
    # A função process_programs ou ConsolidatedAnalyzer precisará ser atualizada para aceitar isso.
    
    # Selecionar modelos
    models = parse_models_argument(args.models) if args.models else config_manager.get('llm.default_models', ['enhanced_mock'])
    
    # Processar programas
    if args.consolidado:
        consolidated_analyzer = ConsolidatedAnalyzer(programs, books, models, args.output, config_manager, args.prompt_set, cost_calculator, rag_integration, args, jcl_content=jcl_content)
        consolidated_analyzer.analyze()
    else:
        process_programs(programs, books, models, args.output, config_manager, args.prompt_set, cost_calculator, rag_integration, args, jcl_content=jcl_content, all_copybook_contents=all_copybook_contents)
    
    # Análise de negócio detalhada
    if args.deep_analysis:
        process_detailed_business_analysis(args.output, config_manager, rag_integration)

    # Análise consolidada avançada
    if args.relatorio_unico:
        process_advanced_consolidated_analysis(args.output, config_manager, rag_integration)

    # Gerar relatório HTML/PDF se solicitado
    if args.pdf:
        html_generator = HTMLReportGenerator(args.output)
        html_generator.generate_html_report()
        # A conversão para PDF pode ser adicionada aqui se necessário

    logger.info("Processo concluído.")

if __name__ == "__main__":
    main()

