"""
Sistema de Aprendizado Inteligente RAG
Extrai conhecimento automaticamente das análises e enriquece a base RAG
"""

import json
import re
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import os

class IntelligentLearningSystem:
    """Sistema que aprende automaticamente com as análises e enriquece a base RAG"""
    
    def __init__(self, knowledge_base_path: str):
        self.knowledge_base_path = knowledge_base_path
        self.logger = logging.getLogger(__name__)
        self.learning_patterns = self._initialize_learning_patterns()
        
    def _initialize_learning_patterns(self) -> Dict[str, List[str]]:
        """Inicializa padrões para extração de conhecimento"""
        return {
            "business_rules": [
                r"regra de negócio:?\s*(.+)",
                r"validação:?\s*(.+)",
                r"critério:?\s*(.+)",
                r"algoritmo:?\s*(.+)",
                r"cálculo:?\s*(.+)",
                r"fórmula:?\s*(.+)"
            ],
            "cobol_patterns": [
                r"padrão\s+(?:de\s+)?(.+?)(?:\s+identificado|\s+detectado|\s+encontrado)",
                r"estrutura\s+(.+?)(?:\s+implementada|\s+utilizada)",
                r"técnica\s+(.+?)(?:\s+aplicada|\s+empregada)",
                r"metodologia\s+(.+?)(?:\s+seguida|\s+adotada)"
            ],
            "technical_knowledge": [
                r"otimização:?\s*(.+)",
                r"performance:?\s*(.+)",
                r"integração:?\s*(.+)",
                r"arquitetura:?\s*(.+)",
                r"design pattern:?\s*(.+)"
            ],
            "domain_specific": [
                r"bancário:?\s*(.+)",
                r"financeiro:?\s*(.+)",
                r"regulamentação:?\s*(.+)",
                r"compliance:?\s*(.+)",
                r"auditoria:?\s*(.+)"
            ]
        }
    
    def extract_knowledge_from_analysis(self, analysis_text: str, program_name: str, 
                                      cobol_code: str) -> Dict[str, Any]:
        """Extrai conhecimento da análise para enriquecer a base RAG"""
        
        extracted_knowledge = {
            "timestamp": datetime.now().isoformat(),
            "program_name": program_name,
            "knowledge_items": []
        }
        
        # Extrai diferentes tipos de conhecimento
        business_rules = self._extract_business_rules(analysis_text, cobol_code)
        cobol_patterns = self._extract_cobol_patterns(analysis_text, cobol_code)
        technical_knowledge = self._extract_technical_knowledge(analysis_text)
        domain_knowledge = self._extract_domain_knowledge(analysis_text)
        
        # Consolida conhecimento extraído
        all_knowledge = {
            "Regras de Negócio": business_rules,
            "Padrões COBOL": cobol_patterns,
            "Conhecimento Técnico": technical_knowledge,
            "Conhecimento do Domínio": domain_knowledge
        }
        
        # Filtra e valida conhecimento
        for category, items in all_knowledge.items():
            for item in items:
                if self._is_valuable_knowledge(item):
                    knowledge_item = self._create_knowledge_item(
                        category, item, program_name, analysis_text
                    )
                    extracted_knowledge["knowledge_items"].append(knowledge_item)
        
        return extracted_knowledge
    
    def _extract_business_rules(self, analysis_text: str, cobol_code: str) -> List[str]:
        """Extrai regras de negócio específicas"""
        rules = []
        
        # Extrai regras do texto de análise
        for pattern in self.learning_patterns["business_rules"]:
            matches = re.finditer(pattern, analysis_text, re.IGNORECASE | re.MULTILINE)
            for match in matches:
                rule = match.group(1).strip()
                if len(rule) > 10 and rule not in rules:
                    rules.append(rule)
        
        # Extrai regras específicas do código COBOL
        cobol_rules = self._extract_rules_from_cobol(cobol_code)
        rules.extend(cobol_rules)
        
        return rules[:10]  # Limita a 10 regras mais relevantes
    
    def _extract_rules_from_cobol(self, cobol_code: str) -> List[str]:
        """Extrai regras específicas do código COBOL"""
        rules = []
        
        # Padrões específicos de validação COBOL
        validation_patterns = [
            r"IF\s+(.+?)\s+(?:THEN|$)",
            r"WHEN\s+(.+?)(?:\s+ALSO|\s+$)",
            r"EVALUATE\s+(.+?)(?:\s+WHEN|\s+$)"
        ]
        
        for pattern in validation_patterns:
            matches = re.finditer(pattern, cobol_code, re.IGNORECASE | re.MULTILINE)
            for match in matches:
                condition = match.group(1).strip()
                if self._is_business_rule_condition(condition):
                    rule = f"Validação: {condition}"
                    if rule not in rules:
                        rules.append(rule)
        
        return rules
    
    def _is_business_rule_condition(self, condition: str) -> bool:
        """Verifica se uma condição representa uma regra de negócio"""
        business_indicators = [
            "saldo", "limite", "valor", "conta", "cliente", "cpf", "cnpj",
            "juros", "taxa", "prazo", "vencimento", "status", "tipo"
        ]
        
        condition_lower = condition.lower()
        return any(indicator in condition_lower for indicator in business_indicators)
    
    def _extract_cobol_patterns(self, analysis_text: str, cobol_code: str) -> List[str]:
        """Extrai padrões COBOL identificados"""
        patterns = []
        
        # Extrai padrões do texto de análise
        for pattern in self.learning_patterns["cobol_patterns"]:
            matches = re.finditer(pattern, analysis_text, re.IGNORECASE | re.MULTILINE)
            for match in matches:
                cobol_pattern = match.group(1).strip()
                if len(cobol_pattern) > 5 and cobol_pattern not in patterns:
                    patterns.append(cobol_pattern)
        
        # Identifica padrões estruturais no código
        structural_patterns = self._identify_structural_patterns(cobol_code)
        patterns.extend(structural_patterns)
        
        return patterns[:8]  # Limita a 8 padrões mais relevantes
    
    def _identify_structural_patterns(self, cobol_code: str) -> List[str]:
        """Identifica padrões estruturais no código COBOL"""
        patterns = []
        
        # Verifica padrões comuns
        if "PERFORM" in cobol_code and "UNTIL" in cobol_code:
            patterns.append("Loop controlado com PERFORM UNTIL")
        
        if "READ" in cobol_code and "AT END" in cobol_code:
            patterns.append("Processamento sequencial de arquivo com AT END")
        
        if "CALL" in cobol_code and "USING" in cobol_code:
            patterns.append("Chamada de subprograma com passagem de parâmetros")
        
        if "SQL" in cobol_code or "EXEC SQL" in cobol_code:
            patterns.append("Integração com banco de dados via SQL embebido")
        
        if "COPY" in cobol_code:
            patterns.append("Uso de copybooks para estruturas de dados")
        
        return patterns
    
    def _extract_technical_knowledge(self, analysis_text: str) -> List[str]:
        """Extrai conhecimento técnico avançado"""
        technical_items = []
        
        for pattern in self.learning_patterns["technical_knowledge"]:
            matches = re.finditer(pattern, analysis_text, re.IGNORECASE | re.MULTILINE)
            for match in matches:
                item = match.group(1).strip()
                if len(item) > 10 and item not in technical_items:
                    technical_items.append(item)
        
        return technical_items[:6]  # Limita a 6 itens mais relevantes
    
    def _extract_domain_knowledge(self, analysis_text: str) -> List[str]:
        """Extrai conhecimento específico do domínio"""
        domain_items = []
        
        for pattern in self.learning_patterns["domain_specific"]:
            matches = re.finditer(pattern, analysis_text, re.IGNORECASE | re.MULTILINE)
            for match in matches:
                item = match.group(1).strip()
                if len(item) > 10 and item not in domain_items:
                    domain_items.append(item)
        
        return domain_items[:6]  # Limita a 6 itens mais relevantes
    
    def _is_valuable_knowledge(self, knowledge_item: str) -> bool:
        """Verifica se o conhecimento é valioso para a base RAG"""
        
        # Filtros de qualidade
        if len(knowledge_item) < 10:
            return False
        
        # Palavras que indicam conhecimento valioso
        valuable_indicators = [
            "algoritmo", "padrão", "regra", "validação", "cálculo",
            "otimização", "performance", "integração", "arquitetura",
            "bancário", "financeiro", "compliance", "auditoria"
        ]
        
        knowledge_lower = knowledge_item.lower()
        return any(indicator in knowledge_lower for indicator in valuable_indicators)
    
    def _create_knowledge_item(self, category: str, content: str, 
                             program_name: str, analysis_text: str) -> Dict[str, Any]:
        """Cria item de conhecimento estruturado"""
        
        # Gera ID único baseado no conteúdo
        knowledge_id = f"learned_{category.lower().replace(' ', '_')}_{hash(content) % 10000:04d}"
        
        # Extrai keywords relevantes
        keywords = self._extract_keywords(content, analysis_text)
        
        # Determina relevância baseada no contexto
        relevance_score = self._calculate_relevance(content, analysis_text)
        
        return {
            "id": knowledge_id,
            "category": f"Conhecimento Aprendido - {category}",
            "title": self._generate_title(content),
            "content": self._enhance_content(content, program_name),
            "keywords": keywords,
            "source_program": program_name,
            "relevance_score": relevance_score,
            "learned_date": datetime.now().isoformat()
        }
    
    def _extract_keywords(self, content: str, context: str) -> List[str]:
        """Extrai keywords relevantes do conteúdo"""
        
        # Keywords técnicas COBOL
        cobol_keywords = [
            "perform", "read", "write", "call", "copy", "sql", "file",
            "record", "field", "division", "section", "paragraph"
        ]
        
        # Keywords de negócio bancário
        business_keywords = [
            "conta", "cliente", "saldo", "transacao", "juros", "taxa",
            "cpf", "cnpj", "validacao", "calculo", "limite"
        ]
        
        # Keywords técnicas avançadas
        technical_keywords = [
            "performance", "otimizacao", "integracao", "arquitetura",
            "padrao", "algoritmo", "estrutura", "metodologia"
        ]
        
        all_keywords = cobol_keywords + business_keywords + technical_keywords
        
        content_lower = content.lower()
        found_keywords = [kw for kw in all_keywords if kw in content_lower]
        
        return found_keywords[:8]  # Limita a 8 keywords
    
    def _calculate_relevance(self, content: str, context: str) -> float:
        """Calcula score de relevância do conhecimento"""
        
        base_score = 0.5
        
        # Aumenta score baseado em indicadores de qualidade
        quality_indicators = [
            ("algoritmo", 0.2), ("padrão", 0.15), ("regra", 0.15),
            ("validação", 0.1), ("cálculo", 0.1), ("otimização", 0.15),
            ("bancário", 0.1), ("financeiro", 0.1)
        ]
        
        content_lower = content.lower()
        for indicator, score_boost in quality_indicators:
            if indicator in content_lower:
                base_score += score_boost
        
        # Limita score entre 0.1 e 1.0
        return min(max(base_score, 0.1), 1.0)
    
    def _generate_title(self, content: str) -> str:
        """Gera título descritivo para o conhecimento"""
        
        # Padrões para gerar títulos
        if "validação" in content.lower():
            return f"Padrão de Validação: {content[:50]}..."
        elif "cálculo" in content.lower():
            return f"Algoritmo de Cálculo: {content[:50]}..."
        elif "padrão" in content.lower():
            return f"Padrão Identificado: {content[:50]}..."
        elif "regra" in content.lower():
            return f"Regra de Negócio: {content[:50]}..."
        else:
            return f"Conhecimento Extraído: {content[:50]}..."
    
    def _enhance_content(self, content: str, program_name: str) -> str:
        """Enriquece o conteúdo com contexto adicional"""
        
        enhanced = f"Conhecimento extraído automaticamente do programa {program_name}:\n\n"
        enhanced += content
        enhanced += f"\n\nEste conhecimento foi identificado através de análise automatizada "
        enhanced += f"e pode ser aplicado em contextos similares de sistemas COBOL bancários."
        
        return enhanced
    
    def add_learned_knowledge_to_base(self, extracted_knowledge: Dict[str, Any]) -> bool:
        """Adiciona conhecimento aprendido à base RAG"""
        
        try:
            # Carrega base atual
            if os.path.exists(self.knowledge_base_path):
                with open(self.knowledge_base_path, 'r', encoding='utf-8') as f:
                    knowledge_base = json.load(f)
            else:
                knowledge_base = []
            
            # Adiciona novos itens de conhecimento
            new_items_added = 0
            for item in extracted_knowledge["knowledge_items"]:
                
                # Verifica se já existe conhecimento similar
                if not self._knowledge_exists(item, knowledge_base):
                    knowledge_base.append(item)
                    new_items_added += 1
                    
                    self.logger.info(f"Novo conhecimento adicionado: {item['title']}")
            
            # Salva base atualizada
            if new_items_added > 0:
                with open(self.knowledge_base_path, 'w', encoding='utf-8') as f:
                    json.dump(knowledge_base, f, ensure_ascii=False, indent=2)
                
                self.logger.info(f"Base RAG enriquecida com {new_items_added} novos itens")
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Erro ao adicionar conhecimento à base RAG: {e}")
            return False
    
    def _knowledge_exists(self, new_item: Dict[str, Any], 
                         knowledge_base: List[Dict[str, Any]]) -> bool:
        """Verifica se conhecimento similar já existe na base"""
        
        new_content = new_item["content"].lower()
        new_keywords = set(new_item["keywords"])
        
        for existing_item in knowledge_base:
            existing_content = existing_item.get("content", "").lower()
            existing_keywords = set(existing_item.get("keywords", []))
            
            # Verifica similaridade por conteúdo
            if self._calculate_similarity(new_content, existing_content) > 0.8:
                return True
            
            # Verifica similaridade por keywords
            if len(new_keywords & existing_keywords) >= len(new_keywords) * 0.7:
                return True
        
        return False
    
    def _calculate_similarity(self, text1: str, text2: str) -> float:
        """Calcula similaridade entre dois textos"""
        
        words1 = set(text1.split())
        words2 = set(text2.split())
        
        if not words1 or not words2:
            return 0.0
        
        intersection = words1 & words2
        union = words1 | words2
        
        return len(intersection) / len(union)
    
    def get_learning_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas do aprendizado"""
        
        try:
            if not os.path.exists(self.knowledge_base_path):
                return {"total_items": 0, "learned_items": 0}
            
            with open(self.knowledge_base_path, 'r', encoding='utf-8') as f:
                knowledge_base = json.load(f)
            
            total_items = len(knowledge_base)
            learned_items = len([item for item in knowledge_base 
                               if "Conhecimento Aprendido" in item.get("category", "")])
            
            categories = {}
            for item in knowledge_base:
                category = item.get("category", "Outros")
                categories[category] = categories.get(category, 0) + 1
            
            return {
                "total_items": total_items,
                "learned_items": learned_items,
                "categories": categories,
                "learning_rate": learned_items / total_items if total_items > 0 else 0
            }
            
        except Exception as e:
            self.logger.error(f"Erro ao obter estatísticas: {e}")
            return {"error": str(e)}
