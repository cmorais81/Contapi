# COBOL to Docs - Análise e Documentação de Programas COBOL com IA

Este pacote contém a versão atualizada do sistema COBOL to Docs, que inclui melhorias significativas na gestão de modelos, processamento de arquivos COBOL com copybooks e integração de JCL.

## Novas Funcionalidades e Melhorias

### 1. Carregamento de Modelos Aprimorado

- **Correção de carregamento de modelos:** O `EnhancedProviderManager` foi atualizado para garantir o carregamento correto de modelos, especialmente aqueles com hífens nos nomes, evitando erros de configuração e garantindo a utilização do modelo correto para análise.

### 2. Processamento Combinado de COBOL e Copybooks

- **Resolução automática de COPY statements:** O `COBOLParser` agora é capaz de resolver `COPY` statements em programas COBOL, inlinando o conteúdo dos copybooks diretamente no código do programa antes da análise. Isso garante que o modelo de IA receba o código completo e contextualizado.
- **Suporte a copybooks internos e externos:** O sistema pode identificar e processar copybooks que estão no mesmo arquivo empilhado (VMEMBER) que o programa principal, bem como copybooks localizados em diretórios externos especificados pelo usuário.
- **Argumento `--copybook-dirs`:** Adicionado um novo argumento de linha de comando `--copybook-dirs` para permitir que o usuário especifique um ou mais diretórios onde o parser deve procurar por copybooks externos.

### 3. Integração de JCL (Job Control Language)

- **Inclusão de JCL na análise:** O sistema agora permite a inclusão de conteúdo JCL (`--jcl-file`) na requisição de análise para o modelo de IA. Isso fornece contexto adicional ao modelo sobre como o programa COBOL é executado, melhorando a qualidade da documentação gerada.
- **Enriquecimento de prompt:** O `DualPromptManager` foi atualizado para incorporar o conteúdo do JCL no prompt enviado ao modelo de IA, garantindo que o modelo tenha todas as informações relevantes para uma análise abrangente.

## Como Usar

### Pré-requisitos

- Python 3.8+
- `pip` para instalação de dependências

### Instalação

1. Clone o repositório ou descompacte o pacote `sbr-thpf-cobol-to-docs-final.tar.gz`.
2. Navegue até o diretório `sbr-thpf-cobol-to-docs`.
3. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```

### Execução

Para executar o sistema, utilize o script `runner/main.py` dentro do diretório `cobol_to_docs`. Certifique-se de que o diretório `cobol_to_docs` esteja no `PYTHONPATH` ou execute a partir do diretório raiz do projeto `sbr-thpf-cobol-to-docs`.

Exemplo de execução a partir do diretório `sbr-thpf-cobol-to-docs`:

```bash
export PYTHONPATH=$(pwd)/cobol_to_docs:$PYTHONPATH
python3 cobol_to_docs/runner/main.py --program-path <caminho_para_seu_programa.cbl> --output <diretorio_saida> --models <modelo_ia>
```

#### Argumentos Principais

- `--program-path <path>`: Caminho para um único arquivo de programa COBOL.
- `--fontes <path>`: Caminho para um arquivo de texto contendo uma lista de caminhos para programas COBOL (um por linha).
- `--books <path>`: Caminho para um arquivo de texto contendo uma lista de caminhos para copybooks COBOL (um por linha). *Nota: O sistema agora também busca copybooks automaticamente em `--copybook-dirs`.*
- `--copybook-dirs <dir1> [<dir2> ...]`: Um ou mais diretórios onde o sistema deve procurar por copybooks externos. O conteúdo desses copybooks será inlinado nos programas COBOL.
- `--jcl-file <path>`: Caminho para um arquivo JCL para incluir na análise, fornecendo contexto de execução.
- `--output <dir>`: Diretório onde os resultados da análise serão salvos (padrão: `output`).
- `--models <model_name>`: Nome do modelo de IA a ser utilizado (ex: `enhanced_mock`, `gpt-4`). Pode ser uma string ou um array JSON de modelos para análise comparativa.
- `--prompt-set <set_name>`: Conjunto de prompts a ser utilizado (ex: `original`, `doc_legado_pro`).
- `--log-level <level>`: Nível de log (ex: `INFO`, `DEBUG`).

#### Exemplo Completo

Para analisar um programa COBOL que usa um copybook e um arquivo JCL, com saída para o diretório `my_analysis` usando o modelo `enhanced_mock`:

```bash
export PYTHONPATH=$(pwd)/cobol_to_docs:$PYTHONPATH
python3 cobol_to_docs/runner/main.py \
    --program-path test_program_with_copy.cbl \
    --copybook-dirs . \
    --jcl-file test_jcl.jcl \
    --output my_analysis \
    --models enhanced_mock
```

Este comando irá:
1. Carregar `test_program_with_copy.cbl`.
2. Procurar `test_copy.cpy` no diretório atual (`.`) e inliná-lo em `test_program_with_copy.cbl`.
3. Carregar `test_jcl.jcl`.
4. Enviar o programa COBOL resolvido e o conteúdo do JCL para o modelo `enhanced_mock` para análise.
5. Salvar os resultados no diretório `my_analysis`.

## Estrutura do Projeto

```
sbr-thpf-cobol-to-docs/
├── cobol_to_docs/
│   ├── config/             # Arquivos de configuração e prompts
│   ├── data/               # Dados para RAG, caches, etc.
│   ├── docs/               # Documentação interna do projeto
│   ├── examples/           # Exemplos de uso
│   ├── logs/               # Logs de execução
│   ├── runner/             # Scripts de execução (e.g., main.py)
│   ├── src/                # Código fonte da aplicação
│   │   ├── analyzers/      # Lógica de análise de COBOL
│   │   ├── core/           # Componentes centrais (config, prompt manager)
│   │   ├── generators/     # Geração de documentação
│   │   ├── parsers/        # Parsers de COBOL e Copybook
│   │   ├── providers/      # Integração com modelos de IA
│   │   ├── rag/            # Componentes RAG
│   │   └── utils/          # Utilitários (calculadora de custo, preprocessor)
│   └── tests/              # Testes unitários
├── test_copy.cpy           # Exemplo de copybook
├── test_jcl.jcl            # Exemplo de JCL
├── test_program.cbl        # Exemplo de programa COBOL simples
├── test_program_with_copy.cbl # Exemplo de programa COBOL com copybook
├── requirements.txt        # Dependências do projeto
├── README.md               # Este arquivo
└── ... (outros arquivos de projeto)
```

## Contribuição

Para contribuir, por favor, siga as diretrizes de desenvolvimento e testes. Certifique-se de que todas as novas funcionalidades sejam cobertas por testes unitários e que a documentação seja atualizada conforme necessário.

---

**Autor:** Manus AI
**Data:** Outubro de 2025

