# COBOL Analysis Engine v2.0

Sistema inteligente de análise e documentação de programas COBOL com suporte a múltiplas IAs e geração automática de relatórios profissionais.

## O que faz

- **Explica o objetivo** de cada programa COBOL de forma clara e detalhada
- **Identifica regras de negócio** importantes (validações, critérios, limites)
- **Detecta particularidades** que merecem atenção especial
- **Integra copybooks** para análise contextual completa
- **Captura prompts e respostas** das IAs para transparência total
- **Gera relatórios profissionais** seguindo padrões de documentação técnica

## Características Principais

### Análise Inteligente
- **Extração automática** de estruturas, regras de negócio e fluxos de processamento
- **Análise de Working Storage** com identificação de campos e tipos de dados
- **Detecção de copybooks** e mapeamento de dependências
- **Identificação de operações** matemáticas, validações e lógica condicional
- **Análise de arquivos** de entrada e saída com mapeamento de fluxos

### Múltiplos Modos de Operação
- **Enhanced Mode**: Análise inteligente com geração de relatórios de alta qualidade
- **Multi-AI Mode**: Análise paralela com múltiplas IAs especializadas
- **Traditional Mode**: Análise básica estrutural (sempre disponível)

### Integração com IAs
- **LuzIA**: Integração nativa com API brasileira (corrigida e funcional)
- **OpenAI**: Suporte completo a GPT-3.5/GPT-4
- **Fallback inteligente**: Sistema funciona mesmo sem IAs configuradas
- **Transparência total**: Todos os prompts e respostas são preservados

## Instalação e Configuração

### Pré-requisitos
```bash
# Python 3.11+
python3.11 --version

# Instalar dependências
pip3 install -r requirements.txt
```

### Configuração de IAs (Opcional)

#### LuzIA (Recomendado para uso brasileiro)
```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

#### OpenAI
```bash
export OPENAI_API_KEY="sua_api_key"
```

**Nota:** O sistema funciona perfeitamente sem IAs configuradas, gerando relatórios baseados em análise estrutural inteligente.

## Uso Básico

### Análise Individual
```bash
# Análise com modo inteligente (recomendado)
python3.11 main.py programa.cbl -o relatorios/ -m enhanced

# Análise com múltiplas IAs
python3.11 main.py programa.cbl -o relatorios/ -m multi_ai

# Análise tradicional (sem IA)
python3.11 main.py programa.cbl -o relatorios/ -m traditional
```

### Processamento em Lote
```bash
# Com copybooks (recomendado)
python3.11 main.py fontes.txt -o relatorios/ -b BOOKS.txt -m enhanced

# Sem copybooks
python3.11 main.py fontes.txt -o relatorios/ -m enhanced
```

### Verificação de Status
```bash
# Verificar conectividade com IAs
python3.11 main.py --status
```

## Modos de Análise

| Modo | Descrição | Tempo | Qualidade | Quando Usar |
|------|-----------|-------|-----------|-------------|
| **traditional** | Análise estrutural básica | ~0.01s | Boa | Estrutura rápida |
| **enhanced** | Análise inteligente + transparência | ~5-15s | Excelente | Documentação completa |
| **multi_ai** | Análise paralela especializada | ~10-30s | Superior | Análise profunda |

## Formatos de Entrada

### Arquivo fontes.txt
```
LHAN0542
LHAN0705
LHAN0706
LHBR0700
MZAN6056
```

### Arquivo BOOKS.txt
```
MZTCM530
DRR00082
BOOK001
BOOK002
```

## Relatórios Gerados

### Estrutura dos Relatórios (Baseada em Padrões Profissionais)
- **Resumo Executivo**: Impacto no negócio e criticidade do sistema
- **Análise Funcional**: Objetivo principal e funcionalidades identificadas
- **Estrutura Técnica**: Arquivos, Working Storage, copybooks e componentes
- **Regras de Negócio**: Validações, critérios e lógica condicional organizadas
- **Fluxo de Processamento**: Fases de execução e sequência de operações
- **Aspectos Técnicos**: Performance, manutenibilidade e pontos de atenção
- **Métricas e Monitoramento**: Indicadores extraídos e pontos de controle
- **Transparência de Análise**: Prompts enviados e respostas recebidas das IAs

### Tipos de Relatório
- `PROGRAMA_ENHANCED_ANALYSIS.md`: Análise inteligente completa
- `PROGRAMA_MULTI_AI_ANALYSIS.md`: Análise com múltiplas IAs especializadas
- `PROGRAMA_ANALYSIS.md`: Análise tradicional estrutural
- `BATCH_PROCESSING_SUMMARY.md`: Resumo do processamento em lote

## Exemplo de Saída

**Entrada:** Programa COBOL LHAN0542
**Saída:** Relatório profissional

```markdown
# Análise COBOL: LHAN0542

## Resumo Executivo
O programa LHAN0542 é uma solução para processamento de dados bancários 
com criticidade alta no sistema. Processa 3 arquivos de entrada e gera 
2 arquivos de saída, integrando com 5 copybooks.

## Análise Funcional
### Objetivo Principal
Processamento de transações bancárias com validação de limites e 
roteamento automático baseado em tipo de operação.

### Funcionalidades Principais
1. Validação de dados de entrada
2. Aplicação de regras de negócio específicas
3. Geração de relatórios de controle

## Estrutura Técnica
### Working Storage (89 campos identificados)
| Campo | Tipo | Tamanho | Descrição |
|-------|------|---------|-----------|
| WS-CONTADOR | PIC 9(05) | 5 | Contador de registros |
| WS-TOTAL-VALOR | PIC 9(15)V99 | 17 | Total de valores |

### Copybooks Utilizados (5 identificados)
- MZTCM530: Estruturas de dados principais
- DRR00082: Códigos de retorno

## Regras de Negócio
| Regra | Condição | Ação |
|-------|----------|------|
| Limite de valor | VALOR > 10000 | Requer aprovação |
| Tipo de conta | TIPO = 'P' | Processamento especial |

## Transparência de Análise
### Análise 1: Análise Principal
**Provedor:** LuzIA  
**Modelo:** luzia-chat  
**Tempo:** 2.45s  
**Status:** Sucesso

**Prompt enviado:**
[Prompt completo preservado]

**Resposta original:**
[Resposta completa da IA preservada]
```

## Estrutura do Projeto

```
cobol_analysis_engine_v2.0/
├── main.py                     # Ponto de entrada principal
├── requirements.txt            # Dependências Python
├── config/
│   ├── config.yaml            # Configurações do sistema
│   └── prompts.yaml           # Templates de prompts para IAs
├── src/
│   ├── core/                  # Núcleo do sistema
│   │   ├── unified_analyzer.py        # Analisador principal
│   │   ├── multi_ai_orchestrator.py  # Orquestrador multi-IA
│   │   └── intelligent_analyzer.py   # Analisador inteligente
│   ├── providers/             # Provedores de IA
│   │   ├── provider_manager.py       # Gerenciador de provedores
│   │   ├── luzia_provider.py         # Integração LuzIA (corrigida)
│   │   └── openai_provider.py        # Integração OpenAI
│   ├── generators/            # Geradores de documentação
│   │   └── intelligent_documentation_generator.py
│   ├── extractors/            # Extratores de dados
│   │   └── cobol_extractor.py        # Extração de código COBOL
│   └── utils/                 # Utilitários
│       ├── enhanced_logger.py        # Sistema de logs
│       └── simple_status_checker.py  # Verificador de status
├── examples/                  # Exemplos e dados de teste
│   ├── fontes.txt            # Lista de programas para análise
│   ├── BOOKS.txt             # Lista de copybooks
│   ├── *.cbl                 # Programas COBOL de exemplo
│   └── output_exemplo/       # Exemplos de relatórios gerados
├── docs/                     # Documentação completa
└── logs/                     # Logs do sistema
```

## Parâmetros da Linha de Comando

```bash
python3.11 main.py [arquivo] [opções]

Argumentos:
  arquivo                 Arquivo .cbl ou fontes.txt

Opções:
  -o, --output           Diretório de saída (padrão: resultado/)
  -b, --books            Arquivo BOOKS.txt com copybooks
  -m, --mode             Modo: traditional, enhanced, multi_ai
  -c, --config           Arquivo de configuração personalizado
  -v, --verbose          Saída detalhada
  --status               Testar conectividade com IAs
  --help                 Mostrar ajuda completa
```

## Casos de Uso

### 1. Documentação de Sistema Legado
- Analisa programas COBOL antigos sem documentação
- Explica objetivo e funcionamento de forma clara
- Identifica regras de negócio críticas para preservação

### 2. Auditoria e Compliance
- Documenta controles e validações implementados
- Identifica pontos de atenção para auditoria
- Facilita revisões de compliance regulatório

### 3. Migração de Sistemas
- Entende lógica de negócio atual
- Mapeia regras para nova plataforma
- Reduz riscos de migração por perda de conhecimento

### 4. Treinamento de Equipe
- Gera material didático sobre programas complexos
- Explica funcionamento de forma didática
- Acelera curva de aprendizado de novos desenvolvedores

## Solução de Problemas

### Sistema Sempre Funcional
- **Modo traditional** sempre disponível, mesmo com erros
- **Análise estrutural** independe de IAs
- **Fallback inteligente** garante operação contínua

### Problemas Comuns

#### "Provider não disponível"
```bash
# Verificar status das IAs
python3.11 main.py --status

# Usar modo tradicional como fallback
python3.11 main.py programa.cbl -m traditional
```

#### "Erro de timeout"
- Verificar conectividade de rede
- Usar modo traditional para análise imediata
- Configurar timeout maior em config.yaml

#### "Arquivo não encontrado"
- Verificar caminhos dos arquivos
- Usar caminhos absolutos se necessário
- Verificar permissões de leitura

### Logs e Diagnóstico
```bash
# Verificar logs de erro
tail -f logs/analysis_errors.log

# Verificar logs gerais
tail -f logs/cobol_analysis.log

# Diagnóstico completo
python3.11 main.py --status -v
```

## Configuração Avançada

### config/config.yaml
```yaml
providers:
  luzia:
    model: "luzia-chat"
    temperature: 0.1
    timeout: 30.0
  openai:
    model: "gpt-4"
    temperature: 0.1
    max_tokens: 4000

logging:
  level: "INFO"
  dir: "logs"

analysis:
  max_prompt_size: 8000
  enable_fallback: true
  preserve_responses: true
```

## Benefícios Comprovados

✅ **Compreensão rápida** do que cada programa faz  
✅ **Identificação clara** de regras de negócio críticas  
✅ **Detecção automática** de particularidades importantes  
✅ **Integração completa** com copybooks e dependências  
✅ **Transparência total** sobre análises realizadas  
✅ **Funciona offline** no modo tradicional  
✅ **Relatórios profissionais** seguindo padrões técnicos  
✅ **Processamento em lote** para análise de sistemas completos  

## Status do Projeto

**Versão:** 2.0 (Estável)  
**Status:** ✅ Funcional e Testado  
**Última atualização:** 20/09/2025  
**Correções aplicadas:**
- ✅ Integração LuzIA corrigida e funcional
- ✅ Erro 'str' object has no attribute 'get' resolvido
- ✅ Modo multi_ai funcionando corretamente
- ✅ Remoção completa de chamadas para API Manus
- ✅ Remoção de ícones para interface profissional
- ✅ Transparência total de prompts e respostas

---

**COBOL Analysis Engine v2.0** - Sistema inteligente de análise e documentação COBOL
