"""
Módulo de Prompts para COBOL Analysis Engine
Contém geradores de prompts contextualizados para diferentes provedores de IA
"""

from .luzia_prompts import LuziaPromptGenerator, PromptResponseLogger

__all__ = ['LuziaPromptGenerator', 'PromptResponseLogger']
