"""
Gerador de Documentação Funcional
Integra análise de lógica de negócio e fluxo de dados para documentação completa
"""

import logging
from datetime import datetime
from typing import Dict, Any, Optional
from analyzers.business_logic_parser import COBOLBusinessLogicParser
from analyzers.data_flow_analyzer import COBOLDataFlowAnalyzer
from prompts.luzia_prompts import PromptResponseLogger

class FunctionalDocumentationGenerator:
    """Gerador de documentação que combina análise estrutural, lógica de negócio e fluxo de dados"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.business_parser = COBOLBusinessLogicParser()
        self.data_flow_analyzer = COBOLDataFlowAnalyzer()
        self.prompt_logger = PromptResponseLogger()
    
    def generate_comprehensive_documentation(self, 
                                           program_name: str,
                                           cobol_code: str,
                                           extracted_data: Dict,
                                           orchestration_result: Optional[Dict] = None) -> str:
        """Gera documentação completa combinando todas as análises"""
        
        self.logger.info(f"Gerando documentação funcional para {program_name}")
        
        # Executar análises avançadas
        business_analysis = self.business_parser.generate_business_documentation(cobol_code)
        data_flow_analysis = self.data_flow_analyzer.generate_data_flow_documentation(cobol_code)
        
        # Gerar documentação
        doc_sections = []
        
        # Cabeçalho
        doc_sections.append(self._generate_header(program_name, extracted_data))
        
        # Resumo Executivo
        doc_sections.append(self._generate_executive_summary(business_analysis, data_flow_analysis))
        
        # Objetivo e Contexto de Negócio
        doc_sections.append(self._generate_business_objective(business_analysis))
        
        # Fluxo de Processamento Detalhado
        doc_sections.append(self._generate_detailed_processing_flow(business_analysis, data_flow_analysis))
        
        # Regras de Negócio Críticas
        doc_sections.append(self._generate_business_rules(business_analysis))
        
        # Análise de Fluxo de Dados
        doc_sections.append(self._generate_data_flow_analysis(data_flow_analysis))
        
        # Análise Estrutural (se disponível)
        if orchestration_result:
            doc_sections.append(self._generate_ai_analysis_summary(orchestration_result))
        
        # Análise de Performance e Volumetria
        doc_sections.append(self._generate_performance_analysis(business_analysis, data_flow_analysis))
        
        # Dependências e Recursos
        doc_sections.append(self._generate_dependencies_analysis(data_flow_analysis, extracted_data))
        
        # Recomendações
        doc_sections.append(self._generate_recommendations(business_analysis, data_flow_analysis))
        
        # Análise de IA (se disponível)
        if orchestration_result:
            doc_sections.append(self._generate_ai_analysis_summary(orchestration_result))
        
        # Apêndice com prompts e respostas
        prompts_appendix = self.prompt_logger.generate_prompt_appendix(program_name)
        if prompts_appendix:
            doc_sections.append(prompts_appendix)
        
        # Rodapé
        doc_sections.append(self._generate_footer())
        
        return '\n\n'.join(doc_sections)
    
    def _generate_header(self, program_name: str, extracted_data: Dict) -> str:
        """Gera cabeçalho da documentação"""
        
        author = extracted_data.get('author', 'Não especificado')
        date_written = extracted_data.get('date_written', 'Não especificado')
        
        return f"""# Documentação Funcional: {program_name}

**Programa:** {program_name}  
**Autor:** {author}  
**Data de Criação:** {date_written}  
**Tipo:** Programa COBOL  
**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M')}

---"""

    def _generate_executive_summary(self, business_analysis: Dict, data_flow_analysis: Dict) -> str:
        """Gera resumo executivo"""
        
        total_rules = business_analysis['summary']['total_rules']
        total_files = data_flow_analysis['summary']['total_files']
        processing_steps = business_analysis['summary']['processing_steps']
        
        main_purpose = business_analysis['objective']['main_purpose']
        
        return f"""##  Resumo Executivo

**Função Principal:** {main_purpose}

**Complexidade do Programa:**
- **Regras de Negócio:** {total_rules} regras identificadas
- **Arquivos Processados:** {total_files} arquivos
- **Etapas de Processamento:** {processing_steps} seções principais
- **Fluxos de Dados:** {data_flow_analysis['summary']['data_flows_count']} fluxos mapeados

**Estratégia de Processamento:** {business_analysis['objective']['processing_strategy']}

**Contexto:** {business_analysis['objective']['business_context']}"""

    def _generate_business_objective(self, business_analysis: Dict) -> str:
        """Gera seção de objetivo e contexto de negócio"""
        
        objective = business_analysis['objective']
        
        volume_info = ""
        if objective['volume_limits']:
            volume_items = [f"- **{k.replace('_', ' ').title()}:** {v}" 
                          for k, v in objective['volume_limits'].items()]
            volume_info = f"\n\n**Limites de Processamento:**\n" + '\n'.join(volume_items)
        
        return f"""##  Objetivo do Programa

### Propósito Principal
{objective['main_purpose']}

### Descrição Detalhada
{objective['detailed_description']}

### Contexto de Negócio
{objective['business_context']}

### Estratégia de Processamento
{objective['processing_strategy']}{volume_info}"""

    def _generate_detailed_processing_flow(self, business_analysis: Dict, data_flow_analysis: Dict) -> str:
        """Gera fluxo de processamento detalhado"""
        
        flow_sections = []
        
        flow_sections.append("## 🔄 Fluxo de Processamento Detalhado")
        
        # Fluxo por etapas
        for i, step in enumerate(business_analysis['processing_flow'], 1):
            step_section = f"""### {i}. Etapa {step.get('step_number', i)}

**Descrição:** {step.get('description', 'Processamento')}"""
            
            if step.get('input_data'):
                step_section += f"\n\n**Entradas:** {step['input_data']}"
            
            if step.get('output_data'):
                step_section += f"\n\n**Saídas:** {step['output_data']}"
            
            if step.get('conditions'):
                step_section += f"\n\n**Condições:**\n" + '\n'.join([f"- {cond}" for cond in step['conditions']])
            
            flow_sections.append(step_section)
        
        # Fluxos de dados
        if data_flow_analysis['data_flows']:
            flow_sections.append("### Fluxos de Dados Identificados")
            
            for flow in data_flow_analysis['data_flows']:
                flow_section = f"""**{flow['name']}**
- **Volume:** {flow['volume']}
- **Lógica:** {flow['logic']}
- **Transformações:** {flow['transformations_count']} operações"""
                
                if flow['conditions']:
                    flow_section += f"\n- **Condições:** {', '.join(flow['conditions'])}"
                
                flow_sections.append(flow_section)
        
        return '\n\n'.join(flow_sections)

    def _generate_business_rules(self, business_analysis: Dict) -> str:
        """Gera seção de regras de negócio"""
        
        rules_sections = []
        rules_sections.append("##  Regras de Negócio Críticas")
        
        rules = business_analysis['business_rules']
        
        # Regras de Validação
        if rules['validation_rules']:
            rules_sections.append("### Validações Obrigatórias")
            
            for i, rule in enumerate(rules['validation_rules'], 1):
                rule_section = f"""**{i}. {rule.get('description', 'Regra de validação')}**
- **Tipo:** {rule.get('type', 'validation')}
- **Condição:** {rule.get('condition', 'N/A')}"""
                
                rules_sections.append(rule_section)
        
        # Regras de Roteamento
        if rules['routing_rules']:
            rules_sections.append("### Critérios de Roteamento")
            
            for i, rule in enumerate(rules['routing_rules'], 1):
                rule_section = f"""**{i}. {rule.get('description', 'Regra de roteamento')}**
- **Tipo:** {rule.get('type', 'routing')}
- **Condição:** {rule.get('condition', 'N/A')}"""
                
                rules_sections.append(rule_section)
        
        # Regras de Controle
        if rules['control_rules']:
            rules_sections.append("### Controles de Processamento")
            
            for i, rule in enumerate(rules['control_rules'], 1):
                rule_section = f"""**{i}. {rule.get('description', 'Regra de controle')}**
- **Tipo:** {rule.get('type', 'control')}
- **Condição:** {rule.get('condition', 'N/A')}"""
                
                rules_sections.append(rule_section)
        
        return '\n\n'.join(rules_sections)

    def _generate_data_flow_analysis(self, data_flow_analysis: Dict) -> str:
        """Gera análise de fluxo de dados"""
        
        sections = []
        sections.append("##  Análise de Fluxo de Dados")
        
        # Arquivos
        sections.append("### Arquivos Processados")
        
        input_files = [f for f in data_flow_analysis['file_definitions'] if f['type'] == 'input']
        output_files = [f for f in data_flow_analysis['file_definitions'] if f['type'] == 'output']
        
        if input_files:
            sections.append("**Arquivos de Entrada:**")
            for file_def in input_files:
                file_section = f"""- **{file_def['name']}**
  - Tamanho do registro: {file_def['record_size']} caracteres
  - Padrão de uso: {file_def['usage_pattern']}"""
                
                if file_def['related_copybooks']:
                    file_section += f"\n  - Copybooks: {', '.join(file_def['related_copybooks'])}"
                
                sections.append(file_section)
        
        if output_files:
            sections.append("**Arquivos de Saída:**")
            for file_def in output_files:
                file_section = f"""- **{file_def['name']}**
  - Tamanho do registro: {file_def['record_size']} caracteres
  - Padrão de uso: {file_def['usage_pattern']}"""
                
                sections.append(file_section)
        
        # Transformações
        if data_flow_analysis['data_transformations']:
            sections.append("### Transformações de Dados")
            
            transformation_types = {}
            for trans in data_flow_analysis['data_transformations']:
                trans_type = trans['type']
                if trans_type not in transformation_types:
                    transformation_types[trans_type] = []
                transformation_types[trans_type].append(trans)
            
            for trans_type, trans_list in transformation_types.items():
                sections.append(f"**{trans_type.title()}:** {len(trans_list)} operações")
                
                for trans in trans_list[:3]:  # Mostrar apenas as 3 primeiras
                    sections.append(f"- {trans['rule']}")
                
                if len(trans_list) > 3:
                    sections.append(f"- ... e mais {len(trans_list) - 3} operações")
        
        # Critérios de Roteamento
        if data_flow_analysis['routing_criteria']:
            sections.append("### Critérios de Roteamento de Dados")
            
            for criteria in data_flow_analysis['routing_criteria']:
                criteria_section = f"""**Campo de Decisão:** {criteria['decision_field']}
**Tipo:** {criteria['type']}
**Regras:**"""
                
                for value, action in criteria['rules'].items():
                    criteria_section += f"\n- {value} → {action}"
                
                criteria_section += f"\n**Ação Padrão:** {criteria['default_action']}"
                
                sections.append(criteria_section)
        
        return '\n\n'.join(sections)

    def _generate_ai_analysis_summary(self, orchestration_result: Dict) -> str:
        """Gera resumo das análises de IA"""
        
        sections = []
        sections.append("##  Análise Estrutural (IA)")
        
        if 'parallel_results' in orchestration_result:
            for domain, result in orchestration_result['parallel_results'].items():
                if hasattr(result, 'success') and result.success:
                    analysis = getattr(result, 'analysis', {})
                    
                    sections.append(f"### {domain.title()}")
                    
                    if isinstance(analysis, dict) and 'summary' in analysis:
                        sections.append(f"**Resumo:** {analysis['summary']}")
                    
                    if isinstance(analysis, dict) and 'score' in analysis:
                        sections.append(f"**Pontuação:** {analysis['score']}/100")
                    
                    if isinstance(analysis, dict) and 'recommendations' in analysis:
                        sections.append("**Recomendações:**")
                        for rec in analysis['recommendations'][:3]:
                            sections.append(f"- {rec}")
        
        return '\n\n'.join(sections)

    def _generate_performance_analysis(self, business_analysis: Dict, data_flow_analysis: Dict) -> str:
        """Gera análise de performance"""
        
        sections = []
        sections.append("## ⚡ Análise de Performance e Volumetria")
        
        # Limites identificados
        volume_limits = business_analysis['objective']['volume_limits']
        if volume_limits:
            sections.append("### Limites de Processamento")
            for limit_type, limit_value in volume_limits.items():
                sections.append(f"- **{limit_type.replace('_', ' ').title()}:** {limit_value}")
        
        # Gargalos potenciais
        sections.append("### Gargalos Identificados")
        
        # Analisar padrões de I/O
        io_intensive = False
        for file_def in data_flow_analysis['file_definitions']:
            if 'sequential' in file_def['usage_pattern']:
                io_intensive = True
                break
        
        if io_intensive:
            sections.append("- **I/O Sequencial:** Leitura/escrita registro a registro pode ser gargalo")
        
        # Analisar transformações
        transform_count = data_flow_analysis['summary']['total_transformations']
        if transform_count > 10:
            sections.append(f"- **Transformações Múltiplas:** {transform_count} transformações por registro")
        
        # Controles de volumetria
        control_rules = business_analysis['business_rules']['control_rules']
        if control_rules:
            sections.append("- **Controle de Volumetria:** Particionamento automático implementado")
        
        # Recomendações de otimização
        sections.append("### Oportunidades de Otimização")
        
        if io_intensive:
            sections.append("- **Buffer de I/O:** Implementar leitura/escrita em blocos")
        
        if transform_count > 5:
            sections.append("- **Cache de Transformações:** Otimizar transformações repetitivas")
        
        if data_flow_analysis['summary']['data_flows_count'] > 2:
            sections.append("- **Paralelização:** Considerar processamento paralelo de fluxos independentes")
        
        return '\n\n'.join(sections)

    def _generate_dependencies_analysis(self, data_flow_analysis: Dict, extracted_data: Dict) -> str:
        """Gera análise de dependências"""
        
        sections = []
        sections.append("## 🔗 Dependências e Recursos Externos")
        
        # Subprogramas
        if 'calls' in extracted_data:
            sections.append("### Subprogramas Chamados")
            for call in extracted_data['calls']:
                sections.append(f"- **{call}:** Função específica (verificar documentação)")
        
        # Arquivos
        sections.append("### Recursos de Arquivos")
        for file_def in data_flow_analysis['file_definitions']:
            file_section = f"""- **{file_def['name']}** ({file_def['type']})
  - Tamanho: {file_def['record_size']} caracteres
  - Uso: {file_def['usage_pattern']}"""
            
            sections.append(file_section)
        
        # Copybooks
        all_copybooks = set()
        for file_def in data_flow_analysis['file_definitions']:
            all_copybooks.update(file_def['related_copybooks'])
        
        if all_copybooks:
            sections.append("### Copybooks Utilizados")
            for copybook in sorted(all_copybooks):
                sections.append(f"- {copybook}")
        
        # Recursos de sistema
        sections.append("### Recursos de Sistema")
        sections.append("- **Memória:** Controlada via working-storage")
        sections.append("- **Disco:** Múltiplos arquivos de entrada/saída")
        sections.append("- **CPU:** Processamento sequencial")
        
        return '\n\n'.join(sections)

    def _generate_recommendations(self, business_analysis: Dict, data_flow_analysis: Dict) -> str:
        """Gera recomendações"""
        
        sections = []
        sections.append("## 💡 Recomendações")
        
        # Recomendações de manutenibilidade
        sections.append("### Manutenibilidade")
        
        if business_analysis['summary']['total_rules'] > 10:
            sections.append("- **Documentação de Regras:** Criar documentação específica para regras de negócio")
        
        if data_flow_analysis['summary']['total_transformations'] > 15:
            sections.append("- **Modularização:** Considerar quebrar transformações em módulos menores")
        
        # Recomendações de performance
        sections.append("### Performance")
        
        if data_flow_analysis['summary']['total_files'] > 3:
            sections.append("- **Otimização de I/O:** Implementar estratégias de buffer para múltiplos arquivos")
        
        # Recomendações de qualidade
        sections.append("### Qualidade de Código")
        
        validation_rules = len(business_analysis['business_rules']['validation_rules'])
        if validation_rules < 3:
            sections.append("- **Validações:** Considerar adicionar mais validações de entrada")
        
        control_rules = len(business_analysis['business_rules']['control_rules'])
        if control_rules < 2:
            sections.append("- **Controles:** Implementar mais controles de processamento")
        
        return '\n\n'.join(sections)

    def _generate_footer(self) -> str:
        """Gera rodapé da documentação"""
        
        return f"""---

*Documentação gerada automaticamente pelo Sistema de Análise COBOL Multi-AI*  
*Data: {datetime.now().strftime('%d/%m/%Y às %H:%M')}*  
*Versão: Functional Documentation Generator v1.0*"""
