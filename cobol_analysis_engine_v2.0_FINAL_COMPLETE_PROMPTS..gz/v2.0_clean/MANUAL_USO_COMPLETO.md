# Manual de Uso Completo - COBOL Analysis Engine v2.0

## Visão Geral

O **COBOL Analysis Engine v2.0** é um sistema inteligente que analisa programas COBOL e gera documentação profissional automaticamente. O sistema foi projetado para ser **sempre funcional**, operando mesmo sem configuração de IAs.

### O que o sistema faz
- **Explica o objetivo** de cada programa COBOL de forma clara e detalhada
- **Identifica regras de negócio** importantes (validações, critérios, limites)
- **Detecta particularidades** que merecem atenção especial
- **Integra copybooks** para análise contextual completa
- **Captura prompts e respostas** das IAs para transparência total
- **Gera relatórios profissionais** seguindo padrões de documentação técnica

---

## Todos os Parâmetros e Opções

### Sintaxe Completa

```bash
python3.11 main.py [arquivo_entrada] [opções]
```

### Parâmetros Obrigatórios

| Parâmetro | Descrição | Exemplo |
|-----------|-----------|---------|
| `arquivo_entrada` | Arquivo COBOL (.cbl) ou fontes.txt | `programa.cbl` ou `fontes.txt` |

### Parâmetros Opcionais

| Parâmetro | Descrição | Valores | Padrão | Exemplo |
|-----------|-----------|---------|--------|---------|
| `-o, --output` | Diretório de saída | Qualquer caminho | `./resultado/` | `-o relatorios/` |
| `-b, --books` | Arquivo de copybooks | Arquivo .txt | Nenhum | `-b BOOKS.txt` |
| `-m, --mode` | Modo de análise | `traditional`, `enhanced`, `multi_ai` | `enhanced` | `-m enhanced` |
| `-c, --config` | Arquivo de configuração | Arquivo .yaml | `config/config.yaml` | `-c minha_config.yaml` |
| `-v, --verbose` | Saída detalhada | Flag (sem valor) | Desabilitado | `-v` |
| `-h, --help` | Ajuda | Flag (sem valor) | - | `--help` |
| `--status` | Testar conectividade | Flag (sem valor) | - | `--status` |

---

## Modos de Análise Disponíveis

### 1. **Traditional** (Sempre Disponível)
- **O que faz:** Análise estrutural baseada em parsing do código
- **Tempo:** ~0.01s por programa
- **Dependências:** Nenhuma
- **Saída:** Estrutura básica e componentes identificados
- **Quando usar:** Para análise rápida e estrutural

```bash
python3.11 main.py programa.cbl -m traditional
```

### 2. **Enhanced** (Recomendado)
- **O que faz:** Análise inteligente com geração de relatórios de alta qualidade
- **Tempo:** ~5-15s por programa
- **Dependências:** Opcional (funciona sem IA)
- **Saída:** Relatório profissional completo + transparência de prompts
- **Quando usar:** Para documentação completa e profissional

```bash
python3.11 main.py programa.cbl -m enhanced
```

### 3. **Multi_AI** (Análise Especializada)
- **O que faz:** Análise paralela com múltiplas IAs especializadas
- **Tempo:** ~10-30s por programa
- **Dependências:** Requer pelo menos uma IA configurada
- **Saída:** Análise especializada por domínios
- **Quando usar:** Para análise profunda e especializada

```bash
python3.11 main.py programa.cbl -m multi_ai
```

---

## Tipos de Entrada Suportados

### 1. Arquivo COBOL Individual

```bash
# Análise de um programa específico
python3.11 main.py examples/LHAN0542_TESTE.cbl -o resultados/
```

**Formatos aceitos:**
- `.cbl` - Arquivo COBOL padrão
- `.cob` - Arquivo COBOL alternativo
- `.txt` - Arquivo texto com código COBOL

### 2. Arquivo fontes.txt (Processamento em Lote)

```bash
# Análise de múltiplos programas
python3.11 main.py examples/fontes.txt -o resultados_lote/
```

**Formato do fontes.txt:**
```
LHAN0542
LHAN0705
LHAN0706
LHBR0700
MZAN6056
```

**Nota:** O sistema procura por `{nome}.cbl` no mesmo diretório do fontes.txt.

### 3. Arquivo BOOKS.txt (Copybooks)

```bash
# Incluir copybooks na análise
python3.11 main.py programa.cbl -b examples/BOOKS.txt
```

**Formato do BOOKS.txt:**
```
MZTCM530
DRR00082
BOOK001
BOOK002
COMMON-FIELDS
```

**Nota:** O sistema procura por `{nome}.cpy` ou `{nome}.cbl` no mesmo diretório.

---

## Exemplos Práticos Completos

### Exemplo 1: Análise Simples

```bash
# Comando
python3.11 main.py examples/LHAN0542_TESTE.cbl

# Resultado
 Detectado programa COBOL: examples/LHAN0542_TESTE.cbl
 Análise individual iniciada...
 Iniciando análise contextualizada para LHAN0542_TESTE
 Análise concluída com sucesso!
 Relatório: LHAN0542_TESTE_ENHANCED_ANALYSIS.md
 Tempo total: 12.02s
 Resultados salvos em: resultado/
```

### Exemplo 2: Análise com Copybooks

```bash
# Comando
python3.11 main.py examples/LHAN0542_TESTE.cbl -b examples/BOOKS.txt -o meus_resultados/

# Resultado
 Detectado programa COBOL: examples/LHAN0542_TESTE.cbl
 Copybooks encontrados: 11 copybooks carregados
 Análise individual iniciada...
 Análise concluída com sucesso!
 Relatório: meus_resultados/LHAN0542_TESTE_ENHANCED_ANALYSIS.md
```

### Exemplo 3: Processamento em Lote

```bash
# Comando
python3.11 main.py examples/fontes.txt -b examples/BOOKS.txt -o lote_completo/ -m enhanced

# Resultado
 Detectado arquivo fontes.txt: examples/fontes.txt
 Processamento em lote iniciado...
Encontrados 5 programas para análise
Encontrados 11 copybooks
============================================================
Processando programa 1/5: LHAN0542
============================================================
 Iniciando análise contextualizada para LHAN0542
✓ Análise concluída: LHAN0542_ENHANCED_ANALYSIS.md
============================================================
[... processamento dos demais programas ...]
============================================================
 Processamento em lote concluído!
 5/5 programas processados com sucesso
 Tempo total: 0.07s
 Resultados salvos em: lote_completo/
```

### Exemplo 4: Modo Multi-AI

```bash
# Comando
python3.11 main.py examples/LHAN0542_TESTE.cbl -m multi_ai -o multi_results/

# Resultado
 Detectado programa COBOL: examples/LHAN0542_TESTE.cbl
 Análise individual iniciada...
 Análise concluída com sucesso!
 Relatório: LHAN0542_TESTE_MULTI_AI_ANALYSIS.md
 Tempo total: 2.02s
```

---

## Configuração de IAs

### LuzIA (Recomendado para Brasil)

#### Configuração via Variáveis de Ambiente
```bash
# Linux/Mac
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# Windows
set LUZIA_CLIENT_ID=seu_client_id
set LUZIA_CLIENT_SECRET=seu_client_secret
```

#### Verificar Configuração LuzIA
```bash
python3.11 main.py --status

# Saída esperada:
 Verificando conectividade com provedores de IA...
============================================================
✅ LUZIA: Conectado
   Modelo: luzia-chat
⚪ OPENAI: API Key inválida
============================================================
```

### OpenAI

#### Configuração via Variáveis de Ambiente
```bash
# Linux/Mac
export OPENAI_API_KEY="sua_api_key"

# Windows
set OPENAI_API_KEY=sua_api_key
```

### Configuração via Arquivo

```yaml
# config/config.yaml
providers:
  luzia:
    client_id: "seu_client_id"
    client_secret: "seu_client_secret"
    model: "luzia-chat"
    temperature: 0.1
    timeout: 30.0
  openai:
    api_key: "sua_api_key"
    model: "gpt-4"
    temperature: 0.1
    max_tokens: 4000

logging:
  level: "INFO"
  dir: "logs"

analysis:
  max_prompt_size: 8000
  enable_fallback: true
  preserve_responses: true
```

---

## Interpretando os Resultados

### Estrutura do Relatório Enhanced

```markdown
# Análise COBOL: NOME_PROGRAMA

**Programa**: NOME_PROGRAMA
**Autor**: N/A
**Data de Criação**: N/A
**Gerado por**: Sistema de Análise COBOL v2.0
**Data de Análise**: 20/09/2025 22:55:44

---

## Resumo Executivo

O programa NOME_PROGRAMA é uma solução para [objetivo identificado]. 
O sistema processa X arquivo(s) de entrada e gera Y arquivo(s) de saída.

### Impacto no Negócio
- **Criticidade**: [Nível identificado]
- **Integrações**: X copybooks utilizados
- **Arquivos processados**: Y arquivos no total

---

## Análise Funcional

### Objetivo Principal
[Descrição do objetivo extraído do código]

### Funcionalidades Principais
[Lista de funcionalidades identificadas]

---

## Estrutura Técnica

### Working Storage (X campos identificados)
| Campo | Tipo | Tamanho | Descrição |
|-------|------|---------|-----------|
| [Campos extraídos automaticamente] |

### Copybooks Utilizados (X identificados)
- [Lista de copybooks com descrições]

---

## Regras de Negócio

| Regra | Condição | Ação |
|-------|----------|------|
| [Regras extraídas do código] |

---

## Fluxo de Processamento

### Fase 1: Inicialização
[Passos identificados]

### Fase 2: Processamento Principal
[Lógica principal extraída]

### Fase 3: Finalização
[Passos de finalização]

---

## Transparência de Análise

### Status: [Status da análise]
### Método: [Método utilizado]

### Análise 1: Análise Principal
**Provedor:** [Nome do provedor]
**Modelo:** [Modelo utilizado]
**Tempo:** [Tempo de execução]
**Status:** [Sucesso/Falha]

**Prompt enviado:**
```
[Prompt completo preservado]
```

**Resposta original:**
```
[Resposta completa preservada]
```
```

### Tipos de Relatório Gerados

#### 1. Enhanced Analysis (`*_ENHANCED_ANALYSIS.md`)
- Relatório completo com análise inteligente
- Inclui transparência de prompts e respostas
- Estrutura profissional e detalhada

#### 2. Multi-AI Analysis (`*_MULTI_AI_ANALYSIS.md`)
- Análise especializada por domínios
- Comparação entre diferentes IAs
- Validação cruzada de resultados

#### 3. Traditional Analysis (`*_ANALYSIS.md`)
- Análise estrutural básica
- Sempre disponível, independe de IA
- Foco em componentes e estrutura

#### 4. Batch Summary (`BATCH_PROCESSING_SUMMARY.md`)
- Resumo do processamento em lote
- Estatísticas de sucesso
- Lista de arquivos processados

---

## Comandos de Diagnóstico

### Verificar Status do Sistema

```bash
# Testar conectividade com IAs
python3.11 main.py --status

# Saída esperada:
 Verificando conectividade com provedores de IA...
============================================================
⚪ LUZIA: Credenciais não configuradas
   Configure: LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET
 OPENAI: API Key inválida
⚪ DATABRICKS: Biblioteca não instalada
⚪ BEDROCK: Biblioteca disponível (não configurado)
⚪ GITHUB_COPILOT: Biblioteca não instalada
============================================================
 Resumo:
   Conectados: 0
   Disponíveis: 1
   Total verificados: 5
 Dicas de configuração:
   - Para usar LuzIA: Configure as variáveis LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET
   - Para usar OpenAI: Configure a variável OPENAI_API_KEY
   - Sistema funciona no modo básico mesmo sem IAs configuradas
 Sistema sempre funcional no modo traditional
```

### Executar com Debug

```bash
# Saída detalhada para diagnóstico
python3.11 main.py programa.cbl -v

# Mostra logs detalhados de cada etapa
```

### Verificar Logs

```bash
# Verificar logs de erro
tail -f logs/analysis_errors.log

# Verificar logs gerais
tail -f logs/cobol_analysis.log

# Verificar se há erros específicos
grep ERROR logs/analysis_errors.log
```

---

## Solução de Problemas

### Sistema Sempre Funcional

O sistema foi projetado para **nunca falhar completamente**:

1. **Modo traditional** sempre disponível
2. **Fallback automático** em caso de erro
3. **Análise estrutural** independe de IA
4. **Relatórios básicos** sempre gerados

```bash
# Em caso de qualquer problema, use:
python3.11 main.py programa.cbl -m traditional
```

### Problemas Comuns e Soluções

#### 1. "Command not found: python3.11"
```bash
# Verificar versões disponíveis
python3 --version
python --version

# Usar versão disponível
python3 main.py --help
```

#### 2. "ModuleNotFoundError"
```bash
# Reinstalar dependências
pip3 install -r requirements.txt

# Verificar instalação
pip3 list | grep requests
```

#### 3. "Provider não disponível"
```bash
# Verificar status
python3.11 main.py --status

# Usar modo tradicional
python3.11 main.py programa.cbl -m traditional
```

#### 4. "Arquivo não encontrado"
```bash
# Verificar caminho
ls -la examples/LHAN0542_TESTE.cbl

# Usar caminho absoluto
python3.11 main.py /caminho/completo/programa.cbl
```

#### 5. "Timeout na análise"
```bash
# Usar modo tradicional para análise rápida
python3.11 main.py programa.cbl -m traditional

# Verificar conectividade
ping luzia.com.br
```

### Recuperação de Falhas

#### Logs e Diagnóstico
```bash
# Monitorar execução em tempo real
tail -f logs/cobol_analysis.log

# Verificar erros específicos
grep "ERROR" logs/analysis_errors.log

# Diagnóstico completo
python3.11 main.py --status -v
```

---

## Casos de Uso Práticos

### 1. **Documentação de Sistema Legado**

#### Cenário
Sistema COBOL de 20 anos sem documentação atualizada.

#### Solução
```bash
# Análise completa do sistema
python3.11 main.py sistema/fontes.txt -b sistema/BOOKS.txt -m enhanced -o documentacao/
```

#### Benefícios
- Compreensão rápida do sistema
- Identificação de regras de negócio críticas
- Base para futuras manutenções

### 2. **Auditoria de Compliance**

#### Cenário
Auditoria regulatória requer documentação de controles.

#### Solução
```bash
# Análise focada em controles
python3.11 main.py controles/fontes.txt -m multi_ai -o auditoria/

# Análise detalhada de programa crítico
python3.11 main.py CONTROLE_PRINCIPAL.cbl -m enhanced -o auditoria_detalhada/
```

#### Benefícios
- Documentação de controles implementados
- Identificação de pontos de atenção
- Relatórios para auditores

### 3. **Migração de Sistema**

#### Cenário
Migração de mainframe para plataforma moderna.

#### Solução
```bash
# Análise completa para migração
python3.11 main.py migracao/fontes.txt -b migracao/BOOKS.txt -m multi_ai -o analise_migracao/
```

#### Benefícios
- Mapeamento completo de regras de negócio
- Identificação de dependências
- Redução de riscos de migração

### 4. **Treinamento de Equipe**

#### Cenário
Novos desenvolvedores precisam entender sistema COBOL.

#### Solução
```bash
# Gerar material didático
python3.11 main.py treinamento/programas_basicos.txt -m enhanced -o material_treinamento/
```

#### Benefícios
- Material didático automatizado
- Explicações claras e estruturadas
- Aceleração do aprendizado

---

## Configuração Avançada

### Prompts Personalizados

#### Arquivo config/prompts.yaml
```yaml
analysis_prompts:
  main_analysis: |
    Analise o programa COBOL de forma COMPLETA e UNIFICADA:
    
    **PROGRAMA:** {program_name}
    
    **COPYBOOKS DISPONÍVEIS:**
    {copybooks_context}
    
    **CÓDIGO COBOL:**
    ```cobol
    {cobol_code}
    ```
    
    Forneça análise detalhada incluindo:
    1. Objetivo e funcionalidade principal
    2. Regras de negócio identificadas
    3. Estruturas de dados importantes
    4. Fluxo de processamento
    5. Pontos de atenção e particularidades
```

### Configuração de Timeout

```yaml
# config/config.yaml
providers:
  luzia:
    timeout: 60.0  # Aumentar para programas grandes
  openai:
    timeout: 45.0
```

### Configuração de Logs

```yaml
# config/config.yaml
logging:
  level: "DEBUG"  # Para diagnóstico detalhado
  dir: "logs_detalhados"
  max_file_size: "10MB"
  backup_count: 5
```

---

## Estrutura do Projeto

```
cobol_analysis_engine_v2.0/
├── main.py                     # Ponto de entrada principal
├── requirements.txt            # Dependências Python
├── README.md                   # Documentação principal
├── MANUAL_USO_COMPLETO.md     # Este manual
├── config/
│   ├── config.yaml            # Configurações do sistema
│   └── prompts.yaml           # Templates de prompts para IAs
├── src/
│   ├── core/                  # Núcleo do sistema
│   │   ├── unified_analyzer.py        # Analisador principal
│   │   ├── multi_ai_orchestrator.py  # Orquestrador multi-IA
│   │   └── intelligent_analyzer.py   # Analisador inteligente
│   ├── providers/             # Provedores de IA
│   │   ├── provider_manager.py       # Gerenciador de provedores
│   │   ├── luzia_provider.py         # Integração LuzIA (corrigida)
│   │   └── openai_provider.py        # Integração OpenAI
│   ├── generators/            # Geradores de documentação
│   │   └── intelligent_documentation_generator.py
│   ├── extractors/            # Extratores de dados
│   │   └── cobol_extractor.py        # Extração de código COBOL
│   └── utils/                 # Utilitários
│       ├── enhanced_logger.py        # Sistema de logs
│       └── simple_status_checker.py  # Verificador de status
├── examples/                  # Exemplos e dados de teste
│   ├── fontes.txt            # Lista de programas para análise
│   ├── BOOKS.txt             # Lista de copybooks
│   ├── *.cbl                 # Programas COBOL de exemplo
│   └── output_exemplo/       # Exemplos de relatórios gerados
├── docs/                     # Documentação adicional
└── logs/                     # Logs do sistema
```

---

## Resumo dos Comandos Essenciais

```bash
# Comandos básicos que sempre funcionam
python3.11 main.py --help                    # Ver ajuda
python3.11 main.py --status                  # Testar sistema
python3.11 main.py programa.cbl              # Análise simples
python3.11 main.py programa.cbl -m enhanced  # Análise completa
python3.11 main.py fontes.txt -b BOOKS.txt   # Lote com copybooks

# Comandos para diagnóstico
python3.11 main.py programa.cbl -v           # Saída detalhada
tail -f logs/cobol_analysis.log              # Monitorar logs
python3.11 main.py --status -v               # Diagnóstico completo

# Comandos para diferentes cenários
python3.11 main.py programa.cbl -m traditional  # Análise rápida
python3.11 main.py programa.cbl -m multi_ai     # Análise especializada
python3.11 main.py fontes.txt -o relatorios/    # Processamento em lote
```

---

## Status do Sistema

**Versão:** 2.0 (Estável)  
**Status:** ✅ Funcional e Testado  
**Última atualização:** 20/09/2025  

### Correções Aplicadas
- ✅ Integração LuzIA corrigida e funcional
- ✅ Erro 'str' object has no attribute 'get' resolvido
- ✅ Modo multi_ai funcionando corretamente
- ✅ Remoção completa de chamadas para API Manus
- ✅ Remoção de ícones para interface profissional
- ✅ Transparência total de prompts e respostas
- ✅ Sistema sempre funcional, mesmo sem IAs

### Funcionalidades Validadas
- ✅ Processamento individual de programas
- ✅ Processamento em lote com fontes.txt
- ✅ Integração com copybooks via BOOKS.txt
- ✅ Três modos de análise funcionais
- ✅ Geração de relatórios profissionais
- ✅ Sistema de logs e diagnóstico
- ✅ Fallback inteligente para modo tradicional

---

**COBOL Analysis Engine v2.0**  
**Manual atualizado em:** 20/09/2025  
**Versão do manual:** 2.0 - Completo e Validado
