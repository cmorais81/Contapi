#!/usr/bin/env python3
"""
CLI adicional para COBOL to Docs v1.0
Comandos de conveniência e funcionalidades extras
"""

import argparse
import sys
import os
import json
import logging
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.parsers.cobol_parser_original import COBOLParser
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.core.config import load_config

def setup_logging(verbose=False):
    """Configura logging"""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def cmd_analyze(args):
    """Comando para análise individual"""
    
    if not os.path.exists(args.fontes):
        print(f"❌ Arquivo não encontrado: {args.fontes}")
        return 1
    
    # Carregar configuração
    config = load_config(args.config)
    
    # Inicializar componentes
    parser = COBOLParser()
    analyzer = EnhancedCOBOLAnalyzer(config)
    doc_generator = DocumentationGenerator(args.output)
    
    print(f"🔍 Analisando: {args.fontes}")
    
    # Parse dos programas
    programs, copybooks = parser.parse_file(args.fontes)
    
    if not programs:
        print("❌ Nenhum programa encontrado")
        return 1
    
    # Carregar books se fornecido
    books_content = ""
    if args.books and os.path.exists(args.books):
        with open(args.books, 'r', encoding='utf-8', errors='ignore') as f:
            books_content = f.read()
        print(f"📚 Books carregados: {len(books_content)} caracteres")
    
    # Analisar cada programa
    success_count = 0
    for program in programs:
        print(f"\\n📋 Processando: {program.name}")
        
        try:
            # Análise
            ai_response = analyzer.analyze_program_enhanced(
                program=program,
                copybooks=copybooks,
                books_content=books_content,
                model=args.model
            )
            
            if ai_response and ai_response.success:
                # Gerar documentação
                doc_path = doc_generator.generate_program_documentation(
                    program=program,
                    ai_response=ai_response
                )
                print(f"✅ Documentação gerada: {doc_path}")
                success_count += 1
            else:
                print(f"❌ Falha na análise de {program.name}")
                
        except Exception as e:
            print(f"❌ Erro ao processar {program.name}: {e}")
    
    print(f"\\n📊 Resultado: {success_count}/{len(programs)} programas analisados com sucesso")
    return 0 if success_count > 0 else 1

def cmd_list(args):
    """Comando para listar programas"""
    
    if not os.path.exists(args.fontes):
        print(f"❌ Arquivo não encontrado: {args.fontes}")
        return 1
    
    parser = COBOLParser()
    programs, copybooks = parser.parse_file(args.fontes)
    
    print(f"📋 Programas encontrados em {args.fontes}:")
    print(f"📊 Total: {len(programs)} programas, {len(copybooks)} copybooks\\n")
    
    for i, program in enumerate(programs, 1):
        lines = len(program.content.split('\\n'))
        chars = len(program.content)
        print(f"{i:2d}. {program.name:<12} ({lines:4d} linhas, {chars:5d} chars)")
    
    if copybooks:
        print(f"\\n📚 Copybooks encontrados:")
        for i, copybook in enumerate(copybooks, 1):
            lines = len(copybook.content.split('\\n'))
            chars = len(copybook.content)
            print(f"{i:2d}. {copybook.name:<12} ({lines:4d} linhas, {chars:5d} chars)")
    
    return 0

def cmd_status(args):
    """Comando para verificar status do sistema"""
    
    print("🔍 COBOL to Docs v1.0 - Status do Sistema\\n")
    
    # Verificar arquivos principais
    files_to_check = [
        ("main.py", "Aplicação principal"),
        ("config/config.yaml", "Configuração"),
        ("src/", "Código fonte"),
        ("data/", "Dados e prompts"),
        ("examples/fontes.txt", "Arquivo de fontes"),
        ("examples/books.txt", "Arquivo de books")
    ]
    
    print("📁 Arquivos do Sistema:")
    for file_path, description in files_to_check:
        full_path = os.path.join(os.path.dirname(__file__), file_path)
        status = "✅" if os.path.exists(full_path) else "❌"
        print(f"  {status} {description:<20} ({file_path})")
    
    # Verificar configuração
    print("\\n⚙️  Configuração:")
    try:
        config = load_config()
        providers = config.get('providers', {})
        print(f"  ✅ Configuração carregada")
        print(f"  📊 Providers configurados: {len(providers)}")
        
        for provider_name, provider_config in providers.items():
            enabled = provider_config.get('enabled', False)
            status = "✅" if enabled else "⚪"
            print(f"    {status} {provider_name}")
            
    except Exception as e:
        print(f"  ❌ Erro na configuração: {e}")
    
    # Verificar diretório de saída
    output_dir = args.output if hasattr(args, 'output') else 'output'
    print(f"\\n📤 Diretório de Saída: {output_dir}")
    if os.path.exists(output_dir):
        files = os.listdir(output_dir)
        md_files = [f for f in files if f.endswith('.md')]
        json_dirs = [f for f in files if os.path.isdir(os.path.join(output_dir, f))]
        print(f"  ✅ Diretório existe")
        print(f"  📄 Relatórios markdown: {len(md_files)}")
        print(f"  📁 Diretórios JSON: {len(json_dirs)}")
    else:
        print(f"  ⚪ Diretório não existe (será criado)")
    
    return 0

def cmd_clean(args):
    """Comando para limpar arquivos de saída"""
    
    output_dir = args.output if hasattr(args, 'output') else 'output'
    
    if not os.path.exists(output_dir):
        print(f"⚪ Diretório {output_dir} não existe")
        return 0
    
    print(f"🧹 Limpando diretório: {output_dir}")
    
    # Contar arquivos antes
    files_before = []
    for root, dirs, files in os.walk(output_dir):
        for file in files:
            files_before.append(os.path.join(root, file))
    
    if not files_before:
        print("⚪ Diretório já está vazio")
        return 0
    
    # Confirmar limpeza
    if not args.force:
        response = input(f"❓ Confirma limpeza de {len(files_before)} arquivos? (s/N): ")
        if response.lower() not in ['s', 'sim', 'y', 'yes']:
            print("❌ Operação cancelada")
            return 1
    
    # Remover arquivos
    removed_count = 0
    for file_path in files_before:
        try:
            os.remove(file_path)
            removed_count += 1
        except Exception as e:
            print(f"❌ Erro ao remover {file_path}: {e}")
    
    # Remover diretórios vazios
    for root, dirs, files in os.walk(output_dir, topdown=False):
        for dir_name in dirs:
            dir_path = os.path.join(root, dir_name)
            try:
                if not os.listdir(dir_path):  # Se diretório está vazio
                    os.rmdir(dir_path)
            except:
                pass
    
    print(f"✅ Limpeza concluída: {removed_count} arquivos removidos")
    return 0

def cmd_config(args):
    """Comando para mostrar configuração"""
    
    try:
        config = load_config(args.config)
        
        if args.json:
            print(json.dumps(config, indent=2, ensure_ascii=False))
        else:
            print("⚙️  CONFIGURAÇÃO DO SISTEMA\\n")
            
            # Providers
            providers = config.get('providers', {})
            print(f"🔗 PROVIDERS ({len(providers)}):")
            for name, provider_config in providers.items():
                enabled = provider_config.get('enabled', False)
                status = "✅ Habilitado" if enabled else "⚪ Desabilitado"
                description = provider_config.get('description', 'N/A')
                print(f"  • {name:<20} {status}")
                print(f"    {description}")
                
                models = provider_config.get('models', [])
                if models:
                    print(f"    Modelos: {', '.join(models) if isinstance(models, list) else str(models)}")
                print()
            
            # Análise
            analysis = config.get('analysis', {})
            if analysis:
                print("🔍 ANÁLISE:")
                for key, value in analysis.items():
                    print(f"  • {key}: {value}")
                print()
            
            # Logging
            logging_config = config.get('logging', {})
            if logging_config:
                print("📝 LOGGING:")
                for key, value in logging_config.items():
                    print(f"  • {key}: {value}")
        
        return 0
        
    except Exception as e:
        print(f"❌ Erro ao carregar configuração: {e}")
        return 1

def main():
    """Função principal do CLI"""
    
    parser = argparse.ArgumentParser(
        description='COBOL to Docs v1.0 - CLI Avançado',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Comandos disponíveis:

  analyze    Analisar programas COBOL
  list       Listar programas em arquivo
  status     Verificar status do sistema
  clean      Limpar arquivos de saída
  config     Mostrar configuração

Exemplos:

  # Analisar programas
  python cli.py analyze --fontes examples/fontes.txt --books examples/books.txt
  
  # Listar programas
  python cli.py list --fontes examples/fontes.txt
  
  # Verificar status
  python cli.py status
  
  # Limpar saída
  python cli.py clean --force
  
  # Mostrar configuração
  python cli.py config --json
        '''
    )
    
    # Argumentos globais
    parser.add_argument('--config', default='config/config.yaml', help='Arquivo de configuração')
    parser.add_argument('--output', default='output', help='Diretório de saída')
    parser.add_argument('--verbose', '-v', action='store_true', help='Modo verboso')
    
    # Subcomandos
    subparsers = parser.add_subparsers(dest='command', help='Comandos disponíveis')
    
    # Comando analyze
    analyze_parser = subparsers.add_parser('analyze', help='Analisar programas COBOL')
    analyze_parser.add_argument('--fontes', required=True, help='Arquivo de fontes COBOL')
    analyze_parser.add_argument('--books', help='Arquivo de books/copybooks')
    analyze_parser.add_argument('--model', default='enhanced_mock', help='Modelo de análise')
    
    # Comando list
    list_parser = subparsers.add_parser('list', help='Listar programas')
    list_parser.add_argument('--fontes', required=True, help='Arquivo de fontes COBOL')
    
    # Comando status
    status_parser = subparsers.add_parser('status', help='Status do sistema')
    
    # Comando clean
    clean_parser = subparsers.add_parser('clean', help='Limpar arquivos de saída')
    clean_parser.add_argument('--force', action='store_true', help='Forçar limpeza sem confirmação')
    
    # Comando config
    config_parser = subparsers.add_parser('config', help='Mostrar configuração')
    config_parser.add_argument('--json', action='store_true', help='Saída em JSON')
    
    # Parse dos argumentos
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.verbose)
    
    # Executar comando
    if args.command == 'analyze':
        return cmd_analyze(args)
    elif args.command == 'list':
        return cmd_list(args)
    elif args.command == 'status':
        return cmd_status(args)
    elif args.command == 'clean':
        return cmd_clean(args)
    elif args.command == 'config':
        return cmd_config(args)
    else:
        parser.print_help()
        return 1

if __name__ == '__main__':
    sys.exit(main())
