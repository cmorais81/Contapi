# Guia de Instalação
## Seguindo Padrões Corporativos

### Pré-requisitos

- Python 3.8+
- Acesso às credenciais dos providers
- Permissões de escrita no diretório de saída

### Instalação Padrão

```bash
# 1. Extrair pacote
tar -xzf cobol_to_docs_v1.0_COMPLETO_VALIDADO_*.tar.gz

# 2. Navegar para diretório
cd cobol_to_docs_v1.0_COMPLETE

# 3. Verificar instalação
python cli.py status
```

### Configuração de Credenciais

Siga os padrões de segurança estabelecidos:

```bash
# Variáveis de ambiente (recomendado)
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
export GITHUB_COPILOT_API_KEY="seu_api_key"
export OPENAI_API_KEY="seu_api_key"
```

### Verificação da Instalação

```bash
# Status completo
python cli.py status

# Teste básico
python cli.py analyze --fontes examples/fontes.txt --books examples/books.txt
```
