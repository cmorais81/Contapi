# Configuração de Credenciais
## Seguindo Padrões de Segurança

### Variáveis de Ambiente (Recomendado)

```bash
# LuzIA (Santander)
export LUZIA_CLIENT_ID="seu_client_id_aqui"
export LUZIA_CLIENT_SECRET="seu_client_secret_aqui"

# GitHub Copilot
export GITHUB_COPILOT_API_KEY="seu_github_token_aqui"

# OpenAI
export OPENAI_API_KEY="seu_openai_key_aqui"

# AWS Bedrock
export AWS_ACCESS_KEY_ID="seu_aws_access_key"
export AWS_SECRET_ACCESS_KEY="seu_aws_secret_key"
export AWS_REGION="us-east-1"

# Databricks
export DATABRICKS_TOKEN="seu_databricks_token"
export DATABRICKS_WORKSPACE_URL="https://your-workspace.cloud.databricks.com"
```

### Arquivo .env (Desenvolvimento)

```bash
# Criar arquivo .env na raiz do projeto
cat > .env << EOF
LUZIA_CLIENT_ID=seu_client_id_aqui
LUZIA_CLIENT_SECRET=seu_client_secret_aqui
GITHUB_COPILOT_API_KEY=seu_github_token_aqui
OPENAI_API_KEY=seu_openai_key_aqui
EOF
```

### Verificação de Credenciais

```bash
# Verificar configuração
python cli.py config --check-credentials

# Status dos providers
python cli.py status --providers
```
