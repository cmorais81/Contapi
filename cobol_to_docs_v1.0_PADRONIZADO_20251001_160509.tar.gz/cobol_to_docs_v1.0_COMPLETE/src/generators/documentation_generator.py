"""
COBOL AI Engine v2.0.0 - Documentation Generator
Gerador de documentação otimizado para clareza, rastreabilidade e usabilidade.
"""

import os
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional

try:
    from .cobol_parser_original import CobolProgram
    from ..providers.base_provider import AIResponse
except ImportError:
    from ..parsers.cobol_parser_original import CobolProgram
    from ..providers.base_provider import AIResponse

class DocumentationGenerator:
    """Gerador de documentação focado em relatórios funcionais."""

    def __init__(self, output_dir: str = "output"):
        self.output_dir = output_dir
        self.logger = logging.getLogger(__name__)
        self.files_generated = 0
        self.total_programs = 0
        
        # Criar diretórios necessários
        os.makedirs(output_dir, exist_ok=True)
        
        # Diretório para JSONs das respostas
        self.json_dir = os.path.join(output_dir, "ai_responses")
        os.makedirs(self.json_dir, exist_ok=True)
        
        # Diretório para JSONs dos requests
        self.request_dir = os.path.join(output_dir, "ai_requests")
        os.makedirs(self.request_dir, exist_ok=True)

    def generate_program_documentation(self, program: CobolProgram, ai_response: AIResponse, phase_info: Optional[Dict[str, Any]] = None) -> str:
        """Gera a documentação funcional aprimorada para um programa."""
        try:
            # Salvar JSONs de auditoria
            self._save_ai_response_json(program, ai_response)
            self._save_ai_request_json(program, ai_response)
            
            # Gerar conteúdo do relatório
            content = self._generate_functional_report(program, ai_response)
            filename = f"{program.name}_analise_funcional.md"
            filepath = os.path.join(self.output_dir, filename)
            
            # Salvar arquivo markdown
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            self.files_generated += 1
            self.logger.info(f"Documentação gerada: {filename}")
            
            return filepath
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação para {program.name}: {e}")
            return None

    def _generate_functional_report(self, program: CobolProgram, ai_response: AIResponse) -> str:
        """Gera o relatório funcional completo."""
        
        # Obter conteúdo da análise
        analysis_content = getattr(ai_response, 'content', getattr(ai_response, 'analysis_content', ''))
        
        # Obter informações do provider
        provider = getattr(ai_response, 'provider', getattr(ai_response, 'provider_used', 'unknown'))
        model = getattr(ai_response, 'model', getattr(ai_response, 'model_used', 'unknown'))
        
        # Gerar relatório
        report = f"""# {program.name} - Análise Funcional

## Informações do Programa

- **Nome:** {program.name}
- **Tamanho:** {len(program.content)} caracteres
- **Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}

## Análise Técnica

{analysis_content}

## Informações da Análise

- **Provider:** {provider}
- **Modelo:** {model}
- **Sucesso:** {'Sim' if ai_response.success else 'Não'}
- **Tokens Utilizados:** {getattr(ai_response, 'tokens_used', 0)}
- **Tempo de Processamento:** {getattr(ai_response, 'processing_time', 0):.2f}s

## Arquivos de Auditoria

- **Resposta da IA:** `ai_responses/{program.name}_ai_response.json`
- **Request Enviado:** `ai_requests/{program.name}_ai_request.json`

---

*Relatório gerado automaticamente pelo COBOL to Docs v1.0*
"""
        
        return report

    def _save_ai_response_json(self, program: CobolProgram, response: AIResponse) -> None:
        """Salva a resposta da IA em formato JSON para auditoria."""
        try:
            # Preparar dados da resposta
            response_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "provider": getattr(response, 'provider', getattr(response, 'provider_used', 'unknown')),
                "model": getattr(response, 'model', getattr(response, 'model_used', 'unknown')),
                "success": response.success,
                "tokens_used": response.tokens_used,
                "processing_time": getattr(response, 'processing_time', 0),
                "content": getattr(response, 'content', getattr(response, 'analysis_content', '')),
                "metadata": getattr(response, 'metadata', {})
            }
            
            # Salvar JSON
            json_filename = f"{program.name}_ai_response.json"
            json_filepath = os.path.join(self.json_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(response_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON da resposta salvo: {json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON da resposta para {program.name}: {e}")
    
    def _save_ai_request_json(self, program: CobolProgram, response: AIResponse) -> None:
        """Salva o request enviado ao provedor em formato JSON para auditoria."""
        try:
            # Extrair dados do request dos metadados da resposta
            request_data = {
                "program_name": program.name,
                "timestamp": datetime.now().isoformat(),
                "provider": getattr(response, 'provider', getattr(response, 'provider_used', 'unknown')),
                "model": getattr(response, 'model', getattr(response, 'model_used', 'unknown')),
                "program_size": len(program.content),
                "configuration": {
                    "temperature": 0.1,
                    "max_tokens": 4000,
                    "timeout": 120
                }
            }
            
            # Salvar JSON do request
            json_filename = f"{program.name}_ai_request.json"
            json_filepath = os.path.join(self.request_dir, json_filename)
            
            with open(json_filepath, 'w', encoding='utf-8') as f:
                json.dump(request_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"JSON do request salvo: {json_filename}")
            
        except Exception as e:
            self.logger.error(f"Erro ao salvar JSON do request para {program.name}: {e}")

    def get_generation_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas de geração."""
        return {
            "files_generated": self.files_generated,
            "total_programs": self.total_programs,
            "output_directory": self.output_dir,
            "json_responses_dir": self.json_dir,
            "json_requests_dir": self.request_dir
        }
