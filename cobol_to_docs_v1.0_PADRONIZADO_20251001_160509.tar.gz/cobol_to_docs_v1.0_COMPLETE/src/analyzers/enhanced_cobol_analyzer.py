"""
Analisador COBOL Aprimorado - Versão Final Limpa
Implementa todas as melhorias do feedback do especialista
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path

class EnhancedCOBOLAnalyzer:
    """Analisador COBOL aprimorado - Versão Final Funcional"""
    
    def __init__(self, config):
        """Inicializa o analisador aprimorado"""
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Inicializar providers
        from ..providers.enhanced_mock_provider import EnhancedMockProvider
        from ..providers.luzia_provider import LuziaProvider
        
        self.providers = {
            "enhanced_mock": EnhancedMockProvider(config),
            "luzia": LuziaProvider(config) if config.get("providers", {}).get("luzia", {}).get("enabled", False) else None
        }
        
        self.logger.info("Enhanced COBOL Analyzer inicializado - Versão Final")
    
    def analyze_program_enhanced(self, program, copybooks=None, books_content="", model: str = "enhanced_mock"):
        """Análise aprimorada de programa COBOL com books"""
        try:
            self.logger.info(f"Analisando programa: {program.name if hasattr(program, 'name') else 'UNKNOWN'}")
            
            # Obter provider
            provider = self.providers.get(model)
            if not provider:
                raise ValueError(f"Provider não disponível: {model}")
            
            # Criar request compatível
            from ..core.analysis_request import AnalysisRequest
            
            request = AnalysisRequest(
                program_name=program.name if hasattr(program, 'name') else 'UNKNOWN',
                program_content=program.content if hasattr(program, 'content') else str(program),
                model=model,
                copybooks=copybooks or [],
                books_content=books_content,  # Passar books content
                prompt=self._get_default_prompt()
            )
            
            # Executar análise
            result = provider.analyze(request)
            
            if result and result.success:
                self.logger.info(f"✅ Análise concluída para {request.program_name}")
                return result
            else:
                self.logger.error(f"❌ Falha na análise de {request.program_name}")
                return None
                
        except Exception as e:
            self.logger.error(f"Erro na análise: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _get_default_prompt(self):
        """Retorna prompt padrão baseado no feedback do especialista"""
        return """Você é um analista de sistemas COBOL especializado na análise de programas COBOL.
Sua tarefa é realizar uma análise detalhada e técnica do programa fornecido.

IMPORTANTE - Baseado no feedback do especialista COBOL:
- Foque em FUNCIONALIDADES ESPECÍFICAS extraídas do código
- Identifique REGRAS DE NEGÓCIO CONCRETAS com evidências
- Analise código SEM DEPENDÊNCIA de comentários (inferência estrutural)
- Use linguagem TÉCNICA SÊNIOR, sem explicações básicas
- Mapeie COPYBOOKS e dependências CADOC detalhadamente
- Extraia ALGORITMOS e lógicas específicas
- Use BOOKS fornecidos como contexto adicional para análise

ESTRUTURA DA ANÁLISE:
1. FUNCIONALIDADES IMPLEMENTADAS (específicas do código)
2. REGRAS DE NEGÓCIO IDENTIFICADAS (com números de linha)
3. ESTRUTURAS DE DADOS (layouts e tipos)
4. INTEGRAÇÕES E DEPENDÊNCIAS (copybooks, módulos)
5. ALGORITMOS E LÓGICAS (cálculos, processamentos)
6. ANÁLISE DE CRITICIDADE (complexidade, impacto)
7. CONTEXTO DOS BOOKS (informações adicionais relevantes)"""

    def get_available_models(self):
        """Retorna modelos disponíveis"""
        return list(self.providers.keys())
    
    def get_provider_status(self):
        """Retorna status dos providers"""
        status = {}
        for name, provider in self.providers.items():
            if provider:
                status[name] = "disponível"
            else:
                status[name] = "indisponível"
        return status
