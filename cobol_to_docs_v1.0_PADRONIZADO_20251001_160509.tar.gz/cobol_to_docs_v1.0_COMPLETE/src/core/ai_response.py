"""
Classe AIResponse para respostas de análise
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any
from datetime import datetime

@dataclass
class AIResponse:
    """Resposta de análise de IA"""
    success: bool = False
    content: str = ""  # Adicionado atributo content
    analysis_content: str = ""
    model_used: str = ""
    provider: str = ""  # Adicionado atributo provider
    provider_used: str = ""
    tokens_used: int = 0
    processing_time: float = 0.0
    timestamp: Optional[datetime] = None
    metadata: Optional[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()
        if self.metadata is None:
            self.metadata = {}
        
        # Garantir compatibilidade entre content e analysis_content
        if self.content and not self.analysis_content:
            self.analysis_content = self.content
        elif self.analysis_content and not self.content:
            self.content = self.analysis_content
        
        # Garantir compatibilidade entre provider e provider_used
        if self.provider and not self.provider_used:
            self.provider_used = self.provider
        elif self.provider_used and not self.provider:
            self.provider = self.provider_used
