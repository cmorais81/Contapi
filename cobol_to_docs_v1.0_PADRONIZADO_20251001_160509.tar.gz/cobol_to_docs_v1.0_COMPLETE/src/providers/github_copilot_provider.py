"""
GitHub Copilot Provider para análise COBOL
"""

import os
import json
import logging
import requests
from typing import Dict, Any, Optional
from .base_provider import BaseProvider, AIResponse

class GitHubCopilotProvider(BaseProvider):
    """Provider para GitHub Copilot"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = os.getenv('GITHUB_COPILOT_API_KEY')
        self.base_url = "https://api.github.com/copilot"
        self.logger = logging.getLogger(__name__)
        
        if not self.api_key:
            self.logger.warning("GitHub Copilot API key não configurada")
    
    def analyze(self, request) -> Optional[AIResponse]:
        """Analisa programa COBOL usando GitHub Copilot"""
        
        if not self.api_key:
            return self._create_fallback_response(request, "API key não configurada")
        
        try:
            # Preparar prompt
            prompt = self._prepare_prompt(request)
            
            # Fazer requisição para GitHub Copilot
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
            
            payload = {
                'messages': [
                    {
                        'role': 'user',
                        'content': prompt
                    }
                ],
                'model': 'gpt-4',
                'max_tokens': 4000,
                'temperature': 0.1
            }
            
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                content = result['choices'][0]['message']['content']
                
                return AIResponse(
                    success=True,
                    content=content,
                    analysis_content=content,
                    model_used="github-copilot",
                    provider="github_copilot",
                    tokens_used=result.get('usage', {}).get('total_tokens', 0),
                    processing_time=1.0
                )
            else:
                self.logger.error(f"GitHub Copilot API error: {response.status_code}")
                return self._create_fallback_response(request, f"API error: {response.status_code}")
                
        except Exception as e:
            self.logger.error(f"Erro no GitHub Copilot Provider: {e}")
            return self._create_fallback_response(request, str(e))
    
    def _prepare_prompt(self, request) -> str:
        """Prepara prompt para GitHub Copilot"""
        
        prompt = f"""Analise o seguinte programa COBOL:

PROGRAMA: {request.program_name}

CÓDIGO COBOL:
{request.program_content}
"""
        
        if hasattr(request, 'books_content') and request.books_content:
            prompt += f"""

COPYBOOKS/BOOKS:
{request.books_content}
"""
        
        prompt += """

Realize uma análise técnica detalhada incluindo:
1. Funcionalidades implementadas
2. Regras de negócio
3. Estruturas de dados
4. Integrações e dependências
5. Algoritmos e lógicas
"""
        
        return prompt
    
    def _create_fallback_response(self, request, error_msg: str) -> AIResponse:
        """Cria resposta de fallback"""
        
        content = f"""# Análise COBOL - {request.program_name}

**Erro**: {error_msg}

## Análise Básica

O programa {request.program_name} é um sistema COBOL que requer análise detalhada.

### Funcionalidades Identificadas
- Processamento de dados COBOL
- Manipulação de arquivos
- Lógica de negócio

### Recomendações
- Configurar GitHub Copilot API key
- Revisar configurações do provider
- Tentar novamente após configuração
"""
        
        return AIResponse(
            success=False,
            content=content,
            analysis_content=content,
            model_used="github-copilot-fallback",
            provider="github_copilot",
            tokens_used=0,
            processing_time=0.1
        )
