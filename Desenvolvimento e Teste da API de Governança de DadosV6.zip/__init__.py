"""
Models SQLAlchemy para TBR GDP Core v6.0
Baseado no modelo de dados v5.0 com 24 tabelas
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, JSON, ForeignKey, Numeric, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from datetime import datetime
from typing import Optional, Dict, Any

Base = declarative_base()

# ===========================
# MÓDULO 1: CORE ENTITIES
# ===========================

class User(Base):
    """
    Usuários do sistema com atributos ABAC para controle de acesso
    """
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(100), unique=True, nullable=False, index=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    full_name = Column(String(255), nullable=False)
    department = Column(String(100), nullable=False, index=True)
    role = Column(String(50), nullable=False, index=True)
    location = Column(String(100), nullable=False)
    security_level = Column(String(20), nullable=False, default="basic")
    is_active = Column(Boolean, default=True, nullable=False)
    last_login = Column(DateTime(timezone=True))
    user_attributes = Column(JSON, nullable=False, default=dict)  # ABAC attributes
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_users_dept_role', 'department', 'role'),
        Index('idx_users_active_security', 'is_active', 'security_level'),
    )

class Domain(Base):
    """
    Domínios organizacionais para hierarquia e ownership
    """
    __tablename__ = "domains"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), unique=True, nullable=False, index=True)
    description = Column(Text)
    parent_domain_id = Column(Integer, ForeignKey('domains.id'), nullable=True)
    owner_user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    business_area = Column(String(100), nullable=False, index=True)
    cost_center = Column(String(50), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    domain_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    parent_domain = relationship("Domain", remote_side=[id])
    owner = relationship("User")
    entities = relationship("Entity", back_populates="domain")

class Entity(Base):
    """
    Entidades/datasets principais do sistema
    """
    __tablename__ = "entities"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, index=True)
    display_name = Column(String(255), nullable=False)
    description = Column(Text)
    domain_id = Column(Integer, ForeignKey('domains.id'), nullable=False)
    entity_type = Column(String(50), nullable=False, index=True)  # table, view, api, file
    source_system = Column(String(100), nullable=False, index=True)
    classification = Column(String(20), nullable=False, default="internal", index=True)
    owner_user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    steward_user_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    location_uri = Column(Text, nullable=False)
    schema_definition = Column(JSON, nullable=False, default=dict)
    quality_score = Column(Numeric(5,2), nullable=True)
    last_profiled = Column(DateTime(timezone=True))
    is_active = Column(Boolean, default=True, nullable=False)
    entity_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    domain = relationship("Domain", back_populates="entities")
    owner = relationship("User", foreign_keys=[owner_user_id])
    steward = relationship("User", foreign_keys=[steward_user_id])
    attributes = relationship("EntityAttribute", back_populates="entity")
    contracts = relationship("DataContract", back_populates="entity")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_entities_domain_type', 'domain_id', 'entity_type'),
        Index('idx_entities_classification_active', 'classification', 'is_active'),
        Index('idx_entities_source_system', 'source_system'),
    )

class EntityAttribute(Base):
    """
    Atributos das entidades com profiling e linhagem
    """
    __tablename__ = "entity_attributes"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    entity_id = Column(Integer, ForeignKey('entities.id'), nullable=False)
    name = Column(String(100), nullable=False, index=True)
    display_name = Column(String(255), nullable=False)
    description = Column(Text)
    data_type = Column(String(50), nullable=False, index=True)
    is_nullable = Column(Boolean, default=True, nullable=False)
    is_primary_key = Column(Boolean, default=False, nullable=False)
    is_foreign_key = Column(Boolean, default=False, nullable=False)
    is_pii = Column(Boolean, default=False, nullable=False, index=True)
    classification = Column(String(20), nullable=False, default="internal")
    format_pattern = Column(String(255), nullable=True)
    business_rules = Column(Text)
    profiling_stats = Column(JSON, nullable=False, default=dict)
    lineage_upstream = Column(JSON, nullable=False, default=list)
    lineage_downstream = Column(JSON, nullable=False, default=list)
    quality_issues = Column(JSON, nullable=False, default=list)
    last_profiled = Column(DateTime(timezone=True))
    attribute_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    entity = relationship("Entity", back_populates="attributes")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_entity_attributes_entity_name', 'entity_id', 'name'),
        Index('idx_entity_attributes_pii', 'is_pii'),
        Index('idx_entity_attributes_data_type', 'data_type'),
    )

class DataContract(Base):
    """
    Contratos de dados principais
    """
    __tablename__ = "data_contracts"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, index=True)
    version = Column(String(20), nullable=False, default="1.0.0")
    entity_id = Column(Integer, ForeignKey('entities.id'), nullable=False)
    template_id = Column(Integer, ForeignKey('contract_templates.id'), nullable=True)
    provider_system = Column(String(100), nullable=False, index=True)
    consumer_systems = Column(JSON, nullable=False, default=list)
    contract_type = Column(String(50), nullable=False, index=True)  # api, batch, stream
    status = Column(String(20), nullable=False, default="draft", index=True)
    sla_definition = Column(JSON, nullable=False, default=dict)
    schema_definition = Column(JSON, nullable=False, default=dict)
    quality_requirements = Column(JSON, nullable=False, default=dict)
    security_requirements = Column(JSON, nullable=False, default=dict)
    business_context = Column(Text)
    owner_user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    approver_user_id = Column(Integer, ForeignKey('users.id'), nullable=True)
    effective_date = Column(DateTime(timezone=True))
    expiration_date = Column(DateTime(timezone=True))
    is_active = Column(Boolean, default=True, nullable=False)
    contract_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    entity = relationship("Entity", back_populates="contracts")
    template = relationship("ContractTemplate")
    owner = relationship("User", foreign_keys=[owner_user_id])
    approver = relationship("User", foreign_keys=[approver_user_id])
    versions = relationship("ContractVersion", back_populates="contract")
    usage_stats = relationship("ContractUsage", back_populates="contract")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_contracts_entity_status', 'entity_id', 'status'),
        Index('idx_contracts_provider_type', 'provider_system', 'contract_type'),
        Index('idx_contracts_active_effective', 'is_active', 'effective_date'),
    )

# ===========================
# MÓDULO 2: CONTRACTS & TEMPLATES
# ===========================

class ContractTemplate(Base):
    """
    Templates reutilizáveis para contratos
    """
    __tablename__ = "contract_templates"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, index=True)
    category = Column(String(50), nullable=False, index=True)
    description = Column(Text)
    contract_type = Column(String(50), nullable=False, index=True)
    domain_id = Column(Integer, ForeignKey('domains.id'), nullable=True)
    default_sla = Column(JSON, nullable=False, default=dict)
    default_quality = Column(JSON, nullable=False, default=dict)
    default_security = Column(JSON, nullable=False, default=dict)
    schema_template = Column(JSON, nullable=False, default=dict)
    configuration_options = Column(JSON, nullable=False, default=dict)
    usage_count = Column(Integer, default=0, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=False)
    template_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    domain = relationship("Domain")
    creator = relationship("User")
    contracts = relationship("DataContract", back_populates="template")

class ContractVersion(Base):
    """
    Versionamento de contratos
    """
    __tablename__ = "contract_versions"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    contract_id = Column(Integer, ForeignKey('data_contracts.id'), nullable=False)
    version_number = Column(String(20), nullable=False)
    version_type = Column(String(10), nullable=False, index=True)  # major, minor, patch
    change_description = Column(Text, nullable=False)
    schema_changes = Column(JSON, nullable=False, default=dict)
    breaking_changes = Column(Boolean, default=False, nullable=False)
    compatibility_notes = Column(Text)
    migration_guide = Column(Text)
    rollback_plan = Column(Text)
    approved_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    deployed_at = Column(DateTime(timezone=True))
    is_current = Column(Boolean, default=False, nullable=False)
    version_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    contract = relationship("DataContract", back_populates="versions")
    approver = relationship("User")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_contract_versions_contract_current', 'contract_id', 'is_current'),
        Index('idx_contract_versions_type_breaking', 'version_type', 'breaking_changes'),
    )

class ContractUsage(Base):
    """
    Métricas de uso dos contratos
    """
    __tablename__ = "contract_usage"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    contract_id = Column(Integer, ForeignKey('data_contracts.id'), nullable=False)
    consumer_system = Column(String(100), nullable=False, index=True)
    usage_date = Column(DateTime(timezone=True), nullable=False, index=True)
    request_count = Column(Integer, default=0, nullable=False)
    data_volume_gb = Column(Numeric(12,3), default=0, nullable=False)
    avg_response_time_ms = Column(Integer, default=0, nullable=False)
    error_count = Column(Integer, default=0, nullable=False)
    success_rate = Column(Numeric(5,2), default=100, nullable=False)
    peak_concurrent_users = Column(Integer, default=0, nullable=False)
    cost_incurred = Column(Numeric(10,2), default=0, nullable=False)
    usage_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    contract = relationship("DataContract", back_populates="usage_stats")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_contract_usage_contract_date', 'contract_id', 'usage_date'),
        Index('idx_contract_usage_consumer_date', 'consumer_system', 'usage_date'),
    )

# ===========================
# MÓDULO 3: POLICIES & SECURITY
# ===========================

class Policy(Base):
    """
    Políticas unificadas (acesso, mascaramento, governança)
    """
    __tablename__ = "policies"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, index=True)
    policy_type = Column(String(50), nullable=False, index=True)  # access, masking, governance, retention
    category = Column(String(50), nullable=False, index=True)
    description = Column(Text)
    scope = Column(String(50), nullable=False, index=True)  # global, domain, entity, attribute
    target_resource = Column(String(255), nullable=True, index=True)
    conditions = Column(JSON, nullable=False, default=dict)  # ABAC conditions
    actions = Column(JSON, nullable=False, default=dict)  # What to do
    priority = Column(Integer, default=100, nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    effective_date = Column(DateTime(timezone=True))
    expiration_date = Column(DateTime(timezone=True))
    created_by = Column(Integer, ForeignKey('users.id'), nullable=False)
    approved_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    policy_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    creator = relationship("User", foreign_keys=[created_by])
    approver = relationship("User", foreign_keys=[approved_by])
    executions = relationship("PolicyExecution", back_populates="policy")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_policies_type_scope', 'policy_type', 'scope'),
        Index('idx_policies_active_priority', 'is_active', 'priority'),
        Index('idx_policies_target_resource', 'target_resource'),
    )

class PolicyExecution(Base):
    """
    Execução e resultados de políticas
    """
    __tablename__ = "policy_executions"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    policy_id = Column(Integer, ForeignKey('policies.id'), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    resource_accessed = Column(String(255), nullable=False, index=True)
    execution_context = Column(JSON, nullable=False, default=dict)
    decision = Column(String(20), nullable=False, index=True)  # allow, deny, mask, transform
    applied_transformations = Column(JSON, nullable=False, default=dict)
    execution_time_ms = Column(Integer, default=0, nullable=False)
    session_id = Column(String(100), nullable=True, index=True)
    client_ip = Column(String(45), nullable=True)
    user_agent = Column(Text)
    execution_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    
    # Relationships
    policy = relationship("Policy", back_populates="executions")
    user = relationship("User")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_policy_executions_policy_date', 'policy_id', 'created_at'),
        Index('idx_policy_executions_user_resource', 'user_id', 'resource_accessed'),
        Index('idx_policy_executions_decision', 'decision'),
    )

class DataLineage(Base):
    """
    Linhagem detalhada de dados
    """
    __tablename__ = "data_lineage"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    source_entity_id = Column(Integer, ForeignKey('entities.id'), nullable=False)
    target_entity_id = Column(Integer, ForeignKey('entities.id'), nullable=False)
    source_attribute = Column(String(100), nullable=True)
    target_attribute = Column(String(100), nullable=True)
    transformation_type = Column(String(50), nullable=False, index=True)  # direct, aggregation, join, calculation
    transformation_logic = Column(Text)
    transformation_code = Column(Text)
    process_name = Column(String(100), nullable=False, index=True)
    process_type = Column(String(50), nullable=False, index=True)  # etl, api, manual, calculation
    frequency = Column(String(20), nullable=False)  # real-time, hourly, daily, weekly
    last_execution = Column(DateTime(timezone=True))
    execution_status = Column(String(20), nullable=False, default="unknown")
    data_quality_impact = Column(Numeric(5,2), nullable=True)
    business_impact = Column(String(20), nullable=False, default="medium")
    lineage_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    source_entity = relationship("Entity", foreign_keys=[source_entity_id])
    target_entity = relationship("Entity", foreign_keys=[target_entity_id])
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_data_lineage_source_target', 'source_entity_id', 'target_entity_id'),
        Index('idx_data_lineage_process_type', 'process_name', 'process_type'),
        Index('idx_data_lineage_transformation_type', 'transformation_type'),
    )

# ===========================
# MÓDULO 4: QUALITY & COMPLIANCE
# ===========================

class QualityRule(Base):
    """
    Regras de qualidade configuráveis
    """
    __tablename__ = "quality_rules"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, index=True)
    rule_type = Column(String(50), nullable=False, index=True)  # completeness, accuracy, consistency, validity
    category = Column(String(50), nullable=False, index=True)
    description = Column(Text)
    entity_id = Column(Integer, ForeignKey('entities.id'), nullable=True)
    attribute_name = Column(String(100), nullable=True, index=True)
    rule_definition = Column(JSON, nullable=False, default=dict)
    threshold_warning = Column(Numeric(5,2), default=90, nullable=False)
    threshold_critical = Column(Numeric(5,2), default=80, nullable=False)
    auto_fix_enabled = Column(Boolean, default=False, nullable=False)
    auto_fix_logic = Column(Text)
    execution_frequency = Column(String(20), nullable=False, default="daily")
    execution_schedule = Column(String(50), nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=False)
    rule_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    entity = relationship("Entity")
    creator = relationship("User")
    executions = relationship("QualityExecution", back_populates="rule")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_quality_rules_entity_attribute', 'entity_id', 'attribute_name'),
        Index('idx_quality_rules_type_category', 'rule_type', 'category'),
        Index('idx_quality_rules_active_frequency', 'is_active', 'execution_frequency'),
    )

class QualityExecution(Base):
    """
    Execução e resultados de qualidade
    """
    __tablename__ = "quality_executions"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    rule_id = Column(Integer, ForeignKey('quality_rules.id'), nullable=False)
    execution_date = Column(DateTime(timezone=True), nullable=False, index=True)
    records_analyzed = Column(Integer, default=0, nullable=False)
    records_passed = Column(Integer, default=0, nullable=False)
    records_failed = Column(Integer, default=0, nullable=False)
    quality_score = Column(Numeric(5,2), nullable=False)
    status = Column(String(20), nullable=False, index=True)  # passed, warning, critical, failed
    execution_time_seconds = Column(Integer, default=0, nullable=False)
    error_details = Column(JSON, nullable=False, default=list)
    failed_records_sample = Column(JSON, nullable=False, default=list)
    auto_fix_applied = Column(Boolean, default=False, nullable=False)
    auto_fix_count = Column(Integer, default=0, nullable=False)
    recommendations = Column(JSON, nullable=False, default=list)
    execution_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    
    # Relationships
    rule = relationship("QualityRule", back_populates="executions")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_quality_executions_rule_date', 'rule_id', 'execution_date'),
        Index('idx_quality_executions_status_date', 'status', 'execution_date'),
    )

class ComplianceReport(Base):
    """
    Relatórios de compliance
    """
    __tablename__ = "compliance_reports"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    report_name = Column(String(100), nullable=False, index=True)
    report_type = Column(String(50), nullable=False, index=True)  # lgpd, gdpr, sox, custom
    scope = Column(String(50), nullable=False, index=True)  # global, domain, entity
    target_resource = Column(String(255), nullable=True)
    reporting_period_start = Column(DateTime(timezone=True), nullable=False)
    reporting_period_end = Column(DateTime(timezone=True), nullable=False)
    compliance_score = Column(Numeric(5,2), nullable=False)
    total_checks = Column(Integer, default=0, nullable=False)
    passed_checks = Column(Integer, default=0, nullable=False)
    failed_checks = Column(Integer, default=0, nullable=False)
    critical_issues = Column(Integer, default=0, nullable=False)
    findings = Column(JSON, nullable=False, default=list)
    recommendations = Column(JSON, nullable=False, default=list)
    action_items = Column(JSON, nullable=False, default=list)
    generated_by = Column(Integer, ForeignKey('users.id'), nullable=False)
    reviewed_by = Column(Integer, ForeignKey('users.id'), nullable=True)
    status = Column(String(20), nullable=False, default="draft", index=True)
    report_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    generator = relationship("User", foreign_keys=[generated_by])
    reviewer = relationship("User", foreign_keys=[reviewed_by])
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_compliance_reports_type_period', 'report_type', 'reporting_period_start'),
        Index('idx_compliance_reports_scope_status', 'scope', 'status'),
    )

# ===========================
# MÓDULO 5: METRICS & MONITORING
# ===========================

class MetricDefinition(Base):
    """
    Definições de métricas customizadas
    """
    __tablename__ = "metrics_definitions"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, index=True)
    metric_type = Column(String(50), nullable=False, index=True)  # business, technical, quality, cost
    category = Column(String(50), nullable=False, index=True)
    description = Column(Text)
    unit_of_measure = Column(String(20), nullable=False)
    calculation_logic = Column(Text, nullable=False)
    data_sources = Column(JSON, nullable=False, default=list)
    calculation_frequency = Column(String(20), nullable=False, default="daily")
    target_value = Column(Numeric(15,3), nullable=True)
    warning_threshold = Column(Numeric(15,3), nullable=True)
    critical_threshold = Column(Numeric(15,3), nullable=True)
    is_kpi = Column(Boolean, default=False, nullable=False)
    dashboard_visible = Column(Boolean, default=True, nullable=False)
    owner_user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    is_active = Column(Boolean, default=True, nullable=False)
    metric_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    owner = relationship("User")
    values = relationship("MetricValue", back_populates="metric")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_metrics_definitions_type_category', 'metric_type', 'category'),
        Index('idx_metrics_definitions_kpi_active', 'is_kpi', 'is_active'),
    )

class MetricValue(Base):
    """
    Valores e tendências de métricas
    """
    __tablename__ = "metrics_values"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    metric_id = Column(Integer, ForeignKey('metrics_definitions.id'), nullable=False)
    measurement_date = Column(DateTime(timezone=True), nullable=False, index=True)
    value = Column(Numeric(15,3), nullable=False)
    target_value = Column(Numeric(15,3), nullable=True)
    variance_percentage = Column(Numeric(5,2), nullable=True)
    status = Column(String(20), nullable=False, index=True)  # normal, warning, critical
    trend = Column(String(20), nullable=False, default="stable")  # improving, stable, declining
    context_data = Column(JSON, nullable=False, default=dict)
    calculation_details = Column(JSON, nullable=False, default=dict)
    data_quality_score = Column(Numeric(5,2), nullable=True)
    confidence_level = Column(Numeric(5,2), default=100, nullable=False)
    alert_triggered = Column(Boolean, default=False, nullable=False)
    value_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    
    # Relationships
    metric = relationship("MetricDefinition", back_populates="values")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_metrics_values_metric_date', 'metric_id', 'measurement_date'),
        Index('idx_metrics_values_status_alert', 'status', 'alert_triggered'),
    )

class SystemMonitoring(Base):
    """
    Monitoramento de sistema
    """
    __tablename__ = "system_monitoring"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    component_name = Column(String(100), nullable=False, index=True)
    component_type = Column(String(50), nullable=False, index=True)  # api, database, integration, service
    health_status = Column(String(20), nullable=False, index=True)  # healthy, degraded, unhealthy
    availability_percentage = Column(Numeric(5,2), default=100, nullable=False)
    response_time_ms = Column(Integer, default=0, nullable=False)
    error_rate_percentage = Column(Numeric(5,2), default=0, nullable=False)
    throughput_per_second = Column(Integer, default=0, nullable=False)
    cpu_usage_percentage = Column(Numeric(5,2), nullable=True)
    memory_usage_percentage = Column(Numeric(5,2), nullable=True)
    disk_usage_percentage = Column(Numeric(5,2), nullable=True)
    active_connections = Column(Integer, default=0, nullable=False)
    version_info = Column(String(50), nullable=True)
    last_deployment = Column(DateTime(timezone=True))
    capacity_utilization = Column(Numeric(5,2), default=0, nullable=False)
    performance_metrics = Column(JSON, nullable=False, default=dict)
    alerts_active = Column(JSON, nullable=False, default=list)
    monitoring_metadata = Column(JSON, nullable=False, default=dict)
    measured_at = Column(DateTime(timezone=True), nullable=False, index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_system_monitoring_component_date', 'component_name', 'measured_at'),
        Index('idx_system_monitoring_health_type', 'health_status', 'component_type'),
    )

# ===========================
# MÓDULO 6: INTEGRATIONS
# ===========================

class ExternalIntegration(Base):
    """
    Configurações de integração
    """
    __tablename__ = "external_integrations"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False, index=True)
    integration_type = Column(String(50), nullable=False, index=True)  # unity_catalog, informatica_axon, apache_atlas
    system_name = Column(String(100), nullable=False, index=True)
    endpoint_url = Column(String(500), nullable=False)
    authentication_type = Column(String(50), nullable=False)  # oauth, api_key, basic, certificate
    connection_config = Column(JSON, nullable=False, default=dict)
    sync_frequency = Column(String(20), nullable=False, default="hourly")
    sync_direction = Column(String(20), nullable=False, default="bidirectional")  # inbound, outbound, bidirectional
    data_types_synced = Column(JSON, nullable=False, default=list)
    field_mappings = Column(JSON, nullable=False, default=dict)
    transformation_rules = Column(JSON, nullable=False, default=dict)
    is_active = Column(Boolean, default=True, nullable=False)
    last_sync_at = Column(DateTime(timezone=True))
    last_sync_status = Column(String(20), nullable=False, default="pending")
    error_count = Column(Integer, default=0, nullable=False)
    success_count = Column(Integer, default=0, nullable=False)
    created_by = Column(Integer, ForeignKey('users.id'), nullable=False)
    integration_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    creator = relationship("User")
    mappings = relationship("IntegrationMapping", back_populates="integration")
    sync_logs = relationship("SyncLog", back_populates="integration")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_external_integrations_type_active', 'integration_type', 'is_active'),
        Index('idx_external_integrations_system_status', 'system_name', 'last_sync_status'),
    )

class IntegrationMapping(Base):
    """
    Mapeamentos entre sistemas
    """
    __tablename__ = "integration_mappings"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    integration_id = Column(Integer, ForeignKey('external_integrations.id'), nullable=False)
    source_system = Column(String(100), nullable=False, index=True)
    target_system = Column(String(100), nullable=False, index=True)
    source_object_type = Column(String(50), nullable=False)  # entity, attribute, contract, policy
    target_object_type = Column(String(50), nullable=False)
    source_object_id = Column(String(255), nullable=False, index=True)
    target_object_id = Column(String(255), nullable=False, index=True)
    mapping_rules = Column(JSON, nullable=False, default=dict)
    transformation_logic = Column(Text)
    bidirectional = Column(Boolean, default=True, nullable=False)
    conflict_resolution = Column(String(50), nullable=False, default="source_wins")
    last_synced = Column(DateTime(timezone=True))
    sync_status = Column(String(20), nullable=False, default="pending")
    is_active = Column(Boolean, default=True, nullable=False)
    mapping_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    integration = relationship("ExternalIntegration", back_populates="mappings")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_integration_mappings_integration_source', 'integration_id', 'source_object_id'),
        Index('idx_integration_mappings_target_status', 'target_object_id', 'sync_status'),
    )

class SyncLog(Base):
    """
    Logs de sincronização
    """
    __tablename__ = "sync_logs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    integration_id = Column(Integer, ForeignKey('external_integrations.id'), nullable=False)
    sync_session_id = Column(String(100), nullable=False, index=True)
    sync_type = Column(String(20), nullable=False, index=True)  # full, incremental, manual
    sync_direction = Column(String(20), nullable=False)  # inbound, outbound
    started_at = Column(DateTime(timezone=True), nullable=False, index=True)
    completed_at = Column(DateTime(timezone=True))
    status = Column(String(20), nullable=False, index=True)  # running, completed, failed, cancelled
    records_processed = Column(Integer, default=0, nullable=False)
    records_created = Column(Integer, default=0, nullable=False)
    records_updated = Column(Integer, default=0, nullable=False)
    records_deleted = Column(Integer, default=0, nullable=False)
    records_failed = Column(Integer, default=0, nullable=False)
    error_summary = Column(Text)
    error_details = Column(JSON, nullable=False, default=list)
    performance_stats = Column(JSON, nullable=False, default=dict)
    triggered_by = Column(String(50), nullable=False, default="scheduler")  # scheduler, manual, api
    sync_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    
    # Relationships
    integration = relationship("ExternalIntegration", back_populates="sync_logs")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_sync_logs_integration_started', 'integration_id', 'started_at'),
        Index('idx_sync_logs_session_status', 'sync_session_id', 'status'),
    )

# ===========================
# MÓDULO 7: CONFIGURATION & AUDIT
# ===========================

class Configuration(Base):
    """
    Configurações globais e templates
    """
    __tablename__ = "configurations"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    config_key = Column(String(100), unique=True, nullable=False, index=True)
    config_category = Column(String(50), nullable=False, index=True)
    config_value = Column(JSON, nullable=False, default=dict)
    description = Column(Text)
    data_type = Column(String(20), nullable=False, default="json")  # string, integer, boolean, json
    is_sensitive = Column(Boolean, default=False, nullable=False)
    is_system = Column(Boolean, default=False, nullable=False)
    validation_rules = Column(JSON, nullable=False, default=dict)
    default_value = Column(JSON, nullable=False, default=dict)
    environment = Column(String(20), nullable=False, default="production")
    last_modified_by = Column(Integer, ForeignKey('users.id'), nullable=False)
    config_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Relationships
    modifier = relationship("User")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_configurations_category_env', 'config_category', 'environment'),
        Index('idx_configurations_system_sensitive', 'is_system', 'is_sensitive'),
    )

class AuditEvent(Base):
    """
    Auditoria completa de eventos
    """
    __tablename__ = "audit_events"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_type = Column(String(50), nullable=False, index=True)  # access, create, update, delete, execute
    event_category = Column(String(50), nullable=False, index=True)  # data_access, policy_change, contract_update
    resource_type = Column(String(50), nullable=False, index=True)  # entity, contract, policy, user
    resource_id = Column(String(255), nullable=False, index=True)
    resource_name = Column(String(255), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    session_id = Column(String(100), nullable=True, index=True)
    client_ip = Column(String(45), nullable=True)
    user_agent = Column(Text)
    action_performed = Column(String(100), nullable=False)
    old_values = Column(JSON, nullable=False, default=dict)
    new_values = Column(JSON, nullable=False, default=dict)
    success = Column(Boolean, nullable=False, index=True)
    error_message = Column(Text)
    business_context = Column(Text)
    risk_level = Column(String(20), nullable=False, default="low", index=True)
    compliance_relevant = Column(Boolean, default=False, nullable=False)
    retention_period_days = Column(Integer, default=2555, nullable=False)  # 7 years default
    event_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    
    # Relationships
    user = relationship("User")
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_audit_events_user_date', 'user_id', 'created_at'),
        Index('idx_audit_events_resource_type_id', 'resource_type', 'resource_id'),
        Index('idx_audit_events_category_risk', 'event_category', 'risk_level'),
        Index('idx_audit_events_compliance_date', 'compliance_relevant', 'created_at'),
    )

class NotificationLog(Base):
    """
    Logs de notificações
    """
    __tablename__ = "notification_logs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    notification_type = Column(String(50), nullable=False, index=True)  # email, slack, webhook, sms
    event_trigger = Column(String(50), nullable=False, index=True)  # quality_alert, contract_change, policy_violation
    recipient_type = Column(String(20), nullable=False)  # user, group, system
    recipient_id = Column(String(255), nullable=False, index=True)
    recipient_address = Column(String(500), nullable=False)
    subject = Column(String(255), nullable=False)
    message_body = Column(Text, nullable=False)
    priority = Column(String(20), nullable=False, default="normal")  # low, normal, high, critical
    status = Column(String(20), nullable=False, index=True)  # pending, sent, delivered, failed, bounced
    sent_at = Column(DateTime(timezone=True))
    delivered_at = Column(DateTime(timezone=True))
    error_message = Column(Text)
    retry_count = Column(Integer, default=0, nullable=False)
    max_retries = Column(Integer, default=3, nullable=False)
    related_resource_type = Column(String(50), nullable=True)
    related_resource_id = Column(String(255), nullable=True)
    notification_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_notification_logs_type_status', 'notification_type', 'status'),
        Index('idx_notification_logs_trigger_priority', 'event_trigger', 'priority'),
        Index('idx_notification_logs_recipient_date', 'recipient_id', 'created_at'),
    )

class CostTracking(Base):
    """
    Rastreamento de custos
    """
    __tablename__ = "cost_tracking"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    cost_category = Column(String(50), nullable=False, index=True)  # infrastructure, storage, compute, licensing
    resource_type = Column(String(50), nullable=False, index=True)  # contract, entity, integration, system
    resource_id = Column(String(255), nullable=False, index=True)
    resource_name = Column(String(255), nullable=False)
    cost_period_start = Column(DateTime(timezone=True), nullable=False, index=True)
    cost_period_end = Column(DateTime(timezone=True), nullable=False)
    currency = Column(String(3), nullable=False, default="BRL")
    base_cost = Column(Numeric(12,2), default=0, nullable=False)
    usage_cost = Column(Numeric(12,2), default=0, nullable=False)
    total_cost = Column(Numeric(12,2), nullable=False)
    budget_allocated = Column(Numeric(12,2), nullable=True)
    budget_consumed_percentage = Column(Numeric(5,2), nullable=True)
    cost_per_unit = Column(Numeric(10,4), nullable=True)
    units_consumed = Column(Numeric(15,3), default=0, nullable=False)
    unit_type = Column(String(20), nullable=True)  # requests, gb, hours, users
    cost_driver = Column(String(100), nullable=True)
    optimization_opportunities = Column(JSON, nullable=False, default=list)
    cost_allocation = Column(JSON, nullable=False, default=dict)
    billing_account = Column(String(100), nullable=True)
    cost_metadata = Column(JSON, nullable=False, default=dict)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_cost_tracking_resource_period', 'resource_type', 'resource_id', 'cost_period_start'),
        Index('idx_cost_tracking_category_period', 'cost_category', 'cost_period_start'),
    )

# Export all models
__all__ = [
    "Base",
    "User", "Domain", "Entity", "EntityAttribute", "DataContract",
    "ContractTemplate", "ContractVersion", "ContractUsage",
    "Policy", "PolicyExecution", "DataLineage",
    "QualityRule", "QualityExecution", "ComplianceReport",
    "MetricDefinition", "MetricValue", "SystemMonitoring",
    "ExternalIntegration", "IntegrationMapping", "SyncLog",
    "Configuration", "AuditEvent", "NotificationLog", "CostTracking"
]

