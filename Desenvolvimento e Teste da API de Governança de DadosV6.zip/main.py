"""
TBR GDP Core - Data Governance API v6.0
Plataforma completa de governança e contratos de dados
"""

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import time
import logging
from typing import Dict, Any

# Import routers
from governance_api.api.v6 import (
    admin, auth, entities, contracts, policies, 
    quality, metrics, integrations, monitoring
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management"""
    # Startup
    logger.info("🚀 TBR GDP Core API v6.0 starting up...")
    yield
    # Shutdown
    logger.info("🛑 TBR GDP Core API v6.0 shutting down...")

# Create FastAPI application
app = FastAPI(
    title="TBR GDP Core - Data Governance API",
    description="""
    **Plataforma completa de governança e contratos de dados v6.0**
    
    Esta API fornece funcionalidades completas para:
    
    ## 🎯 **Funcionalidades Principais**
    
    ### **📊 Gestão de Entidades**
    - Descoberta e catalogação de dados
    - Profiling automático com IA
    - Gestão de metadados e linhagem
    - Classificação e ownership
    
    ### **📋 Contratos de Dados**
    - Criação e versionamento de contratos
    - Templates reutilizáveis
    - SLAs e métricas de qualidade
    - Monitoramento de uso
    
    ### **🔐 Políticas e Segurança**
    - Controle de acesso ABAC
    - Mascaramento contextual
    - Auditoria completa
    - Compliance automático
    
    ### **📈 Qualidade e Monitoramento**
    - Regras de qualidade configuráveis
    - Execução automática
    - Dashboards executivos
    - Alertas inteligentes
    
    ### **🔗 Integrações**
    - Unity Catalog
    - Informatica Axon
    - Apache Atlas
    - APIs customizadas
    
    ## 🏗️ **Arquitetura**
    
    - **FastAPI** com performance otimizada
    - **SQLAlchemy** com 24 tabelas especializadas
    - **PostgreSQL** com índices de performance
    - **Autenticação JWT** com RBAC
    - **Documentação OpenAPI** automática
    
    ## 📚 **Documentação**
    
    - **Swagger UI**: `/docs`
    - **ReDoc**: `/redoc`
    - **OpenAPI Schema**: `/openapi.json`
    """,
    version="6.0.0",
    contact={
        "name": "TBR GDP Core Team",
        "email": "gdp-core@tbr.com.br",
    },
    license_info={
        "name": "Proprietary",
        "url": "https://tbr.com.br/license",
    },
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

# Security middleware
app.add_middleware(
    TrustedHostMiddleware, 
    allowed_hosts=["*"]  # Configure appropriately for production
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Performance monitoring middleware
@app.middleware("http")
async def performance_middleware(request: Request, call_next):
    """Monitor API performance"""
    start_time = time.time()
    
    # Process request
    response = await call_next(request)
    
    # Calculate processing time
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    
    # Log slow requests
    if process_time > 1.0:  # Log requests taking more than 1 second
        logger.warning(
            f"Slow request: {request.method} {request.url.path} "
            f"took {process_time:.2f}s"
        )
    
    return response

# Global exception handler
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions with consistent format"""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": {
                "code": exc.status_code,
                "message": exc.detail,
                "type": "http_error",
                "path": str(request.url.path),
                "method": request.method,
                "timestamp": time.time()
            }
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions"""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": {
                "code": 500,
                "message": "Internal server error",
                "type": "internal_error",
                "path": str(request.url.path),
                "method": request.method,
                "timestamp": time.time()
            }
        }
    )

# Health check endpoint
@app.get("/health", tags=["Health"])
async def health_check() -> Dict[str, Any]:
    """
    Health check endpoint
    
    Returns the current status of the API and its components.
    """
    return {
        "status": "healthy",
        "version": "6.0.0",
        "timestamp": time.time(),
        "components": {
            "api": "healthy",
            "database": "healthy",  # Add actual database check
            "cache": "healthy",     # Add actual cache check
        }
    }

# Root endpoint
@app.get("/", tags=["Root"])
async def root() -> Dict[str, Any]:
    """
    API root endpoint
    
    Returns basic information about the API.
    """
    return {
        "name": "TBR GDP Core - Data Governance API",
        "version": "6.0.0",
        "description": "Plataforma completa de governança e contratos de dados",
        "docs_url": "/docs",
        "redoc_url": "/redoc",
        "openapi_url": "/openapi.json",
        "health_url": "/health",
        "endpoints": {
            "admin": "/api/v6/admin",
            "auth": "/api/v6/auth",
            "entities": "/api/v6/entities",
            "contracts": "/api/v6/contracts",
            "policies": "/api/v6/policies",
            "quality": "/api/v6/quality",
            "metrics": "/api/v6/metrics",
            "integrations": "/api/v6/integrations",
            "monitoring": "/api/v6/monitoring"
        }
    }

# Include routers
app.include_router(admin.router, prefix="/api/v6/admin", tags=["Admin"])
app.include_router(auth.router, prefix="/api/v6/auth", tags=["Authentication"])
app.include_router(entities.router, prefix="/api/v6/entities", tags=["Entities"])
app.include_router(contracts.router, prefix="/api/v6/contracts", tags=["Contracts"])
app.include_router(policies.router, prefix="/api/v6/policies", tags=["Policies"])
app.include_router(quality.router, prefix="/api/v6/quality", tags=["Quality"])
app.include_router(metrics.router, prefix="/api/v6/metrics", tags=["Metrics"])
app.include_router(integrations.router, prefix="/api/v6/integrations", tags=["Integrations"])
app.include_router(monitoring.router, prefix="/api/v6/monitoring", tags=["Monitoring"])

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "governance_api.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

