"""
COBOL AI Engine v2.1.0 - COBOL Parser
Parser avançado para programas COBOL e copybooks.
"""

import logging
import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass


@dataclass
class CobolProgram:
    """Representa um programa COBOL parseado."""
    name: str
    content: str
    line_count: int
    size: int
    divisions: Dict[str, str]
    sections: List[str]
    variables: List[str]
    files: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'line_count': self.line_count,
            'size': self.size,
            'divisions': self.divisions,
            'sections': self.sections,
            'variables': self.variables,
            'files': self.files
        }


@dataclass
class CobolBook:
    """Representa um copybook COBOL."""
    name: str
    content: str
    line_count: int
    size: int
    structures: List[str]
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'name': self.name,
            'content': self.content,
            'line_count': self.line_count,
            'size': self.size,
            'structures': self.structures
        }


class COBOLParser:
    """
    Parser avançado para programas COBOL e copybooks.
    
    Funcionalidades:
    - Parse de arquivos empilhados (VMEMBER NAME)
    - Extração de programas e copybooks
    - Análise de estrutura COBOL
    - Identificação de divisões e seções
    - Extração de variáveis e arquivos
    """
    
    def __init__(self):
        """Inicializa o parser COBOL."""
        self.logger = logging.getLogger(__name__)
        
        # Padrões regex para parsing
        self.vmember_pattern = re.compile(r'^\s*VMEMBER\s+NAME\s+([A-Z0-9]+)', re.IGNORECASE)
        self.division_pattern = re.compile(r'^\s*([A-Z]+)\s+DIVISION\.', re.IGNORECASE)
        self.section_pattern = re.compile(r'^\s*([A-Z0-9\-]+)\s+SECTION\.', re.IGNORECASE)
        self.variable_pattern = re.compile(r'^\s*\d+\s+([A-Z0-9\-]+)', re.IGNORECASE)
        self.file_pattern = re.compile(r'^\s*SELECT\s+([A-Z0-9\-]+)', re.IGNORECASE)
        
        self.logger.info("COBOL Parser inicializado")
    
    def parse_program(self, content: str, file_path: str = None, copybook_contents: Optional[Dict[str, str]] = None) -> CobolProgram:
        """
        Parse de um programa COBOL individual.
        
        Args:
            content: Conteúdo do programa COBOL
            file_path: Caminho do arquivo (opcional)
            
        Returns:
            CobolProgram: Programa parseado
        """
        # Extrair nome do programa
        program_name = "UNKNOWN"
        if file_path:
            import os
            program_name = os.path.splitext(os.path.basename(file_path))[0]
        
        # Buscar PROGRAM-ID no conteúdo
        program_id_match = re.search(r'PROGRAM-ID\.\s+([A-Z0-9\-]+)', content, re.IGNORECASE)
        if program_id_match:
            program_name = program_id_match.group(1)
        
        # Resolver copybooks antes de parsear o programa
        if copybook_contents:
            resolved_content = self._resolve_copybooks(content, copybook_contents)
        else:
            resolved_content = content

        # Parse do programa
        return self._parse_program(program_name, resolved_content)
    
    def parse_file(self, file_path: str, copybook_dirs: Optional[List[str]] = None) -> Tuple[List[CobolProgram], List[CobolBook]]:
        """
        Parse de arquivo COBOL, incluindo programas e copybooks, e resolve COPY statements.
        
        Args:
            file_path: Caminho para o arquivo.
            copybook_dirs: Lista de diretórios onde procurar copybooks externos.
            
        Returns:
            Tuple[List[CobolProgram], List[CobolBook]]: Programas e copybooks encontrados e processados.
        """
        all_programs: List[CobolProgram] = []
        all_copybooks: List[CobolBook] = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            self.logger.info(f"Iniciando parse do arquivo: {file_path}")
            
            # 1. Coletar todos os membros (programas e copybooks) do arquivo, se for empilhado
            members_content: Dict[str, str] = {}
            if 'VMEMBER NAME' in content.upper():
                members_content = self._split_by_vmember(content)
                self.logger.info(f"Arquivo empilhado detectado. Membros encontrados: {list(members_content.keys())}")
            else:
                import os
                file_name = os.path.splitext(os.path.basename(file_path))[0]
                members_content[file_name] = content
                self.logger.info(f"Arquivo único detectado: {file_name}")

            # 2. Separar programas e copybooks e construir um mapa de copybooks
            temp_programs_raw: Dict[str, str] = {}
            copybook_map: Dict[str, str] = {}
            
            for name, member_content in members_content.items():
                if self._is_program(member_content):
                    temp_programs_raw[name] = member_content
                else:
                    # Considerar todos os outros membros como copybooks
                    book = self._parse_book(name, member_content)
                    all_copybooks.append(book)
                    copybook_map[name.upper()] = book.content # Store content for internal copybooks
            
            # 3. Adicionar copybooks de diretórios externos ao mapa
            if copybook_dirs:
                for c_dir in copybook_dirs:
                    if os.path.isdir(c_dir):
                        for root, _, files in os.walk(c_dir):
                            for f_name in files:
                                if f_name.upper().endswith((".CPY", ".CBL")):
                                    c_name = os.path.splitext(f_name)[0].upper()
                                    # Only add if not already defined by an internal copybook
                                    if c_name not in copybook_map:
                                        try:
                                            with open(os.path.join(root, f_name), 'r', encoding='utf-8', errors='ignore') as cb_f:
                                                copybook_map[c_name] = cb_f.read()
                                            self.logger.debug(f"Copybook externo encontrado e lido: {c_name} em {os.path.join(root, f_name)}")
                                        except Exception as cb_e:
                                            self.logger.error(f"Erro ao ler copybook externo {c_name} em {os.path.join(root, f_name)}: {str(cb_e)}")
                                            copybook_map[c_name] = "" # Store empty content on error
                    else:
                        self.logger.warning(f"Diretório de copybook não encontrado: {c_dir}")
            
            # 4. Processar programas, resolvendo copybooks
            for program_name, program_content_raw in temp_programs_raw.items():
                self.logger.info(f"Processando programa {program_name} para resolução de copybooks.")
                resolved_program_content = self._resolve_copybooks(program_content_raw, copybook_map)
                program = self._parse_program(program_name, resolved_program_content)
                all_programs.append(program)
                self.logger.info(f"Programa {program_name} parseado com copybooks resolvidos.")
                    
        except Exception as e:
            self.logger.error(f"Erro crítico ao parsear arquivo {file_path}: {str(e)}")
            
        return all_programs, all_copybooks
    
    def _split_by_vmember(self, content: str) -> Dict[str, str]:
        """
        Divide o conteúdo por VMEMBER NAME.
        
        Args:
            content: Conteúdo do arquivo
            
        Returns:
            Dict[str, str]: Dicionário com nome do membro e seu conteúdo
        """
        members = {}
        lines = content.split('\n')
        current_member = None
        current_content = []
        
        for line in lines:
            vmember_match = self.vmember_pattern.match(line)
            if vmember_match:
                # Salvar membro anterior se existir
                if current_member and current_content:
                    members[current_member] = '\n'.join(current_content)
                
                # Iniciar novo membro
                current_member = vmember_match.group(1)
                current_content = []
            elif current_member:
                current_content.append(line)
        
        # Salvar último membro
        if current_member and current_content:
            members[current_member] = '\n'.join(current_content)
        
        return members
    
    def _is_program(self, content: str) -> bool:
        """
        Verifica se o conteúdo é um programa COBOL.
        
        Args:
            content: Conteúdo a verificar
            
        Returns:
            bool: True se for programa, False se for copybook
        """
        # Indicadores de programa
        program_indicators = [
            'IDENTIFICATION DIVISION',
            'ID DIVISION',
            'PROGRAM-ID',
            'PROCEDURE DIVISION'
        ]
        
        content_upper = content.upper()
        
        # Verificar se tem pelo menos 2 indicadores de programa
        indicators_found = sum(1 for indicator in program_indicators if indicator in content_upper)
        
        return indicators_found >= 2
    
    def _parse_program(self, name: str, content: str) -> CobolProgram:
        """
        Parse de um programa COBOL.
        
        Args:
            name: Nome do programa
            content: Conteúdo do programa
            
        Returns:
            CobolProgram: Programa parseado
        """
        return CobolProgram(
            name=name,
            content=content,
            line_count=len(content.split('\n')),
            size=len(content),
            divisions=self._extract_divisions(content),
            sections=self._extract_sections(content),
            variables=self._extract_variables(content),
            files=self._extract_files(content)
        )
    
    def _parse_book(self, name: str, content: str) -> CobolBook:
        """
        Parse de um copybook COBOL.
        
        Args:
            name: Nome do copybook
            content: Conteúdo do copybook
            
        Returns:
            CobolBook: Copybook parseado
        """
        return CobolBook(
            name=name,
            content=content,
            line_count=len(content.split('\n')),
            size=len(content),
            structures=self._extract_data_structures(content)
        )
    
    def _extract_divisions(self, content: str) -> Dict[str, str]:
        """Extrai as divisões do programa COBOL."""
        divisions = {}
        lines = content.split('\n')
        current_division = None
        current_content = []
        
        for line in lines:
            division_match = self.division_pattern.match(line)
            if division_match:
                # Salvar divisão anterior
                if current_division and current_content:
                    divisions[current_division] = '\n'.join(current_content)
                
                # Nova divisão
                current_division = division_match.group(1).upper()
                current_content = [line]
            elif current_division:
                current_content.append(line)
        
        # Salvar última divisão
        if current_division and current_content:
            divisions[current_division] = '\n'.join(current_content)
        
        return divisions
    
    def _extract_sections(self, content: str) -> List[str]:
        """Extrai as seções do programa COBOL."""
        sections = []
        lines = content.split('\n')
        
        for line in lines:
            section_match = self.section_pattern.match(line)
            if section_match:
                sections.append(section_match.group(1))
        
        return sections
    
    def _extract_variables(self, content: str) -> List[str]:
        """Extrai as variáveis do programa COBOL."""
        variables = []
        lines = content.split('\n')
        
        for line in lines:
            variable_match = self.variable_pattern.match(line)
            if variable_match:
                variables.append(variable_match.group(1))
        
        return variables
    
    def _extract_files(self, content: str) -> List[str]:
        """Extrai os arquivos do programa COBOL."""
        files = []
        lines = content.split('\n')
        
        for line in lines:
            file_match = self.file_pattern.match(line)
            if file_match:
                files.append(file_match.group(1))
        
        return files
    
    def _resolve_copybooks(self, program_content: str, copybook_contents: Dict[str, str], processed_copybooks: Optional[List[str]] = None) -> str:
        """
        Resolve COPY statements in COBOL program content by inlining copybook content.
        
        Args:
            program_content: The COBOL program content.
            copybook_paths: A dictionary mapping copybook names to their file paths.
            processed_copybooks: A list to keep track of already processed copybooks to prevent infinite recursion.
            
        Returns:
            str: The COBOL program content with copybooks inlined.
        """
        if processed_copybooks is None:
            processed_copybooks = []

        resolved_content = []
        lines = program_content.split('\n')
        copy_pattern = re.compile(r'^.{6}(?:COPY|CBL)\s+([A-Z0-9\-]+)\s*(?:OF\s+([A-Z0-9\-]+))?\s*\.', re.IGNORECASE)

        for line in lines:
            match = copy_pattern.match(line)
            if match:
                copybook_name = match.group(1).upper()
                # Check for OF clause, though not strictly needed for simple inlining
                # of_clause = match.group(2)

                if copybook_name in processed_copybooks:
                    self.logger.warning(f"Detecção de recursão ou duplicação: Copybook {copybook_name} já processado. Pulando.")
                    resolved_content.append(f"* WARNING: COPYBOOK {copybook_name} ALREADY PROCESSED OR RECURSIVE CALL SKIPPED.")
                    continue

                if copybook_name in copybook_contents:
                    copybook_content = copybook_contents[copybook_name]
                    self.logger.info(f"Inlining copybook: {copybook_name}")
                    processed_copybooks.append(copybook_name)
                    # Recursively resolve copybooks within the inlined copybook content
                    resolved_copybook_content = self._resolve_copybooks(copybook_content, copybook_contents, processed_copybooks)
                    resolved_content.append(f"* START COPYBOOK: {copybook_name}")
                    resolved_content.append(resolved_copybook_content)
                    resolved_content.append(f"* END COPYBOOK: {copybook_name}")
                else:
                    self.logger.warning(f"Copybook {copybook_name} não encontrado nos conteúdos fornecidos. Linha: {line.strip()}")
                    resolved_content.append(line) # Keep the original line if copybook not found
            else:
                resolved_content.append(line)
        
        return '\n'.join(resolved_content)

    def _extract_data_structures(self, content: str) -> List[str]:
        """Extrai estruturas de dados do copybook."""
        structures = []
        lines = content.split('\n')
        
        # Padrão para estruturas de dados (01 level)
        structure_pattern = re.compile(r'^\s*01\s+([A-Z0-9\-]+)', re.IGNORECASE)
        
        for line in lines:
            structure_match = structure_pattern.match(line)
            if structure_match:
                structures.append(structure_match.group(1))
        
        return structures
    
    def get_parser_statistics(self) -> Dict[str, Any]:
        """
        Retorna estatísticas do parser.
        
        Returns:
            Dict[str, Any]: Estatísticas do parser
        """
        return {
            'parser_version': '2.1.0',
            'supported_formats': ['COBOL', 'Copybook', 'VMEMBER'],
            'features': [
                'Program parsing',
                'Copybook parsing',
                'Division extraction',
                'Section extraction',
                'Variable extraction',
                'File extraction'
            ]
        }
