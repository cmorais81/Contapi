#!/usr/bin/env python3
"""
Instalador Simples e Robusto do COBOL Analyzer
Garante que o comando cobol-to-docs --init funcione
"""

import os
import sys
import shutil
import subprocess
from pathlib import Path

def print_status(msg):
    print(f"[INFO] {msg}")

def print_error(msg):
    print(f"[ERRO] {msg}")

def print_success(msg):
    print(f"[OK] {msg}")

def desinstalar_anterior():
    """Remove instalação anterior"""
    try:
        result = subprocess.run([sys.executable, '-m', 'pip', 'uninstall', 'cobol-to-docs', '-y'], 
                              capture_output=True, text=True)
        print_status("Instalação anterior removida")
    except:
        pass

def instalar_pacote():
    """Instala o pacote usando setup.py"""
    try:
        result = subprocess.run([sys.executable, 'setup.py', 'install'], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print_success("Pacote instalado com sucesso")
            return True
        else:
            print_error(f"Falha na instalação: {result.stderr}")
            return False
    except Exception as e:
        print_error(f"Erro na instalação: {e}")
        return False

def criar_entry_point_robusto():
    """Cria entry point que funciona garantidamente"""
    
    # Localizar onde o Python instala scripts
    script_dirs = [
        '/usr/local/bin',
        '/usr/bin',
        os.path.expanduser('~/.local/bin'),
        os.path.join(sys.prefix, 'bin'),
        os.path.join(sys.prefix, 'Scripts')  # Windows
    ]
    
    # Encontrar diretório válido
    target_dir = None
    for dir_path in script_dirs:
        if os.path.exists(dir_path) and os.access(dir_path, os.W_OK):
            target_dir = dir_path
            break
    
    if not target_dir:
        print_error("Não foi possível encontrar diretório para instalar o comando")
        return False
    
    # Criar script robusto
    script_content = f'''#!/usr/bin/env python3
"""
COBOL to Docs - Entry Point Robusto
Funciona tanto localmente quanto após instalação
"""

import sys
import os
import subprocess
from pathlib import Path

def main():
    # Locais possíveis para main_enhanced.py
    current_dir = os.path.dirname(os.path.abspath(__file__))
    
    locations = [
        # Instalação via pip
        "/usr/local/lib/python3.11/dist-packages/main_enhanced.py",
        "/usr/local/lib/python3.8/dist-packages/main_enhanced.py", 
        "/usr/local/lib/python3.9/dist-packages/main_enhanced.py",
        "/usr/local/lib/python3.10/dist-packages/main_enhanced.py",
        
        # Desenvolvimento local
        os.path.join(current_dir, "main_enhanced.py"),
        "./main_enhanced.py",
        "../main_enhanced.py",
        
        # Diretório do projeto
        "/home/ubuntu/cobol_analyzer_funcional/main_enhanced.py",
        "{os.getcwd()}/main_enhanced.py"
    ]
    
    # Se é comando --init, processar especialmente
    if '--init' in sys.argv:
        for location in locations:
            if os.path.exists(location):
                # Substituir --init por --init-local
                args = []
                for arg in sys.argv[1:]:
                    if arg == '--init':
                        args.append('--init-local')
                    else:
                        args.append(arg)
                
                cmd = [sys.executable, location] + args
                result = subprocess.run(cmd)
                sys.exit(result.returncode)
        
        # Se não encontrou, tentar instalação direta
        print("Tentando instalação direta...")
        try:
            from src.core.local_setup import auto_setup_environment
            auto_setup_environment()
            sys.exit(0)
        except:
            pass
        
        print("Erro: main_enhanced.py não encontrado")
        print("Tente: python main_enhanced.py --init-local")
        sys.exit(1)
    
    # Para outros comandos, tentar main.py
    for location in locations:
        location_main = location.replace('main_enhanced.py', 'main.py')
        if os.path.exists(location_main):
            cmd = [sys.executable, location_main] + sys.argv[1:]
            result = subprocess.run(cmd)
            sys.exit(result.returncode)
    
    print("Erro: Arquivos principais não encontrados")
    sys.exit(1)

if __name__ == "__main__":
    main()
'''
    
    # Escrever script
    script_path = os.path.join(target_dir, 'cobol-to-docs')
    try:
        with open(script_path, 'w') as f:
            f.write(script_content)
        
        # Tornar executável
        os.chmod(script_path, 0o755)
        
        print_success(f"Entry point criado: {script_path}")
        return True
        
    except Exception as e:
        print_error(f"Erro ao criar entry point: {e}")
        return False

def testar_instalacao():
    """Testa se a instalação funcionou"""
    
    print_status("Testando instalação...")
    
    # Testar comando
    try:
        result = subprocess.run(['which', 'cobol-to-docs'], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print_success(f"Comando encontrado: {result.stdout.strip()}")
        else:
            print_error("Comando cobol-to-docs não encontrado no PATH")
            return False
    except:
        print_error("Erro ao verificar comando")
        return False
    
    # Testar --init em diretório temporário
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        os.chdir(temp_dir)
        
        try:
            result = subprocess.run(['cobol-to-docs', '--init'], 
                                  capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                # Verificar se criou estrutura
                if (os.path.exists('config') and os.path.exists('data') and 
                    os.path.exists('logs') and os.path.exists('examples')):
                    print_success("Comando --init funcionando corretamente!")
                    return True
                else:
                    print_error("Comando executou mas não criou estrutura esperada")
                    return False
            else:
                print_error(f"Comando --init falhou: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            print_error("Comando --init demorou muito para executar")
            return False
        except Exception as e:
            print_error(f"Erro ao testar --init: {e}")
            return False

def main():
    print("=" * 60)
    print("COBOL ANALYZER - INSTALAÇÃO SIMPLES E ROBUSTA")
    print("=" * 60)
    
    # Verificar se estamos no diretório correto
    if not os.path.exists('setup.py'):
        print_error("Execute este script no diretório do projeto (onde está setup.py)")
        sys.exit(1)
    
    # Passo 1: Desinstalar anterior
    print_status("Removendo instalação anterior...")
    desinstalar_anterior()
    
    # Passo 2: Instalar pacote
    print_status("Instalando pacote...")
    if not instalar_pacote():
        print_error("Falha na instalação do pacote")
        sys.exit(1)
    
    # Passo 3: Criar entry point robusto
    print_status("Criando entry point robusto...")
    if not criar_entry_point_robusto():
        print_error("Falha ao criar entry point")
        sys.exit(1)
    
    # Passo 4: Testar instalação
    if testar_instalacao():
        print("=" * 60)
        print_success("INSTALAÇÃO CONCLUÍDA COM SUCESSO!")
        print("=" * 60)
        print()
        print("Como usar:")
        print("  cobol-to-docs --init                    # Inicializar ambiente")
        print("  cobol-to-docs --fontes programas.txt    # Analisar programas")
        print("  cobol-to-docs --status                  # Verificar status")
        print()
    else:
        print("=" * 60)
        print_error("INSTALAÇÃO COM PROBLEMAS")
        print("=" * 60)
        print()
        print("Tente usar diretamente:")
        print("  python main_enhanced.py --init-local")
        print("  python main_enhanced.py --fontes programas.txt")
        
if __name__ == "__main__":
    main()
