#!/usr/bin/env python3
"""
Exemplo Rápido - API COBOL Analyzer
Após instalação via: pip install cobol-to-docs
"""

def exemplo_rapido():
    print(" Exemplo Rápido da API COBOL Analyzer")
    print("=" * 50)
    
    try:
        # Importar API
        import cobol_to_docs
        print(" API importada")
        
        # Inicializar
        cobol_to_docs.init()
        print(" Ambiente inicializado")
        
        # Programa exemplo
        programa = """
        IDENTIFICATION DIVISION.
        PROGRAM-ID. EXEMPLO-RAPIDO.
        PROCEDURE DIVISION.
            DISPLAY 'API FUNCIONANDO'.
            STOP RUN.
        """
        
        # Analisar
        resultado = cobol_to_docs.analyze_program(programa, "EXEMPLO.CBL")
        print(f" Análise: {resultado.success}")
        print(f" Documentação: {len(resultado.documentation)} caracteres")
        
        return True
        
    except Exception as e:
        print(f" Erro: {e}")
        return False

if __name__ == "__main__":
    exemplo_rapido()
