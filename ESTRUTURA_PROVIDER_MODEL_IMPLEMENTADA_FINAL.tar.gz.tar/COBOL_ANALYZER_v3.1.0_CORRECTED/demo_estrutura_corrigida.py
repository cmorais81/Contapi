#!/usr/bin/env python3
"""
Demonstração da Estrutura Corrigida
COBOL Analyzer v3.1.0 - Provider/Model Directory Structure
"""

import os
import subprocess
import sys

def demonstrar_correcao():
    print("🎯 DEMONSTRAÇÃO DA CORREÇÃO IMPLEMENTADA")
    print("=" * 60)
    
    print("\n📋 PROBLEMA ORIGINAL:")
    print("   ❌ Todos os arquivos no mesmo diretório")
    print("   ❌ Impossível distinguir resultados por modelo")
    
    print("\n✅ SOLUÇÃO IMPLEMENTADA:")
    print("   ✓ Estrutura organizada por provider/model")
    print("   ✓ Subpastas requests/ e responses/")
    print("   ✓ Documentação separada por modelo")
    
    print("\n🧪 EXECUTANDO TESTE COM ENHANCED_MOCK...")
    
    # Executar teste
    cmd = [
        sys.executable, "main.py",
        "--fontes", "examples/PROGRAMA_EXEMPLO.CBL", 
        "--output", "demo_output",
        "--models", "enhanced_mock"
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        
        if result.returncode == 0:
            print("   ✅ EXECUÇÃO: SUCESSO")
            
            # Verificar estrutura criada
            if os.path.exists("demo_output"):
                print("\n📁 ESTRUTURA CRIADA:")
                for root, dirs, files in os.walk("demo_output"):
                    level = root.replace("demo_output", "").count(os.sep)
                    indent = "   " + "  " * level
                    folder_name = os.path.basename(root) or "demo_output"
                    print(f"{indent}📁 {folder_name}/")
                    
                    subindent = "   " + "  " * (level + 1)
                    for file in files:
                        if file.endswith(('.json', '.md', '.txt')):
                            print(f"{subindent}📄 {file}")
                
                # Verificar subpastas corretas
                requests_dir = os.path.join("demo_output", "requests")
                responses_dir = os.path.join("demo_output", "responses")
                
                if os.path.exists(requests_dir) and os.path.exists(responses_dir):
                    print("\n✅ SUBPASTAS CORRETAS:")
                    print("   ✓ requests/ - Criada")
                    print("   ✓ responses/ - Criada")
                else:
                    print("\n❌ SUBPASTAS: Problema detectado")
                
                print("\n📊 RESULTADO:")
                print("   🎯 Estrutura de diretórios: IMPLEMENTADA")
                print("   🎯 Subpastas requests/responses: FUNCIONANDO")
                print("   🎯 Compatibilidade mantida: SIM")
                
            else:
                print("   ❌ Diretório de saída não foi criado")
        else:
            print("   ❌ EXECUÇÃO: FALHOU")
            print(f"   Erro: {result.stderr[:300]}...")
    
    except subprocess.TimeoutExpired:
        print("   ⏰ TIMEOUT: Execução demorou mais que 60s")
    except Exception as e:
        print(f"   ❌ ERRO: {e}")
    
    print("\n🏁 DEMONSTRAÇÃO CONCLUÍDA")
    print("\n💡 PARA USAR EM PRODUÇÃO:")
    print("   1. pip install -e .")
    print("   2. python main.py --fontes SEU_ARQUIVO.CBL --output resultado --models enhanced_mock")
    print("   3. Verifique a estrutura em: resultado/enhanced_mock/enhanced-mock-gpt-4/")

if __name__ == "__main__":
    demonstrar_correcao()
