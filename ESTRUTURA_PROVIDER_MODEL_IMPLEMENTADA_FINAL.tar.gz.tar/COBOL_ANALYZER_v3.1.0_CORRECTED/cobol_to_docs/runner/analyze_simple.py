#!/usr/bin/env python3
"""
Script simples para análise COBOL que funciona com encoding e config corretos
"""

import sys
import os
import argparse
import logging

# Configurar paths
script_dir = os.path.dirname(os.path.abspath(__file__))
cobol_to_docs_dir = os.path.dirname(script_dir)
src_dir = os.path.join(cobol_to_docs_dir, 'src')
sys.path.insert(0, src_dir)

def analyze_cobol(fonte_file, model="enhanced_mock"):
    """Análise simples de arquivo COBOL"""
    print(f"=== ANÁLISE COBOL - {fonte_file} ===")
    
    try:
        # Importar módulos necessários
        from core.config import ConfigManager
        from parsers.cobol_parser_original import COBOLParser
        
        # Verificar se arquivo existe
        if not os.path.exists(fonte_file):
            print(f"✗ Arquivo não encontrado: {fonte_file}")
            return False
        
        # Inicializar configuração
        config_path = "config/config.yaml"
        if os.path.exists(config_path):
            config_manager = ConfigManager(config_path)
            print(f"✓ Configuração carregada: {config_path}")
        else:
            config_manager = ConfigManager()
            print("⚠ Usando configuração padrão")
        
        # Inicializar parser
        parser = COBOLParser()
        print("✓ Parser COBOL inicializado")
        
        # Parsear arquivo
        print(f"📄 Parseando arquivo: {fonte_file}")
        programs, books = parser.parse_file(fonte_file)
        
        print(f"✓ Análise concluída!")
        print(f"  - Programas encontrados: {len(programs)}")
        print(f"  - Copybooks encontrados: {len(books)}")
        
        # Mostrar detalhes dos programas
        for i, program in enumerate(programs, 1):
            print(f"\n--- Programa {i}: {program.name} ---")
            print(f"  Linhas: {program.line_count}")
            print(f"  Tamanho: {program.size} bytes")
            print(f"  Divisões: {len(program.divisions)}")
            print(f"  Seções: {len(program.sections)}")
            print(f"  Variáveis: {len(program.variables)}")
            print(f"  Arquivos: {len(program.files)}")
        
        # Mostrar detalhes dos copybooks
        for i, book in enumerate(books, 1):
            print(f"\n--- Copybook {i}: {book.name} ---")
            print(f"  Linhas: {book.line_count}")
            print(f"  Tamanho: {book.size} bytes")
            print(f"  Estruturas: {len(book.structures)}")
        
        return True
        
    except Exception as e:
        print(f"✗ Erro durante análise: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    parser = argparse.ArgumentParser(description="Análise simples de COBOL")
    parser.add_argument("--fontes", required=True, help="Arquivo COBOL para analisar")
    parser.add_argument("--models", default="enhanced_mock", help="Modelo a usar (padrão: enhanced_mock)")
    
    args = parser.parse_args()
    
    # Configurar logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    success = analyze_cobol(args.fontes, args.models)
    
    if success:
        print("\n🎉 Análise concluída com sucesso!")
    else:
        print("\n❌ Análise falhou!")
        sys.exit(1)

if __name__ == "__main__":
    main()
