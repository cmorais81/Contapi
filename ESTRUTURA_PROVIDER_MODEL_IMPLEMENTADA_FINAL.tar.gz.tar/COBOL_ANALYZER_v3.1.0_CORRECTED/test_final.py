#!/usr/bin/env python3
import sys
import os

# Adicionar src ao path
src_dir = os.path.join(os.path.dirname(__file__), 'cobol_to_docs', 'src')
sys.path.insert(0, src_dir)

# Imports básicos
from core.config import ConfigManager
from core.main_processor import MainProcessor

def main():
    print("Testando correção final - diretórios por modelo...")
    
    # Configuração
    config_path = "/home/ubuntu/validation_complete/test_project/config/config_enhanced.yaml"
    config_manager = ConfigManager(config_path)
    
    # Processador
    processor = MainProcessor(config_manager, "test_output_final")
    
    # Processar com múltiplos modelos
    success = processor.process_programs(
        fontes_file="/home/ubuntu/validation_complete/test_project/examples/PROGRAMA_EXEMPLO.CBL",
        models=["enhanced_mock", "basic"]
    )
    
    if success:
        print("Processamento concluído com sucesso!")
        print("Verificando estrutura de diretórios...")
        
        # Listar estrutura criada
        import subprocess
        result = subprocess.run(['find', 'test_output_final', '-type', 'd'], 
                              capture_output=True, text=True)
        print("Diretórios criados:")
        print(result.stdout)
        
        # Listar arquivos criados
        result = subprocess.run(['find', 'test_output_final', '-name', '*.md'], 
                              capture_output=True, text=True)
        print("Arquivos de documentação:")
        print(result.stdout)
        
        result = subprocess.run(['find', 'test_output_final', '-name', '*.json'], 
                              capture_output=True, text=True)
        print("Arquivos JSON:")
        print(result.stdout)
    else:
        print("Erro no processamento")

if __name__ == "__main__":
    main()
