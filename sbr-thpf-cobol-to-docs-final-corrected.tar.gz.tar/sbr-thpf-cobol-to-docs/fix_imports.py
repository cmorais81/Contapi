
import os
import re

def fix_imports(base_path):
    for root, _, files in os.walk(base_path):
        for file in files:
            if file.endswith(".py"):
                filepath = os.path.join(root, file)
                with open(filepath, "r", encoding="utf-8") as f:
                    content = f.read()
                
                # Correção para imports que começam com 'src' ou 'runner' e não são relativos
                # e que estão dentro do pacote cobol_to_docs
                new_content = re.sub(r"^(from\s+)(src\..*|runner\..*)", r"\1cobol_to_docs.\2", content, flags=re.MULTILINE)
                new_content = re.sub(r"^(import\s+)(src\..*|runner\..*)", r"\1cobol_to_docs.\2", new_content, flags=re.MULTILINE)

                # Correção para imports que são 'from .src' ou 'from .runner' para 'from cobol_to_docs.src' ou 'from cobol_to_docs.runner'
                new_content = re.sub(r"^(from\s+)(\.)(src\..*|runner\..*)", r"\1cobol_to_docs.\3", new_content, flags=re.MULTILINE)
                new_content = re.sub(r"^(import\s+)(\.)(src\..*|runner\..*)", r"\1cobol_to_docs.\3", new_content, flags=re.MULTILINE)

                if content != new_content:
                    print(f"Corrigindo imports em: {filepath}")
                    with open(filepath, "w", encoding="utf-8") as f:
                        f.write(new_content)

def create_init_files(base_path):
    for root, dirs, _ in os.walk(base_path):
        for dir_name in dirs:
            init_file = os.path.join(root, dir_name, "__init__.py")
            if not os.path.exists(init_file):
                print(f"Criando __init__.py em: {init_file}")
                with open(init_file, "w") as f:
                    pass # Cria um arquivo vazio

    # Garantir que o diretório raiz do pacote também tenha um __init__.py
    package_root_init = os.path.join(base_path, "__init__.py")
    if not os.path.exists(package_root_init):
        print(f"Criando __init__.py em: {package_root_init}")
        with open(package_root_init, "w") as f:
            pass

    # Garantir que o diretório runner tenha um __init__.py
    runner_init = os.path.join(base_path, "runner", "__init__.py")
    if not os.path.exists(runner_init):
        print(f"Criando __init__.py em: {runner_init}")
        with open(runner_init, "w") as f:
            pass

    # Garantir que o diretório src tenha um __init__.py
    src_init = os.path.join(base_path, "src", "__init__.py")
    if not os.path.exists(src_init):
        print(f"Criando __init__.py em: {src_init}")
        with open(src_init, "w") as f:
            pass

if __name__ == "__main__":
    project_root = "sbr-thpf-cobol-to-docs/cobol_to_docs"
    fix_imports(project_root)
    create_init_files(project_root)

