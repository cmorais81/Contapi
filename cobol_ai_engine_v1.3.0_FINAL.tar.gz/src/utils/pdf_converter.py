"""
COBOL AI Engine v2.5.0 - Conversor Markdown para PDF
Utilitário para converter documentação Markdown em PDF.
"""

import os
import logging
import subprocess
from typing import Optional, Dict, Any
from pathlib import Path


class MarkdownToPDFConverter:
    """Conversor de Markdown para PDF usando múltiplas estratégias."""
    
    def __init__(self):
        """Inicializa o conversor."""
        self.logger = logging.getLogger(__name__)
        self.available_methods = self._check_available_methods()
        
    def _check_available_methods(self) -> Dict[str, bool]:
        """Verifica quais métodos de conversão estão disponíveis."""
        methods = {
            'manus_utility': False,
            'weasyprint': False,
            'markdown_pdf': False,
            'pandoc': False
        }
        
        # Verificar utilitário manus-md-to-pdf
        try:
            result = subprocess.run(['which', 'manus-md-to-pdf'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                methods['manus_utility'] = True
                self.logger.info("Utilitário manus-md-to-pdf disponível")
        except Exception:
            pass
        
        # Verificar WeasyPrint
        try:
            import weasyprint
            methods['weasyprint'] = True
            self.logger.info("WeasyPrint disponível")
        except ImportError:
            pass
        
        # Verificar markdown-pdf (via npm)
        try:
            result = subprocess.run(['which', 'markdown-pdf'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                methods['markdown_pdf'] = True
                self.logger.info("markdown-pdf disponível")
        except Exception:
            pass
        
        # Verificar Pandoc
        try:
            result = subprocess.run(['which', 'pandoc'], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                methods['pandoc'] = True
                self.logger.info("Pandoc disponível")
        except Exception:
            pass
        
        return methods
    
    def convert(self, markdown_file: str, pdf_file: str, 
                method: Optional[str] = None) -> bool:
        """
        Converte arquivo Markdown para PDF.
        
        Args:
            markdown_file: Caminho do arquivo Markdown
            pdf_file: Caminho do arquivo PDF de saída
            method: Método específico a usar (opcional)
            
        Returns:
            True se conversão foi bem-sucedida, False caso contrário
        """
        if not os.path.exists(markdown_file):
            self.logger.error(f"Arquivo Markdown não encontrado: {markdown_file}")
            return False
        
        # Criar diretório de saída se não existir
        os.makedirs(os.path.dirname(pdf_file), exist_ok=True)
        
        # Determinar método a usar
        if method and method in self.available_methods and self.available_methods[method]:
            methods_to_try = [method]
        else:
            # Tentar métodos em ordem de preferência
            methods_to_try = [
                'manus_utility',
                'weasyprint', 
                'pandoc',
                'markdown_pdf'
            ]
            methods_to_try = [m for m in methods_to_try if self.available_methods.get(m, False)]
        
        if not methods_to_try:
            self.logger.error("Nenhum método de conversão PDF disponível")
            return False
        
        # Tentar cada método
        for method_name in methods_to_try:
            try:
                self.logger.info(f"Tentando conversão com método: {method_name}")
                
                if method_name == 'manus_utility':
                    success = self._convert_with_manus_utility(markdown_file, pdf_file)
                elif method_name == 'weasyprint':
                    success = self._convert_with_weasyprint(markdown_file, pdf_file)
                elif method_name == 'pandoc':
                    success = self._convert_with_pandoc(markdown_file, pdf_file)
                elif method_name == 'markdown_pdf':
                    success = self._convert_with_markdown_pdf(markdown_file, pdf_file)
                else:
                    continue
                
                if success:
                    self.logger.info(f"Conversão bem-sucedida com {method_name}: {pdf_file}")
                    return True
                    
            except Exception as e:
                self.logger.warning(f"Erro com método {method_name}: {str(e)}")
                continue
        
        self.logger.error("Todos os métodos de conversão falharam")
        return False
    
    def _convert_with_manus_utility(self, markdown_file: str, pdf_file: str) -> bool:
        """Converte usando o utilitário manus-md-to-pdf."""
        try:
            result = subprocess.run([
                'manus-md-to-pdf', 
                markdown_file, 
                pdf_file
            ], capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                return os.path.exists(pdf_file)
            else:
                self.logger.warning(f"manus-md-to-pdf falhou: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            self.logger.warning("manus-md-to-pdf timeout")
            return False
        except Exception as e:
            self.logger.warning(f"Erro no manus-md-to-pdf: {str(e)}")
            return False
    
    def _convert_with_weasyprint(self, markdown_file: str, pdf_file: str) -> bool:
        """Converte usando WeasyPrint."""
        try:
            import weasyprint
            import markdown
            
            # Ler arquivo Markdown
            with open(markdown_file, 'r', encoding='utf-8') as f:
                markdown_content = f.read()
            
            # Converter Markdown para HTML
            html_content = markdown.markdown(markdown_content, extensions=['tables', 'codehilite'])
            
            # Adicionar CSS básico
            html_with_css = f"""
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <style>
                    body {{ font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }}
                    h1, h2, h3 {{ color: #333; }}
                    code {{ background-color: #f4f4f4; padding: 2px 4px; border-radius: 3px; }}
                    pre {{ background-color: #f4f4f4; padding: 10px; border-radius: 5px; overflow-x: auto; }}
                    table {{ border-collapse: collapse; width: 100%; }}
                    th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                    th {{ background-color: #f2f2f2; }}
                </style>
            </head>
            <body>
                {html_content}
            </body>
            </html>
            """
            
            # Converter HTML para PDF
            weasyprint.HTML(string=html_with_css).write_pdf(pdf_file)
            return os.path.exists(pdf_file)
            
        except Exception as e:
            self.logger.warning(f"Erro no WeasyPrint: {str(e)}")
            return False
    
    def _convert_with_pandoc(self, markdown_file: str, pdf_file: str) -> bool:
        """Converte usando Pandoc."""
        try:
            result = subprocess.run([
                'pandoc',
                markdown_file,
                '-o', pdf_file,
                '--pdf-engine=wkhtmltopdf',
                '--variable', 'geometry:margin=1in'
            ], capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                return os.path.exists(pdf_file)
            else:
                # Tentar sem wkhtmltopdf
                result = subprocess.run([
                    'pandoc',
                    markdown_file,
                    '-o', pdf_file
                ], capture_output=True, text=True, timeout=60)
                
                return result.returncode == 0 and os.path.exists(pdf_file)
                
        except subprocess.TimeoutExpired:
            self.logger.warning("Pandoc timeout")
            return False
        except Exception as e:
            self.logger.warning(f"Erro no Pandoc: {str(e)}")
            return False
    
    def _convert_with_markdown_pdf(self, markdown_file: str, pdf_file: str) -> bool:
        """Converte usando markdown-pdf (Node.js)."""
        try:
            result = subprocess.run([
                'markdown-pdf',
                markdown_file,
                '-o', pdf_file
            ], capture_output=True, text=True, timeout=60)
            
            if result.returncode == 0:
                return os.path.exists(pdf_file)
            else:
                self.logger.warning(f"markdown-pdf falhou: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            self.logger.warning("markdown-pdf timeout")
            return False
        except Exception as e:
            self.logger.warning(f"Erro no markdown-pdf: {str(e)}")
            return False
    
    def convert_directory(self, input_dir: str, output_dir: str, 
                         pattern: str = "*.md", show_progress: bool = True) -> Dict[str, bool]:
        """
        Converte todos os arquivos Markdown de um diretório.
        
        Args:
            input_dir: Diretório com arquivos Markdown
            output_dir: Diretório de saída para PDFs
            pattern: Padrão de arquivos a converter
            show_progress: Mostrar progresso da conversão
            
        Returns:
            Dicionário com resultado da conversão de cada arquivo
        """
        results = {}
        
        input_path = Path(input_dir)
        output_path = Path(output_dir)
        
        if not input_path.exists():
            self.logger.error(f"Diretório de entrada não existe: {input_dir}")
            return results
        
        # Criar diretório de saída
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Encontrar arquivos Markdown
        markdown_files = list(input_path.glob(pattern))
        
        if not markdown_files:
            self.logger.warning(f"Nenhum arquivo encontrado com padrão {pattern} em {input_dir}")
            return results
        
        total_files = len(markdown_files)
        if show_progress:
            print(f"Convertendo {total_files} arquivos para PDF...")
        
        # Converter cada arquivo
        for i, md_file in enumerate(markdown_files, 1):
            pdf_file = output_path / f"{md_file.stem}.pdf"
            
            if show_progress:
                print(f"[{i}/{total_files}] Convertendo: {md_file.name}")
            
            self.logger.info(f"Convertendo: {md_file.name} -> {pdf_file.name}")
            success = self.convert(str(md_file), str(pdf_file))
            results[str(md_file)] = success
            
            if show_progress:
                status = "✅" if success else "❌"
                print(f"[{i}/{total_files}] {status} {md_file.name}")
        
        successful = sum(1 for success in results.values() if success)
        if show_progress:
            print(f"\nConversão concluída: {successful}/{total_files} arquivos convertidos com sucesso")
        
        return results
    
    def get_available_methods(self) -> Dict[str, bool]:
        """Retorna métodos de conversão disponíveis."""
        return self.available_methods.copy()
    
    def get_status(self) -> Dict[str, Any]:
        """Retorna status do conversor."""
        return {
            'available_methods': self.available_methods,
            'preferred_method': self._get_preferred_method(),
            'total_methods': len([m for m in self.available_methods.values() if m])
        }
    
    def _get_preferred_method(self) -> Optional[str]:
        """Retorna o método preferido disponível."""
        preference_order = ['manus_utility', 'weasyprint', 'pandoc', 'markdown_pdf']
        
        for method in preference_order:
            if self.available_methods.get(method, False):
                return method
        
        return None

