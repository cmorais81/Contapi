#!/usr/bin/env python3
"""
Processo de Análise Avançada com Relatório Consolidado
Integra extração detalhada de regras com geração de relatório HTML profissional
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import List, Dict, Any, Optional
from pathlib import Path

# Adicionar src ao path
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.analyzers.business_rules_extractor import BusinessRulesExtractor
from src.generators.advanced_report_generator import AdvancedReportGeneratorFacade as AdvancedReportGeneratorFacade
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.providers.base_provider import AIRequest
from src.core.intelligent_model_selector import IntelligentModelSelector
from src.rag.rag_integration import RAGIntegration
from src.utils.cost_calculator import CostCalculator
from src.parsers.cobol_parser_original import COBOLParser

def process_advanced_analysis(programs: List[Any], 
                            models: List[str], 
                            output_dir: str,
                            config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Processa análise avançada com extração detalhada de regras e relatório consolidado
    """
    
    logger = logging.getLogger(__name__)
    logger.info("Iniciando análise avançada com relatório consolidado")
    
    # Inicializar componentes
    rules_extractor = BusinessRulesExtractor()
    report_generator = AdvancedReportGeneratorFacade(output_dir)
    provider_manager = EnhancedProviderManager(config)
    model_selector = IntelligentModelSelector()
    rag_integration = RAGIntegration(config.get('rag', {}))
    cost_calculator = CostCalculator()
    
    # Resultados consolidados
    consolidated_results = {
        'programs': [],
        'analysis_results': [],
        'detailed_analysis': {},
        'rag_stats': {},
        'performance_metrics': {}
    }
    
    start_time = datetime.now()
    
    try:
        # Processar cada programa
        for program in programs:
            logger.info(f"Processando programa: {program.name}")
            
            # 1. Extração detalhada de regras de negócio
            logger.info("Extraindo regras de negócio detalhadas...")
            extracted_rules = rules_extractor.extract_all_rules(program.content, program.name)
            
            # 2. Análise com múltiplos modelos LLM
            program_analysis = {}
            
            for model in models:
                logger.info(f"Analisando com modelo: {model}")
                
                # Preparar prompt enriquecido com regras extraídas
                enriched_prompt = _create_enriched_prompt(program, extracted_rules)
                
                # Aplicar RAG
                rag_context = rag_integration.enhance_analysis_prompt(program_name=program.name, cobol_code=program.content, base_prompt=enriched_prompt, analysis_type='advanced_analysis')
                
                # Criar requisição AI
                ai_request = AIRequest(
                    prompt=rag_context,
                    program_name=program.name,
                    program_code=program.content,
                    context={
                        'extracted_rules': extracted_rules,
                        'rag_applied': True,
                        'model': model
                    }
                )
                
                # Executar análise
                analysis_result = provider_manager.analyze_with_model(model, ai_request)
                
                if analysis_result.success:
                    # Calcular custos
                    cost_info = cost_calculator.tokens_analytics(
                        {'usage': [{'total_tokens': analysis_result.tokens_used}]}, 
                        analysis_result.model
                    )
                    
                    program_analysis[model] = {
                        'success': True,
                        'content': analysis_result.content,
                        'tokens_used': analysis_result.tokens_used,
                        'cost': cost_info.get('cost', 0.0),
                        'model': analysis_result.model,
                        'timestamp': analysis_result.timestamp,
                        'rag_context': rag_context
                    }
                    
                    logger.info(f"Análise com {model} bem-sucedida - {analysis_result.tokens_used} tokens")
                else:
                    logger.error(f"Falha na análise com {model}: {analysis_result.error_message}")
                    program_analysis[model] = {
                        'success': False,
                        'error': analysis_result.error_message
                    }
            
            # 3. Consolidar resultados do programa
            program_result = {
                'program': program,
                'extracted_rules': extracted_rules,
                'llm_analysis': program_analysis,
                'complexity_score': _calculate_program_complexity(program),
                'modernization_priority': _assess_modernization_priority(program, extracted_rules)
            }
            
            consolidated_results['programs'].append(program_result)
            consolidated_results['analysis_results'].extend([
                result for result in program_analysis.values() if result.get('success')
            ])
        
        # 4. Consolidar análise detalhada
        consolidated_results['detailed_analysis'] = _consolidate_detailed_analysis(
            consolidated_results['programs']
        )
        
        # 5. Estatísticas RAG
        consolidated_results["rag_stats"] = rag_integration.get_session_summary()
        
        # 6. Métricas de performance
        end_time = datetime.now()
        consolidated_results['performance_metrics'] = {
            'total_processing_time': (end_time - start_time).total_seconds(),
            'programs_processed': len(programs),
            'models_used': len(models),
            'total_tokens': sum(r.get('tokens_used', 0) for r in consolidated_results['analysis_results']),
            'total_cost': sum(r.get('cost', 0) for r in consolidated_results['analysis_results']),
            'success_rate': len([r for r in consolidated_results['analysis_results'] if r.get('success')]) / len(consolidated_results['analysis_results']) * 100 if consolidated_results['analysis_results'] else 0
        }
        
        # 7. Gerar relatório consolidado
        logger.info("Gerando relatório consolidado...")
        report_files = report_generator.generate_consolidated_report(
            programs=programs,
            analysis_results=consolidated_results['analysis_results'],
            detailed_analysis=consolidated_results['detailed_analysis'],
            rag_stats=consolidated_results['rag_stats']
        )
        
        # 8. Salvar dados consolidados
        consolidated_file = Path(output_dir) / "analise_consolidada_completa.json"
        with open(consolidated_file, 'w', encoding='utf-8') as f:
            json.dump(consolidated_results, f, indent=2, ensure_ascii=False, default=str)
        
        logger.info(f"Análise avançada concluída. Relatório HTML: {report_files.get('html_report')}")
        
        return {
            'success': True,
            'consolidated_results': consolidated_results,
            'report_files': report_files,
            'summary': {
                'programs_analyzed': len(programs),
                'models_used': len(models),
                'total_rules_extracted': sum(
                    len(p['extracted_rules'].get('business_rules', [])) + 
                    len(p['extracted_rules'].get('financial_calculations', [])) + 
                    len(p['extracted_rules'].get('data_validations', []))
                    for p in consolidated_results['programs']
                ),
                'processing_time': consolidated_results['performance_metrics']['total_processing_time'],
                'total_cost': consolidated_results['performance_metrics']['total_cost']
            }
        }
        
    except Exception as e:
        logger.error(f"Erro na análise avançada: {e}")
        return {
            'success': False,
            'error': str(e),
            'consolidated_results': consolidated_results
        }

def _create_enriched_prompt(program: Any, extracted_rules: Dict[str, Any]) -> str:
    """Cria prompt enriquecido com regras extraídas"""
    
    prompt = f"""
Analise o programa COBOL {program.name} com foco em regras de negócio específicas e valores exatos.

REGRAS DE NEGÓCIO IDENTIFICADAS PREVIAMENTE:
"""
    
    # Adicionar regras de negócio
    if extracted_rules.get('business_rules'):
        prompt += "\n=== REGRAS DE NEGÓCIO ===\n"
        for rule in extracted_rules['business_rules']:
            prompt += f"- {rule.name}: {rule.description}\n"
            prompt += f"  Localização: {rule.location}\n"
            prompt += f"  Valores: {', '.join(rule.values)}\n"
            prompt += f"  Código: {rule.cobol_code[:200]}...\n\n"
    
    # Adicionar cálculos financeiros
    if extracted_rules.get('financial_calculations'):
        prompt += "\n=== CÁLCULOS FINANCEIROS ===\n"
        for calc in extracted_rules['financial_calculations']:
            prompt += f"- {calc.name}: {calc.formula}\n"
            prompt += f"  Tipo: {calc.type}\n"
            prompt += f"  Código: {calc.cobol_code}\n\n"
    
    # Adicionar constantes e valores
    if extracted_rules.get('constants_and_values'):
        prompt += "\n=== CONSTANTES E VALORES ===\n"
        for const in extracted_rules['constants_and_values']:
            prompt += f"- {const['name']}: {const['value']} ({const['type']})\n"
            prompt += f"  Descrição: {const['description']}\n\n"
    
    prompt += f"""

CÓDIGO COMPLETO DO PROGRAMA:
{program.content}

INSTRUÇÕES PARA ANÁLISE:
1. Confirme e detalhe cada regra de negócio identificada
2. Extraia valores específicos (tarifas, limites, percentuais) com seus valores exatos
3. Identifique fórmulas matemáticas completas com variáveis e operações
4. Mapeie condições específicas (IF, WHEN, EVALUATE) com critérios exatos
5. Documente trechos de código relevantes com números de linha
6. Explique o propósito de negócio de cada regra
7. Identifique oportunidades de modernização

FORMATO DE RESPOSTA:
Para cada regra encontrada, forneça:
- Nome da regra
- Descrição detalhada
- Valores específicos (com unidades: R$, %, dias, etc.)
- Fórmula matemática exata
- Trecho de código COBOL
- Condições de aplicação
- Exemplo prático de uso
- Impacto no negócio
"""
    
    return prompt

def _consolidate_detailed_analysis(programs_results: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Consolida análise detalhada de todos os programas"""
    
    consolidated = {
        'business_rules': [],
        'financial_calculations': [],
        'data_validations': [],
        'constants_and_values': [],
        'conditional_logic': [],
        'file_operations': [],
        'summary': {
            'total_rules': 0,
            'total_calculations': 0,
            'total_validations': 0,
            'total_constants': 0
        }
    }
    
    for program_result in programs_results:
        extracted = program_result.get('extracted_rules', {})
        
        # Consolidar cada tipo de regra
        for rule_type in ['business_rules', 'financial_calculations', 'data_validations', 
                         'constants_and_values', 'conditional_logic', 'file_operations']:
            if rule_type in extracted:
                consolidated[rule_type].extend(extracted[rule_type])
        
        # Atualizar contadores
        consolidated['summary']['total_rules'] += len(extracted.get('business_rules', []))
        consolidated['summary']['total_calculations'] += len(extracted.get('financial_calculations', []))
        consolidated['summary']['total_validations'] += len(extracted.get('data_validations', []))
        consolidated['summary']['total_constants'] += len(extracted.get('constants_and_values', []))
    
    return consolidated

def _calculate_program_complexity(program: Any) -> Dict[str, Any]:
    """Calcula métricas de complexidade do programa"""
    
    lines = program.content.split('\n')
    
    return {
        'lines_of_code': len(lines),
        'cyclomatic_complexity': _calculate_cyclomatic_complexity(program.content),
        'nesting_depth': _calculate_nesting_depth(program.content),
        'number_of_procedures': _count_procedures(program.content),
        'complexity_score': _calculate_overall_complexity_score(program.content)
    }

def _assess_modernization_priority(program: Any, extracted_rules: Dict[str, Any]) -> Dict[str, Any]:
    """Avalia prioridade de modernização"""
    
    # Fatores de prioridade
    factors = {
        'business_rules_count': len(extracted_rules.get('business_rules', [])),
        'financial_calculations_count': len(extracted_rules.get('financial_calculations', [])),
        'complexity_score': _calculate_overall_complexity_score(program.content),
        'hardcoded_values': len(extracted_rules.get('constants_and_values', [])),
        'file_operations': len(extracted_rules.get('file_operations', []))
    }
    
    # Calcular score de prioridade (0-100)
    priority_score = min(100, (
        factors['business_rules_count'] * 10 +
        factors['financial_calculations_count'] * 15 +
        factors['complexity_score'] * 30 +
        factors['hardcoded_values'] * 5 +
        factors['file_operations'] * 2
    ))
    
    if priority_score >= 70:
        priority_level = "Alta"
    elif priority_score >= 40:
        priority_level = "Média"
    else:
        priority_level = "Baixa"
    
    return {
        'priority_level': priority_level,
        'priority_score': priority_score,
        'factors': factors,
        'recommendations': _generate_priority_recommendations(priority_level, factors)
    }

def _calculate_cyclomatic_complexity(content: str) -> int:
    """Calcula complexidade ciclomática"""
    # Contar estruturas de decisão
    decision_points = (
        content.upper().count('IF ') +
        content.upper().count('EVALUATE ') +
        content.upper().count('PERFORM ') +
        content.upper().count('WHEN ')
    )
    return decision_points + 1  # +1 para o caminho linear

def _calculate_nesting_depth(content: str) -> int:
    """Calcula profundidade de aninhamento"""
    max_depth = 0
    current_depth = 0
    
    lines = content.split('\n')
    for line in lines:
        line_upper = line.strip().upper()
        
        if any(keyword in line_upper for keyword in ['IF ', 'EVALUATE ', 'PERFORM ']):
            current_depth += 1
            max_depth = max(max_depth, current_depth)
        elif any(keyword in line_upper for keyword in ['END-IF', 'END-EVALUATE', 'END-PERFORM']):
            current_depth = max(0, current_depth - 1)
    
    return max_depth

def _count_procedures(content: str) -> int:
    """Conta procedimentos/parágrafos"""
    lines = content.split('\n')
    procedures = 0
    
    for line in lines:
        line_clean = line.strip()
        # Procurar por labels de parágrafo (terminam com .)
        if (line_clean and 
            not line_clean.startswith('*') and 
            line_clean.endswith('.') and 
            not any(keyword in line_clean.upper() for keyword in ['DIVISION', 'SECTION', 'PIC', 'VALUE'])):
            procedures += 1
    
    return procedures

def _calculate_overall_complexity_score(content: str) -> float:
    """Calcula score geral de complexidade (0-1)"""
    lines = len(content.split('\n'))
    cyclomatic = _calculate_cyclomatic_complexity(content)
    nesting = _calculate_nesting_depth(content)
    procedures = _count_procedures(content)
    
    # Normalizar métricas
    normalized_lines = min(1.0, lines / 1000)  # Normalizar para 1000 linhas
    normalized_cyclomatic = min(1.0, cyclomatic / 50)  # Normalizar para 50 pontos de decisão
    normalized_nesting = min(1.0, nesting / 10)  # Normalizar para 10 níveis
    normalized_procedures = min(1.0, procedures / 100)  # Normalizar para 100 procedimentos
    
    # Peso das métricas
    complexity_score = (
        normalized_lines * 0.2 +
        normalized_cyclomatic * 0.4 +
        normalized_nesting * 0.3 +
        normalized_procedures * 0.1
    )
    
    return complexity_score

def _generate_priority_recommendations(priority_level: str, factors: Dict[str, Any]) -> List[str]:
    """Gera recomendações baseadas na prioridade"""
    
    recommendations = []
    
    if priority_level == "Alta":
        recommendations.extend([
            "Priorizar modernização imediata",
            "Considerar refatoração em módulos menores",
            "Implementar testes automatizados antes da modernização",
            "Documentar regras de negócio críticas"
        ])
    elif priority_level == "Média":
        recommendations.extend([
            "Planejar modernização a médio prazo",
            "Melhorar documentação existente",
            "Considerar externalização de regras de negócio"
        ])
    else:
        recommendations.extend([
            "Manter sistema atual com melhorias pontuais",
            "Focar em documentação e manutenibilidade"
        ])
    
    # Recomendações específicas baseadas nos fatores
    if factors['hardcoded_values'] > 10:
        recommendations.append("Externalizar valores hardcoded para arquivos de configuração")
    
    if factors['complexity_score'] > 0.7:
        recommendations.append("Reduzir complexidade através de refatoração")
    
    return recommendations

if __name__ == "__main__":
    # Exemplo de uso
    import argparse
    
    parser = argparse.ArgumentParser(description='Análise Avançada de Programas COBOL')
    parser.add_argument('--fontes', required=True, help='Arquivo com programas COBOL')
    parser.add_argument('--models', default='enhanced_mock', help='Modelos LLM a usar')
    parser.add_argument('--output', default='analise_avancada', help='Diretório de saída')
    
    args = parser.parse_args()
    
    # Configurar logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # Carregar programas
    parser = COBOLParser()
    programs = parser.parse_files([args.fontes])
    
    # Configuração básica
    config = {
        'rag': {'knowledge_base_path': 'data/cobol_knowledge_base_cadoc_expanded.json'},
        'providers': {'enhanced_mock': {'enabled': True}}
    }
    
    # Executar análise
    models = args.models.split(',')
    result = process_advanced_analysis(programs, models, args.output, config)
    
    if result['success']:
        print(f"Análise concluída com sucesso!")
        print(f"Relatório HTML: {result['report_files']['html_report']}")
        print(f"Programas analisados: {result['summary']['programs_analyzed']}")
        print(f"Regras extraídas: {result['summary']['total_rules_extracted']}")
        print(f"Tempo de processamento: {result['summary']['processing_time']:.2f}s")
    else:
        print(f"Erro na análise: {result['error']}")
