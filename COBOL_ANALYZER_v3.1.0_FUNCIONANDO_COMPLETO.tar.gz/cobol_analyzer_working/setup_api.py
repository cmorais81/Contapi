#!/usr/bin/env python3

from setuptools import setup, find_packages
from setuptools.command.install import install
import os
import shutil
from pathlib import Path

class CustomInstallCommand(install):
    """Comando de instalação customizado que configura a API programática"""
    
    def run(self):
        # Executar instalação padrão
        install.run(self)
        
        # Copiar arquivos necessários para o site-packages
        try:
            # Encontrar o diretório de instalação
            install_dir = Path(self.install_lib)
            
            # Criar estrutura do pacote cobol_to_docs
            package_dir = install_dir / "cobol_to_docs"
            package_dir.mkdir(exist_ok=True)
            
            # Copiar arquivos da API
            api_files = [
                "__init__.py",
                "cobol_analyzer_api.py"
            ]
            
            for file_name in api_files:
                source_file = Path(file_name)
                dest_file = package_dir / file_name
                if source_file.exists():
                    shutil.copy2(source_file, dest_file)
                    print(f"✅ API: Copiado {file_name} para {dest_file}")
            
            # Copiar diretório src para dentro do pacote
            src_source = Path("src")
            src_dest = package_dir / "src"
            if src_source.exists():
                if src_dest.exists():
                    shutil.rmtree(src_dest)
                shutil.copytree(src_source, src_dest)
                print(f"✅ API: Copiado diretório src para {src_dest}")
            
            # Copiar diretórios de configuração e dados para o pacote
            for dir_name in ["config", "examples", "data"]:
                source_dir = Path(dir_name)
                dest_dir = package_dir / dir_name
                if source_dir.exists():
                    if dest_dir.exists():
                        shutil.rmtree(dest_dir)
                    shutil.copytree(source_dir, dest_dir)
                    print(f"✅ API: Copiado diretório {dir_name} para {dest_dir}")
            
            # Copiar arquivos principais para site-packages raiz (compatibilidade)
            main_files = [
                "main.py", "main_enhanced.py", 
                "cli.py", "cli_enhanced.py",
                "cobol_to_docs.py", "cobol_to_docs_enhanced.py"
            ]
            
            for file_name in main_files:
                source_file = Path(file_name)
                dest_file = install_dir / file_name
                if source_file.exists():
                    shutil.copy2(source_file, dest_file)
                    print(f"✅ Compatibilidade: Copiado {file_name}")
            
            print("🎉 API programática instalada com sucesso!")
            print("💡 Use: import cobol_to_docs")
            
        except Exception as e:
            print(f"⚠️  Aviso: Erro ao configurar API: {e}")

# Ler o README
try:
    with open("README_USO_PROGRAMATICO.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except:
    try:
        with open("README.md", "r", encoding="utf-8") as fh:
            long_description = fh.read()
    except:
        long_description = "COBOL Analyzer - Ferramenta de análise de código COBOL com IA e API programática"

setup(
    name="cobol-to-docs",
    version="3.1.0",
    author="COBOL Analyzer Team",
    author_email="cobol-analyzer@example.com",
    description="Ferramenta de análise de código COBOL com IA e API programática completa",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/cobol-analyzer/cobol-to-docs",
    
    # Usar comando de instalação customizado
    cmdclass={
        'install': CustomInstallCommand,
    },
    
    # Pacotes Python - incluir cobol_to_docs como pacote principal
    packages=find_packages(where="src") + ["cobol_to_docs"],
    package_dir={
        "": ".", 
        "": "src",
        "cobol_to_docs": "."
    },
    
    # Incluir módulos principais
    py_modules=[
        "main", 
        "main_enhanced",
        "cli", 
        "cli_enhanced",
        "cobol_to_docs",
        "cobol_to_docs_enhanced",
        "cobol_analyzer_api"
    ],
    
    # Scripts executáveis
    scripts=[
        "main.py", 
        "main_enhanced.py",
        "cli.py", 
        "cli_enhanced.py",
        "cobol_to_docs.py",
        "cobol_to_docs_enhanced.py"
    ],
    
    # Entry points para comandos globais E API programática
    entry_points={
        "console_scripts": [
            "cobol-analyzer=cobol_to_docs_enhanced:main",
            "cobol-to-docs=cobol_to_docs_enhanced:main",
            "cobol-docs=cobol_to_docs_enhanced:main",
        ],
    },
    
    # Incluir todos os arquivos necessários
    package_data={
        "": [
            "*.yaml", "*.yml", "*.json", "*.txt", "*.md",
            "config/*", "data/*", "examples/*", "prompts/*",
            "src/**/*", "*.py"
        ],
        "cobol_to_docs": [
            "*.py", "*.yaml", "*.yml", "*.json", "*.txt", "*.md",
            "config/*", "data/*", "examples/*", "src/**/*"
        ],
    },
    
    include_package_data=True,
    
    # Dependências essenciais
    install_requires=[
        "pyyaml>=6.0",
        "requests>=2.28.0",
        "numpy>=1.21.0",
        "scikit-learn>=1.0.0",
        "jinja2>=3.0.0",
        "markdown>=3.3.0",
    ],
    
    # Dependências opcionais
    extras_require={
        "dev": [
            "pytest>=6.0",
            "black>=21.0",
            "flake8>=3.8",
        ],
        "full": [
            "pandas>=1.3.0",
            "matplotlib>=3.3.0",
            "seaborn>=0.11.0",
        ],
        "api": [
            "fastapi>=0.68.0",
            "uvicorn>=0.15.0",
        ],
    },
    
    # Metadados
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Documentation",
        "Topic :: Software Development :: Code Generators",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    
    python_requires=">=3.8",
    zip_safe=False,
    
    # Palavras-chave para busca
    keywords="cobol, analysis, documentation, ai, legacy, modernization, api, programmatic",
    
    # Informações do projeto
    project_urls={
        "Bug Reports": "https://github.com/cobol-analyzer/cobol-to-docs/issues",
        "Source": "https://github.com/cobol-analyzer/cobol-to-docs",
        "Documentation": "https://github.com/cobol-analyzer/cobol-to-docs/wiki",
        "API Documentation": "https://github.com/cobol-analyzer/cobol-to-docs/wiki/API",
    },
)
