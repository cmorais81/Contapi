# COBOL to Docs v1.3

**Análise e Documentação de Código COBOL com Inteligência Artificial e RAG**

---

## Visão Geral

O **COBOL to Docs v1.3** é uma ferramenta de linha de comando poderosa, projetada para analisar, documentar e auxiliar na modernização de sistemas legados escritos em COBOL. Sua principal característica é um sistema avançado de **Geração Aumentada por Recuperação (RAG)**, que enriquece as análises com uma base de conhecimento especializada em COBOL, DB2, CICS e práticas do setor bancário.

A ferramenta não apenas gera documentação funcional, mas também fornece insights técnicos profundos, identifica padrões de código, extrai regras de negócio e oferece recomendações estratégicas para modernização, incluindo a tradução da lógica de negócio para Python.

## Principais Funcionalidades da v1.3

- **Análise Inteligente com RAG**: Utiliza uma base de conhecimento para enriquecer as análises, fornecendo contexto e profundidade técnica que um modelo de IA generalista não conseguiria sozinho.
- **Auto-Learning**: A base de conhecimento RAG se expande e melhora automaticamente a cada análise bem-sucedida, aprendendo os padrões específicos do seu ambiente.
- **Múltiplos Modos de Análise**: Oferece uma variedade de análises, desde uma visão funcional de alto nível até uma análise técnica profunda e sistêmica (`--consolidado`, `--analise-especialista`).
- **Suporte a Múltiplos Provedores de IA**: Compatível com LuzIA (Claude 3.5), OpenAI (GPT-4), Bedrock, Databricks e provedores de simulação para testes offline.
- **Análise de Modernização**: Gera recomendações para migração e traduz a lógica de negócio COBOL para código **Python** (`--modernizacao`).
- **Flexibilidade e Controle**: Altamente configurável através de arquivos `YAML`, permitindo a personalização de prompts, modelos e comportamento do RAG.
- **Saída em Múltiplos Formatos**: Gera documentação em Markdown e oferece a opção de conversão para **PDF** (`--pdf`).

## Instalação Rápida

1. **Extraia o pacote:**
   ```bash
   tar -xzf cobol_to_docs_v1.3.tar.gz
   cd cobol_to_docs_v1.3
   ```

2. **Instale as dependências:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Execute sua primeira análise:**
   ```bash
   python main.py --fontes examples/fontes.txt
   ```

## Como Usar

A ferramenta é operada via linha de comando. O uso mais básico envolve fornecer um arquivo ou uma lista de arquivos COBOL.

```bash
# Analisar uma lista de programas
python main.py --fontes examples/fontes.txt

# Análise consolidada com copybooks e saída em PDF
python main.py --fontes examples/fontes.txt --books examples/books.txt --consolidado --pdf
```

Para uma lista completa de comandos e suas combinações, consulte o **`docs/GUIA_DE_COMANDOS.md`**.

## Documentação Completa

O pacote inclui uma documentação detalhada na pasta `docs/`:

- **`GUIA_COMPLETO_USO_v1.3.md`**: Um guia detalhado sobre todas as funcionalidades.
- **`GUIA_DE_COMANDOS.md`**: Exemplos práticos de todos os comandos, do básico ao avançado.
- **`DOCUMENTACAO_TECNICA.md`**: Detalhes sobre a arquitetura, componentes e funcionamento interno.

## Contribuição

Este projeto é projetado para ser extensível. Você pode contribuir de várias formas:

- **Enriquecendo a Base RAG**: Adicione novos conhecimentos ao arquivo `data/cobol_knowledge_base.json`.
- **Criando Novos Prompts**: Desenvolva novos prompts para análises customizadas em `config/prompts_especialista.yaml`.
- **Adicionando Novos Provedores**: Estenda o sistema com novos provedores de IA na pasta `src/providers/`.

---

**Versão**: 1.3.0

