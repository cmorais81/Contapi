"""
COBOL AI Engine v2.6.0 - Base Provider
Interface base para todos os provedores de IA com validação completa.
"""

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from dataclasses import field
from datetime import datetime


@dataclass
class AIRequest:
    """Requisição para análise de IA."""
    prompt: str
    program_name: str = ""
    model: str = ""
    program_code: str = ""
    books_content: List[str] = field(default_factory=list)
    jcl_content: Optional[str] = None
    all_copybook_contents: Optional[Dict[str, str]] = None
    context: Dict[str, Any] = field(default_factory=dict)
    max_tokens: int = 4000
    temperature: float = 0.7

    def copy(self, **kwargs):
        return AIRequest(
            prompt=kwargs.get("prompt", self.prompt),
            program_name=kwargs.get("program_name", self.program_name),
            model=kwargs.get("model", self.model),
            program_code=kwargs.get("program_code", self.program_code),
            books_content=kwargs.get("books_content", list(self.books_content)),
            jcl_content=kwargs.get("jcl_content", self.jcl_content),
            all_copybook_contents=kwargs.get("all_copybook_contents", self.all_copybook_contents),
            context=kwargs.get("context", dict(self.context)),
            max_tokens=kwargs.get("max_tokens", self.max_tokens),
            temperature=kwargs.get("temperature", self.temperature)
        )
    
    def __post_init__(self):
        if self.context is None:
            self.context = {}


@dataclass
class AIResponse:
    """Resposta de análise de IA."""
    success: bool
    content: str
    tokens_used: int
    model: str
    provider: str = ""
    timestamp: datetime = None
    error_message: str = ""
    metadata: Dict[str, Any] = None
    prompts_used: Dict[str, str] = None  # Novo campo para armazenar prompts
    raw_response: Any = None  # Campo para armazenar resposta bruta do provedor
    response_time: float = 0.0  # Tempo de resposta em segundos
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()
        if self.metadata is None:
            self.metadata = {}
        if self.prompts_used is None:
            self.prompts_used = {}


class BaseProvider(ABC):
    """
    Classe base abstrata para todos os provedores de IA.
    Define a interface comum que todos os provedores devem implementar.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Inicializa o provedor base.
        
        Args:
            config: Configuração específica do provedor
        """
        self.config = config
        self.logger = logging.getLogger(self.__class__.__name__)
        self.enabled = config.get('enabled', True)
        self.model = config.get('model', 'unknown')
        self.max_tokens = config.get('max_tokens', 4000)
        self.temperature = config.get('temperature', 0.7)
        
        # Nome do provedor (baseado na classe)
        self.name = self.__class__.__name__.lower().replace('provider', '')
        
        # Estatísticas
        self.statistics = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'total_tokens': 0,
            'average_response_time': 0.0,
            'last_request_time': None
        }
    
    @abstractmethod
    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando o provedor específico.
        
        Args:
            request: Requisição de análise
            
        Returns:
            AIResponse: Resposta da análise
        """
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        """
        Verifica se o provedor está disponível.
        
        Returns:
            bool: True se disponível, False caso contrário
        """
        pass
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Retorna estatísticas do provedor.
        
        Returns:
            Dict com estatísticas de uso
        """
        return self.statistics.copy()
    
    def reset_statistics(self) -> None:
        """Reseta as estatísticas do provedor."""
        self.statistics = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'total_tokens': 0,
            'average_response_time': 0.0,
            'last_request_time': None
        }
    
    def _update_statistics(self, success: bool, tokens_used: int = 0, response_time: float = 0.0) -> None:
        """
        Atualiza estatísticas internas.
        
        Args:
            success: Se a requisição foi bem-sucedida
            tokens_used: Número de tokens utilizados
            response_time: Tempo de resposta em segundos
        """
        self.statistics['total_requests'] += 1
        self.statistics['last_request_time'] = datetime.now()
        
        if success:
            self.statistics['successful_requests'] += 1
            self.statistics['total_tokens'] += tokens_used
        else:
            self.statistics['failed_requests'] += 1
        
        # Atualizar tempo médio de resposta
        total_requests = self.statistics['total_requests']
        current_avg = self.statistics['average_response_time']
        self.statistics['average_response_time'] = ((current_avg * (total_requests - 1)) + response_time) / total_requests
    
    def validate_request(self, request: AIRequest) -> bool:
        """
        Valida uma requisição antes do processamento.
        
        Args:
            request: Requisição a ser validada
            
        Returns:
            bool: True se válida, False caso contrário
        """
        if not request.prompt or not request.prompt.strip():
            self.logger.error("Prompt vazio ou inválido")
            return False
        
        if request.max_tokens <= 0:
            self.logger.error("max_tokens deve ser maior que zero")
            return False
        
        if not (0.0 <= request.temperature <= 2.0):
            self.logger.error("temperature deve estar entre 0.0 e 2.0")
            return False
        
        return True
    
    def create_error_response(self, error_message: str, request: AIRequest = None) -> AIResponse:
        """
        Cria uma resposta de erro padronizada.
        
        Args:
            error_message: Mensagem de erro
            request: Requisição original (opcional)
            
        Returns:
            AIResponse com erro
        """
        return AIResponse(
            success=False,
            content="",
            tokens_used=0,
            model=self.model,
            provider=self.__class__.__name__,
            error_message=error_message,
            metadata={
                'request_prompt': request.prompt if request else "",
                'request_program': request.program_name if request else ""
            }
        )
    
    def create_success_response(self, content: str, tokens_used: int, 
                              request: AIRequest = None, metadata: Dict[str, Any] = None) -> AIResponse:
        """
        Cria uma resposta de sucesso padronizada.
        
        Args:
            content: Conteúdo da resposta
            tokens_used: Tokens utilizados
            request: Requisição original (opcional)
            metadata: Metadados adicionais (opcional)
            
        Returns:
            AIResponse com sucesso
        """
        response_metadata = {
            'request_prompt': request.prompt if request else "",
            'request_program': request.program_name if request else "",
            'model_used': self.model,
            'provider_used': self.__class__.__name__
        }
        
        if metadata:
            response_metadata.update(metadata)
        
        return AIResponse(
            success=True,
            content=content,
            tokens_used=tokens_used,
            model=self.model,
            provider=self.__class__.__name__,
            metadata=response_metadata
        )
    
    def __str__(self) -> str:
        """Representação string do provedor."""
        return f"{self.__class__.__name__}(model={self.model}, enabled={self.enabled})"
    
    def __repr__(self) -> str:
        """Representação detalhada do provedor."""
        return f"{self.__class__.__name__}(config={self.config})"

