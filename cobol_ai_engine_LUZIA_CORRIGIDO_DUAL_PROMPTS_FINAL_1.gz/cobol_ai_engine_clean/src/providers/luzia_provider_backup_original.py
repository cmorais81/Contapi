"""
LuziaProvider com formato EXATO baseado nas imagens fornecidas
"""

import os
import json
import logging
import time
import warnings
import requests
import base64
from datetime import datetime
from typing import Dict, Any, Optional, List
from urllib3.exceptions import InsecureRequestWarning

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class LuziaProvider:
    def __init__(self, config: Dict[str, Any]):
        self.logger = logging.getLogger('LuziaProvider')
        
        # Configurações da API
        self.client_id = config.get('client_id') or os.getenv('LUZIA_CLIENT_ID')
        self.client_secret = config.get('client_secret') or os.getenv('LUZIA_CLIENT_SECRET')
        self.base_url = config.get('base_url', 'https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit')
        self.auth_url = config.get('auth_url', 'https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token')
        
        # Configurações de timeout
        self.timeout = 5
        
        # Token management
        self._token = None
        self._token_expires_at = None
        
        self.logger.info("LuziaProvider inicializado com formato correto")

    def get_token(self):
        """Obter token OAuth2"""
        try:
            data = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            response = requests.post(
                self.auth_url,
                data=data,
                verify=False,
                timeout=5
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self._token = token_data.get('access_token')
                expires_in = token_data.get('expires_in', 3600)
                self._token_expires_at = time.time() + expires_in - 60
                
                self.logger.info(f"Token OAuth2 obtido com sucesso (expira em {expires_in}s)")
                return self._token
            else:
                raise Exception(f"Erro HTTP {response.status_code}: {response.text}")
                
        except Exception as e:
            self.logger.error(f"Erro ao obter token: {e}")
            raise

    def _ensure_valid_token(self):
        """Garantir que temos um token válido"""
        if not self._token or (self._token_expires_at and time.time() >= self._token_expires_at):
            self.logger.info("Token expirado ou inexistente, renovando...")
            self.get_token()

    def analyze(self, prompt: str, request: Dict[str, Any]) -> Dict[str, Any]:
        """Analisar usando formato EXATO das imagens"""
        
        # Garantir token válido
        self._ensure_valid_token()
        
        # Limpar token
        clean_token = self._token.strip().strip("'\"")
        
        # Dividir prompt
        if "=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===" in prompt:
            parts = prompt.split("=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===")
            system_prompt = parts[0].strip()
            user_prompt = parts[1].strip() if len(parts) > 1 else ""
        else:
            system_prompt = "Você é um analista de sistemas COBOL especializado."
            user_prompt = prompt
        
        # Payload no formato EXATO das imagens
        payload = {
            "input": {
                "query": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ]
            },
            "config": {
                "type": "catena.llm.LLMRouter",
                "obj_kwargs": {
                    "routing_model": "azure-gpt-4o-mini",
                    "temperature": 0.1
                }
            }
        }
        
        # Headers no formato EXATO das imagens
        headers = {
            "Content-Type": "application/json",
            "X-santander-client-id": self.client_id,
            "Authorization": f"Bearer {clean_token}"
        }
        
        # Log do que está sendo enviado
        self.logger.info("=== ENVIANDO PARA LUZIA ===")
        self.logger.info(f"URL: {self.base_url}")
        self.logger.info(f"Headers: X-santander-client-id: {self.client_id}")
        self.logger.info(f"Authorization: Bearer {clean_token[:10]}...{clean_token[-10:]}")
        self.logger.info(f"System prompt: {len(system_prompt)} chars")
        self.logger.info(f"User prompt: {len(user_prompt)} chars")
        
        try:
            # Fazer requisição
            response = requests.post(
                self.base_url,
                headers=headers,
                json=payload,
                verify=False,
                timeout=self.timeout
            )
            
            self.logger.info(f"Status: {response.status_code}")
            
            if response.status_code in [200, 201]:
                self.logger.info("✅ SUCESSO com LuzIA!")
                return response.json()
            else:
                error_text = response.text[:300] if response.text else "Sem resposta"
                self.logger.error(f"❌ Erro {response.status_code}: {error_text}")
                raise Exception(f"Erro HTTP {response.status_code}: {error_text}")
                
        except requests.exceptions.Timeout:
            self.logger.error("⏰ Timeout na requisição")
            raise Exception("Timeout na requisição para LuzIA")
        except Exception as e:
            self.logger.error(f"❌ Exceção: {e}")
            raise

    def is_available(self) -> bool:
        """Verificar se o provider está disponível"""
        try:
            self._ensure_valid_token()
            return True
        except:
            return False
