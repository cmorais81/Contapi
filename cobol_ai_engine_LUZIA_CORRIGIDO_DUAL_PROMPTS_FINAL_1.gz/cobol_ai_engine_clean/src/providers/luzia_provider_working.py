"""
LuziaProvider baseado no formato EXATO do teste.py que funciona
Replicando a estrutura que foi testada e aprovada
"""

import os
import json
import logging
import time
import warnings
import requests
from datetime import datetime
from typing import Dict, Any, Optional, List
from urllib3.exceptions import InsecureRequestWarning

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class LuziaProviderWorking:
    def __init__(self, config: Dict[str, Any]):
        self.logger = logging.getLogger('LuziaProviderWorking')
        
        # Configurações da API - EXATO como no teste.py
        self.client_id = config.get('client_id') or os.getenv('LUZIA_CLIENT_ID')
        self.client_secret = config.get('client_secret') or os.getenv('LUZIA_CLIENT_SECRET')
        
        # URLs EXATAS do teste.py
        self.auth_url = "https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token"
        self.base_url = "https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit"
        
        # Configurações de timeout
        self.timeout = 120.0  # Mesmo timeout do teste.py
        
        # Token management
        self._token = None
        self._token_expires_at = None
        
        self.logger.info("LuziaProviderWorking inicializado com formato do teste.py")

    def get_token(self):
        """Obter token OAuth2 - EXATO como no teste.py"""
        try:
            # Payload EXATO do teste.py
            request_body = {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret
            }
            
            # Headers EXATOS do teste.py
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': '*/*'
            }
            
            self.logger.info("Obtendo token OAuth2...")
            
            response = requests.post(
                self.auth_url,
                headers=headers,
                data=request_body,
                verify=False,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self._token = token_data.get('access_token')
                expires_in = token_data.get('expires_in', 3600)
                self._token_expires_at = time.time() + expires_in - 60
                
                self.logger.info(f"✅ Token OAuth2 obtido com sucesso (expira em {expires_in}s)")
                return self._token
            else:
                error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                self.logger.error(f"❌ Erro ao obter token: {error_msg}")
                raise Exception(error_msg)
                
        except Exception as e:
            self.logger.error(f"❌ Exceção ao obter token: {e}")
            raise

    def _ensure_valid_token(self):
        """Garantir que temos um token válido"""
        if not self._token or (self._token_expires_at and time.time() >= self._token_expires_at):
            self.logger.info("Token expirado ou inexistente, renovando...")
            self.get_token()

    def analyze(self, prompt: str, request: Dict[str, Any]) -> Dict[str, Any]:
        """Analisar usando formato EXATO do teste.py que funciona"""
        
        # Garantir token válido
        self._ensure_valid_token()
        
        # Dividir prompt em system e user - como no teste.py
        if "=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===" in prompt:
            parts = prompt.split("=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===")
            system_prompt = parts[0].strip()
            user_prompt = parts[1].strip() if len(parts) > 1 else ""
        else:
            # Usar prompts padrão se não houver divisão
            system_prompt = """
Answer all questions in brazilian portuguese.
Answer code question with the code only, without using the brackets.
DON'T start the answer with the word 'python'.
"""
            user_prompt = prompt
        
        # Payload no formato EXATO do teste.py
        payload = {
            "input": {
                "query": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user", 
                        "content": user_prompt
                    }
                ]
            },
            "config": {
                "type": "catena.llm.LLMRouter",
                "obj_kwargs": {
                    "routing_model": "azure-gpt-4o-mini",
                    "temperature": 0.1
                }
            }
        }
        
        # Headers no formato EXATO do teste.py
        headers = {
            "X-santander-client-id": self.client_id,
            "Authorization": f"Bearer {self._token}"
        }
        
        # Log detalhado
        self.logger.info("=== ENVIANDO PARA LUZIA (FORMATO TESTE.PY) ===")
        self.logger.info(f"URL: {self.base_url}")
        self.logger.info(f"Client ID: {self.client_id}")
        self.logger.info(f"Token: {self._token[:20]}...{self._token[-10:] if len(self._token) > 30 else self._token}")
        self.logger.info(f"System prompt: {len(system_prompt)} chars")
        self.logger.info(f"User prompt: {len(user_prompt)} chars")
        self.logger.info(f"Payload structure: {json.dumps(payload, indent=2)}")
        
        try:
            # Fazer requisição EXATA como no teste.py
            response = requests.post(
                url=self.base_url,
                json=payload,
                headers=headers,
                verify=False,
                timeout=self.timeout
            )
            
            self.logger.info(f"Status HTTP: {response.status_code}")
            
            if response.status_code in [200, 201]:
                response_data = response.json()
                self.logger.info("✅ SUCESSO com LuzIA (formato teste.py)!")
                self.logger.info(f"Resposta recebida: {len(str(response_data))} chars")
                return response_data
            else:
                error_text = response.text[:500] if response.text else "Sem resposta"
                self.logger.error(f"❌ Erro HTTP {response.status_code}")
                self.logger.error(f"Resposta: {error_text}")
                raise Exception(f"Erro HTTP {response.status_code}: {error_text}")
                
        except requests.exceptions.Timeout:
            self.logger.error("⏰ Timeout na requisição")
            raise Exception("Timeout na requisição para LuzIA")
        except Exception as e:
            self.logger.error(f"❌ Exceção na requisição: {e}")
            raise

    def is_available(self) -> bool:
        """Verificar se o provider está disponível"""
        try:
            self._ensure_valid_token()
            return True
        except Exception as e:
            self.logger.error(f"Provider não disponível: {e}")
            return False

    def get_models(self) -> List[str]:
        """Retornar modelos disponíveis"""
        return ["azure-gpt-4o-mini"]

    def get_status(self) -> Dict[str, Any]:
        """Retornar status do provider"""
        try:
            available = self.is_available()
            return {
                "available": available,
                "models": self.get_models(),
                "auth_url": self.auth_url,
                "api_url": self.base_url,
                "has_credentials": bool(self.client_id and self.client_secret),
                "token_valid": bool(self._token and self._token_expires_at and time.time() < self._token_expires_at)
            }
        except Exception as e:
            return {
                "available": False,
                "error": str(e),
                "models": [],
                "has_credentials": bool(self.client_id and self.client_secret)
            }
