#!/usr/bin/env python3
"""
Teste do LuziaProviderWorking - Validação do formato do teste.py
"""

import os
import sys
import logging
from datetime import datetime

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.providers.luzia_provider_working import LuziaProviderWorking

def setup_logging():
    """Configurar logging para o teste"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout)
        ]
    )

def test_luzia_working():
    """Testar o provider working com formato do teste.py"""
    
    print("=" * 60)
    print("TESTE DO LUZIA PROVIDER WORKING")
    print("Formato baseado no teste.py que funciona")
    print("=" * 60)
    
    # Verificar credenciais
    client_id = os.getenv('LUZIA_CLIENT_ID')
    client_secret = os.getenv('LUZIA_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        print("❌ ERRO: Credenciais LuzIA não encontradas!")
        print("   Defina as variáveis de ambiente:")
        print("   export LUZIA_CLIENT_ID='seu_client_id'")
        print("   export LUZIA_CLIENT_SECRET='seu_client_secret'")
        return False
    
    print(f"✅ Credenciais encontradas:")
    print(f"   Client ID: {client_id[:10]}...{client_id[-5:]}")
    print(f"   Client Secret: {'*' * len(client_secret)}")
    print()
    
    # Configuração do provider
    config = {
        'client_id': client_id,
        'client_secret': client_secret
    }
    
    try:
        # Inicializar provider
        print("🔧 Inicializando LuziaProviderWorking...")
        provider = LuziaProviderWorking(config)
        
        # Testar obtenção de token
        print("🔑 Testando obtenção de token...")
        token = provider.get_token()
        
        if token:
            print(f"✅ Token obtido com sucesso: {token[:20]}...{token[-10:]}")
        else:
            print("❌ Falha ao obter token")
            return False
        
        # Testar disponibilidade
        print("🔍 Testando disponibilidade do provider...")
        available = provider.is_available()
        
        if available:
            print("✅ Provider disponível")
        else:
            print("❌ Provider não disponível")
            return False
        
        # Testar análise simples
        print("📝 Testando análise simples...")
        
        test_prompt = """
Você é um analista de sistemas COBOL especializado.

=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===

IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CONTADOR PIC 9(3) VALUE ZERO.

PROCEDURE DIVISION.
INICIO.
    DISPLAY 'PROGRAMA DE TESTE'.
    MOVE 1 TO WS-CONTADOR.
    DISPLAY 'CONTADOR: ' WS-CONTADOR.
    STOP RUN.
"""
        
        request_data = {
            'program_name': 'TESTE',
            'context': 'Teste do provider working'
        }
        
        print("📤 Enviando requisição para LuzIA...")
        response = provider.analyze(test_prompt, request_data)
        
        if response:
            print("✅ Resposta recebida com sucesso!")
            print(f"   Tamanho da resposta: {len(str(response))} caracteres")
            
            # Mostrar parte da resposta se disponível
            if isinstance(response, dict):
                if 'output' in response:
                    output = response['output']
                    if isinstance(output, str):
                        preview = output[:200] + "..." if len(output) > 200 else output
                        print(f"   Preview: {preview}")
                    elif isinstance(output, dict) and 'content' in output:
                        content = output['content']
                        preview = content[:200] + "..." if len(content) > 200 else content
                        print(f"   Preview: {preview}")
                else:
                    print(f"   Estrutura da resposta: {list(response.keys())}")
            
            return True
        else:
            print("❌ Nenhuma resposta recebida")
            return False
            
    except Exception as e:
        print(f"❌ ERRO durante o teste: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Função principal"""
    setup_logging()
    
    print(f"Iniciando teste em: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    success = test_luzia_working()
    
    print()
    print("=" * 60)
    if success:
        print("✅ TESTE CONCLUÍDO COM SUCESSO!")
        print("   O LuziaProviderWorking está funcionando corretamente")
        print("   Formato do teste.py validado")
    else:
        print("❌ TESTE FALHOU!")
        print("   Verifique os logs acima para detalhes do erro")
    print("=" * 60)
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
