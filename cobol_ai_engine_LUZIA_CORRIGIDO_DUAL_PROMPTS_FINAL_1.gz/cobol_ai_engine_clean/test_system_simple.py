#!/usr/bin/env python3
"""
Teste simples do sistema sem credenciais LuzIA
"""

import os
import sys
import logging

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def test_system_simple():
    """Testar sistema sem credenciais LuzIA"""
    
    print("=" * 60)
    print("TESTE SIMPLES DO SISTEMA")
    print("Verificando funcionamento com fallback")
    print("=" * 60)
    
    try:
        # Configurar logging
        logging.basicConfig(level=logging.WARNING)  # Reduzir logs
        
        # Importar componentes
        from src.core.config import ConfigManager
        from src.providers.enhanced_provider_manager import EnhancedProviderManager
        from src.providers.base_provider import AIRequest
        
        print("1. Inicializando sistema...")
        
        config_manager = ConfigManager()
        provider_manager = EnhancedProviderManager(config_manager.config)
        
        print(f"   Providers inicializados: {list(provider_manager.providers.keys())}")
        print(f"   Provider primário: {provider_manager.primary_provider}")
        print(f"   Providers de fallback: {provider_manager.fallback_providers}")
        
        print()
        print("2. Verificando disponibilidade...")
        
        available = provider_manager.get_available_providers()
        print(f"   Providers disponíveis: {available}")
        
        if not available:
            print("   ERRO: Nenhum provider disponível!")
            return False
        
        print()
        print("3. Testando análise simples...")
        
        # Criar request de teste
        test_prompt = """
Analise este programa COBOL simples:

IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CONTADOR PIC 9(3) VALUE ZERO.

PROCEDURE DIVISION.
INICIO.
    DISPLAY 'PROGRAMA DE TESTE'.
    MOVE 1 TO WS-CONTADOR.
    DISPLAY 'CONTADOR: ' WS-CONTADOR.
    STOP RUN.

Forneça uma análise básica deste programa.
"""
        
        request = AIRequest(
            prompt=test_prompt,
            program_name='TESTE',
            program_code='IDENTIFICATION DIVISION...',
            context={'test': True}
        )
        
        print("   Enviando requisição...")
        response = provider_manager.analyze(request)
        
        if response.success:
            print("   SUCESSO!")
            print(f"   Provider usado: {response.model}")
            print(f"   Tokens: {response.tokens_used}")
            print(f"   Tempo: {response.response_time:.2f}s")
            
            # Preview da resposta
            if response.content:
                preview = response.content[:200] + "..." if len(response.content) > 200 else response.content
                print(f"   Preview: {preview}")
            
            return True
        else:
            print("   FALHA!")
            print(f"   Erro: {response.error_message}")
            return False
        
    except Exception as e:
        print(f"ERRO: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_system_simple()
    
    print()
    print("=" * 60)
    if success:
        print("TESTE CONCLUÍDO COM SUCESSO!")
        print("Sistema funcionando com provider de fallback")
    else:
        print("TESTE FALHOU!")
        print("Verificar logs acima")
    print("=" * 60)
    
    sys.exit(0 if success else 1)
