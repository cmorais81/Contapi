#!/usr/bin/env python3
"""
Script para Consolidação de Bases de Conhecimento COBOL
Consolida múltiplas bases de conhecimento em um único arquivo abrangente
"""

import json
import os
import sys
from datetime import datetime
from typing import Dict, List, Any, Set
import hashlib

def load_json_file(file_path: str) -> List[Dict[str, Any]]:
    """Carrega arquivo JSON e retorna lista de itens"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
            else:
                print(f"Aviso: {file_path} não contém uma lista")
                return []
    except Exception as e:
        print(f"Erro ao carregar {file_path}: {e}")
        return []

def generate_item_hash(item: Dict[str, Any]) -> str:
    """Gera hash único para um item baseado no título e conteúdo"""
    content_to_hash = f"{item.get('title', '')}{item.get('content', '')}"
    return hashlib.md5(content_to_hash.encode('utf-8')).hexdigest()

def normalize_item(item: Dict[str, Any], source_file: str) -> Dict[str, Any]:
    """Normaliza um item de conhecimento para formato padrão"""
    normalized = {
        'id': item.get('id', ''),
        'title': item.get('title', ''),
        'content': item.get('content', ''),
        'category': item.get('category', 'general'),
        'keywords': item.get('keywords', []),
        'cobol_constructs': item.get('cobol_constructs', []),
        'domain': item.get('domain', 'general'),
        'complexity_level': item.get('complexity_level', 'intermediate'),
        'created_at': item.get('created_at', datetime.now().isoformat()),
        'source_file': source_file
    }
    
    # Garantir que keywords e cobol_constructs são listas
    if not isinstance(normalized['keywords'], list):
        normalized['keywords'] = []
    if not isinstance(normalized['cobol_constructs'], list):
        normalized['cobol_constructs'] = []
    
    return normalized

def merge_similar_items(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Mescla itens similares baseado em título e conteúdo"""
    merged_items = []
    seen_hashes = set()
    title_groups = {}
    
    # Agrupar por título similar
    for item in items:
        title = item['title'].lower().strip()
        if title not in title_groups:
            title_groups[title] = []
        title_groups[title].append(item)
    
    # Processar cada grupo
    for title, group_items in title_groups.items():
        if len(group_items) == 1:
            # Item único, adicionar diretamente
            item_hash = generate_item_hash(group_items[0])
            if item_hash not in seen_hashes:
                merged_items.append(group_items[0])
                seen_hashes.add(item_hash)
        else:
            # Múltiplos itens com mesmo título, mesclar
            base_item = group_items[0].copy()
            
            # Combinar conteúdos únicos
            all_content = [base_item['content']]
            all_keywords = set(base_item['keywords'])
            all_constructs = set(base_item['cobol_constructs'])
            source_files = [base_item['source_file']]
            
            for item in group_items[1:]:
                if item['content'] not in all_content:
                    all_content.append(item['content'])
                all_keywords.update(item['keywords'])
                all_constructs.update(item['cobol_constructs'])
                if item['source_file'] not in source_files:
                    source_files.append(item['source_file'])
            
            # Criar item mesclado
            merged_item = base_item.copy()
            merged_item['content'] = '\n\n---\n\n'.join(all_content)
            merged_item['keywords'] = sorted(list(all_keywords))
            merged_item['cobol_constructs'] = sorted(list(all_constructs))
            merged_item['source_file'] = ', '.join(source_files)
            merged_item['merged'] = True
            merged_item['merged_count'] = len(group_items)
            
            item_hash = generate_item_hash(merged_item)
            if item_hash not in seen_hashes:
                merged_items.append(merged_item)
                seen_hashes.add(item_hash)
    
    return merged_items

def enhance_knowledge_base(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Adiciona itens de conhecimento avançado específicos para COBOL to Docs v1.3"""
    
    enhanced_items = [
        {
            'id': 'kb_enhanced_001',
            'title': 'Análise de Complexidade Ciclomática em COBOL',
            'content': '''Metodologia para análise de complexidade ciclomática em programas COBOL:

1. CONTAGEM DE PONTOS DE DECISÃO:
   - IF/ELSE: +1 por condição
   - EVALUATE/WHEN: +1 por WHEN
   - PERFORM UNTIL: +1 por loop
   - PERFORM VARYING: +1 por loop
   - GO TO: +1 por desvio

2. CÁLCULO DA COMPLEXIDADE:
   Complexidade = Pontos de Decisão + 1

3. CLASSIFICAÇÃO:
   - 1-10: Baixa complexidade (fácil manutenção)
   - 11-20: Média complexidade (moderada manutenção)
   - 21-50: Alta complexidade (difícil manutenção)
   - >50: Muito alta (refatoração necessária)

4. EXEMPLO DE ANÁLISE:
   PROCESSAR-CLIENTE.
       IF WS-TIPO-CLIENTE = 'PF'          * +1
           EVALUATE WS-CATEGORIA          * +1
               WHEN 'A'                   * +1
                   PERFORM CATEGORIA-A
               WHEN 'B'                   * +1
                   PERFORM CATEGORIA-B
               WHEN OTHER                 * +1
                   PERFORM CATEGORIA-PADRAO
           END-EVALUATE
       ELSE                               * +1
           PERFORM CLIENTE-PJ
       END-IF
       
       PERFORM UNTIL WS-EOF = 'S'         * +1
           READ ARQUIVO-ENTRADA
           PERFORM PROCESSAR-REGISTRO
       END-PERFORM.
   
   Complexidade = 7 + 1 = 8 (Baixa)

5. RECOMENDAÇÕES:
   - Quebrar parágrafos com complexidade > 20
   - Usar PERFORM para modularizar lógica
   - Evitar aninhamento excessivo de IFs
   - Documentar lógica complexa''',
            'category': 'technical_doc',
            'keywords': ['complexidade', 'ciclomática', 'análise', 'qualidade', 'manutenção'],
            'cobol_constructs': ['IF', 'EVALUATE', 'PERFORM', 'UNTIL', 'VARYING'],
            'domain': 'general',
            'complexity_level': 'advanced',
            'created_at': datetime.now().isoformat(),
            'source_file': 'enhanced_knowledge'
        },
        
        {
            'id': 'kb_enhanced_002',
            'title': 'Padrões de Modernização COBOL para Cloud',
            'content': '''Estratégias e padrões para modernização de sistemas COBOL legados para ambientes cloud:

1. ESTRATÉGIAS DE MODERNIZAÇÃO:
   a) Lift and Shift:
      - Migração direta para containers
      - Mínimas alterações no código
      - Uso de emuladores mainframe
   
   b) Refactoring:
      - Quebra de monólitos em módulos
      - Implementação de APIs REST
      - Separação de lógica de negócio
   
   c) Replatforming:
      - Migração para linguagens modernas
      - Manutenção da lógica de negócio
      - Integração com microsserviços

2. PADRÕES DE INTEGRAÇÃO:
   - API Gateway para exposição de serviços
   - Message Queues para comunicação assíncrona
   - Event-driven architecture
   - Database abstraction layers

3. EXEMPLO DE MODERNIZAÇÃO:
   ANTES (Monolítico):
   PROCESSAR-PEDIDO.
       PERFORM VALIDAR-CLIENTE
       PERFORM CALCULAR-PRECO
       PERFORM ATUALIZAR-ESTOQUE
       PERFORM GERAR-FATURA.
   
   DEPOIS (Microsserviços):
   PROCESSAR-PEDIDO.
       CALL 'CLIENTE-SERVICE' USING WS-CLIENTE-DATA
       CALL 'PRICING-SERVICE' USING WS-PRICE-DATA
       CALL 'INVENTORY-SERVICE' USING WS-STOCK-DATA
       CALL 'BILLING-SERVICE' USING WS-BILL-DATA.

4. CONSIDERAÇÕES TÉCNICAS:
   - Containerização com Docker
   - Orquestração com Kubernetes
   - CI/CD pipelines
   - Monitoramento e observabilidade
   - Testes automatizados

5. BENEFÍCIOS:
   - Escalabilidade horizontal
   - Manutenção simplificada
   - Integração com sistemas modernos
   - Redução de custos operacionais''',
            'category': 'best_practice',
            'keywords': ['modernização', 'cloud', 'microsserviços', 'api', 'containers'],
            'cobol_constructs': ['CALL', 'PERFORM'],
            'domain': 'modernization',
            'complexity_level': 'advanced',
            'created_at': datetime.now().isoformat(),
            'source_file': 'enhanced_knowledge'
        },
        
        {
            'id': 'kb_enhanced_003',
            'title': 'Segurança em Sistemas COBOL Bancários',
            'content': '''Práticas de segurança essenciais para sistemas COBOL em ambiente bancário:

1. CONTROLE DE ACESSO:
   - Autenticação forte (multi-fator)
   - Autorização baseada em roles (RBAC)
   - Princípio do menor privilégio
   - Segregação de funções

2. CRIPTOGRAFIA DE DADOS:
   WORKING-STORAGE SECTION.
   01 WS-DADOS-CRIPTOGRAFADOS.
      05 WS-CONTA-CRIPTO      PIC X(32).
      05 WS-CPF-CRIPTO        PIC X(24).
      05 WS-SENHA-HASH        PIC X(64).
   
   CRIPTOGRAFAR-DADOS.
       CALL 'ENCRYPT-AES256' USING WS-CONTA-ORIGINAL
                                   WS-CHAVE-CRIPTO
                                   WS-CONTA-CRIPTO
       CALL 'HASH-SHA256' USING WS-SENHA-ORIGINAL
                               WS-SENHA-HASH.

3. AUDITORIA E LOGGING:
   - Log de todas as transações
   - Trilha de auditoria imutável
   - Monitoramento em tempo real
   - Alertas de atividades suspeitas

4. VALIDAÇÃO DE ENTRADA:
   VALIDAR-ENTRADA-SEGURA.
       * Validar formato
       IF WS-CONTA NOT NUMERIC
           MOVE 'FORMATO INVÁLIDO' TO WS-ERRO
           GO TO FIM-VALIDACAO
       END-IF
       
       * Validar tamanho
       IF LENGTH OF WS-CONTA < 6 OR > 12
           MOVE 'TAMANHO INVÁLIDO' TO WS-ERRO
           GO TO FIM-VALIDACAO
       END-IF
       
       * Sanitizar entrada
       PERFORM REMOVER-CARACTERES-ESPECIAIS.

5. PROTEÇÃO CONTRA ATAQUES:
   - SQL Injection: Usar prepared statements
   - Buffer Overflow: Validar limites de campos
   - Cross-site scripting: Sanitizar saídas
   - Denial of Service: Rate limiting

6. COMPLIANCE E REGULAMENTAÇÕES:
   - PCI DSS para dados de cartão
   - LGPD para dados pessoais
   - Basel III para riscos operacionais
   - SOX para controles internos

7. EXEMPLO DE TRANSAÇÃO SEGURA:
   PROCESSAR-TRANSFERENCIA-SEGURA.
       PERFORM AUTENTICAR-USUARIO
       PERFORM AUTORIZAR-OPERACAO
       PERFORM VALIDAR-LIMITES
       PERFORM CRIPTOGRAFAR-DADOS
       PERFORM EXECUTAR-TRANSACAO
       PERFORM REGISTRAR-AUDITORIA
       PERFORM NOTIFICAR-CLIENTE.''',
            'category': 'banking_rule',
            'keywords': ['segurança', 'criptografia', 'auditoria', 'compliance', 'bancário'],
            'cobol_constructs': ['CALL', 'IF', 'PERFORM'],
            'domain': 'banking',
            'complexity_level': 'advanced',
            'created_at': datetime.now().isoformat(),
            'source_file': 'enhanced_knowledge'
        },
        
        {
            'id': 'kb_enhanced_004',
            'title': 'Otimização de Performance em COBOL',
            'content': '''Técnicas avançadas de otimização de performance para programas COBOL:

1. OTIMIZAÇÃO DE ACESSO A DADOS:
   - Usar índices apropriados
   - Minimizar I/O com buffering
   - Implementar cache de dados frequentes
   - Usar OCCURS DEPENDING ON eficientemente

   WORKING-STORAGE SECTION.
   01 WS-CACHE-CLIENTES.
      05 WS-CACHE-SIZE        PIC 9(4) VALUE 1000.
      05 WS-CACHE-COUNT       PIC 9(4) VALUE ZEROS.
      05 WS-CACHE-ENTRY OCCURS 1000 TIMES
                        DEPENDING ON WS-CACHE-COUNT.
         10 WS-CACHE-ID       PIC 9(10).
         10 WS-CACHE-DATA     PIC X(100).

2. OTIMIZAÇÃO DE LOOPS:
   * ANTES (Ineficiente):
   PERFORM VARYING I FROM 1 BY 1 UNTIL I > 10000
       PERFORM PROCESSAR-ITEM
   END-PERFORM
   
   * DEPOIS (Otimizado):
   PERFORM PROCESSAR-LOTE-ITEMS

3. GERENCIAMENTO DE MEMÓRIA:
   - Liberar recursos não utilizados
   - Usar REDEFINES para economizar espaço
   - Implementar pools de objetos
   - Controlar tamanho de working-storage

4. OTIMIZAÇÃO DE SQL EMBEBIDO:
   * Usar cursors com FETCH múltiplo:
   EXEC SQL
       DECLARE CURSOR_OTIMIZADO CURSOR FOR
       SELECT ID_CLIENTE, NOME_CLIENTE
       FROM TB_CLIENTE
       WHERE STATUS = 'A'
       ORDER BY ID_CLIENTE
   END-EXEC
   
   EXEC SQL OPEN CURSOR_OTIMIZADO END-EXEC
   
   PERFORM UNTIL SQLCODE NOT = 0
       EXEC SQL
           FETCH CURSOR_OTIMIZADO
           INTO :WS-CLIENTE-ARRAY
           FOR 100 ROWS
       END-EXEC
       PERFORM PROCESSAR-LOTE-CLIENTES
   END-PERFORM

5. TÉCNICAS DE PROFILING:
   - Medir tempo de execução de seções críticas
   - Identificar gargalos de I/O
   - Analisar uso de CPU e memória
   - Monitorar locks de banco de dados

6. PARALELIZAÇÃO:
   - Dividir processamento em lotes
   - Usar múltiplas threads quando possível
   - Implementar processamento assíncrono
   - Balancear carga entre recursos

7. EXEMPLO DE CÓDIGO OTIMIZADO:
   PROCESSAR-ARQUIVO-OTIMIZADO.
       * Ler em blocos grandes
       MOVE 8192 TO WS-BUFFER-SIZE
       
       * Usar buffer duplo
       PERFORM UNTIL WS-EOF = 'S'
           PERFORM LER-BLOCO-DADOS
           PERFORM PROCESSAR-BLOCO-PARALELO
           PERFORM TROCAR-BUFFERS
       END-PERFORM.''',
            'category': 'best_practice',
            'keywords': ['performance', 'otimização', 'cache', 'sql', 'paralelização'],
            'cobol_constructs': ['OCCURS DEPENDING ON', 'PERFORM VARYING', 'EXEC SQL', 'CURSOR'],
            'domain': 'general',
            'complexity_level': 'advanced',
            'created_at': datetime.now().isoformat(),
            'source_file': 'enhanced_knowledge'
        },
        
        {
            'id': 'kb_enhanced_005',
            'title': 'Padrões de Teste Automatizado para COBOL',
            'content': '''Metodologias e padrões para implementação de testes automatizados em sistemas COBOL:

1. ESTRUTURA DE TESTES UNITÁRIOS:
   IDENTIFICATION DIVISION.
   PROGRAM-ID. TEST-VALIDAR-CPF.
   
   DATA DIVISION.
   WORKING-STORAGE SECTION.
   01 WS-TEST-RESULTS.
      05 WS-TESTS-RUN          PIC 9(3) VALUE ZEROS.
      05 WS-TESTS-PASSED       PIC 9(3) VALUE ZEROS.
      05 WS-TESTS-FAILED       PIC 9(3) VALUE ZEROS.
   
   01 WS-TEST-DATA.
      05 WS-CPF-VALIDO         PIC 9(11) VALUE 12345678909.
      05 WS-CPF-INVALIDO       PIC 9(11) VALUE 11111111111.
   
   PROCEDURE DIVISION.
   MAIN-TEST.
       PERFORM TEST-CPF-VALIDO
       PERFORM TEST-CPF-INVALIDO
       PERFORM EXIBIR-RESULTADOS
       STOP RUN.

2. FRAMEWORK DE ASSERTIONS:
   ASSERT-EQUALS.
       ADD 1 TO WS-TESTS-RUN
       IF WS-EXPECTED = WS-ACTUAL
           ADD 1 TO WS-TESTS-PASSED
           DISPLAY 'PASS: ' WS-TEST-NAME
       ELSE
           ADD 1 TO WS-TESTS-FAILED
           DISPLAY 'FAIL: ' WS-TEST-NAME
           DISPLAY '  Expected: ' WS-EXPECTED
           DISPLAY '  Actual: ' WS-ACTUAL
       END-IF.

3. TESTES DE INTEGRAÇÃO:
   - Testes de banco de dados com dados de teste
   - Simulação de arquivos de entrada
   - Validação de saídas esperadas
   - Testes de performance com volumes reais

4. MOCK E STUBS:
   * Substituir chamadas externas por mocks:
   CALL 'SERVICO-EXTERNO' USING WS-PARAMETROS
   
   * Implementar como:
   IF WS-AMBIENTE-TESTE = 'S'
       PERFORM MOCK-SERVICO-EXTERNO
   ELSE
       CALL 'SERVICO-EXTERNO' USING WS-PARAMETROS
   END-IF.

5. TESTES DE REGRESSÃO:
   - Automatizar execução de suítes de teste
   - Comparar resultados com baseline
   - Detectar mudanças não intencionais
   - Integrar com CI/CD pipeline

6. COBERTURA DE CÓDIGO:
   - Instrumentar código para medir cobertura
   - Identificar código não testado
   - Estabelecer métricas mínimas de cobertura
   - Gerar relatórios de cobertura

7. EXEMPLO DE SUITE DE TESTES:
   IDENTIFICATION DIVISION.
   PROGRAM-ID. SUITE-TESTES-BANCARIOS.
   
   PROCEDURE DIVISION.
   EXECUTAR-TODOS-TESTES.
       PERFORM SETUP-AMBIENTE-TESTE
       PERFORM TESTES-VALIDACAO-CONTA
       PERFORM TESTES-CALCULO-JUROS
       PERFORM TESTES-TRANSFERENCIA
       PERFORM TESTES-RELATORIOS
       PERFORM CLEANUP-AMBIENTE-TESTE
       PERFORM GERAR-RELATORIO-TESTES.

8. INTEGRAÇÃO COM FERRAMENTAS:
   - Jenkins para automação
   - SonarQube para qualidade
   - JUnit para relatórios
   - Git hooks para execução automática''',
            'category': 'best_practice',
            'keywords': ['testes', 'automatizado', 'unitário', 'integração', 'qualidade'],
            'cobol_constructs': ['PROGRAM-ID', 'PERFORM', 'CALL', 'IF'],
            'domain': 'general',
            'complexity_level': 'advanced',
            'created_at': datetime.now().isoformat(),
            'source_file': 'enhanced_knowledge'
        }
    ]
    
    # Adicionar itens enhanced aos existentes
    all_items = items + enhanced_items
    return all_items

def consolidate_knowledge_bases():
    """Função principal para consolidar as bases de conhecimento"""
    print("=== CONSOLIDAÇÃO DE BASES DE CONHECIMENTO COBOL ===")
    print(f"Iniciado em: {datetime.now()}")
    
    # Diretório de dados
    data_dir = "data"
    if not os.path.exists(data_dir):
        print(f"Erro: Diretório {data_dir} não encontrado")
        return False
    
    # Arquivos de entrada
    input_files = [
        "cobol_knowledge_base.json",
        "cobol_knowledge_base_basica.json"
    ]
    
    all_items = []
    
    # Carregar todos os arquivos
    for filename in input_files:
        file_path = os.path.join(data_dir, filename)
        if os.path.exists(file_path):
            print(f"Carregando: {filename}")
            items = load_json_file(file_path)
            print(f"  Itens carregados: {len(items)}")
            
            # Normalizar itens
            normalized_items = []
            for item in items:
                normalized = normalize_item(item, filename)
                normalized_items.append(normalized)
            
            all_items.extend(normalized_items)
        else:
            print(f"Aviso: Arquivo não encontrado: {filename}")
    
    print(f"\nTotal de itens carregados: {len(all_items)}")
    
    # Mesclar itens similares
    print("Mesclando itens similares...")
    merged_items = merge_similar_items(all_items)
    print(f"Itens após mesclagem: {len(merged_items)}")
    
    # Adicionar conhecimento avançado
    print("Adicionando conhecimento avançado...")
    enhanced_items = enhance_knowledge_base(merged_items)
    print(f"Itens após enriquecimento: {len(enhanced_items)}")
    
    # Reorganizar IDs
    for i, item in enumerate(enhanced_items):
        item['id'] = f"kb_{i:04d}"
    
    # Estatísticas
    categories = {}
    domains = {}
    complexity_levels = {}
    
    for item in enhanced_items:
        cat = item['category']
        dom = item['domain']
        comp = item['complexity_level']
        
        categories[cat] = categories.get(cat, 0) + 1
        domains[dom] = domains.get(dom, 0) + 1
        complexity_levels[comp] = complexity_levels.get(comp, 0) + 1
    
    # Salvar base consolidada
    output_file = os.path.join(data_dir, "cobol_knowledge_base_consolidated.json")
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(enhanced_items, f, indent=2, ensure_ascii=False)
        print(f"\nBase consolidada salva em: {output_file}")
    except Exception as e:
        print(f"Erro ao salvar base consolidada: {e}")
        return False
    
    # Gerar relatório
    report_file = os.path.join(data_dir, "consolidation_report.txt")
    try:
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("RELATÓRIO DE CONSOLIDAÇÃO - BASE DE CONHECIMENTO COBOL\n")
            f.write("=" * 60 + "\n\n")
            f.write(f"Data/Hora: {datetime.now()}\n")
            f.write(f"Total de itens consolidados: {len(enhanced_items)}\n\n")
            
            f.write("DISTRIBUIÇÃO POR CATEGORIA:\n")
            f.write("-" * 30 + "\n")
            for cat, count in sorted(categories.items()):
                f.write(f"{cat}: {count} itens\n")
            
            f.write("\nDISTRIBUIÇÃO POR DOMÍNIO:\n")
            f.write("-" * 30 + "\n")
            for dom, count in sorted(domains.items()):
                f.write(f"{dom}: {count} itens\n")
            
            f.write("\nDISTRIBUIÇÃO POR COMPLEXIDADE:\n")
            f.write("-" * 30 + "\n")
            for comp, count in sorted(complexity_levels.items()):
                f.write(f"{comp}: {count} itens\n")
            
            f.write("\nARQUIVOS PROCESSADOS:\n")
            f.write("-" * 30 + "\n")
            for filename in input_files:
                f.write(f"- {filename}\n")
            
            f.write(f"\nARQUIVO CONSOLIDADO: {output_file}\n")
        
        print(f"Relatório gerado: {report_file}")
    except Exception as e:
        print(f"Erro ao gerar relatório: {e}")
    
    # Exibir estatísticas
    print("\n=== ESTATÍSTICAS DA CONSOLIDAÇÃO ===")
    print(f"Total de itens: {len(enhanced_items)}")
    print("\nPor categoria:")
    for cat, count in sorted(categories.items()):
        print(f"  {cat}: {count}")
    print("\nPor domínio:")
    for dom, count in sorted(domains.items()):
        print(f"  {dom}: {count}")
    print("\nPor complexidade:")
    for comp, count in sorted(complexity_levels.items()):
        print(f"  {comp}: {count}")
    
    print(f"\nConsolidação concluída com sucesso!")
    return True

if __name__ == "__main__":
    success = consolidate_knowledge_bases()
    sys.exit(0 if success else 1)
