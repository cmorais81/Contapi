# Instalação - COBOL to Docs v1.1

**Autor:** Carlos Morais  
**Versão:** 1.0  
**Data:** Setembro 2025

## Requisitos do Sistema

### Sistema Operacional
- Linux (Ubuntu 22.04+ recomendado)
- Windows 10+ (com WSL recomendado)
- macOS 10.15+

### Python
- Python 3.11 ou superior
- pip (gerenciador de pacotes Python)

### Dependências Python
```bash
pip install pyyaml requests beautifulsoup4 markdown
```

## Instalação

### 1. Extrair Arquivos
```bash
tar -xzf cobol_to_docs_v1.tar.gz
cd cobol_to_docs_v1
```

### 2. Verificar Instalação
```bash
python3 main.py --status
```

### 3. Testar com Exemplo
```bash
python3 main.py --fontes examples/fontes.txt
```

## Configuração

### Credenciais LuzIA (Opcional)
```bash
export LUZIA_CLIENT_ID='seu_client_id'
export LUZIA_CLIENT_SECRET='seu_client_secret'
```

### Configuração Permanente
Adicione ao seu `.bashrc` ou `.profile`:
```bash
echo 'export LUZIA_CLIENT_ID="seu_client_id"' >> ~/.bashrc
echo 'export LUZIA_CLIENT_SECRET="seu_client_secret"' >> ~/.bashrc
source ~/.bashrc
```

## Verificação

### Status do Sistema
```bash
python3 main.py --status
```

### Teste Completo
```bash
python3 main.py --fontes examples/fontes.txt --pdf
```

## Estrutura de Diretórios

Após a instalação, você terá:
```
cobol_to_docs_v1/
├── main.py              # Script principal
├── generate_prompts.py  # Gerador de prompts
├── README.md           # Documentação principal
├── INSTALL.md          # Este arquivo
├── src/                # Código fonte
├── config/             # Configurações
├── examples/           # Exemplos
├── docs/               # Documentação completa
├── old/                # Arquivos de desenvolvimento
└── logs/               # Logs (criado automaticamente)
```

## Primeiros Passos

1. **Verificar Status**:
```bash
python3 main.py --status
```

2. **Executar Exemplo**:
```bash
python3 main.py --fontes examples/fontes.txt
```

3. **Ver Resultado**:
```bash
ls -la output/
```

4. **Ler Documentação**:
```bash
cat docs/GUIA_COMPLETO_USO.md
```

## Solução de Problemas

### Erro de Python
```bash
# Verificar versão
python3 --version

# Instalar se necessário (Ubuntu)
sudo apt update
sudo apt install python3.11 python3-pip
```

### Erro de Dependências
```bash
# Instalar dependências
pip3 install pyyaml requests beautifulsoup4 markdown

# Ou usar requirements.txt se disponível
pip3 install -r requirements.txt
```

### Erro de Permissões
```bash
# Tornar scripts executáveis
chmod +x main.py generate_prompts.py
```

## Suporte

Para suporte técnico:
1. Consulte `docs/GUIA_COMPLETO_USO.md`
2. Verifique logs em `logs/`
3. Execute com `--log DEBUG` para mais detalhes

---

**Sistema desenvolvido por Carlos Morais**  
**COBOL to Docs v1.1 - Setembro 2025**
