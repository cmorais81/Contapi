#!/usr/bin/env python3
"""
Script para gerar PDFs dos relatórios markdown
"""

import os
import sys
import glob

def generate_pdfs(input_dir="output", pattern="*_analise_funcional.md"):
    """Gera PDFs de todos os arquivos markdown"""
    
    md_files = glob.glob(os.path.join(input_dir, pattern))
    
    if not md_files:
        print(f"Nenhum arquivo encontrado em {input_dir} com padrão {pattern}")
        return
    
    print(f"Encontrados {len(md_files)} arquivos para conversão:")
    
    for md_file in md_files:
        pdf_file = md_file.replace('.md', '.pdf')
        print(f"Convertendo: {md_file} -> {pdf_file}")
        
        try:
            os.system(f"manus-md-to-pdf '{md_file}' '{pdf_file}'")
            print(f"✅ PDF gerado: {pdf_file}")
        except Exception as e:
            print(f"❌ Erro: {e}")

if __name__ == "__main__":
    input_dir = sys.argv[1] if len(sys.argv) > 1 else "output"
    generate_pdfs(input_dir)
