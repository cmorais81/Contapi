# Exemplos de Uso - COBOL to Docs v1.0
## Seguindo Padrões de Documentação

### Uso Básico

```bash
# Análise padrão seguindo documentação
python main.py --fontes examples/fontes.txt --books examples/books.txt

# CLI seguindo padrões
python cli.py analyze --fontes examples/fontes.txt --books examples/books.txt
```

### Uso com Providers Específicos

```bash
# LuzIA (Santander) - seguindo padrões corporativos
export LUZIA_CLIENT_ID="your_client_id"
export LUZIA_CLIENT_SECRET="your_client_secret"
python cli.py analyze --fontes examples/fontes.txt --model luzia

# GitHub Copilot - seguindo padrões GitHub
export GITHUB_COPILOT_API_KEY="your_api_key"
python cli.py analyze --fontes examples/fontes.txt --model github_copilot

# OpenAI - seguindo padrões OpenAI
export OPENAI_API_KEY="your_api_key"
python cli.py analyze --fontes examples/fontes.txt --model openai
```

### Uso com Estratégias de Prompt

```bash
# Análise especialista (padrão)
python cli.py analyze --fontes examples/fontes.txt --strategy expert_analysis

# Análise com RAG
python cli.py analyze --fontes examples/fontes.txt --strategy rag_enhanced

# Análise abrangente
python cli.py analyze --fontes examples/fontes.txt --strategy comprehensive
```

### Configurações Avançadas

```bash
# Modo verboso seguindo padrões de logging
python cli.py analyze --fontes examples/fontes.txt --verbose

# Configuração personalizada
python cli.py analyze --config custom_config.yaml --fontes examples/fontes.txt

# Saída personalizada
python cli.py analyze --fontes examples/fontes.txt --output custom_output/
```
