#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema Principal
Análise avançada de programas COBOL com múltiplos providers
"""

import os
import sys
import argparse
import logging
from datetime import datetime
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import load_config
from src.parsers.cobol_parser_original import COBOLParser
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.generators.documentation_generator import DocumentationGenerator

def setup_logging():
    """Configura logging do sistema"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('logs/cobol_to_docs.log', mode='a')
        ]
    )
    
    # Criar diretório de logs se não existir
    os.makedirs('logs', exist_ok=True)

def parse_arguments():
    """Parse argumentos da linha de comando"""
    parser = argparse.ArgumentParser(
        description='COBOL to Docs v1.0 - Análise de Programas COBOL',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  # Análise básica
  python main.py --fontes examples/fontes.txt --books examples/books.txt
  
  # Análise com modelo específico
  python main.py --fontes examples/fontes.txt --books examples/books.txt --model luzia
  
  # Análise com saída personalizada
  python main.py --fontes examples/fontes.txt --books examples/books.txt --output custom_output
  
  # Análise com PDF
  python main.py --fontes examples/fontes.txt --books examples/books.txt --pdf
  
  # Análise completa
  python main.py --fontes examples/fontes.txt --books examples/books.txt --model luzia --output analise_completa --pdf --verbose
        """
    )
    
    # Argumentos obrigatórios
    parser.add_argument('--fontes', required=True, 
                       help='Arquivo com programas COBOL')
    
    # Argumentos opcionais
    parser.add_argument('--books', 
                       help='Arquivo com copybooks')
    parser.add_argument('--model', '--models', dest='model',
                       default='enhanced_mock',
                       help='Modelo a usar (enhanced_mock, luzia, github_copilot, openai)')
    parser.add_argument('--output', 
                       default='output',
                       help='Diretório de saída')
    parser.add_argument('--config', 
                       default='config/config.yaml',
                       help='Arquivo de configuração')
    parser.add_argument('--pdf', action='store_true',
                       help='Gerar também arquivos PDF')
    parser.add_argument('--verbose', '-v', action='store_true',
                       help='Modo verboso')
    parser.add_argument('--strategy', 
                       default='expert_analysis',
                       help='Estratégia de análise (expert_analysis, rag_enhanced, comprehensive)')
    
    return parser.parse_args()

def main():
    """Função principal"""
    try:
        # Parse argumentos
        args = parse_arguments()
        
        # Setup logging
        setup_logging()
        if args.verbose:
            logging.getLogger().setLevel(logging.DEBUG)
        
        logger = logging.getLogger(__name__)
        
        logger.info("=== COBOL to Docs v1.0 - Iniciando ===")
        logger.info(f"Fontes: {args.fontes}")
        logger.info(f"Books: {args.books}")
        logger.info(f"Modelo: {args.model}")
        logger.info(f"Output: {args.output}")
        logger.info(f"PDF: {args.pdf}")
        logger.info(f"Strategy: {args.strategy}")
        
        # Verificar arquivos de entrada
        if not os.path.exists(args.fontes):
            logger.error(f"Arquivo de fontes não encontrado: {args.fontes}")
            return 1
        
        if args.books and not os.path.exists(args.books):
            logger.error(f"Arquivo de books não encontrado: {args.books}")
            return 1
        
        # Carregar configuração
        config = load_config(args.config)
        
        # Criar diretório de saída
        os.makedirs(args.output, exist_ok=True)
        
        # Inicializar parser
        parser = COBOLParser()
        
        # Parse programas
        logger.info(f"Parseando arquivo: {args.fontes}")
        programs, _ = parser.parse_file(args.fontes)
        
        # Parse books se fornecido
        copybooks = []
        books_content = ""
        if args.books:
            logger.info(f"Parseando arquivo: {args.books}")
            _, books = parser.parse_file(args.books)
            copybooks = books
            if books:
                books_content = "\n".join([book.content for book in books])
        
        logger.info(f"Programas encontrados: {len(programs)}")
        logger.info(f"Copybooks encontrados: {len(copybooks)}")
        
        # Inicializar analisador
        analyzer = EnhancedCOBOLAnalyzer(config)
        
        # Inicializar gerador de documentação
        doc_generator = DocumentationGenerator(args.output)
        
        # Processar cada programa
        success_count = 0
        for program in programs:
            logger.info(f"Processando programa: {program.name}")
            
            try:
                # Análise
                ai_response = analyzer.analyze_program_enhanced(
                    program=program,
                    copybooks=copybooks,
                    books_content=books_content,
                    model=args.model
                )
                
                if ai_response and ai_response.success:
                    # Gerar documentação
                    doc_path = doc_generator.generate_program_documentation(
                        program=program,
                        ai_response=ai_response
                    )
                    logger.info(f"✅ Documentação gerada: {doc_path}")
                    
                    # Gerar PDF se solicitado
                    if args.pdf:
                        pdf_path = doc_path.replace('.md', '.pdf')
                        try:
                            os.system(f"manus-md-to-pdf {doc_path} {pdf_path}")
                            logger.info(f"✅ PDF gerado: {pdf_path}")
                        except Exception as e:
                            logger.warning(f"Erro ao gerar PDF: {e}")
                    
                    success_count += 1
                else:
                    logger.error(f"❌ Falha na análise de {program.name}")
                    
            except Exception as e:
                logger.error(f"❌ Erro ao processar {program.name}: {e}")
        
        logger.info("=== Processamento concluído ===")
        logger.info(f"Programas processados com sucesso: {success_count}/{len(programs)}")
        
        # Gerar relatório resumo se múltiplos programas
        if len(programs) > 1:
            summary_path = os.path.join(args.output, f"relatorio_resumo_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md")
            with open(summary_path, 'w', encoding='utf-8') as f:
                f.write(f"# Relatório Resumo - COBOL to Docs v1.0\n\n")
                f.write(f"**Data**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n")
                f.write(f"**Programas Processados**: {success_count}/{len(programs)}\n")
                f.write(f"**Modelo Usado**: {args.model}\n")
                f.write(f"**Strategy**: {args.strategy}\n\n")
                
                f.write("## Programas Analisados\n\n")
                for program in programs:
                    f.write(f"- **{program.name}**: {len(program.content)} caracteres\n")
                
                if copybooks:
                    f.write("\n## Copybooks Utilizados\n\n")
                    for book in copybooks:
                        f.write(f"- **{book.name}**: {len(book.content)} caracteres\n")
            
            logger.info(f"✅ Relatório resumo gerado: {summary_path}")
        
        return 0
        
    except Exception as e:
        logger.error(f"Erro no sistema: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
