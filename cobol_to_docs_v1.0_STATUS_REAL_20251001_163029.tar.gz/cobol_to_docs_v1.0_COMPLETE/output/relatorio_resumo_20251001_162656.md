# Relatório Resumo - COBOL to Docs v1.0

**Data**: 01/10/2025 16:26:56
**Programas Processados**: 0/5
**Modelo Usado**: luzia
**Strategy**: expert_analysis

## Programas Analisados

- **LHAN0542**: 10488 caracteres
- **LHAN0543**: 12536 caracteres
- **LHAN0544**: 14997 caracteres
- **LHAN0545**: 12294 caracteres
- **LHAN0546**: 14672 caracteres

## Copybooks Utilizados

- **PROGRAMA**: 1094 caracteres
