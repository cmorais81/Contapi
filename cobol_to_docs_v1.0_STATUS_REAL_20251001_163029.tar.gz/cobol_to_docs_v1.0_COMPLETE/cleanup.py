#!/usr/bin/env python3
"""
Script para limpeza de arquivos temporários
"""

import os
import shutil
import glob

def cleanup(force=False):
    """Limpa arquivos temporários e cache"""
    
    dirs_to_clean = [
        "temp",
        "cache", 
        "__pycache__",
        "src/__pycache__",
        "src/*/__pycache__"
    ]
    
    files_to_clean = [
        "*.pyc",
        "*.pyo",
        "*.log",
        ".DS_Store"
    ]
    
    if force:
        dirs_to_clean.extend([
            "output/ai_responses",
            "output/ai_requests", 
            "logs"
        ])
    
    print("🧹 Iniciando limpeza...")
    
    # Limpar diretórios
    for dir_pattern in dirs_to_clean:
        for directory in glob.glob(dir_pattern):
            if os.path.exists(directory):
                shutil.rmtree(directory)
                print(f"✅ Removido diretório: {directory}")
    
    # Limpar arquivos
    for file_pattern in files_to_clean:
        for file_path in glob.glob(file_pattern):
            if os.path.exists(file_path):
                os.remove(file_path)
                print(f"✅ Removido arquivo: {file_path}")
    
    print("🧹 Limpeza concluída!")

if __name__ == "__main__":
    import sys
    force = "--force" in sys.argv
    cleanup(force)
