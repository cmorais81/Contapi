


# COBOL AI Engine v2.6.1 - Manual do Usuário

## 1. Introdução

O COBOL AI Engine é uma ferramenta poderosa para análise de programas COBOL, utilizando múltiplos provedores de IA para fornecer uma análise completa e detalhada. Esta versão 2.6.1 inclui a integração com o provedor LuzIA real, um sistema de prompts customizáveis e a capacidade de gerar documentação em formato PDF.

## 2. Instalação

Para instalar o COBOL AI Engine, siga os passos abaixo:

1.  **Pré-requisitos**:
    *   Python 3.8 ou superior
    *   `pip` e `virtualenv`

2.  **Instalação**:
    ```bash
    # Extrair o pacote
    tar -xzf cobol_ai_engine_v2.6.1_FINAL.tar.gz
    cd cobol_ai_engine_v2.6.1

    # Crie e ative um ambiente virtual
    python -m venv venv
    source venv/bin/activate  # No Windows: venv\Scripts\activate

    # Instale as dependências
    pip install -r requirements.txt
    ```

## 3. Configuração

O COBOL AI Engine utiliza arquivos de configuração YAML para gerenciar os provedores de IA. Existem várias configurações pré-definidas:

### 3.1. Configurações Disponíveis

- `config/config_safe.yaml`: Configuração segura que funciona em qualquer ambiente (recomendada para iniciantes)
- `config/config_luzia_real.yaml`: Configuração com LuzIA real para ambiente corporativo
- `config/config.yaml`: Configuração padrão com LuzIA mock

### 3.2. Configuração de Credenciais LuzIA

Para usar o LuzIA real, configure as variáveis de ambiente:

```bash
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

## 4. Formas de Execução

### 4.1. Execução Básica (Recomendada)

Para uma execução segura que funciona em qualquer ambiente:

```bash
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --books examples/BOOKS.txt --output resultado
```

### 4.2. Execução com LuzIA Real

Para usar o provedor LuzIA real (requer credenciais):

```bash
python main.py --config config/config_luzia_real.yaml --fontes examples/fontes.txt --books examples/BOOKS.txt --output resultado
```

### 4.3. Execução com Geração de PDF

Para gerar documentação em PDF:

```bash
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --books examples/BOOKS.txt --output resultado --pdf
```

### 4.4. Verificação do Sistema

Para verificar se tudo está funcionando:

```bash
# Verificar versão
python main.py --version

# Verificar status dos provedores
python main.py --config config/config_safe.yaml --status

# Listar perguntas de análise
python main.py --list-questions
```

### 4.5. Execução com Configuração Customizada

Para usar sua própria configuração:

```bash
python main.py --config minha_config.yaml --fontes fontes.txt --output resultado
```

## 5. Parâmetros da Linha de Comando

### 5.1. Parâmetros Obrigatórios para Análise

- `--fontes <arquivo>`: Arquivo contendo os programas COBOL
- `--output <diretório>`: Diretório de saída para a documentação

### 5.2. Parâmetros Opcionais

- `--config <arquivo>`: Arquivo de configuração (padrão: config/config.yaml)
- `--books <arquivo>`: Arquivo contendo copybooks
- `--pdf`: Gerar documentação em PDF
- `--log-level <nível>`: Nível de log (DEBUG, INFO, WARNING, ERROR)

### 5.3. Comandos de Informação

- `--version`: Exibir versão do sistema
- `--status`: Exibir status dos provedores
- `--list-questions`: Listar perguntas de análise configuradas

## 6. Exemplos de Uso

### 6.1. Análise Simples

```bash
# Análise básica com configuração segura
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output minha_analise
```

### 6.2. Análise Completa com PDF

```bash
# Análise completa com copybooks e PDF
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --books examples/BOOKS.txt --output analise_completa --pdf
```

### 6.3. Análise com Debug

```bash
# Análise com logs detalhados
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output debug_analise --log-level DEBUG
```

## 7. Solução de Problemas

### 7.1. Problemas Comuns

**Erro: "missing 1 required positional argument: 'config'"**
- Solução: Use a configuração segura: `--config config/config_safe.yaml`

**Erro: "Name or service not known" (LuzIA)**
- Solução: Use a configuração segura ou configure as credenciais LuzIA corretamente

**Erro: "No such file or directory"**
- Solução: Verifique se os arquivos de entrada existem e os caminhos estão corretos

**Erro na geração de PDF**
- Solução: Verifique se as dependências do WeasyPrint estão instaladas

### 7.2. Verificação de Problemas

```bash
# Verificar se o sistema está funcionando
python main.py --config config/config_safe.yaml --status

# Testar com arquivos de exemplo
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output teste
```

### 7.3. Logs e Diagnóstico

Os logs são salvos em `logs/cobol_ai_engine_YYYYMMDD.log`. Para diagnóstico detalhado:

```bash
python main.py --config config/config_safe.yaml --log-level DEBUG --fontes examples/fontes.txt --output debug
```

## 8. Configurações Recomendadas por Ambiente

### 8.1. Ambiente de Desenvolvimento/Teste
```bash
python main.py --config config/config_safe.yaml
```

### 8.2. Ambiente Corporativo com LuzIA
```bash
export LUZIA_CLIENT_ID="seu_id"
export LUZIA_CLIENT_SECRET="seu_secret"
python main.py --config config/config_luzia_real.yaml
```

### 8.3. Ambiente de Produção
```bash
python main.py --config config/config_safe.yaml --pdf --log-level INFO
```

Para mais informações, consulte os logs gerados no diretório `logs/` ou o manual de configuração em `docs/MANUAL_CONFIGURACAO.md`.


