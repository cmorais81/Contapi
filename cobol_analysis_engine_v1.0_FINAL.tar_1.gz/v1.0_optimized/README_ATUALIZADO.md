# COBOL Analysis Engine v1.0

Uma ferramenta completa para análise e documentação de programas COBOL utilizando inteligência artificial.

## ✅ Status do Sistema

**Sistema 100% Funcional e Testado**

- ✅ Análise individual de programas COBOL
- ✅ Processamento em lote com fontes.txt
- ✅ Integração de copybooks via BOOKS.txt
- ✅ Análise multi-AI com OpenAI GPT-4
- ✅ Geração de relatórios profissionais
- ✅ Sistema de logging avançado
- ✅ Interface CLI completa

## 🚀 Início Rápido

### 1. Configuração

```bash
# Configurar chave do OpenAI (obrigatório)
export OPENAI_API_KEY="sua_chave_openai_aqui"
```

### 2. Uso Básico

```bash
# Análise individual (Modo Enhanced - Recomendado)
python3.11 main.py programa.cbl -o resultados/ -m enhanced

# Análise individual (Modo Multi-AI)
python3.11 main.py programa.cbl -o resultados/ -m multi_ai

# Processamento em lote (Modo Enhanced)
python3.11 main.py fontes.txt -o resultados/ -b BOOKS.txt -m enhanced

# Modo tradicional (rápido)
python3.11 main.py programa.cbl -o resultados/ -m traditional
```

### 3. Verificação

```bash
# Testar funcionalidade
python3.11 test_basic_functionality.py

# Ver ajuda
python3.11 main.py --help
```

## 📊 Funcionalidades Implementadas

### Análise Multi-AI
- **OpenAI GPT-4.1-mini**: ✅ Totalmente funcional
- **Enhanced Mock Provider**: ✅ Para testes e fallback
- **Outros Provedores**: ⚠️ Requerem configuração adicional

### Tipos de Análise
- **Estrutural**: Organização do código, divisões, seções
- **Regras de Negócio**: Lógica funcional e validações
- **Técnica**: Qualidade de implementação
- **Modelo de Dados**: Estruturas e arquivos
- **Qualidade**: Aderência a padrões

### Formatos Suportados
- **Arquivos .cbl**: Programas COBOL individuais
- **fontes.txt**: Múltiplos programas (formato VMEMBER NAME)
- **BOOKS.txt**: Copybooks (formato MEMBER NAME)

## 📁 Estrutura do Projeto

```
v1.0_optimized/
├── main.py                    # Script principal ✅
├── config/
│   └── config.yaml           # Configuração ✅
├── src/
│   ├── core/                 # Orquestrador multi-AI ✅
│   ├── providers/            # Provedores de IA ✅
│   ├── generators/           # Geradores de relatórios ✅
│   ├── extractors/           # Extratores de conteúdo ✅
│   └── utils/                # Utilitários e logging ✅
├── examples/
│   ├── fontes.txt           # Programas de exemplo ✅
│   ├── BOOKS.txt            # Copybooks de exemplo ✅
│   └── *.cbl                # Programas individuais ✅
├── docs/
│   └── MANUAL_USUARIO.md    # Manual completo ✅
├── test_basic_functionality.py # Testes ✅
└── logs/                    # Arquivos de log ✅
```

## 📋 Comandos Disponíveis

### Parâmetros CLI

```bash
python3.11 main.py <entrada> [opções]

Parâmetros:
  <entrada>              Arquivo .cbl ou fontes.txt
  -o, --output DIR       Diretório de saída (padrão: analysis_results/)
  -m, --mode MODE        Modo: multi_ai ou traditional
  -b, --books FILE       Arquivo BOOKS.txt com copybooks
  -v, --verbose          Modo verboso para depuração
  -h, --help            Mostrar ajuda
```

### Exemplos Práticos

```bash
# Análise completa com IA
python3.11 main.py examples/LHAN0542_TESTE.cbl -o resultados/ -m multi_ai

# Processamento em lote completo
python3.11 main.py examples/fontes.txt -o batch_results/ -b examples/BOOKS.txt -m multi_ai

# Análise rápida sem IA
python3.11 main.py examples/fontes.txt -o quick_results/ -m traditional

# Com modo verboso para depuração
python3.11 main.py programa.cbl -o debug/ -m multi_ai -v
```

## 📊 Saídas Geradas

### Relatórios de Análise
- `PROGRAMA_MULTI_AI_ANALYSIS.md` - Análise completa com IA
- `PROGRAMA_ANALYSIS.md` - Análise tradicional
- `BATCH_PROCESSING_SUMMARY.md` - Resumo do lote

### Logs e Métricas
- `logs/cobol_analysis.log` - Log principal
- `logs/metrics_PROGRAMA_timestamp.json` - Métricas estruturadas

## ⚡ Performance

### Tempos Típicos
- **Análise Multi-AI**: 10-25 segundos por programa
- **Análise Traditional**: < 1 segundo por programa
- **Processamento em Lote**: Tempo linear por programa

### Programas Testados
- ✅ LHAN0542 - Programa de particionamento
- ✅ LHAN0705 - Programa de processamento
- ✅ LHAN0706 - Programa de análise
- ✅ LHBR0700 - Programa de relatório
- ✅ MZAN6056 - Programa de validação

## 🔧 Configuração Avançada

### Provedores de IA

```yaml
# config/config.yaml
ai:
  providers:
    openai:
      enabled: true              # ✅ Funcional
      model: "gpt-4.1-mini"
    luzia:
      enabled: false             # ⚠️ Requer configuração
    bedrock:
      enabled: false             # ⚠️ Requer AWS
    databricks:
      enabled: false             # ⚠️ Requer workspace
```

### Variáveis de Ambiente

```bash
# Obrigatório
export OPENAI_API_KEY="sk-..."

# Opcionais
export LUZIA_API_KEY="..."
export AWS_ACCESS_KEY_ID="..."
export AWS_SECRET_ACCESS_KEY="..."
export AWS_REGION="us-east-1"
```

## 🐛 Solução de Problemas

### Problemas Comuns

1. **"OpenAI API key not found"**
   ```bash
   export OPENAI_API_KEY="sua_chave_aqui"
   ```

2. **Análise muito rápida (< 1s)**
   - Verifique se está usando `-m multi_ai`
   - Confirme se a chave OpenAI está configurada

3. **Erro de importação**
   ```bash
   python3.11 test_basic_functionality.py
   ```

### Modo Debug

```bash
# Executar com logs detalhados
python3.11 main.py arquivo.cbl -o debug/ -m multi_ai -v
```

## 📚 Documentação

- **Manual Completo**: `docs/MANUAL_USUARIO.md`
- **Guia de Uso**: `GUIA_DE_USO_COMPLETO.md`
- **Changelog**: `CHANGELOG.md`
- **Relatório Final**: `RELATORIO_FINAL_v1.0.md`

## 🎯 Casos de Uso

### Análise Individual
Ideal para análise detalhada de um programa específico com insights de IA.

### Processamento em Lote
Perfeito para análise de múltiplos programas de uma vez, com relatório consolidado.

### Integração de Copybooks
Enriquece a análise com informações de estruturas de dados compartilhadas.

### Auditoria e Documentação
Gera documentação técnica completa para compliance e manutenção.

---

**Sistema testado e validado em 20/09/2025**  
**Versão: v1.0 - Totalmente Funcional** ✅
