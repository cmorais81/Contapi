# Guia de Uso Completo - COBOL Analysis Engine v1.0

## 📋 Visão Geral

O COBOL Analysis Engine v1.0 é um sistema completo para análise e documentação de programas COBOL que suporta:

- **Análise Individual**: Processa um programa COBOL por vez
- **Processamento em Lote**: Processa múltiplos programas de arquivos `fontes.txt`
- **Integração de Copybooks**: Inclui informações de `BOOKS.txt` na análise
- **Múltiplos Provedores de IA**: OpenAI, LuzIA, Bedrock, Databricks, GitHub Copilot
- **Interface CLI**: Linha de comando completa
- **Interface Notebook**: Jupyter Notebook para uso interativo

---

## 🚀 Instalação e Configuração

### 1. Extração do Pacote

```bash
# Extrair o pacote
tar -xzf cobol_analysis_engine_v1.0_FINAL_COMPLETE.tar.gz
cd v1.0_optimized/
```

### 2. Configuração de Variáveis de Ambiente

```bash
# OpenAI (obrigatório para análise multi-AI)
export OPENAI_API_KEY="sua_chave_openai_aqui"

# Outros provedores (opcionais)
export LUZIA_API_KEY="sua_chave_luzia"
export AWS_ACCESS_KEY_ID="sua_chave_aws"
export AWS_SECRET_ACCESS_KEY="sua_chave_secreta_aws"
```

### 3. Verificação da Instalação

```bash
# Testar a CLI
python3.11 main.py --help

# Verificar configuração
python3.11 -c "from config.config_loader import load_config; print('Configuração OK')"
```

---

## 💻 Interface CLI (Linha de Comando)

### Sintaxe Básica

```bash
python3.11 main.py <arquivo_entrada> -o <diretorio_saida> [opções]
```

### Opções Disponíveis

- `-o, --output`: Diretório de saída (obrigatório)
- `-b, --books`: Arquivo BOOKS.txt com copybooks (opcional)
- `-m, --mode`: Modo de análise (`multi_ai` ou `traditional`)
- `-c, --config`: Arquivo de configuração personalizado
- `-v, --verbose`: Saída detalhada

### Exemplos de Uso CLI

#### 1. Análise de Programa Individual

```bash
# Análise básica
python3.11 main.py programa.cbl -o resultados/

# Análise com copybooks
python3.11 main.py programa.cbl -o resultados/ -b copybooks.txt

# Análise em modo tradicional
python3.11 main.py programa.cbl -o resultados/ -m traditional

# Análise com saída detalhada
python3.11 main.py programa.cbl -o resultados/ -v
```

#### 2. Processamento em Lote

```bash
# Processar arquivo fontes.txt
python3.11 main.py fontes.txt -o batch_results/

# Processar com copybooks
python3.11 main.py fontes.txt -o batch_results/ -b BOOKS.txt

# Processamento em modo tradicional
python3.11 main.py fontes.txt -o batch_results/ -m traditional
```

#### 3. Configuração Personalizada

```bash
# Usar arquivo de configuração personalizado
python3.11 main.py programa.cbl -o resultados/ -c config/custom.yaml
```

---

## 📓 Interface Notebook (Jupyter)

### 1. Importar o Módulo

```python
# Importar o analisador
from cobol_analysis_engine import COBOLAnalyzer

# Inicializar com provedor específico
analyzer = COBOLAnalyzer(provider='openai')
```

### 2. Análise de Programa Individual

```python
# Analisar um programa
result = analyzer.analyze_program('programa.cbl')

# Visualizar resultado
print(result['summary'])
analyzer.display_analysis(result)
```

### 3. Processamento em Lote

```python
# Processar múltiplos programas
results = analyzer.analyze_batch('fontes.txt', 'BOOKS.txt')

# Gerar relatório consolidado
analyzer.generate_batch_report(results, 'batch_report.md')
```

### 4. Análise Interativa

```python
# Análise passo a passo
analyzer.set_interactive_mode(True)
result = analyzer.analyze_program('programa.cbl')

# Explorar resultados
analyzer.explore_structure(result)
analyzer.explore_business_rules(result)
analyzer.explore_technical_details(result)
```

---

## 📁 Estrutura de Arquivos de Entrada

### Arquivo COBOL Individual (.cbl)

```cobol
       IDENTIFICATION DIVISION.
       PROGRAM-ID. EXEMPLO.
       AUTHOR. DESENVOLVEDOR.
       DATE-WRITTEN. 01/01/2025.
       
       ENVIRONMENT DIVISION.
       ...
```

### Arquivo fontes.txt

Formato com múltiplos programas:

```
VMEMBER NAME  PROGRAMA1
----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
V       IDENTIFICATION DIVISION.
V       PROGRAM-ID. PROGRAMA1.
...

VMEMBER NAME  PROGRAMA2
----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
V       IDENTIFICATION DIVISION.
V       PROGRAM-ID. PROGRAMA2.
...
```

### Arquivo BOOKS.txt

Formato com copybooks:

```
MEMBER NAME  COPYBOOK1
       01  ESTRUTURA-DADOS.
           05  CAMPO1          PIC X(10).
           05  CAMPO2          PIC 9(05).

MEMBER NAME  COPYBOOK2
       01  OUTRA-ESTRUTURA.
           05  CAMPO-A         PIC X(20).
           05  CAMPO-B         PIC 9(10).
```

---

## 📊 Saídas Geradas

### 1. Relatórios de Análise Individual

**Arquivo:** `PROGRAMA_MULTI_AI_ANALYSIS.md`

Conteúdo:
- Cabeçalho com metadados
- Resumo executivo
- Métricas de análise
- Análises especializadas por domínio
- Recomendações

### 2. Relatório de Processamento em Lote

**Arquivo:** `BATCH_PROCESSING_SUMMARY.md`

Conteúdo:
- Estatísticas do processamento
- Lista de programas processados
- Programas com falha
- Links para relatórios individuais

### 3. Logs de Execução

**Diretório:** `logs/`

Arquivos:
- `cobol_analysis.log`: Log geral
- `analysis_metrics.log`: Métricas de performance
- `analysis_errors.log`: Erros detalhados
- `metrics_PROGRAMA_timestamp.json`: Métricas estruturadas

---

## ⚙️ Configuração Avançada

### Arquivo config/config.yaml

```yaml
# Configuração dos provedores de IA
ai:
  providers:
    openai:
      enabled: true
      api_key_env: "OPENAI_API_KEY"
      model: "gpt-4o-mini"
      temperature: 0.1
    
    luzia:
      enabled: false
      api_key_env: "LUZIA_API_KEY"
      model: "claude-3-5-sonnet"
    
    enhanced_mock:
      enabled: true
      model: "mock-model"

  # Análises especializadas
  specialized_ais:
    structural_analysis:
      provider: "openai"
      prompt_template: "structural_analysis"
    
    business_analysis:
      provider: "luzia"
      prompt_template: "business_analysis"

# Configuração de logging
logging:
  level: "INFO"
  save_metrics: true
  detailed_logs: true

# Configuração de saída
output:
  format: "markdown"
  include_metrics: true
  save_json: true
```

### Personalização de Prompts

**Arquivo:** `templates/prompts.yaml`

```yaml
structural_analysis: |
  Analise a estrutura do programa COBOL:
  - Divisões e seções
  - Organização do código
  - Padrões arquiteturais
  
business_analysis: |
  Identifique as regras de negócio:
  - Processos implementados
  - Validações de dados
  - Fluxos de trabalho
```

---

## 🔧 Solução de Problemas

### Problemas Comuns

#### 1. Erro de Importação

```bash
# Erro: ModuleNotFoundError
# Solução: Verificar se está no diretório correto
cd v1.0_optimized/
python3.11 main.py --help
```

#### 2. Erro de Configuração de IA

```bash
# Erro: Provider not available
# Solução: Verificar variáveis de ambiente
echo $OPENAI_API_KEY
export OPENAI_API_KEY="sua_chave_aqui"
```

#### 3. Erro de Permissão

```bash
# Erro: Permission denied
# Solução: Verificar permissões do diretório
chmod +x main.py
mkdir -p resultados/
```

#### 4. Timeout em Processamento

```bash
# Para arquivos grandes, usar modo tradicional
python3.11 main.py fontes.txt -o resultados/ -m traditional
```

### Logs de Depuração

```bash
# Executar com logs detalhados
python3.11 main.py programa.cbl -o resultados/ -v

# Verificar logs
tail -f logs/cobol_analysis.log
```

---

## 📈 Métricas e Performance

### Métricas Coletadas

- **Tempo de Execução**: Total e por componente
- **Uso de Tokens**: Por provedor de IA
- **Taxa de Sucesso**: Análises bem-sucedidas
- **Confiança da Validação**: Consenso entre IAs
- **Pontuação de Clareza**: Qualidade da documentação

### Arquivo de Métricas JSON

```json
{
  "program_name": "PROGRAMA1",
  "execution_time": 15.23,
  "providers_used": ["openai", "enhanced_mock"],
  "success_rate": 0.8,
  "confidence_score": 0.75,
  "clarity_score": 0.85,
  "tokens_used": 1250
}
```

---

## 🔄 Integração com Outros Sistemas

### API REST (Futuro)

```python
# Exemplo de integração futura
import requests

response = requests.post('http://localhost:8000/analyze', {
    'program_content': cobol_code,
    'include_copybooks': True
})

result = response.json()
```

### Pipeline CI/CD

```yaml
# Exemplo para GitHub Actions
- name: Analyze COBOL
  run: |
    python3.11 main.py src/*.cbl -o analysis_results/
    # Upload results to artifact storage
```

---

## 📚 Recursos Adicionais

### Documentação

- `README.md`: Visão geral do projeto
- `CHANGELOG.md`: Histórico de mudanças
- `docs/MANUAL_USUARIO.md`: Manual técnico detalhado

### Exemplos

- `examples/`: Programas COBOL de exemplo
- `exemplo_notebook.ipynb`: Notebook de demonstração

### Suporte

Para dúvidas e suporte:
1. Consultar logs de execução
2. Verificar configuração
3. Revisar exemplos fornecidos
4. Consultar documentação técnica

---

**COBOL Analysis Engine v1.0** - Sistema Completo de Análise e Documentação COBOL
