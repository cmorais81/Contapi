#!/usr/bin/env python3.11
"""
Script para processar arquivos fontes.txt e BOOKS.txt
Uso: python3.11 process_batch.py fontes.txt BOOKS.txt -o output_dir/
"""

import sys
import os
import argparse
import asyncio
from pathlib import Path

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.extractors.content_extractor import COBOLContentExtractor
from src.core.multi_ai_orchestrator import MultiAIOrchestrator
from src.generators.detailed_report_generator import DetailedReportGenerator
from src.utils.enhanced_logger import EnhancedAnalysisLogger
from src.config.config_loader import load_config

class BatchProcessor:
    def __init__(self, config_path="config/config.yaml"):
        self.config = load_config(config_path)
        self.content_extractor = COBOLContentExtractor()
        self.orchestrator = MultiAIOrchestrator(self.config)
        self.report_generator = DetailedReportGenerator()
        self.logger = EnhancedAnalysisLogger(self.config)
        
    def extract_programs_from_fontes(self, fontes_path):
        """Extrai programas individuais do arquivo fontes.txt"""
        programs = []
        current_program = None
        current_lines = []
        
        with open(fontes_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.rstrip()
                
                # Detectar início de novo programa
                if line.startswith('VMEMBER NAME'):
                    if current_program and current_lines:
                        programs.append({
                            'name': current_program,
                            'content': '\n'.join(current_lines)
                        })
                    
                    # Extrair nome do programa
                    parts = line.split()
                    if len(parts) >= 3:
                        current_program = parts[2].strip()
                        current_lines = []
                
                # Adicionar linha ao programa atual
                if current_program:
                    # Remover prefixo 'V' se presente
                    clean_line = line[1:] if line.startswith('V') else line
                    current_lines.append(clean_line)
        
        # Adicionar último programa
        if current_program and current_lines:
            programs.append({
                'name': current_program,
                'content': '\n'.join(current_lines)
            })
        
        return programs
    
    def extract_copybooks_from_books(self, books_path):
        """Extrai copybooks do arquivo BOOKS.txt"""
        if not os.path.exists(books_path):
            return {}
        
        copybooks = {}
        current_book = None
        current_lines = []
        
        with open(books_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.rstrip()
                
                # Detectar início de novo copybook
                if 'MEMBER NAME' in line or line.startswith('BOOK'):
                    if current_book and current_lines:
                        copybooks[current_book] = '\n'.join(current_lines)
                    
                    # Extrair nome do copybook
                    if 'MEMBER NAME' in line:
                        parts = line.split()
                        for i, part in enumerate(parts):
                            if part == 'NAME' and i + 1 < len(parts):
                                current_book = parts[i + 1].strip()
                                break
                    current_lines = []
                
                # Adicionar linha ao copybook atual
                if current_book:
                    current_lines.append(line)
        
        # Adicionar último copybook
        if current_book and current_lines:
            copybooks[current_book] = '\n'.join(current_lines)
        
        return copybooks
    
    async def process_batch(self, fontes_path, books_path, output_dir):
        """Processa todos os programas do arquivo fontes.txt"""
        
        self.logger.start_analysis("batch_processing")
        
        # Criar diretório de saída
        os.makedirs(output_dir, exist_ok=True)
        
        # Extrair programas e copybooks
        programs = self.extract_programs_from_fontes(fontes_path)
        copybooks = self.extract_copybooks_from_books(books_path) if books_path else {}
        
        print(f"Encontrados {len(programs)} programas para análise")
        if copybooks:
            print(f"Encontrados {len(copybooks)} copybooks")
        
        results = []
        
        for i, program in enumerate(programs, 1):
            print(f"\nProcessando programa {i}/{len(programs)}: {program['name']}")
            
            try:
                # Extrair dados do programa
                extracted_data = self.content_extractor.extract_from_content(
                    program['content'], 
                    program['name']
                )
                
                # Adicionar copybooks relevantes
                if copybooks:
                    extracted_data['copybooks'] = copybooks
                
                # Executar análise multi-AI
                orchestration_result = await self.orchestrator.analyze_program(
                    extracted_data
                )
                
                # Gerar relatório
                report_path = os.path.join(output_dir, f"{program['name']}_MULTI_AI_ANALYSIS.md")
                documentation = self.report_generator.generate_from_orchestration(
                    orchestration_result,
                    extracted_data,
                    report_path
                )
                
                # Salvar relatório
                with open(report_path, 'w', encoding='utf-8') as f:
                    f.write(documentation)
                
                results.append({
                    'program': program['name'],
                    'status': 'success',
                    'report_path': report_path
                })
                
                print(f"✓ Análise concluída: {report_path}")
                
            except Exception as e:
                error_msg = f"Erro ao processar {program['name']}: {str(e)}"
                print(f"✗ {error_msg}")
                results.append({
                    'program': program['name'],
                    'status': 'error',
                    'error': error_msg
                })
        
        # Gerar relatório de resumo
        self.generate_summary_report(results, output_dir)
        
        self.logger.finish_analysis(True, output_dir)
        
        return results
    
    def generate_summary_report(self, results, output_dir):
        """Gera relatório de resumo do processamento em lote"""
        
        summary_path = os.path.join(output_dir, "BATCH_PROCESSING_SUMMARY.md")
        
        successful = [r for r in results if r['status'] == 'success']
        failed = [r for r in results if r['status'] == 'error']
        
        summary = f"""# Relatório de Processamento em Lote

**Data:** {self.logger.start_time.strftime('%d/%m/%Y %H:%M:%S')}
**Total de Programas:** {len(results)}
**Sucessos:** {len(successful)}
**Falhas:** {len(failed)}
**Taxa de Sucesso:** {len(successful)/len(results)*100:.1f}%

---

## Programas Processados com Sucesso

"""
        
        for result in successful:
            summary += f"- **{result['program']}** → `{os.path.basename(result['report_path'])}`\n"
        
        if failed:
            summary += f"\n## Programas com Falha\n\n"
            for result in failed:
                summary += f"- **{result['program']}**: {result['error']}\n"
        
        summary += f"\n---\n\n*Processamento concluído em {output_dir}*\n"
        
        with open(summary_path, 'w', encoding='utf-8') as f:
            f.write(summary)
        
        print(f"\n📊 Relatório de resumo salvo em: {summary_path}")

async def main():
    parser = argparse.ArgumentParser(description='Processar arquivos fontes.txt e BOOKS.txt')
    parser.add_argument('fontes', help='Caminho para o arquivo fontes.txt')
    parser.add_argument('books', nargs='?', help='Caminho para o arquivo BOOKS.txt (opcional)')
    parser.add_argument('-o', '--output', required=True, help='Diretório de saída')
    parser.add_argument('-c', '--config', default='config/config.yaml', help='Arquivo de configuração')
    
    args = parser.parse_args()
    
    if not os.path.exists(args.fontes):
        print(f"Erro: Arquivo {args.fontes} não encontrado")
        sys.exit(1)
    
    if args.books and not os.path.exists(args.books):
        print(f"Aviso: Arquivo {args.books} não encontrado, continuando sem copybooks")
        args.books = None
    
    processor = BatchProcessor(args.config)
    results = await processor.process_batch(args.fontes, args.books, args.output)
    
    successful = len([r for r in results if r['status'] == 'success'])
    total = len(results)
    
    print(f"\n🎉 Processamento concluído!")
    print(f"📈 {successful}/{total} programas processados com sucesso")
    print(f"📁 Resultados salvos em: {args.output}")

if __name__ == "__main__":
    asyncio.run(main())
