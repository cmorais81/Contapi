# Relatório de Processamento em Lote - COBOL Analysis Engine

**Data:** 20/09/2025 08:43:07  
**Total de Programas:** 5  
**Sucessos:** 0  
**Falhas:** 5  
**Taxa de Sucesso:** 0.0%  

---

## Programas Processados com Sucesso


## Programas com Falha

- **NAME**: Erro ao processar NAME: 'DetailedReportGenerator' object has no attribute 'generate_traditional_report'
- **NAME**: Erro ao processar NAME: 'DetailedReportGenerator' object has no attribute 'generate_traditional_report'
- **NAME**: Erro ao processar NAME: 'DetailedReportGenerator' object has no attribute 'generate_traditional_report'
- **NAME**: Erro ao processar NAME: 'DetailedReportGenerator' object has no attribute 'generate_traditional_report'
- **NAME**: Erro ao processar NAME: 'DetailedReportGenerator' object has no attribute 'generate_traditional_report'

---

*Processamento concluído em test_batch_results/*
