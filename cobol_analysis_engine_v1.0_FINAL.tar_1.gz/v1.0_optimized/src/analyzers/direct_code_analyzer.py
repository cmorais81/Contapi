import re
import logging
from typing import Dict, Any, List, Tuple

class DirectCodeAnalyzer:
    """
    Analisador direto que extrai informações específicas do código COBOL
    sem depender de LLM, garantindo resultados consistentes e detalhados.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def analyze(self, program_name: str, resolved_code: str) -> Dict[str, Any]:
        """Realiza análise completa e direta do código COBOL."""
        self.logger.info(f"Iniciando análise direta do programa: {program_name}")

        lines = resolved_code.split('\n')
        
        analysis = {
            "program_purpose": self._extract_program_purpose(lines),
            "input_files": self._extract_input_files(lines),
            "output_files": self._extract_output_files(lines),
            "data_structures": self._extract_data_structures(lines),
            "business_logic": self._extract_business_logic(lines),
            "control_flow": self._extract_control_flow(lines),
            "constants_and_limits": self._extract_constants(lines),
            "error_handling": self._extract_error_handling(lines),
            "performance_considerations": self._extract_performance_info(lines)
        }

        return analysis

    def _extract_program_purpose(self, lines: List[str]) -> str:
        """Extrai o propósito do programa dos comentários iniciais."""
        purpose_lines = []
        in_remarks = False
        
        for line in lines:
            line = line.strip()
            
            # Procura por seções de comentários que descrevem o objetivo
            if "OBJETIVO DO PROGRAMA" in line or "REMARKS" in line:
                in_remarks = True
                continue
            
            if in_remarks and line.startswith("*"):
                # Remove asteriscos e espaços
                clean_line = re.sub(r'^\*+\s*', '', line).strip()
                if clean_line and not clean_line.startswith("*"):
                    purpose_lines.append(clean_line)
                
                # Para quando encontrar uma linha de separação
                if "***" in line or "---" in line:
                    break
        
        if purpose_lines:
            return " ".join(purpose_lines)
        
        # Fallback: procura por comentários que mencionem funcionalidade
        for line in lines:
            if any(keyword in line.upper() for keyword in ["PARTICIONAR", "PROCESSAR", "GERAR", "CONVERTER"]):
                return line.strip().replace("*", "").strip()
        
        return "Propósito não identificado nos comentários do programa"

    def _extract_input_files(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extrai informações detalhadas dos arquivos de entrada."""
        input_files = []
        current_file = None
        in_fd_section = False
        
        for i, line in enumerate(lines):
            line = line.strip()
            
            # Detecta SELECT statements para arquivos de entrada
            select_match = re.search(r'SELECT\s+(\w+)\s+ASSIGN\s+(\w+)', line)
            if select_match:
                logical_name = select_match.group(1)
                physical_name = select_match.group(2)
                
                # Determina se é entrada ou saída baseado no nome
                if logical_name.endswith('E1') or logical_name.endswith('E2') or logical_name.endswith('E3') or logical_name.endswith('E4') or logical_name.endswith('E5'):
                    current_file = {
                        "logical_name": logical_name,
                        "physical_name": physical_name,
                        "record_size": "N/A",
                        "format": "fixed",
                        "description": "Arquivo de entrada",
                        "fields": []
                    }
            
            # Detecta FD (File Description) para arquivos de entrada
            fd_match = re.search(r'FD\s+(\w+)', line)
            if fd_match and current_file and fd_match.group(1) == current_file["logical_name"]:
                in_fd_section = True
                
                # Procura por RECORD CONTAINS para tamanho
                for j in range(i, min(i+5, len(lines))):
                    record_match = re.search(r'RECORD\s+CONTAINS\s+(\d+)', lines[j])
                    if record_match:
                        current_file["record_size"] = int(record_match.group(1))
                        break
            
            # Detecta estrutura de registro (01 level)
            if in_fd_section and re.match(r'\s*01\s+(\w+)', line):
                record_match = re.match(r'\s*01\s+(\w+)', line)
                if record_match:
                    record_name = record_match.group(1)
                    
                    # Extrai campos do registro
                    fields = self._extract_record_fields(lines, i)
                    current_file["fields"] = fields
                    
                    input_files.append(current_file)
                    current_file = None
                    in_fd_section = False
        
        return input_files

    def _extract_output_files(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extrai informações detalhadas dos arquivos de saída."""
        output_files = []
        
        for i, line in enumerate(lines):
            line = line.strip()
            
            # Detecta SELECT statements para arquivos de saída
            select_match = re.search(r'SELECT\s+(\w+)\s+ASSIGN\s+(\w+)', line)
            if select_match:
                logical_name = select_match.group(1)
                physical_name = select_match.group(2)
                
                # Determina se é saída baseado no nome
                if logical_name.endswith('S1') or logical_name.endswith('S2') or logical_name.endswith('S3'):
                    output_file = {
                        "logical_name": logical_name,
                        "physical_name": physical_name,
                        "record_size": "N/A",
                        "format": "fixed",
                        "description": "Arquivo de saída",
                        "fields": []
                    }
                    
                    # Procura pela definição FD correspondente
                    for j, fd_line in enumerate(lines):
                        fd_match = re.search(r'FD\s+' + logical_name, fd_line)
                        if fd_match:
                            # Extrai campos do registro de saída
                            fields = self._extract_record_fields(lines, j)
                            output_file["fields"] = fields
                            break
                    
                    output_files.append(output_file)
        
        return output_files

    def _extract_record_fields(self, lines: List[str], start_index: int) -> List[Dict[str, Any]]:
        """Extrai campos de um registro a partir de uma posição específica."""
        fields = []
        
        for i in range(start_index, min(start_index + 20, len(lines))):
            line = lines[i].strip()
            
            # Procura por definições de campo (05, 10, 15, etc.)
            field_match = re.search(r'(\d+)\s+(\w+)\s+PIC\s+([X9V\(\)]+)', line)
            if field_match:
                level = int(field_match.group(1))
                name = field_match.group(2)
                picture = field_match.group(3)
                
                # Calcula tamanho baseado no PIC
                length = self._calculate_field_length(picture)
                
                # Determina tipo baseado no PIC
                field_type = "alphanumeric" if "X" in picture else "numeric"
                
                fields.append({
                    "name": name,
                    "level": level,
                    "picture": picture,
                    "length": length,
                    "type": field_type,
                    "position": "N/A",  # Seria necessário cálculo mais complexo
                    "usage": "DISPLAY"
                })
            
            # Para quando encontrar outro FD ou seção
            if re.match(r'\s*(FD|WORKING-STORAGE|PROCEDURE)', line):
                break
        
        return fields

    def _calculate_field_length(self, picture: str) -> int:
        """Calcula o tamanho de um campo baseado na cláusula PIC."""
        # Remove parênteses e conta caracteres
        if '(' in picture and ')' in picture:
            # Formato PIC X(10) ou 9(5)
            match = re.search(r'[X9V]+\((\d+)\)', picture)
            if match:
                return int(match.group(1))
        
        # Conta caracteres individuais
        return len(re.findall(r'[X9V]', picture))

    def _extract_data_structures(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extrai estruturas de dados da WORKING-STORAGE."""
        structures = []
        in_working_storage = False
        
        for line in lines:
            line = line.strip()
            
            if "WORKING-STORAGE" in line:
                in_working_storage = True
                continue
            
            if in_working_storage and "PROCEDURE" in line:
                break
            
            if in_working_storage:
                # Procura por definições de variáveis
                var_match = re.search(r'(\d+)\s+(\w+)\s+PIC\s+([X9V\(\)]+)(?:\s+VALUE\s+([^.]+))?', line)
                if var_match:
                    level = int(var_match.group(1))
                    name = var_match.group(2)
                    picture = var_match.group(3)
                    value = var_match.group(4) if var_match.group(4) else "N/A"
                    
                    # Determina propósito baseado no nome
                    purpose = self._determine_variable_purpose(name)
                    
                    structures.append({
                        "name": name,
                        "level": level,
                        "type": "numeric" if "9" in picture else "alphanumeric",
                        "size": self._calculate_field_length(picture),
                        "picture": picture,
                        "initial_value": value.strip() if value != "N/A" else "N/A",
                        "purpose": purpose
                    })
        
        return structures

    def _determine_variable_purpose(self, var_name: str) -> str:
        """Determina o propósito de uma variável baseado no nome."""
        name_upper = var_name.upper()
        
        if "FS-" in name_upper or "FILE-STATUS" in name_upper:
            return "Status de arquivo"
        elif "TOT-" in name_upper or "TOTAL" in name_upper:
            return "Contador/totalizador"
        elif "WS-" in name_upper:
            return "Variável de trabalho"
        elif "FLAG" in name_upper:
            return "Indicador/flag"
        elif "MAX" in name_upper:
            return "Valor máximo/limite"
        elif "PART" in name_upper:
            return "Controle de particionamento"
        else:
            return "Variável de uso geral"

    def _extract_business_logic(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extrai a lógica de negócio do programa."""
        logic_steps = []
        step_counter = 1
        
        # Procura por parágrafos na PROCEDURE DIVISION
        in_procedure = False
        current_paragraph = None
        
        for line in lines:
            line = line.strip()
            
            if "PROCEDURE" in line and "DIVISION" in line:
                in_procedure = True
                continue
            
            if in_procedure:
                # Detecta parágrafos (terminam com ponto)
                if re.match(r'^[A-Z0-9-]+\.$', line):
                    current_paragraph = line.replace('.', '')
                    
                    # Determina a lógica baseada no nome do parágrafo
                    description, conditions, actions = self._analyze_paragraph_logic(current_paragraph, lines)
                    
                    logic_steps.append({
                        "step": step_counter,
                        "paragraph": current_paragraph,
                        "description": description,
                        "conditions": conditions,
                        "actions": actions
                    })
                    step_counter += 1
        
        return logic_steps

    def _analyze_paragraph_logic(self, paragraph_name: str, lines: List[str]) -> Tuple[str, str, str]:
        """Analisa a lógica de um parágrafo específico."""
        name_upper = paragraph_name.upper()
        
        # Mapeia nomes comuns de parágrafos para suas funções
        if "INICIO" in name_upper or "MAIN" in name_upper:
            return ("Inicialização do programa", "Início da execução", "Configurar variáveis e abrir arquivos")
        elif "LER" in name_upper or "READ" in name_upper:
            return ("Leitura de arquivo", "Arquivo disponível para leitura", "Ler próximo registro")
        elif "GRAVAR" in name_upper or "WRITE" in name_upper:
            return ("Gravação de registro", "Registro válido para gravação", "Escrever registro no arquivo de saída")
        elif "VALIDAR" in name_upper or "VALID" in name_upper:
            return ("Validação de dados", "Registro lido", "Verificar integridade e formato dos dados")
        elif "PROCESSAR" in name_upper or "PROCESS" in name_upper:
            return ("Processamento principal", "Dados validados", "Aplicar regras de negócio")
        elif "FECHAR" in name_upper or "CLOSE" in name_upper:
            return ("Finalização", "Processamento concluído", "Fechar arquivos e finalizar programa")
        elif "ERRO" in name_upper or "ERROR" in name_upper:
            return ("Tratamento de erro", "Erro detectado", "Registrar erro e tomar ação corretiva")
        else:
            return (f"Processamento específico ({paragraph_name})", "Condições específicas", "Ações específicas do parágrafo")

    def _extract_control_flow(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extrai o fluxo de controle do programa."""
        flow_steps = []
        
        # Procura por PERFORM statements que indicam chamadas entre parágrafos
        for line in lines:
            line = line.strip()
            
            perform_match = re.search(r'PERFORM\s+([A-Z0-9-]+)', line)
            if perform_match:
                called_paragraph = perform_match.group(1)
                
                # Procura por condições (IF, WHEN, etc.)
                conditions = "Incondicional"
                if "IF" in line:
                    conditions = "Condicional (IF)"
                elif "UNTIL" in line:
                    conditions = "Loop (UNTIL)"
                elif "TIMES" in line:
                    conditions = "Repetição (TIMES)"
                
                flow_steps.append({
                    "paragraph": called_paragraph,
                    "calls": [called_paragraph],
                    "conditions": conditions,
                    "type": "PERFORM"
                })
        
        return flow_steps

    def _extract_constants(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extrai constantes e valores literais do programa."""
        constants = []
        
        for line in lines:
            line = line.strip()
            
            # Procura por VALUE clauses
            value_match = re.search(r'(\w+)\s+.*VALUE\s+([^.]+)', line)
            if value_match:
                name = value_match.group(1)
                value = value_match.group(2).strip()
                
                # Remove aspas se presentes
                if value.startswith(("'", '"')) and value.endswith(("'", '"')):
                    value = value[1:-1]
                
                constants.append({
                    "name": name,
                    "value": value,
                    "usage": self._determine_constant_usage(name, value)
                })
        
        return constants

    def _determine_constant_usage(self, name: str, value: str) -> str:
        """Determina o uso de uma constante baseado no nome e valor."""
        name_upper = name.upper()
        
        if "SPACES" in value.upper():
            return "Inicialização com espaços"
        elif "ZEROS" in value.upper() or value == "0":
            return "Inicialização com zeros"
        elif "DOC" in name_upper:
            return "Marcador de documento"
        elif "FLAG" in name_upper:
            return "Indicador de status"
        else:
            return "Constante de programa"

    def _extract_error_handling(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extrai informações sobre tratamento de erros."""
        error_handling = []
        
        for line in lines:
            line = line.strip()
            
            # Procura por verificações de file status
            if "FILE" in line and "STATUS" in line and ("NOT" in line or "=" in line):
                error_handling.append({
                    "condition": "Erro de arquivo (file status)",
                    "action": "Verificar status e tomar ação apropriada"
                })
            
            # Procura por tratamento de SQLCODE (se houver)
            if "SQLCODE" in line:
                error_handling.append({
                    "condition": "Erro de banco de dados",
                    "action": "Verificar SQLCODE e tratar erro SQL"
                })
            
            # Procura por parágrafos de erro
            if re.match(r'^[A-Z0-9-]*ERRO[A-Z0-9-]*\.$', line):
                error_handling.append({
                    "condition": "Erro geral do programa",
                    "action": f"Executar rotina de erro: {line.replace('.', '')}"
                })
        
        return error_handling

    def _extract_performance_info(self, lines: List[str]) -> List[Dict[str, Any]]:
        """Extrai informações sobre considerações de performance."""
        performance = []
        
        # Procura por indicadores de performance nos comentários
        for line in lines:
            line = line.strip().upper()
            
            if "PARTICION" in line and ("4000" in line or "MB" in line):
                performance.append({
                    "aspect": "Particionamento de arquivos",
                    "details": "Arquivos são particionados em blocos de 4000 MB para otimizar performance"
                })
            
            if "LIMITE" in line and "PARTES" in line:
                performance.append({
                    "aspect": "Controle de partições",
                    "details": "Número de partições é controlado baseado no tipo de arquivo"
                })
            
            if "BLOCK" in line and "RECORDS" in line:
                performance.append({
                    "aspect": "Bloqueamento de registros",
                    "details": "Arquivos configurados com bloqueamento otimizado (BLOCK 0 RECORDS)"
                })
        
        return performance
