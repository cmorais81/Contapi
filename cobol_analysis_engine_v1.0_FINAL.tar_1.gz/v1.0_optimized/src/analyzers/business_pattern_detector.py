import re
import logging
from typing import Dict, Any, List, Set, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

class PatternType(Enum):
    VALIDATOR = "validator"
    CALCULATOR = "calculator"
    FORMATTER = "formatter"
    PARTITIONER = "partitioner"
    CONSOLIDATOR = "consolidator"
    TRANSFORMER = "transformer"
    CONTROLLER = "controller"
    REPORTER = "reporter"

@dataclass
class BusinessPattern:
    """Representa um padrão de negócio identificado."""
    pattern_type: PatternType
    pattern_name: str
    confidence: float  # 0.0 a 1.0
    description: str
    code_sections: List[Tuple[int, int]]  # (start_line, end_line)
    key_elements: List[str]
    modern_equivalent: str
    implementation_effort: str  # LOW, MEDIUM, HIGH
    business_value: str
    example_technologies: List[str]

@dataclass
class PatternSignature:
    """Assinatura de um padrão para detecção."""
    keywords: List[str]
    structures: List[str]
    operations: List[str]
    data_patterns: List[str]
    weight: float

class BusinessPatternDetector:
    """
    Detector de Padrões de Negócio
    
    Identifica padrões conhecidos de implementação em COBOL e sugere
    equivalentes modernos para facilitar modernização.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Base de conhecimento de padrões
        self.pattern_signatures = {
            PatternType.VALIDATOR: [
                PatternSignature(
                    keywords=['IF', 'INVALID', 'ERROR', 'VALID', 'CHECK'],
                    structures=['PIC 9', 'PIC X'],
                    operations=['MOVE', 'INSPECT', 'EVALUATE'],
                    data_patterns=['CPF', 'CNPJ', 'EMAIL', 'PHONE', 'DATE'],
                    weight=0.8
                ),
                PatternSignature(
                    keywords=['NUMERIC', 'ALPHABETIC', 'ALPHANUMERIC'],
                    structures=['88'],
                    operations=['TEST', 'VALIDATE'],
                    data_patterns=['RANGE', 'FORMAT', 'LENGTH'],
                    weight=0.7
                )
            ],
            PatternType.CALCULATOR: [
                PatternSignature(
                    keywords=['COMPUTE', 'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE'],
                    structures=['PIC 9', 'DECIMAL', 'COMP'],
                    operations=['ROUNDED', 'REMAINDER'],
                    data_patterns=['INTEREST', 'TAX', 'DISCOUNT', 'TOTAL'],
                    weight=0.9
                ),
                PatternSignature(
                    keywords=['FUNCTION', 'SUM', 'AVERAGE', 'MAX', 'MIN'],
                    structures=['OCCURS'],
                    operations=['VARYING', 'UNTIL'],
                    data_patterns=['ACCUMULATOR', 'COUNTER'],
                    weight=0.8
                )
            ],
            PatternType.FORMATTER: [
                PatternSignature(
                    keywords=['STRING', 'UNSTRING', 'INSPECT'],
                    structures=['PIC X', 'DELIMITED'],
                    operations=['REPLACING', 'TALLYING', 'CONVERTING'],
                    data_patterns=['MASK', 'TEMPLATE', 'FORMAT'],
                    weight=0.8
                ),
                PatternSignature(
                    keywords=['MOVE', 'CORRESPONDING', 'REDEFINES'],
                    structures=['GROUP', 'ELEMENTARY'],
                    operations=['JUSTIFIED', 'BLANK'],
                    data_patterns=['LAYOUT', 'RECORD'],
                    weight=0.7
                )
            ],
            PatternType.PARTITIONER: [
                PatternSignature(
                    keywords=['EVALUATE', 'IF', 'WHEN', 'SELECT'],
                    structures=['FILE', 'RECORD'],
                    operations=['WRITE', 'OPEN', 'CLOSE'],
                    data_patterns=['TYPE', 'CODE', 'CATEGORY'],
                    weight=0.9
                ),
                PatternSignature(
                    keywords=['SORT', 'MERGE', 'RELEASE', 'RETURN'],
                    structures=['SORT-FILE', 'WORK-FILE'],
                    operations=['ASCENDING', 'DESCENDING'],
                    data_patterns=['KEY', 'SEQUENCE'],
                    weight=0.8
                )
            ],
            PatternType.CONSOLIDATOR: [
                PatternSignature(
                    keywords=['PERFORM', 'UNTIL', 'READ', 'WRITE'],
                    structures=['CONTROL-BREAK', 'TOTAL'],
                    operations=['ACCUMULATE', 'SUMMARIZE'],
                    data_patterns=['GROUP', 'SUBTOTAL', 'GRANDTOTAL'],
                    weight=0.9
                ),
                PatternSignature(
                    keywords=['MERGE', 'MATCH', 'COMPARE'],
                    structures=['MULTIPLE-FILES'],
                    operations=['SEQUENCE', 'ORDER'],
                    data_patterns=['MASTER', 'TRANSACTION'],
                    weight=0.8
                )
            ]
        }
        
        # Mapeamento para tecnologias modernas
        self.modern_mappings = {
            PatternType.VALIDATOR: {
                'technologies': ['Spring Validation', 'Hibernate Validator', 'Apache Commons Validator'],
                'frameworks': ['Bean Validation (JSR-303)', 'JSON Schema', 'OpenAPI Validation'],
                'patterns': ['Strategy Pattern', 'Chain of Responsibility', 'Decorator Pattern']
            },
            PatternType.CALCULATOR: {
                'technologies': ['Apache Commons Math', 'BigDecimal', 'JScience'],
                'frameworks': ['Spring Expression Language', 'MVEL', 'JEXL'],
                'patterns': ['Strategy Pattern', 'Command Pattern', 'Visitor Pattern']
            },
            PatternType.FORMATTER: {
                'technologies': ['Apache Commons Lang', 'Jackson', 'JAXB'],
                'frameworks': ['Spring Converter', 'MapStruct', 'Dozer'],
                'patterns': ['Adapter Pattern', 'Template Method', 'Builder Pattern']
            },
            PatternType.PARTITIONER: {
                'technologies': ['Spring Batch', 'Apache Camel', 'Kafka Streams'],
                'frameworks': ['Spring Integration', 'Apache NiFi', 'Akka Streams'],
                'patterns': ['Splitter Pattern', 'Content-Based Router', 'Message Filter']
            },
            PatternType.CONSOLIDATOR: {
                'technologies': ['Spring Batch', 'Apache Spark', 'Hazelcast'],
                'frameworks': ['Spring Integration', 'Apache Flink', 'Kafka Streams'],
                'patterns': ['Aggregator Pattern', 'Scatter-Gather', 'Resequencer']
            }
        }

    def detect_patterns(self, program_name: str, code_lines: List[str], 
                       analysis_results: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Detecta padrões de negócio no código COBOL.
        """
        self.logger.info(f"Detectando padrões de negócio para {program_name}")
        
        code_text = '\n'.join(code_lines)
        
        # Detecta padrões por tipo
        detected_patterns = []
        
        for pattern_type, signatures in self.pattern_signatures.items():
            patterns = self._detect_pattern_type(pattern_type, signatures, code_lines, code_text)
            detected_patterns.extend(patterns)
        
        # Ordena por confiança
        detected_patterns.sort(key=lambda p: p.confidence, reverse=True)
        
        # Analisa combinações de padrões
        pattern_combinations = self._analyze_pattern_combinations(detected_patterns)
        
        # Gera recomendações de modernização
        modernization_recommendations = self._generate_modernization_recommendations(detected_patterns)
        
        # Calcula métricas
        pattern_metrics = self._calculate_pattern_metrics(detected_patterns)
        
        return {
            "program_name": program_name,
            "detected_patterns": detected_patterns,
            "pattern_combinations": pattern_combinations,
            "modernization_recommendations": modernization_recommendations,
            "pattern_metrics": pattern_metrics,
            "modernization_roadmap": self._generate_modernization_roadmap(detected_patterns)
        }

    def _detect_pattern_type(self, pattern_type: PatternType, signatures: List[PatternSignature],
                           code_lines: List[str], code_text: str) -> List[BusinessPattern]:
        """Detecta padrões de um tipo específico."""
        patterns = []
        
        for signature in signatures:
            confidence = self._calculate_pattern_confidence(signature, code_text)
            
            if confidence >= 0.5:  # Threshold mínimo
                # Identifica seções de código relacionadas
                code_sections = self._identify_pattern_sections(signature, code_lines)
                
                # Extrai elementos chave
                key_elements = self._extract_key_elements(signature, code_text)
                
                # Determina padrão específico
                specific_pattern = self._identify_specific_pattern(pattern_type, key_elements, code_text)
                
                # Mapeia para tecnologia moderna
                modern_mapping = self.modern_mappings.get(pattern_type, {})
                
                pattern = BusinessPattern(
                    pattern_type=pattern_type,
                    pattern_name=specific_pattern['name'],
                    confidence=confidence,
                    description=specific_pattern['description'],
                    code_sections=code_sections,
                    key_elements=key_elements,
                    modern_equivalent=specific_pattern['modern_equivalent'],
                    implementation_effort=specific_pattern['effort'],
                    business_value=specific_pattern['value'],
                    example_technologies=modern_mapping.get('technologies', [])
                )
                
                patterns.append(pattern)
        
        return patterns

    def _calculate_pattern_confidence(self, signature: PatternSignature, code_text: str) -> float:
        """Calcula confiança da detecção de um padrão."""
        confidence = 0.0
        code_upper = code_text.upper()
        
        # Pontuação por keywords
        keyword_score = 0
        for keyword in signature.keywords:
            if keyword in code_upper:
                keyword_score += 1
        keyword_confidence = min(1.0, keyword_score / len(signature.keywords))
        
        # Pontuação por estruturas
        structure_score = 0
        for structure in signature.structures:
            if structure in code_upper:
                structure_score += 1
        structure_confidence = min(1.0, structure_score / len(signature.structures)) if signature.structures else 0
        
        # Pontuação por operações
        operation_score = 0
        for operation in signature.operations:
            if operation in code_upper:
                operation_score += 1
        operation_confidence = min(1.0, operation_score / len(signature.operations)) if signature.operations else 0
        
        # Pontuação por padrões de dados
        data_score = 0
        for pattern in signature.data_patterns:
            if pattern in code_upper:
                data_score += 1
        data_confidence = min(1.0, data_score / len(signature.data_patterns)) if signature.data_patterns else 0
        
        # Combina pontuações com peso
        confidence = (
            keyword_confidence * 0.4 +
            structure_confidence * 0.3 +
            operation_confidence * 0.2 +
            data_confidence * 0.1
        ) * signature.weight
        
        return min(1.0, confidence)

    def _identify_pattern_sections(self, signature: PatternSignature, 
                                 code_lines: List[str]) -> List[Tuple[int, int]]:
        """Identifica seções de código que implementam o padrão."""
        sections = []
        current_section_start = None
        keyword_count = 0
        
        for i, line in enumerate(code_lines):
            line_upper = line.upper()
            
            # Conta keywords na linha
            line_keywords = sum(1 for keyword in signature.keywords if keyword in line_upper)
            
            if line_keywords > 0:
                if current_section_start is None:
                    current_section_start = i
                keyword_count += line_keywords
            else:
                # Se não há keywords e temos uma seção ativa
                if current_section_start is not None and keyword_count >= 2:
                    sections.append((current_section_start, i - 1))
                current_section_start = None
                keyword_count = 0
        
        # Fecha última seção se necessário
        if current_section_start is not None and keyword_count >= 2:
            sections.append((current_section_start, len(code_lines) - 1))
        
        return sections

    def _extract_key_elements(self, signature: PatternSignature, code_text: str) -> List[str]:
        """Extrai elementos chave do padrão."""
        elements = []
        
        # Extrai campos mencionados
        field_pattern = r'\b([A-Z][A-Z0-9-]*)\b'
        fields = set()
        
        for keyword in signature.keywords:
            # Procura por campos próximos às keywords
            keyword_pattern = rf'{keyword}\s+([A-Z][A-Z0-9-]*)'
            matches = re.finditer(keyword_pattern, code_text, re.IGNORECASE)
            for match in matches:
                fields.add(match.group(1))
        
        elements.extend(list(fields)[:5])  # Top 5 campos
        
        # Adiciona keywords encontradas
        for keyword in signature.keywords:
            if keyword in code_text.upper():
                elements.append(f"OPERATION_{keyword}")
        
        return elements

    def _identify_specific_pattern(self, pattern_type: PatternType, key_elements: List[str], 
                                 code_text: str) -> Dict[str, str]:
        """Identifica o padrão específico baseado nos elementos."""
        code_upper = code_text.upper()
        
        if pattern_type == PatternType.VALIDATOR:
            if any('CPF' in elem or 'CNPJ' in elem for elem in key_elements):
                return {
                    'name': 'Validador de CPF/CNPJ',
                    'description': 'Valida documentos brasileiros (CPF/CNPJ) usando algoritmo de dígito verificador',
                    'modern_equivalent': 'Biblioteca de validação de documentos (ex: caelum-stella)',
                    'effort': 'LOW',
                    'value': 'Reutilização de código validado e testado'
                }
            elif 'NUMERIC' in code_upper and 'RANGE' in ' '.join(key_elements):
                return {
                    'name': 'Validador de Faixa Numérica',
                    'description': 'Valida se valores numéricos estão dentro de faixas permitidas',
                    'modern_equivalent': 'Bean Validation com @Min/@Max ou @Range',
                    'effort': 'LOW',
                    'value': 'Validação declarativa e reutilizável'
                }
            else:
                return {
                    'name': 'Validador Genérico',
                    'description': 'Implementa validações de dados de entrada',
                    'modern_equivalent': 'Framework de validação (Bean Validation, Hibernate Validator)',
                    'effort': 'MEDIUM',
                    'value': 'Padronização e centralização de validações'
                }
        
        elif pattern_type == PatternType.CALCULATOR:
            if any('INTEREST' in elem or 'JUROS' in elem for elem in key_elements):
                return {
                    'name': 'Calculadora de Juros',
                    'description': 'Calcula juros simples ou compostos sobre valores',
                    'modern_equivalent': 'Biblioteca financeira (ex: QuantLib, JQuantLib)',
                    'effort': 'MEDIUM',
                    'value': 'Precisão matemática e algoritmos otimizados'
                }
            elif 'TAX' in ' '.join(key_elements) or 'IMPOSTO' in code_upper:
                return {
                    'name': 'Calculadora de Impostos',
                    'description': 'Calcula impostos baseado em regras fiscais',
                    'modern_equivalent': 'Engine de regras de negócio (Drools, Easy Rules)',
                    'effort': 'HIGH',
                    'value': 'Flexibilidade para mudanças de regras fiscais'
                }
            else:
                return {
                    'name': 'Calculadora Matemática',
                    'description': 'Realiza cálculos matemáticos complexos',
                    'modern_equivalent': 'Apache Commons Math ou BigDecimal nativo',
                    'effort': 'LOW',
                    'value': 'Precisão e performance melhoradas'
                }
        
        elif pattern_type == PatternType.PARTITIONER:
            if 'TYPE' in ' '.join(key_elements) or 'TIPO' in code_upper:
                return {
                    'name': 'Particionador por Tipo',
                    'description': 'Divide registros em arquivos diferentes baseado no tipo',
                    'modern_equivalent': 'Spring Batch Partitioner ou Kafka Streams',
                    'effort': 'MEDIUM',
                    'value': 'Processamento paralelo e escalabilidade'
                }
            elif 'DATE' in ' '.join(key_elements) or 'DATA' in code_upper:
                return {
                    'name': 'Particionador por Data',
                    'description': 'Organiza dados por períodos temporais',
                    'modern_equivalent': 'Apache Spark com particionamento temporal',
                    'effort': 'MEDIUM',
                    'value': 'Consultas otimizadas por período'
                }
            else:
                return {
                    'name': 'Particionador de Dados',
                    'description': 'Divide dados baseado em critérios específicos',
                    'modern_equivalent': 'Framework de processamento distribuído',
                    'effort': 'HIGH',
                    'value': 'Escalabilidade e performance'
                }
        
        elif pattern_type == PatternType.FORMATTER:
            if 'MASK' in ' '.join(key_elements) or 'MASCARA' in code_upper:
                return {
                    'name': 'Formatador com Máscara',
                    'description': 'Aplica máscaras de formatação a dados',
                    'modern_equivalent': 'Apache Commons Lang StringUtils ou DecimalFormat',
                    'effort': 'LOW',
                    'value': 'Formatação consistente e internacionalização'
                }
            else:
                return {
                    'name': 'Transformador de Dados',
                    'description': 'Converte dados entre diferentes formatos',
                    'modern_equivalent': 'MapStruct ou Dozer para mapeamento de objetos',
                    'effort': 'MEDIUM',
                    'value': 'Mapeamento type-safe e performance'
                }
        
        elif pattern_type == PatternType.CONSOLIDATOR:
            return {
                'name': 'Consolidador de Relatórios',
                'description': 'Agrega dados de múltiplas fontes em relatórios',
                'modern_equivalent': 'Spring Batch com ItemProcessor/ItemWriter',
                'effort': 'HIGH',
                'value': 'Processamento batch robusto e monitorável'
            }
        
        # Padrão genérico
        return {
            'name': f'{pattern_type.value.title()} Genérico',
            'description': f'Implementa funcionalidade de {pattern_type.value}',
            'modern_equivalent': 'Framework moderno equivalente',
            'effort': 'MEDIUM',
            'value': 'Modernização e manutenibilidade'
        }

    def _analyze_pattern_combinations(self, patterns: List[BusinessPattern]) -> List[Dict[str, Any]]:
        """Analisa combinações de padrões que trabalham juntos."""
        combinations = []
        
        # Procura por padrões que frequentemente trabalham juntos
        pattern_types = [p.pattern_type for p in patterns]
        
        # Validator + Calculator (comum em sistemas financeiros)
        if PatternType.VALIDATOR in pattern_types and PatternType.CALCULATOR in pattern_types:
            combinations.append({
                'name': 'Pipeline de Validação e Cálculo',
                'patterns': [PatternType.VALIDATOR, PatternType.CALCULATOR],
                'description': 'Valida dados de entrada antes de realizar cálculos',
                'modern_equivalent': 'Spring Boot com Bean Validation + Service Layer',
                'synergy': 'Garante integridade dos dados antes do processamento'
            })
        
        # Partitioner + Consolidator (comum em processamento batch)
        if PatternType.PARTITIONER in pattern_types and PatternType.CONSOLIDATOR in pattern_types:
            combinations.append({
                'name': 'Pipeline de Particionamento e Consolidação',
                'patterns': [PatternType.PARTITIONER, PatternType.CONSOLIDATOR],
                'description': 'Divide dados para processamento e depois consolida resultados',
                'modern_equivalent': 'Apache Spark ou Spring Batch com particionamento',
                'synergy': 'Processamento paralelo com agregação final'
            })
        
        # Formatter + Validator (comum em interfaces)
        if PatternType.FORMATTER in pattern_types and PatternType.VALIDATOR in pattern_types:
            combinations.append({
                'name': 'Pipeline de Formatação e Validação',
                'patterns': [PatternType.FORMATTER, PatternType.VALIDATOR],
                'description': 'Formata dados e valida o resultado',
                'modern_equivalent': 'Spring MVC com Converters e Validators',
                'synergy': 'Interface consistente com validação robusta'
            })
        
        return combinations

    def _generate_modernization_recommendations(self, patterns: List[BusinessPattern]) -> List[Dict[str, Any]]:
        """Gera recomendações específicas de modernização."""
        recommendations = []
        
        # Agrupa padrões por esforço
        low_effort = [p for p in patterns if p.implementation_effort == 'LOW']
        medium_effort = [p for p in patterns if p.implementation_effort == 'MEDIUM']
        high_effort = [p for p in patterns if p.implementation_effort == 'HIGH']
        
        if low_effort:
            recommendations.append({
                'priority': 'HIGH',
                'phase': 'Fase 1: Quick Wins',
                'patterns': len(low_effort),
                'effort': 'LOW',
                'description': 'Modernize padrões simples primeiro para ganhar experiência',
                'examples': [p.pattern_name for p in low_effort[:3]],
                'timeline': '2-4 semanas',
                'risk': 'BAIXO'
            })
        
        if medium_effort:
            recommendations.append({
                'priority': 'MEDIUM',
                'phase': 'Fase 2: Funcionalidades Core',
                'patterns': len(medium_effort),
                'effort': 'MEDIUM',
                'description': 'Modernize funcionalidades principais do sistema',
                'examples': [p.pattern_name for p in medium_effort[:3]],
                'timeline': '2-3 meses',
                'risk': 'MÉDIO'
            })
        
        if high_effort:
            recommendations.append({
                'priority': 'LOW',
                'phase': 'Fase 3: Transformação Completa',
                'patterns': len(high_effort),
                'effort': 'HIGH',
                'description': 'Modernize padrões complexos com maior impacto',
                'examples': [p.pattern_name for p in high_effort[:3]],
                'timeline': '6-12 meses',
                'risk': 'ALTO'
            })
        
        return recommendations

    def _calculate_pattern_metrics(self, patterns: List[BusinessPattern]) -> Dict[str, Any]:
        """Calcula métricas dos padrões detectados."""
        total_patterns = len(patterns)
        
        if total_patterns == 0:
            return {"total_patterns": 0}
        
        # Distribuição por tipo
        by_type = {}
        for pattern in patterns:
            pattern_type = pattern.pattern_type.value
            by_type[pattern_type] = by_type.get(pattern_type, 0) + 1
        
        # Distribuição por esforço
        by_effort = {'LOW': 0, 'MEDIUM': 0, 'HIGH': 0}
        for pattern in patterns:
            by_effort[pattern.implementation_effort] += 1
        
        # Confiança média
        avg_confidence = sum(p.confidence for p in patterns) / total_patterns
        
        # Padrões de alta confiança (>= 0.8)
        high_confidence = len([p for p in patterns if p.confidence >= 0.8])
        
        return {
            "total_patterns": total_patterns,
            "by_type": by_type,
            "by_effort": by_effort,
            "average_confidence": round(avg_confidence, 3),
            "high_confidence_patterns": high_confidence,
            "modernization_readiness": self._calculate_modernization_readiness(patterns)
        }

    def _calculate_modernization_readiness(self, patterns: List[BusinessPattern]) -> str:
        """Calcula prontidão para modernização baseada nos padrões."""
        if not patterns:
            return "LOW"
        
        # Pontuação baseada em confiança e facilidade de implementação
        score = 0
        for pattern in patterns:
            confidence_points = pattern.confidence * 10
            
            effort_points = {
                'LOW': 3,
                'MEDIUM': 2,
                'HIGH': 1
            }[pattern.implementation_effort]
            
            score += confidence_points * effort_points
        
        avg_score = score / len(patterns)
        
        if avg_score >= 20:
            return "HIGH"
        elif avg_score >= 10:
            return "MEDIUM"
        else:
            return "LOW"

    def _generate_modernization_roadmap(self, patterns: List[BusinessPattern]) -> Dict[str, Any]:
        """Gera roadmap de modernização baseado nos padrões."""
        roadmap = {
            "phases": [],
            "total_timeline": "6-18 meses",
            "estimated_effort": "MEDIUM-HIGH",
            "success_factors": []
        }
        
        # Fase 1: Padrões simples
        low_effort_patterns = [p for p in patterns if p.implementation_effort == 'LOW']
        if low_effort_patterns:
            roadmap["phases"].append({
                "phase": 1,
                "name": "Modernização de Padrões Simples",
                "duration": "1-2 meses",
                "patterns": len(low_effort_patterns),
                "focus": "Validadores, Formatadores, Calculadoras simples",
                "deliverables": ["Bibliotecas de validação", "Utilitários de formatação", "Serviços de cálculo"],
                "risk": "BAIXO"
            })
        
        # Fase 2: Padrões médios
        medium_effort_patterns = [p for p in patterns if p.implementation_effort == 'MEDIUM']
        if medium_effort_patterns:
            roadmap["phases"].append({
                "phase": 2,
                "name": "Modernização de Funcionalidades Core",
                "duration": "3-6 meses",
                "patterns": len(medium_effort_patterns),
                "focus": "Particionadores, Transformadores, Integrações",
                "deliverables": ["Serviços de processamento", "APIs de integração", "Pipelines de dados"],
                "risk": "MÉDIO"
            })
        
        # Fase 3: Padrões complexos
        high_effort_patterns = [p for p in patterns if p.implementation_effort == 'HIGH']
        if high_effort_patterns:
            roadmap["phases"].append({
                "phase": 3,
                "name": "Transformação Arquitetural",
                "duration": "6-12 meses",
                "patterns": len(high_effort_patterns),
                "focus": "Consolidadores, Controladores, Sistemas complexos",
                "deliverables": ["Arquitetura de microserviços", "Plataforma de dados", "Sistema modernizado"],
                "risk": "ALTO"
            })
        
        # Fatores de sucesso
        roadmap["success_factors"] = [
            "Equipe com conhecimento em COBOL e tecnologias modernas",
            "Ambiente de desenvolvimento e teste robusto",
            "Estratégia de migração incremental",
            "Testes automatizados abrangentes",
            "Monitoramento e observabilidade"
        ]
        
        return roadmap

    def generate_patterns_report(self, patterns_analysis: Dict[str, Any]) -> str:
        """Gera relatório de padrões em formato Markdown."""
        program_name = patterns_analysis["program_name"]
        patterns = patterns_analysis["detected_patterns"]
        combinations = patterns_analysis["pattern_combinations"]
        recommendations = patterns_analysis["modernization_recommendations"]
        metrics = patterns_analysis["pattern_metrics"]
        roadmap = patterns_analysis["modernization_roadmap"]
        
        report = [
            f"# 🧠 Padrões de Negócio Detectados - {program_name}",
            "",
            "##  Resumo Executivo",
            f"- **Padrões Identificados:** {metrics['total_patterns']}",
            f"- **Confiança Média:** {metrics['average_confidence']*100:.1f}%",
            f"- **Padrões de Alta Confiança:** {metrics['high_confidence_patterns']}",
            f"- **Prontidão para Modernização:** {metrics['modernization_readiness']}",
            "",
            "##  Padrões Detectados",
            ""
        ]
        
        for i, pattern in enumerate(patterns, 1):
            confidence_pct = f"{pattern.confidence*100:.1f}%"
            sections_info = f"{len(pattern.code_sections)} seções" if pattern.code_sections else "Código distribuído"
            
            report.extend([
                f"### {i}. {pattern.pattern_name}",
                f"**Tipo:** {pattern.pattern_type.value.title()}  ",
                f"**Confiança:** {confidence_pct}  ",
                f"**Localização:** {sections_info}  ",
                f"**Descrição:** {pattern.description}  ",
                "",
                f"** Equivalente Moderno:** {pattern.modern_equivalent}  ",
                f"** Esforço de Implementação:** {pattern.implementation_effort}  ",
                f"** Valor de Negócio:** {pattern.business_value}  ",
                "",
                "** Tecnologias Sugeridas:**"
            ])
            
            for tech in pattern.example_technologies[:3]:  # Top 3
                report.append(f"- {tech}")
            
            if pattern.key_elements:
                report.extend([
                    "",
                    "**🔑 Elementos Chave:**",
                    f"- {', '.join(pattern.key_elements[:5])}"  # Top 5
                ])
            
            report.append("")
        
        # Combinações de padrões
        if combinations:
            report.extend([
                "## 🔗 Combinações de Padrões",
                ""
            ])
            
            for combo in combinations:
                pattern_names = [pt.value.title() for pt in combo['patterns']]
                report.extend([
                    f"### {combo['name']}",
                    f"**Padrões:** {' + '.join(pattern_names)}  ",
                    f"**Descrição:** {combo['description']}  ",
                    f"**Equivalente Moderno:** {combo['modern_equivalent']}  ",
                    f"**Sinergia:** {combo['synergy']}  ",
                    ""
                ])
        
        # Recomendações de modernização
        report.extend([
            "##  Roadmap de Modernização",
            ""
        ])
        
        for rec in recommendations:
            report.extend([
                f"### {rec['phase']} - Prioridade {rec['priority']}",
                f"**Padrões:** {rec['patterns']}  ",
                f"**Esforço:** {rec['effort']}  ",
                f"**Timeline:** {rec['timeline']}  ",
                f"**Risco:** {rec['risk']}  ",
                f"**Descrição:** {rec['description']}  ",
                "",
                "**Exemplos:**"
            ])
            
            for example in rec['examples']:
                report.append(f"- {example}")
            
            report.append("")
        
        # Roadmap detalhado
        if roadmap['phases']:
            report.extend([
                "## 📅 Plano de Implementação Detalhado",
                ""
            ])
            
            for phase in roadmap['phases']:
                report.extend([
                    f"### Fase {phase['phase']}: {phase['name']}",
                    f"**Duração:** {phase['duration']}  ",
                    f"**Padrões:** {phase['patterns']}  ",
                    f"**Foco:** {phase['focus']}  ",
                    f"**Risco:** {phase['risk']}  ",
                    "",
                    "**Entregas:**"
                ])
                
                for deliverable in phase['deliverables']:
                    report.append(f"- {deliverable}")
                
                report.append("")
        
        # Fatores de sucesso
        report.extend([
            "##  Fatores Críticos de Sucesso",
            ""
        ])
        
        for factor in roadmap['success_factors']:
            report.append(f"- {factor}")
        
        report.extend([
            "",
            "##  Próximos Passos Recomendados",
            "",
            "1. **Validar Padrões:** Revisar padrões identificados com especialistas",
            "2. **Priorizar Quick Wins:** Começar com padrões de baixo esforço",
            "3. **Preparar Ambiente:** Configurar ferramentas de desenvolvimento modernas",
            "4. **Formar Equipe:** Treinar desenvolvedores nas tecnologias sugeridas",
            "5. **Implementar Piloto:** Escolher um padrão simples para prova de conceito",
            "6. **Medir Resultados:** Definir métricas de sucesso da modernização",
            ""
        ])
        
        return "\n".join(report)
