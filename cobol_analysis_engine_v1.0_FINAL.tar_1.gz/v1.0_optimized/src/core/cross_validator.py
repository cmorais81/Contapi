#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Sistema de Análise COBOL - Cross Validator
Sistema de validação cruzada e resolução de conflitos entre análises.
"""

import logging
import re
import json
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from collections import Counter
import difflib


@dataclass
class ValidationResult:
    """Resultado da validação cruzada."""
    consensus_scores: Dict[str, float]
    conflicts: List[Dict[str, Any]]
    resolved_conflicts: List[Dict[str, Any]]
    overall_confidence: float
    validation_summary: Dict[str, Any]


@dataclass
class ConflictResolution:
    """Resultado da resolução de um conflito."""
    conflict_id: str
    original_conflict: Dict[str, Any]
    resolution_method: str
    resolved_value: Any
    confidence: float
    reasoning: str


class CrossValidator:
    """Sistema de validação cruzada entre análises."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        validation_config = config.get("cross_validation", {})
        self.consensus_threshold = validation_config.get("consensus_threshold", 0.75)
        self.conflict_threshold = validation_config.get("conflict_threshold", 0.3)
        self.min_agreement_ratio = validation_config.get("min_agreement_ratio", 0.6)
        
        self.domain_weights = validation_config.get("domain_weights", {
            "structural": 0.25,
            "business": 0.35,
            "technical": 0.25,
            "quality": 0.15
        })
        
        # self.conflict_resolver = ConflictResolver(config)
        
        self.logger.info("Cross Validator inicializado")
    
    async def validate_analyses(self, analysis_results: List[Dict[str, Any]]) -> ValidationResult:
        """
        Valida consistência entre análises das análises.
        
        Args:
            analysis_results: Lista de resultados das análises
            
        Returns:
            Resultado da validação cruzada
        """
        try:
            self.logger.info("Iniciando validação cruzada entre análises")

            if not isinstance(analysis_results, list):
                self.logger.error(f"Formato de entrada inválido para validação cruzada: esperado 'list', recebido '{type(analysis_results)}'")
                return self._create_error_result("Formato de entrada inválido")

            successful_results = {item["ai_name"]: item for item in analysis_results}
            
            if len(successful_results) < 2:
                return self._create_insufficient_data_result(successful_results)
            
            consensus_scores = self._calculate_consensus_scores(successful_results)
            conflicts = self._identify_conflicts(successful_results, consensus_scores)
            # resolved_conflicts = await self._resolve_conflicts(conflicts, successful_results)
            resolved_conflicts = [] # Placeholder
            
            overall_confidence = self._calculate_overall_confidence(
                consensus_scores, resolved_conflicts, successful_results
            )
            
            validation_summary = self._create_validation_summary(
                successful_results, consensus_scores, conflicts, resolved_conflicts
            )
            
            result = ValidationResult(
                consensus_scores=consensus_scores,
                conflicts=conflicts,
                resolved_conflicts=resolved_conflicts,
                overall_confidence=overall_confidence,
                validation_summary=validation_summary
            )
            
            self.logger.info(f"Validação cruzada concluída - Confiança: {overall_confidence:.2%}")
            return result
            
        except Exception as e:
            self.logger.error(f"Erro na validação cruzada: {str(e)}", exc_info=True)
            return self._create_error_result(str(e))

    def _calculate_consensus_scores(self, results: Dict[str, Any]) -> Dict[str, float]:
        """Calcula scores de consenso entre as análises."""
        
        comparable_elements = self._extract_comparable_elements(results)
        consensus_scores = {}
        
        for element_type, element_data in comparable_elements.items():
            if len(element_data) >= 2:
                consensus_score = self._calculate_element_consensus(element_data)
                consensus_scores[element_type] = consensus_score
            else:
                consensus_scores[element_type] = 0.5
        
        return consensus_scores

    def _extract_comparable_elements(self, results: Dict[str, Any]) -> Dict[str, List]:
        """Extrai elementos comparáveis das análises."""
        
        comparable_elements = {
            "program_structure": [],
            "business_rules": [],
            "technical_complexity": [],
            "quality_assessment": [],
            "confidence_levels": []
        }
        
        for ai_name, result in results.items():
            analysis = result.get("analysis", {})
            
            if "divisions_identified" in analysis:
                comparable_elements["program_structure"].append({
                    "ai": ai_name,
                    "value": analysis["divisions_identified"]
                })
            
            if "business_rules_count" in analysis:
                comparable_elements["business_rules"].append({
                    "ai": ai_name,
                    "value": analysis["business_rules_count"]
                })
            
            if "algorithm_complexity" in analysis:
                comparable_elements["technical_complexity"].append({
                    "ai": ai_name,
                    "value": analysis["algorithm_complexity"]
                })
            
            quality_scores = [analysis[key] for key in ["structural_quality", "overall_quality", "performance_score"] if key in analysis]
            if quality_scores:
                comparable_elements["quality_assessment"].append({
                    "ai": ai_name,
                    "value": sum(quality_scores) / len(quality_scores)
                })
            
            if "confidence" in result:
                comparable_elements["confidence_levels"].append({
                    "ai": ai_name,
                    "value": result["confidence"]
                })
        
        return comparable_elements

    def _calculate_element_consensus(self, element_data: List[Dict]) -> float:
        if len(element_data) < 2: return 0.5
        values = [item["value"] for item in element_data]
        if all(isinstance(v, (int, float)) for v in values): return self._calculate_numeric_consensus(values)
        if all(isinstance(v, list) for v in values): return self._calculate_list_consensus(values)
        if all(isinstance(v, str) for v in values): return self._calculate_string_consensus(values)
        return self._calculate_string_consensus([str(v) for v in values])

    def _calculate_numeric_consensus(self, values: List[float]) -> float:
        if not values: return 0.0
        mean_val = sum(values) / len(values)
        if mean_val == 0: return 1.0 if all(v == 0 for v in values) else 0.0
        variance = sum((v - mean_val) ** 2 for v in values) / len(values)
        std_dev = variance ** 0.5
        cv = std_dev / abs(mean_val)
        return max(0.0, min(1.0, 1.0 - cv))

    def _calculate_list_consensus(self, lists: List[List]) -> float:
        if not lists: return 0.0
        all_items = set()
        common_items = set(lists[0]) if lists else set()
        for lst in lists:
            lst_set = set(lst)
            all_items.update(lst_set)
            common_items.intersection_update(lst_set)
        if not all_items: return 1.0
        return len(common_items) / len(all_items)

    def _calculate_string_consensus(self, strings: List[str]) -> float:
        if not strings: return 0.0
        if len(strings) == 1: return 1.0
        similarities = [difflib.SequenceMatcher(None, strings[i], strings[j]).ratio() for i in range(len(strings)) for j in range(i + 1, len(strings))]
        return sum(similarities) / len(similarities) if similarities else 0.0

    def _identify_conflicts(self, results: Dict[str, Any], consensus_scores: Dict[str, float]) -> List[Dict[str, Any]]:
        conflicts = []
        for element_type, consensus_score in consensus_scores.items():
            if consensus_score < self.conflict_threshold:
                conflicting_values = self._extract_conflicting_values(results, element_type)
                conflict = {
                    "id": f"conflict_{len(conflicts) + 1}",
                    "element_type": element_type,
                    "consensus_score": consensus_score,
                    "severity": self._determine_conflict_severity(consensus_score),
                    "conflicting_values": conflicting_values,
                    "affected_ais": list(conflicting_values.keys()) if conflicting_values else []
                }
                conflicts.append(conflict)
        return conflicts

    def _extract_conflicting_values(self, results: Dict[str, Any], element_type: str) -> Dict[str, Any]:
        conflicting_values = {}
        field_mapping = {
            "program_structure": "divisions_identified",
            "business_rules": "business_rules_count",
            "technical_complexity": "algorithm_complexity",
            "quality_assessment": ["structural_quality", "overall_quality", "performance_score"],
            "confidence_levels": "confidence"
        }
        field = field_mapping.get(element_type)
        if not field: return {}

        for ai_name, result in results.items():
            analysis = result.get("analysis", {})
            if isinstance(field, list):
                values = [analysis[f] for f in field if f in analysis]
                if values: conflicting_values[ai_name] = sum(values) / len(values)
            elif field == "confidence":
                if "confidence" in result: conflicting_values[ai_name] = result["confidence"]
            else:
                if field in analysis: conflicting_values[ai_name] = analysis[field]
        return conflicting_values

    def _determine_conflict_severity(self, consensus_score: float) -> str:
        if consensus_score < 0.1: return "critical"
        if consensus_score < 0.2: return "high"
        if consensus_score < 0.3: return "medium"
        return "low"

    def _calculate_overall_confidence(self, consensus_scores: Dict[str, float], resolved_conflicts: List[Dict[str, Any]], results: Dict[str, Any]) -> float:
        if not consensus_scores: return 0.0
        
        weighted_consensus, total_weight = 0.0, 0.0
        for element_type, consensus_score in consensus_scores.items():
            weight = self.domain_weights.get(element_type, 0.25)
            weighted_consensus += consensus_score * weight
            total_weight += weight
        
        base_confidence = weighted_consensus / total_weight if total_weight > 0 else 0.0
        unresolved_conflicts = sum(1 for rc in resolved_conflicts if rc.get("status") != "resolved")
        conflict_penalty = unresolved_conflicts * 0.05
        agreement_bonus = min(0.1, (len(results) - 1) * 0.02)
        
        return max(0.0, min(1.0, base_confidence - conflict_penalty + agreement_bonus))

    def _create_validation_summary(self, results: Dict[str, Any], consensus_scores: Dict[str, float], conflicts: List[Dict[str, Any]], resolved_conflicts: List[Dict[str, Any]]) -> Dict[str, Any]:
        return {
            "total_ais_analyzed": len(results),
            "consensus_elements": len(consensus_scores),
            "high_consensus_elements": sum(1 for s in consensus_scores.values() if s >= self.consensus_threshold),
            "total_conflicts": len(conflicts),
            "resolved_conflicts": sum(1 for rc in resolved_conflicts if rc.get("status") == "resolved"),
        }

    def _create_insufficient_data_result(self, results: Dict[str, Any]) -> ValidationResult:
        self.logger.warning(f"Validação cruzada não pôde ser executada: {len(results)} resultado(s) bem-sucedido(s) (mínimo 2)")
        return ValidationResult({}, [], [], 0.25, {"message": "Dados insuficientes"})

    def _create_error_result(self, error_message: str) -> ValidationResult:
        return ValidationResult({}, [], [], 0.0, {"error": error_message})

# Dummy ConflictResolver for now
class ConflictResolver:
    def __init__(self, config):
        pass
    async def resolve_conflict(self, conflict, results):
        return None

