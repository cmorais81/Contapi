# COBOL Analysis Engine v1.0

Uma ferramenta poderosa para análise e documentação de programas COBOL utilizando múltiplos provedores de IA.

## Características Principais

- **Análise Multi-AI:** Utiliza múltiplos provedores de IA para análises especializadas
- **Relatórios Detalhados:** Gera documentação completa e bem formatada
- **Sistema de Logging Avançado:** Registra métricas detalhadas e eventos de execução
- **Arquitetura Modular:** Facilmente extensível para novos provedores e funcionalidades
- **Suporte a Copybooks:** Integra informações de copybooks na análise

## Instalação

1. Extraia o arquivo do projeto
2. Configure as variáveis de ambiente necessárias (ex: `OPENAI_API_KEY`)
3. Execute o sistema conforme descrito no manual

## Uso Básico

```bash
python3.11 main.py programa.cbl -o resultados/ -m multi_ai
```

## Documentação

- **Manual do Usuário:** `docs/MANUAL_USUARIO.md`
- **CHANGELOG:** `CHANGELOG.md`
- **Relatório Final:** `RELATORIO_FINAL_v1.0.md`

## Estrutura do Projeto

```
├── main.py                 # Script principal
├── config/                 # Arquivos de configuração
├── src/                    # Código fonte
│   ├── core/              # Componentes principais
│   ├── providers/         # Provedores de IA
│   ├── generators/        # Geradores de relatórios
│   └── utils/             # Utilitários
├── examples/              # Programas COBOL de exemplo
├── analysis_results/      # Resultados das análises
├── logs/                  # Arquivos de log
└── docs/                  # Documentação

```

## Provedores Suportados

- OpenAI (GPT-4)
- LuzIA (Santander)
- AWS Bedrock
- Databricks
- GitHub Copilot
- Enhanced Mock (para testes)

## Versão

v1.0.0 - Setembro 2025

## Licença

Este projeto foi desenvolvido como parte de um sistema de análise COBOL corporativo.
