#!/usr/bin/env python3
"""
Sistema de Análise COBOL Multi-AI v1.0 - Enhanced Version
Sistema principal com análise funcional aprimorada
"""

import os
import sys
import argparse
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, Optional

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.config.config_loader import load_config
from src.extractors.content_extractor import COBOLContentExtractor
from src.core.multi_ai_orchestrator import MultiAIOrchestrator
from src.providers.provider_manager import ProviderManager
from src.generators.functional_documentation_generator import FunctionalDocumentationGenerator
from src.generators.detailed_report_generator import DetailedReportGenerator
from src.core.cross_validator import CrossValidator
from src.core.clarity_engine import ClarityEngine
from src.utils.enhanced_logger import EnhancedAnalysisLogger

class EnhancedCOBOLAnalysisSystem:
    """Sistema principal de análise COBOL com funcionalidades aprimoradas"""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """Inicializa o sistema de análise"""
        
        # Carregar configuração
        self.config = load_config(config_path)
        
        # Configurar logging
        self._setup_logging()
        
        # Inicializar componentes
        self.content_extractor = COBOLContentExtractor()
        self.provider_manager = ProviderManager(self.config)
        self.orchestrator = MultiAIOrchestrator(self.config)
        self.functional_generator = FunctionalDocumentationGenerator()
        self.detailed_generator = DetailedReportGenerator()
        self.cross_validator = CrossValidator(self.config)
        self.clarity_engine = ClarityEngine(self.config)
        self.logger = EnhancedAnalysisLogger(self.config)
        
        logging.info("Sistema Enhanced COBOL Analysis inicializado")
    
    def _setup_logging(self):
        """Configura o sistema de logging"""
        
        log_level = self.config.get('logging', {}).get('level', 'INFO')
        log_file = self.config.get('logging', {}).get('file', 'logs/cobol_analysis.log')
        
        # Criar diretório de logs se não existir
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
        logging.basicConfig(
            level=getattr(logging, log_level),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
    
    async def analyze_single_program(self, file_path: str, output_dir: str, mode: str = "multi_ai") -> Dict[str, Any]:
        """Analisa um programa COBOL individual"""
        
        program_name = os.path.splitext(os.path.basename(file_path))[0]
        
        # Iniciar logging da análise
        self.logger.start_analysis(program_name, "individual")
        
        try:
            # Extrair conteúdo
            with open(file_path, 'r', encoding='utf-8') as f:
                cobol_code = f.read()
            
            extracted_data = self.content_extractor.extract_from_content(cobol_code, program_name)
            
            # Executar análise baseada no modo
            if mode == "multi_ai":
                # Análise Multi-AI
                orchestration_result = await self.orchestrator.analyze_program(
                    cobol_code, program_name, []  # copybooks como lista vazia
                )
                
                # Validação cruzada
                validation_result = await self.cross_validator.validate_analyses(
                    list(orchestration_result.get('parallel_results', {}).values())
                )
                
                # Análise de clareza
                clarity_result = self.clarity_engine.analyze_clarity(orchestration_result, "developer")
                
                # Gerar documentação funcional aprimorada
                documentation = self.functional_generator.generate_comprehensive_documentation(
                    program_name, cobol_code, extracted_data, orchestration_result
                )
                
                # Log dos resultados
                self.logger.log_analysis_result("multi_ai", orchestration_result)
                self.logger.log_validation_result(validation_result)
                self.logger.log_clarity_result(clarity_result)
                
            else:
                # Análise tradicional
                documentation = self.detailed_generator.generate(
                    extracted_data, program_name
                )
                
                orchestration_result = None
                validation_result = None
                clarity_result = None
            
            # Salvar documentação
            os.makedirs(output_dir, exist_ok=True)
            output_file = os.path.join(output_dir, f"{program_name}_FUNCTIONAL_ANALYSIS.md")
            
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(documentation)
            
            # Finalizar logging
            logging.info(f"Análise de {program_name} concluída com sucesso")
            
            result = {
                'program_name': program_name,
                'output_file': output_file,
                'mode': mode,
                'success': True,
                'extracted_data': extracted_data,
                'orchestration_result': orchestration_result,
                'validation_result': validation_result,
                'clarity_result': clarity_result
            }
            
            print(f"✅ Análise concluída: {program_name}")
            print(f"📄 Relatório: {output_file}")
            
            return result
            
        except Exception as e:
            logging.error(f"Erro na análise de {program_name}: {str(e)}")
            print(f"❌ Erro na análise de {program_name}: {str(e)}")
            raise
    
    def extract_programs_from_fontes(self, fontes_path: str) -> Dict[str, str]:
        """Extrai programas individuais do arquivo fontes.txt"""
        
        programs = {}
        current_program = None
        current_content = []
        
        with open(fontes_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.rstrip()
                
                # Identificar início de novo programa
                if line.startswith('VMEMBER NAME '):
                    # Salvar programa anterior se existir
                    if current_program and current_content:
                        programs[current_program] = '\n'.join(current_content)
                    
                    # Extrair nome do novo programa
                    current_program = line.split('VMEMBER NAME ')[1].strip()
                    current_content = []
                    
                elif current_program:
                    current_content.append(line)
            
            # Salvar último programa
            if current_program and current_content:
                programs[current_program] = '\n'.join(current_content)
        
        return programs
    
    async def analyze_batch(self, fontes_path: str, output_dir: str, books_path: Optional[str] = None, mode: str = "multi_ai") -> Dict[str, Any]:
        """Analisa múltiplos programas do arquivo fontes.txt"""
        
        # Iniciar logging do batch
        logging.info("Iniciando processamento em lote")
        
        try:
            # Extrair programas
            programs = self.extract_programs_from_fontes(fontes_path)
            
            print(f"📁 Encontrados {len(programs)} programas em {fontes_path}")
            for name in programs.keys():
                print(f"  - {name}")
            
            # Processar copybooks se fornecido
            copybooks = {}
            if books_path and os.path.exists(books_path):
                copybooks = self.content_extractor.extract_copybooks_from_file(books_path)
                print(f"📚 Carregados {len(copybooks)} copybooks")
            
            # Analisar cada programa
            results = {}
            
            for program_name, program_content in programs.items():
                print(f"\n🔍 Analisando {program_name}...")
                
                try:
                    # Extrair dados do programa
                    extracted_data = self.content_extractor.extract_from_content(program_content, program_name)
                    
                    # Executar análise baseada no modo
                    if mode == "multi_ai":
                        # Análise Multi-AI
                        orchestration_result = await self.orchestrator.analyze_program(
                            program_content, program_name, copybooks
                        )
                        
                        # Validação cruzada
                        validation_result = await self.cross_validator.validate_analyses(
                            list(orchestration_result.get('parallel_results', {}).values())
                        )
                        
                        # Análise de clareza
                        clarity_result = self.clarity_engine.analyze_clarity(orchestration_result, "developer")
                        
                        # Gerar documentação funcional
                        documentation = self.functional_generator.generate_comprehensive_documentation(
                            program_name, program_content, extracted_data, orchestration_result
                        )
                        
                    else:
                        # Análise tradicional
                        documentation = self.detailed_generator.generate(
                            extracted_data, program_name
                        )
                        
                        orchestration_result = None
                        validation_result = None
                        clarity_result = None
                    
                    # Salvar documentação
                    os.makedirs(output_dir, exist_ok=True)
                    output_file = os.path.join(output_dir, f"{program_name}_FUNCTIONAL_ANALYSIS.md")
                    
                    with open(output_file, 'w', encoding='utf-8') as f:
                        f.write(documentation)
                    
                    results[program_name] = {
                        'success': True,
                        'output_file': output_file,
                        'mode': mode,
                        'extracted_data': extracted_data,
                        'orchestration_result': orchestration_result,
                        'validation_result': validation_result,
                        'clarity_result': clarity_result
                    }
                    
                    print(f"✅ {program_name} concluído")
                    
                except Exception as e:
                    print(f"❌ Erro em {program_name}: {str(e)}")
                    results[program_name] = {
                        'success': False,
                        'error': str(e)
                    }
            
            # Gerar relatório de resumo
            summary_report = self._generate_batch_summary(results, fontes_path, books_path, mode)
            summary_file = os.path.join(output_dir, "BATCH_PROCESSING_SUMMARY.md")
            
            with open(summary_file, 'w', encoding='utf-8') as f:
                f.write(summary_report)
            
            # Finalizar logging
            logging.info("Processamento em lote concluído com sucesso")
            
            print(f"\n🎉 Processamento em lote concluído!")
            print(f"📊 Resumo: {summary_file}")
            
            return {
                'success': True,
                'total_programs': len(programs),
                'successful_analyses': len([r for r in results.values() if r.get('success')]),
                'failed_analyses': len([r for r in results.values() if not r.get('success')]),
                'results': results,
                'summary_file': summary_file
            }
            
        except Exception as e:
            logging.error(f"Erro no processamento em lote: {str(e)}")
            print(f"❌ Erro no processamento em lote: {str(e)}")
            raise
    
    def _generate_batch_summary(self, results: Dict, fontes_path: str, books_path: Optional[str], mode: str) -> str:
        """Gera relatório de resumo do processamento em lote"""
        
        successful = [r for r in results.values() if r.get('success')]
        failed = [r for r in results.values() if not r.get('success')]
        
        summary = f"""# Relatório de Processamento em Lote

**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M')}  
**Arquivo Fonte:** {fontes_path}  
**Copybooks:** {books_path if books_path else 'Não fornecido'}  
**Modo de Análise:** {mode}

## 📊 Resumo Estatístico

- **Total de Programas:** {len(results)}
- **Análises Bem-sucedidas:** {len(successful)}
- **Análises com Falha:** {len(failed)}
- **Taxa de Sucesso:** {(len(successful)/len(results)*100):.1f}%

## ✅ Programas Analisados com Sucesso

"""
        
        for program_name, result in results.items():
            if result.get('success'):
                summary += f"- **{program_name}** → `{os.path.basename(result['output_file'])}`\n"
        
        if failed:
            summary += f"\n## ❌ Programas com Falha\n\n"
            for program_name, result in results.items():
                if not result.get('success'):
                    summary += f"- **{program_name}** → {result.get('error', 'Erro desconhecido')}\n"
        
        summary += f"""
## 🔧 Configuração Utilizada

- **Modo:** {mode}
- **Análise Funcional:** {'Ativada' if mode == 'multi_ai' else 'Desativada'}
- **Análise de Lógica de Negócio:** {'Ativada' if mode == 'multi_ai' else 'Desativada'}
- **Análise de Fluxo de Dados:** {'Ativada' if mode == 'multi_ai' else 'Desativada'}

---

*Relatório gerado automaticamente pelo Sistema Enhanced COBOL Analysis v1.0*
"""
        
        return summary

def main():
    """Função principal"""
    
    parser = argparse.ArgumentParser(description='Sistema Enhanced COBOL Analysis v1.0')
    parser.add_argument('file_path', help='Caminho para arquivo COBOL (.cbl) ou fontes.txt')
    parser.add_argument('-o', '--output', default='enhanced_results', help='Diretório de saída')
    parser.add_argument('-b', '--books', help='Caminho para arquivo BOOKS.txt (copybooks)')
    parser.add_argument('-m', '--mode', choices=['multi_ai', 'traditional'], default='multi_ai', 
                       help='Modo de análise')
    parser.add_argument('-c', '--config', default='config/config.yaml', help='Arquivo de configuração')
    parser.add_argument('-v', '--verbose', action='store_true', help='Saída detalhada')
    
    args = parser.parse_args()
    
    # Configurar verbosidade
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    try:
        # Inicializar sistema
        system = EnhancedCOBOLAnalysisSystem(args.config)
        
        # Determinar tipo de processamento
        if args.file_path.endswith('.cbl') or not args.file_path.endswith('.txt'):
            # Análise individual
            print(f"🔍 Iniciando análise individual: {args.file_path}")
            print(f"📁 Modo: {args.mode}")
            
            result = asyncio.run(system.analyze_single_program(
                args.file_path, args.output, args.mode
            ))
            
        else:
            # Processamento em lote
            print(f"📦 Iniciando processamento em lote: {args.file_path}")
            print(f"📁 Modo: {args.mode}")
            
            result = asyncio.run(system.analyze_batch(
                args.file_path, args.output, args.books, args.mode
            ))
        
        print(f"\n🎉 Processamento concluído com sucesso!")
        
    except KeyboardInterrupt:
        print("\n⚠️ Processamento interrompido pelo usuário")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Erro durante o processamento: {str(e)}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
