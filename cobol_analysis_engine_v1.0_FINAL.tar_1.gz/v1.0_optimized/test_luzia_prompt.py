#!/usr/bin/env python3
import sys
import os
sys.path.append('src')

from providers.luzia_provider import LuziaProvider

# Configuração de teste
config = {
    'luzia': {
        'client_id': 'test_client',
        'client_secret': 'test_secret',
        'auth_url': 'https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token',
        'api_url': 'https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/',
        'model': 'azure-gpt-4o-mini',
        'temperature': 0.1
    },
    'ssl': {
        'verify': True
    },
    'logging': {
        'dir': 'logs'
    }
}

# Criar pasta de logs
os.makedirs('logs', exist_ok=True)

# Criar provider
provider = LuziaProvider(config)

# Prompt de teste
test_prompt = """
Analise o seguinte programa COBOL e forneça uma análise detalhada:

IDENTIFICATION DIVISION.
PROGRAM-ID. TESTE-PROGRAMA.
AUTHOR. DESENVOLVEDOR.

ENVIRONMENT DIVISION.
INPUT-OUTPUT SECTION.
FILE-CONTROL.
    SELECT ARQUIVO-ENTRADA ASSIGN TO 'ENTRADA.DAT'.

DATA DIVISION.
FILE SECTION.
FD ARQUIVO-ENTRADA.
01 REGISTRO-ENTRADA.
   05 CAMPO-ID     PIC 9(5).
   05 CAMPO-NOME   PIC X(30).

WORKING-STORAGE SECTION.
01 WS-CONTADOR      PIC 9(3) VALUE ZERO.

PROCEDURE DIVISION.
INICIO.
    OPEN INPUT ARQUIVO-ENTRADA.
    PERFORM UNTIL WS-CONTADOR = 100
        READ ARQUIVO-ENTRADA
        ADD 1 TO WS-CONTADOR
    END-PERFORM.
    CLOSE ARQUIVO-ENTRADA.
    STOP RUN.
"""

print("Testando LuzIA Provider - Gerando log de prompt...")
result = provider.analyze(test_prompt)
print(f"Resultado: {result}")
print("Log de prompt salvo em logs/luzia_prompts.log")
