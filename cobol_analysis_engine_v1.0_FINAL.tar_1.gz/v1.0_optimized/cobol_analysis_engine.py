#!/usr/bin/env python3
"""
Sistema de Análise COBOL v1.0.0 - Interface para Notebooks
Interface simplificada para uso em Jupyter Notebooks e scripts Python.
"""

import os
import sys
import asyncio
from typing import Dict, Any, List, Optional

# Adicionar o diretório atual ao path
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

from main import UnifiedAnalysisEngine

class COBOLAnalyzer:
    """Interface simplificada para análise COBOL em notebooks."""
    
    def __init__(self, provider: str = 'enhanced_mock', config_file: str = None):
        """
        Inicializa o analisador COBOL.
        
        Args:
            provider: Provider de IA a ser usado
            config_file: Arquivo de configuração (opcional)
        """
        self.provider = provider
        self.config_file = config_file or os.path.join(current_dir, 'config', 'config.yaml')
        self.engine = UnifiedAnalysisEngine()
        self.engine.analysis_mode = 'multi_ai'
        self.engine.provider = provider
        
    def analyze_code(self, cobol_code: str, program_name: str = "PROGRAMA") -> Dict[str, Any]:
        """
        Analisa código COBOL diretamente.
        
        Args:
            cobol_code: Código COBOL como string
            program_name: Nome do programa
            
        Returns:
            Resultado da análise
        """
        try:
            # Criar arquivo temporário
            temp_file = f"/tmp/{program_name}.cbl"
            with open(temp_file, 'w', encoding='utf-8') as f:
                f.write(cobol_code)
            
            # Analisar arquivo
            result = asyncio.run(self.engine.analyze_programs(
                [temp_file], 
                None, 
                "/tmp/analysis_results"
            ))
            
            # Limpar arquivo temporário
            if os.path.exists(temp_file):
                os.remove(temp_file)
            
            # Ler documentação gerada
            doc_file = f"/tmp/analysis_results/{program_name}_MULTI_AI_ANALYSIS.md"
            documentation = ""
            if os.path.exists(doc_file):
                with open(doc_file, 'r', encoding='utf-8') as f:
                    documentation = f.read()
            
            return {
                'success': result.get('success', True),
                'program_name': program_name,
                'provider_used': self.provider,
                'documentation': documentation,
                'metadata': result
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'program_name': program_name,
                'provider_used': self.provider
            }
    
    def analyze_file(self, file_path: str) -> Dict[str, Any]:
        """
        Analisa arquivo COBOL.
        
        Args:
            file_path: Caminho para o arquivo COBOL
            
        Returns:
            Resultado da análise
        """
        try:
            if not os.path.exists(file_path):
                return {
                    'success': False,
                    'error': f'Arquivo não encontrado: {file_path}'
                }
            
            program_name = os.path.splitext(os.path.basename(file_path))[0]
            
            result = asyncio.run(self.engine.analyze_programs(
                [file_path], 
                None, 
                "/tmp/analysis_results"
            ))
            
            # Ler documentação gerada
            doc_file = f"/tmp/analysis_results/{program_name}_MULTI_AI_ANALYSIS.md"
            documentation = ""
            if os.path.exists(doc_file):
                with open(doc_file, 'r', encoding='utf-8') as f:
                    documentation = f.read()
            
            return {
                'success': result.get('success', True),
                'program_name': program_name,
                'provider_used': self.provider,
                'documentation': documentation,
                'file_path': file_path,
                'metadata': result
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'file_path': file_path,
                'provider_used': self.provider
            }
    
    def analyze_multiple_files(self, file_paths: List[str]) -> Dict[str, Dict[str, Any]]:
        """
        Analisa múltiplos arquivos COBOL.
        
        Args:
            file_paths: Lista de caminhos para arquivos COBOL
            
        Returns:
            Dicionário com resultados por arquivo
        """
        results = {}
        
        for file_path in file_paths:
            program_name = os.path.splitext(os.path.basename(file_path))[0]
            results[program_name] = self.analyze_file(file_path)
        
        return results
    
    def analyze_directory(self, directory: str, extensions: List[str] = None) -> Dict[str, Dict[str, Any]]:
        """
        Analisa todos os arquivos COBOL em um diretório.
        
        Args:
            directory: Diretório a ser analisado
            extensions: Extensões de arquivo a considerar
            
        Returns:
            Dicionário com resultados por arquivo
        """
        if extensions is None:
            extensions = ['.cbl', '.cob', '.cobol']
        
        if not os.path.exists(directory):
            return {}
        
        cobol_files = []
        for root, dirs, files in os.walk(directory):
            for file in files:
                if any(file.lower().endswith(ext) for ext in extensions):
                    cobol_files.append(os.path.join(root, file))
        
        return self.analyze_multiple_files(cobol_files)
    
    def get_available_providers(self) -> List[str]:
        """Retorna lista de provedores disponíveis."""
        return ['enhanced_mock', 'openai', 'luzia', 'bedrock', 'databricks', 'github_copilot']
    
    def get_provider_status(self) -> Dict[str, Any]:
        """Retorna status dos provedores."""
        try:
            # Usar o status checker do sistema
            from src.utils.status_checker import StatusChecker
            checker = StatusChecker()
            return checker.get_system_status()
        except Exception as e:
            return {
                'error': str(e),
                'providers': {},
                'total_providers': 0,
                'available_providers': 0
            }
    
    def set_provider(self, provider: str) -> bool:
        """
        Altera o provedor de IA.
        
        Args:
            provider: Nome do provedor
            
        Returns:
            True se alterado com sucesso
        """
        available_providers = self.get_available_providers()
        if provider in available_providers:
            self.provider = provider
            self.engine.provider = provider
            return True
        return False
    
    def get_current_provider(self) -> str:
        """Retorna o provedor atual."""
        return self.provider
    
    def generate_report(self, results: Dict[str, Dict[str, Any]], 
                       output_file: str, format: str = 'markdown') -> bool:
        """
        Gera relatório consolidado.
        
        Args:
            results: Resultados das análises
            output_file: Arquivo de saída
            format: Formato do relatório ('markdown' ou 'pdf')
            
        Returns:
            True se gerado com sucesso
        """
        try:
            if format.lower() == 'markdown':
                return self._generate_markdown_report(results, output_file)
            elif format.lower() == 'pdf':
                return self._generate_pdf_report(results, output_file)
            else:
                return False
        except Exception as e:
            print(f"Erro ao gerar relatório: {e}")
            return False
    
    def _generate_markdown_report(self, results: Dict[str, Dict[str, Any]], output_file: str) -> bool:
        """Gera relatório em Markdown."""
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write("# Relatório de Análise COBOL\n\n")
                f.write(f"**Data**: {os.popen('date').read().strip()}\n")
                f.write(f"**Total de programas**: {len(results)}\n\n")
                
                for program_name, result in results.items():
                    f.write(f"## {program_name}\n\n")
                    
                    if result.get('success'):
                        f.write("**Status**: ✅ Sucesso\n")
                        f.write(f"**Provider**: {result.get('provider_used', 'N/A')}\n\n")
                        
                        documentation = result.get('documentation', '')
                        if documentation:
                            f.write("### Documentação\n\n")
                            f.write(documentation)
                            f.write("\n\n")
                    else:
                        f.write("**Status**: ❌ Erro\n")
                        f.write(f"**Erro**: {result.get('error', 'Erro desconhecido')}\n\n")
                    
                    f.write("---\n\n")
            
            return True
        except Exception as e:
            print(f"Erro ao gerar relatório Markdown: {e}")
            return False
    
    def _generate_pdf_report(self, results: Dict[str, Dict[str, Any]], output_file: str) -> bool:
        """Gera relatório em PDF."""
        try:
            # Primeiro gerar Markdown
            md_file = output_file.replace('.pdf', '.md')
            if not self._generate_markdown_report(results, md_file):
                return False
            
            # Tentar converter para PDF usando weasyprint
            try:
                import weasyprint
                html_content = f"""
                <html>
                <head>
                    <meta charset="utf-8">
                    <style>
                        body {{ font-family: Arial, sans-serif; margin: 40px; }}
                        h1, h2, h3 {{ color: #333; }}
                        pre {{ background: #f5f5f5; padding: 10px; }}
                    </style>
                </head>
                <body>
                """
                
                # Converter Markdown para HTML básico
                with open(md_file, 'r', encoding='utf-8') as f:
                    md_content = f.read()
                
                # Conversão simples MD -> HTML
                html_content += md_content.replace('\n# ', '\n<h1>').replace('\n## ', '\n<h2>')
                html_content += "</body></html>"
                
                weasyprint.HTML(string=html_content).write_pdf(output_file)
                return True
                
            except ImportError:
                print("WeasyPrint não disponível. Relatório PDF não pode ser gerado.")
                return False
                
        except Exception as e:
            print(f"Erro ao gerar relatório PDF: {e}")
            return False


# ============================================================================
# FUNÇÕES DE CONVENIÊNCIA PARA NOTEBOOKS
# ============================================================================

def analyze_cobol(cobol_code: str, provider: str = 'enhanced_mock') -> Dict[str, Any]:
    """
    Função de conveniência para análise rápida de código COBOL.
    
    Args:
        cobol_code: Código COBOL como string
        provider: Provider de IA a ser usado
        
    Returns:
        Resultado da análise
    """
    analyzer = COBOLAnalyzer(provider=provider)
    return analyzer.analyze_code(cobol_code)

def analyze_cobol_file(file_path: str, provider: str = 'enhanced_mock') -> Dict[str, Any]:
    """
    Função de conveniência para análise de arquivo COBOL.
    
    Args:
        file_path: Caminho para o arquivo COBOL
        provider: Provider de IA a ser usado
        
    Returns:
        Resultado da análise
    """
    analyzer = COBOLAnalyzer(provider=provider)
    return analyzer.analyze_file(file_path)

def create_analyzer(provider: str = 'enhanced_mock', config_file: str = None) -> COBOLAnalyzer:
    """
    Cria uma instância do analisador COBOL.
    
    Args:
        provider: Provider de IA a ser usado
        config_file: Arquivo de configuração (opcional)
        
    Returns:
        Instância do COBOLAnalyzer
    """
    return COBOLAnalyzer(provider=provider, config_file=config_file)

def list_providers():
    """Lista os provedores de IA disponíveis."""
    providers = ['enhanced_mock', 'openai', 'luzia', 'bedrock', 'databricks', 'github_copilot']
    
    print("🤖 Provedores de IA Disponíveis:")
    print("-" * 40)
    
    for provider in providers:
        if provider == 'enhanced_mock':
            print(f"✅ {provider} (sempre disponível)")
        else:
            print(f"⚙️  {provider} (requer configuração)")

def quick_start_guide():
    """Mostra guia rápido de uso."""
    
    print("""
🚀 GUIA RÁPIDO - Sistema de Análise COBOL v1.0.0
===============================================

1. ANÁLISE SIMPLES:
   
   import cobol_analysis_engine as cae
   
   codigo = '''
   IDENTIFICATION DIVISION.
   PROGRAM-ID. HELLO.
   PROCEDURE DIVISION.
   DISPLAY 'Hello World'.
   STOP RUN.
   '''
   
   resultado = cae.analyze_cobol(codigo)
   print(resultado['documentation'])

2. ANÁLISE DE ARQUIVO:
   
   resultado = cae.analyze_cobol_file('programa.cbl')

3. USO AVANÇADO:
   
   analyzer = cae.create_analyzer(provider='enhanced_mock')
   resultados = analyzer.analyze_directory('/caminho/cobol/')

4. PROVEDORES DISPONÍVEIS:
   
   cae.list_providers()

5. GERAR RELATÓRIO:
   
   analyzer.generate_report(resultados, 'relatorio.md', format='markdown')

📝 DICA: Use 'enhanced_mock' para testes (sempre funciona)
🔧 CONFIGURAÇÃO: Configure credenciais para provedores reais
    """)

# Exportar funções principais
__all__ = [
    'COBOLAnalyzer',
    'analyze_cobol',
    'analyze_cobol_file', 
    'create_analyzer',
    'list_providers',
    'quick_start_guide'
]

if __name__ == "__main__":
    quick_start_guide()
