# Documentação Funcional: MZAN6056

**Programa:** MZAN6056  
**Autor:** Não especificado  
**Data de Criação:** Não especificado  
**Tipo:** Programa COBOL  
**Data da Análise:** 20/09/2025 10:28

---

## 📋 Resumo Executivo

**Função Principal:** * OBJETIVOS DO PROGRAMA:                                         * *    - RECUPERAR INFORMACOES DA OPERACAO NO MQ12 DO MES ANTERIOR * ****************************************************************** * ALTERACOES:                                                    * * -------------------------------------------------------------- * 

**Complexidade do Programa:**
- **Regras de Negócio:** 5 regras identificadas
- **Arquivos Processados:** 0 arquivos
- **Etapas de Processamento:** 2 seções principais
- **Fluxos de Dados:** 0 fluxos mapeados

**Estratégia de Processamento:** Processamento sequencial

**Contexto:** Sistema mainframe

## 🎯 Objetivo do Programa

### Propósito Principal
* OBJETIVOS DO PROGRAMA:                                         * *    - RECUPERAR INFORMACOES DA OPERACAO NO MQ12 DO MES ANTERIOR * ****************************************************************** * ALTERACOES:                                                    * * -------------------------------------------------------------- * 

### Descrição Detalhada
* OBJETIVOS DO PROGRAMA:                                         * *    - RECUPERAR INFORMACOES DA OPERACAO NO MQ12 DO MES ANTERIOR * ****************************************************************** * ALTERACOES:                                                    * * -------------------------------------------------------------- * 

### Contexto de Negócio
Sistema mainframe

### Estratégia de Processamento
Processamento sequencial

## 🔄 Fluxo de Processamento Detalhado

### 1. Etapa 1

**Descrição:** Início do processamento

**Entradas:** Arquivos de entrada

**Saídas:** Processamento iniciado

### 2. Etapa 2

**Descrição:** WRITE - WRITE  REG-S1DQ6056  FROM  REG-E1DQ6056...

**Entradas:** Dados do arquivo

**Saídas:** Dados processados

## 📋 Regras de Negócio Críticas

### Critérios de Roteamento

**1. Movimentação de dados: MOVE  QT-DIA-ATR-MZ13    TO QT-ATR-ACO-MES-ANT-600...**
- **Tipo:** routing
- **Condição:** MOVE  QT-DIA-ATR-MZ13    TO QT-ATR-ACO-MES-ANT-6001.

**2. Movimentação de dados: MOVE  PC-AMO-RENEG-MZ13  TO PC-PAG-ACO-MES-ANT-600...**
- **Tipo:** routing
- **Condição:** MOVE  PC-AMO-RENEG-MZ13  TO PC-PAG-ACO-MES-ANT-6001.

**3. Movimentação de dados: MOVE  IN-ACORDO-MZ13     TO ST-ACD-MES-ANT-6001....**
- **Tipo:** routing
- **Condição:** MOVE  IN-ACORDO-MZ13     TO ST-ACD-MES-ANT-6001.

**4. Movimentação de dados: SPRT28     MOVE  QT-PARC-PAG-ACD-MZ13 TO PAR-PAG-A...**
- **Tipo:** routing
- **Condição:** SPRT28     MOVE  QT-PARC-PAG-ACD-MZ13 TO PAR-PAG-ACD-MES-ANT-6001.

**5. Movimentação de dados: CMP05      MOVE  CD-RGR-RAT-OPE-MZ13  TO CD-RGR-RA...**
- **Tipo:** routing
- **Condição:** CMP05      MOVE  CD-RGR-RAT-OPE-MZ13  TO CD-RGR-RAT-OPE-ANT-6001.

### Controles de Processamento

**1. Controle de fluxo: PERFORM  800-00-INICIALIZA....**
- **Tipo:** control
- **Condição:** PERFORM  800-00-INICIALIZA.

**2. Controle de fluxo: PERFORM  100-00-PROCESSAMENTO...**
- **Tipo:** control
- **Condição:** PERFORM  100-00-PROCESSAMENTO

**3. Controle de fluxo: PERFORM  700-00-FINALIZA....**
- **Tipo:** control
- **Condição:** PERFORM  700-00-FINALIZA.

**4. Controle de fluxo: PERFORM  110-00-MOVER-CAMPOS...**
- **Tipo:** control
- **Condição:** PERFORM  110-00-MOVER-CAMPOS

**5. Controle de fluxo: PERFORM  500-00-GRAVA-S1DQ6056...**
- **Tipo:** control
- **Condição:** PERFORM  500-00-GRAVA-S1DQ6056

## 📊 Análise de Fluxo de Dados

### Arquivos Processados

### Transformações de Dados

**Move:** 68 operações

- Copia valor de QT-DIA-ATR-MZ13 para QT-ATR-ACO-MES-ANT-6001

- Copia valor de PC-AMO-RENEG-MZ13 para PC-PAG-ACO-MES-ANT-6001

- Copia valor de IN-ACORDO-MZ13 para ST-ACD-MES-ANT-6001

- ... e mais 65 operações

**Add:** 3 operações

- Adiciona 1 ao valor de AC

- Adiciona 1 ao valor de AC

- Adiciona 1 ao valor de AC

### Critérios de Roteamento de Dados

**Campo de Decisão:** CD
**Tipo:** value_based
**Regras:**
- AA → MOVE 09       TO  CD-RAT-REF-6001
**Ação Padrão:** Nenhuma ação definida

**Campo de Decisão:** CD
**Tipo:** value_based
**Regras:**
- AA → CMP05                      MOVE 09       TO  CD-CLF-MESANT-6001; CMP05                WHEN 'A '; CMP05                      MOVE 08       TO  CD-CLF-MESANT-6001; CMP05                WHEN 'B '; CMP05                      MOVE 07       TO  CD-CLF-MESANT-6001; CMP05                WHEN 'C '; CMP05                      MOVE 06       TO  CD-CLF-MESANT-6001; CMP05                WHEN 'D '; CMP05                      MOVE 05       TO  CD-CLF-MESANT-6001; CMP05                WHEN 'E '; CMP05                      MOVE 04       TO  CD-CLF-MESANT-6001; CMP05                WHEN 'F '; CMP05                      MOVE 03       TO  CD-CLF-MESANT-6001; CMP05                WHEN 'G '; CMP05                      MOVE 02       TO  CD-CLF-MESANT-6001; CMP05                WHEN 'H '; CMP05                      MOVE 01       TO  CD-CLF-MESANT-6001; CMP05                WHEN    OTHER; CMP05                      MOVE 99       TO  CD-CLF-MESANT-6001; CMP05              END-IF; CMP05      END-IF.; 630-99-EXIT.; EXIT.; ******************************************************************; *           F   I   N   A   L   I   Z   A   C   A   O            *; ******************************************************************; 700-00-FINALIZA  SECTION.; CLOSE  E1DQ6056; E2DQ6056; S1DQ6056.; DISPLAY '*********************************************'; DISPLAY 'REGISTROS LIDOS E1DQ6056 .....: ' AC-LIDOS-E1DQ6056; DISPLAY 'REGISTROS LIDOS E2DQ6056 .....: ' AC-LIDOS-E2DQ6056; DISPLAY 'REGISTROS GRAVADOS ...........: ' AC-GRAVADOS; DISPLAY '*********************************************'; DISPLAY '*** PROGRAMA MZAN6055 ***'.; DISPLAY '***  TERMINO  NORMAL  ***'.; DISPLAY '*************************'.; STOP RUN.; 700-99-EXIT.; EXIT.; EJECT; ******************************************************************; *       I   N   I   C   I   A   L   I   Z   A   C   A   O        *; ******************************************************************; 800-00-INICIALIZA  SECTION.; MOVE  FUNCTION  CURRENT-DATE  TO  WS-CURRENT-DATE.; MOVE  WS-SYSTEM-DATE-YYYY     TO  WS-DATA-SIST-AAAA; MOVE  WS-SYSTEM-DATE-MM       TO  WS-DATA-SIST-MM; MOVE  WS-SYSTEM-DATE-DD       TO  WS-DATA-SIST-DD; MOVE  WS-SYSTEM-TIME-HH       TO  WS-HORA-SIST-HH; MOVE  WS-SYSTEM-TIME-MM       TO  WS-HORA-SIST-MM; MOVE  WS-SYSTEM-TIME-SS       TO  WS-HORA-SIST-SS.; MOVE  WHEN-COMPILED           TO  WS-COMPILATION-DATE; MOVE  WS-COMP-DATE-MM         TO  WS-DATA-COMP-MM; MOVE  WS-COMP-DATE-DD         TO  WS-DATA-COMP-DD; MOVE  WS-COMP-DATE-YY         TO  WS-DATA-COMP-AA; DISPLAY '**************************************'; DISPLAY '*         PROGRAMA  MZAN6056         *'; DISPLAY '**************************************'; DISPLAY '*  DATA DO SISTEMA ....: ' WS-DATA-SIST '  *'; DISPLAY '*  HORA DO SISTEMA ....: ' WS-HORA-SIST '    *'; DISPLAY '*  DATA DE COMPILACAO .: ' WS-DATA-COMP '    *'; DISPLAY '*  HORA DE COMPILACAO .: ' WS-COMP-TIME '    *'; DISPLAY '**************************************'; OPEN  INPUT   E1DQ6056; E2DQ6056; OUTPUT  S1DQ6056.; PERFORM  610-00-LE-E1DQ6056.; IF  WS-CHAVE-E1DQ6056 EQUAL HIGH-VALUES; DISPLAY  '*********************************'; DISPLAY  '**  A  T  E  N  C  A  O  !  !  **'; DISPLAY  '*********************************'; DISPLAY  'ARQUIVO E1DQ6056 VAZIO'; DISPLAY  '*********************'; DISPLAY  '* PROGRAMA MZAN6055 *'; SPRT31         DISPLAY  '*  TERMINO  NORMAL  *'; DISPLAY  '*********************'; SPRT31         PERFORM  700-00-FINALIZA; SPRT31*        PERFORM  900-00-FIM-ANORMAL; END-IF.; PERFORM  620-00-LE-E2DQ6056.; IF  WS-CHAVE-E2DQ6056 EQUAL HIGH-VALUES; DISPLAY  '*********************************'; DISPLAY  '**  A  T  E  N  C  A  O  !  !  **'; DISPLAY  '*********************************'; DISPLAY  'ARQUIVO E2DQ6056 VAZIO'; DISPLAY  '*********************'; DISPLAY  '* PROGRAMA MZAN6056 *'; DISPLAY  '*  TERMINO ANORMAL  *'; DISPLAY  '*********************'; PERFORM  900-00-FIM-ANORMAL; END-IF.; 800-99-FIM.; EXIT.; EJECT; ******************************************************************; *   T   E   R   M   I   N   O        A   N   O   R   M   A   L   *; ******************************************************************; 900-00-FIM-ANORMAL SECTION.; CLOSE  E1DQ6056; E2DQ6056; S1DQ6056.; MOVE  4444  TO  RETURN-CODE.; STOP  RUN.; 900-99-EXIT.; EXIT.
**Ação Padrão:** Nenhuma ação definida

## 🤖 Análise Estrutural (IA)

### Structural

**Resumo:** ```json
{
  "structure_mapping": {
    "IDENTIFICATION DIVISION": {
      "PROGRAM-ID": "MZAN6056",
      "COMMENTS": [
        "CMP01 * CRISTIANE   22/07/2014  ACERTO ERRO FINANCEIRA",
        "CMP01 * T520Q6S     01/10/2014  CAMPOS NOVOS FLUXO FINANCEIRO",
        "CMP04 * CRISTIANE   21/11/2019  EXPANSAO DO BOOK 6001",
        "PLARD * CABRAL      24/06/2025  INCLUSAO PLARD ON01 - O1"
      ]
    },
    "ENVIRONMENT DIVISION": {
      "CONFIGURATION SECTION": {},
      "INPUT-OUTPUT SECTION":...

**Recomendações:**

## ⚡ Análise de Performance e Volumetria

### Gargalos Identificados

- **Transformações Múltiplas:** 71 transformações por registro

- **Controle de Volumetria:** Particionamento automático implementado

### Oportunidades de Otimização

- **Cache de Transformações:** Otimizar transformações repetitivas

## 🔗 Dependências e Recursos Externos

### Recursos de Arquivos

### Recursos de Sistema

- **Memória:** Controlada via working-storage

- **Disco:** Múltiplos arquivos de entrada/saída

- **CPU:** Processamento sequencial

## 💡 Recomendações

### Manutenibilidade

- **Modularização:** Considerar quebrar transformações em módulos menores

### Performance

### Qualidade de Código

- **Validações:** Considerar adicionar mais validações de entrada

---

*Documentação gerada automaticamente pelo Sistema de Análise COBOL Multi-AI*  
*Data: 20/09/2025 às 10:28*  
*Versão: Functional Documentation Generator v1.0*