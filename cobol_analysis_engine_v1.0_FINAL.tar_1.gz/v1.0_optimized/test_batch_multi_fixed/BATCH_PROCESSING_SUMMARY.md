# Relatório de Processamento em Lote - COBOL Analysis Engine

**Data:** 20/09/2025 09:06:02  
**Total de Programas:** 5  
**Sucessos:** 0  
**Falhas:** 5  
**Taxa de Sucesso:** 0.0%  

---

## Programas Processados com Sucesso


## Programas com Falha

- **LHAN0542**: Erro ao processar LHAN0542: name 'file_path' is not defined
- **LHAN0705**: Erro ao processar LHAN0705: name 'file_path' is not defined
- **LHAN0706**: Erro ao processar LHAN0706: name 'file_path' is not defined
- **LHBR0700**: Erro ao processar LHBR0700: name 'file_path' is not defined
- **MZAN6056**: Erro ao processar MZAN6056: name 'file_path' is not defined

---

*Processamento concluído em test_batch_multi_fixed/*
