# CHANGELOG - COBOL Analysis Engine v1.0

## v1.0.0 - 2025-09-20

### Adicionado

- **Suporte Multi-AI:** Implementado suporte para múltiplos provedores de IA (OpenAI, LuzIA, Bedrock, Databricks, GitHub Copilot) com orquestração paralela.
- **Análises Especializadas:** Adicionado sistema de análises especializadas por domínio (estrutural, negócio, técnico, modelo de dados, qualidade).
- **Sistema de Logging Aprimorado:** Implementado um novo sistema de logging que registra métricas detalhadas, uso de provedores e erros em arquivos separados e em formato JSON.
- **Gerador de Relatórios Aprimorado:** O gerador de relatórios foi refatorado para criar documentação mais completa e bem formatada, com seções de resumo executivo, métricas e análises detalhadas.
- **Manual do Usuário:** Criado um manual do usuário completo com instruções de configuração, execução e extensibilidade.
- **CHANGELOG:** Adicionado este arquivo para documentar as mudanças em cada versão.

### Corrigido

- **Integração de Copybooks:** Otimizado o processamento de copybooks para evitar timeouts e melhorar a integração das informações na análise.
- **Chamadas de API:** Corrigido problemas com chamadas assíncronas aos provedores de IA, garantindo que as análises sejam executadas corretamente.
- **Erros de Execução:** Corrigido diversos erros de execução, incluindo `AttributeError`, `TypeError`, `NameError` e `IndentationError`.
- **Configuração:** Corrigido problemas com o carregamento e a estrutura do arquivo de configuração `config.yaml`.
- **Importações:** Corrigido problemas com importações relativas que impediam a execução do modo `multi_ai`.

### Alterado

- **Estrutura do Projeto:** A estrutura do projeto foi reorganizada para melhorar a modularidade e a manutenibilidade.
- **Fluxo de Análise:** O fluxo de análise foi refatorado para integrar o sistema de logging aprimorado e o novo gerador de relatórios.

---

## Histórico de Versões Anteriores

### [v1.0.0 - VERSÃO OTIMIZADA] - 2025-09-19

- Sistema completamente otimizado e funcional com 6 provedores de IA essenciais.
- Estratégia Multi-IA otimizada com 6 análises especializadas e validação cruzada.
- Extração completa de informações de programas COBOL e copybooks.
- Relatórios funcionais e técnicos detalhados.
- Logging detalhado de execução e prompts.
- Configuração SSL global.

### [1.0.3] - 2025-09-19

- Correções críticas de configuração e relatórios.
- Simplificação do `config.yaml` e carregamento de variáveis de ambiente.
- Geração de relatórios corrigida para forçar o uso do gerador híbrido.

### [1.0.2] - 2025-09-19

- Correções críticas na configuração SSL e no processamento de múltiplos programas.
- Status detalhado dos provedores com diagnóstico de erros.
- Extração de conteúdo corrigida para incluir o código completo dos programas.

### [1.0.1] - 2025-09-19

- Adicionado suporte a certificados SSL personalizados para provedores corporativos.
- Logging de prompts para visualização completa do que é enviado aos LLMs.
- Provedor LuzIA corrigido com base em implementação funcional.
- Remoção de ícones e emojis da documentação e interface.

### [1.0.0] - 2025-09-19

- Versão inicial com script principal unificado, análise Multi-IA, validação cruzada e garantia de clareza na documentação.

