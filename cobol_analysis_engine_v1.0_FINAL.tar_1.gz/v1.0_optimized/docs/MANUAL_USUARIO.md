# Manual do Usuário - COBOL Analysis Engine v1.0

## 1. Introdução

Bem-vindo ao **COBOL Analysis Engine**, uma ferramenta poderosa para análise e documentação de programas COBOL. Este manual fornece um guia completo para configurar, executar e entender os resultados gerados pelo sistema.

### 1.1. Visão Geral

O sistema foi projetado para:

- **Analisar programas COBOL** e extrair informações estruturais e de negócio.
- **Utilizar múltiplos provedores de IA** para obter análises especializadas em diferentes domínios (estrutural, negócio, técnico, etc.).
- **Gerar relatórios detalhados** e bem formatados em Markdown.
- **Integrar informações de copybooks** para enriquecer a análise.
- **Fornecer um sistema de logging robusto** para auditoria e depuração.

### 1.2. Arquitetura do Sistema

O sistema é composto pelos seguintes módulos principais:

- **Extrator de Conteúdo:** Responsável por ler e parsear arquivos COBOL e copybooks.
- **Orquestrador Multi-AI:** Gerencia a execução de análises em paralelo com múltiplos provedores de IA.
- **Gerenciador de Provedores:** Carrega e gerencia os provedores de IA configurados.
- **Gerador de Relatórios:** Cria a documentação final em Markdown.
- **Sistema de Logging:** Registra todas as operações e métricas da análise.

---

## 2. Configuração

O sistema é configurado através do arquivo `config/config.yaml`. Esta seção detalha as principais opções de configuração.

### 2.1. Configuração Geral

- `mode`: Define o modo de operação. Pode ser `multi_ai` ou `traditional`.
- `logging`:
  - `log_dir`: Diretório para salvar os arquivos de log.
  - `level`: Nível de log (DEBUG, INFO, WARNING, ERROR).

### 2.2. Configuração dos Provedores de IA

- `ai.providers`:
  - `name`: Nome do provedor (ex: `openai`, `luzia`).
  - `enabled`: `true` para habilitar, `false` para desabilitar.
  - `api_key`: Chave de API do provedor (pode ser uma variável de ambiente).
  - `model`: Modelo de IA a ser utilizado.

### 2.3. Configuração das IAs Especializadas

- `ai.specialized_ais`:
  - `structural`: Provedor para análise estrutural.
  - `business`: Provedor para análise de regras de negócio.
  - `technical`: Provedor para análise técnica.
  - `data_model`: Provedor para análise de modelo de dados.
  - `quality`: Provedor para análise de qualidade.

---

## 3. Execução

O sistema pode ser executado através da linha de comando.

### 3.1. Comando de Execução

```bash
python3.11 main.py <caminho_para_arquivo_cobol> -o <diretorio_de_saida> -m <modo>
```

- `<caminho_para_arquivo_cobol>`: Caminho para o arquivo COBOL a ser analisado.
- `-o <diretorio_de_saida>`: Diretório onde os relatórios serão salvos.
- `-m <modo>`: Modo de operação (`multi_ai` ou `traditional`).

### 3.2. Exemplo de Execução

```bash
python3.11 main.py examples/LHAN0542_TESTE.cbl -o analysis_results/ -m multi_ai
```

---

## 4. Saídas

O sistema gera os seguintes artefatos:

### 4.1. Relatório de Análise

- Um arquivo Markdown (`.md`) para cada programa analisado, contendo a documentação completa.
- O relatório inclui seções de resumo, análise estrutural, de negócio, técnica, de modelo de dados e de qualidade.

### 4.2. Logs

- `cobol_analysis.log`: Log geral com todas as operações do sistema.
- `analysis_metrics.log`: Log com as métricas de cada análise.
- `analysis_errors.log`: Log com os erros ocorridos durante a análise.
- `metrics_*.json`: Arquivo JSON com as métricas estruturadas de cada análise.

---

## 5. Extensibilidade

O sistema foi projetado para ser extensível.

### 5.1. Adicionando Novos Provedores de IA

1. Crie um novo arquivo de provedor em `src/providers/` (ex: `meu_provedor.py`).
2. Implemente a classe do provedor, herdando de `BaseProvider`.
3. Adicione o novo provedor ao `config.yaml`.

### 5.2. Adicionando Novos Domínios de Análise

1. Adicione o novo domínio ao `config.yaml` na seção `specialized_ais`.
2. Atualize o orquestrador (`multi_ai_orchestrator.py`) para incluir o novo domínio na análise.

---

*COBOL Analysis Engine v1.0 - Manual do Usuário*
