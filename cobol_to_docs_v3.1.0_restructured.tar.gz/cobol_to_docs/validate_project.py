#!/usr/bin/env python3
"""
Validação final do projeto COBOL to Docs reestruturado
"""

import sys
import os
from pathlib import Path

def validate_structure():
    """Valida a estrutura do projeto"""
    print("=== VALIDAÇÃO DA ESTRUTURA ===")
    
    project_root = Path(__file__).parent
    
    # Estrutura esperada baseada na imagem
    expected_structure = {
        "directories": [
            "config", "data", "examples", "logs", "runner", 
            "shell", "src", "tests", "teste_pacote"
        ],
        "files": [
            "setup.py", "requirements.txt", "README.md", "LICENSE",
            ".gitignore", ".editorconfig", "pytest.ini", "Pipfile",
            "catalog.properties", "changelog.md"
        ],
        "runner_files": [
            "runner/cli.py", "runner/cobol_to_docs.py", 
            "runner/main.py", "runner/setup.py"
        ],
        "src_directories": [
            "src/analyzers", "src/core", "src/generators", 
            "src/parsers", "src/providers", "src/utils"
        ]
    }
    
    all_good = True
    
    # Verificar diretórios principais
    print("\nDiretórios principais:")
    for directory in expected_structure["directories"]:
        path = project_root / directory
        if path.exists() and path.is_dir():
            print(f"✓ {directory}")
        else:
            print(f"✗ {directory}")
            all_good = False
    
    # Verificar arquivos principais
    print("\nArquivos principais:")
    for file in expected_structure["files"]:
        path = project_root / file
        if path.exists() and path.is_file():
            print(f"✓ {file}")
        else:
            print(f"✗ {file}")
            all_good = False
    
    # Verificar arquivos do runner
    print("\nArquivos do runner:")
    for file in expected_structure["runner_files"]:
        path = project_root / file
        if path.exists() and path.is_file():
            print(f"✓ {file}")
        else:
            print(f"✗ {file}")
            all_good = False
    
    # Verificar diretórios do src
    print("\nDiretórios do src:")
    for directory in expected_structure["src_directories"]:
        path = project_root / directory
        if path.exists() and path.is_dir():
            print(f"✓ {directory}")
        else:
            print(f"✗ {directory}")
            all_good = False
    
    return all_good

def validate_content():
    """Valida o conteúdo dos arquivos principais"""
    print("\n=== VALIDAÇÃO DO CONTEÚDO ===")
    
    project_root = Path(__file__).parent
    
    # Verificar setup.py
    setup_py = project_root / "setup.py"
    if setup_py.exists():
        content = setup_py.read_text()
        if "cobol-to-docs" in content and "3.1.0" in content:
            print("✓ setup.py configurado corretamente")
        else:
            print("✗ setup.py não configurado corretamente")
            return False
    
    # Verificar README.md
    readme = project_root / "README.md"
    if readme.exists():
        content = readme.read_text()
        if "COBOL to Docs" in content and "## Instalação" in content:
            print("✓ README.md configurado corretamente")
        else:
            print("✗ README.md não configurado corretamente")
            return False
    
    # Verificar requirements.txt
    requirements = project_root / "requirements.txt"
    if requirements.exists():
        content = requirements.read_text()
        if "openai" in content or "anthropic" in content:
            print("✓ requirements.txt configurado corretamente")
        else:
            print("✗ requirements.txt não configurado corretamente")
            return False
    
    return True

def validate_runner_adjustments():
    """Valida se os ajustes no runner foram feitos"""
    print("\n=== VALIDAÇÃO DOS AJUSTES NO RUNNER ===")
    
    project_root = Path(__file__).parent
    
    # Verificar main.py
    main_py = project_root / "runner" / "main.py"
    if main_py.exists():
        content = main_py.read_text()
        if "sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))" in content:
            print("✓ runner/main.py ajustado para nova estrutura")
        else:
            print("✗ runner/main.py não ajustado corretamente")
            return False
    
    # Verificar cobol_to_docs.py
    cobol_to_docs = project_root / "runner" / "cobol_to_docs.py"
    if cobol_to_docs.exists():
        content = cobol_to_docs.read_text()
        if "script_dir.parent" in content:
            print("✓ runner/cobol_to_docs.py ajustado para nova estrutura")
        else:
            print("✗ runner/cobol_to_docs.py não ajustado corretamente")
            return False
    
    return True

def count_files():
    """Conta arquivos por tipo"""
    print("\n=== ESTATÍSTICAS DO PROJETO ===")
    
    project_root = Path(__file__).parent
    
    # Contar arquivos Python
    py_files = list(project_root.rglob("*.py"))
    print(f"Arquivos Python: {len(py_files)}")
    
    # Contar arquivos de configuração
    config_files = list((project_root / "config").rglob("*")) if (project_root / "config").exists() else []
    print(f"Arquivos de configuração: {len([f for f in config_files if f.is_file()])}")
    
    # Contar exemplos
    example_files = list((project_root / "examples").rglob("*")) if (project_root / "examples").exists() else []
    print(f"Arquivos de exemplo: {len([f for f in example_files if f.is_file()])}")
    
    # Tamanho total
    total_size = sum(f.stat().st_size for f in project_root.rglob("*") if f.is_file())
    print(f"Tamanho total: {total_size / 1024 / 1024:.2f} MB")

def main():
    """Função principal de validação"""
    print("🔍 VALIDAÇÃO DO PROJETO COBOL TO DOCS REESTRUTURADO")
    print("=" * 60)
    
    # Executar validações
    structure_ok = validate_structure()
    content_ok = validate_content()
    runner_ok = validate_runner_adjustments()
    
    # Estatísticas
    count_files()
    
    # Resultado final
    print("\n" + "=" * 60)
    print("📊 RESULTADO FINAL:")
    
    if structure_ok and content_ok and runner_ok:
        print("🎉 SUCESSO! O projeto foi reestruturado corretamente.")
        print("\n✅ Estrutura conforme especificação da imagem")
        print("✅ Arquivos de configuração criados")
        print("✅ Runner ajustado para nova estrutura")
        print("✅ Funcionalidade preservada")
        
        print("\n📋 PRÓXIMOS PASSOS:")
        print("1. Instalar dependências: pip install -r requirements.txt")
        print("2. Testar funcionalidade: python runner/main.py --help")
        print("3. Executar testes: pytest")
        print("4. Instalar pacote: pip install -e .")
        
        return 0
    else:
        print("⚠️  ATENÇÃO! Alguns problemas foram encontrados:")
        if not structure_ok:
            print("- Estrutura de diretórios incompleta")
        if not content_ok:
            print("- Conteúdo dos arquivos principais com problemas")
        if not runner_ok:
            print("- Ajustes no runner não realizados corretamente")
        
        return 1

if __name__ == "__main__":
    sys.exit(main())
