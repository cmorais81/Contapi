#!/usr/bin/env python3
"""
Script de teste para validar funcionalidade básica do COBOL to Docs
"""

import sys
import os
from pathlib import Path

# Adicionar src ao path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root / "src"))

def test_basic_imports():
    """Testa imports básicos"""
    print("Testando imports básicos...")
    
    try:
        from core.config import ConfigManager
        print("✓ ConfigManager importado com sucesso")
    except ImportError as e:
        print(f"✗ Erro ao importar ConfigManager: {e}")
        return False
    
    try:
        from parsers.cobol_parser_original import COBOLParser
        print("✓ COBOLParser importado com sucesso")
    except ImportError as e:
        print(f"✗ Erro ao importar COBOLParser: {e}")
        return False
    
    try:
        from analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
        print("✓ EnhancedCOBOLAnalyzer importado com sucesso")
    except ImportError as e:
        print(f"✗ Erro ao importar EnhancedCOBOLAnalyzer: {e}")
        return False
    
    return True

def test_config_loading():
    """Testa carregamento de configuração"""
    print("\nTestando carregamento de configuração...")
    
    try:
        from core.config import ConfigManager
        config = ConfigManager()
        print("✓ ConfigManager instanciado com sucesso")
        return True
    except Exception as e:
        print(f"✗ Erro ao instanciar ConfigManager: {e}")
        return False

def test_cobol_parser():
    """Testa parser COBOL básico"""
    print("\nTestando parser COBOL...")
    
    try:
        from parsers.cobol_parser_original import COBOLParser
        parser = COBOLParser()
        print("✓ COBOLParser instanciado com sucesso")
        return True
    except Exception as e:
        print(f"✗ Erro ao instanciar COBOLParser: {e}")
        return False

def test_structure():
    """Testa estrutura do projeto"""
    print("\nTestando estrutura do projeto...")
    
    required_dirs = [
        "src", "runner", "config", "data", "examples", 
        "logs", "tests", "teste_pacote"
    ]
    
    for dir_name in required_dirs:
        dir_path = project_root / dir_name
        if dir_path.exists():
            print(f"✓ Diretório {dir_name} existe")
        else:
            print(f"✗ Diretório {dir_name} não encontrado")
            return False
    
    required_files = [
        "setup.py", "requirements.txt", "README.md", 
        "LICENSE", "runner/main.py", "runner/cli.py"
    ]
    
    for file_name in required_files:
        file_path = project_root / file_name
        if file_path.exists():
            print(f"✓ Arquivo {file_name} existe")
        else:
            print(f"✗ Arquivo {file_name} não encontrado")
            return False
    
    return True

def main():
    """Função principal de teste"""
    print("=== TESTE DE FUNCIONALIDADE COBOL TO DOCS ===\n")
    
    tests = [
        ("Estrutura do Projeto", test_structure),
        ("Imports Básicos", test_basic_imports),
        ("Carregamento de Configuração", test_config_loading),
        ("Parser COBOL", test_cobol_parser),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n--- {test_name} ---")
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"✗ Erro inesperado em {test_name}: {e}")
            results.append((test_name, False))
    
    print("\n=== RESUMO DOS TESTES ===")
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✓ PASSOU" if result else "✗ FALHOU"
        print(f"{test_name}: {status}")
        if result:
            passed += 1
    
    print(f"\nResultado: {passed}/{total} testes passaram")
    
    if passed == total:
        print("🎉 Todos os testes passaram! O projeto está funcionando corretamente.")
        return 0
    else:
        print("⚠️  Alguns testes falharam. Verifique os erros acima.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
