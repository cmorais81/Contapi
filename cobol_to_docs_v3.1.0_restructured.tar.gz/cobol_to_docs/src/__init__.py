"""
COBOL AI Engine v2.6.0 - Pacote Principal
Sistema completo de análise de programas COBOL com IA.
"""

__version__ = "3.1.0"
__author__ = "Carlos Morais"
__description__ = "Sistema de análise e documentação de programas COBOL usando IA"

