# COBOL to Docs

Sistema completo de análise e documentação de programas COBOL usando Inteligência Artificial.

## Descrição

O **COBOL to Docs** é uma ferramenta avançada que automatiza a análise de programas COBOL e gera documentação técnica profissional. Utiliza múltiplos modelos de IA para compreender a lógica de negócio, estruturas de dados e fluxos de processamento em códigos COBOL legados.

## Características Principais

- **Análise Automatizada**: Processamento inteligente de programas COBOL
- **Múltiplos Modelos de IA**: Suporte a diferentes provedores (OpenAI, Anthropic, Google, etc.)
- **Documentação Profissional**: Geração de relatórios técnicos detalhados
- **Análise de Copybooks**: Processamento de bibliotecas complementares
- **Relatórios Comparativos**: Análise consolidada de múltiplos programas
- **Interface CLI**: Linha de comando intuitiva
- **Detecção Automática**: Identificação automática de código COBOL

## Instalação

### Via pip (Recomendado)

```bash
pip install cobol-to-docs
```

### Desenvolvimento Local

```bash
git clone https://github.com/usuario/cobol-to-docs.git
cd cobol-to-docs
pip install -e .
```

## Uso

### Linha de Comando

```bash
# Análise básica
cobol-to-docs programa.cbl

# Análise com copybooks
cobol-to-docs programa.cbl --copybooks copy1.cpy copy2.cpy

# Análise de múltiplos programas
cobol-to-docs *.cbl --output relatorio.html

# Usar modelo específico
cobol-to-docs programa.cbl --model gpt-4
```

### Programático

```python
from runner.main import main
import sys

# Configurar argumentos
sys.argv = ['cobol-to-docs', 'programa.cbl', '--output', 'doc.html']
main()
```

## Estrutura do Projeto

```
cobol_to_docs/
├── runner/              # Executáveis principais
│   ├── cli.py          # Interface CLI
│   ├── cobol_to_docs.py # Entry point principal
│   ├── main.py         # Processador principal
│   └── setup.py        # Setup do runner
├── src/                # Código fonte
│   ├── analyzers/      # Analisadores COBOL
│   ├── api/           # APIs
│   ├── core/          # Funcionalidades centrais
│   ├── generators/    # Geradores de documentação
│   ├── parsers/       # Parsers COBOL
│   └── utils/         # Utilitários
├── config/            # Configurações
├── data/              # Dados e cache
├── examples/          # Exemplos
├── tests/             # Testes unitários
└── teste_pacote/      # Testes do pacote
```

## Configuração

### Variáveis de Ambiente

```bash
export OPENAI_API_KEY="sua-chave-openai"
export ANTHROPIC_API_KEY="sua-chave-anthropic"
export GOOGLE_API_KEY="sua-chave-google"
```

### Arquivo de Configuração

Crie um arquivo `config/config.json`:

```json
{
    "default_model": "gpt-4",
    "output_format": "html",
    "max_tokens": 4000,
    "temperature": 0.1
}
```

## Exemplos

### Análise Simples

```bash
cobol-to-docs examples/programa-exemplo.cbl
```

### Análise Avançada

```bash
cobol-to-docs programa.cbl \
    --copybooks lib/*.cpy \
    --model gpt-4 \
    --output relatorio-completo.html \
    --verbose
```

## Desenvolvimento

### Configurar Ambiente

```bash
git clone https://github.com/usuario/cobol-to-docs.git
cd cobol-to-docs
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows
pip install -r requirements.txt
pip install -e .
```

### Executar Testes

```bash
pytest
```

### Executar Localmente

```bash
python runner/main.py programa.cbl
```

## Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## Licença

Distribuído sob a licença MIT. Veja `LICENSE` para mais informações.

## Contato

Carlos Morais - carlos@example.com

Link do Projeto: [https://github.com/usuario/cobol-to-docs](https://github.com/usuario/cobol-to-docs)

## Changelog

Veja [CHANGELOG.md](CHANGELOG.md) para detalhes das versões.
