"""
Testes básicos para verificar a estrutura do projeto
"""

import sys
import os
import pytest
from pathlib import Path

# Adicionar src ao path para testes
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "src"))

def test_project_structure():
    """Testa se a estrutura básica do projeto está correta"""
    project_root = Path(__file__).parent.parent
    
    # Verificar diretórios principais
    assert (project_root / "src").exists()
    assert (project_root / "runner").exists()
    assert (project_root / "config").exists()
    assert (project_root / "data").exists()
    assert (project_root / "examples").exists()
    assert (project_root / "logs").exists()
    
    # Verificar arquivos principais
    assert (project_root / "setup.py").exists()
    assert (project_root / "requirements.txt").exists()
    assert (project_root / "README.md").exists()
    assert (project_root / "LICENSE").exists()

def test_runner_files():
    """Testa se os arquivos do runner existem"""
    project_root = Path(__file__).parent.parent
    runner_dir = project_root / "runner"
    
    assert (runner_dir / "main.py").exists()
    assert (runner_dir / "cli.py").exists()
    assert (runner_dir / "cobol_to_docs.py").exists()

def test_src_structure():
    """Testa se a estrutura do src está correta"""
    project_root = Path(__file__).parent.parent
    src_dir = project_root / "src"
    
    # Verificar módulos principais
    assert (src_dir / "analyzers").exists()
    assert (src_dir / "core").exists()
    assert (src_dir / "generators").exists()
    assert (src_dir / "parsers").exists()
    assert (src_dir / "utils").exists()

def test_imports():
    """Testa se os imports básicos funcionam"""
    try:
        # Testar imports principais
        from src.core import config
        from src.analyzers import enhanced_cobol_analyzer
        from src.parsers import cobol_parser_original
        assert True
    except ImportError as e:
        pytest.fail(f"Erro ao importar módulos: {e}")

if __name__ == "__main__":
    pytest.main([__file__])
