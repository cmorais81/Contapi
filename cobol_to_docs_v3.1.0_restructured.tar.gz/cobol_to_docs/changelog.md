# Changelog

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.0.0/),
e este projeto adere ao [Semantic Versioning](https://semver.org/lang/pt-BR/).

## [3.1.0] - 2025-10-08

### Adicionado
- Nova estrutura de projeto organizada
- Diretório `runner/` para executáveis principais
- Diretório `tests/` para testes unitários
- Diretório `teste_pacote/` para testes do pacote
- Arquivos de configuração padrão (.gitignore, .editorconfig, pytest.ini)
- Documentação completa (README.md, LICENSE)
- Setup.py principal para instalação via pip
- Entry points para linha de comando

### Alterado
- Reestruturação completa do projeto
- Organização dos módulos em `src/`
- Melhoria na estrutura de imports
- Atualização da documentação

### Mantido
- Toda funcionalidade existente dos analisadores
- Compatibilidade com múltiplos modelos de IA
- Processamento de copybooks
- Geração de relatórios
- Interface de linha de comando

## [3.0.0] - 2025-09-XX

### Adicionado
- Sistema completo de análise COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
- Interface CLI avançada

### Funcionalidades Principais
- Processamento de múltiplos programas COBOL
- Análise de regras de negócio
- Mapeamento de linhagem de dados
- Geração de documentação técnica
- Relatórios HTML profissionais
- Integração com RAG (Retrieval-Augmented Generation)

## [2.x.x] - Versões Anteriores

### Histórico
- Desenvolvimento inicial do analisador COBOL
- Implementação dos parsers básicos
- Integração com provedores de IA
- Desenvolvimento dos geradores de documentação
