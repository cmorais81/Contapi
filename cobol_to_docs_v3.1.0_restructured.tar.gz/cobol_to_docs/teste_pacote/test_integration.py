"""
Testes de integração para o pacote COBOL to Docs
"""

import sys
import os
import subprocess
from pathlib import Path

def test_cli_help():
    """Testa se o CLI responde ao comando --help"""
    project_root = Path(__file__).parent.parent
    cli_path = project_root / "runner" / "cli.py"
    
    try:
        result = subprocess.run(
            [sys.executable, str(cli_path), "--help"],
            capture_output=True,
            text=True,
            timeout=30
        )
        # O comando deve executar sem erro (mesmo que não tenha argumentos válidos)
        assert result.returncode in [0, 2]  # 0 = sucesso, 2 = argparse help
    except subprocess.TimeoutExpired:
        assert False, "CLI não respondeu em tempo hábil"
    except Exception as e:
        assert False, f"Erro ao executar CLI: {e}"

def test_main_import():
    """Testa se o main.py pode ser importado"""
    project_root = Path(__file__).parent.parent
    sys.path.insert(0, str(project_root / "runner"))
    
    try:
        # Adicionar src ao path
        sys.path.insert(0, str(project_root / "src"))
        
        # Tentar importar o main
        import main
        assert hasattr(main, 'main'), "Função main não encontrada"
    except ImportError as e:
        assert False, f"Erro ao importar main: {e}"

def test_cobol_to_docs_import():
    """Testa se o cobol_to_docs.py pode ser importado"""
    project_root = Path(__file__).parent.parent
    sys.path.insert(0, str(project_root / "runner"))
    
    try:
        import cobol_to_docs
        assert hasattr(cobol_to_docs, 'main'), "Função main não encontrada"
    except ImportError as e:
        assert False, f"Erro ao importar cobol_to_docs: {e}"

if __name__ == "__main__":
    import pytest
    pytest.main([__file__])
