#!/usr/bin/env python3
"""
Setup script para COBOL to Docs
Configuração de instalação do pacote
"""

from setuptools import setup, find_packages
import os

# Ler o README
def read_readme():
    try:
        with open("README.md", "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return "COBOL to Docs - Sistema de análise e documentação de programas COBOL"

# Ler requirements
def read_requirements():
    try:
        with open("requirements.txt", "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip() and not line.startswith("#")]
    except FileNotFoundError:
        return []

setup(
    name="cobol-to-docs",
    version="3.1.0",
    description="Sistema de análise e documentação de programas COBOL usando IA",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    author="Carlos Morais",
    author_email="carlos@example.com",
    url="https://github.com/usuario/cobol-to-docs",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    install_requires=read_requirements(),
    python_requires=">=3.8",
    entry_points={
        "console_scripts": [
            "cobol-to-docs=runner.cobol_to_docs:main",
            "cobol-analyzer=runner.main:main",
            "cobol-cli=runner.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Documentation",
        "Topic :: Software Development :: Code Generators",
    ],
    keywords="cobol analysis documentation ai",
    project_urls={
        "Bug Reports": "https://github.com/usuario/cobol-to-docs/issues",
        "Source": "https://github.com/usuario/cobol-to-docs",
    },
)
