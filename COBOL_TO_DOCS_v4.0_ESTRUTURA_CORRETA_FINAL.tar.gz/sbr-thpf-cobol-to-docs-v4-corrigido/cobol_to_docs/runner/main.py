#!/usr/bin/env python3
"""
COBOL to Docs v4.0 - Sistema de Análise e Documentação de Programas COBOL
Sistema completo para análise automatizada de múltiplos programas COBOL com IA.
"""

import argparse
import logging
import os
import sys
import json
import time
import re
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Configurar path para imports
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.join(current_dir, "..", "src")
sys.path.insert(0, src_dir)

# Imports do sistema (apenas os que existem)
from core.config import ConfigManager
from providers.enhanced_provider_manager import EnhancedProviderManager
from providers.base_provider import AIRequest
from core.custom_prompt_manager import CustomPromptManager

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = os.path.join(log_dir, f"cobol_analyzer_{timestamp}.log")
    
    logging.basicConfig(
        level=log_level.upper(),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(log_file)
        ]
    )
    logging.getLogger("urllib3").setLevel(logging.WARNING)

def parse_multiple_programs(file_content: str) -> List[Dict[str, str]]:
    """Extrai múltiplos programas COBOL de um arquivo único."""
    programs = []
    sections = re.split(r"VMEMBER NAME\s+(\w+)", file_content)
    
    if len(sections) > 1:
        for i in range(1, len(sections), 2):
            if i + 1 < len(sections):
                program_name = sections[i].strip()
                program_content = f"VMEMBER NAME  {program_name}\n{sections[i + 1]}"
                programs.append({
                    "name": program_name,
                    "content": program_content
                })
    return programs

def parse_multiple_copybooks(file_content: str) -> List[Dict[str, str]]:
    """Extrai múltiplos copybooks de um arquivo único."""
    copybooks = []
    sections = re.split(r"VMEMBER NAME\s+(\w+)", file_content)
    
    if len(sections) > 1:
        for i in range(1, len(sections), 2):
            if i + 1 < len(sections):
                copybook_name = sections[i].strip()
                copybook_content = f"VMEMBER NAME  {copybook_name}\n{sections[i + 1]}"
                copybooks.append({
                    "name": copybook_name,
                    "content": copybook_content
                })
    return copybooks

def create_output_structure(base_output_dir: str, analysis_name: str, model_name: str) -> Dict[str, str]:
    """
    Cria a estrutura de diretórios de saída seguindo o padrão da imagem:
    output/analysis_name/model_{model_name}/
    output/analysis_name/model_{model_name}/ai_requests/
    output/analysis_name/model_{model_name}/ai_responses/
    
    Args:
        base_output_dir: Diretório base de saída
        analysis_name: Nome da análise (ex: analise_sem_coment_def)
        model_name: Nome do modelo utilizado
        
    Returns:
        Dicionário com os caminhos dos diretórios criados
    """
    # Sanitizar nome do modelo
    safe_model_name = model_name.replace('.', '_').replace('-', '_')
    analysis_dir = os.path.join(base_output_dir, analysis_name)
    model_dir = os.path.join(analysis_dir, f"model_{safe_model_name}")
    ai_requests_dir = os.path.join(model_dir, "ai_requests")
    ai_responses_dir = os.path.join(model_dir, "ai_responses")
    
    # Criar diretórios
    os.makedirs(analysis_dir, exist_ok=True)
    os.makedirs(model_dir, exist_ok=True)
    os.makedirs(ai_requests_dir, exist_ok=True)
    os.makedirs(ai_responses_dir, exist_ok=True)
    
    return {
        "analysis_dir": analysis_dir,
        "model_dir": model_dir,
        "ai_requests_dir": ai_requests_dir,
        "ai_responses_dir": ai_responses_dir
    }

def save_analysis_files(program_name: str, model_name: str, response: Any, request: AIRequest, 
                       output_dirs: Dict[str, str], custom_prompt_used: bool = False, 
                       generate_html: bool = False) -> None:
    """Salva os arquivos de análise seguindo o padrão da imagem."""
    # Nomes dos arquivos
    analysis_md_file = os.path.join(output_dirs["model_dir"], f"{program_name}_analise_funcional.md")
    analysis_html_file = os.path.join(output_dirs["model_dir"], f"{program_name}_analise_funcional.html")
    request_file = os.path.join(output_dirs["ai_requests_dir"], f"{program_name}_ai_request.json")
    response_file = os.path.join(output_dirs["ai_responses_dir"], f"{program_name}_ai_response.json")
    
    # 1. Salvar análise funcional (Markdown)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    provider = response.provider if hasattr(response, "provider") else "N/A"
    tokens = response.tokens_used if hasattr(response, "tokens_used") else "N/A"
    prompt_status = "Sim" if custom_prompt_used else "Não"
    content = response.content if hasattr(response, "content") else str(response)
    
    analysis_content = f"""# Análise Funcional do Programa {program_name}

**Data da análise:** {timestamp}
**Modelo utilizado:** {model_name}
**Provider:** {provider}
**Tokens utilizados:** {tokens}
**Prompt customizado:** {prompt_status}

## Resultado da Análise

{content}

---
*Análise gerada pelo COBOL-to-Docs v4.0*
"""
    
    # Salvar arquivo MD
    with open(analysis_md_file, "w", encoding="utf-8") as f:
        f.write(analysis_content)
    
    # Salvar arquivo HTML se solicitado
    if generate_html:
        html_content = f"""<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análise Funcional - {program_name}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }}
        h1 {{ color: #333; border-bottom: 2px solid #333; }}
        h2 {{ color: #666; }}
        strong {{ color: #000; }}
        pre {{ background: #f4f4f4; padding: 10px; border-radius: 5px; }}
        code {{ background: #f4f4f4; padding: 2px 4px; border-radius: 3px; }}
    </style>
</head>
<body>
    <h1>Análise Funcional do Programa {program_name}</h1>
    
    <p><strong>Data da análise:</strong> {timestamp}</p>
    <p><strong>Modelo utilizado:</strong> {model_name}</p>
    <p><strong>Provider:</strong> {provider}</p>
    <p><strong>Tokens utilizados:</strong> {tokens}</p>
    <p><strong>Prompt customizado:</strong> {prompt_status}</p>
    
    <h2>Resultado da Análise</h2>
    <div>{content.replace(chr(10), '<br>')}</div>
    
    <hr>
    <p><em>Análise gerada pelo COBOL-to-Docs v4.0</em></p>
</body>
</html>"""
        
        with open(analysis_html_file, "w", encoding="utf-8") as f:
            f.write(html_content)
    
    # 2. Salvar request (JSON) - GARANTIR QUE TODAS AS INFORMAÇÕES DO YAML SEJAM INCLUÍDAS
    request_data = {
        "program_name": program_name,
        "timestamp": datetime.now().isoformat(),
        "provider": provider,
        "model": model_name,
        "custom_prompt_used": custom_prompt_used,
        "request_payload": {
            "prompt": request.prompt,  # PROMPT COMPLETO COM YAML
            "program_code": request.program_code,
            "program_name": request.program_name,
            "full_prompt_content": request.prompt,  # GARANTIR PROMPT COMPLETO
            "yaml_prompt_applied": custom_prompt_used
        },
        "prompts_sent": {
            "system_prompt": request.context.get("system_prompt", "N/A"),
            "original_prompt": request.context.get("original_prompt", "N/A"),
            "main_prompt": request.context.get("main_prompt", "N/A"),
            "custom_prompt_content": request.context.get("custom_prompt_content", "N/A"),
            "yaml_content": request.context.get("yaml_content", "N/A"),  # CONTEÚDO YAML COMPLETO
            "bian_analysis_included": "BIAN" in request.prompt,  # VERIFICAR SE BIAN ESTÁ INCLUÍDO
            "componentization_included": "componentização" in request.prompt or "Componentes Reutilizáveis" in request.prompt
        },
        "headers": {},
        "endpoint": "",
        "method": "POST",
        "request_size": len(request.prompt) + len(request.program_code),
        "configuration": {
            "temperature": 0.1,
            "max_tokens": 4000,
            "timeout": 120
        }
    }
    
    with open(request_file, "w", encoding="utf-8") as f:
        json.dump(request_data, f, indent=2, ensure_ascii=False)
    
    # 3. Salvar response (JSON)
    response_data = {
        "program_name": program_name,
        "timestamp": datetime.now().isoformat(),
        "provider": provider,
        "model": model_name,
        "success": response.success if hasattr(response, "success") else True,
        "content": content,
        "tokens_used": response.tokens_used if hasattr(response, "tokens_used") else 0,
        "response_time": response.response_time if hasattr(response, "response_time") else 0,
        "error_message": response.error_message if hasattr(response, "error_message") else "",
        "metadata": {
            "analysis_type": "functional_analysis",
            "custom_prompt_used": custom_prompt_used,
            "bian_analysis_applied": custom_prompt_used,
            "timestamp": time.time()
        }
    }
    
    with open(response_file, "w", encoding="utf-8") as f:
        json.dump(response_data, f, indent=2, ensure_ascii=False)

def load_yaml_prompts(yaml_file: str) -> Dict[str, Any]:
    """Carrega prompts do arquivo YAML e retorna o conteúdo completo."""
    try:
        import yaml
        with open(yaml_file, 'r', encoding='utf-8') as f:
            prompts_data = yaml.safe_load(f)
        
        # Extrair o prompt principal (deep_business_analysis)
        if 'prompts' in prompts_data and 'deep_business_analysis' in prompts_data['prompts']:
            system_prompt = prompts_data['prompts']['deep_business_analysis']['system']
            user_prompt = prompts_data['prompts']['deep_business_analysis']['user']
            full_prompt = f"{system_prompt}\n\n{user_prompt}"
            
            return {
                "full_prompt": full_prompt,
                "system_prompt": system_prompt,
                "user_prompt": user_prompt,
                "raw_yaml": prompts_data,
                "yaml_file": yaml_file
            }
        else:
            return None
    except Exception as e:
        logging.error(f"Erro ao carregar YAML de prompts: {e}")
        return None

def main():
    """Função principal para execução do sistema."""
    parser = argparse.ArgumentParser(
        description="COBOL to Docs v4.0 - Análise e Documentação de Programas COBOL com IA",
        formatter_class=argparse.RawTextHelpFormatter
    )
    
    # Argumentos principais
    parser.add_argument("--fontes", type=str, help="Arquivo com múltiplos programas COBOL")
    parser.add_argument("--books", type=str, help="Arquivo com múltiplos copybooks")
    parser.add_argument("--output", type=str, default="output", help="Diretório de saída")
    parser.add_argument("--analysis-name", type=str, default="analise_sem_coment_def", help="Nome da análise")
    parser.add_argument("--log-level", type=str, default="INFO", help="Nível de log")
    parser.add_argument("--custom-prompt", type=str, help="Arquivo de prompt customizado (.txt)")
    parser.add_argument("--prompts-yaml", type=str, help="Arquivo de prompts YAML")
    parser.add_argument("--html", action="store_true", help="Gerar arquivos HTML além dos MD")
    parser.add_argument("--prompt-set", type=str, default="especialista", help="Conjunto de prompts")
    parser.add_argument("--config-dir", type=str, help="Diretório de configuração customizado")
    parser.add_argument("--prompts-file", type=str, help="Arquivo de prompts customizado")
    parser.add_argument("--status", action="store_true", help="Status do sistema")

    args = parser.parse_args()
    
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    config_manager = ConfigManager(args.config_dir, args.prompts_file)
    
    if args.status:
        print("Sistema COBOL Analyzer v4.0 - Operacional")
        return

    try:
        # Verificar arquivos obrigatórios
        if not args.fontes:
            logger.error("Arquivo de fontes é obrigatório")
            print("Erro: Especifique o arquivo de fontes com --fontes")
            return
        
        if not os.path.exists(args.fontes):
            logger.error(f"Arquivo de fontes não encontrado: {args.fontes}")
            print(f"Erro: Arquivo {args.fontes} não encontrado")
            return
        
        # Criar diretório de saída
        os.makedirs(args.output, exist_ok=True)
        
        # Inicializar componentes
        provider_manager = EnhancedProviderManager(config_manager.config)
        
        # Ler e processar múltiplos programas COBOL
        programs = []
        copybooks = []
        
        # Processar arquivo fontes.txt
        if args.fontes and os.path.exists(args.fontes):
            try:
                with open(args.fontes, "r", encoding="utf-8") as f:
                    fontes_content = f.read()
                
                extracted_programs = parse_multiple_programs(fontes_content)
                
                class Program:
                    def __init__(self, name, content, file_path):
                        self.name = name
                        self.content = content
                        self.file_path = file_path
                
                for prog_data in extracted_programs:
                    prog_name = prog_data["name"]
                    prog_content = prog_data["content"]
                    programs.append(Program(prog_name, prog_content, args.fontes))
                    logger.info(f"Programa {prog_name} extraído - {len(prog_content)} caracteres")

            except Exception as e:
                logger.error(f"Erro ao processar fontes.txt: {e}", exc_info=True)

        # Processar arquivo BOOKS.txt
        if args.books and os.path.exists(args.books):
            try:
                with open(args.books, "r", encoding="utf-8") as f:
                    books_content = f.read()
                
                extracted_copybooks = parse_multiple_copybooks(books_content)
                
                class Copybook:
                    def __init__(self, name, content):
                        self.name = name
                        self.content = content
                
                for copy_data in extracted_copybooks:
                    copy_name = copy_data["name"]
                    copy_content = copy_data["content"]
                    copybooks.append(Copybook(copy_name, copy_content))
                    logger.info(f"Copybook {copy_name} extraído - {len(copy_content)} caracteres")

            except Exception as e:
                logger.error(f"Erro ao processar BOOKS.txt: {e}", exc_info=True)
        
        if not programs:
            logger.error("Nenhum programa válido encontrado")
            print("Erro: Nenhum programa COBOL válido encontrado")
            return
        
        # Executar análise
        print(f"\nIniciando análise de {len(programs)} programa(s)...")
        print(f"Copybooks disponíveis: {len(copybooks)}")
        
        start_time = time.time()
        all_results = []
        
        # Obter modelos configurados
        configured_models = [{"name": "enhanced_mock", "provider": "enhanced_mock"}]

        # Gerenciador de prompt customizado
        custom_prompt_manager = None
        custom_prompt_used = False
        yaml_prompt_data = None
        
        # Verificar se há prompt YAML (prioridade)
        if args.prompts_yaml and os.path.exists(args.prompts_yaml):
            yaml_prompt_data = load_yaml_prompts(args.prompts_yaml)
            if yaml_prompt_data:
                custom_prompt_used = True
                logger.info(f"Prompt YAML carregado: {args.prompts_yaml} ({len(yaml_prompt_data['full_prompt'])} caracteres)")
                logger.info(f"BIAN analysis incluída: {'BIAN' in yaml_prompt_data['full_prompt']}")
        
        # Se não há YAML, verificar prompt TXT
        elif args.custom_prompt and os.path.exists(args.custom_prompt):
            custom_prompt_manager = CustomPromptManager(args.custom_prompt)
            custom_prompt_used = True
            logger.info(f"Prompt TXT carregado: {args.custom_prompt}")
        
        # Verificar se há prompt padrão Minato
        elif os.path.exists("config/prompts_minato.yaml"):
            yaml_prompt_data = load_yaml_prompts("config/prompts_minato.yaml")
            if yaml_prompt_data:
                custom_prompt_used = True
                logger.info(f"Prompt Minato padrão carregado: config/prompts_minato.yaml")

        # Criar estrutura de saída por modelo (uma vez só)
        model_outputs = {}
        for model_config in configured_models:
            model_name = model_config.get("name", "unknown_model")
            model_outputs[model_name] = create_output_structure(args.output, args.analysis_name, model_name)

        for i, program in enumerate(programs, 1):
            print(f"\nAnalisando programa {i}/{len(programs)}: {program.name}")
            
            # Iterar sobre os modelos configurados
            for model_config in configured_models:
                model_name = model_config.get("name", "unknown_model")
                provider_name = model_config.get("provider", "unknown_provider")
                
                logger.info(f"Tentando analisar {program.name} com modelo {model_name} via {provider_name}")

                try:
                    # Usar estrutura de saída já criada para este modelo
                    output_dirs = model_outputs[model_name]
                    
                    final_prompt = ""
                    custom_prompt_content_for_request = "N/A"
                    yaml_content_for_request = "N/A"

                    # Prioridade: YAML > TXT > Padrão
                    if yaml_prompt_data:
                        # Substituir placeholders no prompt YAML - GARANTIR SUBSTITUIÇÃO COMPLETA
                        copybooks_text = "\n\n".join([f"COPYBOOK {cb.name}:\n{cb.content}" for cb in copybooks])
                        final_prompt = yaml_prompt_data['full_prompt'].replace("{cobol_code}", program.content)
                        final_prompt = final_prompt.replace("{copybooks}", copybooks_text)
                        custom_prompt_content_for_request = yaml_prompt_data['full_prompt']
                        yaml_content_for_request = json.dumps(yaml_prompt_data['raw_yaml'], indent=2, ensure_ascii=False)
                        logger.info(f"Usando prompt YAML para {program.name} - BIAN incluído: {'BIAN' in final_prompt}")
                    elif custom_prompt_manager:
                        final_prompt = custom_prompt_manager.get_custom_prompt(program.content)
                        custom_prompt_content_for_request = "Prompt TXT customizado"
                        logger.info(f"Usando prompt TXT customizado para {program.name}")
                    else:
                        # Fallback para prompt padrão
                        final_prompt = f"Analise este programa COBOL e extraia as regras de negócio:\n\n{program.content}"
                        logger.info(f"Usando prompt padrão para {program.name}")
                    
                    request = AIRequest(
                        prompt=final_prompt,  # PROMPT COMPLETO COM YAML E BIAN
                        program_code=program.content,
                        program_name=program.name,
                        context={
                            "model": model_name,
                            "provider": provider_name,
                            "system_prompt": yaml_prompt_data['system_prompt'] if yaml_prompt_data else "Sistema de análise COBOL",
                            "original_prompt": final_prompt,
                            "main_prompt": final_prompt,
                            "custom_prompt_content": custom_prompt_content_for_request,
                            "yaml_content": yaml_content_for_request,  # YAML COMPLETO
                            "bian_analysis": "BIAN" in final_prompt,
                            "componentization_analysis": "Componentes Reutilizáveis" in final_prompt
                        }
                    )
                    
                    response = provider_manager.analyze(request)
                    
                    if response.success:
                        # Salvar arquivos seguindo o padrão da imagem
                        save_analysis_files(
                            program_name=program.name,
                            model_name=model_name,
                            response=response,
                            request=request,
                            output_dirs=output_dirs,
                            custom_prompt_used=custom_prompt_used,
                            generate_html=args.html
                        )
                        
                        logger.info(f"Análise salva em: {output_dirs['model_dir']}")
                        print(f"   ✅ Análise concluída - {response.tokens_used} tokens")
                        print(f"   📁 Arquivos salvos em: {output_dirs['model_dir']}/")
                        if args.html:
                            print(f"   🌐 Arquivo HTML gerado")
                        all_results.append(response)
                        break
                    else:
                        logger.error(f"Falha na análise com {model_name} via {provider_name}: {response.error_message}")
                
                except Exception as e:
                    logger.critical(f"Erro fatal durante a análise: {e}", exc_info=True)

        end_time = time.time()
        total_time = end_time - start_time
        total_tokens = sum(r.tokens_used for r in all_results if r)
        
        print("\n" + "="*60)
        print("PROCESSAMENTO CONCLUÍDO")
        print("="*60)
        print(f"📊 Programas encontrados: {len(programs)}")
        print(f"📚 Copybooks encontrados: {len(copybooks)}")
        print(f"🤖 Modelos utilizados: {len(set(r.provider for r in all_results if r))}")
        print(f"✅ Análises bem-sucedidas: {len(all_results)}/{len(programs)}")
        print(f"🔢 Total de tokens utilizados: {total_tokens:,}")
        print(f"⏱️  Tempo total: {total_time:.2f}s")
        print(f"📁 Resultados salvos em: {args.output}/{args.analysis_name}")
        prompt_status = "Sim" if custom_prompt_used else "Não"
        print(f"🎯 Prompt customizado usado: {prompt_status}")
        if yaml_prompt_data:
            print(f"🏦 Análise BIAN aplicada: {'BIAN' in yaml_prompt_data['full_prompt']}")
        
        # Listar programas processados
        print(f"\n📋 Programas processados:")
        for i, program in enumerate(programs, 1):
            print(f"   {i}. {program.name}")
        
        logger.info("Processamento concluído com sucesso")

    except Exception as e:
        logger.critical(f"Erro inesperado no processamento: {e}", exc_info=True)
        print("Ocorreu um erro crítico. Verifique o log para mais detalhes.")

if __name__ == "__main__":
    main()
