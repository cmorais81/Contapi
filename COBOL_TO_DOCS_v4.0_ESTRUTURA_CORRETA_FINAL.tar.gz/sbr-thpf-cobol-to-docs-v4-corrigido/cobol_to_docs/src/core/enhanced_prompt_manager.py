import os
import yaml
import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class EnhancedPromptManager:
    def __init__(self, config_manager: Any):
        self.config_manager = config_manager
        self.prompts_config = self._load_prompts_config()

    def _load_prompts_config(self) -> Dict[str, Any]:
        """Carrega a configuração de prompts do arquivo prompts.yaml."""
        prompts_file_path = self.config_manager.get_prompts_file_path()
        if prompts_file_path and os.path.exists(prompts_file_path):
            try:
                with open(prompts_file_path, 'r', encoding='utf-8') as f:
                    return yaml.safe_load(f)
            except Exception as e:
                logger.error(f"Erro ao carregar prompts.yaml de {prompts_file_path}: {e}")
        else:
            logger.warning(f"Arquivo prompts.yaml não encontrado ou não especificado: {prompts_file_path}")
        return {}

    def get_prompt_components(self, program_name: str, program_code: str, copybooks: List[Any], prompt_set: str = "especialista") -> Dict[str, str]:
        """
        Constrói o prompt completo para análise, incluindo system, original e main prompts,
        e integra o conteúdo de copybooks e programas COBOL.
        """
        system_prompt_template = self.prompts_config.get(prompt_set, {}).get("system_prompt", "")
        original_prompt_template = self.prompts_config.get(prompt_set, {}).get("original_prompt", "")
        main_prompt_template = self.prompts_config.get(prompt_set, {}).get("main_prompt", "")

        # Inlining de copybooks no program_code
        resolved_program_code = self._inline_copybooks(program_code, copybooks)

        # Substituir placeholders nos prompts
        system_prompt = system_prompt_template.format(
            program_name=program_name,
            program_code=resolved_program_code,
            copybooks_content="\n".join([cb.content for cb in copybooks]) # Conteúdo dos copybooks
        )
        original_prompt = original_prompt_template.format(
            program_name=program_name,
            program_code=resolved_program_code,
            copybooks_content="\n".join([cb.content for cb in copybooks])
        )
        main_prompt = main_prompt_template.format(
            program_name=program_name,
            program_code=resolved_program_code,
            copybooks_content="\n".join([cb.content for cb in copybooks])
        )

        full_prompt = f"{system_prompt}\n\n{original_prompt}\n\n{main_prompt}"

        return {
            "full_prompt": full_prompt,
            "system_prompt": system_prompt,
            "original_prompt": original_prompt,
            "main_prompt": main_prompt
        }

    def _inline_copybooks(self, program_code: str, copybooks: List[Any]) -> str:
        """
        Substitui as chamadas COPY no código COBOL pelo conteúdo real dos copybooks.
        """
        resolved_code = program_code
        for cb in copybooks:
            # Regex para encontrar COPY <copybook_name> [IN <library>] ou COPY <copybook_name>.
            # A flag re.IGNORECASE é importante para COBOL.
            pattern = re.compile(r"COPY\s+" + re.escape(cb.name) + r"(?:\s+IN\s+\w+)?\s*\.", re.IGNORECASE)
            resolved_code = pattern.sub(f"\n{cb.content}\n", resolved_code)
        return resolved_code

