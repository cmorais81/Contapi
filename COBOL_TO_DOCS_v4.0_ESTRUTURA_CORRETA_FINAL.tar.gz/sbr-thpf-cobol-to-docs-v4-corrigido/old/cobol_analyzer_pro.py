#!/usr/bin/env python3
"""
COBOL Analyzer Pro - Sistema Profissional de Análise COBOL
Versão otimizada para testes com providers reais
"""

import os
import sys
import json
import logging
import argparse
from datetime import datetime
from pathlib import Path

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.parsers.cobol_parser_original import COBOLParser
from src.analyzers.enhanced_professional_analyzer import EnhancedProfessionalAnalyzer
from src.generators.professional_report_generator import ProfessionalReportGenerator
from src.utils.enhanced_cost_calculator import EnhancedCostCalculator

def setup_logging(output_dir: str, verbose: bool = False) -> logging.Logger:
    """Configura logging para a análise"""
    log_dir = Path(output_dir) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = log_dir / f"cobol_analyzer_pro_{timestamp}.log"
    
    level = logging.DEBUG if verbose else logging.INFO
    
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    return logging.getLogger(__name__)

def load_programs_from_file(fontes_file: str) -> list:
    """Carrega programas COBOL do arquivo de fontes"""
    logger = logging.getLogger(__name__)
    parser = COBOLParser()
    programs = []
    
    logger.info(f"Carregando programas de {fontes_file}")
    
    with open(fontes_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Dividir por programas baseado em PROGRAM-ID
    program_sections = content.split('PROGRAM-ID.')
    
    for i, section in enumerate(program_sections[1:], 1):
        lines = section.strip().split('\n')
        if lines:
            # Extrair nome do programa
            program_name = lines[0].strip().split('.')[0].strip()
            program_content = 'PROGRAM-ID. ' + section
            
            # Criar objeto programa
            program = type('Program', (), {
                'name': program_name,
                'content': program_content,
                'lines': len(program_content.split('\n')),
                'size': len(program_content)
            })()
            
            programs.append(program)
            logger.debug(f"Programa carregado: {program_name} ({program.lines} linhas)")
    
    logger.info(f"Total de {len(programs)} programas carregados")
    return programs

def load_copybooks_from_file(books_file: str) -> dict:
    """Carrega copybooks do arquivo BOOKS"""
    logger = logging.getLogger(__name__)
    copybooks = {}
    
    if not books_file or not os.path.exists(books_file):
        logger.warning("Arquivo de copybooks não encontrado ou não fornecido")
        return copybooks
    
    logger.info(f"Carregando copybooks de {books_file}")
    
    with open(books_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Processar copybooks (implementação simplificada)
    # Em produção, seria necessário parsear adequadamente cada copybook
    copybooks['MAIN_COPYBOOK'] = content
    
    logger.info(f"Carregados {len(copybooks)} copybooks")
    return copybooks

def create_provider_config(model: str, **kwargs) -> dict:
    """Cria configuração para providers"""
    config = {
        'ai': {
            'primary_provider': model,
            'fallback_providers': ['enhanced_mock'],
            'model_configurations': {
                model: {
                    'max_tokens': kwargs.get('max_tokens', 8000),
                    'temperature': kwargs.get('temperature', 0.1),
                    'timeout': kwargs.get('timeout', 60)
                }
            }
        },
        'providers': {
            'luzia': {
                'enabled': True,
                'base_url': kwargs.get('luzia_url', ''),
                'api_key': kwargs.get('luzia_key', ''),
                'timeout': 60
            },
            'openai': {
                'enabled': True,
                'api_key': kwargs.get('openai_key', os.getenv('OPENAI_API_KEY', '')),
                'timeout': 60
            },
            'aws': {
                'enabled': True,
                'region': kwargs.get('aws_region', 'us-east-1'),
                'access_key': kwargs.get('aws_access_key', ''),
                'secret_key': kwargs.get('aws_secret_key', ''),
                'timeout': 60
            },
            'databricks': {
                'enabled': True,
                'endpoint': kwargs.get('databricks_endpoint', ''),
                'token': kwargs.get('databricks_token', ''),
                'timeout': 60
            },
            'enhanced_mock': {
                'enabled': True,
                'timeout': 5
            }
        }
    }
    
    return config

def estimate_costs(programs: list, model: str) -> dict:
    """Estima custos da análise"""
    cost_calculator = EnhancedCostCalculator()
    
    total_lines = sum(program.lines for program in programs)
    total_size = sum(program.size for program in programs)
    
    # Estimativa de tokens baseada no tamanho
    estimated_tokens = {
        'prompt_tokens': total_size // 4,  # ~1 token por 4 caracteres
        'completion_tokens': (total_size // 4) * 0.4,  # Estimativa de resposta
        'total_tokens': int((total_size // 4) * 1.4)
    }
    
    estimated_cost = cost_calculator.calculate_cost(estimated_tokens, model)
    estimated_cost_brl = estimated_cost * 5.50
    
    return {
        'programs_count': len(programs),
        'total_lines': total_lines,
        'total_size_bytes': total_size,
        'estimated_tokens': estimated_tokens,
        'estimated_cost_usd': estimated_cost,
        'estimated_cost_brl': estimated_cost_brl,
        'model': model,
        'cost_per_program': estimated_cost_brl / len(programs) if programs else 0
    }

def analyze_programs(programs: list, copybooks: dict, config: dict, model: str) -> list:
    """Executa análise dos programas"""
    logger = logging.getLogger(__name__)
    
    logger.info(f"Iniciando análise de {len(programs)} programas com modelo {model}")
    
    # Inicializar analisador
    analyzer = EnhancedProfessionalAnalyzer(config)
    
    analysis_results = []
    
    for i, program in enumerate(programs, 1):
        logger.info(f"Analisando programa {i}/{len(programs)}: {program.name}")
        
        try:
            # Executar análise profissional
            result = analyzer.analyze_program_comprehensive(
                program, model, copybooks
            )
            
            result['program_name'] = program.name
            result['analysis_order'] = i
            analysis_results.append(result)
            
            # Log de progresso
            if result['main_analysis'].get('success'):
                cost = result['cost_analysis'].get('total_cost_brl', 0)
                logger.info(f"✅ {program.name} analisado com sucesso - Custo: R$ {cost:.4f}")
            else:
                error = result['main_analysis'].get('error', 'Erro desconhecido')
                logger.warning(f"❌ Falha na análise de {program.name}: {error}")
                
        except Exception as e:
            logger.error(f"Erro crítico ao analisar {program.name}: {e}", exc_info=True)
            analysis_results.append({
                'program_name': program.name,
                'analysis_order': i,
                'main_analysis': {'success': False, 'error': str(e)},
                'cost_analysis': {'total_cost_brl': 0}
            })
    
    logger.info(f"Análise concluída: {len(analysis_results)} programas processados")
    return analysis_results

def generate_reports(programs: list, analysis_results: list, copybooks: dict, output_dir: str) -> dict:
    """Gera relatórios profissionais"""
    logger = logging.getLogger(__name__)
    
    logger.info("Gerando relatórios profissionais...")
    
    try:
        # Inicializar gerador de relatórios
        report_generator = ProfessionalReportGenerator(output_dir)
        
        # Dados consolidados para relatório
        detailed_analysis = {
            'total_programs': len(programs),
            'successful_analyses': len([r for r in analysis_results if r['main_analysis'].get('success')]),
            'total_cost': sum(r['cost_analysis'].get('total_cost_brl', 0) for r in analysis_results),
            'analysis_timestamp': datetime.now().isoformat()
        }
        
        # Gerar relatórios
        report_paths = report_generator.generate_comprehensive_report(
            programs, analysis_results, detailed_analysis, copybooks
        )
        
        logger.info(f"Relatórios gerados com sucesso em {output_dir}")
        return report_paths
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatórios: {e}", exc_info=True)
        return {}

def print_summary(programs: list, analysis_results: list, report_paths: dict, execution_time: float):
    """Imprime resumo da execução"""
    successful_analyses = len([r for r in analysis_results if r['main_analysis'].get('success')])
    total_cost = sum(r['cost_analysis'].get('total_cost_brl', 0) for r in analysis_results)
    
    print("\n" + "="*80)
    print("🎯 COBOL ANALYZER PRO - ANÁLISE CONCLUÍDA")
    print("="*80)
    print(f"📊 Programas processados: {len(programs)}")
    print(f"✅ Análises bem-sucedidas: {successful_analyses}")
    print(f"❌ Análises com falha: {len(programs) - successful_analyses}")
    print(f"💰 Custo total: R$ {total_cost:.4f}")
    print(f"⏱️  Tempo de execução: {execution_time:.2f} segundos")
    print(f"💡 Custo médio por programa: R$ {total_cost/len(programs):.4f}")
    
    if report_paths:
        print("\n📄 RELATÓRIOS GERADOS:")
        print("-" * 40)
        for report_type, path in report_paths.items():
            print(f"• {report_type}: {path}")
    
    print("\n🚀 PRÓXIMOS PASSOS:")
    print("1. Revisar relatório executivo HTML")
    print("2. Analisar relatórios individuais por programa")
    print("3. Implementar recomendações de modernização")
    print("4. Documentar regras de negócio críticas")
    print("="*80)

def main():
    parser = argparse.ArgumentParser(
        description='COBOL Analyzer Pro - Sistema Profissional de Análise COBOL',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:

# Análise básica com mock
python cobol_analyzer_pro.py --fontes fontes.txt --output relatorio

# Análise com Luzia
python cobol_analyzer_pro.py --fontes fontes.txt --books books.txt --output relatorio --model luzia

# Análise com OpenAI
python cobol_analyzer_pro.py --fontes fontes.txt --output relatorio --model openai-gpt-4

# Apenas estimativa de custos
python cobol_analyzer_pro.py --fontes fontes.txt --model luzia --estimate-only

# Análise com configurações customizadas
python cobol_analyzer_pro.py --fontes fontes.txt --output relatorio --model luzia --max-tokens 10000 --temperature 0.2
        """
    )
    
    # Argumentos obrigatórios
    parser.add_argument('--fontes', required=True, help='Arquivo com programas COBOL')
    
    # Argumentos opcionais
    parser.add_argument('--books', help='Arquivo com copybooks')
    parser.add_argument('--output', help='Diretório de saída (obrigatório exceto para --estimate-only)')
    parser.add_argument('--model', default='enhanced_mock', 
                       choices=['luzia', 'openai-gpt-4', 'openai-gpt-3.5-turbo', 'aws-claude-3-5-sonnet', 
                               'databricks', 'enhanced_mock'],
                       help='Modelo de IA a usar (default: enhanced_mock)')
    
    # Flags
    parser.add_argument('--estimate-only', action='store_true', 
                       help='Apenas estimar custos sem executar análise')
    parser.add_argument('--verbose', '-v', action='store_true', 
                       help='Logging detalhado')
    
    # Configurações de modelo
    parser.add_argument('--max-tokens', type=int, default=8000, 
                       help='Máximo de tokens por requisição')
    parser.add_argument('--temperature', type=float, default=0.1, 
                       help='Temperatura do modelo (0.0-1.0)')
    parser.add_argument('--timeout', type=int, default=60, 
                       help='Timeout em segundos')
    
    # Configurações de providers
    parser.add_argument('--openai-key', help='Chave API OpenAI')
    parser.add_argument('--luzia-url', help='URL base Luzia')
    parser.add_argument('--luzia-key', help='Chave API Luzia')
    parser.add_argument('--aws-region', default='us-east-1', help='Região AWS')
    parser.add_argument('--aws-access-key', help='AWS Access Key')
    parser.add_argument('--aws-secret-key', help='AWS Secret Key')
    parser.add_argument('--databricks-endpoint', help='Endpoint Databricks')
    parser.add_argument('--databricks-token', help='Token Databricks')
    
    args = parser.parse_args()
    
    # Validações
    if not args.estimate_only and not args.output:
        parser.error("--output é obrigatório exceto quando usando --estimate-only")
    
    if not os.path.exists(args.fontes):
        parser.error(f"Arquivo de fontes não encontrado: {args.fontes}")
    
    # Configurar diretório de saída
    if args.output:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = Path(args.output) / f"cobol_analysis_{timestamp}"
        output_dir.mkdir(parents=True, exist_ok=True)
    else:
        output_dir = Path("/tmp/cobol_estimate")
        output_dir.mkdir(exist_ok=True)
    
    # Setup logging
    logger = setup_logging(str(output_dir), args.verbose)
    logger.info("🚀 Iniciando COBOL Analyzer Pro")
    
    start_time = datetime.now()
    
    try:
        # Carregar programas e copybooks
        programs = load_programs_from_file(args.fontes)
        copybooks = load_copybooks_from_file(args.books) if args.books else {}
        
        if not programs:
            logger.error("Nenhum programa COBOL encontrado no arquivo de fontes")
            sys.exit(1)
        
        # Estimativa de custos
        estimate = estimate_costs(programs, args.model)
        
        print("\n" + "="*60)
        print("💰 ESTIMATIVA DE CUSTOS")
        print("="*60)
        print(f"Programas: {estimate['programs_count']}")
        print(f"Linhas de código: {estimate['total_lines']:,}")
        print(f"Tokens estimados: {estimate['estimated_tokens']['total_tokens']:,}")
        print(f"Custo estimado: R$ {estimate['estimated_cost_brl']:.4f} (${estimate['estimated_cost_usd']:.4f})")
        print(f"Custo por programa: R$ {estimate['cost_per_program']:.4f}")
        print(f"Modelo: {estimate['model']}")
        print("="*60)
        
        if args.estimate_only:
            logger.info("Estimativa concluída. Saindo...")
            return
        
        # Confirmar execução se custo for alto
        if estimate['estimated_cost_brl'] > 50.0:
            response = input(f"\n⚠️  Custo estimado é R$ {estimate['estimated_cost_brl']:.2f}. Continuar? (s/N): ")
            if response.lower() not in ['s', 'sim', 'y', 'yes']:
                logger.info("Execução cancelada pelo usuário")
                return
        
        # Criar configuração de providers
        provider_config = create_provider_config(args.model, 
                                                max_tokens=args.max_tokens,
                                                temperature=args.temperature,
                                                timeout=args.timeout,
                                                openai_key=args.openai_key,
                                                luzia_url=args.luzia_url,
                                                luzia_key=args.luzia_key)
        
        # Executar análise
        analysis_results = analyze_programs(programs, copybooks, provider_config, args.model)
        
        # Gerar relatórios
        report_paths = generate_reports(programs, analysis_results, copybooks, str(output_dir))
        
        # Calcular tempo de execução
        execution_time = (datetime.now() - start_time).total_seconds()
        
        # Imprimir resumo
        print_summary(programs, analysis_results, report_paths, execution_time)
        
        logger.info(f"✅ Análise concluída com sucesso em {execution_time:.2f} segundos")
        
    except KeyboardInterrupt:
        logger.info("❌ Análise interrompida pelo usuário")
        sys.exit(1)
    except Exception as e:
        logger.error(f"❌ Erro crítico durante execução: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
