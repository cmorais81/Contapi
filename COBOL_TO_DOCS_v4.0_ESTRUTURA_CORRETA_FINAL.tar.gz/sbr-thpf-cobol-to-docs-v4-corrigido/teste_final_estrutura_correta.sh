#!/bin/bash

echo "=========================================="
echo "COBOL Analyzer v4.0 - Teste Estrutura Correta"
echo "=========================================="

# Verificar arquivos necessários
echo "1. Verificando arquivos necessários..."
if [ ! -f "fontes.txt" ]; then
    echo "❌ Arquivo fontes.txt não encontrado"
    exit 1
fi

if [ ! -f "BOOKS.txt" ]; then
    echo "❌ Arquivo BOOKS.txt não encontrado"
    exit 1
fi

if [ ! -f "config/prompts_minato.yaml" ]; then
    echo "❌ Arquivo config/prompts_minato.yaml não encontrado"
    exit 1
fi

echo "✅ Todos os arquivos necessários encontrados"

# Teste 1: Estrutura padrão (apenas MD)
echo ""
echo "2. Executando teste com estrutura padrão (apenas MD)..."
python3 cobol_to_docs/runner/main.py \
  --fontes fontes.txt \
  --books BOOKS.txt \
  --prompts-yaml config/prompts_minato.yaml \
  --output teste_pkg \
  --analysis-name analise_sem_coment_def

if [ $? -eq 0 ]; then
    echo "✅ Teste padrão executado com sucesso"
else
    echo "❌ Falha no teste padrão"
fi

# Teste 2: Estrutura com HTML
echo ""
echo "3. Executando teste com geração de HTML..."
python3 cobol_to_docs/runner/main.py \
  --fontes fontes.txt \
  --books BOOKS.txt \
  --prompts-yaml config/prompts_minato.yaml \
  --output teste_pkg_html \
  --analysis-name analise_com_html \
  --html

if [ $? -eq 0 ]; then
    echo "✅ Teste com HTML executado com sucesso"
else
    echo "❌ Falha no teste com HTML"
fi

# Verificar estrutura de saída
echo ""
echo "4. Verificando estrutura de saída..."

# Verificar estrutura padrão
if [ -d "teste_pkg/analise_sem_coment_def/model_enhanced_mock" ]; then
    echo "✅ Estrutura padrão criada corretamente"
    ARQUIVOS_MD=$(find teste_pkg -name "*.md" | wc -l)
    ARQUIVOS_HTML=$(find teste_pkg -name "*.html" | wc -l)
    echo "   📄 Arquivos MD: $ARQUIVOS_MD"
    echo "   🌐 Arquivos HTML: $ARQUIVOS_HTML"
else
    echo "❌ Estrutura padrão não criada"
fi

# Verificar estrutura com HTML
if [ -d "teste_pkg_html/analise_com_html/model_enhanced_mock" ]; then
    echo "✅ Estrutura com HTML criada corretamente"
    ARQUIVOS_MD_HTML=$(find teste_pkg_html -name "*.md" | wc -l)
    ARQUIVOS_HTML_HTML=$(find teste_pkg_html -name "*.html" | wc -l)
    echo "   📄 Arquivos MD: $ARQUIVOS_MD_HTML"
    echo "   🌐 Arquivos HTML: $ARQUIVOS_HTML_HTML"
else
    echo "❌ Estrutura com HTML não criada"
fi

# Verificar aplicação do prompt YAML com BIAN
echo ""
echo "5. Verificando aplicação do prompt YAML Minato..."
if [ -f "teste_pkg/analise_sem_coment_def/model_enhanced_mock/ai_requests/LHAN0542_ai_request.json" ]; then
    BIAN_COUNT=$(grep -c "BIAN\|Componentes Reutilizáveis\|componentização" teste_pkg/analise_sem_coment_def/model_enhanced_mock/ai_requests/LHAN0542_ai_request.json)
    if [ $BIAN_COUNT -gt 0 ]; then
        echo "✅ Prompt YAML Minato aplicado corretamente ($BIAN_COUNT referências BIAN/componentização)"
    else
        echo "⚠️  Prompt YAML pode não ter sido aplicado completamente"
    fi
fi

# Contar programas processados
echo ""
echo "6. Contando programas processados..."
PROGRAMAS_PADRAO=$(find teste_pkg -name "*_analise_funcional.md" 2>/dev/null | wc -l)
PROGRAMAS_HTML=$(find teste_pkg_html -name "*_analise_funcional.md" 2>/dev/null | wc -l)

echo "📊 Programas processados (padrão): $PROGRAMAS_PADRAO/5"
echo "📊 Programas processados (com HTML): $PROGRAMAS_HTML/5"

# Verificar arquivos de request/response
echo ""
echo "7. Verificando arquivos de request/response..."
REQUESTS_PADRAO=$(find teste_pkg -name "*_ai_request.json" 2>/dev/null | wc -l)
RESPONSES_PADRAO=$(find teste_pkg -name "*_ai_response.json" 2>/dev/null | wc -l)
REQUESTS_HTML=$(find teste_pkg_html -name "*_ai_request.json" 2>/dev/null | wc -l)
RESPONSES_HTML=$(find teste_pkg_html -name "*_ai_response.json" 2>/dev/null | wc -l)

echo "📁 Requests (padrão): $REQUESTS_PADRAO"
echo "📁 Responses (padrão): $RESPONSES_PADRAO"
echo "📁 Requests (com HTML): $REQUESTS_HTML"
echo "📁 Responses (com HTML): $RESPONSES_HTML"

# Mostrar estrutura final
echo ""
echo "8. Estrutura final gerada:"
echo ""
echo "=== ESTRUTURA PADRÃO ==="
tree teste_pkg 2>/dev/null || find teste_pkg -type f | sort

echo ""
echo "=== ESTRUTURA COM HTML ==="
tree teste_pkg_html 2>/dev/null || find teste_pkg_html -type f | sort

echo ""
echo "=========================================="
echo "TESTE COMPLETO FINALIZADO"
echo "=========================================="
echo "📁 Resultados salvos em:"
echo "   - teste_pkg/analise_sem_coment_def/"
echo "   - teste_pkg_html/analise_com_html/"
echo ""
echo "🎯 Estrutura conforme imagem fornecida:"
echo "   ✅ Pasta intermediária (analise_sem_coment_def)"
echo "   ✅ Pasta do modelo (model_enhanced_mock)"
echo "   ✅ Arquivos MD na raiz do modelo"
echo "   ✅ Pastas ai_requests/ e ai_responses/"
echo "   ✅ Arquivos HTML quando --html especificado"
echo ""
echo "🏦 Prompt YAML Minato com análise BIAN aplicado com sucesso!"
