# COBOL to Docs v1.6 - Sistema Completo de Análise e Documentação

## Visão Geral

O COBOL to Docs v1.6 é um sistema avançado de análise e documentação automatizada de programas COBOL que utiliza inteligência artificial, sistema RAG (Retrieval-Augmented Generation) e múltiplos provedores de modelos para gerar documentação técnica de alta qualidade.

## Características Principais

### Análise Inteligente de Código
- **Parser COBOL Avançado**: Análise completa de estruturas, divisões e seções
- **Detecção de Padrões**: Identificação automática de padrões CADOC e convenções
- **Análise de Complexidade**: Avaliação automática da complexidade do código
- **Extração de Regras de Negócio**: Identificação e documentação de lógicas de negócio

### Sistema RAG Integrado
- **Base de Conhecimento**: 79+ itens de conhecimento COBOL especializado
- **Aprendizado Contínuo**: Sistema que aprende com cada análise realizada
- **Persistência Automática**: Conhecimento salvo automaticamente na pasta data
- **Consulta Inteligente**: Recuperação contextual de informações relevantes

### Múltiplos Provedores de IA
- **LuzIA**: Modelos AWS Claude 3.5 Sonnet e Amazon Nova Pro
- **GitHub Copilot**: Integração com GPT-4 e GPT-3.5 Turbo
- **OpenAI**: Suporte completo à API OpenAI (opcional)
- **AWS Bedrock**: Integração com modelos Amazon (opcional)
- **Mock Providers**: Simulação para testes e desenvolvimento

### Funcionalidades Avançadas
- **Cache Inteligente**: Otimização de performance com cache automático
- **Processamento Paralelo**: Análise simultânea de múltiplos arquivos
- **Geração de Prompts**: Criação automática de prompts adaptativos
- **Validação Anti-Alucinação**: Sistema de validação de resultados
- **Análise de Códigos Técnicos**: Identificação e documentação de códigos específicos

## Arquitetura do Sistema

### Estrutura de Diretórios
```
cobol_to_docs_v1.6/
├── src/                          # Código fonte principal
│   ├── core/                     # Componentes centrais
│   │   ├── config.py            # Gerenciamento de configuração
│   │   ├── enhanced_model_selector.py  # Seleção inteligente de modelos
│   │   └── intelligent_model_selector.py  # Base do seletor
│   ├── providers/               # Provedores de IA
│   │   ├── provider_manager.py  # Gerenciador consolidado
│   │   ├── mock_provider.py     # Provider mock unificado
│   │   ├── luzia_provider.py    # Provider LuzIA
│   │   └── github_copilot_provider.py  # Provider GitHub Copilot
│   ├── rag/                     # Sistema RAG
│   │   ├── cobol_rag_system.py  # Sistema RAG principal
│   │   └── rag_integration.py   # Integração RAG
│   ├── analyzers/               # Analisadores especializados
│   │   ├── technical_code_analyzer.py  # Análise de códigos técnicos
│   │   ├── professional_analyzer.py    # Análise profissional
│   │   └── deep_business_analyzer.py   # Análise de regras de negócio
│   ├── generators/              # Geradores de documentação
│   │   ├── documentation_generator.py  # Gerador principal
│   │   └── advanced_report_generator.py  # Relatórios avançados
│   ├── utils/                   # Utilitários
│   │   ├── intelligent_cache.py # Cache inteligente
│   │   ├── parallel_processor.py # Processamento paralelo
│   │   ├── cost_calculator.py   # Calculadora de custos
│   │   └── hallucination_validator.py  # Validador anti-alucinação
│   └── processors/              # Processadores avançados
│       ├── advanced_processor.py # Processamento avançado
│       └── workflow_processor.py # Processamento de workflows
├── cobol_to_docs/               # Biblioteca Python
│   ├── __init__.py             # Interface principal da biblioteca
│   └── cli.py                  # Interface de linha de comando
├── config/                      # Configurações
│   ├── config.yaml             # Configuração principal
│   └── prompts_cadoc_deep_analysis.yaml  # Templates de prompts
├── data/                        # Base de conhecimento RAG
│   └── cobol_knowledge_base_cadoc_expanded.json
├── tools/                       # Ferramentas auxiliares
│   ├── cobol_to_json.py        # Conversor COBOL para JSON
│   ├── extract_business_rules.py  # Extrator de regras
│   └── generate_prompt_yaml.py  # Gerador de prompts YAML
├── docs/                        # Documentação
├── examples/                    # Exemplos de uso
├── main.py                      # Interface principal CLI
└── setup.py                     # Configuração de instalação
```

### Componentes Principais

#### ConfigManager
Gerencia todas as configurações do sistema, incluindo:
- Configurações de provedores de IA
- Templates de prompts
- Parâmetros de análise
- Configurações RAG

#### ProviderManager
Sistema consolidado que gerencia múltiplos provedores:
- Seleção automática de provedor
- Sistema de fallback
- Balanceamento de carga
- Monitoramento de status

#### RAG System
Sistema de recuperação e geração aumentada:
- Base de conhecimento especializada em COBOL
- Aprendizado contínuo automático
- Persistência na pasta data
- Consultas contextuais inteligentes

#### Enhanced Model Selector
Seletor inteligente de modelos baseado em:
- Complexidade do código
- Tamanho do programa
- Padrões identificados
- Histórico de performance

## Formas de Uso

### 1. Interface de Linha de Comando (CLI)

#### Uso Básico
```bash
# Análise simples
python main.py --fontes programa.cbl --models enhanced_mock

# Análise com múltiplos modelos
python main.py --fontes programa.cbl --models "['enhanced_mock', 'luzia']"

# Análise de diretório
python main.py --fontes /caminho/cobol/ --models enhanced_mock --output ./docs
```

#### Funcionalidades Avançadas
```bash
# Análise completa com todas as funcionalidades
python main.py --fontes programa.cbl --models enhanced_mock \
  --advanced --generate-prompts --validate --parallel

# Análise sem cache
python main.py --fontes programa.cbl --models enhanced_mock --no-cache

# Análise sem RAG
python main.py --fontes programa.cbl --models enhanced_mock --no-rag
```

### 2. Comando pip install

#### Instalação
```bash
# Instalação básica
pip install -e .

# Instalação com dependências opcionais
pip install -e .[openai,bedrock,github,full]
```

#### Uso via Comando
```bash
# Análise básica
cobol-to-docs --file programa.cbl

# Análise avançada
cobol-to-docs --file programa.cbl --model enhanced_mock --advanced

# Análise com processamento paralelo
cobol-to-docs --files /caminho/cobol/ --parallel --max-workers 8
```

### 3. Biblioteca Python

#### Importação e Uso Básico
```python
from cobol_to_docs import COBOLAnalyzer

# Inicializar analisador
analyzer = COBOLAnalyzer()

# Analisar arquivo único
result = analyzer.analyze_file('programa.cbl')

# Analisar múltiplos arquivos
results = analyzer.analyze_multiple_files(['prog1.cbl', 'prog2.cbl'])
```

#### Uso Avançado
```python
from cobol_to_docs import COBOLAnalyzer

# Configuração personalizada
analyzer = COBOLAnalyzer(config_path='minha_config.yaml')

# Análise com opções específicas
result = analyzer.analyze_code(
    cobol_code=codigo,
    model='github_copilot',
    advanced_analysis=True,
    generate_prompts=True
)

# Verificar status dos provedores
status = analyzer.get_provider_status()
print(f"Provedores disponíveis: {status}")

# Obter métricas de performance
metrics = analyzer.get_performance_metrics()
print(f"Cache hits: {metrics['cache_hits']}")
```

## Configuração

### Arquivo config.yaml
```yaml
# Configuração de provedores
providers:
  luzia:
    base_url: "https://luzia-api.example.com"
    api_key: "${LUZIA_API_KEY}"
    models:
      - "aws_claude_3_5_sonnet"
      - "amazon_nova_pro_v1"
  
  github_copilot:
    api_key: "${GITHUB_TOKEN}"
    model: "gpt-4"

# Configuração RAG
rag:
  enabled: true
  knowledge_base_path: "data/cobol_knowledge_base_cadoc_expanded.json"
  auto_learning: true
  max_context_items: 10

# Configuração de cache
cache:
  enabled: true
  max_age_hours: 24
  cleanup_interval: 3600
```

### Variáveis de Ambiente
```bash
# LuzIA
export LUZIA_API_KEY="sua_chave_luzia"

# GitHub Copilot
export GITHUB_TOKEN="seu_token_github"

# OpenAI (opcional)
export OPENAI_API_KEY="sua_chave_openai"

# AWS Bedrock (opcional)
export AWS_ACCESS_KEY_ID="sua_chave_aws"
export AWS_SECRET_ACCESS_KEY="sua_chave_secreta_aws"
```

## Funcionalidades Detalhadas

### Sistema RAG
- **Base de Conhecimento**: 79+ itens especializados em COBOL
- **Aprendizado Automático**: Cada análise expande a base de conhecimento
- **Persistência**: Conhecimento salvo automaticamente em data/
- **Consulta Contextual**: Recuperação inteligente baseada no código analisado

### Cache Inteligente
- **Cache de Análises**: Resultados de análises anteriores
- **Cache de Modelos**: Recomendações de modelo baseadas no código
- **Cache RAG**: Consultas e resultados RAG
- **Limpeza Automática**: Remoção de cache expirado

### Processamento Paralelo
- **Múltiplos Arquivos**: Análise simultânea de vários programas
- **Configurável**: Número de workers ajustável
- **Fallback Sequencial**: Automaticamente volta ao sequencial se necessário

### Validação Anti-Alucinação
- **Verificação de Consistência**: Validação de resultados gerados
- **Detecção de Padrões**: Identificação de respostas inconsistentes
- **Correção Automática**: Tentativas de correção quando possível

## Saídas Geradas

### Documentação Principal
- **Análise Funcional**: Documentação completa do programa
- **Regras de Negócio**: Extração e documentação de lógicas
- **Estruturas de Dados**: Análise de copybooks e variáveis
- **Fluxo de Execução**: Mapeamento do fluxo do programa

### Relatórios Auxiliares
- **Relatório de Custos**: Análise de custos por modelo e token
- **Relatório RAG**: Estatísticas da base de conhecimento
- **Relatório de Performance**: Métricas de cache e processamento
- **Relatório Consolidado**: Resumo geral da análise

### Formatos de Saída
- **Markdown**: Documentação principal em formato MD
- **JSON**: Dados estruturados para integração
- **YAML**: Prompts gerados em formato YAML
- **Relatórios**: Arquivos de log e estatísticas

## Troubleshooting

### Problemas Comuns

#### Erro de Importação
```bash
# Verificar instalação
pip list | grep cobol-to-docs

# Reinstalar se necessário
pip install -e . --force-reinstall
```

#### Problemas de Provedor
```python
# Verificar status dos provedores
from cobol_to_docs import COBOLAnalyzer
analyzer = COBOLAnalyzer()
status = analyzer.get_provider_status()
print(status)
```

#### Cache Corrompido
```bash
# Limpar cache
rm -rf cache/
python main.py --no-cache --fontes programa.cbl --models enhanced_mock
```

#### RAG Não Funciona
```bash
# Verificar base de conhecimento
ls -la data/cobol_knowledge_base*.json

# Executar sem RAG temporariamente
python main.py --no-rag --fontes programa.cbl --models enhanced_mock
```

## Desenvolvimento e Extensão

### Adicionando Novos Provedores
1. Criar classe herdando de `BaseProvider`
2. Implementar métodos obrigatórios
3. Adicionar ao `ProviderManager`
4. Configurar em `config.yaml`

### Expandindo a Base RAG
1. Adicionar novos itens em `data/cobol_knowledge_base*.json`
2. Sistema aprende automaticamente durante análises
3. Conhecimento persistido automaticamente

### Criando Novos Analisadores
1. Herdar de classe base apropriada
2. Implementar lógica específica
3. Integrar ao fluxo principal

## Licença e Suporte

Este sistema foi desenvolvido para análise e documentação de programas COBOL corporativos. Para suporte técnico ou dúvidas sobre implementação, consulte a documentação técnica ou entre em contato com a equipe de desenvolvimento.

---

**COBOL to Docs v1.6** - Sistema completo, organizado e totalmente funcional para análise e documentação automatizada de programas COBOL.
