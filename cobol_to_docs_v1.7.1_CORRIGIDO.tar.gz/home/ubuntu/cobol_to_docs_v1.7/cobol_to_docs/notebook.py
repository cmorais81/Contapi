"""
COBOL to Docs - Interface otimizada para Jupyter Notebooks
Fornece uma interface simplificada e amigável para uso em notebooks
"""

import os
import sys
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional, Union
import json

# Configurar logging para notebooks
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

class COBOLNotebook:
    """
    Interface simplificada do COBOL to Docs para uso em Jupyter Notebooks
    
    Exemplo de uso:
    ```python
    from cobol_to_docs.notebook import COBOLNotebook
    
    # Inicializar
    cobol = COBOLNotebook()
    
    # Analisar um programa
    result = cobol.analyze('programa.cbl')
    
    # Ver resultados
    cobol.show_summary(result)
    ```
    """
    
    def __init__(self, config_path: Optional[str] = None, quiet: bool = False):
        """
        Inicializar COBOL Notebook
        
        Args:
            config_path: Caminho para arquivo de configuração personalizado
            quiet: Se True, reduz a verbosidade dos logs
        """
        if quiet:
            logging.getLogger().setLevel(logging.WARNING)
            
        self.config_path = config_path
        self._analyzer = None
        self._setup_paths()
        self._init_analyzer()
        
    def _setup_paths(self):
        """Configurar caminhos para funcionamento em notebooks"""
        # Detectar se estamos em um notebook
        try:
            from IPython import get_ipython
            if get_ipython() is not None:
                self.in_notebook = True
            else:
                self.in_notebook = False
        except ImportError:
            self.in_notebook = False
            
        # Configurar diretório base
        current_dir = Path.cwd()
        self.base_dir = current_dir
        
        # Criar diretório de saída se não existir
        self.output_dir = current_dir / "cobol_analysis"
        self.output_dir.mkdir(exist_ok=True)
        
    def _init_analyzer(self):
        """Inicializar o analisador COBOL"""
        try:
            # Adicionar caminho do módulo se necessário
            module_path = Path(__file__).parent.parent
            if str(module_path) not in sys.path:
                sys.path.insert(0, str(module_path))
                
            from cobol_to_docs import COBOLAnalyzer
            self._analyzer = COBOLAnalyzer(config_path=self.config_path)
            
            if not hasattr(self, 'quiet') or not self.quiet:
                print("COBOL to Docs inicializado com sucesso!")
                print(f"Modelos disponíveis: {self.get_available_models()}")
                
        except Exception as e:
            print(f"Erro ao inicializar COBOL to Docs: {e}")
            self._analyzer = None
            
    def analyze(self, 
                source: Union[str, Path], 
                model: str = "enhanced_mock",
                output_name: Optional[str] = None,
                save_pdf: bool = True,
                save_messages: bool = False) -> Dict[str, Any]:
        """
        Analisar programa COBOL
        
        Args:
            source: Caminho para arquivo .cbl ou string com código COBOL
            model: Modelo a usar para análise
            output_name: Nome personalizado para saída
            save_pdf: Se deve gerar relatórios em PDF
            save_messages: Se deve salvar mensagens enviadas/recebidas
            
        Returns:
            Dicionário com resultados da análise
        """
        if not self._analyzer:
            return {"error": "Analisador não inicializado"}
            
        try:
            # Preparar arquivo de entrada
            if isinstance(source, str) and not Path(source).exists():
                # Assumir que é código COBOL direto
                temp_file = self.output_dir / "temp_program.cbl"
                temp_file.write_text(source)
                source_path = temp_file
            else:
                source_path = Path(source)
                
            if not source_path.exists():
                return {"error": f"Arquivo não encontrado: {source_path}"}
                
            # Configurar saída
            if output_name:
                output_path = self.output_dir / output_name
            else:
                output_path = self.output_dir / f"analysis_{source_path.stem}"
                
            # Executar análise
            print(f"Analisando {source_path.name}...")
            
            result = self._analyzer.analyze_file(
                str(source_path),
                model=model,
                output_dir=str(output_path)
            )
            
            # Adicionar informações extras
            result.update({
                "source_file": str(source_path),
                "output_dir": str(output_path),
                "model_used": model,
                "pdf_generated": save_pdf,
                "messages_saved": save_messages
            })
            
            print(f"Análise concluída! Resultados em: {output_path}")
            return result
            
        except Exception as e:
            error_msg = f"Erro na análise: {e}"
            print(error_msg)
            return {"error": error_msg}
            
    def analyze_code(self, cobol_code: str, program_name: str = "notebook_program") -> Dict[str, Any]:
        """
        Analisar código COBOL diretamente (útil para células de notebook)
        
        Args:
            cobol_code: Código COBOL como string
            program_name: Nome do programa para identificação
            
        Returns:
            Dicionário com resultados da análise
        """
        # Criar arquivo temporário
        temp_file = self.output_dir / f"{program_name}.cbl"
        temp_file.write_text(cobol_code)
        
        return self.analyze(temp_file, output_name=f"analysis_{program_name}")
        
    def get_available_models(self) -> List[str]:
        """Obter lista de modelos disponíveis"""
        if self._analyzer:
            return self._analyzer.get_available_models()
        return []
        
    def show_summary(self, result: Dict[str, Any]) -> None:
        """
        Exibir resumo dos resultados de forma amigável para notebooks
        
        Args:
            result: Resultado da análise
        """
        if "error" in result:
            print(f"ERRO: {result['error']}")
            return
            
        print("=== RESUMO DA ANÁLISE ===")
        print(f"Arquivo: {result.get('source_file', 'N/A')}")
        print(f"Modelo: {result.get('model_used', 'N/A')}")
        print(f"Status: {'Sucesso' if result.get('success', False) else 'Falha'}")
        
        if 'tokens_used' in result:
            print(f"Tokens utilizados: {result['tokens_used']}")
            
        if 'processing_time' in result:
            print(f"Tempo de processamento: {result['processing_time']:.2f}s")
            
        if 'output_dir' in result:
            output_path = Path(result['output_dir'])
            if output_path.exists():
                files = list(output_path.glob("*"))
                print(f"Arquivos gerados: {len(files)}")
                for file in files[:5]:  # Mostrar apenas os primeiros 5
                    print(f"  - {file.name}")
                if len(files) > 5:
                    print(f"  ... e mais {len(files) - 5} arquivos")
                    
        print("========================")
        
    def list_analyses(self) -> List[str]:
        """Listar análises realizadas"""
        if not self.output_dir.exists():
            return []
            
        analyses = []
        for item in self.output_dir.iterdir():
            if item.is_dir() and item.name.startswith("analysis_"):
                analyses.append(item.name)
                
        return sorted(analyses)
        
    def load_analysis(self, analysis_name: str) -> Optional[Dict[str, Any]]:
        """
        Carregar resultados de uma análise anterior
        
        Args:
            analysis_name: Nome da análise (sem prefixo analysis_)
            
        Returns:
            Dicionário com resultados ou None se não encontrado
        """
        if not analysis_name.startswith("analysis_"):
            analysis_name = f"analysis_{analysis_name}"
            
        analysis_path = self.output_dir / analysis_name
        if not analysis_path.exists():
            print(f"Análise não encontrada: {analysis_name}")
            return None
            
        # Tentar carregar relatório consolidado
        consolidated_file = analysis_path / "relatorio_consolidado.json"
        if consolidated_file.exists():
            try:
                with open(consolidated_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"Erro ao carregar análise: {e}")
                
        return None
        
    def get_rag_info(self) -> Dict[str, Any]:
        """Obter informações sobre o sistema RAG"""
        if self._analyzer and hasattr(self._analyzer, 'rag_integration'):
            try:
                rag = self._analyzer.rag_integration
                return {
                    "knowledge_base_size": len(rag.cobol_rag.knowledge_base) if hasattr(rag, 'cobol_rag') else 0,
                    "cache_size": len(rag.cobol_rag.embedding_cache) if hasattr(rag, 'cobol_rag') else 0,
                    "auto_learning": True
                }
            except:
                pass
                
        return {"status": "RAG não disponível"}
        
    def clear_cache(self) -> None:
        """Limpar cache do sistema"""
        if self._analyzer and hasattr(self._analyzer, 'cache_manager'):
            try:
                self._analyzer.cache_manager.clear_all_cache()
                print("Cache limpo com sucesso!")
            except Exception as e:
                print(f"Erro ao limpar cache: {e}")
        else:
            print("Cache não disponível")
            
    def __repr__(self):
        """Representação string para notebooks"""
        status = "Inicializado" if self._analyzer else "Não inicializado"
        models = len(self.get_available_models())
        return f"COBOLNotebook(status={status}, modelos={models})"


# Função de conveniência para uso rápido
def quick_analyze(cobol_code: str, program_name: str = "quick_analysis") -> Dict[str, Any]:
    """
    Função de conveniência para análise rápida em notebooks
    
    Args:
        cobol_code: Código COBOL como string
        program_name: Nome do programa
        
    Returns:
        Resultado da análise
    """
    cobol = COBOLNotebook(quiet=True)
    return cobol.analyze_code(cobol_code, program_name)


# Exemplo de uso para documentação
EXAMPLE_USAGE = '''
# Exemplo de uso em Jupyter Notebook:

from cobol_to_docs.notebook import COBOLNotebook

# 1. Inicializar
cobol = COBOLNotebook()

# 2. Analisar código diretamente
cobol_code = """
IDENTIFICATION DIVISION.
PROGRAM-ID. HELLO-WORLD.
PROCEDURE DIVISION.
    DISPLAY 'Hello, World!'.
    STOP RUN.
"""

result = cobol.analyze_code(cobol_code, "hello_world")
cobol.show_summary(result)

# 3. Analisar arquivo
result = cobol.analyze("meu_programa.cbl")

# 4. Ver análises anteriores
print("Análises realizadas:", cobol.list_analyses())

# 5. Carregar análise anterior
old_result = cobol.load_analysis("hello_world")

# 6. Informações do sistema
print("Info RAG:", cobol.get_rag_info())
'''
