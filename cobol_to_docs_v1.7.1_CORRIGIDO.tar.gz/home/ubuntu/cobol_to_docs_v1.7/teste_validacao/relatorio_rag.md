# Relatório RAG - Base de Conhecimento COBOL

## Estatísticas Gerais
- **Total de itens**: 79
- **Última atualização**: N/A
- **Versão da base**: 1.7

## Distribuição por Categoria
- **Fundamentos CADOC**: 1 itens
- **Processamento Documental**: 1 itens
- **Indexação**: 1 itens
- **Controle de Qualidade**: 1 itens
- **Auditoria**: 1 itens
- **Retenção**: 1 itens
- **Busca**: 1 itens
- **Integração**: 1 itens
- **Processamento Batch**: 1 itens
- **Segurança**: 1 itens
- **Workflow**: 1 itens
- **Métricas**: 1 itens
- **Modernização**: 1 itens
- **Disaster Recovery**: 1 itens
- **OCR**: 1 itens
- **Processamento Bancário**: 1 itens
- **Documentos Jurídicos**: 1 itens
- **Comprovantes Eletrônicos**: 1 itens
- **Documentos de Crédito**: 1 itens
- **Compliance Regulatório**: 1 itens
- **Captura Inteligente**: 1 itens
- **Gestão de Exceções**: 1 itens
- **Integração Core Banking**: 1 itens
- **Analytics Documental**: 1 itens
- **Controle de Versões**: 1 itens
- **technical_doc**: 54 itens

## Conhecimento Recente

## Métricas de Uso
- **Consultas realizadas**: 0
- **Cache hits**: 0
- **Itens aprendidos**: 0

---
*Relatório gerado pelo sistema COBOL to Docs v1.7*
