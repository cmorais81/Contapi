# COBOL to Docs v1.7

Sistema completo de análise e documentação automatizada de programas COBOL com IA, RAG e auto-learning.

## Principais Funcionalidades

### Sistema RAG com Auto-Learning
- Base de conhecimento com 79+ itens que cresce automaticamente
- Aprendizado contínuo a cada análise realizada
- Contextualização inteligente baseada em conhecimento acumulado
- Persistência automática de novos padrões descobertos

### Múltiplas Interfaces
- **Jupyter Notebooks**: Interface otimizada para análise interativa
- **CLI Direto**: Linha de comando completa com todas as funcionalidades
- **Biblioteca Python**: Uso programático em scripts e aplicações
- **pip install**: Instalação e uso como biblioteca padrão

### Análises Avançadas
- Identificação automática de regras de negócio
- Análise de códigos técnicos especializados
- Validação anti-alucinação para qualidade
- Processamento paralelo para múltiplos arquivos
- Cache inteligente para otimização de performance

## Instalação Rápida

### Via pip (Recomendado)
```bash
# Extrair pacote
tar -xzf cobol_to_docs_v1.7_FINAL.tar.gz
cd cobol_to_docs_v1.7

# Instalar
pip install -e .

# Configurar PYTHONPATH (se necessário)
export PYTHONPATH=/path/to/cobol_to_docs_v1.7:$PYTHONPATH
```

## Formas de Uso

### 1. Jupyter Notebook (Recomendado)
```python
from cobol_to_docs import COBOLNotebook, quick_analyze

# Inicializar
cobol = COBOLNotebook()
print(f"Modelos disponíveis: {cobol.get_available_models()}")

# Analisar código COBOL
cobol_code = '''
IDENTIFICATION DIVISION.
PROGRAM-ID. CALCULO-JUROS.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-PRINCIPAL PIC 9(7)V99 VALUE 1000.00.
01 WS-TAXA      PIC 9V999   VALUE 0.05.
PROCEDURE DIVISION.
    COMPUTE WS-JUROS = WS-PRINCIPAL * WS-TAXA.
    DISPLAY 'Juros: ' WS-JUROS.
    STOP RUN.
'''

result = cobol.analyze_code(cobol_code, "calculo_juros")
cobol.show_summary(result)

# Ver informações do sistema RAG
print("Info RAG:", cobol.get_rag_info())
```

### 2. CLI Direto
```bash
# Análise básica
python main.py --fontes programa.cbl --models enhanced_mock --output resultado

# Análise completa com todas as funcionalidades
python main.py --fontes programa.cbl --models enhanced_mock --output resultado \
  --pdf --save-messages --advanced --validate --parallel
```

### 3. Comando pip install
```bash
# Após instalação
cobol-to-docs --file programa.cbl --model enhanced_mock --output resultado --pdf
```

### 4. Biblioteca Python
```python
from cobol_to_docs import COBOLAnalyzer

analyzer = COBOLAnalyzer()
result = analyzer.analyze_file('programa.cbl', model='enhanced_mock')
print(f"Sucesso: {result.get('success', False)}")
```

### 5. Análise Rápida
```python
from cobol_to_docs import quick_analyze

result = quick_analyze(cobol_code, "teste_rapido")
print(f"Tokens utilizados: {result.get('tokens_used', 0)}")
```

## Argumentos Principais

### Obrigatórios
- `--fontes` / `--file`: Arquivo ou diretório COBOL
- `--models` / `--model`: Modelo a usar (enhanced_mock, basic, etc.)

### Funcionais
- `--output`: Diretório de saída (padrão: análise com timestamp)
- `--pdf`: Gerar relatórios HTML/PDF otimizados
- `--save-messages`: Salvar prompts enviados e respostas recebidas
- `--advanced`: Ativar análises avançadas (regras de negócio, códigos técnicos)
- `--validate`: Ativar validação anti-alucinação
- `--parallel`: Processamento paralelo de múltiplos arquivos

### Controle
- `--no-cache`: Desabilitar cache inteligente
- `--no-rag`: Desabilitar sistema RAG
- `--quiet`: Reduzir verbosidade dos logs
- `--debug`: Ativar logs detalhados para debugging

## Estrutura de Saída

```
resultado/
├── model_enhanced_mock/              # Análises por modelo
│   ├── PROGRAMA_analise_funcional.md
│   ├── ai_requests/                  # Prompts enviados (se --save-messages)
│   └── ai_responses/                 # Respostas recebidas (se --save-messages)
├── relatorio_consolidado.json       # Relatório consolidado
├── relatorio_custos.json           # Análise de custos
├── relatorio_estatisticas.json     # Estatísticas de processamento
├── relatorio_rag.md                # Relatório do sistema RAG
├── relatorio_rag.html              # Versão HTML/PDF (se --pdf)
└── messages/                       # Mensagens detalhadas (se --save-messages)
```

## Sistema RAG e Auto-Learning

### Base de Conhecimento
- **79+ itens** de conhecimento COBOL
- **Categorias**: technical_doc, banking_rule, data_structure, business_logic
- **Domínios**: banking, general, mainframe, business, technical
- **Crescimento automático** a cada análise

### Auto-Learning Ativo
```python
# O sistema aprende automaticamente:
# 1. Extrai padrões da análise realizada
# 2. Identifica conhecimento valioso
# 3. Adiciona à base de conhecimento
# 4. Persiste automaticamente em data/
# 5. Enriquece análises futuras

# Verificar crescimento da base
cobol = COBOLNotebook()
rag_info = cobol.get_rag_info()
print(f"Itens na base: {rag_info['knowledge_base_size']}")
print(f"Auto-learning: {rag_info['auto_learning']}")
```

## Providers Disponíveis

### Configurados
- **enhanced_mock**: Provider de teste avançado (padrão)
- **basic**: Provider básico para testes simples
- **luzia**: Integração com modelos LuzIA (AWS Claude)
- **github_copilot**: Integração com GitHub Copilot (GPT-4)

### Opcionais (com dependências)
- **openai**: OpenAI GPT models
- **bedrock**: AWS Bedrock models
- **anthropic**: Anthropic Claude models

## Exemplos Práticos

### Análise de Sistema Bancário
```python
banking_code = '''
IDENTIFICATION DIVISION.
PROGRAM-ID. CALCULO-PRESTACAO.
DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-VALOR-FINANCIADO  PIC 9(8)V99.
01 WS-TAXA-JUROS        PIC 9V9999.
01 WS-PRAZO-MESES       PIC 999.
01 WS-PRESTACAO         PIC 9(6)V99.
PROCEDURE DIVISION.
    COMPUTE WS-PRESTACAO = WS-VALOR-FINANCIADO * 
        (WS-TAXA-JUROS * (1 + WS-TAXA-JUROS) ** WS-PRAZO-MESES) /
        ((1 + WS-TAXA-JUROS) ** WS-PRAZO-MESES - 1).
    DISPLAY 'Prestação: R$ ' WS-PRESTACAO.
    STOP RUN.
'''

result = cobol.analyze_code(banking_code, "calculo_prestacao")
# Sistema RAG reconhece padrões bancários e enriquece a análise
```

### Análise de Arquivo
```python
# Analisar arquivo existente
result = cobol.analyze("sistema_vendas.cbl", 
                      model="enhanced_mock",
                      save_pdf=True,
                      save_messages=True)

# Ver resultados
cobol.show_summary(result)

# Listar análises realizadas
print("Análises:", cobol.list_analyses())

# Carregar análise anterior
old_result = cobol.load_analysis("sistema_vendas")
```

## Configuração

### Arquivo config/config.yaml
```yaml
providers:
  luzia:
    base_url: "https://api.luzia.com"
    models:
      - "aws_claude_3_5_sonnet"
      - "aws_claude_3_5_haiku"
  
  github_copilot:
    base_url: "https://api.githubcopilot.com"
    models:
      - "gpt-4"
      - "gpt-3.5-turbo"

rag:
  enabled: true
  auto_learning: true
  knowledge_base_path: "data/cobol_knowledge_base_cadoc_expanded.json"
  embedding_cache_path: "data/embeddings_cache.json"

cache:
  enabled: true
  max_workers: 4
  cache_dir: "cache/"

analysis:
  default_model: "enhanced_mock"
  enable_validation: true
  enable_technical_codes: true
```

### Variáveis de Ambiente
```bash
export PYTHONPATH=/path/to/cobol_to_docs_v1.7:$PYTHONPATH
export COBOL_TO_DOCS_CONFIG=/path/to/config.yaml
export COBOL_TO_DOCS_LOG_LEVEL=INFO
```

## Arquitetura

### Princípios SOLID Aplicados
- **Single Responsibility**: Cada classe tem uma responsabilidade específica
- **Open/Closed**: Sistema extensível sem modificar código existente
- **Liskov Substitution**: Providers intercambiáveis
- **Interface Segregation**: Interfaces específicas para cada funcionalidade
- **Dependency Inversion**: Sistema baseado em abstrações

### Componentes Principais
```
src/
├── providers/          # Sistema de provedores de IA
│   ├── mock_provider.py
│   ├── luzia_provider.py
│   ├── github_copilot_provider.py
│   └── provider_manager.py
├── rag/               # Sistema RAG e auto-learning
│   ├── cobol_rag_system.py
│   ├── rag_integration.py
│   └── auto_learning_enhancement.py
├── analyzers/         # Analisadores especializados
│   ├── enhanced_cobol_analyzer.py
│   ├── technical_code_analyzer.py
│   └── business_rules_extractor.py
├── utils/             # Utilitários e cache
│   ├── intelligent_cache.py
│   ├── parallel_processor.py
│   └── hallucination_validator.py
└── core/              # Núcleo do sistema
    ├── config.py
    ├── adaptive_prompt_generator.py
    └── enhanced_model_selector.py
```

## Troubleshooting

### Erro de Importação
```bash
# Solução: Configurar PYTHONPATH
export PYTHONPATH=/path/to/cobol_to_docs_v1.7:$PYTHONPATH
python -c "from cobol_to_docs import COBOLNotebook; print('OK')"
```

### Comando não encontrado
```bash
# Solução: Reinstalar
pip install -e . --force-reinstall
cobol-to-docs --help
```

### Base RAG não carrega
```bash
# Verificar arquivos
ls -la data/cobol_knowledge_base*.json

# Recriar se necessário
python -c "
from src.rag.cobol_rag_system import CobolRAGSystem
from src.core.config import ConfigManager
config = ConfigManager()
rag = CobolRAGSystem(config)
print('Base RAG inicializada')
"
```

### PDF não gerado
```bash
# Usar argumento --pdf
python main.py --fontes programa.cbl --models enhanced_mock --output resultado --pdf

# Verificar arquivo HTML gerado
ls -la resultado/relatorio_rag.html
```

## Dependências

### Essenciais
```
requests>=2.28.0
pyyaml>=6.0
jinja2>=3.1.0
scikit-learn>=1.2.0
numpy>=1.24.0
markdown>=3.4.0
```

### Opcionais
```
# Para providers específicos
openai>=1.0.0          # OpenAI provider
boto3>=1.26.0          # AWS Bedrock provider
anthropic>=0.7.0       # Anthropic provider

# Para notebooks
jupyter>=1.0.0
ipython>=7.0.0
pandas>=1.3.0
matplotlib>=3.5.0
```

## Desenvolvimento

### Estrutura do Projeto
```
cobol_to_docs_v1.7/
├── main.py                    # Interface principal CLI
├── cobol_to_docs/            # Biblioteca Python
│   ├── __init__.py           # Interface principal
│   ├── cli.py                # CLI via pip install
│   └── notebook.py           # Interface para notebooks
├── src/                      # Código fonte
├── config/                   # Configurações
├── data/                     # Base de conhecimento RAG
├── examples/                 # Exemplos de uso
├── docs/                     # Documentação
├── tools/                    # Ferramentas auxiliares
└── tests/                    # Testes (futuro)
```

### Contribuição
1. Fork o projeto
2. Crie uma branch para sua feature
3. Implemente seguindo princípios SOLID
4. Teste todas as interfaces
5. Submeta um pull request

## Changelog v1.7.1 (Versão Corrigida)

### Correções (v1.7.1)
- **Consolidação da Interface**: `main.py` foi consolidado como a interface de linha de comando principal, eliminando arquivos duplicados e conflitantes como `main_original.py`.
- **Assinaturas de Métodos**: Corrigido o método `generate_documentation` que era chamado com uma assinatura incorreta. O método correto `generate_program_documentation` agora é usado.
- **Manipulação de Configuração**: Resolvidos problemas de passagem de configuração para `ProviderManager` e `RAGIntegration`, garantindo que os componentes sejam inicializados corretamente.
- **Métodos Ausentes**: Implementado o método `learn_from_analysis` que faltava no `RAGIntegration`, restaurando a funcionalidade de auto-aprendizagem.
- **Comando de Status**: Corrigido o comando `--status` que falhava ao tentar acessar um atributo inexistente, garantindo que o status do sistema possa ser verificado corretamente.
- **Bugs de Geração de Documentação**: Corrigidos múltiplos bugs no `DocumentationGenerator` que impediam a criação de relatórios de análise devido a referências incorretas de objetos.
- **Erro de Cache**: Corrigida a chamada para o método de cache que causava falhas durante a análise do programa.

### Novas Funcionalidades (v1.7)
- Interface COBOLNotebook otimizada para Jupyter
- Função quick_analyze para análise rápida
- Auto-learning ativo com persistência automática
- Geração de PDF otimizada
- Documentação de mensagens completa
- Sistema sem ícones (interface profissional)

### Melhorias (v1.7)
- Arquitetura SOLID implementada
- Providers consolidados (sem duplicações)
- Cache inteligente otimizado
- Processamento paralelo configurável
- Validação anti-alucinação aprimorada
- Base RAG expandida (79+ itens)

### Correções (v1.7)
- Compatibilidade com notebooks melhorada
- Entry points do pip install corrigidos
- Persistência do auto-learning garantida
- Logs mais limpos e informativos
- Tratamento de erros aprimorado

### Novas Funcionalidades
- Interface COBOLNotebook otimizada para Jupyter
- Função quick_analyze para análise rápida
- Auto-learning ativo com persistência automática
- Geração de PDF otimizada
- Documentação de mensagens completa
- Sistema sem ícones (interface profissional)

### Melhorias
- Arquitetura SOLID implementada
- Providers consolidados (sem duplicações)
- Cache inteligente otimizado
- Processamento paralelo configurável
- Validação anti-alucinação aprimorada
- Base RAG expandida (79+ itens)

### Correções
- Compatibilidade com notebooks melhorada
- Entry points do pip install corrigidos
- Persistência do auto-learning garantida
- Logs mais limpos e informativos
- Tratamento de erros aprimorado

## Licença

MIT License - veja LICENSE para detalhes.

## Suporte

Para dúvidas ou problemas:
1. Consultar documentação em `docs/`
2. Verificar exemplos em `examples/`
3. Verificar logs em `logs/`
4. Abrir issue no repositório

---

**COBOL to Docs v1.7 - Sistema completo de análise COBOL com IA e auto-learning**

*Quanto mais você usa, mais inteligente o sistema fica!*
