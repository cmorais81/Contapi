"""
Gerenciador de Dependências Opcionais
Sistema para instalação automática de bibliotecas opcionais mantendo compatibilidade.
"""

import os
import sys
import subprocess
import logging
import importlib
from typing import Dict, List, Any, Optional, Tuple
import json

logger = logging.getLogger(__name__)

class DependencyManager:
    """
    Gerenciador de dependências opcionais.
    
    Funcionalidades:
    - Detecção automática de bibliotecas ausentes
    - Instalação opcional de dependências
    - Verificação de compatibilidade
    - Fallback gracioso quando bibliotecas não estão disponíveis
    - Manutenção de compatibilidade total
    """
    
    def __init__(self):
        """Inicializa o gerenciador de dependências."""
        self.optional_dependencies = {
            'openai': {
                'package': 'openai>=1.0.0',
                'description': 'Suporte a modelos OpenAI (GPT-4, GPT-3.5)',
                'providers': ['openai'],
                'features': ['OpenAI GPT models', 'ChatGPT integration']
            },
            'boto3': {
                'package': 'boto3>=1.26.0',
                'description': 'Suporte a AWS Bedrock',
                'providers': ['bedrock'],
                'features': ['AWS Bedrock models', 'Claude via Bedrock', 'Titan models']
            },
            'anthropic': {
                'package': 'anthropic>=0.7.0',
                'description': 'Suporte direto a modelos Anthropic Claude',
                'providers': ['anthropic'],
                'features': ['Claude direct API', 'Anthropic models']
            },
            'google-cloud-aiplatform': {
                'package': 'google-cloud-aiplatform>=1.25.0',
                'description': 'Suporte a Google Cloud AI Platform',
                'providers': ['google'],
                'features': ['Vertex AI', 'PaLM models', 'Gemini models']
            },
            'azure-cognitiveservices-language': {
                'package': 'azure-cognitiveservices-language>=0.2.0',
                'description': 'Suporte a Azure Cognitive Services',
                'providers': ['azure'],
                'features': ['Azure OpenAI', 'Cognitive Services']
            },
            'transformers': {
                'package': 'transformers>=4.20.0',
                'description': 'Suporte a modelos Hugging Face locais',
                'providers': ['huggingface'],
                'features': ['Local models', 'Offline processing', 'Custom models']
            },
            'torch': {
                'package': 'torch>=1.12.0',
                'description': 'PyTorch para modelos locais',
                'providers': ['local'],
                'features': ['Local inference', 'GPU acceleration']
            },
            'sentence-transformers': {
                'package': 'sentence-transformers>=2.2.0',
                'description': 'Embeddings avançados para RAG',
                'providers': ['rag'],
                'features': ['Better embeddings', 'Semantic search', 'RAG optimization']
            },
            'faiss-cpu': {
                'package': 'faiss-cpu>=1.7.0',
                'description': 'Busca vetorial otimizada para RAG',
                'providers': ['rag'],
                'features': ['Fast vector search', 'Large knowledge bases', 'Similarity search']
            },
            'chromadb': {
                'package': 'chromadb>=0.4.0',
                'description': 'Base de dados vetorial para RAG',
                'providers': ['rag'],
                'features': ['Vector database', 'Persistent storage', 'Advanced RAG']
            }
        }
        
        self.installed_packages = self._check_installed_packages()
        logger.info(f"Dependency Manager inicializado: {len(self.installed_packages)} pacotes opcionais detectados")
    
    def _check_installed_packages(self) -> Dict[str, bool]:
        """
        Verifica quais pacotes opcionais estão instalados.
        
        Returns:
            Dicionário com status de instalação
        """
        installed = {}
        
        for package_name in self.optional_dependencies.keys():
            try:
                importlib.import_module(package_name.replace('-', '_'))
                installed[package_name] = True
                logger.debug(f"Pacote opcional detectado: {package_name}")
            except ImportError:
                installed[package_name] = False
                logger.debug(f"Pacote opcional ausente: {package_name}")
        
        return installed
    
    def check_provider_dependencies(self, provider_name: str) -> Dict[str, Any]:
        """
        Verifica dependências para um provider específico.
        
        Args:
            provider_name: Nome do provider
            
        Returns:
            Status das dependências do provider
        """
        required_deps = []
        missing_deps = []
        
        for dep_name, dep_info in self.optional_dependencies.items():
            if provider_name in dep_info['providers']:
                required_deps.append(dep_name)
                if not self.installed_packages.get(dep_name, False):
                    missing_deps.append(dep_name)
        
        return {
            'provider': provider_name,
            'required_dependencies': required_deps,
            'missing_dependencies': missing_deps,
            'is_available': len(missing_deps) == 0,
            'installation_command': self._get_installation_command(missing_deps)
        }
    
    def _get_installation_command(self, packages: List[str]) -> str:
        """
        Gera comando de instalação para pacotes.
        
        Args:
            packages: Lista de pacotes
            
        Returns:
            Comando pip install
        """
        if not packages:
            return ""
        
        package_specs = []
        for package in packages:
            if package in self.optional_dependencies:
                package_specs.append(self.optional_dependencies[package]['package'])
        
        return f"pip install {' '.join(package_specs)}"
    
    def install_dependencies(self, packages: List[str], auto_confirm: bool = False) -> Dict[str, Any]:
        """
        Instala dependências opcionais.
        
        Args:
            packages: Lista de pacotes para instalar
            auto_confirm: Se True, instala sem confirmação
            
        Returns:
            Resultado da instalação
        """
        if not packages:
            return {'success': True, 'message': 'Nenhum pacote para instalar'}
        
        # Filtrar apenas pacotes válidos
        valid_packages = [p for p in packages if p in self.optional_dependencies]
        if not valid_packages:
            return {'success': False, 'message': 'Nenhum pacote válido especificado'}
        
        # Confirmar instalação se necessário
        if not auto_confirm:
            package_list = '\n'.join([
                f"  - {pkg}: {self.optional_dependencies[pkg]['description']}"
                for pkg in valid_packages
            ])
            
            print(f"\nPacotes a serem instalados:\n{package_list}\n")
            response = input("Deseja continuar com a instalação? (s/N): ").lower().strip()
            
            if response not in ['s', 'sim', 'y', 'yes']:
                return {'success': False, 'message': 'Instalação cancelada pelo usuário'}
        
        # Instalar pacotes
        results = {}
        for package in valid_packages:
            try:
                package_spec = self.optional_dependencies[package]['package']
                logger.info(f"Instalando {package}: {package_spec}")
                
                result = subprocess.run([
                    sys.executable, '-m', 'pip', 'install', package_spec
                ], capture_output=True, text=True, timeout=300)
                
                if result.returncode == 0:
                    results[package] = {'success': True, 'message': 'Instalado com sucesso'}
                    self.installed_packages[package] = True
                    logger.info(f"Pacote {package} instalado com sucesso")
                else:
                    results[package] = {'success': False, 'message': result.stderr}
                    logger.error(f"Erro ao instalar {package}: {result.stderr}")
                    
            except subprocess.TimeoutExpired:
                results[package] = {'success': False, 'message': 'Timeout na instalação'}
                logger.error(f"Timeout ao instalar {package}")
            except Exception as e:
                results[package] = {'success': False, 'message': str(e)}
                logger.error(f"Exceção ao instalar {package}: {e}")
        
        # Resumo
        successful = sum(1 for r in results.values() if r['success'])
        total = len(results)
        
        return {
            'success': successful == total,
            'results': results,
            'summary': f"{successful}/{total} pacotes instalados com sucesso"
        }
    
    def get_available_features(self) -> Dict[str, Any]:
        """
        Lista recursos disponíveis baseados nas dependências instaladas.
        
        Returns:
            Recursos disponíveis por categoria
        """
        features = {
            'providers': {
                'available': [],
                'unavailable': []
            },
            'enhancements': {
                'available': [],
                'unavailable': []
            }
        }
        
        # Verificar providers
        provider_deps = {}
        for dep_name, dep_info in self.optional_dependencies.items():
            for provider in dep_info['providers']:
                if provider not in provider_deps:
                    provider_deps[provider] = []
                provider_deps[provider].append(dep_name)
        
        for provider, deps in provider_deps.items():
            if all(self.installed_packages.get(dep, False) for dep in deps):
                features['providers']['available'].append(provider)
            else:
                features['providers']['unavailable'].append({
                    'provider': provider,
                    'missing_deps': [dep for dep in deps if not self.installed_packages.get(dep, False)]
                })
        
        # Verificar melhorias
        enhancement_features = []
        for dep_name, dep_info in self.optional_dependencies.items():
            if self.installed_packages.get(dep_name, False):
                enhancement_features.extend(dep_info['features'])
            else:
                features['enhancements']['unavailable'].extend([
                    {'feature': feature, 'requires': dep_name}
                    for feature in dep_info['features']
                ])
        
        features['enhancements']['available'] = list(set(enhancement_features))
        
        return features
    
    def generate_installation_guide(self) -> str:
        """
        Gera guia de instalação para dependências opcionais.
        
        Returns:
            Guia de instalação em markdown
        """
        guide = "# Guia de Instalação - Dependências Opcionais\n\n"
        
        # Status atual
        guide += "## Status Atual\n\n"
        for dep_name, dep_info in self.optional_dependencies.items():
            status = "[OK] Instalado" if self.installed_packages.get(dep_name, False) else "[OK] Não instalado"
            guide += f"- **{dep_name}**: {status}\n"
            guide += f"  - {dep_info['description']}\n"
            guide += f"  - Recursos: {', '.join(dep_info['features'])}\n\n"
        
        # Comandos de instalação por categoria
        guide += "## Instalação por Categoria\n\n"
        
        categories = {
            'Provedores de IA': ['openai', 'boto3', 'anthropic', 'google-cloud-aiplatform', 'azure-cognitiveservices-language'],
            'Modelos Locais': ['transformers', 'torch'],
            'RAG Avançado': ['sentence-transformers', 'faiss-cpu', 'chromadb']
        }
        
        for category, packages in categories.items():
            guide += f"### {category}\n\n"
            
            available_packages = [p for p in packages if p in self.optional_dependencies]
            if available_packages:
                package_specs = [self.optional_dependencies[p]['package'] for p in available_packages]
                guide += f"```bash\npip install {' '.join(package_specs)}\n```\n\n"
                
                for package in available_packages:
                    dep_info = self.optional_dependencies[package]
                    guide += f"- **{package}**: {dep_info['description']}\n"
                
                guide += "\n"
        
        # Instalação completa
        guide += "## Instalação Completa\n\n"
        guide += "Para instalar todas as dependências opcionais:\n\n"
        
        all_packages = [info['package'] for info in self.optional_dependencies.values()]
        guide += f"```bash\npip install {' '.join(all_packages)}\n```\n\n"
        
        # Verificação
        guide += "## Verificação\n\n"
        guide += "Para verificar quais dependências estão instaladas:\n\n"
        guide += "```python\n"
        guide += "from src.utils.dependency_manager import DependencyManager\n"
        guide += "dm = DependencyManager()\n"
        guide += "print(dm.get_installation_status())\n"
        guide += "```\n\n"
        
        return guide
    
    def get_installation_status(self) -> Dict[str, Any]:
        """
        Obtém status detalhado de instalação.
        
        Returns:
            Status detalhado das dependências
        """
        status = {
            'total_dependencies': len(self.optional_dependencies),
            'installed_count': sum(self.installed_packages.values()),
            'missing_count': len(self.optional_dependencies) - sum(self.installed_packages.values()),
            'dependencies': {}
        }
        
        for dep_name, dep_info in self.optional_dependencies.items():
            is_installed = self.installed_packages.get(dep_name, False)
            status['dependencies'][dep_name] = {
                'installed': is_installed,
                'description': dep_info['description'],
                'providers': dep_info['providers'],
                'features': dep_info['features'],
                'package': dep_info['package']
            }
        
        return status
    
    def auto_install_for_provider(self, provider_name: str) -> Dict[str, Any]:
        """
        Instala automaticamente dependências para um provider.
        
        Args:
            provider_name: Nome do provider
            
        Returns:
            Resultado da instalação automática
        """
        deps_check = self.check_provider_dependencies(provider_name)
        
        if deps_check['is_available']:
            return {'success': True, 'message': f'Provider {provider_name} já tem todas as dependências'}
        
        missing_deps = deps_check['missing_dependencies']
        logger.info(f"Instalando dependências para provider {provider_name}: {missing_deps}")
        
        return self.install_dependencies(missing_deps, auto_confirm=True)

# Instância global do gerenciador
dependency_manager = DependencyManager()
