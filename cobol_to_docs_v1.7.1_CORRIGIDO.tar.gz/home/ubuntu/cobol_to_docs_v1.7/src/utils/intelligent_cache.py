"""
Sistema de Cache Inteligente
Implementa cache para otimização de performance mantendo compatibilidade total.
"""

import os
import json
import hashlib
import logging
import time
from typing import Dict, Any, Optional, Tuple
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class IntelligentCache:
    """
    Sistema de cache inteligente para otimização de performance.
    
    Funcionalidades:
    - Cache de recomendações de modelo
    - Cache de análises de complexidade
    - Cache de resultados RAG
    - Expiração automática
    - Limpeza inteligente
    """
    
    def __init__(self, cache_dir: str = "cache", max_age_hours: int = 24):
        """
        Inicializa o sistema de cache.
        
        Args:
            cache_dir: Diretório para armazenar cache
            max_age_hours: Idade máxima do cache em horas
        """
        self.cache_dir = cache_dir
        self.max_age = timedelta(hours=max_age_hours)
        self._ensure_cache_dir()
        
    def _ensure_cache_dir(self):
        """Garante que o diretório de cache existe."""
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)
            logger.info(f"Diretório de cache criado: {self.cache_dir}")
    
    def _get_cache_key(self, data: str) -> str:
        """
        Gera chave de cache baseada no conteúdo.
        
        Args:
            data: Dados para gerar a chave
            
        Returns:
            Chave de cache MD5
        """
        return hashlib.md5(data.encode('utf-8')).hexdigest()
    
    def _get_cache_path(self, cache_type: str, key: str) -> str:
        """
        Obtém caminho do arquivo de cache.
        
        Args:
            cache_type: Tipo de cache (model, complexity, rag)
            key: Chave do cache
            
        Returns:
            Caminho completo do arquivo
        """
        return os.path.join(self.cache_dir, f"{cache_type}_{key}.json")
    
    def _is_cache_valid(self, cache_path: str) -> bool:
        """
        Verifica se o cache ainda é válido.
        
        Args:
            cache_path: Caminho do arquivo de cache
            
        Returns:
            True se o cache é válido
        """
        if not os.path.exists(cache_path):
            return False
            
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)
                
            cache_time = datetime.fromisoformat(cache_data.get('timestamp', ''))
            return datetime.now() - cache_time < self.max_age
            
        except Exception as e:
            logger.warning(f"Erro ao verificar cache {cache_path}: {e}")
            return False
    
    def get_model_recommendation(self, code_content: str) -> Optional[Dict[str, Any]]:
        """
        Obtém recomendação de modelo do cache.
        
        Args:
            code_content: Conteúdo do código COBOL
            
        Returns:
            Recomendação cached ou None
        """
        try:
            key = self._get_cache_key(code_content)
            cache_path = self._get_cache_path("model", key)
            
            if self._is_cache_valid(cache_path):
                with open(cache_path, 'r', encoding='utf-8') as f:
                    cache_data = json.load(f)
                    logger.info(f"Cache hit para recomendação de modelo: {key[:8]}")
                    return cache_data['data']
                    
        except Exception as e:
            logger.warning(f"Erro ao ler cache de modelo: {e}")
            
        return None
    
    def set_model_recommendation(self, code_content: str, recommendation: Dict[str, Any]):
        """
        Armazena recomendação de modelo no cache.
        
        Args:
            code_content: Conteúdo do código COBOL
            recommendation: Recomendação a ser cached
        """
        try:
            key = self._get_cache_key(code_content)
            cache_path = self._get_cache_path("model", key)
            
            cache_data = {
                'timestamp': datetime.now().isoformat(),
                'data': recommendation,
                'type': 'model_recommendation'
            }
            
            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, indent=2, ensure_ascii=False)
                
            logger.info(f"Recomendação de modelo cached: {key[:8]}")
            
        except Exception as e:
            logger.error(f"Erro ao salvar cache de modelo: {e}")
    
    def get_complexity_analysis(self, code_content: str) -> Optional[Dict[str, Any]]:
        """
        Obtém análise de complexidade do cache.
        
        Args:
            code_content: Conteúdo do código COBOL
            
        Returns:
            Análise cached ou None
        """
        try:
            key = self._get_cache_key(code_content)
            cache_path = self._get_cache_path("complexity", key)
            
            if self._is_cache_valid(cache_path):
                with open(cache_path, 'r', encoding='utf-8') as f:
                    cache_data = json.load(f)
                    logger.info(f"Cache hit para análise de complexidade: {key[:8]}")
                    return cache_data['data']
                    
        except Exception as e:
            logger.warning(f"Erro ao ler cache de complexidade: {e}")
            
        return None
    
    def set_complexity_analysis(self, code_content: str, analysis: Dict[str, Any]):
        """
        Armazena análise de complexidade no cache.
        
        Args:
            code_content: Conteúdo do código COBOL
            analysis: Análise a ser cached
        """
        try:
            key = self._get_cache_key(code_content)
            cache_path = self._get_cache_path("complexity", key)
            
            cache_data = {
                'timestamp': datetime.now().isoformat(),
                'data': analysis,
                'type': 'complexity_analysis'
            }
            
            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, indent=2, ensure_ascii=False)
                
            logger.info(f"Análise de complexidade cached: {key[:8]}")
            
        except Exception as e:
            logger.error(f"Erro ao salvar cache de complexidade: {e}")
    
    def get_rag_results(self, query: str) -> Optional[Dict[str, Any]]:
        """
        Obtém resultados RAG do cache.
        
        Args:
            query: Query RAG
            
        Returns:
            Resultados cached ou None
        """
        try:
            key = self._get_cache_key(query)
            cache_path = self._get_cache_path("rag", key)
            
            if self._is_cache_valid(cache_path):
                with open(cache_path, 'r', encoding='utf-8') as f:
                    cache_data = json.load(f)
                    logger.info(f"Cache hit para RAG: {key[:8]}")
                    return cache_data['data']
                    
        except Exception as e:
            logger.warning(f"Erro ao ler cache RAG: {e}")
            
        return None
    
    def set_rag_results(self, query: str, results: Dict[str, Any]):
        """
        Armazena resultados RAG no cache.
        
        Args:
            query: Query RAG
            results: Resultados a serem cached
        """
        try:
            key = self._get_cache_key(query)
            cache_path = self._get_cache_path("rag", key)
            
            cache_data = {
                'timestamp': datetime.now().isoformat(),
                'data': results,
                'type': 'rag_results'
            }
            
            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, indent=2, ensure_ascii=False)
                
            logger.info(f"Resultados RAG cached: {key[:8]}")
            
        except Exception as e:
            logger.error(f"Erro ao salvar cache RAG: {e}")
    
    def get_analysis_cache(self, cobol_code: str, model: str) -> Optional[Dict[str, Any]]:
        """
        Recupera análise do cache.
        
        Args:
            cobol_code: Código COBOL
            model: Modelo usado
            
        Returns:
            Resultado da análise ou None se não encontrado
        """
        cache_key = f"analysis_{model}_{self._get_cache_key(cobol_code)}"
        cache_path = self._get_cache_path("analysis", cache_key)
        
        if os.path.exists(cache_path):
            try:
                with open(cache_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # Verificar se não expirou
                created_time = datetime.fromisoformat(data['created_at'])
                if datetime.now() - created_time < self.max_age:
                    logger.debug(f"Cache hit para análise: {cache_key}")
                    return data['result']
                else:
                    # Cache expirado, remover
                    os.remove(cache_path)
                    logger.debug(f"Cache expirado removido: {cache_key}")
            except Exception as e:
                logger.error(f"Erro ao ler cache de análise: {e}")
        
        return None
    
    def set_analysis_cache(self, cobol_code: str, model: str, result: Dict[str, Any]) -> bool:
        """
        Armazena análise no cache.
        
        Args:
            cobol_code: Código COBOL
            model: Modelo usado
            result: Resultado da análise
            
        Returns:
            True se armazenado com sucesso
        """
        cache_key = f"analysis_{model}_{self._get_cache_key(cobol_code)}"
        return self.set(cache_key, result)

    def cleanup_expired(self) -> int:
        """
        Remove arquivos de cache expirados.
        
        Returns:
            Número de arquivos removidos
        """
        removed_count = 0
        
        try:
            for filename in os.listdir(self.cache_dir):
                if filename.endswith('.json'):
                    cache_path = os.path.join(self.cache_dir, filename)
                    
                    if not self._is_cache_valid(cache_path):
                        os.remove(cache_path)
                        removed_count += 1
                        logger.debug(f"Cache expirado removido: {filename}")
                        
        except Exception as e:
            logger.error(f"Erro na limpeza de cache: {e}")
            
        if removed_count > 0:
            logger.info(f"Limpeza de cache concluída: {removed_count} arquivos removidos")
            
        return removed_count
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """
        Obtém estatísticas do cache.
        
        Returns:
            Estatísticas do cache
        """
        stats = {
            'total_files': 0,
            'valid_files': 0,
            'expired_files': 0,
            'cache_size_mb': 0,
            'types': {
                'model': 0,
                'complexity': 0,
                'rag': 0
            }
        }
        
        try:
            total_size = 0
            
            for filename in os.listdir(self.cache_dir):
                if filename.endswith('.json'):
                    cache_path = os.path.join(self.cache_dir, filename)
                    stats['total_files'] += 1
                    
                    # Tamanho do arquivo
                    total_size += os.path.getsize(cache_path)
                    
                    # Tipo de cache
                    if filename.startswith('model_'):
                        stats['types']['model'] += 1
                    elif filename.startswith('complexity_'):
                        stats['types']['complexity'] += 1
                    elif filename.startswith('rag_'):
                        stats['types']['rag'] += 1
                    
                    # Validade
                    if self._is_cache_valid(cache_path):
                        stats['valid_files'] += 1
                    else:
                        stats['expired_files'] += 1
            
            stats['cache_size_mb'] = round(total_size / (1024 * 1024), 2)
            
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas de cache: {e}")
            
        return stats

# Instância global do cache
cache_manager = IntelligentCache()
