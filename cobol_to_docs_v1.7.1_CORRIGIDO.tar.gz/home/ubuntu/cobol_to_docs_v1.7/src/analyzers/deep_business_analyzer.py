"""
COBOL AI Engine v1.6 - Deep Business Analyzer
Analisador profundo de regras de negócio em código COBOL.
"""

import logging
import re
from typing import Dict, List, Any


class DeepBusinessAnalyzer:
    """Analisador profundo de regras de negócio."""
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o analisador."""
        self.config = config
        self.logger = logging.getLogger(__name__)
    
    def extract_business_rules(self, cobol_code: str) -> List[Dict[str, Any]]:
        """
        Extrai regras de negócio do código COBOL.
        
        Args:
            cobol_code: Código COBOL para análise
            
        Returns:
            Lista de regras de negócio identificadas
        """
        rules = []
        
        try:
            # Padrões de regras de negócio
            patterns = [
                (r'IF\s+([A-Z0-9\-]+)\s*(=|>|<|NOT)\s*([A-Z0-9\-\'"]+)', 'Validação Condicional'),
                (r'EVALUATE\s+([A-Z0-9\-]+)', 'Regra de Decisão'),
                (r'PERFORM\s+([A-Z0-9\-]+)\s+UNTIL', 'Processamento Iterativo'),
                (r'CALL\s+[\'"]([A-Z0-9\-]+)[\'"]', 'Chamada de Subprograma'),
                (r'MOVE\s+([A-Z0-9\-]+)\s+TO\s+([A-Z0-9\-]+)', 'Transferência de Dados')
            ]
            
            lines = cobol_code.split('\n')
            
            for line_num, line in enumerate(lines, 1):
                line_stripped = line.strip()
                
                for pattern, rule_type in patterns:
                    matches = re.findall(pattern, line_stripped, re.IGNORECASE)
                    
                    for match in matches:
                        if isinstance(match, tuple):
                            description = f"{rule_type}: {' '.join(match)}"
                        else:
                            description = f"{rule_type}: {match}"
                        
                        rules.append({
                            'type': rule_type,
                            'description': description,
                            'line_number': line_num,
                            'source_line': line_stripped,
                            'pattern': pattern
                        })
            
            self.logger.info(f"Extraídas {len(rules)} regras de negócio")
            return rules
            
        except Exception as e:
            self.logger.error(f"Erro na extração de regras de negócio: {e}")
            return []
