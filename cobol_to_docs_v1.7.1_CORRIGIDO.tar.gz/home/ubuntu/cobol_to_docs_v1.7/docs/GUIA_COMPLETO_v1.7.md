# Guia Completo - COBOL to Docs v1.7

## Visão Geral

O COBOL to Docs v1.7 é um sistema completo de análise e documentação automatizada de programas COBOL que utiliza inteligência artificial, sistema RAG (Retrieval-Augmented Generation) e auto-learning para gerar documentação técnica de alta qualidade.

## Principais Características v1.7

### Auto-Learning Ativo
- Base de conhecimento que cresce automaticamente (79+ itens)
- Aprendizado contínuo a cada análise realizada
- Persistência automática de novos padrões descobertos
- Contextualização inteligente baseada em conhecimento acumulado

### Interface Otimizada para Notebooks
- Classe COBOLNotebook específica para Jupyter
- Função quick_analyze para análise rápida
- Métodos otimizados para uso interativo
- Visualização de resultados aprimorada

### Sistema Sem Ícones
- Interface profissional e limpa
- Compatibilidade total com ambientes corporativos
- Logs e mensagens padronizados
- Documentação técnica formal

## Instalação Detalhada

### Pré-requisitos
```bash
# Python 3.8 ou superior
python --version

# pip atualizado
pip install --upgrade pip
```

### Instalação Básica
```bash
# Extrair pacote
tar -xzf cobol_to_docs_v1.7_FINAL.tar.gz
cd cobol_to_docs_v1.7

# Instalar em modo desenvolvimento
pip install -e .

# Verificar instalação
python -c "from cobol_to_docs import COBOLNotebook; print('Instalação OK')"
```

### Configuração de Ambiente
```bash
# Configurar PYTHONPATH (se necessário)
export PYTHONPATH=/path/to/cobol_to_docs_v1.7:$PYTHONPATH

# Adicionar ao .bashrc/.zshrc para persistência
echo 'export PYTHONPATH=/path/to/cobol_to_docs_v1.7:$PYTHONPATH' >> ~/.bashrc
```

### Instalação com Dependências Opcionais
```bash
# Para uso completo em notebooks
pip install -e .[notebook]

# Para providers específicos
pip install -e .[openai]      # OpenAI
pip install -e .[bedrock]     # AWS Bedrock
pip install -e .[github]      # GitHub Copilot

# Instalação completa
pip install -e .[full]
```

## Interfaces de Uso

### 1. Jupyter Notebook (Recomendado)

#### Inicialização Básica
```python
from cobol_to_docs import COBOLNotebook

# Inicializar (modo silencioso para notebooks)
cobol = COBOLNotebook(quiet=True)

# Verificar status
print(f"Modelos disponíveis: {cobol.get_available_models()}")
print(f"Sistema RAG: {cobol.get_rag_info()['auto_learning']}")
```

#### Análise de Código COBOL
```python
# Código COBOL de exemplo
cobol_code = '''
IDENTIFICATION DIVISION.
PROGRAM-ID. SISTEMA-VENDAS.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-VENDAS.
   05 WS-PRODUTO        PIC X(20).
   05 WS-QUANTIDADE     PIC 9(5).
   05 WS-PRECO-UNIT     PIC 9(7)V99.
   05 WS-TOTAL          PIC 9(9)V99.

PROCEDURE DIVISION.
MAIN-PARA.
    ACCEPT WS-PRODUTO.
    ACCEPT WS-QUANTIDADE.
    ACCEPT WS-PRECO-UNIT.
    
    COMPUTE WS-TOTAL = WS-QUANTIDADE * WS-PRECO-UNIT.
    
    DISPLAY 'Produto: ' WS-PRODUTO.
    DISPLAY 'Total: R$ ' WS-TOTAL.
    
    STOP RUN.
'''

# Analisar código
result = cobol.analyze_code(cobol_code, "sistema_vendas")

# Mostrar resumo
cobol.show_summary(result)
```

#### Análise de Arquivo
```python
# Analisar arquivo COBOL
result = cobol.analyze("programa.cbl", 
                      model="enhanced_mock",
                      save_pdf=True,
                      save_messages=True)

# Ver detalhes do resultado
print(f"Sucesso: {result.get('success', False)}")
print(f"Tokens: {result.get('tokens_used', 0)}")
print(f"Tempo: {result.get('processing_time', 0):.2f}s")

# Listar análises realizadas
analyses = cobol.list_analyses()
for analysis in analyses:
    print(f"- {analysis['program']} ({analysis['timestamp']})")
```

#### Informações do Sistema RAG
```python
# Obter informações detalhadas do RAG
rag_info = cobol.get_rag_info()
print(f"Base de conhecimento: {rag_info['knowledge_base_size']} itens")
print(f"Cache de embeddings: {rag_info['cache_size']} itens")
print(f"Auto-learning: {rag_info['auto_learning']}")

# Ver estatísticas por categoria
stats = rag_info.get('stats', {})
if stats:
    print("\nCategorias de conhecimento:")
    for category, count in stats.get('categories', {}).items():
        print(f"  - {category}: {count} itens")
```

### 2. CLI Direto (main.py)

#### Análise Básica
```bash
# Análise simples
python main.py --fontes programa.cbl --models enhanced_mock --output resultado

# Verificar resultados
ls -la resultado/
```

#### Análise Completa
```bash
# Análise com todas as funcionalidades
python main.py \
  --fontes programa.cbl \
  --models enhanced_mock \
  --output resultado_completo \
  --pdf \
  --save-messages \
  --advanced \
  --validate \
  --parallel

# Verificar estrutura de saída
tree resultado_completo/
```

#### Múltiplos Arquivos
```bash
# Criar lista de arquivos
echo "sistema1.cbl" > lista_arquivos.txt
echo "sistema2.cbl" >> lista_arquivos.txt
echo "sistema3.cbl" >> lista_arquivos.txt

# Processar em lote
python main.py \
  --fontes lista_arquivos.txt \
  --models enhanced_mock \
  --output analise_lote \
  --parallel \
  --pdf
```

### 3. Comando pip install

#### Após Instalação
```bash
# Verificar comando disponível
cobol-to-docs --help

# Análise básica
cobol-to-docs --file programa.cbl --model enhanced_mock --output resultado

# Análise com PDF
cobol-to-docs --file programa.cbl --model enhanced_mock --output resultado --pdf --save-messages
```

### 4. Biblioteca Python

#### Uso Programático
```python
from cobol_to_docs import COBOLAnalyzer

# Inicializar analyzer
analyzer = COBOLAnalyzer()

# Verificar modelos disponíveis
models = analyzer.get_available_models()
print(f"Modelos: {models}")

# Analisar arquivo
result = analyzer.analyze_file('programa.cbl', model='enhanced_mock')
print(f"Sucesso: {result.get('success', False)}")

# Analisar código diretamente
code_result = analyzer.analyze_code(cobol_code, 'teste_codigo')
print(f"Análise: {code_result.get('analysis', 'N/A')}")
```

### 5. Análise Rápida

#### Função de Conveniência
```python
from cobol_to_docs import quick_analyze

# Análise rápida sem configuração
result = quick_analyze(cobol_code, "teste_rapido")
print(f"Resultado: {result}")

# Com opções específicas
result = quick_analyze(
    cobol_code, 
    "teste_avancado",
    model="enhanced_mock",
    enable_rag=True
)
```

## Argumentos e Parâmetros

### Argumentos CLI Principais

#### Obrigatórios
- `--fontes` / `--file`: Arquivo COBOL ou lista de arquivos
- `--models` / `--model`: Modelo de IA a utilizar

#### Funcionais
- `--output`: Diretório de saída (padrão: timestamp)
- `--pdf`: Gerar relatórios HTML/PDF
- `--save-messages`: Salvar prompts e respostas
- `--advanced`: Análises avançadas (regras de negócio, códigos técnicos)
- `--validate`: Validação anti-alucinação
- `--parallel`: Processamento paralelo

#### Controle
- `--no-cache`: Desabilitar cache inteligente
- `--no-rag`: Desabilitar sistema RAG
- `--quiet`: Reduzir verbosidade
- `--debug`: Logs detalhados

### Parâmetros da Biblioteca

#### COBOLNotebook
```python
cobol = COBOLNotebook(
    config_path="config/config.yaml",  # Arquivo de configuração
    quiet=True,                        # Modo silencioso
    enable_cache=True,                 # Cache inteligente
    enable_rag=True,                   # Sistema RAG
    auto_learn=True                    # Auto-learning
)
```

#### analyze_code / analyze
```python
result = cobol.analyze_code(
    cobol_code,                        # Código COBOL
    program_name,                      # Nome do programa
    model="enhanced_mock",             # Modelo de IA
    save_pdf=False,                    # Gerar PDF
    save_messages=False,               # Salvar mensagens
    enable_validation=True,            # Validação
    enable_technical_codes=True        # Códigos técnicos
)
```

## Sistema RAG e Auto-Learning

### Base de Conhecimento

#### Estrutura Atual
```
data/cobol_knowledge_base_cadoc_expanded.json
├── 79+ itens de conhecimento
├── Categorias: technical_doc, banking_rule, data_structure, business_logic
├── Domínios: banking, general, mainframe, business, technical
└── Crescimento automático a cada análise
```

#### Verificar Crescimento
```python
# Via notebook
cobol = COBOLNotebook()
rag_info = cobol.get_rag_info()
print(f"Itens na base: {rag_info['knowledge_base_size']}")

# Via arquivo
import json
with open('data/cobol_knowledge_base_cadoc_expanded.json', 'r') as f:
    data = json.load(f)
print(f"Total de itens: {len(data)}")

# Ver últimos itens adicionados
for item in data[-3:]:
    print(f"- {item.get('title', 'Sem título')} ({item.get('id', 'Sem ID')})")
```

### Processo de Auto-Learning

#### Como Funciona
1. **Análise Realizada**: Sistema processa programa COBOL
2. **Extração de Conhecimento**: Identifica padrões valiosos
3. **Validação**: Verifica se conhecimento é relevante
4. **Adição à Base**: Adiciona automaticamente à base RAG
5. **Persistência**: Salva imediatamente em arquivo JSON
6. **Enriquecimento**: Próximas análises usam novo conhecimento

#### Logs de Auto-Learning
```
RAG - INFO - *** SISTEMA RAG ATIVO *** ENRIQUECIMENTO DE CONTEXTO:
RAG - INFO -   Programa: SISTEMA-VENDAS
RAG - INFO -   Contexto base: 45 caracteres
RAG - INFO -   Contexto enriquecido: 12847 caracteres
RAG - INFO -   Aumento: 12802 caracteres
RAG - INFO -   Itens de conhecimento utilizados: 8
RAG - INFO - Base RAG enriquecida com conhecimento do programa SISTEMA-VENDAS
```

## Providers e Modelos

### Providers Configurados

#### enhanced_mock (Padrão)
```python
# Provider de teste avançado
result = cobol.analyze_code(code, "teste", model="enhanced_mock")
```

#### basic
```python
# Provider básico para testes simples
result = cobol.analyze_code(code, "teste", model="basic")
```

#### luzia (LuzIA/Santander)
```yaml
# config/config.yaml
providers:
  luzia:
    base_url: "https://api.luzia.com"
    models:
      - "aws_claude_3_5_sonnet"
      - "aws_claude_3_5_haiku"
```

#### github_copilot
```yaml
# config/config.yaml
providers:
  github_copilot:
    base_url: "https://api.githubcopilot.com"
    models:
      - "gpt-4"
      - "gpt-3.5-turbo"
```

### Providers Opcionais

#### OpenAI
```bash
# Instalar dependência
pip install openai>=1.0.0

# Configurar
export OPENAI_API_KEY="sua_chave"
```

#### AWS Bedrock
```bash
# Instalar dependência
pip install boto3>=1.26.0

# Configurar
export AWS_ACCESS_KEY_ID="sua_chave"
export AWS_SECRET_ACCESS_KEY="sua_chave_secreta"
export AWS_REGION="us-east-1"
```

## Estrutura de Saída

### Diretório de Resultados
```
resultado/
├── model_enhanced_mock/              # Análises por modelo
│   ├── PROGRAMA_analise_funcional.md # Análise principal
│   ├── ai_requests/                  # Prompts enviados (--save-messages)
│   │   └── PROGRAMA_request.json
│   └── ai_responses/                 # Respostas recebidas (--save-messages)
│       └── PROGRAMA_response.json
├── relatorio_consolidado.json       # Relatório consolidado
├── relatorio_custos.json           # Análise de custos
├── relatorio_estatisticas.json     # Estatísticas de processamento
├── relatorio_rag.md                # Relatório do sistema RAG
├── relatorio_rag.html              # Versão HTML/PDF (--pdf)
└── messages/                       # Mensagens detalhadas (--save-messages)
    └── PROGRAMA_messages.json
```

### Conteúdo dos Relatórios

#### Análise Funcional (Markdown)
```markdown
# Análise Funcional - PROGRAMA

## Resumo Executivo
Descrição geral do programa...

## Estrutura de Dados
Mapeamento de variáveis...

## Fluxo de Execução
Descrição da lógica...

## Regras de Negócio
Identificação de regras...

## Dependências
Copybooks e chamadas...

## Métricas de Complexidade
Estatísticas do código...
```

#### Relatório RAG (Markdown/HTML)
```markdown
# Relatório do Sistema RAG

## Estatísticas da Base
- Total de itens: 79
- Categorias: 5
- Domínios: 4

## Conhecimento Utilizado
Lista dos itens RAG utilizados...

## Auto-Learning
Novos padrões descobertos...
```

#### Relatório Consolidado (JSON)
```json
{
  "summary": {
    "total_programs": 1,
    "successful_analyses": 1,
    "success_rate": 100.0
  },
  "programs": [
    {
      "name": "PROGRAMA",
      "status": "success",
      "model": "enhanced_mock",
      "tokens_used": 1250,
      "processing_time": 2.34
    }
  ],
  "rag_stats": {
    "knowledge_items_used": 8,
    "context_enhancement": 12802
  }
}
```

## Configuração Avançada

### Arquivo config/config.yaml

#### Configuração Completa
```yaml
# Provedores de IA
providers:
  luzia:
    base_url: "https://api.luzia.com"
    timeout: 30
    models:
      - "aws_claude_3_5_sonnet"
      - "aws_claude_3_5_haiku"
  
  github_copilot:
    base_url: "https://api.githubcopilot.com"
    timeout: 30
    models:
      - "gpt-4"
      - "gpt-3.5-turbo"

# Sistema RAG
rag:
  enabled: true
  auto_learning: true
  knowledge_base_path: "data/cobol_knowledge_base_cadoc_expanded.json"
  embedding_cache_path: "data/embeddings_cache.json"
  similarity_threshold: 0.7
  max_context_items: 10

# Cache inteligente
cache:
  enabled: true
  max_workers: 4
  cache_dir: "cache/"
  ttl_hours: 24

# Análise
analysis:
  default_model: "enhanced_mock"
  enable_validation: true
  enable_technical_codes: true
  enable_business_rules: true
  max_retries: 3
  timeout: 60

# Logs
logging:
  level: "INFO"
  file: "logs/cobol_to_docs.log"
  max_size_mb: 10
  backup_count: 5
```

### Variáveis de Ambiente

#### Configuração do Sistema
```bash
# Caminho do projeto
export PYTHONPATH=/path/to/cobol_to_docs_v1.7:$PYTHONPATH

# Configuração personalizada
export COBOL_TO_DOCS_CONFIG=/path/to/config.yaml

# Nível de log
export COBOL_TO_DOCS_LOG_LEVEL=DEBUG

# Diretório de cache
export COBOL_TO_DOCS_CACHE_DIR=/tmp/cobol_cache
```

#### Credenciais de Providers
```bash
# LuzIA
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"

# GitHub Copilot
export GITHUB_TOKEN="seu_github_token"

# OpenAI
export OPENAI_API_KEY="sua_api_key"

# AWS Bedrock
export AWS_ACCESS_KEY_ID="sua_chave"
export AWS_SECRET_ACCESS_KEY="sua_chave_secreta"
export AWS_REGION="us-east-1"
```

## Exemplos Práticos

### Análise de Sistema Bancário

#### Código COBOL Bancário
```python
banking_code = '''
IDENTIFICATION DIVISION.
PROGRAM-ID. CALCULO-PRESTACAO.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-DADOS-FINANCIAMENTO.
   05 WS-VALOR-FINANCIADO  PIC 9(8)V99.
   05 WS-TAXA-JUROS        PIC 9V9999.
   05 WS-PRAZO-MESES       PIC 999.
   05 WS-PRESTACAO         PIC 9(6)V99.
   05 WS-TOTAL-JUROS       PIC 9(8)V99.

01 WS-CONSTANTES.
   05 WS-TAXA-MINIMA       PIC 9V9999 VALUE 0.0050.
   05 WS-TAXA-MAXIMA       PIC 9V9999 VALUE 0.1500.
   05 WS-PRAZO-MINIMO      PIC 999    VALUE 006.
   05 WS-PRAZO-MAXIMO      PIC 999    VALUE 360.

PROCEDURE DIVISION.
MAIN-PARA.
    PERFORM VALIDAR-DADOS.
    PERFORM CALCULAR-PRESTACAO.
    PERFORM EXIBIR-RESULTADOS.
    STOP RUN.

VALIDAR-DADOS.
    IF WS-TAXA-JUROS < WS-TAXA-MINIMA OR 
       WS-TAXA-JUROS > WS-TAXA-MAXIMA
        DISPLAY 'ERRO: Taxa de juros inválida'
        STOP RUN
    END-IF.
    
    IF WS-PRAZO-MESES < WS-PRAZO-MINIMO OR
       WS-PRAZO-MESES > WS-PRAZO-MAXIMO
        DISPLAY 'ERRO: Prazo inválido'
        STOP RUN
    END-IF.

CALCULAR-PRESTACAO.
    COMPUTE WS-PRESTACAO = WS-VALOR-FINANCIADO * 
        (WS-TAXA-JUROS * (1 + WS-TAXA-JUROS) ** WS-PRAZO-MESES) /
        ((1 + WS-TAXA-JUROS) ** WS-PRAZO-MESES - 1).
    
    COMPUTE WS-TOTAL-JUROS = 
        (WS-PRESTACAO * WS-PRAZO-MESES) - WS-VALOR-FINANCIADO.

EXIBIR-RESULTADOS.
    DISPLAY 'Valor Financiado: R$ ' WS-VALOR-FINANCIADO.
    DISPLAY 'Taxa de Juros: ' WS-TAXA-JUROS.
    DISPLAY 'Prazo: ' WS-PRAZO-MESES ' meses'.
    DISPLAY 'Prestação: R$ ' WS-PRESTACAO.
    DISPLAY 'Total de Juros: R$ ' WS-TOTAL-JUROS.
'''

# Analisar com sistema RAG
result = cobol.analyze_code(banking_code, "calculo_prestacao")

# O sistema RAG reconhece padrões bancários e enriquece a análise
cobol.show_summary(result)
```

### Análise de Sistema de Vendas

#### Processamento em Lote
```python
# Lista de programas de vendas
vendas_programs = [
    "sistema_vendas.cbl",
    "calculo_comissao.cbl", 
    "relatorio_vendas.cbl",
    "controle_estoque.cbl"
]

# Processar todos os programas
results = []
for program in vendas_programs:
    try:
        result = cobol.analyze(program, 
                              model="enhanced_mock",
                              save_pdf=True,
                              save_messages=True)
        results.append(result)
        print(f"[OK] {program} analisado com sucesso")
    except Exception as e:
        print(f"[ERRO] {program}: {e}")

# Gerar relatório consolidado
print(f"\nResumo: {len(results)} programas analisados")
total_tokens = sum(r.get('tokens_used', 0) for r in results)
print(f"Total de tokens: {total_tokens}")
```

### Análise com Validação Avançada

#### Código com Validação Anti-Alucinação
```python
complex_code = '''
IDENTIFICATION DIVISION.
PROGRAM-ID. SISTEMA-COMPLEXO.

DATA DIVISION.
FILE SECTION.
FD ARQUIVO-ENTRADA.
01 REG-ENTRADA.
   05 CODIGO-CLIENTE    PIC 9(6).
   05 NOME-CLIENTE      PIC X(30).
   05 VALOR-COMPRA      PIC 9(7)V99.

WORKING-STORAGE SECTION.
01 WS-CONTADORES.
   05 WS-TOTAL-CLIENTES PIC 9(6) VALUE ZERO.
   05 WS-TOTAL-VENDAS   PIC 9(9)V99 VALUE ZERO.

01 WS-FLAGS.
   05 WS-EOF            PIC X VALUE 'N'.

PROCEDURE DIVISION.
MAIN-PARA.
    OPEN INPUT ARQUIVO-ENTRADA.
    PERFORM PROCESSAR-ARQUIVO UNTIL WS-EOF = 'Y'.
    PERFORM GERAR-RELATORIO.
    CLOSE ARQUIVO-ENTRADA.
    STOP RUN.

PROCESSAR-ARQUIVO.
    READ ARQUIVO-ENTRADA
        AT END MOVE 'Y' TO WS-EOF
        NOT AT END PERFORM PROCESSAR-REGISTRO
    END-READ.

PROCESSAR-REGISTRO.
    ADD 1 TO WS-TOTAL-CLIENTES.
    ADD VALOR-COMPRA TO WS-TOTAL-VENDAS.
    
    IF VALOR-COMPRA > 1000
        PERFORM APLICAR-DESCONTO
    END-IF.

APLICAR-DESCONTO.
    COMPUTE VALOR-COMPRA = VALOR-COMPRA * 0.95.

GERAR-RELATORIO.
    DISPLAY 'Total de Clientes: ' WS-TOTAL-CLIENTES.
    DISPLAY 'Total de Vendas: R$ ' WS-TOTAL-VENDAS.
'''

# Análise com validação completa
result = cobol.analyze_code(
    complex_code, 
    "sistema_complexo",
    model="enhanced_mock",
    enable_validation=True,
    enable_technical_codes=True,
    save_pdf=True
)

# Verificar qualidade da análise
if result.get('validation_passed', False):
    print("[OK] Análise validada com sucesso")
else:
    print("[AVISO] Análise pode conter imprecisões")

cobol.show_summary(result)
```

## Troubleshooting

### Problemas Comuns

#### Erro de Importação
```bash
# Problema: ModuleNotFoundError: No module named 'cobol_to_docs'
# Solução:
export PYTHONPATH=/path/to/cobol_to_docs_v1.7:$PYTHONPATH
python -c "from cobol_to_docs import COBOLNotebook; print('OK')"
```

#### Comando não Encontrado
```bash
# Problema: cobol-to-docs: command not found
# Solução:
pip install -e . --force-reinstall
cobol-to-docs --help
```

#### Base RAG não Carrega
```bash
# Problema: Erro ao carregar base de conhecimento
# Verificar arquivos:
ls -la data/cobol_knowledge_base*.json

# Recriar base se necessário:
python -c "
from src.core.config import ConfigManager
from src.rag.cobol_rag_system import CobolRAGSystem
config = ConfigManager()
rag = CobolRAGSystem(config)
print('Base RAG inicializada')
"
```

#### PDF não Gerado
```bash
# Problema: Relatório PDF não é criado
# Solução: Usar argumento --pdf
python main.py --fontes programa.cbl --models enhanced_mock --output resultado --pdf

# Verificar arquivo HTML gerado
ls -la resultado/relatorio_rag.html
# Abrir no navegador e usar Ctrl+P para salvar como PDF
```

#### Análise Falha
```python
# Problema: Análise retorna erro
# Debug:
cobol = COBOLNotebook(quiet=False)  # Ativar logs
result = cobol.analyze_code(code, "debug", model="enhanced_mock")

# Verificar logs
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Logs e Debugging

#### Ativar Logs Detalhados
```python
import logging

# Configurar logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Usar sistema com logs
cobol = COBOLNotebook(quiet=False)
result = cobol.analyze_code(code, "debug_test")
```

#### Verificar Status do Sistema
```python
# Status dos providers
cobol = COBOLNotebook()
status = cobol.get_provider_status()
for provider, info in status.items():
    print(f"{provider}: {info['status']}")

# Status do RAG
rag_info = cobol.get_rag_info()
print(f"RAG ativo: {rag_info['auto_learning']}")
print(f"Base: {rag_info['knowledge_base_size']} itens")

# Modelos disponíveis
models = cobol.get_available_models()
print(f"Modelos: {models}")
```

#### Arquivos de Log
```bash
# Verificar logs do sistema
tail -f logs/cobol_to_docs.log

# Logs específicos do RAG
grep "RAG" logs/cobol_to_docs.log

# Logs de erro
grep "ERROR" logs/cobol_to_docs.log
```

## Performance e Otimização

### Cache Inteligente

#### Configuração
```yaml
# config/config.yaml
cache:
  enabled: true
  max_workers: 4        # Processamento paralelo
  cache_dir: "cache/"   # Diretório de cache
  ttl_hours: 24        # Tempo de vida do cache
```

#### Uso
```python
# Cache automático ativo por padrão
result1 = cobol.analyze_code(code, "teste")  # Primeira análise
result2 = cobol.analyze_code(code, "teste")  # Usa cache (mais rápido)

# Desabilitar cache se necessário
cobol = COBOLNotebook(enable_cache=False)
```

### Processamento Paralelo

#### CLI
```bash
# Processar múltiplos arquivos em paralelo
python main.py \
  --fontes lista_arquivos.txt \
  --models enhanced_mock \
  --output resultado \
  --parallel
```

#### Biblioteca
```python
# Configurar workers
from src.utils.parallel_processor import ParallelProcessor

processor = ParallelProcessor(max_workers=4)
results = processor.process_multiple_files(file_list, cobol.analyze)
```

### Otimização de Memória

#### Para Análises Grandes
```python
# Processar arquivos grandes em lotes
def process_large_batch(file_list, batch_size=10):
    results = []
    for i in range(0, len(file_list), batch_size):
        batch = file_list[i:i+batch_size]
        batch_results = [cobol.analyze(f) for f in batch]
        results.extend(batch_results)
        
        # Limpar cache periodicamente
        if i % 50 == 0:
            cobol.clear_cache()
    
    return results
```

## Desenvolvimento e Extensão

### Estrutura do Projeto

#### Organização v1.7
```
cobol_to_docs_v1.7/
├── main.py                    # Interface principal CLI
├── cobol_to_docs/            # Biblioteca Python
│   ├── __init__.py           # Interface principal
│   ├── cli.py                # CLI via pip install
│   └── notebook.py           # Interface para notebooks
├── src/                      # Código fonte
│   ├── providers/            # Sistema de provedores
│   ├── rag/                  # Sistema RAG e auto-learning
│   ├── analyzers/            # Analisadores especializados
│   ├── utils/                # Utilitários e cache
│   └── core/                 # Núcleo do sistema
├── config/                   # Configurações
├── data/                     # Base de conhecimento RAG
├── examples/                 # Exemplos de uso
├── docs/                     # Documentação
├── tools/                    # Ferramentas auxiliares
└── tests/                    # Testes (futuro)
```

### Princípios SOLID Aplicados

#### Single Responsibility
```python
# Cada classe tem uma responsabilidade específica
class CobolRAGSystem:          # Gerencia sistema RAG
class IntelligentCache:        # Gerencia cache
class MockProvider:            # Provê análises mock
class TechnicalCodeAnalyzer:   # Analisa códigos técnicos
```

#### Open/Closed
```python
# Sistema extensível sem modificar código existente
class BaseProvider:            # Interface base
class NewProvider(BaseProvider): # Novo provider
```

#### Liskov Substitution
```python
# Providers intercambiáveis
def analyze_with_provider(provider: BaseProvider):
    return provider.analyze(code)  # Funciona com qualquer provider
```

### Adicionando Novo Provider

#### 1. Criar Provider
```python
# src/providers/meu_provider.py
from .base_provider import BaseProvider

class MeuProvider(BaseProvider):
    def __init__(self, config):
        super().__init__(config)
        self.api_key = config.get('meu_provider', {}).get('api_key')
    
    def analyze(self, request):
        # Implementar análise
        response = self._call_api(request.prompt)
        return self._format_response(response)
    
    def _call_api(self, prompt):
        # Chamar API externa
        pass
    
    def _format_response(self, response):
        # Formatar resposta
        pass
```

#### 2. Registrar Provider
```python
# src/providers/provider_manager.py
from .meu_provider import MeuProvider

class ProviderManager:
    def __init__(self, config):
        self.providers = {
            'enhanced_mock': MockProvider(config),
            'meu_provider': MeuProvider(config),  # Adicionar aqui
        }
```

#### 3. Configurar
```yaml
# config/config.yaml
providers:
  meu_provider:
    api_key: "sua_chave"
    base_url: "https://api.meuprovider.com"
    models:
      - "modelo1"
      - "modelo2"
```

### Contribuição

#### Processo de Desenvolvimento
1. Fork o projeto
2. Crie branch para feature: `git checkout -b feature/nova-funcionalidade`
3. Implemente seguindo princípios SOLID
4. Teste todas as interfaces
5. Documente mudanças
6. Submeta pull request

#### Padrões de Código
```python
# Usar type hints
def analyze_code(self, code: str, program_name: str) -> Dict[str, Any]:
    pass

# Documentar métodos
def analyze_code(self, code: str, program_name: str) -> Dict[str, Any]:
    """
    Analisa código COBOL e gera documentação.
    
    Args:
        code: Código COBOL a ser analisado
        program_name: Nome do programa
        
    Returns:
        Dicionário com resultado da análise
    """
    pass

# Usar logging
import logging
logger = logging.getLogger(__name__)
logger.info("Análise iniciada")
```

## Changelog v1.7

### Novas Funcionalidades
- **Interface COBOLNotebook**: Otimizada para Jupyter Notebooks
- **Função quick_analyze**: Análise rápida sem configuração
- **Auto-learning ativo**: Persistência automática de conhecimento
- **Geração de PDF**: Conversão otimizada de relatórios
- **Sistema sem ícones**: Interface profissional e limpa

### Melhorias
- **Arquitetura SOLID**: Princípios aplicados consistentemente
- **Providers consolidados**: Eliminadas duplicações enhanced_*
- **Cache inteligente**: Otimização de performance
- **Processamento paralelo**: Configurável e eficiente
- **Base RAG expandida**: 79+ itens com crescimento automático

### Correções
- **Compatibilidade notebooks**: Melhorada significativamente
- **Entry points pip**: Corrigidos e funcionais
- **Persistência auto-learning**: Garantida em data/
- **Logs limpos**: Sem ícones, mais informativos
- **Tratamento de erros**: Aprimorado e consistente

## Licença e Suporte

### Licença
MIT License - consulte LICENSE para detalhes completos.

### Suporte Técnico
1. **Documentação**: Consultar `docs/` para guias detalhados
2. **Exemplos**: Verificar `examples/` para casos de uso
3. **Logs**: Analisar `logs/` para debugging
4. **Issues**: Abrir issue no repositório para problemas
5. **Comunidade**: Participar de discussões e contribuições

### Recursos Adicionais
- **Wiki**: Documentação colaborativa
- **Discussions**: Fórum da comunidade
- **Releases**: Notas de versão detalhadas
- **Roadmap**: Planejamento de funcionalidades futuras

---

**COBOL to Docs v1.7 - Guia Completo**

*Sistema completo de análise COBOL com IA e auto-learning*
*Quanto mais você usa, mais inteligente o sistema fica!*
