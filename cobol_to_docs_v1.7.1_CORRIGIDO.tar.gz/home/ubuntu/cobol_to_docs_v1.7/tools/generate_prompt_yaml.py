#!/usr/bin/env python3
"""
Gerador de Prompts YAML
Gera arquivos de prompts YAML a partir de texto de entrada, aplicando ao formato existente.
"""

import os
import sys
import yaml
import argparse
import logging
from typing import Dict, List, Any, Optional

# Adicionar diretório pai ao path para importar módulos do projeto
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def generate_prompt_yaml(input_text: str, template_yaml_file: str, output_yaml_file: str, 
                       model_name: str = 'aws_claude_3_5_sonnet', 
                       analysis_type: str = 'funcionalidades_completas') -> bool:
    """
    Gera um arquivo de prompts YAML a partir de texto de entrada, aplicando ao formato existente.
    
    Args:
        input_text: Texto de entrada para o prompt
        template_yaml_file: Arquivo YAML de template
        output_yaml_file: Arquivo YAML de saída
        model_name: Nome do modelo para o qual gerar o prompt
        analysis_type: Tipo de análise para o qual gerar o prompt
        
    Returns:
        True se bem-sucedido, False caso contrário
    """
    try:
        # Carregar o template YAML
        with open(template_yaml_file, 'r', encoding='utf-8') as f:
            yaml_content = yaml.safe_load(f)
        
        # Verificar se o modelo existe
        if model_name not in yaml_content.get('model_prompts', {}):
            print(f"Modelo '{model_name}' não encontrado no template. Usando o primeiro modelo disponível.")
            model_name = next(iter(yaml_content.get('model_prompts', {}).keys()))
        
        # Verificar se o tipo de análise existe
        if analysis_type not in yaml_content.get('analysis_types', {}):
            print(f"Tipo de análise '{analysis_type}' não encontrado no template. Usando o primeiro tipo disponível.")
            analysis_type = next(iter(yaml_content.get('analysis_types', {}).keys()))
        
        # Criar novo conteúdo YAML
        new_yaml = {
            'version': yaml_content.get('version', '1.0.0'),
            'system_prompt': input_text,
            'model_prompts': {
                model_name: {
                    'system_prompt': input_text,
                    'persona': yaml_content.get('model_prompts', {}).get(model_name, {}).get('persona', 'especialista COBOL'),
                    'analysis_depth': yaml_content.get('model_prompts', {}).get(model_name, {}).get('analysis_depth', 'functional'),
                    'token_optimization': yaml_content.get('model_prompts', {}).get(model_name, {}).get('token_optimization', False)
                }
            },
            'analysis_types': {
                analysis_type: {
                    'prompt': input_text
                }
            },
            'optimization_settings': yaml_content.get('optimization_settings', {}),
            'output_templates': yaml_content.get('output_templates', {})
        }
        
        # Salvar o novo YAML
        with open(output_yaml_file, 'w', encoding='utf-8') as f:
            yaml.dump(new_yaml, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
        
        print(f"Arquivo YAML gerado com sucesso: {output_yaml_file}")
        return True
        
    except Exception as e:
        print(f"Erro ao gerar arquivo YAML: {e}")
        return False


if __name__ == "__main__":
    # Configuração de logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Argumentos de linha de comando
    parser = argparse.ArgumentParser(description='Gerar arquivo de prompts YAML a partir de texto')
    parser.add_argument('--input', required=True, help='Arquivo de texto de entrada ou texto direto')
    parser.add_argument('--template', default=None, help='Arquivo YAML de template')
    parser.add_argument('--output', default=None, help='Arquivo YAML de saída')
    parser.add_argument('--model', default='aws_claude_3_5_sonnet', help='Nome do modelo')
    parser.add_argument('--type', default='funcionalidades_completas', help='Tipo de análise')
    
    args = parser.parse_args()
    
    # Determinar template se não especificado
    template_file = args.template
    if not template_file:
        # Procurar em locais padrão
        possible_locations = [
            'config/prompts_melhorado_rag.yaml',
            '../config/prompts_melhorado_rag.yaml',
            '/home/ubuntu/cobol_to_docs_v1.0_final/config/prompts_melhorado_rag.yaml',
            '/home/ubuntu/cobol_to_docs_v1.6/config/prompts_melhorado_rag.yaml'
        ]
        
        for location in possible_locations:
            if os.path.exists(location):
                template_file = location
                break
        
        if not template_file:
            print("Erro: Arquivo de template YAML não encontrado.")
            sys.exit(1)
    
    # Determinar arquivo de saída se não especificado
    output_file = args.output
    if not output_file:
        output_file = f"prompt_gerado_{args.model}_{args.type}.yaml"
    
    # Ler texto de entrada
    input_text = args.input
    if os.path.exists(input_text):
        with open(input_text, 'r', encoding='utf-8') as f:
            input_text = f.read()
    
    # Gerar YAML
    success = generate_prompt_yaml(
        input_text,
        template_file,
        output_file,
        args.model,
        args.type
    )
    
    if success:
        print(f"Geração de YAML concluída com sucesso!")
    else:
        print(f"Erro na geração de YAML. Verifique os logs para mais detalhes.")
        sys.exit(1)
