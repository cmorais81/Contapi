"""
Exemplo de uso do COBOL to Docs em Jupyter Notebook
Execute este código em células separadas de um notebook
"""

# Célula 1: Instalação e importação
"""
# Instalar a biblioteca (execute apenas uma vez)
!pip install -e /path/to/cobol_to_docs_v1.6

# Importar
from cobol_to_docs import COBOLNotebook, quick_analyze
"""

# Célula 2: Inicialização
"""
# Inicializar o analisador
cobol = COBOLNotebook()
print("Sistema inicializado!")
print(f"Modelos disponíveis: {cobol.get_available_models()}")
"""

# Célula 3: Análise rápida de código
"""
# Código COBOL de exemplo
cobol_code = '''
IDENTIFICATION DIVISION.
PROGRAM-ID. CALCULO-JUROS.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-PRINCIPAL     PIC 9(7)V99 VALUE 1000.00.
01 WS-TAXA          PIC 9V999   VALUE 0.05.
01 WS-TEMPO         PIC 99      VALUE 12.
01 WS-JUROS         PIC 9(7)V99.
01 WS-MONTANTE      PIC 9(8)V99.

PROCEDURE DIVISION.
MAIN-PARA.
    COMPUTE WS-JUROS = WS-PRINCIPAL * WS-TAXA * WS-TEMPO / 100.
    COMPUTE WS-MONTANTE = WS-PRINCIPAL + WS-JUROS.
    
    DISPLAY 'Principal: ' WS-PRINCIPAL.
    DISPLAY 'Taxa: ' WS-TAXA '%'.
    DISPLAY 'Tempo: ' WS-TEMPO ' meses'.
    DISPLAY 'Juros: ' WS-JUROS.
    DISPLAY 'Montante: ' WS-MONTANTE.
    
    STOP RUN.
'''

# Analisar o código
result = cobol.analyze_code(cobol_code, "calculo_juros")
cobol.show_summary(result)
"""

# Célula 4: Análise de arquivo
"""
# Se você tiver um arquivo COBOL
# result = cobol.analyze("meu_programa.cbl")
# cobol.show_summary(result)
"""

# Célula 5: Análise rápida (função de conveniência)
"""
# Para análise rápida sem configuração
quick_result = quick_analyze('''
IDENTIFICATION DIVISION.
PROGRAM-ID. HELLO-WORLD.
PROCEDURE DIVISION.
    DISPLAY 'Hello from COBOL!'.
    STOP RUN.
''', "hello_world")

print("Resultado da análise rápida:")
print(f"Sucesso: {quick_result.get('success', False)}")
print(f"Tokens: {quick_result.get('tokens_used', 0)}")
"""

# Célula 6: Explorar resultados
"""
# Listar análises realizadas
print("Análises realizadas:")
for analysis in cobol.list_analyses():
    print(f"  - {analysis}")

# Carregar análise anterior
if cobol.list_analyses():
    old_result = cobol.load_analysis("calculo_juros")
    if old_result:
        print("Análise carregada com sucesso!")
"""

# Célula 7: Informações do sistema
"""
# Ver informações do sistema RAG
rag_info = cobol.get_rag_info()
print("Informações do RAG:")
for key, value in rag_info.items():
    print(f"  {key}: {value}")

# Limpar cache se necessário
# cobol.clear_cache()
"""

# Célula 8: Exemplo com programa mais complexo
"""
complex_cobol = '''
IDENTIFICATION DIVISION.
PROGRAM-ID. SISTEMA-VENDAS.

ENVIRONMENT DIVISION.
INPUT-OUTPUT SECTION.
FILE-CONTROL.
    SELECT VENDAS-FILE ASSIGN TO 'VENDAS.DAT'
    ORGANIZATION IS SEQUENTIAL.

DATA DIVISION.
FILE SECTION.
FD VENDAS-FILE.
01 VENDA-RECORD.
   05 VENDA-ID          PIC 9(6).
   05 CLIENTE-ID        PIC 9(5).
   05 PRODUTO-ID        PIC 9(4).
   05 QUANTIDADE        PIC 9(3).
   05 PRECO-UNITARIO    PIC 9(5)V99.
   05 DATA-VENDA        PIC 9(8).

WORKING-STORAGE SECTION.
01 WS-TOTAL-VENDAS      PIC 9(8)V99 VALUE ZERO.
01 WS-CONTADOR          PIC 9(4) VALUE ZERO.
01 WS-VALOR-VENDA       PIC 9(7)V99.
01 WS-EOF               PIC X VALUE 'N'.

PROCEDURE DIVISION.
MAIN-PARA.
    OPEN INPUT VENDAS-FILE.
    
    PERFORM UNTIL WS-EOF = 'Y'
        READ VENDAS-FILE
            AT END MOVE 'Y' TO WS-EOF
            NOT AT END PERFORM PROCESSAR-VENDA
        END-READ
    END-PERFORM.
    
    CLOSE VENDAS-FILE.
    
    DISPLAY 'Total de vendas processadas: ' WS-CONTADOR.
    DISPLAY 'Valor total das vendas: ' WS-TOTAL-VENDAS.
    
    STOP RUN.

PROCESSAR-VENDA.
    COMPUTE WS-VALOR-VENDA = QUANTIDADE * PRECO-UNITARIO.
    ADD WS-VALOR-VENDA TO WS-TOTAL-VENDAS.
    ADD 1 TO WS-CONTADOR.
    
    DISPLAY 'Venda ' VENDA-ID ': R$ ' WS-VALOR-VENDA.
'''

# Analisar programa complexo
complex_result = cobol.analyze_code(complex_cobol, "sistema_vendas")
cobol.show_summary(complex_result)
"""

# Informações adicionais para o notebook
NOTEBOOK_TIPS = """
# Dicas para uso em Notebooks:

1. **Instalação**: Execute `!pip install -e /path/to/cobol_to_docs_v1.6` uma vez

2. **Importação**: Use `from cobol_to_docs import COBOLNotebook, quick_analyze`

3. **Análise rápida**: Use `quick_analyze()` para testes rápidos

4. **Análise completa**: Use `COBOLNotebook()` para controle total

5. **Resultados**: Os arquivos são salvos em `./cobol_analysis/`

6. **Modelos**: Use 'enhanced_mock' para testes ou outros modelos configurados

7. **Cache**: O sistema mantém cache para melhor performance

8. **RAG**: O sistema aprende automaticamente com cada análise
"""
