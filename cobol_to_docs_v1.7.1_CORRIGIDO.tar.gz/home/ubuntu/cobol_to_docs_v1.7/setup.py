"""
COBOL to Docs v1.6 - Setup para uso como biblioteca Python
Configuração otimizada para pip install e uso em notebooks
"""

from setuptools import setup, find_packages
from pathlib import Path

# Ler README para descrição longa
def read_readme():
    try:
        readme_path = Path(__file__).parent / "README.md"
        return readme_path.read_text(encoding='utf-8')
    except FileNotFoundError:
        return "Sistema de análise e documentação automatizada de programas COBOL com IA e RAG"

# Ler versão
def read_version():
    try:
        version_path = Path(__file__).parent / "VERSION"
        return version_path.read_text(encoding='utf-8').strip()
    except FileNotFoundError:
        return "1.7.0"

# Dependências essenciais para notebooks
def get_requirements():
    return [
        'requests>=2.28.0',
        'pyyaml>=6.0',
        'jinja2>=3.1.0',
        'scikit-learn>=1.2.0',
        'numpy>=1.24.0',
        'markdown>=3.4.0',
        'pathlib2>=2.3.7; python_version < "3.4"',
        'typing-extensions>=4.0.0; python_version < "3.8"'
    ]

setup(
    name="cobol-to-docs",
    version=read_version(),
    author="COBOL to Docs Team",
    author_email="contato@cobol-to-docs.com",
    description="Biblioteca Python para análise e documentação automatizada de programas COBOL",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/cobol-to-docs/cobol-to-docs",
    packages=find_packages(include=['cobol_to_docs', 'cobol_to_docs.*', 'src', 'src.*']),
    include_package_data=True,
    package_data={
        "": [
            "config/*.yaml",
            "data/*.json",
            "examples/*.txt",
            "examples/*.cbl",
            "docs/*.md",
            "VERSION"
        ]
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Information Technology",
        "Topic :: Software Development :: Documentation",
        "Topic :: Software Development :: Code Generators",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=get_requirements(),
    extras_require={
        "openai": ["openai>=1.0.0"],
        "bedrock": ["boto3>=1.26.0"],
        "anthropic": ["anthropic>=0.7.0"],
        "github": ["requests>=2.28.0"],
        "notebook": [
            "jupyter>=1.0.0",
            "ipython>=7.0.0",
            "pandas>=1.3.0",
            "matplotlib>=3.5.0"
        ],
        "full": [
            "openai>=1.0.0",
            "boto3>=1.26.0",
            "anthropic>=0.7.0",
            "sentence-transformers>=2.2.0",
            "pandas>=1.3.0",
            "jupyter>=1.0.0",
            "ipython>=7.0.0",
            "matplotlib>=3.5.0"
        ]
    },
    entry_points={
        "console_scripts": [
            "cobol-to-docs=cobol_to_docs.cli:main",
        ],
    },
    keywords=[
        "cobol", "documentation", "ai", "analysis", "legacy", "mainframe",
        "reverse-engineering", "modernization", "rag", "nlp", "notebook", "jupyter"
    ],
    project_urls={
        "Bug Reports": "https://github.com/cobol-to-docs/cobol-to-docs/issues",
        "Source": "https://github.com/cobol-to-docs/cobol-to-docs",
        "Documentation": "https://github.com/cobol-to-docs/cobol-to-docs/wiki",
    },
)
