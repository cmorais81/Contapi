"""Setup do COBOL Analyzer"""
from setuptools import setup, find_packages

setup(
    name="cobol-to-docs",
    version="3.1.0",
    description="Analisador de código COBOL com IA",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "pyyaml>=5.4.0",
        "python-dotenv>=0.19.0",
        "colorama>=0.4.4",
        "tabulate>=0.8.9",
        "jinja2>=3.0.0",
        "markdown>=3.3.0",
        "beautifulsoup4>=4.9.0",
        "lxml>=4.6.0",
        "reportlab>=3.6.0",
        "weasyprint>=54.0",
        "fpdf2>=2.5.0",
        "xhtml2pdf>=0.2.5",
        "pdf2image>=1.16.0",
        "pillow>=8.3.0",
        "numpy>=1.21.0",
        "scikit-learn>=1.0.0",
        "sentence-transformers>=2.2.0"
    ],
    entry_points={
        'console_scripts': [
            'cobol-to-docs=cobol_to_docs.runner.main:main',
        ],
    },
    python_requires=">=3.8",
)
