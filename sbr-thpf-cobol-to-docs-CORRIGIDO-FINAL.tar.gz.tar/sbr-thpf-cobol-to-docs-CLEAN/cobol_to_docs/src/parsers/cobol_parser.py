"""Parser simples para código COBOL"""

import re
from typing import Dict, Any, List

class COBOLParser:
    def __init__(self):
        self.divisions = ['IDENTIFICATION', 'ENVIRONMENT', 'DATA', 'PROCEDURE']
    
    def parse(self, code: str) -> Dict[str, Any]:
        """Parse básico do código COBOL"""
        
        result = {
            'program_name': self._extract_program_name(code),
            'divisions': self._identify_divisions(code),
            'line_count': len(code.split('\n')),
            'has_file_section': 'FILE SECTION' in code.upper(),
            'has_working_storage': 'WORKING-STORAGE' in code.upper(),
            'procedures': self._extract_procedures(code)
        }
        
        return result
    
    def _extract_program_name(self, code: str) -> str:
        """Extrai nome do programa"""
        match = re.search(r'PROGRAM-ID\.\s*([A-Z0-9-]+)', code.upper())
        return match.group(1) if match else 'UNKNOWN'
    
    def _identify_divisions(self, code: str) -> List[str]:
        """Identifica divisões presentes"""
        found_divisions = []
        for division in self.divisions:
            if f'{division} DIVISION' in code.upper():
                found_divisions.append(division)
        return found_divisions
    
    def _extract_procedures(self, code: str) -> List[str]:
        """Extrai nomes de procedimentos"""
        procedures = []
        lines = code.split('\n')
        
        for line in lines:
            line = line.strip().upper()
            if line and not line.startswith('*') and '.' in line:
                # Procura por labels de parágrafo
                if re.match(r'^[A-Z][A-Z0-9-]*\.$', line.split()[0]):
                    proc_name = line.split()[0].rstrip('.')
                    if proc_name not in ['IDENTIFICATION', 'ENVIRONMENT', 'DATA', 'PROCEDURE']:
                        procedures.append(proc_name)
        
        return procedures
