"""Provider mock para testes"""

import time
import random
from typing import Dict, Any

class EnhancedMockProvider:
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.name = "enhanced_mock"
    
    def analyze(self, code: str, model: str = "enhanced-mock-gpt-4") -> Dict[str, Any]:
        """Simula análise de código COBOL"""
        
        # Simular tempo de processamento
        time.sleep(random.uniform(0.5, 1.5))
        
        # Análise mock baseada no código
        program_name = self._extract_program_name(code)
        
        analysis = f"""## Análise Estrutural do Programa {program_name}

### IDENTIFICATION DIVISION
- **Program-ID**: {program_name}
- **Autor**: Sistema COBOL
- **Data de criação**: Identificada no código fonte

### ENVIRONMENT DIVISION
- **Configuração de arquivos**: Detectados arquivos de entrada e saída
- **Organização**: Sequential file processing

### DATA DIVISION
#### File Section
- Estruturas de arquivo definidas para entrada e saída
- Layouts de registro estruturados

#### Working-Storage Section
- Variáveis de controle e contadores
- Áreas de trabalho para processamento

### PROCEDURE DIVISION
- **Fluxo principal**: Abertura → Processamento → Fechamento
- **Rotinas identificadas**:
  - Processamento de arquivo
  - Tratamento de registros
  - Cálculos e totalizações

## Regras de Negócio Identificadas

1. **Processamento sequencial** de arquivo de entrada
2. **Acumulação de totais** durante o processamento
3. **Geração de relatório** com dados processados
4. **Controle de fim de arquivo** adequado

## Recomendações

- ✅ Estrutura bem organizada
- ✅ Tratamento de EOF implementado
- ⚠️ Considerar tratamento de erros mais robusto
- ⚠️ Adicionar validações de dados de entrada

## Métricas de Qualidade

- **Complexidade**: Baixa
- **Manutenibilidade**: Alta
- **Legibilidade**: Boa
- **Padrões COBOL**: Seguidos

---

*Análise realizada por {model} ({self.name})*
"""
        
        tokens_used = len(code.split()) + len(analysis.split())
        processing_time = random.uniform(0.8, 2.0)
        
        return {
            'success': True,
            'analysis': analysis,
            'tokens_used': tokens_used,
            'processing_time': processing_time,
            'estimated_cost': tokens_used * 0.00001,
            'provider_used': self.name,
            'model_used': model,
            'program_name': program_name
        }
    
    def _extract_program_name(self, code: str) -> str:
        """Extrai nome do programa do código"""
        lines = code.split('\n')
        for line in lines:
            if 'PROGRAM-ID' in line.upper():
                parts = line.split('.')
                if len(parts) > 1:
                    return parts[1].strip()
        return "PROGRAMA-EXEMPLO"
