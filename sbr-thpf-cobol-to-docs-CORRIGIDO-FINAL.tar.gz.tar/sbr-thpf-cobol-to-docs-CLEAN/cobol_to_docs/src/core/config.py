"""Gerenciador de configuração do COBOL Analyzer"""

import yaml
import os
from typing import Dict, Any, Optional

class ConfigManager:
    def __init__(self, config_path: str = None):
        if config_path is None:
            config_path = os.path.join(os.path.dirname(__file__), "../config/config.yaml")
        
        self.config_path = config_path
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Carrega configuração do arquivo YAML"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except Exception as e:
            print(f"Erro ao carregar config: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Configuração padrão"""
        return {
            'providers': {
                'enhanced_mock': {
                    'enabled': True,
                    'models': {
                        'enhanced-mock-gpt-4': {
                            'name': 'enhanced-mock-gpt-4',
                            'max_tokens': 4096,
                            'temperature': 0.1
                        }
                    }
                }
            },
            'prompts': {
                'enhanced-mock-gpt-4': {
                    'system': 'Você é um especialista em COBOL.',
                    'user': 'Analise o código: {codigo_cobol}'
                }
            }
        }
    
    def get_provider_config(self, provider_name: str) -> Optional[Dict[str, Any]]:
        """Obtém configuração de um provider"""
        return self.config.get('providers', {}).get(provider_name)
    
    def get_model_config(self, model_name: str) -> Optional[Dict[str, Any]]:
        """Obtém configuração de um modelo"""
        for provider_config in self.config.get('providers', {}).values():
            models = provider_config.get('models', {})
            if model_name in models:
                return models[model_name]
        return None
    
    def get_prompt(self, model_name: str, prompt_type: str = 'user') -> str:
        """Obtém prompt para um modelo"""
        prompts = self.config.get('prompts', {}).get(model_name, {})
        return prompts.get(prompt_type, 'Analise o código COBOL fornecido.')
    
    def get_provider_for_model(self, model_name: str) -> str:
        """Obtém o provider de um modelo"""
        for provider_name, provider_config in self.config.get('providers', {}).items():
            models = provider_config.get('models', {})
            if model_name in models:
                return provider_name
        return 'enhanced_mock'  # fallback
