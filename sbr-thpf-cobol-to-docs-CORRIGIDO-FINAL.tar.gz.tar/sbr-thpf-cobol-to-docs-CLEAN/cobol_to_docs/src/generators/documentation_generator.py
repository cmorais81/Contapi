"""Gerador de documentação com estrutura provider/model"""

import os
import json
from datetime import datetime
from typing import Dict, Any

class DocumentationGenerator:
    def __init__(self, output_dir: str, provider: str = None, model: str = None):
        self.base_output_dir = output_dir
        self.provider = provider or "enhanced_mock"
        self.model = model or "enhanced-mock-gpt-4"
        
        # Criar estrutura provider/model
        self.output_dir = os.path.join(output_dir, self.provider, self.model)
        self.requests_dir = os.path.join(self.output_dir, "requests")
        self.responses_dir = os.path.join(self.output_dir, "responses")
        
        self._create_directories()
    
    def _create_directories(self):
        """Cria diretórios necessários"""
        for dir_path in [self.output_dir, self.requests_dir, self.responses_dir]:
            os.makedirs(dir_path, exist_ok=True)
    
    def save_request(self, program_name: str, request_data: Dict[str, Any]):
        """Salva dados da requisição"""
        filename = f"{program_name}_request.json"
        filepath = os.path.join(self.requests_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(request_data, f, indent=2, ensure_ascii=False)
        
        return filepath
    
    def save_response(self, program_name: str, response_data: Dict[str, Any]):
        """Salva dados da resposta"""
        filename = f"{program_name}_response.json"
        filepath = os.path.join(self.responses_dir, filename)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(response_data, f, indent=2, ensure_ascii=False)
        
        return filepath
    
    def generate_documentation(self, program_name: str, analysis_result: Dict[str, Any]):
        """Gera documentação markdown"""
        doc_content = f"""# Análise do Programa {program_name}

**Data**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Provider**: {self.provider}  
**Modelo**: {self.model}  

---

## Análise Funcional

{analysis_result.get('analysis', 'Análise não disponível')}

## Informações Técnicas

- **Tokens utilizados**: {analysis_result.get('tokens_used', 0)}
- **Tempo de processamento**: {analysis_result.get('processing_time', 0):.2f}s
- **Custo estimado**: ${analysis_result.get('estimated_cost', 0):.4f}

---

*Gerado pelo COBOL Analyzer v3.1.0*  
*Estrutura: {self.provider}/{self.model}/*
"""
        
        doc_filename = f"{program_name}_analise_funcional.md"
        doc_filepath = os.path.join(self.output_dir, doc_filename)
        
        with open(doc_filepath, 'w', encoding='utf-8') as f:
            f.write(doc_content)
        
        return doc_filepath
    
    def generate_cost_report(self, total_cost: float, total_tokens: int):
        """Gera relatório de custos"""
        report_content = f"""# Relatório de Custos

**Data**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}
**Provider**: {self.provider}
**Modelo**: {self.model}

## Resumo

- **Total de tokens**: {total_tokens:,}
- **Custo total**: ${total_cost:.4f}

---

*Relatório gerado automaticamente*
"""
        
        report_path = os.path.join(self.output_dir, "relatorio_custos.txt")
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        return report_path
