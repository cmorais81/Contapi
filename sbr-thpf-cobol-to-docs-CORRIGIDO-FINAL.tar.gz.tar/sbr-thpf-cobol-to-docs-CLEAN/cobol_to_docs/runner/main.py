#!/usr/bin/env python3
"""
Runner principal do COBOL Analyzer v3.1.0
CORRIGIDO: Sem temp_program, com estrutura provider/model
"""

import os
import sys
import argparse
import json
from datetime import datetime

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from core.config import ConfigManager
from generators.documentation_generator import DocumentationGenerator
from providers.enhanced_mock_provider import EnhancedMockProvider
from parsers.cobol_parser import COBOLParser

def main():
    parser = argparse.ArgumentParser(description='COBOL Analyzer v3.1.0')
    parser.add_argument('--fontes', required=True, help='Arquivo COBOL para análise')
    parser.add_argument('--output', default='output', help='Diretório de saída')
    parser.add_argument('--models', default='enhanced_mock', help='Modelo para análise')
    parser.add_argument('--log-level', default='INFO', help='Nível de log')
    
    args = parser.parse_args()
    
    print("🚀 COBOL ANALYZER v3.1.0")
    print("=" * 50)
    print(f"📄 Arquivo: {args.fontes}")
    print(f"📁 Saída: {args.output}")
    print(f"🤖 Modelo: {args.models}")
    print()
    
    # Verificar se arquivo existe
    if not os.path.exists(args.fontes):
        print(f"❌ Erro: Arquivo não encontrado: {args.fontes}")
        return 1
    
    # Carregar configuração
    config_manager = ConfigManager()
    
    # Ler código COBOL - SEM criar temp_program
    print("📖 Lendo código COBOL...")
    try:
        with open(args.fontes, 'r', encoding='utf-8') as f:
            cobol_code = f.read()
        print(f"   ✓ {len(cobol_code)} caracteres lidos")
    except Exception as e:
        print(f"❌ Erro ao ler arquivo: {e}")
        return 1
    
    # Parse básico
    parser_obj = COBOLParser()
    parse_result = parser_obj.parse(cobol_code)
    program_name = parse_result['program_name']
    
    print(f"🔍 Programa identificado: {program_name}")
    print(f"📊 Linhas de código: {parse_result['line_count']}")
    
    # Determinar provider e modelo
    model_name = args.models
    provider_name = config_manager.get_provider_for_model(model_name)
    
    print(f"🏢 Provider: {provider_name}")
    print(f"🤖 Modelo: {model_name}")
    
    # Criar gerador de documentação com estrutura provider/model
    doc_generator = DocumentationGenerator(
        output_dir=args.output,
        provider=provider_name,
        model=model_name
    )
    
    print(f"📁 Estrutura de saída: {provider_name}/{model_name}/")
    
    # Inicializar provider
    if provider_name == 'enhanced_mock':
        provider = EnhancedMockProvider()
    else:
        print(f"⚠️ Provider {provider_name} não implementado, usando enhanced_mock")
        provider = EnhancedMockProvider()
    
    # Realizar análise
    print("\n🔬 Iniciando análise...")
    start_time = datetime.now()
    
    try:
        analysis_result = provider.analyze(cobol_code, model_name)
        
        if analysis_result['success']:
            print("   ✅ Análise concluída com sucesso")
            
            # Salvar request
            request_data = {
                'program_name': program_name,
                'model': model_name,
                'provider': provider_name,
                'timestamp': datetime.now().isoformat(),
                'code_length': len(cobol_code),
                'prompt_system': config_manager.get_prompt(model_name, 'system'),
                'prompt_user': config_manager.get_prompt(model_name, 'user').format(codigo_cobol=cobol_code[:500] + '...')
            }
            
            request_file = doc_generator.save_request(program_name, request_data)
            print(f"   ✓ Request salvo: {os.path.basename(request_file)}")
            
            # Salvar response
            response_data = {
                'program_name': program_name,
                'success': True,
                'analysis': analysis_result['analysis'],
                'tokens_used': analysis_result['tokens_used'],
                'processing_time': analysis_result['processing_time'],
                'estimated_cost': analysis_result['estimated_cost'],
                'timestamp': datetime.now().isoformat(),
                'provider': provider_name,
                'model': model_name
            }
            
            response_file = doc_generator.save_response(program_name, response_data)
            print(f"   ✓ Response salvo: {os.path.basename(response_file)}")
            
            # Gerar documentação
            doc_file = doc_generator.generate_documentation(program_name, analysis_result)
            print(f"   ✓ Documentação: {os.path.basename(doc_file)}")
            
            # Gerar relatório de custos
            cost_file = doc_generator.generate_cost_report(
                analysis_result['estimated_cost'],
                analysis_result['tokens_used']
            )
            print(f"   ✓ Relatório de custos: {os.path.basename(cost_file)}")
            
        else:
            print("   ❌ Análise falhou")
            return 1
            
    except Exception as e:
        print(f"❌ Erro durante análise: {e}")
        return 1
    
    # Estatísticas finais
    end_time = datetime.now()
    total_time = (end_time - start_time).total_seconds()
    
    print("\n" + "=" * 50)
    print("📊 PROCESSAMENTO CONCLUÍDO")
    print(f"✅ Programa processado: {program_name}")
    print(f"🤖 Modelo utilizado: {model_name} ({provider_name})")
    print(f"📊 Tokens utilizados: {analysis_result['tokens_used']:,}")
    print(f"💰 Custo estimado: ${analysis_result['estimated_cost']:.4f}")
    print(f"⏱️ Tempo total: {total_time:.2f}s")
    print(f"📁 Documentação gerada em: {doc_generator.output_dir}")
    print("=" * 50)
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
