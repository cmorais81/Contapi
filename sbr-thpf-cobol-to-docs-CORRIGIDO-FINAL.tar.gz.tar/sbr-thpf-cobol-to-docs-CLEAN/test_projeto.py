#!/usr/bin/env python3
"""Script de teste para validar o projeto"""

import os
import sys
import subprocess

def test_project():
    print("🧪 TESTANDO PROJETO LIMPO")
    print("=" * 40)
    
    # Verificar estrutura
    print("1. Verificando estrutura...")
    required_files = [
        "setup.py",
        "requirements.txt", 
        "cobol_to_docs/__init__.py",
        "cobol_to_docs/src/__init__.py",
        "cobol_to_docs/runner/main.py",
        "examples/PROGRAMA_EXEMPLO.CBL"
    ]
    
    for file_path in required_files:
        if os.path.exists(file_path):
            print(f"   ✅ {file_path}")
        else:
            print(f"   ❌ {file_path}")
    
    # Testar execução
    print("\n2. Testando execução...")
    cmd = [
        sys.executable,
        "cobol_to_docs/runner/main.py",
        "--fontes", "examples/PROGRAMA_EXEMPLO.CBL",
        "--output", "test_output",
        "--models", "enhanced_mock"
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            print("   ✅ Execução bem-sucedida")
            
            # Verificar saída
            if os.path.exists("test_output"):
                print("   ✅ Diretório de saída criado")
                
                # Verificar estrutura provider/model
                provider_dir = "test_output/enhanced_mock/enhanced-mock-gpt-4"
                if os.path.exists(provider_dir):
                    print("   ✅ Estrutura provider/model criada")
                    
                    requests_dir = os.path.join(provider_dir, "requests")
                    responses_dir = os.path.join(provider_dir, "responses")
                    
                    if os.path.exists(requests_dir) and os.path.exists(responses_dir):
                        print("   ✅ Subpastas requests/ e responses/ criadas")
                    else:
                        print("   ❌ Subpastas não encontradas")
                else:
                    print("   ❌ Estrutura provider/model não criada")
            else:
                print("   ❌ Diretório de saída não criado")
        else:
            print("   ❌ Execução falhou")
            print(f"   Erro: {result.stderr}")
    
    except subprocess.TimeoutExpired:
        print("   ⏰ Timeout na execução")
    except Exception as e:
        print(f"   ❌ Erro: {e}")
    
    print("\n🏁 TESTE CONCLUÍDO")

if __name__ == "__main__":
    test_project()
