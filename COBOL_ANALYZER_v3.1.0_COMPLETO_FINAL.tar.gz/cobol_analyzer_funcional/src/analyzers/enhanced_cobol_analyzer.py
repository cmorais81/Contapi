"""
COBOL AI Engine v3.0.0 - Enhanced COBOL Code Analyzer
Analisador aprimorado de código COBOL com foco em análise profunda de comentários e lógica de negócio.
"""

import re
import logging
from typing import Dict, List, Any, Tuple, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict

# Importar classes necessárias
try:
    from ..providers.base_provider import AIRequest, AIResponse
    from ..parsers.cobol_parser import CobolProgram
except ImportError:
    from providers.base_provider import AIRequest, AIResponse
    from parsers.cobol_parser import CobolProgram


@dataclass
class AnalysisResult:
    """Resultado da análise de um programa COBOL."""
    success: bool
    content: str = ""
    error_message: str = ""
    tokens_used: int = 0
    model_used: str = ""
    provider_used: str = ""
    analysis_time: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)


class EnhancedCOBOLAnalyzer:
    """
    Analisador aprimorado de código COBOL com foco em análise profunda
    de comentários e extração de lógica de negócio.
    """
    
    def __init__(self, provider_manager=None, prompt_manager=None, rag_integration=None):
        self.logger = logging.getLogger(__name__)
        self.provider_manager = provider_manager
        self.prompt_manager = prompt_manager
        self.rag_integration = rag_integration
        
        if rag_integration and rag_integration.is_enabled():
            self.logger.info("Enhanced COBOL Analyzer inicializado com RAG ativo")
        else:
            self.logger.info("Enhanced COBOL Analyzer inicializado sem RAG")
    
    def analyze_program(self, program: CobolProgram, model: str, **kwargs) -> AnalysisResult:
        """
        Analisa um programa COBOL usando IA.
        
        Args:
            program: Programa COBOL parseado
            model: Modelo de IA a usar
            
        Returns:
            AnalysisResult: Resultado da análise
        """
        try:
            self.logger.info(f"Iniciando análise do programa: {program.name}")
            
            # Preparar prompt para análise
            if self.prompt_manager:
                # Gerar prompt base
                base_prompt = self.prompt_manager.generate_base_prompt(program.name, program.content)
                
                # Enriquecer com RAG se disponível
                if self.rag_integration and self.rag_integration.is_enabled():
                    self.logger.info(f"*** ENRIQUECENDO ANÁLISE COM RAG para {program.name} ***")
                    prompt = self.rag_integration.enhance_analysis_prompt(
                        program.name, 
                        program.content, 
                        base_prompt, 
                        "cobol_analysis"
                    )
                else:
                    prompt = base_prompt
            else:
                prompt = self._get_default_prompt(program)
            
            # Criar request para IA
            ai_request = AIRequest(
                prompt=prompt,
                program_name=program.name,
                program_code=program.content,
                max_tokens=4000,
                temperature=0.1
            )
            
            # Fazer análise com IA
            if self.provider_manager:
                # Se um modelo específico foi solicitado, usar analyze_with_model (sem fallback)
                # Se não, usar analyze (com fallback)
                if model and model != 'auto':
                    self.logger.info(f"Usando modelo específico: {model} (sem fallback)")
                    response = self.provider_manager.analyze_with_model(model, ai_request)
                else:
                    self.logger.info("Usando análise com fallback automático")
                    response = self.provider_manager.analyze(ai_request)
                
                # Adicionar prompt usado na resposta para auditoria
                if not hasattr(response, 'prompts_used') or not response.prompts_used:
                    response.prompts_used = {}
                
                # Salvar o prompt final enriquecido (não o base)
                response.prompts_used['system_prompt'] = prompt  # Prompt final enriquecido
                response.prompts_used['full_prompt'] = prompt
                response.prompts_used['program_code'] = program.content
                response.prompts_used['program_name'] = program.name
                response.prompts_used['original_prompt'] = prompt  # Prompt completo usado
                response.prompts_used['main_prompt'] = prompt[:1000] + "..." if len(prompt) > 1000 else prompt
                
                if response.success:
                    return AnalysisResult(
                        success=True,
                        content=response.content,
                        tokens_used=response.tokens_used,
                        model_used=response.model,
                        provider_used=response.provider,
                        metadata={
                            'program_name': program.name,
                            'line_count': program.line_count,
                            'size': program.size,
                            'prompt_used': prompt[:500] + "..." if len(prompt) > 500 else prompt  # Resumo do prompt
                        }
                    )
                else:
                    return AnalysisResult(
                        success=False,
                        error_message=response.error_message,
                        model_used=response.model,
                        provider_used=response.provider
                    )
            else:
                # Fallback sem provider manager
                return self._mock_analysis(program, model)
                
        except Exception as e:
            self.logger.error(f"Erro na análise do programa {program.name}: {str(e)}")
            return AnalysisResult(
                success=False,
                error_message=str(e),
                model_used=model
            )
    
    def _get_default_prompt(self, program: CobolProgram) -> str:
        """Gera prompt padrão para análise."""
        return f"""
Analise o seguinte programa COBOL e forneça uma documentação detalhada:

PROGRAMA: {program.name}
LINHAS: {program.line_count}
TAMANHO: {program.size} bytes

CÓDIGO:
{program.content}

Por favor, forneça:
1. Propósito e objetivo principal do programa
2. Divisões e seções identificadas
3. Variáveis e estruturas de dados principais
4. Arquivos utilizados
5. Lógica de negócio principal
6. Fluxo de processamento
7. Observações técnicas importantes

Formato da resposta em markdown estruturado.
"""
    
    def _mock_analysis(self, program: CobolProgram, model: str) -> AnalysisResult:
        """Análise mock para testes."""
        mock_content = f"""
# Análise do Programa COBOL: {program.name}

## Informações Gerais
- **Nome**: {program.name}
- **Linhas**: {program.line_count}
- **Tamanho**: {program.size} bytes
- **Modelo usado**: {model}

## Divisões Identificadas
{self._format_divisions(program.divisions)}

## Seções
{self._format_sections(program.sections)}

## Variáveis
{self._format_variables(program.variables)}

## Arquivos
{self._format_files(program.files)}

## Análise Técnica
Este programa COBOL foi analisado automaticamente pelo sistema COBOL to Docs v1.1.
A análise completa requer configuração de providers de IA.

---
*Análise gerada por: Enhanced Mock Provider*
*Data: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}*
"""
        
        return AnalysisResult(
            success=True,
            content=mock_content,
            tokens_used=len(mock_content.split()),
            model_used=model,
            metadata={
                'program_name': program.name,
                'line_count': program.line_count,
                'size': program.size,
                'analysis_type': 'mock'
            }
        )
    
    def _format_divisions(self, divisions: Dict[str, str]) -> str:
        """Formata divisões para exibição."""
        if not divisions:
            return "- Nenhuma divisão identificada"
        
        result = []
        for name, content in divisions.items():
            lines = len(content.split('\n'))
            result.append(f"- **{name}**: {lines} linhas")
        
        return '\n'.join(result)
    
    def _format_sections(self, sections: List[str]) -> str:
        """Formata seções para exibição."""
        if not sections:
            return "- Nenhuma seção identificada"
        
        return '\n'.join([f"- {section}" for section in sections])
    
    def _format_variables(self, variables: List[str]) -> str:
        """Formata variáveis para exibição."""
        if not variables:
            return "- Nenhuma variável identificada"
        
        # Mostrar apenas as primeiras 10 variáveis
        display_vars = variables[:10]
        result = '\n'.join([f"- {var}" for var in display_vars])
        
        if len(variables) > 10:
            result += f"\n- ... e mais {len(variables) - 10} variáveis"
        
        return result
    
    def _format_files(self, files: List[str]) -> str:
        """Formata arquivos para exibição."""
        if not files:
            return "- Nenhum arquivo identificado"
        
        return '\n'.join([f"- {file}" for file in files])
