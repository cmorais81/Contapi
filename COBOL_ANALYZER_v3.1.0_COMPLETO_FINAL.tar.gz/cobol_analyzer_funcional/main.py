#!/usr/bin/env python3
"""
COBOL to Docs v3.1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Outubro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

NOVA FUNCIONALIDADE v3.1.0:
- Inicialização automática de diretórios locais na primeira execução
- Parâmetros de linha de comando para personalização de caminhos
- Configuração automática de ambiente local
- Suporte a diretórios personalizados via CLI
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config_enhanced import EnhancedConfigManager as ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration import RAGIntegration
from src.core.intelligent_model_selector import IntelligentModelSelector
from src.analytics.consolidated_analysis import (
    process_advanced_consolidated_analysis,
    process_detailed_business_analysis
)
from src.core.local_setup import LocalSetup, auto_setup_environment

def setup_logging(log_level: str = "INFO", logs_dir: str = None) -> None:
    """Configura o sistema de logging com diretório personalizável."""
    log_dir = logs_dir or "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def initialize_local_environment(args) -> Dict[str, str]:
    """
    Inicializa o ambiente local automaticamente na primeira execução
    ou quando diretórios personalizados são especificados.
    
    Args:
        args: Argumentos da linha de comando
        
    Returns:
        dict: Caminhos dos diretórios configurados
    """
    logger = logging.getLogger(__name__)
    
    # Verificar se diretórios personalizados foram especificados
    custom_config = args.config_dir if hasattr(args, 'config_dir') else None
    custom_data = args.data_dir if hasattr(args, 'data_dir') else None
    custom_logs = args.logs_dir if hasattr(args, 'logs_dir') else None
    
    # Verificar se é primeira execução ou se há diretórios personalizados
    setup = LocalSetup()
    needs_setup = (not setup.is_initialized() or 
                   custom_config or custom_data or custom_logs or
                   (hasattr(args, 'force_init') and args.force_init))
    
    if needs_setup:
        logger.info("Configurando ambiente local do COBOL Analyzer...")
        
        # Configurar ambiente com diretórios personalizados se especificados
        result = auto_setup_environment(
            config_dir=custom_config,
            data_dir=custom_data, 
            logs_dir=custom_logs,
            force=hasattr(args, 'force_init') and args.force_init
        )
        
        logger.info("Ambiente local configurado com sucesso!")
        return result
    else:
        # Retornar caminhos existentes
        return setup.get_local_paths(custom_config, custom_data, custom_logs)

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        # String simples
        return [models_str]

def analyze_program_with_model(program: CobolProgram, books: List[CobolBook], model: str, output_dir: str, config_manager: ConfigManager, is_multi_model: bool, prompt_set: str, cost_calculator: CostCalculator, rag_integration=None, args=None) -> Dict[str, Any]:
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)
    
    # Criar diretório específico do modelo se multi-modelo
    if is_multi_model:
        model_output_dir = os.path.join(output_dir, f"model_{model.replace('/', '_').replace('-', '_')}")
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = output_dir
    
    try:
        # Inicializar componentes específicos para o modelo
        prompt_manager = DualPromptManager(config_manager.config, prompt_set)
        provider_manager = EnhancedProviderManager(config_manager.config)
        doc_generator = DocumentationGenerator(model_output_dir)
        
        # Análise com IA (passando RAG integration)
        analyzer = EnhancedCOBOLAnalyzer(
            provider_manager=provider_manager,
            prompt_manager=prompt_manager,
            rag_integration=rag_integration
        )
        
        # Configurar opções de análise baseadas nos argumentos
        analysis_options = {
            'procedure_detalhada': getattr(args, 'procedure_detalhada', False),
            'modernizacao': getattr(args, 'modernizacao', False),
            'deep_analysis': getattr(args, 'deep_analysis', False),
            'extract_formulas': getattr(args, 'extract_formulas', False),
            'no_comments': getattr(args, 'no_comments', False)
        }
        
        # Executar análise
        analysis_result = analyzer.analyze_program(
            program=program,
            model=model,
            **analysis_options
        )
        
        # Registrar custos
        if 'cost_info' in analysis_result:
            cost_calculator.add_analysis_cost(
                model=model,
                program_name=program.name,
                **analysis_result['cost_info']
            )
        
        # Gerar documentação
        doc_result = doc_generator.generate_documentation(
            program=program,
            analysis_result=analysis_result,
            books=books,
            generate_pdf=getattr(args, 'pdf', False)
        )
        
        logger.info(f"Análise concluída para {program.name} com modelo {model}")
        
        return {
            'program_name': program.name,
            'model': model,
            'analysis_result': analysis_result,
            'documentation': doc_result,
            'output_dir': model_output_dir
        }
        
    except Exception as e:
        logger.error(f"Erro na análise do programa {program.name} com modelo {model}: {str(e)}")
        return {
            'program_name': program.name,
            'model': model,
            'error': str(e),
            'output_dir': model_output_dir
        }

def process_cobol_files(args, config_manager: ConfigManager, cost_calculator: CostCalculator, rag_integration=None, local_paths=None):
    """Processa os arquivos COBOL especificados."""
    logger = logging.getLogger(__name__)
    
    # Usar caminhos locais se fornecidos
    if local_paths:
        logger.info(f"Usando configuração local: {local_paths['config_dir']}")
    
    # Parse dos modelos
    models = parse_models_argument(args.models) if args.models else ['enhanced_mock']
    is_multi_model = len(models) > 1
    
    # Criar diretório de saída
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if is_multi_model:
        output_dir = f"{args.output}_multi_model_{timestamp}"
    else:
        output_dir = f"{args.output}_{timestamp}"
    
    os.makedirs(output_dir, exist_ok=True)
    logger.info(f"Diretório de saída: {output_dir}")
    
    # Carregar programas COBOL
    parser = COBOLParser()
    programs = []
    
    # Ler lista de arquivos do arquivo fontes
    try:
        with open(args.fontes, 'r', encoding='utf-8') as f:
            file_paths = [line.strip() for line in f if line.strip()]
        
        # Processar cada arquivo
        for file_path in file_paths:
            if os.path.exists(file_path):
                try:
                    parsed_programs, _ = parser.parse_file(file_path)
                    programs.extend(parsed_programs)
                    logger.info(f"Arquivo processado: {file_path}")
                except Exception as e:
                    logger.error(f"Erro ao processar {file_path}: {e}")
            else:
                logger.warning(f"Arquivo não encontrado: {file_path}")
                
    except Exception as e:
        logger.error(f"Erro ao ler arquivo de fontes {args.fontes}: {e}")
        return
    
    if not programs:
        logger.error("Nenhum programa COBOL válido encontrado")
        return
    
    logger.info(f"Carregados {len(programs)} programas COBOL")
    
    # Carregar copybooks se especificado
    books = []
    if args.books and os.path.exists(args.books):
        books = parser.load_books_from_file(args.books)
        logger.info(f"Carregados {len(books)} copybooks")
    
    # Seleção automática de modelo se solicitada
    if args.auto_model:
        selector = IntelligentModelSelector(config_manager.config)
        for program in programs:
            recommended_model = selector.select_best_model(program)
            logger.info(f"Modelo recomendado para {program.name}: {recommended_model}")
    
    # Processar cada programa com cada modelo
    all_results = []
    
    for program in programs:
        logger.info(f"Processando programa: {program.name}")
        
        for model in models:
            logger.info(f"Analisando {program.name} com modelo {model}")
            
            result = analyze_program_with_model(
                program=program,
                books=books,
                model=model,
                output_dir=output_dir,
                config_manager=config_manager,
                is_multi_model=is_multi_model,
                prompt_set=args.prompt_set,
                cost_calculator=cost_calculator,
                rag_integration=rag_integration,
                args=args
            )
            
            all_results.append(result)
    
    # Análise consolidada se solicitada
    if args.consolidado or args.relatorio_unico:
        logger.info("Executando análise consolidada...")
        
        consolidator = ConsolidatedAnalyzer(
            provider_manager=EnhancedProviderManager(config_manager.config),
            prompt_manager=DualPromptManager(config_manager.config, args.prompt_set),
            rag_integration=rag_integration
        )
        
        consolidated_result = consolidator.analyze_system(
            programs=programs,
            books=books,
            models=models,
            analysis_results=all_results
        )
        
        # Gerar relatório consolidado
        html_generator = HTMLReportGenerator(output_dir)
        consolidated_report = html_generator.generate_consolidated_report(
            programs=programs,
            analysis_results=all_results,
            consolidated_analysis=consolidated_result,
            cost_summary=cost_calculator.get_summary()
        )
        
        logger.info(f"Relatório consolidado gerado: {consolidated_report}")
    
    # Análise avançada se solicitada
    if args.advanced_analysis:
        logger.info("Executando análise avançada...")
        
        advanced_result = process_advanced_consolidated_analysis(
            programs=programs,
            books=books,
            output_dir=output_dir,
            config_manager=config_manager,
            rag_integration=rag_integration
        )
        
        logger.info(f"Análise avançada concluída: {advanced_result}")
    
    # Exibir resumo final
    print(f"\n=== RESUMO DA EXECUÇÃO ===")
    print(f"Programas processados: {len(programs)}")
    print(f"Modelos utilizados: {', '.join(models)}")
    print(f"Diretório de saída: {output_dir}")
    
    # Resumo de custos
    cost_summary = cost_calculator.get_cost_summary()
    if cost_summary['total_cost'] > 0:
        print(f"Custo total estimado: ${cost_summary['total_cost']:.4f}")
    
    print("=" * 40)

def create_argument_parser():
    """Cria o parser de argumentos com novos parâmetros para diretórios personalizados."""
    parser = argparse.ArgumentParser(
        description="COBOL to Docs v3.1.0 - Análise e Documentação de Programas COBOL",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  python main_enhanced.py --fontes examples/fontes.txt
  python main_enhanced.py --fontes examples/fontes.txt --books examples/books.txt
  python main_enhanced.py --fontes examples/fontes.txt --models '["aws-claude-3.7", "enhanced_mock"]'
  python main_enhanced.py --fontes examples/fontes.txt --consolidado
  python main_enhanced.py --fontes examples/fontes.txt --config-dir ./minha_config --data-dir ./meus_dados
  python main_enhanced.py --status
  python main_enhanced.py --init-local --force-init
        """
    )
    
    # Argumentos originais
    parser.add_argument('--fontes', type=str, help='Arquivo com programas COBOL')
    parser.add_argument('--books', type=str, help='Arquivo com copybooks COBOL')
    parser.add_argument('--output', type=str, default='output', help='Diretório de saída')
    parser.add_argument('--models', type=str, help='Modelos de IA (string ou JSON array)')
    parser.add_argument('--prompt-set', type=str, default='original', help='Conjunto de prompts')
    parser.add_argument('--log-level', type=str, default='INFO', help='Nível de log')
    parser.add_argument('--pdf', action='store_true', help='Gerar relatórios HTML/PDF')
    parser.add_argument('--relatorio-unico', action='store_true',
                        help='Gera relatório único consolidado de todo o sistema')
    parser.add_argument('--consolidado', action='store_true',
                        help='Análise consolidada sistêmica de todos os programas simultaneamente')
    parser.add_argument('--analise-especialista', action='store_true',
                        help='Usa prompts especializados para análise técnica profunda')
    parser.add_argument('--procedure-detalhada', action='store_true',
                        help='Foca na análise detalhada da PROCEDURE DIVISION')
    parser.add_argument('--modernizacao', action='store_true',
                        help='Inclui análise de modernização e migração')
    parser.add_argument('--status', action='store_true', help='Verificar status dos provedores')
    parser.add_argument('--auto-model', action='store_true', 
                        help='Seleção automática de modelo baseada na complexidade do código')
    parser.add_argument('--model-comparison', action='store_true',
                        help='Exibir comparação de adequação de modelos para o código')
    parser.add_argument('--deep-analysis', action='store_true',
                        help='Análise detalhada de regras de negócio com valores específicos')
    parser.add_argument('--extract-formulas', action='store_true',
                        help='Extrair fórmulas matemáticas e cálculos específicos do código')
    parser.add_argument('--advanced-analysis', action='store_true',
                        help='Executar análise avançada com relatório consolidado HTML profissional')
    parser.add_argument('--no-comments', action='store_true',
                        help='Remove comentários do código antes da análise (útil para códigos com muitos comentários)')
    
    # NOVOS ARGUMENTOS v3.1.0 - Personalização de diretórios
    parser.add_argument('--config-dir', type=str, 
                        help='Diretório personalizado para arquivos de configuração (padrão: ./config)')
    parser.add_argument('--data-dir', type=str,
                        help='Diretório personalizado para dados RAG e base de conhecimento (padrão: ./data)')
    parser.add_argument('--logs-dir', type=str,
                        help='Diretório personalizado para arquivos de log (padrão: ./logs)')
    parser.add_argument('--init-local', action='store_true',
                        help='Inicializar ambiente local (criar diretórios e arquivos padrão)')
    parser.add_argument('--force-init', action='store_true',
                        help='Forçar reinicialização do ambiente local mesmo se já configurado')
    parser.add_argument('--show-paths', action='store_true',
                        help='Exibir caminhos de diretórios configurados e sair')
    
    return parser

def main():
    """Função principal com inicialização automática de ambiente."""
    parser = create_argument_parser()
    args = parser.parse_args()
    
    # Inicializar ambiente local automaticamente
    try:
        local_paths = initialize_local_environment(args)
        
        # Se solicitado apenas mostrar caminhos, exibir e sair
        if args.show_paths:
            print("=== CAMINHOS CONFIGURADOS ===")
            print(f"Configurações: {local_paths['config_dir']}")
            print(f"Dados RAG: {local_paths['data_dir']}")
            print(f"Logs: {local_paths['logs_dir']}")
            print(f"Exemplos: {local_paths['examples_dir']}")
            return
        
        # Se solicitado apenas inicialização, fazer e sair
        if args.init_local:
            print("Ambiente local inicializado com sucesso!")
            return
            
    except Exception as e:
        print(f"Erro na inicialização do ambiente local: {e}")
        # Continuar com configuração padrão no diretório atual
        current_dir = os.getcwd()
        local_paths = {
            'config_dir': os.path.join(current_dir, 'config'),
            'data_dir': os.path.join(current_dir, 'data'), 
            'logs_dir': os.path.join(current_dir, 'logs'),
            'examples_dir': os.path.join(current_dir, 'examples')
        }
        
        # Se não existir config local, tentar inicializar automaticamente
        if not os.path.exists(local_paths['config_dir']):
            print("Configuração local não encontrada. Executando inicialização automática...")
            try:
                from src.core.local_setup import auto_setup_environment
                auto_setup_environment(
                    config_dir=local_paths['config_dir'],
                    data_dir=local_paths['data_dir'],
                    logs_dir=local_paths['logs_dir'],
                    examples_dir=local_paths['examples_dir']
                )
                print("Inicialização automática concluída!")
            except Exception as init_error:
                print(f"Erro na inicialização automática: {init_error}")
                print("Usando configuração padrão do sistema...")
    
    # Configurar logging com diretório personalizado
    setup_logging(args.log_level, local_paths['logs_dir'])
    logger = logging.getLogger(__name__)
    
    try:
        # Carregar configuração do diretório local
        config_manager = ConfigManager(
            config_dir=local_paths['config_dir'],
            data_dir=local_paths['data_dir'],
            logs_dir=local_paths['logs_dir']
        )
        
        # Inicializar sistema RAG
        rag_integration = RAGIntegration(config_manager.config)
        
        if rag_integration.is_enabled():
            rag_stats = rag_integration.get_rag_statistics()
            logger.info(f"Sistema RAG inicializado: {rag_stats['total_items']} itens na base de conhecimento")
        else:
            logger.info("Sistema RAG desabilitado")
        
        # Inicializar calculadora de custos
        cost_calculator = CostCalculator()
        
        # Verificar status se solicitado
        if args.status:
            provider_manager = EnhancedProviderManager(config_manager.config)
            print("=== STATUS DOS PROVEDORES ===")
            providers = ['luzia', 'enhanced_mock', 'basic']
            for name in providers:
                try:
                    available = provider_manager.get_provider_status(name)
                    print(f"  {name}: {'Disponível' if available else 'Indisponível'}")
                except Exception as e:
                    print(f"  {name}: Erro - {e}")
            return
        
        # Validar argumentos
        if not args.fontes:
            print("Erro: --fontes é obrigatório")
            parser.print_help()
            return
        
        if not os.path.exists(args.fontes):
            print(f"Erro: Arquivo não encontrado: {args.fontes}")
            return
        
        # Processar arquivos COBOL
        process_cobol_files(args, config_manager, cost_calculator, rag_integration, local_paths)
        
        # Finalizar sessão RAG e gerar relatório
        if rag_integration.is_enabled():
            try:
                rag_report = rag_integration.finalize_session()
                if rag_report:
                    logger.info(f"Relatório de uso do RAG gerado: {rag_report}")
                    print(f"\n=== RELATÓRIO RAG DISPONÍVEL ===")
                    print(f"Arquivo: {rag_report}")
                    
                    # Exibir resumo da sessão
                    session_summary = rag_integration.get_session_summary()
                    if session_summary:
                        print(f"Operações RAG realizadas: {session_summary.get('total_operations', 0)}")
                        print(f"Programas analisados: {len(session_summary.get('programs_analyzed', []))}")
                        print(f"Itens de conhecimento utilizados: {session_summary.get('knowledge_items_used', 0)}")
                        print("=" * 40)
            except Exception as e:
                logger.warning(f"Erro ao finalizar sessão RAG: {e}")
        
    except KeyboardInterrupt:
        print("\nProcessamento interrompido pelo usuário.")
    except Exception as e:
        import traceback
        logger.error(f"Erro fatal: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        print(f"Erro: {str(e)}")
        print("Traceback completo:")
        traceback.print_exc()

if __name__ == "__main__":
    main()
