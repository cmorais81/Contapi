# Manual de Uso Completo - COBOL Analysis Engine v2.0

## 🎯 Visão Geral

O **COBOL Analysis Engine v2.0** é um sistema que analisa programas COBOL e explica de forma simples:

- **O que o programa faz** (objetivo principal)
- **Quais são as regras de negócio** importantes  
- **Se há particularidades** que merecem atenção

---

## 📋 Todos os Parâmetros e Opções

### Sintaxe Completa

```bash
python3.11 main.py [arquivo_entrada] [opções]
```

### Parâmetros Obrigatórios

| Parâmetro | Descrição | Exemplo |
|-----------|-----------|---------|
| `arquivo_entrada` | Arquivo COBOL (.cbl) ou fontes.txt | `programa.cbl` ou `fontes.txt` |

### Parâmetros Opcionais

| Parâmetro | Descrição | Valores | Padrão | Exemplo |
|-----------|-----------|---------|--------|---------|
| `-o, --output` | Diretório de saída | Qualquer caminho | `./output/` | `-o resultados/` |
| `-b, --books` | Arquivo de copybooks | Arquivo .txt | Nenhum | `-b BOOKS.txt` |
| `-m, --mode` | Modo de análise | `traditional`, `multi_ai`, `enhanced` | `multi_ai` | `-m enhanced` |
| `-c, --config` | Arquivo de configuração | Arquivo .yaml | `config/config.yaml` | `-c minha_config.yaml` |
| `-v, --verbose` | Saída detalhada | Flag (sem valor) | Desabilitado | `-v` |
| `-h, --help` | Ajuda | Flag (sem valor) | - | `--help` |
| `--status` | Testar conectividade | Flag (sem valor) | - | `--status` |

---

## 🔧 Modos de Análise Disponíveis

### 1. **Traditional** (Rápido)
- **O que faz:** Análise básica sem IA
- **Tempo:** ~0.01s por programa
- **Saída:** Estrutura básica do programa
- **Quando usar:** Para análise rápida de estrutura

```bash
python3.11 main.py programa.cbl -m traditional
```

### 2. **Multi_AI** (Padrão)
- **O que faz:** Análise estrutural com IA
- **Tempo:** ~5-10s por programa
- **Saída:** Análise estrutural detalhada
- **Quando usar:** Para análise completa sem captura de prompts

```bash
python3.11 main.py programa.cbl -m multi_ai
```

### 3. **Enhanced** (Recomendado)
- **O que faz:** Análise funcional com captura de prompts/respostas
- **Tempo:** ~5-15s por programa
- **Saída:** Explicação clara + prompts originais das IAs
- **Quando usar:** Para máxima transparência e compreensão

```bash
python3.11 main.py programa.cbl -m enhanced
```

---

## 📁 Tipos de Entrada Suportados

### 1. Arquivo COBOL Individual

```bash
# Análise de um programa específico
python3.11 main.py examples/LHAN0542_TESTE.cbl -o resultados/
```

**Formatos aceitos:**
- `.cbl` - Arquivo COBOL padrão
- `.cob` - Arquivo COBOL alternativo
- `.txt` - Arquivo texto com código COBOL

### 2. Arquivo fontes.txt (Lote)

```bash
# Análise de múltiplos programas
python3.11 main.py examples/fontes.txt -o resultados_lote/
```

**Formato do fontes.txt:**
```
VMEMBER NAME  LHAN0542
V      ******************** OBJETIVO DO PROGRAMA ***********************
V      *** PARTICIONAR ARQUIVO BACEN DOC3040                          **
V      **  SERAO GERADOS ARQUIVOS PARTICIONADOS DINAMICAMENTE         **
V      *****************************************************************
V       IDENTIFICATION DIVISION.
V       PROGRAM-ID. LHAN0542.
...
VMEMBER NAME  LHAN0705
V      ******************** OUTRO PROGRAMA ****************************
...
```

### 3. Arquivo BOOKS.txt (Copybooks)

```bash
# Incluir copybooks na análise
python3.11 main.py programa.cbl -b examples/BOOKS.txt
```

**Formato do BOOKS.txt:**
```
BOOK NAME     LHCP3402
B      01  WS-DADOS-ENTRADA.
B          05  WS-TIPO-REGISTRO    PIC X(02).
B          05  WS-NUMERO-CONTA     PIC 9(10).
...
BOOK NAME     LHCP3403
B      01  WS-DADOS-SAIDA.
...
```

---

## 🚀 Exemplos Práticos Completos

### Exemplo 1: Análise Simples

```bash
# Comando
python3.11 main.py examples/LHAN0542_TESTE.cbl

# Resultado
🔍 Detectado programa COBOL: examples/LHAN0542_TESTE.cbl
⚙️ Análise individual iniciada...
✅ Análise concluída com sucesso!
📄 Relatório: LHAN0542_TESTE_MULTI_AI_ANALYSIS.md
⏱️ Tempo total: 8.45s
```

### Exemplo 2: Análise com Copybooks

```bash
# Comando
python3.11 main.py examples/LHAN0542_TESTE.cbl -b examples/BOOKS.txt -o meus_resultados/

# Resultado
🔍 Detectado programa COBOL: examples/LHAN0542_TESTE.cbl
📚 Copybooks encontrados: 11 copybooks carregados
⚙️ Análise individual iniciada...
✅ Análise concluída com sucesso!
📄 Relatório: meus_resultados/LHAN0542_TESTE_MULTI_AI_ANALYSIS.md
```

### Exemplo 3: Processamento em Lote

```bash
# Comando
python3.11 main.py examples/fontes.txt -b examples/BOOKS.txt -o lote_completo/ -m enhanced

# Resultado
🔍 Detectado arquivo fontes.txt: examples/fontes.txt
📁 Processamento em lote iniciado...
📚 Copybooks encontrados: 11 copybooks carregados
🎉 Processamento em lote concluído!
📈 5/5 programas processados com sucesso
⏱️ Tempo total: 45.2s
📁 Resultados salvos em: lote_completo/
```

### Exemplo 4: Modo Enhanced com Captura de Prompts

```bash
# Comando
python3.11 main.py examples/LHAN0542_TESTE.cbl -m enhanced -o enhanced_results/

# Resultado
🔍 Detectado programa COBOL: examples/LHAN0542_TESTE.cbl
⚙️ Análise individual iniciada...
🤖 Executando análise com LuzIA...
✅ Análise concluída com sucesso!
📄 Relatório: enhanced_results/LHAN0542_TESTE_ENHANCED_ANALYSIS.md
⏱️ Tempo total: 12.3s

# O relatório incluirá:
# - Explicação do que o programa faz
# - Regras de negócio identificadas
# - Particularidades importantes
# - Prompts enviados para LuzIA
# - Respostas originais recebidas
```

---

## ⚙️ Configuração Avançada

### 1. Configurar LuzIA (IA Principal)

```bash
# Definir credenciais
export LUZIA_CLIENT_ID="seu_client_id_aqui"
export LUZIA_CLIENT_SECRET="seu_client_secret_aqui"

# Testar conectividade
python3.11 main.py --status
```

### 2. Arquivo de Configuração (config.yaml)

```yaml
# config/config.yaml
ai:
  primary_provider: "luzia"
  
luzia:
  client_id: "${LUZIA_CLIENT_ID}"
  client_secret: "${LUZIA_CLIENT_SECRET}"
  model: "azure-gpt-4o-mini"
  temperature: 0.1
  timeout: 120

logging:
  level: "INFO"
  dir: "logs"
```

### 3. Prompts Personalizados (prompts.yaml)

```yaml
# config/prompts.yaml
analysis_prompts:
  main_analysis: |
    Analise o programa COBOL e explique:
    1. O que faz
    2. Regras importantes
    3. Particularidades
    
  business_rules: |
    Identifique as regras de negócio no código COBOL...
```

---

## 📊 Interpretando os Resultados

### Estrutura do Relatório Enhanced

```markdown
# Análise do Programa COBOL: NOME_PROGRAMA

## 🎯 O que este programa faz
[Explicação clara do objetivo]

## 📋 Regras de Negócio
[Lista das regras importantes identificadas]

## ⚠️ Particularidades e Pontos de Atenção
[Aspectos que merecem cuidado especial]

## 📁 Arquivos e Estruturas de Dados
[Arquivos processados e copybooks utilizados]

## 🔍 Detalhes da Análise com IA
[Prompts enviados e respostas originais das IAs]
```

### Códigos de Status

| Status | Significado | Ação |
|--------|-------------|------|
| ✅ Sucesso | Análise concluída | Verificar relatório gerado |
| ❌ Falha | Erro na análise | Verificar logs e configuração |
| ⚠️ Parcial | Alguns componentes falharam | Verificar conectividade |

---

## 🔍 Comandos de Diagnóstico

### Verificar Status do Sistema

```bash
# Testar conectividade com IAs
python3.11 main.py --status

# Saída esperada:
🔍 Verificando conectividade com provedores de IA...
✅ LUZIA: Conectado
   Modelo: azure-gpt-4o-mini
⚪ OPENAI: Desabilitado
```

### Executar com Debug

```bash
# Saída detalhada para diagnóstico
python3.11 main.py programa.cbl -v

# Mostra logs detalhados de cada etapa
```

### Verificar Configuração

```bash
# Verificar se arquivos de configuração existem
ls -la config/
# Deve mostrar: config.yaml, prompts.yaml
```

---

## 🚨 Solução de Problemas

### Problema: "Multi-IA não disponível"

**Causa:** Erro de importação nos módulos  
**Solução:** Sistema funciona no modo tradicional, análise básica disponível

### Problema: "Credenciais LuzIA não configuradas"

**Causa:** Variáveis de ambiente não definidas  
**Solução:**
```bash
export LUZIA_CLIENT_ID="seu_id"
export LUZIA_CLIENT_SECRET="seu_secret"
```

### Problema: "Arquivo não encontrado"

**Causa:** Caminho incorreto para arquivo de entrada  
**Solução:** Verificar se o arquivo existe e o caminho está correto

### Problema: "Erro na análise"

**Causa:** Falha na conectividade ou configuração  
**Solução:**
1. Testar com `--status`
2. Verificar logs em `logs/`
3. Usar modo `traditional` como fallback

---

## 📈 Casos de Uso Recomendados

### 1. **Documentação de Sistema Legado**
```bash
# Processar todos os programas de um sistema
python3.11 main.py sistema_fontes.txt -b sistema_books.txt -o documentacao_sistema/ -m enhanced
```

### 2. **Auditoria de Código**
```bash
# Análise detalhada para auditoria
python3.11 main.py programa_critico.cbl -m enhanced -v
```

### 3. **Treinamento de Equipe**
```bash
# Gerar material didático
python3.11 main.py exemplos_fontes.txt -o material_treinamento/ -m enhanced
```

### 4. **Migração de Sistema**
```bash
# Entender lógica antes da migração
python3.11 main.py programas_migrar.txt -b copybooks.txt -o analise_migracao/ -m enhanced
```

---

## 📝 Resumo dos Comandos Essenciais

```bash
# Comandos básicos que sempre funcionam
python3.11 main.py --help                    # Ver ajuda
python3.11 main.py --status                  # Testar sistema
python3.11 main.py programa.cbl              # Análise simples
python3.11 main.py programa.cbl -m enhanced  # Análise completa
python3.11 main.py fontes.txt -b BOOKS.txt   # Lote com copybooks
```

---

**COBOL Analysis Engine v2.0**  
**Manual atualizado em:** 20/09/2025  
**Versão do sistema:** 2.0 - Limpa e Funcional
