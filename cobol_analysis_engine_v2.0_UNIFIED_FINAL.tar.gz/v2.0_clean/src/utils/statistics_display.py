"""
Utilitário para exibir estatísticas finais do processamento
"""

import time
from typing import Dict, Any

def display_final_statistics(stats: Dict[str, Any], output_dir: str = ""):
    """Exibe estatísticas finais no formato da imagem fornecida"""
    
    print("\\n" + "="*50)
    print("=== PROCESSAMENTO CONCLUÍDO ===")
    print(f"Programas processados: {stats.get('total_programs', 0)}")
    print(f"Copybooks processados: {stats.get('copybooks_processed', 0)}")
    print(f"Análises bem-sucedidas: {stats.get('successful_analyses', 0)}/{stats.get('total_programs', 0)}")
    print(f"Taxa de sucesso: {stats.get('success_rate', 0)}%")
    print(f"Total de tokens utilizados: {stats.get('total_tokens', 0)}")
    print(f"Tempo de processamento: {stats.get('total_time', 0)}s")
    
    if stats.get('retries_performed', 0) > 0:
        print(f"Tentativas de retry: {stats.get('retries_performed', 0)}")
    
    if output_dir:
        print(f"Arquivos gerados em: {output_dir}")
    
    print("="*50)

def format_statistics_for_summary(stats: Dict[str, Any]) -> str:
    """Formata estatísticas para inclusão em relatório de resumo"""
    
    return f"""
## 📊 Estatísticas de Processamento

- **Programas processados:** {stats.get('total_programs', 0)}
- **Copybooks processados:** {stats.get('copybooks_processed', 0)}
- **Análises bem-sucedidas:** {stats.get('successful_analyses', 0)}/{stats.get('total_programs', 0)}
- **Taxa de sucesso:** {stats.get('success_rate', 0)}%
- **Total de tokens utilizados:** {stats.get('total_tokens', 0)}
- **Tempo de processamento:** {stats.get('total_time', 0)}s
- **Tentativas de retry:** {stats.get('retries_performed', 0)}

---
"""
