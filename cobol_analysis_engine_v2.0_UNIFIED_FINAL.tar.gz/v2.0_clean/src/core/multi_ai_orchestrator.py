#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Sistema de Análise COBOL - Multi-análise Orchestrator
Orquestrador central para coordenação de múltiplas análises especializadas.
"""

import asyncio
import logging
import time
import json
import re
import os
import sys
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
import yaml

# Adicionar o diretório src ao sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


# Importação robusta para contornar problemas de path
try:
    # When running as part of the application
    from providers.provider_manager import ProviderManager
    from providers.base_provider import AIRequest, AIResponse
except ImportError:
    # When running as a standalone script or in a different context
    from src.providers.provider_manager import ProviderManager
    from src.providers.base_provider import AIRequest, AIResponse


@dataclass
class AnalysisResult:
    """Resultado de análise de uma análise específica."""
    ai_name: str
    domain: str
    analysis: Dict[str, Any]
    confidence: float
    execution_time: float
    tokens_used: int
    success: bool
    error_message: Optional[str] = None


@dataclass
class ValidationResult:
    """Resultado da validação cruzada."""
    consensus_scores: Dict[str, float]
    conflicts: List[Dict[str, Any]]
    resolved_conflicts: List[Dict[str, Any]]
    overall_confidence: float


class COBOLPreprocessor:
    """Pré-processador inteligente para código COBOL."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    async def preprocess(self, cobol_code: str, copybooks: List[Dict[str, Any]] = None, extracted_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Pré-processa código COBOL para análise multi-IA."""
        copybooks = copybooks or []
        extracted_data = extracted_data or {}
        
        syntax_tree = self._parse_cobol_structure(cobol_code)
        resolved_code = self._resolve_copybooks(cobol_code, copybooks)
        metadata = self._extract_metadata(syntax_tree, extracted_data)
        domain_segments = self._segment_by_domain(resolved_code, syntax_tree)
        ai_contexts = self._prepare_ai_contexts(domain_segments, metadata, resolved_code, copybooks)
        
        return {
            'original_code': cobol_code,
            'resolved_code': resolved_code,
            'syntax_tree': syntax_tree,
            'metadata': metadata,
            'domain_segments': domain_segments,
            'ai_contexts': ai_contexts,
            'copybooks': copybooks,
            'extracted_data': extracted_data
        }
    
    def _parse_cobol_structure(self, code: str) -> Dict[str, Any]:
        structure = {
            'divisions': {},
            'sections': {},
            'paragraphs': {},
            'data_items': {},
            'file_definitions': {}
        }
        
        lines = code.split('\n')
        current_division = None
        current_section = None
        
        for i, line in enumerate(lines):
            line = line.strip()
            if 'DIVISION' in line.upper():
                if 'IDENTIFICATION' in line.upper():
                    current_division = 'identification'
                elif 'ENVIRONMENT' in line.upper():
                    current_division = 'environment'
                elif 'DATA' in line.upper():
                    current_division = 'data'
                elif 'PROCEDURE' in line.upper():
                    current_division = 'procedure'
                
                if current_division:
                    structure['divisions'][current_division] = {'start_line': i, 'content': []}
            
            if current_division and 'SECTION' in line.upper():
                section_name = line.replace('SECTION.', '').strip()
                structure['sections'][section_name] = {
                    'division': current_division,
                    'start_line': i,
                    'content': []
                }
                current_section = section_name
            
            if current_division:
                structure['divisions'][current_division]['content'].append(line)
            
            if current_section:
                structure['sections'][current_section]['content'].append(line)
        
        return structure
    
    def _resolve_copybooks(self, code: str, copybooks: List[Dict[str, Any]]) -> str:
        """Resolve referências de copybooks no código."""
        resolved_code = code
        
        for copybook in copybooks:
            copybook_name = copybook.get('name', '')
            copybook_content = copybook.get('code', '')
            
            # Substituir referências COPY
            copy_pattern = rf'COPY\s+{re.escape(copybook_name)}'
            if re.search(copy_pattern, resolved_code, re.IGNORECASE):
                resolved_code = re.sub(
                    copy_pattern,
                    f'* COPYBOOK {copybook_name} EXPANDIDO:\n{copybook_content}\n* FIM COPYBOOK {copybook_name}',
                    resolved_code,
                    flags=re.IGNORECASE
                )
        
        return resolved_code
    
    def _extract_metadata(self, syntax_tree: Dict[str, Any], extracted_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Extrai metadados do código COBOL."""
        extracted_data = extracted_data or {}
        
        metadata = {
            'complexity_score': self._calculate_complexity(syntax_tree),
            'divisions_present': list(syntax_tree['divisions'].keys()),
            'sections_count': len(syntax_tree['sections']),
            'estimated_lines': sum(len(div['content']) for div in syntax_tree['divisions'].values()),
            'business_rules': extracted_data.get('business_rules', []),
            'technical_info': extracted_data.get('technical_info', {}),
            'copybooks_info': extracted_data.get('copybooks', [])
        }
        
        return metadata
    
    def _calculate_complexity(self, syntax_tree: Dict[str, Any]) -> int:
        """Calcula score de complexidade do código."""
        score = 0
        score += len(syntax_tree['divisions']) * 10
        score += len(syntax_tree['sections']) * 5
        score += len(syntax_tree['paragraphs']) * 2
        return min(score, 100)
    
    def _segment_by_domain(self, code: str, syntax_tree: Dict[str, Any]) -> Dict[str, str]:
        """Segmenta código por domínio de análise."""
        segments = {
            'structural': self._extract_structural_elements(code, syntax_tree),
            'business': self._extract_business_elements(code),
            'technical': self._extract_technical_elements(code),
            'data_model': self._extract_data_elements(code, syntax_tree),
            'quality': code  # Análise de qualidade precisa do código completo
        }
        
        return segments
    
    def _extract_structural_elements(self, code: str, syntax_tree: Dict[str, Any]) -> str:
        """Extrai elementos estruturais do código."""
        structural_lines = []
        
        for line in code.split('\n'):
            if any(keyword in line.upper() for keyword in 
                  ['DIVISION', 'SECTION', 'PROGRAM-ID', 'FD ', 'SELECT', '01 ']):
                structural_lines.append(line)
        
        return '\n'.join(structural_lines)
    
    def _extract_business_elements(self, code: str) -> str:
        """Extrai elementos de negócio do código."""
        business_lines = []
        
        for line in code.split('\n'):
            if any(keyword in line.upper() for keyword in 
                  ['OBJETIVO', 'REMARKS', 'PERFORM', 'IF ', 'EVALUATE', 'WHEN']):
                business_lines.append(line)
        
        return '\n'.join(business_lines)
    
    def _extract_technical_elements(self, code: str) -> str:
        """Extrai elementos técnicos do código."""
        technical_lines = []
        
        for line in code.split('\n'):
            if any(keyword in line.upper() for keyword in 
                  ['CALL', 'OPEN', 'CLOSE', 'READ', 'WRITE', 'MOVE', 'ADD']):
                technical_lines.append(line)
        
        return '\n'.join(technical_lines)
    
    def _extract_data_elements(self, code: str, syntax_tree: Dict[str, Any]) -> str:
        """Extrai elementos de dados do código."""
        data_lines = []
        
        for line in code.split('\n'):
            if any(keyword in line.upper() for keyword in 
                  ['PIC ', 'VALUE', 'OCCURS', 'REDEFINES', 'COMP']):
                data_lines.append(line)
        
        return '\n'.join(data_lines)
    
    def _prepare_ai_contexts(self, segments: Dict[str, str], metadata: Dict[str, Any], 
                           full_code: str, copybooks: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """Prepara contextos específicos para cada IA."""
        
        # Preparar informações de copybooks para contexto
        copybooks_context = ""
        if copybooks:
            copybooks_context = "\n\n### Copybooks Relacionados:\n"
            # Tratar copybooks como lista de dicionários ou strings
            for cb in copybooks[:3]:  # Limitar a 3 copybooks para não sobrecarregar
                if isinstance(cb, dict):
                    copybooks_context += f"**{cb.get('name', 'Unknown')}**: {cb.get('description', 'Copybook de dados')}\n"
                elif isinstance(cb, str):
                    copybooks_context += f"**{cb}**: Copybook de dados\n"
                else:
                    copybooks_context += f"**Copybook**: {str(cb)}\n"
        
        contexts = {
            'structural': {
                'code_segment': segments['structural'],
                'full_code': full_code,
                'focus': 'Análise da estrutura e organização do programa COBOL',
                'metadata': metadata,
                'copybooks_context': copybooks_context
            },
            'business': {
                'code_segment': segments['business'],
                'full_code': full_code,
                'focus': 'Análise das regras de negócio e lógica funcional',
                'metadata': metadata,
                'business_rules': metadata.get('business_rules', []),
                'copybooks_context': copybooks_context
            },
            'technical': {
                'code_segment': segments['technical'],
                'full_code': full_code,
                'focus': 'Análise técnica de implementação e performance',
                'metadata': metadata,
                'copybooks_context': copybooks_context
            },
            'data_model': {
                'code_segment': segments['data_model'],
                'full_code': full_code,
                'focus': 'Análise do modelo de dados e fluxo de informações',
                'metadata': metadata,
                'copybooks_context': copybooks_context
            },
            'quality': {
                'code_segment': full_code,
                'full_code': full_code,
                'focus': 'Análise de qualidade, padrões e melhores práticas',
                'metadata': metadata,
                'copybooks_context': copybooks_context
            }
        }
        
        return contexts


class ParallelAnalysisCoordinator:
    """Coordenador de análises paralelas especializadas."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.provider_manager = ProviderManager(config)
        
        # Configurar análises especializadas
        self.specialized_ais = config.get('ai', {}).get('specialized_ais', {})
        
        # Prompts especializados para cada domínio
        self.prompts = {
            'structural': """
Analise a estrutura do programa COBOL fornecido. Foque em:

1. **Organização das Divisões**: Identifique e avalie a presença e organização das divisões COBOL
2. **Estrutura de Seções**: Analise as seções dentro de cada divisão
3. **Hierarquia de Dados**: Examine a organização dos dados e arquivos
4. **Modularização**: Avalie a divisão em parágrafos e seções
5. **Padrões Estruturais**: Identifique padrões e convenções seguidas

{copybooks_context}

**Código para análise:**
```cobol
{code}
```

Forneça uma análise estrutural detalhada em formato JSON com as chaves:
- structure_mapping: Mapeamento completo da estrutura
- organization_score: Pontuação da organização (0-100)
- recommendations: Lista de recomendações estruturais
- summary: Resumo da análise estrutural
""",
            
            'business': """
Analise as regras de negócio e lógica funcional do programa COBOL. Foque em:

1. **Objetivo do Programa**: Identifique o propósito principal
2. **Regras de Negócio**: Extraia regras e validações implementadas
3. **Fluxo Funcional**: Mapeie o fluxo de processamento
4. **Validações**: Identifique controles e validações
5. **Processamento**: Analise a lógica de processamento

{copybooks_context}

**Código para análise:**
```cobol
{code}
```

Forneça uma análise de negócio detalhada em formato JSON com as chaves:
- business_objective: Objetivo principal do programa
- business_rules: Lista de regras identificadas
- process_flow: Fluxo de processamento
- validations: Validações implementadas
- summary: Resumo da análise de negócio
""",
            
            'technical': """
Analise os aspectos técnicos de implementação do programa COBOL. Foque em:

1. **Implementação Técnica**: Avalie a qualidade da implementação
2. **Performance**: Identifique aspectos de performance
3. **Tratamento de Erros**: Analise o tratamento de exceções
4. **Operações de I/O**: Examine operações de entrada e saída
5. **Eficiência**: Avalie a eficiência do código

{copybooks_context}

**Código para análise:**
```cobol
{code}
```

Forneça uma análise técnica detalhada em formato JSON com as chaves:
- implementation_quality: Qualidade da implementação
- performance_aspects: Aspectos de performance
- error_handling: Tratamento de erros
- io_operations: Operações de I/O
- summary: Resumo da análise técnica
""",
            
            'data_model': """
Analise o modelo de dados e fluxo de informações do programa COBOL. Foque em:

1. **Estruturas de Dados**: Analise as definições de dados
2. **Arquivos**: Examine os arquivos utilizados
3. **Fluxo de Dados**: Mapeie o fluxo de informações
4. **Relacionamentos**: Identifique relacionamentos entre dados
5. **Integridade**: Avalie controles de integridade

{copybooks_context}

**Código para análise:**
```cobol
{code}
```

Forneça uma análise de modelo de dados detalhada em formato JSON com as chaves:
- data_structures: Estruturas de dados identificadas
- file_definitions: Definições de arquivos
- data_flow: Fluxo de dados
- relationships: Relacionamentos identificados
- summary: Resumo da análise de dados
""",
            
            'quality': """
Analise a qualidade, padrões e melhores práticas do programa COBOL. Foque em:

1. **Qualidade do Código**: Avalie a qualidade geral
2. **Padrões**: Verifique aderência a padrões
3. **Manutenibilidade**: Analise facilidade de manutenção
4. **Documentação**: Avalie a documentação interna
5. **Melhores Práticas**: Identifique oportunidades de melhoria

{copybooks_context}

**Código para análise:**
```cobol
{code}
```

Forneça uma análise de qualidade detalhada em formato JSON com as chaves:
- quality_score: Pontuação de qualidade (0-100)
- standards_compliance: Aderência a padrões
- maintainability: Facilidade de manutenção
- documentation_quality: Qualidade da documentação
- improvement_opportunities: Oportunidades de melhoria
- summary: Resumo da análise de qualidade
""",
            
            'internal_review': """
Realize uma revisão interna abrangente do código COBOL. Extraia os trechos mais relevantes e importantes:

1. **Trechos Principais**: Identifique as partes mais importantes do código
2. **Lógica Central**: Extraia a lógica principal de processamento
3. **Estruturas Críticas**: Identifique estruturas críticas
4. **Pontos de Atenção**: Marque pontos que requerem atenção
5. **Resumo Executivo**: Forneça um resumo executivo

{copybooks_context}

**Código para análise:**
```cobol
{code}
```

Forneça uma revisão interna em formato JSON com as chaves:
- raw_content: Trechos de código mais relevantes com explicações
- summary: Resumo executivo da revisão
- recommendations: Recomendações principais
- score: Pontuação geral (0-10)
- confidence: Nível de confiança da análise (0-1)
"""
        }
    
    async def execute_parallel_analysis(self, preprocessed_data: Dict[str, Any]) -> Dict[str, AnalysisResult]:
        """Executa análises paralelas especializadas."""
        ai_contexts = preprocessed_data['ai_contexts']
        
        # Criar tasks para execução paralela
        tasks = []
        for domain, ai_config in self.specialized_ais.items():
            if domain in ai_contexts:
                task = self._analyze_domain(domain, ai_config, ai_contexts[domain])
                tasks.append(task)
        
        # Executar análises em paralelo
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Processar resultados
        parallel_results = {}
        for i, (domain, _) in enumerate(self.specialized_ais.items()):
            if i < len(results):
                result = results[i]
                if isinstance(result, Exception):
                    self.logger.error(f"Erro na análise {domain}: {result}")
                    parallel_results[domain] = AnalysisResult(
                        ai_name=domain,
                        domain=domain,
                        analysis={},
                        confidence=0.0,
                        execution_time=0.0,
                        tokens_used=0,
                        success=False,
                        error_message=str(result)
                    )
                else:
                    parallel_results[domain] = result
        
        return parallel_results
    
    async def _analyze_domain(self, domain: str, ai_config: Dict[str, Any], context: Dict[str, Any]) -> AnalysisResult:
        """Executa análise para um domínio específico."""
        start_time = time.time()
        
        try:
            provider_name = ai_config.get('provider', 'enhanced_mock')
            
            # Preparar prompt específico do domínio
            prompt_template = self.prompts.get(domain, self.prompts['internal_review'])
            prompt = prompt_template.format(
                code=context['code_segment'],
                copybooks_context=context.get('copybooks_context', '')
            )
            
            # Criar requisição
            request = AIRequest(
                prompt=prompt,
                model=ai_config.get('model', 'default'),
                temperature=ai_config.get('temperature', 0.1),
                max_tokens=ai_config.get('max_tokens', 4000)
            )
            
            # Executar análise
            response = await self.provider_manager.analyze_with_specific_provider(provider_name, request)
            
            execution_time = time.time() - start_time
            
            if response.success:
                # Processar resposta específica do domínio
                analysis = self._process_specialized_response(domain, response.content)
                
                return AnalysisResult(
                    ai_name=domain,
                    domain=domain,
                    analysis=analysis,
                    confidence=0.8,  # Confiança padrão
                    execution_time=execution_time,
                    tokens_used=response.tokens_used,
                    success=True
                )
            else:
                return AnalysisResult(
                    ai_name=domain,
                    domain=domain,
                    analysis={},
                    confidence=0.0,
                    execution_time=execution_time,
                    tokens_used=0,
                    success=False,
                    error_message=f"Falha na análise com {provider_name}: {response.error_message}"
                )
                
        except Exception as e:
            execution_time = time.time() - start_time
            self.logger.error(f"Erro na análise {domain}: {e}")
            
            return AnalysisResult(
                ai_name=domain,
                domain=domain,
                analysis={},
                confidence=0.0,
                execution_time=execution_time,
                tokens_used=0,
                success=False,
                error_message=str(e)
            )
    
    def _process_specialized_response(self, domain: str, response_content: str) -> Dict[str, Any]:
        """Processa resposta específica de cada domínio."""
        
        # Tentar extrair JSON da resposta
        try:
            # Procurar por JSON na resposta
            json_match = re.search(r'\{.*\}', response_content, re.DOTALL)
            if json_match:
                json_str = json_match.group(0)
                parsed_json = json.loads(json_str)
                return parsed_json
        except (json.JSONDecodeError, AttributeError):
            pass
        
        # Fallback: estruturar resposta baseada no domínio
        if domain == 'structural':
            return {
                'structure_mapping': response_content,
                'organization_score': 75,
                'recommendations': [],
                'summary': response_content[:500] + '...' if len(response_content) > 500 else response_content
            }
        elif domain == 'business':
            return {
                'business_objective': 'Análise de regras de negócio',
                'business_rules': [],
                'process_flow': response_content,
                'validations': [],
                'summary': response_content[:500] + '...' if len(response_content) > 500 else response_content
            }
        elif domain == 'technical':
            return {
                'implementation_quality': 'Boa',
                'performance_aspects': [],
                'error_handling': 'Adequado',
                'io_operations': [],
                'summary': response_content[:500] + '...' if len(response_content) > 500 else response_content
            }
        elif domain == 'data_model':
            return {
                'data_structures': [],
                'file_definitions': [],
                'data_flow': response_content,
                'relationships': [],
                'summary': response_content[:500] + '...' if len(response_content) > 500 else response_content
            }
        elif domain == 'quality':
            return {
                'quality_score': 80,
                'standards_compliance': 'Boa',
                'maintainability': 'Adequada',
                'documentation_quality': 'Suficiente',
                'improvement_opportunities': [],
                'summary': response_content[:500] + '...' if len(response_content) > 500 else response_content
            }
        else:  # internal_review
            return {
                'raw_content': response_content,
                'summary': '',
                'recommendations': [],
                'score': 0,
                'confidence': 0.8
            }


class MultiAIOrchestrator:
    """Orquestrador principal para análise multi-IA."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.preprocessor = COBOLPreprocessor()
        self.parallel_coordinator = ParallelAnalysisCoordinator(config)
        self.logger.info("Multi-análise Orchestrator inicializado com sucesso")
    
    async def analyze_program(self, cobol_code: str, copybooks: List[Dict[str, Any]] = None, program_name: str = None, extracted_data: Dict[str, Any] = None) -> Dict[str, Any]:
        """Executa análise multi-IA completa de um programa COBOL."""
        start_time = time.time()
        self.logger.info(f"Iniciando análise multi-análise do programa {program_name}")
        
        try:
            # Fase 1: Pré-processamento
            self.logger.info("Fase 1: Pré-processamento inteligente")
            preprocessed_data = await self.preprocessor.preprocess(cobol_code, copybooks, extracted_data)
            
            # Fase 2: Análise Paralela
            self.logger.info(f"Fase 2: Análise paralela com {len(self.parallel_coordinator.specialized_ais)} análises especializadas")
            parallel_results = await self.parallel_coordinator.execute_parallel_analysis(preprocessed_data)
            
            # Fase 3: Síntese
            self.logger.info("Fase 3: Síntese dos resultados")
            final_documentation = self._synthesize_results(parallel_results, preprocessed_data)
            
            execution_time = time.time() - start_time
            self.logger.info(f"Análise multi-análise concluída com sucesso em {execution_time:.2f}s")
            
            return {
                'success': True,
                'program_name': program_name,
                'execution_time': execution_time,
                'preprocessed_data': preprocessed_data,
                'parallel_results': parallel_results,
                'documentation': final_documentation,
                'metadata': {
                    'total_tokens': sum(r.tokens_used for r in parallel_results.values() if r.success),
                    'successful_analyses': sum(1 for r in parallel_results.values() if r.success),
                    'total_analyses': len(parallel_results)
                }
            }
            
        except Exception as e:
            execution_time = time.time() - start_time
            self.logger.error(f"Erro na análise multi-análise: {e}")
            
            return {
                'success': False,
                'program_name': program_name,
                'execution_time': execution_time,
                'error': str(e),
                'parallel_results': {},
                'documentation': {'detailed_results': {}}
            }
    
    def _synthesize_results(self, parallel_results: Dict[str, AnalysisResult], preprocessed_data: Dict[str, Any]) -> Dict[str, Any]:
        """Sintetiza resultados das análises paralelas."""
        
        detailed_results = {}
        summary_insights = []
        overall_confidence = 0.0
        successful_analyses = 0
        
        for domain, result in parallel_results.items():
            if result.success:
                detailed_results[domain] = result.analysis
                summary_insights.append(f"**{domain.title()}**: {result.analysis.get('summary', 'Análise concluída')}")
                overall_confidence += result.confidence
                successful_analyses += 1
            else:
                detailed_results[domain] = {'error': result.error_message}
                summary_insights.append(f"**{domain.title()}**: Análise falhou - {result.error_message}")
        
        if successful_analyses > 0:
            overall_confidence /= successful_analyses
        
        return {
            'detailed_results': detailed_results,
            'summary_insights': summary_insights,
            'overall_confidence': overall_confidence,
            'successful_analyses': successful_analyses,
            'total_analyses': len(parallel_results),
            'metadata': preprocessed_data.get('metadata', {})
        }
