"""
Analisador Direto de IA - COBOL Analysis Engine v2.0
Versão simplificada que funciona diretamente com LuzIA
"""

import asyncio
import logging
import time
import os
import requests
import httpx
from typing import Dict, Any, List, Optional
from datetime import datetime

class DirectAIAnalyzer:
    """Analisador direto que se conecta ao LuzIA e captura prompts/respostas"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.prompt_history = []
        
        # Configuração LuzIA
        self.client_id = os.getenv("LUZIA_CLIENT_ID")
        self.client_secret = os.getenv("LUZIA_CLIENT_SECRET")
        self.sso_endpoint = "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token"
        self.base_url = "https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/"
        self.model = "azure-gpt-4o-mini"
    
    async def analyze_cobol_program(self, 
                                  program_name: str,
                                  cobol_code: str,
                                  copybooks: Optional[Dict] = None) -> Dict[str, Any]:
        """Analisa programa COBOL com LuzIA e captura prompts/respostas"""
        
        self.logger.info(f"Iniciando análise direta de {program_name}")
        
        # Limpar histórico anterior
        self.prompt_history.clear()
        
        # Criar prompt principal
        copybooks_info = self._format_copybooks_info(copybooks) if copybooks else "Nenhum copybook disponível"
        main_prompt = self._create_main_analysis_prompt(program_name, cobol_code, copybooks_info)
        
        # Executar análise
        analysis_result = await self._execute_luzia_analysis(main_prompt)
        
        return {
            'analysis_result': analysis_result,
            'prompt_history': self.prompt_history.copy(),
            'summary': self._get_summary()
        }
    
    async def _execute_luzia_analysis(self, prompt: str) -> Dict[str, Any]:
        """Executa análise com LuzIA"""
        
        try:
            # Obter token
            token = await self._get_token()
            if not token:
                self._log_interaction("LUZIA", "Análise Principal", prompt, "Erro: Falha na autenticação", False)
                return {'success': False, 'error': 'Falha na autenticação'}
            
            # Preparar requisição
            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": self.model,
                "messages": self._format_luzia_query(prompt),
                "temperature": 0.1,
                "max_tokens": 2000
            }
            
            # Executar requisição
            start_time = time.time()
            
            async with httpx.AsyncClient(verify=False, timeout=120.0) as client:
                response = await client.post(
                    f"{self.base_url}chat/completions",
                    headers=headers,
                    json=payload
                )
                
                execution_time = time.time() - start_time
                
                if response.status_code == 200:
                    result = response.json()
                    content = result.get('choices', [{}])[0].get('message', {}).get('content', '')
                    tokens_used = result.get('usage', {}).get('total_tokens', 0)
                    
                    # Registrar interação bem-sucedida
                    self._log_interaction("LUZIA", "Análise Principal", prompt, content, True, execution_time, tokens_used)
                    
                    return {
                        'success': True,
                        'content': content,
                        'provider': 'luzia',
                        'model': self.model,
                        'tokens_used': tokens_used,
                        'execution_time': execution_time
                    }
                else:
                    error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                    self._log_interaction("LUZIA", "Análise Principal", prompt, error_msg, False, execution_time)
                    
                    return {
                        'success': False,
                        'error': error_msg,
                        'provider': 'luzia'
                    }
                    
        except Exception as e:
            error_msg = f"Erro na análise: {str(e)}"
            self._log_interaction("LUZIA", "Análise Principal", prompt, error_msg, False)
            
            return {
                'success': False,
                'error': error_msg,
                'provider': 'luzia'
            }
    
    async def _get_token(self) -> Optional[str]:
        """Obtém token de autenticação do LuzIA"""
        
        if not self.client_id or not self.client_secret:
            self.logger.error("Credenciais LuzIA não configuradas")
            return None
        
        try:
            payload = {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret
            }
            
            async with httpx.AsyncClient(verify=False, timeout=30.0) as client:
                response = await client.post(self.sso_endpoint, data=payload)
                
                if response.status_code == 200:
                    token_data = response.json()
                    return token_data.get("access_token")
                else:
                    self.logger.error(f"Erro na autenticação: {response.status_code}")
                    return None
                    
        except Exception as e:
            self.logger.error(f"Erro ao obter token: {str(e)}")
            return None
    
    def _format_luzia_query(self, prompt: str) -> List[Dict]:
        """Formata query para LuzIA"""
        
        system_prompt = """Você é um especialista em análise de código COBOL.
Responda em português do Brasil.
Seja objetivo e claro na explicação.
Foque no que é importante para entender o programa."""
        
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ]
    
    def _create_main_analysis_prompt(self, program_name: str, cobol_code: str, copybooks_info: str) -> str:
        """Cria prompt principal para análise"""
        
        prompt = f"""Analise o programa COBOL abaixo e explique de forma clara e objetiva:

**Nome do Programa:** {program_name}

**Instruções:**
1. O QUE este programa faz (objetivo principal)
2. QUAIS são as regras de negócio importantes (validações, critérios, limites)
3. SE HÁ particularidades ou pontos que merecem atenção especial

**Código COBOL:**
```cobol
{cobol_code[:3000]}{"..." if len(cobol_code) > 3000 else ""}
```

**Copybooks disponíveis:**
{copybooks_info}

**Formato da resposta:**
- Use linguagem simples e direta
- Seja objetivo mas completo
- Foque no que é importante para entender o programa
- Evite jargões técnicos desnecessários
- Explique regras de negócio em linguagem clara"""

        return prompt
    
    def _format_copybooks_info(self, copybooks: Dict[str, str]) -> str:
        """Formata informações dos copybooks"""
        
        if not copybooks:
            return "Nenhum copybook disponível"
        
        info = []
        for name, content in copybooks.items():
            lines = content.split('\n')
            field_count = sum(1 for line in lines if any(level in line.strip() for level in ['01 ', '05 ', '10 ', '15 ', '20 ']))
            info.append(f"- **{name}**: {field_count} campos definidos")
        
        return '\n'.join(info)
    
    def _log_interaction(self, provider: str, prompt_type: str, prompt: str, response: str, 
                        success: bool, execution_time: float = 0.0, tokens_used: int = 0):
        """Registra interação com IA"""
        
        interaction = {
            "timestamp": datetime.now().isoformat(),
            "provider": provider,
            "prompt_type": prompt_type,
            "prompt": prompt,
            "response": response,
            "success": success,
            "execution_time": execution_time,
            "tokens_used": tokens_used,
            "model": self.model,
            "interaction_id": len(self.prompt_history) + 1
        }
        
        self.prompt_history.append(interaction)
    
    def _get_summary(self) -> Dict[str, Any]:
        """Retorna resumo das interações"""
        
        total = len(self.prompt_history)
        successful = len([i for i in self.prompt_history if i.get('success', False)])
        
        return {
            "total_interactions": total,
            "successful_interactions": successful,
            "success_rate": successful / total if total > 0 else 0,
            "total_tokens_used": sum(i.get('tokens_used', 0) for i in self.prompt_history),
            "total_execution_time": sum(i.get('execution_time', 0) for i in self.prompt_history)
        }
