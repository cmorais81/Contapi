"""
Analisador unificado que combina análise estrutural, business e técnica
com sistema de retry e estatísticas detalhadas
"""

import asyncio
import time
import re
from typing import Dict, Any, List, Optional
from .smart_prompt_splitter import SmartPromptSplitter
from ..providers.luzia_provider import LuziaProvider
from ..providers.provider_manager import ProviderManager

class UnifiedAnalyzer:
    """Analisador unificado com retry e estatísticas completas"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.splitter = SmartPromptSplitter(max_tokens_per_prompt=6000)  # Aumentado para análise unificada
        self.provider_manager = ProviderManager(config)
        
        # Estatísticas globais
        self.stats = {
            'total_programs': 0,
            'successful_analyses': 0,
            'failed_analyses': 0,
            'total_tokens': 0,
            'total_time': 0.0,
            'copybooks_processed': 0,
            'retries_performed': 0
        }
        
        # Configurações de retry
        self.max_retries = 3
        self.retry_delay = 2.0  # segundos
        self.timeout_per_request = 60.0  # segundos
        
        # Histórico de prompts
        self.prompt_history = []
    
    async def analyze_cobol_program_unified(
        self, 
        program_name: str, 
        cobol_code: str, 
        copybooks: Dict = None
    ) -> Dict[str, Any]:
        """Analisa programa COBOL com análise unificada (estrutural + business + técnica)"""
        
        start_time = time.time()
        self.stats['total_programs'] += 1
        
        if copybooks:
            self.stats['copybooks_processed'] += len(copybooks)
        
        try:
            # 1. Extrair comentários e informações do código
            comments = self.splitter.extract_cobol_comments(cobol_code)
            
            # 2. Criar prompt unificado
            unified_prompt = self._create_unified_prompt(
                program_name, cobol_code, comments, copybooks
            )
            
            # 3. Verificar se precisa dividir o prompt
            if self._estimate_tokens(unified_prompt) > 6000:
                # Dividir em múltiplos prompts
                analysis_result = await self._analyze_with_multiple_prompts(
                    program_name, cobol_code, comments, copybooks
                )
            else:
                # Usar prompt único
                analysis_result = await self._analyze_with_single_prompt(
                    program_name, unified_prompt
                )
            
            # 4. Calcular estatísticas
            processing_time = time.time() - start_time
            self.stats['total_time'] += processing_time
            
            if analysis_result.get('success', False):
                self.stats['successful_analyses'] += 1
            else:
                self.stats['failed_analyses'] += 1
            
            # 5. Preparar resultado final
            return {
                'analysis_result': analysis_result.get('content', {}),
                'prompt_history': self.prompt_history,
                'processing_time': processing_time,
                'success': analysis_result.get('success', False),
                'tokens_used': analysis_result.get('tokens_used', 0),
                'retries_performed': analysis_result.get('retries_performed', 0)
            }
            
        except Exception as e:
            processing_time = time.time() - start_time
            self.stats['total_time'] += processing_time
            self.stats['failed_analyses'] += 1
            
            return {
                'analysis_result': self._create_fallback_analysis(program_name, str(e)),
                'prompt_history': self.prompt_history,
                'processing_time': processing_time,
                'success': False,
                'tokens_used': 0,
                'retries_performed': 0,
                'error': str(e)
            }
    
    def _create_unified_prompt(
        self, 
        program_name: str, 
        cobol_code: str, 
        comments: Dict[str, List[str]], 
        copybooks: Dict = None
    ) -> str:
        """Cria prompt unificado combinando análise estrutural, business e técnica"""
        
        # Informações dos copybooks
        copybook_info = ""
        if copybooks:
            copybook_info = "\\n\\nCOPYBOOKS DISPONÍVEIS:\\n"
            for name, info in list(copybooks.items())[:8]:  # Limitar a 8 copybooks
                copybook_info += f"- {name}: {info.get('description', 'Layout de dados')}\\n"
        
        # Comentários formatados
        comments_section = ""
        if any(comments.values()):
            comments_section = "\\n\\nCOMENTÁRIOS DO PROGRAMA:\\n"
            
            if comments['objective']:
                comments_section += "OBJETIVO:\\n"
                for comment in comments['objective'][:3]:  # Limitar a 3 comentários
                    comments_section += f"- {comment}\\n"
            
            if comments['business_rules']:
                comments_section += "\\nREGRAS DE NEGÓCIO:\\n"
                for comment in comments['business_rules'][:5]:  # Limitar a 5 regras
                    comments_section += f"- {comment}\\n"
            
            if comments['technical_notes']:
                comments_section += "\\nNOTAS TÉCNICAS:\\n"
                for comment in comments['technical_notes'][:3]:  # Limitar a 3 notas
                    comments_section += f"- {comment}\\n"
        
        # Código COBOL (truncado se muito grande)
        code_section = cobol_code
        if len(cobol_code) > 3000:
            code_section = cobol_code[:3000] + "\\n... [código truncado] ..."
        
        return f"""Analise o programa COBOL abaixo de forma COMPLETA e UNIFICADA:

**PROGRAMA:** {program_name}
{comments_section}
{copybook_info}

**CÓDIGO COBOL:**
```cobol
{code_section}
```

Faça uma análise COMPLETA e UNIFICADA respondendo:

## 🎯 OBJETIVO E FUNCIONALIDADE
- O que este programa faz (objetivo principal)
- Qual o fluxo de processamento
- Qual o contexto de negócio

## 📋 REGRAS DE NEGÓCIO
- Quais são as principais regras implementadas
- Validações críticas identificadas
- Condições especiais de processamento

## 🔧 ANÁLISE TÉCNICA
- Estruturas de dados principais
- Arquivos de entrada e saída
- Campos de controle e contadores
- Operações técnicas realizadas

## ⚠️ PARTICULARIDADES
- Pontos de atenção especiais
- Complexidades identificadas
- Aspectos únicos do programa

## 📊 ESTRUTURAS DE DADOS
- Principais campos do Working Storage
- Definições de arquivo importantes
- Relacionamentos entre dados

Seja DETALHADO, PRECISO e OBJETIVO. Foque no que é IMPORTANTE para entender o programa."""
    
    async def _analyze_with_single_prompt(self, program_name: str, prompt: str) -> Dict[str, Any]:
        """Executa análise com prompt único usando sistema de retry"""
        
        for attempt in range(self.max_retries + 1):
            try:
                # Registrar prompt
                prompt_entry = {
                    'program': program_name,
                    'prompt': prompt,
                    'timestamp': time.time(),
                    'attempt': attempt + 1,
                    'provider': 'LUZIA',
                    'type': 'unified_analysis'
                }
                
                # Tentar análise com timeout
                response = await asyncio.wait_for(
                    self._execute_analysis(prompt),
                    timeout=self.timeout_per_request
                )
                
                if response and response.get('success'):
                    # Sucesso - registrar e retornar
                    prompt_entry.update({
                        'response': response.get('content', ''),
                        'success': True,
                        'tokens_used': response.get('tokens_used', 0),
                        'processing_time': response.get('processing_time', 0)
                    })
                    
                    self.prompt_history.append(prompt_entry)
                    self.stats['total_tokens'] += response.get('tokens_used', 0)
                    
                    # Parsear resposta unificada
                    parsed_content = self._parse_unified_response(response.get('content', ''))
                    
                    return {
                        'success': True,
                        'content': parsed_content,
                        'tokens_used': response.get('tokens_used', 0),
                        'processing_time': response.get('processing_time', 0),
                        'retries_performed': attempt
                    }
                
                # Falha - tentar novamente se não for última tentativa
                if attempt < self.max_retries:
                    self.stats['retries_performed'] += 1
                    prompt_entry.update({
                        'response': f'Tentativa {attempt + 1} falhou - tentando novamente',
                        'success': False,
                        'error': response.get('error', 'Resposta inválida')
                    })
                    self.prompt_history.append(prompt_entry)
                    
                    await asyncio.sleep(self.retry_delay * (attempt + 1))  # Backoff exponencial
                    continue
                
                # Última tentativa falhou
                prompt_entry.update({
                    'response': f'Falha após {self.max_retries + 1} tentativas',
                    'success': False,
                    'error': response.get('error', 'Análise não disponível')
                })
                self.prompt_history.append(prompt_entry)
                
                return {
                    'success': False,
                    'content': self._create_fallback_analysis(program_name, 'Análise IA indisponível'),
                    'tokens_used': 0,
                    'processing_time': 0,
                    'retries_performed': attempt,
                    'error': 'Máximo de tentativas excedido'
                }
                
            except asyncio.TimeoutError:
                if attempt < self.max_retries:
                    self.stats['retries_performed'] += 1
                    await asyncio.sleep(self.retry_delay * (attempt + 1))
                    continue
                
                return {
                    'success': False,
                    'content': self._create_fallback_analysis(program_name, 'Timeout na análise'),
                    'tokens_used': 0,
                    'processing_time': 0,
                    'retries_performed': attempt,
                    'error': 'Timeout excedido'
                }
                
            except Exception as e:
                if attempt < self.max_retries:
                    self.stats['retries_performed'] += 1
                    await asyncio.sleep(self.retry_delay * (attempt + 1))
                    continue
                
                return {
                    'success': False,
                    'content': self._create_fallback_analysis(program_name, str(e)),
                    'tokens_used': 0,
                    'processing_time': 0,
                    'retries_performed': attempt,
                    'error': str(e)
                }
    
    async def _analyze_with_multiple_prompts(
        self, 
        program_name: str, 
        cobol_code: str, 
        comments: Dict[str, List[str]], 
        copybooks: Dict = None
    ) -> Dict[str, Any]:
        """Executa análise dividindo em múltiplos prompts menores"""
        
        # Dividir em seções
        sections = self.splitter.split_cobol_program(cobol_code, program_name)
        analysis_prompts = self.splitter.create_analysis_prompts(sections, copybooks)
        
        # Processar cada seção
        section_results = []
        total_tokens = 0
        total_retries = 0
        
        for prompt_data in analysis_prompts:
            result = await self._analyze_with_single_prompt(
                program_name, 
                prompt_data['prompt']
            )
            
            if result.get('success'):
                section_results.append({
                    'section_type': prompt_data['section_type'],
                    'content': result.get('content', {}),
                    'priority': prompt_data.get('priority', 999)
                })
            
            total_tokens += result.get('tokens_used', 0)
            total_retries += result.get('retries_performed', 0)
        
        # Consolidar resultados
        consolidated = self.splitter.consolidate_analysis_results(section_results)
        
        return {
            'success': len(section_results) > 0,
            'content': consolidated,
            'tokens_used': total_tokens,
            'processing_time': 0,  # Será calculado externamente
            'retries_performed': total_retries
        }
    
    async def _execute_analysis(self, prompt: str) -> Dict[str, Any]:
        """Executa análise usando o provider configurado"""
        
        try:
            provider = self.provider_manager.get_provider('luzia')
            if provider and hasattr(provider, 'analyze_async'):
                response = await provider.analyze_async(prompt)
                
                if response and response.success:
                    return {
                        'success': True,
                        'content': response.content,
                        'tokens_used': getattr(response, 'tokens_used', 0),
                        'processing_time': getattr(response, 'processing_time', 0)
                    }
                else:
                    return {
                        'success': False,
                        'content': '',
                        'error': getattr(response, 'error', 'Resposta inválida')
                    }
            
            # Fallback para análise básica
            return {
                'success': False,
                'content': '',
                'error': 'Provider não disponível'
            }
            
        except Exception as e:
            return {
                'success': False,
                'content': '',
                'error': str(e)
            }
    
    def _parse_unified_response(self, response_text: str) -> Dict[str, Any]:
        """Parseia resposta unificada da IA"""
        
        result = {
            'objective': '',
            'business_rules': [],
            'technical_analysis': [],
            'particularities': [],
            'data_structures': [],
            'processing_flow': []
        }
        
        # Dividir por seções usando regex
        sections = {
            'objective': r'🎯.*?OBJETIVO.*?(?=📋|🔧|⚠️|📊|$)',
            'business_rules': r'📋.*?REGRAS.*?(?=🔧|⚠️|📊|$)',
            'technical_analysis': r'🔧.*?TÉCNICA.*?(?=⚠️|📊|$)',
            'particularities': r'⚠️.*?PARTICULARIDADES.*?(?=📊|$)',
            'data_structures': r'📊.*?ESTRUTURAS.*?(?=$)'
        }
        
        for key, pattern in sections.items():
            match = re.search(pattern, response_text, re.DOTALL | re.IGNORECASE)
            if match:
                section_text = match.group(0)
                
                if key == 'objective':
                    # Extrair texto do objetivo
                    lines = section_text.split('\\n')
                    objective_lines = [line.strip() for line in lines if line.strip() and not line.startswith('#')]
                    result['objective'] = ' '.join(objective_lines[:3])  # Primeiras 3 linhas
                else:
                    # Extrair itens de lista
                    items = re.findall(r'^[-•*]\\s*(.+)$', section_text, re.MULTILINE)
                    result[key] = items[:10]  # Limitar a 10 itens
        
        return result
    
    def _create_fallback_analysis(self, program_name: str, error_msg: str) -> Dict[str, Any]:
        """Cria análise básica quando IA não está disponível"""
        
        return {
            'objective': f'Análise do programa {program_name} (IA indisponível: {error_msg})',
            'business_rules': ['Análise de regras requer IA funcional'],
            'technical_analysis': ['Análise técnica requer IA funcional'],
            'particularities': ['Análise de particularidades requer IA funcional'],
            'data_structures': ['Análise de estruturas requer IA funcional'],
            'processing_flow': ['Análise de fluxo requer IA funcional']
        }
    
    def _estimate_tokens(self, text: str) -> int:
        """Estima número de tokens no texto (aproximadamente 4 caracteres por token)"""
        return len(text) // 4
    
    def get_final_statistics(self) -> Dict[str, Any]:
        """Retorna estatísticas finais do processamento"""
        
        success_rate = 0.0
        if self.stats['total_programs'] > 0:
            success_rate = (self.stats['successful_analyses'] / self.stats['total_programs']) * 100
        
        return {
            'total_programs': self.stats['total_programs'],
            'successful_analyses': self.stats['successful_analyses'],
            'failed_analyses': self.stats['failed_analyses'],
            'success_rate': round(success_rate, 1),
            'total_tokens': self.stats['total_tokens'],
            'total_time': round(self.stats['total_time'], 2),
            'copybooks_processed': self.stats['copybooks_processed'],
            'retries_performed': self.stats['retries_performed']
        }
