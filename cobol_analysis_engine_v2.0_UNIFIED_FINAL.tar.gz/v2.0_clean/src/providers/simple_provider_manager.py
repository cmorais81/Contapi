#!/usr/bin/env python3.11
# -*- coding: utf-8 -*-
"""
Provider Manager simples para testes.
"""

import logging
from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class AIRequest:
    """Requisição para análise."""
    prompt: str
    temperature: float = 0.1
    max_tokens: int = 4000
    model: Optional[str] = None


@dataclass
class AIResponse:
    """Resposta da análise."""
    content: str
    success: bool
    tokens_used: int = 0
    error: Optional[str] = None


class SimpleProviderManager:
    """Provider manager simples para testes."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
    
    def analyze(self, request: AIRequest) -> AIResponse:
        """Executa análise mock."""
        
        # Resposta mock baseada no prompt
        if 'structural' in request.prompt.lower():
            content = """
            Análise Estrutural:
            - Divisões COBOL identificadas: IDENTIFICATION, ENVIRONMENT, DATA, PROCEDURE
            - Qualidade estrutural: 85/100
            - Organização adequada
            """
        elif 'business' in request.prompt.lower():
            content = """
            Análise de Negócio:
            - 5 regras de negócio identificadas
            - Complexidade: média
            - Compliance: alto
            """
        elif 'technical' in request.prompt.lower():
            content = """
            Análise Técnica:
            - Complexidade algorítmica: O(n)
            - Score de performance: 75/100
            - 3 oportunidades de otimização
            """
        else:
            content = """
            Análise de Qualidade:
            - Qualidade geral: 82/100
            - 5 problemas identificados
            - Score de manutenibilidade: 78/100
            """
        
        return AIResponse(
            content=content,
            success=True,
            tokens_used=500
        )
