"""
Sistema de Análise COBOL v2.6.0 - Pacote Principal
Sistema completo de análise de programas COBOL com análise.
"""

__version__ = "2.6.0"
__author__ = "Sistema de Análise COBOL Team"
__description__ = "Sistema de análise de programas COBOL com análise"

