"""
Enhanced RAG Integration - Versão aprimorada com suporte a análises ultra-detalhadas
"""

import logging
import os
from typing import Dict, Any, Optional
from .rag_integration import RAGIntegration

class EnhancedRAGIntegration(RAGIntegration):
    """
    Versão aprimorada da integração RAG com suporte a análises ultra-detalhadas
    """
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.session_stats = {
            'total_operations': 0,
            'programs_analyzed': [],
            'knowledge_items_used': 0,
            'new_items_added': 0,
            'analysis_types_processed': set()
        }
    
    def add_analysis_to_knowledge_base(self, analysis_id: str, 
                                     analysis_content: str, 
                                     cobol_code: str,
                                     analysis_type: str = "general") -> Optional[str]:
        """
        Adiciona análise específica à base de conhecimento RAG.
        
        Args:
            analysis_id: ID único da análise (ex: "LHAN0542_functional_analysis")
            analysis_content: Conteúdo da análise
            cobol_code: Código COBOL original
            analysis_type: Tipo de análise (functional, business_rules, validation, etc.)
            
        Returns:
            ID do item adicionado ou None se falhou
        """
        if not self.is_enabled():
            return None
        
        try:
            # Extrair nome do programa do analysis_id
            program_name = analysis_id.split('_')[0] if '_' in analysis_id else analysis_id
            
            # Extrair características do código para keywords
            code_features = self.rag_system._extract_code_features(cobol_code)
            
            # Gerar keywords baseadas no tipo de análise e características
            keywords = [program_name.lower(), analysis_type]
            
            # Keywords específicas por tipo de análise
            if analysis_type == 'functional_analysis':
                keywords.extend(['funcionalidade', 'sequencia-execucao', 'rotinas'])
            elif analysis_type == 'business_rules_analysis':
                keywords.extend(['regras-negocio', 'validacao', 'algoritmos'])
            elif analysis_type == 'validation_analysis':
                keywords.extend(['validacao', 'cpf', 'cnpj', 'tipos-informacao'])
            elif analysis_type == 'file_processing_analysis':
                keywords.extend(['arquivo', 'processamento', 'entrada-saida'])
            elif analysis_type == 'cadoc_analysis':
                keywords.extend(['cadoc', 'documento', 'tipos-documento'])
            elif analysis_type == 'error_handling_analysis':
                keywords.extend(['erro', 'tratamento', 'recuperacao'])
            
            # Keywords baseadas nas características do código
            if code_features['has_file_operations']:
                keywords.extend(['arquivo', 'file-operations'])
            if code_features['has_calculations']:
                keywords.extend(['calculo', 'matematica'])
            if code_features['banking_indicators']:
                keywords.extend(['bancario', 'financeiro'])
            
            # Identificar constructs COBOL
            cobol_constructs = []
            if code_features['has_loops']:
                cobol_constructs.append('PERFORM UNTIL')
            if code_features['has_conditionals']:
                cobol_constructs.extend(['IF', 'EVALUATE'])
            if code_features['has_file_operations']:
                cobol_constructs.extend(['READ', 'WRITE', 'OPEN', 'CLOSE'])
            
            # Determinar domínio
            domain = 'banking' if code_features['banking_indicators'] else 'general'
            
            # Determinar nível de complexidade baseado no tipo de análise
            complexity_mapping = {
                'functional_analysis': 'intermediate',
                'business_rules_analysis': 'advanced',
                'validation_analysis': 'intermediate',
                'file_processing_analysis': 'basic',
                'cadoc_analysis': 'advanced',
                'error_handling_analysis': 'intermediate'
            }
            complexity_level = complexity_mapping.get(analysis_type, 'intermediate')
            
            # Adicionar à base de conhecimento
            item_id = self.rag_system.add_knowledge_item(
                title=f"Análise {analysis_type.replace('_', ' ').title()} - {program_name}",
                content=f"Programa: {program_name}\nTipo: {analysis_type}\n\nAnálise:\n{analysis_content}",
                category="ultra_detailed_analysis",
                keywords=keywords,
                cobol_constructs=cobol_constructs,
                domain=domain,
                complexity_level=complexity_level
            )
            
            # Atualizar estatísticas da sessão
            self.session_stats['total_operations'] += 1
            if program_name not in self.session_stats['programs_analyzed']:
                self.session_stats['programs_analyzed'].append(program_name)
            self.session_stats['new_items_added'] += 1
            self.session_stats['analysis_types_processed'].add(analysis_type)
            
            self.logger.info(f"Análise {analysis_type} de {program_name} adicionada à base RAG: {item_id}")
            return item_id
            
        except Exception as e:
            self.logger.error(f"Erro ao adicionar análise {analysis_type} à base de conhecimento: {e}")
            return None
    
    def get_session_summary(self) -> Dict[str, Any]:
        """
        Retorna resumo da sessão atual de uso do RAG.
        
        Returns:
            Dicionário com estatísticas da sessão
        """
        summary = self.session_stats.copy()
        summary['analysis_types_processed'] = list(summary['analysis_types_processed'])
        return summary
    
    def finalize_session(self) -> Optional[str]:
        """
        Finaliza a sessão RAG e gera relatório de uso.
        
        Returns:
            Caminho do arquivo de relatório gerado ou None
        """
        if not self.is_enabled():
            return None
        
        try:
            # Gerar relatório da sessão
            timestamp = __import__('datetime').datetime.now().strftime('%Y%m%d_%H%M%S')
            report_file = f"logs/rag_session_report_{timestamp}.md"
            
            os.makedirs('logs', exist_ok=True)
            
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write("# Relatório de Sessão RAG\n\n")
                f.write(f"**Data**: {__import__('datetime').datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
                
                f.write("## Resumo da Sessão\n\n")
                f.write(f"- **Operações RAG realizadas**: {self.session_stats['total_operations']}\n")
                f.write(f"- **Programas analisados**: {len(self.session_stats['programs_analyzed'])}\n")
                f.write(f"- **Novos itens adicionados**: {self.session_stats['new_items_added']}\n")
                f.write(f"- **Tipos de análise processados**: {len(self.session_stats['analysis_types_processed'])}\n\n")
                
                f.write("## Programas Analisados\n\n")
                for program in self.session_stats['programs_analyzed']:
                    f.write(f"- {program}\n")
                
                f.write("\n## Tipos de Análise Processados\n\n")
                for analysis_type in self.session_stats['analysis_types_processed']:
                    f.write(f"- {analysis_type.replace('_', ' ').title()}\n")
                
                # Estatísticas da base de conhecimento
                rag_stats = self.get_rag_statistics()
                f.write("\n## Estatísticas da Base de Conhecimento\n\n")
                f.write(f"- **Total de itens**: {rag_stats.get('total_items', 0)}\n")
                f.write(f"- **Categorias**: {rag_stats.get('categories', 0)}\n")
                f.write(f"- **Domínios**: {rag_stats.get('domains', 0)}\n")
            
            self.logger.info(f"Relatório de sessão RAG gerado: {report_file}")
            return report_file
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório de sessão RAG: {e}")
            return None
    
    def enhance_ultra_detailed_prompt(self, program_name: str, cobol_code: str, 
                                    base_prompt: str, analysis_type: str) -> str:
        """
        Enriquece prompt de análise ultra-detalhada com conhecimento RAG específico.
        
        Args:
            program_name: Nome do programa
            cobol_code: Código COBOL
            base_prompt: Prompt base
            analysis_type: Tipo de análise específica
            
        Returns:
            Prompt enriquecido com conhecimento RAG
        """
        if not self.is_enabled():
            return base_prompt
        
        try:
            # Buscar conhecimento específico para o tipo de análise
            search_queries = [
                f"{program_name} {analysis_type}",
                analysis_type.replace('_', ' '),
                program_name
            ]
            
            rag_sections = []
            
            for query in search_queries:
                results = self.search_knowledge_base(query, max_results=3)
                if results.get('success') and results.get('results'):
                    for result in results['results'][:2]:  # Limitar a 2 resultados por query
                        rag_sections.append(f"**Conhecimento Relacionado ({result['category']}):**")
                        rag_sections.append(result['content'][:500] + "..." if len(result['content']) > 500 else result['content'])
                        rag_sections.append("")
            
            # Atualizar estatísticas
            if rag_sections:
                self.session_stats['knowledge_items_used'] += len(rag_sections) // 3
            
            # Construir prompt enriquecido
            if rag_sections:
                rag_content = "\n".join(rag_sections)
                enhanced_prompt = f"""
{base_prompt}

---

**CONHECIMENTO CONTEXTUAL DA BASE RAG:**

{rag_content}

---

**ANÁLISE {analysis_type.upper().replace('_', ' ')} (use o conhecimento contextual acima):**
"""
            else:
                enhanced_prompt = base_prompt
            
            return enhanced_prompt
            
        except Exception as e:
            self.logger.error(f"Erro ao enriquecer prompt ultra-detalhado: {e}")
            return base_prompt
