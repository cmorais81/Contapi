#!/usr/bin/env python3
"""
COBOL Ultra Analyzer - Sistema de Análise Ultra-Detalhada
Análise técnica profunda com máximo detalhamento para especialistas
"""

import os
import sys
import json
import logging
import argparse
from datetime import datetime
from pathlib import Path

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.parsers.cobol_parser_original import COBOLParser
from src.analyzers.ultra_detailed_analyzer import UltraDetailedAnalyzer
from src.generators.professional_report_generator import ProfessionalReportGenerator
from src.utils.enhanced_cost_calculator import EnhancedCostCalculator

def setup_logging(output_dir: str, verbose: bool = False) -> logging.Logger:
    """Configura logging para análise ultra-detalhada"""
    log_dir = Path(output_dir) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = log_dir / f"ultra_analysis_{timestamp}.log"
    
    level = logging.DEBUG if verbose else logging.INFO
    
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    
    return logging.getLogger(__name__)

def load_programs_from_file(fontes_file: str) -> list:
    """Carrega programas COBOL do arquivo de fontes"""
    logger = logging.getLogger(__name__)
    parser = COBOLParser()
    programs = []
    
    logger.info(f"Carregando programas de {fontes_file}")
    
    with open(fontes_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Dividir por programas baseado em PROGRAM-ID
    program_sections = content.split('PROGRAM-ID.')
    
    for i, section in enumerate(program_sections[1:], 1):
        lines = section.strip().split('\n')
        if lines:
            # Extrair nome do programa
            program_name = lines[0].strip().split('.')[0].strip()
            program_content = 'PROGRAM-ID. ' + section
            
            # Criar objeto programa
            program = type('Program', (), {
                'name': program_name,
                'content': program_content,
                'lines': len(program_content.split('\n')),
                'size': len(program_content)
            })()
            
            programs.append(program)
            logger.debug(f"Programa carregado: {program_name} ({program.lines} linhas)")
    
    logger.info(f"Total de {len(programs)} programas carregados")
    return programs

def load_copybooks_from_file(books_file: str) -> dict:
    """Carrega copybooks do arquivo BOOKS"""
    logger = logging.getLogger(__name__)
    copybooks = {}
    
    if not books_file or not os.path.exists(books_file):
        logger.warning("Arquivo de copybooks não encontrado ou não fornecido")
        return copybooks
    
    logger.info(f"Carregando copybooks de {books_file}")
    
    with open(books_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Processar copybooks
    copybooks['MAIN_COPYBOOK'] = content
    
    logger.info(f"Carregados {len(copybooks)} copybooks")
    return copybooks

def create_provider_config(model: str, **kwargs) -> dict:
    """Cria configuração para providers"""
    config = {
        'ai': {
            'primary_provider': model,
            'fallback_providers': ['enhanced_mock'],
            'model_configurations': {
                model: {
                    'max_tokens': kwargs.get('max_tokens', 12000),
                    'temperature': kwargs.get('temperature', 0.05),
                    'timeout': kwargs.get('timeout', 120)
                }
            }
        },
        'providers': {
            'luzia': {
                'enabled': True,
                'base_url': kwargs.get('luzia_url', ''),
                'api_key': kwargs.get('luzia_key', ''),
                'timeout': 120
            },
            'openai': {
                'enabled': True,
                'api_key': kwargs.get('openai_key', os.getenv('OPENAI_API_KEY', '')),
                'timeout': 120
            },
            'aws': {
                'enabled': True,
                'region': kwargs.get('aws_region', 'us-east-1'),
                'access_key': kwargs.get('aws_access_key', ''),
                'secret_key': kwargs.get('aws_secret_key', ''),
                'timeout': 120
            },
            'enhanced_mock': {
                'enabled': True,
                'timeout': 5
            }
        }
    }
    
    return config

def estimate_ultra_detailed_costs(programs: list, model: str) -> dict:
    """Estima custos para análise ultra-detalhada"""
    cost_calculator = EnhancedCostCalculator()
    
    total_lines = sum(program.lines for program in programs)
    total_size = sum(program.size for program in programs)
    
    # Estimativa de tokens para análise ultra-detalhada (6 análises por programa)
    base_tokens_per_program = (total_size // len(programs)) // 4 if programs else 0
    
    # Multiplicador para análise ultra-detalhada (6 análises específicas)
    ultra_detailed_multiplier = 6
    
    estimated_tokens = {
        'prompt_tokens': base_tokens_per_program * len(programs) * ultra_detailed_multiplier,
        'completion_tokens': base_tokens_per_program * len(programs) * ultra_detailed_multiplier * 0.8,
        'total_tokens': int(base_tokens_per_program * len(programs) * ultra_detailed_multiplier * 1.8)
    }
    
    estimated_cost = cost_calculator.calculate_cost(estimated_tokens, model)
    estimated_cost_brl = estimated_cost * 5.50
    
    return {
        'programs_count': len(programs),
        'total_lines': total_lines,
        'total_size_bytes': total_size,
        'analysis_types': 6,
        'estimated_tokens': estimated_tokens,
        'estimated_cost_usd': estimated_cost,
        'estimated_cost_brl': estimated_cost_brl,
        'model': model,
        'cost_per_program': estimated_cost_brl / len(programs) if programs else 0,
        'note': 'Análise ultra-detalhada com 6 tipos de análise específica por programa'
    }

def analyze_programs_ultra_detailed(programs: list, copybooks: dict, config: dict, model: str) -> list:
    """Executa análise ultra-detalhada dos programas"""
    logger = logging.getLogger(__name__)
    
    logger.info(f"Iniciando análise ultra-detalhada de {len(programs)} programas com modelo {model}")
    
    # Inicializar analisador ultra-detalhado
    analyzer = UltraDetailedAnalyzer(config)
    
    analysis_results = []
    
    for i, program in enumerate(programs, 1):
        logger.info(f"Analisando programa {i}/{len(programs)}: {program.name} (análise ultra-detalhada)")
        
        try:
            # Executar análise ultra-detalhada
            result = analyzer.analyze_program_ultra_detailed(
                program, model, copybooks
            )
            
            result['program_name'] = program.name
            result['analysis_order'] = i
            analysis_results.append(result)
            
            # Log de progresso detalhado
            if result['functional_analysis'].get('success'):
                cost = result['cost_summary'].get('total_cost_brl', 0)
                analyses_count = sum(1 for key in result.keys() 
                                   if key.endswith('_analysis') and result[key].get('success'))
                logger.info(f"✅ {program.name} - {analyses_count}/6 análises concluídas - Custo: R$ {cost:.4f}")
            else:
                error = result['functional_analysis'].get('error', 'Erro desconhecido')
                logger.warning(f"❌ Falha na análise ultra-detalhada de {program.name}: {error}")
                
        except Exception as e:
            logger.error(f"Erro crítico ao analisar {program.name}: {e}", exc_info=True)
            analysis_results.append({
                'program_name': program.name,
                'analysis_order': i,
                'functional_analysis': {'success': False, 'error': str(e)},
                'cost_summary': {'total_cost_brl': 0}
            })
    
    logger.info(f"Análise ultra-detalhada concluída: {len(analysis_results)} programas processados")
    return analysis_results

def generate_ultra_detailed_reports(programs: list, analysis_results: list, copybooks: dict, output_dir: str) -> dict:
    """Gera relatórios ultra-detalhados"""
    logger = logging.getLogger(__name__)
    
    logger.info("Gerando relatórios ultra-detalhados...")
    
    try:
        # Salvar análises detalhadas em JSON
        detailed_data_file = Path(output_dir) / "analise_ultra_detalhada_completa.json"
        
        with open(detailed_data_file, 'w', encoding='utf-8') as f:
            json.dump(analysis_results, f, ensure_ascii=False, indent=2, default=str)
        
        # Gerar relatórios individuais ultra-detalhados
        report_paths = {}
        
        for result in analysis_results:
            program_name = result['program_name']
            
            # Relatório funcional detalhado
            if result.get('functional_analysis', {}).get('success'):
                functional_report = Path(output_dir) / f"funcional_{program_name}_ultra_detalhado.md"
                with open(functional_report, 'w', encoding='utf-8') as f:
                    f.write(f"# Análise Funcional Ultra-Detalhada - {program_name}\n\n")
                    f.write(result['functional_analysis']['analysis_content'])
                
                report_paths[f'functional_{program_name}'] = str(functional_report)
            
            # Relatório de regras de negócio detalhado
            if result.get('business_rules_analysis', {}).get('success'):
                business_report = Path(output_dir) / f"regras_negocio_{program_name}_ultra_detalhado.md"
                with open(business_report, 'w', encoding='utf-8') as f:
                    f.write(f"# Regras de Negócio Ultra-Detalhadas - {program_name}\n\n")
                    f.write(result['business_rules_analysis']['analysis_content'])
                
                report_paths[f'business_rules_{program_name}'] = str(business_report)
            
            # Relatório de validações detalhado
            if result.get('validation_analysis', {}).get('success'):
                validation_report = Path(output_dir) / f"validacoes_{program_name}_ultra_detalhado.md"
                with open(validation_report, 'w', encoding='utf-8') as f:
                    f.write(f"# Validações Ultra-Detalhadas - {program_name}\n\n")
                    f.write(result['validation_analysis']['analysis_content'])
                
                report_paths[f'validations_{program_name}'] = str(validation_report)
            
            # Relatório CADOC específico
            if result.get('cadoc_analysis', {}).get('success'):
                cadoc_report = Path(output_dir) / f"cadoc_{program_name}_detalhado.md"
                with open(cadoc_report, 'w', encoding='utf-8') as f:
                    f.write(f"# Análise CADOC Específica - {program_name}\n\n")
                    f.write(result['cadoc_analysis']['analysis_content'])
                
                report_paths[f'cadoc_{program_name}'] = str(cadoc_report)
        
        # Relatório consolidado ultra-detalhado
        consolidated_report = Path(output_dir) / "relatorio_consolidado_ultra_detalhado.md"
        generate_consolidated_ultra_report(analysis_results, consolidated_report)
        report_paths['consolidated_ultra'] = str(consolidated_report)
        
        # Dados JSON ultra-detalhados
        report_paths['json_ultra_detailed'] = str(detailed_data_file)
        
        logger.info(f"Relatórios ultra-detalhados gerados com sucesso em {output_dir}")
        return report_paths
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatórios ultra-detalhados: {e}", exc_info=True)
        return {}

def generate_consolidated_ultra_report(analysis_results: list, output_file: Path):
    """Gera relatório consolidado ultra-detalhado"""
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write("# Relatório Consolidado Ultra-Detalhado - Análise COBOL\n\n")
        f.write(f"**Data da Análise**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
        
        # Estatísticas gerais
        total_programs = len(analysis_results)
        successful_analyses = sum(1 for r in analysis_results 
                                if r.get('functional_analysis', {}).get('success'))
        total_cost = sum(r.get('cost_summary', {}).get('total_cost_brl', 0) 
                        for r in analysis_results)
        
        f.write("## Resumo Executivo\n\n")
        f.write(f"- **Programas Analisados**: {total_programs}\n")
        f.write(f"- **Análises Bem-sucedidas**: {successful_analyses}\n")
        f.write(f"- **Custo Total**: R$ {total_cost:.4f}\n")
        f.write(f"- **Tipos de Análise**: 6 por programa\n\n")
        
        # Detalhes por programa
        f.write("## Análises por Programa\n\n")
        
        for result in analysis_results:
            program_name = result['program_name']
            f.write(f"### {program_name}\n\n")
            
            # Informações do programa
            if 'program_info' in result:
                info = result['program_info']
                f.write(f"- **Linhas de Código**: {info.get('statistics', {}).get('total_lines', 'N/A')}\n")
                f.write(f"- **Autor**: {info.get('author', 'N/A')}\n")
                f.write(f"- **Complexidade Ciclomática**: {info.get('complexity_indicators', {}).get('cyclomatic_complexity', 'N/A')}\n")
            
            # Status das análises
            analyses = ['functional_analysis', 'business_rules_analysis', 'file_processing_analysis',
                       'validation_analysis', 'cadoc_analysis', 'error_handling_analysis']
            
            successful_count = sum(1 for analysis in analyses 
                                 if result.get(analysis, {}).get('success'))
            
            f.write(f"- **Análises Concluídas**: {successful_count}/6\n")
            
            # Principais descobertas
            if result.get('business_rules_analysis', {}).get('success'):
                br_data = result['business_rules_analysis'].get('processed_data', {})
                f.write(f"- **Regras de Negócio**: {br_data.get('business_rules_count', 'N/A')}\n")
            
            if result.get('validation_analysis', {}).get('success'):
                val_data = result['validation_analysis'].get('processed_data', {})
                f.write(f"- **Validações**: {val_data.get('total_validations', 'N/A')}\n")
            
            f.write("\n")
        
        # Recomendações consolidadas
        f.write("## Recomendações Consolidadas\n\n")
        f.write("### Prioridades Imediatas\n")
        f.write("1. **Revisar regras de negócio críticas** identificadas nas análises\n")
        f.write("2. **Documentar validações específicas** encontradas\n")
        f.write("3. **Implementar melhorias** nas funcionalidades CADOC\n")
        f.write("4. **Otimizar tratamento de erros** conforme análises\n\n")
        
        f.write("### Próximos Passos\n")
        f.write("1. Análise detalhada dos relatórios individuais\n")
        f.write("2. Implementação das recomendações por prioridade\n")
        f.write("3. Validação das descobertas com especialistas\n")
        f.write("4. Planejamento de modernização baseado nos achados\n\n")

def print_ultra_summary(programs: list, analysis_results: list, report_paths: dict, execution_time: float):
    """Imprime resumo da análise ultra-detalhada"""
    successful_analyses = len([r for r in analysis_results 
                             if r.get('functional_analysis', {}).get('success')])
    total_cost = sum(r.get('cost_summary', {}).get('total_cost_brl', 0) 
                    for r in analysis_results)
    
    # Contar análises específicas bem-sucedidas
    analysis_types = ['functional_analysis', 'business_rules_analysis', 'file_processing_analysis',
                     'validation_analysis', 'cadoc_analysis', 'error_handling_analysis']
    
    total_specific_analyses = 0
    successful_specific_analyses = 0
    
    for result in analysis_results:
        for analysis_type in analysis_types:
            total_specific_analyses += 1
            if result.get(analysis_type, {}).get('success'):
                successful_specific_analyses += 1
    
    print("\n" + "="*80)
    print("🔬 COBOL ULTRA ANALYZER - ANÁLISE ULTRA-DETALHADA CONCLUÍDA")
    print("="*80)
    print(f"📊 Programas processados: {len(programs)}")
    print(f"✅ Programas analisados com sucesso: {successful_analyses}")
    print(f"🔍 Análises específicas realizadas: {successful_specific_analyses}/{total_specific_analyses}")
    print(f"💰 Custo total: R$ {total_cost:.4f}")
    print(f"⏱️  Tempo de execução: {execution_time:.2f} segundos")
    print(f"💡 Custo médio por programa: R$ {total_cost/len(programs):.4f}")
    
    if report_paths:
        print("\n📄 RELATÓRIOS ULTRA-DETALHADOS GERADOS:")
        print("-" * 50)
        for report_type, path in report_paths.items():
            print(f"• {report_type}: {path}")
    
    print("\n🎯 ANÁLISES ESPECÍFICAS REALIZADAS:")
    print("1. 🔧 Análise Funcional Ultra-Detalhada")
    print("2. 📋 Extração Profunda de Regras de Negócio")
    print("3. 📁 Análise Detalhada de Processamento de Arquivos")
    print("4. ✅ Análise Específica de Validações")
    print("5. 📄 Análise Especializada CADOC")
    print("6. ⚠️  Análise de Tratamento de Erros")
    
    print("\n🚀 PRÓXIMOS PASSOS:")
    print("1. Revisar relatórios funcionais ultra-detalhados")
    print("2. Analisar regras de negócio específicas identificadas")
    print("3. Implementar validações críticas encontradas")
    print("4. Otimizar funcionalidades CADOC conforme análise")
    print("5. Melhorar tratamento de erros baseado nos achados")
    print("="*80)

def main():
    parser = argparse.ArgumentParser(
        description='COBOL Ultra Analyzer - Análise Ultra-Detalhada de Sistemas COBOL',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:

# Análise ultra-detalhada básica
python cobol_ultra_analyzer.py --fontes fontes.txt --output relatorio_ultra

# Análise com Luzia (recomendado)
python cobol_ultra_analyzer.py --fontes fontes.txt --books books.txt --output relatorio_ultra --model luzia

# Apenas estimativa de custos
python cobol_ultra_analyzer.py --fontes fontes.txt --model luzia --estimate-only

# Análise com configurações otimizadas
python cobol_ultra_analyzer.py --fontes fontes.txt --output relatorio_ultra --model luzia --max-tokens 15000 --temperature 0.01
        """
    )
    
    # Argumentos obrigatórios
    parser.add_argument('--fontes', required=True, help='Arquivo com programas COBOL')
    
    # Argumentos opcionais
    parser.add_argument('--books', help='Arquivo com copybooks')
    parser.add_argument('--output', help='Diretório de saída (obrigatório exceto para --estimate-only)')
    parser.add_argument('--model', default='enhanced_mock', 
                       choices=['luzia', 'openai-gpt-4', 'openai-gpt-3.5-turbo', 'aws-claude-3-5-sonnet', 'enhanced_mock'],
                       help='Modelo de IA a usar (default: enhanced_mock)')
    
    # Flags
    parser.add_argument('--estimate-only', action='store_true', 
                       help='Apenas estimar custos sem executar análise')
    parser.add_argument('--verbose', '-v', action='store_true', 
                       help='Logging detalhado')
    
    # Configurações de modelo
    parser.add_argument('--max-tokens', type=int, default=12000, 
                       help='Máximo de tokens por requisição')
    parser.add_argument('--temperature', type=float, default=0.05, 
                       help='Temperatura do modelo (0.0-1.0)')
    parser.add_argument('--timeout', type=int, default=120, 
                       help='Timeout em segundos')
    
    # Configurações de providers
    parser.add_argument('--openai-key', help='Chave API OpenAI')
    parser.add_argument('--luzia-url', help='URL base Luzia')
    parser.add_argument('--luzia-key', help='Chave API Luzia')
    
    args = parser.parse_args()
    
    # Validações
    if not args.estimate_only and not args.output:
        parser.error("--output é obrigatório exceto quando usando --estimate-only")
    
    if not os.path.exists(args.fontes):
        parser.error(f"Arquivo de fontes não encontrado: {args.fontes}")
    
    # Configurar diretório de saída
    if args.output:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = Path(args.output) / f"ultra_analysis_{timestamp}"
        output_dir.mkdir(parents=True, exist_ok=True)
    else:
        output_dir = Path("/tmp/ultra_estimate")
        output_dir.mkdir(exist_ok=True)
    
    # Setup logging
    logger = setup_logging(str(output_dir), args.verbose)
    logger.info("🔬 Iniciando COBOL Ultra Analyzer")
    
    start_time = datetime.now()
    
    try:
        # Carregar programas e copybooks
        programs = load_programs_from_file(args.fontes)
        copybooks = load_copybooks_from_file(args.books) if args.books else {}
        
        if not programs:
            logger.error("Nenhum programa COBOL encontrado no arquivo de fontes")
            sys.exit(1)
        
        # Estimativa de custos ultra-detalhada
        estimate = estimate_ultra_detailed_costs(programs, args.model)
        
        print("\n" + "="*70)
        print("💰 ESTIMATIVA DE CUSTOS - ANÁLISE ULTRA-DETALHADA")
        print("="*70)
        print(f"Programas: {estimate['programs_count']}")
        print(f"Linhas de código: {estimate['total_lines']:,}")
        print(f"Tipos de análise: {estimate['analysis_types']} por programa")
        print(f"Tokens estimados: {estimate['estimated_tokens']['total_tokens']:,}")
        print(f"Custo estimado: R$ {estimate['estimated_cost_brl']:.4f} (${estimate['estimated_cost_usd']:.4f})")
        print(f"Custo por programa: R$ {estimate['cost_per_program']:.4f}")
        print(f"Modelo: {estimate['model']}")
        print(f"Nota: {estimate['note']}")
        print("="*70)
        
        if args.estimate_only:
            logger.info("Estimativa ultra-detalhada concluída. Saindo...")
            return
        
        # Confirmar execução se custo for alto
        if estimate['estimated_cost_brl'] > 100.0:
            response = input(f"\n⚠️  Custo estimado é R$ {estimate['estimated_cost_brl']:.2f}. Continuar? (s/N): ")
            if response.lower() not in ['s', 'sim', 'y', 'yes']:
                logger.info("Execução cancelada pelo usuário")
                return
        
        # Criar configuração de providers
        provider_config = create_provider_config(args.model, 
                                                max_tokens=args.max_tokens,
                                                temperature=args.temperature,
                                                timeout=args.timeout,
                                                openai_key=args.openai_key,
                                                luzia_url=args.luzia_url,
                                                luzia_key=args.luzia_key)
        
        # Executar análise ultra-detalhada
        analysis_results = analyze_programs_ultra_detailed(programs, copybooks, provider_config, args.model)
        
        # Gerar relatórios ultra-detalhados
        report_paths = generate_ultra_detailed_reports(programs, analysis_results, copybooks, str(output_dir))
        
        # Calcular tempo de execução
        execution_time = (datetime.now() - start_time).total_seconds()
        
        # Imprimir resumo ultra-detalhado
        print_ultra_summary(programs, analysis_results, report_paths, execution_time)
        
        logger.info(f"✅ Análise ultra-detalhada concluída com sucesso em {execution_time:.2f} segundos")
        
    except KeyboardInterrupt:
        logger.info("❌ Análise interrompida pelo usuário")
        sys.exit(1)
    except Exception as e:
        logger.error(f"❌ Erro crítico durante execução: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    main()
