#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
- NOVA: Análise Ultra-Detalhada Automática
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration import RAGIntegration
from src.core.intelligent_model_selector import IntelligentModelSelector
from process_detailed_analysis import process_detailed_business_analysis
from process_advanced_consolidated_analysis import process_advanced_consolidated_analysis
from src.analyzers.ultra_detailed_analyzer import UltraDetailedAnalyzer
from src.prompts.ultra_detailed_cobol_prompts import UltraDetailedCOBOLPrompts

def execute_ultra_detailed_analysis(programs: List[CobolProgram], 
                                   books: List[CobolBook], 
                                   model: str, 
                                   args, 
                                   config_manager: ConfigManager, 
                                   cost_calculator: CostCalculator) -> Dict[str, Any]:
    """
    Executa análise ultra-detalhada dos programas COBOL
    """
    logger = logging.getLogger(__name__)
    
    try:
        # Criar configuração de providers
        provider_config = config_manager.get_config()
        
        # Inicializar analisador ultra-detalhado
        ultra_analyzer = UltraDetailedAnalyzer(provider_config)
        
        # Preparar copybooks
        copybooks_dict = {}
        for book in books:
            copybooks_dict[book.name] = book.content
        
        # Executar análise para cada programa
        all_ultra_results = []
        total_cost_brl = 0.0
        total_analyses = 0
        
        for program in programs:
            logger.info(f"Executando análise ultra-detalhada para {program.name}")
            
            result = ultra_analyzer.analyze_program_ultra_detailed(
                program, model, copybooks_dict
            )
            
            all_ultra_results.append(result)
            
            # Contar análises bem-sucedidas
            analysis_types = ['functional_analysis', 'business_rules_analysis', 
                            'file_processing_analysis', 'validation_analysis', 
                            'cadoc_analysis', 'error_handling_analysis']
            
            for analysis_type in analysis_types:
                if result.get(analysis_type, {}).get('success'):
                    total_analyses += 1
                    total_cost_brl += result[analysis_type].get('cost_brl', 0.0)
        
        # Gerar relatórios ultra-detalhados
        ultra_output_dir = os.path.join(args.output, "analise_ultra_detalhada")
        os.makedirs(ultra_output_dir, exist_ok=True)
        
        # Salvar resultados em JSON
        ultra_json_file = os.path.join(ultra_output_dir, "analise_ultra_detalhada_completa.json")
        with open(ultra_json_file, 'w', encoding='utf-8') as f:
            json.dump(all_ultra_results, f, ensure_ascii=False, indent=2, default=str)
        
        # Gerar relatórios individuais
        for result in all_ultra_results:
            program_name = result['program_name']
            
            # Relatório funcional ultra-detalhado
            if result.get('functional_analysis', {}).get('success'):
                func_file = os.path.join(ultra_output_dir, f"funcional_{program_name}_ultra_detalhado.md")
                with open(func_file, 'w', encoding='utf-8') as f:
                    f.write(f"# Análise Funcional Ultra-Detalhada - {program_name}\n\n")
                    f.write(result['functional_analysis']['analysis_content'])
            
            # Relatório de regras de negócio ultra-detalhado
            if result.get('business_rules_analysis', {}).get('success'):
                rules_file = os.path.join(ultra_output_dir, f"regras_negocio_{program_name}_ultra_detalhado.md")
                with open(rules_file, 'w', encoding='utf-8') as f:
                    f.write(f"# Regras de Negócio Ultra-Detalhadas - {program_name}\n\n")
                    f.write(result['business_rules_analysis']['analysis_content'])
            
            # Relatório de validações ultra-detalhado
            if result.get('validation_analysis', {}).get('success'):
                val_file = os.path.join(ultra_output_dir, f"validacoes_{program_name}_ultra_detalhado.md")
                with open(val_file, 'w', encoding='utf-8') as f:
                    f.write(f"# Validações Ultra-Detalhadas - {program_name}\n\n")
                    f.write(result['validation_analysis']['analysis_content'])
        
        # Gerar relatório consolidado ultra-detalhado
        consolidated_file = os.path.join(ultra_output_dir, "relatorio_consolidado_ultra_detalhado.md")
        with open(consolidated_file, 'w', encoding='utf-8') as f:
            f.write("# Relatório Consolidado Ultra-Detalhado - Análise COBOL\n\n")
            f.write(f"**Data da Análise**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
            
            f.write("## Resumo Executivo\n\n")
            f.write(f"- **Programas Analisados**: {len(programs)}\n")
            f.write(f"- **Análises Específicas Realizadas**: {total_analyses}\n")
            f.write(f"- **Custo Total**: R$ {total_cost_brl:.4f}\n")
            f.write(f"- **Tipos de Análise**: 6 por programa\n\n")
            
            f.write("## Tipos de Análise Realizados\n\n")
            f.write("1. **🔧 Análise Funcional Ultra-Detalhada** - Funcionalidades e sequência de execução\n")
            f.write("2. **📋 Extração Profunda de Regras de Negócio** - Regras com algoritmos específicos\n")
            f.write("3. **📁 Análise Detalhada de Processamento de Arquivos** - Estruturas e operações\n")
            f.write("4. **✅ Análise Específica de Validações** - Tipos de informação e algoritmos\n")
            f.write("5. **📄 Análise Especializada CADOC** - Funcionalidades CADOC específicas\n")
            f.write("6. **⚠️ Análise de Tratamento de Erros** - Códigos e ações de recuperação\n\n")
            
            f.write("## Principais Descobertas\n\n")
            for result in all_ultra_results:
                program_name = result['program_name']
                f.write(f"### {program_name}\n\n")
                
                # Estatísticas do programa
                if 'program_info' in result:
                    info = result['program_info']
                    f.write(f"- **Linhas de Código**: {info.get('statistics', {}).get('total_lines', 'N/A')}\n")
                    f.write(f"- **Complexidade Ciclomática**: {info.get('complexity_indicators', {}).get('cyclomatic_complexity', 'N/A')}\n")
                
                # Contagem de análises bem-sucedidas
                successful_analyses = sum(1 for analysis_type in analysis_types 
                                        if result.get(analysis_type, {}).get('success'))
                f.write(f"- **Análises Concluídas**: {successful_analyses}/6\n")
                
                # Principais descobertas por tipo
                if result.get('business_rules_analysis', {}).get('success'):
                    br_data = result['business_rules_analysis'].get('processed_data', {})
                    f.write(f"- **Regras de Negócio Identificadas**: {br_data.get('business_rules_count', 'N/A')}\n")
                
                if result.get('validation_analysis', {}).get('success'):
                    val_data = result['validation_analysis'].get('processed_data', {})
                    f.write(f"- **Validações Identificadas**: {val_data.get('total_validations', 'N/A')}\n")
                
                f.write("\n")
        
        logger.info(f"Análise ultra-detalhada concluída: {len(programs)} programas, {total_analyses} análises específicas")
        
        return {
            'success': True,
            'programs_analyzed': len(programs),
            'total_analyses': total_analyses,
            'total_cost_brl': total_cost_brl,
            'output_directory': ultra_output_dir,
            'reports_generated': {
                'json_data': ultra_json_file,
                'consolidated_report': consolidated_file,
                'individual_reports': total_analyses
            }
        }
        
    except Exception as e:
        logger.error(f"Erro na análise ultra-detalhada: {e}", exc_info=True)
        return {
            'success': False,
            'error': str(e),
            'programs_analyzed': 0,
            'total_analyses': 0,
            'total_cost_brl': 0.0
        }

def setup_logging(log_level: str = "INFO") -> None:
