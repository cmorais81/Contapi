#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
- NOVA: Análise Ultra-Detalhada Automática Integrada
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration_enhanced import EnhancedRAGIntegration
from src.core.intelligent_model_selector import IntelligentModelSelector
from process_detailed_analysis import process_detailed_business_analysis
from process_advanced_consolidated_analysis import process_advanced_consolidated_analysis

# Importações para análise ultra-detalhada (com fallback)
try:
    from src.analyzers.ultra_detailed_analyzer import UltraDetailedAnalyzer
    from src.prompts.ultra_detailed_cobol_prompts import UltraDetailedCOBOLPrompts
    ULTRA_DETAILED_AVAILABLE = True
except ImportError as e:
    logging.warning(f"Análise ultra-detalhada não disponível: {e}")
    ULTRA_DETAILED_AVAILABLE = False

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def execute_ultra_detailed_analysis(programs: List[CobolProgram], 
                                   books: List[CobolBook], 
                                   model: str, 
                                   args, 
                                   config_manager: ConfigManager, 
                                   cost_calculator: CostCalculator,
                                   rag_integration) -> Dict[str, Any]:
    """
    Executa análise ultra-detalhada dos programas COBOL (se disponível)
    """
    logger = logging.getLogger(__name__)
    
    if not ULTRA_DETAILED_AVAILABLE:
        logger.info("Análise ultra-detalhada não disponível, continuando com análise padrão")
        return {'success': False, 'reason': 'ultra_detailed_not_available'}
    
    try:
        logger.info("=== EXECUTANDO ANÁLISE ULTRA-DETALHADA AUTOMÁTICA ===")
        
        # Criar configuração de providers
        provider_config = config_manager.get_config()
        
        # Inicializar analisador ultra-detalhado
        ultra_analyzer = UltraDetailedAnalyzer(provider_config)
        
        # Preparar copybooks
        copybooks_dict = {}
        for book in books:
            copybooks_dict[book.name] = book.content
        
        # Executar análise para cada programa
        all_ultra_results = []
        total_cost_brl = 0.0
        total_analyses = 0
        
        for program in programs:
            logger.info(f"Executando análise ultra-detalhada para {program.name}")
            
            result = ultra_analyzer.analyze_program_ultra_detailed(
                program, model, copybooks_dict
            )
            
            all_ultra_results.append(result)
            
            # Contar análises bem-sucedidas
            analysis_types = ['functional_analysis', 'business_rules_analysis', 
                            'file_processing_analysis', 'validation_analysis', 
                            'cadoc_analysis', 'error_handling_analysis']
            
            for analysis_type in analysis_types:
                if result.get(analysis_type, {}).get('success'):
                    total_analyses += 1
                    total_cost_brl += result[analysis_type].get('cost_brl', 0.0)
                    
                    # Adicionar conhecimento ao RAG
                    if rag_integration and hasattr(rag_integration, 'add_analysis_to_knowledge_base'):
                        try:
                            analysis_content = result[analysis_type].get('analysis_content', '')
                            rag_integration.add_analysis_to_knowledge_base(
                                f"{program.name}_{analysis_type}",
                                analysis_content,
                                program.content,
                                analysis_type
                            )
                            logger.info(f"Conhecimento {analysis_type} de {program.name} adicionado ao RAG")
                        except Exception as e:
                            logger.warning(f"Falha ao adicionar {analysis_type} ao RAG: {e}")
        
        # Gerar relatórios ultra-detalhados
        ultra_output_dir = os.path.join(args.output, "analise_ultra_detalhada")
        os.makedirs(ultra_output_dir, exist_ok=True)
        
        # Salvar resultados em JSON
        ultra_json_file = os.path.join(ultra_output_dir, "analise_ultra_detalhada_completa.json")
        with open(ultra_json_file, 'w', encoding='utf-8') as f:
            json.dump(all_ultra_results, f, ensure_ascii=False, indent=2, default=str)
        
        # Gerar relatórios individuais
        for result in all_ultra_results:
            program_name = result['program_name']
            
            # Relatório funcional ultra-detalhado
            if result.get('functional_analysis', {}).get('success'):
                func_file = os.path.join(ultra_output_dir, f"funcional_{program_name}_ultra_detalhado.md")
                with open(func_file, 'w', encoding='utf-8') as f:
                    f.write(f"# Análise Funcional Ultra-Detalhada - {program_name}\n\n")
                    f.write(result['functional_analysis']['analysis_content'])
            
            # Relatório de regras de negócio ultra-detalhado
            if result.get('business_rules_analysis', {}).get('success'):
                rules_file = os.path.join(ultra_output_dir, f"regras_negocio_{program_name}_ultra_detalhado.md")
                with open(rules_file, 'w', encoding='utf-8') as f:
                    f.write(f"# Regras de Negócio Ultra-Detalhadas - {program_name}\n\n")
                    f.write(result['business_rules_analysis']['analysis_content'])
            
            # Relatório de validações ultra-detalhado
            if result.get('validation_analysis', {}).get('success'):
                val_file = os.path.join(ultra_output_dir, f"validacoes_{program_name}_ultra_detalhado.md")
                with open(val_file, 'w', encoding='utf-8') as f:
                    f.write(f"# Validações Ultra-Detalhadas - {program_name}\n\n")
                    f.write(result['validation_analysis']['analysis_content'])
        
        # Gerar relatório consolidado ultra-detalhado
        consolidated_file = os.path.join(ultra_output_dir, "relatorio_consolidado_ultra_detalhado.md")
        with open(consolidated_file, 'w', encoding='utf-8') as f:
            f.write("# Relatório Consolidado Ultra-Detalhado - Análise COBOL\n\n")
            f.write(f"**Data da Análise**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
            
            f.write("## Resumo Executivo\n\n")
            f.write(f"- **Programas Analisados**: {len(programs)}\n")
            f.write(f"- **Análises Específicas Realizadas**: {total_analyses}\n")
            f.write(f"- **Custo Total**: R$ {total_cost_brl:.4f}\n")
            f.write(f"- **Tipos de Análise**: 6 por programa\n\n")
            
            f.write("## Tipos de Análise Realizados\n\n")
            f.write("1. **🔧 Análise Funcional Ultra-Detalhada** - Funcionalidades e sequência de execução\n")
            f.write("2. **📋 Extração Profunda de Regras de Negócio** - Regras com algoritmos específicos\n")
            f.write("3. **📁 Análise Detalhada de Processamento de Arquivos** - Estruturas e operações\n")
            f.write("4. **✅ Análise Específica de Validações** - Tipos de informação e algoritmos\n")
            f.write("5. **📄 Análise Especializada CADOC** - Funcionalidades CADOC específicas\n")
            f.write("6. **⚠️ Análise de Tratamento de Erros** - Códigos e ações de recuperação\n\n")
        
        logger.info(f"✅ Análise ultra-detalhada concluída: {total_analyses} análises específicas")
        logger.info(f"💰 Custo da análise ultra-detalhada: R$ {total_cost_brl:.4f}")
        
        return {
            'success': True,
            'programs_analyzed': len(programs),
            'total_analyses': total_analyses,
            'total_cost_brl': total_cost_brl,
            'output_directory': ultra_output_dir,
            'reports_generated': {
                'json_data': ultra_json_file,
                'consolidated_report': consolidated_file,
                'individual_reports': total_analyses
            }
        }
        
    except Exception as e:
        logger.error(f"Erro na análise ultra-detalhada: {e}", exc_info=True)
        return {
            'success': False,
            'error': str(e),
            'programs_analyzed': 0,
            'total_analyses': 0,
            'total_cost_brl': 0.0
        }

def parse_models_argument(models_str: str) -> List[str]:
    """Parse do argumento models que pode ser string ou lista JSON."""
    if not models_str:
        return []
    
    models_str = models_str.strip()
    
    # Se começa com [ é uma lista JSON
    if models_str.startswith('['):
        try:
            models = json.loads(models_str)
            return models if isinstance(models, list) else [models]
        except json.JSONDecodeError:
            print(f"Erro: Formato JSON inválido para models: {models_str}")
            sys.exit(1)
    else:
        # String simples
        return [models_str]

def analyze_program_with_model(program: CobolProgram, books: List[CobolBook], model: str, output_dir: str, config_manager: ConfigManager, is_multi_model: bool, prompt_set: str, cost_calculator: CostCalculator, rag_integration=None) -> Dict[str, Any]:
    """Analisa um programa COBOL com um modelo específico."""
    logger = logging.getLogger(__name__)
    
    # Criar diretório específico do modelo se multi-modelo
    if is_multi_model:
        model_output_dir = os.path.join(output_dir, f"model_{model.replace('/', '_').replace('-', '_')}")
        os.makedirs(model_output_dir, exist_ok=True)
    else:
        model_output_dir = output_dir
    
    try:
        # Inicializar componentes específicos para o modelo
        prompt_manager = DualPromptManager(config_manager.config, prompt_set)
        provider_manager = EnhancedProviderManager(config_manager.config)
        doc_generator = DocumentationGenerator(model_output_dir)
        
        # Análise com IA (passando RAG integration)
        analyzer = EnhancedCOBOLAnalyzer(provider_manager, prompt_manager, rag_integration)
        
        start_time = time.time()
        
        # Log do provider que será usado
        logger.info(f"*** PROVIDER SELECIONADO: {model} ***")
        logger.info(f"Iniciando análise de {program.name} com provider {model}")
        
        analysis_result = analyzer.analyze_program(program, model)
        analysis_time = time.time() - start_time
        
        # Log do provider efetivamente usado
        provider_usado = getattr(analysis_result, 'provider_used', model)
        logger.info(f"*** ANÁLISE CONCLUÍDA COM PROVIDER: {provider_usado} ***")
        
        if not analysis_result.success:
            logger.error(f"Falha na análise de {program.name} com modelo {model}: {analysis_result.error_message}")
            return {
                'success': False,
                'program_name': program.name,
                'model': model,
                'error': analysis_result.error_message,
                'tokens_used': 0,
                'analysis_time': analysis_time,
                'output_dir': model_output_dir
            }
        
        # Calcular custos
        cost_info = cost_calculator.tokens_analytics(
            {'usage': [{'total_tokens': analysis_result.tokens_used}]}, 
            analysis_result.model_used
        )
        
        # Gerar documentação
        from src.providers.base_provider import AIResponse
        
        # Obter prompts utilizados do prompt_manager
        prompts_used = {
            'system_prompt': prompt_manager.get_system_prompt(),
            'original_prompt': getattr(analysis_result, 'original_prompt', 'Prompt gerado dinamicamente'),
            'main_prompt': getattr(analysis_result, 'prompt_used', 'Prompt principal não disponível')
        }
        
        ai_response = AIResponse(
            success=True,
            content=analysis_result.content,
            tokens_used=analysis_result.tokens_used,
            model=analysis_result.model_used,
            provider=getattr(analysis_result, 'provider_used', 'enhanced_mock'),
            prompts_used=prompts_used,
            response_time=analysis_time
        )
        
        doc_result = doc_generator.generate_program_documentation(program, ai_response)
        
        logger.info(f"Análise de {program.name} com {model} bem-sucedida.")
        logger.info(f"Tokens utilizados: {analysis_result.tokens_used:,}")
        logger.info(f"Custo: ${cost_info['cost']:.4f}")
        logger.info(f"Modelo utilizado: {analysis_result.model_used}")
        
        # Auto-learning: Adicionar análise bem-sucedida à base de conhecimento
        if rag_integration and hasattr(rag_integration, 'add_program_analysis_to_knowledge_base'):
            try:
                rag_integration.add_program_analysis_to_knowledge_base(
                    program.name, 
                    analysis_result.content, 
                    program.content
                )
                logger.info(f"Auto-learning: Conhecimento do programa {program.name} adicionado à base RAG")
            except Exception as e:
                logger.warning(f"Auto-learning falhou para {program.name}: {e}")
        
        return {
            'success': True,
            'program_name': program.name,
            'model': model,
            'tokens_used': analysis_result.tokens_used,
            'analysis_time': analysis_time,
            'output_dir': model_output_dir,
            'files_generated': [doc_result] if doc_result else [],
            'response': analysis_result
        }
        
    except Exception as e:
        logger.error(f"Erro na análise de {program.name} com modelo {model}: {str(e)}")
        return {
            'success': False,
            'program_name': program.name,
            'model': model,
            'error': str(e),
            'tokens_used': 0,
            'analysis_time': 0,
            'output_dir': model_output_dir
        }

def get_models_from_providers(config_manager: ConfigManager) -> List[str]:
    """Obtém modelos disponíveis dos providers configurados."""
    try:
        provider_manager = EnhancedProviderManager(config_manager.config)
        available_models = []
        
        # Verificar providers disponíveis
        providers = ['luzia', 'enhanced_mock', 'basic']
        for provider_name in providers:
            try:
                if provider_manager.get_provider_status(provider_name):
                    if provider_name == 'luzia':
                        available_models.append('luzia')
                    elif provider_name == 'enhanced_mock':
                        available_models.append('enhanced_mock')
                    elif provider_name == 'basic':
                        available_models.append('basic')
            except Exception:
                continue
        
        # Se nenhum provider disponível, usar mock
        if not available_models:
            available_models = ['enhanced_mock']
        
        return available_models
    except Exception:
        return ['enhanced_mock']

def process_cobol_files(args, config_manager: ConfigManager, cost_calculator: CostCalculator, rag_integration) -> None:
    """Processa arquivos COBOL com funcionalidade completa restaurada."""
    logger = logging.getLogger(__name__)
    
    # Inicializar seletor inteligente de modelos
    model_selector = IntelligentModelSelector()
    
    # Determinar modelos a usar
    if hasattr(args, 'models') and args.models:
        models = parse_models_argument(args.models)
        logger.info(f"Modelos especificados pelo usuário: {models}")
    else:
        # Obter modelos dos providers configurados
        models = get_models_from_providers(config_manager)
        logger.info(f"Modelos obtidos dos providers: {models}")
    
    # Inicializar parser
    parser = COBOLParser()
    
    # Verificar modo de operação
    if args.consolidado:
        logger.info("=== MODO ANÁLISE CONSOLIDADA SISTÊMICA ===")
        process_consolidated_analysis(args, config_manager, cost_calculator, parser, models)
        return
    
    if args.relatorio_unico:
        logger.info("=== MODO RELATÓRIO ÚNICO CONSOLIDADO ===")
        process_consolidated_report(args, config_manager, cost_calculator, parser, models)
        return
    
    # Verificar se deve usar análise especializada
    if args.analise_especialista or args.procedure_detalhada or args.modernizacao:
        logger.info("=== MODO ANÁLISE ESPECIALIZADA ===")
        process_expert_analysis(args, config_manager, cost_calculator, parser, models)
        return
    
    # Verificar se deve usar análise avançada com relatório consolidado
    if hasattr(args, 'advanced_analysis') and args.advanced_analysis:
        logger.info("=== MODO ANÁLISE AVANÇADA COM RELATÓRIO CONSOLIDADO ===")
        process_advanced_consolidated_analysis(args, config_manager, cost_calculator, parser, models)
        return
    
    # Verificar se deve usar análise detalhada de regras de negócio
    if hasattr(args, 'deep_analysis') and args.deep_analysis:
        logger.info("=== MODO ANÁLISE DETALHADA DE REGRAS DE NEGÓCIO ===")
        process_detailed_business_analysis(args, config_manager, cost_calculator, parser, models)
        return
    
    logger.info("=== INICIANDO PROCESSAMENTO COMPLETO ===")
    logger.info(f"Modelos selecionados: {models}")
    logger.info(f"Arquivo de fontes: {args.fontes}")
    if args.books:
        logger.info(f"Arquivo de books: {args.books}")
    logger.info(f"Diretório de saída: {args.output}")
    
    start_time = time.time()
    
    try:
        # Parse do arquivo principal
        programs, books = parser.parse_file(args.fontes)
        
        # Parse de copybooks adicionais se especificado
        if args.books and os.path.exists(args.books):
            _, additional_books = parser.parse_file(args.books)
            books.extend(additional_books)
        
        logger.info(f"Programas encontrados: {len(programs)}, Books encontrados: {len(books)}")
        
        if not programs:
            print("Nenhum programa encontrado para análise.")
            sys.exit(0)
            
    except Exception as e:
        logger.error(f"Erro ao parsear arquivos: {str(e)}")
        return
    
    # Criar diretório de saída
    os.makedirs(args.output, exist_ok=True)
    
    # NOVA FUNCIONALIDADE: Executar análise ultra-detalhada automaticamente
    if ULTRA_DETAILED_AVAILABLE and len(programs) > 0:
        try:
            ultra_results = execute_ultra_detailed_analysis(
                programs, books, models[0] if models else 'enhanced_mock', 
                args, config_manager, cost_calculator, rag_integration
            )
            
            if ultra_results.get('success'):
                logger.info(f"✅ Análise ultra-detalhada concluída: {ultra_results['total_analyses']} análises específicas")
                logger.info(f"💰 Custo da análise ultra-detalhada: R$ {ultra_results['total_cost_brl']:.4f}")
            else:
                logger.info("Análise ultra-detalhada não executada, continuando com análise padrão")
        except Exception as e:
            logger.warning(f"Análise ultra-detalhada falhou, continuando com análise padrão: {e}")
    
    all_results = []
    is_multi_model = len(models) > 1
    
    print(f"\nCOBOL to Docs v1.1 - Iniciando processamento")
    print(f"Autor: Carlos Morais")
    print(f"Programas COBOL: {len(programs)}")
    if books:
        print(f"Copybooks: {len(books)}")
    print(f"Modelos: {', '.join(models)}")
    print(f"Diretório de saída: {args.output}")
    print("=" * 60)
    
    # Processamento baseado no número de modelos
    if not is_multi_model:
        # Modelo único - usar seleção inteligente se não especificado pelo usuário
        if not hasattr(args, 'models') or not args.models:
            # Seleção inteligente baseada na complexidade do primeiro programa
            first_program_code = programs[0].content if programs else ""
            recommendation = model_selector.select_optimal_model(first_program_code)
            
            # Verificar se o modelo recomendado está disponível
            available_models = get_models_from_providers(config_manager)
            if recommendation['model'] in available_models:
                models = [recommendation['model']]
                print(f"🤖 Modelo selecionado automaticamente: {recommendation['model']}")
                print(f"   Razão: {recommendation['reason']}")
                print(f"   Adequação: {recommendation['suitability_score']:.1f}/10")
            else:
                models = available_models[:1]  # Usar o primeiro disponível
                print(f"⚠️  Modelo recomendado ({recommendation['model']}) não disponível")
                print(f"   Usando: {models[0]}")
        
        model = models[0]
        
        # Processar cada programa com o modelo único
        for i, program in enumerate(programs, 1):
            print(f"\n[{i}/{len(programs)}] Analisando {program.name} com {model}...")
            
            result = analyze_program_with_model(
                program, books, model, args.output, config_manager, 
                is_multi_model, args.prompt_set, cost_calculator, rag_integration
            )
            
            all_results.append(result)
            
            if result['success']:
                print(f"   ✅ Sucesso - {result['tokens_used']:,} tokens - {result['analysis_time']:.1f}s")
            else:
                print(f"   ❌ Falha: {result['error']}")
    
    else:
        # Múltiplos modelos - processar cada programa com cada modelo
        for i, program in enumerate(programs, 1):
            print(f"\n[{i}/{len(programs)}] Analisando {program.name}...")
            
            for j, model in enumerate(models, 1):
                print(f"  [{j}/{len(models)}] Modelo: {model}")
                
                result = analyze_program_with_model(
                    program, books, model, args.output, config_manager, 
                    is_multi_model, args.prompt_set, cost_calculator, rag_integration
                )
                
                all_results.append(result)
                
                if result['success']:
                    print(f"     ✅ Sucesso - {result['tokens_used']:,} tokens - {result['analysis_time']:.1f}s")
                else:
                    print(f"     ❌ Falha: {result['error']}")
    
    # Gerar relatório comparativo se múltiplos modelos
    if is_multi_model:
        generate_comparative_report(programs, all_results, args.output)
    
    # Gerar relatórios HTML se solicitado
    if hasattr(args, 'pdf') and args.pdf:
        print(f"\n📄 Gerando relatórios HTML...")
        generate_html_reports(args.output, programs, all_results, is_multi_model)
    
    # Estatísticas finais
    total_time = time.time() - start_time
    successful_analyses = [r for r in all_results if r['success']]
    failed_analyses = [r for r in all_results if not r['success']]
    total_tokens = sum(r.get('tokens_used', 0) for r in successful_analyses)
    
    print(f"\n" + "=" * 60)
    print(f"PROCESSAMENTO CONCLUÍDO")
    print(f"Programas processados: {len(programs)}")
    print(f"Modelos utilizados: {len(models)}")
    print(f"Análises bem-sucedidas: {len(successful_analyses)}")
    print(f"Análises falharam: {len(failed_analyses)}")
    print(f"Total de tokens utilizados: {total_tokens:,}")
    print(f"Tempo total de processamento: {total_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    
    if failed_analyses:
        print(f"\n⚠️  Análises que falharam:")
        for result in failed_analyses:
            print(f"   - {result['program_name']} ({result['model']}): {result['error']}")

def generate_comparative_report(programs: List[CobolProgram], all_results: List[Dict[str, Any]], output_dir: str) -> None:
    """Gera relatório comparativo entre modelos."""
    logger = logging.getLogger(__name__)
    
    try:
        report_path = os.path.join(output_dir, "relatorio_comparativo_modelos.md")
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("# Relatório Comparativo de Modelos\n\n")
            f.write(f"**Data da Análise**: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")
            
            # Agrupar resultados por modelo
            models_results = {}
            for result in all_results:
                model = result['model']
                if model not in models_results:
                    models_results[model] = []
                models_results[model].append(result)
            
            # Estatísticas por modelo
            f.write("## Estatísticas por Modelo\n\n")
            f.write("| Modelo | Sucessos | Falhas | Taxa de Sucesso | Tokens Médios | Tempo Médio |\n")
            f.write("|--------|----------|--------|-----------------|---------------|-------------|\n")
            
            for model, results in models_results.items():
                successful = [r for r in results if r['success']]
                failed = [r for r in results if not r['success']]
                success_rate = len(successful) / len(results) * 100 if results else 0
                avg_tokens = sum(r.get('tokens_used', 0) for r in successful) / len(successful) if successful else 0
                avg_time = sum(r.get('analysis_time', 0) for r in successful) / len(successful) if successful else 0
                
                f.write(f"| {model} | {len(successful)} | {len(failed)} | {success_rate:.1f}% | {avg_tokens:,.0f} | {avg_time:.1f}s |\n")
            
            # Detalhes por programa
            f.write("\n## Detalhes por Programa\n\n")
            for program in programs:
                f.write(f"### {program.name}\n\n")
                program_results = [r for r in all_results if r['program_name'] == program.name]
                
                for result in program_results:
                    status = "✅ Sucesso" if result['success'] else "❌ Falha"
                    f.write(f"- **{result['model']}**: {status}")
                    if result['success']:
                        f.write(f" - {result['tokens_used']:,} tokens - {result['analysis_time']:.1f}s")
                    else:
                        f.write(f" - Erro: {result['error']}")
                    f.write("\n")
                f.write("\n")
        
        logger.info(f"Relatório comparativo gerado: {report_path}")
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatório comparativo: {e}")

def generate_html_reports(output_dir: str, programs: List, all_results: List[Dict], is_multi_model: bool) -> None:
    """Gera relatórios HTML/PDF a partir dos arquivos Markdown."""
    try:
        from src.utils.html_generator import HTMLReportGenerator
        
        html_generator = HTMLReportGenerator()
        html_files_generated = []
        
        if is_multi_model:
            # Para múltiplos modelos, processar cada diretório de modelo
            for result in all_results:
                if result['success']:
                    model_dir = result['output_dir']
                    md_files = [f for f in os.listdir(model_dir) if f.endswith('_analise_funcional.md')]
                    
                    for md_file in md_files:
                        md_path = os.path.join(model_dir, md_file)
                        
                        # Gerar HTML (passando diretório, não arquivo)
                        html_file = html_generator.generate_html_report(md_path, model_dir)
                        html_files_generated.append(html_file)
                        print(f"  HTML gerado: {html_file}")
        else:
            # Para modelo único, processar arquivos na raiz
            md_files = [f for f in os.listdir(output_dir) if f.endswith('_analise_funcional.md')]
            
            for md_file in md_files:
                md_path = os.path.join(output_dir, md_file)
                
                # Gerar HTML (passando diretório, não arquivo)
                html_file = html_generator.generate_html_report(md_path, output_dir)
                html_files_generated.append(html_file)
                print(f"  HTML gerado: {html_file}")
        
        print(f"  Total de arquivos HTML gerados: {len(html_files_generated)}")
        
    except Exception as e:
        print(f"  Erro ao gerar relatórios HTML: {e}")

# Funções auxiliares para modos especiais (stubs para compatibilidade)
def process_consolidated_analysis(args, config_manager, cost_calculator, parser, models):
    """Stub para análise consolidada"""
    print("Modo de análise consolidada não implementado nesta versão")

def process_consolidated_report(args, config_manager, cost_calculator, parser, models):
    """Stub para relatório consolidado"""
    print("Modo de relatório consolidado não implementado nesta versão")

def process_expert_analysis(args, config_manager, cost_calculator, parser, models):
    """Stub para análise especializada"""
    print("Modo de análise especializada não implementado nesta versão")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='COBOL to Docs - Análise e Documentação de Programas COBOL')
    
    # Argumentos principais
    parser.add_argument('--fontes', required=True, help='Arquivo contendo os programas COBOL')
    parser.add_argument('--books', help='Arquivo contendo os copybooks')
    parser.add_argument('--output', default='output', help='Diretório de saída')
    parser.add_argument('--models', help='Modelos a usar (string ou JSON)')
    parser.add_argument('--prompt-set', default='enhanced', choices=['basic', 'enhanced'], 
                        help='Conjunto de prompts a usar')
    parser.add_argument('--log-level', default='INFO', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                        help='Nível de logging')
    parser.add_argument('--pdf', action='store_true', help='Gerar relatórios HTML/PDF')
    parser.add_argument('--status', action='store_true', help='Verificar status dos providers')
    
    # Modos especiais
    parser.add_argument('--consolidado', action='store_true', 
                        help='Análise consolidada sistêmica de todos os programas')
    parser.add_argument('--relatorio-unico', action='store_true',
                        help='Gerar relatório único consolidado')
    parser.add_argument('--analise-especialista', action='store_true',
                        help='Análise especializada com foco em arquitetura')
    parser.add_argument('--procedure-detalhada', action='store_true',
                        help='Análise detalhada da PROCEDURE DIVISION')
    parser.add_argument('--modernizacao', action='store_true',
                        help='Análise focada em oportunidades de modernização')
    
    # Funcionalidades avançadas
    parser.add_argument('--auto-model', action='store_true', 
                        help='Seleção automática de modelo baseada na complexidade do código')
    parser.add_argument('--model-comparison', action='store_true',
                        help='Exibir comparação de adequação de modelos para o código')
    parser.add_argument('--deep-analysis', action='store_true',
                        help='Análise detalhada de regras de negócio com valores específicos')
    parser.add_argument('--extract-formulas', action='store_true',
                        help='Extrair fórmulas matemáticas e cálculos específicos do código')
    parser.add_argument('--advanced-analysis', action='store_true',
                        help='Executar análise avançada com relatório consolidado HTML profissional')
    
    args = parser.parse_args()
    
    # Configurar logging
    setup_logging(args.log_level)
    logger = logging.getLogger(__name__)
    
    try:
        # Carregar configuração
        config_manager = ConfigManager()
        
        # Inicializar sistema RAG aprimorado
        rag_integration = EnhancedRAGIntegration(config_manager.config)
        if rag_integration.is_enabled():
            rag_stats = rag_integration.get_rag_statistics()
            logger.info(f"Sistema RAG inicializado: {rag_stats['total_items']} itens na base de conhecimento")
        else:
            logger.info("Sistema RAG desabilitado")
        
        # Inicializar calculadora de custos
        cost_calculator = CostCalculator()
        
        # Verificar status se solicitado
        if args.status:
            provider_manager = EnhancedProviderManager(config_manager.config)
            print("=== STATUS DOS PROVEDORES ===")
            # Verificar status de cada provider
            providers = ['luzia', 'enhanced_mock', 'basic']
            for name in providers:
                try:
                    available = provider_manager.get_provider_status(name)
                    print(f"  {name}: {'Disponível' if available else 'Indisponível'}")
                except Exception as e:
                    print(f"  {name}: Erro - {e}")
            sys.exit(0)
        
        # Validar argumentos
        if not args.fontes:
            print("Erro: --fontes é obrigatório")
            parser.print_help()
            sys.exit(0)
        
        if not os.path.exists(args.fontes):
            print(f"Erro: Arquivo não encontrado: {args.fontes}")
            sys.exit(0)
        
        # Processar arquivos COBOL
        process_cobol_files(args, config_manager, cost_calculator, rag_integration)
        
        # Finalizar sessão RAG e gerar relatório
        if rag_integration.is_enabled():
            try:
                rag_report = rag_integration.finalize_session()
                if rag_report:
                    logger.info(f"Relatório de uso do RAG gerado: {rag_report}")
                    print(f"\n=== RELATÓRIO RAG DISPONÍVEL ===")
                    print(f"Arquivo: {rag_report}")
                    
                    # Exibir resumo da sessão
                    session_summary = rag_integration.get_session_summary()
                    if session_summary:
                        print(f"Operações RAG realizadas: {session_summary.get('total_operations', 0)}")
                        print(f"Programas analisados: {len(session_summary.get('programs_analyzed', []))}")
                        print(f"Itens de conhecimento utilizados: {session_summary.get('knowledge_items_used', 0)}")
                        print(f"Novos itens adicionados: {session_summary.get('new_items_added', 0)}")
                        print("=" * 40)
            except Exception as e:
                logger.warning(f"Erro ao finalizar sessão RAG: {e}")
        
    except KeyboardInterrupt:
        print("\nProcessamento interrompido pelo usuário.")
    except Exception as e:
        import traceback
        logger.error(f"Erro fatal: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        print(f"Erro: {str(e)}")
        print("Traceback completo:")
        traceback.print_exc()
