# Compatibilidade Multiplataforma - COBOL to Docs v1.1

**Autor:** Carlos Morais  
**Versão:** 1.0  
**Data:** Setembro 2025

## Resumo de Compatibilidade

**SIM!** O COBOL to Docs v1.1 foi desenvolvido para ser **100% multiplataforma** e funciona em qualquer sistema operacional com Python 3.11+, incluindo todos os tipos de terminal.

## Sistemas Operacionais Suportados

###  Linux
- **Ubuntu 18.04+**
- **CentOS 7+**
- **Red Hat Enterprise Linux 7+**
- **Debian 9+**
- **Fedora 30+**
- **SUSE Linux Enterprise 12+**
- **Arch Linux**
- **Qualquer distribuição com Python 3.11+**

###  Windows
- **Windows 10**
- **Windows 11**
- **Windows Server 2019+**
- **WSL (Windows Subsystem for Linux)**
- **WSL2**

###  macOS
- **macOS 10.15 (Catalina)+**
- **macOS 11 (Big Sur)**
- **macOS 12 (Monterey)**
- **macOS 13 (Ventura)**
- **macOS 14 (Sonoma)**

## Terminais Suportados

### Windows
- **PowerShell** (5.1 e 7+)
- **Command Prompt (cmd)**
- **Windows Terminal**
- **Git Bash**
- **WSL Bash**
- **WSL2 Bash**

### Linux
- **Bash**
- **Zsh**
- **Fish**
- **Dash**
- **Tcsh**
- **Ksh**

### macOS
- **Terminal.app**
- **iTerm2**
- **Zsh (padrão)**
- **Bash**
- **Fish**

## Instalação por Plataforma

### Windows (PowerShell)

#### 1. Verificar Python
```powershell
python --version
# ou
python3 --version
```

#### 2. Instalar Dependências
```powershell
pip install pyyaml requests beautifulsoup4 markdown
```

#### 3. Extrair e Usar
```powershell
# Extrair (se tiver tar)
tar -xzf cobol_to_docs_v1.1_FINAL.tar.gz

# Ou usar 7-Zip, WinRAR, etc.
# Navegar para pasta
cd cobol_to_docs_v1

# Testar
python main.py --status
```

### Windows (Command Prompt)

```cmd
REM Verificar Python
python --version

REM Instalar dependências
pip install pyyaml requests beautifulsoup4 markdown

REM Usar sistema
cd cobol_to_docs_v1
python main.py --status
```

### Linux (Bash/Zsh/Fish)

```bash
# Verificar Python
python3 --version

# Instalar dependências
pip3 install pyyaml requests beautifulsoup4 markdown
# ou
sudo apt install python3-yaml python3-requests python3-bs4 python3-markdown

# Extrair e usar
tar -xzf cobol_to_docs_v1.1_FINAL.tar.gz
cd cobol_to_docs_v1
python3 main.py --status
```

### macOS (Terminal/iTerm2)

```bash
# Verificar Python (pode precisar instalar)
python3 --version

# Instalar Python se necessário (via Homebrew)
brew install python@3.11

# Instalar dependências
pip3 install pyyaml requests beautifulsoup4 markdown

# Extrair e usar
tar -xzf cobol_to_docs_v1.1_FINAL.tar.gz
cd cobol_to_docs_v1
python3 main.py --status
```

## Comandos Universais

### Análise Básica (Funciona em Todos os Terminais)

**Linux/macOS:**
```bash
python3 main.py --fontes examples/fontes.txt
```

**Windows:**
```powershell
python main.py --fontes examples/fontes.txt
```

### Geração de Prompts (Universal)

**Linux/macOS:**
```bash
python3 generate_prompts.py --interactive
```

**Windows:**
```powershell
python generate_prompts.py --interactive
```

### Análise Multi-Modelo (Universal)

**Linux/macOS:**
```bash
python3 main.py --fontes examples/fontes.txt --models '["aws-claude-3.7","gpt-4"]'
```

**Windows PowerShell:**
```powershell
python main.py --fontes examples/fontes.txt --models '["aws-claude-3.7","gpt-4"]'
```

**Windows CMD:**
```cmd
python main.py --fontes examples/fontes.txt --models "[\"aws-claude-3.7\",\"gpt-4\"]"
```

## Diferenças por Plataforma

### Separadores de Caminho
O sistema usa `os.path.join()` e `pathlib.Path()`, então funciona automaticamente:
- **Windows**: `output\programa\documentacao.md`
- **Linux/macOS**: `output/programa/documentacao.md`

### Encoding de Arquivos
O sistema detecta automaticamente:
- **UTF-8** (padrão)
- **Latin-1** (fallback para arquivos antigos)
- **Windows-1252** (Windows)

### Variáveis de Ambiente

**Linux/macOS:**
```bash
export LUZIA_CLIENT_ID='seu_id'
export LUZIA_CLIENT_SECRET='seu_secret'
```

**Windows PowerShell:**
```powershell
$env:LUZIA_CLIENT_ID='seu_id'
$env:LUZIA_CLIENT_SECRET='seu_secret'
```

**Windows CMD:**
```cmd
set LUZIA_CLIENT_ID=seu_id
set LUZIA_CLIENT_SECRET=seu_secret
```

## Instalação Automática por Plataforma

### Script Linux/macOS (install.sh)
```bash
#!/bin/bash
echo "Instalando COBOL to Docs v1.1..."

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo "Python 3 não encontrado. Instale Python 3.11+"
    exit 1
fi

# Instalar dependências
pip3 install pyyaml requests beautifulsoup4 markdown

# Extrair se necessário
if [ -f "cobol_to_docs_v1.1_FINAL.tar.gz" ]; then
    tar -xzf cobol_to_docs_v1.1_FINAL.tar.gz
fi

cd cobol_to_docs_v1
chmod +x main.py generate_prompts.py

echo "Testando instalação..."
python3 main.py --status

echo "Instalação concluída!"
echo "Use: python3 main.py --fontes examples/fontes.txt"
```

### Script Windows (install.ps1)
```powershell
Write-Host "Instalando COBOL to Docs v1.1..."

# Verificar Python
try {
    $pythonVersion = python --version
    Write-Host "Python encontrado: $pythonVersion"
} catch {
    Write-Host "Python não encontrado. Instale Python 3.11+"
    exit 1
}

# Instalar dependências
pip install pyyaml requests beautifulsoup4 markdown

# Extrair se necessário
if (Test-Path "cobol_to_docs_v1.1_FINAL.tar.gz") {
    tar -xzf cobol_to_docs_v1.1_FINAL.tar.gz
}

Set-Location cobol_to_docs_v1

Write-Host "Testando instalação..."
python main.py --status

Write-Host "Instalação concluída!"
Write-Host "Use: python main.py --fontes examples/fontes.txt"
```

## Testes de Compatibilidade

### Teste Rápido (Qualquer Plataforma)

**1. Verificar Python:**
```bash
python3 --version  # Linux/macOS
python --version   # Windows
```

**2. Testar Sistema:**
```bash
python3 main.py --status  # Linux/macOS
python main.py --status   # Windows
```

**3. Executar Exemplo:**
```bash
python3 main.py --fontes examples/fontes.txt  # Linux/macOS
python main.py --fontes examples/fontes.txt   # Windows
```

### Teste Completo

```bash
# 1. Status
python3 main.py --status

# 2. Análise básica
python3 main.py --fontes examples/fontes.txt

# 3. Geração de prompts
python3 generate_prompts.py --input examples/requisitos_exemplo.txt

# 4. Análise com prompts personalizados
python3 main.py --fontes examples/fontes.txt --prompts-file requisitos_exemplo_prompts.yaml

# 5. Análise multi-modelo (se tiver credenciais)
python3 main.py --fontes examples/fontes.txt --models '["aws-claude-3.7","enhanced_mock"]'
```

## Solução de Problemas por Plataforma

### Windows

**Problema: "python não é reconhecido"**
```powershell
# Adicionar Python ao PATH ou usar:
py -3 main.py --status
```

**Problema: Encoding de arquivos**
```powershell
# O sistema detecta automaticamente, mas se necessário:
chcp 65001  # UTF-8
```

### Linux

**Problema: Permissões**
```bash
chmod +x main.py generate_prompts.py
```

**Problema: Python não encontrado**
```bash
# Ubuntu/Debian
sudo apt install python3.11 python3-pip

# CentOS/RHEL
sudo yum install python3.11 python3-pip
```

### macOS

**Problema: Python não encontrado**
```bash
# Instalar via Homebrew
brew install python@3.11

# Ou usar pyenv
pyenv install 3.11.0
pyenv global 3.11.0
```

## Características Multiplataforma

###  Funciona Nativamente
- **Paths**: Usa `pathlib` para compatibilidade
- **Encoding**: Detecção automática UTF-8/Latin-1
- **Logs**: Formato universal
- **Configuração**: YAML multiplataforma

###  Sem Dependências do Sistema
- **Não usa comandos específicos** do OS
- **Bibliotecas Python puras**
- **Sem binários compilados**
- **Sem dependências nativas**

###  Interface Consistente
- **Mesmos argumentos** em todas as plataformas
- **Mesma saída** independente do terminal
- **Mesmos arquivos** de configuração
- **Mesmo comportamento** em todos os sistemas

## Distribuição Universal

### Pacote Único
- **Um arquivo .tar.gz** funciona em todas as plataformas
- **Sem modificações** necessárias por plataforma
- **Mesma estrutura** de diretórios
- **Mesma documentação**

### Instalação Simples
1. **Extrair** arquivo
2. **Instalar** dependências Python
3. **Executar** diretamente

### Uso Imediato
- **Sem compilação**
- **Sem configuração específica**
- **Funciona imediatamente** após extração

---

## Resumo Final

**COBOL to Docs v1.1 é 100% multiplataforma:**

-  **Windows**: PowerShell, CMD, Windows Terminal, Git Bash, WSL
-  **Linux**: Bash, Zsh, Fish, qualquer distribuição
-  **macOS**: Terminal, iTerm2, qualquer shell

**Instalação universal:**
1. Python 3.11+
2. Extrair arquivo
3. Instalar dependências: `pip install pyyaml requests beautifulsoup4 markdown`
4. Usar: `python main.py --fontes examples/fontes.txt`

**Desenvolvido por Carlos Morais para máxima compatibilidade!**
