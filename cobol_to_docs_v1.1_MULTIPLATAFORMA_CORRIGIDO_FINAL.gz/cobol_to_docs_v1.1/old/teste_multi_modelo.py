#!/usr/bin/env python3
"""
Teste da funcionalidade multi-modelo do COBOL AI Engine
Demonstra como o sistema funciona com múltiplos modelos
"""

import os
import sys
import tempfile
from pathlib import Path

def criar_programa_teste():
    """Criar um programa COBOL simples para teste"""
    programa = """       IDENTIFICATION DIVISION.
       PROGRAM-ID. TESTE-MULTI.
       AUTHOR. SISTEMA-TESTE.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-CONTADOR PIC 9(3) VALUE 0.
       01 WS-RESULTADO PIC 9(5) VALUE 0.
       
       PROCEDURE DIVISION.
       MAIN-PROCESS.
           DISPLAY 'TESTE MULTI-MODELO'.
           PERFORM VARYING WS-CONTADOR FROM 1 BY 1 UNTIL WS-CONTADOR > 10
               COMPUTE WS-RESULTADO = WS-RESULTADO + WS-CONTADOR
           END-PERFORM.
           DISPLAY 'RESULTADO: ' WS-RESULTADO.
           STOP RUN.
"""
    return programa

def testar_funcionalidade_multi_modelo():
    """Testar como funciona a funcionalidade multi-modelo"""
    
    print("🧪 TESTE DA FUNCIONALIDADE MULTI-MODELO")
    print("=" * 60)
    print()
    
    # Verificar se o main.py existe
    main_path = Path("main.py")
    if not main_path.exists():
        print("❌ Arquivo main.py não encontrado")
        return False
    
    print("✅ Sistema COBOL AI Engine encontrado")
    print()
    
    # Criar arquivo temporário com programa COBOL
    programa_cobol = criar_programa_teste()
    
    with tempfile.NamedTemporaryFile(mode='w', suffix='.cbl', delete=False, encoding='utf-8') as f:
        f.write(programa_cobol)
        temp_file = f.name
    
    print(f"✅ Programa COBOL de teste criado: {temp_file}")
    print()
    
    try:
        # Demonstrar diferentes cenários de uso
        print("📋 CENÁRIOS DE USO MULTI-MODELO:")
        print()
        
        # Cenário 1: Modelo único
        print("1️⃣ MODELO ÚNICO (comportamento padrão)")
        comando1 = f"python3 main.py --fontes {temp_file} --models 'aws-claude-3.7' --output /tmp/teste_single"
        print(f"Comando: {comando1}")
        print("Resultado: Análise com um modelo apenas, estrutura simples de diretórios")
        print()
        
        # Cenário 2: Múltiplos modelos
        print("2️⃣ MÚLTIPLOS MODELOS (funcionalidade multi-modelo)")
        comando2 = f'python3 main.py --fontes {temp_file} --models \'["aws-claude-3.7","gpt-4"]\' --output /tmp/teste_multi'
        print(f"Comando: {comando2}")
        print("Resultado:")
        print("  - Cria diretório separado para cada modelo:")
        print("    /tmp/teste_multi/model_aws-claude-3.7/")
        print("    /tmp/teste_multi/model_gpt-4/")
        print("  - Gera relatório comparativo: relatorio_comparativo_modelos.md")
        print("  - Análise completa com cada modelo")
        print()
        
        # Cenário 3: Múltiplos modelos com diferentes providers
        print("3️⃣ MÚLTIPLOS PROVIDERS")
        comando3 = f'python3 main.py --fontes {temp_file} --models \'["luzia","openai"]\' --output /tmp/teste_providers'
        print(f"Comando: {comando3}")
        print("Resultado: Usa diferentes providers para comparação")
        print()
        
        print("🔍 COMO FUNCIONA INTERNAMENTE:")
        print()
        print("Quando você passa múltiplos modelos:")
        print("1. O sistema detecta que é análise multi-modelo")
        print("2. Para cada programa COBOL:")
        print("   - Executa análise com CADA modelo especificado")
        print("   - Salva resultados em diretórios separados")
        print("   - Mantém logs independentes")
        print("3. Gera relatório comparativo final")
        print("4. Calcula estatísticas por modelo")
        print()
        
        print("📊 RELATÓRIO COMPARATIVO INCLUI:")
        print("- Taxa de sucesso por modelo")
        print("- Tokens utilizados por modelo")
        print("- Tempo de processamento")
        print("- Comparação qualitativa das análises")
        print("- Estatísticas detalhadas")
        print()
        
        print("📁 ESTRUTURA DE SAÍDA MULTI-MODELO:")
        print("output/")
        print("├── model_aws-claude-3.7/")
        print("│   ├── TESTE-MULTI_analise.md")
        print("│   ├── TESTE-MULTI_analise.html")
        print("│   └── logs/")
        print("├── model_gpt-4/")
        print("│   ├── TESTE-MULTI_analise.md")
        print("│   ├── TESTE-MULTI_analise.html")
        print("│   └── logs/")
        print("└── relatorio_comparativo_modelos.md")
        print()
        
        print("⚡ VANTAGENS DA FUNCIONALIDADE MULTI-MODELO:")
        print("✅ Comparação direta entre diferentes modelos")
        print("✅ Validação cruzada de análises")
        print("✅ Identificação do melhor modelo para cada tipo de código")
        print("✅ Relatórios independentes e comparativos")
        print("✅ Estatísticas detalhadas de performance")
        print("✅ Estrutura organizada de saída")
        
        return True
        
    finally:
        # Limpar arquivo temporário
        try:
            os.unlink(temp_file)
            print(f"🧹 Arquivo temporário removido: {temp_file}")
        except:
            pass

def verificar_configuracao_modelos():
    """Verificar quais modelos estão configurados"""
    print()
    print("🔧 VERIFICANDO CONFIGURAÇÃO DE MODELOS:")
    print()
    
    config_path = Path("config/config.yaml")
    if config_path.exists():
        print("✅ Arquivo de configuração encontrado")
        
        try:
            import yaml
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            providers = config.get('providers', {})
            modelos_disponiveis = []
            
            for provider_name, provider_config in providers.items():
                if provider_config.get('enabled', False):
                    models = provider_config.get('models', {})
                    for model_key in models.keys():
                        modelos_disponiveis.append(f"{provider_name}:{model_key}")
            
            print(f"✅ Modelos configurados: {len(modelos_disponiveis)}")
            for modelo in modelos_disponiveis:
                print(f"  - {modelo}")
            
            print()
            print("💡 EXEMPLO DE USO COM MODELOS CONFIGURADOS:")
            if len(modelos_disponiveis) >= 2:
                modelo1 = modelos_disponiveis[0].split(':')[1]
                modelo2 = modelos_disponiveis[1].split(':')[1] if len(modelos_disponiveis) > 1 else modelo1
                print(f'python3 main.py --fontes programa.cbl --models \'["{modelo1}","{modelo2}"]\'')
            else:
                print("Configure múltiplos modelos no config.yaml para usar multi-modelo")
                
        except Exception as e:
            print(f"⚠️  Erro ao ler configuração: {e}")
    else:
        print("❌ Arquivo de configuração não encontrado")

def main():
    """Executar teste da funcionalidade multi-modelo"""
    os.chdir(Path(__file__).parent)
    
    success = testar_funcionalidade_multi_modelo()
    verificar_configuracao_modelos()
    
    print()
    print("=" * 60)
    print("RESUMO DA FUNCIONALIDADE MULTI-MODELO")
    print("=" * 60)
    
    if success:
        print("✅ FUNCIONALIDADE MULTI-MODELO DISPONÍVEL")
        print()
        print("🎯 QUANDO USAR:")
        print("- Comparar qualidade de análise entre modelos")
        print("- Validar resultados com múltiplas IAs")
        print("- Encontrar o melhor modelo para seu tipo de código")
        print("- Gerar relatórios comparativos detalhados")
        print()
        print("📝 FORMATO DO ARGUMENTO --models:")
        print('  Modelo único: --models "aws-claude-3.7"')
        print('  Múltiplos: --models \'["aws-claude-3.7","gpt-4","claude-3"]\'')
        print()
        print("🚀 SISTEMA PRONTO PARA USO MULTI-MODELO!")
    else:
        print("❌ Problemas detectados na funcionalidade multi-modelo")

if __name__ == "__main__":
    main()
