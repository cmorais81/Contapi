"""
COBOL AI Engine v2.6.0 - Prompt Manager
Gerenciador de prompts customizáveis com todos os métodos implementados.
"""

import os
import yaml
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime


class PromptManager:
    """
    Gerenciador de prompts customizáveis para análise COBOL.
    Implementa TODOS os métodos necessários.
    """
    
    def __init__(self, config_file: str = "config/prompts.yaml"):
        """Inicializa o gerenciador de prompts."""
        self.logger = logging.getLogger(__name__)
        self.config_file = config_file
        self.config = {}
        self.load_config()
        self.logger.info(f"Configuração de prompts carregada: {config_file}")
        self.logger.info("Prompt Manager inicializado com configuração customizável")
    
    def load_config(self) -> None:
        """Carrega configuração de prompts do arquivo YAML."""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    self.config = yaml.safe_load(f) or {}
            else:
                self.config = self._get_default_config()
                self.save_config()
        except Exception as e:
            self.logger.error(f"Erro ao carregar configuração de prompts: {e}")
            self.config = self._get_default_config()
    
    def save_config(self) -> None:
        """Salva configuração atual no arquivo YAML."""
        try:
            os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
            with open(self.config_file, 'w', encoding='utf-8') as f:
                yaml.dump(self.config, f, default_flow_style=False, 
                         allow_unicode=True, indent=2)
        except Exception as e:
            self.logger.error(f"Erro ao salvar configuração de prompts: {e}")
    
    def get_analysis_questions(self) -> Dict[str, Dict[str, Any]]:
        """
        Retorna todas as perguntas de análise configuradas.
        MÉTODO IMPLEMENTADO - corrige erro da imagem.
        """
        return self.config.get('analysis_questions', {})
    
    def get_functional_question(self) -> str:
        """Retorna a pergunta funcional atual."""
        questions = self.get_analysis_questions()
        functional = questions.get('functional', {})
        return functional.get('question', "O que este programa faz funcionalmente?")
    
    def update_functional_question(self, new_question: str) -> bool:
        """Atualiza a pergunta funcional."""
        try:
            if 'analysis_questions' not in self.config:
                self.config['analysis_questions'] = {}
            
            if 'functional' not in self.config['analysis_questions']:
                self.config['analysis_questions']['functional'] = {}
            
            self.config['analysis_questions']['functional']['question'] = new_question
            self.save_config()
            
            self.logger.info(f"Pergunta funcional atualizada: {new_question}")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao atualizar pergunta funcional: {e}")
            return False
    
    def generate_base_prompt(self, program_name: str, program_code: str, 
                           context: Dict[str, Any] = None) -> str:
        """Gera prompt base para análise."""
        context = context or {}
        
        # Template base
        base_template = self.config.get('base_template', {})
        template = base_template.get('template', self._get_default_base_template())
        
        # Substituições
        substitutions = {
            'program_name': program_name,
            'program_code': program_code,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'books_count': len(context.get('books', [])),
            'context_info': self._format_context(context)
        }
        
        # Aplicar substituições
        prompt = template
        for key, value in substitutions.items():
            prompt = prompt.replace(f'{{{key}}}', str(value))
        
        return prompt
    
    def generate_phase_prompt(self, base_prompt: str, phase: str, 
                            question_data: Dict[str, Any]) -> str:
        """Gera prompt específico para uma fase."""
        phase_template = self.config.get('phase_templates', {}).get(
            phase, self._get_default_phase_template()
        )
        
        # Substituições específicas da fase
        substitutions = {
            'base_prompt': base_prompt,
            'question': question_data.get('question', ''),
            'focus': question_data.get('focus', ''),
            'context': question_data.get('context', ''),
            'phase': phase
        }
        
        prompt = phase_template
        for key, value in substitutions.items():
            prompt = prompt.replace(f'{{{key}}}', str(value))
        
        return prompt
    
    def get_questions_by_priority(self) -> List[tuple]:
        """Retorna perguntas ordenadas por prioridade."""
        questions = self.get_analysis_questions()
        
        # Ordenar por prioridade
        sorted_questions = sorted(
            questions.items(),
            key=lambda x: x[1].get('priority', 999)
        )
        
        return sorted_questions
    
    def get_required_questions(self) -> Dict[str, Dict[str, Any]]:
        """Retorna apenas perguntas obrigatórias."""
        questions = self.get_analysis_questions()
        return {
            key: value for key, value in questions.items()
            if value.get('required', False)
        }
    
    def get_optional_questions(self) -> Dict[str, Dict[str, Any]]:
        """Retorna apenas perguntas opcionais."""
        questions = self.get_analysis_questions()
        return {
            key: value for key, value in questions.items()
            if not value.get('required', False)
        }
    
    def add_custom_question(self, key: str, question: str, 
                          priority: int = 10, required: bool = False,
                          context: str = "") -> bool:
        """Adiciona uma pergunta customizada."""
        try:
            if 'analysis_questions' not in self.config:
                self.config['analysis_questions'] = {}
            
            self.config['analysis_questions'][key] = {
                'question': question,
                'priority': priority,
                'required': required,
                'context': context,
                'added_at': datetime.now().isoformat()
            }
            
            self.save_config()
            self.logger.info(f"Pergunta customizada adicionada: {key}")
            return True
        except Exception as e:
            self.logger.error(f"Erro ao adicionar pergunta customizada: {e}")
            return False
    
    def remove_question(self, key: str) -> bool:
        """Remove uma pergunta."""
        try:
            questions = self.config.get('analysis_questions', {})
            if key in questions:
                del questions[key]
                self.save_config()
                self.logger.info(f"Pergunta removida: {key}")
                return True
            return False
        except Exception as e:
            self.logger.error(f"Erro ao remover pergunta: {e}")
            return False
    
    def get_context_templates(self) -> Dict[str, str]:
        """Retorna templates de contexto por tipo de programa."""
        return self.config.get('context_templates', {})
    
    def detect_program_type(self, program_name: str, program_code: str) -> str:
        """Detecta tipo de programa baseado em padrões."""
        patterns = self.config.get('program_patterns', {})
        
        for program_type, pattern_data in patterns.items():
            name_patterns = pattern_data.get('name_patterns', [])
            code_patterns = pattern_data.get('code_patterns', [])
            
            # Verificar padrões no nome
            for pattern in name_patterns:
                if pattern.lower() in program_name.lower():
                    return program_type
            
            # Verificar padrões no código
            for pattern in code_patterns:
                if pattern.upper() in program_code.upper():
                    return program_type
        
        return 'default'
    
    def get_program_context(self, program_name: str, program_code: str) -> str:
        """Retorna contexto específico para o tipo de programa."""
        program_type = self.detect_program_type(program_name, program_code)
        templates = self.get_context_templates()
        return templates.get(program_type, templates.get('default', ''))
    
    def _format_context(self, context: Dict[str, Any]) -> str:
        """Formata informações de contexto."""
        if not context:
            return "Nenhum contexto adicional fornecido."
        
        formatted = []
        
        if 'books' in context:
            books = context['books']
            if books:
                formatted.append(f"Copybooks relacionados: {len(books)} encontrados")
                if len(books) <= 5:
                    formatted.append(f"Nomes: {', '.join(books)}")
        
        if 'related_programs' in context:
            related = context['related_programs']
            if related:
                formatted.append(f"Programas relacionados: {len(related)}")
        
        return "; ".join(formatted) if formatted else "Contexto básico de análise."
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão."""
        return {
            'version': '2.6.0',
            'analysis_questions': {
                'functional': {
                    'question': 'O que este programa faz funcionalmente?',
                    'priority': 1,
                    'required': True,
                    'focus': 'Explicação clara da função principal do programa',
                    'context': 'Análise funcional detalhada'
                },
                'technical': {
                    'question': 'Qual é a estrutura técnica e componentes principais?',
                    'priority': 2,
                    'required': True,
                    'focus': 'Divisões, seções, arquivos e variáveis',
                    'context': 'Análise técnica detalhada'
                },
                'business_rules': {
                    'question': 'Quais regras de negócio estão implementadas?',
                    'priority': 3,
                    'required': True,
                    'focus': 'Lógica de negócio e validações',
                    'context': 'Regras e validações de negócio'
                },
                'code_snippets': {
                    'question': 'Quais são os trechos de código mais relevantes?',
                    'priority': 4,
                    'required': False,
                    'focus': 'Trechos importantes do código COBOL',
                    'context': 'Exemplos de código relevante'
                },
                'relationships': {
                    'question': 'Como este programa se relaciona com outros sistemas?',
                    'priority': 5,
                    'required': False,
                    'focus': 'Interfaces e relacionamentos',
                    'context': 'Análise de relacionamentos'
                }
            },
            'base_template': {
                'template': '''Analise o seguinte programa COBOL:

Nome do programa: {program_name}
Timestamp da análise: {timestamp}
Contexto: {context_info}

Código COBOL:
{program_code}

Por favor, forneça uma análise completa e detalhada.'''
            },
            'phase_templates': {
                'default': '''Baseado no seguinte programa COBOL:

{base_prompt}

Foque especificamente em: {question}

{context}'''
            },
            'context_templates': {
                'data_processing': 'Programa de processamento de dados corporativo',
                'report_programs': 'Programa de geração de relatórios',
                'batch_programs': 'Programa de processamento em lote',
                'online_programs': 'Programa de transação online',
                'interface_programs': 'Programa de interface/API',
                'utility_programs': 'Programa utilitário/ferramenta',
                'default': 'Programa COBOL genérico'
            },
            'program_patterns': {
                'data_processing': {
                    'name_patterns': ['proc', 'process', 'data'],
                    'code_patterns': ['SELECT', 'FD', 'SORT']
                },
                'report_programs': {
                    'name_patterns': ['rel', 'rpt', 'rep', 'report'],
                    'code_patterns': ['WRITE', 'DISPLAY', 'REPORT']
                },
                'batch_programs': {
                    'name_patterns': ['batch', 'bth', 'job'],
                    'code_patterns': ['JCL', 'STEP', 'SYSIN']
                },
                'online_programs': {
                    'name_patterns': ['onl', 'txn', 'scr', 'cics'],
                    'code_patterns': ['CICS', 'COMMAREA', 'DFHCOMMAREA']
                },
                'interface_programs': {
                    'name_patterns': ['int', 'ifc', 'api', 'web'],
                    'code_patterns': ['CALL', 'LINKAGE', 'COPY']
                },
                'utility_programs': {
                    'name_patterns': ['utl', 'util', 'tool'],
                    'code_patterns': ['UTILITY', 'TOOL', 'CONVERT']
                }
            }
        }
    
    def _get_default_base_template(self) -> str:
        """Retorna template base padrão."""
        return '''Analise o seguinte programa COBOL:

Nome do programa: {program_name}
Timestamp da análise: {timestamp}
Contexto: {context_info}

Código COBOL:
{program_code}

Por favor, forneça uma análise completa e detalhada.'''
    
    def _get_default_phase_template(self) -> str:
        """Retorna template de fase padrão."""
        return '''Baseado no seguinte programa COBOL:

{base_prompt}

Foque especificamente em: {question}

{context}'''

