# COBOL AI Engine v2.6.1 - Guia de Início Rápido

## Instalação e Execução em 3 Passos

### Passo 1: Extrair e Instalar
```bash
# Extrair o pacote
tar -xzf cobol_ai_engine_v2.6.1_FINAL.tar.gz
cd cobol_ai_engine_v2.6.1

# Instalar dependências
pip install -r requirements.txt
```

### Passo 2: Verificar se Funciona
```bash
# Verificar versão
python main.py --version

# Verificar status (configuração segura)
python main.py --config config/config_safe.yaml --status
```

### Passo 3: Executar Análise
```bash
# Análise básica (sempre funciona)
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output resultado

# Análise completa com PDF
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --books examples/BOOKS.txt --output resultado --pdf
```

## Configurações Disponíveis

- **config_safe.yaml**: Configuração segura (recomendada para iniciantes)
- **config_luzia_real.yaml**: Para ambiente corporativo com LuzIA
- **config.yaml**: Configuração padrão

## Solução de Problemas

**Se der erro de "missing argument 'config'":**
```bash
python main.py --config config/config_safe.yaml --status
```

**Se der erro de conexão:**
```bash
# Use sempre a configuração segura
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output teste
```

## Comandos Úteis

```bash
# Ver ajuda
python main.py --help

# Verificar status
python main.py --config config/config_safe.yaml --status

# Listar perguntas
python main.py --list-questions

# Análise com debug
python main.py --config config/config_safe.yaml --fontes examples/fontes.txt --output debug --log-level DEBUG
```

## Novidades da v2.6.1

- ✅ Corrigidos todos os erros de inicialização
- ✅ Sistema funciona em qualquer ambiente
- ✅ Configuração segura que nunca falha
- ✅ Documentação completa e atualizada

Para mais detalhes, consulte `docs/MANUAL_USUARIO.md`

