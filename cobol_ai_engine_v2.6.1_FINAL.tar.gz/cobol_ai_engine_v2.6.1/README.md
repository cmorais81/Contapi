


# COBOL AI Engine v2.6.1

O COBOL AI Engine é uma ferramenta de linha de comando para análise de programas COBOL utilizando múltiplos provedores de IA. Esta versão inclui a integração com o provedor LuzIA real, um sistema de prompts customizáveis e a capacidade de gerar documentação em formato PDF.

## Funcionalidades

*   Análise de programas COBOL com múltiplos provedores de IA.
*   Integração com o provedor LuzIA real.
*   Sistema de prompts customizáveis para focar a análise.
*   Geração de documentação em formato Markdown e PDF.
*   Sistema de fallback para garantir a disponibilidade da análise.
*   Controle de uso de tokens.

## Instalação

Consulte o `docs/MANUAL_USUARIO.md` para instruções detalhadas de instalação e uso.

## Configuração

Consulte o `docs/MANUAL_CONFIGURACAO.md` para instruções detalhadas de configuração.

## Uso

```bash
# Analisar um programa COBOL
python main.py --fontes <arquivo_fontes> --books <arquivo_books> --output <diretorio_saida>

# Gerar documentação em PDF
python main.py --fontes <arquivo_fontes> --pdf --output <diretorio_saida>

# Verificar o status do sistema
python main.py --status
```

## Licença

Este projeto é licenciado sob a licença MIT. Consulte o arquivo `LICENSE` para mais detalhes.


