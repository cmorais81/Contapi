#!/usr/bin/env python3
"""
COBOL AI Engine v2.0.0 - Constantes do Sistema
Centraliza constantes importantes usadas em todo o sistema.
"""

# Separadores de prompt
PROMPT_SEPARATOR = "=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ==="

# Configurações de análise
DEFAULT_SYSTEM_PROMPT = "Você é um analista de sistemas COBOL especializado com mais de 20 anos de experiência."

# Timeouts e limites
DEFAULT_TIMEOUT = 180.0
DEFAULT_MAX_TOKENS = 4000
DEFAULT_TEMPERATURE = 0.1

# Configurações de retry
DEFAULT_MAX_RETRIES = 5
DEFAULT_BASE_DELAY = 2.0
DEFAULT_MAX_DELAY = 60.0
DEFAULT_BACKOFF_MULTIPLIER = 2.0

# Rate limiting
DEFAULT_REQUESTS_PER_MINUTE = 10

# Configurações de token
DEFAULT_MAX_TOKENS_PER_REQUEST = 200000

# Modelos suportados
SUPPORTED_MODELS = [
    'azure-gpt-4o-mini',
    'claude-3-5-sonnet',
    'gpt-4',
    'mock-enhanced'
]

# Provedores suportados
SUPPORTED_PROVIDERS = [
    'luzia',
    'openai',
    'claude',
    'mock'
]

# Extensões de arquivo suportadas
SUPPORTED_COBOL_EXTENSIONS = [
    '.cbl',
    '.cob',
    '.cobol',
    '.txt'
]

# Configurações de log
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
LOG_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'

# Versão do sistema
VERSION = "2.0.0"
