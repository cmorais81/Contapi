# Guia de Uso - Correções de Prompt v2.0.1

## Visão Geral

Este guia explica como utilizar a aplicação COBOL AI Engine após as correções de prompt implementadas na versão 2.0.1. As correções garantem compatibilidade total com a API LuzIA e eliminam os erros de formatação de prompt.

## Configuração Necessária

### 1. Variáveis de Ambiente

Certifique-se de que as seguintes variáveis estão configuradas:

```bash
export LUZIA_CLIENT_ID="seu_client_id_aqui"
export LUZIA_CLIENT_SECRET="seu_client_secret_aqui"
```

### 2. Verificação da Configuração

Execute o teste de validação para confirmar que tudo está funcionando:

```bash
cd /home/ubuntu/cobol_ai_engine_v2.0.0
python3 test_prompt_fixes.py
```

Resultado esperado:
```
🎉 TODOS OS TESTES PASSARAM!
✅ As correções de prompt estão funcionando corretamente
```

## Uso da Aplicação

### 1. Interface CLI Interativa

```bash
python3 cli_interactive.py
```

**Fluxo de uso:**
1. Selecione o arquivo COBOL para análise
2. Escolha o provedor "luzia" quando solicitado
3. Aguarde o processamento (pode levar alguns minutos)
4. Visualize o relatório gerado

### 2. Uso Programático

```python
from src.core.prompt_manager_enhanced import EnhancedPromptManager
from src.providers.luzia_provider import LuziaProvider
from src.providers.base_provider import AIRequest

# 1. Configurar o prompt manager
prompt_manager = EnhancedPromptManager(model_name='luzia')

# 2. Gerar prompt para análise
prompt = prompt_manager.generate_base_prompt(
    program_name="MEU-PROGRAMA",
    program_code=codigo_cobol
)

# 3. Configurar o provider LuzIA
config = {
    'luzia': {
        'client_id': '${LUZIA_CLIENT_ID}',
        'client_secret': '${LUZIA_CLIENT_SECRET}',
        'auth_url': 'https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token',
        'api_url': 'https://gpt-api-aws.santanderbr.dev.corp/genai_services/v1/chat/completions',
        'model': 'azure-gpt-4o-mini'
    }
}

provider = LuziaProvider(config)

# 4. Executar análise
request = AIRequest(
    program_name="MEU-PROGRAMA",
    prompt=prompt
)

response = provider.analyze(request)

if response.success:
    print("Análise concluída com sucesso!")
    print(response.content)
else:
    print(f"Erro na análise: {response.error_message}")
```

## Formato de Prompt Atualizado

### Estrutura do Prompt

O novo formato divide o prompt em duas partes separadas por um delimitador específico:

```
[SYSTEM PROMPT]
=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===
[USER PROMPT]
```

### System Prompt
Contém:
- Persona do analista COBOL experiente
- Instruções de análise geral
- Questões específicas detalhadas
- Diretrizes de qualidade

### User Prompt
Contém:
- Nome do programa
- Informações contextuais
- Código fonte COBOL
- Dados de copybooks (se disponíveis)

## Monitoramento e Logs

### 1. Logs do Sistema

Os logs agora incluem informações detalhadas sobre o processamento:

```
2025-09-22 21:48:44 - LuziaProvider - INFO - Iniciando análise com LuzIA para programa: MEU-PROGRAMA
2025-09-22 21:48:44 - LuziaProvider - DEBUG - Prompt dividido com sucesso. System: 5034 chars, User: 387 chars
2025-09-22 21:48:44 - LuziaProvider - DEBUG - Criando payload para API LuzIA...
2025-09-22 21:48:44 - LuziaProvider - INFO - Análise concluída com sucesso. Conteúdo: 2500 caracteres
```

### 2. Verificação de Funcionamento

Para verificar se o sistema está funcionando corretamente:

```bash
# Verificar se as constantes estão sendo usadas
grep -r "PROMPT_SEPARATOR" src/

# Verificar logs em tempo real
tail -f logs/cobol_ai_engine.log
```

## Solução de Problemas

### 1. Erro: "Separador não encontrado no prompt"

**Causa:** O EnhancedPromptManager não está sendo usado ou há problema na importação.

**Solução:**
```python
# Verificar se está usando o EnhancedPromptManager
from src.core.prompt_manager_enhanced import EnhancedPromptManager
prompt_manager = EnhancedPromptManager(model_name='luzia')
```

### 2. Erro: "Token inválido ou não definido"

**Causa:** Variáveis de ambiente não configuradas.

**Solução:**
```bash
# Verificar variáveis
echo $LUZIA_CLIENT_ID
echo $LUZIA_CLIENT_SECRET

# Configurar se necessário
export LUZIA_CLIENT_ID="seu_client_id"
export LUZIA_CLIENT_SECRET="seu_client_secret"
```

### 3. Erro: "Payload falhou na validação"

**Causa:** Estrutura de payload incorreta.

**Solução:**
- Verificar se está usando a versão corrigida do LuziaProvider
- Executar teste de validação: `python3 test_prompt_fixes.py`

### 4. HTTP 403 - Forbidden

**Possíveis causas e soluções:**

1. **Token expirado:**
   - O sistema renova automaticamente
   - Verificar logs para confirmação

2. **Credenciais incorretas:**
   - Validar LUZIA_CLIENT_ID e LUZIA_CLIENT_SECRET
   - Contatar administrador se necessário

3. **Formato de requisição:**
   - As correções implementadas resolvem este problema
   - Executar testes para confirmar

## Validação de Funcionamento

### Teste Rápido

```python
# Teste simples para validar funcionamento
from src.core.constants import PROMPT_SEPARATOR

test_prompt = f"System prompt{PROMPT_SEPARATOR}User prompt"
parts = test_prompt.split(PROMPT_SEPARATOR, 1)

if len(parts) == 2:
    print("✅ Separador funcionando corretamente")
else:
    print("❌ Problema com separador")
```

### Teste Completo

Execute o arquivo de teste completo:

```bash
python3 test_prompt_fixes.py
```

## Melhores Práticas

### 1. Uso do Sistema

- Sempre use o **EnhancedPromptManager** para gerar prompts
- Configure logs em nível DEBUG para desenvolvimento
- Use nível INFO para produção

### 2. Monitoramento

- Monitore logs do LuziaProvider regularmente
- Verifique taxa de sucesso das requisições
- Acompanhe tempo de resposta da API

### 3. Manutenção

- Execute testes após qualquer modificação
- Mantenha variáveis de ambiente atualizadas
- Faça backup das configurações

## Suporte

### Logs Importantes

Sempre inclua os seguintes logs ao reportar problemas:

```bash
# Logs do sistema
grep "LuziaProvider" logs/cobol_ai_engine.log

# Logs de erro
grep "ERROR" logs/cobol_ai_engine.log

# Logs de token
grep "Token" logs/cobol_ai_engine.log
```

### Informações para Suporte

Ao reportar problemas, inclua:

1. Versão do sistema (2.0.1)
2. Logs relevantes
3. Código COBOL sendo analisado (se possível)
4. Configuração utilizada
5. Resultado dos testes de validação

---

**Versão:** 2.0.1  
**Data:** 22 de setembro de 2025  
**Status:** Ativo
