# Guia de Prompts - COBOL AI Engine v2.0.0

**Data:** 22 de setembro de 2025  
**Versão:** 2.0.0  
**Funcionalidade:** Múltiplos arquivos de prompts  

## 📋 Visão Geral

O COBOL AI Engine v2.0.0 agora suporta múltiplos arquivos de prompts, permitindo escolher entre diferentes metodologias de análise conforme sua necessidade.

## 🎯 Arquivos de Prompts Disponíveis

### **1. prompts.yaml (Padrão)**
- **Metodologia:** Análise estruturada em 9 questões
- **Foco:** Análise funcional detalhada para desenvolvedores e analistas de negócio
- **Características:**
  - 9 questões estruturadas específicas
  - Rastreabilidade direta ao código
  - Formato funcional para validação com negócio
  - Análise em duas etapas (geral + específica)

### **2. prompts_doc_legado.yaml (DOC-LEGADO PRO)**
- **Metodologia:** DOC-LEGADO PRO sistêmica
- **Foco:** Documentação sistêmica completa (Mainframe e distribuído)
- **Características:**
  - Documento Funcional + Especificação Técnica
  - Artefatos visuais (fluxogramas/diagramas)
  - Matrizes CRUD e DMN
  - Rastreabilidade completa (arquivo/linha/objeto)
  - Lacunas & Suposições estruturadas
  - Próximos passos com DOR → AÇÃO → DONO → PRAZO

## 🔧 Como Alternar Entre Prompts

### **Método 1: Configuração no config.yaml**

Edite o arquivo `config/config.yaml`:

```yaml
ai:
  prompt:
    # Para usar prompts padrão (9 questões estruturadas)
    prompts_file: "config/prompts.yaml"
    
    # Para usar metodologia DOC-LEGADO PRO
    # prompts_file: "config/prompts_doc_legado.yaml"
```

### **Método 2: Renomeação de Arquivos**

```bash
# Backup do arquivo atual
cp config/prompts.yaml config/prompts_backup.yaml

# Para usar DOC-LEGADO PRO
cp config/prompts_doc_legado.yaml config/prompts.yaml

# Para voltar ao padrão
cp config/prompts_backup.yaml config/prompts.yaml
```

## 📊 Comparação das Metodologias

| Aspecto | Prompts Padrão | DOC-LEGADO PRO |
|---------|----------------|----------------|
| **Estrutura** | 9 questões específicas | Documento + Especificação |
| **Foco** | Análise funcional | Documentação sistêmica |
| **Saída** | Relatório funcional | Doc Funcional + Spec Técnica |
| **Rastreabilidade** | Linhas de código | Arquivo/linha/objeto |
| **Diagramas** | Básicos | Mermaid/PlantUML |
| **Público-alvo** | Desenvolvedores/Negócio | Arquitetos/Documentação |
| **Complexidade** | Média | Alta |
| **Tempo de análise** | Rápido | Detalhado |

## 🎯 Quando Usar Cada Metodologia

### **Use Prompts Padrão quando:**
- ✅ Precisa de análise rápida e funcional
- ✅ Foco na validação com área de negócio
- ✅ Quer rastreabilidade direta ao código
- ✅ Equipe prefere formato de questões estruturadas
- ✅ Análise para desenvolvimento/manutenção

### **Use DOC-LEGADO PRO quando:**
- ✅ Precisa de documentação sistêmica completa
- ✅ Projeto de migração ou modernização
- ✅ Análise arquitetural detalhada
- ✅ Documentação para auditoria/compliance
- ✅ Análise de sistemas legados complexos
- ✅ Precisa de diagramas e especificações técnicas

## 📝 Exemplos de Saída

### **Prompts Padrão - Estrutura**
```markdown
# Análise Funcional - [PROGRAMA]

## 1. Contexto e Objetivo
[Análise do propósito do programa]

## 2. Visão de Alto Nível
[Entradas, processamento, saídas]

## 3. Regras de Negócio
| ID | Regra | Evidência | Criticidade |
|----|-------|-----------|-------------|

[... 9 questões estruturadas ...]

## Seção de Transparência
[Metodologia, prompts, estatísticas]
```

### **DOC-LEGADO PRO - Estrutura**
```markdown
# RESUMO EXECUTIVO
[3-5 bullets do que o programa faz]

# DOCUMENTO FUNCIONAL v1.0
## 1. Contexto e Objetivo do Componente
## 2. Visão de Alto Nível
## 3. Regras de Negócio (com rastreabilidade)
[... 9 seções funcionais ...]

# ESPECIFICAÇÃO TÉCNICA v1.0
## 1. Arquitetura Atual
```mermaid
[Diagrama da arquitetura]
```
## 2. Fluxo Detalhado
[... 10 seções técnicas ...]

# LACUNAS & SUPOSIÇÕES
# PRÓXIMOS PASSOS
| DOR | AÇÃO | DONO | PRAZO |
```

## 🔄 Migração Entre Metodologias

### **De Padrão para DOC-LEGADO PRO**
1. Altere `prompts_file` no `config.yaml`
2. Execute nova análise
3. Compare resultados
4. Ajuste conforme necessário

### **De DOC-LEGADO PRO para Padrão**
1. Altere `prompts_file` no `config.yaml`
2. Execute nova análise
3. Valide se atende necessidades
4. Mantenha documentação anterior se necessário

## 🛠️ Personalização

### **Criando Seu Próprio Arquivo de Prompts**
1. Copie um dos arquivos existentes
2. Modifique conforme sua metodologia
3. Configure no `config.yaml`
4. Teste com programas conhecidos

### **Estrutura Mínima Necessária**
```yaml
# Configuração do sistema
system_role: |
  [Definição do papel da IA]

# Prompts principais
prompts:
  general_analysis:
    template: |
      [Template de análise geral]
  
  structured_questions:
    [Questões específicas]

# Configurações
settings:
  max_tokens: 8192
  temperature: 0.1
```

## 📋 Validação da Configuração

### **Teste de Configuração**
```bash
# Verificar qual arquivo está sendo usado
python main.py --status

# Executar análise de teste
python main.py --fontes examples/fontes.txt --books examples/BOOKS.txt --output teste_prompts
```

### **Logs de Configuração**
```
INFO - Configuração de prompts carregada de: config/prompts.yaml
INFO - Configuração de prompts carregada de: config/prompts_doc_legado.yaml
```

## 🎯 Recomendações

### **Para Equipes de Desenvolvimento**
- **Use prompts padrão** para análises rápidas e funcionais
- **Mantenha consistência** na metodologia escolhida
- **Documente** qual metodologia está sendo usada

### **Para Projetos de Migração**
- **Use DOC-LEGADO PRO** para documentação completa
- **Combine** ambas as metodologias se necessário
- **Valide** resultados com arquitetos e negócio

### **Para Auditoria/Compliance**
- **Use DOC-LEGADO PRO** para rastreabilidade completa
- **Mantenha** evidências de análise
- **Documente** metodologia utilizada

## 🏆 Benefícios da Flexibilidade

- **Adaptabilidade** - Escolha a metodologia adequada ao contexto
- **Eficiência** - Use a abordagem mais eficiente para cada situação
- **Qualidade** - Obtenha o nível de detalhe necessário
- **Padronização** - Mantenha consistência dentro de cada metodologia
- **Evolução** - Facilita criação de novas metodologias

---

**Guia elaborado pela equipe COBOL AI Engine**  
**Atualizado em 22/09/2025 para v2.0.0**
