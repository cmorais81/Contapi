#!/usr/bin/env python3
"""
Teste das Correções de Prompt v2.0.0
Valida se as correções no EnhancedPromptManager e LuziaProvider funcionam corretamente.
"""

import os
import sys
import logging
from datetime import datetime

# Adicionar o diretório src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Importar apenas os módulos necessários para evitar problemas de dependência
from core.prompt_manager_enhanced import EnhancedPromptManager
from core.constants import PROMPT_SEPARATOR

# Simular AIRequest para teste
class MockAIRequest:
    def __init__(self, program_name, prompt, context=None):
        self.program_name = program_name
        self.prompt = prompt
        self.context = context or {}

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def test_prompt_generation():
    """Testa a geração de prompt pelo EnhancedPromptManager."""
    print("=" * 60)
    print("TESTE 1: Geração de Prompt pelo EnhancedPromptManager")
    print("=" * 60)
    
    try:
        # Inicializar o prompt manager
        prompt_manager = EnhancedPromptManager(model_name='luzia')
        
        # Código COBOL de exemplo
        sample_code = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. SAMPLE-PROG.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-COUNTER PIC 9(3) VALUE 0.
       
       PROCEDURE DIVISION.
       MAIN-PARA.
           DISPLAY 'Hello COBOL World'.
           STOP RUN.
        """
        
        # Gerar prompt
        prompt = prompt_manager.generate_base_prompt(
            program_name="SAMPLE-PROG",
            program_code=sample_code
        )
        
        # Verificar se o separador está presente
        if PROMPT_SEPARATOR in prompt:
            print("✅ Separador encontrado no prompt")
            
            # Dividir o prompt
            parts = prompt.split(PROMPT_SEPARATOR, 1)
            system_prompt = parts[0].strip()
            user_prompt = parts[1].strip()
            
            print(f"✅ System prompt: {len(system_prompt)} caracteres")
            print(f"✅ User prompt: {len(user_prompt)} caracteres")
            
            # Verificar conteúdo
            if "PROGRAMADOR COBOL MUITO EXPERIENTE" in system_prompt:
                print("✅ System prompt contém persona correta")
            else:
                print("❌ System prompt não contém persona esperada")
            
            if "SAMPLE-PROG" in user_prompt:
                print("✅ User prompt contém nome do programa")
            else:
                print("❌ User prompt não contém nome do programa")
            
            if "Hello COBOL World" in user_prompt:
                print("✅ User prompt contém código COBOL")
            else:
                print("❌ User prompt não contém código COBOL")
                
        else:
            print("❌ Separador não encontrado no prompt")
            return False
            
        print("✅ Teste de geração de prompt: PASSOU")
        return True
        
    except Exception as e:
        print(f"❌ Erro no teste de geração de prompt: {e}")
        return False

def test_luzia_provider_parsing():
    """Testa o parsing de prompt simulando o comportamento do LuziaProvider."""
    print("\n" + "=" * 60)
    print("TESTE 2: Parsing de Prompt (Simulação LuziaProvider)")
    print("=" * 60)
    
    try:
        # Criar prompt de teste com separador
        system_part = "Você é um analista COBOL experiente."
        user_part = "Analise este programa: SAMPLE-PROG"
        test_prompt = f"{system_part}{PROMPT_SEPARATOR}{user_part}"
        
        # Criar request de teste
        request = MockAIRequest(
            program_name="SAMPLE-PROG",
            prompt=test_prompt,
            context={}
        )
        
        # Simular o parsing interno (como faz o LuziaProvider)
        prompt_parts = request.prompt.split(PROMPT_SEPARATOR, 1)
        
        if len(prompt_parts) == 2:
            parsed_system = prompt_parts[0].strip()
            parsed_user = prompt_parts[1].strip()
            
            print("✅ Prompt dividido corretamente")
            print(f"✅ System prompt extraído: {len(parsed_system)} caracteres")
            print(f"✅ User prompt extraído: {len(parsed_user)} caracteres")
            
            if parsed_system == system_part:
                print("✅ System prompt extraído corretamente")
            else:
                print("❌ System prompt não extraído corretamente")
                
            if parsed_user == user_part:
                print("✅ User prompt extraído corretamente")
            else:
                print("❌ User prompt não extraído corretamente")
                
        else:
            print("❌ Prompt não foi dividido corretamente")
            return False
            
        print("✅ Teste de parsing simulado: PASSOU")
        return True
        
    except Exception as e:
        print(f"❌ Erro no teste de parsing: {e}")
        return False

def test_payload_creation():
    """Testa a estrutura de payload esperada pelo LuzIA."""
    print("\n" + "=" * 60)
    print("TESTE 3: Estrutura de Payload para LuzIA")
    print("=" * 60)
    
    try:
        # Simular criação de payload como faz o LuziaProvider
        system_prompt = "Você é um analista COBOL experiente."
        user_prompt = "Analise este programa: SAMPLE-PROG"
        
        # Estrutura de payload esperada pelo LuzIA
        payload = {
            "input": {
                "query": [
                    {
                        "role": "system",
                        "content": system_prompt
                    },
                    {
                        "role": "user", 
                        "content": user_prompt
                    }
                ]
            },
            "config": [
                {
                    "type": "catena.llm.LLMRouter",
                    "obj_kwargs": {
                        "routing_model": "azure-gpt-4o-mini",
                        "temperature": 0.1,
                        "max_tokens": 4000
                    }
                }
            ]
        }
        
        # Validar estrutura do payload
        if "input" in payload:
            print("✅ Payload contém 'input'")
        else:
            print("❌ Payload não contém 'input'")
            return False
            
        if "config" in payload:
            print("✅ Payload contém 'config'")
        else:
            print("❌ Payload não contém 'config'")
            return False
            
        if isinstance(payload["config"], list):
            print("✅ Config é uma lista (formato correto)")
        else:
            print("❌ Config não é uma lista")
            return False
            
        if "query" in payload["input"]:
            print("✅ Input contém 'query'")
        else:
            print("❌ Input não contém 'query'")
            return False
            
        if isinstance(payload["input"]["query"], list):
            print("✅ Query é uma lista (formato correto)")
        else:
            print("❌ Query não é uma lista")
            return False
            
        # Verificar mensagens
        messages = payload["input"]["query"]
        if len(messages) == 2:
            print("✅ Duas mensagens criadas (system e user)")
            
            if messages[0]["role"] == "system":
                print("✅ Primeira mensagem é system")
            else:
                print("❌ Primeira mensagem não é system")
                
            if messages[1]["role"] == "user":
                print("✅ Segunda mensagem é user")
            else:
                print("❌ Segunda mensagem não é user")
                
        else:
            print(f"❌ Número incorreto de mensagens: {len(messages)}")
            return False
            
        print("✅ Teste de estrutura de payload: PASSOU")
        return True
        
    except Exception as e:
        print(f"❌ Erro no teste de payload: {e}")
        return False

def test_integration():
    """Testa a integração completa entre componentes."""
    print("\n" + "=" * 60)
    print("TESTE 4: Integração Completa")
    print("=" * 60)
    
    try:
        # 1. Gerar prompt com EnhancedPromptManager
        prompt_manager = EnhancedPromptManager(model_name='luzia')
        
        sample_code = """
       IDENTIFICATION DIVISION.
       PROGRAM-ID. INTEGRATION-TEST.
       
       DATA DIVISION.
       WORKING-STORAGE SECTION.
       01 WS-RESULT PIC X(20) VALUE 'SUCCESS'.
       
       PROCEDURE DIVISION.
       MAIN-PARA.
           DISPLAY WS-RESULT.
           STOP RUN.
        """
        
        prompt = prompt_manager.generate_base_prompt(
            program_name="INTEGRATION-TEST",
            program_code=sample_code
        )
        
        print("✅ Prompt gerado pelo EnhancedPromptManager")
        
        # 2. Simular processamento como faria o LuziaProvider
        prompt_parts = prompt.split(PROMPT_SEPARATOR, 1)
        
        if len(prompt_parts) == 2:
            system_prompt = prompt_parts[0].strip()
            user_prompt = prompt_parts[1].strip()
            
            print("✅ Prompt processado corretamente")
            
            # 3. Simular criação de payload
            payload = {
                "input": {
                    "query": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ]
                },
                "config": [
                    {
                        "type": "catena.llm.LLMRouter",
                        "obj_kwargs": {
                            "routing_model": "azure-gpt-4o-mini",
                            "temperature": 0.1,
                            "max_tokens": 4000
                        }
                    }
                ]
            }
            
            print("✅ Payload criado corretamente")
            
            # Verificar conteúdo específico
            if "INTEGRATION-TEST" in user_prompt:
                print("✅ Nome do programa preservado no fluxo")
            else:
                print("❌ Nome do programa perdido no fluxo")
                
            if "SUCCESS" in user_prompt:
                print("✅ Código COBOL preservado no fluxo")
            else:
                print("❌ Código COBOL perdido no fluxo")
                
            if "PROGRAMADOR COBOL MUITO EXPERIENTE" in system_prompt:
                print("✅ Persona preservada no system prompt")
            else:
                print("❌ Persona perdida no system prompt")
                
        else:
            print("❌ Falha no parsing do prompt")
            return False
            
        print("✅ Teste de integração completa: PASSOU")
        return True
        
    except Exception as e:
        print(f"❌ Erro no teste de integração: {e}")
        return False

def main():
    """Executa todos os testes."""
    print("INICIANDO TESTES DAS CORREÇÕES DE PROMPT")
    print("=" * 60)
    print(f"Data/Hora: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Separador usado: {PROMPT_SEPARATOR}")
    print("=" * 60)
    
    tests = [
        test_prompt_generation,
        test_luzia_provider_parsing,
        test_payload_creation,
        test_integration
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print("\n" + "=" * 60)
    print("RESUMO DOS TESTES")
    print("=" * 60)
    print(f"Testes executados: {total}")
    print(f"Testes aprovados: {passed}")
    print(f"Testes falharam: {total - passed}")
    
    if passed == total:
        print("🎉 TODOS OS TESTES PASSARAM!")
        print("✅ As correções de prompt estão funcionando corretamente")
        return True
    else:
        print("❌ ALGUNS TESTES FALHARAM")
        print("⚠️  Verifique os erros acima")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
