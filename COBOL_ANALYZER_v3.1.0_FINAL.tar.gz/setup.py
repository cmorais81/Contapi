#!/usr/bin/env python3

from setuptools import setup, find_packages
import os

# Ler o README
try:
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()
except:
    long_description = "COBOL Analyzer - Ferramenta de análise de código COBOL com IA"

setup(
    name="cobol-analyzer",
    version="3.1.0",
    author="COBOL Analyzer Team",
    author_email="contact@cobol-analyzer.com",
    description="Ferramenta de análise de código COBOL com tecnologia de IA",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/cobol-analyzer/cobol-analyzer",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    py_modules=["cli", "main"],
    include_package_data=True,
    package_data={
        "": ["*.yaml", "*.yml", "*.json", "*.md", "*.txt"],
    },
    data_files=[
        ("config", ["config/config.yaml"]),
        ("examples", ["examples/fontes.txt", "examples/books.txt"]),
        ("data", ["data/README.md"]),
    ],
    entry_points={
        "console_scripts": [
            "cobol-analyzer=cli:main",
        ],
    },
    install_requires=[
        "pyyaml>=6.0",
        "openai>=1.0.0",
        "boto3>=1.26.0",
        "requests>=2.28.0",
        "numpy>=1.21.0",
        "scikit-learn>=1.0.0",
        "jinja2>=3.0.0",
        "markdown>=3.3.0",
        "weasyprint>=54.0",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Code Generators",
        "Topic :: Software Development :: Documentation",
    ],
    python_requires=">=3.8",
)
