# Guia de Comandos - COBOL to Docs v1.3

Este guia apresenta uma lista completa de exemplos de comandos, desde o uso básico até as combinações mais avançadas para extrair o máximo poder da ferramenta.

---

## 1. Comandos Básicos

### Análise Padrão de um Único Programa
Analisa um único arquivo COBOL e gera a documentação funcional em um diretório com o nome do programa.

```bash
python main.py --fontes examples/LHAN0542.cbl
```

### Análise de Múltiplos Programas (via arquivo de lista)
Analisa todos os programas listados no arquivo `fontes.txt`, gerando uma pasta de análise para cada um.

```bash
python main.py --fontes examples/fontes.txt
```

### Especificando o Diretório de Saída
Analisa os programas e salva todos os resultados em um diretório de saída específico.

```bash
python main.py --fontes examples/fontes.txt --output minha_analise_customizada
```

---

## 2. Uso de Copybooks

### Análise com Inclusão de Copybooks
Inclui o conteúdo dos copybooks (livros) durante a análise para uma resolução de dependências mais precisa.

```bash
python main.py --fontes examples/fontes.txt --books examples/books.txt
```

---

## 3. Seleção de Modelos e Provedores

### Selecionando um Modelo Específico
Força a utilização de um modelo de IA específico para a análise (ex: `aws-claude-3-5-sonnet`).

```bash
python main.py --fontes examples/fontes.txt --models aws-claude-3-5-sonnet
```

### Análise Comparativa com Múltiplos Modelos
Executa a análise com vários modelos de IA simultaneamente, gerando uma pasta de resultado para cada modelo. Ideal para comparar a qualidade das respostas.

```bash
python main.py --fontes examples/fontes.txt --models "aws-claude-3-5-sonnet,enhanced_mock"
```

---

## 4. Modos de Análise Avançada

### Análise Consolidada (Visão Sistêmica)
**Flag: `--consolidado`**
Analisa todos os programas como um sistema único, focando nas interações e dependências entre eles.

```bash
python main.py --fontes examples/fontes.txt --books examples/books.txt --consolidado
```

### Relatório Único Consolidado
**Flag: `--relatorio-unico`**
Similar à análise consolidada, mas gera um único arquivo Markdown contendo a análise de todos os programas.

```bash
python main.py --fontes examples/fontes.txt --relatorio-unico
```

### Análise de Especialista
**Flag: `--analise-especialista`**
Utiliza um conjunto de prompts especializados para realizar uma análise técnica profunda, focando em regras de negócio, complexidade e arquitetura.

```bash
python main.py --fontes examples/fontes.txt --analise-especialista
```

### Análise Detalhada da Procedure Division
**Flag: `--procedure-detalhada`**
Foca a análise exclusivamente na `PROCEDURE DIVISION`, detalhando o fluxo lógico, parágrafos e execução do programa.

```bash
python main.py --fontes examples/fontes.txt --procedure-detalhada
```

### Análise de Modernização e Migração
**Flag: `--modernizacao`**
Analisa o programa sob a ótica de modernização, fornecendo recomendações e uma tradução da lógica de negócio para **Python**.

```bash
python main.py --fontes examples/fontes.txt --modernizacao
```

---

## 5. Formato de Saída

### Geração de Documentação em PDF
**Flag: `--pdf`**
Converte todos os relatórios Markdown gerados para o formato PDF.

```bash
python main.py --fontes examples/fontes.txt --pdf
```

---

## 6. Comandos Utilitários

### Verificar Status dos Provedores
**Flag: `--status`**
Testa a conexão com todos os provedores de IA configurados e exibe seu status.

```bash
python main.py --status
```

### Ajuda e Todas as Opções
**Flag: `--help`**
Exibe uma lista completa de todos os argumentos e opções disponíveis.

```bash
python main.py --help
```

---

## 7. Combinações Avançadas (Exemplos de Poder)

### Análise Sistêmica Completa em PDF
Combina análise consolidada, análise de especialista e geração de PDF para um relatório técnico completo do sistema.

```bash
python main.py --fontes examples/fontes.txt --books examples/books.txt --consolidado --analise-especialista --pdf
```

### Relatório Único Comparativo com Múltiplos Modelos
Gera um único documento comparando a análise de todos os programas por diferentes modelos de IA.

```bash
python main.py --fontes examples/fontes.txt --relatorio-unico --models "aws-claude-3-5-sonnet,gpt-4"
```

### Análise de Modernização para Python com Detalhes da Procedure
Cria uma análise focada em migração, detalhando a lógica da `PROCEDURE DIVISION` e traduzindo-a para Python.

```bash
python main.py --fontes examples/fontes.txt --modernizacao --procedure-detalhada
```

### O Comando Mais Completo (All-in)
Executa uma análise consolidada e especialista de todos os programas, com seus respectivos copybooks, utilizando múltiplos modelos de IA e gerando a saída final em PDF.

```bash
python main.py \
    --fontes examples/fontes.txt \
    --books examples/books.txt \
    --output analise_completa_v1_3 \
    --consolidado \
    --analise-especialista \
    --models "aws-claude-3-5-sonnet,enhanced_mock" \
    --pdf
```

