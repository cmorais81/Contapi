#!/usr/bin/env python3
"""
Função auxiliar para parsear arquivos COBOL usando o COBOLParser
"""

import sys
from pathlib import Path

# Adicionar o diretório src ao sys.path
current_dir = Path(__file__).resolve().parent
sys.path.insert(0, str(current_dir / "cobol_to_docs" / "src"))

from parsers.cobol_parser import COBOLParser

def parse_cobol_files(fontes_path, books_path):
    """
    Parseia arquivos COBOL e retorna um dicionário com os programas
    """
    parser = COBOLParser()
    
    # Parsear arquivo de fontes
    programs, _ = parser.parse_file(fontes_path)
    
    # Parsear arquivo de books
    _, books = parser.parse_file(books_path)
    
    # Converter para dicionário
    programs_data = {}
    for program in programs:
        programs_data[program.name] = program.content
    
    # Criar conteúdo de copybooks
    copybooks_content = ""
    for book in books:
        copybooks_content += f"\n=== COPYBOOK {book.name} ===\n{book.content}\n"
    
    return programs_data, copybooks_content

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Uso: python3 parse_cobol_files.py <fontes.txt> <BOOKS.txt>")
        sys.exit(1)
    
    programs, copybooks = parse_cobol_files(sys.argv[1], sys.argv[2])
    print(f"Programas encontrados: {list(programs.keys())}")
    print(f"Copybooks: {len(copybooks)} caracteres")
