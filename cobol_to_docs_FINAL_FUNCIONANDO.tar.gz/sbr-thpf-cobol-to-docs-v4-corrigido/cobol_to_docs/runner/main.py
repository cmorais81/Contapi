#!/usr/bin/env python3
"""
COBOL AI Engine v4.0 - Main Runner
Sistema de análise de programas COBOL com IA
"""

import argparse
import logging
import os
import json
import datetime
import sys
from pathlib import Path

# Adicionar o diretório raiz do projeto ao sys.path
current_dir = Path(__file__).resolve().parent
project_root = current_dir.parent.parent  # sbr-thpf-cobol-to-docs-v4-corrigido
sys.path.insert(0, str(project_root))

# Imports diretos dos módulos
sys.path.insert(0, str(current_dir.parent / "src"))

from core.config import ConfigManager
from core.enhanced_prompt_manager import EnhancedPromptManager
from core.enhanced_file_manager import EnhancedFileManager
from providers.provider_manager import ProviderManager
from providers.base_provider import AIRequest
from parsers.implementations.enhanced_cobol_parser import EnhancedCobolParser
from utils.enhanced_response_formatter import EnhancedResponseFormatter

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')


def load_html_template():
    """Carrega o template HTML para conversão."""
    template_path = os.path.join(os.path.dirname(__file__), '..', 'templates', 'analysis_template.html')
    
    if os.path.exists(template_path):
        with open(template_path, 'r', encoding='utf-8') as f:
            return f.read()
    
    # Template básico se não encontrar o arquivo
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Análise COBOL - {program_name}</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            h1, h2, h3 { color: #2c3e50; }
            pre { background: #f8f9fa; padding: 15px; border-radius: 5px; }
            .metadata { background: #e9ecef; padding: 10px; border-radius: 5px; margin: 10px 0; }
        </style>
    </head>
    <body>
        {content}
    </body>
    </html>
    """


def save_analysis_files(analysis_result, output_dir, program_name, model_info, html_template=None):
    """
    Salva os arquivos de análise (Markdown, HTML, JSONs).
    
    Args:
        analysis_result: Resultado da análise
        output_dir: Diretório de saída
        program_name: Nome do programa
        model_info: Informações do modelo
        html_template: Template HTML
    """
    logger = logging.getLogger(__name__)
    
    # Criar estrutura de diretórios
    model_dir = os.path.join(output_dir, "analise_geral", f"model_{model_info['provider']}_{model_info['name']}")
    os.makedirs(model_dir, exist_ok=True)
    os.makedirs(os.path.join(model_dir, "ai_requests"), exist_ok=True)
    os.makedirs(os.path.join(model_dir, "ai_responses"), exist_ok=True)
    
    # Salvar análise em Markdown
    md_file = os.path.join(model_dir, f"{program_name}_analise_funcional.md")
    with open(md_file, 'w', encoding='utf-8') as f:
        f.write(analysis_result.get('analysis', ''))
    logger.info(f"  Análise Markdown salva: {md_file}")
    
    # Salvar request JSON
    request_file = os.path.join(model_dir, "ai_requests", f"{program_name}_ai_request.json")
    with open(request_file, 'w', encoding='utf-8') as f:
        json.dump(analysis_result.get('request_data', {}), f, indent=2, ensure_ascii=False)
    logger.info(f"  Request JSON salvo: {request_file}")
    
    # Salvar response JSON
    response_file = os.path.join(model_dir, "ai_responses", f"{program_name}_ai_response.json")
    with open(response_file, 'w', encoding='utf-8') as f:
        json.dump(analysis_result.get('response_data', {}), f, indent=2, ensure_ascii=False)
    logger.info(f"  Response JSON salvo: {response_file}")


def main():
    """Função principal do sistema."""
    logger = logging.getLogger(__name__)
    
    # Configurar argumentos da linha de comando
    parser = argparse.ArgumentParser(description='COBOL to Docs - Análise de programas COBOL com IA')
    parser.add_argument('--fontes', required=True, help='Arquivo com lista de programas COBOL ou arquivo COBOL empilhado')
    parser.add_argument('--books', required=True, help='Arquivo com lista de copybooks ou arquivo de copybooks empilhado')
    parser.add_argument('--output', required=True, help='Diretório de saída para os resultados')
    parser.add_argument('--config-dir', help='Diretório com configurações personalizadas')
    parser.add_argument('--prompts-file', help='Arquivo YAML com prompts personalizados')
    parser.add_argument('--html', action='store_true', help='Gerar também saída em HTML')
    parser.add_argument('--provider', help='Provedor específico a usar (sobrescreve configuração)')
    parser.add_argument('--model', help='Modelo específico a usar (sobrescreve configuração)')
    
    args = parser.parse_args()
    
    logger.info("=== COBOL AI Engine v4.0 - Iniciando Processamento ===")
    
    # Inicializar gerenciadores seguindo princípios de design orientado a objetos
    try:
        # 1. ConfigManager - Responsabilidade única: gerenciar configurações
        config_manager = ConfigManager(
            config_dir=args.config_dir,
            prompts_file=args.prompts_file
        )
        
        # 2. FileManager - Responsabilidade única: gerenciar arquivos de entrada
        enhanced_parser = EnhancedCobolParser()
        file_manager = EnhancedFileManager(enhanced_parser)
        
        # 3. ProviderManager - Responsabilidade única: gerenciar provedores de IA
        provider_manager = ProviderManager(config_manager.get_config())
        
        logger.info("Gerenciadores inicializados com sucesso")
        
    except Exception as e:
        logger.error(f"Erro ao inicializar gerenciadores: {e}")
        return

    # Carregar programas COBOL usando FileManager
    try:
        logger.info("Carregando programas COBOL...")
        programs_data, program_entries = file_manager.load_programs_from_list(args.fontes)
        
        # Estatísticas dos arquivos de programa
        program_stats = file_manager.get_file_statistics(program_entries)
        logger.info(f"Estatísticas de programas: {program_stats}")
        
        logger.info(f"Programas encontrados: {list(programs_data.keys())}")

        if not programs_data:
            logger.error("Nenhum programa COBOL encontrado para processar.")
            return

    except Exception as e:
        logger.error(f"Erro ao carregar programas COBOL: {e}")
        return

    # Carregar copybooks usando FileManager
    try:
        logger.info("Carregando copybooks...")
        copybooks_content, copybook_entries = file_manager.load_copybooks_from_list(args.books)
        
        # Estatísticas dos arquivos de copybook
        copybook_stats = file_manager.get_file_statistics(copybook_entries)
        logger.info(f"Estatísticas de copybooks: {copybook_stats}")
        
    except Exception as e:
        logger.error(f"Erro ao carregar copybooks: {e}")
        copybooks_content = ""

    # Carregar template HTML
    html_template = load_html_template()

    # Processar cada programa com cada modelo configurado
    try:
        configured_models = config_manager.get_configured_models()
        logger.info(f"Modelos configurados: {len(configured_models)}")
        
        for model_info in configured_models:
            logger.info(f"Modelo: {model_info}")

        if not configured_models:
            logger.error("Nenhum modelo de IA configurado ou habilitado. Verifique seu config.yaml.")
            return

        # Filtrar modelos se especificado na linha de comando
        if args.provider or args.model:
            filtered_models = []
            for model_info in configured_models:
                if args.provider and model_info['provider'] != args.provider:
                    continue
                if args.model and model_info['name'] != args.model:
                    continue
                filtered_models.append(model_info)
            configured_models = filtered_models
            logger.info(f"Modelos filtrados: {len(configured_models)}")

        # Processar cada programa com cada modelo
        for program_name, program_content in programs_data.items():
            logger.info(f"\n=== Processando programa: {program_name} ===")
            
            for model_info in configured_models:
                logger.info(f"  Usando modelo: model_{model_info['provider']}_{model_info['name']}")
                
                try:
                    # Criar prompt manager para este modelo
                    prompt_manager = EnhancedPromptManager(config_manager.get_prompts())
                    
                    # Gerar prompt especializado
                    prompt = prompt_manager.create_complete_analysis_prompt(program_name, program_content, copybooks_content)
                    logger.info(f"  Prompt completo criado para {program_name}: {len(prompt)} caracteres")
                    
                    # Criar objeto AIRequest
                    ai_request = AIRequest(
                        prompt=prompt,
                        program_name=program_name,
                        program_code=program_content,
                        context={
                            'copybooks': copybooks_content,
                            'model_info': model_info
                        },
                        max_tokens=model_info['config'].get('max_tokens', 4000),
                        temperature=model_info['config'].get('temperature', 0.1)
                    )
                    
                    # Preparar dados da requisição
                    request_data = {
                        "program_name": program_name,
                        "prompt": prompt,
                        "model_info": model_info,
                        "timestamp": datetime.datetime.now().isoformat(),
                        "bian_references": 0  # Placeholder para referências BIAN
                    }
                    
                    logger.info(f"  Request payload preparado. BIAN refs: {request_data['bian_references']}")
                    
                    # Fazer análise com o provedor
                    analysis_response = provider_manager.analyze_with_specific_provider(
                        model_info['provider'],
                        ai_request
                    )
                    
                    # Processar resposta
                    if analysis_response and hasattr(analysis_response, 'content') and analysis_response.content:
                        analysis_content = analysis_response.content
                        tokens_used = getattr(analysis_response, 'tokens_used', 0)
                    else:
                        analysis_content = "Erro: Não foi possível obter resposta do provedor."
                        tokens_used = 0
                    
                    logger.info(f"  Resposta recebida. Tokens usados: {tokens_used}")
                    
                    # Preparar resultado da análise
                    analysis_result = {
                        'analysis': analysis_content,
                        'request_data': request_data,
                        'response_data': {
                            'success': getattr(analysis_response, 'success', False),
                            'content': analysis_content,
                            'tokens_used': tokens_used,
                            'model': getattr(analysis_response, 'model', ''),
                            'provider': getattr(analysis_response, 'provider', ''),
                            'error_message': getattr(analysis_response, 'error_message', '')
                        }
                    }
                    
                    # Salvar arquivos de análise
                    save_analysis_files(
                        analysis_result,
                        args.output,
                        program_name,
                        model_info,
                        html_template if args.html else None
                    )
                    
                except Exception as e:
                    logger.error(f"  Erro ao processar {program_name} com {model_info['provider']}: {e}")
                    continue

    except Exception as e:
        logger.error(f"Erro durante processamento: {e}")
        return

    logger.info("=== PROCESSAMENTO CONCLUÍDO ===")


if __name__ == "__main__":
    main()
