import os
import json
import logging
import time
import warnings
import requests
from datetime import datetime
from typing import Dict, Any, Optional, List
from urllib3.exceptions import InsecureRequestWarning

# Suprimir warnings de SSL
warnings.filterwarnings("ignore", message="Unverified HTTPS request")
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

from .base_provider import BaseProvider, AIRequest, AIResponse

class LuziaProvider(BaseProvider):
    """Provider LuzIA corrigido com URLs e payload corretos da versão funcionando"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.logger = logging.getLogger("LuziaProvider")
        
        # Obter configurações do LuzIA do config.yaml
        luzia_config = config.get("providers", {}).get("luzia", {})
        
        # Configurações da API - URLs do config.yaml ou padrão
        self.client_id = luzia_config.get("client_id") or os.getenv("LUZIA_CLIENT_ID")
        self.client_secret = luzia_config.get("client_secret") or os.getenv("LUZIA_CLIENT_SECRET")
        
        # URLs do config.yaml - usar exatamente as URLs configuradas
        self.auth_url = luzia_config.get("auth_url", "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token")
        self.base_url = luzia_config.get("api_url", "https://gut-api-aws.santanderbr.pre.corp/genai_services/v1/")
        
        # Sem URLs de fallback - falhar imediatamente se não conectar
        
        # Configurações de timeout do config.yaml
        models_config = luzia_config.get("models", {})
        default_model_config = list(models_config.values())[0] if models_config else {}
        self.timeout = default_model_config.get("timeout", 120.0)
        
        # Verificar credenciais e definir valores padrão se necessário
        if not self.client_id or not self.client_secret:
            self.logger.warning("Credenciais LuzIA não configuradas - usando valores padrão para evitar erros")
            self.client_id = self.client_id or "test_client_id"
            self.client_secret = self.client_secret or "test_client_secret"
        
        # Obter o modelo padrão ou o primeiro modelo configurado
        self.model = luzia_config.get("default_model")
        if not self.model and models_config:
            self.model = list(models_config.keys())[0]
        
        self.logger.info(f"LuzIA configurado: modelo={self.model}, timeout={self.timeout}s")
        self.logger.info(f"URLs: auth={self.auth_url[:50]}..., api={self.base_url[:50]}...")
        
        # Token management
        self._token = None
        self._token_expires_at = None
        
        # Armazenar configuração completa para uso posterior
        self.luzia_config = luzia_config
        
        self.logger.info("LuziaProvider CORRIGIDO inicializado com URLs e payload corretos")

    def get_model_config(self, model_name: str = None) -> Dict[str, Any]:
        """
        Obter configurações específicas de um modelo do config.yaml
        
        Args:
            model_name: Nome do modelo (se None, usa o modelo padrão)
            
        Returns:
            Dicionário com configurações do modelo
        """
        if not model_name:
            model_name = self.model
            
        models_config = self.luzia_config.get("models", {})
        
        # Procurar por nome do modelo
        for model_key, model_config in models_config.items():
            if model_config.get("name") == model_name:
                return model_config
                
        # Se não encontrar, retornar configuração padrão
        return {
            "name": model_name,
            "max_tokens": 8192,
            "temperature": 0.1,
            "timeout": 120,
            "context_window": 200000
        }
        
    def get_available_models(self) -> List[str]:
        """
        Obter lista de modelos disponíveis do config.yaml
        
        Returns:
            Lista de nomes de modelos disponíveis
        """
        models_config = self.luzia_config.get("models", {})
        return [model_config.get("name", key) for key, model_config in models_config.items()]

    def get_token(self):
        """Obter token OAuth2 - usar apenas a URL configurada"""
        auth_url = self.auth_url
        
        try:
            # Payload correto para OAuth2
            request_body = {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret
            }
            
            # Headers corretos
            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "*/*"
            }
            
            self.logger.info(f"Obtendo token OAuth2 de {auth_url}")
            
            response = requests.post(
                auth_url,
                headers=headers,
                data=request_body,
                verify=False,
                timeout=self.timeout
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self._token = token_data.get("access_token")
                expires_in = token_data.get("expires_in", 3600)
                self._token_expires_at = time.time() + expires_in - 60
                
                # Log detalhado do token para debug
                if self._token:
                    token_preview = self._token[:20] + "..." if len(self._token) > 20 else self._token
                    self.logger.info(f"Token obtido com sucesso de {auth_url}")
                    self.logger.info(f"Token: {token_preview} (tamanho: {len(self._token)})")
                
                return self._token
            else:
                error_msg = f"Erro HTTP {response.status_code} ao obter token: {response.text}"
                self.logger.error(error_msg)
                raise Exception(error_msg)
                
        except requests.exceptions.RequestException as e:
            error_msg = f"Erro de conexão ao obter token: {str(e)}"
            self.logger.error(error_msg)
            raise Exception(error_msg)

    def is_available(self) -> bool:
        """
        Verifica se o LuzIA está disponível tentando obter um token de acesso.
        """
        if not self.client_id or not self.client_secret:
            self.logger.warning("LuzIA client_id ou client_secret não configurado")
            return False
        
        try:
            self.get_token()
            return True
        except Exception as e:
            self.logger.error(f"Erro ao autenticar com LuzIA para verificar disponibilidade: {e}")
            return False

    def analyze(self, request: AIRequest) -> AIResponse:
        """
        Realiza análise usando a API LuzIA com payload correto.
        """
        start_time = time.time()
        
        try:
            # Obter token de acesso
            access_token = self.get_token()
            
            # Construir system_prompt e user_prompt
            system_prompt = "Você é um especialista em análise de sistemas COBOL. Responda sempre em português brasileiro com análises técnicas detalhadas"
            user_prompt = f"""
Analise o seguinte programa COBOL:

PROGRAMA: {request.program_name}

CÓDIGO:
{request.program_code}

PROMPT DE ANÁLISE:
{request.prompt}

Por favor, forneça uma análise técnica detalhada seguindo as diretrizes do prompt.
"""
            
            # Obter configurações do modelo do config.yaml
            model_config = self.get_model_config(self.model)
            
            # Usar configurações do modelo do config.yaml
            temperature = model_config.get("temperature", request.temperature or 0.1)
            max_tokens = model_config.get("max_tokens", request.max_tokens or 8192)
            
            # Payload no formato correto da versão funcionando
            payload = {
                "input": {
                    "query": [
                        {
                            "role": "system",
                            "content": system_prompt
                        },
                        {
                            "role": "user", 
                            "content": user_prompt
                        }
                    ]
                },
                "config": [
                    {
                        "type": "catena.llm.LLMRouter",
                        "obj_kwargs": {
                            "routing_model": self.model,
                            "temperature": temperature,
                            "max_tokens": max_tokens,
                            "system_prompt": system_prompt # Adicionado system_prompt aqui
                        }
                    }
                ]
            }
            
            # Headers no formato correto - CORREÇÃO: usar Bearer no Authorization
            # Verificar se o token é válido antes de usar
            if not access_token:
                self.logger.error("Token não disponível - não é possível fazer requisição")
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model=self.model,
                    provider=self.__class__.__name__,
                    error_message="Token de autenticação não disponível",
                    response_time=0.0
                )
            
            # Construir header Authorization com validação e limpeza
            clean_token = access_token.strip().replace("\n", "").replace("\r", "").replace("\t", "") if access_token else ""
            auth_header = f"Bearer {clean_token}"
            
            # Log detalhado para debug
            self.logger.info(f"Construindo header Authorization: Bearer [token de {len(clean_token)} chars]")
            
            # Validar se o token não está vazio
            if not clean_token:
                self.logger.error("Token vazio após limpeza!")
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model=self.model,
                    provider=self.__class__.__name__,
                    error_message="Token de autenticação vazio",
                    response_time=0.0
                )
            
            # Headers limpos e validados
            headers = {
                "X-santander-client-id": str(self.client_id).strip(),
                "Authorization": auth_header,
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            # Log detalhado
            self.logger.info("Enviando para LuzIA (formato correto)")
            self.logger.info(f"URL: {self.base_url}")
            self.logger.info(f"Modelo: {self.model}")
            self.logger.info(f"System prompt: {len(system_prompt)} chars")
            self.logger.info(f"User prompt: {len(user_prompt)} chars")
            
            # Endpoint correto para LuzIA
            api_endpoint = f"{self.base_url}pipelines/submit"
            
            # Fazer requisição usando json= para enviar JSON corretamente
            response = requests.post(
                url=api_endpoint,
                json=payload,
                headers=headers,
                verify=False,
                timeout=self.timeout
            )
            
            response_time = time.time() - start_time
            self.logger.info(f"Status HTTP: {response.status_code} (tempo: {response_time:.2f}s)")
            
            # Tratar HTTP 200 e 201 como sucesso
            if response.status_code in [200, 201]:
                response_data = response.json()
                
                # Extrair conteúdo da resposta
                content = ""
                if "choices" in response_data and len(response_data["choices"]) > 0:
                    choice = response_data["choices"][0]
                    if "message" in choice and "content" in choice["message"]:
                        content = choice["message"]["content"]
                elif "output" in response_data:
                    content = str(response_data["output"])
                elif "result" in response_data:
                    content = str(response_data["result"])
                else:
                    # Fallback: usar toda a resposta como string
                    content = str(response_data)
                
                # Extrair tokens usados
                tokens_used = 0
                if "usage" in response_data:
                    tokens_used = response_data["usage"].get("total_tokens", 0)
                
                self.logger.info(f"Análise LuzIA concluída com sucesso em {response_time:.2f}s")
                
                return AIResponse(
                    success=True,
                    content=content,
                    tokens_used=tokens_used,
                    model=self.model,
                    provider=self.__class__.__name__,
                    response_time=response_time
                )
            else:
                error_msg = f"Erro HTTP {response.status_code}: {response.text}"
                self.logger.error(error_msg)
                
                return AIResponse(
                    success=False,
                    content="",
                    tokens_used=0,
                    model=self.model,
                    provider=self.__class__.__name__,
                    error_message=error_msg,
                    response_time=response_time
                )
                
        except Exception as e:
            response_time = time.time() - start_time
            error_msg = f"Erro na análise LuzIA: {str(e)}"
            self.logger.error(error_msg)
            
            return AIResponse(
                success=False,
                content="",
                tokens_used=0,
                model=self.model or "unknown",
                provider=self.__class__.__name__,
                error_message=error_msg,
                response_time=response_time
            )

    def get_statistics(self) -> Dict[str, Any]:
        """
        Retorna estatísticas do provider.
        """
        return {
            "provider": self.__class__.__name__,
            "auth_url": self.auth_url,
            "api_url": self.base_url,
            "has_token": self._token is not None,
            "token_expires_at": self._token_expires_at
        }
