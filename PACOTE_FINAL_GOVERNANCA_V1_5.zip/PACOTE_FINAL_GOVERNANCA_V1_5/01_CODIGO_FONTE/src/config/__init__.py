"""
Configuration Layer - Configurações da aplicação
"""

