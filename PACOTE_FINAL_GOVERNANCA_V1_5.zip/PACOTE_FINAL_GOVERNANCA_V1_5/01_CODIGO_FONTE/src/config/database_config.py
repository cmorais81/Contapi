"""
Configuração de banco de dados para múltiplos ambientes
"""
import os
from typing import Dict, Any
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.pool import StaticPool

from settings import get_settings


class DatabaseConfig:
    """Configuração de banco de dados"""
    
    @staticmethod
    def get_database_url() -> str:
        """Retorna URL do banco baseada no ambiente"""
        settings = get_settings()
        
        # Se estiver em desenvolvimento e SQLite estiver habilitado
        if settings.environment == "development" and settings.use_sqlite:
            return f"sqlite:///{settings.sqlite_db_path}"
        
        # Caso contrário, usar PostgreSQL
        return settings.database_url
    
    @staticmethod
    def create_engine_for_environment() -> Engine:
        """Cria engine apropriada para o ambiente"""
        settings = get_settings()
        database_url = DatabaseConfig.get_database_url()
        
        if database_url.startswith("sqlite"):
            # Configuração específica para SQLite
            return create_engine(
                database_url,
                poolclass=StaticPool,
                connect_args={
                    "check_same_thread": False,
                    "timeout": 20
                },
                echo=settings.database_echo
            )
        else:
            # Configuração para PostgreSQL
            return create_engine(
                database_url,
                pool_size=settings.database_pool_size,
                max_overflow=settings.database_max_overflow,
                pool_pre_ping=True,
                pool_recycle=3600,
                echo=settings.database_echo
            )
    
    @staticmethod
    def get_alembic_config() -> Dict[str, Any]:
        """Configuração para Alembic baseada no ambiente"""
        database_url = DatabaseConfig.get_database_url()
        
        if database_url.startswith("sqlite"):
            return {
                "sqlalchemy.url": database_url,
                "render_as_batch": True,  # Necessário para SQLite
                "compare_type": True,
                "compare_server_default": True
            }
        else:
            return {
                "sqlalchemy.url": database_url,
                "render_as_batch": False,
                "compare_type": True,
                "compare_server_default": True
            }


def get_database_engine() -> Engine:
    """Factory para engine de banco de dados"""
    return DatabaseConfig.create_engine_for_environment()


def is_sqlite() -> bool:
    """Verifica se está usando SQLite"""
    return DatabaseConfig.get_database_url().startswith("sqlite")


def is_postgresql() -> bool:
    """Verifica se está usando PostgreSQL"""
    return DatabaseConfig.get_database_url().startswith("postgresql")

