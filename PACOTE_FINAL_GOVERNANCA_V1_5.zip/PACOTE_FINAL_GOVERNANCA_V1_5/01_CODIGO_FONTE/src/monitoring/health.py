"""
Health Checks para monitoramento
"""

import asyncio
import time
from datetime import datetime
from typing import Any, Dict, List, Optional

from cache.redis_cache import cache_manager
from config.settings import get_settings
from database.connection import db_manager
from external.unity_catalog import UnityCatalogClient

settings = get_settings()


class HealthStatus:
    """Status de saúde"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"


class HealthCheck:
    """Classe base para health checks"""
    
    def __init__(self, name: str, timeout: int = 30):
        self.name = name
        self.timeout = timeout
    
    async def check(self) -> Dict[str, Any]:
        """Executa verificação de saúde"""
        start_time = time.time()
        
        try:
            # Executar verificação com timeout
            result = await asyncio.wait_for(
                self._perform_check(),
                timeout=self.timeout
            )
            
            response_time = (time.time() - start_time) * 1000  # ms
            
            return {
                "name": self.name,
                "status": HealthStatus.HEALTHY,
                "response_time_ms": round(response_time, 2),
                "details": result,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except asyncio.TimeoutError:
            return {
                "name": self.name,
                "status": HealthStatus.UNHEALTHY,
                "error": f"Timeout after {self.timeout}s",
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            return {
                "name": self.name,
                "status": HealthStatus.UNHEALTHY,
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
    
    async def _perform_check(self) -> Dict[str, Any]:
        """Implementa verificação específica"""
        raise NotImplementedError


class DatabaseHealthCheck(HealthCheck):
    """Health check para banco de dados"""
    
    def __init__(self):
        super().__init__("database", timeout=10)
    
    async def _perform_check(self) -> Dict[str, Any]:
        """Verifica conexão com banco de dados"""
        
        # Testar conexão
        async with db_manager.get_session() as session:
            # Executar query simples
            result = await session.execute("SELECT 1 as test")
            row = result.fetchone()
            
            if row and row[0] == 1:
                return {
                    "connection": "ok",
                    "query_test": "passed"
                }
            else:
                raise Exception("Database query test failed")


class RedisHealthCheck(HealthCheck):
    """Health check para Redis"""
    
    def __init__(self):
        super().__init__("redis", timeout=5)
    
    async def _perform_check(self) -> Dict[str, Any]:
        """Verifica conexão com Redis"""
        
        # Testar conexão
        is_healthy = await cache_manager.redis_cache.health_check()
        
        if is_healthy:
            # Testar operações básicas
            test_key = "health_check_test"
            test_value = "ok"
            
            # Set
            await cache_manager.redis_cache.set(test_key, test_value, ttl=60)
            
            # Get
            retrieved_value = await cache_manager.redis_cache.get(test_key)
            
            # Delete
            await cache_manager.redis_cache.delete(test_key)
            
            if retrieved_value == test_value:
                return {
                    "connection": "ok",
                    "operations": "passed"
                }
            else:
                raise Exception("Redis operations test failed")
        else:
            raise Exception("Redis connection failed")


class UnityCatalogHealthCheck(HealthCheck):
    """Health check para Unity Catalog"""
    
    def __init__(self):
        super().__init__("unity_catalog", timeout=15)
    
    async def _perform_check(self) -> Dict[str, Any]:
        """Verifica conexão com Unity Catalog"""
        
        if not settings.unity_catalog_url or not settings.unity_catalog_token:
            return {
                "status": "disabled",
                "reason": "Unity Catalog not configured"
            }
        
        async with UnityCatalogClient() as client:
            is_healthy = await client.health_check()
            
            if is_healthy:
                return {
                    "connection": "ok",
                    "api_test": "passed"
                }
            else:
                raise Exception("Unity Catalog API test failed")


class ApplicationHealthCheck(HealthCheck):
    """Health check para aplicação"""
    
    def __init__(self):
        super().__init__("application", timeout=5)
    
    async def _perform_check(self) -> Dict[str, Any]:
        """Verifica saúde da aplicação"""
        
        import psutil
        import os
        
        # Informações do processo
        process = psutil.Process(os.getpid())
        
        # Uso de memória
        memory_info = process.memory_info()
        memory_percent = process.memory_percent()
        
        # Uso de CPU
        cpu_percent = process.cpu_percent()
        
        # Threads
        num_threads = process.num_threads()
        
        # Arquivos abertos
        num_fds = process.num_fds() if hasattr(process, 'num_fds') else 0
        
        return {
            "pid": process.pid,
            "memory_rss_mb": round(memory_info.rss / 1024 / 1024, 2),
            "memory_percent": round(memory_percent, 2),
            "cpu_percent": round(cpu_percent, 2),
            "num_threads": num_threads,
            "num_file_descriptors": num_fds,
            "status": "running"
        }


class HealthCheckManager:
    """Gerenciador de health checks"""
    
    def __init__(self):
        self.checks = [
            ApplicationHealthCheck(),
            DatabaseHealthCheck(),
            RedisHealthCheck(),
            UnityCatalogHealthCheck()
        ]
    
    async def run_all_checks(self) -> Dict[str, Any]:
        """Executa todos os health checks"""
        
        start_time = time.time()
        
        # Executar checks em paralelo
        tasks = [check.check() for check in self.checks]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Processar resultados
        components = {}
        overall_status = HealthStatus.HEALTHY
        
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                # Health check falhou com exceção
                check_name = self.checks[i].name
                components[check_name] = {
                    "status": HealthStatus.UNHEALTHY,
                    "error": str(result),
                    "timestamp": datetime.utcnow().isoformat()
                }
                overall_status = HealthStatus.UNHEALTHY
            else:
                # Health check executou
                check_name = result["name"]
                components[check_name] = result
                
                # Atualizar status geral
                if result["status"] == HealthStatus.UNHEALTHY:
                    overall_status = HealthStatus.UNHEALTHY
                elif result["status"] == HealthStatus.DEGRADED and overall_status == HealthStatus.HEALTHY:
                    overall_status = HealthStatus.DEGRADED
        
        total_time = (time.time() - start_time) * 1000  # ms
        
        return {
            "status": overall_status,
            "timestamp": datetime.utcnow().isoformat(),
            "version": settings.api_version,
            "environment": "production" if settings.is_production else "development",
            "total_check_time_ms": round(total_time, 2),
            "components": components
        }
    
    async def run_check(self, check_name: str) -> Optional[Dict[str, Any]]:
        """Executa health check específico"""
        
        for check in self.checks:
            if check.name == check_name:
                return await check.check()
        
        return None
    
    def add_check(self, health_check: HealthCheck):
        """Adiciona health check customizado"""
        self.checks.append(health_check)
    
    def remove_check(self, check_name: str):
        """Remove health check"""
        self.checks = [check for check in self.checks if check.name != check_name]
    
    def get_check_names(self) -> List[str]:
        """Retorna nomes dos health checks"""
        return [check.name for check in self.checks]


# Instância global do gerenciador
health_manager = HealthCheckManager()


# ========================================
# HEALTH CHECKS CUSTOMIZADOS
# ========================================

class CustomHealthCheck(HealthCheck):
    """Health check customizado"""
    
    def __init__(self, name: str, check_function, timeout: int = 30):
        super().__init__(name, timeout)
        self.check_function = check_function
    
    async def _perform_check(self) -> Dict[str, Any]:
        """Executa função customizada"""
        if asyncio.iscoroutinefunction(self.check_function):
            return await self.check_function()
        else:
            return self.check_function()


def register_health_check(name: str, check_function, timeout: int = 30):
    """Registra health check customizado"""
    custom_check = CustomHealthCheck(name, check_function, timeout)
    health_manager.add_check(custom_check)


# ========================================
# HEALTH CHECK SCHEDULER
# ========================================

class HealthCheckScheduler:
    """Agendador de health checks"""
    
    def __init__(self, interval: int = 60):
        self.interval = interval
        self.running = False
        self.last_results = {}
    
    async def start(self):
        """Inicia execução periódica de health checks"""
        self.running = True
        
        while self.running:
            try:
                # Executar health checks
                results = await health_manager.run_all_checks()
                self.last_results = results
                
                # Log se houver problemas
                if results["status"] != HealthStatus.HEALTHY:
                    print(f"Health check warning: {results['status']}")
                    
                    # Log componentes com problemas
                    for name, component in results["components"].items():
                        if component["status"] != HealthStatus.HEALTHY:
                            print(f"  - {name}: {component['status']}")
                            if "error" in component:
                                print(f"    Error: {component['error']}")
                
            except Exception as e:
                print(f"Health check scheduler error: {e}")
            
            # Aguardar próximo ciclo
            await asyncio.sleep(self.interval)
    
    def stop(self):
        """Para execução periódica"""
        self.running = False
    
    def get_last_results(self) -> Dict[str, Any]:
        """Retorna últimos resultados"""
        return self.last_results


# Instância global do scheduler
health_scheduler = HealthCheckScheduler(interval=settings.health_check_interval)

