"""
Middleware da API de Governança de Dados V1.4
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

import time
import logging
from typing import Callable
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger(__name__)

class LoggingMiddleware(BaseHTTPMiddleware):
    """Middleware para logging de requisições"""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Processa requisição com logging"""
        
        start_time = time.time()
        
        # Log da requisição
        logger.info(f"Requisição iniciada: {request.method} {request.url}")
        
        try:
            # Processar requisição
            response = await call_next(request)
            
            # Calcular tempo de processamento
            process_time = time.time() - start_time
            
            # Log da resposta
            logger.info(
                f"Requisição concluída: {request.method} {request.url} "
                f"- Status: {response.status_code} "
                f"- Tempo: {process_time:.3f}s"
            )
            
            # Adicionar header com tempo de processamento
            response.headers["X-Process-Time"] = str(process_time)
            
            return response
            
        except Exception as e:
            # Log de erro
            process_time = time.time() - start_time
            logger.error(
                f"Erro na requisição: {request.method} {request.url} "
                f"- Erro: {str(e)} "
                f"- Tempo: {process_time:.3f}s"
            )
            raise

class CORSMiddleware(BaseHTTPMiddleware):
    """Middleware para CORS"""
    
    def __init__(self, app, allow_origins=None, allow_methods=None, allow_headers=None):
        super().__init__(app)
        self.allow_origins = allow_origins or ["*"]
        self.allow_methods = allow_methods or ["GET", "POST", "PUT", "DELETE", "OPTIONS"]
        self.allow_headers = allow_headers or ["*"]
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Processa requisição com CORS"""
        
        # Processar requisição OPTIONS (preflight)
        if request.method == "OPTIONS":
            response = Response()
        else:
            response = await call_next(request)
        
        # Adicionar headers CORS
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Methods"] = ", ".join(self.allow_methods)
        response.headers["Access-Control-Allow-Headers"] = ", ".join(self.allow_headers)
        response.headers["Access-Control-Allow-Credentials"] = "true"
        
        return response

class SecurityMiddleware(BaseHTTPMiddleware):
    """Middleware para segurança"""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Processa requisição com headers de segurança"""
        
        response = await call_next(request)
        
        # Headers de segurança
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        
        return response

class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware para rate limiting básico"""
    
    def __init__(self, app, max_requests=100, window_seconds=60):
        super().__init__(app)
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.requests = {}
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Processa requisição com rate limiting"""
        
        client_ip = request.client.host
        current_time = time.time()
        
        # Limpar requisições antigas
        if client_ip in self.requests:
            self.requests[client_ip] = [
                req_time for req_time in self.requests[client_ip]
                if current_time - req_time < self.window_seconds
            ]
        else:
            self.requests[client_ip] = []
        
        # Verificar limite
        if len(self.requests[client_ip]) >= self.max_requests:
            logger.warning(f"Rate limit excedido para IP: {client_ip}")
            return Response(
                content="Rate limit exceeded",
                status_code=429,
                headers={"Retry-After": str(self.window_seconds)}
            )
        
        # Registrar requisição
        self.requests[client_ip].append(current_time)
        
        return await call_next(request)

