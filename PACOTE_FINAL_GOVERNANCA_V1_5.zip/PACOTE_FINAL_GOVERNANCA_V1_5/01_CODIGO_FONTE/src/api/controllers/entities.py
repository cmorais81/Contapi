"""
Controller de Entidades de Dados
API de Governança de Dados V1.4
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional, Dict, Any
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# Criar router
router = APIRouter()

# Simulação de dados em memória
entities_db = {}

@router.get("/entities", summary="Listar entidades")
async def list_entities(
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    entity_type: Optional[str] = Query(None)
):
    """
    Lista todas as entidades de dados disponíveis.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        entities_list = list(entities_db.values())
        
        # Filtrar por tipo se especificado
        if entity_type:
            entities_list = [e for e in entities_list if e.get('type') == entity_type]
        
        total = len(entities_list)
        
        # Aplicar paginação
        start = offset
        end = offset + limit
        paginated_entities = entities_list[start:end]
        
        logger.info(f"Listando {len(paginated_entities)} entidades de {total} total")
        
        return {
            "entities": paginated_entities,
            "total": total,
            "limit": limit,
            "offset": offset,
            "filter": {"entity_type": entity_type} if entity_type else None,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar entidades: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/entities/{entity_id}", summary="Obter entidade")
async def get_entity(entity_id: str):
    """
    Obtém uma entidade específica por ID.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        if entity_id not in entities_db:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        entity = entities_db[entity_id]
        logger.info(f"Entidade encontrada: {entity_id}")
        
        return {
            "entity": entity,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/entities", summary="Criar entidade")
async def create_entity(entity_data: Dict[str, Any]):
    """
    Cria uma nova entidade de dados.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        entity_id = entity_data.get('id', f"entity_{len(entities_db) + 1}")
        
        if entity_id in entities_db:
            raise HTTPException(status_code=409, detail="Entidade já existe")
        
        entity = {
            'id': entity_id,
            'name': entity_data.get('name', 'Unnamed Entity'),
            'description': entity_data.get('description', ''),
            'type': entity_data.get('type', 'table'),
            'schema': entity_data.get('schema', {}),
            'metadata': entity_data.get('metadata', {}),
            'status': 'active',
            'created_at': datetime.utcnow().isoformat(),
            'updated_at': datetime.utcnow().isoformat(),
            'owner': entity_data.get('owner', 'system'),
            'tags': entity_data.get('tags', []),
            'author': 'Carlos Morais',
            'email': 'carlos.morais@f1rst.com.br'
        }
        
        entities_db[entity_id] = entity
        logger.info(f"Entidade criada: {entity_id}")
        
        return {
            "message": "Entidade criada com sucesso",
            "entity": entity,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao criar entidade: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/entities/{entity_id}", summary="Atualizar entidade")
async def update_entity(entity_id: str, update_data: Dict[str, Any]):
    """
    Atualiza uma entidade existente.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        if entity_id not in entities_db:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        entity = entities_db[entity_id]
        
        # Atualizar campos permitidos
        updatable_fields = ['name', 'description', 'schema', 'metadata', 'tags']
        for field in updatable_fields:
            if field in update_data:
                entity[field] = update_data[field]
        
        entity['updated_at'] = datetime.utcnow().isoformat()
        
        logger.info(f"Entidade atualizada: {entity_id}")
        
        return {
            "message": "Entidade atualizada com sucesso",
            "entity": entity,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao atualizar entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.delete("/entities/{entity_id}", summary="Remover entidade")
async def delete_entity(entity_id: str):
    """
    Remove uma entidade.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        if entity_id not in entities_db:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        del entities_db[entity_id]
        logger.info(f"Entidade removida: {entity_id}")
        
        return {
            "message": "Entidade removida com sucesso",
            "entity_id": entity_id,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao remover entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/entities/{entity_id}/schema", summary="Schema da entidade")
async def get_entity_schema(entity_id: str):
    """
    Obtém o schema de uma entidade.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        if entity_id not in entities_db:
            raise HTTPException(status_code=404, detail="Entidade não encontrada")
        
        entity = entities_db[entity_id]
        schema = entity.get('schema', {})
        
        logger.info(f"Schema obtido para entidade: {entity_id}")
        
        return {
            "entity_id": entity_id,
            "schema": schema,
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter schema da entidade {entity_id}: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/entities/types", summary="Tipos de entidades")
async def get_entity_types():
    """
    Lista os tipos de entidades disponíveis.
    
    Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
    """
    try:
        entity_types = [
            {
                "type": "table",
                "description": "Tabela de banco de dados",
                "icon": "table"
            },
            {
                "type": "view",
                "description": "View de banco de dados",
                "icon": "view"
            },
            {
                "type": "file",
                "description": "Arquivo de dados",
                "icon": "file"
            },
            {
                "type": "api",
                "description": "Endpoint de API",
                "icon": "api"
            },
            {
                "type": "stream",
                "description": "Stream de dados",
                "icon": "stream"
            }
        ]
        
        logger.info("Tipos de entidades listados")
        
        return {
            "entity_types": entity_types,
            "total": len(entity_types),
            "author": "Carlos Morais",
            "email": "carlos.morais@f1rst.com.br"
        }
        
    except Exception as e:
        logger.error(f"Erro ao listar tipos de entidades: {e}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

