"""
DTOs para Workflows e Aprovações
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional, Union
from uuid import UUID

from pydantic import BaseModel, Field


class WorkflowType(str, Enum):
    """Tipo de workflow"""
    DATA_ACCESS_REQUEST = "data_access_request"
    CONTRACT_APPROVAL = "contract_approval"
    POLICY_CHANGE = "policy_change"
    STEWARD_ASSIGNMENT = "steward_assignment"
    CLASSIFICATION_REVIEW = "classification_review"
    QUALITY_EXCEPTION = "quality_exception"
    RETENTION_APPROVAL = "retention_approval"
    CUSTOM = "custom"


class WorkflowStatus(str, Enum):
    """Status do workflow"""
    DRAFT = "draft"
    SUBMITTED = "submitted"
    IN_REVIEW = "in_review"
    PENDING_APPROVAL = "pending_approval"
    APPROVED = "approved"
    REJECTED = "rejected"
    CANCELLED = "cancelled"
    COMPLETED = "completed"


class ApprovalAction(str, Enum):
    """Ação de aprovação"""
    APPROVE = "approve"
    REJECT = "reject"
    REQUEST_CHANGES = "request_changes"
    DELEGATE = "delegate"
    ESCALATE = "escalate"


class Priority(str, Enum):
    """Prioridade"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


class WorkflowDefinitionDTO(BaseModel):
    """DTO para definição de workflow"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str
    workflow_type: WorkflowType
    steps: List[Dict] = Field(min_items=1)
    approval_matrix: Dict = Field(default_factory=dict)
    auto_approval_rules: List[Dict] = Field(default_factory=list)
    escalation_rules: List[Dict] = Field(default_factory=list)
    sla_hours: Optional[int] = Field(None, ge=1)
    is_active: bool = Field(default=True)
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Data Access Request Workflow",
                "description": "Standard workflow for data access requests",
                "workflow_type": "data_access_request",
                "steps": [
                    {
                        "step_id": "initial_review",
                        "name": "Initial Review",
                        "type": "approval",
                        "approvers": ["data_steward"],
                        "required_approvals": 1,
                        "auto_approve_conditions": []
                    },
                    {
                        "step_id": "security_review",
                        "name": "Security Review",
                        "type": "approval",
                        "approvers": ["security_team"],
                        "required_approvals": 1,
                        "conditions": ["classification == 'confidential'"]
                    }
                ],
                "approval_matrix": {
                    "data_steward": ["domain_steward", "data_owner"],
                    "security_team": ["security_manager", "ciso"]
                },
                "auto_approval_rules": [
                    {
                        "condition": "classification == 'public' AND requester_role == 'analyst'",
                        "action": "auto_approve"
                    }
                ],
                "escalation_rules": [
                    {
                        "condition": "sla_exceeded",
                        "escalate_to": "manager",
                        "escalate_after_hours": 24
                    }
                ],
                "sla_hours": 72,
                "metadata": {"department": "data_governance"}
            }
        }


class WorkflowInstanceDTO(BaseModel):
    """DTO para instância de workflow"""
    workflow_definition_id: UUID
    title: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    priority: Priority = Priority.MEDIUM
    requester_id: UUID
    context_data: Dict = Field(default_factory=dict)
    attachments: List[str] = Field(default_factory=list)
    due_date: Optional[datetime] = None
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "workflow_definition_id": "123e4567-e89b-12d3-a456-426614174000",
                "title": "Access to Customer Database",
                "description": "Request access to customer database for analytics project",
                "priority": "high",
                "requester_id": "456e7890-e89b-12d3-a456-426614174000",
                "context_data": {
                    "entity_id": "789e0123-e89b-12d3-a456-426614174000",
                    "access_type": "read_only",
                    "business_justification": "Customer segmentation analysis",
                    "project_code": "PROJ-2025-001"
                },
                "attachments": ["business_case.pdf", "data_usage_agreement.pdf"],
                "due_date": "2025-01-21T17:00:00Z",
                "metadata": {"department": "marketing", "cost_center": "CC-001"}
            }
        }


class WorkflowInstanceResponseDTO(BaseModel):
    """DTO para resposta de instância de workflow"""
    id: UUID
    workflow_definition_id: UUID
    workflow_name: str
    title: str
    description: Optional[str]
    status: WorkflowStatus
    priority: Priority
    requester_id: UUID
    requester_name: str
    current_step: Optional[str]
    current_approvers: List[str] = Field(default_factory=list)
    progress_percentage: float = Field(ge=0, le=100)
    context_data: Dict
    attachments: List[str]
    due_date: Optional[datetime]
    sla_status: str  # on_time, at_risk, overdue
    created_at: datetime
    updated_at: datetime
    completed_at: Optional[datetime] = None
    metadata: Dict

    class Config:
        from_attributes = True


class ApprovalRequestDTO(BaseModel):
    """DTO para solicitação de aprovação"""
    workflow_instance_id: UUID
    step_id: str
    action: ApprovalAction
    comments: Optional[str] = None
    conditions: Dict = Field(default_factory=dict)
    delegate_to: Optional[UUID] = None
    attachments: List[str] = Field(default_factory=list)

    class Config:
        json_schema_extra = {
            "example": {
                "workflow_instance_id": "123e4567-e89b-12d3-a456-426614174000",
                "step_id": "initial_review",
                "action": "approve",
                "comments": "Request approved with conditions",
                "conditions": {
                    "access_duration": "30_days",
                    "monitoring_required": True
                },
                "attachments": ["approval_conditions.pdf"]
            }
        }


class ApprovalResponseDTO(BaseModel):
    """DTO para resposta de aprovação"""
    id: UUID
    workflow_instance_id: UUID
    step_id: str
    step_name: str
    approver_id: UUID
    approver_name: str
    action: ApprovalAction
    comments: Optional[str]
    conditions: Dict
    delegate_to: Optional[UUID] = None
    delegate_to_name: Optional[str] = None
    attachments: List[str]
    approved_at: datetime
    metadata: Dict

    class Config:
        from_attributes = True


class WorkflowStepDTO(BaseModel):
    """DTO para etapa do workflow"""
    step_id: str
    name: str
    description: Optional[str]
    step_type: str  # approval, review, notification, automation
    status: str  # pending, in_progress, completed, skipped
    required_approvals: int = Field(default=1, ge=1)
    current_approvals: int = Field(default=0, ge=0)
    approvers: List[str] = Field(default_factory=list)
    current_assignees: List[str] = Field(default_factory=list)
    conditions: List[str] = Field(default_factory=list)
    auto_approve_conditions: List[str] = Field(default_factory=list)
    sla_hours: Optional[int] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    metadata: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "step_id": "security_review",
                "name": "Security Review",
                "description": "Review security implications of data access",
                "step_type": "approval",
                "status": "pending",
                "required_approvals": 1,
                "current_approvals": 0,
                "approvers": ["security_team"],
                "current_assignees": ["john.security@company.com"],
                "conditions": ["classification == 'confidential'"],
                "sla_hours": 24,
                "metadata": {"escalation_enabled": True}
            }
        }


class WorkflowHistoryDTO(BaseModel):
    """DTO para histórico do workflow"""
    id: UUID
    workflow_instance_id: UUID
    action: str
    actor_id: UUID
    actor_name: str
    step_id: Optional[str] = None
    step_name: Optional[str] = None
    description: str
    details: Dict = Field(default_factory=dict)
    timestamp: datetime

    class Config:
        from_attributes = True


class WorkflowMetricsDTO(BaseModel):
    """DTO para métricas de workflow"""
    workflow_type: WorkflowType
    total_instances: int
    completed_instances: int
    pending_instances: int
    rejected_instances: int
    avg_completion_time_hours: float
    avg_approval_time_hours: float
    sla_compliance_rate: float = Field(ge=0, le=1)
    bottleneck_steps: List[Dict] = Field(default_factory=list)
    top_rejectors: List[Dict] = Field(default_factory=list)
    approval_patterns: Dict = Field(default_factory=dict)
    period_start: datetime
    period_end: datetime

    class Config:
        json_schema_extra = {
            "example": {
                "workflow_type": "data_access_request",
                "total_instances": 150,
                "completed_instances": 120,
                "pending_instances": 25,
                "rejected_instances": 5,
                "avg_completion_time_hours": 48.5,
                "avg_approval_time_hours": 12.3,
                "sla_compliance_rate": 0.85,
                "bottleneck_steps": [
                    {"step_id": "security_review", "avg_time_hours": 36.2}
                ],
                "top_rejectors": [
                    {"approver": "security_team", "rejection_rate": 0.15}
                ],
                "approval_patterns": {
                    "auto_approved": 0.30,
                    "single_approval": 0.45,
                    "multiple_approvals": 0.25
                },
                "period_start": "2025-01-01T00:00:00Z",
                "period_end": "2025-01-14T23:59:59Z"
            }
        }


class TaskDTO(BaseModel):
    """DTO para tarefa pendente"""
    id: UUID
    workflow_instance_id: UUID
    workflow_title: str
    step_id: str
    step_name: str
    task_type: str  # approval, review, notification
    priority: Priority
    assignee_id: UUID
    assignee_name: str
    description: str
    due_date: Optional[datetime]
    sla_status: str  # on_time, at_risk, overdue
    context_data: Dict
    created_at: datetime
    metadata: Dict

    class Config:
        from_attributes = True


class BulkApprovalDTO(BaseModel):
    """DTO para aprovação em lote"""
    workflow_instance_ids: List[UUID] = Field(min_items=1, max_items=50)
    action: ApprovalAction
    comments: Optional[str] = None
    conditions: Dict = Field(default_factory=dict)

    class Config:
        json_schema_extra = {
            "example": {
                "workflow_instance_ids": [
                    "123e4567-e89b-12d3-a456-426614174000",
                    "456e7890-e89b-12d3-a456-426614174000"
                ],
                "action": "approve",
                "comments": "Bulk approval for routine requests",
                "conditions": {"monitoring_required": True}
            }
        }


class BulkApprovalResultDTO(BaseModel):
    """DTO para resultado de aprovação em lote"""
    total_requests: int
    successful_approvals: int
    failed_approvals: int
    errors: List[Dict] = Field(default_factory=list)
    processing_time_ms: int

    class Config:
        json_schema_extra = {
            "example": {
                "total_requests": 10,
                "successful_approvals": 8,
                "failed_approvals": 2,
                "errors": [
                    {
                        "workflow_instance_id": "123e4567-e89b-12d3-a456-426614174000",
                        "error": "Workflow already completed"
                    }
                ],
                "processing_time_ms": 1500
            }
        }


class WorkflowTemplateDTO(BaseModel):
    """DTO para template de workflow"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str
    category: str
    workflow_type: WorkflowType
    template_data: Dict
    is_public: bool = Field(default=False)
    tags: List[str] = Field(default_factory=list)

    class Config:
        json_schema_extra = {
            "example": {
                "name": "Standard Data Access Template",
                "description": "Template for routine data access requests",
                "category": "data_access",
                "workflow_type": "data_access_request",
                "template_data": {
                    "default_priority": "medium",
                    "default_sla_hours": 48,
                    "required_fields": ["business_justification", "access_duration"]
                },
                "is_public": True,
                "tags": ["standard", "data_access", "routine"]
            }
        }

