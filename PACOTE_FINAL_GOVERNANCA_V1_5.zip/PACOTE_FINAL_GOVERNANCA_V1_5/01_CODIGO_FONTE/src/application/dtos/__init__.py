"""
Módulo de DTOs (Data Transfer Objects)
API de Governança de Dados V1.5
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
"""

# Importações seguras dos DTOs disponíveis
try:
    from .domains import *
except ImportError:
    pass

try:
    from .lineage import *
except ImportError:
    pass

try:
    from .policies import *
except ImportError:
    pass

try:
    from .stewardship import *
except ImportError:
    pass

try:
    from .tags import *
except ImportError:
    pass

try:
    from .analytics import *
except ImportError:
    pass

try:
    from .discovery import *
except ImportError:
    pass

try:
    from .workflows import *
except ImportError:
    pass

try:
    from .notifications import *
except ImportError:
    pass

try:
    from .integrations import *
except ImportError:
    pass

try:
    from .security import *
except ImportError:
    pass

try:
    from .performance import *
except ImportError:
    pass

__all__ = [
    # Domains
    'DomainCreateDTO', 'DomainResponseDTO', 'DomainUpdateDTO',
    # Lineage
    'LineageCreateDTO', 'LineageResponseDTO', 'LineageUpdateDTO',
    # Policies
    'PolicyCreateDTO', 'PolicyResponseDTO', 'PolicyUpdateDTO',
    # Stewardship
    'StewardCreateDTO', 'StewardResponseDTO', 'StewardUpdateDTO',
    # Tags
    'TagCreateDTO', 'TagResponseDTO', 'TagUpdateDTO',
    # Analytics
    'AnalyticsCreateDTO', 'AnalyticsResponseDTO', 'AnalyticsUpdateDTO',
    # Discovery
    'DiscoveryCreateDTO', 'DiscoveryResponseDTO', 'DiscoveryUpdateDTO',
    # Workflows
    'WorkflowCreateDTO', 'WorkflowResponseDTO', 'WorkflowUpdateDTO',
    # Notifications
    'NotificationCreateDTO', 'NotificationResponseDTO', 'NotificationUpdateDTO',
    # Integrations
    'IntegrationCreateDTO', 'IntegrationResponseDTO', 'IntegrationUpdateDTO',
    # Security
    'SecurityCreateDTO', 'SecurityResponseDTO', 'SecurityUpdateDTO',
    # Performance
    'PerformanceCreateDTO', 'PerformanceResponseDTO', 'PerformanceUpdateDTO'
]

