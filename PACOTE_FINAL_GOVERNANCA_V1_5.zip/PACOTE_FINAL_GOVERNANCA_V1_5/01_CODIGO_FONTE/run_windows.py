"""
Script de execução para Windows - API de Governança de Dados V1.3
Desenvolvido por: Carlos Morais (carlos.morais@f1rst.com.br)
Organização: F1rst

Este script configura o ambiente Python corretamente para Windows
e executa a API com todas as configurações necessárias.
"""

import sys
import os
from pathlib import Path
import subprocess
import logging

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def setup_environment():
    """Configura o ambiente Python para Windows"""
    
    # Obter diretório atual
    current_dir = Path(__file__).parent
    src_dir = current_dir / "src"
    
    # Adicionar src ao PYTHONPATH
    if str(src_dir) not in sys.path:
        sys.path.insert(0, str(src_dir))
    
    # Configurar variável de ambiente PYTHONPATH
    current_pythonpath = os.environ.get('PYTHONPATH', '')
    if str(src_dir) not in current_pythonpath:
        if current_pythonpath:
            os.environ['PYTHONPATH'] = f"{src_dir}{os.pathsep}{current_pythonpath}"
        else:
            os.environ['PYTHONPATH'] = str(src_dir)
    
    logger.info(f"PYTHONPATH configurado: {os.environ.get('PYTHONPATH')}")
    logger.info(f"Diretório src: {src_dir}")
    logger.info(f"Python version: {sys.version}")
    logger.info(f"Platform: {sys.platform}")

def check_dependencies():
    """Verifica se as dependências estão instaladas"""
    
    required_packages = [
        'fastapi',
        'uvicorn',
        'sqlalchemy',
        'pydantic',
        'python-dotenv'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package.replace('-', '_'))
            logger.info(f"✓ {package} está instalado")
        except ImportError:
            missing_packages.append(package)
            logger.warning(f"✗ {package} não está instalado")
    
    if missing_packages:
        logger.error(f"Pacotes faltando: {', '.join(missing_packages)}")
        logger.info("Execute: pip install -r requirements.txt")
        return False
    
    return True

def run_api():
    """Executa a API"""
    
    try:
        # Importar e executar a API
        sys.path.insert(0, str(Path(__file__).parent / "src"))
        
        import uvicorn
        from main import app
        
        logger.info("Iniciando API de Governança de Dados V1.3")
        logger.info("Desenvolvida por: Carlos Morais (carlos.morais@f1rst.com.br)")
        logger.info("Organização: F1rst")
        logger.info("Acesse: http://localhost:8000")
        logger.info("Documentação: http://localhost:8000/docs")
        
        uvicorn.run(
            app,
            host="0.0.0.0",
            port=8000,
            reload=True,
            log_level="info"
        )
        
    except ImportError as e:
        logger.error(f"Erro ao importar módulos: {e}")
        logger.info("Verifique se todas as dependências estão instaladas")
        logger.info("Execute: pip install -r requirements.txt")
        return False
    except Exception as e:
        logger.error(f"Erro ao executar API: {e}")
        return False
    
    return True

def main():
    """Função principal"""
    
    print("=" * 60)
    print("API de Governança de Dados V1.3")
    print("Desenvolvida por: Carlos Morais")
    print("Email: carlos.morais@f1rst.com.br")
    print("Organização: F1rst")
    print("=" * 60)
    
    # Configurar ambiente
    logger.info("Configurando ambiente...")
    setup_environment()
    
    # Verificar dependências
    logger.info("Verificando dependências...")
    if not check_dependencies():
        input("Pressione Enter para sair...")
        return
    
    # Executar API
    logger.info("Executando API...")
    try:
        run_api()
    except KeyboardInterrupt:
        logger.info("API interrompida pelo usuário")
    except Exception as e:
        logger.error(f"Erro inesperado: {e}")
        input("Pressione Enter para sair...")

if __name__ == "__main__":
    main()

