#!/bin/bash

# ========================================
# API de Governança de Dados V1.0
# Script de Instalação Automática
# ========================================
# Desenvolvido por: Carlos Morais - F1rst
# Email: carlos.morais@f1rst.com.br
# Junho 2025
# ========================================

set -e  # Parar em caso de erro

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para log
log() {
    echo -e "${GREEN}[$(date +'%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date +'%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

# Banner
echo -e "${BLUE}"
echo "=========================================="
echo "  API de Governança de Dados V1.0"
echo "  Instalação Automática"
echo "=========================================="
echo "  Desenvolvido por: Carlos Morais"
echo "  Organização: F1rst"
echo "  Email: carlos.morais@f1rst.com.br"
echo "  Junho 2025"
echo "=========================================="
echo -e "${NC}"

# Verificar se está rodando como root
if [[ $EUID -eq 0 ]]; then
   error "Este script não deve ser executado como root"
fi

# Verificar sistema operacional
if [[ "$OSTYPE" != "linux-gnu"* ]]; then
    error "Este script é compatível apenas com Linux"
fi

# Verificar distribuição
if ! command -v apt-get &> /dev/null && ! command -v yum &> /dev/null; then
    error "Sistema não suportado. Requer Ubuntu/Debian ou CentOS/RHEL"
fi

log "Iniciando instalação da API de Governança de Dados V1.0..."

# 1. Atualizar sistema
log "Atualizando sistema..."
if command -v apt-get &> /dev/null; then
    sudo apt-get update -y
    sudo apt-get upgrade -y
else
    sudo yum update -y
fi

# 2. Instalar dependências do sistema
log "Instalando dependências do sistema..."
if command -v apt-get &> /dev/null; then
    sudo apt-get install -y \
        python3.11 \
        python3.11-venv \
        python3.11-dev \
        python3-pip \
        postgresql-14 \
        postgresql-client-14 \
        postgresql-contrib-14 \
        redis-server \
        nginx \
        curl \
        wget \
        git \
        build-essential \
        libpq-dev \
        libssl-dev \
        libffi-dev \
        pkg-config
else
    sudo yum install -y \
        python3.11 \
        python3.11-devel \
        python3-pip \
        postgresql14-server \
        postgresql14 \
        postgresql14-contrib \
        redis \
        nginx \
        curl \
        wget \
        git \
        gcc \
        gcc-c++ \
        make \
        postgresql-devel \
        openssl-devel \
        libffi-devel
fi

# 3. Configurar PostgreSQL
log "Configurando PostgreSQL..."
if command -v apt-get &> /dev/null; then
    sudo systemctl start postgresql
    sudo systemctl enable postgresql
else
    sudo postgresql-setup --initdb
    sudo systemctl start postgresql
    sudo systemctl enable postgresql
fi

# Criar usuário e banco de dados
sudo -u postgres psql -c "CREATE USER governance_user WITH PASSWORD 'governance_pass';" || true
sudo -u postgres psql -c "CREATE DATABASE governance_db OWNER governance_user;" || true
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE governance_db TO governance_user;" || true

# 4. Configurar Redis
log "Configurando Redis..."
sudo systemctl start redis
sudo systemctl enable redis

# 5. Criar ambiente virtual Python
log "Criando ambiente virtual Python..."
cd ../01_CODIGO_FONTE
python3.11 -m venv venv
source venv/bin/activate

# 6. Instalar dependências Python
log "Instalando dependências Python..."
pip install --upgrade pip
pip install -r requirements.txt

# 7. Configurar variáveis de ambiente
log "Configurando variáveis de ambiente..."
if [ ! -f .env ]; then
    cp .env.example .env
    log "Arquivo .env criado. Configure as variáveis antes de continuar."
fi

# 8. Executar migrações do banco
log "Executando migrações do banco de dados..."
export DATABASE_URL="postgresql://governance_user:governance_pass@localhost:5432/governance_db"
python -c "
import sys
sys.path.append('src')
from database.models import Base
from sqlalchemy import create_engine
engine = create_engine('$DATABASE_URL')
Base.metadata.create_all(engine)
print('Tabelas criadas com sucesso!')
"

# 9. Executar testes
log "Executando testes..."
python -m pytest tests/ -v --tb=short

# 10. Configurar Nginx (opcional)
log "Configurando Nginx..."
sudo tee /etc/nginx/sites-available/governance-api > /dev/null <<EOF
server {
    listen 80;
    server_name localhost;
    
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

sudo ln -sf /etc/nginx/sites-available/governance-api /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# 11. Criar scripts de controle
log "Criando scripts de controle..."

# Script de inicialização
cat > start_api.sh << 'EOF'
#!/bin/bash
cd "$(dirname "$0")/../01_CODIGO_FONTE"
source venv/bin/activate
export PYTHONPATH="$PWD/src:$PYTHONPATH"
uvicorn src.main:app --host 0.0.0.0 --port 8000 --workers 4
EOF

# Script de parada
cat > stop_api.sh << 'EOF'
#!/bin/bash
pkill -f "uvicorn src.main:app"
echo "API parada"
EOF

# Script de status
cat > status_api.sh << 'EOF'
#!/bin/bash
if pgrep -f "uvicorn src.main:app" > /dev/null; then
    echo "API está rodando"
    curl -s http://localhost:8000/health | jq .
else
    echo "API não está rodando"
fi
EOF

# Script de logs
cat > logs_api.sh << 'EOF'
#!/bin/bash
tail -f ../01_CODIGO_FONTE/logs/app.log
EOF

# Tornar scripts executáveis
chmod +x *.sh

# 12. Criar serviço systemd
log "Criando serviço systemd..."
sudo tee /etc/systemd/system/governance-api.service > /dev/null <<EOF
[Unit]
Description=API de Governança de Dados V1.0
After=network.target postgresql.service redis.service

[Service]
Type=exec
User=$USER
Group=$USER
WorkingDirectory=$PWD/../01_CODIGO_FONTE
Environment=PATH=$PWD/../01_CODIGO_FONTE/venv/bin
Environment=PYTHONPATH=$PWD/../01_CODIGO_FONTE/src
ExecStart=$PWD/../01_CODIGO_FONTE/venv/bin/uvicorn src.main:app --host 0.0.0.0 --port 8000 --workers 4
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable governance-api

# 13. Verificar instalação
log "Verificando instalação..."

# Verificar serviços
services=("postgresql" "redis" "nginx")
for service in "${services[@]}"; do
    if systemctl is-active --quiet $service; then
        log "✓ $service está rodando"
    else
        warn "✗ $service não está rodando"
    fi
done

# Verificar conectividade do banco
if python -c "
import psycopg2
try:
    conn = psycopg2.connect('postgresql://governance_user:governance_pass@localhost:5432/governance_db')
    conn.close()
    print('✓ Conexão com PostgreSQL OK')
except:
    print('✗ Erro na conexão com PostgreSQL')
"; then
    log "Banco de dados configurado corretamente"
else
    error "Erro na configuração do banco de dados"
fi

# Verificar Redis
if redis-cli ping | grep -q PONG; then
    log "✓ Redis está funcionando"
else
    warn "✗ Redis não está respondendo"
fi

# 14. Finalização
log "Instalação concluída com sucesso!"
echo
echo -e "${BLUE}=========================================="
echo "  INSTALAÇÃO CONCLUÍDA"
echo "=========================================="
echo
echo "Para iniciar a API:"
echo "  ./start_api.sh"
echo
echo "Para verificar status:"
echo "  ./status_api.sh"
echo
echo "Para ver logs:"
echo "  ./logs_api.sh"
echo
echo "Para parar a API:"
echo "  ./stop_api.sh"
echo
echo "URLs de acesso:"
echo "  Health Check: http://localhost:8000/health"
echo "  Swagger UI:   http://localhost:8000/docs"
echo "  ReDoc:        http://localhost:8000/redoc"
echo
echo "Desenvolvido por Carlos Morais - F1rst"
echo "Email: carlos.morais@f1rst.com.br"
echo "=========================================="
echo -e "${NC}"

# Perguntar se deve iniciar a API
read -p "Deseja iniciar a API agora? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log "Iniciando API..."
    ./start_api.sh &
    sleep 5
    ./status_api.sh
fi

log "Instalação finalizada. Consulte a documentação para próximos passos."

