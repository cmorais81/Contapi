# Databricks notebook source
# MAGIC %md
# MAGIC # Unity Catalog Data Extractor para API de Governança de Dados
# MAGIC 
# MAGIC **Desenvolvido por:** Carlos Morais  
# MAGIC **Versão:** 2.1  
# MAGIC **Data:** Janeiro 2025
# MAGIC 
# MAGIC ## Objetivo
# MAGIC Este notebook extrai metadados e dados do Unity Catalog para alimentar o modelo de governança de dados com 56 tabelas baseado no ODCS v3.0.2.
# MAGIC 
# MAGIC ## Funcionalidades
# MAGIC - Extração de catálogos, schemas e tabelas
# MAGIC - Metadados de colunas e tipos de dados
# MAGIC - Lineage e relacionamentos
# MAGIC - Políticas de acesso e mascaramento
# MAGIC - Métricas de uso e qualidade
# MAGIC - Tags e classificações
# MAGIC - Histórico de mudanças

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Configuração e Imports

# COMMAND ----------

import json
import pandas as pd
from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import requests
import uuid
import logging

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configurações da API de Governança
API_BASE_URL = "https://your-governance-api.com/api/v1"  # Substituir pela URL real
API_TOKEN = dbutils.secrets.get(scope="governance", key="api_token")  # Token da API

# Headers para requisições
headers = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}

print("✅ Configuração inicial concluída")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Funções Auxiliares

# COMMAND ----------

def generate_uuid():
    """Gera UUID único"""
    return str(uuid.uuid4())

def safe_api_call(url, method="GET", data=None, max_retries=3):
    """Faz chamada segura para a API com retry"""
    for attempt in range(max_retries):
        try:
            if method == "GET":
                response = requests.get(url, headers=headers, timeout=30)
            elif method == "POST":
                response = requests.post(url, headers=headers, json=data, timeout=30)
            elif method == "PUT":
                response = requests.put(url, headers=headers, json=data, timeout=30)
            
            if response.status_code in [200, 201]:
                return response.json() if response.content else {}
            elif response.status_code == 404:
                logger.warning(f"Recurso não encontrado: {url}")
                return None
            else:
                logger.error(f"Erro na API: {response.status_code} - {response.text}")
                
        except Exception as e:
            logger.error(f"Tentativa {attempt + 1} falhou: {str(e)}")
            if attempt == max_retries - 1:
                raise
    
    return None

def extract_unity_catalog_metadata():
    """Extrai metadados completos do Unity Catalog"""
    
    # Obter lista de catálogos
    catalogs_df = spark.sql("SHOW CATALOGS")
    
    metadata = {
        "catalogs": [],
        "schemas": [],
        "tables": [],
        "columns": [],
        "functions": [],
        "volumes": []
    }
    
    for catalog_row in catalogs_df.collect():
        catalog_name = catalog_row['catalog']
        
        # Pular catálogos do sistema
        if catalog_name in ['system', 'information_schema']:
            continue
            
        catalog_info = {
            "name": catalog_name,
            "type": "catalog",
            "created_at": datetime.now().isoformat(),
            "properties": {}
        }
        
        try:
            # Obter propriedades do catálogo
            catalog_details = spark.sql(f"DESCRIBE CATALOG EXTENDED {catalog_name}")
            for detail_row in catalog_details.collect():
                if detail_row['info_name'] == 'Properties':
                    catalog_info["properties"] = detail_row['info_value'] or {}
                    
        except Exception as e:
            logger.warning(f"Erro ao obter detalhes do catálogo {catalog_name}: {str(e)}")
        
        metadata["catalogs"].append(catalog_info)
        
        # Obter schemas do catálogo
        try:
            schemas_df = spark.sql(f"SHOW SCHEMAS IN {catalog_name}")
            
            for schema_row in schemas_df.collect():
                schema_name = schema_row['databaseName']
                
                schema_info = {
                    "catalog_name": catalog_name,
                    "name": schema_name,
                    "full_name": f"{catalog_name}.{schema_name}",
                    "type": "schema",
                    "created_at": datetime.now().isoformat(),
                    "properties": {}
                }
                
                metadata["schemas"].append(schema_info)
                
                # Obter tabelas do schema
                try:
                    tables_df = spark.sql(f"SHOW TABLES IN {catalog_name}.{schema_name}")
                    
                    for table_row in tables_df.collect():
                        table_name = table_row['tableName']
                        table_type = table_row.get('isTemporary', False)
                        
                        full_table_name = f"{catalog_name}.{schema_name}.{table_name}"
                        
                        table_info = {
                            "catalog_name": catalog_name,
                            "schema_name": schema_name,
                            "name": table_name,
                            "full_name": full_table_name,
                            "type": "temporary" if table_type else "table",
                            "created_at": datetime.now().isoformat(),
                            "properties": {},
                            "columns": []
                        }
                        
                        # Obter detalhes da tabela
                        try:
                            table_details = spark.sql(f"DESCRIBE TABLE EXTENDED {full_table_name}")
                            
                            for detail_row in table_details.collect():
                                col_name = detail_row['col_name']
                                data_type = detail_row['data_type']
                                comment = detail_row['comment']
                                
                                if col_name and not col_name.startswith('#'):
                                    column_info = {
                                        "name": col_name,
                                        "data_type": data_type,
                                        "comment": comment,
                                        "is_nullable": True,  # Padrão
                                        "is_primary_key": False,
                                        "is_foreign_key": False
                                    }
                                    
                                    table_info["columns"].append(column_info)
                                    
                                    # Adicionar à lista global de colunas
                                    metadata["columns"].append({
                                        "table_full_name": full_table_name,
                                        "column_name": col_name,
                                        "data_type": data_type,
                                        "comment": comment,
                                        "created_at": datetime.now().isoformat()
                                    })
                                    
                        except Exception as e:
                            logger.warning(f"Erro ao obter detalhes da tabela {full_table_name}: {str(e)}")
                        
                        metadata["tables"].append(table_info)
                        
                except Exception as e:
                    logger.warning(f"Erro ao obter tabelas do schema {catalog_name}.{schema_name}: {str(e)}")
                    
        except Exception as e:
            logger.warning(f"Erro ao obter schemas do catálogo {catalog_name}: {str(e)}")
    
    return metadata

print("✅ Funções auxiliares definidas")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Extração de Metadados do Unity Catalog

# COMMAND ----------

print("🔍 Iniciando extração de metadados do Unity Catalog...")

# Extrair metadados
unity_metadata = extract_unity_catalog_metadata()

print(f"📊 Metadados extraídos:")
print(f"  - Catálogos: {len(unity_metadata['catalogs'])}")
print(f"  - Schemas: {len(unity_metadata['schemas'])}")
print(f"  - Tabelas: {len(unity_metadata['tables'])}")
print(f"  - Colunas: {len(unity_metadata['columns'])}")

# Salvar metadados localmente
with open("/tmp/unity_catalog_metadata.json", "w") as f:
    json.dump(unity_metadata, f, indent=2, default=str)

print("✅ Metadados salvos em /tmp/unity_catalog_metadata.json")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Mapeamento para Modelo de Governança

# COMMAND ----------

def map_to_governance_model(metadata):
    """Mapeia metadados do Unity Catalog para o modelo de governança"""
    
    governance_data = {
        "domains": [],
        "entities": [],
        "entity_attributes": [],
        "data_contracts": [],
        "business_terms": [],
        "tags": [],
        "entity_tags": [],
        "lineage_relationships": [],
        "usage_metrics": [],
        "external_references": []
    }
    
    # Criar domínios baseados nos catálogos
    for catalog in metadata["catalogs"]:
        domain = {
            "id": generate_uuid(),
            "name": catalog["name"],
            "description": f"Domínio baseado no catálogo Unity Catalog: {catalog['name']}",
            "parent_domain_id": None,
            "steward_id": None,  # Será preenchido posteriormente
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        governance_data["domains"].append(domain)
    
    # Mapear tabelas para entidades
    domain_map = {d["name"]: d["id"] for d in governance_data["domains"]}
    
    for table in metadata["tables"]:
        entity = {
            "id": generate_uuid(),
            "name": table["name"],
            "type": "table",
            "description": f"Tabela do Unity Catalog: {table['full_name']}",
            "domain_id": domain_map.get(table["catalog_name"]),
            "steward_id": None,
            "unity_catalog_path": table["full_name"],
            "schema_definition": {
                "columns": table["columns"],
                "table_type": table["type"]
            },
            "business_glossary_id": None,
            "classification": "internal",
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "created_by": None,
            "updated_by": None
        }
        governance_data["entities"].append(entity)
        
        # Mapear colunas para atributos de entidade
        for column in table["columns"]:
            attribute = {
                "id": generate_uuid(),
                "entity_id": entity["id"],
                "name": column["name"],
                "data_type": column["data_type"],
                "description": column.get("comment", ""),
                "is_nullable": column.get("is_nullable", True),
                "is_primary_key": column.get("is_primary_key", False),
                "is_foreign_key": column.get("is_foreign_key", False),
                "business_term_id": None,
                "classification": "internal",
                "masking_policy_id": None,
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
            governance_data["entity_attributes"].append(attribute)
        
        # Criar referência externa para Unity Catalog
        external_ref = {
            "id": generate_uuid(),
            "entity_id": entity["id"],
            "reference_type": "unity_catalog",
            "external_id": table["full_name"],
            "external_url": f"databricks://catalog/{table['catalog_name']}/schema/{table['schema_name']}/table/{table['name']}",
            "sync_status": "active",
            "last_synced_at": datetime.now().isoformat(),
            "created_at": datetime.now().isoformat()
        }
        governance_data["external_references"].append(external_ref)
    
    # Criar tags baseadas nos tipos de dados
    data_types = set()
    for table in metadata["tables"]:
        for column in table["columns"]:
            data_types.add(column["data_type"])
    
    for data_type in data_types:
        tag = {
            "id": generate_uuid(),
            "name": f"type_{data_type.lower().replace(' ', '_')}",
            "description": f"Tag para tipo de dados: {data_type}",
            "color": "#007bff",
            "category": "data_type",
            "created_at": datetime.now().isoformat()
        }
        governance_data["tags"].append(tag)
    
    return governance_data

# Mapear dados
print("🔄 Mapeando dados para modelo de governança...")
governance_data = map_to_governance_model(unity_metadata)

print(f"📊 Dados mapeados:")
print(f"  - Domínios: {len(governance_data['domains'])}")
print(f"  - Entidades: {len(governance_data['entities'])}")
print(f"  - Atributos: {len(governance_data['entity_attributes'])}")
print(f"  - Tags: {len(governance_data['tags'])}")
print(f"  - Referências externas: {len(governance_data['external_references'])}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Extração de Lineage e Relacionamentos

# COMMAND ----------

def extract_lineage_information():
    """Extrai informações de lineage do Unity Catalog"""
    
    lineage_data = []
    
    try:
        # Obter informações de lineage usando system tables (se disponível)
        lineage_query = """
        SELECT 
            source_table_full_name,
            target_table_full_name,
            dependency_type,
            created_at
        FROM system.access.table_lineage 
        WHERE created_at >= current_date() - INTERVAL 30 DAYS
        """
        
        lineage_df = spark.sql(lineage_query)
        
        for row in lineage_df.collect():
            lineage_rel = {
                "id": generate_uuid(),
                "source_entity_path": row["source_table_full_name"],
                "target_entity_path": row["target_table_full_name"],
                "relationship_type": row["dependency_type"],
                "transformation_logic": None,
                "confidence_score": 1.0,
                "created_at": row["created_at"].isoformat() if row["created_at"] else datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat()
            }
            lineage_data.append(lineage_rel)
            
    except Exception as e:
        logger.warning(f"Lineage system tables não disponíveis: {str(e)}")
        
        # Fallback: analisar queries recentes para inferir lineage
        try:
            query_history = """
            SELECT 
                statement_text,
                executed_by,
                execution_status,
                start_time
            FROM system.access.audit
            WHERE action_name = 'commandSubmit'
            AND start_time >= current_date() - INTERVAL 7 DAYS
            AND statement_text LIKE '%INSERT%' OR statement_text LIKE '%CREATE%'
            """
            
            history_df = spark.sql(query_history)
            
            for row in history_df.collect():
                # Análise simples de queries para inferir lineage
                statement = row["statement_text"].upper()
                
                if "INSERT INTO" in statement and "SELECT" in statement:
                    # Extrair tabelas de origem e destino (análise básica)
                    # Esta é uma implementação simplificada
                    lineage_rel = {
                        "id": generate_uuid(),
                        "source_entity_path": "inferred_from_query",
                        "target_entity_path": "inferred_from_query",
                        "relationship_type": "derived",
                        "transformation_logic": row["statement_text"][:1000],  # Primeiros 1000 chars
                        "confidence_score": 0.7,  # Menor confiança para inferência
                        "created_at": row["start_time"].isoformat() if row["start_time"] else datetime.now().isoformat(),
                        "updated_at": datetime.now().isoformat()
                    }
                    lineage_data.append(lineage_rel)
                    
        except Exception as e:
            logger.warning(f"Não foi possível extrair lineage do histórico: {str(e)}")
    
    return lineage_data

# Extrair lineage
print("🔗 Extraindo informações de lineage...")
lineage_data = extract_lineage_information()
print(f"📊 Relacionamentos de lineage encontrados: {len(lineage_data)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Extração de Métricas de Uso

# COMMAND ----------

def extract_usage_metrics():
    """Extrai métricas de uso das tabelas"""
    
    usage_metrics = []
    
    try:
        # Métricas de acesso às tabelas
        usage_query = """
        SELECT 
            table_catalog,
            table_schema,
            table_name,
            COUNT(*) as access_count,
            COUNT(DISTINCT user_identity.email) as unique_users,
            DATE(request_time) as access_date
        FROM system.access.audit
        WHERE action_name IN ('commandSubmit', 'read', 'select')
        AND request_time >= current_date() - INTERVAL 30 DAYS
        AND table_catalog IS NOT NULL
        GROUP BY table_catalog, table_schema, table_name, DATE(request_time)
        """
        
        usage_df = spark.sql(usage_query)
        
        for row in usage_df.collect():
            full_table_name = f"{row['table_catalog']}.{row['table_schema']}.{row['table_name']}"
            
            # Métrica de acessos
            access_metric = {
                "id": generate_uuid(),
                "entity_path": full_table_name,
                "metric_type": "access_count",
                "metric_value": float(row["access_count"]),
                "measurement_date": row["access_date"].isoformat() if row["access_date"] else datetime.now().date().isoformat(),
                "additional_data": {
                    "unique_users": row["unique_users"]
                },
                "created_at": datetime.now().isoformat()
            }
            usage_metrics.append(access_metric)
            
            # Métrica de usuários únicos
            users_metric = {
                "id": generate_uuid(),
                "entity_path": full_table_name,
                "metric_type": "unique_users",
                "metric_value": float(row["unique_users"]),
                "measurement_date": row["access_date"].isoformat() if row["access_date"] else datetime.now().date().isoformat(),
                "additional_data": {
                    "total_accesses": row["access_count"]
                },
                "created_at": datetime.now().isoformat()
            }
            usage_metrics.append(users_metric)
            
    except Exception as e:
        logger.warning(f"Não foi possível extrair métricas de uso: {str(e)}")
        
        # Fallback: métricas básicas das tabelas
        for table in unity_metadata["tables"]:
            try:
                # Contar registros na tabela
                count_df = spark.sql(f"SELECT COUNT(*) as row_count FROM {table['full_name']}")
                row_count = count_df.collect()[0]["row_count"]
                
                size_metric = {
                    "id": generate_uuid(),
                    "entity_path": table["full_name"],
                    "metric_type": "row_count",
                    "metric_value": float(row_count),
                    "measurement_date": datetime.now().date().isoformat(),
                    "additional_data": {},
                    "created_at": datetime.now().isoformat()
                }
                usage_metrics.append(size_metric)
                
            except Exception as e:
                logger.warning(f"Erro ao contar registros da tabela {table['full_name']}: {str(e)}")
    
    return usage_metrics

# Extrair métricas
print("📊 Extraindo métricas de uso...")
usage_metrics = extract_usage_metrics()
print(f"📈 Métricas coletadas: {len(usage_metrics)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Envio de Dados para API de Governança

# COMMAND ----------

def send_data_to_governance_api(data_type, data_list, batch_size=50):
    """Envia dados para a API de Governança em lotes"""
    
    endpoint_map = {
        "domains": f"{API_BASE_URL}/domains/",
        "entities": f"{API_BASE_URL}/entities/",
        "entity_attributes": f"{API_BASE_URL}/entities/attributes/",
        "tags": f"{API_BASE_URL}/tags/",
        "external_references": f"{API_BASE_URL}/entities/external-references/",
        "lineage_relationships": f"{API_BASE_URL}/lineage/relationships/",
        "usage_metrics": f"{API_BASE_URL}/metrics/usage/"
    }
    
    if data_type not in endpoint_map:
        logger.error(f"Tipo de dados não suportado: {data_type}")
        return False
    
    endpoint = endpoint_map[data_type]
    total_items = len(data_list)
    success_count = 0
    error_count = 0
    
    print(f"📤 Enviando {total_items} itens de {data_type}...")
    
    # Enviar em lotes
    for i in range(0, total_items, batch_size):
        batch = data_list[i:i + batch_size]
        
        try:
            # Para alguns endpoints, enviar item por item
            if data_type in ["domains", "entities"]:
                for item in batch:
                    response = safe_api_call(endpoint, method="POST", data=item)
                    if response:
                        success_count += 1
                    else:
                        error_count += 1
            else:
                # Enviar lote completo
                response = safe_api_call(endpoint + "batch/", method="POST", data={"items": batch})
                if response:
                    success_count += len(batch)
                else:
                    error_count += len(batch)
                    
        except Exception as e:
            logger.error(f"Erro ao enviar lote {i//batch_size + 1}: {str(e)}")
            error_count += len(batch)
    
    print(f"✅ {data_type}: {success_count} sucessos, {error_count} erros")
    return error_count == 0

# Enviar todos os dados
print("🚀 Iniciando envio de dados para API de Governança...")

# Ordem de envio (respeitando dependências)
send_order = [
    ("domains", governance_data["domains"]),
    ("tags", governance_data["tags"]),
    ("entities", governance_data["entities"]),
    ("entity_attributes", governance_data["entity_attributes"]),
    ("external_references", governance_data["external_references"]),
    ("usage_metrics", usage_metrics)
]

# Adicionar lineage se houver dados
if lineage_data:
    send_order.append(("lineage_relationships", lineage_data))

total_success = True
for data_type, data_list in send_order:
    if data_list:
        success = send_data_to_governance_api(data_type, data_list)
        total_success = total_success and success
    else:
        print(f"⚠️ Nenhum dado para enviar: {data_type}")

if total_success:
    print("🎉 Todos os dados foram enviados com sucesso!")
else:
    print("⚠️ Alguns dados falharam no envio. Verifique os logs.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Relatório de Extração

# COMMAND ----------

# Gerar relatório final
report = {
    "extraction_timestamp": datetime.now().isoformat(),
    "unity_catalog_summary": {
        "catalogs_found": len(unity_metadata["catalogs"]),
        "schemas_found": len(unity_metadata["schemas"]),
        "tables_found": len(unity_metadata["tables"]),
        "columns_found": len(unity_metadata["columns"])
    },
    "governance_mapping": {
        "domains_created": len(governance_data["domains"]),
        "entities_created": len(governance_data["entities"]),
        "attributes_created": len(governance_data["entity_attributes"]),
        "tags_created": len(governance_data["tags"]),
        "external_references_created": len(governance_data["external_references"])
    },
    "lineage_analysis": {
        "relationships_found": len(lineage_data)
    },
    "usage_metrics": {
        "metrics_collected": len(usage_metrics)
    },
    "api_integration": {
        "total_success": total_success,
        "data_types_sent": len(send_order)
    }
}

# Salvar relatório
with open("/tmp/unity_catalog_extraction_report.json", "w") as f:
    json.dump(report, f, indent=2, default=str)

print("📋 Relatório de Extração:")
print("=" * 50)
print(f"🕐 Timestamp: {report['extraction_timestamp']}")
print(f"📊 Unity Catalog:")
print(f"   - Catálogos: {report['unity_catalog_summary']['catalogs_found']}")
print(f"   - Schemas: {report['unity_catalog_summary']['schemas_found']}")
print(f"   - Tabelas: {report['unity_catalog_summary']['tables_found']}")
print(f"   - Colunas: {report['unity_catalog_summary']['columns_found']}")
print(f"🏗️ Governança:")
print(f"   - Domínios: {report['governance_mapping']['domains_created']}")
print(f"   - Entidades: {report['governance_mapping']['entities_created']}")
print(f"   - Atributos: {report['governance_mapping']['attributes_created']}")
print(f"   - Tags: {report['governance_mapping']['tags_created']}")
print(f"🔗 Lineage: {report['lineage_analysis']['relationships_found']} relacionamentos")
print(f"📈 Métricas: {report['usage_metrics']['metrics_collected']} coletadas")
print(f"🚀 API: {'✅ Sucesso' if report['api_integration']['total_success'] else '❌ Falhas'}")
print("=" * 50)

print("✅ Extração do Unity Catalog concluída!")
print("📁 Arquivos salvos:")
print("   - /tmp/unity_catalog_metadata.json")
print("   - /tmp/unity_catalog_extraction_report.json")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Agendamento e Automação
# MAGIC 
# MAGIC Para executar este notebook automaticamente:
# MAGIC 
# MAGIC 1. **Agendamento via Jobs:**
# MAGIC    ```python
# MAGIC    # Criar job via API do Databricks
# MAGIC    job_config = {
# MAGIC        "name": "Unity Catalog Data Extraction",
# MAGIC        "tasks": [{
# MAGIC            "task_key": "extract_unity_catalog",
# MAGIC            "notebook_task": {
# MAGIC                "notebook_path": "/path/to/this/notebook"
# MAGIC            },
# MAGIC            "job_cluster_key": "extraction_cluster"
# MAGIC        }],
# MAGIC        "schedule": {
# MAGIC            "quartz_cron_expression": "0 0 2 * * ?",  # Diário às 2h
# MAGIC            "timezone_id": "America/Sao_Paulo"
# MAGIC        }
# MAGIC    }
# MAGIC    ```
# MAGIC 
# MAGIC 2. **Configurar Secrets:**
# MAGIC    ```bash
# MAGIC    databricks secrets create-scope governance
# MAGIC    databricks secrets put-secret governance api_token
# MAGIC    ```
# MAGIC 
# MAGIC 3. **Monitoramento:**
# MAGIC    - Configurar alertas para falhas
# MAGIC    - Dashboard de métricas de extração
# MAGIC    - Logs centralizados

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Próximos Passos
# MAGIC 
# MAGIC ### Melhorias Recomendadas:
# MAGIC 
# MAGIC 1. **Extração Incremental:**
# MAGIC    - Implementar delta para extrair apenas mudanças
# MAGIC    - Usar timestamps de última sincronização
# MAGIC 
# MAGIC 2. **Qualidade de Dados:**
# MAGIC    - Implementar regras de qualidade automáticas
# MAGIC    - Validação de esquemas
# MAGIC 
# MAGIC 3. **Lineage Avançado:**
# MAGIC    - Parser de SQL para lineage detalhado
# MAGIC    - Integração com ferramentas de lineage
# MAGIC 
# MAGIC 4. **Classificação Automática:**
# MAGIC    - ML para classificar dados sensíveis
# MAGIC    - Aplicação automática de tags
# MAGIC 
# MAGIC 5. **Integração com Ferramentas:**
# MAGIC    - Apache Atlas
# MAGIC    - Informatica Axon
# MAGIC    - Collibra
# MAGIC 
# MAGIC ### Configurações Adicionais:
# MAGIC 
# MAGIC ```python
# MAGIC # Configurar para ambientes específicos
# MAGIC ENVIRONMENTS = {
# MAGIC     "dev": {
# MAGIC         "api_url": "https://dev-governance-api.com",
# MAGIC         "catalogs": ["dev_catalog"]
# MAGIC     },
# MAGIC     "prod": {
# MAGIC         "api_url": "https://prod-governance-api.com",
# MAGIC         "catalogs": ["prod_catalog", "analytics_catalog"]
# MAGIC     }
# MAGIC }
# MAGIC ```

