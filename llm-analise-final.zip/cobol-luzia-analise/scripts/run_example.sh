#!/usr/bin/env bash
set -euo pipefail
cobol-luzia-analise           --input "./examples"           --output "./out"           --config "./examples/config.yaml"           --prompt "./examples/prompt_original.yaml"
