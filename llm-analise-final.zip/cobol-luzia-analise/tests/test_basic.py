import datetime as dt
from pathlib import Path
from cobol_luzia_analise.app import InputOrganizer, SourceArtifact, ProgramBundle, AnalysisRunner, RequestResponseArchiver, ModelConfig, AIResponse

def test_extract_program_id():
    sample = """
    IDENTIFICATION DIVISION.
    PROGRAM-ID. LHAN0542.
    """
    assert InputOrganizer._extract_program_id(sample) == "LHAN0542"

def test_build_bundles_cobol_and_other(tmp_path: Path):
    cob = SourceArtifact(tmp_path / "a.cob", "cobol", "PROGRAM-ID. ABC123.")
    txt = SourceArtifact(tmp_path / "readme.txt", "other", "some text")
    org = InputOrganizer()
    bundles = org.build_bundles([cob, txt])
    names = {b.name for b in bundles}
    assert "ABC123" in names
    assert "readme" in names
    assert len(bundles) == 2

def test_report_md_has_sections(tmp_path: Path):
    art = SourceArtifact(tmp_path / "a.cob", "cobol", "PROGRAM-ID. ABC123.")
    bundle = ProgramBundle(name="ABC123", program=art, copybooks=[], jcls=[], others=[])
    resp = AIResponse(
        program_name="ABC123",
        timestamp=dt.datetime.now().isoformat(),
        provider="Luzia",
        model="aws-claude-3-5-sonnet",
        success=True,
        tokens_used=10,
        response_time=0.5,
        content="ok",
    )
    md = AnalysisRunner._build_report_md(bundle, resp)
    assert "# Análise do Artefato:" in md
    assert "## Análise Detalhada" in md
    assert "## Transparência e Auditoria" in md

def test_binary_placeholder_passthrough_and_persistence(tmp_path: Path):
    art = SourceArtifact(tmp_path / "file.bin", "other", "<BINARY_FILE_UNREADABLE_AS_TEXT>")
    bundle = ProgramBundle(name="file", program=art, copybooks=[], jcls=[], others=[])

    class DummyProvider:
        def get_provider_name(self):
            return "Dummy"
        def analyze_code(self, **kwargs):
            assert kwargs["code"] == "<BINARY_FILE_UNREADABLE_AS_TEXT>"
            return {"content": "ok", "tokens_used": 1, "response_time": 0.01}

    archiver = RequestResponseArchiver(tmp_path, "app")
    runner = AnalysisRunner(DummyProvider(), archiver)
    model_cfg = ModelConfig(key="dummy", name="dummy-model")
    req, resp, _ = runner.run_for_model(model_cfg, bundle, prompt="p")
    assert "<BINARY_FILE_UNREADABLE_AS_TEXT>" in req.program_code
    assert resp.success is True
