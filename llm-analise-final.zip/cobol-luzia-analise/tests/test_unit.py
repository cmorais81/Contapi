import pytest
import os
import json
import re
from pathlib import Path
from unittest.mock import MagicMock, patch

# Adicionar o diretório raiz do projeto ao sys.path para imports relativos
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from llm_analise.app import (
    ConfigLoader,
    PromptLoader,
    InputOrganizer,
    RequestResponseArchiver,
    SourceArtifact,
    AIRequest,
    AIResponse,
    ProgramBundle,
)

# --- Fixtures e Configurações Mock ---

@pytest.fixture
def mock_config_yaml(tmp_path):
    config_content = """
provider:
  type: LuziaProvider
  auth_url: https://auth.example.com
  api_url: https://api.example.com
  client_id: mock_id
  client_secret: mock_secret
  enabled: True
  timeout: 60
  retry:
    max_attempts: 3
    backoff_factor: 2
  circuit_breaker:
    fail_max: 5
    reset_timeout: 30
models:
  model_a:
    name: gpt-4-turbo
    enabled: True
    temperature: 0.5
    max_tokens: 8000
    extra_param: value
  model_b:
    name: claude-3-sonnet
    enabled: False
    temperature: 0.1
    max_tokens: 4000
"""
    f = tmp_path / "config.yaml"
    f.write_text(config_content)
    return f

@pytest.fixture
def mock_prompt_yaml(tmp_path):
    prompt_content = """
system_prompt: |
  Você é um analista COBOL. Analise o programa {{program_name}}.
  O código é:
  {{program_code}}
"""
    f = tmp_path / "prompt.yaml"
    f.write_text(prompt_content)
    return f

@pytest.fixture
def mock_input_dir(tmp_path):
    # Arquivo COBOL principal
    (tmp_path / "PGM001.cbl").write_text("""
       IDENTIFICATION DIVISION.
       PROGRAM-ID. PGM001.
       DATA DIVISION.
       WORKING-STORAGE SECTION.
           COPY WS-BOOK.
       PROCEDURE DIVISION.
           CALL 'JCL001'.
           MOVE 1 TO A.
           COPY WS-BOOK2.
           CALL 'PGM002'.
           GOBACK.
    """)
    # Copybooks
    (tmp_path / "WS-BOOK.cpy").write_text("01 WS-VAR PIC X(10).")
    (tmp_path / "WS-BOOK2.cpy").write_text("01 WS-VAR2 PIC X(10).")
    # JCLs
    (tmp_path / "JCL001.jcl").write_text("//STEP01 EXEC PGM=IEBGENER")
    (tmp_path / "JCL002.jcl").write_text("//STEP01 EXEC PGM=JCL002")
    # Outros
    (tmp_path / "README.txt").write_text("Test files")
    return tmp_path

@pytest.fixture
def mock_output_dir(tmp_path):
    return tmp_path / "output"

# --- Testes de ConfigLoader ---

def test_config_loader_load(mock_config_yaml):
    loader = ConfigLoader()
    config = loader.load(mock_config_yaml)

    assert config.provider_name == "LuziaProvider"
    assert config.provider["client_id"] == "mock_id"
    assert len(config.models) == 2

    model_a = config.models[0]
    assert model_a.key == "model_a"
    assert model_a.name == "gpt-4-turbo"
    assert model_a.enabled is True
    assert model_a.extra["extra_param"] == "value"

    model_b = config.models[1]
    assert model_b.key == "model_b"
    assert model_b.enabled is False

# --- Testes de PromptLoader ---

def test_prompt_loader_load_yaml(mock_prompt_yaml):
    loader = PromptLoader()
    prompt = loader.load(mock_prompt_yaml)
    assert "Você é um analista COBOL" in prompt
    assert "{{program_code}}" in prompt

def test_prompt_loader_load_txt(tmp_path):
    f = tmp_path / "prompt.txt"
    f.write_text("Analise o código: {{program_code}}")
    loader = PromptLoader()
    prompt = loader.load(f)
    assert "Analise o código: {{program_code}}" == prompt

# --- Testes de InputOrganizer ---

def test_input_organizer_scan(mock_input_dir):
    organizer = InputOrganizer()
    artifacts = organizer.scan(mock_input_dir)

    assert len(artifacts) == 6 # 1 COBOL, 2 Copybooks, 2 JCLs, 1 Other (Total 6)
    kinds = [a.kind for a in artifacts]
    assert kinds.count("cobol") == 1
    assert kinds.count("copybook") == 2
    assert kinds.count("jcl") == 2
    assert kinds.count("other") == 1

def test_input_organizer_extract_program_id():
    content = "       IDENTIFICATION DIVISION.\n       PROGRAM-ID. MY-PROG.\n"
    assert InputOrganizer._extract_program_id(content) == "MY-PROG"

    content = "PROGRAM-ID. ANOTHER-PROG."
    assert InputOrganizer._extract_program_id(content) == "ANOTHER-PROG"

    content = "       PROGRAM-ID. PGM001."
    assert InputOrganizer._extract_program_id(content) == "PGM001"

    content = "No program id here."
    assert InputOrganizer._extract_program_id(content) is None

def test_input_organizer_build_bundles_intelligent_context(mock_input_dir):
    organizer = InputOrganizer()
    artifacts = organizer.scan(mock_input_dir)
    bundles = organizer.build_bundles(artifacts)

    # Deve ter 2 bundles: 1 para COBOL (PGM001) e 1 para o JCL002 (que não foi referenciado) e 1 para README.txt
    # O PGM001.cbl referencia WS-BOOK e WS-BOOK2 (COPY) e JCL001 (CALL 'JCL001')
    assert len(bundles) == 6

    pgm_bundle = next(b for b in bundles if b.name == "PGM001")
    assert pgm_bundle.name == "PGM001"
    assert pgm_bundle.program.kind == "cobol"
    
    # Contexto Inteligente: Apenas Copybooks referenciados (WS-BOOK e WS-BOOK2)
    copybook_names = {c.path.stem for c in pgm_bundle.copybooks}
    assert copybook_names == {"WS-BOOK", "WS-BOOK2"}
    
    # Contexto Inteligente: Apenas JCLs referenciados (JCL001)
    jcl_names = {j.path.stem for j in pgm_bundle.jcls}
    assert jcl_names == {"JCL001"}

    # Bundle para JCL002 (não referenciado)
    jcl_bundle = next(b for b in bundles if b.name == "JCL002")
    assert jcl_bundle.program.kind == "jcl"
    assert len(jcl_bundle.copybooks) == 0
    assert len(jcl_bundle.jcls) == 0

# --- Testes de RequestResponseArchiver ---

@patch("llm_analise.app.dt")
def test_archiver_save_request_response(mock_dt, mock_output_dir):
    mock_dt.datetime.now.return_value.isoformat.return_value = "2025-10-29T10:00:00.000000"
    
    archiver = RequestResponseArchiver(mock_output_dir, "test_app")
    
    req = AIRequest(
        program_name="PGM001",
        timestamp="2025-10-29T10:00:00.000000",
        provider="MockProvider",
        model="model_a",
        program_code="CODE",
        prompts_sent="PROMPT",
    )
    
    resp = AIResponse(
        program_name="PGM001",
        timestamp="2025-10-29T10:00:00.000000",
        provider="MockProvider",
        model="model_a",
        success=True,
        tokens_used=100,
        response_time=1.5,
        content="ANALYSIS",
    )
    
    req_path = archiver.save_request("model_a", req)
    resp_path = archiver.save_response("model_a", resp)
    report_path = archiver.save_report("model_a", "PGM001", "# Report")

    # Verifica caminhos
    # O slug gerado pela função _ts_slug (linha 261 de app.py) é: 20251029_100000000000
    expected_req_path = mock_output_dir / "model_model_a" / "ai_requests" / "PGM001_20251029_100000000000.json"
    expected_resp_path = mock_output_dir / "model_model_a" / "ai_responses" / "PGM001_20251029_100000000000.json"
    expected_report_path = mock_output_dir / "model_model_a" / "test_app_analise.md"

    assert req_path == expected_req_path
    assert resp_path == expected_resp_path
    assert report_path == expected_report_path

    # Verifica conteúdo
    assert json.loads(req_path.read_text())["program_name"] == "PGM001"
    assert json.loads(resp_path.read_text())["tokens_used"] == 100
    assert expected_report_path.read_text() == "# Report"
