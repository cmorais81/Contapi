"""
Provider base abstrato para integração com diferentes provedores de IA.
Define interface comum para todos os providers.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional


class ProviderError(Exception):
    """Erro específico dos providers de IA."""
    pass

class ProviderAuthError(ProviderError):
    """Erro de autenticação com o provider."""
    pass

class ProviderAPIError(ProviderError):
    """Erro de API (código de status HTTP não-2xx)."""
    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code
    pass


class BaseProvider(ABC):
    """Classe base abstrata para providers de IA."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.enabled = config.get('enabled', False)
        self.timeout = config.get('timeout', 120)

        if not self.enabled:
            raise ProviderError(f"Provider {self.__class__.__name__} está desabilitado")

    @abstractmethod
    def authenticate(self) -> bool:
        """
        Autentica com o provedor de IA.

        Returns:
            True se autenticação foi bem-sucedida

        Raises:
            ProviderError: Se falhar na autenticação
        """
        pass

    @abstractmethod
    def analyze_code(self, code: str, prompt: str, model_name: str,
                     temperature: float = 0.1, max_tokens: int = 4000,
                     timeout: Optional[int] = None, **kwargs) -> Dict[str, Any]:
        """
        Analisa código usando o modelo especificado.

        Args:
            code: Código a ser analisado
            prompt: Prompt para análise
            model_name: Nome do modelo a ser usado
            temperature: Temperatura para geração de texto (0.0-1.0)
            max_tokens: Número máximo de tokens na resposta
            timeout: Timeout específico para esta requisição
            **kwargs: Argumentos adicionais específicos do provider

        Returns:
            Dicionário com resultado da análise contendo:
            - content: Conteúdo da análise gerada
            - tokens_used: Número de tokens utilizados
            - model: Modelo utilizado
            - metadata: Metadados adicionais

        Raises:
            ProviderError: Se falhar na análise
        """
        pass

    @abstractmethod
    def get_available_models(self) -> Dict[str, Any]:
        """
        Retorna modelos disponíveis no provider.

        Returns:
            Dicionário com modelos disponíveis e suas configurações
        """
        pass

    @abstractmethod
    def validate_model(self, model_name: str) -> bool:
        """
        Valida se o modelo está disponível e configurado.

        Args:
            model_name: Nome do modelo a ser validado

        Returns:
            True se modelo é válido
        """
        pass

    @abstractmethod
    def get_health_status(self) -> Dict[str, Any]:
        """
        Verifica status de saúde do provider.

        Returns:
            Dicionário com informações de status
        """
        pass

    def get_provider_name(self) -> str:
        """
        Retorna nome do provider.

        Returns:
            Nome do provider
        """
        return self.__class__.__name__

    def is_enabled(self) -> bool:
        """
        Verifica se o provider está habilitado.

        Returns:
            True se habilitado
        """
        return self.enabled

    def get_configuration(self) -> Dict[str, Any]:
        """
        Retorna configuração do provider (sem credenciais sensíveis).

        Returns:
            Configuração sanitizada
        """
        safe_config = self.config.copy()

        # Remove informações sensíveis
        sensitive_keys = ['client_secret', 'api_key', 'password', 'token']
        for key in sensitive_keys:
            if key in safe_config:
                safe_config[key] = "***"

        return safe_config
