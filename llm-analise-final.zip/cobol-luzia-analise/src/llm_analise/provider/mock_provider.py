"""
Mock Provider para simulação de chamadas a LLM.
"""

import time
from typing import Any, Dict, Optional

from .base_provider import BaseProvider, ProviderError, ProviderAuthError, ProviderAPIError


class MockProvider(BaseProvider):
    """Provider de simulação para testes e geração de estrutura de output."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.provider_name = "MockProvider"
        self.models = self.config.get('models', {})
        
        import logging
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.info("MockProvider inicializado.")

    def authenticate(self) -> bool:
        """Simula autenticação bem-sucedida."""
        return True

    def analyze_code(self, code: str, prompt: str, model_name: str,
                     temperature: float = 0.1, max_tokens: int = 4000,
                     timeout: Optional[int] = None, **kwargs) -> Dict[str, Any]:
        """
        Simula a análise de código.

        Retorna uma resposta estática com base na estrutura esperada.
        """
        start_time = time.time()
        
        # Simular tempo de resposta
        time.sleep(0.1) 

        # Simular conteúdo da resposta (Markdown)
        mock_content = (
            f"# Análise Simulada para o Modelo: {model_name}\n\n"
            "## Resumo Funcional\n"
            "O código analisado (simulado) parece implementar uma regra de negócio simples de cálculo de taxa.\n\n"
            "## Código Recebido\n"
            "```\n"
            f"{code[:500]}...\n"
            "```\n\n"
            "## Componentização Proposta (Simulada)\n"
            "Proposta de componente `TaxCalculator` com contrato JSON de entrada e saída.\n"
            "**Tokens Simulados:** 500\n"
            "**Tempo de Resposta:** 0.15s"
        )
        
        response_time = time.time() - start_time
        tokens_used = 500 # Valor fixo para simulação

        return {
            'content': mock_content,
            'tokens_used': tokens_used,
            'model': model_name,
            'response_time': response_time,
            'metadata': {
                'prompt_tokens': tokens_used - 100,
                'completion_tokens': 100,
                'temperature': temperature,
                'max_tokens': max_tokens
            }
        }

    def get_available_models(self) -> Dict[str, Any]:
        """Retorna os modelos configurados no __init__."""
        return self.models

    def validate_model(self, model_name: str) -> bool:
        """Valida se o modelo está na lista de modelos configurados."""
        return model_name in self.models

    def get_health_status(self) -> Dict[str, Any]:
        """Simula status saudável."""
        return {
            'provider': self.get_provider_name(),
            'healthy': True,
            'authenticated': True,
            'models_available': len(self.models),
            'last_check': time.time()
        }

    def test_connection(self) -> bool:
        """Simula conexão bem-sucedida."""
        return True

    def get_provider_name(self) -> str:
        """Retorna o nome do provider."""
        return self.provider_name
