"""
Provider para integração com o Luzia (ambiente interno Santander).
Implementa autenticação OAuth2 e chamadas para modelos LLM.
"""

import json
import os
import time
from datetime import datetime, timedelta
from typing import Any, Dict, Optional

import requests
from pybreaker import CircuitBreaker, CircuitBreakerError

# Removido: from core.logger import StructuredLogger, get_logger
from .base_provider import BaseProvider, ProviderError, ProviderAuthError, ProviderAPIError
import backoff


class LuziaProvider(BaseProvider):
    """Provider para integração com o sistema Luzia."""

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)

        # Usar o logger do app.py (global) ou injetar um logger. Por enquanto, usar logging padrão.
        import logging
        self.logger = logging.getLogger(self.__class__.__name__)
        # Removido StructuredLogger, usar logging padrão.

        # Configurações OAuth2
        self.client_id = os.environ.get('LUZIA_CLIENT_ID') or config.get('client_id')
        self.client_secret = os.environ.get('LUZIA_CLIENT_SECRET') or config.get('client_secret')
        self.auth_url = config.get('auth_url')
        self.api_url = config.get('api_url')

        # Configurações SSL
        self.ssl_cert = os.environ.get('SSL_CERT_FILE')
        self.verify_ssl = bool(self.ssl_cert) if self.ssl_cert else False

        # Se SSL verificação está desabilitada, suprimir avisos
        if not self.verify_ssl:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        # Configurações de conexão
        self.timeout = config.get('timeout', 120)
        self.max_attempts = config.get('retry', {}).get('max_attempts', 3)
        self.backoff_factor = config.get('retry', {}).get('backoff_factor', 1.5)

        # Configurações do Circuit Breaker
        self.breaker_config = config.get('circuit_breaker', {})
        self.breaker = self._setup_circuit_breaker()

        # Estado de autenticação
        self.access_token: Optional[str] = None
        self.token_expires_at: Optional[datetime] = None

        # Configurar sessão HTTP compartilhada
        self.session = self._setup_session()

        # Validar configuração
        self._validate_config()

        self.logger.info(f"LuziaProvider inicializado (SSL Verify: {self.verify_ssl}, Cert: {self.ssl_cert})")

    def _validate_config(self):
        """Valida configuração obrigatória."""
        required_fields = ['client_id', 'client_secret', 'auth_url', 'api_url']

        for field in required_fields:
            if not self.config.get(field):
                raise ProviderError(f"Campo obrigatório '{field}' não configurado")

    def authenticate(self) -> bool:
        """
        Autentica com o Luzia usando OAuth2.

        Returns:
            True se autenticação foi bem-sucedida

        Raises:
            ProviderError: Se falhar na autenticação
        """
        try:
            self.logger.info("Iniciando autenticação OAuth2 com Luzia")

            # Verificar se token ainda é válido
            if self._is_token_valid():
                self.logger.debug("Token ainda válido, reutilizando")
                return True

            # Preparar dados para autenticação
            auth_data = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }

            # Fazer requisição de autenticação
            start_time = time.time()

            response = requests.post(
                self.auth_url,
                data=auth_data,
                timeout=self.timeout,
                verify=self.verify_ssl
            )

            response_time = time.time() - start_time

            # Log da chamada
            self.logger.debug(f"API Call: {self.auth_url}, POST, Status: {response.status_code}, Time: {response_time:.2f}s") # Substituído por log simples

            if response.status_code != 200:
                error_msg = f"Falha na autenticação: {response.status_code} - {response.text}"
                # Usar ProviderAuthError para erros de autenticação
                raise ProviderAuthError(error_msg)

            # Processar resposta
            auth_response = response.json()

            self.access_token = auth_response.get('access_token')
            expires_in = auth_response.get('expires_in', 3600)  # Default 1 hora

            if not self.access_token:
                raise ProviderError("Token de acesso não retornado")

            # Calcular expiração do token (com margem de segurança de 5 minutos)
            self.token_expires_at = datetime.now() + timedelta(seconds=expires_in - 300)

            self.logger.info("Autenticação OAuth2 concluída com sucesso")
            return True

        except requests.RequestException as e:
            error_msg = f"Erro de rede na autenticação: {e}"
            self.logger.error(error_msg)
            raise ProviderAuthError(error_msg)
        except ProviderAuthError:
            raise
        except Exception as e:
            error_msg = f"Erro inesperado na autenticação: {e}"
            self.logger.error(error_msg)
            raise ProviderAuthError(error_msg)

    def _is_token_valid(self) -> bool:
        """Verifica se o token atual ainda é válido."""
        if not self.access_token or not self.token_expires_at:
            return False

        return datetime.now() < self.token_expires_at

    def analyze_code(self, code: str, prompt: str, model_name: str,
                     temperature: float = 0.1, max_tokens: int = 4000,
                     timeout: Optional[int] = None, **kwargs) -> Dict[str, Any]:
        """
        Analisa código usando o modelo especificado do Luzia.

        Args:
            code: Código a ser analisado
            prompt: Prompt para análise
            model_name: Nome do modelo a ser usado
            temperature: Temperatura para geração de texto
            max_tokens: Número máximo de tokens na resposta
            timeout: Timeout específico para esta requisição
            **kwargs: Argumentos adicionais

        Returns:
            Dicionário com resultado da análise

        Raises:
            ProviderError: Se falhar na análise
        """
        try:
            # Garantir autenticação
            if not self.authenticate():
                raise ProviderAuthError("Falha na autenticação")

            # Validar modelo
            if not self.validate_model(model_name):
                raise ProviderError(f"Modelo '{model_name}' não disponível")

            self.logger.info(f"Iniciando análise com modelo {model_name}")

            # Usar o Circuit Breaker
            return self.breaker.call(self._do_analyze_code, code, prompt, model_name, temperature, max_tokens, timeout, **kwargs)

        except CircuitBreakerError as e:
            error_msg = f"Circuit Breaker Aberto: Serviço Luzia está indisponível. {e}"
            self.logger.error(error_msg)
            raise ProviderError(error_msg)
        except ProviderError:
            raise
        except Exception as e:
            error_msg = f"Erro inesperado na análise: {e}"
            self.logger.error(error_msg)
            raise ProviderError(error_msg)

    @backoff.on_exception(
        backoff.expo,
        ProviderAPIError,
        max_tries=3,
        max_time=60,
        factor=2
    )
    def _do_analyze_code(self, code: str, prompt: str, model_name: str,
                         temperature: float = 0.1, max_tokens: int = 4000,
                         timeout: Optional[int] = None, **kwargs) -> Dict[str, Any]:
        """Lógica real da análise, protegida pelo Circuit Breaker e com retry automático."""
        try:

            # Preparar payload
            payload = {
                'model': model_name,
                'messages': [
                    {
                        'role': 'system',
                        'content': prompt
                    },
                    {
                        'role': 'user',
                        'content': f"Analise o seguinte código:\n\n{code}"
                    }
                ],
                'temperature': temperature,
                'max_tokens': max_tokens,
                **kwargs
            }

            # Preparar headers
            headers = {
                'Authorization': f'Bearer {self.access_token}',
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }

            # Fazer requisição
            start_time = time.time()
            request_timeout = timeout or self.timeout

            endpoint = f"{self.api_url}/chat/completions"

            response = requests.post(
                endpoint,
                json=payload,
                headers=headers,
                timeout=request_timeout,
                verify=self.verify_ssl
            )

            response_time = time.time() - start_time

            # Log da chamada
            self.logger.debug(f"API Call: {endpoint}, POST, Status: {response.status_code}, Time: {response_time:.2f}s, Model: {model_name}") # Substituído por log simples

            if response.status_code != 200:
                error_msg = f"Erro na análise: {response.status_code} - {response.text}"
                # Usar ProviderAPIError para erros de API
                raise ProviderAPIError(error_msg, response.status_code)

            # Processar resposta
            api_response = response.json()

            # Extrair conteúdo da resposta
            choices = api_response.get('choices', [])
            if not choices:
                raise ProviderError("Nenhuma resposta retornada pelo modelo")

            content = choices[0].get('message', {}).get('content', '')

            # Extrair informações de uso
            usage = api_response.get('usage', {})
            tokens_used = usage.get('total_tokens', 0)

            result = {
                'content': content,
                'tokens_used': tokens_used,
                'model': model_name,
                'response_time': response_time,
                'metadata': {
                    'prompt_tokens': usage.get('prompt_tokens', 0),
                    'completion_tokens': usage.get('completion_tokens', 0),
                    'temperature': temperature,
                    'max_tokens': max_tokens
                }
            }

            self.logger.info(f"Análise concluída: {tokens_used} tokens em {response_time:.2f}s")

            return result

        except requests.RequestException as e:
        error_msg = f"Erro de rede na análise: {e}"
        self.logger.error(error_msg)
        raise ProviderAPIError(error_msg) # Erro de rede é um erro transiente que deve ser reprocessado
        except ProviderAPIError:
            raise
        except ProviderError:
            raise
        except Exception as e:
            error_msg = f"Erro inesperado na análise: {e}"
            self.logger.error(error_msg)
            raise ProviderError(error_msg)

    def get_available_models(self) -> Dict[str, Any]:
        """
        Retorna modelos disponíveis no Luzia.

        Returns:
            Dicionário com modelos disponíveis
        """
        return self.config.get('models', {})

    def validate_model(self, model_name: str) -> bool:
        """
        Valida se o modelo está disponível.

        Args:
            model_name: Nome do modelo a ser validado

        Returns:
            True se modelo é válido
        """
        available_models = self.get_available_models()

        # Verificar por nome exato
        if model_name in available_models:
            return True

        # Verificar por nome interno (field 'name')
        for model_key, model_config in available_models.items():
            if isinstance(model_config, dict):
                if model_config.get('name') == model_name:
                    return True

        return False

    def get_health_status(self) -> Dict[str, Any]:
        """
        Verifica status de saúde do Luzia.

        Returns:
            Dicionário com informações de status
        """
        try:
            # Tentar autenticar para verificar conectividade
            auth_success = self.authenticate()

            status = {
                'provider': self.get_provider_name(),
                'healthy': auth_success,
                'authenticated': auth_success,
                'api_url': self.api_url,
                'models_available': len(self.get_available_models()),
                'last_check': datetime.now().isoformat()
            }

            if auth_success:
                status['token_expires_at'] = self.token_expires_at.isoformat() if self.token_expires_at else None

            return status

        except Exception as e:
            return {
                'provider': self.get_provider_name(),
                'healthy': False,
                'error': str(e),
                'last_check': datetime.now().isoformat()
            }

    def test_connection(self) -> bool:
        """
        Testa conectividade com o Luzia.

        Returns:
            True se conexão está funcionando
        """
        try:
            return self.authenticate()
        except Exception:
            return False

    def _setup_circuit_breaker(self) -> CircuitBreaker:
        """Configura o Circuit Breaker."""
        return CircuitBreaker(
            fail_max=self.breaker_config.get('fail_max', 5),
            reset_timeout=self.breaker_config.get('reset_timeout', 30), # 30 segundos
            exclude=[ProviderAuthError, ProviderAPIError], # Não abrir o circuito em erros de autenticação ou erros de cliente (4xx)
            name="luzia_api_breaker"
        )

    def _setup_session(self) -> requests.Session:
        """Configura sessão HTTP com retry e SSL."""
        session = requests.Session()

        # Configurar SSL com fallback para verificação desabilitada
        cert_file = os.environ.get('SSL_CERT_FILE')
        if cert_file and os.path.exists(cert_file):
            session.verify = cert_file
            self.logger.info(f"Usando certificado SSL: {cert_file}")
        else:
            session.verify = False
            self.logger.warning("Verificação SSL desabilitada - usando modo inseguro para desenvolvimento")
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        # Configurar retry
        retry_strategy = requests.adapters.Retry(
            total=self.max_attempts,
            backoff_factor=self.backoff_factor,
            status_forcelist=[408, 429, 500, 502, 503, 504]
        )

        adapter = requests.adapters.HTTPAdapter(max_retries=retry_strategy)
        session.mount("https://", adapter)
        session.mount("http://", adapter)

        return session

