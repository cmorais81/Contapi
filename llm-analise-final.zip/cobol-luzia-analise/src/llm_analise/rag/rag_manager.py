"""
Gerenciador de RAG (Retrieval-Augmented Generation)
Combina VectorDBManager e RAGRetriever em uma única classe para simplificar.
"""
import json
import os
from pathlib import Path
from typing import List, Dict, Any, Optional

from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import FakeEmbeddings
from langchain_core.documents import Document

# Importar classes do app
try:
    from ..app import ProgramBundle, AIResponse, log
except ImportError:
    # Fallback para execução direta
    import logging
    log = logging.getLogger(__name__)
    log.setLevel(logging.INFO)
    
    # Mock das classes para evitar erro de import
    class ProgramBundle:
        def __init__(self, name, program, copybooks, jcls, others):
            self.name = name
            self.program = program
            self.copybooks = copybooks
            self.jcls = jcls
            self.others = others
    class AIResponse:
        def __init__(self, program_name, timestamp, provider, model, success, tokens_used, response_time, content, error_message, metadata, prompts_used):
            self.program_name = program_name
            self.timestamp = timestamp
            self.provider = provider
            self.model = model
            self.success = success
            self.tokens_used = tokens_used
            self.response_time = response_time
            self.content = content
            self.error_message = error_message
            self.metadata = metadata
            self.prompts_used = prompts_used


class RAGManager:
    def __init__(self, db_path: Path, collection_name: str = "llm_analise_collection"):
        self.db_path = db_path
        self.collection_name = collection_name
        
        # Usar FakeEmbeddings para manter o projeto leve e evitar dependências de modelos de embedding
        # Em um cenário real, seria substituído por OpenAIEmbeddings, HuggingFaceEmbeddings, etc.
        self.embedding_function = FakeEmbeddings(size=128) 
        
        self.db = Chroma(
            persist_directory=str(self.db_path),
            embedding_function=self.embedding_function,
            collection_name=self.collection_name,
        )
        log.info(json.dumps({"event": "rag_init", "db_path": str(self.db_path), "collection": self.collection_name}))

    def ingest_analysis(self, bundle: ProgramBundle, response: AIResponse):
        """
        Ingere os resultados de uma análise bem-sucedida no Vector DB.
        """
        if not response.success:
            log.warning(json.dumps({"event": "rag_ingest_skip", "reason": "analysis_failed", "program": bundle.name}))
            return

        # 1. Documento Principal (Resultado da Análise)
        doc_content = f"Resultado da Análise do programa {bundle.name} pelo modelo {response.model}:\n\n{response.content}"
        
        metadata = {
            "source": str(bundle.program.path),
            "program_name": bundle.name,
            "artifact_type": bundle.program.kind,
            "model": response.model,
            "timestamp": response.timestamp,
            "doc_type": "analysis_result",
        }
        
        result_doc = Document(page_content=doc_content, metadata=metadata)

        # 2. Documento de Código (para contexto de busca de código similar)
        code_content = f"Código Fonte do programa {bundle.name} ({bundle.program.kind}):\n\n{bundle.program.content}"
        code_metadata = metadata.copy()
        code_metadata["doc_type"] = "source_code"
        code_doc = Document(page_content=code_content, metadata=code_metadata)

        # 3. Documentos de Copybooks/JCLs (para contexto de dependências)
        dependency_docs = []
        for dep in bundle.copybooks + bundle.jcls:
            dep_content = f"Dependência ({dep.kind}) {dep.path.stem} usada pelo programa {bundle.name}:\n\n{dep.content}"
            dep_metadata = metadata.copy()
            dep_metadata["artifact_name"] = dep.path.stem
            dep_metadata["artifact_type"] = dep.kind
            dep_metadata["doc_type"] = "dependency"
            dependency_docs.append(Document(page_content=dep_content, metadata=dep_metadata))

        docs_to_ingest = [result_doc, code_doc] + dependency_docs
        
        self.db.add_documents(docs_to_ingest)
        log.info(json.dumps({"event": "rag_ingest_success", "program": bundle.name, "count": len(docs_to_ingest)}))

    def retrieve_context(self, bundle: ProgramBundle, query: str, k: int = 3) -> List[str]:
        """
        Busca contexto relevante para o programa atual.
        """
        # A busca inicial é baseada no código do programa e no nome.
        # A query é o prompt + o código do programa.
        
        # 1. Busca por similaridade
        search_query = f"Análise prévia ou código similar ao programa {bundle.name}: {query}"
        
        # Filtro: Excluir o próprio código fonte (se já estiver no DB, o que não deve acontecer no fluxo normal)
        # E priorizar resultados de análise
        
        # Busca por documentos de análise e código
        retrieved_docs = self.db.similarity_search(search_query, k=k)
        
        context_list = []
        for doc in retrieved_docs:
            context_list.append(f"--- Contexto Recuperado ({doc.metadata.get('doc_type', 'N/A')} - {doc.metadata.get('program_name', 'N/A')}) ---\n{doc.page_content}")
            
        log.info(json.dumps({"event": "rag_retrieve", "program": bundle.name, "count": len(context_list)}))
        
        return context_list

    def close(self):
        """
        Fecha a conexão com o DB, garantindo que os dados sejam persistidos.
        """
        # O ChromaDB usa persistência automática, mas chamar persist() explicitamente é uma boa prática.
        try:
            self.db.persist()
            log.info(json.dumps({"event": "rag_persist_success", "db_path": str(self.db_path)}))
        except Exception as e:
            log.error(json.dumps({"event": "rag_persist_error", "error": str(e)}))

    def get_db_path(self) -> Path:
        return self.db_path
