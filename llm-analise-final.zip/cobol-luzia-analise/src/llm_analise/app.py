#!/usr/bin/env python3
"""
CLI app to analyze any files under --input, build Luzia requests per model, and save ai_requests, ai_responses,
and a Markdown report per model.

- SOLID/SRP
- Structured JSON logging
"""
from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import json
import os
import re
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from jinja2 import Environment, FileSystemLoader
from markdown import markdown

# Provider deps (use package imports)
try:
    from .provider.luzia_provider import LuziaProvider
    from .provider.base_provider import ProviderError
    from .provider.mock_provider import MockProvider
except ImportError:  # pragma: no cover
    # Fallback para execução direta (se o pacote não estiver instalado)
    LuziaProvider = None
    class ProviderError(Exception):
        pass

# -----------------------------
# Logging
# -----------------------------
import logging

class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:  # pragma: no cover
        payload = {
            "ts": dt.datetime.now().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)

def setup_logger(name: str = "app", level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(level)
    if not logger.handlers:
        ch = logging.StreamHandler(sys.stdout)
        ch.setFormatter(JsonFormatter())
        logger.addHandler(ch)
    return logger

log = setup_logger("llm-analise-app")

# -----------------------------
# Config / Prompt loaders
# -----------------------------
import yaml

@dataclass
class ModelConfig:
    key: str
    name: str
    enabled: bool = True
    temperature: float = 0.1
    max_tokens: int = 4000
    extra: dict = dataclasses.field(default_factory=dict)

@dataclass
class AppConfig:
    provider_name: str
    provider: dict
    models: List[ModelConfig]

class ConfigLoader:
    def load(self, path: Path) -> AppConfig:
        with path.open("r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
        provider_cfg = cfg.get("provider", {})
        models_raw: Dict[str, dict] = cfg.get("models", {})
        models = []
        for key, mc in models_raw.items():
            models.append(
                ModelConfig(
                    key=key,
                    name=mc.get("name", key),
                    enabled=mc.get("enabled", True),
                    temperature=mc.get("temperature", 0.1),
                    max_tokens=mc.get("max_tokens", 4000),
                    extra={k: v for k, v in mc.items() if k not in {"name", "enabled", "temperature", "max_tokens"}},
                )
            )
        return AppConfig(
            provider_name=provider_cfg.get("type", "LuziaProvider"),
            provider=provider_cfg,
            models=models,
        )

class PromptLoader:
    def load(self, path: Path) -> str:
        text = path.read_text(encoding="utf-8")
        if path.suffix.lower() in {".yaml", ".yml"}:
            data = yaml.safe_load(text)
            return data.get("system_prompt") or data.get("prompt") or data.get("content") or text
        return text

# -----------------------------
# Input organization
# -----------------------------
@dataclass
class SourceArtifact:
    path: Path
    kind: str   # "cobol" | "copybook" | "jcl" | "other"
    content: str

@dataclass
class ProgramBundle:
    name: str
    program: SourceArtifact
    copybooks: List[SourceArtifact]
    jcls: List[SourceArtifact]
    others: List[SourceArtifact]

class InputOrganizer:
    def scan(self, root: Path) -> List[SourceArtifact]:
        arts: List[SourceArtifact] = []
        for p in sorted(root.rglob("*")):
            if p.is_file():
                kind = self._detect_kind(p)
                try:
                    content = p.read_text(encoding="latin-1")
                except UnicodeDecodeError:
                    content = p.read_text(encoding="utf-8", errors="ignore")
                except Exception:
                    content = "<BINARY_FILE_UNREADABLE_AS_TEXT>"
                arts.append(SourceArtifact(p, kind, content))
        return arts

    def _detect_kind(self, path: Path) -> str:
        sfx = path.suffix.lower()
        name = path.name.lower()
        if sfx in {".cob", ".cbl", ".cobol"}:
            return "cobol"
        if sfx == ".cpy" or "copy" in name or "book" in name:
            return "copybook"
        if sfx == ".jcl" or name.endswith(".jcl"):
            return "jcl"
        return "other"

    def build_bundles(self, artifacts: List[SourceArtifact]) -> List[ProgramBundle]:
        """
        Cria um pacote (bundle) para cada programa COBOL encontrado.
        Apenas arquivos COBOL são considerados programas principais para análise.
        Implementa Contexto Inteligente: inclui apenas Copybooks e JCLs referenciados.
        """
        bundles: List[ProgramBundle] = []
        copybooks_map = {a.path.stem.upper(): a for a in artifacts if a.kind == "copybook"}
        jcls_map = {a.path.stem.upper(): a for a in artifacts if a.kind == "jcl"}
        
        cobol_artifacts = [a for a in artifacts if a.kind == "cobol"]

        for art in cobol_artifacts:
            name = self._extract_program_id(art.content) or art.path.stem.upper()
            
            # --- Contexto Inteligente: Copybooks ---
            # Regex para encontrar COPY <nome> (ou COPY <nome> OF <biblioteca>)
            # COBOL é case-insensitive, mas o nome do arquivo (stem) é a chave.
            copy_names = re.findall(r"COPY\s+([A-Z0-9_-]+)", art.content, flags=re.IGNORECASE)
            
            # Remove duplicatas e garante que o nome seja em maiúsculas para a busca no mapa
            copy_names = {n.upper() for n in copy_names}
            
            # Adiciona o Copybook ao bundle se ele existir no mapa
            referenced_copybooks = [copybooks_map[n] for n in copy_names if n in copybooks_map]

            # --- Contexto Inteligente: JCLs ---
            # Regex para encontrar JCLs referenciados (ex: CALL 'JCLNAME' ou EXEC PGM=JCLNAME)
            # Simplificado para encontrar referências a nomes de JCLs (pode ser refinado)
            jcl_names = re.findall(r"EXEC\s+PGM=([A-Z0-9_-]+)|CALL\s+['\"]([A-Z0-9_-]+)['\"]", art.content, flags=re.IGNORECASE)
            
            # Flatten a lista de tuplas e remove None/duplicatas
            jcl_names = {n.upper() for t in jcl_names for n in t if n}
            
            # Adiciona o JCL ao bundle se ele existir no mapa
            referenced_jcls = [jcls_map[n] for n in jcl_names if n in jcls_map]

            bundles.append(ProgramBundle(
                name=name, 
                program=art, 
                copybooks=referenced_copybooks, 
                jcls=referenced_jcls, 
                others=[]
            ))
            
        # Adicionar bundles para arquivos não-COBOL que não foram analisados
        non_cobol_artifacts = [a for a in artifacts if a.kind != "cobol"]
        for art in non_cobol_artifacts:
            name = art.path.stem
            bundles.append(ProgramBundle(name=name, program=art, copybooks=[], jcls=[], others=[]))

        return bundles

    @staticmethod
    def _extract_program_id(content: str) -> Optional[str]:
        m = re.search(r"PROGRAM-\s*ID\s*\.\s*([A-Z0-9_-]+)", content, flags=re.IGNORECASE)
        if not m:
            # Tentar regex mais simples para PROGRAM-ID em coluna 8-72
            m = re.search(r"^\s{7}PROGRAM-ID\.\s*([A-Z0-9_-]+)", content, flags=re.IGNORECASE | re.MULTILINE)
        return m.group(1).upper() if m else None

# -----------------------------
# Request/Response persistence
# -----------------------------
@dataclass
class AIRequest:
    program_name: str
    timestamp: str
    provider: str
    model: str
    program_code: str
    prompts_sent: str
    program_code_included: bool = True
    extra: dict = dataclasses.field(default_factory=dict)

    def to_dict(self) -> dict:
        base_out = {
            "program_name": self.program_name,
            "timestamp": self.timestamp,
            "provider": self.provider,
            "model": self.model,
            "program_code": self.program_code,
            "prompts_sent": self.prompts_sent,
            "program_code_included": self.program_code_included,
        }
        base_out.update(self.extra or {})
        return base_out

@dataclass
class AIResponse:
    program_name: str
    timestamp: str
    provider: str
    model: str
    success: bool
    tokens_used: int
    response_time: float
    content: str
    error_message: str = ""
    metadata: dict = dataclasses.field(default_factory=dict)
    prompts_used: dict = dataclasses.field(default_factory=dict)

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

class RequestResponseArchiver:
    def __init__(self, base_out: Path, app_name: str):
        self.base_out = base_out
        self.app_name = app_name

    def model_root(self, model_key: str) -> Path:
        return self.base_out / f"model_{model_key}"

    def ensure_model_dirs(self, model_key: str) -> Tuple[Path, Path, Path]:
        root = self.model_root(model_key)
        req = root / "ai_requests"
        resp = root / "ai_responses"
        for d in (root, req, resp):
            d.mkdir(parents=True, exist_ok=True)
        return root, req, resp

    def save_request(self, model_key: str, req_obj: AIRequest) -> Path:
        _, req_dir, _ = self.ensure_model_dirs(model_key)
        fname = f"{req_obj.program_name}_{self._ts_slug(req_obj.timestamp)}.json"
        path = req_dir / fname
        path.write_text(json.dumps(req_obj.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
        return path

    def save_response(self, model_key: str, resp_obj: AIResponse) -> Path:
        _, _, resp_dir = self.ensure_model_dirs(model_key)
        fname = f"{resp_obj.program_name}_{self._ts_slug(resp_obj.timestamp)}.json"
        path = resp_dir / fname
        path.write_text(json.dumps(resp_obj.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
        return path

    def save_report(self, model_key: str, program_name: str, content: str, extension: str = "md", root_dir: Path = None) -> Path:
        root = self.model_root(model_key)
        if extension == "md":
            path = root / f"{self.app_name}_analise.md"
            path.write_text(content, encoding="utf-8")
            return path
        
        # Lógica para HTML
        if extension == "html":
            # O root_dir é o diretório raiz do projeto (cobol-luzia-analise)
            # O template está em examples/report_template.html
            template_path = root_dir / "examples"
            
            env = Environment(loader=FileSystemLoader(template_path))
            template = env.get_template("report_template.html")
            
            # 1. Converter Markdown para HTML
            html_content = markdown(content, extensions=['fenced_code', 'tables'])
            
            # 2. Renderizar o template
            rendered_html = template.render(
                report_markdown=html_content,
                model_name=self.model_root(model_key).name.replace("model_", ""),
                timestamp=dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                input_dir=self.base_out.name.replace("output_", "")
            )
            
        path = root / f"{self.app_name}_analise.html"
        path.write_text(rendered_html, encoding="utf-8")
        return path
        
        raise ValueError(f"Extensão de relatório não suportada: {extension}")

    @staticmethod
    def _ts_slug(ts: str) -> str:
        return re.sub(r"[^0-9T]", "", ts).replace(":", "").replace("T", "_")

# -----------------------------
# Provider factory
# -----------------------------
class ProviderFactory:
    def create(self, app_cfg: AppConfig) -> 'BaseProvider':
        if app_cfg.provider_name == "LuziaProvider":
            if LuziaProvider is None:
                raise ProviderError("LuziaProvider não disponível neste ambiente")
            return LuziaProvider(app_cfg.provider)
        if app_cfg.provider_name == "MockProvider":
            return MockProvider(app_cfg.provider)
        # Adicionar outros providers aqui se necessário
        raise ProviderError(f"Provider não suportado: {app_cfg.provider_name}")

# -----------------------------
# Analysis runner
# -----------------------------
class AnalysisRunner:
    def __init__(self, provider: 'BaseProvider', archiver: 'RequestResponseArchiver', models: List[ModelConfig], rag_manager: Optional['RAGManager'] = None):
        self.provider = provider
        self.archiver = archiver
        self.models = models
        self.rag_manager = rag_manager

    def run_analysis(self, bundles: List[ProgramBundle], prompt: str):
        models = [m for m in self.models if m.enabled]
        if not models:
            raise RuntimeError("Nenhum modelo habilitado na configuração")

        for bundle in bundles:
            log.info(json.dumps({"event": "program_bundle", "program": bundle.name}))
            for m in models:
                log.info(json.dumps({"event": "model_run_start", "model": m.name, "program": bundle.name}))
                req, resp, _ = self.run_for_model(m, bundle, prompt)
                
                # 4. Ingestão Incremental (após a análise)
                if resp.success and self.rag_manager:
                    self.rag_manager.ingest_analysis(bundle, resp)
        
        # 5. Persistir o DB Vetorial
        if self.rag_manager:
            self.rag_manager.close()
                log.info(json.dumps({
                    "event": "model_run_done",
                    "model": m.name,
                    "program": bundle.name,
                    "success": resp.success,
                    "tokens": resp.tokens_used,
                }))

    def run_for_model(self, model_cfg: ModelConfig, bundle: ProgramBundle, prompt_template: str):
        now = dt.datetime.now().isoformat()
        
        # 1. Preparar o código com contexto (Copybooks e JCLs)
        full_code = self._build_full_code(bundle)

        # 2. Parametrizar o Prompt
        # 2. Recuperação Contextual (RAG)
        rag_context = ""
        if self.rag_manager:
            # A query de busca é o próprio código fonte completo para encontrar análises similares
            rag_docs = self.rag_manager.retrieve_context(bundle, full_code)
            if rag_docs:
                rag_context = "\\n\\n--- CONTEXTO RAG RECUPERADO ---\\n" + "\\n\\n".join(rag_docs) + "\\n--- FIM CONTEXTO RAG ---\\n\\n"
        
        # 3. Parametrizar o Prompt
        final_prompt = prompt_template.replace("{{rag_context}}", rag_context)
        final_prompt = final_prompt.replace("{{program_code}}", full_code)
        
        # Outras substituições de template (ex: nome do programa, copybooks, etc.)
        final_prompt = final_prompt.replace("{{program_name}}", bundle.name)
        final_prompt = final_prompt.replace("{{copybooks_count}}", str(len(bundle.copybooks)))
        final_prompt = final_prompt.replace("{{jcls_count}}", str(len(bundle.jcls)))
        # Adicionar mais variáveis de contexto conforme necessário

        req = AIRequest(
            program_name=bundle.name,
            timestamp=now,
            provider=self.provider.get_provider_name() if hasattr(self.provider, "get_provider_name") else type(self.provider).__name__,
            model=model_cfg.name,
            program_code=full_code, # Enviar o código completo com contexto
            prompts_sent=final_prompt,
            program_code_included=True,
            extra={},
        )
        self.archiver.save_request(model_cfg.key, req)

        try:
            res = self.provider.analyze_code(
                code=full_code,
                prompt=final_prompt,
                model_name=model_cfg.name,
                temperature=model_cfg.temperature,
                max_tokens=model_cfg.max_tokens,
                **(model_cfg.extra or {}),
            )
            resp = AIResponse(
                program_name=bundle.name,
                timestamp=now,
                provider=req.provider,
                model=model_cfg.name,
                success=True,
                tokens_used=int(res.get("tokens_used", 0)),
                response_time=float(res.get("response_time", 0.0)),
                content=str(res.get("content", "")),
                error_message="",
                metadata=res.get("metadata", {}),
                prompts_used={"system_prompt": prompt_template},
            )
        except Exception as e:
            log.error(json.dumps({
                "event": "analysis_error",
                "model": model_cfg.name,
                "program": bundle.name,
                "error": str(e),
            }, ensure_ascii=False))
            resp = AIResponse(
                program_name=bundle.name,
                timestamp=now,
                provider=req.provider,
                model=model_cfg.name,
                success=False,
                tokens_used=0,
                response_time=0.0,
                content="",
                error_message=str(e),
                metadata={},
                prompts_used={"system_prompt": prompt_template},
            )
        self.archiver.save_response(model_cfg.key, resp)
        report_md = self._build_report_md(bundle, resp)
        self.archiver.save_report(model_cfg.key, resp.program_name, report_md, "md")
        self.archiver.save_report(model_cfg.key, resp.program_name, report_md, "html", self.archiver.base_out.parent.parent.parent) # Passa a raiz do projeto (3 níveis acima) para o archiver para o template HTML
        return req, resp, report_md

    @staticmethod
    def _build_report_md(bundle: ProgramBundle, resp: AIResponse) -> str:
        header = f"# Análise do Artefato: {bundle.name}\\n\\n"
        try:
            kind = bundle.program.kind
            source_path = str(bundle.program.path)
        except Exception:
            kind = "unknown"
            source_path = "<desconhecido>"
        meta = (
            f"**Data da Análise:** {resp.timestamp}  \\n"
            f"**Modelo de IA:** {resp.model}  \\n"
            f"**Provedor:** {resp.provider}  \\n"
            f"**Tipo do Artefato:** {kind}  \\n"
            f"**Origem:** `{source_path}`  \\n\\n"
        )
        status = "SUCESSO" if resp.success else "FALHA"
        transparencia = (
            "\\n---\\n\\n## Transparência e Auditoria\\n\\n"
            "| Aspecto | Valor |\\n|---------|-------|\\n"
            f"| **Status da Análise** | {status} |\\n"
            f"| **Tokens Utilizados** | {resp.tokens_used} |\\n"
            f"| **Tempo de Resposta** | {resp.response_time:.2f} segundos |\\n"
        )
        content = resp.content or "(Sem conteúdo – verifique `ai_responses`)"
        corpo = (
            "\\n---\\n\\n## Análise Detalhada\\n\\n"
            f"{content}\\n"
        )
        if bundle.program.kind == "cobol":
            copybooks_list = "\\n".join([f"  - {c.path.name}" for c in bundle.copybooks])
            jcls_list = "\\n".join([f"  - {j.path.name}" for j in bundle.jcls])

            aux = (
                "\\n---\\n\\n## Contexto de Execução (COBOL)\\n\\n"
                f"**Copybooks Referenciados ({len(bundle.copybooks)}):**\\n{copybooks_list}\\n"
                f"**JCLs Referenciados ({len(bundle.jcls)}):**\\n{jcls_list}\\n"
            )
        else:
            aux = ""
        return header + meta + corpo + transparencia + aux

    def _build_full_code(self, bundle: ProgramBundle) -> str:
        """Constrói o código completo para envio à IA, incluindo Copybooks e JCLs."""
        full_code = f"--- ARTEFATO PRINCIPAL: {bundle.name} ({bundle.program.path.name}) ---\n"
        full_code += bundle.program.content
        full_code += "\n\n--- CONTEXTO ---\n"

        if bundle.copybooks:
            full_code += "\n--- COPYBOOKS REFERENCIADOS ---\n"
            for c in bundle.copybooks:
                full_code += f"\n--- COPYBOOK: {c.path.name} ---\n"
                full_code += c.content
                full_code += "\n"

        if bundle.jcls:
            full_code += "\n--- JCLS REFERENCIADOS ---\n"
            for j in bundle.jcls:
                full_code += f"\n--- JCL: {j.path.name} ---\n"
                full_code += j.content
                full_code += "\n"
        
        return full_code

# -----------------------------
# App Orchestrator
# -----------------------------
class App:
    def __init__(self, input_dir: Path, output_dir: Path, config_path: Path, prompt_path: Path,
                 config_loader: 'ConfigLoader', prompt_loader: 'PromptLoader',
                 archiver: 'RequestResponseArchiver', provider: 'BaseProvider',
                 input_organizer: 'InputOrganizer', rag_manager: Optional['RAGManager'] = None, app_name: str = "llm-analise"):

        self.input_dir = input_dir
        self.config_path = config_path
        self.prompt_path = prompt_path

        # Carregar config e prompt (ainda dependem de caminhos, mas os loaders são injetados)
        self.config = config_loader.load(config_path)
        self.prompt = prompt_loader.load(prompt_path)

        # Dependências injetadas
        self.archiver = archiver
        self.provider = provider
        self.input_organizer = input_organizer
        self.rag_manager = rag_manager
        self.app_name = app_name

        log.info(json.dumps({"event": "app_init", "output_base": str(archiver.base_out)}))

    def run(self) -> None:
        artifacts = self.input_organizer.scan(self.input_dir)
        bundles = self.input_organizer.build_bundles(artifacts)
        if not bundles:
            raise RuntimeError("Nenhum arquivo legível encontrado no diretório de entrada")
        runner = AnalysisRunner(self.provider, self.archiver, self.config.models, self.rag_manager)
        runner.run_analysis(bundles, self.prompt)

if __name__ == "__main__":
    if os.environ.get("RUN_APP_TESTS") != "1":
        raise SystemExit(main())
