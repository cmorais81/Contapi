llm-analise \

CLI para organizar e analisar qualquer arquivo na pasta de entrada, gerando requests para cada **modelo** do Luzia/LLM,
salvando **ai_requests**, **ai_responses** e um **relatório Markdown** por modelo.

## Instalação (modo dev)
```bash
# Instalar dependências (incluindo pybreaker)
pip install -e .
pip install pybreaker

# Executar via script runner/main.py
python3 runner/main.py --input ...
```
```bash
pip install -e .
```

## Uso

### Inicialização do Projeto

Para copiar os arquivos de configuração e exemplos (`examples/`) para o diretório atual:

```bash
llm-analise --init
```

### Execução da Análise
```bash
python3 runner/main.py \\
  --input /caminho/da/pasta \\
  --output /caminho/saida \\
  --config examples/config.yaml \\
  --prompt examples/prompt_original.yaml
```

## Saída
```
/output_<nome_da_pasta>/
  /model_<model_key>/
    ai_requests/
    ai_responses/
    cobol_llm_analise_analise.md
```

## Testes
```bash
pytest -q
```
