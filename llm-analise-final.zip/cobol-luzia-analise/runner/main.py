#!/usr/bin/env python3
"""
Ponto de entrada CLI para o Luzia-Analise.
"""
import argparse
import json
import sys
import traceback
from pathlib import Path
from typing import List, Optional
import importlib.resources as pkg_resources
import shutil

# Adicionar o diretório src ao sys.path para imports relativos
# sys.path.insert(0, str(Path(__file__).parent.parent / "src")) # Não é necessário se o pacote estiver instalado

try:
    from llm_analise.app import App, ConfigLoader, PromptLoader, InputOrganizer, RequestResponseArchiver, ProviderFactory, log
    from llm_analise.provider.base_provider import ProviderError, BaseProvider
    from llm_analise.rag import RAGManager
except ImportError as e:
    # Fallback para execução direta (se o pacote não estiver instalado)
    # Tenta adicionar o src/ ao path se falhar
    sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
    try:
        from llm_analise.app import App, ConfigLoader, PromptLoader, InputOrganizer, RequestResponseArchiver, ProviderFactory, log
        from llm_analise.provider.base_provider import ProviderError, BaseProvider
        from llm_analise.rag import RAGManager
    except ImportError:
        print(f"Erro ao importar módulos do pacote llm_analise. Certifique-se de que o pacote está instalado ou que você está executando a partir da raiz do projeto. Erro: {e}", file=sys.stderr)
        sys.exit(1)


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Analisador de programas (COBOL e outros) usando Luzia/LLMs")
    
    # Argumento de inicialização
    p.add_argument("--init", action="store_true", help="Copia arquivos de configuração e exemplos para o diretório atual.")

    # Argumentos de execução
    p.add_argument("--input", help="Caminho para a pasta com arquivos a serem analisados")
    p.add_argument("--output", help="Diretório onde o resultado será salvo")
    p.add_argument("--config", help="Arquivo de configuração YAML")
    p.add_argument("--prompt", help="Arquivo de prompt (YAML/MD/TXT)")
    
    return p.parse_args(argv)

def init_project() -> int:
    """Copia arquivos de configuração e exemplos para o diretório atual."""
    target_dir = Path.cwd()
    package_name = "llm_analise"
    resource_dir = "examples"
    
    log.info(json.dumps({"event": "init_start", "target_dir": str(target_dir)}))
    
    try:
        # Tenta copiar a pasta examples
        with pkg_resources.as_file(pkg_resources.files(package_name).joinpath(resource_dir)) as source_path:
            dest_path = target_dir / resource_dir
            if dest_path.exists():
                log.warning(json.dumps({"event": "init_warning", "message": f"Diretório '{resource_dir}' já existe. Ignorando."}))
            else:
                shutil.copytree(source_path, dest_path)
                log.info(json.dumps({"event": "init_success", "message": f"Diretório '{resource_dir}' copiado para {dest_path}"}))

        # Tenta copiar o README.md para o diretório atual
        readme_name = "README.md"
        with pkg_resources.as_file(pkg_resources.files(".").joinpath(readme_name)) as source_path:
            dest_path = target_dir / readme_name
            if dest_path.exists():
                log.warning(json.dumps({"event": "init_warning", "message": f"Arquivo '{readme_name}' já existe. Ignorando."}))
            else:
                shutil.copy2(source_path, dest_path)
                log.info(json.dumps({"event": "init_success", "message": f"Arquivo '{readme_name}' copiado para {dest_path}"}))

        log.info(json.dumps({"event": "init_done", "message": "Projeto inicializado com sucesso!"}))
        return 0
    except Exception as e:
        log.error(json.dumps({"event": "init_error", "error": str(e), "trace": traceback.format_exc()}))
        print(f"Erro ao inicializar o projeto: {e}", file=sys.stderr)
        return 1

def main(argv: Optional[List[str]] = None) -> int:
    try:
        args = parse_args(argv)

        # --- Lógica do comando --init ---
        if args.init:
            return init_project()

        # Validar argumentos obrigatórios para execução
        if not args.input or not args.output or not args.config or not args.prompt:
            log.error(json.dumps({"event": "fatal_error", "error": "Argumentos obrigatórios para execução (--input, --output, --config, --prompt) não fornecidos."}))
            return 1
            
        input_dir = Path(args.input).expanduser().resolve()
        output_dir = Path(args.output).expanduser().resolve()
        config_path = Path(args.config).expanduser().resolve()
        prompt_path = Path(args.prompt).expanduser().resolve()
        app_name = "llm-analise"

        # --- Configuração das Dependências (DI Container Simples) ---
        config_loader = ConfigLoader()
        app_config = config_loader.load(config_path)
        prompt_loader = PromptLoader()
        input_organizer = InputOrganizer()

        # Provider
        provider_factory = ProviderFactory()
        provider = provider_factory.create(app_config)
        
        if not provider.is_enabled():
            log.error(json.dumps({"event": "fatal_error", "error": f"Provider {provider.get_provider_name()} está desabilitado na configuração."}))
            return 1

        # RAG Manager (Sempre inicializa, mas só persiste se houver sucesso)
        rag_db_path = Path.cwd() / "rag_data"
        rag_manager = RAGManager(rag_db_path)

        # Archiver
        output_base = output_dir / f"output_{input_dir.name}"
        archiver = RequestResponseArchiver(output_base, app_name)

        # App (Injeção de Dependência)
        app = App(
            input_dir=input_dir,
            output_dir=output_dir, # Mantido para consistência da CLI, mas não usado dentro do App
            config_path=config_path,
            prompt_path=prompt_path,
            config_loader=config_loader,
            prompt_loader=prompt_loader,
            archiver=archiver,
            provider=provider,
            input_organizer=input_organizer,
            rag_manager=rag_manager, # Injeção do RAGManager
            app_name=app_name,
        )
        app.run()
        log.info(json.dumps({"event": "done"}))
        return 0
    except ProviderError as pe:
        log.error(json.dumps({"event": "provider_error", "error": str(pe)}))
        return 2
    except Exception as e:
        log.error(json.dumps({
            "event": "fatal_error",
            "error": str(e),
            "trace": traceback.format_exc(),
        }, ensure_ascii=False))
        return 1

if __name__ == "__main__":
    sys.exit(main())
