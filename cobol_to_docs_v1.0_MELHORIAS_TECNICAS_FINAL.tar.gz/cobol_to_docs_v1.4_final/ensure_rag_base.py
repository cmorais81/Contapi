#!/usr/bin/env python3
"""
Script para garantir que a base de conhecimento RAG seja usada corretamente.
Este script verifica e corrige as configurações para garantir que:
1. A base de conhecimento RAG seja sempre carregada da pasta data/
2. O novo conhecimento aprendido seja salvo na pasta data/
3. O sistema use a base expandida por padrão
"""

import os
import json
import shutil
import logging
import yaml
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("ensure_rag_base")

def ensure_data_directory():
    """Garante que o diretório data/ exista."""
    data_dir = Path("data")
    if not data_dir.exists():
        data_dir.mkdir(parents=True)
        logger.info("Diretório data/ criado")
    return data_dir

def check_and_fix_config():
    """Verifica e corrige o arquivo de configuração."""
    config_path = Path("config/config.yaml")
    
    if not config_path.exists():
        logger.error(f"Arquivo de configuração não encontrado: {config_path}")
        return False
    
    try:
        # Carregar configuração
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        # Verificar seção RAG
        if 'rag' not in config:
            config['rag'] = {}
        
        # Verificar e corrigir caminhos
        changes_made = False
        
        # Verificar knowledge_base_path
        if 'knowledge_base_path' not in config['rag'] or not config['rag']['knowledge_base_path'].startswith('data/'):
            config['rag']['knowledge_base_path'] = 'data/cobol_knowledge_base_cadoc_expanded.json'
            changes_made = True
            logger.info("Corrigido: knowledge_base_path apontando para data/cobol_knowledge_base_cadoc_expanded.json")
        
        # Verificar embeddings_path
        if 'embeddings_path' not in config['rag'] or not config['rag']['embeddings_path'].startswith('data/'):
            config['rag']['embeddings_path'] = 'data/cobol_embeddings.pkl'
            changes_made = True
            logger.info("Corrigido: embeddings_path apontando para data/cobol_embeddings.pkl")
        
        # Verificar auto_learn
        if 'auto_learn' not in config['rag']:
            config['rag']['auto_learn'] = True
            changes_made = True
            logger.info("Corrigido: auto_learn habilitado")
        
        # Verificar log_dir
        if 'log_dir' not in config['rag']:
            config['rag']['log_dir'] = 'logs'
            changes_made = True
            logger.info("Corrigido: log_dir configurado para logs/")
        
        # Salvar configuração se houve mudanças
        if changes_made:
            with open(config_path, 'w', encoding='utf-8') as f:
                yaml.dump(config, f, default_flow_style=False)
            logger.info(f"Configuração atualizada: {config_path}")
        else:
            logger.info("Configuração já está correta")
        
        return True
        
    except Exception as e:
        logger.error(f"Erro ao verificar/corrigir configuração: {e}")
        return False

def check_knowledge_base_files():
    """Verifica e garante que os arquivos da base de conhecimento existam."""
    data_dir = ensure_data_directory()
    
    # Verificar arquivo principal
    kb_expanded_path = data_dir / "cobol_knowledge_base_cadoc_expanded.json"
    kb_path = data_dir / "cobol_knowledge_base.json"
    
    # Se o arquivo expandido não existir, verificar se existe uma cópia
    if not kb_expanded_path.exists():
        logger.warning(f"Base de conhecimento expandida não encontrada: {kb_expanded_path}")
        
        # Verificar se existe o arquivo básico
        if kb_path.exists():
            # Copiar o básico para o expandido
            shutil.copy(kb_path, kb_expanded_path)
            logger.info(f"Copiado {kb_path} para {kb_expanded_path}")
        else:
            # Criar um arquivo básico vazio
            create_empty_knowledge_base(kb_expanded_path)
            logger.info(f"Criado arquivo vazio: {kb_expanded_path}")
    
    # Garantir que o arquivo básico também exista
    if not kb_path.exists():
        if kb_expanded_path.exists():
            # Copiar o expandido para o básico
            shutil.copy(kb_expanded_path, kb_path)
            logger.info(f"Copiado {kb_expanded_path} para {kb_path}")
        else:
            # Criar um arquivo básico vazio
            create_empty_knowledge_base(kb_path)
            logger.info(f"Criado arquivo vazio: {kb_path}")
    
    # Verificar embeddings
    embeddings_path = data_dir / "cobol_embeddings.pkl"
    if not embeddings_path.exists():
        # Criar arquivo vazio de embeddings
        with open(embeddings_path, 'wb') as f:
            import pickle
            pickle.dump({}, f)
        logger.info(f"Criado arquivo vazio de embeddings: {embeddings_path}")
    
    return True

def create_empty_knowledge_base(path):
    """Cria um arquivo de base de conhecimento vazio."""
    empty_kb = []
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(empty_kb, f, indent=2)

def check_rag_integration():
    """Verifica se o sistema RAG está integrado corretamente."""
    try:
        # Importar módulo RAG
        from src.rag.rag_integration import RAGIntegration
        from src.rag.cobol_rag_system import CobolRAGSystem
        
        logger.info("Módulos RAG importados com sucesso")
        return True
    except ImportError as e:
        logger.error(f"Erro ao importar módulos RAG: {e}")
        return False

def main():
    """Função principal."""
    logger.info("Iniciando verificação da base RAG")
    
    # Verificar diretório data/
    ensure_data_directory()
    
    # Verificar e corrigir configuração
    if not check_and_fix_config():
        logger.error("Falha ao verificar/corrigir configuração")
        return False
    
    # Verificar arquivos da base de conhecimento
    if not check_knowledge_base_files():
        logger.error("Falha ao verificar arquivos da base de conhecimento")
        return False
    
    # Verificar integração RAG
    if not check_rag_integration():
        logger.error("Falha ao verificar integração RAG")
        return False
    
    logger.info("Verificação da base RAG concluída com sucesso")
    return True

if __name__ == "__main__":
    success = main()
    exit(0 if success else 1)
