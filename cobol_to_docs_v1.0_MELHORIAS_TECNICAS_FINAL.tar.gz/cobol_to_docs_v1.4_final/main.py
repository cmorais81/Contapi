#!/usr/bin/env python3
"""
COBOL to Docs v1.4 - Sistema de Análise e Documentação de Programas COBOL
Autor: Carlos Morais
Data: Setembro 2025

Sistema completo para análise automatizada de programas COBOL com geração
de documentação técnica profissional usando IA.

FUNCIONALIDADE COMPLETA RESTAURADA:
- Processamento de múltiplos programas COBOL
- Suporte a múltiplos modelos de IA
- Análise de copybooks complementares
- Geração de relatórios comparativos
- Detecção automática de código COBOL
- Análise aprofundada por padrão (v1.4)
- Base RAG expandida com auto-aprendizado
"""

import argparse
import logging
import os
import sys
import json
import time
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

# Garantir que a base RAG esteja configurada corretamente
try:
    from ensure_rag_base import main as ensure_rag
    ensure_rag()
except ImportError:
    print("AVISO: Script ensure_rag_base.py não encontrado. A base RAG pode não estar configurada corretamente.")
except Exception as e:
    print(f"AVISO: Erro ao verificar base RAG: {e}")

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from src.core.config import ConfigManager
from src.core.prompt_manager_dual import DualPromptManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.parsers.cobol_parser_original import COBOLParser, CobolProgram, CobolBook
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer
from src.analyzers.consolidated_analyzer import ConsolidatedAnalyzer
from src.generators.documentation_generator import DocumentationGenerator
from src.utils.html_generator import HTMLReportGenerator
from src.utils.cost_calculator import CostCalculator
from src.rag.rag_integration import RAGIntegration
from src.core.intelligent_model_selector import IntelligentModelSelector
from process_detailed_analysis import process_detailed_business_analysis
from process_advanced_consolidated_analysis import process_advanced_consolidated_analysis

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_to_docs_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
