#!/usr/bin/env python3
"""
Debug Test - Identificar problema específico
"""

import os
import sys
import json
import logging
from datetime import datetime
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from analyzers.technical_cobol_analyzer import TechnicalCobolAnalyzer

def debug_analysis():
    """Debug da análise técnica"""
    
    # Configurar logging
    logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger(__name__)
    
    # Configuração simplificada
    config = {
        'technical_analysis': {
            'focus_mode': 'technical_precision'
        }
    }
    
    try:
        # Inicializar analisador
        analyzer = TechnicalCobolAnalyzer(config)
        
        # Ler código COBOL
        with open('test_program.cbl', 'r', encoding='utf-8', errors='ignore') as f:
            cobol_code = f.read()
        
        # Realizar análise
        result = analyzer.analyze_program(cobol_code, "LHAN0546")
        
        # Debug: mostrar estrutura do resultado
        print("\\n=== DEBUG: Estrutura do Resultado ===")
        print(f"Program ID: {result.program_id}")
        print(f"Analysis Type: {result.analysis_type}")
        
        print("\\n=== Technical Metrics ===")
        print(json.dumps(result.technical_metrics, indent=2, default=str))
        
        print("\\n=== Code Structures ===")
        print(json.dumps(result.code_structures, indent=2, default=str))
        
        print("\\n=== Dependencies ===")
        print(json.dumps(result.dependencies, indent=2, default=str))
        
        print("\\n=== Business Rules (first 3) ===")
        for i, rule in enumerate(result.business_rules[:3]):
            print(f"Rule {i+1}: {rule}")
        
        print("\\n=== Performance Analysis ===")
        print(json.dumps(result.performance_analysis, indent=2, default=str))
        
        print("\\n=== Quality Metrics ===")
        print(json.dumps(result.quality_metrics, indent=2, default=str))
        
        print("\\n✓ Análise concluída com sucesso!")
        
    except Exception as e:
        logger.error(f"Erro na análise: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    debug_analysis()
