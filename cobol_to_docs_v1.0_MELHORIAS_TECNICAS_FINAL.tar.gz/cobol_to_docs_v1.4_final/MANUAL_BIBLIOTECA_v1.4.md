# Manual de Uso - COBOL to Docs v1.4 como Biblioteca Python

## Instalação

### Via pip (Recomendado)

```bash
# Instalar do diretório local
pip install -e .

# OU instalar dependências manualmente
pip install -r requirements.txt
```

### Verificar Instalação

```python
import cobol_to_docs
print(f"Versão: {cobol_to_docs.__version__}")
print("Instalação bem-sucedida!")
```

## Uso Básico

### Análise Rápida de Arquivo

```python
from cobol_to_docs import analyze_cobol_file

# Análise com configurações padrão (análise aprofundada ativada)
result = analyze_cobol_file('programa.cbl')

print(f"Programa: {result.program_name}")
print(f"Sucesso: {result.success}")
print(f"Regras de negócio encontradas: {len(result.business_rules)}")

# Exibir regras de negócio
for i, rule in enumerate(result.business_rules, 1):
    print(f"{i}. {rule}")
```

### Análise de Código Direto

```python
from cobol_to_docs import analyze_cobol_code

codigo_cobol = """
IDENTIFICATION DIVISION.
PROGRAM-ID. CALCULO-JUROS.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 PRINCIPAL     PIC 9(7)V99.
01 TAXA-MENSAL   PIC 9(1)V9999 VALUE 0.0150.
01 DIAS-ATRASO   PIC 9(3).
01 JUROS         PIC 9(7)V99.

PROCEDURE DIVISION.
CALCULAR-JUROS.
    COMPUTE JUROS = PRINCIPAL * TAXA-MENSAL * DIAS-ATRASO / 30.
    DISPLAY 'JUROS CALCULADOS: ' JUROS.
    STOP RUN.
"""

result = analyze_cobol_code(codigo_cobol, program_name="CALCULO-JUROS")
print(result.get_summary())
```

## Uso Avançado

### Configuração Personalizada

```python
from cobol_to_docs import CobolAnalyzer, CobolConfig

# Criar configuração personalizada
config = CobolConfig(
    deep_analysis=True,          # Análise aprofundada (padrão v1.4)
    model='enhanced_mock',       # Modelo a usar
    rag_enabled=True,           # Sistema RAG ativado
    output_dir='./resultados',  # Diretório de saída
    extract_formulas=True,      # Extrair fórmulas matemáticas
    generate_html=True,         # Gerar relatório HTML
    log_level='DEBUG'           # Nível de log detalhado
)

# Criar analisador com configuração
analyzer = CobolAnalyzer(
    deep_analysis=config.deep_analysis,
    model=config.model,
    rag_enabled=config.rag_enabled,
    output_dir=config.output_dir,
    extract_formulas=config.extract_formulas,
    log_level=config.log_level
)

# Analisar arquivo
result = analyzer.analyze_file('programa_complexo.cbl')
```

### Análise com Múltiplos Modelos

```python
from cobol_to_docs import CobolAnalyzer

# Lista de modelos para comparação
modelos = ['enhanced_mock', 'basic']
resultados = {}

for modelo in modelos:
    analyzer = CobolAnalyzer(model=modelo, output_dir=f'./analise_{modelo}')
    resultado = analyzer.analyze_file('programa.cbl')
    resultados[modelo] = resultado
    
    print(f"\\n=== Resultado {modelo} ===")
    print(f"Tokens: {resultado.tokens_used:,}")
    print(f"Custo: ${resultado.cost:.4f}")
    print(f"Regras: {len(resultado.business_rules)}")
    print(f"Complexidade: {resultado.complexity_score:.1f}/10")

# Comparar resultados
melhor_modelo = max(resultados.keys(), 
                   key=lambda k: len(resultados[k].business_rules))
print(f"\\nMelhor modelo para este programa: {melhor_modelo}")
```

## Configurações Detalhadas

### Análise Aprofundada (Padrão v1.4)

```python
from cobol_to_docs import CobolAnalyzer

# Análise aprofundada é padrão na v1.4
analyzer = CobolAnalyzer()  # deep_analysis=True por padrão

# Para forçar análise básica
analyzer_basico = CobolAnalyzer(deep_analysis=False)

# Análise com extração de fórmulas
analyzer_formulas = CobolAnalyzer(
    deep_analysis=True,
    extract_formulas=True,
    include_code_snippets=True
)

result = analyzer_formulas.analyze_file('calculo_financeiro.cbl')

# Verificar se encontrou fórmulas
if 'formulas' in result.detailed_analysis:
    print("Fórmulas encontradas:")
    for formula in result.detailed_analysis['formulas']:
        print(f"- {formula}")
```

### Sistema RAG Personalizado

```python
from cobol_to_docs import CobolAnalyzer

# Configurar RAG com base de conhecimento específica
analyzer = CobolAnalyzer(
    rag_enabled=True,
    rag_knowledge_base='cobol_knowledge_base_cadoc_expanded.json',
    rag_threshold=0.8  # Threshold mais alto para maior precisão
)

result = analyzer.analyze_file('sistema_bancario.cbl')

# Verificar contexto RAG aplicado
if result.metadata.get('rag_context'):
    rag_info = result.metadata['rag_context']
    print(f"Itens de conhecimento aplicados: {rag_info['knowledge_items_used']}")
    print(f"Operações RAG: {rag_info['operations_performed']}")
```

### Controle de Custos

```python
from cobol_to_docs import CobolAnalyzer

# Configurar limite de custo
analyzer = CobolAnalyzer(
    track_costs=True,
    cost_limit=0.10,  # Limite de $0.10
    model='enhanced_mock'  # Modelo gratuito para testes
)

try:
    result = analyzer.analyze_file('programa_grande.cbl')
    print(f"Análise concluída - Custo: ${result.cost:.4f}")
except Exception as e:
    if "custo excedido" in str(e):
        print(f"Limite de custo atingido: {e}")
```

## Trabalhando com Resultados

### Acessar Regras de Negócio Detalhadas

```python
result = analyze_cobol_file('programa.cbl')

if result.success:
    print("=== REGRAS DE NEGÓCIO ===")
    for i, regra in enumerate(result.business_rules, 1):
        print(f"{i}. {regra}")
    
    print("\\n=== DETALHES TÉCNICOS ===")
    for categoria, detalhes in result.technical_details.items():
        print(f"{categoria.upper()}: {len(detalhes)} itens")
        for detalhe in detalhes[:3]:  # Primeiros 3
            print(f"  - {detalhe}")
    
    print("\\n=== RECOMENDAÇÕES ===")
    for i, rec in enumerate(result.recommendations, 1):
        print(f"{i}. {rec}")
```

### Análise Detalhada Estruturada

```python
result = analyze_cobol_file('programa.cbl', extract_formulas=True)

if result.detailed_analysis:
    analysis = result.detailed_analysis
    
    # Regras de negócio com valores específicos
    if 'business_rules' in analysis:
        print("=== REGRAS COM VALORES ===")
        for rule in analysis['business_rules']:
            print(f"Regra: {rule.get('description', 'N/A')}")
            if rule.get('values'):
                print(f"  Valores: {rule['values']}")
            if rule.get('code_reference'):
                print(f"  Código: {rule['code_reference']}")
            print()
    
    # Cálculos financeiros
    if 'financial_calculations' in analysis:
        print("=== CÁLCULOS FINANCEIROS ===")
        for calc in analysis['financial_calculations']:
            print(f"Fórmula: {calc.get('formula', 'N/A')}")
            print(f"Variáveis: {calc.get('variables', [])}")
            print(f"Linha: {calc.get('line_number', 'N/A')}")
            print()
```

### Exportar Resultados

```python
import json
from pathlib import Path

result = analyze_cobol_file('programa.cbl', output_dir='./exportacao')

# Salvar resultado completo em JSON
output_file = Path('./exportacao/resultado_completo.json')
with open(output_file, 'w', encoding='utf-8') as f:
    json.dump(result.to_dict(), f, indent=2, ensure_ascii=False, default=str)

# Salvar apenas regras de negócio
rules_file = Path('./exportacao/regras_negocio.txt')
with open(rules_file, 'w', encoding='utf-8') as f:
    f.write(f"REGRAS DE NEGÓCIO - {result.program_name}\\n")
    f.write("=" * 50 + "\\n\\n")
    
    for i, regra in enumerate(result.business_rules, 1):
        f.write(f"{i}. {regra}\\n")

print(f"Resultados exportados para: {output_file.parent}")
```

## Integração com Projetos

### Análise de Múltiplos Arquivos

```python
from pathlib import Path
from cobol_to_docs import CobolAnalyzer

def analisar_projeto_cobol(diretorio_fonte, output_dir='./analise_projeto'):
    """Analisar todos os arquivos COBOL de um projeto"""
    
    analyzer = CobolAnalyzer(
        deep_analysis=True,
        output_dir=output_dir,
        rag_enabled=True
    )
    
    # Encontrar arquivos COBOL
    cobol_files = []
    for ext in ['*.cbl', '*.cob', '*.cobol']:
        cobol_files.extend(Path(diretorio_fonte).glob(f"**/{ext}"))
    
    resultados = {}
    
    for arquivo in cobol_files:
        print(f"Analisando: {arquivo.name}")
        
        try:
            resultado = analyzer.analyze_file(arquivo)
            resultados[arquivo.name] = resultado
            
            print(f"  ✓ {len(resultado.business_rules)} regras encontradas")
            
        except Exception as e:
            print(f"  ✗ Erro: {e}")
            resultados[arquivo.name] = None
    
    # Relatório consolidado
    total_regras = sum(len(r.business_rules) for r in resultados.values() if r and r.success)
    arquivos_ok = sum(1 for r in resultados.values() if r and r.success)
    
    print(f"\\n=== RESUMO DO PROJETO ===")
    print(f"Arquivos analisados: {len(cobol_files)}")
    print(f"Análises bem-sucedidas: {arquivos_ok}")
    print(f"Total de regras encontradas: {total_regras}")
    
    return resultados

# Usar a função
resultados = analisar_projeto_cobol('./src/cobol/')
```

### Pipeline de CI/CD

```python
# ci_analysis.py
import sys
from pathlib import Path
from cobol_to_docs import analyze_cobol_file

def main():
    """Script para CI/CD - análise de código COBOL"""
    
    if len(sys.argv) < 2:
        print("Uso: python ci_analysis.py <arquivo.cbl>")
        sys.exit(1)
    
    arquivo = sys.argv[1]
    
    try:
        # Análise com configurações para CI
        result = analyze_cobol_file(
            arquivo,
            model='enhanced_mock',  # Modelo rápido para CI
            deep_analysis=True,
            output_dir='./ci_reports'
        )
        
        if not result.success:
            print(f"ERRO: Falha na análise - {result.error_message}")
            sys.exit(1)
        
        # Verificar qualidade mínima
        min_rules = 3
        if len(result.business_rules) < min_rules:
            print(f"AVISO: Poucas regras encontradas ({len(result.business_rules)} < {min_rules})")
        
        # Verificar complexidade
        if result.complexity_score > 8.0:
            print(f"AVISO: Alta complexidade detectada ({result.complexity_score:.1f}/10)")
        
        print(f"✓ Análise concluída: {result.get_summary()}")
        
    except Exception as e:
        print(f"ERRO: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
```

## Exemplos Práticos

### Sistema Bancário

```python
from cobol_to_docs import CobolAnalyzer

# Configuração específica para sistemas bancários
analyzer = CobolAnalyzer(
    deep_analysis=True,
    rag_enabled=True,
    rag_knowledge_base='cobol_knowledge_base_cadoc_expanded.json',
    extract_formulas=True,
    include_code_snippets=True,
    output_dir='./analise_bancaria'
)

# Analisar programa de cálculo de juros
result = analyzer.analyze_file('CALC_JUROS.cbl')

print("=== ANÁLISE SISTEMA BANCÁRIO ===")
print(f"Programa: {result.program_name}")
print(f"Complexidade: {result.complexity_score:.1f}/10")

# Buscar regras específicas de juros
regras_juros = [r for r in result.business_rules 
                if any(palavra in r.lower() for palavra in ['juros', 'taxa', 'cálculo'])]

print(f"\\nRegras de juros encontradas: {len(regras_juros)}")
for regra in regras_juros:
    print(f"- {regra}")

# Verificar fórmulas financeiras
if result.detailed_analysis.get('financial_calculations'):
    print("\\nFórmulas financeiras:")
    for calc in result.detailed_analysis['financial_calculations']:
        print(f"- {calc.get('formula', 'N/A')}")
```

### Modernização de Legacy

```python
from cobol_to_docs import CobolAnalyzer

def avaliar_modernizacao(arquivo_cobol):
    """Avaliar programa COBOL para modernização"""
    
    analyzer = CobolAnalyzer(
        deep_analysis=True,
        advanced_analysis=True,
        model_comparison=True
    )
    
    result = analyzer.analyze_file(arquivo_cobol)
    
    # Critérios de modernização
    criterios = {
        'complexidade_alta': result.complexity_score > 7.0,
        'muitas_regras': len(result.business_rules) > 10,
        'tem_calculos': len(result.detailed_analysis.get('financial_calculations', [])) > 0,
        'tem_recomendacoes': len(result.recommendations) > 0
    }
    
    score_modernizacao = sum(criterios.values()) / len(criterios) * 100
    
    print(f"=== AVALIAÇÃO DE MODERNIZAÇÃO ===")
    print(f"Programa: {result.program_name}")
    print(f"Score de modernização: {score_modernizacao:.1f}%")
    print()
    
    for criterio, atende in criterios.items():
        status = "✓" if atende else "✗"
        print(f"{status} {criterio.replace('_', ' ').title()}")
    
    if score_modernizacao > 75:
        print("\\n🚀 RECOMENDAÇÃO: Alta prioridade para modernização")
    elif score_modernizacao > 50:
        print("\\n⚠️  RECOMENDAÇÃO: Considerar modernização")
    else:
        print("\\n✅ RECOMENDAÇÃO: Baixa prioridade para modernização")
    
    return score_modernizacao

# Usar a função
score = avaliar_modernizacao('SISTEMA_LEGADO.cbl')
```

## Tratamento de Erros

```python
from cobol_to_docs import analyze_cobol_file, CobolAnalysisError, ModelNotAvailableError

try:
    result = analyze_cobol_file('programa.cbl', model='modelo_inexistente')
    
except ModelNotAvailableError as e:
    print(f"Modelo não disponível: {e}")
    print(f"Modelos disponíveis: {e.available_models}")
    
except CobolAnalysisError as e:
    print(f"Erro na análise: {e}")
    if hasattr(e, 'program_name'):
        print(f"Programa: {e.program_name}")
    
except Exception as e:
    print(f"Erro inesperado: {e}")
```

## Configuração para Produção

```python
from cobol_to_docs import CobolAnalyzer, CobolConfig

# Configuração otimizada para produção
config_producao = CobolConfig(
    deep_analysis=True,          # Análise completa
    model='enhanced_mock',       # Modelo estável
    rag_enabled=True,           # RAG para contexto
    track_costs=True,           # Monitorar custos
    cost_limit=1.00,            # Limite de $1.00 por análise
    timeout=600,                # 10 minutos timeout
    log_level='INFO',           # Log moderado
    generate_html=True,         # Relatórios HTML
    include_code_snippets=True  # Incluir trechos de código
)

analyzer = CobolAnalyzer(**config_producao.to_dict())

# Análise com monitoramento
try:
    result = analyzer.analyze_file('programa_producao.cbl')
    
    # Log de auditoria
    print(f"AUDITORIA: {result.program_name} - "
          f"Tokens: {result.tokens_used:,} - "
          f"Custo: ${result.cost:.4f} - "
          f"Modelo: {result.model_used}")
    
except Exception as e:
    print(f"ERRO PRODUÇÃO: {e}")
    # Implementar notificação/alerta aqui
```

## Conclusão

A versão v1.4 do COBOL to Docs oferece:

- **Análise aprofundada por padrão**: Extração detalhada de regras e valores
- **Interface de biblioteca simplificada**: Fácil integração em projetos Python
- **Configuração flexível**: Adaptável a diferentes necessidades
- **Sistema RAG integrado**: Contexto especializado em COBOL/CADOC
- **Múltiplos formatos de saída**: Markdown, HTML, JSON
- **Controle de custos**: Monitoramento e limites configuráveis
- **Tratamento robusto de erros**: Exceções específicas e informativas

Para mais exemplos e documentação avançada, consulte os arquivos de exemplo incluídos no pacote.

---

**Versão**: 1.4.0  
**Data**: 30 de setembro de 2025  
**Compatibilidade**: Python 3.8+
