"""
Technical COBOL Analyzer - Analisador COBOL Técnico Aprimorado
Foco em análise técnica objetiva eliminando linguagem humanizada
"""

import re
import logging
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime

@dataclass
class TechnicalAnalysisResult:
    """Resultado de análise técnica estruturada"""
    program_id: str
    analysis_type: str
    technical_metrics: Dict[str, Any]
    code_structures: Dict[str, Any]
    dependencies: Dict[str, Any]
    business_rules: List[Dict[str, Any]]
    performance_analysis: Dict[str, Any]
    quality_metrics: Dict[str, Any]
    recommendations: List[str]
    analysis_timestamp: datetime

class TechnicalCobolAnalyzer:
    """
    Analisador COBOL técnico que elimina linguagem humanizada
    e foca em aspectos técnicos mensuráveis e verificáveis.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o analisador técnico"""
        self.logger = logging.getLogger(__name__)
        self.config = config
        
        # Padrões COBOL técnicos
        self.cobol_patterns = self._initialize_cobol_patterns()
        
        # Métricas de qualidade
        self.quality_thresholds = {
            'low_complexity': 10,
            'medium_complexity': 20,
            'high_complexity': 30,
            'max_nesting_depth': 5,
            'max_paragraph_lines': 50
        }
        
        self.logger.info("Technical COBOL Analyzer inicializado")
    
    def _initialize_cobol_patterns(self) -> Dict[str, str]:
        """Inicializa padrões regex para análise técnica COBOL"""
        return {
            # Identificação de programa
            'program_id': r'PROGRAM-ID\.\s*([\w-]+)',
            'author': r'AUTHOR\.\s*(.+)',
            'date_written': r'DATE-WRITTEN\.\s*(.+)',
            
            # Divisões e seções
            'identification_division': r'IDENTIFICATION\s+DIVISION\.',
            'environment_division': r'ENVIRONMENT\s+DIVISION\.',
            'data_division': r'DATA\s+DIVISION\.',
            'procedure_division': r'PROCEDURE\s+DIVISION\.',
            'working_storage': r'WORKING-STORAGE\s+SECTION\.',
            'file_section': r'FILE\s+SECTION\.',
            'input_output': r'INPUT-OUTPUT\s+SECTION\.',
            
            # Dependências
            'copy_statement': r'COPY\s+([\w-]+)(?:\s+REPLACING\s+(.+?))?(?:\.|$)',
            'include_statement': r'\+\+INCLUDE\s+([\w-]+)',
            
            # Definições de arquivo
            'select_statement': r'SELECT\s+([\w-]+)\s+ASSIGN\s+TO\s+[\'"]?([^\s\'"\.]+)[\'"]?',
            'organization': r'ORGANIZATION\s+IS\s+(\w+)',
            'access_mode': r'ACCESS\s+MODE\s+IS\s+(\w+)',
            'record_key': r'RECORD\s+KEY\s+IS\s+([\w-]+)',
            'alternate_key': r'ALTERNATE\s+RECORD\s+KEY\s+IS\s+([\w-]+)',
            'file_status': r'FILE\s+STATUS\s+IS\s+([\w-]+)',
            
            # Estruturas de dados
            'fd_definition': r'FD\s+([\w-]+)',
            'level_01': r'^\s*01\s+([\w-]+)',
            'level_77': r'^\s*77\s+([\w-]+)',
            'level_88': r'^\s*88\s+([\w-]+)',
            'pic_clause': r'PIC\s+([X9VS\(\)\+\-\.]+)',
            'occurs_clause': r'OCCURS\s+(\d+)(?:\s+TO\s+(\d+))?\s+TIMES',
            
            # Controle de fluxo
            'paragraph': r'^\s*([A-Z0-9][A-Z0-9-]*)\.\s*$',
            'perform_statement': r'PERFORM\s+([\w-]+)',
            'perform_until': r'PERFORM\s+UNTIL\s+(.+?)(?:\s+|$)',
            'perform_varying': r'PERFORM\s+VARYING\s+([\w-]+)',
            'if_statement': r'IF\s+(.+?)\s+THEN',
            'evaluate_statement': r'EVALUATE\s+(.+?)(?:\s+|$)',
            'when_clause': r'WHEN\s+(.+?)(?:\s+|$)',
            'go_to': r'GO\s+TO\s+([\w-]+)',
            
            # Operações de arquivo
            'open_statement': r'OPEN\s+(INPUT|OUTPUT|I-O|EXTEND)\s+([\w-]+)',
            'close_statement': r'CLOSE\s+([\w-]+)',
            'read_statement': r'READ\s+([\w-]+)(?:\s+INTO\s+([\w-]+))?',
            'write_statement': r'WRITE\s+([\w-]+)(?:\s+FROM\s+([\w-]+))?',
            'rewrite_statement': r'REWRITE\s+([\w-]+)(?:\s+FROM\s+([\w-]+))?',
            'delete_statement': r'DELETE\s+([\w-]+)',
            'start_statement': r'START\s+([\w-]+)\s+KEY\s+(?:IS\s+)?(.+?)(?:\s+|$)',
            
            # Operações de dados
            'move_statement': r'MOVE\s+(.+?)\s+TO\s+([\w-]+)',
            'compute_statement': r'COMPUTE\s+([\w-]+)\s*=\s*(.+?)(?:\s+|$)',
            'add_statement': r'ADD\s+(.+?)\s+TO\s+([\w-]+)',
            'subtract_statement': r'SUBTRACT\s+(.+?)\s+FROM\s+([\w-]+)',
            'multiply_statement': r'MULTIPLY\s+(.+?)\s+BY\s+([\w-]+)',
            'divide_statement': r'DIVIDE\s+(.+?)\s+INTO\s+([\w-]+)',
            
            # Operações de string
            'string_statement': r'STRING\s+(.+?)\s+DELIMITED\s+BY\s+(.+?)\s+INTO\s+([\w-]+)',
            'unstring_statement': r'UNSTRING\s+([\w-]+)\s+DELIMITED\s+BY\s+(.+?)\s+INTO\s+(.+?)(?:\s+|$)',
            'inspect_statement': r'INSPECT\s+([\w-]+)\s+(TALLYING|REPLACING)\s+(.+?)(?:\s+|$)',
            
            # Controles de erro
            'at_end': r'AT\s+END',
            'not_at_end': r'NOT\s+AT\s+END',
            'invalid_key': r'INVALID\s+KEY',
            'not_invalid_key': r'NOT\s+INVALID\s+KEY',
            'on_size_error': r'ON\s+SIZE\s+ERROR',
            
            # Funções intrínsecas
            'function_call': r'FUNCTION\s+([\w-]+)(?:\s*\((.+?)\))?',
            'current_date': r'CURRENT-DATE',
            'current_time': r'CURRENT-TIME',
            
            # Operações de busca e ordenação
            'search_statement': r'SEARCH\s+(ALL\s+)?([\w-]+)',
            'sort_statement': r'SORT\s+([\w-]+)\s+ON\s+(ASCENDING|DESCENDING)\s+KEY\s+([\w-]+)',
            'merge_statement': r'MERGE\s+([\w-]+)\s+ON\s+(ASCENDING|DESCENDING)\s+KEY\s+([\w-]+)'
        }
    
    def analyze_program(self, cobol_code: str, program_name: str = None) -> TechnicalAnalysisResult:
        """
        Realiza análise técnica completa do programa COBOL.
        
        Args:
            cobol_code: Código fonte COBOL
            program_name: Nome do programa (opcional)
            
        Returns:
            Resultado da análise técnica estruturada
        """
        try:
            # Normalizar código para análise
            normalized_code = self._normalize_code(cobol_code)
            
            # Extrair informações básicas
            program_id = self._extract_program_id(normalized_code) or program_name or "UNKNOWN"
            
            # Realizar análises específicas
            technical_metrics = self._analyze_technical_metrics(normalized_code)
            code_structures = self._analyze_code_structures(normalized_code)
            dependencies = self._analyze_dependencies(normalized_code)
            business_rules = self._extract_business_rules(normalized_code)
            performance_analysis = self._analyze_performance(normalized_code)
            quality_metrics = self._calculate_quality_metrics(normalized_code)
            recommendations = self._generate_technical_recommendations(
                technical_metrics, code_structures, performance_analysis, quality_metrics
            )
            
            # Criar resultado estruturado
            result = TechnicalAnalysisResult(
                program_id=program_id,
                analysis_type="technical_comprehensive",
                technical_metrics=technical_metrics,
                code_structures=code_structures,
                dependencies=dependencies,
                business_rules=business_rules,
                performance_analysis=performance_analysis,
                quality_metrics=quality_metrics,
                recommendations=recommendations,
                analysis_timestamp=datetime.now()
            )
            
            self.logger.info(f"Análise técnica concluída para programa: {program_id}")
            return result
            
        except Exception as e:
            self.logger.error(f"Erro na análise técnica: {e}")
            raise
    
    def _normalize_code(self, code: str) -> str:
        """Normaliza código COBOL para análise consistente"""
        # Remover comentários de linha
        lines = []
        for line in code.split('\n'):
            # Manter apenas linhas que não são comentários
            if len(line) > 6 and line[6] not in ['*', '/']:
                lines.append(line)
        
        return '\n'.join(lines)
    
    def _extract_program_id(self, code: str) -> Optional[str]:
        """Extrai PROGRAM-ID do código"""
        match = re.search(self.cobol_patterns['program_id'], code, re.IGNORECASE)
        return match.group(1) if match else None
    
    def _analyze_technical_metrics(self, code: str) -> Dict[str, Any]:
        """Analisa métricas técnicas básicas do programa"""
        lines = code.split('\n')
        effective_lines = [line for line in lines if line.strip() and not line.strip().startswith('*')]
        
        # Contar divisões
        divisions = {
            'identification': len(re.findall(self.cobol_patterns['identification_division'], code, re.IGNORECASE)),
            'environment': len(re.findall(self.cobol_patterns['environment_division'], code, re.IGNORECASE)),
            'data': len(re.findall(self.cobol_patterns['data_division'], code, re.IGNORECASE)),
            'procedure': len(re.findall(self.cobol_patterns['procedure_division'], code, re.IGNORECASE))
        }
        
        # Contar seções
        sections = {
            'working_storage': len(re.findall(self.cobol_patterns['working_storage'], code, re.IGNORECASE)),
            'file_section': len(re.findall(self.cobol_patterns['file_section'], code, re.IGNORECASE)),
            'input_output': len(re.findall(self.cobol_patterns['input_output'], code, re.IGNORECASE))
        }
        
        # Contar parágrafos
        paragraphs = re.findall(self.cobol_patterns['paragraph'], code, re.MULTILINE | re.IGNORECASE)
        
        return {
            'total_lines': len(lines),
            'effective_lines': len(effective_lines),
            'comment_lines': len(lines) - len(effective_lines),
            'divisions_found': divisions,
            'sections_found': sections,
            'paragraph_count': len(paragraphs),
            'paragraph_names': paragraphs[:20]  # Primeiros 20 parágrafos
        }
    
    def _analyze_code_structures(self, code: str) -> Dict[str, Any]:
        """Analisa estruturas de código COBOL"""
        
        # Estruturas de dados
        data_structures = {
            'fd_definitions': re.findall(self.cobol_patterns['fd_definition'], code, re.IGNORECASE),
            'level_01_items': re.findall(self.cobol_patterns['level_01'], code, re.MULTILINE | re.IGNORECASE),
            'level_77_items': re.findall(self.cobol_patterns['level_77'], code, re.MULTILINE | re.IGNORECASE),
            'level_88_items': re.findall(self.cobol_patterns['level_88'], code, re.MULTILINE | re.IGNORECASE),
            'occurs_clauses': re.findall(self.cobol_patterns['occurs_clause'], code, re.IGNORECASE)
        }
        
        # Estruturas de controle
        control_structures = {
            'perform_statements': len(re.findall(self.cobol_patterns['perform_statement'], code, re.IGNORECASE)),
            'perform_until': len(re.findall(self.cobol_patterns['perform_until'], code, re.IGNORECASE)),
            'perform_varying': len(re.findall(self.cobol_patterns['perform_varying'], code, re.IGNORECASE)),
            'if_statements': len(re.findall(self.cobol_patterns['if_statement'], code, re.IGNORECASE)),
            'evaluate_statements': len(re.findall(self.cobol_patterns['evaluate_statement'], code, re.IGNORECASE)),
            'when_clauses': len(re.findall(self.cobol_patterns['when_clause'], code, re.IGNORECASE)),
            'go_to_statements': len(re.findall(self.cobol_patterns['go_to'], code, re.IGNORECASE))
        }
        
        # Operações de arquivo
        file_operations = {
            'open_statements': re.findall(self.cobol_patterns['open_statement'], code, re.IGNORECASE),
            'close_statements': re.findall(self.cobol_patterns['close_statement'], code, re.IGNORECASE),
            'read_statements': len(re.findall(self.cobol_patterns['read_statement'], code, re.IGNORECASE)),
            'write_statements': len(re.findall(self.cobol_patterns['write_statement'], code, re.IGNORECASE)),
            'rewrite_statements': len(re.findall(self.cobol_patterns['rewrite_statement'], code, re.IGNORECASE)),
            'delete_statements': len(re.findall(self.cobol_patterns['delete_statement'], code, re.IGNORECASE))
        }
        
        return {
            'data_structures': data_structures,
            'control_structures': control_structures,
            'file_operations': file_operations
        }
    
    def _analyze_dependencies(self, code: str) -> Dict[str, Any]:
        """Analisa dependências do programa (COPY e ++INCLUDE)"""
        
        # Extrair COPY statements
        copy_matches = re.findall(self.cobol_patterns['copy_statement'], code, re.IGNORECASE | re.MULTILINE)
        copy_statements = []
        for match in copy_matches:
            copy_name = match[0] if isinstance(match, tuple) else match
            replacing_clause = match[1] if isinstance(match, tuple) and len(match) > 1 and match[1] else None
            copy_statements.append({
                'name': copy_name,
                'type': 'COPY',
                'replacing_clause': replacing_clause
            })
        
        # Extrair ++INCLUDE statements
        include_matches = re.findall(self.cobol_patterns['include_statement'], code, re.IGNORECASE)
        include_statements = []
        for include_name in include_matches:
            include_statements.append({
                'name': include_name,
                'type': '++INCLUDE',
                'replacing_clause': None
            })
        
        # Analisar arquivos definidos
        select_matches = re.findall(self.cobol_patterns['select_statement'], code, re.IGNORECASE)
        file_definitions = []
        for match in select_matches:
            logical_name = match[0]
            physical_name = match[1] if len(match) > 1 else None
            
            # Buscar organização e modo de acesso para este arquivo
            file_context = self._extract_file_context(code, logical_name)
            
            file_definitions.append({
                'logical_name': logical_name,
                'physical_name': physical_name,
                'organization': file_context.get('organization'),
                'access_mode': file_context.get('access_mode'),
                'record_key': file_context.get('record_key'),
                'alternate_keys': file_context.get('alternate_keys', []),
                'file_status': file_context.get('file_status')
            })
        
        return {
            'copy_statements': copy_statements,
            'include_statements': include_statements,
            'total_dependencies': len(copy_statements) + len(include_statements),
            'dependency_summary': {
                'copy_count': len(copy_statements),
                'include_count': len(include_statements)
            },
            'file_definitions': file_definitions,
            'total_files': len(file_definitions)
        }
    
    def _extract_file_context(self, code: str, file_name: str) -> Dict[str, Any]:
        """Extrai contexto específico de um arquivo"""
        context = {}
        
        # Buscar organização
        org_pattern = rf'SELECT\s+{re.escape(file_name)}.*?ORGANIZATION\s+IS\s+(\w+)'
        org_match = re.search(org_pattern, code, re.IGNORECASE | re.DOTALL)
        if org_match:
            context['organization'] = org_match.group(1)
        
        # Buscar modo de acesso
        access_pattern = rf'SELECT\s+{re.escape(file_name)}.*?ACCESS\s+MODE\s+IS\s+(\w+)'
        access_match = re.search(access_pattern, code, re.IGNORECASE | re.DOTALL)
        if access_match:
            context['access_mode'] = access_match.group(1)
        
        # Buscar chave de registro
        key_pattern = rf'SELECT\s+{re.escape(file_name)}.*?RECORD\s+KEY\s+IS\s+([\w-]+)'
        key_match = re.search(key_pattern, code, re.IGNORECASE | re.DOTALL)
        if key_match:
            context['record_key'] = key_match.group(1)
        
        # Buscar chaves alternativas
        alt_key_pattern = rf'SELECT\s+{re.escape(file_name)}.*?ALTERNATE\s+RECORD\s+KEY\s+IS\s+([\w-]+)'
        alt_keys = re.findall(alt_key_pattern, code, re.IGNORECASE | re.DOTALL)
        if alt_keys:
            context['alternate_keys'] = alt_keys
        
        # Buscar file status
        status_pattern = rf'SELECT\s+{re.escape(file_name)}.*?FILE\s+STATUS\s+IS\s+([\w-]+)'
        status_match = re.search(status_pattern, code, re.IGNORECASE | re.DOTALL)
        if status_match:
            context['file_status'] = status_match.group(1)
        
        return context
    
    def _extract_business_rules(self, code: str) -> List[Dict[str, Any]]:
        """Extrai regras de negócio implementadas no código"""
        business_rules = []
        rule_counter = 1
        
        # Analisar estruturas IF
        if_matches = re.finditer(r'IF\s+(.+?)(?:\s+THEN|\s+PERFORM|\s+MOVE|\s+GO\s+TO|\s+DISPLAY)', code, re.IGNORECASE | re.DOTALL)
        for match in if_matches:
            condition = match.group(1).strip()
            line_number = code[:match.start()].count('\n') + 1
            
            business_rules.append({
                'rule_id': f"RULE_{rule_counter:03d}",
                'type': 'conditional_validation',
                'condition': condition,
                'location': f"Line {line_number}",
                'construct': 'IF',
                'description': f"Validação condicional: {condition[:100]}..."
            })
            rule_counter += 1
        
        # Analisar estruturas EVALUATE/WHEN
        evaluate_matches = re.finditer(r'EVALUATE\s+(.+?)(?:\s+WHEN)', code, re.IGNORECASE | re.DOTALL)
        for match in evaluate_matches:
            evaluate_expr = match.group(1).strip()
            line_number = code[:match.start()].count('\n') + 1
            
            # Buscar WHEN clauses associadas
            when_pattern = rf'WHEN\s+(.+?)(?:\s+PERFORM|\s+MOVE|\s+GO\s+TO|\s+DISPLAY|\s+WHEN|\s+END-EVALUATE)'
            when_matches = re.findall(when_pattern, code[match.end():], re.IGNORECASE | re.DOTALL)
            
            for when_condition in when_matches[:5]:  # Limitar a 5 WHEN clauses
                business_rules.append({
                    'rule_id': f"RULE_{rule_counter:03d}",
                    'type': 'classification_rule',
                    'condition': f"{evaluate_expr} = {when_condition.strip()}",
                    'location': f"Line {line_number}",
                    'construct': 'EVALUATE/WHEN',
                    'description': f"Regra de classificação: {evaluate_expr} = {when_condition.strip()[:50]}..."
                })
                rule_counter += 1
        
        # Analisar validações numéricas
        numeric_matches = re.finditer(r'IF\s+(.+?)\s+(?:IS\s+)?NUMERIC', code, re.IGNORECASE)
        for match in numeric_matches:
            field_name = match.group(1).strip()
            line_number = code[:match.start()].count('\n') + 1
            
            business_rules.append({
                'rule_id': f"RULE_{rule_counter:03d}",
                'type': 'format_validation',
                'condition': f"{field_name} IS NUMERIC",
                'location': f"Line {line_number}",
                'construct': 'NUMERIC validation',
                'description': f"Validação de formato numérico para campo: {field_name}"
            })
            rule_counter += 1
        
        # Analisar validações de file status
        status_matches = re.finditer(r'IF\s+([\w-]+)\s*(?:NOT\s*)?=\s*[\'"]?(\d{2})[\'"]?', code, re.IGNORECASE)
        for match in status_matches:
            status_var = match.group(1)
            status_code = match.group(2)
            line_number = code[:match.start()].count('\n') + 1
            
            business_rules.append({
                'rule_id': f"RULE_{rule_counter:03d}",
                'type': 'file_status_control',
                'condition': f"{status_var} = '{status_code}'",
                'location': f"Line {line_number}",
                'construct': 'FILE STATUS validation',
                'description': f"Controle de status de arquivo: {status_var} = {status_code}"
            })
            rule_counter += 1
        
        return business_rules[:50]  # Limitar a 50 regras para evitar sobrecarga
    
    def _analyze_performance(self, code: str) -> Dict[str, Any]:
        """Analisa aspectos de performance do código"""
        
        # Contar operações custosas
        io_operations = {
            'read_operations': len(re.findall(self.cobol_patterns['read_statement'], code, re.IGNORECASE)),
            'write_operations': len(re.findall(self.cobol_patterns['write_statement'], code, re.IGNORECASE)),
            'rewrite_operations': len(re.findall(self.cobol_patterns['rewrite_statement'], code, re.IGNORECASE)),
            'delete_operations': len(re.findall(self.cobol_patterns['delete_statement'], code, re.IGNORECASE))
        }
        
        # Analisar loops
        loop_analysis = {
            'perform_until_loops': len(re.findall(self.cobol_patterns['perform_until'], code, re.IGNORECASE)),
            'perform_varying_loops': len(re.findall(self.cobol_patterns['perform_varying'], code, re.IGNORECASE)),
            'go_to_statements': len(re.findall(self.cobol_patterns['go_to'], code, re.IGNORECASE))
        }
        
        # Operações de busca e ordenação
        search_sort_operations = {
            'search_operations': len(re.findall(self.cobol_patterns['search_statement'], code, re.IGNORECASE)),
            'sort_operations': len(re.findall(self.cobol_patterns['sort_statement'], code, re.IGNORECASE)),
            'merge_operations': len(re.findall(self.cobol_patterns['merge_statement'], code, re.IGNORECASE))
        }
        
        # Operações de string
        string_operations = {
            'string_operations': len(re.findall(self.cobol_patterns['string_statement'], code, re.IGNORECASE)),
            'unstring_operations': len(re.findall(self.cobol_patterns['unstring_statement'], code, re.IGNORECASE)),
            'inspect_operations': len(re.findall(self.cobol_patterns['inspect_statement'], code, re.IGNORECASE))
        }
        
        # Calcular score de performance
        total_io = sum(io_operations.values())
        total_loops = sum(loop_analysis.values())
        total_search_sort = sum(search_sort_operations.values())
        total_string = sum(string_operations.values())
        
        performance_score = total_io + (total_loops * 2) + (total_search_sort * 3) + total_string
        
        if performance_score < 20:
            performance_level = 'optimized'
        elif performance_score < 50:
            performance_level = 'moderate'
        else:
            performance_level = 'resource_intensive'
        
        return {
            'io_operations': io_operations,
            'loop_analysis': loop_analysis,
            'search_sort_operations': search_sort_operations,
            'string_operations': string_operations,
            'performance_score': performance_score,
            'performance_level': performance_level,
            'total_operations': {
                'io_total': total_io,
                'loop_total': total_loops,
                'search_sort_total': total_search_sort,
                'string_total': total_string
            }
        }
    
    def _calculate_quality_metrics(self, code: str) -> Dict[str, Any]:
        """Calcula métricas de qualidade do código"""
        
        # Complexidade ciclomática
        decision_points = (
            len(re.findall(r'\bIF\b', code, re.IGNORECASE)) +
            len(re.findall(r'\bWHEN\b', code, re.IGNORECASE)) +
            len(re.findall(self.cobol_patterns['perform_until'], code, re.IGNORECASE)) +
            len(re.findall(r'GO\s+TO.*IF', code, re.IGNORECASE))
        )
        
        cyclomatic_complexity = decision_points + 1  # +1 para o caminho base
        
        if cyclomatic_complexity <= self.quality_thresholds['low_complexity']:
            complexity_level = 'low'
        elif cyclomatic_complexity <= self.quality_thresholds['medium_complexity']:
            complexity_level = 'medium'
        else:
            complexity_level = 'high'
        
        # Análise de nomenclatura
        naming_analysis = {
            'ws_variables': len(re.findall(r'\bws-[\w-]+', code, re.IGNORECASE)),
            'fd_variables': len(re.findall(r'\bfd-[\w-]+', code, re.IGNORECASE)),
            'consistent_naming': True  # Simplificado para esta versão
        }
        
        # Análise de modularização
        paragraphs = re.findall(self.cobol_patterns['paragraph'], code, re.MULTILINE | re.IGNORECASE)
        modularization = {
            'paragraph_count': len(paragraphs),
            'average_paragraph_size': len(code.split('\n')) / max(len(paragraphs), 1),
            'modularization_level': 'good' if len(paragraphs) > 5 else 'needs_improvement'
        }
        
        # Tratamento de erros
        error_handling = {
            'at_end_handlers': len(re.findall(self.cobol_patterns['at_end'], code, re.IGNORECASE)),
            'invalid_key_handlers': len(re.findall(self.cobol_patterns['invalid_key'], code, re.IGNORECASE)),
            'file_status_checks': len(re.findall(r'FILE\s+STATUS', code, re.IGNORECASE)),
            'error_handling_coverage': 'comprehensive' if len(re.findall(r'AT\s+END|INVALID\s+KEY', code, re.IGNORECASE)) > 3 else 'basic'
        }
        
        return {
            'cyclomatic_complexity': cyclomatic_complexity,
            'complexity_level': complexity_level,
            'decision_points': decision_points,
            'naming_analysis': naming_analysis,
            'modularization': modularization,
            'error_handling': error_handling,
            'quality_score': self._calculate_overall_quality_score(
                cyclomatic_complexity, naming_analysis, modularization, error_handling
            )
        }
    
    def _calculate_overall_quality_score(self, complexity: int, naming: Dict, modularization: Dict, error_handling: Dict) -> Dict[str, Any]:
        """Calcula score geral de qualidade"""
        
        # Score de complexidade (0-10, onde 10 é melhor)
        if complexity <= 10:
            complexity_score = 10
        elif complexity <= 20:
            complexity_score = 7
        else:
            complexity_score = 4
        
        # Score de nomenclatura (0-10)
        naming_score = 8 if naming['consistent_naming'] else 5
        
        # Score de modularização (0-10)
        if modularization['modularization_level'] == 'good':
            modularization_score = 8
        else:
            modularization_score = 5
        
        # Score de tratamento de erros (0-10)
        if error_handling['error_handling_coverage'] == 'comprehensive':
            error_score = 9
        else:
            error_score = 6
        
        # Score geral (média ponderada)
        overall_score = (complexity_score * 0.3 + naming_score * 0.2 + 
                        modularization_score * 0.3 + error_score * 0.2)
        
        if overall_score >= 8:
            quality_level = 'excellent'
        elif overall_score >= 6:
            quality_level = 'good'
        elif overall_score >= 4:
            quality_level = 'acceptable'
        else:
            quality_level = 'needs_improvement'
        
        return {
            'overall_score': round(overall_score, 2),
            'quality_level': quality_level,
            'component_scores': {
                'complexity': complexity_score,
                'naming': naming_score,
                'modularization': modularization_score,
                'error_handling': error_score
            }
        }
    
    def _generate_technical_recommendations(self, metrics: Dict, structures: Dict, 
                                         performance: Dict, quality: Dict) -> List[str]:
        """Gera recomendações técnicas baseadas na análise"""
        recommendations = []
        
        # Recomendações de complexidade
        if quality['complexity_level'] == 'high':
            recommendations.append(
                f"COMPLEXIDADE ALTA: Programa possui {quality['cyclomatic_complexity']} pontos de decisão. "
                "Considerar refatoração em módulos menores."
            )
        
        # Recomendações de performance
        if performance['performance_level'] == 'resource_intensive':
            recommendations.append(
                f"PERFORMANCE: {performance['performance_score']} operações custosas identificadas. "
                "Revisar algoritmos de I/O e loops."
            )
        
        # Recomendações de I/O
        total_io = performance['total_operations']['io_total']
        if total_io > 50:
            recommendations.append(
                f"I/O INTENSIVO: {total_io} operações de arquivo. "
                "Considerar buffering ou otimização de acesso."
            )
        
        # Recomendações de loops
        if performance['loop_analysis']['go_to_statements'] > 5:
            recommendations.append(
                f"ESTRUTURA: {performance['loop_analysis']['go_to_statements']} statements GO TO. "
                "Substituir por PERFORM para melhor estruturação."
            )
        
        # Recomendações de tratamento de erros
        if quality['error_handling']['error_handling_coverage'] == 'basic':
            recommendations.append(
                "TRATAMENTO DE ERROS: Implementar mais controles AT END e INVALID KEY "
                "para robustez do programa."
            )
        
        # Recomendações de modularização
        if quality['modularization']['modularization_level'] == 'needs_improvement':
            recommendations.append(
                f"MODULARIZAÇÃO: {quality['modularization']['paragraph_count']} parágrafos. "
                "Aumentar modularização para facilitar manutenção."
            )
        
        # Recomendações de dependências
        total_deps = structures.get('dependencies', {}).get('total_dependencies', 0)
        if total_deps > 10:
            recommendations.append(
                f"DEPENDÊNCIAS: {total_deps} copybooks/includes. "
                "Revisar necessidade de todas as dependências."
            )
        
        return recommendations[:10]  # Limitar a 10 recomendações
