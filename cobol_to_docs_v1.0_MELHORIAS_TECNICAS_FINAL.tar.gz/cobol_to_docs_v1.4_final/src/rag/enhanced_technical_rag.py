"""
Enhanced Technical RAG System - Sistema RAG Técnico Aprimorado
Foco em análise técnica precisa e objetiva de código COBOL
"""

import os
import json
import logging
import re
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
import numpy as np
from dataclasses import dataclass

@dataclass
class TechnicalKnowledgeItem:
    """Item de conhecimento técnico COBOL otimizado para análise precisa"""
    id: str
    title: str
    content: str
    category: str
    keywords: List[str]
    cobol_constructs: List[str]
    domain: str
    complexity_level: str
    technical_pattern: str  # Novo: padrão técnico específico
    code_examples: List[str] = None
    performance_impact: str = None
    maintenance_notes: str = None

class EnhancedTechnicalRAG:
    """
    Sistema RAG técnico aprimorado para análise objetiva de COBOL.
    Elimina linguagem humanizada e foca em aspectos técnicos mensuráveis.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o sistema RAG técnico aprimorado"""
        self.logger = logging.getLogger(__name__)
        self.config = config
        
        # Configurações técnicas
        self.technical_kb_path = config.get('rag', {}).get('technical_knowledge_base', 'data/cobol_knowledge_base_tecnico_cadoc.json')
        self.max_technical_items = config.get('rag', {}).get('max_technical_items', 8)
        self.technical_threshold = config.get('rag', {}).get('technical_threshold', 0.8)
        
        # Base de conhecimento técnico
        self.technical_knowledge: List[TechnicalKnowledgeItem] = []
        
        # Padrões técnicos específicos
        self.technical_patterns = {
            'dependency_analysis': self._analyze_dependencies,
            'file_organization': self._analyze_file_organization,
            'classification_algorithm': self._analyze_classification,
            'integrity_control': self._analyze_integrity,
            'loop_optimization': self._analyze_loops,
            'error_handling': self._analyze_error_handling,
            'index_optimization': self._analyze_indexes,
            'format_validation': self._analyze_validations,
            'audit_control': self._analyze_audit,
            'batch_processing': self._analyze_batch,
            'complexity_analysis': self._analyze_complexity,
            'naming_convention': self._analyze_naming
        }
        
        self._load_technical_knowledge()
        self.logger.info("Enhanced Technical RAG System inicializado")
    
    def _load_technical_knowledge(self):
        """Carrega base de conhecimento técnico especializada"""
        try:
            if os.path.exists(self.technical_kb_path):
                with open(self.technical_kb_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for item_data in data:
                        item = TechnicalKnowledgeItem(**item_data)
                        self.technical_knowledge.append(item)
                self.logger.info(f"Base técnica carregada: {len(self.technical_knowledge)} itens")
            else:
                self.logger.warning(f"Base técnica não encontrada: {self.technical_kb_path}")
        except Exception as e:
            self.logger.error(f"Erro ao carregar base técnica: {e}")
    
    def get_technical_context(self, cobol_code: str, analysis_type: str = "general") -> Dict[str, Any]:
        """
        Recupera contexto técnico relevante para análise de código COBOL.
        
        Args:
            cobol_code: Código COBOL a ser analisado
            analysis_type: Tipo de análise (general, dependencies, performance, etc.)
            
        Returns:
            Contexto técnico estruturado
        """
        try:
            # Extrair construtos COBOL do código
            constructs = self._extract_cobol_constructs(cobol_code)
            
            # Identificar padrões técnicos
            patterns = self._identify_technical_patterns(cobol_code)
            
            # Recuperar conhecimento relevante
            relevant_knowledge = self._retrieve_relevant_knowledge(constructs, patterns, analysis_type)
            
            # Gerar contexto técnico estruturado
            technical_context = {
                'constructs_found': constructs,
                'patterns_identified': patterns,
                'relevant_knowledge': relevant_knowledge,
                'technical_guidelines': self._get_technical_guidelines(analysis_type),
                'analysis_focus': self._get_analysis_focus(analysis_type)
            }
            
            return technical_context
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar contexto técnico: {e}")
            return {}
    
    def _extract_cobol_constructs(self, code: str) -> List[str]:
        """Extrai construtos COBOL específicos do código"""
        constructs = []
        
        # Padrões de construtos COBOL
        patterns = {
            'COPY': r'COPY\s+[\w-]+',
            'INCLUDE': r'\+\+INCLUDE\s+[\w-]+',
            'SELECT': r'SELECT\s+[\w-]+',
            'FD': r'FD\s+[\w-]+',
            'ORGANIZATION': r'ORGANIZATION\s+IS\s+\w+',
            'ACCESS': r'ACCESS\s+MODE\s+IS\s+\w+',
            'FILE STATUS': r'FILE\s+STATUS\s+IS\s+[\w-]+',
            'PERFORM': r'PERFORM\s+[\w-]+',
            'IF': r'IF\s+',
            'EVALUATE': r'EVALUATE\s+',
            'WHEN': r'WHEN\s+',
            'READ': r'READ\s+[\w-]+',
            'WRITE': r'WRITE\s+[\w-]+',
            'REWRITE': r'REWRITE\s+[\w-]+',
            'DELETE': r'DELETE\s+[\w-]+',
            'SEARCH': r'SEARCH\s+ALL\s+|SEARCH\s+',
            'SORT': r'SORT\s+[\w-]+',
            'MERGE': r'MERGE\s+[\w-]+'
        }
        
        for construct, pattern in patterns.items():
            matches = re.findall(pattern, code, re.IGNORECASE)
            if matches:
                constructs.append(construct)
        
        return constructs
    
    def _identify_technical_patterns(self, code: str) -> List[str]:
        """Identifica padrões técnicos específicos no código"""
        patterns = []
        
        # Análise de dependências
        if re.search(r'COPY\s+|^\s*\+\+INCLUDE', code, re.MULTILINE | re.IGNORECASE):
            patterns.append('dependency_analysis')
        
        # Organização de arquivos
        if re.search(r'ORGANIZATION\s+IS\s+INDEXED|ACCESS\s+MODE', code, re.IGNORECASE):
            patterns.append('file_organization')
        
        # Algoritmos de classificação
        if re.search(r'EVALUATE\s+.*WHEN.*WHEN', code, re.IGNORECASE | re.DOTALL):
            patterns.append('classification_algorithm')
        
        # Controles de integridade
        if re.search(r'FILE\s+STATUS|IF.*NOT\s*=\s*[\'"]00[\'"]', code, re.IGNORECASE):
            patterns.append('integrity_control')
        
        # Otimização de loops
        if re.search(r'PERFORM\s+UNTIL|PERFORM\s+VARYING', code, re.IGNORECASE):
            patterns.append('loop_optimization')
        
        # Tratamento de erros
        if re.search(r'AT\s+END|NOT\s+AT\s+END|INVALID\s+KEY', code, re.IGNORECASE):
            patterns.append('error_handling')
        
        # Otimização de índices
        if re.search(r'ALTERNATE\s+RECORD\s+KEY|START\s+.*KEY', code, re.IGNORECASE):
            patterns.append('index_optimization')
        
        # Validações de formato
        if re.search(r'IF.*NUMERIC|IF.*ALPHABETIC|INSPECT.*TALLYING', code, re.IGNORECASE):
            patterns.append('format_validation')
        
        # Controles de auditoria
        if re.search(r'CURRENT-DATE|CURRENT-TIME|USER-ID', code, re.IGNORECASE):
            patterns.append('audit_control')
        
        # Processamento batch
        if re.search(r'OCCURS.*TIMES|CHECKPOINT|RESTART', code, re.IGNORECASE):
            patterns.append('batch_processing')
        
        return patterns
    
    def _retrieve_relevant_knowledge(self, constructs: List[str], patterns: List[str], analysis_type: str) -> List[Dict]:
        """Recupera conhecimento técnico relevante"""
        relevant_items = []
        
        for item in self.technical_knowledge:
            relevance_score = 0
            
            # Pontuação por construtos COBOL
            for construct in constructs:
                if construct.upper() in [c.upper() for c in item.cobol_constructs]:
                    relevance_score += 2
            
            # Pontuação por padrões técnicos
            if item.technical_pattern in patterns:
                relevance_score += 3
            
            # Pontuação por tipo de análise
            if analysis_type in item.category.lower():
                relevance_score += 1
            
            # Pontuação por palavras-chave
            for keyword in item.keywords:
                if any(keyword.lower() in construct.lower() for construct in constructs):
                    relevance_score += 1
            
            if relevance_score >= 2:  # Threshold mínimo
                relevant_items.append({
                    'item': item,
                    'relevance_score': relevance_score
                })
        
        # Ordenar por relevância e retornar os mais relevantes
        relevant_items.sort(key=lambda x: x['relevance_score'], reverse=True)
        return relevant_items[:self.max_technical_items]
    
    def _get_technical_guidelines(self, analysis_type: str) -> List[str]:
        """Retorna diretrizes técnicas específicas para o tipo de análise"""
        guidelines = {
            'general': [
                "Documente apenas construtos efetivamente presentes no código",
                "Use terminologia técnica COBOL padrão",
                "Evite especulações ou interpretações subjetivas",
                "Foque em aspectos mensuráveis e verificáveis"
            ],
            'dependencies': [
                "Diferencie COPY de ++INCLUDE explicitamente",
                "Identifique localização exata de cada dependência",
                "Documente finalidade inferida de cada copybook",
                "Verifique consistência entre programas"
            ],
            'performance': [
                "Conte operações de I/O efetivamente realizadas",
                "Identifique loops aninhados e sua complexidade",
                "Avalie eficiência de algoritmos de acesso",
                "Documente gargalos potenciais identificados"
            ],
            'business_rules': [
                "Extraia apenas regras implementadas no código",
                "Referencie linhas específicas para cada regra",
                "Documente condições lógicas exatas",
                "Evite interpretações de negócio não evidentes"
            ]
        }
        
        return guidelines.get(analysis_type, guidelines['general'])
    
    def _get_analysis_focus(self, analysis_type: str) -> List[str]:
        """Retorna focos específicos para cada tipo de análise"""
        focus_areas = {
            'general': [
                "Estruturas de dados definidas",
                "Fluxo de execução implementado",
                "Operações de arquivo realizadas",
                "Controles de erro implementados"
            ],
            'dependencies': [
                "Copybooks utilizados (COPY vs ++INCLUDE)",
                "Estruturas de dados importadas",
                "Dependências entre módulos",
                "Impacto de mudanças em dependências"
            ],
            'performance': [
                "Complexidade ciclomática calculada",
                "Operações custosas identificadas",
                "Padrões de acesso a dados",
                "Oportunidades de otimização"
            ],
            'business_rules': [
                "Validações de entrada implementadas",
                "Regras de cálculo codificadas",
                "Controles de integridade aplicados",
                "Exceções e tratamentos especiais"
            ]
        }
        
        return focus_areas.get(analysis_type, focus_areas['general'])
    
    # Métodos de análise específicos por padrão técnico
    def _analyze_dependencies(self, code: str) -> Dict[str, Any]:
        """Análise específica de dependências"""
        copies = re.findall(r'COPY\s+([\w-]+)', code, re.IGNORECASE)
        includes = re.findall(r'\+\+INCLUDE\s+([\w-]+)', code, re.IGNORECASE)
        
        return {
            'copy_statements': copies,
            'include_statements': includes,
            'total_dependencies': len(copies) + len(includes),
            'dependency_types': {
                'COPY': len(copies),
                'INCLUDE': len(includes)
            }
        }
    
    def _analyze_file_organization(self, code: str) -> Dict[str, Any]:
        """Análise específica de organização de arquivos"""
        selects = re.findall(r'SELECT\s+([\w-]+).*?ASSIGN\s+TO\s+[\'"]?([^\s\'"]+)', code, re.IGNORECASE | re.DOTALL)
        organizations = re.findall(r'ORGANIZATION\s+IS\s+(\w+)', code, re.IGNORECASE)
        access_modes = re.findall(r'ACCESS\s+MODE\s+IS\s+(\w+)', code, re.IGNORECASE)
        
        return {
            'files_defined': len(selects),
            'file_details': selects,
            'organizations': organizations,
            'access_modes': access_modes
        }
    
    def _analyze_classification(self, code: str) -> Dict[str, Any]:
        """Análise específica de algoritmos de classificação"""
        evaluates = len(re.findall(r'EVALUATE\s+', code, re.IGNORECASE))
        whens = len(re.findall(r'WHEN\s+', code, re.IGNORECASE))
        
        return {
            'evaluate_statements': evaluates,
            'when_clauses': whens,
            'classification_complexity': 'high' if whens > 10 else 'medium' if whens > 5 else 'low'
        }
    
    def _analyze_integrity(self, code: str) -> Dict[str, Any]:
        """Análise específica de controles de integridade"""
        file_status_checks = len(re.findall(r'FILE\s+STATUS|IF.*[\'"]00[\'"]', code, re.IGNORECASE))
        validations = len(re.findall(r'IF.*NOT\s*=|IF.*INVALID', code, re.IGNORECASE))
        
        return {
            'file_status_checks': file_status_checks,
            'validation_points': validations,
            'integrity_level': 'high' if file_status_checks > 5 else 'medium' if file_status_checks > 2 else 'low'
        }
    
    def _analyze_loops(self, code: str) -> Dict[str, Any]:
        """Análise específica de otimização de loops"""
        perform_untils = len(re.findall(r'PERFORM\s+UNTIL', code, re.IGNORECASE))
        perform_varyings = len(re.findall(r'PERFORM\s+VARYING', code, re.IGNORECASE))
        go_tos = len(re.findall(r'GO\s+TO', code, re.IGNORECASE))
        
        return {
            'perform_until_loops': perform_untils,
            'perform_varying_loops': perform_varyings,
            'go_to_statements': go_tos,
            'loop_complexity': 'high' if go_tos > 5 else 'medium' if perform_untils > 3 else 'low'
        }
    
    def _analyze_error_handling(self, code: str) -> Dict[str, Any]:
        """Análise específica de tratamento de erros"""
        at_ends = len(re.findall(r'AT\s+END', code, re.IGNORECASE))
        not_at_ends = len(re.findall(r'NOT\s+AT\s+END', code, re.IGNORECASE))
        invalid_keys = len(re.findall(r'INVALID\s+KEY', code, re.IGNORECASE))
        
        return {
            'at_end_handlers': at_ends,
            'not_at_end_handlers': not_at_ends,
            'invalid_key_handlers': invalid_keys,
            'error_handling_coverage': 'good' if (at_ends + invalid_keys) > 3 else 'basic'
        }
    
    def _analyze_indexes(self, code: str) -> Dict[str, Any]:
        """Análise específica de otimização de índices"""
        alternate_keys = len(re.findall(r'ALTERNATE\s+RECORD\s+KEY', code, re.IGNORECASE))
        starts = len(re.findall(r'START\s+', code, re.IGNORECASE))
        
        return {
            'alternate_keys': alternate_keys,
            'start_operations': starts,
            'index_optimization': 'optimized' if alternate_keys > 0 else 'basic'
        }
    
    def _analyze_validations(self, code: str) -> Dict[str, Any]:
        """Análise específica de validações de formato"""
        numeric_checks = len(re.findall(r'IF.*NUMERIC', code, re.IGNORECASE))
        alphabetic_checks = len(re.findall(r'IF.*ALPHABETIC', code, re.IGNORECASE))
        inspects = len(re.findall(r'INSPECT.*TALLYING', code, re.IGNORECASE))
        
        return {
            'numeric_validations': numeric_checks,
            'alphabetic_validations': alphabetic_checks,
            'inspect_operations': inspects,
            'validation_coverage': 'comprehensive' if (numeric_checks + alphabetic_checks) > 5 else 'basic'
        }
    
    def _analyze_audit(self, code: str) -> Dict[str, Any]:
        """Análise específica de controles de auditoria"""
        current_dates = len(re.findall(r'CURRENT-DATE', code, re.IGNORECASE))
        current_times = len(re.findall(r'CURRENT-TIME', code, re.IGNORECASE))
        user_ids = len(re.findall(r'USER-ID', code, re.IGNORECASE))
        
        return {
            'date_stamps': current_dates,
            'time_stamps': current_times,
            'user_tracking': user_ids,
            'audit_level': 'comprehensive' if (current_dates + user_ids) > 2 else 'basic'
        }
    
    def _analyze_batch(self, code: str) -> Dict[str, Any]:
        """Análise específica de processamento batch"""
        occurs = len(re.findall(r'OCCURS\s+\d+\s+TIMES', code, re.IGNORECASE))
        checkpoints = len(re.findall(r'CHECKPOINT', code, re.IGNORECASE))
        restarts = len(re.findall(r'RESTART', code, re.IGNORECASE))
        
        return {
            'array_structures': occurs,
            'checkpoint_controls': checkpoints,
            'restart_capabilities': restarts,
            'batch_optimization': 'optimized' if occurs > 0 else 'basic'
        }
    
    def _analyze_complexity(self, code: str) -> Dict[str, Any]:
        """Análise específica de complexidade ciclomática"""
        ifs = len(re.findall(r'\bIF\b', code, re.IGNORECASE))
        whens = len(re.findall(r'\bWHEN\b', code, re.IGNORECASE))
        perform_untils = len(re.findall(r'PERFORM\s+UNTIL', code, re.IGNORECASE))
        
        complexity_score = ifs + whens + perform_untils + 1  # +1 para o caminho base
        
        if complexity_score <= 10:
            complexity_level = 'low'
        elif complexity_score <= 20:
            complexity_level = 'medium'
        else:
            complexity_level = 'high'
        
        return {
            'decision_points': ifs + whens,
            'loop_points': perform_untils,
            'cyclomatic_complexity': complexity_score,
            'complexity_level': complexity_level
        }
    
    def _analyze_naming(self, code: str) -> Dict[str, Any]:
        """Análise específica de convenções de nomenclatura"""
        ws_vars = len(re.findall(r'\b(ws-[\w-]+)', code, re.IGNORECASE))
        fd_vars = len(re.findall(r'\b(fd-[\w-]+)', code, re.IGNORECASE))
        idx_vars = len(re.findall(r'\b(idx-[\w-]+)', code, re.IGNORECASE))
        
        return {
            'working_storage_vars': ws_vars,
            'file_description_vars': fd_vars,
            'index_vars': idx_vars,
            'naming_consistency': 'good' if (ws_vars + fd_vars) > 5 else 'needs_improvement'
        }
