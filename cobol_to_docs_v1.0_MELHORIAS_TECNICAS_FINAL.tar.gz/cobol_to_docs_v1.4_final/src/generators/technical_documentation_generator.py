"""
Technical Documentation Generator - Gerador de Documentação Técnica
Elimina linguagem humanizada e foca em aspectos técnicos mensuráveis
"""

import os
import json
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
from dataclasses import asdict

class TechnicalDocumentationGenerator:
    """
    Gerador de documentação técnica objetiva para análises COBOL.
    Elimina linguagem humanizada e foca em informações técnicas verificáveis.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """Inicializa o gerador de documentação técnica"""
        self.logger = logging.getLogger(__name__)
        self.config = config
        
        # Templates técnicos
        self.templates = self._initialize_technical_templates()
        
        self.logger.info("Technical Documentation Generator inicializado")
    
    def _initialize_technical_templates(self) -> Dict[str, str]:
        """Inicializa templates de documentação técnica"""
        return {
            'header': """# Análise Técnica: {program_id}

**Data da Análise:** {analysis_date}  
**Tipo de Análise:** {analysis_type}  
**Complexidade Identificada:** {complexity_level}  

---
""",
            
            'technical_metrics': """## 1. MÉTRICAS TÉCNICAS

| Métrica | Valor |
|---------|-------|
| **Linhas Efetivas** | {effective_lines} |
| **Linhas de Comentário** | {comment_lines} |
| **Total de Parágrafos** | {paragraph_count} |
| **Divisões Implementadas** | {divisions_count} |
| **Seções Implementadas** | {sections_count} |

### 1.1 Estrutura do Programa

**Divisões Encontradas:**
{divisions_detail}

**Seções Identificadas:**
{sections_detail}

""",
            
            'dependencies': """## 2. ANÁLISE DE DEPENDÊNCIAS

### 2.1 Copybooks e Includes

| Tipo | Quantidade | Detalhes |
|------|------------|----------|
| **COPY** | {copy_count} | {copy_details} |
| **++INCLUDE** | {include_count} | {include_details} |
| **Total** | {total_dependencies} | - |

{dependency_table}

### 2.2 Arquivos Definidos

{file_definitions_table}

""",
            
            'code_structures': """## 3. ESTRUTURAS DE CÓDIGO

### 3.1 Estruturas de Dados

| Estrutura | Quantidade |
|-----------|------------|
| **FD Definitions** | {fd_count} |
| **01 Level Items** | {level_01_count} |
| **77 Level Items** | {level_77_count} |
| **88 Level Items** | {level_88_count} |
| **OCCURS Clauses** | {occurs_count} |

### 3.2 Estruturas de Controle

| Construto | Quantidade |
|-----------|------------|
| **PERFORM** | {perform_count} |
| **PERFORM UNTIL** | {perform_until_count} |
| **PERFORM VARYING** | {perform_varying_count} |
| **IF** | {if_count} |
| **EVALUATE** | {evaluate_count} |
| **WHEN** | {when_count} |
| **GO TO** | {goto_count} |

### 3.3 Operações de Arquivo

| Operação | Quantidade |
|----------|------------|
| **READ** | {read_count} |
| **WRITE** | {write_count} |
| **REWRITE** | {rewrite_count} |
| **DELETE** | {delete_count} |

""",
            
            'business_rules': """## 4. REGRAS DE NEGÓCIO IMPLEMENTADAS

**Total de Regras Identificadas:** {total_rules}

{business_rules_table}

### 4.1 Distribuição por Tipo

| Tipo de Regra | Quantidade |
|---------------|------------|
| **Validações Condicionais** | {conditional_count} |
| **Regras de Classificação** | {classification_count} |
| **Validações de Formato** | {format_count} |
| **Controles de File Status** | {status_count} |

""",
            
            'performance_analysis': """## 5. ANÁLISE DE PERFORMANCE

### 5.1 Operações de I/O

| Tipo | Quantidade | Impacto |
|------|------------|---------|
| **READ** | {read_ops} | {read_impact} |
| **WRITE** | {write_ops} | {write_impact} |
| **REWRITE** | {rewrite_ops} | {rewrite_impact} |
| **DELETE** | {delete_ops} | {delete_impact} |

### 5.2 Análise de Loops

| Tipo | Quantidade | Complexidade |
|------|------------|--------------|
| **PERFORM UNTIL** | {until_loops} | {until_complexity} |
| **PERFORM VARYING** | {varying_loops} | {varying_complexity} |
| **GO TO** | {goto_loops} | {goto_complexity} |

### 5.3 Operações Custosas

| Operação | Quantidade |
|----------|------------|
| **SEARCH** | {search_ops} |
| **SORT** | {sort_ops} |
| **MERGE** | {merge_ops} |
| **STRING** | {string_ops} |
| **UNSTRING** | {unstring_ops} |
| **INSPECT** | {inspect_ops} |

**Score de Performance:** {performance_score} ({performance_level})

""",
            
            'quality_metrics': """## 6. MÉTRICAS DE QUALIDADE

### 6.1 Complexidade Ciclomática

| Métrica | Valor | Classificação |
|---------|-------|---------------|
| **Pontos de Decisão** | {decision_points} | - |
| **Complexidade Ciclomática** | {cyclomatic_complexity} | {complexity_level} |

### 6.2 Análise de Nomenclatura

| Aspecto | Valor |
|---------|-------|
| **Variáveis WS-** | {ws_variables} |
| **Variáveis FD-** | {fd_variables} |
| **Consistência** | {naming_consistency} |

### 6.3 Modularização

| Métrica | Valor |
|---------|-------|
| **Total de Parágrafos** | {paragraph_count} |
| **Tamanho Médio** | {avg_paragraph_size} linhas |
| **Nível de Modularização** | {modularization_level} |

### 6.4 Tratamento de Erros

| Controle | Quantidade |
|----------|------------|
| **AT END** | {at_end_handlers} |
| **INVALID KEY** | {invalid_key_handlers} |
| **FILE STATUS** | {file_status_checks} |
| **Cobertura** | {error_coverage} |

**Score Geral de Qualidade:** {quality_score}/10 ({quality_level})

""",
            
            'recommendations': """## 7. RECOMENDAÇÕES TÉCNICAS

{recommendations_list}

""",
            
            'technical_summary': """## 8. RESUMO TÉCNICO

### 8.1 Características Principais

- **Tipo de Programa:** {program_type}
- **Complexidade:** {complexity_level}
- **Performance:** {performance_level}
- **Qualidade:** {quality_level}
- **Manutenibilidade:** {maintainability_level}

### 8.2 Pontos Críticos Identificados

{critical_points}

### 8.3 Aspectos Técnicos Relevantes

{technical_aspects}

""",
            
            'footer': """---

**Análise Técnica Gerada:** {timestamp}  
**Metodologia:** Análise estática de código COBOL  
**Ferramentas:** Technical COBOL Analyzer v2.0  

*Esta análise técnica baseia-se exclusivamente em construtos identificados no código fonte.*
"""
        }
    
    def generate_technical_documentation(self, analysis_result, output_path: str = None) -> str:
        """
        Gera documentação técnica completa baseada no resultado da análise.
        
        Args:
            analysis_result: Resultado da análise técnica
            output_path: Caminho para salvar a documentação (opcional)
            
        Returns:
            Documentação técnica em formato Markdown
        """
        try:
            # Converter dataclass para dict se necessário
            if hasattr(analysis_result, '__dict__'):
                result_dict = asdict(analysis_result)
            else:
                result_dict = analysis_result
            
            # Gerar seções da documentação
            documentation_parts = []
            
            # Header
            documentation_parts.append(self._generate_header(result_dict))
            
            # Métricas técnicas
            documentation_parts.append(self._generate_technical_metrics(result_dict))
            
            # Análise de dependências
            documentation_parts.append(self._generate_dependencies_section(result_dict))
            
            # Estruturas de código
            documentation_parts.append(self._generate_code_structures_section(result_dict))
            
            # Regras de negócio
            documentation_parts.append(self._generate_business_rules_section(result_dict))
            
            # Análise de performance
            documentation_parts.append(self._generate_performance_section(result_dict))
            
            # Métricas de qualidade
            documentation_parts.append(self._generate_quality_section(result_dict))
            
            # Recomendações técnicas
            documentation_parts.append(self._generate_recommendations_section(result_dict))
            
            # Resumo técnico
            documentation_parts.append(self._generate_technical_summary(result_dict))
            
            # Footer
            documentation_parts.append(self._generate_footer(result_dict))
            
            # Combinar todas as partes
            full_documentation = '\n'.join(documentation_parts)
            
            # Salvar se caminho fornecido
            if output_path:
                self._save_documentation(full_documentation, output_path)
            
            self.logger.info(f"Documentação técnica gerada para: {result_dict.get('program_id', 'UNKNOWN')}")
            return full_documentation
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação técnica: {e}")
            raise
    
    def _generate_header(self, result: Dict[str, Any]) -> str:
        """Gera cabeçalho da documentação"""
        return self.templates['header'].format(
            program_id=result.get('program_id', 'UNKNOWN'),
            analysis_date=result.get('analysis_timestamp', datetime.now()).strftime('%d/%m/%Y %H:%M:%S'),
            analysis_type=result.get('analysis_type', 'technical_comprehensive'),
            complexity_level=result.get('quality_metrics', {}).get('complexity_level', 'unknown')
        )
    
    def _generate_technical_metrics(self, result: Dict[str, Any]) -> str:
        """Gera seção de métricas técnicas"""
        metrics = result.get('technical_metrics', {})
        
        # Processar divisões
        divisions = metrics.get('divisions_found', {})
        divisions_detail = '\n'.join([f"- {div.upper()}: {'✓' if count > 0 else '✗'}" 
                                    for div, count in divisions.items()])
        
        # Processar seções
        sections = metrics.get('sections_found', {})
        sections_detail = '\n'.join([f"- {sec.upper().replace('_', ' ')}: {'✓' if count > 0 else '✗'}" 
                                   for sec, count in sections.items()])
        
        return self.templates['technical_metrics'].format(
            effective_lines=metrics.get('effective_lines', 0),
            comment_lines=metrics.get('comment_lines', 0),
            paragraph_count=metrics.get('paragraph_count', 0),
            divisions_count=sum(divisions.values()) if divisions else 0,
            sections_count=sum(sections.values()) if sections else 0,
            divisions_detail=divisions_detail,
            sections_detail=sections_detail
        )
    
    def _generate_dependencies_section(self, result: Dict[str, Any]) -> str:
        """Gera seção de análise de dependências"""
        deps = result.get('dependencies', {})
        
        copy_statements = deps.get('copy_statements', [])
        include_statements = deps.get('include_statements', [])
        
        # Tabela de dependências
        dependency_rows = []
        for copy in copy_statements:
            replacing = copy.get('replacing_clause', '')
            replacing_text = f" (REPLACING: {replacing})" if replacing else ""
            dependency_rows.append(f"| COPY | {copy['name']}{replacing_text} |")
        
        for include in include_statements:
            dependency_rows.append(f"| ++INCLUDE | {include['name']} |")
        
        dependency_table = "| Tipo | Nome |\n|------|------|\n" + '\n'.join(dependency_rows) if dependency_rows else "Nenhuma dependência identificada."
        
        # Tabela de arquivos
        files = deps.get('file_definitions', [])
        file_rows = []
        for file_def in files:
            org = file_def.get('organization', 'N/A')
            access = file_def.get('access_mode', 'N/A')
            key = file_def.get('record_key', 'N/A')
            file_rows.append(f"| {file_def['logical_name']} | {file_def.get('physical_name', 'N/A')} | {org} | {access} | {key} |")
        
        file_definitions_table = ("| Nome Lógico | Nome Físico | Organização | Acesso | Chave |\n"
                                "|-------------|-------------|-------------|--------|-------|\n" + 
                                '\n'.join(file_rows)) if file_rows else "Nenhum arquivo definido."
        
        return self.templates['dependencies'].format(
            copy_count=len(copy_statements),
            include_count=len(include_statements),
            total_dependencies=deps.get('total_dependencies', 0),
            copy_details=', '.join([c['name'] for c in copy_statements]) if copy_statements else 'Nenhum',
            include_details=', '.join([i['name'] for i in include_statements]) if include_statements else 'Nenhum',
            dependency_table=dependency_table,
            file_definitions_table=file_definitions_table
        )
    
    def _generate_code_structures_section(self, result: Dict[str, Any]) -> str:
        """Gera seção de estruturas de código"""
        structures = result.get('code_structures', {})
        
        data_structs = structures.get('data_structures', {})
        control_structs = structures.get('control_structures', {})
        file_ops = structures.get('file_operations', {})
        
        # Garantir que todos os valores sejam números
        def safe_len(value):
            return len(value) if isinstance(value, list) else 0
        
        def safe_get(d, key, default=0):
            value = d.get(key, default)
            return value if isinstance(value, int) else default
        
        return self.templates['code_structures'].format(
            fd_count=safe_len(data_structs.get('fd_definitions', [])),
            level_01_count=safe_len(data_structs.get('level_01_items', [])),
            level_77_count=safe_len(data_structs.get('level_77_items', [])),
            level_88_count=safe_len(data_structs.get('level_88_items', [])),
            occurs_count=safe_len(data_structs.get('occurs_clauses', [])),
            perform_count=safe_get(control_structs, 'perform_statements', 0),
            perform_until_count=safe_get(control_structs, 'perform_until', 0),
            perform_varying_count=safe_get(control_structs, 'perform_varying', 0),
            if_count=safe_get(control_structs, 'if_statements', 0),
            evaluate_count=safe_get(control_structs, 'evaluate_statements', 0),
            when_count=safe_get(control_structs, 'when_clauses', 0),
            goto_count=safe_get(control_structs, 'go_to_statements', 0),
            read_count=safe_get(file_ops, 'read_statements', 0),
            write_count=safe_get(file_ops, 'write_statements', 0),
            rewrite_count=safe_get(file_ops, 'rewrite_statements', 0),
            delete_count=safe_get(file_ops, 'delete_statements', 0)
        )
    
    def _generate_business_rules_section(self, result: Dict[str, Any]) -> str:
        """Gera seção de regras de negócio"""
        rules = result.get('business_rules', [])
        
        # Contar por tipo
        type_counts = {}
        for rule in rules:
            rule_type = rule.get('type', 'unknown')
            type_counts[rule_type] = type_counts.get(rule_type, 0) + 1
        
        # Tabela de regras
        rule_rows = []
        for rule in rules[:20]:  # Limitar a 20 regras na documentação
            rule_rows.append(
                f"| {rule.get('rule_id', 'N/A')} | {rule.get('type', 'N/A')} | "
                f"{rule.get('construct', 'N/A')} | {rule.get('location', 'N/A')} | "
                f"{rule.get('condition', 'N/A')[:50]}... |"
            )
        
        business_rules_table = ("| ID | Tipo | Construto | Localização | Condição |\n"
                              "|----|----- |-----------|-------------|----------|\n" + 
                              '\n'.join(rule_rows)) if rule_rows else "Nenhuma regra identificada."
        
        return self.templates['business_rules'].format(
            total_rules=len(rules),
            business_rules_table=business_rules_table,
            conditional_count=type_counts.get('conditional_validation', 0),
            classification_count=type_counts.get('classification_rule', 0),
            format_count=type_counts.get('format_validation', 0),
            status_count=type_counts.get('file_status_control', 0)
        )
    
    def _generate_performance_section(self, result: Dict[str, Any]) -> str:
        """Gera seção de análise de performance"""
        perf = result.get('performance_analysis', {})
        
        io_ops = perf.get('io_operations', {})
        loop_analysis = perf.get('loop_analysis', {})
        search_sort = perf.get('search_sort_operations', {})
        string_ops = perf.get('string_operations', {})
        
        # Calcular impacto das operações
        def get_impact_level(count):
            if count == 0:
                return "Nenhum"
            elif count <= 5:
                return "Baixo"
            elif count <= 15:
                return "Médio"
            else:
                return "Alto"
        
        return self.templates['performance_analysis'].format(
            read_ops=io_ops.get('read_operations', 0),
            write_ops=io_ops.get('write_operations', 0),
            rewrite_ops=io_ops.get('rewrite_operations', 0),
            delete_ops=io_ops.get('delete_operations', 0),
            read_impact=get_impact_level(io_ops.get('read_operations', 0)),
            write_impact=get_impact_level(io_ops.get('write_operations', 0)),
            rewrite_impact=get_impact_level(io_ops.get('rewrite_operations', 0)),
            delete_impact=get_impact_level(io_ops.get('delete_operations', 0)),
            until_loops=loop_analysis.get('perform_until_loops', 0),
            varying_loops=loop_analysis.get('perform_varying_loops', 0),
            goto_loops=loop_analysis.get('go_to_statements', 0),
            until_complexity=get_impact_level(loop_analysis.get('perform_until_loops', 0)),
            varying_complexity=get_impact_level(loop_analysis.get('perform_varying_loops', 0)),
            goto_complexity=get_impact_level(loop_analysis.get('go_to_statements', 0)),
            search_ops=search_sort.get('search_operations', 0),
            sort_ops=search_sort.get('sort_operations', 0),
            merge_ops=search_sort.get('merge_operations', 0),
            string_ops=string_ops.get('string_operations', 0),
            unstring_ops=string_ops.get('unstring_operations', 0),
            inspect_ops=string_ops.get('inspect_operations', 0),
            performance_score=perf.get('performance_score', 0),
            performance_level=perf.get('performance_level', 'unknown').replace('_', ' ').title()
        )
    
    def _generate_quality_section(self, result: Dict[str, Any]) -> str:
        """Gera seção de métricas de qualidade"""
        quality = result.get('quality_metrics', {})
        
        naming = quality.get('naming_analysis', {})
        modularization = quality.get('modularization', {})
        error_handling = quality.get('error_handling', {})
        quality_score_data = quality.get('quality_score', {})
        
        return self.templates['quality_metrics'].format(
            decision_points=quality.get('decision_points', 0),
            cyclomatic_complexity=quality.get('cyclomatic_complexity', 0),
            complexity_level=quality.get('complexity_level', 'unknown').title(),
            ws_variables=naming.get('ws_variables', 0),
            fd_variables=naming.get('fd_variables', 0),
            naming_consistency="Boa" if naming.get('consistent_naming', False) else "Precisa Melhorar",
            paragraph_count=modularization.get('paragraph_count', 0),
            avg_paragraph_size=round(modularization.get('average_paragraph_size', 0), 1),
            modularization_level=modularization.get('modularization_level', 'unknown').replace('_', ' ').title(),
            at_end_handlers=error_handling.get('at_end_handlers', 0),
            invalid_key_handlers=error_handling.get('invalid_key_handlers', 0),
            file_status_checks=error_handling.get('file_status_checks', 0),
            error_coverage=error_handling.get('error_handling_coverage', 'unknown').title(),
            quality_score=quality_score_data.get('overall_score', 0),
            quality_level=quality_score_data.get('quality_level', 'unknown').replace('_', ' ').title()
        )
    
    def _generate_recommendations_section(self, result: Dict[str, Any]) -> str:
        """Gera seção de recomendações técnicas"""
        recommendations = result.get('recommendations', [])
        
        if not recommendations:
            recommendations_list = "Nenhuma recomendação específica identificada. Programa apresenta estrutura técnica adequada."
        else:
            recommendations_list = '\n'.join([f"### {i+1}. {rec}" for i, rec in enumerate(recommendations)])
        
        return self.templates['recommendations'].format(
            recommendations_list=recommendations_list
        )
    
    def _generate_technical_summary(self, result: Dict[str, Any]) -> str:
        """Gera resumo técnico"""
        
        # Determinar tipo de programa baseado nas estruturas
        structures = result.get('code_structures', {})
        file_ops = structures.get('file_operations', {})
        total_file_ops = sum(file_ops.values()) if file_ops else 0
        
        if total_file_ops > 20:
            program_type = "Processamento Intensivo de Dados"
        elif total_file_ops > 5:
            program_type = "Processamento de Arquivos"
        else:
            program_type = "Utilitário/Controle"
        
        # Pontos críticos
        critical_points = []
        quality = result.get('quality_metrics', {})
        performance = result.get('performance_analysis', {})
        
        if quality.get('complexity_level') == 'high':
            critical_points.append("- Complexidade ciclomática elevada")
        
        if performance.get('performance_level') == 'resource_intensive':
            critical_points.append("- Uso intensivo de recursos")
        
        if not critical_points:
            critical_points.append("- Nenhum ponto crítico identificado")
        
        # Aspectos técnicos relevantes
        technical_aspects = []
        deps = result.get('dependencies', {})
        
        if deps.get('total_dependencies', 0) > 5:
            technical_aspects.append(f"- {deps['total_dependencies']} dependências externas")
        
        if deps.get('total_files', 0) > 0:
            technical_aspects.append(f"- {deps['total_files']} arquivos definidos")
        
        rules_count = len(result.get('business_rules', []))
        if rules_count > 0:
            technical_aspects.append(f"- {rules_count} regras de negócio implementadas")
        
        if not technical_aspects:
            technical_aspects.append("- Estrutura técnica padrão")
        
        return self.templates['technical_summary'].format(
            program_type=program_type,
            complexity_level=quality.get('complexity_level', 'unknown').title(),
            performance_level=performance.get('performance_level', 'unknown').replace('_', ' ').title(),
            quality_level=quality.get('quality_score', {}).get('quality_level', 'unknown').replace('_', ' ').title(),
            maintainability_level=quality.get('modularization', {}).get('modularization_level', 'unknown').replace('_', ' ').title(),
            critical_points='\n'.join(critical_points),
            technical_aspects='\n'.join(technical_aspects)
        )
    
    def _generate_footer(self, result: Dict[str, Any]) -> str:
        """Gera rodapé da documentação"""
        return self.templates['footer'].format(
            timestamp=datetime.now().strftime('%d/%m/%Y às %H:%M:%S')
        )
    
    def _save_documentation(self, documentation: str, output_path: str):
        """Salva documentação em arquivo"""
        try:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(documentation)
            self.logger.info(f"Documentação salva em: {output_path}")
        except Exception as e:
            self.logger.error(f"Erro ao salvar documentação: {e}")
            raise
