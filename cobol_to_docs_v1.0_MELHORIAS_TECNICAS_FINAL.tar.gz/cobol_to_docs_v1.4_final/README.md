# COBOL to Docs v1.4

Sistema avançado de análise e documentação automatizada de programas COBOL com Inteligência Artificial, RAG (Retrieval Augmented Generation) e análise aprofundada por padrão.

## Visão Geral

O COBOL to Docs é uma ferramenta profissional que utiliza inteligência artificial para analisar código COBOL legado e gerar documentação técnica abrangente. O sistema incorpora tecnologia RAG (Retrieval Augmented Generation) com base de conhecimento especializada em padrões COBOL, sistemas bancários e engenharia reversa.

## Principais Funcionalidades

### Análise Inteligente de Código
- Análise automatizada de programas COBOL com IA
- Suporte a 14+ modelos LLM via LuzIA e providers alternativos
- Sistema RAG com 77+ itens de conhecimento especializado em CADOC
- Seleção inteligente automática de modelos baseada na complexidade
- Prompts adaptativos especializados por domínio

### Processamento Abrangente
- Análise de copybooks e dependências
- Processamento em lote de múltiplos programas
- Análise consolidada de sistemas completos
- Extração de regras de negócio implícitas

### Documentação Profissional
- Geração de documentação funcional detalhada
- Relatórios HTML e PDF
- Análise de impacto e dependências
- Documentação de interfaces e fluxos de dados

### Transparência e Auditoria
- Logging completo de todas as operações
- Relatórios de sessão RAG detalhados
- Cálculo preciso de custos baseado em entrada + saída
- Métricas de performance e comparação de modelos
- Rastreabilidade total do processo

## Instalação

### Instalação Automática (Recomendada)
```bash
# Extrair o pacote
tar -xzf cobol_to_docs_v1.0.tar.gz
cd cobol_to_docs_v1.0_final/

# Executar instalador automático
python3 install.py
```

### Instalação Manual
```bash
# Instalar dependências essenciais
pip install -r requirements-lite.txt

# Ou instalar dependências completas
pip install -r requirements.txt

# Configurar credenciais
cp .env.example .env
# Editar .env com suas credenciais
```

### Instalação via pip
```bash
# Instalação local
pip install ./cobol_to_docs_v1.0_final/

# Instalação em modo desenvolvimento
pip install -e ./cobol_to_docs_v1.0_final/
```

## Configuração

### Arquivo de Configuração
O sistema utiliza `config/config.yaml` para configurações principais:
- Providers de IA disponíveis
- Configurações do sistema RAG
- Parâmetros de análise
- Configurações de logging

### Variáveis de Ambiente
Configure suas credenciais no arquivo `.env`:
```bash
# LuzIA Configuration
LUZIA_CLIENT_ID=your_client_id_here
LUZIA_CLIENT_SECRET=your_client_secret_here

# OpenAI Configuration (opcional)
OPENAI_API_KEY=your_openai_api_key_here
```

## Uso

### Análise Básica
```bash
# Analisar programas COBOL
python3 main.py --fontes examples/fontes.txt --books examples/books.txt

# Seleção automática de modelo
python3 main.py --fontes examples/fontes.txt --auto-model

# Comparação de modelos
python3 main.py --fontes examples/fontes.txt --model-comparison

# Múltiplos modelos específicos
python3 main.py --fontes examples/fontes.txt --models '["aws-claude-3-5-sonnet", "amazon-nova-pro-v1"]'

# Análise consolidada do sistema
python3 main.py --fontes examples/fontes.txt --consolidado
```

### Comandos Disponíveis (após instalação pip)
```bash
cobol-to-docs --fontes examples/fontes.txt
cobol-docs --fontes examples/fontes.txt
cobol-analyze --fontes examples/fontes.txt
```

### Verificar Status
```bash
python3 main.py --status
```

## Sistema RAG

### Base de Conhecimento
O sistema inclui 77+ itens especializados de conhecimento:
- Estruturas e padrões COBOL avançados
- Sistemas CADOC e gestão documental
- Processamento de documentos bancários
- Compliance e regulamentação BACEN
- Workflows de aprovação e validação
- Auditoria e rastreabilidade
- Integração com sistemas core banking
- Técnicas de modernização e migração

### Funcionalidades RAG
- Enriquecimento automático de prompts
- Recuperação de conhecimento contextual especializado
- Identificação automática de domínios CADOC
- Prompts adaptativos por complexidade
- Aprendizado contínuo do sistema
- Otimização de tokens e custos

## Arquitetura

### Componentes Principais
- **Core**: Gerenciamento de configuração e prompts
- **Providers**: Integração com diferentes IAs
- **Analyzers**: Análise de código COBOL
- **RAG System**: Sistema de recuperação de conhecimento
- **Generators**: Geração de documentação

### Fluxo de Processamento
1. Carregamento de programas COBOL e copybooks
2. Enriquecimento de contexto via RAG
3. Análise com IA selecionada
4. Geração de documentação estruturada
5. Relatórios de auditoria e métricas

## Requisitos

### Sistema
- Python 3.8 ou superior
- Sistema operacional: Linux, Windows, macOS
- Memória: 4GB RAM (8GB recomendado)
- Espaço em disco: 500MB

### Dependências
- requests, pyyaml, jinja2 (essenciais)
- scikit-learn, numpy (RAG básico)
- sentence-transformers (RAG completo)
- openai (provider OpenAI)
- weasyprint (geração PDF)

## Estrutura do Projeto

```
cobol_to_docs_v1.1_final/
├── main.py                 # Script principal
├── install.py              # Instalador automático
├── setup.py                # Configuração pip
├── requirements.txt        # Dependências completas
├── requirements-lite.txt   # Dependências essenciais
├── config/
│   ├── config.yaml        # Configuração principal
│   └── prompts_cadoc_deep_analysis.yaml  # Prompts adaptativos
├── data/
│   └── cobol_knowledge_base_cadoc_expanded.json  # Base RAG expandida
├── src/
│   ├── core/              # Seleção inteligente e prompts adaptativos
│   ├── providers/         # Múltiplos providers LLM
│   ├── rag/               # Sistema RAG avançado
│   └── utils/             # Calculadora de custos
├── examples/              # Exemplos de uso
└── docs/                  # Documentação
```

## Exemplos

### Arquivo de Fontes (fontes.txt)
```
PROGRAMA: LHAN0542
IDENTIFICACAO: Sistema de Validação de Contas
CODIGO:
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LHAN0542.
       ...
```

### Arquivo de Copybooks (books.txt)
```
COPYBOOK: CONTA-LAYOUT
CODIGO:
       01  WS-CONTA-REGISTRO.
           05  WS-CONTA-NUMERO    PIC 9(10).
           05  WS-CONTA-DIGITO    PIC 9(01).
           ...
```

## Suporte e Documentação

### Documentação Adicional
- `docs/GUIA_COMPLETO_USO.md`: Guia detalhado de uso
- `docs/DOCUMENTACAO_TECNICA.md`: Documentação técnica
- `INSTALL.md`: Guia de instalação
- `CHANGELOG.md`: Histórico de versões

### Logs e Auditoria
- `logs/`: Logs de execução
- Relatórios RAG automáticos
- Métricas de performance
- Arquivos de auditoria JSON

## Licença

Este projeto está licenciado sob a Licença MIT - veja o arquivo LICENSE para detalhes.

## Autor

**Carlos Morais**  
Especialista em Sistemas Legados e Modernização COBOL

---

**COBOL to Docs v1.1** - Análise avançada de código COBOL com IA especializada
