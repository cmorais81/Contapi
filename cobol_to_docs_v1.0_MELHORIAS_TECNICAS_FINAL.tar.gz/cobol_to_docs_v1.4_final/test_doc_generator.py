#!/usr/bin/env python3
"""
Teste do Gerador de Documentação Técnica
"""

import os
import sys
import json
import logging
from datetime import datetime
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from analyzers.technical_cobol_analyzer import TechnicalCobolAnalyzer

class FixedTechnicalDocumentationGenerator:
    """Gerador de documentação técnica corrigido"""
    
    def __init__(self, config):
        self.logger = logging.getLogger(__name__)
        self.config = config
    
    def generate_technical_documentation(self, analysis_result, output_path=None):
        """Gera documentação técnica simples"""
        try:
            # Converter dataclass para dict
            if hasattr(analysis_result, '__dict__'):
                result = {
                    'program_id': analysis_result.program_id,
                    'analysis_type': analysis_result.analysis_type,
                    'technical_metrics': analysis_result.technical_metrics,
                    'code_structures': analysis_result.code_structures,
                    'dependencies': analysis_result.dependencies,
                    'business_rules': analysis_result.business_rules,
                    'performance_analysis': analysis_result.performance_analysis,
                    'quality_metrics': analysis_result.quality_metrics,
                    'recommendations': analysis_result.recommendations,
                    'analysis_timestamp': analysis_result.analysis_timestamp
                }
            else:
                result = analysis_result
            
            # Gerar documentação
            doc = self._generate_documentation(result)
            
            # Salvar se caminho fornecido
            if output_path:
                os.makedirs(os.path.dirname(output_path), exist_ok=True)
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(doc)
                self.logger.info(f"Documentação salva: {output_path}")
            
            return doc
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar documentação: {e}")
            raise
    
    def _generate_documentation(self, result):
        """Gera documentação técnica"""
        
        doc = f"""# Análise Técnica: {result['program_id']}

**Data da Análise:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}  
**Tipo de Análise:** {result['analysis_type']}  
**Complexidade:** {result['quality_metrics']['complexity_level']}  

---

## 1. MÉTRICAS TÉCNICAS

| Métrica | Valor |
|---------|-------|
| **Linhas Efetivas** | {result['technical_metrics']['effective_lines']} |
| **Linhas de Comentário** | {result['technical_metrics']['comment_lines']} |
| **Total de Parágrafos** | {result['technical_metrics']['paragraph_count']} |

## 2. ANÁLISE DE DEPENDÊNCIAS

### 2.1 Copybooks e Includes

| Tipo | Quantidade |
|------|------------|
| **COPY** | {len(result['dependencies']['copy_statements'])} |
| **++INCLUDE** | {len(result['dependencies']['include_statements'])} |
| **Total** | {result['dependencies']['total_dependencies']} |

### 2.2 Dependências Identificadas

"""
        
        # Listar dependências
        for copy in result['dependencies']['copy_statements']:
            doc += f"- **COPY:** {copy['name']}\\n"
        
        for include in result['dependencies']['include_statements']:
            doc += f"- **++INCLUDE:** {include['name']}\\n"
        
        doc += f"""

### 2.3 Arquivos Definidos

| Nome Lógico | Organização | Acesso | Chave |
|-------------|-------------|--------|-------|
"""
        
        for file_def in result['dependencies']['file_definitions']:
            doc += f"| {file_def['logical_name']} | {file_def.get('organization', 'N/A')} | {file_def.get('access_mode', 'N/A')} | {file_def.get('record_key', 'N/A')} |\\n"
        
        doc += f"""

## 3. ESTRUTURAS DE CÓDIGO

### 3.1 Estruturas de Dados

| Estrutura | Quantidade |
|-----------|------------|
| **FD Definitions** | {len(result['code_structures']['data_structures']['fd_definitions'])} |
| **01 Level Items** | {len(result['code_structures']['data_structures']['level_01_items'])} |
| **77 Level Items** | {len(result['code_structures']['data_structures']['level_77_items'])} |
| **88 Level Items** | {len(result['code_structures']['data_structures']['level_88_items'])} |

### 3.2 Estruturas de Controle

| Construto | Quantidade |
|-----------|------------|
| **PERFORM** | {result['code_structures']['control_structures']['perform_statements']} |
| **PERFORM UNTIL** | {result['code_structures']['control_structures']['perform_until']} |
| **IF** | {result['code_structures']['control_structures']['if_statements']} |
| **EVALUATE** | {result['code_structures']['control_structures']['evaluate_statements']} |
| **WHEN** | {result['code_structures']['control_structures']['when_clauses']} |
| **GO TO** | {result['code_structures']['control_structures']['go_to_statements']} |

## 4. REGRAS DE NEGÓCIO IMPLEMENTADAS

**Total de Regras Identificadas:** {len(result['business_rules'])}

"""
        
        # Listar primeiras 10 regras
        for rule in result['business_rules'][:10]:
            doc += f"- **{rule['rule_id']}:** {rule['type']} - {rule['description'][:100]}...\\n"
        
        doc += f"""

## 5. ANÁLISE DE PERFORMANCE

### 5.1 Operações de I/O

| Tipo | Quantidade |
|------|------------|
| **READ** | {result['performance_analysis']['io_operations']['read_operations']} |
| **WRITE** | {result['performance_analysis']['io_operations']['write_operations']} |
| **REWRITE** | {result['performance_analysis']['io_operations']['rewrite_operations']} |
| **DELETE** | {result['performance_analysis']['io_operations']['delete_operations']} |

**Score de Performance:** {result['performance_analysis']['performance_score']} ({result['performance_analysis']['performance_level']})

## 6. MÉTRICAS DE QUALIDADE

### 6.1 Complexidade Ciclomática

| Métrica | Valor |
|---------|-------|
| **Pontos de Decisão** | {result['quality_metrics']['decision_points']} |
| **Complexidade Ciclomática** | {result['quality_metrics']['cyclomatic_complexity']} |
| **Nível** | {result['quality_metrics']['complexity_level']} |

**Score Geral de Qualidade:** {result['quality_metrics']['quality_score']['overall_score']}/10 ({result['quality_metrics']['quality_score']['quality_level']})

## 7. RECOMENDAÇÕES TÉCNICAS

"""
        
        for i, rec in enumerate(result['recommendations'], 1):
            doc += f"{i}. {rec}\\n\\n"
        
        doc += f"""

## 8. RESUMO TÉCNICO

### 8.1 Características Principais

- **Complexidade:** {result['quality_metrics']['complexity_level']}
- **Performance:** {result['performance_analysis']['performance_level']}
- **Qualidade:** {result['quality_metrics']['quality_score']['quality_level']}
- **Modularização:** {result['quality_metrics']['modularization']['modularization_level']}

### 8.2 Melhorias Implementadas

✓ **Análise objetiva de dependências:** COPY vs ++INCLUDE diferenciados  
✓ **Métricas técnicas precisas:** Complexidade ciclomática calculada  
✓ **Extração de regras de negócio:** {len(result['business_rules'])} regras identificadas  
✓ **Análise de performance:** Score {result['performance_analysis']['performance_score']} calculado  
✓ **Eliminação de linguagem humanizada:** Terminologia técnica aplicada  

---

**Análise Técnica Gerada:** {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}  
**Sistema:** COBOL to Docs v1.0 - Versão Técnica Aprimorada  
"""
        
        return doc

def test_documentation_generator():
    """Testa o gerador de documentação corrigido"""
    
    # Configurar logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    try:
        # Configuração
        config = {'technical_analysis': {'focus_mode': 'technical_precision'}}
        
        # Inicializar componentes
        analyzer = TechnicalCobolAnalyzer(config)
        doc_generator = FixedTechnicalDocumentationGenerator(config)
        
        # Ler código COBOL
        with open('test_program.cbl', 'r', encoding='utf-8', errors='ignore') as f:
            cobol_code = f.read()
        
        # Realizar análise
        analysis_result = analyzer.analyze_program(cobol_code, "LHAN0546")
        
        # Gerar documentação
        output_dir = "teste_tecnico_melhorado"
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, "LHAN0546_analise_tecnica.md")
        
        documentation = doc_generator.generate_technical_documentation(analysis_result, output_path)
        
        print(f"\\n✓ Teste concluído com sucesso!")
        print(f"✓ Documentação gerada: {output_path}")
        print(f"✓ Tamanho da documentação: {len(documentation)} caracteres")
        
        # Mostrar algumas métricas
        print(f"\\nMétricas Técnicas:")
        print(f"- Linhas efetivas: {analysis_result.technical_metrics['effective_lines']}")
        print(f"- Complexidade ciclomática: {analysis_result.quality_metrics['cyclomatic_complexity']}")
        print(f"- Regras de negócio: {len(analysis_result.business_rules)}")
        print(f"- Dependências: {analysis_result.dependencies['total_dependencies']}")
        print(f"- Score de qualidade: {analysis_result.quality_metrics['quality_score']['overall_score']}/10")
        
        return True
        
    except Exception as e:
        logger.error(f"Erro no teste: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_documentation_generator()
    sys.exit(0 if success else 1)
