# Relatório de Análise Detalhada de Regras de Negócio

**Data:** 29/09/2025 16:15:07
**Programas Analisados:** 1
**Modelos Utilizados:** enhanced_mock

## Resumo da Análise Prévia

### Cálculos Financeiros Identificados: 0

### Regras de Negócio Identificadas: 2

- **Regra: Status Cliente**
  - Localização: Linha 252
  - Descrição: Controle baseado no status do cliente
  - Condições: 1

- **Regra: Tipo Conta**
  - Localização: Linha 299
  - Descrição: Validação baseada no tipo de conta
  - Condições: 0

### Validações de Dados Identificadas: 1

- **numeric**
  - Campo: IF
  - Localização: Linha 147

### Constantes Identificadas: 0


### Tabelas Identificadas: 1

- **01**: Tamanho 10

## Observações

Esta análise prévia identifica elementos estruturais do código COBOL.
Para detalhes específicos de valores, fórmulas e regras, consulte os relatórios
gerados pelos modelos de IA que contêm a análise detalhada completa.
