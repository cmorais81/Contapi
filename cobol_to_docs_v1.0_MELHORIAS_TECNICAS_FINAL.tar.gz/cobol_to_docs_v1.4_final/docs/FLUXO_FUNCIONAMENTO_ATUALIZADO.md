# Fluxo de Funcionamento - COBOL to Docs v1.4

## Visão Geral do Sistema

O COBOL to Docs v1.4 é um sistema avançado que combina análise de código COBOL, inteligência artificial e sistema RAG para gerar documentação técnica especializada.

## Fluxograma Principal

```mermaid
graph TD
    Z[Inicialização do Sistema] --> ZA[Verificação da Base RAG]
    ZA --> ZB[Carregamento da Base de Conhecimento]
    ZB --> A
    
    A[Entrada: Arquivo COBOL] --> B{Análise Aprofundada?}
    B -->|Sim - Padrão v1.4| C[Modo Deep Analysis]
    B -->|Não - --basic-analysis| D[Modo Basic Analysis]
    
    C --> E[Parse do Código COBOL]
    D --> E
    
    E --> F[Extração de Estruturas]
    F --> G[Identificação de Divisões]
    G --> H[Mapeamento de Variáveis]
    H --> I[Análise de Fluxo]
    
    I --> J{RAG Habilitado?}
    J -->|Sim| K[Sistema RAG]
    J -->|Não| M[Seleção de Modelo]
    
    K --> L[Base de Conhecimento CADOC]
    L --> N[Enriquecimento de Contexto]
    N --> M
    
    M --> O{Seleção Automática?}
    O -->|Sim| P[Análise de Complexidade]
    O -->|Não| Q[Modelo Especificado]
    
    P --> R[Recomendação de Modelo]
    R --> S[Modelo Selecionado]
    Q --> S
    
    S --> T[Geração de Prompt]
    T --> U{Múltiplos Modelos?}
    U -->|Sim| V[Processamento Paralelo]
    U -->|Não| W[Processamento Único]
    
    V --> X[Modelo 1: Claude Sonnet]
    V --> Y[Modelo 2: Nova Pro]
    V --> Z1[Modelo 3: GPT-4]
    
    X --> AA[Análise IA 1]
    Y --> BB[Análise IA 2]
    Z1 --> CC[Análise IA 3]
    
    W --> DD[Análise IA Única]
    
    AA --> EE[Extração de Regras]
    BB --> EE
    CC --> EE
    DD --> EE
    
    EE --> FF[Identificação de Valores]
    FF --> GG[Mapeamento de Fórmulas]
    GG --> HH[Análise de Condições]
    
    HH --> II{Análise Avançada?}
    II -->|Sim| JJ[Geração HTML]
    II -->|Não| KK[Geração Markdown]
    
    JJ --> LL[Relatório Consolidado]
    KK --> MM[Documentação Individual]
    
    LL --> NN[Cálculo de Custos]
    MM --> NN
    
    NN --> OO[Relatório de Auditoria]
    OO --> PP[Finalização RAG]
    PP --> QQ[Auto-Aprendizado RAG]
    QQ --> RR[Salvamento de Conhecimento]
    RR --> SS[Entrega Final]
```

## Verificação da Base RAG

```mermaid
graph TD
    A[Inicialização do Sistema] --> B[Execução ensure_rag_base.py]
    B --> C{Diretório data/ existe?}
    C -->|Não| D[Criar diretório data/]
    C -->|Sim| E[Verificar arquivos]
    D --> E
    
    E --> F{Base expandida existe?}
    F -->|Não| G[Verificar base básica]
    F -->|Sim| H[Carregar base expandida]
    
    G --> I{Base básica existe?}
    I -->|Não| J[Criar base vazia]
    I -->|Sim| K[Copiar para base expandida]
    
    J --> L[Inicializar base]
    K --> L
    H --> L
    
    L --> M{Embeddings existem?}
    M -->|Não| N[Criar arquivo vazio]
    M -->|Sim| O[Carregar embeddings]
    
    N --> P[Verificar configuração]
    O --> P
    
    P --> Q{Config correta?}
    Q -->|Não| R[Corrigir caminhos]
    Q -->|Sim| S[Configuração OK]
    
    R --> T[Salvar configuração]
    S --> U[Inicialização completa]
    T --> U
```

## Componentes Detalhados

### 1. Entrada e Configuração

```mermaid
graph LR
    A[Arquivo COBOL] --> B[Parser COBOL]
    C[Configuração YAML] --> D[ConfigManager]
    E[Argumentos CLI] --> F[ArgumentParser]
    
    B --> G[CobolProgram Object]
    D --> H[Sistema Configurado]
    F --> I[Parâmetros de Execução]
    
    G --> J[Análise Estrutural]
    H --> J
    I --> J
```

### 2. Sistema RAG (Retrieval Augmented Generation)

```mermaid
graph TD
    A[Prompt Inicial] --> B[RAG Integration]
    B --> C[Base de Conhecimento CADOC]
    C --> D[79+ Itens Especializados]
    
    D --> E[Busca Semântica]
    E --> F[Seleção de Contexto]
    F --> G[Enriquecimento do Prompt]
    
    G --> H[Prompt Enriquecido]
    H --> I[Análise IA]
    
    subgraph "Base CADOC"
        J[Processamento Documentos]
        K[Workflows Bancários]
        L[Compliance BACEN]
        M[Auditoria e Controle]
    end
    
    C --> J
    C --> K
    C --> L
    C --> M
    
    I --> N[Resultado Análise]
    N --> O[Auto-Aprendizado]
    O --> P[Extração de Insights]
    P --> Q[Adição à Base]
    Q --> C
```

### 3. Análise de Complexidade e Seleção de Modelo

```mermaid
graph TD
    A[Código COBOL] --> B[Intelligent Model Selector]
    B --> C[Análise de Complexidade]
    
    C --> D{Complexidade}
    D -->|Alta 8-10| E[Claude 3.5 Sonnet]
    D -->|Média 5-7| F[Amazon Nova Pro]
    D -->|Baixa 1-4| G[Claude Haiku]
    
    E --> H[Análise Detalhada]
    F --> I[Análise Balanceada]
    G --> J[Análise Rápida]
    
    H --> K[Resultado Especializado]
    I --> K
    J --> K
```

### 4. Processamento de Múltiplos Modelos

```mermaid
graph TD
    A[Lista de Modelos] --> B[Enhanced Provider Manager]
    
    B --> C[Modelo 1]
    B --> D[Modelo 2]
    B --> E[Modelo N]
    
    C --> F[Diretório model_1]
    D --> G[Diretório model_2]
    E --> H[Diretório model_n]
    
    F --> I[Análise Individual 1]
    G --> J[Análise Individual 2]
    H --> K[Análise Individual N]
    
    I --> L[Documentação MD]
    J --> M[Documentação MD]
    K --> N[Documentação MD]
    
    L --> O[Relatório Consolidado]
    M --> O
    N --> O
```

### 5. Extração Detalhada de Regras de Negócio

```mermaid
graph TD
    A[Código COBOL] --> B[Deep Business Analyzer]
    B --> C[Análise Sintática]
    C --> D[Identificação de Padrões]
    
    D --> E[Regras Financeiras]
    D --> F[Validações de Dados]
    D --> G[Cálculos Matemáticos]
    D --> H[Condições de Negócio]
    
    E --> I[Valores Específicos]
    F --> J[Campos e Tipos]
    G --> K[Fórmulas Completas]
    H --> L[Lógica Condicional]
    
    I --> M[Tarifa: R$ 8,50]
    J --> N[CONTA-NUM PIC 9(10)]
    K --> O[JUROS = PRINCIPAL * TAXA]
    L --> P[IF SALDO > 1000 THEN...]
    
    M --> Q[Regra Estruturada]
    N --> Q
    O --> Q
    P --> Q
```

### 6. Geração de Documentação

```mermaid
graph TD
    A[Análise Completa] --> B[Documentation Generator]
    B --> C{Formato de Saída}
    
    C -->|Markdown| D[Gerador MD]
    C -->|HTML| E[Gerador HTML]
    C -->|PDF| F[Gerador PDF]
    
    D --> G[Arquivo .md]
    E --> H[Arquivo .html]
    F --> I[Arquivo .pdf]
    
    G --> J[Estrutura Padronizada]
    H --> K[CSS Profissional]
    I --> L[Layout Corporativo]
    
    J --> M[Entrega Final]
    K --> M
    L --> M
```

### 7. Auto-Aprendizado e Persistência

```mermaid
graph TD
    A[Análise Concluída] --> B[Auto-Learning Enhancement]
    B --> C[Extração de Insights]
    
    C --> D[Padrões Identificados]
    C --> E[Regras de Negócio]
    C --> F[Técnicas de Otimização]
    C --> G[Tratamentos de Erro]
    
    D --> H[Filtro de Qualidade]
    E --> H
    F --> H
    G --> H
    
    H --> I{Insight Valioso?}
    I -->|Não| J[Descartado]
    I -->|Sim| K[Novo Item de Conhecimento]
    
    K --> L[Adição à Base RAG]
    L --> M[Salvamento em data/]
    M --> N[Atualização de Embeddings]
    N --> O[Base Enriquecida]
```

## Fluxo de Dados Detalhado

### Entrada → Processamento → Saída

```mermaid
sequenceDiagram
    participant U as Usuário
    participant CLI as Interface CLI
    participant RAG as Sistema RAG
    participant AI as Provedor IA
    participant DOC as Gerador Docs
    participant DB as Base de Conhecimento
    
    U->>CLI: python main.py --fontes programa.cbl
    CLI->>RAG: Verificar base RAG
    RAG->>DB: Carregar base de conhecimento
    
    CLI->>RAG: Enriquecer prompt
    RAG->>RAG: Buscar conhecimento relevante
    RAG->>CLI: Prompt enriquecido
    
    CLI->>AI: Enviar para análise
    AI->>AI: Processar com IA
    AI->>CLI: Retornar análise
    
    CLI->>DOC: Gerar documentação
    DOC->>DOC: Criar arquivos MD/HTML
    
    CLI->>RAG: Extrair novos insights
    RAG->>DB: Adicionar à base de conhecimento
    DB->>DB: Salvar em data/
    
    DOC->>U: Entregar resultados
```

## Arquitetura de Componentes

```mermaid
graph TB
    subgraph "Interface"
        A[main.py]
        B[cobol_to_docs/__init__.py]
        Z[ensure_rag_base.py]
    end
    
    subgraph "Core"
        C[ConfigManager]
        D[Intelligent Model Selector]
        E[Adaptive Prompt Manager]
    end
    
    subgraph "Análise"
        F[COBOL Parser]
        G[Deep Business Analyzer]
        H[Business Rules Extractor]
    end
    
    subgraph "IA e RAG"
        I[Enhanced Provider Manager]
        J[RAG Integration]
        K[CADOC Knowledge Base]
        L[Auto Learning Enhancement]
    end
    
    subgraph "Geração"
        M[Documentation Generator]
        N[Advanced Report Generator]
        O[Cost Calculator]
    end
    
    subgraph "Persistência"
        P[data/cobol_knowledge_base_cadoc_expanded.json]
        Q[data/cobol_embeddings.pkl]
    end
    
    A --> Z
    Z --> P
    Z --> Q
    
    A --> C
    B --> C
    C --> D
    D --> E
    
    A --> F
    F --> G
    G --> H
    
    E --> I
    I --> J
    J --> K
    K --> L
    
    H --> M
    M --> N
    I --> O
    
    L --> P
    L --> Q
```

## Métricas e Monitoramento

### Fluxo de Auditoria

```mermaid
graph LR
    A[Início da Análise] --> B[Log de Início]
    B --> C[Operações RAG]
    C --> D[Chamadas IA]
    D --> E[Cálculo de Custos]
    E --> F[Geração de Docs]
    F --> G[Auto-Aprendizado]
    G --> H[Relatório Final]
    
    B --> I[Timestamp]
    C --> J[Itens Conhecimento]
    D --> K[Tokens Utilizados]
    E --> L[Custo por Modelo]
    F --> M[Arquivos Gerados]
    G --> N[Insights Adicionados]
    H --> O[Métricas Consolidadas]
```

## Casos de Uso Principais

### 1. Análise Simples
```
Entrada: programa.cbl
Processo: Análise aprofundada padrão
Saída: Documentação MD + relatório custos
Base RAG: Enriquecida com novos insights
```

### 2. Comparação de Modelos
```
Entrada: programa.cbl + múltiplos modelos
Processo: Análise paralela
Saída: Relatórios individuais + comparativo
Base RAG: Enriquecida com insights de múltiplos modelos
```

### 3. Análise Avançada
```
Entrada: sistema_complexo.cbl
Processo: RAG + análise avançada + HTML
Saída: Relatório consolidado profissional
Base RAG: Enriquecida com insights complexos
```

## Configurações de Performance

### Otimizações Implementadas

1. **Cache de Contexto RAG**: Evita reprocessamento
2. **Processamento Paralelo**: Múltiplos modelos simultâneos
3. **Seleção Inteligente**: Modelo ótimo por complexidade
4. **Fallback Automático**: Continuidade operacional
5. **Controle de Custos**: Limites e monitoramento
6. **Persistência de Conhecimento**: Base RAG em data/
7. **Verificação Automática**: Garantia de integridade da base

### Métricas de Qualidade

- **Taxa de Sucesso**: > 95%
- **Tempo de Resposta**: < 30s por programa
- **Precisão de Regras**: > 90%
- **Cobertura de Análise**: 100% do código
- **Crescimento da Base**: Média de 2-3 insights por análise

---

Este fluxo demonstra como o COBOL to Docs v1.4 processa código COBOL legado e transforma em documentação técnica especializada, utilizando IA avançada e conhecimento específico do domínio bancário/CADOC, com persistência e evolução contínua da base de conhecimento.
