# Fluxo de Funcionamento - COBOL to Docs v1.4

## Visão Geral do Sistema

O COBOL to Docs v1.4 é um sistema avançado que combina análise de código COBOL, inteligência artificial e sistema RAG para gerar documentação técnica especializada.

## Fluxograma Principal

```mermaid
graph TD
    A[Início: Arquivo COBOL] --> B{Análise Aprofundada?}
    B -->|Sim - Padrão v1.4| C[Modo Deep Analysis]
    B -->|Não - --basic-analysis| D[Modo Basic Analysis]
    
    C --> E[Parse do Código COBOL]
    D --> E
    
    E --> F[Extração de Estruturas]
    F --> G[Identificação de Divisões]
    G --> H[Mapeamento de Variáveis]
    H --> I[Análise de Fluxo]
    
    I --> J{RAG Habilitado?}
    J -->|Sim| K[Sistema RAG]
    J -->|Não| M[Seleção de Modelo]
    
    K --> L[Base de Conhecimento CADOC]
    L --> N[Enriquecimento de Contexto]
    N --> M
    
    M --> O{Seleção Automática?}
    O -->|Sim| P[Análise de Complexidade]
    O -->|Não| Q[Modelo Especificado]
    
    P --> R[Recomendação de Modelo]
    R --> S[Modelo Selecionado]
    Q --> S
    
    S --> T[Geração de Prompt]
    T --> U{Múltiplos Modelos?}
    U -->|Sim| V[Processamento Paralelo]
    U -->|Não| W[Processamento Único]
    
    V --> X[Modelo 1: Claude Sonnet]
    V --> Y[Modelo 2: Nova Pro]
    V --> Z[Modelo 3: GPT-4]
    
    X --> AA[Análise IA 1]
    Y --> BB[Análise IA 2]
    Z --> CC[Análise IA 3]
    
    W --> DD[Análise IA Única]
    
    AA --> EE[Extração de Regras]
    BB --> EE
    CC --> EE
    DD --> EE
    
    EE --> FF[Identificação de Valores]
    FF --> GG[Mapeamento de Fórmulas]
    GG --> HH[Análise de Condições]
    
    HH --> II{Análise Avançada?}
    II -->|Sim| JJ[Geração HTML]
    II -->|Não| KK[Geração Markdown]
    
    JJ --> LL[Relatório Consolidado]
    KK --> MM[Documentação Individual]
    
    LL --> NN[Cálculo de Custos]
    MM --> NN
    
    NN --> OO[Relatório de Auditoria]
    OO --> PP[Finalização RAG]
    PP --> QQ[Entrega Final]
```

## Componentes Detalhados

### 1. Entrada e Configuração

```mermaid
graph LR
    A[Arquivo COBOL] --> B[Parser COBOL]
    C[Configuração YAML] --> D[ConfigManager]
    E[Argumentos CLI] --> F[ArgumentParser]
    
    B --> G[CobolProgram Object]
    D --> H[Sistema Configurado]
    F --> I[Parâmetros de Execução]
    
    G --> J[Análise Estrutural]
    H --> J
    I --> J
```

### 2. Sistema RAG (Retrieval Augmented Generation)

```mermaid
graph TD
    A[Prompt Inicial] --> B[RAG Integration]
    B --> C[Base de Conhecimento CADOC]
    C --> D[77+ Itens Especializados]
    
    D --> E[Busca Semântica]
    E --> F[Seleção de Contexto]
    F --> G[Enriquecimento do Prompt]
    
    G --> H[Prompt Enriquecido]
    H --> I[Análise IA]
    
    subgraph "Base CADOC"
        J[Processamento Documentos]
        K[Workflows Bancários]
        L[Compliance BACEN]
        M[Auditoria e Controle]
    end
    
    C --> J
    C --> K
    C --> L
    C --> M
```

### 3. Análise de Complexidade e Seleção de Modelo

```mermaid
graph TD
    A[Código COBOL] --> B[Intelligent Model Selector]
    B --> C[Análise de Complexidade]
    
    C --> D{Complexidade}
    D -->|Alta 8-10| E[Claude 3.5 Sonnet]
    D -->|Média 5-7| F[Amazon Nova Pro]
    D -->|Baixa 1-4| G[Claude Haiku]
    
    E --> H[Análise Detalhada]
    F --> I[Análise Balanceada]
    G --> J[Análise Rápida]
    
    H --> K[Resultado Especializado]
    I --> K
    J --> K
```

### 4. Processamento de Múltiplos Modelos

```mermaid
graph TD
    A[Lista de Modelos] --> B[Enhanced Provider Manager]
    
    B --> C[Modelo 1]
    B --> D[Modelo 2]
    B --> E[Modelo N]
    
    C --> F[Diretório model_1]
    D --> G[Diretório model_2]
    E --> H[Diretório model_n]
    
    F --> I[Análise Individual 1]
    G --> J[Análise Individual 2]
    H --> K[Análise Individual N]
    
    I --> L[Documentação MD]
    J --> M[Documentação MD]
    K --> N[Documentação MD]
    
    L --> O[Relatório Consolidado]
    M --> O
    N --> O
```

### 5. Extração Detalhada de Regras de Negócio

```mermaid
graph TD
    A[Código COBOL] --> B[Deep Business Analyzer]
    B --> C[Análise Sintática]
    C --> D[Identificação de Padrões]
    
    D --> E[Regras Financeiras]
    D --> F[Validações de Dados]
    D --> G[Cálculos Matemáticos]
    D --> H[Condições de Negócio]
    
    E --> I[Valores Específicos]
    F --> J[Campos e Tipos]
    G --> K[Fórmulas Completas]
    H --> L[Lógica Condicional]
    
    I --> M[Tarifa: R$ 8,50]
    J --> N[CONTA-NUM PIC 9(10)]
    K --> O[JUROS = PRINCIPAL * TAXA]
    L --> P[IF SALDO > 1000 THEN...]
    
    M --> Q[Regra Estruturada]
    N --> Q
    O --> Q
    P --> Q
```

### 6. Geração de Documentação

```mermaid
graph TD
    A[Análise Completa] --> B[Documentation Generator]
    B --> C{Formato de Saída}
    
    C -->|Markdown| D[Gerador MD]
    C -->|HTML| E[Gerador HTML]
    C -->|PDF| F[Gerador PDF]
    
    D --> G[Arquivo .md]
    E --> H[Arquivo .html]
    F --> I[Arquivo .pdf]
    
    G --> J[Estrutura Padronizada]
    H --> K[CSS Profissional]
    I --> L[Layout Corporativo]
    
    J --> M[Entrega Final]
    K --> M
    L --> M
```

## Fluxo de Dados Detalhado

### Entrada → Processamento → Saída

```mermaid
sequenceDiagram
    participant U as Usuário
    participant CLI as Interface CLI
    participant CM as ConfigManager
    participant RAG as Sistema RAG
    participant AI as Provedor IA
    participant DOC as Gerador Docs
    
    U->>CLI: python main.py --fontes programa.cbl
    CLI->>CM: Carregar configurações
    CM->>RAG: Inicializar base CADOC
    
    CLI->>RAG: Enriquecer prompt
    RAG->>RAG: Buscar conhecimento relevante
    RAG->>CLI: Prompt enriquecido
    
    CLI->>AI: Enviar para análise
    AI->>AI: Processar com IA
    AI->>CLI: Retornar análise
    
    CLI->>DOC: Gerar documentação
    DOC->>DOC: Criar arquivos MD/HTML
    DOC->>U: Entregar resultados
```

## Arquitetura de Componentes

```mermaid
graph TB
    subgraph "Interface"
        A[main.py]
        B[cobol_to_docs/__init__.py]
    end
    
    subgraph "Core"
        C[ConfigManager]
        D[Intelligent Model Selector]
        E[Adaptive Prompt Manager]
    end
    
    subgraph "Análise"
        F[COBOL Parser]
        G[Deep Business Analyzer]
        H[Business Rules Extractor]
    end
    
    subgraph "IA e RAG"
        I[Enhanced Provider Manager]
        J[RAG Integration]
        K[CADOC Knowledge Base]
    end
    
    subgraph "Geração"
        L[Documentation Generator]
        M[Advanced Report Generator]
        N[Cost Calculator]
    end
    
    A --> C
    B --> C
    C --> D
    D --> E
    
    A --> F
    F --> G
    G --> H
    
    E --> I
    I --> J
    J --> K
    
    H --> L
    L --> M
    I --> N
```

## Métricas e Monitoramento

### Fluxo de Auditoria

```mermaid
graph LR
    A[Início da Análise] --> B[Log de Início]
    B --> C[Operações RAG]
    C --> D[Chamadas IA]
    D --> E[Cálculo de Custos]
    E --> F[Geração de Docs]
    F --> G[Relatório Final]
    
    B --> H[Timestamp]
    C --> I[Itens Conhecimento]
    D --> J[Tokens Utilizados]
    E --> K[Custo por Modelo]
    F --> L[Arquivos Gerados]
    G --> M[Métricas Consolidadas]
```

## Casos de Uso Principais

### 1. Análise Simples
```
Entrada: programa.cbl
Processo: Análise aprofundada padrão
Saída: Documentação MD + relatório custos
```

### 2. Comparação de Modelos
```
Entrada: programa.cbl + múltiplos modelos
Processo: Análise paralela
Saída: Relatórios individuais + comparativo
```

### 3. Análise Avançada
```
Entrada: sistema_complexo.cbl
Processo: RAG + análise avançada + HTML
Saída: Relatório consolidado profissional
```

## Configurações de Performance

### Otimizações Implementadas

1. **Cache de Contexto RAG**: Evita reprocessamento
2. **Processamento Paralelo**: Múltiplos modelos simultâneos
3. **Seleção Inteligente**: Modelo ótimo por complexidade
4. **Fallback Automático**: Continuidade operacional
5. **Controle de Custos**: Limites e monitoramento

### Métricas de Qualidade

- **Taxa de Sucesso**: > 95%
- **Tempo de Resposta**: < 30s por programa
- **Precisão de Regras**: > 90%
- **Cobertura de Análise**: 100% do código

---

Este fluxo demonstra como o COBOL to Docs v1.4 processa código COBOL legado e transforma em documentação técnica especializada, utilizando IA avançada e conhecimento específico do domínio bancário/CADOC.
