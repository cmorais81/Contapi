"""
CobolAnalyzer - Classe principal para análise de código COBOL
"""

import os
import sys
import logging
from pathlib import Path
from typing import Dict, List, Optional, Union

# Adicionar src ao path para importações
current_dir = Path(__file__).parent.parent
src_path = current_dir / 'src'
sys.path.insert(0, str(src_path))

from src.core.config import ConfigManager
from src.parsers.cobol_parser_original import COBOLParser
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.rag.rag_integration import RAGIntegration
from src.utils.cost_calculator import CostCalculator
from src.generators.documentation_generator import DocumentationGenerator
from src.analyzers.deep_business_analyzer import DeepBusinessAnalyzer
from src.core.detailed_prompt_generator import DetailedPromptGenerator
from src.providers.base_provider import AIRequest

from .models import CobolProgram, AnalysisResult
from .exceptions import CobolAnalysisError, ConfigurationError
from .config import CobolConfig

class CobolAnalyzer:
    """
    Analisador principal de código COBOL
    
    Fornece interface simplificada para análise de programas COBOL
    com suporte a múltiplos modelos LLM, RAG e análise aprofundada.
    """
    
    def __init__(self, **kwargs):
        """
        Inicializar analisador COBOL
        
        Args:
            **kwargs: Opções de configuração
                - model (str): Modelo LLM a usar
                - deep_analysis (bool): Ativar análise aprofundada (padrão: True)
                - rag_enabled (bool): Ativar sistema RAG (padrão: True)
                - output_dir (str): Diretório de saída
                - log_level (str): Nível de log
        """
        self.config = CobolConfig(**kwargs)
        self.logger = self._setup_logging()
        
        try:
            # Inicializar componentes
            self.config_manager = ConfigManager()
            self.parser = COBOLParser()
            self.cost_calculator = CostCalculator()
            
            # Inicializar RAG se habilitado
            self.rag_integration = None
            if self.config.rag_enabled:
                self.rag_integration = RAGIntegration(self.config_manager)
                if self.rag_integration.is_enabled():
                    self.logger.info("Sistema RAG inicializado")
                else:
                    self.logger.warning("RAG não pôde ser inicializado")
            
            # Inicializar provider manager
            self.provider_manager = EnhancedProviderManager(self.config_manager)
            
            # Inicializar analisadores especializados
            self.business_analyzer = DeepBusinessAnalyzer()
            self.prompt_generator = DetailedPromptGenerator()
            
            self.logger.info(f"CobolAnalyzer v1.4 inicializado - Modelo: {self.config.model}")
            
        except Exception as e:
            raise ConfigurationError(f"Erro ao inicializar CobolAnalyzer: {e}")
    
    def _setup_logging(self) -> logging.Logger:
        """Configurar logging"""
        logging.basicConfig(
            level=getattr(logging, self.config.log_level.upper()),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        return logging.getLogger(__name__)
    
    def analyze_file(self, file_path: Union[str, Path]) -> AnalysisResult:
        """
        Analisar arquivo COBOL
        
        Args:
            file_path: Caminho para o arquivo COBOL
            
        Returns:
            AnalysisResult: Resultado da análise
            
        Raises:
            CobolAnalysisError: Erro na análise
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise CobolAnalysisError(f"Arquivo não encontrado: {file_path}")
        
        try:
            # Parse do arquivo
            programs, books = self.parser.parse_file(str(file_path))
            
            if not programs and books:
                # Converter books para programs se necessário
                from src.parsers.cobol_parser_original import CobolProgram as SrcCobolProgram
                programs = [SrcCobolProgram(name=book.name, content=book.content, divisions={}, sections=[]) 
                           for book in books]
            
            if not programs:
                raise CobolAnalysisError("Nenhum programa COBOL encontrado no arquivo")
            
            # Analisar primeiro programa (ou todos se múltiplos)
            results = []
            for program in programs:
                result = self._analyze_program(program)
                results.append(result)
            
            # Retornar primeiro resultado ou consolidado
            return results[0] if len(results) == 1 else self._consolidate_results(results)
            
        except Exception as e:
            raise CobolAnalysisError(f"Erro ao analisar arquivo {file_path}: {e}")
    
    def analyze_code(self, code: str, program_name: str = "PROGRAMA") -> AnalysisResult:
        """
        Analisar código COBOL direto
        
        Args:
            code: Código COBOL
            program_name: Nome do programa
            
        Returns:
            AnalysisResult: Resultado da análise
        """
        try:
            # Criar programa temporário
            from src.parsers.cobol_parser_original import CobolProgram as SrcCobolProgram
            program = SrcCobolProgram(name=program_name, content=code, divisions={}, sections=[])
            
            return self._analyze_program(program)
            
        except Exception as e:
            raise CobolAnalysisError(f"Erro ao analisar código: {e}")
    
    def _analyze_program(self, program) -> AnalysisResult:
        """
        Analisar programa individual
        
        Args:
            program: Programa COBOL parseado
            
        Returns:
            AnalysisResult: Resultado da análise
        """
        try:
            self.logger.info(f"Analisando programa: {program.name}")
            
            # Análise prévia com business analyzer se deep_analysis ativado
            detailed_analysis = {}
            if self.config.deep_analysis:
                detailed_analysis = self.business_analyzer.extract_detailed_rules(
                    program.content, ""
                )
                self.logger.info(f"Análise prévia: {len(detailed_analysis.get('business_rules', []))} regras encontradas")
            
            # Gerar prompt apropriado
            if self.config.deep_analysis:
                prompt = self.prompt_generator.generate_detailed_analysis_prompt(
                    program.content, "", False
                )
            else:
                # Prompt básico
                prompt = f"Analise o seguinte programa COBOL:\n\n{program.content}"
            
            # Aplicar RAG se habilitado
            if self.rag_integration and self.rag_integration.is_enabled():
                rag_context = self.rag_integration.enhance_prompt(prompt, program.name)
                if rag_context:
                    prompt = rag_context
                    self.logger.info("Contexto RAG aplicado ao prompt")
            
            # Criar requisição AI
            ai_request = AIRequest(
                prompt=prompt,
                program_name=program.name,
                program_code=program.content,
                context={"deep_analysis": self.config.deep_analysis}
            )
            
            # Executar análise
            analysis_result = self.provider_manager.analyze_with_model(self.config.model, ai_request)
            
            if not analysis_result.success:
                raise CobolAnalysisError(f"Falha na análise: {analysis_result.error_message}")
            
            # Calcular custos
            cost_info = self.cost_calculator.tokens_analytics(
                {'usage': [{'total_tokens': analysis_result.tokens_used}]}, 
                analysis_result.model
            )
            
            # Gerar documentação se output_dir especificado
            documentation_files = {}
            if self.config.output_dir:
                doc_generator = DocumentationGenerator(self.config.output_dir)
                
                # Criar AIResponse para documentação
                from src.providers.base_provider import AIResponse
                ai_response = AIResponse(
                    success=True,
                    content=analysis_result.content,
                    tokens_used=analysis_result.tokens_used,
                    model=analysis_result.model,
                    provider=getattr(analysis_result, 'provider_used', self.config.model),
                    prompts_used={'main_prompt': prompt[:500] + '...'},
                    response_time=1.0
                )
                
                doc_result = doc_generator.generate_program_documentation(program, ai_response)
                if doc_result['success']:
                    documentation_files = doc_result.get('files', {})
            
            # Criar resultado
            return AnalysisResult(
                program_name=program.name,
                success=True,
                content=analysis_result.content,
                business_rules=self._extract_business_rules(analysis_result.content),
                technical_details=self._extract_technical_details(analysis_result.content),
                recommendations=self._extract_recommendations(analysis_result.content),
                tokens_used=analysis_result.tokens_used,
                cost=cost_info.get('cost', 0.0),
                model_used=analysis_result.model,
                detailed_analysis=detailed_analysis,
                documentation_files=documentation_files,
                metadata={
                    'deep_analysis': self.config.deep_analysis,
                    'rag_enabled': self.config.rag_enabled,
                    'timestamp': analysis_result.timestamp
                }
            )
            
        except Exception as e:
            return AnalysisResult(
                program_name=program.name,
                success=False,
                error_message=str(e),
                content="",
                business_rules=[],
                technical_details={},
                recommendations=[],
                tokens_used=0,
                cost=0.0,
                model_used=self.config.model
            )
    
    def _extract_business_rules(self, content: str) -> List[str]:
        """Extrair regras de negócio do conteúdo analisado"""
        rules = []
        lines = content.split('\\n')
        
        for line in lines:
            line = line.strip()
            if any(keyword in line.lower() for keyword in ['regra', 'rule', 'cálculo', 'tarifa', 'limite']):
                if line and not line.startswith('#'):
                    rules.append(line)
        
        return rules[:10]  # Limitar a 10 regras principais
    
    def _extract_technical_details(self, content: str) -> Dict:
        """Extrair detalhes técnicos do conteúdo analisado"""
        details = {
            'divisions': [],
            'sections': [],
            'files': [],
            'variables': []
        }
        
        lines = content.split('\\n')
        for line in lines:
            line = line.strip().lower()
            if 'division' in line:
                details['divisions'].append(line)
            elif 'section' in line:
                details['sections'].append(line)
            elif any(keyword in line for keyword in ['arquivo', 'file', 'fd']):
                details['files'].append(line)
            elif any(keyword in line for keyword in ['pic', 'variável', 'campo']):
                details['variables'].append(line)
        
        return details
    
    def _extract_recommendations(self, content: str) -> List[str]:
        """Extrair recomendações do conteúdo analisado"""
        recommendations = []
        lines = content.split('\\n')
        
        for line in lines:
            line = line.strip()
            if any(keyword in line.lower() for keyword in ['recomenda', 'suggest', 'melhoria', 'moderniz']):
                if line and not line.startswith('#'):
                    recommendations.append(line)
        
        return recommendations[:5]  # Limitar a 5 recomendações principais
    
    def _consolidate_results(self, results: List[AnalysisResult]) -> AnalysisResult:
        """Consolidar múltiplos resultados em um único resultado"""
        if not results:
            raise CobolAnalysisError("Nenhum resultado para consolidar")
        
        # Consolidar informações
        consolidated_content = "\\n\\n".join([r.content for r in results if r.success])
        consolidated_rules = []
        consolidated_recommendations = []
        total_tokens = 0
        total_cost = 0.0
        
        for result in results:
            if result.success:
                consolidated_rules.extend(result.business_rules)
                consolidated_recommendations.extend(result.recommendations)
                total_tokens += result.tokens_used
                total_cost += result.cost
        
        return AnalysisResult(
            program_name="CONSOLIDADO",
            success=True,
            content=consolidated_content,
            business_rules=consolidated_rules,
            technical_details={},
            recommendations=consolidated_recommendations,
            tokens_used=total_tokens,
            cost=total_cost,
            model_used=self.config.model,
            metadata={'consolidated': True, 'programs_count': len(results)}
        )
    
    def get_available_models(self) -> List[str]:
        """Obter lista de modelos disponíveis"""
        try:
            return self.provider_manager.get_available_models()
        except Exception as e:
            self.logger.error(f"Erro ao obter modelos: {e}")
            return ['enhanced_mock']  # Fallback
    
    def get_cost_report(self) -> str:
        """Obter relatório de custos"""
        return self.cost_calculator.format_cost_report()
    
    def finalize(self) -> Optional[str]:
        """Finalizar sessão e obter relatório RAG se disponível"""
        if self.rag_integration and self.rag_integration.is_enabled():
            try:
                return self.rag_integration.finalize_session()
            except Exception as e:
                self.logger.warning(f"Erro ao finalizar sessão RAG: {e}")
        return None
