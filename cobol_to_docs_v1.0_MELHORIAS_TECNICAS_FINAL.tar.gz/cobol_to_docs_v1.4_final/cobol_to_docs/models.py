"""
Modelos de dados para COBOL to Docs
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime

@dataclass
class CobolProgram:
    """Representa um programa COBOL"""
    name: str
    content: str
    divisions: Dict[str, Any] = field(default_factory=dict)
    sections: List[str] = field(default_factory=list)
    files: List[str] = field(default_factory=list)
    variables: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Processar conteúdo após inicialização"""
        if self.content and not self.divisions:
            self._parse_basic_structure()
    
    def _parse_basic_structure(self):
        """Parse básico da estrutura do programa"""
        lines = self.content.split('\\n')
        current_division = None
        
        for line in lines:
            line = line.strip().upper()
            
            if 'DIVISION' in line:
                if 'IDENTIFICATION' in line:
                    current_division = 'IDENTIFICATION'
                elif 'ENVIRONMENT' in line:
                    current_division = 'ENVIRONMENT'
                elif 'DATA' in line:
                    current_division = 'DATA'
                elif 'PROCEDURE' in line:
                    current_division = 'PROCEDURE'
                
                if current_division:
                    self.divisions[current_division] = []
            
            elif 'SECTION' in line and current_division:
                section_name = line.replace('SECTION', '').strip().rstrip('.')
                self.sections.append(section_name)
                
            elif current_division and line:
                self.divisions[current_division].append(line)

@dataclass
class AnalysisResult:
    """Resultado de análise de programa COBOL"""
    program_name: str
    success: bool
    content: str = ""
    business_rules: List[str] = field(default_factory=list)
    technical_details: Dict[str, Any] = field(default_factory=dict)
    recommendations: List[str] = field(default_factory=list)
    tokens_used: int = 0
    cost: float = 0.0
    model_used: str = ""
    error_message: str = ""
    detailed_analysis: Dict[str, Any] = field(default_factory=dict)
    documentation_files: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)
    
    @property
    def has_business_rules(self) -> bool:
        """Verificar se tem regras de negócio"""
        return len(self.business_rules) > 0
    
    @property
    def has_recommendations(self) -> bool:
        """Verificar se tem recomendações"""
        return len(self.recommendations) > 0
    
    @property
    def complexity_score(self) -> float:
        """Calcular score de complexidade baseado no conteúdo"""
        if not self.content:
            return 0.0
        
        # Fatores de complexidade
        factors = {
            'business_rules': len(self.business_rules) * 0.3,
            'content_length': min(len(self.content) / 1000, 5.0) * 0.2,
            'technical_details': len(self.technical_details) * 0.2,
            'tokens_used': min(self.tokens_used / 1000, 5.0) * 0.3
        }
        
        return min(sum(factors.values()), 10.0)
    
    def to_dict(self) -> Dict[str, Any]:
        """Converter para dicionário"""
        return {
            'program_name': self.program_name,
            'success': self.success,
            'content': self.content,
            'business_rules': self.business_rules,
            'technical_details': self.technical_details,
            'recommendations': self.recommendations,
            'tokens_used': self.tokens_used,
            'cost': self.cost,
            'model_used': self.model_used,
            'error_message': self.error_message,
            'detailed_analysis': self.detailed_analysis,
            'documentation_files': self.documentation_files,
            'metadata': self.metadata,
            'timestamp': self.timestamp.isoformat(),
            'complexity_score': self.complexity_score
        }
    
    def get_summary(self) -> str:
        """Obter resumo da análise"""
        if not self.success:
            return f"Análise falhou: {self.error_message}"
        
        summary_parts = [
            f"Programa: {self.program_name}",
            f"Modelo: {self.model_used}",
            f"Tokens: {self.tokens_used:,}",
            f"Custo: ${self.cost:.4f}",
            f"Regras de negócio: {len(self.business_rules)}",
            f"Recomendações: {len(self.recommendations)}",
            f"Complexidade: {self.complexity_score:.1f}/10"
        ]
        
        return " | ".join(summary_parts)

@dataclass
class BusinessRule:
    """Representa uma regra de negócio extraída"""
    id: str
    description: str
    code_reference: str = ""
    line_numbers: List[int] = field(default_factory=list)
    values: Dict[str, Any] = field(default_factory=dict)
    formulas: List[str] = field(default_factory=list)
    conditions: List[str] = field(default_factory=list)
    category: str = "general"
    priority: str = "medium"
    
    @property
    def has_specific_values(self) -> bool:
        """Verificar se tem valores específicos"""
        return len(self.values) > 0
    
    @property
    def has_formulas(self) -> bool:
        """Verificar se tem fórmulas"""
        return len(self.formulas) > 0

@dataclass
class TechnicalDetail:
    """Detalhes técnicos do programa"""
    type: str  # 'division', 'section', 'file', 'variable', etc.
    name: str
    description: str = ""
    properties: Dict[str, Any] = field(default_factory=dict)
    line_numbers: List[int] = field(default_factory=list)
    
@dataclass
class CostBreakdown:
    """Detalhamento de custos"""
    model: str
    input_tokens: int
    output_tokens: int
    total_tokens: int
    input_cost: float
    output_cost: float
    total_cost: float
    currency: str = "USD"
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'model': self.model,
            'input_tokens': self.input_tokens,
            'output_tokens': self.output_tokens,
            'total_tokens': self.total_tokens,
            'input_cost': self.input_cost,
            'output_cost': self.output_cost,
            'total_cost': self.total_cost,
            'currency': self.currency
        }

@dataclass
class RAGContext:
    """Contexto RAG aplicado"""
    knowledge_items_used: int
    operations_performed: int
    context_added: str = ""
    confidence_score: float = 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'knowledge_items_used': self.knowledge_items_used,
            'operations_performed': self.operations_performed,
            'context_added': self.context_added,
            'confidence_score': self.confidence_score
        }
