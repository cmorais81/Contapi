"""
COBOL to Docs v1.4 - Biblioteca Python
Sistema avançado de análise e documentação de código COBOL com IA
"""

__version__ = "1.4.0"
__author__ = "Equipe COBOL to Docs"
__email__ = "cobol-to-docs@empresa.com"

# Importações principais para uso como biblioteca
from .analyzer import CobolAnalyzer
from .config import CobolConfig
from .models import CobolProgram, AnalysisResult
from .exceptions import CobolAnalysisError, ConfigurationError

# Função principal para análise rápida
def analyze_cobol_file(file_path, **kwargs):
    """
    Análise rápida de arquivo COBOL
    
    Args:
        file_path (str): Caminho para o arquivo COBOL
        **kwargs: Opções de configuração
        
    Returns:
        AnalysisResult: Resultado da análise
        
    Example:
        >>> from cobol_to_docs import analyze_cobol_file
        >>> result = analyze_cobol_file('programa.cbl', model='enhanced_mock')
        >>> print(result.business_rules)
    """
    analyzer = CobolAnalyzer(**kwargs)
    return analyzer.analyze_file(file_path)

def analyze_cobol_code(code, program_name="PROGRAMA", **kwargs):
    """
    Análise de código COBOL direto
    
    Args:
        code (str): Código COBOL
        program_name (str): Nome do programa
        **kwargs: Opções de configuração
        
    Returns:
        AnalysisResult: Resultado da análise
        
    Example:
        >>> from cobol_to_docs import analyze_cobol_code
        >>> code = '''
        ... IDENTIFICATION DIVISION.
        ... PROGRAM-ID. TESTE.
        ... '''
        >>> result = analyze_cobol_code(code, program_name="TESTE")
    """
    analyzer = CobolAnalyzer(**kwargs)
    return analyzer.analyze_code(code, program_name)

# Configuração padrão
DEFAULT_CONFIG = {
    'deep_analysis': True,  # Análise aprofundada por padrão
    'model': 'enhanced_mock',
    'rag_enabled': True,
    'output_format': 'markdown'
}

# Exportar classes principais
__all__ = [
    'CobolAnalyzer',
    'CobolConfig', 
    'CobolProgram',
    'AnalysisResult',
    'CobolAnalysisError',
    'ConfigurationError',
    'analyze_cobol_file',
    'analyze_cobol_code',
    'DEFAULT_CONFIG'
]
