"""
Configuração para COBOL to Docs
"""

import os
from pathlib import Path
from typing import Dict, Any, Optional

class CobolConfig:
    """Configuração para análise COBOL"""
    
    def __init__(self, **kwargs):
        """
        Inicializar configuração
        
        Args:
            **kwargs: Opções de configuração
        """
        # Configurações padrão
        self.deep_analysis = kwargs.get('deep_analysis', True)  # Análise aprofundada por padrão
        self.model = kwargs.get('model', 'enhanced_mock')
        self.rag_enabled = kwargs.get('rag_enabled', True)
        self.output_dir = kwargs.get('output_dir', None)
        self.output_format = kwargs.get('output_format', 'markdown')
        self.log_level = kwargs.get('log_level', 'INFO')
        self.max_tokens = kwargs.get('max_tokens', 4000)
        self.timeout = kwargs.get('timeout', 300)
        
        # Configurações avançadas
        self.extract_formulas = kwargs.get('extract_formulas', False)
        self.advanced_analysis = kwargs.get('advanced_analysis', False)
        self.auto_model = kwargs.get('auto_model', False)
        self.model_comparison = kwargs.get('model_comparison', False)
        
        # Configurações de custo
        self.track_costs = kwargs.get('track_costs', True)
        self.cost_limit = kwargs.get('cost_limit', None)
        
        # Configurações RAG
        self.rag_knowledge_base = kwargs.get('rag_knowledge_base', 'cobol_knowledge_base_cadoc_expanded.json')
        self.rag_threshold = kwargs.get('rag_threshold', 0.7)
        
        # Configurações de saída
        self.generate_html = kwargs.get('generate_html', False)
        self.generate_pdf = kwargs.get('generate_pdf', False)
        self.include_code_snippets = kwargs.get('include_code_snippets', True)
        
        # Validar configurações
        self._validate_config()
    
    def _validate_config(self):
        """Validar configurações"""
        if self.output_dir:
            self.output_dir = Path(self.output_dir)
            self.output_dir.mkdir(parents=True, exist_ok=True)
        
        if self.log_level not in ['DEBUG', 'INFO', 'WARNING', 'ERROR']:
            self.log_level = 'INFO'
        
        if self.max_tokens < 100:
            self.max_tokens = 100
        elif self.max_tokens > 32000:
            self.max_tokens = 32000
    
    def to_dict(self) -> Dict[str, Any]:
        """Converter para dicionário"""
        return {
            'deep_analysis': self.deep_analysis,
            'model': self.model,
            'rag_enabled': self.rag_enabled,
            'output_dir': str(self.output_dir) if self.output_dir else None,
            'output_format': self.output_format,
            'log_level': self.log_level,
            'max_tokens': self.max_tokens,
            'timeout': self.timeout,
            'extract_formulas': self.extract_formulas,
            'advanced_analysis': self.advanced_analysis,
            'auto_model': self.auto_model,
            'model_comparison': self.model_comparison,
            'track_costs': self.track_costs,
            'cost_limit': self.cost_limit,
            'rag_knowledge_base': self.rag_knowledge_base,
            'rag_threshold': self.rag_threshold,
            'generate_html': self.generate_html,
            'generate_pdf': self.generate_pdf,
            'include_code_snippets': self.include_code_snippets
        }
    
    @classmethod
    def from_file(cls, config_file: str) -> 'CobolConfig':
        """Carregar configuração de arquivo"""
        config_path = Path(config_file)
        
        if not config_path.exists():
            raise FileNotFoundError(f"Arquivo de configuração não encontrado: {config_file}")
        
        import yaml
        with open(config_path, 'r', encoding='utf-8') as f:
            config_data = yaml.safe_load(f)
        
        return cls(**config_data)
    
    def save_to_file(self, config_file: str):
        """Salvar configuração em arquivo"""
        config_path = Path(config_file)
        config_path.parent.mkdir(parents=True, exist_ok=True)
        
        import yaml
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(self.to_dict(), f, default_flow_style=False, allow_unicode=True)
    
    def get_analysis_mode(self) -> str:
        """Obter modo de análise atual"""
        if self.advanced_analysis:
            return "advanced"
        elif self.deep_analysis:
            return "deep"
        else:
            return "basic"
    
    def get_output_formats(self) -> list:
        """Obter formatos de saída habilitados"""
        formats = [self.output_format]
        
        if self.generate_html:
            formats.append('html')
        
        if self.generate_pdf:
            formats.append('pdf')
        
        return list(set(formats))
    
    def is_cost_tracking_enabled(self) -> bool:
        """Verificar se rastreamento de custo está habilitado"""
        return self.track_costs
    
    def has_cost_limit(self) -> bool:
        """Verificar se há limite de custo"""
        return self.cost_limit is not None and self.cost_limit > 0
    
    def __str__(self) -> str:
        """Representação string da configuração"""
        return f"CobolConfig(mode={self.get_analysis_mode()}, model={self.model}, rag={self.rag_enabled})"
    
    def __repr__(self) -> str:
        """Representação detalhada da configuração"""
        return f"CobolConfig({self.to_dict()})"
