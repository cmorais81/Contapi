"""
Exceções personalizadas para COBOL to Docs
"""

class CobolToDocsError(Exception):
    """Exceção base para COBOL to Docs"""
    pass

class CobolAnalysisError(CobolToDocsError):
    """Erro durante análise de código COBOL"""
    
    def __init__(self, message: str, program_name: str = None, line_number: int = None):
        self.program_name = program_name
        self.line_number = line_number
        
        if program_name:
            message = f"[{program_name}] {message}"
        
        if line_number:
            message = f"{message} (linha {line_number})"
        
        super().__init__(message)

class ConfigurationError(CobolToDocsError):
    """Erro de configuração"""
    pass

class ModelNotAvailableError(CobolToDocsError):
    """Modelo LLM não disponível"""
    
    def __init__(self, model_name: str, available_models: list = None):
        self.model_name = model_name
        self.available_models = available_models or []
        
        message = f"Modelo '{model_name}' não está disponível"
        if self.available_models:
            message += f". Modelos disponíveis: {', '.join(self.available_models)}"
        
        super().__init__(message)

class RAGError(CobolToDocsError):
    """Erro no sistema RAG"""
    pass

class ParsingError(CobolAnalysisError):
    """Erro ao fazer parse do código COBOL"""
    pass

class DocumentationError(CobolToDocsError):
    """Erro ao gerar documentação"""
    pass

class CostLimitExceededError(CobolToDocsError):
    """Limite de custo excedido"""
    
    def __init__(self, current_cost: float, limit: float):
        self.current_cost = current_cost
        self.limit = limit
        
        message = f"Limite de custo excedido: ${current_cost:.4f} > ${limit:.4f}"
        super().__init__(message)

class TokenLimitExceededError(CobolAnalysisError):
    """Limite de tokens excedido"""
    
    def __init__(self, tokens_used: int, limit: int):
        self.tokens_used = tokens_used
        self.limit = limit
        
        message = f"Limite de tokens excedido: {tokens_used:,} > {limit:,}"
        super().__init__(message)

class ProviderError(CobolToDocsError):
    """Erro do provedor LLM"""
    
    def __init__(self, provider_name: str, error_message: str):
        self.provider_name = provider_name
        self.error_message = error_message
        
        message = f"Erro no provedor '{provider_name}': {error_message}"
        super().__init__(message)

class ValidationError(CobolToDocsError):
    """Erro de validação de dados"""
    pass
