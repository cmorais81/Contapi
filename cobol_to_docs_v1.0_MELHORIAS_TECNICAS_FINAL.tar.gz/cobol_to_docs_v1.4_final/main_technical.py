#!/usr/bin/env python3
"""
COBOL to Docs v1.0 - Sistema Técnico Aprimorado
Sistema de análise técnica COBOL com foco em objetividade e precisão
"""

import os
import sys
import json
import yaml
import logging
import argparse
from datetime import datetime
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from analyzers.technical_cobol_analyzer import TechnicalCobolAnalyzer
from generators.technical_documentation_generator import TechnicalDocumentationGenerator
from rag.enhanced_technical_rag import EnhancedTechnicalRAG
from providers.luzia_provider import LuziaProvider
from core.prompt_manager_dual import PromptManagerDual

class TechnicalCobolAnalysisSystem:
    """
    Sistema de análise técnica COBOL aprimorado.
    Elimina linguagem humanizada e foca em aspectos técnicos mensuráveis.
    """
    
    def __init__(self, config_path: str = None):
        """Inicializa o sistema técnico"""
        
        # Configurar logging
        self._setup_logging()
        self.logger = logging.getLogger(__name__)
        
        # Carregar configuração
        self.config = self._load_config(config_path)
        
        # Inicializar componentes
        self.technical_analyzer = TechnicalCobolAnalyzer(self.config)
        self.doc_generator = TechnicalDocumentationGenerator(self.config)
        self.technical_rag = EnhancedTechnicalRAG(self.config)
        
        # Inicializar provider LuzIA se configurado
        self.luzia_provider = None
        if self.config.get('providers', {}).get('luzia', {}).get('enabled', False):
            try:
                self.luzia_provider = LuziaProvider(self.config)
                self.logger.info("LuzIA Provider inicializado com sucesso")
            except Exception as e:
                self.logger.warning(f"Erro ao inicializar LuzIA Provider: {e}")
        
        # Inicializar gerenciador de prompts técnicos
        self.prompt_manager = PromptManagerDual(self.config)
        
        self.logger.info("Sistema Técnico COBOL inicializado")
    
    def _setup_logging(self):
        """Configura sistema de logging"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler('logs/technical_analysis.log', encoding='utf-8')
            ]
        )
        
        # Criar diretório de logs se não existir
        os.makedirs('logs', exist_ok=True)
    
    def _load_config(self, config_path: str = None) -> dict:
        """Carrega configuração do sistema"""
        if config_path is None:
            config_path = 'config/config.yaml'
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            # Configurações específicas para análise técnica
            config.setdefault('technical_analysis', {
                'focus_mode': 'technical_precision',
                'eliminate_humanized_language': True,
                'focus_on_measurable_aspects': True,
                'use_technical_terminology_only': True
            })
            
            return config
            
        except Exception as e:
            print(f"Erro ao carregar configuração: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> dict:
        """Retorna configuração padrão"""
        return {
            'technical_analysis': {
                'focus_mode': 'technical_precision',
                'eliminate_humanized_language': True,
                'focus_on_measurable_aspects': True,
                'use_technical_terminology_only': True
            },
            'rag': {
                'technical_knowledge_base': 'data/cobol_knowledge_base_tecnico_cadoc.json',
                'max_technical_items': 8,
                'technical_threshold': 0.8
            },
            'providers': {
                'luzia': {
                    'enabled': False
                }
            }
        }
    
    def analyze_cobol_program(self, cobol_file_path: str, output_dir: str = None, 
                            analysis_type: str = "comprehensive") -> dict:
        """
        Realiza análise técnica completa de um programa COBOL.
        
        Args:
            cobol_file_path: Caminho para o arquivo COBOL
            output_dir: Diretório de saída (opcional)
            analysis_type: Tipo de análise (comprehensive, dependencies, performance, business_rules)
            
        Returns:
            Resultado da análise técnica
        """
        try:
            self.logger.info(f"Iniciando análise técnica: {cobol_file_path}")
            
            # Ler código COBOL
            with open(cobol_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                cobol_code = f.read()
            
            program_name = Path(cobol_file_path).stem
            
            # Obter contexto técnico RAG
            technical_context = self.technical_rag.get_technical_context(cobol_code, analysis_type)
            
            # Realizar análise técnica local
            local_analysis = self.technical_analyzer.analyze_program(cobol_code, program_name)
            
            # Enriquecer análise com LuzIA se disponível
            enhanced_analysis = local_analysis
            if self.luzia_provider and self.config.get('technical_analysis', {}).get('use_luzia_enhancement', False):
                try:
                    enhanced_analysis = self._enhance_with_luzia(cobol_code, local_analysis, technical_context)
                except Exception as e:
                    self.logger.warning(f"Erro ao enriquecer com LuzIA: {e}")
            
            # Gerar documentação técnica
            if output_dir:
                output_path = os.path.join(output_dir, f"{program_name}_analise_tecnica.md")
                documentation = self.doc_generator.generate_technical_documentation(enhanced_analysis, output_path)
            else:
                documentation = self.doc_generator.generate_technical_documentation(enhanced_analysis)
            
            # Preparar resultado
            result = {
                'program_name': program_name,
                'analysis_result': enhanced_analysis,
                'documentation': documentation,
                'technical_context': technical_context,
                'analysis_timestamp': datetime.now().isoformat(),
                'analysis_type': analysis_type
            }
            
            self.logger.info(f"Análise técnica concluída: {program_name}")
            return result
            
        except Exception as e:
            self.logger.error(f"Erro na análise técnica: {e}")
            raise
    
    def _enhance_with_luzia(self, cobol_code: str, local_analysis, technical_context: dict):
        """Enriquece análise local com LuzIA usando prompts técnicos"""
        try:
            # Preparar prompt técnico
            technical_prompt = self._prepare_technical_prompt(cobol_code, local_analysis, technical_context)
            
            # Fazer requisição para LuzIA
            luzia_response = self.luzia_provider.analyze_code(
                code=cobol_code,
                prompt=technical_prompt,
                model="claude-3-5-sonnet-20241022"  # Usar modelo mais técnico
            )
            
            # Integrar resposta LuzIA com análise local
            enhanced_analysis = self._integrate_luzia_response(local_analysis, luzia_response)
            
            return enhanced_analysis
            
        except Exception as e:
            self.logger.error(f"Erro ao enriquecer com LuzIA: {e}")
            return local_analysis
    
    def _prepare_technical_prompt(self, cobol_code: str, local_analysis, technical_context: dict) -> str:
        """Prepara prompt técnico para LuzIA"""
        
        # Carregar prompt técnico especialista
        technical_prompts = self.prompt_manager.load_prompts('config/prompts_tecnico_especialista.yaml')
        
        # Contexto técnico do RAG
        rag_context = ""
        if technical_context.get('relevant_knowledge'):
            rag_context = "\\n\\nCONTEXTO TÉCNICO RELEVANTE:\\n"
            for item in technical_context['relevant_knowledge'][:5]:
                knowledge_item = item['item']
                rag_context += f"- {knowledge_item.title}: {knowledge_item.content}\\n"
        
        # Diretrizes técnicas
        guidelines = "\\n".join(technical_context.get('technical_guidelines', []))
        
        # Focos de análise
        focus_areas = "\\n".join(technical_context.get('analysis_focus', []))
        
        # Construir prompt técnico
        technical_prompt = f"""
{technical_prompts.get('system_prompt', '')}

{technical_prompts.get('main_prompt', '')}

DIRETRIZES ESPECÍFICAS:
{guidelines}

FOCOS DE ANÁLISE:
{focus_areas}

{rag_context}

IMPORTANTE:
- Use APENAS terminologia técnica COBOL
- Seja objetivo e mensurável
- Evite linguagem humanizada
- Documente apenas o que está no código
- Foque em aspectos técnicos verificáveis

CÓDIGO PARA ANÁLISE:
{cobol_code}
"""
        
        return technical_prompt
    
    def _integrate_luzia_response(self, local_analysis, luzia_response):
        """Integra resposta LuzIA com análise local"""
        
        # Por enquanto, manter análise local como base
        # Em versões futuras, pode-se integrar insights específicos da LuzIA
        enhanced_analysis = local_analysis
        
        # Adicionar metadados da LuzIA
        if hasattr(enhanced_analysis, '__dict__'):
            enhanced_analysis.luzia_enhancement = {
                'enhanced': True,
                'luzia_response_available': bool(luzia_response),
                'enhancement_timestamp': datetime.now().isoformat()
            }
        
        return enhanced_analysis
    
    def analyze_multiple_programs(self, input_dir: str, output_dir: str = None, 
                                file_pattern: str = "*.cbl") -> dict:
        """
        Analisa múltiplos programas COBOL em um diretório.
        
        Args:
            input_dir: Diretório com arquivos COBOL
            output_dir: Diretório de saída
            file_pattern: Padrão de arquivos (*.cbl, *.cob, etc.)
            
        Returns:
            Resultados consolidados das análises
        """
        try:
            input_path = Path(input_dir)
            cobol_files = list(input_path.glob(file_pattern))
            
            if not cobol_files:
                raise ValueError(f"Nenhum arquivo encontrado com padrão {file_pattern} em {input_dir}")
            
            results = {}
            
            for cobol_file in cobol_files:
                try:
                    result = self.analyze_cobol_program(str(cobol_file), output_dir)
                    results[cobol_file.stem] = result
                    self.logger.info(f"Programa analisado: {cobol_file.name}")
                except Exception as e:
                    self.logger.error(f"Erro ao analisar {cobol_file.name}: {e}")
                    results[cobol_file.stem] = {'error': str(e)}
            
            # Gerar relatório consolidado
            if output_dir:
                self._generate_consolidated_report(results, output_dir)
            
            return results
            
        except Exception as e:
            self.logger.error(f"Erro na análise múltipla: {e}")
            raise
    
    def _generate_consolidated_report(self, results: dict, output_dir: str):
        """Gera relatório consolidado das análises"""
        try:
            report_path = os.path.join(output_dir, "relatorio_consolidado_tecnico.md")
            
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write("# Relatório Consolidado - Análise Técnica COBOL\\n\\n")
                f.write(f"**Data:** {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\\n")
                f.write(f"**Programas Analisados:** {len(results)}\\n\\n")
                
                # Resumo executivo
                f.write("## Resumo Executivo\\n\\n")
                
                successful_analyses = [r for r in results.values() if 'error' not in r]
                failed_analyses = [r for r in results.values() if 'error' in r]
                
                f.write(f"- **Análises Bem-sucedidas:** {len(successful_analyses)}\\n")
                f.write(f"- **Análises com Erro:** {len(failed_analyses)}\\n\\n")
                
                if successful_analyses:
                    # Métricas consolidadas
                    f.write("## Métricas Consolidadas\\n\\n")
                    
                    total_lines = sum([r['analysis_result'].technical_metrics['effective_lines'] 
                                     for r in successful_analyses])
                    avg_complexity = sum([r['analysis_result'].quality_metrics['cyclomatic_complexity'] 
                                        for r in successful_analyses]) / len(successful_analyses)
                    
                    f.write(f"- **Total de Linhas Efetivas:** {total_lines:,}\\n")
                    f.write(f"- **Complexidade Média:** {avg_complexity:.1f}\\n\\n")
                
                # Lista de programas
                f.write("## Programas Analisados\\n\\n")
                f.write("| Programa | Status | Complexidade | Linhas | Qualidade |\\n")
                f.write("|----------|--------|--------------|--------|-----------|\\n")
                
                for program_name, result in results.items():
                    if 'error' in result:
                        f.write(f"| {program_name} | ERRO | - | - | - |\\n")
                    else:
                        analysis = result['analysis_result']
                        complexity = analysis.quality_metrics['cyclomatic_complexity']
                        lines = analysis.technical_metrics['effective_lines']
                        quality = analysis.quality_metrics['quality_score']['quality_level']
                        f.write(f"| {program_name} | OK | {complexity} | {lines} | {quality} |\\n")
            
            self.logger.info(f"Relatório consolidado gerado: {report_path}")
            
        except Exception as e:
            self.logger.error(f"Erro ao gerar relatório consolidado: {e}")

def main():
    """Função principal do sistema técnico"""
    parser = argparse.ArgumentParser(description='COBOL to Docs - Sistema Técnico v1.0')
    parser.add_argument('input', help='Arquivo COBOL ou diretório de entrada')
    parser.add_argument('-o', '--output', help='Diretório de saída')
    parser.add_argument('-c', '--config', help='Arquivo de configuração')
    parser.add_argument('-t', '--type', choices=['comprehensive', 'dependencies', 'performance', 'business_rules'],
                       default='comprehensive', help='Tipo de análise')
    parser.add_argument('-p', '--pattern', default='*.cbl', help='Padrão de arquivos (para diretórios)')
    parser.add_argument('--luzia', action='store_true', help='Usar enriquecimento LuzIA')
    
    args = parser.parse_args()
    
    try:
        # Inicializar sistema
        system = TechnicalCobolAnalysisSystem(args.config)
        
        # Configurar uso do LuzIA
        if args.luzia:
            system.config.setdefault('technical_analysis', {})['use_luzia_enhancement'] = True
        
        # Determinar se é arquivo ou diretório
        input_path = Path(args.input)
        
        if input_path.is_file():
            # Análise de arquivo único
            result = system.analyze_cobol_program(str(input_path), args.output, args.type)
            print(f"\\nAnálise concluída: {result['program_name']}")
            
            if args.output:
                print(f"Documentação salva em: {args.output}")
            
        elif input_path.is_dir():
            # Análise de múltiplos arquivos
            results = system.analyze_multiple_programs(str(input_path), args.output, args.pattern)
            print(f"\\nAnálise concluída: {len(results)} programas processados")
            
            successful = len([r for r in results.values() if 'error' not in r])
            failed = len(results) - successful
            
            print(f"Sucessos: {successful}, Falhas: {failed}")
            
            if args.output:
                print(f"Resultados salvos em: {args.output}")
        
        else:
            print(f"Erro: Caminho não encontrado: {args.input}")
            sys.exit(1)
    
    except Exception as e:
        print(f"Erro: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
