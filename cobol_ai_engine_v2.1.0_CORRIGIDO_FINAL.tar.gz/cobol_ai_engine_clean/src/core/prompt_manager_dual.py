"""
COBOL AI Engine v2.1.0 - Dual Prompt Manager
Gerenciador de prompts que suporta múltiplos padrões de análise com arquivos separados.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime
import yaml
import os

class DualPromptManager:
    """
    Gerenciador de prompts que suporta múltiplos padrões de análise:
    - original: Análise técnica tradicional (prompts_original.yaml)
    - doc_legado_pro: Documentação sistêmica especializada (prompts_doc_legado_pro.yaml)
    """
    
    def __init__(self, config: Dict[str, Any], prompt_set: str = None):
        """
        Inicializa o gerenciador de prompts dual.
        
        Args:
            config: Configuração geral do sistema
            prompt_set: Nome do conjunto de prompts a usar ('original' ou 'doc_legado_pro')
        """
        self.logger = logging.getLogger(__name__)
        self.config = config
        
        # Definir conjunto de prompts ativo
        self.active_prompt_set = prompt_set or 'original'
        
        # Carregar configuração de prompts específica
        self.prompts_config = self._load_prompts_config()
        
        # Validar se carregou corretamente
        if not self.prompts_config or 'system_prompt' not in self.prompts_config:
            self.logger.error(f"Falha ao carregar prompts para {self.active_prompt_set}")
            self.active_prompt_set = 'original'
            self.prompts_config = self._load_prompts_config()
        
        self.logger.info(f"Dual Prompt Manager inicializado - Conjunto ativo: {self.active_prompt_set}")
    
    def _load_prompts_config(self) -> Dict[str, Any]:
        """Carrega a configuração de prompts do arquivo YAML específico."""
        # Mapear conjunto de prompts para arquivo
        prompt_files = {
            'original': 'config/prompts_original.yaml',
            'doc_legado_pro': 'config/prompts_doc_legado_pro.yaml'
        }
        
        # Usar arquivo específico do conjunto ativo
        prompts_file = prompt_files.get(self.active_prompt_set, 'config/prompts_original.yaml')
        
        # Fallback se arquivo não existir
        if not os.path.exists(prompts_file):
            self.logger.warning(f"Arquivo {prompts_file} não encontrado, usando fallback")
            prompts_file = 'config/prompts.yaml'
            if not os.path.exists(prompts_file):
                prompts_file = 'config/prompts_original.yaml'
        
        try:
            with open(prompts_file, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
                self.logger.info(f"Prompts carregados de: {prompts_file}")
                return config
        except Exception as e:
            self.logger.error(f"Erro ao carregar prompts de {prompts_file}: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Retorna configuração padrão em caso de erro."""
        return {
            'version': '2.1.0',
            'system_prompt': 'Você é um analista de sistemas COBOL especializado.',
            'analysis_questions': {
                'functional': {
                    'priority': 1,
                    'required': True,
                    'question': 'Forneça uma análise funcional do programa COBOL.'
                }
            }
        }
    
    def get_available_prompt_sets(self) -> List[Dict[str, str]]:
        """Retorna lista de conjuntos de prompts disponíveis."""
        return [
            {
                'name': 'original',
                'title': 'Análise Técnica Original',
                'description': 'Prompt original focado em análise técnica detalhada de COBOL'
            },
            {
                'name': 'doc_legado_pro',
                'title': 'DOC-LEGADO PRO',
                'description': 'Especialista em documentação sistêmica para código legado'
            }
        ]
    
    def switch_prompt_set(self, prompt_set: str) -> bool:
        """
        Alterna para um conjunto de prompts diferente.
        
        Args:
            prompt_set: Nome do conjunto de prompts
            
        Returns:
            True se a alternância foi bem-sucedida
        """
        available = [ps['name'] for ps in self.get_available_prompt_sets()]
        
        if prompt_set not in available:
            self.logger.error(f"Conjunto de prompts '{prompt_set}' não disponível. Disponíveis: {available}")
            return False
        
        self.active_prompt_set = prompt_set
        self.prompts_config = self._load_prompts_config()
        self.logger.info(f"Conjunto de prompts alterado para: {prompt_set}")
        return True
    
    def get_system_prompt(self, model_name: str = None) -> str:
        """
        Retorna o prompt de sistema para o modelo especificado.
        
        Args:
            model_name: Nome do modelo (opcional)
            
        Returns:
            Prompt de sistema
        """
        # Tentar prompt específico do modelo primeiro
        if model_name:
            model_prompts = self.prompts_config.get('model_prompts', {})
            if model_name in model_prompts:
                return model_prompts[model_name].get('system_prompt', '')
        
        # Fallback para prompt de sistema padrão
        return self.prompts_config.get('system_prompt', '')
    
    def get_analysis_questions(self) -> Dict[str, Any]:
        """Retorna as questões de análise do conjunto ativo."""
        return self.prompts_config.get('analysis_questions', {})
    
    def generate_base_prompt(self, program_name: str, program_code: str, context: Dict[str, Any] = None) -> str:
        """
        Gera o prompt base para análise do programa.
        
        Args:
            program_name: Nome do programa
            program_code: Código do programa
            context: Contexto adicional
            
        Returns:
            Prompt formatado
        """
        base_template = self.prompts_config.get('base_template', '')
        
        if not base_template:
            # Template padrão simples
            base_template = """
            Analise o seguinte programa COBOL:
            
            Nome: {program_name}
            Data: {timestamp}
            
            Código:
            {program_code}
            
            Forneça uma análise detalhada seguindo as questões específicas.
            """
        
        # Preparar contexto
        context_info = "Programa COBOL genérico"
        if context:
            books = context.get('books', [])
            if books:
                context_info += f" (com {len(books)} copybooks)"
        
        # Formatar template
        formatted_prompt = base_template.format(
            program_name=program_name,
            program_code=program_code,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            context_info=context_info
        )
        
        return formatted_prompt.strip()
    
    def get_context_template(self, program_type: str = 'default') -> str:
        """Retorna template de contexto para tipo de programa."""
        context_templates = self.prompts_config.get('context_templates', {})
        return context_templates.get(program_type, context_templates.get('default', 'Programa COBOL genérico'))
    
    def get_prompt_info(self) -> Dict[str, Any]:
        """Retorna informações sobre o conjunto de prompts ativo."""
        available_sets = self.get_available_prompt_sets()
        active_info = next((ps for ps in available_sets if ps['name'] == self.active_prompt_set), {})
        
        return {
            'active_set': self.active_prompt_set,
            'title': active_info.get('title', 'Desconhecido'),
            'description': active_info.get('description', ''),
            'version': self.prompts_config.get('version', '2.1.0'),
            'available_sets': available_sets
        }
    
    def validate_prompt_compatibility(self, model_name: str) -> bool:
        """
        Valida se o modelo é compatível com o conjunto de prompts ativo.
        
        Args:
            model_name: Nome do modelo
            
        Returns:
            True se compatível
        """
        # Verificar se há prompts específicos para o modelo
        model_prompts = self.prompts_config.get('model_prompts', {})
        
        # Se não há prompts específicos, usar o padrão (sempre compatível)
        if not model_prompts:
            return True
        
        # Se há prompts específicos, verificar se o modelo está incluído
        return model_name in model_prompts or 'system_prompt' in self.prompts_config
