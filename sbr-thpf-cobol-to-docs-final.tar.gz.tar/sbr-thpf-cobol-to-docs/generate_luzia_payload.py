
import sys
import os
import json
from pathlib import Path
from typing import Dict, Any

# Adjust sys.path to include the project root for imports
script_dir = Path(__file__).parent
project_root = script_dir
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / 'cobol_to_docs'))
sys.path.insert(0, str(project_root / 'cobol_to_docs' / 'src'))

from cobol_to_docs.src.providers.luzia_provider import LuziaProvider
from cobol_to_docs.src.providers.base_provider import AIRequest

# Mock ConfigManager and its config for testing purposes
class MockConfigManager:
    def __init__(self, config_data: Dict[str, Any]):
        self._config = config_data

    def get_config(self) -> Dict[str, Any]:
        return self._config

# Dummy config for LuziaProvider initialization
dummy_config = {
    "providers": {
        "luzia": {
            "client_id": "dummy_client_id",
            "client_secret": "dummy_client_secret",
            "auth_url": "https://login.azure.paas.santanderbr.pre.corp/auth/realms/corp/protocol/openid-connect/token",
            "api_url": "https://gut-api-aws.santanderbr.pre.corp/genai_services/v1/",
            "models": {
                "default": {
                    "name": "aws-claude-3-5-sonnet",
                    "max_tokens": 8192,
                    "temperature": 0.1,
                    "timeout": 120,
                    "context_window": 200000
                }
            }
        }
    }
}

mock_config_manager = MockConfigManager(dummy_config)

def generate_luzia_payload_example():
    # Create a dummy AIRequest object
    sample_prompt = """
=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===
       IDENTIFICATION DIVISION.
       PROGRAM-ID. SAMPLE-PROG.
       PROCEDURE DIVISION.
           DISPLAY 'HELLO WORLD'.
           STOP RUN.
"""
    ai_request = AIRequest(
        prompt=sample_prompt,
        temperature=0.1,
        max_tokens=8192,
        model="aws-claude-3-5-sonnet"
    )

    # Initialize LuziaProvider
    luzia_provider = LuziaProvider(mock_config_manager.get_config())
    
    # Mock the _ensure_valid_token method to avoid actual API calls
    def mock_ensure_valid_token(self):
        self._token = "mock_access_token"
        self._token_expires_at = float('inf') # Never expires for test
    luzia_provider._ensure_valid_token = mock_ensure_valid_token.__get__(luzia_provider, LuziaProvider)

    # Call the analyze method to get the payload (it will return AIResponse, but we can inspect the payload)
    # To get the actual payload, we need to temporarily modify the analyze method or extract it before the request.
    # For this example, we'll simulate the payload construction directly.

    # Simulate payload construction from analyze method
    system_prompt = """Você é um analista de sistemas COBOL especializado.\nSua tarefa é realizar uma análise detalhada e técnica do programa COBOL fornecido.\nResponda sempre em português brasileiro.\nForneça análises precisas e detalhadas sobre estrutura, lógica de negócio e aspectos técnicos."""
    user_prompt = sample_prompt.split("=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===")[1].strip()

    model_config = luzia_provider.get_model_config(ai_request.model)
    temperature = model_config.get('temperature', ai_request.temperature)
    max_tokens = model_config.get('max_tokens', ai_request.max_tokens)

    payload = {
        "input": {
            "query": [
                {
                    "role": "system",
                    "content": system_prompt
                },
                {
                    "role": "user", 
                    "content": user_prompt
                }
            ]
        },
        "config": [
            {
                "type": "catena.llm.LLMRouter",
                "obj_kwargs": {
                    "routing_model": luzia_provider.model,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                    "system_prompt": "Responda sempre em português brasileiro com análises técnicas detalhadas"
                }
            }
        ]
    }

    print(json.dumps(payload, indent=4, ensure_ascii=False))

if __name__ == "__main__":
    generate_luzia_payload_example()

