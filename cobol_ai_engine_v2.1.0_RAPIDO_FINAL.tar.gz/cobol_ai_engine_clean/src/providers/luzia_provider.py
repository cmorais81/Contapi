"""
LuziaProvider Simplificado - Foco na correção do Authorization header
"""

import os
import json
import logging
import re
import time
import warnings
import requests
import base64
from datetime import datetime
from typing import Dict, Any, Optional, List
from urllib3.exceptions import InsecureRequestWarning

# Suprimir warnings de SSL
warnings.filterwarnings('ignore', message='Unverified HTTPS request')
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

class LuziaProvider:
    def __init__(self, config: Dict[str, Any]):
        self.logger = logging.getLogger('LuziaProvider')
        
        # Configurações da API
        self.client_id = config.get('client_id') or os.getenv('LUZIA_CLIENT_ID')
        self.client_secret = config.get('client_secret') or os.getenv('LUZIA_CLIENT_SECRET')
        self.base_url = config.get('base_url', 'https://gut-api-aws.santanderbr.dev.corp/genai_services/v1/pipelines/submit')
        self.auth_url = config.get('auth_url', 'https://login.azure.paas.santanderbr.pre.corp/auth/realms/santander/protocol/openid-connect/token')
        
        # Configurações de retry (reduzidas para evitar travamento)
        self.max_retries = config.get('max_retries', 1)  # Apenas 1 tentativa por abordagem
        self.timeout = config.get('timeout', 5)  # Timeout de 5 segundos
        
        # Token management
        self._token = None
        self._token_expires_at = None
        
        self.logger.info("LuziaProvider inicializado")

    def get_token(self):
        """Obter token OAuth2"""
        try:
            data = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            response = requests.post(
                self.auth_url,
                data=data,
                verify=False,
                timeout=5  # Timeout fixo de 5s para token
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self._token = token_data.get('access_token')
                expires_in = token_data.get('expires_in', 3600)
                self._token_expires_at = time.time() + expires_in - 60  # 60s buffer
                
                self.logger.info(f"Token OAuth2 obtido com sucesso (expira em {expires_in}s)")
                return self._token
            else:
                raise Exception(f"Erro HTTP {response.status_code}: {response.text}")
                
        except Exception as e:
            self.logger.error(f"Erro ao obter token: {e}")
            raise

    def _ensure_valid_token(self):
        """Garantir que temos um token válido"""
        if not self._token or (self._token_expires_at and time.time() >= self._token_expires_at):
            self.logger.info("Token expirado ou inexistente, renovando...")
            self.get_token()

    def analyze(self, prompt: str, request: Dict[str, Any]) -> Dict[str, Any]:
        """Analisar com múltiplas abordagens de autenticação"""
        
        # Garantir token válido
        self._ensure_valid_token()
        
        # Limpar token
        clean_token = self._token.strip().strip("'\"")
        
        # Dividir prompt
        if "=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===" in prompt:
            parts = prompt.split("=== PROGRAMA COBOL PARA ANÁLISE APROFUNDADA ===")
            system_prompt = parts[0].strip()
            user_prompt = parts[1].strip() if len(parts) > 1 else ""
        else:
            system_prompt = "Você é um analista de sistemas COBOL especializado."
            user_prompt = prompt
        
        # Criar payload base
        base_payload = {
            "input": {
                "query": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ]
            },
            "config": {
                "configurable": {
                    "model_name": "azure-gpt-4o-mini"
                }
            }
        }
        
        # Log do payload
        self.logger.info(f"=== PAYLOAD PARA LUZIA ===")
        self.logger.info(f"System prompt: {len(system_prompt)} chars")
        self.logger.info(f"User prompt: {len(user_prompt)} chars")
        
        # Definir abordagens de autenticação
        approaches = []
        
        # Se token tem caracteres problemáticos, usar abordagens alternativas
        if any(char in clean_token for char in ['+', '/', '=']):
            self.logger.warning("Token contém caracteres problemáticos: +, /, =")
            
            # ABORDAGEM 1: Basic Authentication
            basic_auth = base64.b64encode(f"token:{clean_token}".encode()).decode()
            approaches.append({
                'name': 'Basic Authentication',
                'headers': {
                    'Content-Type': 'application/json',
                    'Authorization': f'Basic {basic_auth}',
                    'Accept': 'application/json'
                },
                'payload': base_payload
            })
            
            # ABORDAGEM 2: Token no corpo
            approaches.append({
                'name': 'Token no corpo',
                'headers': {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                'payload': {
                    **base_payload,
                    'authorization': {
                        'type': 'Bearer',
                        'token': clean_token
                    }
                }
            })
            
            # ABORDAGEM 3: Bearer URL-safe
            safe_token = clean_token.replace('+', '-').replace('/', '_').replace('=', '')
            approaches.append({
                'name': 'Bearer URL-safe',
                'headers': {
                    'Content-Type': 'application/json',
                    'Authorization': f'Bearer {safe_token}',
                    'Accept': 'application/json'
                },
                'payload': base_payload
            })
        else:
            # Token limpo - usar Bearer tradicional
            approaches.append({
                'name': 'Bearer tradicional',
                'headers': {
                    'Content-Type': 'application/json',
                    'Authorization': f'Bearer {clean_token}',
                    'Accept': 'application/json'
                },
                'payload': base_payload
            })
        
        # Tentar cada abordagem (UMA VEZ APENAS)
        for i, approach in enumerate(approaches):
            self.logger.info(f"🔄 Tentando abordagem {i+1}/{len(approaches)}: {approach['name']}")
            
            try:
                # UMA tentativa apenas com timeout curto
                response = requests.post(
                    self.base_url,
                    headers=approach['headers'],
                    json=approach['payload'],
                    verify=False,
                    timeout=3  # Timeout de apenas 3 segundos
                )
                
                self.logger.info(f"Status: {response.status_code}")
                
                if response.status_code in [200, 201]:
                    self.logger.info(f"✅ SUCESSO com {approach['name']}!")
                    return response.json()
                elif response.status_code == 403:
                    self.logger.warning(f"❌ Erro 403 com {approach['name']}")
                    # Continuar para próxima abordagem imediatamente
                    continue
                else:
                    self.logger.warning(f"❌ Erro {response.status_code} com {approach['name']}")
                    # Continuar para próxima abordagem imediatamente
                    continue
                    
            except requests.exceptions.Timeout:
                self.logger.warning(f"⏰ Timeout (3s) com {approach['name']}")
                continue
            except Exception as e:
                self.logger.warning(f"❌ Exceção com {approach['name']}: {str(e)[:100]}")
                continue
        
        # Se chegou aqui, todas as abordagens falharam
        raise Exception("Todas as abordagens de autenticação falharam")

    def is_available(self) -> bool:
        """Verificar se o provider está disponível"""
        try:
            self._ensure_valid_token()
            return True
        except:
            return False
