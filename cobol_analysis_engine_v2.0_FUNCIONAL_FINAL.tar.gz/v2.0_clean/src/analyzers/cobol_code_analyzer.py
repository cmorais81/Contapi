"""
Sistema de Análise COBOL v2.1.8 - Analisador Detalhado de Código COBOL
Módulo responsável por fazer pré-análise estrutural e extração de informações do código COBOL.
"""

import re
import logging
from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass
from datetime import datetime


@dataclass
class CobolStructure:
    """Estrutura identificada no código COBOL."""
    divisions: List[str]
    sections: List[str]
    paragraphs: List[str]
    files: List[str]
    copybooks: List[str]
    variables: List[str]


@dataclass
class BusinessRule:
    """Regra de negócio identificada no código."""
    type: str  # 'regulatory', 'validation', 'calculation', 'control'
    description: str
    location: str  # linha ou seção onde foi encontrada
    context: str
    references: List[str]  # referências a leis, normas, etc.


@dataclass
class CommentAnalysis:
    """Análise dos comentários do código."""
    total_comments: int
    business_comments: List[str]
    technical_comments: List[str]
    regulatory_references: List[str]
    operation_codes: List[str]
    product_codes: List[str]


@dataclass
class CodeMetrics:
    """Métricas do código analisado."""
    total_lines: int
    code_lines: int
    comment_lines: int
    blank_lines: int
    complexity_score: int
    maintainability_index: float


@dataclass
class CobolAnalysisResult:
    """Resultado completo da análise do código COBOL."""
    program_name: str
    analysis_timestamp: datetime
    structure: CobolStructure
    business_rules: List[BusinessRule]
    comments: CommentAnalysis
    metrics: CodeMetrics
    regulatory_context: Dict[str, Any]
    quality_assessment: Dict[str, Any]


class COBOLCodeAnalyzer:
    """
    Analisador avançado de código COBOL que faz pré-análise estrutural
    e extração detalhada de informações de negócio.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Padrões para identificação de elementos COBOL
        self.division_patterns = {
            'identification': r'^\s*IDENTIFICATION\s+DIVISION',
            'environment': r'^\s*ENVIRONMENT\s+DIVISION',
            'data': r'^\s*DATA\s+DIVISION',
            'procedure': r'^\s*PROCEDURE\s+DIVISION'
        }
        
        self.section_patterns = {
            'file': r'^\s*FILE\s+SECTION',
            'working_storage': r'^\s*WORKING-STORAGE\s+SECTION',
            'linkage': r'^\s*LINKAGE\s+SECTION',
            'local_storage': r'^\s*LOCAL-STORAGE\s+SECTION'
        }
        
        # Padrões para identificação de regras de negócio
        self.regulatory_patterns = {
            'lei': r'LEI\s+\d+',
            'circular': r'CIRCULAR\s+\d+',
            'resolucao': r'RESOLUÇÃO\s+\d+',
            'instrucao': r'INSTRUÇÃO\s+\d+',
            'pronampe': r'PRONAMPE',
            'fgi': r'FGI',
            'peac': r'PEAC',
            'bacen': r'BACEN|BANCO\s+CENTRAL',
            'cvm': r'CVM',
            'susep': r'SUSEP'
        }
        
        self.business_patterns = {
            'operacao': r'OPERAÇÃO|OPERACAO',
            'produto': r'PRODUTO\s+\d+',
            'conta': r'CONTA\s+\d+',
            'agencia': r'AGÊNCIA|AGENCIA\s+\d+',
            'cliente': r'CLIENTE\s+\d+',
            'contrato': r'CONTRATO\s+\d+',
            'limite': r'LIMITE\s+\d+',
            'taxa': r'TAXA\s+\d+',
            'percentual': r'PERCENTUAL\s+\d+',
            'valor': r'VALOR\s+\d+'
        }
    
    def analyze_program(self, code: str, program_name: str) -> CobolAnalysisResult:
        """
        Realiza análise completa do programa COBOL.
        
        Args:
            code: Código fonte do programa COBOL
            program_name: Nome do programa
            
        Returns:
            CobolAnalysisResult: Resultado completo da análise
        """
        self.logger.info(f"Iniciando análise detalhada do programa {program_name}")
        
        lines = code.split('\n')
        
        # Análise estrutural
        structure = self._analyze_structure(lines)
        
        # Análise de comentários
        comments = self._analyze_comments(lines)
        
        # Extração de regras de negócio
        business_rules = self._extract_business_rules(lines, comments)
        
        # Cálculo de métricas
        metrics = self._calculate_metrics(lines)
        
        # Análise de contexto regulatório
        regulatory_context = self._analyze_regulatory_context(comments, business_rules)
        
        # Avaliação de qualidade
        quality_assessment = self._assess_quality(structure, comments, metrics)
        
        result = CobolAnalysisResult(
            program_name=program_name,
            analysis_timestamp=datetime.now(),
            structure=structure,
            business_rules=business_rules,
            comments=comments,
            metrics=metrics,
            regulatory_context=regulatory_context,
            quality_assessment=quality_assessment
        )
        
        self.logger.info(f"Análise concluída: {len(business_rules)} regras de negócio identificadas")
        return result
    
    def _analyze_structure(self, lines: List[str]) -> CobolStructure:
        """Analisa a estrutura do programa COBOL."""
        divisions = []
        sections = []
        paragraphs = []
        files = []
        copybooks = []
        variables = []
        
        for line in lines:
            line_upper = line.upper().strip()
            
            # Identificar divisões
            for div_name, pattern in self.division_patterns.items():
                if re.search(pattern, line_upper):
                    divisions.append(div_name)
            
            # Identificar seções
            for sec_name, pattern in self.section_patterns.items():
                if re.search(pattern, line_upper):
                    sections.append(sec_name)
            
            # Identificar parágrafos
            if re.match(r'^\s*[A-Z0-9-]+\s*\.$', line_upper):
                paragraphs.append(line.strip())
            
            # Identificar arquivos
            if 'SELECT' in line_upper and 'ASSIGN' in line_upper:
                file_match = re.search(r'SELECT\s+([A-Z0-9-]+)', line_upper)
                if file_match:
                    files.append(file_match.group(1))
            
            # Identificar copybooks
            if 'COPY' in line_upper:
                copy_match = re.search(r'COPY\s+([A-Z0-9-]+)', line_upper)
                if copy_match:
                    copybooks.append(copy_match.group(1))
            
            # Identificar variáveis principais
            if re.match(r'^\s*\d+\s+[A-Z0-9-]+', line_upper):
                var_match = re.search(r'\d+\s+([A-Z0-9-]+)', line_upper)
                if var_match:
                    variables.append(var_match.group(1))
        
        return CobolStructure(
            divisions=list(set(divisions)),
            sections=list(set(sections)),
            paragraphs=paragraphs[:20],  # Limitar para os primeiros 20
            files=list(set(files)),
            copybooks=list(set(copybooks)),
            variables=list(set(variables))[:50]  # Limitar para as primeiras 50
        )
    
    def _analyze_comments(self, lines: List[str]) -> CommentAnalysis:
        """Analisa os comentários do código."""
        business_comments = []
        technical_comments = []
        regulatory_references = []
        operation_codes = []
        product_codes = []
        total_comments = 0
        
        for line in lines:
            # Identificar linhas de comentário
            if line.strip().startswith('*') or line.strip().startswith('C'):
                total_comments += 1
                comment_text = line.strip()[1:].strip()
                
                # Classificar tipo de comentário
                if self._is_business_comment(comment_text):
                    business_comments.append(comment_text)
                else:
                    technical_comments.append(comment_text)
                
                # Extrair referências regulatórias
                for reg_type, pattern in self.regulatory_patterns.items():
                    matches = re.findall(pattern, comment_text.upper())
                    regulatory_references.extend(matches)
                
                # Extrair códigos de operação e produto
                op_matches = re.findall(r'OPERAÇÃO\s+(\d+)', comment_text.upper())
                operation_codes.extend(op_matches)
                
                prod_matches = re.findall(r'PRODUTO\s+(\d+)', comment_text.upper())
                product_codes.extend(prod_matches)
        
        return CommentAnalysis(
            total_comments=total_comments,
            business_comments=business_comments,
            technical_comments=technical_comments,
            regulatory_references=list(set(regulatory_references)),
            operation_codes=list(set(operation_codes)),
            product_codes=list(set(product_codes))
        )
    
    def _is_business_comment(self, comment: str) -> bool:
        """Determina se um comentário é relacionado a negócio."""
        business_keywords = [
            'OBJETIVO', 'FUNCIONALIDADE', 'REGRA', 'VALIDAÇÃO', 'CONTROLE',
            'OPERAÇÃO', 'PRODUTO', 'CLIENTE', 'CONTA', 'LIMITE', 'TAXA',
            'REGULAMENTAÇÃO', 'COMPLIANCE', 'AUDITORIA', 'RISCO',
            'BACEN', 'PRONAMPE', 'FGI', 'PEAC', 'LEI', 'CIRCULAR'
        ]
        
        comment_upper = comment.upper()
        return any(keyword in comment_upper for keyword in business_keywords)
    
    def _extract_business_rules(self, lines: List[str], comments: CommentAnalysis) -> List[BusinessRule]:
        """Extrai regras de negócio do código com descrições detalhadas."""
        business_rules = []
        
        # Regras extraídas dos comentários
        for comment in comments.business_comments:
            if any(ref in comment.upper() for ref in comments.regulatory_references):
                rule = BusinessRule(
                    type='regulatory',
                    description=f"Regra regulatória: {comment}",
                    location='comentário',
                    context='regulamentação',
                    references=comments.regulatory_references
                )
                business_rules.append(rule)
        
        # Regras extraídas do código com análise detalhada
        for i, line in enumerate(lines):
            line_upper = line.upper().strip()
            line_clean = line.strip()
            
            # Identificar validações com contexto
            if 'IF' in line_upper:
                condition_context = self._analyze_condition_context(line_clean, lines, i)
                rule = BusinessRule(
                    type='validation',
                    description=f"Validação condicional: {condition_context['description']}",
                    location=f"linha {i+1}",
                    context=condition_context['business_context'],
                    references=condition_context['related_fields']
                )
                business_rules.append(rule)
            
            # Identificar cálculos com propósito
            if any(op in line_upper for op in ['COMPUTE', 'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE']):
                calc_context = self._analyze_calculation_context(line_clean, lines, i)
                rule = BusinessRule(
                    type='calculation',
                    description=f"Cálculo de negócio: {calc_context['description']}",
                    location=f"linha {i+1}",
                    context=calc_context['business_purpose'],
                    references=calc_context['variables_involved']
                )
                business_rules.append(rule)
            
            # Identificar movimentações de dados importantes
            if 'MOVE' in line_upper and any(keyword in line_upper for keyword in ['VALOR', 'SALDO', 'TAXA', 'LIMITE', 'CONTA']):
                move_context = self._analyze_move_context(line_clean, lines, i)
                rule = BusinessRule(
                    type='data_transformation',
                    description=f"Transformação de dados: {move_context['description']}",
                    location=f"linha {i+1}",
                    context=move_context['business_impact'],
                    references=move_context['fields_affected']
                )
                business_rules.append(rule)
            
            # Identificar operações de arquivo
            if any(op in line_upper for op in ['READ', 'WRITE', 'REWRITE', 'DELETE']):
                file_context = self._analyze_file_operation_context(line_clean, lines, i)
                rule = BusinessRule(
                    type='data_processing',
                    description=f"Operação de dados: {file_context['description']}",
                    location=f"linha {i+1}",
                    context=file_context['business_operation'],
                    references=file_context['files_involved']
                )
                business_rules.append(rule)
            
            # Identificar chamadas de programa
            if 'CALL' in line_upper:
                call_context = self._analyze_call_context(line_clean, lines, i)
                rule = BusinessRule(
                    type='integration',
                    description=f"Integração com sistema: {call_context['description']}",
                    location=f"linha {i+1}",
                    context=call_context['integration_purpose'],
                    references=call_context['programs_called']
                )
                business_rules.append(rule)
        
        return business_rules
    
    def _analyze_condition_context(self, line: str, lines: List[str], line_index: int) -> Dict[str, Any]:
        """Analisa o contexto de uma condição IF para extrair significado de negócio."""
        context = {
            'description': 'Condição não identificada',
            'business_context': 'validação geral',
            'related_fields': []
        }
        
        line_upper = line.upper()
        
        # Extrair campos mencionados na condição
        fields = re.findall(r'[A-Z][A-Z0-9-]*', line_upper)
        context['related_fields'] = fields[:5]  # Limitar a 5 campos
        
        # Identificar tipo de validação baseado em palavras-chave
        if any(word in line_upper for word in ['ZERO', 'ZEROS', 'SPACE', 'SPACES']):
            context['description'] = 'Validação de campos vazios ou nulos'
            context['business_context'] = 'controle de qualidade de dados'
        elif any(word in line_upper for word in ['EQUAL', '=', 'NOT EQUAL', 'NOT =']):
            context['description'] = 'Comparação de valores para validação'
            context['business_context'] = 'verificação de consistência'
        elif any(word in line_upper for word in ['GREATER', '>', 'LESS', '<']):
            context['description'] = 'Validação de limites ou faixas de valores'
            context['business_context'] = 'controle de limites de negócio'
        elif any(word in line_upper for word in ['NUMERIC', 'ALPHABETIC']):
            context['description'] = 'Validação de formato de dados'
            context['business_context'] = 'controle de integridade de dados'
        else:
            context['description'] = f"Condição de negócio: {line[:50]}..."
            context['business_context'] = 'lógica de negócio específica'
        
        return context
    
    def _analyze_calculation_context(self, line: str, lines: List[str], line_index: int) -> Dict[str, Any]:
        """Analisa o contexto de um cálculo para extrair propósito de negócio."""
        context = {
            'description': 'Cálculo não identificado',
            'business_purpose': 'processamento numérico',
            'variables_involved': []
        }
        
        line_upper = line.upper()
        
        # Extrair variáveis envolvidas no cálculo
        variables = re.findall(r'[A-Z][A-Z0-9-]*', line_upper)
        context['variables_involved'] = variables[:5]  # Limitar a 5 variáveis
        
        # Identificar tipo de cálculo baseado em padrões
        if any(word in line_upper for word in ['CONTADOR', 'COUNT', 'CT-', 'AC-']):
            context['description'] = 'Incremento de contador ou acumulador'
            context['business_purpose'] = 'controle de quantidade e totalizações'
        elif any(word in line_upper for word in ['VALOR', 'VL-', 'SALDO', 'TOTAL']):
            context['description'] = 'Cálculo de valores monetários'
            context['business_purpose'] = 'processamento financeiro'
        elif any(word in line_upper for word in ['TAXA', 'PERCENT', 'JUROS']):
            context['description'] = 'Cálculo de taxas ou percentuais'
            context['business_purpose'] = 'cálculos de juros e taxas'
        elif any(word in line_upper for word in ['INDICE', 'IND-', 'INDEX']):
            context['description'] = 'Manipulação de índices'
            context['business_purpose'] = 'controle de posicionamento e navegação'
        else:
            # Tentar identificar pelo tipo de operação
            if 'ADD' in line_upper:
                context['description'] = 'Soma de valores'
                context['business_purpose'] = 'acumulação de totais'
            elif 'SUBTRACT' in line_upper:
                context['description'] = 'Subtração de valores'
                context['business_purpose'] = 'redução ou ajuste de valores'
            elif 'MULTIPLY' in line_upper:
                context['description'] = 'Multiplicação de valores'
                context['business_purpose'] = 'cálculo proporcional'
            elif 'DIVIDE' in line_upper:
                context['description'] = 'Divisão de valores'
                context['business_purpose'] = 'cálculo de médias ou proporções'
            else:
                context['description'] = f"Operação matemática: {line[:50]}..."
        
        return context
    
    def _analyze_move_context(self, line: str, lines: List[str], line_index: int) -> Dict[str, Any]:
        """Analisa o contexto de uma movimentação de dados."""
        context = {
            'description': 'Movimentação de dados',
            'business_impact': 'transferência de informações',
            'fields_affected': []
        }
        
        line_upper = line.upper()
        
        # Extrair campos origem e destino
        move_match = re.search(r'MOVE\s+([A-Z0-9-]+)\s+TO\s+([A-Z0-9-]+)', line_upper)
        if move_match:
            source_field = move_match.group(1)
            target_field = move_match.group(2)
            context['fields_affected'] = [source_field, target_field]
            
            # Identificar tipo de movimentação baseado nos nomes dos campos
            if any(word in line_upper for word in ['VALOR', 'VL-', 'SALDO']):
                context['description'] = f'Transferência de valor monetário de {source_field} para {target_field}'
                context['business_impact'] = 'atualização de valores financeiros'
            elif any(word in line_upper for word in ['CONTA', 'AGENCIA', 'CLIENTE']):
                context['description'] = f'Transferência de dados de identificação de {source_field} para {target_field}'
                context['business_impact'] = 'atualização de dados cadastrais'
            elif any(word in line_upper for word in ['DATA', 'DT-']):
                context['description'] = f'Transferência de data de {source_field} para {target_field}'
                context['business_impact'] = 'controle temporal'
            else:
                context['description'] = f'Transferência de dados de {source_field} para {target_field}'
        
        return context
    
    def _analyze_file_operation_context(self, line: str, lines: List[str], line_index: int) -> Dict[str, Any]:
        """Analisa o contexto de uma operação de arquivo."""
        context = {
            'description': 'Operação de arquivo',
            'business_operation': 'processamento de dados',
            'files_involved': []
        }
        
        line_upper = line.upper()
        
        # Extrair nome do arquivo
        file_match = re.search(r'(READ|WRITE|REWRITE|DELETE)\s+([A-Z0-9-]+)', line_upper)
        if file_match:
            operation = file_match.group(1)
            file_name = file_match.group(2)
            context['files_involved'] = [file_name]
            
            # Identificar tipo de operação
            if operation == 'READ':
                context['description'] = f'Leitura de dados do arquivo {file_name}'
                context['business_operation'] = 'consulta de informações'
            elif operation == 'WRITE':
                context['description'] = f'Gravação de dados no arquivo {file_name}'
                context['business_operation'] = 'persistência de informações'
            elif operation == 'REWRITE':
                context['description'] = f'Atualização de dados no arquivo {file_name}'
                context['business_operation'] = 'modificação de registros'
            elif operation == 'DELETE':
                context['description'] = f'Exclusão de dados do arquivo {file_name}'
                context['business_operation'] = 'remoção de registros'
        
        return context
    
    def _analyze_call_context(self, line: str, lines: List[str], line_index: int) -> Dict[str, Any]:
        """Analisa o contexto de uma chamada de programa."""
        context = {
            'description': 'Chamada de programa',
            'integration_purpose': 'integração com sistema',
            'programs_called': []
        }
        
        line_upper = line.upper()
        
        # Extrair nome do programa chamado
        call_match = re.search(r'CALL\s+[\'"]?([A-Z0-9-]+)[\'"]?', line_upper)
        if call_match:
            program_name = call_match.group(1)
            context['programs_called'] = [program_name]
            
            # Identificar tipo de programa baseado no nome
            if program_name.startswith('LH'):
                context['description'] = f'Chamada para programa de processamento {program_name}'
                context['integration_purpose'] = 'processamento especializado'
            elif program_name.startswith('MZ'):
                context['description'] = f'Chamada para utilitário {program_name}'
                context['integration_purpose'] = 'função utilitária'
            elif any(word in program_name for word in ['VALID', 'CHECK']):
                context['description'] = f'Chamada para validação via {program_name}'
                context['integration_purpose'] = 'validação de dados'
            else:
                context['description'] = f'Chamada para programa externo {program_name}'
                context['integration_purpose'] = 'integração com módulo externo'
        
        return context
    
    def _calculate_metrics(self, lines: List[str]) -> CodeMetrics:
        """Calcula métricas do código."""
        total_lines = len(lines)
        comment_lines = sum(1 for line in lines if line.strip().startswith('*') or line.strip().startswith('C'))
        blank_lines = sum(1 for line in lines if not line.strip())
        code_lines = total_lines - comment_lines - blank_lines
        
        # Cálculo simplificado de complexidade
        complexity_score = 0
        for line in lines:
            line_upper = line.upper()
            if any(keyword in line_upper for keyword in ['IF', 'WHEN', 'PERFORM', 'CALL']):
                complexity_score += 1
        
        # Índice de manutenibilidade simplificado
        if code_lines > 0:
            comment_ratio = comment_lines / code_lines
            maintainability_index = max(0, min(100, 100 - complexity_score + (comment_ratio * 10)))
        else:
            maintainability_index = 0
        
        return CodeMetrics(
            total_lines=total_lines,
            code_lines=code_lines,
            comment_lines=comment_lines,
            blank_lines=blank_lines,
            complexity_score=complexity_score,
            maintainability_index=maintainability_index
        )
    
    def _analyze_regulatory_context(self, comments: CommentAnalysis, business_rules: List[BusinessRule]) -> Dict[str, Any]:
        """Analisa o contexto regulatório do programa."""
        regulatory_context = {
            'has_regulatory_content': len(comments.regulatory_references) > 0,
            'regulatory_references': comments.regulatory_references,
            'compliance_level': 'high' if len(comments.regulatory_references) > 3 else 'medium' if len(comments.regulatory_references) > 0 else 'low',
            'business_focus': self._determine_business_focus(comments, business_rules),
            'risk_indicators': self._identify_risk_indicators(comments, business_rules)
        }
        
        return regulatory_context
    
    def _determine_business_focus(self, comments: CommentAnalysis, business_rules: List[BusinessRule]) -> str:
        """Determina o foco de negócio do programa."""
        all_text = ' '.join(comments.business_comments).upper()
        
        if 'RISCO' in all_text or 'PROVISÃO' in all_text:
            return 'gestão de risco'
        elif 'REGULATÓRIO' in all_text or 'COMPLIANCE' in all_text:
            return 'compliance regulatório'
        elif 'OPERAÇÃO' in all_text or 'TRANSAÇÃO' in all_text:
            return 'operações bancárias'
        elif 'RELATÓRIO' in all_text or 'REPORT' in all_text:
            return 'relatórios gerenciais'
        else:
            return 'processamento geral'
    
    def _identify_risk_indicators(self, comments: CommentAnalysis, business_rules: List[BusinessRule]) -> List[str]:
        """Identifica indicadores de risco no código."""
        risk_indicators = []
        
        all_text = ' '.join(comments.business_comments).upper()
        
        if 'CRÍTICO' in all_text:
            risk_indicators.append('processo crítico')
        if 'AUDITORIA' in all_text:
            risk_indicators.append('sujeito a auditoria')
        if 'REGULATÓRIO' in all_text:
            risk_indicators.append('impacto regulatório')
        if len(comments.regulatory_references) > 5:
            risk_indicators.append('alta complexidade regulatória')
        
        return risk_indicators
    
    def _assess_quality(self, structure: CobolStructure, comments: CommentAnalysis, metrics: CodeMetrics) -> Dict[str, Any]:
        """Avalia a qualidade do código."""
        quality_score = 0
        quality_factors = []
        
        # Fator: Documentação
        if metrics.comment_lines > 0:
            doc_ratio = metrics.comment_lines / metrics.total_lines
            if doc_ratio > 0.2:
                quality_score += 25
                quality_factors.append('boa documentação')
            elif doc_ratio > 0.1:
                quality_score += 15
                quality_factors.append('documentação adequada')
        
        # Fator: Estrutura
        if len(structure.divisions) >= 3:
            quality_score += 20
            quality_factors.append('estrutura completa')
        
        # Fator: Complexidade
        if metrics.complexity_score < 20:
            quality_score += 20
            quality_factors.append('baixa complexidade')
        elif metrics.complexity_score < 50:
            quality_score += 10
            quality_factors.append('complexidade moderada')
        
        # Fator: Organização
        if len(structure.sections) > 0:
            quality_score += 15
            quality_factors.append('bem organizado')
        
        # Fator: Comentários de negócio
        if len(comments.business_comments) > 0:
            quality_score += 20
            quality_factors.append('comentários de negócio')
        
        # Determinar nível de qualidade
        if quality_score >= 80:
            quality_level = 'excelente'
        elif quality_score >= 60:
            quality_level = 'boa'
        elif quality_score >= 40:
            quality_level = 'adequada'
        else:
            quality_level = 'precisa melhorias'
        
        return {
            'quality_score': quality_score,
            'quality_level': quality_level,
            'quality_factors': quality_factors,
            'maintainability_index': metrics.maintainability_index,
            'documentation_ratio': metrics.comment_lines / metrics.total_lines if metrics.total_lines > 0 else 0
        }
    
    def generate_analysis_summary(self, analysis: CobolAnalysisResult) -> str:
        """Gera resumo da análise para inclusão no prompt."""
        summary = f"""
=== PRÉ-ANÁLISE DETALHADA DO PROGRAMA {analysis.program_name} ===

ESTRUTURA IDENTIFICADA:
- Divisões: {', '.join(analysis.structure.divisions)}
- Seções: {len(analysis.structure.sections)} seções
- Parágrafos: {len(analysis.structure.paragraphs)} parágrafos
- Arquivos: {len(analysis.structure.files)} arquivos
- Copybooks: {len(analysis.structure.copybooks)} copybooks

MÉTRICAS DO CÓDIGO:
- Total de linhas: {analysis.metrics.total_lines}
- Linhas de código: {analysis.metrics.code_lines}
- Linhas de comentário: {analysis.metrics.comment_lines}
- Complexidade: {analysis.metrics.complexity_score}
- Índice de manutenibilidade: {analysis.metrics.maintainability_index:.1f}

REGRAS DE NEGÓCIO IDENTIFICADAS ({len(analysis.business_rules)}):"""
        
        for rule in analysis.business_rules[:10]:  # Primeiros 10 regras
            summary += f"\n- {rule.type.upper()}: {rule.description[:100]}..."
        
        summary += f"""

CONTEXTO REGULATÓRIO:
- Nível de compliance: {analysis.regulatory_context['compliance_level']}
- Foco de negócio: {analysis.regulatory_context['business_focus']}
- Referências regulatórias: {', '.join(analysis.regulatory_context['regulatory_references'][:5])}
- Indicadores de risco: {', '.join(analysis.regulatory_context['risk_indicators'])}

ANÁLISE DE COMENTÁRIOS:
- Total de comentários: {analysis.comments.total_comments}
- Comentários de negócio: {len(analysis.comments.business_comments)}
- Comentários técnicos: {len(analysis.comments.technical_comments)}
- Códigos de operação: {', '.join(analysis.comments.operation_codes)}
- Códigos de produto: {', '.join(analysis.comments.product_codes)}

AVALIAÇÃO DE QUALIDADE:
- Nível de qualidade: {analysis.quality_assessment['quality_level']}
- Pontuação: {analysis.quality_assessment['quality_score']}/100
- Fatores positivos: {', '.join(analysis.quality_assessment['quality_factors'])}

COMENTÁRIOS DE NEGÓCIO RELEVANTES:"""
        
        for comment in analysis.comments.business_comments[:5]:  # Primeiros 5 comentários
            summary += f"\n- {comment}"
        
        summary += "\n\n=== FIM DA PRÉ-ANÁLISE ===\n"
        
        return summary

