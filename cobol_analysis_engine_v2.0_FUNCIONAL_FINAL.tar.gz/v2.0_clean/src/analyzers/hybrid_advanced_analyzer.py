import logging
import re
from typing import Dict, Any, List

class HybridAdvancedAnalyzer:
    """
    Analisador híbrido avançado que combina:
    1. Código-fonte original completo (com copybooks resolvidos)
    2. Análise estrutural detalhada (layouts, arquivos, fluxo)
    3. Análise semântica via LLM
    
    Para máxima efetividade na extração de lógica de negócio e detalhes técnicos.
    """

    def __init__(self, llm_provider: Any):
        self.logger = logging.getLogger(__name__)
        self.llm_provider = llm_provider

    def analyze(self, program_name: str, resolved_code: str, structural_analysis: Dict[str, Any], record_layouts: Dict[str, Any]) -> Dict[str, Any]:
        """Realiza análise híbrida completa combinando todas as fontes de informação."""
        self.logger.info(f"Iniciando análise híbrida avançada para o programa: {program_name}")

        # Gera um prompt super detalhado com TODAS as informações disponíveis
        comprehensive_prompt = self._generate_comprehensive_prompt(
            program_name, resolved_code, structural_analysis, record_layouts
        )

        # Envia para o LLM
        response = self.llm_provider.generate_text(comprehensive_prompt)

        # Processa a resposta
        return self._parse_comprehensive_response(response)

    def _generate_comprehensive_prompt(self, program_name: str, resolved_code: str, 
                                     structural_analysis: Dict[str, Any], 
                                     record_layouts: Dict[str, Any]) -> str:
        """Gera um prompt extremamente detalhado com todas as informações disponíveis."""
        
        # Extrai informações específicas do código
        code_insights = self._extract_code_insights(resolved_code)
        
        prompt = f"""# ANÁLISE COMPLETA DE PROGRAMA COBOL: {program_name}

Você é um especialista em COBOL com 30 anos de experiência em modernização de sistemas legados. Sua tarefa é analisar este programa COBOL de forma EXTREMAMENTE DETALHADA para que um programador possa reimplementá-lo PERFEITAMENTE em outra linguagem.

## 1. CÓDIGO-FONTE COMPLETO (com copybooks resolvidos):

```cobol
{resolved_code}
```

## 2. ANÁLISE ESTRUTURAL PRELIMINAR:

### Divisões Identificadas:
{self._format_divisions(structural_analysis)}

### Seções e Parágrafos:
{self._format_sections_paragraphs(structural_analysis)}

### Layouts de Registro Detectados:
{self._format_record_layouts(record_layouts)}

## 3. INSIGHTS EXTRAÍDOS DO CÓDIGO:

### Arquivos Identificados:
{self._format_file_insights(code_insights.get('files', []))}

### Variáveis Críticas:
{self._format_variables(code_insights.get('variables', []))}

### Constantes e Valores:
{self._format_constants(code_insights.get('constants', []))}

### Chamadas de Sub-rotinas:
{self._format_subroutines(code_insights.get('subroutines', []))}

## 4. TAREFA - ANÁLISE COMPLETA:

Forneça uma análise EXTREMAMENTE DETALHADA em formato YAML que permita reimplementação PERFEITA:

### OBRIGATÓRIO - Inclua TODOS estes detalhes:

1. **program_purpose**: Descrição precisa do que o programa faz
2. **input_files**: Lista COMPLETA de arquivos de entrada com:
   - Nome lógico e físico
   - Tamanho de registro
   - Formato (fixo/variável)
   - Estrutura detalhada de campos
3. **output_files**: Lista COMPLETA de arquivos de saída com mesmos detalhes
4. **data_structures**: Estruturas de dados da WORKING-STORAGE com:
   - Nome do campo
   - Tipo de dado (numérico/alfanumérico/grupo)
   - Tamanho
   - Valor inicial
   - Propósito/uso
5. **business_logic**: Lógica de negócio PASSO A PASSO:
   - Sequência exata de processamento
   - Condições IF/WHEN com valores específicos
   - Loops e iterações
   - Validações e critérios
6. **control_flow**: Fluxo de controle COMPLETO:
   - Ordem de execução dos parágrafos
   - Condições de desvio
   - Tratamento de erros
7. **constants_and_limits**: TODOS os valores constantes:
   - Limites numéricos
   - Strings literais
   - Códigos de status
   - Valores de comparação
8. **error_handling**: Como o programa trata erros:
   - Códigos de retorno
   - Mensagens de erro
   - Ações em caso de falha
9. **performance_considerations**: Aspectos de performance:
   - Tamanho de buffers
   - Frequência de commits
   - Otimizações específicas

### FORMATO DA RESPOSTA (YAML COMPLETO):

```yaml
program_purpose: "..."
input_files:
  - logical_name: "..."
    physical_name: "..."
    record_size: 999
    format: "fixed"
    fields:
      - name: "..."
        position: 999
        length: 999
        type: "..."
        picture: "..."
        usage: "..."
output_files:
  - logical_name: "..."
    # ... mesmo formato
data_structures:
  - name: "..."
    type: "..."
    size: 999
    initial_value: "..."
    purpose: "..."
business_logic:
  - step: 1
    description: "..."
    conditions: "..."
    actions: "..."
control_flow:
  - paragraph: "..."
    calls: ["...", "..."]
    conditions: "..."
constants_and_limits:
  - name: "..."
    value: "..."
    usage: "..."
error_handling:
  - condition: "..."
    action: "..."
performance_considerations:
  - aspect: "..."
    details: "..."
```

**IMPORTANTE**: Seja EXTREMAMENTE específico. Inclua TODOS os valores numéricos, strings literais, condições exatas e detalhes técnicos encontrados no código. Um programador deve conseguir reimplementar PERFEITAMENTE com base apenas nesta análise.
"""
        return prompt

    def _extract_code_insights(self, code: str) -> Dict[str, List]:
        """Extrai insights específicos do código-fonte."""
        insights = {
            'files': [],
            'variables': [],
            'constants': [],
            'subroutines': []
        }

        lines = code.split('\n')
        
        for line in lines:
            line = line.strip()
            
            # Detecta arquivos (SELECT statements)
            if 'SELECT' in line and 'ASSIGN' in line:
                match = re.search(r'SELECT\s+(\w+)\s+ASSIGN\s+(\w+)', line)
                if match:
                    insights['files'].append({
                        'logical': match.group(1),
                        'physical': match.group(2)
                    })
            
            # Detecta variáveis com PIC
            if 'PIC' in line:
                match = re.search(r'(\w+)\s+PIC\s+([X9V\(\)]+)', line)
                if match:
                    insights['variables'].append({
                        'name': match.group(1),
                        'picture': match.group(2)
                    })
            
            # Detecta constantes (VALUE clauses)
            if 'VALUE' in line:
                match = re.search(r'VALUE\s+[\'"]([^\'"]*)[\'"]', line)
                if match:
                    insights['constants'].append(match.group(1))
            
            # Detecta chamadas de sub-rotinas
            if 'CALL' in line:
                match = re.search(r'CALL\s+[\'"]([^\'"]*)[\'"]', line)
                if match:
                    insights['subroutines'].append(match.group(1))

        return insights

    def _format_divisions(self, structural_analysis: Dict[str, Any]) -> str:
        divisions = structural_analysis.get('divisions', [])
        return '\n'.join([f"- {div}" for div in divisions])

    def _format_sections_paragraphs(self, structural_analysis: Dict[str, Any]) -> str:
        sections = structural_analysis.get('sections', {})
        result = []
        for section, paragraphs in sections.items():
            result.append(f"**{section}**: {', '.join(paragraphs)}")
        return '\n'.join(result)

    def _format_record_layouts(self, record_layouts: Dict[str, Any]) -> str:
        if not record_layouts:
            return "Nenhum layout detectado."
        
        result = []
        for record_name, fields in record_layouts.items():
            result.append(f"**{record_name}**:")
            for field in fields:
                result.append(f"  - {field.name}: {field.picture} (pos: {field.start}, len: {field.length})")
        return '\n'.join(result)

    def _format_file_insights(self, files: List[Dict]) -> str:
        if not files:
            return "Nenhum arquivo detectado."
        
        result = []
        for file_info in files:
            result.append(f"- {file_info['logical']} -> {file_info['physical']}")
        return '\n'.join(result)

    def _format_variables(self, variables: List[Dict]) -> str:
        if not variables:
            return "Nenhuma variável detectada."
        
        result = []
        for var in variables:
            result.append(f"- {var['name']}: {var['picture']}")
        return '\n'.join(result)

    def _format_constants(self, constants: List[str]) -> str:
        if not constants:
            return "Nenhuma constante detectada."
        
        return '\n'.join([f"- '{const}'" for const in constants])

    def _format_subroutines(self, subroutines: List[str]) -> str:
        if not subroutines:
            return "Nenhuma sub-rotina detectada."
        
        return '\n'.join([f"- {sub}" for sub in subroutines])

    def _parse_comprehensive_response(self, response: str) -> Dict[str, Any]:
        """Processa a resposta completa do LLM."""
        try:
            # Extrai o conteúdo YAML
            yaml_content = re.search(r"```yaml\n(.*?)\n```", response, re.DOTALL)
            if yaml_content:
                import yaml
                return yaml.safe_load(yaml_content.group(1))
            else:
                # Se não encontrar YAML, tenta extrair informações da resposta em texto
                return self._extract_from_text_response(response)
        except Exception as e:
            self.logger.error(f"Erro ao processar resposta do LLM: {e}")
            return {"error": str(e), "raw_response": response}

    def _extract_from_text_response(self, response: str) -> Dict[str, Any]:
        """Extrai informações mesmo se a resposta não estiver em YAML perfeito."""
        return {
            "program_purpose": "Análise extraída da resposta em texto",
            "raw_analysis": response,
            "extraction_method": "text_fallback"
        }
