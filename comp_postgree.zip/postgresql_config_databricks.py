"""
Configurações Específicas para PostgreSQL no Databricks Azure
Otimizado para integração com milhões de registros
"""

from pyspark.sql import SparkSession
import os


class PostgreSQLDatabricksConfig:
    """Configurações otimizadas para PostgreSQL no Databricks Azure"""
    
    @staticmethod
    def create_optimized_spark_session_postgresql(app_name="PostgreSQL-ETL-Optimized"):
        """Cria sessão Spark otimizada para operações PostgreSQL"""
        
        spark = SparkSession.builder \
            .appName(app_name) \
            .config("spark.sql.adaptive.enabled", "true") \
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
            .config("spark.sql.adaptive.skewJoin.enabled", "true") \
            .config("spark.sql.adaptive.localShuffleReader.enabled", "true") \
            .config("spark.sql.adaptive.advisoryPartitionSizeInBytes", "256MB") \
            .config("spark.sql.adaptive.coalescePartitions.minPartitionNum", "16") \
            .config("spark.sql.adaptive.coalescePartitions.maxPartitionNum", "64") \
            .config("spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes", "512MB") \
            .config("spark.sql.adaptive.skewJoin.skewedPartitionFactor", "3") \
            .config("spark.sql.shuffle.partitions", "32") \
            .config("spark.sql.autoBroadcastJoinThreshold", "200MB") \
            .config("spark.sql.broadcastTimeout", "3600") \
            .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
            .config("spark.kryo.unsafe", "true") \
            .config("spark.kryoserializer.buffer.max", "1024m") \
            .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
            .config("spark.sql.execution.arrow.maxRecordsPerBatch", "50000") \
            .config("spark.sql.execution.arrow.pyspark.fallback.enabled", "true") \
            .config("spark.databricks.delta.optimizeWrite.enabled", "true") \
            .config("spark.databricks.delta.autoCompact.enabled", "true") \
            .config("spark.databricks.io.cache.enabled", "true") \
            .config("spark.databricks.io.cache.maxDiskUsage", "200g") \
            .config("spark.databricks.io.cache.maxMetaDataCache", "4g") \
            .config("spark.network.timeout", "3600s") \
            .config("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "256MB") \
            .config("spark.sql.files.maxPartitionBytes", "512MB") \
            .config("spark.sql.files.openCostInBytes", "4194304") \
            .config("spark.default.parallelism", "32") \
            .config("spark.executor.memoryFraction", "0.8") \
            .config("spark.executor.memoryStorageFraction", "0.3") \
            .config("spark.sql.adaptive.maxShuffledHashJoinLocalMapThreshold", "512MB") \
            .config("spark.sql.adaptive.optimizeSkewsInRebalancePartitions.enabled", "true") \
            .config("spark.sql.adaptive.forceOptimizeSkewedJoin", "true") \
            .getOrCreate()
        
        # Configurar log level
        spark.sparkContext.setLogLevel("WARN")
        
        return spark
    
    @staticmethod
    def get_postgresql_cluster_config():
        """Retorna configuração de cluster otimizada para PostgreSQL"""
        
        return {
            "cluster_name": "postgresql-etl-optimized",
            "spark_version": "11.3.x-scala2.12",
            "node_type_id": "Standard_D16s_v3",
            "driver_node_type_id": "Standard_D16s_v3", 
            "num_workers": 8,
            "autoscale": {
                "min_workers": 6,
                "max_workers": 12
            },
            "spark_conf": {
                # Configurações específicas para PostgreSQL
                "spark.executor.memory": "50g",
                "spark.executor.cores": "8",
                "spark.executor.memoryFraction": "0.8",
                "spark.executor.memoryStorageFraction": "0.3",
                "spark.driver.memory": "50g",
                "spark.driver.cores": "8",
                "spark.driver.maxResultSize": "4g",
                
                # Configurações JDBC otimizadas
                "spark.sql.execution.arrow.pyspark.enabled": "true",
                "spark.sql.execution.arrow.maxRecordsPerBatch": "50000",
                "spark.serializer": "org.apache.spark.serializer.KryoSerializer",
                "spark.kryo.unsafe": "true",
                "spark.kryoserializer.buffer.max": "1024m",
                
                # Configurações de rede para PostgreSQL
                "spark.network.timeout": "3600s",
                "spark.sql.broadcastTimeout": "3600",
                "spark.rpc.askTimeout": "3600s",
                "spark.rpc.lookupTimeout": "3600s",
                
                # Configurações adaptativas
                "spark.sql.adaptive.enabled": "true",
                "spark.sql.adaptive.coalescePartitions.enabled": "true",
                "spark.sql.adaptive.skewJoin.enabled": "true",
                "spark.sql.adaptive.localShuffleReader.enabled": "true",
                "spark.sql.adaptive.advisoryPartitionSizeInBytes": "256MB",
                "spark.sql.adaptive.coalescePartitions.minPartitionNum": "16",
                "spark.sql.adaptive.coalescePartitions.maxPartitionNum": "64",
                
                # Configurações de shuffle
                "spark.sql.shuffle.partitions": "32",
                "spark.sql.adaptive.shuffle.targetPostShuffleInputSize": "256MB",
                "spark.default.parallelism": "32",
                
                # Configurações de broadcast
                "spark.sql.autoBroadcastJoinThreshold": "200MB",
                "spark.sql.adaptive.maxShuffledHashJoinLocalMapThreshold": "512MB",
                
                # Configurações de cache
                "spark.databricks.io.cache.enabled": "true",
                "spark.databricks.io.cache.maxDiskUsage": "200g",
                "spark.databricks.io.cache.maxMetaDataCache": "4g",
                
                # Configurações Delta
                "spark.databricks.delta.optimizeWrite.enabled": "true",
                "spark.databricks.delta.autoCompact.enabled": "true",
                "spark.databricks.delta.retentionDurationCheck.enabled": "false"
            },
            "azure_attributes": {
                "availability": "ON_DEMAND_AZURE",
                "first_on_demand": 8,
                "spot_bid_max_price": -1
            },
            "enable_elastic_disk": True,
            "disk_spec": {
                "disk_type": {
                    "azure_disk_volume_type": "PREMIUM_LRS"
                },
                "disk_size": 512
            },
            "autotermination_minutes": 60,
            "custom_tags": {
                "Environment": "Production",
                "Project": "PostgreSQL-ETL",
                "Owner": "DataEngineering",
                "CostCenter": "IT-DataPlatform",
                "OptimizationType": "PostgreSQL-Integration"
            }
        }
    
    @staticmethod
    def get_postgresql_jdbc_config(host, database, user, password):
        """Retorna configurações JDBC otimizadas para PostgreSQL"""
        
        return {
            "read_options": {
                "url": f"jdbc:postgresql://{host}/{database}",
                "user": user,
                "password": password,
                "driver": "org.postgresql.Driver",
                "fetchsize": "100000",
                "queryTimeout": "3600",
                "connectTimeout": "60",
                "socketTimeout": "3600",
                "loginTimeout": "60",
                "prepareThreshold": "5",
                "preparedStatementCacheQueries": "256",
                "preparedStatementCacheSizeMiB": "5",
                "defaultRowFetchSize": "100000",
                "logUnclosedConnections": "true",
                "tcpKeepAlive": "true"
            },
            "write_options": {
                "url": f"jdbc:postgresql://{host}/{database}",
                "user": user,
                "password": password,
                "driver": "org.postgresql.Driver",
                "batchsize": "50000",
                "isolationLevel": "READ_COMMITTED",
                "rewriteBatchedStatements": "true",
                "stringtype": "unspecified",
                "queryTimeout": "3600",
                "connectTimeout": "60",
                "socketTimeout": "3600",
                "loginTimeout": "60",
                "prepareThreshold": "5",
                "tcpKeepAlive": "true"
            },
            "partitioning": {
                "numPartitions": "32",
                "partitionColumn": "penumper",
                "fetchsize": "100000"
            }
        }
    
    @staticmethod
    def configure_postgresql_performance_monitoring(spark):
        """Configura monitoramento de performance para PostgreSQL"""
        
        # Configurar métricas do Spark
        spark.conf.set("spark.sql.streaming.metricsEnabled", "true")
        spark.conf.set("spark.metrics.conf.*.sink.console.period", "10")
        spark.conf.set("spark.metrics.conf.*.sink.console.unit", "seconds")
        
        # Configurar logs detalhados para JDBC
        spark.sparkContext.setLogLevel("INFO")
        
        # Configurar métricas customizadas
        spark.conf.set("spark.sql.adaptive.logLevel", "INFO")
        
        return spark
    
    @staticmethod
    def get_postgresql_performance_queries():
        """Retorna queries para monitoramento do PostgreSQL"""
        
        return {
            "active_connections": """
                SELECT count(*) as active_connections 
                FROM pg_stat_activity 
                WHERE state = 'active' AND application_name LIKE '%spark%'
            """,
            
            "slow_queries": """
                SELECT query, mean_time, calls, total_time
                FROM pg_stat_statements 
                WHERE query LIKE '%tb_dossie_simples%'
                ORDER BY mean_time DESC 
                LIMIT 10
            """,
            
            "table_stats": """
                SELECT 
                    schemaname,
                    tablename,
                    n_tup_ins as inserts,
                    n_tup_upd as updates,
                    n_tup_del as deletes,
                    n_live_tup as live_tuples,
                    n_dead_tup as dead_tuples,
                    last_vacuum,
                    last_autovacuum,
                    last_analyze,
                    last_autoanalyze
                FROM pg_stat_user_tables 
                WHERE tablename = 'tb_dossie_simples'
            """,
            
            "index_usage": """
                SELECT 
                    indexrelname as index_name,
                    idx_tup_read,
                    idx_tup_fetch,
                    idx_scan
                FROM pg_stat_user_indexes 
                WHERE relname = 'tb_dossie_simples'
                ORDER BY idx_scan DESC
            """,
            
            "locks": """
                SELECT 
                    mode,
                    count(*) as lock_count
                FROM pg_locks l
                JOIN pg_class c ON l.relation = c.oid
                WHERE c.relname = 'tb_dossie_simples'
                GROUP BY mode
            """,
            
            "table_size": """
                SELECT 
                    pg_size_pretty(pg_total_relation_size('tb_dossie_simples')) as total_size,
                    pg_size_pretty(pg_relation_size('tb_dossie_simples')) as table_size,
                    pg_size_pretty(pg_indexes_size('tb_dossie_simples')) as indexes_size
            """,
            
            "connection_stats": """
                SELECT 
                    state,
                    count(*) as connection_count,
                    application_name
                FROM pg_stat_activity 
                WHERE application_name LIKE '%spark%'
                GROUP BY state, application_name
            """
        }
    
    @staticmethod
    def get_postgresql_optimization_queries():
        """Retorna queries para otimização do PostgreSQL"""
        
        return {
            "create_indexes": [
                """
                CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tb_dossie_simples_penumper_hash 
                ON tb_dossie_simples (penumper, identity_hash)
                """,
                """
                CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tb_dossie_simples_penumper 
                ON tb_dossie_simples (penumper)
                """,
                """
                CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tb_dossie_simples_penumper_btree 
                ON tb_dossie_simples USING btree (penumper)
                """
            ],
            
            "analyze_table": [
                "ANALYZE tb_dossie_simples",
                "VACUUM ANALYZE tb_dossie_simples"
            ],
            
            "performance_settings": [
                "ALTER SYSTEM SET shared_buffers = '4GB'",
                "ALTER SYSTEM SET work_mem = '256MB'",
                "ALTER SYSTEM SET maintenance_work_mem = '1GB'",
                "ALTER SYSTEM SET checkpoint_completion_target = 0.9",
                "ALTER SYSTEM SET wal_buffers = '64MB'",
                "ALTER SYSTEM SET max_connections = 200",
                "ALTER SYSTEM SET effective_cache_size = '12GB'",
                "ALTER SYSTEM SET synchronous_commit = off",
                "ALTER SYSTEM SET commit_delay = 10000",
                "ALTER SYSTEM SET commit_siblings = 5",
                "SELECT pg_reload_conf()"
            ]
        }


# Exemplo de uso das configurações
def exemplo_configuracao_postgresql():
    """Exemplo de como usar as configurações PostgreSQL"""
    
    # Criar sessão Spark otimizada
    spark = PostgreSQLDatabricksConfig.create_optimized_spark_session_postgresql()
    
    # Configurar monitoramento
    spark = PostgreSQLDatabricksConfig.configure_postgresql_performance_monitoring(spark)
    
    # Obter configurações JDBC
    jdbc_config = PostgreSQLDatabricksConfig.get_postgresql_jdbc_config(
        host="your-postgres-host",
        database="your-database", 
        user="your-user",
        password="your-password"
    )
    
    # Usar configurações para leitura
    df = spark.read.format("jdbc") \
        .options(**jdbc_config["read_options"]) \
        .option("dbtable", "tb_dossie_simples") \
        .option("numPartitions", jdbc_config["partitioning"]["numPartitions"]) \
        .option("partitionColumn", jdbc_config["partitioning"]["partitionColumn"]) \
        .load()
    
    return df


# Configurações específicas para diferentes volumes de dados
class PostgreSQLVolumeConfig:
    """Configurações específicas baseadas no volume de dados"""
    
    @staticmethod
    def get_config_for_volume(record_count):
        """Retorna configuração otimizada baseada no volume"""
        
        if record_count < 1000000:  # < 1M registros
            return {
                "num_partitions": 8,
                "fetch_size": 50000,
                "batch_size": 25000,
                "workers": 4
            }
        elif record_count < 10000000:  # < 10M registros
            return {
                "num_partitions": 16,
                "fetch_size": 100000,
                "batch_size": 50000,
                "workers": 8
            }
        elif record_count < 50000000:  # < 50M registros
            return {
                "num_partitions": 32,
                "fetch_size": 100000,
                "batch_size": 50000,
                "workers": 12
            }
        else:  # > 50M registros
            return {
                "num_partitions": 64,
                "fetch_size": 100000,
                "batch_size": 75000,
                "workers": 16
            }

