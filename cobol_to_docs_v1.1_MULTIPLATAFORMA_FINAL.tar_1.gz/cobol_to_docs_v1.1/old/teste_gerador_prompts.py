#!/usr/bin/env python3
"""
Teste do Gerador de Prompts YAML
Demonstra a nova funcionalidade de conversão de texto livre em prompts otimizados
"""

import os
import sys
import tempfile
from pathlib import Path

def testar_gerador_prompts():
    """Testar a funcionalidade de geração de prompts."""
    print("🧪 TESTE DO GERADOR DE PROMPTS YAML")
    print("=" * 60)
    print()
    
    # Verificar se os arquivos existem
    script_path = Path("generate_prompts.py")
    example_path = Path("exemplo_requisitos.txt")
    
    if not script_path.exists():
        print("❌ Script generate_prompts.py não encontrado")
        return False
    
    if not example_path.exists():
        print("❌ Arquivo exemplo_requisitos.txt não encontrado")
        return False
    
    print("✅ Arquivos necessários encontrados")
    print()
    
    # Demonstrar funcionalidades
    print("🎯 FUNCIONALIDADES DISPONÍVEIS:")
    print()
    
    print("1️⃣ GERAÇÃO A PARTIR DE ARQUIVO:")
    print("   python3 generate_prompts.py --input exemplo_requisitos.txt --output prompts_bancarios.yaml")
    print("   - Converte arquivo de texto em prompts YAML")
    print("   - Aplica boas práticas de engenharia de prompt")
    print("   - Otimiza para análise COBOL")
    print()
    
    print("2️⃣ MODO INTERATIVO:")
    print("   python3 generate_prompts.py --interactive")
    print("   - Digite texto diretamente no terminal")
    print("   - Finaliza com 'FIM' em linha separada")
    print("   - Gera arquivo com timestamp automático")
    print()
    
    print("3️⃣ VALIDAÇÃO DE PROMPTS:")
    print("   python3 generate_prompts.py --validate meus_prompts.yaml")
    print("   - Verifica estrutura YAML")
    print("   - Valida seções obrigatórias")
    print("   - Mostra estatísticas do arquivo")
    print()
    
    print("4️⃣ STATUS DO SISTEMA:")
    print("   python3 generate_prompts.py --status")
    print("   - Verifica conectividade com LuzIA")
    print("   - Mostra status dos componentes")
    print("   - Valida configuração")
    print()
    
    print("5️⃣ PREVIEW DE ARQUIVO:")
    print("   python3 generate_prompts.py --input texto.txt --preview")
    print("   - Mostra preview do arquivo antes de processar")
    print("   - Permite confirmação antes da geração")
    print("   - Útil para arquivos grandes")
    print()
    
    # Mostrar exemplo de uso
    print("📋 EXEMPLO PRÁTICO:")
    print()
    print("# 1. Verificar status")
    print("python3 generate_prompts.py --status")
    print()
    print("# 2. Gerar prompts do exemplo")
    print("python3 generate_prompts.py --input exemplo_requisitos.txt --preview --output prompts_bancarios.yaml")
    print()
    print("# 3. Validar prompts gerados")
    print("python3 generate_prompts.py --validate prompts_bancarios.yaml")
    print()
    print("# 4. Usar prompts na análise")
    print("python3 main.py --fontes programa.cbl --prompts-file prompts_bancarios.yaml")
    print()
    
    # Mostrar conteúdo do exemplo
    print("📄 CONTEÚDO DO ARQUIVO DE EXEMPLO:")
    print("-" * 50)
    try:
        with open("exemplo_requisitos.txt", 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Mostrar preview
        preview_length = 300
        if len(content) > preview_length:
            print(content[:preview_length] + "...")
            print(f"\n[... mais {len(content) - preview_length} caracteres]")
        else:
            print(content)
    except Exception as e:
        print(f"Erro ao ler arquivo: {e}")
    
    print("-" * 50)
    print()
    
    # Explicar o processo
    print("🔄 COMO FUNCIONA:")
    print()
    print("1. **Entrada**: Texto livre em qualquer formato")
    print("2. **Processamento**: IA analisa e estrutura o texto")
    print("3. **Otimização**: Aplica boas práticas de engenharia de prompt")
    print("4. **Sanitização**: Remove caracteres problemáticos")
    print("5. **Validação**: Verifica estrutura YAML válida")
    print("6. **Saída**: Arquivo YAML pronto para uso")
    print()
    
    print("✨ BENEFÍCIOS:")
    print("✅ Converte qualquer texto em prompts estruturados")
    print("✅ Aplica automaticamente boas práticas")
    print("✅ Otimiza especificamente para COBOL")
    print("✅ Remove caracteres que podem quebrar o sistema")
    print("✅ Valida estrutura antes de salvar")
    print("✅ Mantém compatibilidade com sistema existente")
    print()
    
    print("🎯 CASOS DE USO:")
    print("- Converter requisitos de negócio em prompts")
    print("- Adaptar documentação existente para análise")
    print("- Criar prompts específicos para domínios (bancário, seguros, etc.)")
    print("- Personalizar análises para diferentes audiências")
    print("- Gerar prompts a partir de especificações técnicas")
    
    return True

def demonstrar_comando_status():
    """Demonstrar comando de status."""
    print()
    print("🔍 DEMONSTRAÇÃO: VERIFICANDO STATUS")
    print("=" * 50)
    
    # Executar comando de status
    os.system("python3 generate_prompts.py --status")

def main():
    """Executar teste do gerador de prompts."""
    os.chdir(Path(__file__).parent)
    
    success = testar_gerador_prompts()
    
    if success:
        demonstrar_comando_status()
        
        print()
        print("=" * 60)
        print("FUNCIONALIDADE PRONTA PARA USO!")
        print("=" * 60)
        print()
        print("🚀 PRÓXIMOS PASSOS:")
        print("1. Execute: python3 generate_prompts.py --status")
        print("2. Teste: python3 generate_prompts.py --input exemplo_requisitos.txt --preview")
        print("3. Gere: python3 generate_prompts.py --input exemplo_requisitos.txt --output meus_prompts.yaml")
        print("4. Use: python3 main.py --fontes programa.cbl --prompts-file meus_prompts.yaml")
        print()
        print("✅ NOVA FUNCIONALIDADE INTEGRADA COM SUCESSO!")
    else:
        print("❌ Problemas detectados na funcionalidade")

if __name__ == "__main__":
    main()
