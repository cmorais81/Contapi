# COBOL to Docs v1.0 - Sistema Final

Sistema profissional para análise de programas COBOL com geração de documentação técnica detalhada.

## Características

- **Análise Profissional Sênior**: Implementa feedback de especialista COBOL
- **Múltiplos Providers**: Enhanced Mock (padrão) e LuzIA
- **Documentação Completa**: Relatórios markdown + JSONs de auditoria
- **Estrutura Limpa**: Código organizado seguindo princípios SOLID

## Uso

```bash
python3 main.py --fontes examples/fontes.txt --books examples/books.txt --models enhanced_mock --output output
```

## Estrutura

```
├── config/
│   └── config.yaml          # Configuração principal
├── src/
│   ├── core/                # Classes principais
│   ├── parsers/             # Parser COBOL
│   ├── analyzers/           # Analisador aprimorado
│   ├── providers/           # Providers de IA
│   └── generators/          # Gerador de documentação
├── examples/
│   ├── fontes.txt           # Programas COBOL exemplo
│   └── books.txt            # Copybooks exemplo
├── output/                  # Saída gerada
│   ├── *.md                 # Relatórios de análise
│   ├── ai_responses/        # JSONs das respostas
│   └── ai_requests/         # JSONs dos requests
└── main.py                  # Ponto de entrada
```

## Saída

Para cada programa COBOL:
- `{PROGRAMA}_analise_funcional.md` - Relatório principal
- `ai_responses/{PROGRAMA}_ai_response.json` - Resposta completa da IA
- `ai_requests/{PROGRAMA}_ai_request.json` - Request enviado

## Análise Profissional

O sistema implementa análise sênior focada em:
- Funcionalidades específicas extraídas do código
- Regras de negócio concretas com evidências
- Análise estrutural sem dependência de comentários
- Linguagem técnica sênior
- Mapeamento detalhado de copybooks CADOC
- Extração de algoritmos e lógicas específicas

---

*COBOL to Docs v1.0 - Sistema Final Funcional*
