# LHAN0543 - Análise Funcional

## Informações do Programa

- **Nome:** LHAN0543
- **Tamanho:** 12536 caracteres
- **Data da Análise:** 01/10/2025 14:39:57

## Análise Técnica

# LHAN0543 - Análise Técnica Sênior

    ## Funcionalidades Implementadas
    • **V           PROCESSAR UNTIL WS-CONTINUA = 'N':** Linha 73
• **Interface:** LHAN0543 - CADASTRO DE CONTAS (Linha 92)
• **Interface:** OPCAO:  (Linha 99)
• **V               WHEN '1' INCLUIR-CONTA:** Linha 102
• **V               WHEN '2' ALTERAR-CONTA:** Linha 103
• **V               WHEN '3' EXCLUIR-CONTA:** Linha 104
• **V               WHEN '4' CONSULTAR-CONTA:** Linha 105
• **Interface:** OPCAO INVALIDA (Linha 109)

    ## Regras de Negócio Identificadas
    • **Validação:** V           IF WS-STATUS-CONTA NOT = '00' AND '97' (Linha 79)
• **Critério:** V           IF WS-STATUS-CONTA NOT = '00' AND '97' (Linha 79)
• **Validação:** V           IF WS-STATUS-CLIENTE NOT = '00' (Linha 85)
• **Critério:** V           IF WS-STATUS-CLIENTE NOT = '00' (Linha 85)
• **Validação:** V           IF WS-STATUS-CONTA = '00' (Linha 117)
• **Validação:** V               IF WS-STATUS-CLIENTE = '00' (Linha 124)
• **Validação:** V                   IF WS-STATUS-CONTA = '00' (Linha 134)

    ## Estruturas de Dados
    • **Arquivo:** V           SELECT CONTA-FILE ASSIGN TO CONTA
• **Arquivo:** V           SELECT CLIENTE-FILE ASSIGN TO CLIENTE
• 05  CLI-CODIGO          PIC X(10).
• 05  CLI-NOME            PIC X(50).
• 05  CLI-CPF             PIC X(11).
• 05  CLI-ENDERECO        PIC X(100).
• 05  CLI-TELEFONE        PIC X(15).
• 05  CLI-DATA-CADASTRO   PIC X(08).

    ## Integrações e Dependências
    • **Copybook:** CONTA (Linha 48)
• **Copybook:** CLIENTE (Linha 52)

    ## Algoritmos e Lógicas
    • **Cálculo:** V       SOURCE-COMPUTER.    IBM-370. (Linha 24)
• **Cálculo:** V       OBJECT-COMPUTER.    IBM-370. (Linha 25)
• **Cálculo:** V                       ADD 1 TO WS-CONT-GRAVADAS (Linha 136)

    ## Análise de Criticidade
    **Complexidade:** Média (182 linhas)
    **Integrações:** 2 dependências identificadas
    **Regras:** 7 validações mapeadas
    **Funcionalidades:** 8 operações principais

    ---
    *Análise baseada em 182 linhas de código COBOL*
    

## Informações da Análise

- **Provider:** enhanced_mock
- **Modelo:** enhanced_mock
- **Sucesso:** Sim
- **Tokens Utilizados:** 911
- **Tempo de Processamento:** 0.00s

## Arquivos de Auditoria

- **Resposta da IA:** `ai_responses/LHAN0543_ai_response.json`
- **Request Enviado:** `ai_requests/LHAN0543_ai_request.json`

---

*Relatório gerado automaticamente pelo COBOL to Docs v1.0*
