"""
Classe AnalysisRequest para requisições de análise
"""

from dataclasses import dataclass
from typing import Optional, Dict, Any, List

@dataclass
class AnalysisRequest:
    """Requisição de análise de programa COBOL"""
    program_name: str
    program_content: str = ""
    model: str = "enhanced_mock"
    prompt: str = ""
    analysis_type: str = "individual"
    context: Optional[Dict[str, Any]] = None
    copybooks: Optional[List] = None
    books_content: str = ""
    cobol_content: str = ""
    temperature: float = 0.1
    max_tokens: int = 4000
    
    def __post_init__(self):
        if not self.cobol_content and self.program_content:
            self.cobol_content = self.program_content
        if self.context is None:
            self.context = {}
