"""
Testes unitários para entidades de domínio
"""

import pytest
from datetime import datetime
from uuid import uuid4

from governance_api.domain.entities import DataContract, Entity, QualityRule
from governance_api.domain.exceptions import ValidationError, BusinessRuleViolation
from governance_api.domain.value_objects import Email, UnityCatalogPath, Version


class TestDataContract:
    """Testes para entidade DataContract"""
    
    def test_create_data_contract_valid(self):
        """Testa criação de contrato válido"""
        contract = DataContract(
            name="Test Contract",
            description="Test description",
            created_by=uuid4()
        )
        
        assert contract.name == "Test Contract"
        assert contract.description == "Test description"
        assert contract.status == "draft"
        assert contract.created_at is not None
        assert contract.updated_at is not None
    
    def test_create_data_contract_with_unity_path(self):
        """Testa criação de contrato com Unity Catalog path"""
        unity_path = UnityCatalogPath.from_string("catalog.schema.table")
        
        contract = DataContract(
            name="Test Contract",
            unity_catalog_path=unity_path,
            created_by=uuid4()
        )
        
        assert contract.unity_catalog_path == unity_path
        assert str(contract.unity_catalog_path) == "catalog.schema.table"
    
    def test_create_data_contract_invalid_name(self):
        """Testa criação de contrato com nome inválido"""
        with pytest.raises(ValidationError):
            DataContract(
                name="",  # Nome vazio
                created_by=uuid4()
            )
        
        with pytest.raises(ValidationError):
            DataContract(
                name="a" * 256,  # Nome muito longo
                created_by=uuid4()
            )
    
    def test_update_contract_status(self):
        """Testa atualização de status do contrato"""
        contract = DataContract(
            name="Test Contract",
            created_by=uuid4()
        )
        
        # Status inicial deve ser draft
        assert contract.status == "draft"
        
        # Atualizar para active
        contract.status = "active"
        assert contract.status == "active"
        
        # Não deve permitir status inválido
        with pytest.raises(ValidationError):
            contract.status = "invalid_status"
    
    def test_contract_validation(self):
        """Testa validação do contrato"""
        contract = DataContract(
            name="Test Contract",
            created_by=uuid4()
        )
        
        # Contrato sem versão não deve ser válido para ativação
        validation_result = contract.validate()
        assert not validation_result["is_valid"]
        assert "no_active_version" in validation_result["errors"]
    
    def test_contract_equality(self):
        """Testa igualdade entre contratos"""
        contract_id = uuid4()
        
        contract1 = DataContract(
            id=contract_id,
            name="Test Contract",
            created_by=uuid4()
        )
        
        contract2 = DataContract(
            id=contract_id,
            name="Test Contract",
            created_by=uuid4()
        )
        
        assert contract1 == contract2
        
        # Contratos com IDs diferentes não devem ser iguais
        contract3 = DataContract(
            id=uuid4(),
            name="Test Contract",
            created_by=uuid4()
        )
        
        assert contract1 != contract3


class TestEntity:
    """Testes para entidade Entity"""
    
    def test_create_entity_valid(self):
        """Testa criação de entidade válida"""
        entity = Entity(
            name="Test Entity",
            type="table",
            created_by=uuid4()
        )
        
        assert entity.name == "Test Entity"
        assert entity.type == "table"
        assert entity.classification == "internal"  # Valor padrão
        assert entity.created_at is not None
    
    def test_create_entity_with_schema(self):
        """Testa criação de entidade com schema"""
        schema_definition = {
            "type": "object",
            "properties": {
                "id": {"type": "integer"},
                "name": {"type": "string"}
            }
        }
        
        entity = Entity(
            name="Test Entity",
            type="table",
            schema_definition=schema_definition,
            created_by=uuid4()
        )
        
        assert entity.schema_definition == schema_definition
    
    def test_entity_invalid_type(self):
        """Testa criação de entidade com tipo inválido"""
        with pytest.raises(ValidationError):
            Entity(
                name="Test Entity",
                type="invalid_type",
                created_by=uuid4()
            )
    
    def test_entity_invalid_classification(self):
        """Testa criação de entidade com classificação inválida"""
        with pytest.raises(ValidationError):
            Entity(
                name="Test Entity",
                type="table",
                classification="invalid_classification",
                created_by=uuid4()
            )
    
    def test_entity_unity_catalog_path(self):
        """Testa Unity Catalog path na entidade"""
        unity_path = UnityCatalogPath.from_string("catalog.schema.table")
        
        entity = Entity(
            name="Test Entity",
            type="table",
            unity_catalog_path=unity_path,
            created_by=uuid4()
        )
        
        assert entity.unity_catalog_path == unity_path
        assert entity.unity_catalog_path.catalog == "catalog"
        assert entity.unity_catalog_path.schema == "schema"
        assert entity.unity_catalog_path.table == "table"


class TestQualityRule:
    """Testes para entidade QualityRule"""
    
    def test_create_quality_rule_valid(self):
        """Testa criação de regra de qualidade válida"""
        rule = QualityRule(
            name="Test Rule",
            entity_id=uuid4(),
            dimension_id=uuid4(),
            rule_type="completeness",
            rule_definition={"column": "name", "condition": "NOT NULL"},
            created_by=uuid4()
        )
        
        assert rule.name == "Test Rule"
        assert rule.rule_type == "completeness"
        assert rule.is_active is True  # Valor padrão
        assert rule.created_at is not None
    
    def test_quality_rule_invalid_type(self):
        """Testa criação de regra com tipo inválido"""
        with pytest.raises(ValidationError):
            QualityRule(
                name="Test Rule",
                entity_id=uuid4(),
                dimension_id=uuid4(),
                rule_type="invalid_type",
                rule_definition={"column": "name"},
                created_by=uuid4()
            )
    
    def test_quality_rule_thresholds(self):
        """Testa thresholds da regra de qualidade"""
        rule = QualityRule(
            name="Test Rule",
            entity_id=uuid4(),
            dimension_id=uuid4(),
            rule_type="completeness",
            rule_definition={"column": "name"},
            threshold_warning=90.0,
            threshold_critical=80.0,
            created_by=uuid4()
        )
        
        assert rule.threshold_warning == 90.0
        assert rule.threshold_critical == 80.0
    
    def test_quality_rule_invalid_thresholds(self):
        """Testa thresholds inválidos"""
        with pytest.raises(ValidationError):
            QualityRule(
                name="Test Rule",
                entity_id=uuid4(),
                dimension_id=uuid4(),
                rule_type="completeness",
                rule_definition={"column": "name"},
                threshold_warning=80.0,
                threshold_critical=90.0,  # Crítico maior que warning
                created_by=uuid4()
            )
    
    def test_quality_rule_execution(self):
        """Testa execução de regra de qualidade"""
        rule = QualityRule(
            name="Test Rule",
            entity_id=uuid4(),
            dimension_id=uuid4(),
            rule_type="completeness",
            rule_definition={"column": "name", "condition": "NOT NULL"},
            threshold_warning=90.0,
            threshold_critical=80.0,
            created_by=uuid4()
        )
        
        # Simular execução
        metric = rule.execute()
        
        assert metric is not None
        assert metric.rule_id == rule.id
        assert metric.entity_id == rule.entity_id
        assert hasattr(metric, 'metric_value')
        assert hasattr(metric, 'status')
    
    def test_quality_rule_deactivate(self):
        """Testa desativação de regra"""
        rule = QualityRule(
            name="Test Rule",
            entity_id=uuid4(),
            dimension_id=uuid4(),
            rule_type="completeness",
            rule_definition={"column": "name"},
            created_by=uuid4()
        )
        
        assert rule.is_active is True
        
        rule.deactivate()
        assert rule.is_active is False
    
    def test_quality_rule_activate(self):
        """Testa ativação de regra"""
        rule = QualityRule(
            name="Test Rule",
            entity_id=uuid4(),
            dimension_id=uuid4(),
            rule_type="completeness",
            rule_definition={"column": "name"},
            is_active=False,
            created_by=uuid4()
        )
        
        assert rule.is_active is False
        
        rule.activate()
        assert rule.is_active is True


class TestEntityRelationships:
    """Testes para relacionamentos entre entidades"""
    
    def test_contract_entity_relationship(self):
        """Testa relacionamento entre contrato e entidade"""
        contract_id = uuid4()
        entity_id = uuid4()
        
        # Criar contrato
        contract = DataContract(
            id=contract_id,
            name="Test Contract",
            created_by=uuid4()
        )
        
        # Criar entidade relacionada
        entity = Entity(
            id=entity_id,
            name="Test Entity",
            type="table",
            created_by=uuid4()
        )
        
        # Verificar que podem ser relacionados
        assert contract.id != entity.id
        assert isinstance(contract.id, type(entity.id))
    
    def test_entity_quality_rule_relationship(self):
        """Testa relacionamento entre entidade e regra de qualidade"""
        entity_id = uuid4()
        
        entity = Entity(
            id=entity_id,
            name="Test Entity",
            type="table",
            created_by=uuid4()
        )
        
        rule = QualityRule(
            name="Test Rule",
            entity_id=entity_id,
            dimension_id=uuid4(),
            rule_type="completeness",
            rule_definition={"column": "name"},
            created_by=uuid4()
        )
        
        assert rule.entity_id == entity.id

