"""
Testes unitários para value objects
"""

import pytest

from governance_api.domain.exceptions import ValidationError
from governance_api.domain.value_objects import Email, UnityCatalogPath, Version


class TestEmail:
    """Testes para value object Email"""
    
    def test_create_valid_email(self):
        """Testa criação de email válido"""
        email = Email("test@example.com")
        assert str(email) == "test@example.com"
        assert email.value == "test@example.com"
    
    def test_create_invalid_email(self):
        """Testa criação de email inválido"""
        with pytest.raises(ValidationError):
            Email("invalid-email")
        
        with pytest.raises(ValidationError):
            Email("@example.com")
        
        with pytest.raises(ValidationError):
            Email("test@")
        
        with pytest.raises(ValidationError):
            Email("")
    
    def test_email_equality(self):
        """Testa igualdade entre emails"""
        email1 = Email("test@example.com")
        email2 = Email("test@example.com")
        email3 = Email("other@example.com")
        
        assert email1 == email2
        assert email1 != email3
    
    def test_email_case_insensitive(self):
        """Testa que email é case insensitive"""
        email1 = Email("Test@Example.Com")
        email2 = Email("test@example.com")
        
        assert email1 == email2
        assert str(email1) == "test@example.com"
    
    def test_email_domain_validation(self):
        """Testa validação de domínio"""
        # Domínios válidos
        Email("test@example.com")
        Email("test@sub.example.com")
        Email("test@example.co.uk")
        
        # Domínios inválidos
        with pytest.raises(ValidationError):
            Email("test@.com")
        
        with pytest.raises(ValidationError):
            Email("test@com.")


class TestUnityCatalogPath:
    """Testes para value object UnityCatalogPath"""
    
    def test_create_valid_path(self):
        """Testa criação de path válido"""
        path = UnityCatalogPath.from_string("catalog.schema.table")
        
        assert path.catalog == "catalog"
        assert path.schema == "schema"
        assert path.table == "table"
        assert str(path) == "catalog.schema.table"
    
    def test_create_path_with_constructor(self):
        """Testa criação com construtor direto"""
        path = UnityCatalogPath("catalog", "schema", "table")
        
        assert path.catalog == "catalog"
        assert path.schema == "schema"
        assert path.table == "table"
        assert str(path) == "catalog.schema.table"
    
    def test_create_invalid_path_format(self):
        """Testa criação de path com formato inválido"""
        with pytest.raises(ValidationError):
            UnityCatalogPath.from_string("catalog.schema")  # Faltando table
        
        with pytest.raises(ValidationError):
            UnityCatalogPath.from_string("catalog")  # Faltando schema e table
        
        with pytest.raises(ValidationError):
            UnityCatalogPath.from_string("catalog.schema.table.extra")  # Muitas partes
        
        with pytest.raises(ValidationError):
            UnityCatalogPath.from_string("")  # String vazia
    
    def test_create_invalid_path_components(self):
        """Testa criação com componentes inválidos"""
        with pytest.raises(ValidationError):
            UnityCatalogPath("", "schema", "table")  # Catalog vazio
        
        with pytest.raises(ValidationError):
            UnityCatalogPath("catalog", "", "table")  # Schema vazio
        
        with pytest.raises(ValidationError):
            UnityCatalogPath("catalog", "schema", "")  # Table vazio
    
    def test_path_equality(self):
        """Testa igualdade entre paths"""
        path1 = UnityCatalogPath.from_string("catalog.schema.table")
        path2 = UnityCatalogPath("catalog", "schema", "table")
        path3 = UnityCatalogPath.from_string("other.schema.table")
        
        assert path1 == path2
        assert path1 != path3
    
    def test_path_case_sensitivity(self):
        """Testa sensibilidade a maiúsculas/minúsculas"""
        path1 = UnityCatalogPath.from_string("Catalog.Schema.Table")
        path2 = UnityCatalogPath.from_string("catalog.schema.table")
        
        # Unity Catalog paths são case sensitive
        assert path1 != path2
        assert path1.catalog == "Catalog"
        assert path2.catalog == "catalog"
    
    def test_path_validation_rules(self):
        """Testa regras de validação específicas"""
        # Nomes válidos
        UnityCatalogPath("catalog_1", "schema_2", "table_3")
        UnityCatalogPath("catalog-1", "schema-2", "table-3")
        
        # Nomes com caracteres especiais inválidos
        with pytest.raises(ValidationError):
            UnityCatalogPath("catalog@", "schema", "table")
        
        with pytest.raises(ValidationError):
            UnityCatalogPath("catalog", "schema#", "table")
        
        with pytest.raises(ValidationError):
            UnityCatalogPath("catalog", "schema", "table$")


class TestVersion:
    """Testes para value object Version"""
    
    def test_create_valid_version(self):
        """Testa criação de versão válida"""
        version = Version.from_string("1.0.0")
        
        assert version.major == 1
        assert version.minor == 0
        assert version.patch == 0
        assert version.prerelease is None
        assert str(version) == "1.0.0"
    
    def test_create_version_with_prerelease(self):
        """Testa criação de versão com prerelease"""
        version = Version.from_string("1.0.0-alpha.1")
        
        assert version.major == 1
        assert version.minor == 0
        assert version.patch == 0
        assert version.prerelease == "alpha.1"
        assert str(version) == "1.0.0-alpha.1"
    
    def test_create_version_with_constructor(self):
        """Testa criação com construtor direto"""
        version = Version(1, 2, 3, "beta")
        
        assert version.major == 1
        assert version.minor == 2
        assert version.patch == 3
        assert version.prerelease == "beta"
        assert str(version) == "1.2.3-beta"
    
    def test_create_invalid_version_format(self):
        """Testa criação de versão com formato inválido"""
        with pytest.raises(ValidationError):
            Version.from_string("1.0")  # Faltando patch
        
        with pytest.raises(ValidationError):
            Version.from_string("1")  # Faltando minor e patch
        
        with pytest.raises(ValidationError):
            Version.from_string("v1.0.0")  # Prefixo inválido
        
        with pytest.raises(ValidationError):
            Version.from_string("1.0.0.0")  # Muitas partes
        
        with pytest.raises(ValidationError):
            Version.from_string("")  # String vazia
    
    def test_create_invalid_version_numbers(self):
        """Testa criação com números inválidos"""
        with pytest.raises(ValidationError):
            Version(-1, 0, 0)  # Major negativo
        
        with pytest.raises(ValidationError):
            Version(1, -1, 0)  # Minor negativo
        
        with pytest.raises(ValidationError):
            Version(1, 0, -1)  # Patch negativo
    
    def test_version_comparison(self):
        """Testa comparação entre versões"""
        v1_0_0 = Version.from_string("1.0.0")
        v1_0_1 = Version.from_string("1.0.1")
        v1_1_0 = Version.from_string("1.1.0")
        v2_0_0 = Version.from_string("2.0.0")
        
        # Igualdade
        assert v1_0_0 == Version.from_string("1.0.0")
        
        # Menor que
        assert v1_0_0 < v1_0_1
        assert v1_0_1 < v1_1_0
        assert v1_1_0 < v2_0_0
        
        # Maior que
        assert v2_0_0 > v1_1_0
        assert v1_1_0 > v1_0_1
        assert v1_0_1 > v1_0_0
    
    def test_version_prerelease_comparison(self):
        """Testa comparação com prerelease"""
        v1_0_0 = Version.from_string("1.0.0")
        v1_0_0_alpha = Version.from_string("1.0.0-alpha")
        v1_0_0_beta = Version.from_string("1.0.0-beta")
        
        # Prerelease é menor que release
        assert v1_0_0_alpha < v1_0_0
        assert v1_0_0_beta < v1_0_0
        
        # Comparação entre prereleases (alfabética)
        assert v1_0_0_alpha < v1_0_0_beta
    
    def test_version_increment(self):
        """Testa incremento de versão"""
        version = Version.from_string("1.2.3")
        
        # Incrementar patch
        patch_version = version.increment_patch()
        assert str(patch_version) == "1.2.4"
        
        # Incrementar minor
        minor_version = version.increment_minor()
        assert str(minor_version) == "1.3.0"
        
        # Incrementar major
        major_version = version.increment_major()
        assert str(major_version) == "2.0.0"
    
    def test_version_is_compatible(self):
        """Testa compatibilidade entre versões"""
        v1_0_0 = Version.from_string("1.0.0")
        v1_0_1 = Version.from_string("1.0.1")
        v1_1_0 = Version.from_string("1.1.0")
        v2_0_0 = Version.from_string("2.0.0")
        
        # Compatibilidade semântica
        assert v1_0_0.is_compatible_with(v1_0_1)  # Patch compatible
        assert v1_0_0.is_compatible_with(v1_1_0)  # Minor compatible
        assert not v1_0_0.is_compatible_with(v2_0_0)  # Major incompatible

