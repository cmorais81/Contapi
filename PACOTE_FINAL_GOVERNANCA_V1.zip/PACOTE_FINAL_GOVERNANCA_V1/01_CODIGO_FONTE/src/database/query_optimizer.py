"""
Sistema de Otimização de Queries
Desenvolvido por Carlos Morais
"""

import asyncio
import hashlib
import time
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import Enum

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text, select, and_, func, desc
from sqlalchemy.engine import Result
from sqlalchemy.sql import ClauseElement

from database.models import QueryPerformanceLog
from database.connection import get_async_session
from config.settings import get_settings
from monitoring.audit_logger import audit_logger, EventType, Severity


class QueryType(str, Enum):
    """Tipos de query"""
    SELECT = "SELECT"
    INSERT = "INSERT"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    CREATE = "CREATE"
    DROP = "DROP"
    ALTER = "ALTER"


class OptimizationLevel(str, Enum):
    """Níveis de otimização"""
    NONE = "none"
    BASIC = "basic"
    ADVANCED = "advanced"
    AGGRESSIVE = "aggressive"


@dataclass
class QueryMetrics:
    """Métricas de performance de query"""
    execution_time_ms: int
    rows_returned: Optional[int]
    rows_examined: Optional[int]
    index_usage: Dict[str, Any]
    execution_plan: Dict[str, Any]
    memory_usage_mb: Optional[float]
    cpu_usage_percent: Optional[float]
    io_operations: Optional[int]


@dataclass
class OptimizationSuggestion:
    """Sugestão de otimização"""
    type: str
    priority: int  # 1-10, sendo 10 mais crítico
    description: str
    sql_suggestion: Optional[str]
    estimated_improvement: Optional[str]
    complexity: str  # "low", "medium", "high"


class QueryAnalyzer:
    """Analisador de queries para otimização"""
    
    def __init__(self):
        self.settings = get_settings()
        self.slow_query_threshold_ms = 1000  # 1 segundo
        self.very_slow_query_threshold_ms = 5000  # 5 segundos
    
    def analyze_query(self, query_text: str, metrics: QueryMetrics) -> List[OptimizationSuggestion]:
        """
        Analisa uma query e retorna sugestões de otimização
        
        Args:
            query_text: Texto da query SQL
            metrics: Métricas de performance
            
        Returns:
            Lista de sugestões de otimização
        """
        
        suggestions = []
        query_upper = query_text.upper().strip()
        
        # Análise de performance geral
        if metrics.execution_time_ms > self.very_slow_query_threshold_ms:
            suggestions.append(OptimizationSuggestion(
                type="performance_critical",
                priority=10,
                description=f"Query muito lenta: {metrics.execution_time_ms}ms. Requer otimização urgente.",
                sql_suggestion=None,
                estimated_improvement="50-80% redução no tempo",
                complexity="high"
            ))
        elif metrics.execution_time_ms > self.slow_query_threshold_ms:
            suggestions.append(OptimizationSuggestion(
                type="performance_warning",
                priority=7,
                description=f"Query lenta: {metrics.execution_time_ms}ms. Considere otimização.",
                sql_suggestion=None,
                estimated_improvement="20-50% redução no tempo",
                complexity="medium"
            ))
        
        # Análise de índices
        if not metrics.index_usage or not any(metrics.index_usage.values()):
            suggestions.append(OptimizationSuggestion(
                type="missing_index",
                priority=8,
                description="Query não está usando índices. Considere criar índices apropriados.",
                sql_suggestion=self._suggest_index_creation(query_text),
                estimated_improvement="70-90% redução no tempo",
                complexity="low"
            ))
        
        # Análise de SELECT *
        if "SELECT *" in query_upper:
            suggestions.append(OptimizationSuggestion(
                type="select_star",
                priority=5,
                description="Evite SELECT *. Especifique apenas as colunas necessárias.",
                sql_suggestion=self._suggest_specific_columns(query_text),
                estimated_improvement="10-30% redução no tempo e memória",
                complexity="low"
            ))
        
        # Análise de JOINs
        join_count = query_upper.count("JOIN")
        if join_count > 3:
            suggestions.append(OptimizationSuggestion(
                type="complex_joins",
                priority=6,
                description=f"Query com {join_count} JOINs. Considere otimizar ou dividir.",
                sql_suggestion=None,
                estimated_improvement="20-40% redução no tempo",
                complexity="high"
            ))
        
        # Análise de subconsultas
        if "(" in query_text and "SELECT" in query_upper:
            subquery_count = query_text.count("(") - query_text.count(")")
            if subquery_count > 0:
                suggestions.append(OptimizationSuggestion(
                    type="subqueries",
                    priority=6,
                    description="Considere converter subconsultas em JOINs quando possível.",
                    sql_suggestion=None,
                    estimated_improvement="15-35% redução no tempo",
                    complexity="medium"
                ))
        
        # Análise de ORDER BY sem LIMIT
        if "ORDER BY" in query_upper and "LIMIT" not in query_upper:
            if metrics.rows_returned and metrics.rows_returned > 1000:
                suggestions.append(OptimizationSuggestion(
                    type="order_without_limit",
                    priority=7,
                    description="ORDER BY sem LIMIT em resultado grande. Considere paginação.",
                    sql_suggestion=self._suggest_pagination(query_text),
                    estimated_improvement="40-60% redução no tempo",
                    complexity="low"
                ))
        
        # Análise de LIKE com wildcard inicial
        if "LIKE '%" in query_upper:
            suggestions.append(OptimizationSuggestion(
                type="like_wildcard",
                priority=6,
                description="LIKE com wildcard inicial não pode usar índices. Considere full-text search.",
                sql_suggestion=None,
                estimated_improvement="50-80% redução no tempo",
                complexity="medium"
            ))
        
        # Análise de funções em WHERE
        where_functions = ["UPPER(", "LOWER(", "SUBSTRING(", "DATE("]
        for func_name in where_functions:
            if func_name in query_upper and "WHERE" in query_upper:
                suggestions.append(OptimizationSuggestion(
                    type="function_in_where",
                    priority=6,
                    description=f"Função {func_name} em WHERE impede uso de índices.",
                    sql_suggestion=None,
                    estimated_improvement="30-50% redução no tempo",
                    complexity="medium"
                ))
                break
        
        return sorted(suggestions, key=lambda x: x.priority, reverse=True)
    
    def _suggest_index_creation(self, query_text: str) -> Optional[str]:
        """Sugere criação de índices baseado na query"""
        
        # Análise simples para sugerir índices
        query_upper = query_text.upper()
        
        # Extrair tabelas e colunas de WHERE
        if "WHERE" in query_upper:
            # Esta é uma implementação simplificada
            # Em produção, seria necessário um parser SQL mais robusto
            return "-- Analise as colunas usadas em WHERE, JOIN e ORDER BY para criar índices apropriados"
        
        return None
    
    def _suggest_specific_columns(self, query_text: str) -> Optional[str]:
        """Sugere colunas específicas ao invés de SELECT *"""
        
        return query_text.replace("SELECT *", "SELECT col1, col2, col3 -- especifique apenas as colunas necessárias")
    
    def _suggest_pagination(self, query_text: str) -> Optional[str]:
        """Sugere adição de paginação"""
        
        if "ORDER BY" in query_text.upper():
            return f"{query_text.rstrip(';')} LIMIT 50 OFFSET 0;"
        
        return f"{query_text.rstrip(';')} LIMIT 50;"


class QueryPerformanceMonitor:
    """Monitor de performance de queries"""
    
    def __init__(self):
        self.analyzer = QueryAnalyzer()
        self.settings = get_settings()
    
    async def log_query_performance(
        self,
        query_text: str,
        execution_time_ms: int,
        rows_returned: Optional[int] = None,
        rows_examined: Optional[int] = None,
        endpoint: Optional[str] = None,
        user_id: Optional[str] = None,
        session: Optional[AsyncSession] = None
    ):
        """
        Registra performance de uma query
        
        Args:
            query_text: Texto da query SQL
            execution_time_ms: Tempo de execução em milissegundos
            rows_returned: Número de linhas retornadas
            rows_examined: Número de linhas examinadas
            endpoint: Endpoint que executou a query
            user_id: ID do usuário
            session: Sessão do banco de dados
        """
        
        async def _log_performance(db_session: AsyncSession):
            try:
                # Calcular hash da query
                query_hash = hashlib.sha256(
                    self._normalize_query(query_text).encode()
                ).hexdigest()
                
                # Métricas básicas
                metrics = QueryMetrics(
                    execution_time_ms=execution_time_ms,
                    rows_returned=rows_returned,
                    rows_examined=rows_examined,
                    index_usage={},  # Seria obtido do plano de execução
                    execution_plan={},  # Seria obtido do EXPLAIN
                    memory_usage_mb=None,
                    cpu_usage_percent=None,
                    io_operations=None
                )
                
                # Analisar query
                suggestions = self.analyzer.analyze_query(query_text, metrics)
                
                # Determinar se é query lenta
                is_slow = execution_time_ms > self.analyzer.slow_query_threshold_ms
                
                # Criar log de performance
                perf_log = QueryPerformanceLog(
                    query_hash=query_hash,
                    query_text=query_text,
                    execution_time_ms=execution_time_ms,
                    rows_returned=rows_returned,
                    rows_examined=rows_examined,
                    index_usage={},
                    execution_plan={},
                    endpoint=endpoint,
                    user_id=user_id,
                    table_names=self._extract_table_names(query_text),
                    is_slow_query=is_slow,
                    optimization_suggestions={
                        "suggestions": [
                            {
                                "type": s.type,
                                "priority": s.priority,
                                "description": s.description,
                                "sql_suggestion": s.sql_suggestion,
                                "estimated_improvement": s.estimated_improvement,
                                "complexity": s.complexity
                            }
                            for s in suggestions
                        ]
                    }
                )
                
                db_session.add(perf_log)
                await db_session.commit()
                
                # Log de auditoria para queries muito lentas
                if execution_time_ms > self.analyzer.very_slow_query_threshold_ms:
                    await audit_logger.log_event(
                        event_type=EventType.SYSTEM_EVENT,
                        resource_type="query_performance",
                        resource_id=query_hash,
                        user_id=user_id,
                        additional_metadata={
                            "execution_time_ms": execution_time_ms,
                            "endpoint": endpoint,
                            "suggestions_count": len(suggestions),
                            "query_preview": query_text[:200] + "..." if len(query_text) > 200 else query_text
                        },
                        severity=Severity.WARN,
                        tags=["performance", "slow_query"],
                        session=db_session
                    )
                
            except Exception as e:
                # Não falhar a aplicação por erro de log
                print(f"Error logging query performance: {e}")
        
        if session:
            await _log_performance(session)
        else:
            async with get_async_session() as db_session:
                await _log_performance(db_session)
    
    def _normalize_query(self, query_text: str) -> str:
        """Normaliza query para hash consistente"""
        
        # Remove espaços extras, quebras de linha e comentários
        normalized = " ".join(query_text.split())
        
        # Remove valores literais para agrupar queries similares
        # Esta é uma implementação simplificada
        import re
        
        # Remove números
        normalized = re.sub(r'\b\d+\b', '?', normalized)
        
        # Remove strings entre aspas
        normalized = re.sub(r"'[^']*'", "'?'", normalized)
        normalized = re.sub(r'"[^"]*"', '"?"', normalized)
        
        return normalized.upper()
    
    def _extract_table_names(self, query_text: str) -> List[str]:
        """Extrai nomes de tabelas da query"""
        
        # Implementação simplificada
        # Em produção, usaria um parser SQL mais robusto
        import re
        
        tables = []
        
        # Padrões para encontrar tabelas
        patterns = [
            r'FROM\s+(\w+)',
            r'JOIN\s+(\w+)',
            r'UPDATE\s+(\w+)',
            r'INSERT\s+INTO\s+(\w+)',
            r'DELETE\s+FROM\s+(\w+)'
        ]
        
        query_upper = query_text.upper()
        
        for pattern in patterns:
            matches = re.findall(pattern, query_upper)
            tables.extend(matches)
        
        return list(set(tables))  # Remove duplicatas
    
    async def get_slow_queries_report(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        limit: int = 50,
        session: Optional[AsyncSession] = None
    ) -> List[Dict[str, Any]]:
        """
        Gera relatório de queries lentas
        
        Args:
            start_date: Data inicial
            end_date: Data final
            limit: Limite de resultados
            session: Sessão do banco de dados
            
        Returns:
            Lista de queries lentas com estatísticas
        """
        
        async def _get_report(db_session: AsyncSession) -> List[Dict[str, Any]]:
            # Definir período padrão (últimos 7 dias)
            if not end_date:
                end_date_filter = datetime.utcnow()
            else:
                end_date_filter = end_date
                
            if not start_date:
                start_date_filter = end_date_filter - timedelta(days=7)
            else:
                start_date_filter = start_date
            
            # Query para buscar queries lentas
            query = select(
                QueryPerformanceLog.query_hash,
                QueryPerformanceLog.query_text,
                func.count().label('execution_count'),
                func.avg(QueryPerformanceLog.execution_time_ms).label('avg_execution_time'),
                func.max(QueryPerformanceLog.execution_time_ms).label('max_execution_time'),
                func.min(QueryPerformanceLog.execution_time_ms).label('min_execution_time'),
                func.sum(QueryPerformanceLog.execution_time_ms).label('total_execution_time'),
                QueryPerformanceLog.optimization_suggestions
            ).where(
                and_(
                    QueryPerformanceLog.is_slow_query == True,
                    QueryPerformanceLog.created_at >= start_date_filter,
                    QueryPerformanceLog.created_at <= end_date_filter
                )
            ).group_by(
                QueryPerformanceLog.query_hash,
                QueryPerformanceLog.query_text,
                QueryPerformanceLog.optimization_suggestions
            ).order_by(
                desc('total_execution_time')
            ).limit(limit)
            
            result = await db_session.execute(query)
            rows = result.fetchall()
            
            report = []
            for row in rows:
                report.append({
                    'query_hash': row.query_hash,
                    'query_text': row.query_text[:500] + "..." if len(row.query_text) > 500 else row.query_text,
                    'execution_count': row.execution_count,
                    'avg_execution_time_ms': round(float(row.avg_execution_time), 2),
                    'max_execution_time_ms': row.max_execution_time,
                    'min_execution_time_ms': row.min_execution_time,
                    'total_execution_time_ms': row.total_execution_time,
                    'optimization_suggestions': row.optimization_suggestions
                })
            
            return report
        
        if session:
            return await _get_report(session)
        else:
            async with get_async_session() as db_session:
                return await _get_report(db_session)


class QueryOptimizer:
    """Otimizador automático de queries"""
    
    def __init__(self):
        self.monitor = QueryPerformanceMonitor()
        self.settings = get_settings()
    
    async def optimize_query(
        self,
        query_text: str,
        optimization_level: OptimizationLevel = OptimizationLevel.BASIC
    ) -> Tuple[str, List[OptimizationSuggestion]]:
        """
        Otimiza uma query automaticamente
        
        Args:
            query_text: Query original
            optimization_level: Nível de otimização
            
        Returns:
            Tupla com (query_otimizada, sugestões_aplicadas)
        """
        
        optimized_query = query_text
        applied_suggestions = []
        
        # Métricas simuladas para análise
        metrics = QueryMetrics(
            execution_time_ms=0,
            rows_returned=None,
            rows_examined=None,
            index_usage={},
            execution_plan={},
            memory_usage_mb=None,
            cpu_usage_percent=None,
            io_operations=None
        )
        
        # Obter sugestões
        suggestions = self.monitor.analyzer.analyze_query(query_text, metrics)
        
        # Aplicar otimizações baseadas no nível
        for suggestion in suggestions:
            if self._should_apply_suggestion(suggestion, optimization_level):
                if suggestion.sql_suggestion:
                    optimized_query = suggestion.sql_suggestion
                    applied_suggestions.append(suggestion)
        
        return optimized_query, applied_suggestions
    
    def _should_apply_suggestion(
        self,
        suggestion: OptimizationSuggestion,
        optimization_level: OptimizationLevel
    ) -> bool:
        """Determina se uma sugestão deve ser aplicada baseada no nível"""
        
        if optimization_level == OptimizationLevel.NONE:
            return False
        elif optimization_level == OptimizationLevel.BASIC:
            return suggestion.complexity == "low" and suggestion.priority >= 7
        elif optimization_level == OptimizationLevel.ADVANCED:
            return suggestion.complexity in ["low", "medium"] and suggestion.priority >= 5
        elif optimization_level == OptimizationLevel.AGGRESSIVE:
            return suggestion.priority >= 3
        
        return False
    
    async def create_recommended_indexes(
        self,
        session: Optional[AsyncSession] = None
    ) -> List[str]:
        """
        Cria índices recomendados baseado no histórico de queries
        
        Returns:
            Lista de comandos SQL para criar índices
        """
        
        async def _create_indexes(db_session: AsyncSession) -> List[str]:
            # Buscar queries lentas mais frequentes
            slow_queries = await self.monitor.get_slow_queries_report(
                start_date=datetime.utcnow() - timedelta(days=30),
                limit=20,
                session=db_session
            )
            
            index_commands = []
            
            for query_data in slow_queries:
                suggestions = query_data.get('optimization_suggestions', {}).get('suggestions', [])
                
                for suggestion in suggestions:
                    if suggestion['type'] == 'missing_index' and suggestion['sql_suggestion']:
                        # Extrair comando de criação de índice
                        if 'CREATE INDEX' in suggestion['sql_suggestion'].upper():
                            index_commands.append(suggestion['sql_suggestion'])
            
            # Remover duplicatas
            return list(set(index_commands))
        
        if session:
            return await _create_indexes(session)
        else:
            async with get_async_session() as db_session:
                return await _create_indexes(db_session)


# Instância global do monitor
query_monitor = QueryPerformanceMonitor()
query_optimizer = QueryOptimizer()

