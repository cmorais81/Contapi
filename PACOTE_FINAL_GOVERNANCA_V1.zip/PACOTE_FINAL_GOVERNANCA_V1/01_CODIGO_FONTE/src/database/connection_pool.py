"""
Sistema de Connection Pooling Avançado
Desenvolvido por Carlos Morais
"""

import asyncio
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass
from enum import Enum

from sqlalchemy.ext.asyncio import create_async_engine, AsyncEngine, AsyncSession
from sqlalchemy.pool import QueuePool, NullPool, StaticPool
from sqlalchemy.engine.events import event
from sqlalchemy import text, select
from sqlalchemy.exc import SQLAlchemyError, DisconnectionError

from database.models import ConnectionPoolMetrics
from config.settings import get_settings
from monitoring.audit_logger import audit_logger, EventType, Severity


class PoolStatus(str, Enum):
    """Status do pool de conexões"""
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"
    OFFLINE = "offline"


class ConnectionStatus(str, Enum):
    """Status de uma conexão"""
    ACTIVE = "active"
    IDLE = "idle"
    INVALID = "invalid"
    TESTING = "testing"


@dataclass
class PoolConfiguration:
    """Configuração do pool de conexões"""
    pool_size: int = 20
    max_overflow: int = 30
    pool_timeout: int = 30
    pool_recycle: int = 3600  # 1 hora
    pool_pre_ping: bool = True
    pool_reset_on_return: str = "commit"
    echo: bool = False
    echo_pool: bool = False


@dataclass
class PoolMetrics:
    """Métricas do pool de conexões"""
    pool_name: str
    active_connections: int
    idle_connections: int
    total_connections: int
    max_connections: int
    overflow_connections: int
    failed_connections: int
    connection_wait_time_ms: Optional[int]
    connection_creation_time_ms: Optional[int]
    pool_utilization_percent: float
    health_status: PoolStatus
    last_health_check: datetime
    uptime_seconds: int


class ConnectionHealthChecker:
    """Verificador de saúde das conexões"""
    
    def __init__(self, check_interval: int = 30):
        self.check_interval = check_interval
        self.last_check = {}
        self.failed_checks = {}
        self.max_failed_checks = 3
    
    async def check_connection_health(self, engine: AsyncEngine, pool_name: str) -> bool:
        """
        Verifica a saúde de uma conexão
        
        Args:
            engine: Engine do SQLAlchemy
            pool_name: Nome do pool
            
        Returns:
            True se a conexão está saudável
        """
        
        try:
            async with engine.begin() as conn:
                # Teste simples de conectividade
                result = await conn.execute(text("SELECT 1"))
                row = result.fetchone()
                
                if row and row[0] == 1:
                    # Reset contador de falhas
                    self.failed_checks[pool_name] = 0
                    self.last_check[pool_name] = datetime.utcnow()
                    return True
                else:
                    raise Exception("Health check query returned unexpected result")
                    
        except Exception as e:
            # Incrementar contador de falhas
            self.failed_checks[pool_name] = self.failed_checks.get(pool_name, 0) + 1
            
            # Log do erro
            await audit_logger.log_event(
                event_type=EventType.SYSTEM_EVENT,
                resource_type="connection_pool",
                additional_metadata={
                    "pool_name": pool_name,
                    "health_check_failed": True,
                    "error": str(e),
                    "failed_checks_count": self.failed_checks[pool_name]
                },
                severity=Severity.WARN,
                tags=["database", "health_check", "failure"]
            )
            
            return False
    
    async def is_pool_healthy(self, engine: AsyncEngine, pool_name: str) -> bool:
        """Verifica se o pool está saudável"""
        
        # Verificar se precisa fazer health check
        last_check = self.last_check.get(pool_name)
        if last_check and (datetime.utcnow() - last_check).seconds < self.check_interval:
            # Usar resultado do último check
            return self.failed_checks.get(pool_name, 0) < self.max_failed_checks
        
        # Fazer novo health check
        is_healthy = await self.check_connection_health(engine, pool_name)
        
        # Se falhou muitas vezes, considerar não saudável
        if self.failed_checks.get(pool_name, 0) >= self.max_failed_checks:
            return False
        
        return is_healthy


class AdaptiveConnectionPool:
    """Pool de conexões adaptativo com auto-scaling"""
    
    def __init__(self, database_url: str, pool_name: str = "default"):
        self.database_url = database_url
        self.pool_name = pool_name
        self.engine: Optional[AsyncEngine] = None
        self.config = PoolConfiguration()
        self.health_checker = ConnectionHealthChecker()
        self.metrics_history: List[PoolMetrics] = []
        self.created_at = datetime.utcnow()
        self.connection_events = {}
        self.auto_scaling_enabled = True
        self.min_pool_size = 5
        self.max_pool_size = 50
        
        # Configurações adaptativas
        self.load_threshold_scale_up = 0.8  # 80% de utilização
        self.load_threshold_scale_down = 0.3  # 30% de utilização
        self.scale_check_interval = 60  # 1 minuto
        self.last_scale_check = datetime.utcnow()
    
    async def initialize(self, config: Optional[PoolConfiguration] = None):
        """Inicializa o pool de conexões"""
        
        if config:
            self.config = config
        
        # Criar engine com configurações otimizadas
        self.engine = create_async_engine(
            self.database_url,
            poolclass=QueuePool,
            pool_size=self.config.pool_size,
            max_overflow=self.config.max_overflow,
            pool_timeout=self.config.pool_timeout,
            pool_recycle=self.config.pool_recycle,
            pool_pre_ping=self.config.pool_pre_ping,
            pool_reset_on_return=self.config.pool_reset_on_return,
            echo=self.config.echo,
            echo_pool=self.config.echo_pool,
            # Configurações adicionais para performance
            connect_args={
                "server_settings": {
                    "application_name": f"governance_api_{self.pool_name}",
                    "tcp_keepalives_idle": "600",
                    "tcp_keepalives_interval": "30",
                    "tcp_keepalives_count": "3",
                }
            }
        )
        
        # Configurar event listeners
        self._setup_event_listeners()
        
        # Log da inicialização
        await audit_logger.log_event(
            event_type=EventType.SYSTEM_EVENT,
            resource_type="connection_pool",
            additional_metadata={
                "pool_name": self.pool_name,
                "action": "initialized",
                "config": {
                    "pool_size": self.config.pool_size,
                    "max_overflow": self.config.max_overflow,
                    "pool_timeout": self.config.pool_timeout
                }
            },
            severity=Severity.INFO,
            tags=["database", "pool_init"]
        )
    
    def _setup_event_listeners(self):
        """Configura listeners de eventos do pool"""
        
        @event.listens_for(self.engine.sync_engine, "connect")
        def on_connect(dbapi_connection, connection_record):
            """Evento de nova conexão"""
            connection_id = id(dbapi_connection)
            self.connection_events[connection_id] = {
                "connected_at": time.time(),
                "status": ConnectionStatus.ACTIVE,
                "queries_executed": 0,
                "last_activity": time.time()
            }
        
        @event.listens_for(self.engine.sync_engine, "checkout")
        def on_checkout(dbapi_connection, connection_record, connection_proxy):
            """Evento de checkout de conexão"""
            connection_id = id(dbapi_connection)
            if connection_id in self.connection_events:
                self.connection_events[connection_id]["status"] = ConnectionStatus.ACTIVE
                self.connection_events[connection_id]["last_activity"] = time.time()
        
        @event.listens_for(self.engine.sync_engine, "checkin")
        def on_checkin(dbapi_connection, connection_record):
            """Evento de checkin de conexão"""
            connection_id = id(dbapi_connection)
            if connection_id in self.connection_events:
                self.connection_events[connection_id]["status"] = ConnectionStatus.IDLE
                self.connection_events[connection_id]["last_activity"] = time.time()
        
        @event.listens_for(self.engine.sync_engine, "close")
        def on_close(dbapi_connection, connection_record):
            """Evento de fechamento de conexão"""
            connection_id = id(dbapi_connection)
            if connection_id in self.connection_events:
                connection_info = self.connection_events.pop(connection_id)
                connection_duration = time.time() - connection_info["connected_at"]
                
                # Log de conexão longa
                if connection_duration > 1800:  # 30 minutos
                    asyncio.create_task(self._log_long_connection(
                        connection_duration=connection_duration,
                        queries_executed=connection_info["queries_executed"]
                    ))
    
    async def get_metrics(self) -> PoolMetrics:
        """Obtém métricas atuais do pool"""
        
        if not self.engine:
            raise RuntimeError("Pool not initialized")
        
        pool = self.engine.pool
        
        # Calcular métricas
        active_connections = pool.checkedout()
        idle_connections = pool.checkedin()
        total_connections = pool.size()
        max_connections = pool.size() + pool.overflow()
        overflow_connections = pool.overflow()
        
        # Calcular utilização
        utilization = (active_connections / max(total_connections, 1)) * 100
        
        # Determinar status de saúde
        health_status = PoolStatus.HEALTHY
        if utilization > 90:
            health_status = PoolStatus.CRITICAL
        elif utilization > 75:
            health_status = PoolStatus.WARNING
        
        # Verificar saúde das conexões
        is_healthy = await self.health_checker.is_pool_healthy(self.engine, self.pool_name)
        if not is_healthy:
            health_status = PoolStatus.OFFLINE
        
        metrics = PoolMetrics(
            pool_name=self.pool_name,
            active_connections=active_connections,
            idle_connections=idle_connections,
            total_connections=total_connections,
            max_connections=max_connections,
            overflow_connections=overflow_connections,
            failed_connections=self.health_checker.failed_checks.get(self.pool_name, 0),
            connection_wait_time_ms=None,  # Seria calculado com métricas mais avançadas
            connection_creation_time_ms=None,
            pool_utilization_percent=round(utilization, 2),
            health_status=health_status,
            last_health_check=self.health_checker.last_check.get(self.pool_name, datetime.utcnow()),
            uptime_seconds=int((datetime.utcnow() - self.created_at).total_seconds())
        )
        
        # Adicionar ao histórico
        self.metrics_history.append(metrics)
        
        # Manter apenas últimas 100 métricas
        if len(self.metrics_history) > 100:
            self.metrics_history = self.metrics_history[-100:]
        
        return metrics
    
    async def auto_scale_pool(self):
        """Auto-scaling do pool baseado na utilização"""
        
        if not self.auto_scaling_enabled or not self.engine:
            return
        
        # Verificar se é hora de fazer scaling
        now = datetime.utcnow()
        if (now - self.last_scale_check).seconds < self.scale_check_interval:
            return
        
        self.last_scale_check = now
        
        # Obter métricas atuais
        metrics = await self.get_metrics()
        
        # Decidir se deve fazer scale up ou down
        current_size = self.config.pool_size
        new_size = current_size
        
        if metrics.pool_utilization_percent > (self.load_threshold_scale_up * 100):
            # Scale up
            new_size = min(current_size + 5, self.max_pool_size)
        elif metrics.pool_utilization_percent < (self.load_threshold_scale_down * 100):
            # Scale down
            new_size = max(current_size - 2, self.min_pool_size)
        
        # Aplicar mudança se necessário
        if new_size != current_size:
            await self._resize_pool(new_size, metrics.pool_utilization_percent)
    
    async def _resize_pool(self, new_size: int, current_utilization: float):
        """Redimensiona o pool de conexões"""
        
        old_size = self.config.pool_size
        self.config.pool_size = new_size
        
        # Recriar engine com novo tamanho
        # Nota: Em produção, seria necessário uma estratégia mais sofisticada
        # para não interromper conexões ativas
        
        await audit_logger.log_event(
            event_type=EventType.SYSTEM_EVENT,
            resource_type="connection_pool",
            additional_metadata={
                "pool_name": self.pool_name,
                "action": "auto_scaled",
                "old_size": old_size,
                "new_size": new_size,
                "utilization_percent": current_utilization,
                "reason": "auto_scaling"
            },
            severity=Severity.INFO,
            tags=["database", "auto_scaling"]
        )
    
    async def _log_long_connection(self, connection_duration: float, queries_executed: int):
        """Log de conexões longas"""
        
        await audit_logger.log_event(
            event_type=EventType.SYSTEM_EVENT,
            resource_type="database_connection",
            additional_metadata={
                "pool_name": self.pool_name,
                "connection_duration_seconds": round(connection_duration, 2),
                "queries_executed": queries_executed,
                "avg_time_per_query": round(connection_duration / max(queries_executed, 1), 2)
            },
            severity=Severity.WARN,
            tags=["database", "long_connection"]
        )
    
    async def get_session(self) -> AsyncSession:
        """Obtém uma sessão do pool"""
        
        if not self.engine:
            raise RuntimeError("Pool not initialized")
        
        # Auto-scaling check
        await self.auto_scale_pool()
        
        return AsyncSession(self.engine)
    
    async def close(self):
        """Fecha o pool de conexões"""
        
        if self.engine:
            await self.engine.dispose()
            
            await audit_logger.log_event(
                event_type=EventType.SYSTEM_EVENT,
                resource_type="connection_pool",
                additional_metadata={
                    "pool_name": self.pool_name,
                    "action": "closed",
                    "uptime_seconds": int((datetime.utcnow() - self.created_at).total_seconds())
                },
                severity=Severity.INFO,
                tags=["database", "pool_close"]
            )


class ConnectionPoolManager:
    """Gerenciador de múltiplos pools de conexão"""
    
    def __init__(self):
        self.pools: Dict[str, AdaptiveConnectionPool] = {}
        self.settings = get_settings()
        self.monitoring_task: Optional[asyncio.Task] = None
        self.monitoring_interval = 60  # 1 minuto
    
    async def create_pool(
        self,
        name: str,
        database_url: str,
        config: Optional[PoolConfiguration] = None
    ) -> AdaptiveConnectionPool:
        """Cria um novo pool de conexões"""
        
        if name in self.pools:
            raise ValueError(f"Pool '{name}' already exists")
        
        pool = AdaptiveConnectionPool(database_url, name)
        await pool.initialize(config)
        
        self.pools[name] = pool
        
        # Iniciar monitoramento se for o primeiro pool
        if len(self.pools) == 1 and not self.monitoring_task:
            self.monitoring_task = asyncio.create_task(self._monitoring_loop())
        
        return pool
    
    async def get_pool(self, name: str = "default") -> AdaptiveConnectionPool:
        """Obtém um pool por nome"""
        
        if name not in self.pools:
            # Criar pool padrão se não existir
            if name == "default":
                return await self.create_pool(
                    name="default",
                    database_url=self.settings.database_url
                )
            else:
                raise ValueError(f"Pool '{name}' not found")
        
        return self.pools[name]
    
    async def get_session(self, pool_name: str = "default") -> AsyncSession:
        """Obtém uma sessão de um pool específico"""
        
        pool = await self.get_pool(pool_name)
        return await pool.get_session()
    
    async def get_all_metrics(self) -> Dict[str, PoolMetrics]:
        """Obtém métricas de todos os pools"""
        
        metrics = {}
        for name, pool in self.pools.items():
            metrics[name] = await pool.get_metrics()
        
        return metrics
    
    async def _monitoring_loop(self):
        """Loop de monitoramento dos pools"""
        
        while True:
            try:
                await asyncio.sleep(self.monitoring_interval)
                
                # Coletar métricas de todos os pools
                all_metrics = await self.get_all_metrics()
                
                # Salvar métricas no banco
                for pool_name, metrics in all_metrics.items():
                    await self._save_pool_metrics(metrics)
                
                # Verificar pools com problemas
                for pool_name, metrics in all_metrics.items():
                    if metrics.health_status in [PoolStatus.CRITICAL, PoolStatus.OFFLINE]:
                        await audit_logger.log_event(
                            event_type=EventType.SYSTEM_EVENT,
                            resource_type="connection_pool",
                            additional_metadata={
                                "pool_name": pool_name,
                                "health_status": metrics.health_status.value,
                                "utilization_percent": metrics.pool_utilization_percent,
                                "failed_connections": metrics.failed_connections
                            },
                            severity=Severity.ERROR if metrics.health_status == PoolStatus.OFFLINE else Severity.WARN,
                            tags=["database", "pool_health", "alert"]
                        )
                
            except Exception as e:
                print(f"Error in pool monitoring loop: {e}")
    
    async def _save_pool_metrics(self, metrics: PoolMetrics):
        """Salva métricas do pool no banco"""
        
        try:
            pool = await self.get_pool("default")  # Usar pool padrão para salvar métricas
            
            async with await pool.get_session() as session:
                pool_metrics = ConnectionPoolMetrics(
                    pool_name=metrics.pool_name,
                    active_connections=metrics.active_connections,
                    idle_connections=metrics.idle_connections,
                    total_connections=metrics.total_connections,
                    max_connections=metrics.max_connections,
                    connection_wait_time_ms=metrics.connection_wait_time_ms,
                    connection_creation_time_ms=metrics.connection_creation_time_ms,
                    failed_connections=metrics.failed_connections,
                    pool_utilization_percent=metrics.pool_utilization_percent,
                    health_status=metrics.health_status.value,
                    additional_metrics={
                        "overflow_connections": metrics.overflow_connections,
                        "uptime_seconds": metrics.uptime_seconds,
                        "last_health_check": metrics.last_health_check.isoformat()
                    }
                )
                
                session.add(pool_metrics)
                await session.commit()
                
        except Exception as e:
            print(f"Error saving pool metrics: {e}")
    
    async def close_all(self):
        """Fecha todos os pools"""
        
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
        
        for pool in self.pools.values():
            await pool.close()
        
        self.pools.clear()


# Instância global do gerenciador
pool_manager = ConnectionPoolManager()

