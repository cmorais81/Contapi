"""
Repositórios para acesso a dados
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, Generic, List, Optional, TypeVar
from uuid import UUID

from sqlalchemy import and_, delete, func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from domain.exceptions import EntityNotFoundError
from database.connection import Base

T = TypeVar("T", bound=Base)


class BaseRepository(Generic[T], ABC):
    """Repositório base com operações CRUD"""
    
    def __init__(self, session: AsyncSession, model_class: type[T]):
        self.session = session
        self.model_class = model_class
    
    async def create(self, entity: T) -> T:
        """Cria uma nova entidade"""
        self.session.add(entity)
        await self.session.flush()
        await self.session.refresh(entity)
        return entity
    
    async def get_by_id(self, id: UUID) -> Optional[T]:
        """Busca entidade por ID"""
        result = await self.session.execute(
            select(self.model_class).where(self.model_class.id == id)
        )
        return result.scalar_one_or_none()
    
    async def get_by_id_or_raise(self, id: UUID) -> T:
        """Busca entidade por ID ou levanta exceção"""
        entity = await self.get_by_id(id)
        if not entity:
            raise EntityNotFoundError(
                f"{self.model_class.__name__} com ID {id} não encontrado"
            )
        return entity
    
    async def update(self, id: UUID, **kwargs) -> T:
        """Atualiza entidade"""
        entity = await self.get_by_id_or_raise(id)
        for key, value in kwargs.items():
            if hasattr(entity, key):
                setattr(entity, key, value)
        
        await self.session.flush()
        await self.session.refresh(entity)
        return entity
    
    async def delete(self, id: UUID) -> bool:
        """Remove entidade"""
        result = await self.session.execute(
            delete(self.model_class).where(self.model_class.id == id)
        )
        return result.rowcount > 0
    
    async def list_all(
        self,
        offset: int = 0,
        limit: int = 100,
        order_by: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[T]:
        """Lista entidades com paginação e filtros"""
        query = select(self.model_class)
        
        # Aplicar filtros
        if filters:
            conditions = []
            for key, value in filters.items():
                if hasattr(self.model_class, key):
                    attr = getattr(self.model_class, key)
                    if isinstance(value, list):
                        conditions.append(attr.in_(value))
                    elif isinstance(value, str) and "%" in value:
                        conditions.append(attr.like(value))
                    else:
                        conditions.append(attr == value)
            
            if conditions:
                query = query.where(and_(*conditions))
        
        # Aplicar ordenação
        if order_by:
            if order_by.startswith("-"):
                # Ordenação descendente
                attr_name = order_by[1:]
                if hasattr(self.model_class, attr_name):
                    attr = getattr(self.model_class, attr_name)
                    query = query.order_by(attr.desc())
            else:
                # Ordenação ascendente
                if hasattr(self.model_class, order_by):
                    attr = getattr(self.model_class, order_by)
                    query = query.order_by(attr.asc())
        else:
            # Ordenação padrão por created_at
            if hasattr(self.model_class, "created_at"):
                query = query.order_by(self.model_class.created_at.desc())
        
        # Aplicar paginação
        query = query.offset(offset).limit(limit)
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def count(self, filters: Optional[Dict[str, Any]] = None) -> int:
        """Conta entidades com filtros"""
        query = select(func.count(self.model_class.id))
        
        if filters:
            conditions = []
            for key, value in filters.items():
                if hasattr(self.model_class, key):
                    attr = getattr(self.model_class, key)
                    if isinstance(value, list):
                        conditions.append(attr.in_(value))
                    elif isinstance(value, str) and "%" in value:
                        conditions.append(attr.like(value))
                    else:
                        conditions.append(attr == value)
            
            if conditions:
                query = query.where(and_(*conditions))
        
        result = await self.session.execute(query)
        return result.scalar() or 0
    
    async def exists(self, **kwargs) -> bool:
        """Verifica se entidade existe"""
        conditions = []
        for key, value in kwargs.items():
            if hasattr(self.model_class, key):
                attr = getattr(self.model_class, key)
                conditions.append(attr == value)
        
        if not conditions:
            return False
        
        query = select(func.count(self.model_class.id)).where(and_(*conditions))
        result = await self.session.execute(query)
        count = result.scalar() or 0
        return count > 0
    
    async def search(
        self,
        search_term: str,
        search_fields: List[str],
        offset: int = 0,
        limit: int = 100
    ) -> List[T]:
        """Busca textual em campos específicos"""
        conditions = []
        search_pattern = f"%{search_term}%"
        
        for field in search_fields:
            if hasattr(self.model_class, field):
                attr = getattr(self.model_class, field)
                conditions.append(attr.ilike(search_pattern))
        
        if not conditions:
            return []
        
        query = select(self.model_class).where(or_(*conditions))
        
        # Ordenação por relevância (campos que começam com o termo primeiro)
        if hasattr(self.model_class, "name"):
            query = query.order_by(
                self.model_class.name.ilike(f"{search_term}%").desc(),
                self.model_class.name
            )
        
        query = query.offset(offset).limit(limit)
        
        result = await self.session.execute(query)
        return list(result.scalars().all())


class DataContractRepository(BaseRepository):
    """Repositório para contratos de dados"""
    
    def __init__(self, session: AsyncSession):
        from database.models import DataContract
        super().__init__(session, DataContract)
    
    async def get_by_name_and_domain(
        self, 
        name: str, 
        domain_id: Optional[UUID] = None
    ) -> Optional[Any]:
        """Busca contrato por nome e domínio"""
        query = select(self.model_class).where(self.model_class.name == name)
        
        if domain_id:
            query = query.where(self.model_class.domain_id == domain_id)
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def get_with_versions(self, id: UUID) -> Optional[Any]:
        """Busca contrato com suas versões"""
        query = select(self.model_class).options(
            selectinload(self.model_class.versions)
        ).where(self.model_class.id == id)
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def get_by_unity_catalog_path(self, path: str) -> Optional[Any]:
        """Busca contrato por caminho do Unity Catalog"""
        query = select(self.model_class).where(
            self.model_class.unity_catalog_path == path
        )
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def get_by_status(self, status: str) -> List[Any]:
        """Busca contratos por status"""
        query = select(self.model_class).where(self.model_class.status == status)
        
        result = await self.session.execute(query)
        return list(result.scalars().all())


class DataContractVersionRepository(BaseRepository):
    """Repositório para versões de contratos"""
    
    def __init__(self, session: AsyncSession):
        from database.models import DataContractVersion
        super().__init__(session, DataContractVersion)
    
    async def get_by_contract_and_version(
        self, 
        contract_id: UUID, 
        version: str
    ) -> Optional[Any]:
        """Busca versão específica de um contrato"""
        query = select(self.model_class).where(
            and_(
                self.model_class.contract_id == contract_id,
                self.model_class.version == version
            )
        )
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def get_active_version(self, contract_id: UUID) -> Optional[Any]:
        """Busca versão ativa de um contrato"""
        query = select(self.model_class).where(
            and_(
                self.model_class.contract_id == contract_id,
                self.model_class.is_active == True
            )
        )
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def get_latest_version(self, contract_id: UUID) -> Optional[Any]:
        """Busca versão mais recente de um contrato"""
        query = select(self.model_class).where(
            self.model_class.contract_id == contract_id
        ).order_by(self.model_class.created_at.desc())
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()


class EntityRepository(BaseRepository):
    """Repositório para entidades"""
    
    def __init__(self, session: AsyncSession):
        from database.models import Entity
        super().__init__(session, Entity)
    
    async def get_with_attributes(self, id: UUID) -> Optional[Any]:
        """Busca entidade com seus atributos"""
        query = select(self.model_class).options(
            selectinload(self.model_class.attributes),
            selectinload(self.model_class.tags)
        ).where(self.model_class.id == id)
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def get_by_unity_catalog_path(self, path: str) -> Optional[Any]:
        """Busca entidade por caminho do Unity Catalog"""
        query = select(self.model_class).where(
            self.model_class.unity_catalog_path == path
        )
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def get_by_domain(self, domain_id: UUID) -> List[Any]:
        """Busca entidades por domínio"""
        query = select(self.model_class).where(
            self.model_class.domain_id == domain_id
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_by_classification(self, classification: str) -> List[Any]:
        """Busca entidades por classificação"""
        query = select(self.model_class).where(
            self.model_class.classification == classification
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())


class QualityRuleRepository(BaseRepository):
    """Repositório para regras de qualidade"""
    
    def __init__(self, session: AsyncSession):
        from database.models import QualityRule
        super().__init__(session, QualityRule)
    
    async def get_by_entity(self, entity_id: UUID) -> List[Any]:
        """Busca regras por entidade"""
        query = select(self.model_class).where(
            self.model_class.entity_id == entity_id
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_active_rules(self) -> List[Any]:
        """Busca regras ativas"""
        query = select(self.model_class).where(
            self.model_class.is_active == True
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_by_dimension(self, dimension_id: UUID) -> List[Any]:
        """Busca regras por dimensão"""
        query = select(self.model_class).where(
            self.model_class.dimension_id == dimension_id
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())


class QualityMetricRepository(BaseRepository):
    """Repositório para métricas de qualidade"""
    
    def __init__(self, session: AsyncSession):
        from database.models import QualityMetric
        super().__init__(session, QualityMetric)
    
    async def get_by_rule(self, rule_id: UUID, limit: int = 100) -> List[Any]:
        """Busca métricas por regra"""
        query = select(self.model_class).where(
            self.model_class.rule_id == rule_id
        ).order_by(self.model_class.execution_date.desc()).limit(limit)
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_latest_by_entity(self, entity_id: UUID) -> List[Any]:
        """Busca métricas mais recentes por entidade"""
        # Subquery para encontrar a data mais recente por regra
        subquery = select(
            self.model_class.rule_id,
            func.max(self.model_class.execution_date).label("max_date")
        ).where(
            self.model_class.entity_id == entity_id
        ).group_by(self.model_class.rule_id).subquery()
        
        # Query principal
        query = select(self.model_class).join(
            subquery,
            and_(
                self.model_class.rule_id == subquery.c.rule_id,
                self.model_class.execution_date == subquery.c.max_date
            )
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())


class UserRepository(BaseRepository):
    """Repositório para usuários"""
    
    def __init__(self, session: AsyncSession):
        from database.models import User
        super().__init__(session, User)
    
    async def get_by_username(self, username: str) -> Optional[Any]:
        """Busca usuário por username"""
        query = select(self.model_class).where(
            self.model_class.username == username
        )
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def get_by_email(self, email: str) -> Optional[Any]:
        """Busca usuário por email"""
        query = select(self.model_class).where(
            self.model_class.email == email
        )
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def get_active_users(self) -> List[Any]:
        """Busca usuários ativos"""
        query = select(self.model_class).where(
            self.model_class.is_active == True
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())


class DomainRepository(BaseRepository):
    """Repositório para domínios"""
    
    def __init__(self, session: AsyncSession):
        from database.models import Domain
        super().__init__(session, Domain)
    
    async def get_by_name(self, name: str) -> Optional[Any]:
        """Busca domínio por nome"""
        query = select(self.model_class).where(
            self.model_class.name == name
        )
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def get_root_domains(self) -> List[Any]:
        """Busca domínios raiz (sem pai)"""
        query = select(self.model_class).where(
            self.model_class.parent_domain_id.is_(None)
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_child_domains(self, parent_id: UUID) -> List[Any]:
        """Busca domínios filhos"""
        query = select(self.model_class).where(
            self.model_class.parent_domain_id == parent_id
        )
        
        result = await self.session.execute(query)
        return list(result.scalars().all())

