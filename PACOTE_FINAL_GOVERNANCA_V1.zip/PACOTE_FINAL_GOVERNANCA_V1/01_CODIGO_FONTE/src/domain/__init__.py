"""
Domain Layer - Entidades e regras de negócio
"""

