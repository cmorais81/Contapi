"""
Exceções de domínio para a API de Governança de Dados
"""

from typing import Any, Dict, Optional


class DomainException(Exception):
    """Exceção base para erros de domínio"""
    
    def __init__(self, message: str, details: Optional[Dict[str, Any]] = None):
        self.message = message
        self.details = details or {}
        super().__init__(self.message)


class ValidationError(DomainException):
    """Erro de validação de dados"""
    pass


class BusinessRuleViolation(DomainException):
    """Violação de regra de negócio"""
    pass


class EntityNotFoundError(DomainException):
    """Entidade não encontrada"""
    pass


class DuplicateEntityError(DomainException):
    """Entidade duplicada"""
    pass


class InvalidVersionError(DomainException):
    """Versão inválida"""
    pass


class ContractValidationError(DomainException):
    """Erro de validação de contrato de dados"""
    pass


class QualityRuleExecutionError(DomainException):
    """Erro na execução de regra de qualidade"""
    pass


class IntegrationError(DomainException):
    """Erro de integração externa"""
    pass


class AuthorizationError(DomainException):
    """Erro de autorização"""
    pass


class ConfigurationError(DomainException):
    """Erro de configuração"""
    pass


class CircuitBreakerOpenError(DomainException):
    """Circuit breaker aberto"""
    pass


class RateLimitExceededError(DomainException):
    """Limite de taxa excedido"""
    pass

