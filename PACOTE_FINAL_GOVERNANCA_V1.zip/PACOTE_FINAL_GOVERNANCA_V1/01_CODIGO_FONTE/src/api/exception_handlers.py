"""
Exception Handlers Globais - API de Governança de Dados
Objetivo: 100% de cobertura de tratamento de erros
"""

import logging
import traceback
from datetime import datetime
from typing import Dict, Any, Optional
from uuid import uuid4

from fastapi import FastAPI, Request, HTTPException, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError, ResponseValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException
from sqlalchemy.exc import (
    SQLAlchemyError, 
    IntegrityError, 
    OperationalError, 
    DatabaseError,
    DisconnectionError,
    TimeoutError as SQLTimeoutError
)
from pydantic import ValidationError
import asyncio
import aiohttp
import redis

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ErrorResponse:
    """Classe para padronizar respostas de erro"""
    
    @staticmethod
    def create_error_response(
        error_code: str,
        message: str,
        details: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
        status_code: int = 500
    ) -> Dict[str, Any]:
        """Cria resposta de erro padronizada"""
        return {
            "error": {
                "code": error_code,
                "message": message,
                "details": details or {},
                "request_id": request_id or str(uuid4()),
                "timestamp": datetime.utcnow().isoformat(),
                "status_code": status_code
            }
        }


class ErrorLogger:
    """Classe para logging estruturado de erros"""
    
    @staticmethod
    def log_error(
        error: Exception,
        request: Request,
        error_code: str,
        additional_context: Optional[Dict[str, Any]] = None
    ) -> str:
        """Registra erro com contexto completo"""
        request_id = str(uuid4())
        
        error_context = {
            "request_id": request_id,
            "error_type": type(error).__name__,
            "error_message": str(error),
            "url": str(request.url),
            "method": request.method,
            "headers": dict(request.headers),
            "client_ip": request.client.host if request.client else "unknown",
            "user_agent": request.headers.get("user-agent", "unknown"),
            "timestamp": datetime.utcnow().isoformat(),
            "error_code": error_code,
            "traceback": traceback.format_exc(),
            "additional_context": additional_context or {}
        }
        
        logger.error(f"Error occurred: {error_code}", extra=error_context)
        return request_id


def setup_exception_handlers(app: FastAPI) -> None:
    """Configura todos os exception handlers da aplicação"""
    
    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
        """Handler para HTTPException"""
        request_id = ErrorLogger.log_error(
            exc, request, "HTTP_EXCEPTION",
            {"status_code": exc.status_code, "detail": exc.detail}
        )
        
        return JSONResponse(
            status_code=exc.status_code,
            content=ErrorResponse.create_error_response(
                error_code="HTTP_ERROR",
                message=exc.detail,
                request_id=request_id,
                status_code=exc.status_code
            )
        )
    
    @app.exception_handler(StarletteHTTPException)
    async def starlette_http_exception_handler(request: Request, exc: StarletteHTTPException) -> JSONResponse:
        """Handler para StarletteHTTPException"""
        request_id = ErrorLogger.log_error(
            exc, request, "STARLETTE_HTTP_EXCEPTION",
            {"status_code": exc.status_code, "detail": exc.detail}
        )
        
        return JSONResponse(
            status_code=exc.status_code,
            content=ErrorResponse.create_error_response(
                error_code="HTTP_ERROR",
                message=exc.detail,
                request_id=request_id,
                status_code=exc.status_code
            )
        )
    
    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
        """Handler para erros de validação de request"""
        request_id = ErrorLogger.log_error(
            exc, request, "REQUEST_VALIDATION_ERROR",
            {"errors": exc.errors(), "body": exc.body}
        )
        
        # Formatar erros de validação de forma amigável
        formatted_errors = []
        for error in exc.errors():
            formatted_errors.append({
                "field": ".".join(str(loc) for loc in error["loc"]),
                "message": error["msg"],
                "type": error["type"],
                "input": error.get("input")
            })
        
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content=ErrorResponse.create_error_response(
                error_code="VALIDATION_ERROR",
                message="Request validation failed",
                details={"validation_errors": formatted_errors},
                request_id=request_id,
                status_code=422
            )
        )
    
    @app.exception_handler(ResponseValidationError)
    async def response_validation_exception_handler(request: Request, exc: ResponseValidationError) -> JSONResponse:
        """Handler para erros de validação de response"""
        request_id = ErrorLogger.log_error(
            exc, request, "RESPONSE_VALIDATION_ERROR",
            {"errors": exc.errors()}
        )
        
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=ErrorResponse.create_error_response(
                error_code="INTERNAL_ERROR",
                message="Internal server error occurred",
                details={"error_type": "response_validation_error"},
                request_id=request_id,
                status_code=500
            )
        )
    
    @app.exception_handler(ValidationError)
    async def pydantic_validation_exception_handler(request: Request, exc: ValidationError) -> JSONResponse:
        """Handler para erros de validação Pydantic"""
        request_id = ErrorLogger.log_error(
            exc, request, "PYDANTIC_VALIDATION_ERROR",
            {"errors": exc.errors()}
        )
        
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content=ErrorResponse.create_error_response(
                error_code="VALIDATION_ERROR",
                message="Data validation failed",
                details={"validation_errors": exc.errors()},
                request_id=request_id,
                status_code=422
            )
        )
    
    # Database Exception Handlers
    @app.exception_handler(IntegrityError)
    async def integrity_error_handler(request: Request, exc: IntegrityError) -> JSONResponse:
        """Handler para erros de integridade do banco"""
        request_id = ErrorLogger.log_error(
            exc, request, "DATABASE_INTEGRITY_ERROR",
            {"statement": str(exc.statement), "params": exc.params}
        )
        
        # Detectar tipo específico de erro de integridade
        error_message = "Database integrity constraint violation"
        if "duplicate key" in str(exc).lower():
            error_message = "Duplicate entry found"
        elif "foreign key" in str(exc).lower():
            error_message = "Referenced record not found"
        elif "not null" in str(exc).lower():
            error_message = "Required field cannot be empty"
        
        return JSONResponse(
            status_code=status.HTTP_409_CONFLICT,
            content=ErrorResponse.create_error_response(
                error_code="INTEGRITY_ERROR",
                message=error_message,
                details={"constraint_type": "database_integrity"},
                request_id=request_id,
                status_code=409
            )
        )
    
    @app.exception_handler(OperationalError)
    async def operational_error_handler(request: Request, exc: OperationalError) -> JSONResponse:
        """Handler para erros operacionais do banco"""
        request_id = ErrorLogger.log_error(
            exc, request, "DATABASE_OPERATIONAL_ERROR",
            {"statement": str(exc.statement), "params": exc.params}
        )
        
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content=ErrorResponse.create_error_response(
                error_code="DATABASE_ERROR",
                message="Database service temporarily unavailable",
                details={"error_type": "operational_error"},
                request_id=request_id,
                status_code=503
            )
        )
    
    @app.exception_handler(DisconnectionError)
    async def disconnection_error_handler(request: Request, exc: DisconnectionError) -> JSONResponse:
        """Handler para erros de desconexão do banco"""
        request_id = ErrorLogger.log_error(
            exc, request, "DATABASE_DISCONNECTION_ERROR"
        )
        
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content=ErrorResponse.create_error_response(
                error_code="DATABASE_CONNECTION_ERROR",
                message="Database connection lost",
                details={"error_type": "disconnection_error"},
                request_id=request_id,
                status_code=503
            )
        )
    
    @app.exception_handler(SQLTimeoutError)
    async def sql_timeout_error_handler(request: Request, exc: SQLTimeoutError) -> JSONResponse:
        """Handler para timeout de queries SQL"""
        request_id = ErrorLogger.log_error(
            exc, request, "DATABASE_TIMEOUT_ERROR"
        )
        
        return JSONResponse(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            content=ErrorResponse.create_error_response(
                error_code="DATABASE_TIMEOUT",
                message="Database query timeout",
                details={"error_type": "timeout_error"},
                request_id=request_id,
                status_code=504
            )
        )
    
    @app.exception_handler(SQLAlchemyError)
    async def sqlalchemy_error_handler(request: Request, exc: SQLAlchemyError) -> JSONResponse:
        """Handler genérico para erros SQLAlchemy"""
        request_id = ErrorLogger.log_error(
            exc, request, "DATABASE_ERROR"
        )
        
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=ErrorResponse.create_error_response(
                error_code="DATABASE_ERROR",
                message="Database error occurred",
                details={"error_type": "sqlalchemy_error"},
                request_id=request_id,
                status_code=500
            )
        )
    
    # External Service Exception Handlers
    @app.exception_handler(aiohttp.ClientError)
    async def aiohttp_client_error_handler(request: Request, exc: aiohttp.ClientError) -> JSONResponse:
        """Handler para erros de cliente HTTP"""
        request_id = ErrorLogger.log_error(
            exc, request, "HTTP_CLIENT_ERROR"
        )
        
        return JSONResponse(
            status_code=status.HTTP_502_BAD_GATEWAY,
            content=ErrorResponse.create_error_response(
                error_code="EXTERNAL_SERVICE_ERROR",
                message="External service communication error",
                details={"error_type": "http_client_error"},
                request_id=request_id,
                status_code=502
            )
        )
    
    @app.exception_handler(aiohttp.ClientTimeout)
    async def aiohttp_timeout_error_handler(request: Request, exc: aiohttp.ClientTimeout) -> JSONResponse:
        """Handler para timeout de cliente HTTP"""
        request_id = ErrorLogger.log_error(
            exc, request, "HTTP_CLIENT_TIMEOUT"
        )
        
        return JSONResponse(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            content=ErrorResponse.create_error_response(
                error_code="EXTERNAL_SERVICE_TIMEOUT",
                message="External service timeout",
                details={"error_type": "http_timeout"},
                request_id=request_id,
                status_code=504
            )
        )
    
    @app.exception_handler(redis.ConnectionError)
    async def redis_connection_error_handler(request: Request, exc: redis.ConnectionError) -> JSONResponse:
        """Handler para erros de conexão Redis"""
        request_id = ErrorLogger.log_error(
            exc, request, "REDIS_CONNECTION_ERROR"
        )
        
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content=ErrorResponse.create_error_response(
                error_code="CACHE_SERVICE_ERROR",
                message="Cache service unavailable",
                details={"error_type": "redis_connection_error"},
                request_id=request_id,
                status_code=503
            )
        )
    
    @app.exception_handler(redis.TimeoutError)
    async def redis_timeout_error_handler(request: Request, exc: redis.TimeoutError) -> JSONResponse:
        """Handler para timeout Redis"""
        request_id = ErrorLogger.log_error(
            exc, request, "REDIS_TIMEOUT_ERROR"
        )
        
        return JSONResponse(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            content=ErrorResponse.create_error_response(
                error_code="CACHE_SERVICE_TIMEOUT",
                message="Cache service timeout",
                details={"error_type": "redis_timeout"},
                request_id=request_id,
                status_code=504
            )
        )
    
    # Async Exception Handlers
    @app.exception_handler(asyncio.TimeoutError)
    async def asyncio_timeout_error_handler(request: Request, exc: asyncio.TimeoutError) -> JSONResponse:
        """Handler para timeout de operações assíncronas"""
        request_id = ErrorLogger.log_error(
            exc, request, "ASYNC_TIMEOUT_ERROR"
        )
        
        return JSONResponse(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            content=ErrorResponse.create_error_response(
                error_code="OPERATION_TIMEOUT",
                message="Operation timeout",
                details={"error_type": "async_timeout"},
                request_id=request_id,
                status_code=504
            )
        )
    
    @app.exception_handler(asyncio.CancelledError)
    async def asyncio_cancelled_error_handler(request: Request, exc: asyncio.CancelledError) -> JSONResponse:
        """Handler para operações canceladas"""
        request_id = ErrorLogger.log_error(
            exc, request, "ASYNC_CANCELLED_ERROR"
        )
        
        return JSONResponse(
            status_code=status.HTTP_499_CLIENT_CLOSED_REQUEST,
            content=ErrorResponse.create_error_response(
                error_code="OPERATION_CANCELLED",
                message="Operation was cancelled",
                details={"error_type": "async_cancelled"},
                request_id=request_id,
                status_code=499
            )
        )
    
    # Generic Exception Handler (catch-all)
    @app.exception_handler(Exception)
    async def generic_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        """Handler genérico para todas as outras exceções"""
        request_id = ErrorLogger.log_error(
            exc, request, "UNHANDLED_EXCEPTION"
        )
        
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=ErrorResponse.create_error_response(
                error_code="INTERNAL_ERROR",
                message="An unexpected error occurred",
                details={"error_type": type(exc).__name__},
                request_id=request_id,
                status_code=500
            )
        )


# Custom Domain Exceptions
class DomainException(Exception):
    """Exceção base para erros de domínio"""
    
    def __init__(self, message: str, error_code: str = None, details: Dict[str, Any] = None):
        super().__init__(message)
        self.message = message
        self.error_code = error_code or "DOMAIN_ERROR"
        self.details = details or {}


class BusinessRuleViolation(DomainException):
    """Exceção para violações de regras de negócio"""
    
    def __init__(self, message: str, details: Dict[str, Any] = None):
        super().__init__(message, "BUSINESS_RULE_VIOLATION", details)


class EntityNotFoundError(DomainException):
    """Exceção para entidade não encontrada"""
    
    def __init__(self, entity_type: str, entity_id: str):
        message = f"{entity_type} with ID {entity_id} not found"
        details = {"entity_type": entity_type, "entity_id": entity_id}
        super().__init__(message, "ENTITY_NOT_FOUND", details)


class UnauthorizedError(DomainException):
    """Exceção para acesso não autorizado"""
    
    def __init__(self, message: str, details: Dict[str, Any] = None):
        super().__init__(message, "UNAUTHORIZED", details)


class ValidationError(DomainException):
    """Exceção para erros de validação"""
    
    def __init__(self, message: str, field_errors: Dict[str, list] = None):
        details = {"field_errors": field_errors} if field_errors else {}
        super().__init__(message, "VALIDATION_ERROR", details)


class DuplicateEntityError(DomainException):
    """Exceção para entidade duplicada"""
    
    def __init__(self, entity_type: str, identifier: str):
        message = f"{entity_type} with identifier '{identifier}' already exists"
        details = {"entity_type": entity_type, "identifier": identifier}
        super().__init__(message, "DUPLICATE_ENTITY", details)


class IntegrationError(DomainException):
    """Exceção para erros de integração"""
    
    def __init__(self, system: str, operation: str, error_details: Dict[str, Any] = None):
        message = f"Integration error with {system} during {operation}"
        details = {"system": system, "operation": operation, "error_details": error_details or {}}
        super().__init__(message, "INTEGRATION_ERROR", details)


# Setup domain exception handlers
def setup_domain_exception_handlers(app: FastAPI) -> None:
    """Configura handlers para exceções de domínio"""
    
    @app.exception_handler(BusinessRuleViolation)
    async def business_rule_violation_handler(request: Request, exc: BusinessRuleViolation) -> JSONResponse:
        """Handler para violações de regras de negócio"""
        request_id = ErrorLogger.log_error(exc, request, exc.error_code, exc.details)
        
        return JSONResponse(
            status_code=status.HTTP_400_BAD_REQUEST,
            content=ErrorResponse.create_error_response(
                error_code=exc.error_code,
                message=exc.message,
                details=exc.details,
                request_id=request_id,
                status_code=400
            )
        )
    
    @app.exception_handler(EntityNotFoundError)
    async def entity_not_found_handler(request: Request, exc: EntityNotFoundError) -> JSONResponse:
        """Handler para entidade não encontrada"""
        request_id = ErrorLogger.log_error(exc, request, exc.error_code, exc.details)
        
        return JSONResponse(
            status_code=status.HTTP_404_NOT_FOUND,
            content=ErrorResponse.create_error_response(
                error_code=exc.error_code,
                message=exc.message,
                details=exc.details,
                request_id=request_id,
                status_code=404
            )
        )
    
    @app.exception_handler(UnauthorizedError)
    async def unauthorized_error_handler(request: Request, exc: UnauthorizedError) -> JSONResponse:
        """Handler para acesso não autorizado"""
        request_id = ErrorLogger.log_error(exc, request, exc.error_code, exc.details)
        
        return JSONResponse(
            status_code=status.HTTP_403_FORBIDDEN,
            content=ErrorResponse.create_error_response(
                error_code=exc.error_code,
                message=exc.message,
                details=exc.details,
                request_id=request_id,
                status_code=403
            )
        )
    
    @app.exception_handler(DuplicateEntityError)
    async def duplicate_entity_handler(request: Request, exc: DuplicateEntityError) -> JSONResponse:
        """Handler para entidade duplicada"""
        request_id = ErrorLogger.log_error(exc, request, exc.error_code, exc.details)
        
        return JSONResponse(
            status_code=status.HTTP_409_CONFLICT,
            content=ErrorResponse.create_error_response(
                error_code=exc.error_code,
                message=exc.message,
                details=exc.details,
                request_id=request_id,
                status_code=409
            )
        )
    
    @app.exception_handler(IntegrationError)
    async def integration_error_handler(request: Request, exc: IntegrationError) -> JSONResponse:
        """Handler para erros de integração"""
        request_id = ErrorLogger.log_error(exc, request, exc.error_code, exc.details)
        
        return JSONResponse(
            status_code=status.HTTP_502_BAD_GATEWAY,
            content=ErrorResponse.create_error_response(
                error_code=exc.error_code,
                message=exc.message,
                details=exc.details,
                request_id=request_id,
                status_code=502
            )
        )

