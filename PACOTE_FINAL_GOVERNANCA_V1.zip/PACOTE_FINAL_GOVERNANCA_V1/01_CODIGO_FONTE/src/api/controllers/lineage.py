"""
Controller para Lineage de Dados
"""

from typing import Dict, List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from application.dtos.lineage import (
    LineageGraphDTO,
    LineageTraceRequestDTO,
    LineageImpactAnalysisDTO,
    LineageRootCauseAnalysisDTO,
    LineageRegistrationDTO,
    LineageBulkTraceRequestDTO,
    LineageBulkTraceResponseDTO,
    ColumnLineageDTO,
    LineageStatsDTO,
    LineageDirection,
)
from application.services.lineage_service import LineageService
from domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from api.dependencies import get_current_active_user, get_lineage_service

router = APIRouter(prefix="/api/v1/lineage", tags=["Data Lineage"])


@router.get(
    "/entity/{entity_id}",
    response_model=LineageGraphDTO,
    summary="Obter lineage da entidade",
    description="Retorna o grafo de lineage completo de uma entidade"
)
async def get_entity_lineage(
    entity_id: UUID,
    direction: LineageDirection = Query(LineageDirection.BOTH, description="Direção do lineage"),
    max_depth: int = Query(3, ge=1, le=10, description="Profundidade máxima"),
    include_transformations: bool = Query(True, description="Incluir transformações"),
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> LineageGraphDTO:
    """Obtém lineage completo de uma entidade"""
    try:
        request = LineageTraceRequestDTO(
            entity_id=entity_id,
            direction=direction,
            max_depth=max_depth,
            include_transformations=include_transformations
        )
        return await service.trace_lineage(request)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/entity/{entity_id}/upstream",
    response_model=LineageGraphDTO,
    summary="Obter dependências upstream",
    description="Retorna todas as dependências upstream de uma entidade"
)
async def get_upstream_lineage(
    entity_id: UUID,
    max_depth: int = Query(3, ge=1, le=10, description="Profundidade máxima"),
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> LineageGraphDTO:
    """Obtém dependências upstream"""
    try:
        request = LineageTraceRequestDTO(
            entity_id=entity_id,
            direction=LineageDirection.UPSTREAM,
            max_depth=max_depth
        )
        return await service.trace_lineage(request)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/entity/{entity_id}/downstream",
    response_model=LineageGraphDTO,
    summary="Obter dependências downstream",
    description="Retorna todas as dependências downstream de uma entidade"
)
async def get_downstream_lineage(
    entity_id: UUID,
    max_depth: int = Query(3, ge=1, le=10, description="Profundidade máxima"),
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> LineageGraphDTO:
    """Obtém dependências downstream"""
    try:
        request = LineageTraceRequestDTO(
            entity_id=entity_id,
            direction=LineageDirection.DOWNSTREAM,
            max_depth=max_depth
        )
        return await service.trace_lineage(request)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/trace",
    response_model=LineageGraphDTO,
    summary="Rastrear lineage completo",
    description="Realiza trace completo de lineage com parâmetros customizados"
)
async def trace_lineage(
    request: LineageTraceRequestDTO,
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> LineageGraphDTO:
    """Rastreia lineage com parâmetros customizados"""
    try:
        return await service.trace_lineage(request)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/impact-analysis/{entity_id}",
    response_model=LineageImpactAnalysisDTO,
    summary="Análise de impacto",
    description="Analisa o impacto de mudanças em uma entidade"
)
async def analyze_impact(
    entity_id: UUID,
    impact_type: str = Query("change", description="Tipo de impacto: change, deletion, schema_change"),
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> LineageImpactAnalysisDTO:
    """Analisa impacto de mudanças"""
    try:
        return await service.analyze_impact(entity_id, impact_type)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/root-cause/{entity_id}",
    response_model=LineageRootCauseAnalysisDTO,
    summary="Análise de causa raiz",
    description="Analisa possíveis causas raiz de problemas em uma entidade"
)
async def analyze_root_cause(
    entity_id: UUID,
    issue_type: str = Query("quality", description="Tipo de problema: quality, availability, performance"),
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> LineageRootCauseAnalysisDTO:
    """Analisa causa raiz de problemas"""
    try:
        return await service.analyze_root_cause(entity_id, issue_type)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/bulk-trace",
    response_model=LineageBulkTraceResponseDTO,
    summary="Lineage em lote",
    description="Realiza trace de lineage para múltiplas entidades"
)
async def bulk_trace_lineage(
    request: LineageBulkTraceRequestDTO,
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> LineageBulkTraceResponseDTO:
    """Trace de lineage em lote"""
    try:
        return await service.bulk_trace_lineage(request)
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/graph/{entity_id}",
    response_model=Dict,
    summary="Grafo visual de lineage",
    description="Retorna dados formatados para visualização em grafo"
)
async def get_lineage_graph(
    entity_id: UUID,
    format: str = Query("d3", description="Formato: d3, cytoscape, vis"),
    max_depth: int = Query(3, ge=1, le=5, description="Profundidade máxima"),
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> Dict:
    """Obtém grafo formatado para visualização"""
    try:
        return await service.get_visual_graph(entity_id, format, max_depth)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/attribute/{attribute_id}",
    response_model=List[ColumnLineageDTO],
    summary="Lineage granular por atributo",
    description="Retorna lineage no nível de coluna/atributo"
)
async def get_attribute_lineage(
    attribute_id: UUID,
    direction: LineageDirection = Query(LineageDirection.BOTH, description="Direção do lineage"),
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[ColumnLineageDTO]:
    """Obtém lineage granular por atributo"""
    try:
        return await service.get_attribute_lineage(attribute_id, direction)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/column-level",
    response_model=List[ColumnLineageDTO],
    summary="Lineage por coluna",
    description="Retorna lineage detalhado no nível de coluna"
)
async def get_column_lineage(
    entity_id: UUID,
    column_names: List[str] = Query(..., description="Nomes das colunas"),
    direction: LineageDirection = Query(LineageDirection.BOTH, description="Direção"),
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[ColumnLineageDTO]:
    """Obtém lineage por coluna"""
    try:
        return await service.get_column_lineage(entity_id, column_names, direction)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/transformations/{entity_id}",
    response_model=List[Dict],
    summary="Transformações aplicadas",
    description="Lista todas as transformações aplicadas a uma entidade"
)
async def get_transformations(
    entity_id: UUID,
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[Dict]:
    """Lista transformações de uma entidade"""
    try:
        return await service.get_entity_transformations(entity_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/register",
    response_model=Dict,
    status_code=status.HTTP_201_CREATED,
    summary="Registrar lineage manual",
    description="Registra relacionamento de lineage manualmente"
)
async def register_lineage(
    lineage_data: LineageRegistrationDTO,
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> Dict:
    """Registra lineage manualmente"""
    try:
        lineage_data.created_by = current_user["id"]
        result = await service.register_lineage(lineage_data)
        return {"message": "Lineage registered successfully", "id": result}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/stats",
    response_model=LineageStatsDTO,
    summary="Estatísticas de lineage",
    description="Retorna estatísticas gerais sobre lineage no sistema"
)
async def get_lineage_stats(
    service: LineageService = Depends(get_lineage_service),
    current_user: dict = Depends(get_current_active_user)
) -> LineageStatsDTO:
    """Obtém estatísticas de lineage"""
    return await service.get_lineage_stats()

