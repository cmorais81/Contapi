"""
Controller para Performance e Escalabilidade
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from application.dtos.performance import (
    PerformanceMetricDTO,
    PerformanceMetricsResponseDTO,
    BottleneckAnalysisDTO,
    OptimizationRecommendationDTO,
    CapacityPlanningDTO,
    OptimizationRequestDTO,
    PerformanceAlertDTO,
    MetricType,
    BottleneckType,
    OptimizationType,
    Severity,
)
from application.dtos import PaginatedResponse, PaginationParams
from application.services.performance_service import PerformanceService
from domain.exceptions import BusinessRuleViolation, EntityNotFoundError, UnauthorizedError
from api.dependencies import get_current_active_user, get_performance_service, validate_pagination

router = APIRouter(prefix="/api/v1/performance", tags=["Performance & Scalability"])


# Performance Metrics
@router.get(
    "/metrics",
    response_model=PerformanceMetricsResponseDTO,
    summary="Métricas de performance",
    description="Retorna métricas consolidadas de performance do sistema"
)
async def get_performance_metrics(
    component: Optional[str] = Query(None, description="Filtro por componente"),
    metric_types: List[MetricType] = Query(None, description="Tipos de métricas"),
    period_hours: int = Query(24, ge=1, le=168, description="Período em horas"),
    include_trends: bool = Query(True, description="Incluir análise de tendências"),
    include_alerts: bool = Query(True, description="Incluir alertas ativos"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> PerformanceMetricsResponseDTO:
    """Obtém métricas de performance"""
    try:
        filters = {
            "component": component,
            "metric_types": metric_types,
            "period_hours": period_hours,
            "include_trends": include_trends,
            "include_alerts": include_alerts
        }
        filters = {k: v for k, v in filters.items() if v is not None}
        
        return await service.get_performance_metrics(filters)
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


@router.get(
    "/metrics/real-time",
    response_model=List[PerformanceMetricDTO],
    summary="Métricas em tempo real",
    description="Retorna métricas de performance em tempo real"
)
async def get_real_time_metrics(
    components: List[str] = Query(None, description="Componentes específicos"),
    metric_types: List[MetricType] = Query(None, description="Tipos de métricas"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[PerformanceMetricDTO]:
    """Obtém métricas em tempo real"""
    try:
        filters = {
            "components": components,
            "metric_types": metric_types
        }
        filters = {k: v for k, v in filters.items() if v is not None}
        
        return await service.get_real_time_metrics(filters)
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


# Bottleneck Analysis
@router.get(
    "/bottlenecks",
    response_model=PaginatedResponse[BottleneckAnalysisDTO],
    summary="Análise de gargalos",
    description="Identifica e analisa gargalos de performance no sistema"
)
async def analyze_bottlenecks(
    pagination: PaginationParams = Depends(validate_pagination),
    component: Optional[str] = Query(None, description="Filtro por componente"),
    bottleneck_type: Optional[BottleneckType] = Query(None, description="Tipo de gargalo"),
    severity: Optional[Severity] = Query(None, description="Severidade mínima"),
    is_resolved: bool = Query(False, description="Incluir resolvidos"),
    auto_analyze: bool = Query(True, description="Executar análise automática"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[BottleneckAnalysisDTO]:
    """Analisa gargalos de performance"""
    try:
        filters = {
            "component": component,
            "bottleneck_type": bottleneck_type,
            "severity": severity,
            "is_resolved": is_resolved,
            "auto_analyze": auto_analyze
        }
        filters = {k: v for k, v in filters.items() if v is not None}
        
        return await service.analyze_bottlenecks(pagination, filters)
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


@router.get(
    "/bottlenecks/{bottleneck_id}",
    response_model=BottleneckAnalysisDTO,
    summary="Detalhes do gargalo",
    description="Retorna análise detalhada de um gargalo específico"
)
async def get_bottleneck_details(
    bottleneck_id: UUID,
    include_recommendations: bool = Query(True, description="Incluir recomendações"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> BottleneckAnalysisDTO:
    """Obtém detalhes do gargalo"""
    try:
        return await service.get_bottleneck_details(bottleneck_id, include_recommendations)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/bottlenecks/{bottleneck_id}/resolve",
    response_model=dict,
    summary="Marcar gargalo como resolvido",
    description="Marca um gargalo como resolvido com notas de resolução"
)
async def resolve_bottleneck(
    bottleneck_id: UUID,
    resolution_notes: str = Query(..., description="Notas da resolução"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Resolve gargalo"""
    try:
        await service.resolve_bottleneck(bottleneck_id, resolution_notes, current_user["id"])
        return {"message": "Bottleneck marked as resolved successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


# Optimization
@router.post(
    "/optimization",
    response_model=List[OptimizationRecommendationDTO],
    summary="Otimização automática",
    description="Executa análise e gera recomendações de otimização"
)
async def auto_optimize(
    request: OptimizationRequestDTO,
    execute_safe_optimizations: bool = Query(False, description="Executar otimizações seguras"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[OptimizationRecommendationDTO]:
    """Executa otimização automática"""
    try:
        return await service.auto_optimize(request, execute_safe_optimizations, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


@router.get(
    "/optimization/recommendations",
    response_model=PaginatedResponse[OptimizationRecommendationDTO],
    summary="Recomendações de otimização",
    description="Lista recomendações de otimização disponíveis"
)
async def get_optimization_recommendations(
    pagination: PaginationParams = Depends(validate_pagination),
    component: Optional[str] = Query(None, description="Filtro por componente"),
    optimization_type: Optional[OptimizationType] = Query(None, description="Tipo de otimização"),
    priority: Optional[int] = Query(None, ge=1, le=5, description="Prioridade mínima"),
    status: Optional[str] = Query(None, description="Status da recomendação"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[OptimizationRecommendationDTO]:
    """Lista recomendações de otimização"""
    filters = {
        "component": component,
        "optimization_type": optimization_type,
        "priority": priority,
        "status": status
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.get_optimization_recommendations(pagination, filters)


@router.post(
    "/optimization/recommendations/{recommendation_id}/approve",
    response_model=dict,
    summary="Aprovar recomendação",
    description="Aprova uma recomendação de otimização para implementação"
)
async def approve_optimization_recommendation(
    recommendation_id: UUID,
    assigned_to: Optional[UUID] = Query(None, description="Usuário responsável"),
    deadline: Optional[str] = Query(None, description="Prazo para implementação"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Aprova recomendação de otimização"""
    try:
        await service.approve_optimization_recommendation(
            recommendation_id, assigned_to, deadline, current_user["id"]
        )
        return {"message": "Optimization recommendation approved successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


@router.post(
    "/optimization/recommendations/{recommendation_id}/implement",
    response_model=dict,
    summary="Implementar otimização",
    description="Executa a implementação de uma recomendação aprovada"
)
async def implement_optimization(
    recommendation_id: UUID,
    dry_run: bool = Query(False, description="Executar em modo de teste"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Implementa otimização"""
    try:
        result = await service.implement_optimization(recommendation_id, dry_run, current_user["id"])
        return {
            "message": "Optimization implemented successfully" if not dry_run else "Dry run completed",
            "result": result
        }
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


# Capacity Planning
@router.get(
    "/capacity-planning",
    response_model=CapacityPlanningDTO,
    summary="Planejamento de capacidade",
    description="Gera análise de planejamento de capacidade do sistema"
)
async def get_capacity_planning(
    component: Optional[str] = Query(None, description="Componente específico"),
    projection_months: int = Query(12, ge=1, le=60, description="Meses de projeção"),
    growth_rate_override: Optional[float] = Query(None, description="Taxa de crescimento customizada"),
    include_cost_analysis: bool = Query(True, description="Incluir análise de custos"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> CapacityPlanningDTO:
    """Obtém planejamento de capacidade"""
    try:
        options = {
            "component": component,
            "projection_months": projection_months,
            "growth_rate_override": growth_rate_override,
            "include_cost_analysis": include_cost_analysis
        }
        options = {k: v for k, v in options.items() if v is not None}
        
        return await service.get_capacity_planning(options)
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


@router.post(
    "/capacity-planning/scenarios",
    response_model=List[CapacityPlanningDTO],
    summary="Cenários de capacidade",
    description="Gera múltiplos cenários de planejamento de capacidade"
)
async def generate_capacity_scenarios(
    scenarios: List[dict],
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[CapacityPlanningDTO]:
    """Gera cenários de capacidade"""
    try:
        return await service.generate_capacity_scenarios(scenarios, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except UnauthorizedError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e)
        )


# Performance Alerts
@router.get(
    "/alerts",
    response_model=PaginatedResponse[PerformanceAlertDTO],
    summary="Alertas de performance",
    description="Lista alertas de performance ativos e históricos"
)
async def get_performance_alerts(
    pagination: PaginationParams = Depends(validate_pagination),
    severity: Optional[Severity] = Query(None, description="Severidade mínima"),
    component: Optional[str] = Query(None, description="Filtro por componente"),
    is_acknowledged: Optional[bool] = Query(None, description="Filtro por reconhecido"),
    is_resolved: Optional[bool] = Query(None, description="Filtro por resolvido"),
    hours_ago: int = Query(24, ge=1, le=168, description="Período em horas"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[PerformanceAlertDTO]:
    """Lista alertas de performance"""
    filters = {
        "severity": severity,
        "component": component,
        "is_acknowledged": is_acknowledged,
        "is_resolved": is_resolved,
        "hours_ago": hours_ago
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.get_performance_alerts(pagination, filters)


@router.post(
    "/alerts/{alert_id}/acknowledge",
    response_model=dict,
    summary="Reconhecer alerta",
    description="Marca um alerta como reconhecido"
)
async def acknowledge_alert(
    alert_id: UUID,
    notes: Optional[str] = Query(None, description="Notas do reconhecimento"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Reconhece alerta"""
    try:
        await service.acknowledge_alert(alert_id, notes, current_user["id"])
        return {"message": "Alert acknowledged successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/alerts/{alert_id}/resolve",
    response_model=dict,
    summary="Resolver alerta",
    description="Marca um alerta como resolvido"
)
async def resolve_alert(
    alert_id: UUID,
    resolution_notes: str = Query(..., description="Notas da resolução"),
    service: PerformanceService = Depends(get_performance_service),
    current_user: dict = Depends(get_current_active_user)
) -> dict:
    """Resolve alerta"""
    try:
        await service.resolve_alert(alert_id, resolution_notes, current_user["id"])
        return {"message": "Alert resolved successfully"}
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

