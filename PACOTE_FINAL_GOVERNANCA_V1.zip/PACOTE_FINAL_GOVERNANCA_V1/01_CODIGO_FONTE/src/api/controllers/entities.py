"""
Controller para entidades de dados
"""

from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status

from application.dtos import (
    EntityCreateDTO,
    EntityResponseDTO,
    EntityUpdateDTO,
    PaginatedResponse,
    PaginationParams,
    SearchParams,
)
from application.services import EntityService
from domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from api.dependencies import get_current_active_user, get_entity_service, validate_pagination

router = APIRouter(prefix="/entities", tags=["Entities"])


@router.post(
    "/",
    response_model=EntityResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar entidade",
    description="Cria uma nova entidade de dados no sistema"
)
async def create_entity(
    entity_data: EntityCreateDTO,
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
) -> EntityResponseDTO:
    """Cria uma nova entidade"""
    try:
        return await service.create_entity(entity_data, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/",
    response_model=PaginatedResponse,
    summary="Listar entidades",
    description="Lista entidades com paginação e filtros"
)
async def list_entities(
    pagination: dict = Depends(validate_pagination),
    domain_id: Optional[UUID] = Query(None, description="Filtrar por domínio"),
    type: Optional[str] = Query(None, description="Filtrar por tipo"),
    classification: Optional[str] = Query(None, description="Filtrar por classificação"),
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse:
    """Lista entidades"""
    
    # Construir filtros
    filters = {}
    if domain_id:
        filters["domain_id"] = domain_id
    if type:
        filters["type"] = type
    if classification:
        filters["classification"] = classification
    
    # Implementação futura - usar repositório
    return PaginatedResponse(
        items=[],
        total=0,
        page=pagination["page"],
        size=pagination["size"]
    )


@router.get(
    "/{entity_id}",
    response_model=EntityResponseDTO,
    summary="Buscar entidade",
    description="Busca uma entidade específica por ID"
)
async def get_entity(
    entity_id: UUID,
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
) -> EntityResponseDTO:
    """Busca uma entidade por ID"""
    # Implementação futura
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Endpoint será implementado"
    )


@router.put(
    "/{entity_id}",
    response_model=EntityResponseDTO,
    summary="Atualizar entidade",
    description="Atualiza uma entidade existente"
)
async def update_entity(
    entity_id: UUID,
    entity_data: EntityUpdateDTO,
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
) -> EntityResponseDTO:
    """Atualiza uma entidade"""
    try:
        return await service.update_entity(
            entity_id, 
            entity_data, 
            current_user["id"]
        )
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete(
    "/{entity_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Deletar entidade",
    description="Remove uma entidade do sistema"
)
async def delete_entity(
    entity_id: UUID,
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
):
    """Remove uma entidade"""
    # Implementação futura
    pass


@router.post(
    "/search",
    response_model=PaginatedResponse,
    summary="Buscar entidades",
    description="Busca entidades por texto livre"
)
async def search_entities(
    search_params: SearchParams,
    pagination: dict = Depends(validate_pagination),
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse:
    """Busca entidades por texto"""
    pagination_params = PaginationParams(**pagination)
    return await service.search_entities(search_params, pagination_params)


@router.get(
    "/{entity_id}/attributes",
    response_model=List[Dict[str, Any]],
    summary="Listar atributos da entidade",
    description="Lista todos os atributos de uma entidade"
)
async def list_entity_attributes(
    entity_id: UUID,
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[Dict[str, Any]]:
    """Lista atributos da entidade"""
    # Implementação futura
    return []


@router.post(
    "/{entity_id}/attributes",
    response_model=Dict[str, Any],
    status_code=status.HTTP_201_CREATED,
    summary="Adicionar atributo",
    description="Adiciona um novo atributo à entidade"
)
async def add_entity_attribute(
    entity_id: UUID,
    attribute_data: Dict[str, Any],
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
) -> Dict[str, Any]:
    """Adiciona atributo à entidade"""
    # Implementação futura
    return {"message": "Endpoint será implementado"}


@router.get(
    "/{entity_id}/tags",
    response_model=List[Dict[str, Any]],
    summary="Listar tags da entidade",
    description="Lista todas as tags associadas à entidade"
)
async def list_entity_tags(
    entity_id: UUID,
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[Dict[str, Any]]:
    """Lista tags da entidade"""
    # Implementação futura
    return []


@router.post(
    "/{entity_id}/tags/{tag_id}",
    status_code=status.HTTP_201_CREATED,
    summary="Associar tag",
    description="Associa uma tag à entidade"
)
async def add_entity_tag(
    entity_id: UUID,
    tag_id: UUID,
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
):
    """Associa tag à entidade"""
    # Implementação futura
    pass


@router.delete(
    "/{entity_id}/tags/{tag_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Remover tag",
    description="Remove associação de tag da entidade"
)
async def remove_entity_tag(
    entity_id: UUID,
    tag_id: UUID,
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
):
    """Remove tag da entidade"""
    # Implementação futura
    pass


@router.post(
    "/{entity_id}/sync",
    response_model=Dict[str, Any],
    summary="Sincronizar com Unity Catalog",
    description="Sincroniza entidade com Unity Catalog"
)
async def sync_entity_unity_catalog(
    entity_id: UUID,
    force_update: bool = Query(False, description="Forçar atualização"),
    service: EntityService = Depends(get_entity_service),
    current_user: dict = Depends(get_current_active_user)
) -> Dict[str, Any]:
    """Sincroniza entidade com Unity Catalog"""
    return await service.sync_with_unity_catalog(entity_id, force_update)

