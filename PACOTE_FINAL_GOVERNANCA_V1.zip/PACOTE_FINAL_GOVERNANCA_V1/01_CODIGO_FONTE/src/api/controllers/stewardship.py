"""
Controller para Stewardship e Responsabilidades
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import JSONResponse

from application.dtos.stewardship import (
    StewardCreateDTO,
    StewardUpdateDTO,
    StewardResponseDTO,
    ResponsibilityAssignmentDTO,
    ResponsibilityResponseDTO,
    StewardPerformanceDTO,
    StewardTaskDTO,
    StewardDashboardDTO,
    StewardSearchDTO,
    StewardRole,
    ResponsibilityType,
    StewardStatus,
)
from application.dtos import PaginatedResponse, PaginationParams
from application.services.stewardship_service import StewardshipService
from domain.exceptions import BusinessRuleViolation, EntityNotFoundError
from api.dependencies import get_current_active_user, get_stewardship_service, validate_pagination

router = APIRouter(prefix="/api/v1/stewards", tags=["Data Stewardship"])


@router.post(
    "/",
    response_model=StewardResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Criar steward",
    description="Cria um novo data steward no sistema"
)
async def create_steward(
    steward_data: StewardCreateDTO,
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> StewardResponseDTO:
    """Cria um novo steward"""
    try:
        return await service.create_steward(steward_data, current_user["id"])
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/",
    response_model=PaginatedResponse[StewardResponseDTO],
    summary="Listar stewards",
    description="Lista todos os stewards com filtros e paginação"
)
async def list_stewards(
    pagination: PaginationParams = Depends(validate_pagination),
    role: Optional[StewardRole] = Query(None, description="Filtro por papel"),
    department: Optional[str] = Query(None, description="Filtro por departamento"),
    status: Optional[StewardStatus] = Query(None, description="Filtro por status"),
    is_primary_contact: Optional[bool] = Query(None, description="Filtro por contato principal"),
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[StewardResponseDTO]:
    """Lista stewards com filtros"""
    filters = {
        "role": role,
        "department": department,
        "status": status,
        "is_primary_contact": is_primary_contact
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_stewards(pagination, filters)


@router.get(
    "/{steward_id}",
    response_model=StewardResponseDTO,
    summary="Buscar steward",
    description="Busca um steward específico por ID"
)
async def get_steward(
    steward_id: UUID,
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> StewardResponseDTO:
    """Busca um steward específico"""
    try:
        return await service.get_steward(steward_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.put(
    "/{steward_id}",
    response_model=StewardResponseDTO,
    summary="Atualizar steward",
    description="Atualiza informações de um steward"
)
async def update_steward(
    steward_id: UUID,
    steward_data: StewardUpdateDTO,
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> StewardResponseDTO:
    """Atualiza um steward"""
    try:
        return await service.update_steward(steward_id, steward_data, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/{steward_id}/entities",
    response_model=PaginatedResponse,
    summary="Entidades sob responsabilidade",
    description="Lista entidades sob responsabilidade de um steward"
)
async def get_steward_entities(
    steward_id: UUID,
    pagination: PaginationParams = Depends(validate_pagination),
    responsibility_type: Optional[ResponsibilityType] = Query(None, description="Filtro por tipo"),
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse:
    """Lista entidades do steward"""
    try:
        return await service.get_steward_entities(steward_id, pagination, responsibility_type)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/{steward_id}/assign",
    response_model=ResponsibilityResponseDTO,
    status_code=status.HTTP_201_CREATED,
    summary="Atribuir responsabilidade",
    description="Atribui responsabilidade sobre entidade ou domínio a um steward"
)
async def assign_responsibility(
    steward_id: UUID,
    assignment: ResponsibilityAssignmentDTO,
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> ResponsibilityResponseDTO:
    """Atribui responsabilidade"""
    try:
        assignment.steward_id = steward_id
        return await service.assign_responsibility(assignment, current_user["id"])
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete(
    "/{steward_id}/unassign",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Remover responsabilidade",
    description="Remove responsabilidade de um steward"
)
async def unassign_responsibility(
    steward_id: UUID,
    entity_id: Optional[UUID] = Query(None, description="ID da entidade"),
    domain_id: Optional[UUID] = Query(None, description="ID do domínio"),
    responsibility_type: Optional[ResponsibilityType] = Query(None, description="Tipo de responsabilidade"),
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
):
    """Remove responsabilidade"""
    try:
        await service.unassign_responsibility(
            steward_id, entity_id, domain_id, responsibility_type, current_user["id"]
        )
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )
    except BusinessRuleViolation as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.get(
    "/{steward_id}/performance",
    response_model=StewardPerformanceDTO,
    summary="Performance do steward",
    description="Retorna métricas de performance de um steward"
)
async def get_steward_performance(
    steward_id: UUID,
    period_days: int = Query(30, ge=1, le=365, description="Período em dias"),
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> StewardPerformanceDTO:
    """Obtém performance do steward"""
    try:
        return await service.get_steward_performance(steward_id, period_days)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/{steward_id}/dashboard",
    response_model=StewardDashboardDTO,
    summary="Dashboard do steward",
    description="Retorna dashboard personalizado para o steward"
)
async def get_steward_dashboard(
    steward_id: UUID,
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> StewardDashboardDTO:
    """Obtém dashboard do steward"""
    try:
        return await service.get_steward_dashboard(steward_id)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/{steward_id}/tasks",
    response_model=PaginatedResponse[StewardTaskDTO],
    summary="Tarefas do steward",
    description="Lista tarefas atribuídas a um steward"
)
async def get_steward_tasks(
    steward_id: UUID,
    pagination: PaginationParams = Depends(validate_pagination),
    status: Optional[str] = Query(None, description="Filtro por status"),
    priority: Optional[str] = Query(None, description="Filtro por prioridade"),
    overdue_only: bool = Query(False, description="Apenas tarefas em atraso"),
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[StewardTaskDTO]:
    """Lista tarefas do steward"""
    try:
        filters = {
            "status": status,
            "priority": priority,
            "overdue_only": overdue_only
        }
        filters = {k: v for k, v in filters.items() if v is not None}
        
        return await service.get_steward_tasks(steward_id, pagination, filters)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post(
    "/search",
    response_model=PaginatedResponse[StewardResponseDTO],
    summary="Busca avançada de stewards",
    description="Realiza busca avançada de stewards com múltiplos critérios"
)
async def search_stewards(
    search_criteria: StewardSearchDTO,
    pagination: PaginationParams = Depends(validate_pagination),
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[StewardResponseDTO]:
    """Busca avançada de stewards"""
    return await service.search_stewards(search_criteria, pagination)


# Entity-specific endpoints
@router.get(
    "/entities/{entity_id}/stewards",
    response_model=List[StewardResponseDTO],
    summary="Stewards da entidade",
    description="Lista todos os stewards responsáveis por uma entidade"
)
async def get_entity_stewards(
    entity_id: UUID,
    responsibility_type: Optional[ResponsibilityType] = Query(None, description="Filtro por tipo"),
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> List[StewardResponseDTO]:
    """Lista stewards de uma entidade"""
    try:
        return await service.get_entity_stewards(entity_id, responsibility_type)
    except EntityNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.get(
    "/responsibilities",
    response_model=PaginatedResponse[ResponsibilityResponseDTO],
    summary="Listar responsabilidades",
    description="Lista todas as responsabilidades atribuídas"
)
async def list_responsibilities(
    pagination: PaginationParams = Depends(validate_pagination),
    steward_id: Optional[UUID] = Query(None, description="Filtro por steward"),
    entity_id: Optional[UUID] = Query(None, description="Filtro por entidade"),
    domain_id: Optional[UUID] = Query(None, description="Filtro por domínio"),
    responsibility_type: Optional[ResponsibilityType] = Query(None, description="Filtro por tipo"),
    status: Optional[str] = Query(None, description="Filtro por status"),
    service: StewardshipService = Depends(get_stewardship_service),
    current_user: dict = Depends(get_current_active_user)
) -> PaginatedResponse[ResponsibilityResponseDTO]:
    """Lista responsabilidades com filtros"""
    filters = {
        "steward_id": steward_id,
        "entity_id": entity_id,
        "domain_id": domain_id,
        "responsibility_type": responsibility_type,
        "status": status
    }
    filters = {k: v for k, v in filters.items() if v is not None}
    
    return await service.list_responsibilities(pagination, filters)

