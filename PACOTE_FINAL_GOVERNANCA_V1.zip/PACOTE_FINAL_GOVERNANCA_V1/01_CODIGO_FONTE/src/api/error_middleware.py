"""
Middleware de Erro - Tratamento Centralizado
Objetivo: Interceptar e tratar erros de forma consistente
"""

import time
import logging
from typing import Callable, Dict, Any
from uuid import uuid4
from datetime import datetime

from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse
import asyncio

logger = logging.getLogger(__name__)


class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """Middleware para tratamento centralizado de erros"""
    
    def __init__(self, app, enable_detailed_errors: bool = False):
        super().__init__(app)
        self.enable_detailed_errors = enable_detailed_errors
        self.error_stats = {
            "total_errors": 0,
            "error_types": {},
            "error_rates": {}
        }
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Processa request e trata erros"""
        start_time = time.time()
        request_id = str(uuid4())
        
        # Adicionar request_id ao contexto
        request.state.request_id = request_id
        
        try:
            # Log da request
            await self._log_request(request, request_id)
            
            # Processar request
            response = await call_next(request)
            
            # Log da response
            await self._log_response(request, response, start_time, request_id)
            
            return response
            
        except Exception as exc:
            # Incrementar estatísticas de erro
            self._update_error_stats(exc)
            
            # Log do erro
            await self._log_error(request, exc, start_time, request_id)
            
            # Retornar resposta de erro
            return await self._create_error_response(request, exc, request_id)
    
    async def _log_request(self, request: Request, request_id: str) -> None:
        """Log da request recebida"""
        logger.info(
            f"Request received",
            extra={
                "request_id": request_id,
                "method": request.method,
                "url": str(request.url),
                "client_ip": request.client.host if request.client else "unknown",
                "user_agent": request.headers.get("user-agent", "unknown"),
                "content_type": request.headers.get("content-type"),
                "content_length": request.headers.get("content-length"),
                "timestamp": datetime.utcnow().isoformat()
            }
        )
    
    async def _log_response(
        self, 
        request: Request, 
        response: Response, 
        start_time: float, 
        request_id: str
    ) -> None:
        """Log da response enviada"""
        process_time = time.time() - start_time
        
        logger.info(
            f"Response sent",
            extra={
                "request_id": request_id,
                "status_code": response.status_code,
                "process_time": round(process_time, 4),
                "content_type": response.headers.get("content-type"),
                "content_length": response.headers.get("content-length"),
                "timestamp": datetime.utcnow().isoformat()
            }
        )
    
    async def _log_error(
        self, 
        request: Request, 
        exc: Exception, 
        start_time: float, 
        request_id: str
    ) -> None:
        """Log do erro ocorrido"""
        process_time = time.time() - start_time
        
        logger.error(
            f"Error occurred during request processing",
            extra={
                "request_id": request_id,
                "error_type": type(exc).__name__,
                "error_message": str(exc),
                "method": request.method,
                "url": str(request.url),
                "process_time": round(process_time, 4),
                "client_ip": request.client.host if request.client else "unknown",
                "timestamp": datetime.utcnow().isoformat()
            },
            exc_info=True
        )
    
    def _update_error_stats(self, exc: Exception) -> None:
        """Atualiza estatísticas de erro"""
        self.error_stats["total_errors"] += 1
        
        error_type = type(exc).__name__
        if error_type not in self.error_stats["error_types"]:
            self.error_stats["error_types"][error_type] = 0
        self.error_stats["error_types"][error_type] += 1
    
    async def _create_error_response(
        self, 
        request: Request, 
        exc: Exception, 
        request_id: str
    ) -> JSONResponse:
        """Cria resposta de erro padronizada"""
        
        # Determinar status code baseado no tipo de exceção
        status_code = self._get_status_code_for_exception(exc)
        
        # Criar resposta de erro
        error_response = {
            "error": {
                "code": "INTERNAL_ERROR",
                "message": "An internal error occurred",
                "request_id": request_id,
                "timestamp": datetime.utcnow().isoformat(),
                "status_code": status_code
            }
        }
        
        # Adicionar detalhes se habilitado
        if self.enable_detailed_errors:
            error_response["error"]["details"] = {
                "error_type": type(exc).__name__,
                "error_message": str(exc)
            }
        
        return JSONResponse(
            status_code=status_code,
            content=error_response
        )
    
    def _get_status_code_for_exception(self, exc: Exception) -> int:
        """Determina status code baseado no tipo de exceção"""
        
        # Mapeamento de exceções para status codes
        exception_status_map = {
            "ValidationError": 422,
            "ValueError": 400,
            "KeyError": 400,
            "AttributeError": 400,
            "TypeError": 400,
            "FileNotFoundError": 404,
            "PermissionError": 403,
            "TimeoutError": 504,
            "ConnectionError": 503,
            "asyncio.TimeoutError": 504,
            "asyncio.CancelledError": 499
        }
        
        exception_name = type(exc).__name__
        return exception_status_map.get(exception_name, 500)
    
    def get_error_stats(self) -> Dict[str, Any]:
        """Retorna estatísticas de erro"""
        return self.error_stats.copy()


class CircuitBreakerMiddleware(BaseHTTPMiddleware):
    """Middleware para implementar circuit breaker pattern"""
    
    def __init__(
        self, 
        app, 
        failure_threshold: int = 5,
        recovery_timeout: int = 60,
        expected_exception: type = Exception
    ):
        super().__init__(app)
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception
        
        # Estado do circuit breaker
        self.failure_count = 0
        self.last_failure_time = None
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Implementa lógica do circuit breaker"""
        
        # Verificar estado do circuit breaker
        if self.state == "OPEN":
            if self._should_attempt_reset():
                self.state = "HALF_OPEN"
            else:
                return await self._create_circuit_open_response(request)
        
        try:
            response = await call_next(request)
            
            # Sucesso - resetar contador se necessário
            if self.state == "HALF_OPEN":
                self._reset()
            
            return response
            
        except self.expected_exception as exc:
            self._record_failure()
            
            if self.failure_count >= self.failure_threshold:
                self.state = "OPEN"
                self.last_failure_time = time.time()
            
            # Re-raise para ser tratado por outros handlers
            raise exc
    
    def _should_attempt_reset(self) -> bool:
        """Verifica se deve tentar resetar o circuit breaker"""
        return (
            self.last_failure_time and 
            time.time() - self.last_failure_time >= self.recovery_timeout
        )
    
    def _record_failure(self) -> None:
        """Registra uma falha"""
        self.failure_count += 1
        self.last_failure_time = time.time()
    
    def _reset(self) -> None:
        """Reseta o circuit breaker"""
        self.failure_count = 0
        self.last_failure_time = None
        self.state = "CLOSED"
    
    async def _create_circuit_open_response(self, request: Request) -> JSONResponse:
        """Cria resposta quando circuit breaker está aberto"""
        return JSONResponse(
            status_code=503,
            content={
                "error": {
                    "code": "SERVICE_UNAVAILABLE",
                    "message": "Service temporarily unavailable due to repeated failures",
                    "request_id": str(uuid4()),
                    "timestamp": datetime.utcnow().isoformat(),
                    "status_code": 503,
                    "details": {
                        "circuit_breaker_state": "OPEN",
                        "failure_count": self.failure_count,
                        "retry_after": self.recovery_timeout
                    }
                }
            }
        )


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Middleware para rate limiting"""
    
    def __init__(
        self, 
        app, 
        requests_per_minute: int = 60,
        burst_size: int = 10
    ):
        super().__init__(app)
        self.requests_per_minute = requests_per_minute
        self.burst_size = burst_size
        self.client_requests = {}  # {client_ip: [(timestamp, count), ...]}
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Implementa rate limiting por IP"""
        
        client_ip = request.client.host if request.client else "unknown"
        current_time = time.time()
        
        # Limpar requests antigos
        self._cleanup_old_requests(current_time)
        
        # Verificar rate limit
        if self._is_rate_limited(client_ip, current_time):
            return await self._create_rate_limit_response(request)
        
        # Registrar request
        self._record_request(client_ip, current_time)
        
        # Processar request
        response = await call_next(request)
        
        # Adicionar headers de rate limit
        self._add_rate_limit_headers(response, client_ip, current_time)
        
        return response
    
    def _cleanup_old_requests(self, current_time: float) -> None:
        """Remove requests antigas do tracking"""
        cutoff_time = current_time - 60  # 1 minuto atrás
        
        for client_ip in list(self.client_requests.keys()):
            self.client_requests[client_ip] = [
                (timestamp, count) for timestamp, count in self.client_requests[client_ip]
                if timestamp > cutoff_time
            ]
            
            if not self.client_requests[client_ip]:
                del self.client_requests[client_ip]
    
    def _is_rate_limited(self, client_ip: str, current_time: float) -> bool:
        """Verifica se cliente está rate limited"""
        if client_ip not in self.client_requests:
            return False
        
        # Contar requests no último minuto
        cutoff_time = current_time - 60
        recent_requests = sum(
            count for timestamp, count in self.client_requests[client_ip]
            if timestamp > cutoff_time
        )
        
        return recent_requests >= self.requests_per_minute
    
    def _record_request(self, client_ip: str, current_time: float) -> None:
        """Registra uma request"""
        if client_ip not in self.client_requests:
            self.client_requests[client_ip] = []
        
        self.client_requests[client_ip].append((current_time, 1))
    
    def _add_rate_limit_headers(
        self, 
        response: Response, 
        client_ip: str, 
        current_time: float
    ) -> None:
        """Adiciona headers de rate limit à response"""
        if client_ip in self.client_requests:
            cutoff_time = current_time - 60
            recent_requests = sum(
                count for timestamp, count in self.client_requests[client_ip]
                if timestamp > cutoff_time
            )
            remaining = max(0, self.requests_per_minute - recent_requests)
        else:
            remaining = self.requests_per_minute
        
        response.headers["X-RateLimit-Limit"] = str(self.requests_per_minute)
        response.headers["X-RateLimit-Remaining"] = str(remaining)
        response.headers["X-RateLimit-Reset"] = str(int(current_time + 60))
    
    async def _create_rate_limit_response(self, request: Request) -> JSONResponse:
        """Cria resposta de rate limit excedido"""
        return JSONResponse(
            status_code=429,
            content={
                "error": {
                    "code": "RATE_LIMIT_EXCEEDED",
                    "message": "Too many requests",
                    "request_id": str(uuid4()),
                    "timestamp": datetime.utcnow().isoformat(),
                    "status_code": 429,
                    "details": {
                        "limit": self.requests_per_minute,
                        "window": "1 minute",
                        "retry_after": 60
                    }
                }
            },
            headers={
                "Retry-After": "60",
                "X-RateLimit-Limit": str(self.requests_per_minute),
                "X-RateLimit-Remaining": "0"
            }
        )


class RequestValidationMiddleware(BaseHTTPMiddleware):
    """Middleware para validação de requests"""
    
    def __init__(self, app, max_request_size: int = 10 * 1024 * 1024):  # 10MB
        super().__init__(app)
        self.max_request_size = max_request_size
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Valida requests antes do processamento"""
        
        # Validar tamanho da request
        content_length = request.headers.get("content-length")
        if content_length and int(content_length) > self.max_request_size:
            return await self._create_payload_too_large_response(request)
        
        # Validar content-type para requests com body
        if request.method in ["POST", "PUT", "PATCH"]:
            content_type = request.headers.get("content-type", "")
            if not self._is_valid_content_type(content_type):
                return await self._create_unsupported_media_type_response(request)
        
        # Validar headers obrigatórios
        if not self._has_required_headers(request):
            return await self._create_missing_headers_response(request)
        
        return await call_next(request)
    
    def _is_valid_content_type(self, content_type: str) -> bool:
        """Verifica se content-type é válido"""
        valid_types = [
            "application/json",
            "application/x-www-form-urlencoded",
            "multipart/form-data",
            "text/plain"
        ]
        
        return any(content_type.startswith(valid_type) for valid_type in valid_types)
    
    def _has_required_headers(self, request: Request) -> bool:
        """Verifica se headers obrigatórios estão presentes"""
        # Por enquanto, não há headers obrigatórios
        # Pode ser expandido conforme necessário
        return True
    
    async def _create_payload_too_large_response(self, request: Request) -> JSONResponse:
        """Cria resposta para payload muito grande"""
        return JSONResponse(
            status_code=413,
            content={
                "error": {
                    "code": "PAYLOAD_TOO_LARGE",
                    "message": "Request payload too large",
                    "request_id": str(uuid4()),
                    "timestamp": datetime.utcnow().isoformat(),
                    "status_code": 413,
                    "details": {
                        "max_size": self.max_request_size,
                        "max_size_mb": self.max_request_size / (1024 * 1024)
                    }
                }
            }
        )
    
    async def _create_unsupported_media_type_response(self, request: Request) -> JSONResponse:
        """Cria resposta para media type não suportado"""
        return JSONResponse(
            status_code=415,
            content={
                "error": {
                    "code": "UNSUPPORTED_MEDIA_TYPE",
                    "message": "Unsupported media type",
                    "request_id": str(uuid4()),
                    "timestamp": datetime.utcnow().isoformat(),
                    "status_code": 415,
                    "details": {
                        "supported_types": [
                            "application/json",
                            "application/x-www-form-urlencoded",
                            "multipart/form-data",
                            "text/plain"
                        ]
                    }
                }
            }
        )
    
    async def _create_missing_headers_response(self, request: Request) -> JSONResponse:
        """Cria resposta para headers obrigatórios ausentes"""
        return JSONResponse(
            status_code=400,
            content={
                "error": {
                    "code": "MISSING_REQUIRED_HEADERS",
                    "message": "Required headers missing",
                    "request_id": str(uuid4()),
                    "timestamp": datetime.utcnow().isoformat(),
                    "status_code": 400
                }
            }
        )

