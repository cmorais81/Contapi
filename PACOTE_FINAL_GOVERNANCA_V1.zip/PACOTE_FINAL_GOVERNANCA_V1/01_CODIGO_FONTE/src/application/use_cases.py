"""
Casos de uso da aplicação
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession

from database.repositories import (
    DataContractRepository,
    DataContractVersionRepository,
    DomainRepository,
    EntityRepository,
    QualityMetricRepository,
    QualityRuleRepository,
    UserRepository,
)
from domain.entities import DataContract, DataContractVersion, Entity, QualityRule
from domain.exceptions import (
    BusinessRuleViolation,
    EntityNotFoundError,
    ValidationError,
)
from domain.value_objects import Email, UnityCatalogPath, Version
from application.dtos import (
    DataContractCreateDTO,
    DataContractResponseDTO,
    DataContractUpdateDTO,
    DataContractVersionCreateDTO,
    DataContractVersionResponseDTO,
    EntityCreateDTO,
    EntityResponseDTO,
    EntityUpdateDTO,
    PaginatedResponse,
    PaginationParams,
    QualityRuleCreateDTO,
    QualityRuleResponseDTO,
    QualityRuleUpdateDTO,
)


class BaseUseCase(ABC):
    """Caso de uso base"""
    
    def __init__(self, session: AsyncSession):
        self.session = session


# ========================================
# DATA CONTRACT USE CASES
# ========================================

class CreateDataContractUseCase(BaseUseCase):
    """Caso de uso para criar contrato de dados"""
    
    async def execute(
        self, 
        dto: DataContractCreateDTO, 
        created_by: Optional[UUID] = None
    ) -> DataContractResponseDTO:
        """Executa criação de contrato"""
        
        # Verificar se já existe contrato com mesmo nome no domínio
        contract_repo = DataContractRepository(self.session)
        
        existing = await contract_repo.get_by_name_and_domain(
            dto.name, dto.domain_id
        )
        if existing:
            raise BusinessRuleViolation(
                f"Já existe contrato com nome '{dto.name}' no domínio especificado"
            )
        
        # Verificar se Unity Catalog path já está em uso
        if dto.unity_catalog_path:
            existing_path = await contract_repo.get_by_unity_catalog_path(
                dto.unity_catalog_path
            )
            if existing_path:
                raise BusinessRuleViolation(
                    f"Unity Catalog path '{dto.unity_catalog_path}' já está em uso"
                )
        
        # Validar domínio se especificado
        if dto.domain_id:
            domain_repo = DomainRepository(self.session)
            domain = await domain_repo.get_by_id(dto.domain_id)
            if not domain:
                raise EntityNotFoundError(f"Domínio {dto.domain_id} não encontrado")
        
        # Criar entidade de domínio
        unity_path = None
        if dto.unity_catalog_path:
            unity_path = UnityCatalogPath.from_string(dto.unity_catalog_path)
        
        contract = DataContract(
            name=dto.name,
            description=dto.description,
            domain_id=dto.domain_id,
            steward_id=dto.steward_id,
            unity_catalog_path=unity_path,
            created_by=created_by,
        )
        
        # Persistir
        saved_contract = await contract_repo.create(contract)
        
        return DataContractResponseDTO.from_orm(saved_contract)


class UpdateDataContractUseCase(BaseUseCase):
    """Caso de uso para atualizar contrato de dados"""
    
    async def execute(
        self,
        contract_id: UUID,
        dto: DataContractUpdateDTO,
        updated_by: Optional[UUID] = None
    ) -> DataContractResponseDTO:
        """Executa atualização de contrato"""
        
        contract_repo = DataContractRepository(self.session)
        
        # Buscar contrato existente
        contract = await contract_repo.get_by_id_or_raise(contract_id)
        
        # Verificar nome único no domínio se alterado
        if dto.name and dto.name != contract.name:
            existing = await contract_repo.get_by_name_and_domain(
                dto.name, dto.domain_id or contract.domain_id
            )
            if existing and existing.id != contract_id:
                raise BusinessRuleViolation(
                    f"Já existe contrato com nome '{dto.name}' no domínio"
                )
        
        # Atualizar campos
        update_data = dto.dict(exclude_unset=True)
        if updated_by:
            update_data['updated_by'] = updated_by
        
        updated_contract = await contract_repo.update(contract_id, **update_data)
        
        return DataContractResponseDTO.from_orm(updated_contract)


class GetDataContractUseCase(BaseUseCase):
    """Caso de uso para buscar contrato de dados"""
    
    async def execute(self, contract_id: UUID) -> DataContractResponseDTO:
        """Executa busca de contrato"""
        
        contract_repo = DataContractRepository(self.session)
        contract = await contract_repo.get_by_id_or_raise(contract_id)
        
        return DataContractResponseDTO.from_orm(contract)


class ListDataContractsUseCase(BaseUseCase):
    """Caso de uso para listar contratos de dados"""
    
    async def execute(
        self,
        pagination: PaginationParams,
        filters: Optional[Dict[str, Any]] = None
    ) -> PaginatedResponse:
        """Executa listagem de contratos"""
        
        contract_repo = DataContractRepository(self.session)
        
        # Buscar contratos
        contracts = await contract_repo.list_all(
            offset=pagination.offset,
            limit=pagination.limit,
            order_by=pagination.order_by,
            filters=filters
        )
        
        # Contar total
        total = await contract_repo.count(filters)
        
        # Converter para DTOs
        items = [DataContractResponseDTO.from_orm(c) for c in contracts]
        
        return PaginatedResponse(
            items=items,
            total=total,
            page=pagination.page,
            size=pagination.size
        )


class DeleteDataContractUseCase(BaseUseCase):
    """Caso de uso para deletar contrato de dados"""
    
    async def execute(self, contract_id: UUID) -> bool:
        """Executa deleção de contrato"""
        
        contract_repo = DataContractRepository(self.session)
        
        # Verificar se contrato existe
        await contract_repo.get_by_id_or_raise(contract_id)
        
        # Verificar se há versões ativas
        version_repo = DataContractVersionRepository(self.session)
        active_version = await version_repo.get_active_version(contract_id)
        
        if active_version:
            raise BusinessRuleViolation(
                "Não é possível deletar contrato com versão ativa"
            )
        
        return await contract_repo.delete(contract_id)


# ========================================
# DATA CONTRACT VERSION USE CASES
# ========================================

class CreateDataContractVersionUseCase(BaseUseCase):
    """Caso de uso para criar versão de contrato"""
    
    async def execute(
        self,
        contract_id: UUID,
        dto: DataContractVersionCreateDTO,
        created_by: Optional[UUID] = None
    ) -> DataContractVersionResponseDTO:
        """Executa criação de versão"""
        
        # Verificar se contrato existe
        contract_repo = DataContractRepository(self.session)
        contract = await contract_repo.get_by_id_or_raise(contract_id)
        
        # Verificar se versão já existe
        version_repo = DataContractVersionRepository(self.session)
        existing_version = await version_repo.get_by_contract_and_version(
            contract_id, dto.version
        )
        
        if existing_version:
            raise BusinessRuleViolation(
                f"Versão {dto.version} já existe para este contrato"
            )
        
        # Criar value object de versão
        version = Version.from_string(dto.version)
        
        # Criar versão
        contract_version = DataContractVersion(
            contract_id=contract_id,
            version=version,
            description=dto.description,
            schema_definition=dto.schema_definition,
            quality_rules=dto.quality_rules,
            sla_definition=dto.sla_definition,
            terms_and_conditions=dto.terms_and_conditions,
            created_by=created_by,
        )
        
        # Gerar export ODCS
        contract_version.generate_odcs_export()
        
        # Persistir
        saved_version = await version_repo.create(contract_version)
        
        return DataContractVersionResponseDTO.from_orm(saved_version)


class ActivateDataContractVersionUseCase(BaseUseCase):
    """Caso de uso para ativar versão de contrato"""
    
    async def execute(
        self,
        contract_id: UUID,
        version: str,
        updated_by: Optional[UUID] = None
    ) -> DataContractVersionResponseDTO:
        """Executa ativação de versão"""
        
        # Buscar versão
        version_repo = DataContractVersionRepository(self.session)
        contract_version = await version_repo.get_by_contract_and_version(
            contract_id, version
        )
        
        if not contract_version:
            raise EntityNotFoundError(
                f"Versão {version} não encontrada para contrato {contract_id}"
            )
        
        # Desativar versão atual
        current_active = await version_repo.get_active_version(contract_id)
        if current_active:
            await version_repo.update(current_active.id, is_active=False)
        
        # Ativar nova versão
        activated_version = await version_repo.update(
            contract_version.id, 
            is_active=True
        )
        
        # Atualizar contrato
        contract_repo = DataContractRepository(self.session)
        await contract_repo.update(
            contract_id,
            current_version_id=activated_version.id,
            status="active",
            updated_by=updated_by
        )
        
        return DataContractVersionResponseDTO.from_orm(activated_version)


class ExportODCSUseCase(BaseUseCase):
    """Caso de uso para exportar contrato no formato ODCS"""
    
    async def execute(
        self,
        contract_id: UUID,
        version: Optional[str] = None
    ) -> Dict[str, Any]:
        """Executa export ODCS"""
        
        version_repo = DataContractVersionRepository(self.session)
        
        if version:
            # Buscar versão específica
            contract_version = await version_repo.get_by_contract_and_version(
                contract_id, version
            )
        else:
            # Buscar versão ativa
            contract_version = await version_repo.get_active_version(contract_id)
        
        if not contract_version:
            raise EntityNotFoundError(
                "Versão não encontrada ou contrato não possui versão ativa"
            )
        
        # Gerar export se não existe
        if not contract_version.odcs_export:
            contract_version.generate_odcs_export()
            await version_repo.update(
                contract_version.id,
                odcs_export=contract_version.odcs_export
            )
        
        return contract_version.odcs_export


# ========================================
# ENTITY USE CASES
# ========================================

class CreateEntityUseCase(BaseUseCase):
    """Caso de uso para criar entidade"""
    
    async def execute(
        self,
        dto: EntityCreateDTO,
        created_by: Optional[UUID] = None
    ) -> EntityResponseDTO:
        """Executa criação de entidade"""
        
        entity_repo = EntityRepository(self.session)
        
        # Verificar Unity Catalog path único
        if dto.unity_catalog_path:
            existing = await entity_repo.get_by_unity_catalog_path(
                dto.unity_catalog_path
            )
            if existing:
                raise BusinessRuleViolation(
                    f"Unity Catalog path '{dto.unity_catalog_path}' já está em uso"
                )
        
        # Validar domínio
        if dto.domain_id:
            domain_repo = DomainRepository(self.session)
            domain = await domain_repo.get_by_id(dto.domain_id)
            if not domain:
                raise EntityNotFoundError(f"Domínio {dto.domain_id} não encontrado")
        
        # Criar entidade
        unity_path = None
        if dto.unity_catalog_path:
            unity_path = UnityCatalogPath.from_string(dto.unity_catalog_path)
        
        entity = Entity(
            name=dto.name,
            type=dto.type,
            description=dto.description,
            domain_id=dto.domain_id,
            steward_id=dto.steward_id,
            unity_catalog_path=unity_path,
            schema_definition=dto.schema_definition,
            business_glossary_id=dto.business_glossary_id,
            classification=dto.classification,
            created_by=created_by,
        )
        
        # Persistir
        saved_entity = await entity_repo.create(entity)
        
        return EntityResponseDTO.from_orm(saved_entity)


class UpdateEntityUseCase(BaseUseCase):
    """Caso de uso para atualizar entidade"""
    
    async def execute(
        self,
        entity_id: UUID,
        dto: EntityUpdateDTO,
        updated_by: Optional[UUID] = None
    ) -> EntityResponseDTO:
        """Executa atualização de entidade"""
        
        entity_repo = EntityRepository(self.session)
        
        # Verificar se entidade existe
        await entity_repo.get_by_id_or_raise(entity_id)
        
        # Atualizar
        update_data = dto.dict(exclude_unset=True)
        if updated_by:
            update_data['updated_by'] = updated_by
        
        updated_entity = await entity_repo.update(entity_id, **update_data)
        
        return EntityResponseDTO.from_orm(updated_entity)


# ========================================
# QUALITY RULE USE CASES
# ========================================

class CreateQualityRuleUseCase(BaseUseCase):
    """Caso de uso para criar regra de qualidade"""
    
    async def execute(
        self,
        dto: QualityRuleCreateDTO,
        created_by: Optional[UUID] = None
    ) -> QualityRuleResponseDTO:
        """Executa criação de regra de qualidade"""
        
        # Verificar se entidade existe
        entity_repo = EntityRepository(self.session)
        await entity_repo.get_by_id_or_raise(dto.entity_id)
        
        # Criar regra
        rule = QualityRule(
            name=dto.name,
            description=dto.description,
            entity_id=dto.entity_id,
            attribute_id=dto.attribute_id,
            dimension_id=dto.dimension_id,
            rule_type=dto.rule_type,
            rule_definition=dto.rule_definition,
            threshold_warning=dto.threshold_warning,
            threshold_critical=dto.threshold_critical,
            is_active=dto.is_active,
            created_by=created_by,
        )
        
        # Persistir
        rule_repo = QualityRuleRepository(self.session)
        saved_rule = await rule_repo.create(rule)
        
        return QualityRuleResponseDTO.from_orm(saved_rule)


class ExecuteQualityRuleUseCase(BaseUseCase):
    """Caso de uso para executar regra de qualidade"""
    
    async def execute(self, rule_id: UUID) -> Dict[str, Any]:
        """Executa regra de qualidade"""
        
        rule_repo = QualityRuleRepository(self.session)
        rule = await rule_repo.get_by_id_or_raise(rule_id)
        
        if not rule.is_active:
            raise BusinessRuleViolation("Regra não está ativa")
        
        # Executar regra (simulação)
        metric = rule.execute()
        
        # Persistir métrica
        metric_repo = QualityMetricRepository(self.session)
        saved_metric = await metric_repo.create(metric)
        
        return {
            "rule_id": rule_id,
            "metric_id": saved_metric.id,
            "value": metric.metric_value,
            "status": metric.status,
            "execution_time_ms": metric.execution_time_ms
        }


# ========================================
# SEARCH USE CASES
# ========================================

class SearchEntitiesUseCase(BaseUseCase):
    """Caso de uso para buscar entidades"""
    
    async def execute(
        self,
        query: str,
        pagination: PaginationParams,
        filters: Optional[Dict[str, Any]] = None
    ) -> PaginatedResponse:
        """Executa busca de entidades"""
        
        entity_repo = EntityRepository(self.session)
        
        # Campos de busca
        search_fields = ["name", "description"]
        
        # Buscar entidades
        entities = await entity_repo.search(
            search_term=query,
            search_fields=search_fields,
            offset=pagination.offset,
            limit=pagination.limit
        )
        
        # Contar total (aproximado)
        total = len(entities)
        
        # Converter para DTOs
        items = [EntityResponseDTO.from_orm(e) for e in entities]
        
        return PaginatedResponse(
            items=items,
            total=total,
            page=pagination.page,
            size=pagination.size
        )

