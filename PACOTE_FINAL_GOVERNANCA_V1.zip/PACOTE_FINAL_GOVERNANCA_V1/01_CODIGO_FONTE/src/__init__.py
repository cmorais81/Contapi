"""
API de Governança de Dados
Baseada no modelo ODCS v3.0.2
"""

__version__ = "1.0.0"
__author__ = "Carlos Morais"

