# Databricks notebook source
# MAGIC %md
# MAGIC # Azure Service Principal Data Extractor para API de Governança de Dados
# MAGIC 
# MAGIC **Desenvolvido por:** Carlos Morais  
# MAGIC **Versão:** 2.1  
# MAGIC **Data:** Janeiro 2025
# MAGIC 
# MAGIC ## Objetivo
# MAGIC Este notebook extrai dados dos serviços Azure usando autenticação via Service Principal (SPN) para alimentar o modelo de governança de dados com 56 tabelas baseado no ODCS v3.0.2.
# MAGIC 
# MAGIC ## Serviços Azure Suportados
# MAGIC - **Azure Data Factory** - Pipelines, datasets, linked services
# MAGIC - **Azure Synapse Analytics** - Workspaces, pools, databases
# MAGIC - **Azure Storage** - Containers, blobs, data lakes
# MAGIC - **Azure SQL Database** - Databases, tables, schemas
# MAGIC - **Azure Purview** - Catálogo de dados, classificações
# MAGIC - **Azure Key Vault** - Secrets, certificados
# MAGIC - **Azure Monitor** - Logs, métricas de uso
# MAGIC - **Azure Resource Manager** - Recursos, tags, políticas

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Configuração e Imports

# COMMAND ----------

import json
import pandas as pd
from datetime import datetime, timedelta
import requests
import uuid
import logging
from azure.identity import ClientSecretCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.datafactory import DataFactoryManagementClient
from azure.mgmt.synapse import SynapseManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.mgmt.sql import SqlManagementClient
from azure.mgmt.monitor import MonitorManagementClient
from azure.keyvault.secrets import SecretClient
import pyodbc
from pyspark.sql import SparkSession
from pyspark.sql.functions import *

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configurações Azure SPN
TENANT_ID = dbutils.secrets.get(scope="azure", key="tenant_id")
CLIENT_ID = dbutils.secrets.get(scope="azure", key="client_id")
CLIENT_SECRET = dbutils.secrets.get(scope="azure", key="client_secret")
SUBSCRIPTION_ID = dbutils.secrets.get(scope="azure", key="subscription_id")

# Configurações da API de Governança
API_BASE_URL = "https://your-governance-api.com/api/v1"  # Substituir pela URL real
API_TOKEN = dbutils.secrets.get(scope="governance", key="api_token")

# Headers para requisições da API
api_headers = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}

# Credencial Azure
credential = ClientSecretCredential(
    tenant_id=TENANT_ID,
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET
)

print("✅ Configuração Azure SPN concluída")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Funções Auxiliares Azure

# COMMAND ----------

def generate_uuid():
    """Gera UUID único"""
    return str(uuid.uuid4())

def safe_azure_call(func, *args, **kwargs):
    """Executa chamada Azure com tratamento de erro"""
    try:
        return func(*args, **kwargs)
    except Exception as e:
        logger.error(f"Erro na chamada Azure: {str(e)}")
        return None

def get_azure_clients():
    """Inicializa clientes Azure"""
    clients = {}
    
    try:
        clients['resource'] = ResourceManagementClient(credential, SUBSCRIPTION_ID)
        clients['datafactory'] = DataFactoryManagementClient(credential, SUBSCRIPTION_ID)
        clients['synapse'] = SynapseManagementClient(credential, SUBSCRIPTION_ID)
        clients['storage'] = StorageManagementClient(credential, SUBSCRIPTION_ID)
        clients['sql'] = SqlManagementClient(credential, SUBSCRIPTION_ID)
        clients['monitor'] = MonitorManagementClient(credential, SUBSCRIPTION_ID)
        
        print("✅ Clientes Azure inicializados")
        return clients
        
    except Exception as e:
        logger.error(f"Erro ao inicializar clientes Azure: {str(e)}")
        return {}

def extract_resource_tags():
    """Extrai tags de recursos Azure"""
    
    resource_client = ResourceManagementClient(credential, SUBSCRIPTION_ID)
    tags_data = []
    
    try:
        # Listar todos os recursos
        resources = resource_client.resources.list()
        
        for resource in resources:
            if resource.tags:
                for tag_key, tag_value in resource.tags.items():
                    tag_info = {
                        "resource_id": resource.id,
                        "resource_name": resource.name,
                        "resource_type": resource.type,
                        "tag_key": tag_key,
                        "tag_value": tag_value,
                        "location": resource.location,
                        "created_at": datetime.now().isoformat()
                    }
                    tags_data.append(tag_info)
                    
    except Exception as e:
        logger.error(f"Erro ao extrair tags de recursos: {str(e)}")
    
    return tags_data

print("✅ Funções auxiliares Azure definidas")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Extração Azure Data Factory

# COMMAND ----------

def extract_data_factory_metadata():
    """Extrai metadados do Azure Data Factory"""
    
    adf_client = DataFactoryManagementClient(credential, SUBSCRIPTION_ID)
    adf_data = {
        "factories": [],
        "pipelines": [],
        "datasets": [],
        "linked_services": [],
        "triggers": [],
        "pipeline_runs": []
    }
    
    try:
        # Listar Data Factories
        factories = adf_client.factories.list()
        
        for factory in factories:
            factory_info = {
                "id": generate_uuid(),
                "name": factory.name,
                "location": factory.location,
                "resource_group": factory.id.split('/')[4],  # Extrair resource group do ID
                "provisioning_state": factory.provisioning_state,
                "created_time": factory.create_time.isoformat() if factory.create_time else None,
                "version": factory.version,
                "tags": factory.tags or {},
                "created_at": datetime.now().isoformat()
            }
            adf_data["factories"].append(factory_info)
            
            resource_group = factory_info["resource_group"]
            factory_name = factory.name
            
            # Extrair pipelines
            try:
                pipelines = adf_client.pipelines.list_by_factory(resource_group, factory_name)
                
                for pipeline in pipelines:
                    pipeline_info = {
                        "id": generate_uuid(),
                        "factory_id": factory_info["id"],
                        "name": pipeline.name,
                        "description": getattr(pipeline, 'description', ''),
                        "activities": [],
                        "parameters": getattr(pipeline, 'parameters', {}),
                        "created_at": datetime.now().isoformat()
                    }
                    
                    # Extrair atividades do pipeline
                    if hasattr(pipeline, 'activities') and pipeline.activities:
                        for activity in pipeline.activities:
                            activity_info = {
                                "name": activity.name,
                                "type": activity.type,
                                "description": getattr(activity, 'description', ''),
                                "depends_on": [dep.activity for dep in getattr(activity, 'depends_on', [])]
                            }
                            pipeline_info["activities"].append(activity_info)
                    
                    adf_data["pipelines"].append(pipeline_info)
                    
            except Exception as e:
                logger.warning(f"Erro ao extrair pipelines da factory {factory_name}: {str(e)}")
            
            # Extrair datasets
            try:
                datasets = adf_client.datasets.list_by_factory(resource_group, factory_name)
                
                for dataset in datasets:
                    dataset_info = {
                        "id": generate_uuid(),
                        "factory_id": factory_info["id"],
                        "name": dataset.name,
                        "type": dataset.type,
                        "description": getattr(dataset, 'description', ''),
                        "linked_service": getattr(dataset.properties, 'linked_service_name', '') if hasattr(dataset, 'properties') else '',
                        "schema": getattr(dataset.properties, 'schema', []) if hasattr(dataset, 'properties') else [],
                        "created_at": datetime.now().isoformat()
                    }
                    adf_data["datasets"].append(dataset_info)
                    
            except Exception as e:
                logger.warning(f"Erro ao extrair datasets da factory {factory_name}: {str(e)}")
            
            # Extrair linked services
            try:
                linked_services = adf_client.linked_services.list_by_factory(resource_group, factory_name)
                
                for linked_service in linked_services:
                    ls_info = {
                        "id": generate_uuid(),
                        "factory_id": factory_info["id"],
                        "name": linked_service.name,
                        "type": linked_service.type,
                        "description": getattr(linked_service, 'description', ''),
                        "created_at": datetime.now().isoformat()
                    }
                    adf_data["linked_services"].append(ls_info)
                    
            except Exception as e:
                logger.warning(f"Erro ao extrair linked services da factory {factory_name}: {str(e)}")
                
    except Exception as e:
        logger.error(f"Erro ao extrair metadados do Data Factory: {str(e)}")
    
    return adf_data

# Extrair dados do ADF
print("🏭 Extraindo metadados do Azure Data Factory...")
adf_metadata = extract_data_factory_metadata()

print(f"📊 Azure Data Factory extraído:")
print(f"  - Factories: {len(adf_metadata['factories'])}")
print(f"  - Pipelines: {len(adf_metadata['pipelines'])}")
print(f"  - Datasets: {len(adf_metadata['datasets'])}")
print(f"  - Linked Services: {len(adf_metadata['linked_services'])}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Extração Azure Synapse Analytics

# COMMAND ----------

def extract_synapse_metadata():
    """Extrai metadados do Azure Synapse Analytics"""
    
    synapse_client = SynapseManagementClient(credential, SUBSCRIPTION_ID)
    synapse_data = {
        "workspaces": [],
        "sql_pools": [],
        "spark_pools": [],
        "databases": [],
        "tables": []
    }
    
    try:
        # Listar workspaces
        workspaces = synapse_client.workspaces.list()
        
        for workspace in workspaces:
            workspace_info = {
                "id": generate_uuid(),
                "name": workspace.name,
                "location": workspace.location,
                "resource_group": workspace.id.split('/')[4],
                "provisioning_state": workspace.provisioning_state,
                "sql_administrator_login": getattr(workspace, 'sql_administrator_login', ''),
                "managed_virtual_network": getattr(workspace, 'managed_virtual_network', ''),
                "tags": workspace.tags or {},
                "created_at": datetime.now().isoformat()
            }
            synapse_data["workspaces"].append(workspace_info)
            
            resource_group = workspace_info["resource_group"]
            workspace_name = workspace.name
            
            # Extrair SQL pools
            try:
                sql_pools = synapse_client.sql_pools.list_by_workspace(resource_group, workspace_name)
                
                for sql_pool in sql_pools:
                    pool_info = {
                        "id": generate_uuid(),
                        "workspace_id": workspace_info["id"],
                        "name": sql_pool.name,
                        "status": sql_pool.status,
                        "sku": sql_pool.sku.name if sql_pool.sku else '',
                        "max_size_bytes": sql_pool.max_size_bytes,
                        "collation": sql_pool.collation,
                        "created_at": datetime.now().isoformat()
                    }
                    synapse_data["sql_pools"].append(pool_info)
                    
            except Exception as e:
                logger.warning(f"Erro ao extrair SQL pools do workspace {workspace_name}: {str(e)}")
            
            # Extrair Spark pools
            try:
                spark_pools = synapse_client.big_data_pools.list_by_workspace(resource_group, workspace_name)
                
                for spark_pool in spark_pools:
                    pool_info = {
                        "id": generate_uuid(),
                        "workspace_id": workspace_info["id"],
                        "name": spark_pool.name,
                        "provisioning_state": spark_pool.provisioning_state,
                        "auto_scale": spark_pool.auto_scale.enabled if spark_pool.auto_scale else False,
                        "node_count": spark_pool.node_count,
                        "node_size": spark_pool.node_size,
                        "spark_version": spark_pool.spark_version,
                        "created_at": datetime.now().isoformat()
                    }
                    synapse_data["spark_pools"].append(pool_info)
                    
            except Exception as e:
                logger.warning(f"Erro ao extrair Spark pools do workspace {workspace_name}: {str(e)}")
                
    except Exception as e:
        logger.error(f"Erro ao extrair metadados do Synapse: {str(e)}")
    
    return synapse_data

# Extrair dados do Synapse
print("🔄 Extraindo metadados do Azure Synapse Analytics...")
synapse_metadata = extract_synapse_metadata()

print(f"📊 Azure Synapse extraído:")
print(f"  - Workspaces: {len(synapse_metadata['workspaces'])}")
print(f"  - SQL Pools: {len(synapse_metadata['sql_pools'])}")
print(f"  - Spark Pools: {len(synapse_metadata['spark_pools'])}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Extração Azure Storage

# COMMAND ----------

def extract_storage_metadata():
    """Extrai metadados do Azure Storage"""
    
    storage_client = StorageManagementClient(credential, SUBSCRIPTION_ID)
    storage_data = {
        "accounts": [],
        "containers": [],
        "blobs": [],
        "file_shares": [],
        "queues": []
    }
    
    try:
        # Listar storage accounts
        storage_accounts = storage_client.storage_accounts.list()
        
        for account in storage_accounts:
            account_info = {
                "id": generate_uuid(),
                "name": account.name,
                "location": account.location,
                "resource_group": account.id.split('/')[4],
                "kind": account.kind,
                "sku_name": account.sku.name,
                "sku_tier": account.sku.tier,
                "access_tier": account.access_tier,
                "provisioning_state": account.provisioning_state,
                "primary_location": account.primary_location,
                "secondary_location": account.secondary_location,
                "enable_https_traffic_only": account.enable_https_traffic_only,
                "encryption_services": {},
                "tags": account.tags or {},
                "created_at": datetime.now().isoformat()
            }
            
            # Extrair informações de criptografia
            if account.encryption and account.encryption.services:
                if account.encryption.services.blob:
                    account_info["encryption_services"]["blob"] = account.encryption.services.blob.enabled
                if account.encryption.services.file:
                    account_info["encryption_services"]["file"] = account.encryption.services.file.enabled
            
            storage_data["accounts"].append(account_info)
            
            # Extrair containers (blob storage)
            try:
                resource_group = account_info["resource_group"]
                account_name = account.name
                
                containers = storage_client.blob_containers.list(resource_group, account_name)
                
                for container in containers:
                    container_info = {
                        "id": generate_uuid(),
                        "storage_account_id": account_info["id"],
                        "name": container.name,
                        "public_access": container.public_access,
                        "has_immutability_policy": container.has_immutability_policy,
                        "has_legal_hold": container.has_legal_hold,
                        "metadata": container.metadata or {},
                        "created_at": datetime.now().isoformat()
                    }
                    storage_data["containers"].append(container_info)
                    
            except Exception as e:
                logger.warning(f"Erro ao extrair containers da storage account {account.name}: {str(e)}")
            
            # Extrair file shares
            try:
                file_shares = storage_client.file_shares.list(resource_group, account_name)
                
                for share in file_shares:
                    share_info = {
                        "id": generate_uuid(),
                        "storage_account_id": account_info["id"],
                        "name": share.name,
                        "quota": share.share_quota,
                        "metadata": share.metadata or {},
                        "created_at": datetime.now().isoformat()
                    }
                    storage_data["file_shares"].append(share_info)
                    
            except Exception as e:
                logger.warning(f"Erro ao extrair file shares da storage account {account.name}: {str(e)}")
                
    except Exception as e:
        logger.error(f"Erro ao extrair metadados do Storage: {str(e)}")
    
    return storage_data

# Extrair dados do Storage
print("💾 Extraindo metadados do Azure Storage...")
storage_metadata = extract_storage_metadata()

print(f"📊 Azure Storage extraído:")
print(f"  - Storage Accounts: {len(storage_metadata['accounts'])}")
print(f"  - Containers: {len(storage_metadata['containers'])}")
print(f"  - File Shares: {len(storage_metadata['file_shares'])}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Extração Azure SQL Database

# COMMAND ----------

def extract_sql_database_metadata():
    """Extrai metadados do Azure SQL Database"""
    
    sql_client = SqlManagementClient(credential, SUBSCRIPTION_ID)
    sql_data = {
        "servers": [],
        "databases": [],
        "tables": [],
        "columns": [],
        "elastic_pools": []
    }
    
    try:
        # Listar SQL servers
        sql_servers = sql_client.servers.list()
        
        for server in sql_servers:
            server_info = {
                "id": generate_uuid(),
                "name": server.name,
                "location": server.location,
                "resource_group": server.id.split('/')[4],
                "version": server.version,
                "administrator_login": server.administrator_login,
                "state": server.state,
                "fully_qualified_domain_name": server.fully_qualified_domain_name,
                "tags": server.tags or {},
                "created_at": datetime.now().isoformat()
            }
            sql_data["servers"].append(server_info)
            
            resource_group = server_info["resource_group"]
            server_name = server.name
            
            # Extrair databases
            try:
                databases = sql_client.databases.list_by_server(resource_group, server_name)
                
                for database in databases:
                    # Pular database master
                    if database.name == 'master':
                        continue
                        
                    database_info = {
                        "id": generate_uuid(),
                        "server_id": server_info["id"],
                        "name": database.name,
                        "status": database.status,
                        "collation": database.collation,
                        "creation_date": database.creation_date.isoformat() if database.creation_date else None,
                        "current_service_objective_name": database.current_service_objective_name,
                        "max_size_bytes": database.max_size_bytes,
                        "elastic_pool_name": database.elastic_pool_name,
                        "tags": database.tags or {},
                        "created_at": datetime.now().isoformat()
                    }
                    sql_data["databases"].append(database_info)
                    
                    # Extrair esquema das tabelas (se possível conectar)
                    try:
                        # Construir connection string
                        connection_string = f"Driver={{ODBC Driver 17 for SQL Server}};Server={server.fully_qualified_domain_name};Database={database.name};Authentication=ActiveDirectoryServicePrincipal;UID={CLIENT_ID};PWD={CLIENT_SECRET}"
                        
                        # Conectar e extrair metadados
                        with pyodbc.connect(connection_string, timeout=30) as conn:
                            cursor = conn.cursor()
                            
                            # Obter tabelas
                            cursor.execute("""
                                SELECT 
                                    TABLE_SCHEMA,
                                    TABLE_NAME,
                                    TABLE_TYPE
                                FROM INFORMATION_SCHEMA.TABLES
                                WHERE TABLE_TYPE = 'BASE TABLE'
                            """)
                            
                            for row in cursor.fetchall():
                                table_info = {
                                    "id": generate_uuid(),
                                    "database_id": database_info["id"],
                                    "schema_name": row[0],
                                    "name": row[1],
                                    "type": row[2],
                                    "full_name": f"{database.name}.{row[0]}.{row[1]}",
                                    "created_at": datetime.now().isoformat()
                                }
                                sql_data["tables"].append(table_info)
                                
                                # Obter colunas da tabela
                                cursor.execute("""
                                    SELECT 
                                        COLUMN_NAME,
                                        DATA_TYPE,
                                        IS_NULLABLE,
                                        COLUMN_DEFAULT,
                                        CHARACTER_MAXIMUM_LENGTH
                                    FROM INFORMATION_SCHEMA.COLUMNS
                                    WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
                                    ORDER BY ORDINAL_POSITION
                                """, row[0], row[1])
                                
                                for col_row in cursor.fetchall():
                                    column_info = {
                                        "id": generate_uuid(),
                                        "table_id": table_info["id"],
                                        "name": col_row[0],
                                        "data_type": col_row[1],
                                        "is_nullable": col_row[2] == 'YES',
                                        "default_value": col_row[3],
                                        "max_length": col_row[4],
                                        "created_at": datetime.now().isoformat()
                                    }
                                    sql_data["columns"].append(column_info)
                                    
                    except Exception as e:
                        logger.warning(f"Erro ao conectar no database {database.name}: {str(e)}")
                        
            except Exception as e:
                logger.warning(f"Erro ao extrair databases do servidor {server_name}: {str(e)}")
                
    except Exception as e:
        logger.error(f"Erro ao extrair metadados do SQL Database: {str(e)}")
    
    return sql_data

# Extrair dados do SQL Database
print("🗄️ Extraindo metadados do Azure SQL Database...")
sql_metadata = extract_sql_database_metadata()

print(f"📊 Azure SQL Database extraído:")
print(f"  - Servers: {len(sql_metadata['servers'])}")
print(f"  - Databases: {len(sql_metadata['databases'])}")
print(f"  - Tables: {len(sql_metadata['tables'])}")
print(f"  - Columns: {len(sql_metadata['columns'])}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Extração de Métricas Azure Monitor

# COMMAND ----------

def extract_azure_monitor_metrics():
    """Extrai métricas do Azure Monitor"""
    
    monitor_client = MonitorManagementClient(credential, SUBSCRIPTION_ID)
    metrics_data = []
    
    try:
        # Período para coleta de métricas (últimos 7 dias)
        end_time = datetime.now()
        start_time = end_time - timedelta(days=7)
        
        # Obter recursos para coletar métricas
        resource_client = ResourceManagementClient(credential, SUBSCRIPTION_ID)
        resources = resource_client.resources.list()
        
        # Tipos de recursos para coletar métricas
        target_resource_types = [
            'Microsoft.DataFactory/factories',
            'Microsoft.Synapse/workspaces',
            'Microsoft.Storage/storageAccounts',
            'Microsoft.Sql/servers/databases'
        ]
        
        for resource in resources:
            if resource.type in target_resource_types:
                try:
                    # Definir métricas baseadas no tipo de recurso
                    metric_names = []
                    
                    if resource.type == 'Microsoft.DataFactory/factories':
                        metric_names = ['PipelineRuns', 'ActivityRuns', 'TriggerRuns']
                    elif resource.type == 'Microsoft.Synapse/workspaces':
                        metric_names = ['BuiltinSqlPoolDataProcessedBytes', 'BuiltinSqlPoolLoginAttempts']
                    elif resource.type == 'Microsoft.Storage/storageAccounts':
                        metric_names = ['Transactions', 'UsedCapacity', 'Availability']
                    elif resource.type == 'Microsoft.Sql/servers/databases':
                        metric_names = ['cpu_percent', 'dtu_consumption_percent', 'storage_percent']
                    
                    for metric_name in metric_names:
                        try:
                            # Obter métricas
                            metrics = monitor_client.metrics.list(
                                resource_uri=resource.id,
                                timespan=f"{start_time.isoformat()}/{end_time.isoformat()}",
                                interval='PT1H',  # Intervalo de 1 hora
                                metricnames=metric_name,
                                aggregation='Average'
                            )
                            
                            for metric in metrics.value:
                                for timeserie in metric.timeseries:
                                    for data_point in timeserie.data:
                                        if data_point.average is not None:
                                            metric_info = {
                                                "id": generate_uuid(),
                                                "resource_id": resource.id,
                                                "resource_name": resource.name,
                                                "resource_type": resource.type,
                                                "metric_name": metric.name.value,
                                                "metric_value": data_point.average,
                                                "unit": metric.unit.value if metric.unit else '',
                                                "timestamp": data_point.time_stamp.isoformat(),
                                                "aggregation": "Average",
                                                "created_at": datetime.now().isoformat()
                                            }
                                            metrics_data.append(metric_info)
                                            
                        except Exception as e:
                            logger.warning(f"Erro ao obter métrica {metric_name} para {resource.name}: {str(e)}")
                            
                except Exception as e:
                    logger.warning(f"Erro ao processar métricas do recurso {resource.name}: {str(e)}")
                    
    except Exception as e:
        logger.error(f"Erro ao extrair métricas do Azure Monitor: {str(e)}")
    
    return metrics_data

# Extrair métricas
print("📈 Extraindo métricas do Azure Monitor...")
monitor_metrics = extract_azure_monitor_metrics()

print(f"📊 Azure Monitor extraído:")
print(f"  - Métricas coletadas: {len(monitor_metrics)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Mapeamento para Modelo de Governança

# COMMAND ----------

def map_azure_to_governance_model():
    """Mapeia dados Azure para o modelo de governança"""
    
    governance_data = {
        "domains": [],
        "entities": [],
        "entity_attributes": [],
        "data_contracts": [],
        "stewards": [],
        "tags": [],
        "entity_tags": [],
        "external_references": [],
        "usage_metrics": [],
        "integration_configs": [],
        "sync_logs": []
    }
    
    # Criar domínios baseados nos resource groups
    resource_groups = set()
    
    # Coletar resource groups de todos os serviços
    for factory in adf_metadata["factories"]:
        resource_groups.add(factory["resource_group"])
    for workspace in synapse_metadata["workspaces"]:
        resource_groups.add(workspace["resource_group"])
    for account in storage_metadata["accounts"]:
        resource_groups.add(account["resource_group"])
    for server in sql_metadata["servers"]:
        resource_groups.add(server["resource_group"])
    
    # Criar domínios
    domain_map = {}
    for rg in resource_groups:
        domain = {
            "id": generate_uuid(),
            "name": rg,
            "description": f"Domínio baseado no Resource Group Azure: {rg}",
            "parent_domain_id": None,
            "steward_id": None,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        governance_data["domains"].append(domain)
        domain_map[rg] = domain["id"]
    
    # Mapear Data Factory pipelines para entidades
    for pipeline in adf_metadata["pipelines"]:
        factory = next((f for f in adf_metadata["factories"] if f["id"] == pipeline["factory_id"]), None)
        if factory:
            entity = {
                "id": generate_uuid(),
                "name": pipeline["name"],
                "type": "pipeline",
                "description": f"Pipeline do Azure Data Factory: {pipeline['description']}",
                "domain_id": domain_map.get(factory["resource_group"]),
                "steward_id": None,
                "unity_catalog_path": None,
                "schema_definition": {
                    "activities": pipeline["activities"],
                    "parameters": pipeline["parameters"]
                },
                "business_glossary_id": None,
                "classification": "internal",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "created_by": None,
                "updated_by": None
            }
            governance_data["entities"].append(entity)
            
            # Criar referência externa
            external_ref = {
                "id": generate_uuid(),
                "entity_id": entity["id"],
                "reference_type": "azure_data_factory",
                "external_id": f"{factory['name']}/{pipeline['name']}",
                "external_url": f"https://portal.azure.com/#@{TENANT_ID}/resource/subscriptions/{SUBSCRIPTION_ID}/resourceGroups/{factory['resource_group']}/providers/Microsoft.DataFactory/factories/{factory['name']}/pipelines/{pipeline['name']}",
                "sync_status": "active",
                "last_synced_at": datetime.now().isoformat(),
                "created_at": datetime.now().isoformat()
            }
            governance_data["external_references"].append(external_ref)
    
    # Mapear datasets do Data Factory
    for dataset in adf_metadata["datasets"]:
        factory = next((f for f in adf_metadata["factories"] if f["id"] == dataset["factory_id"]), None)
        if factory:
            entity = {
                "id": generate_uuid(),
                "name": dataset["name"],
                "type": "dataset",
                "description": f"Dataset do Azure Data Factory: {dataset['description']}",
                "domain_id": domain_map.get(factory["resource_group"]),
                "steward_id": None,
                "unity_catalog_path": None,
                "schema_definition": {
                    "type": dataset["type"],
                    "linked_service": dataset["linked_service"],
                    "schema": dataset["schema"]
                },
                "business_glossary_id": None,
                "classification": "internal",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "created_by": None,
                "updated_by": None
            }
            governance_data["entities"].append(entity)
            
            # Mapear schema para atributos
            for column in dataset["schema"]:
                if isinstance(column, dict) and "name" in column:
                    attribute = {
                        "id": generate_uuid(),
                        "entity_id": entity["id"],
                        "name": column["name"],
                        "data_type": column.get("type", "unknown"),
                        "description": column.get("description", ""),
                        "is_nullable": True,
                        "is_primary_key": False,
                        "is_foreign_key": False,
                        "business_term_id": None,
                        "classification": "internal",
                        "masking_policy_id": None,
                        "created_at": datetime.now().isoformat(),
                        "updated_at": datetime.now().isoformat()
                    }
                    governance_data["entity_attributes"].append(attribute)
    
    # Mapear tabelas SQL para entidades
    for table in sql_metadata["tables"]:
        database = next((d for d in sql_metadata["databases"] if d["id"] == table["database_id"]), None)
        if database:
            server = next((s for s in sql_metadata["servers"] if s["id"] == database["server_id"]), None)
            if server:
                entity = {
                    "id": generate_uuid(),
                    "name": table["name"],
                    "type": "table",
                    "description": f"Tabela do Azure SQL Database: {table['full_name']}",
                    "domain_id": domain_map.get(server["resource_group"]),
                    "steward_id": None,
                    "unity_catalog_path": None,
                    "schema_definition": {
                        "schema_name": table["schema_name"],
                        "table_type": table["type"]
                    },
                    "business_glossary_id": None,
                    "classification": "internal",
                    "created_at": datetime.now().isoformat(),
                    "updated_at": datetime.now().isoformat(),
                    "created_by": None,
                    "updated_by": None
                }
                governance_data["entities"].append(entity)
                
                # Mapear colunas para atributos
                table_columns = [c for c in sql_metadata["columns"] if c["table_id"] == table["id"]]
                for column in table_columns:
                    attribute = {
                        "id": generate_uuid(),
                        "entity_id": entity["id"],
                        "name": column["name"],
                        "data_type": column["data_type"],
                        "description": "",
                        "is_nullable": column["is_nullable"],
                        "is_primary_key": False,
                        "is_foreign_key": False,
                        "business_term_id": None,
                        "classification": "internal",
                        "masking_policy_id": None,
                        "created_at": datetime.now().isoformat(),
                        "updated_at": datetime.now().isoformat()
                    }
                    governance_data["entity_attributes"].append(attribute)
    
    # Mapear storage containers para entidades
    for container in storage_metadata["containers"]:
        account = next((a for a in storage_metadata["accounts"] if a["id"] == container["storage_account_id"]), None)
        if account:
            entity = {
                "id": generate_uuid(),
                "name": container["name"],
                "type": "container",
                "description": f"Container do Azure Storage: {account['name']}/{container['name']}",
                "domain_id": domain_map.get(account["resource_group"]),
                "steward_id": None,
                "unity_catalog_path": None,
                "schema_definition": {
                    "public_access": container["public_access"],
                    "metadata": container["metadata"]
                },
                "business_glossary_id": None,
                "classification": "internal" if container["public_access"] == "None" else "public",
                "created_at": datetime.now().isoformat(),
                "updated_at": datetime.now().isoformat(),
                "created_by": None,
                "updated_by": None
            }
            governance_data["entities"].append(entity)
    
    # Mapear métricas do Azure Monitor
    for metric in monitor_metrics:
        usage_metric = {
            "id": generate_uuid(),
            "entity_path": metric["resource_name"],
            "metric_type": metric["metric_name"],
            "metric_value": metric["metric_value"],
            "measurement_date": datetime.fromisoformat(metric["timestamp"]).date().isoformat(),
            "additional_data": {
                "resource_type": metric["resource_type"],
                "unit": metric["unit"],
                "aggregation": metric["aggregation"]
            },
            "created_at": datetime.now().isoformat()
        }
        governance_data["usage_metrics"].append(usage_metric)
    
    # Criar configurações de integração
    integration_config = {
        "id": generate_uuid(),
        "name": "Azure Services Integration",
        "integration_type": "azure_services",
        "configuration": {
            "tenant_id": TENANT_ID,
            "subscription_id": SUBSCRIPTION_ID,
            "services": ["data_factory", "synapse", "storage", "sql_database", "monitor"]
        },
        "is_active": True,
        "last_sync_at": datetime.now().isoformat(),
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat()
    }
    governance_data["integration_configs"].append(integration_config)
    
    # Criar log de sincronização
    sync_log = {
        "id": generate_uuid(),
        "integration_config_id": integration_config["id"],
        "sync_type": "full_extraction",
        "status": "completed",
        "records_processed": (
            len(governance_data["entities"]) + 
            len(governance_data["entity_attributes"]) + 
            len(governance_data["usage_metrics"])
        ),
        "records_success": (
            len(governance_data["entities"]) + 
            len(governance_data["entity_attributes"]) + 
            len(governance_data["usage_metrics"])
        ),
        "records_failed": 0,
        "error_details": None,
        "started_at": datetime.now().isoformat(),
        "completed_at": datetime.now().isoformat()
    }
    governance_data["sync_logs"].append(sync_log)
    
    return governance_data

# Mapear dados
print("🔄 Mapeando dados Azure para modelo de governança...")
azure_governance_data = map_azure_to_governance_model()

print(f"📊 Dados Azure mapeados:")
print(f"  - Domínios: {len(azure_governance_data['domains'])}")
print(f"  - Entidades: {len(azure_governance_data['entities'])}")
print(f"  - Atributos: {len(azure_governance_data['entity_attributes'])}")
print(f"  - Referências externas: {len(azure_governance_data['external_references'])}")
print(f"  - Métricas de uso: {len(azure_governance_data['usage_metrics'])}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 9. Envio de Dados para API de Governança

# COMMAND ----------

def send_azure_data_to_governance_api(data_type, data_list, batch_size=50):
    """Envia dados Azure para a API de Governança em lotes"""
    
    endpoint_map = {
        "domains": f"{API_BASE_URL}/domains/",
        "entities": f"{API_BASE_URL}/entities/",
        "entity_attributes": f"{API_BASE_URL}/entities/attributes/",
        "external_references": f"{API_BASE_URL}/entities/external-references/",
        "usage_metrics": f"{API_BASE_URL}/metrics/usage/",
        "integration_configs": f"{API_BASE_URL}/integrations/configs/",
        "sync_logs": f"{API_BASE_URL}/integrations/sync-logs/"
    }
    
    if data_type not in endpoint_map:
        logger.error(f"Tipo de dados não suportado: {data_type}")
        return False
    
    endpoint = endpoint_map[data_type]
    total_items = len(data_list)
    success_count = 0
    error_count = 0
    
    print(f"📤 Enviando {total_items} itens de {data_type}...")
    
    # Enviar em lotes
    for i in range(0, total_items, batch_size):
        batch = data_list[i:i + batch_size]
        
        try:
            # Para alguns endpoints, enviar item por item
            if data_type in ["domains", "entities", "integration_configs"]:
                for item in batch:
                    try:
                        response = requests.post(endpoint, headers=api_headers, json=item, timeout=30)
                        if response.status_code in [200, 201]:
                            success_count += 1
                        else:
                            error_count += 1
                            logger.error(f"Erro API: {response.status_code} - {response.text}")
                    except Exception as e:
                        error_count += 1
                        logger.error(f"Erro ao enviar item: {str(e)}")
            else:
                # Enviar lote completo
                try:
                    response = requests.post(endpoint + "batch/", headers=api_headers, json={"items": batch}, timeout=60)
                    if response.status_code in [200, 201]:
                        success_count += len(batch)
                    else:
                        error_count += len(batch)
                        logger.error(f"Erro API lote: {response.status_code} - {response.text}")
                except Exception as e:
                    error_count += len(batch)
                    logger.error(f"Erro ao enviar lote: {str(e)}")
                    
        except Exception as e:
            logger.error(f"Erro ao processar lote {i//batch_size + 1}: {str(e)}")
            error_count += len(batch)
    
    print(f"✅ {data_type}: {success_count} sucessos, {error_count} erros")
    return error_count == 0

# Enviar todos os dados Azure
print("🚀 Iniciando envio de dados Azure para API de Governança...")

# Ordem de envio (respeitando dependências)
azure_send_order = [
    ("domains", azure_governance_data["domains"]),
    ("entities", azure_governance_data["entities"]),
    ("entity_attributes", azure_governance_data["entity_attributes"]),
    ("external_references", azure_governance_data["external_references"]),
    ("usage_metrics", azure_governance_data["usage_metrics"]),
    ("integration_configs", azure_governance_data["integration_configs"]),
    ("sync_logs", azure_governance_data["sync_logs"])
]

azure_total_success = True
for data_type, data_list in azure_send_order:
    if data_list:
        success = send_azure_data_to_governance_api(data_type, data_list)
        azure_total_success = azure_total_success and success
    else:
        print(f"⚠️ Nenhum dado Azure para enviar: {data_type}")

if azure_total_success:
    print("🎉 Todos os dados Azure foram enviados com sucesso!")
else:
    print("⚠️ Alguns dados Azure falharam no envio. Verifique os logs.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 10. Relatório de Extração Azure

# COMMAND ----------

# Gerar relatório final Azure
azure_report = {
    "extraction_timestamp": datetime.now().isoformat(),
    "azure_services_summary": {
        "data_factory": {
            "factories": len(adf_metadata["factories"]),
            "pipelines": len(adf_metadata["pipelines"]),
            "datasets": len(adf_metadata["datasets"]),
            "linked_services": len(adf_metadata["linked_services"])
        },
        "synapse": {
            "workspaces": len(synapse_metadata["workspaces"]),
            "sql_pools": len(synapse_metadata["sql_pools"]),
            "spark_pools": len(synapse_metadata["spark_pools"])
        },
        "storage": {
            "accounts": len(storage_metadata["accounts"]),
            "containers": len(storage_metadata["containers"]),
            "file_shares": len(storage_metadata["file_shares"])
        },
        "sql_database": {
            "servers": len(sql_metadata["servers"]),
            "databases": len(sql_metadata["databases"]),
            "tables": len(sql_metadata["tables"]),
            "columns": len(sql_metadata["columns"])
        },
        "monitor": {
            "metrics_collected": len(monitor_metrics)
        }
    },
    "governance_mapping": {
        "domains_created": len(azure_governance_data["domains"]),
        "entities_created": len(azure_governance_data["entities"]),
        "attributes_created": len(azure_governance_data["entity_attributes"]),
        "external_references_created": len(azure_governance_data["external_references"]),
        "usage_metrics_created": len(azure_governance_data["usage_metrics"])
    },
    "api_integration": {
        "total_success": azure_total_success,
        "data_types_sent": len(azure_send_order)
    },
    "authentication": {
        "tenant_id": TENANT_ID,
        "client_id": CLIENT_ID,
        "subscription_id": SUBSCRIPTION_ID
    }
}

# Salvar relatório
with open("/tmp/azure_extraction_report.json", "w") as f:
    json.dump(azure_report, f, indent=2, default=str)

# Salvar metadados completos
azure_complete_data = {
    "data_factory": adf_metadata,
    "synapse": synapse_metadata,
    "storage": storage_metadata,
    "sql_database": sql_metadata,
    "monitor_metrics": monitor_metrics,
    "governance_mapping": azure_governance_data
}

with open("/tmp/azure_complete_metadata.json", "w") as f:
    json.dump(azure_complete_data, f, indent=2, default=str)

print("📋 Relatório de Extração Azure:")
print("=" * 60)
print(f"🕐 Timestamp: {azure_report['extraction_timestamp']}")
print(f"🏭 Azure Data Factory:")
print(f"   - Factories: {azure_report['azure_services_summary']['data_factory']['factories']}")
print(f"   - Pipelines: {azure_report['azure_services_summary']['data_factory']['pipelines']}")
print(f"   - Datasets: {azure_report['azure_services_summary']['data_factory']['datasets']}")
print(f"   - Linked Services: {azure_report['azure_services_summary']['data_factory']['linked_services']}")
print(f"🔄 Azure Synapse:")
print(f"   - Workspaces: {azure_report['azure_services_summary']['synapse']['workspaces']}")
print(f"   - SQL Pools: {azure_report['azure_services_summary']['synapse']['sql_pools']}")
print(f"   - Spark Pools: {azure_report['azure_services_summary']['synapse']['spark_pools']}")
print(f"💾 Azure Storage:")
print(f"   - Accounts: {azure_report['azure_services_summary']['storage']['accounts']}")
print(f"   - Containers: {azure_report['azure_services_summary']['storage']['containers']}")
print(f"   - File Shares: {azure_report['azure_services_summary']['storage']['file_shares']}")
print(f"🗄️ Azure SQL Database:")
print(f"   - Servers: {azure_report['azure_services_summary']['sql_database']['servers']}")
print(f"   - Databases: {azure_report['azure_services_summary']['sql_database']['databases']}")
print(f"   - Tables: {azure_report['azure_services_summary']['sql_database']['tables']}")
print(f"   - Columns: {azure_report['azure_services_summary']['sql_database']['columns']}")
print(f"📈 Azure Monitor:")
print(f"   - Métricas: {azure_report['azure_services_summary']['monitor']['metrics_collected']}")
print(f"🏗️ Governança:")
print(f"   - Domínios: {azure_report['governance_mapping']['domains_created']}")
print(f"   - Entidades: {azure_report['governance_mapping']['entities_created']}")
print(f"   - Atributos: {azure_report['governance_mapping']['attributes_created']}")
print(f"   - Referências externas: {azure_report['governance_mapping']['external_references_created']}")
print(f"   - Métricas de uso: {azure_report['governance_mapping']['usage_metrics_created']}")
print(f"🚀 API: {'✅ Sucesso' if azure_report['api_integration']['total_success'] else '❌ Falhas'}")
print("=" * 60)

print("✅ Extração Azure via SPN concluída!")
print("📁 Arquivos salvos:")
print("   - /tmp/azure_extraction_report.json")
print("   - /tmp/azure_complete_metadata.json")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 11. Configuração de Secrets e Segurança
# MAGIC 
# MAGIC ### Configurar Secrets no Databricks:
# MAGIC 
# MAGIC ```bash
# MAGIC # Criar scope para Azure
# MAGIC databricks secrets create-scope azure
# MAGIC 
# MAGIC # Adicionar credenciais do Service Principal
# MAGIC databricks secrets put-secret azure tenant_id
# MAGIC databricks secrets put-secret azure client_id
# MAGIC databricks secrets put-secret azure client_secret
# MAGIC databricks secrets put-secret azure subscription_id
# MAGIC 
# MAGIC # Criar scope para API de Governança
# MAGIC databricks secrets create-scope governance
# MAGIC databricks secrets put-secret governance api_token
# MAGIC ```
# MAGIC 
# MAGIC ### Permissões Necessárias no Azure:
# MAGIC 
# MAGIC O Service Principal precisa das seguintes permissões:
# MAGIC 
# MAGIC 1. **Subscription Level:**
# MAGIC    - Reader
# MAGIC    - Monitoring Reader
# MAGIC 
# MAGIC 2. **Data Factory:**
# MAGIC    - Data Factory Contributor (ou Reader)
# MAGIC 
# MAGIC 3. **Synapse:**
# MAGIC    - Synapse Contributor (ou Reader)
# MAGIC 
# MAGIC 4. **Storage:**
# MAGIC    - Storage Account Contributor (ou Reader)
# MAGIC    - Storage Blob Data Reader
# MAGIC 
# MAGIC 5. **SQL Database:**
# MAGIC    - SQL DB Contributor (ou Reader)
# MAGIC    - Acesso de login nas databases específicas
# MAGIC 
# MAGIC 6. **Key Vault:**
# MAGIC    - Key Vault Reader
# MAGIC    - Key Vault Secrets User

# COMMAND ----------

# MAGIC %md
# MAGIC ## 12. Agendamento e Automação
# MAGIC 
# MAGIC ### Job Configuration:
# MAGIC 
# MAGIC ```json
# MAGIC {
# MAGIC   "name": "Azure SPN Data Extraction",
# MAGIC   "tasks": [{
# MAGIC     "task_key": "extract_azure_data",
# MAGIC     "notebook_task": {
# MAGIC       "notebook_path": "/path/to/this/notebook"
# MAGIC     },
# MAGIC     "job_cluster_key": "azure_extraction_cluster"
# MAGIC   }],
# MAGIC   "schedule": {
# MAGIC     "quartz_cron_expression": "0 0 3 * * ?",
# MAGIC     "timezone_id": "America/Sao_Paulo"
# MAGIC   },
# MAGIC   "email_notifications": {
# MAGIC     "on_failure": ["admin@company.com"],
# MAGIC     "on_success": ["data-team@company.com"]
# MAGIC   }
# MAGIC }
# MAGIC ```
# MAGIC 
# MAGIC ### Monitoramento:
# MAGIC 
# MAGIC ```python
# MAGIC # Configurar alertas para falhas
# MAGIC alert_config = {
# MAGIC     "name": "Azure Extraction Failure",
# MAGIC     "condition": "job_status == 'FAILED'",
# MAGIC     "actions": ["email", "slack", "teams"]
# MAGIC }
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC ## 13. Próximos Passos e Melhorias
# MAGIC 
# MAGIC ### Funcionalidades Avançadas:
# MAGIC 
# MAGIC 1. **Extração Incremental:**
# MAGIC    ```python
# MAGIC    # Implementar delta baseado em timestamps
# MAGIC    last_sync = get_last_sync_timestamp()
# MAGIC    new_resources = get_resources_modified_since(last_sync)
# MAGIC    ```
# MAGIC 
# MAGIC 2. **Classificação Automática:**
# MAGIC    ```python
# MAGIC    # ML para detectar dados sensíveis
# MAGIC    sensitive_patterns = [
# MAGIC        r'\b\d{3}-\d{2}-\d{4}\b',  # SSN
# MAGIC        r'\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b'  # Credit Card
# MAGIC    ]
# MAGIC    ```
# MAGIC 
# MAGIC 3. **Lineage Automático:**
# MAGIC    ```python
# MAGIC    # Analisar pipelines ADF para lineage
# MAGIC    def extract_pipeline_lineage(pipeline_definition):
# MAGIC        sources = []
# MAGIC        targets = []
# MAGIC        # Parse activities...
# MAGIC        return build_lineage_graph(sources, targets)
# MAGIC    ```
# MAGIC 
# MAGIC 4. **Qualidade de Dados:**
# MAGIC    ```python
# MAGIC    # Implementar regras de qualidade automáticas
# MAGIC    quality_rules = [
# MAGIC        {"type": "completeness", "threshold": 0.95},
# MAGIC        {"type": "uniqueness", "columns": ["id"]},
# MAGIC        {"type": "validity", "pattern": r"^[A-Z]{2}\d{4}$"}
# MAGIC    ]
# MAGIC    ```
# MAGIC 
# MAGIC ### Integrações Adicionais:
# MAGIC 
# MAGIC - **Azure Purview** - Catálogo nativo
# MAGIC - **Power BI** - Relatórios e dashboards
# MAGIC - **Azure DevOps** - Pipelines CI/CD
# MAGIC - **Microsoft Graph** - Usuários e permissões
# MAGIC - **Azure Cost Management** - Custos por recurso

