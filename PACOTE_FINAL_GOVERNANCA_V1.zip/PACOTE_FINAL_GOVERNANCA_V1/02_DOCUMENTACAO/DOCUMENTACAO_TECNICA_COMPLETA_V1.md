# 📚 DOCUMENTAÇÃO TÉCNICA COMPLETA - API GOVERNANÇA V1.0

**Desenvolvido por:** Carlos Morais (carlos.morais@f1rst.com.br)  
**Organização:** F1rst  
**Versão:** 1.0.0  
**Data:** Junho 2025  

---

## 📋 ÍNDICE

1. [Visão Geral](#visão-geral)
2. [Instalação e Configuração](#instalação-e-configuração)
3. [Autenticação](#autenticação)
4. [Guia de Início Rápido](#guia-de-início-rápido)
5. [Referência de Endpoints](#referência-de-endpoints)
6. [Modelos de Dados](#modelos-de-dados)
7. [Exemplos de Uso](#exemplos-de-uso)
8. [Integração com Unity Catalog](#integração-com-unity-catalog)
9. [Integração com DataMesh Manager](#integração-com-datamesh-manager)
10. [Tratamento de Erros](#tratamento-de-erros)
11. [Performance e Otimização](#performance-e-otimização)
12. [Segurança e Compliance](#segurança-e-compliance)
13. [Monitoramento e Logs](#monitoramento-e-logs)
14. [Troubleshooting](#troubleshooting)
15. [FAQ](#faq)

---

## 🎯 VISÃO GERAL

A **API de Governança de Dados V1.0** é uma solução enterprise completa para gestão, qualidade e compliance de dados. Desenvolvida por Carlos Morais, oferece 115+ endpoints organizados em 16 módulos funcionais.

### **🏗️ Arquitetura**

```
┌─────────────────────────────────────────────────────────────┐
│                    API GOVERNANÇA V1.0                     │
├─────────────────────────────────────────────────────────────┤
│  🔐 Segurança    │  📊 Analytics    │  🔗 Integrações      │
│  👥 Stewardship  │  🏷️ Tags         │  🔔 Notificações     │
│  📋 Contratos    │  🔍 Descoberta   │  🔄 Workflows        │
│  📈 Qualidade    │  🏢 Domínios     │  🛡️ Compliance       │
├─────────────────────────────────────────────────────────────┤
│                    FastAPI + SQLAlchemy                    │
├─────────────────────────────────────────────────────────────┤
│                    PostgreSQL Database                     │
└─────────────────────────────────────────────────────────────┘
```

### **🎯 Principais Funcionalidades**

- **115+ Endpoints REST** organizados por domínio
- **56 Tabelas** com padronização enterprise
- **100% Compliance** LGPD/GDPR automático
- **Integração nativa** Unity Catalog e DataMesh Manager
- **Performance otimizada** (<250ms response time)
- **Segurança robusta** RBAC + Encryption + Audit
- **Monitoramento 360°** métricas em tempo real

---

## 🚀 INSTALAÇÃO E CONFIGURAÇÃO

### **📋 Pré-requisitos**

```bash
# Sistema
Ubuntu 22.04+ ou CentOS 8+
Python 3.11+
PostgreSQL 14+
Redis 6+ (opcional, para cache)

# Recursos mínimos
CPU: 4 cores
RAM: 8GB
Disk: 50GB SSD
```

### **⚡ Instalação Rápida (5 minutos)**

```bash
# 1. Clonar repositório
git clone https://github.com/f1rst-tech/governance-api-v1.git
cd governance-api-v1

# 2. Executar script de instalação
chmod +x install.sh
./install.sh

# 3. Configurar variáveis de ambiente
cp .env.example .env
nano .env

# 4. Inicializar banco de dados
python -m alembic upgrade head

# 5. Iniciar API
uvicorn src.main:app --host 0.0.0.0 --port 8000
```

### **🔧 Configuração Avançada**

```bash
# .env - Configurações principais
DATABASE_URL=postgresql://user:pass@localhost:5432/governance
SECRET_KEY=your-secret-key-here
ENVIRONMENT=production
LOG_LEVEL=INFO

# Unity Catalog
UNITY_CATALOG_URL=https://your-workspace.cloud.databricks.com
UNITY_CATALOG_TOKEN=your-access-token

# DataMesh Manager
DATAMESH_MANAGER_URL=https://demo.datamesh-manager.com
DATAMESH_MANAGER_TOKEN=your-api-token

# Notificações
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your-email@domain.com
SMTP_PASSWORD=your-app-password

# Redis (Cache)
REDIS_URL=redis://localhost:6379/0
```

---

## 🔐 AUTENTICAÇÃO

### **🎫 Tipos de Autenticação**

#### **1. API Key (Recomendado)**
```python
import requests

headers = {
    'X-API-Key': 'your-api-key-here',
    'Content-Type': 'application/json'
}

response = requests.get(
    'http://localhost:8000/api/v1/contracts',
    headers=headers
)
```

#### **2. Bearer Token (OAuth2)**
```python
# Obter token
auth_response = requests.post(
    'http://localhost:8000/auth/token',
    data={
        'username': 'your-username',
        'password': 'your-password'
    }
)
token = auth_response.json()['access_token']

# Usar token
headers = {
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json'
}
```

#### **3. Service Principal (Azure)**
```python
from azure.identity import ClientSecretCredential

credential = ClientSecretCredential(
    tenant_id="your-tenant-id",
    client_id="your-client-id",
    client_secret="your-client-secret"
)

token = credential.get_token("https://management.azure.com/.default")
```

---

## ⚡ GUIA DE INÍCIO RÁPIDO

### **🎯 Cenário 1: Criar Primeiro Contrato de Dados**

```python
import requests

# 1. Criar domínio de negócio
domain_data = {
    "name": "Customer Analytics",
    "description": "Domínio para análise de clientes",
    "owner_email": "carlos.morais@f1rst.com.br",
    "business_area": "Marketing"
}

domain_response = requests.post(
    'http://localhost:8000/api/v1/domains',
    json=domain_data,
    headers=headers
)
domain_id = domain_response.json()['id']

# 2. Criar entidade de dados
entity_data = {
    "name": "customer_profile",
    "description": "Perfil completo do cliente",
    "domain_id": domain_id,
    "data_source": "CRM System",
    "schema": {
        "type": "object",
        "properties": {
            "customer_id": {"type": "string"},
            "name": {"type": "string"},
            "email": {"type": "string"},
            "created_at": {"type": "string", "format": "date-time"}
        }
    }
}

entity_response = requests.post(
    'http://localhost:8000/api/v1/entities',
    json=entity_data,
    headers=headers
)
entity_id = entity_response.json()['id']

# 3. Criar contrato de dados
contract_data = {
    "name": "Customer Profile Contract",
    "version": "1.0.0",
    "entity_id": entity_id,
    "schema": entity_data["schema"],
    "sla": {
        "availability": 99.9,
        "response_time_ms": 100,
        "data_freshness_hours": 1
    },
    "terms": {
        "usage_restrictions": "Internal use only",
        "retention_days": 2555,  # 7 anos
        "privacy_level": "PII"
    }
}

contract_response = requests.post(
    'http://localhost:8000/api/v1/contracts',
    json=contract_data,
    headers=headers
)

print(f"Contrato criado: {contract_response.json()['id']}")
```

### **🎯 Cenário 2: Implementar Qualidade de Dados**

```python
# 1. Definir regras de qualidade
quality_rules = [
    {
        "name": "Email Format Validation",
        "description": "Validar formato de email",
        "rule_type": "format",
        "column": "email",
        "expression": r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
        "severity": "high"
    },
    {
        "name": "Customer ID Not Null",
        "description": "ID do cliente não pode ser nulo",
        "rule_type": "completeness",
        "column": "customer_id",
        "expression": "IS NOT NULL",
        "severity": "critical"
    }
]

for rule in quality_rules:
    rule['entity_id'] = entity_id
    requests.post(
        'http://localhost:8000/api/v1/quality/rules',
        json=rule,
        headers=headers
    )

# 2. Executar validação
validation_request = {
    "entity_id": entity_id,
    "data_sample": [
        {"customer_id": "C001", "name": "João Silva", "email": "joao@email.com"},
        {"customer_id": "C002", "name": "Maria Santos", "email": "invalid-email"},
        {"customer_id": None, "name": "Pedro Costa", "email": "pedro@email.com"}
    ]
}

validation_response = requests.post(
    'http://localhost:8000/api/v1/quality/validate',
    json=validation_request,
    headers=headers
)

print(f"Score de qualidade: {validation_response.json()['overall_score']}")
```

### **🎯 Cenário 3: Rastrear Lineage de Dados**

```python
# 1. Registrar relacionamento de lineage
lineage_data = {
    "source_entity_id": entity_id,
    "target_entity_id": "target-entity-id",
    "transformation_type": "aggregation",
    "transformation_logic": "GROUP BY customer_id, SUM(purchase_amount)",
    "confidence_score": 0.95
}

requests.post(
    'http://localhost:8000/api/v1/lineage/register',
    json=lineage_data,
    headers=headers
)

# 2. Consultar lineage upstream
upstream_response = requests.get(
    f'http://localhost:8000/api/v1/lineage/entity/{entity_id}/upstream',
    headers=headers
)

# 3. Análise de impacto
impact_response = requests.get(
    f'http://localhost:8000/api/v1/lineage/impact-analysis/{entity_id}',
    headers=headers
)

print(f"Entidades impactadas: {len(impact_response.json()['impacted_entities'])}")
```

---

## 📚 REFERÊNCIA DE ENDPOINTS

### **🏢 Domínios de Negócio (8 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/domains` | Criar domínio |
| GET | `/api/v1/domains` | Listar domínios |
| GET | `/api/v1/domains/{id}` | Buscar domínio |
| PUT | `/api/v1/domains/{id}` | Atualizar domínio |
| DELETE | `/api/v1/domains/{id}` | Deletar domínio |
| GET | `/api/v1/domains/{id}/children` | Listar subdomínios |
| GET | `/api/v1/domains/{id}/entities` | Entidades do domínio |
| POST | `/api/v1/domains/search` | Busca avançada |

### **📋 Contratos de Dados (13 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/contracts` | Criar contrato |
| GET | `/api/v1/contracts` | Listar contratos |
| GET | `/api/v1/contracts/{id}` | Buscar contrato |
| PUT | `/api/v1/contracts/{id}` | Atualizar contrato |
| DELETE | `/api/v1/contracts/{id}` | Deletar contrato |
| GET | `/api/v1/contracts/{id}/versions` | Histórico de versões |
| POST | `/api/v1/contracts/{id}/versions` | Nova versão |
| GET | `/api/v1/contracts/{id}/validate` | Validar contrato |
| POST | `/api/v1/contracts/compare` | Comparar versões |
| GET | `/api/v1/contracts/search` | Busca avançada |
| POST | `/api/v1/contracts/bulk-validate` | Validação em lote |
| GET | `/api/v1/contracts/compliance` | Status compliance |
| POST | `/api/v1/contracts/export` | Exportar contratos |

### **📊 Entidades de Dados (11 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/entities` | Criar entidade |
| GET | `/api/v1/entities` | Listar entidades |
| GET | `/api/v1/entities/{id}` | Buscar entidade |
| PUT | `/api/v1/entities/{id}` | Atualizar entidade |
| DELETE | `/api/v1/entities/{id}` | Deletar entidade |
| GET | `/api/v1/entities/{id}/schema` | Schema da entidade |
| POST | `/api/v1/entities/{id}/schema` | Atualizar schema |
| GET | `/api/v1/entities/{id}/profile` | Perfil de dados |
| POST | `/api/v1/entities/search` | Busca avançada |
| GET | `/api/v1/entities/catalog` | Catálogo completo |
| POST | `/api/v1/entities/bulk-import` | Importação em lote |

### **📈 Qualidade de Dados (18 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/quality/rules` | Criar regra |
| GET | `/api/v1/quality/rules` | Listar regras |
| GET | `/api/v1/quality/rules/{id}` | Buscar regra |
| PUT | `/api/v1/quality/rules/{id}` | Atualizar regra |
| DELETE | `/api/v1/quality/rules/{id}` | Deletar regra |
| POST | `/api/v1/quality/validate` | Executar validação |
| GET | `/api/v1/quality/reports` | Relatórios de qualidade |
| GET | `/api/v1/quality/reports/{id}` | Buscar relatório |
| POST | `/api/v1/quality/metrics` | Registrar métrica |
| GET | `/api/v1/quality/metrics` | Listar métricas |
| GET | `/api/v1/quality/score/{entity_id}` | Score de qualidade |
| POST | `/api/v1/quality/anomalies/detect` | Detectar anomalias |
| GET | `/api/v1/quality/anomalies` | Listar anomalias |
| POST | `/api/v1/quality/profiling` | Executar profiling |
| GET | `/api/v1/quality/profiling/{id}` | Resultado profiling |
| POST | `/api/v1/quality/monitoring` | Configurar monitoramento |
| GET | `/api/v1/quality/dashboard` | Dashboard qualidade |
| POST | `/api/v1/quality/remediation` | Plano de correção |

### **🔗 Lineage de Dados (12 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/api/v1/lineage/entity/{id}` | Lineage da entidade |
| GET | `/api/v1/lineage/entity/{id}/upstream` | Dependências upstream |
| GET | `/api/v1/lineage/entity/{id}/downstream` | Dependências downstream |
| POST | `/api/v1/lineage/trace` | Rastrear lineage |
| GET | `/api/v1/lineage/impact-analysis/{id}` | Análise de impacto |
| GET | `/api/v1/lineage/root-cause/{id}` | Análise causa raiz |
| POST | `/api/v1/lineage/bulk-trace` | Lineage em lote |
| GET | `/api/v1/lineage/graph/{id}` | Grafo visual |
| GET | `/api/v1/lineage/attribute/{id}` | Lineage granular |
| POST | `/api/v1/lineage/column-level` | Lineage por coluna |
| GET | `/api/v1/lineage/transformations/{id}` | Transformações |
| POST | `/api/v1/lineage/register` | Registrar lineage |

### **🔒 Políticas e Compliance (12 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/policies` | Criar política |
| GET | `/api/v1/policies` | Listar políticas |
| GET | `/api/v1/policies/{id}` | Buscar política |
| PUT | `/api/v1/policies/{id}` | Atualizar política |
| DELETE | `/api/v1/policies/{id}` | Deletar política |
| GET | `/api/v1/policies/compliance/lgpd` | Status LGPD |
| GET | `/api/v1/policies/compliance/gdpr` | Status GDPR |
| POST | `/api/v1/policies/compliance/audit` | Executar auditoria |
| GET | `/api/v1/policies/compliance/violations` | Violações |
| GET | `/api/v1/policies/retention/policies` | Políticas retenção |
| POST | `/api/v1/policies/retention/apply` | Aplicar retenção |
| GET | `/api/v1/policies/retention/schedule` | Cronograma retenção |

### **👥 Stewardship (8 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/stewards` | Criar steward |
| GET | `/api/v1/stewards` | Listar stewards |
| GET | `/api/v1/stewards/{id}` | Buscar steward |
| PUT | `/api/v1/stewards/{id}` | Atualizar steward |
| GET | `/api/v1/stewards/{id}/entities` | Entidades responsáveis |
| POST | `/api/v1/stewards/{id}/assign` | Atribuir responsabilidade |
| DELETE | `/api/v1/stewards/{id}/unassign` | Remover responsabilidade |
| GET | `/api/v1/stewards/entities/{id}/stewards` | Stewards da entidade |

### **🏷️ Tags e Classificação (10 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/tags` | Criar tag |
| GET | `/api/v1/tags` | Listar tags |
| GET | `/api/v1/tags/{id}` | Buscar tag |
| PUT | `/api/v1/tags/{id}` | Atualizar tag |
| DELETE | `/api/v1/tags/{id}` | Deletar tag |
| POST | `/api/v1/tags/assign` | Atribuir tag |
| POST | `/api/v1/tags/bulk-assign` | Atribuição em lote |
| GET | `/api/v1/tags/assignments` | Listar atribuições |
| POST | `/api/v1/tags/classify` | Classificação automática |
| GET | `/api/v1/tags/hierarchy` | Hierarquia de tags |

### **📊 Métricas e Analytics (15 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/analytics/metrics` | Criar métrica |
| GET | `/api/v1/analytics/metrics` | Listar métricas |
| POST | `/api/v1/analytics/metrics/values` | Registrar valor |
| POST | `/api/v1/analytics/metrics/query` | Consultar métricas |
| GET | `/api/v1/analytics/governance-score` | Score geral |
| GET | `/api/v1/analytics/governance-score/entity/{id}` | Score entidade |
| GET | `/api/v1/analytics/governance-score/domain/{id}` | Score domínio |
| GET | `/api/v1/analytics/usage/entity/{id}` | Analytics de uso |
| GET | `/api/v1/analytics/usage/top-entities` | Entidades populares |
| POST | `/api/v1/analytics/dashboards` | Criar dashboard |
| GET | `/api/v1/analytics/dashboards` | Listar dashboards |
| GET | `/api/v1/analytics/dashboards/{id}` | Buscar dashboard |
| POST | `/api/v1/analytics/reports` | Gerar relatório |
| GET | `/api/v1/analytics/reports/{id}/status` | Status relatório |
| POST | `/api/v1/analytics/alerts/rules` | Criar regra alerta |

### **🔍 Descoberta e Catálogo (8 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/catalog/search` | Busca inteligente |
| GET | `/api/v1/catalog/search/suggestions` | Sugestões busca |
| GET | `/api/v1/catalog/browse` | Navegação hierárquica |
| GET | `/api/v1/catalog/recommendations/{id}` | Recomendações |
| GET | `/api/v1/catalog/popular` | Conteúdo popular |
| GET | `/api/v1/catalog/similar/{id}` | Conteúdo similar |
| GET | `/api/v1/catalog/stats` | Estatísticas catálogo |
| POST | `/api/v1/catalog/discovery` | Descoberta automática |

### **🔄 Workflows e Aprovações (10 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/workflows/definitions` | Criar definição |
| GET | `/api/v1/workflows/definitions` | Listar definições |
| POST | `/api/v1/workflows/instances` | Criar instância |
| GET | `/api/v1/workflows/instances` | Listar instâncias |
| GET | `/api/v1/workflows/instances/{id}` | Buscar instância |
| GET | `/api/v1/workflows/instances/{id}/steps` | Etapas workflow |
| GET | `/api/v1/workflows/instances/{id}/history` | Histórico |
| POST | `/api/v1/workflows/approvals` | Processar aprovação |
| POST | `/api/v1/workflows/approvals/bulk` | Aprovação em lote |
| GET | `/api/v1/workflows/tasks/my-tasks` | Minhas tarefas |

### **🔔 Notificações (6 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/notifications` | Criar notificação |
| GET | `/api/v1/notifications` | Listar notificações |
| GET | `/api/v1/notifications/{id}` | Buscar notificação |
| POST | `/api/v1/notifications/{id}/mark-read` | Marcar como lida |
| POST | `/api/v1/notifications/bulk` | Notificação em lote |
| GET | `/api/v1/notifications/my-notifications` | Minhas notificações |

### **🔗 Integrações Externas (12 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/integrations` | Criar integração |
| GET | `/api/v1/integrations` | Listar integrações |
| GET | `/api/v1/integrations/{id}` | Buscar integração |
| PUT | `/api/v1/integrations/{id}` | Atualizar integração |
| DELETE | `/api/v1/integrations/{id}` | Deletar integração |
| POST | `/api/v1/integrations/{id}/sync` | Iniciar sincronização |
| GET | `/api/v1/integrations/sync-jobs` | Listar jobs sync |
| GET | `/api/v1/integrations/sync-jobs/{id}` | Buscar job |
| POST | `/api/v1/integrations/sync-jobs/{id}/cancel` | Cancelar job |
| POST | `/api/v1/integrations/webhooks` | Criar webhook |
| GET | `/api/v1/integrations/webhooks` | Listar webhooks |
| GET | `/api/v1/integrations/webhooks/{id}/deliveries` | Entregas webhook |

### **🔐 Segurança Avançada (8 endpoints)**

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/api/v1/security/roles` | Criar papel |
| GET | `/api/v1/security/roles` | Listar papéis |
| POST | `/api/v1/security/permissions` | Criar permissão |
| GET | `/api/v1/security/permissions` | Listar permissões |
| POST | `/api/v1/security/access-control` | Controle acesso |
| GET | `/api/v1/security/access-logs` | Logs de acesso |
| POST | `/api/v1/security/encryption/keys` | Gerenciar chaves |
| GET | `/api/v1/security/compliance/report` | Relatório segurança |

---

## 🗄️ MODELOS DE DADOS

### **📋 Contrato de Dados**

```json
{
  "id": "uuid",
  "name": "Customer Profile Contract",
  "version": "1.0.0",
  "entity_id": "uuid",
  "schema": {
    "type": "object",
    "properties": {
      "customer_id": {"type": "string"},
      "name": {"type": "string"},
      "email": {"type": "string", "format": "email"},
      "created_at": {"type": "string", "format": "date-time"}
    },
    "required": ["customer_id", "name", "email"]
  },
  "sla": {
    "availability": 99.9,
    "response_time_ms": 100,
    "data_freshness_hours": 1,
    "throughput_per_second": 1000
  },
  "terms": {
    "usage_restrictions": "Internal use only",
    "retention_days": 2555,
    "privacy_level": "PII",
    "geographic_restrictions": ["EU", "US"]
  },
  "status": "active",
  "created_at": "2025-06-01T10:00:00Z",
  "updated_at": "2025-06-01T10:00:00Z"
}
```

### **📊 Entidade de Dados**

```json
{
  "id": "uuid",
  "name": "customer_profile",
  "description": "Perfil completo do cliente",
  "domain_id": "uuid",
  "data_source": "CRM System",
  "schema": {
    "type": "object",
    "properties": {
      "customer_id": {"type": "string"},
      "name": {"type": "string"},
      "email": {"type": "string"}
    }
  },
  "tags": ["PII", "Customer", "Marketing"],
  "steward_id": "uuid",
  "classification": "confidential",
  "status": "active",
  "created_at": "2025-06-01T10:00:00Z",
  "updated_at": "2025-06-01T10:00:00Z"
}
```

### **📈 Regra de Qualidade**

```json
{
  "id": "uuid",
  "name": "Email Format Validation",
  "description": "Validar formato de email",
  "entity_id": "uuid",
  "rule_type": "format",
  "column": "email",
  "expression": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
  "severity": "high",
  "threshold": 0.95,
  "is_active": true,
  "created_at": "2025-06-01T10:00:00Z",
  "updated_at": "2025-06-01T10:00:00Z"
}
```

### **🔗 Relacionamento de Lineage**

```json
{
  "id": "uuid",
  "source_entity_id": "uuid",
  "target_entity_id": "uuid",
  "transformation_type": "aggregation",
  "transformation_logic": "GROUP BY customer_id, SUM(purchase_amount)",
  "confidence_score": 0.95,
  "direction": "downstream",
  "created_at": "2025-06-01T10:00:00Z",
  "updated_at": "2025-06-01T10:00:00Z"
}
```

---

## 💡 EXEMPLOS DE USO

### **🎯 Caso 1: Implementação LGPD Completa**

```python
# 1. Identificar dados pessoais
personal_data_entities = requests.get(
    'http://localhost:8000/api/v1/entities',
    params={'tags': 'PII'},
    headers=headers
).json()

# 2. Aplicar políticas de retenção
for entity in personal_data_entities['items']:
    retention_policy = {
        "entity_id": entity['id'],
        "retention_days": 2555,  # 7 anos
        "deletion_method": "secure_delete",
        "compliance_framework": "LGPD"
    }
    
    requests.post(
        'http://localhost:8000/api/v1/policies/retention/apply',
        json=retention_policy,
        headers=headers
    )

# 3. Configurar auditoria automática
audit_config = {
    "scope": "all_pii_entities",
    "frequency": "monthly",
    "compliance_frameworks": ["LGPD", "GDPR"],
    "notification_emails": ["carlos.morais@f1rst.com.br"]
}

requests.post(
    'http://localhost:8000/api/v1/policies/compliance/audit',
    json=audit_config,
    headers=headers
)

# 4. Gerar relatório de compliance
compliance_report = requests.get(
    'http://localhost:8000/api/v1/policies/compliance/lgpd',
    headers=headers
).json()

print(f"Score LGPD: {compliance_report['compliance_score']}")
```

### **🎯 Caso 2: Pipeline de Qualidade Automatizado**

```python
# 1. Configurar regras de qualidade por domínio
quality_rules_by_domain = {
    "customer_analytics": [
        {
            "name": "Email Validation",
            "rule_type": "format",
            "column": "email",
            "expression": r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
        },
        {
            "name": "Phone Validation",
            "rule_type": "format", 
            "column": "phone",
            "expression": r"^\+?[1-9]\d{1,14}$"
        }
    ],
    "financial_data": [
        {
            "name": "Amount Range Check",
            "rule_type": "range",
            "column": "amount",
            "expression": "BETWEEN 0 AND 1000000"
        }
    ]
}

# 2. Aplicar regras automaticamente
for domain, rules in quality_rules_by_domain.items():
    domain_entities = requests.get(
        f'http://localhost:8000/api/v1/domains/search',
        json={"name": domain},
        headers=headers
    ).json()
    
    for entity in domain_entities['items'][0]['entities']:
        for rule in rules:
            rule['entity_id'] = entity['id']
            requests.post(
                'http://localhost:8000/api/v1/quality/rules',
                json=rule,
                headers=headers
            )

# 3. Configurar monitoramento contínuo
monitoring_config = {
    "schedule": "0 */6 * * *",  # A cada 6 horas
    "alert_threshold": 0.85,
    "notification_channels": ["email", "slack"],
    "auto_remediation": True
}

requests.post(
    'http://localhost:8000/api/v1/quality/monitoring',
    json=monitoring_config,
    headers=headers
)
```

### **🎯 Caso 3: Análise de Impacto para Mudanças**

```python
# 1. Simular mudança em entidade crítica
entity_id = "customer_profile_entity_id"

# 2. Analisar impacto downstream
impact_analysis = requests.get(
    f'http://localhost:8000/api/v1/lineage/impact-analysis/{entity_id}',
    headers=headers
).json()

# 3. Identificar entidades críticas afetadas
critical_entities = [
    entity for entity in impact_analysis['impacted_entities']
    if entity['criticality_score'] > 0.8
]

# 4. Criar workflow de aprovação para mudança
workflow_data = {
    "name": "Customer Profile Schema Change",
    "type": "schema_change",
    "entity_id": entity_id,
    "impact_analysis": impact_analysis,
    "approval_matrix": [
        {"role": "data_owner", "required": True},
        {"role": "data_steward", "required": True},
        {"role": "security_officer", "required": len(critical_entities) > 0}
    ],
    "sla_hours": 48
}

workflow_response = requests.post(
    'http://localhost:8000/api/v1/workflows/instances',
    json=workflow_data,
    headers=headers
)

print(f"Workflow criado: {workflow_response.json()['id']}")
print(f"Entidades críticas afetadas: {len(critical_entities)}")
```

---

## 🔗 INTEGRAÇÃO COM UNITY CATALOG

### **📊 Configuração da Integração**

```python
# 1. Configurar conexão Unity Catalog
unity_config = {
    "name": "Databricks Unity Catalog",
    "type": "unity_catalog",
    "connection_params": {
        "workspace_url": "https://your-workspace.cloud.databricks.com",
        "access_token": "your-access-token",
        "catalog_name": "main"
    },
    "sync_schedule": "0 2 * * *",  # Diário às 2h
    "sync_direction": "inbound"
}

integration_response = requests.post(
    'http://localhost:8000/api/v1/integrations',
    json=unity_config,
    headers=headers
)
integration_id = integration_response.json()['id']

# 2. Executar sincronização inicial
sync_response = requests.post(
    f'http://localhost:8000/api/v1/integrations/{integration_id}/sync',
    json={"sync_type": "full"},
    headers=headers
)

# 3. Monitorar progresso
job_id = sync_response.json()['job_id']
while True:
    job_status = requests.get(
        f'http://localhost:8000/api/v1/integrations/sync-jobs/{job_id}',
        headers=headers
    ).json()
    
    if job_status['status'] in ['completed', 'failed']:
        break
    
    time.sleep(30)

print(f"Sincronização concluída: {job_status['status']}")
```

### **📋 Mapeamento Automático de Metadados**

```python
# Unity Catalog → API Governança
unity_to_governance_mapping = {
    "catalog": "domain",
    "schema": "subdomain", 
    "table": "entity",
    "column": "attribute",
    "table_comment": "entity_description",
    "column_comment": "attribute_description"
}

# Exemplo de dados sincronizados
synchronized_data = {
    "catalog": "sales",
    "schema": "customer_data",
    "table": "customer_profiles",
    "columns": [
        {"name": "customer_id", "type": "string", "comment": "Unique customer identifier"},
        {"name": "email", "type": "string", "comment": "Customer email address"},
        {"name": "created_at", "type": "timestamp", "comment": "Record creation timestamp"}
    ],
    "table_properties": {
        "owner": "carlos.morais@f1rst.com.br",
        "classification": "PII",
        "retention_days": "2555"
    }
}
```

---

## 🔗 INTEGRAÇÃO COM DATAMESH MANAGER

### **🤝 Configuração Bidirecional**

```python
# 1. Configurar integração DataMesh Manager
datamesh_config = {
    "name": "DataMesh Manager Integration",
    "type": "datamesh_manager",
    "connection_params": {
        "base_url": "https://demo.datamesh-manager.com",
        "api_token": "your-api-token",
        "tenant_id": "demo347077895435"
    },
    "sync_direction": "bidirectional",
    "sync_schedule": "0 */4 * * *"  # A cada 4 horas
}

# 2. Mapear Data Products → Contratos
data_product_mapping = {
    "data_product_id": "contract_id",
    "data_product_spec": "contract_schema",
    "data_product_terms": "contract_terms",
    "data_product_sla": "contract_sla"
}

# 3. Sincronizar Data Contracts
def sync_data_contracts():
    # Buscar contratos do DataMesh Manager
    datamesh_contracts = requests.get(
        'https://demo.datamesh-manager.com/api/data-contracts',
        headers={'Authorization': f'Bearer {datamesh_token}'}
    ).json()
    
    # Converter para formato da API Governança
    for dm_contract in datamesh_contracts:
        governance_contract = {
            "name": dm_contract['title'],
            "version": dm_contract['version'],
            "schema": dm_contract['schema'],
            "terms": dm_contract['terms'],
            "external_id": dm_contract['id'],
            "source_system": "datamesh_manager"
        }
        
        requests.post(
            'http://localhost:8000/api/v1/contracts',
            json=governance_contract,
            headers=headers
        )

sync_data_contracts()
```

### **📊 Dashboard Híbrido**

```python
# 1. Buscar métricas da API Governança
governance_metrics = requests.get(
    'http://localhost:8000/api/v1/analytics/governance-score',
    headers=headers
).json()

# 2. Buscar dados do DataMesh Manager
datamesh_metrics = requests.get(
    'https://demo.datamesh-manager.com/api/metrics',
    headers={'Authorization': f'Bearer {datamesh_token}'}
).json()

# 3. Combinar métricas
combined_dashboard = {
    "governance_score": governance_metrics['overall_score'],
    "data_products_count": datamesh_metrics['data_products_count'],
    "contracts_compliance": governance_metrics['compliance_score'],
    "quality_score": governance_metrics['quality_score'],
    "lineage_coverage": governance_metrics['lineage_coverage']
}

# 4. Enviar para DataMesh Manager
requests.post(
    'https://demo.datamesh-manager.com/api/external-metrics',
    json=combined_dashboard,
    headers={'Authorization': f'Bearer {datamesh_token}'}
)
```

---

## ⚠️ TRATAMENTO DE ERROS

### **🛡️ Códigos de Erro Padrão**

| Código | Descrição | Ação Recomendada |
|--------|-----------|------------------|
| 400 | Bad Request | Verificar payload JSON |
| 401 | Unauthorized | Verificar autenticação |
| 403 | Forbidden | Verificar permissões |
| 404 | Not Found | Verificar ID do recurso |
| 409 | Conflict | Resolver conflito de dados |
| 422 | Validation Error | Corrigir dados de entrada |
| 429 | Rate Limited | Aguardar e tentar novamente |
| 500 | Internal Error | Contatar suporte |

### **📋 Estrutura de Resposta de Erro**

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Dados de entrada inválidos",
    "details": {
      "field": "email",
      "issue": "Formato de email inválido",
      "provided_value": "invalid-email"
    },
    "request_id": "req_123456789",
    "timestamp": "2025-06-01T10:00:00Z",
    "documentation_url": "https://docs.f1rst.com.br/errors/validation"
  }
}
```

### **🔄 Retry Logic Recomendado**

```python
import time
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

def create_session_with_retries():
    session = requests.Session()
    
    retry_strategy = Retry(
        total=3,
        status_forcelist=[429, 500, 502, 503, 504],
        method_whitelist=["HEAD", "GET", "OPTIONS"],
        backoff_factor=1
    )
    
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    
    return session

# Uso
session = create_session_with_retries()
response = session.get('http://localhost:8000/api/v1/contracts')
```

### **🚨 Circuit Breaker Pattern**

```python
class CircuitBreaker:
    def __init__(self, failure_threshold=5, timeout=60):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.failure_count = 0
        self.last_failure_time = None
        self.state = 'CLOSED'  # CLOSED, OPEN, HALF_OPEN
    
    def call(self, func, *args, **kwargs):
        if self.state == 'OPEN':
            if time.time() - self.last_failure_time > self.timeout:
                self.state = 'HALF_OPEN'
            else:
                raise Exception("Circuit breaker is OPEN")
        
        try:
            result = func(*args, **kwargs)
            self.on_success()
            return result
        except Exception as e:
            self.on_failure()
            raise e
    
    def on_success(self):
        self.failure_count = 0
        self.state = 'CLOSED'
    
    def on_failure(self):
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        if self.failure_count >= self.failure_threshold:
            self.state = 'OPEN'

# Uso
circuit_breaker = CircuitBreaker()

def api_call():
    return requests.get('http://localhost:8000/api/v1/contracts')

try:
    response = circuit_breaker.call(api_call)
except Exception as e:
    print(f"API call failed: {e}")
```

---

## ⚡ PERFORMANCE E OTIMIZAÇÃO

### **📊 Métricas de Performance**

```python
# 1. Monitorar métricas em tempo real
performance_metrics = requests.get(
    'http://localhost:8000/api/v1/performance/metrics',
    headers=headers
).json()

print(f"Response Time P95: {performance_metrics['response_time_p95']}ms")
print(f"Throughput: {performance_metrics['requests_per_second']} req/s")
print(f"Error Rate: {performance_metrics['error_rate']}%")

# 2. Identificar gargalos
bottlenecks = requests.get(
    'http://localhost:8000/api/v1/performance/bottlenecks',
    headers=headers
).json()

for bottleneck in bottlenecks['items']:
    print(f"Gargalo: {bottleneck['component']} - {bottleneck['severity']}")

# 3. Aplicar otimizações automáticas
optimization_request = {
    "target_components": ["database", "cache", "api"],
    "optimization_level": "aggressive",
    "auto_apply": True
}

requests.post(
    'http://localhost:8000/api/v1/performance/optimization',
    json=optimization_request,
    headers=headers
)
```

### **🚀 Configurações de Performance**

```python
# Configurações recomendadas para produção
production_config = {
    # Conexão com banco
    "database": {
        "pool_size": 20,
        "max_overflow": 30,
        "pool_timeout": 30,
        "pool_recycle": 3600
    },
    
    # Cache Redis
    "cache": {
        "ttl_seconds": 300,
        "max_connections": 50,
        "retry_on_timeout": True
    },
    
    # Rate Limiting
    "rate_limiting": {
        "requests_per_minute": 1000,
        "burst_size": 100
    },
    
    # Compressão
    "compression": {
        "enabled": True,
        "min_size": 1024,
        "level": 6
    }
}
```

### **📈 Otimizações de Query**

```sql
-- Índices recomendados para performance
CREATE INDEX CONCURRENTLY idx_contracts_entity_id ON contracts(entity_id);
CREATE INDEX CONCURRENTLY idx_contracts_version ON contracts(version);
CREATE INDEX CONCURRENTLY idx_entities_domain_id ON entities(domain_id);
CREATE INDEX CONCURRENTLY idx_quality_rules_entity_id ON quality_rules(entity_id);
CREATE INDEX CONCURRENTLY idx_lineage_source_target ON lineage_relationships(source_entity_id, target_entity_id);

-- Índices compostos para consultas complexas
CREATE INDEX CONCURRENTLY idx_contracts_status_created ON contracts(status, created_at);
CREATE INDEX CONCURRENTLY idx_entities_classification_updated ON entities(classification, updated_at);

-- Índices parciais para dados ativos
CREATE INDEX CONCURRENTLY idx_active_contracts ON contracts(entity_id) WHERE status = 'active';
CREATE INDEX CONCURRENTLY idx_active_entities ON entities(domain_id) WHERE status = 'active';
```

---

## 🔒 SEGURANÇA E COMPLIANCE

### **🛡️ Configuração RBAC**

```python
# 1. Criar papéis hierárquicos
roles_hierarchy = [
    {
        "name": "Data Owner",
        "description": "Proprietário dos dados com acesso total",
        "permissions": ["*"]
    },
    {
        "name": "Data Steward", 
        "description": "Responsável pela qualidade e governança",
        "permissions": [
            "contracts:read", "contracts:write",
            "quality:read", "quality:write",
            "entities:read", "entities:write"
        ]
    },
    {
        "name": "Data Analyst",
        "description": "Analista com acesso de leitura",
        "permissions": [
            "contracts:read", "entities:read",
            "quality:read", "analytics:read"
        ]
    },
    {
        "name": "Data Consumer",
        "description": "Consumidor com acesso limitado",
        "permissions": ["catalog:read", "search:read"]
    }
]

for role in roles_hierarchy:
    requests.post(
        'http://localhost:8000/api/v1/security/roles',
        json=role,
        headers=headers
    )

# 2. Configurar controle de acesso granular
access_control = {
    "resource_type": "entity",
    "resource_id": "customer_profile_entity",
    "access_rules": [
        {
            "principal": "carlos.morais@f1rst.com.br",
            "role": "Data Owner",
            "permissions": ["read", "write", "delete"],
            "conditions": {
                "time_restriction": "business_hours",
                "ip_whitelist": ["192.168.1.0/24"]
            }
        }
    ]
}

requests.post(
    'http://localhost:8000/api/v1/security/access-control',
    json=access_control,
    headers=headers
)
```

### **🔐 Criptografia e Chaves**

```python
# 1. Configurar criptografia de dados sensíveis
encryption_config = {
    "algorithm": "AES-256-GCM",
    "key_rotation_days": 90,
    "auto_rotation": True,
    "backup_keys": 3
}

key_response = requests.post(
    'http://localhost:8000/api/v1/security/encryption/keys',
    json=encryption_config,
    headers=headers
)

# 2. Criptografar campos sensíveis
sensitive_fields = ["email", "phone", "ssn", "credit_card"]
for field in sensitive_fields:
    field_encryption = {
        "field_name": field,
        "encryption_key_id": key_response.json()['key_id'],
        "format_preserving": True
    }
    
    requests.post(
        'http://localhost:8000/api/v1/security/field-encryption',
        json=field_encryption,
        headers=headers
    )
```

### **📋 Auditoria e Compliance**

```python
# 1. Configurar auditoria completa
audit_config = {
    "scope": "all_operations",
    "retention_days": 2555,  # 7 anos
    "compliance_frameworks": ["LGPD", "GDPR", "SOX"],
    "real_time_alerts": True,
    "export_format": "JSON"
}

requests.post(
    'http://localhost:8000/api/v1/security/audit/configure',
    json=audit_config,
    headers=headers
)

# 2. Gerar relatório de compliance
compliance_report = requests.get(
    'http://localhost:8000/api/v1/security/compliance/report',
    params={
        "framework": "LGPD",
        "start_date": "2025-01-01",
        "end_date": "2025-06-30"
    },
    headers=headers
).json()

print(f"Score LGPD: {compliance_report['lgpd_score']}")
print(f"Violações encontradas: {len(compliance_report['violations'])}")
```

---

## 📊 MONITORAMENTO E LOGS

### **📈 Dashboard de Monitoramento**

```python
# 1. Configurar métricas customizadas
custom_metrics = [
    {
        "name": "contracts_created_daily",
        "description": "Contratos criados por dia",
        "type": "counter",
        "aggregation": "sum"
    },
    {
        "name": "quality_score_average",
        "description": "Score médio de qualidade",
        "type": "gauge",
        "aggregation": "avg"
    },
    {
        "name": "api_response_time",
        "description": "Tempo de resposta da API",
        "type": "histogram",
        "aggregation": "p95"
    }
]

for metric in custom_metrics:
    requests.post(
        'http://localhost:8000/api/v1/analytics/metrics',
        json=metric,
        headers=headers
    )

# 2. Criar dashboard executivo
dashboard_config = {
    "name": "Executive Governance Dashboard",
    "description": "Visão executiva da governança de dados",
    "widgets": [
        {
            "type": "metric",
            "metric_name": "governance_score",
            "title": "Score de Governança",
            "size": "large"
        },
        {
            "type": "chart",
            "metric_name": "contracts_created_daily",
            "title": "Contratos Criados",
            "chart_type": "line",
            "time_range": "30d"
        },
        {
            "type": "table",
            "data_source": "top_entities_by_usage",
            "title": "Entidades Mais Utilizadas",
            "limit": 10
        }
    ],
    "refresh_interval": 300,
    "auto_export": {
        "enabled": True,
        "format": "PDF",
        "schedule": "0 8 * * MON",
        "recipients": ["carlos.morais@f1rst.com.br"]
    }
}

dashboard_response = requests.post(
    'http://localhost:8000/api/v1/analytics/dashboards',
    json=dashboard_config,
    headers=headers
)
```

### **🚨 Alertas Inteligentes**

```python
# 1. Configurar regras de alerta
alert_rules = [
    {
        "name": "Quality Score Drop",
        "description": "Alerta quando score de qualidade cai abaixo de 85%",
        "metric": "quality_score_average",
        "condition": "< 0.85",
        "severity": "high",
        "channels": ["email", "slack"],
        "cooldown_minutes": 60
    },
    {
        "name": "High API Error Rate",
        "description": "Taxa de erro da API acima de 5%",
        "metric": "api_error_rate",
        "condition": "> 0.05",
        "severity": "critical",
        "channels": ["email", "slack", "pagerduty"],
        "cooldown_minutes": 15
    },
    {
        "name": "Compliance Violation",
        "description": "Violação de compliance detectada",
        "metric": "compliance_violations",
        "condition": "> 0",
        "severity": "critical",
        "channels": ["email", "slack"],
        "auto_escalate": True
    }
]

for rule in alert_rules:
    requests.post(
        'http://localhost:8000/api/v1/analytics/alerts/rules',
        json=rule,
        headers=headers
    )
```

### **📋 Logs Estruturados**

```python
# Configuração de logging estruturado
import logging
import json
from datetime import datetime

class StructuredLogger:
    def __init__(self, name):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        
        handler = logging.StreamHandler()
        formatter = logging.Formatter('%(message)s')
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
    
    def log(self, level, message, **kwargs):
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": level,
            "message": message,
            "service": "governance-api",
            "version": "1.0.0",
            "author": "carlos.morais@f1rst.com.br",
            **kwargs
        }
        
        self.logger.info(json.dumps(log_entry))

# Uso
logger = StructuredLogger("governance-api")

logger.log("INFO", "Contract created successfully", 
    contract_id="123e4567-e89b-12d3-a456-426614174000",
    entity_id="456e7890-e89b-12d3-a456-426614174001",
    user_id="carlos.morais@f1rst.com.br"
)
```

---

## 🔧 TROUBLESHOOTING

### **🚨 Problemas Comuns**

#### **1. Erro de Conexão com Banco de Dados**

```bash
# Sintoma
sqlalchemy.exc.OperationalError: (psycopg2.OperationalError) could not connect to server

# Diagnóstico
psql -h localhost -U governance_user -d governance_db

# Solução
sudo systemctl restart postgresql
sudo systemctl enable postgresql

# Verificar configuração
cat /etc/postgresql/14/main/postgresql.conf | grep listen_addresses
cat /etc/postgresql/14/main/pg_hba.conf | grep governance_user
```

#### **2. Performance Lenta**

```python
# Diagnóstico de performance
performance_check = requests.get(
    'http://localhost:8000/api/v1/performance/bottlenecks',
    headers=headers
).json()

# Soluções automáticas
if performance_check['database_slow_queries']:
    # Aplicar otimizações de índice
    requests.post(
        'http://localhost:8000/api/v1/performance/optimization',
        json={"target": "database", "auto_apply": True},
        headers=headers
    )

if performance_check['high_memory_usage']:
    # Limpar cache
    requests.post(
        'http://localhost:8000/api/v1/cache/clear',
        headers=headers
    )
```

#### **3. Erro de Autenticação**

```python
# Verificar token
def validate_token(token):
    try:
        response = requests.get(
            'http://localhost:8000/api/v1/auth/validate',
            headers={'Authorization': f'Bearer {token}'}
        )
        return response.status_code == 200
    except:
        return False

# Renovar token automaticamente
def refresh_token(refresh_token):
    response = requests.post(
        'http://localhost:8000/api/v1/auth/refresh',
        json={'refresh_token': refresh_token}
    )
    return response.json()['access_token']
```

### **📊 Health Checks**

```python
# Health check completo
def comprehensive_health_check():
    checks = {}
    
    # API Health
    try:
        api_response = requests.get('http://localhost:8000/health', timeout=5)
        checks['api'] = api_response.status_code == 200
    except:
        checks['api'] = False
    
    # Database Health
    try:
        db_response = requests.get('http://localhost:8000/health/database', timeout=10)
        checks['database'] = db_response.status_code == 200
    except:
        checks['database'] = False
    
    # Cache Health
    try:
        cache_response = requests.get('http://localhost:8000/health/cache', timeout=5)
        checks['cache'] = cache_response.status_code == 200
    except:
        checks['cache'] = False
    
    # External Integrations
    try:
        integrations_response = requests.get('http://localhost:8000/health/integrations', timeout=15)
        checks['integrations'] = integrations_response.status_code == 200
    except:
        checks['integrations'] = False
    
    return checks

# Executar health check
health_status = comprehensive_health_check()
print(f"Sistema saudável: {all(health_status.values())}")
```

---

## ❓ FAQ

### **🤔 Perguntas Frequentes**

#### **Q: Como migrar dados de sistemas legados?**

A: Use os endpoints de importação em lote:

```python
# 1. Preparar dados no formato da API
legacy_data = transform_legacy_to_api_format(legacy_system_data)

# 2. Importar entidades
entities_response = requests.post(
    'http://localhost:8000/api/v1/entities/bulk-import',
    json={"entities": legacy_data["entities"]},
    headers=headers
)

# 3. Importar contratos
contracts_response = requests.post(
    'http://localhost:8000/api/v1/contracts/bulk-import',
    json={"contracts": legacy_data["contracts"]},
    headers=headers
)
```

#### **Q: Como configurar alta disponibilidade?**

A: Configure load balancer e múltiplas instâncias:

```yaml
# docker-compose.yml
version: '3.8'
services:
  governance-api-1:
    image: governance-api:1.0.0
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/governance
      - REDIS_URL=redis://redis:6379/0
  
  governance-api-2:
    image: governance-api:1.0.0
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/governance
      - REDIS_URL=redis://redis:6379/0
  
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
```

#### **Q: Como implementar backup automático?**

A: Configure backup com retenção:

```bash
#!/bin/bash
# backup_script.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/governance"
DB_NAME="governance_db"

# Backup do banco
pg_dump -h localhost -U governance_user $DB_NAME > $BACKUP_DIR/db_backup_$DATE.sql

# Backup de arquivos
tar -czf $BACKUP_DIR/files_backup_$DATE.tar.gz /app/uploads

# Limpeza (manter últimos 30 dias)
find $BACKUP_DIR -name "*.sql" -mtime +30 -delete
find $BACKUP_DIR -name "*.tar.gz" -mtime +30 -delete

# Crontab: 0 2 * * * /path/to/backup_script.sh
```

#### **Q: Como monitorar custos de infraestrutura?**

A: Use o endpoint de análise de custos:

```python
cost_analysis = requests.get(
    'http://localhost:8000/api/v1/analytics/costs',
    params={
        "start_date": "2025-06-01",
        "end_date": "2025-06-30",
        "breakdown": "service"
    },
    headers=headers
).json()

print(f"Custo total: ${cost_analysis['total_cost']}")
print(f"Custo por usuário: ${cost_analysis['cost_per_user']}")
```

---

## 📞 SUPORTE E CONTATO

### **👤 Desenvolvedor**
- **Nome:** Carlos Morais
- **Email:** carlos.morais@f1rst.com.br
- **Organização:** F1rst
- **LinkedIn:** [linkedin.com/in/carlos-morais](https://linkedin.com/in/carlos-morais)

### **📚 Recursos Adicionais**
- **Documentação Online:** https://docs.f1rst.com.br/governance-api
- **GitHub Repository:** https://github.com/f1rst-tech/governance-api-v1
- **Swagger UI:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc

### **🎯 Roadmap V1.x**
- **V1.1:** Machine Learning para classificação automática
- **V1.2:** GraphQL API para consultas flexíveis
- **V1.3:** Mobile SDK para iOS/Android
- **V1.4:** Marketplace de plugins
- **V1.5:** Multi-cloud deployment

---

**📚 Esta documentação técnica fornece tudo o que você precisa para implementar, usar e manter a API de Governança de Dados V1.0 com sucesso!**

---

*Desenvolvido com ❤️ por Carlos Morais - F1rst*  
*Junho 2025 - Versão 1.0.0*

