# Componentes de Integração e Fluxos Técnicos - TBR GDP Core v2.1

**Projeto:** TBR GDP Core - Data Governance API  
**Versão:** 2.1 (Production/Stable)  
**Desenvolvido por:** Carlos Morais  
**Data:** Janeiro 2025  

## 🎯 Visão Geral

O **TBR GDP Core v2.1** oferece uma arquitetura de integração robusta e extensível, projetada para conectar-se nativamente com as principais ferramentas do ecossistema de dados moderno. Com notebooks Databricks especializados, SDKs multi-linguagem e componentes prontos para uso, a plataforma facilita integrações complexas através de interfaces simples e intuitivas.

### 🚀 Principais Componentes v2.1

- **Notebooks Databricks Especializados** - Unity Catalog e Azure SPN extractors
- **SDK Python Completo** - Com suporte async e type hints
- **CLI Tool Avançado** - Para automação e operações em lote
- **Componentes React/Vue** - Para interfaces web
- **APIs REST (65+ endpoints)** - Organizadas por domínio funcional
- **Integrações Nativas** - Unity Catalog, Azure Services, Prometheus
- **Arquitetura Hexagonal** - Extensível e testável

## 🏗️ Arquitetura de Integração

### Modelo Hub-and-Spoke

O TBR GDP Core v2.1 atua como hub central, conectando-se a múltiplas fontes de dados e sistemas consumidores através de uma arquitetura hub-and-spoke otimizada:

```
┌─────────────────────────────────────────────────────────────────┐
│                        External Systems                         │
├─────────────────┬─────────────────┬─────────────────┬───────────┤
│ Unity Catalog   │ Azure Services  │ Informatica     │ Custom    │
│ • Metadados     │ • Data Factory  │ Axon            │ Systems   │
│ • Políticas     │ • SQL Database  │ • Glossário     │ • APIs    │
│ • Lineage       │ • Storage       │ • Políticas     │ • Files   │
│ • Métricas      │ • Synapse       │ • Stewards      │ • Streams │
└─────────────────┴─────────────────┴─────────────────┴───────────┘
         │                 │                 │             │
         ▼                 ▼                 ▼             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Integration Layer                            │
├─────────────────┬─────────────────┬─────────────────┬───────────┤
│ Unity Catalog   │ Azure SPN       │ REST API        │ Custom    │
│ Extractor       │ Extractor       │ Connectors      │ Adapters  │
│ Notebook        │ Notebook        │                 │           │
└─────────────────┴─────────────────┴─────────────────┴───────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                    TBR GDP Core v2.1                           │
│                     (Central Hub)                              │
├─────────────────┬─────────────────┬─────────────────┬───────────┤
│ API Gateway     │ Business Logic  │ Data Storage    │ Event     │
│ • 65+ endpoints │ • Contracts     │ • PostgreSQL    │ Processing│
│ • Rate Limiting │ • Quality       │ • Redis Cache   │ • Kafka   │
│ • Auth/AuthZ    │ • Lineage       │ • 56 Tables     │ • Webhooks│
└─────────────────┴─────────────────┴─────────────────┴───────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Consumer Systems                          │
├─────────────────┬─────────────────┬─────────────────┬───────────┤
│ BI Tools        │ Data Platforms  │ Applications    │ Analytics │
│ • Tableau       │ • Databricks    │ • Custom Apps   │ • ML      │
│ • Power BI      │ • Snowflake     │ • Dashboards    │ • AI      │
│ • Looker        │ • Spark         │ • Reports       │ • Jupyter │
└─────────────────┴─────────────────┴─────────────────┴───────────┘
```

### Princípios de Integração v2.1

#### 1. **API-First Design**
- Todas as integrações via APIs REST padronizadas
- OpenAPI 3.0 specification completa
- Versionamento semântico para compatibilidade
- Rate limiting inteligente por usuário/endpoint

#### 2. **Event-Driven Architecture**
- Eventos para sincronização em tempo real
- Message queues para processamento assíncrono
- Webhooks para notificações externas
- Event sourcing para auditoria completa

#### 3. **Idempotência e Resiliência**
- Operações seguras para retry automático
- Circuit breakers para falhas em cascata
- Timeout configurável por operação
- Dead letter queues para falhas persistentes

#### 4. **Observabilidade Completa**
- Métricas Prometheus nativas
- Logs estruturados em JSON
- Tracing distribuído com OpenTelemetry
- Dashboards Grafana pré-configurados

## 🔌 Componentes de Integração Principais

### 1. Notebook Unity Catalog Extractor

**Objetivo:** Sincronização bidirecional de metadados entre Unity Catalog e TBR GDP Core

#### Arquitetura de Integração
```
Unity Catalog ←→ Databricks Notebook ←→ TBR GDP Core API
     ↓                    ↓                      ↓
  Metadados         Transformação           Governança
  Nativos           e Mapeamento            Centralizada
     ↓                    ↓                      ↓
  Políticas         Validação e             Contratos
  Segurança         Enriquecimento          Formais
```

#### Funcionalidades Implementadas (12 Seções)

**Seção 1: Configuração e Autenticação**
```python
# Configuração do extractor
import os
from databricks.sdk import WorkspaceClient
from tbr_gdpcore_client import GDPCoreClient

# Cliente Databricks
w = WorkspaceClient(
    host=os.getenv("DATABRICKS_HOST"),
    token=os.getenv("DATABRICKS_TOKEN")
)

# Cliente TBR GDP Core
gdp_client = GDPCoreClient(
    base_url=os.getenv("TBR_GDP_BASE_URL"),
    api_key=os.getenv("TBR_GDP_API_KEY")
)
```

**Seção 2: Extração de Catálogos e Schemas**
```python
def extract_catalogs():
    """Extrai todos os catálogos e schemas do Unity Catalog"""
    catalogs = []
    
    for catalog in w.catalogs.list():
        catalog_info = {
            "name": catalog.name,
            "comment": catalog.comment,
            "created_at": catalog.created_at,
            "updated_at": catalog.updated_at,
            "schemas": []
        }
        
        # Extrair schemas do catálogo
        for schema in w.schemas.list(catalog_name=catalog.name):
            schema_info = {
                "name": schema.name,
                "comment": schema.comment,
                "created_at": schema.created_at,
                "updated_at": schema.updated_at,
                "tables": []
            }
            catalog_info["schemas"].append(schema_info)
        
        catalogs.append(catalog_info)
    
    return catalogs
```

**Seção 3: Extração de Tabelas e Colunas**
```python
def extract_tables(catalog_name, schema_name):
    """Extrai tabelas e colunas de um schema específico"""
    tables = []
    
    for table in w.tables.list(catalog_name=catalog_name, schema_name=schema_name):
        table_info = {
            "name": table.name,
            "table_type": table.table_type,
            "data_source_format": table.data_source_format,
            "storage_location": table.storage_location,
            "comment": table.comment,
            "created_at": table.created_at,
            "updated_at": table.updated_at,
            "columns": []
        }
        
        # Extrair colunas da tabela
        table_details = w.tables.get(
            full_name=f"{catalog_name}.{schema_name}.{table.name}"
        )
        
        for column in table_details.columns:
            column_info = {
                "name": column.name,
                "type_name": column.type_name,
                "type_text": column.type_text,
                "nullable": column.nullable,
                "comment": column.comment,
                "position": column.position
            }
            table_info["columns"].append(column_info)
        
        tables.append(table_info)
    
    return tables
```

**Seção 4: Extração de Políticas de Segurança**
```python
def extract_security_policies():
    """Extrai políticas de segurança e mascaramento"""
    policies = {
        "row_filters": [],
        "column_masks": [],
        "grants": []
    }
    
    # Row-level security policies
    # (Implementação específica baseada na configuração do workspace)
    
    # Column masking policies
    # (Implementação específica baseada na configuração do workspace)
    
    # Grants e permissões
    # (Implementação específica baseada na configuração do workspace)
    
    return policies
```

**Seção 5: Extração de Lineage**
```python
def extract_lineage():
    """Extrai relacionamentos de lineage entre tabelas"""
    lineage_relationships = []
    
    # Usar Databricks Lineage API quando disponível
    # Implementação baseada em logs de query e metadados
    
    return lineage_relationships
```

**Seção 6: Extração de Métricas de Uso**
```python
def extract_usage_metrics():
    """Extrai métricas de uso das tabelas"""
    usage_metrics = []
    
    # Query logs para extrair padrões de uso
    # Métricas de performance e frequência de acesso
    
    return usage_metrics
```

**Seção 7: Mapeamento para Modelo ODCS v3.0.2**
```python
def map_to_gdp_core_model(unity_metadata):
    """Mapeia metadados do Unity Catalog para modelo TBR GDP Core"""
    
    # Mapeamento de entidades
    entities = []
    for catalog in unity_metadata["catalogs"]:
        for schema in catalog["schemas"]:
            for table in schema["tables"]:
                entity = {
                    "name": f"{catalog['name']}.{schema['name']}.{table['name']}",
                    "type": "table",
                    "domain": catalog["name"],
                    "subdomain": schema["name"],
                    "description": table.get("comment", ""),
                    "attributes": []
                }
                
                # Mapear colunas para atributos
                for column in table["columns"]:
                    attribute = {
                        "name": column["name"],
                        "data_type": column["type_name"],
                        "nullable": column["nullable"],
                        "description": column.get("comment", ""),
                        "position": column["position"]
                    }
                    entity["attributes"].append(attribute)
                
                entities.append(entity)
    
    return entities
```

**Seção 8: Sincronização com TBR GDP Core**
```python
def sync_to_gdp_core(mapped_entities):
    """Sincroniza entidades mapeadas com TBR GDP Core"""
    sync_results = {
        "entities_created": 0,
        "entities_updated": 0,
        "contracts_created": 0,
        "errors": []
    }
    
    for entity in mapped_entities:
        try:
            # Verificar se entidade já existe
            existing_entity = gdp_client.entities.get_by_name(entity["name"])
            
            if existing_entity:
                # Atualizar entidade existente
                updated_entity = gdp_client.entities.update(
                    existing_entity.id, 
                    entity
                )
                sync_results["entities_updated"] += 1
            else:
                # Criar nova entidade
                new_entity = gdp_client.entities.create(entity)
                sync_results["entities_created"] += 1
                
                # Criar contrato básico se não existir
                contract_data = {
                    "name": f"{entity['name']}_contract",
                    "entity_id": new_entity.id,
                    "schema": generate_schema_from_entity(entity),
                    "quality_rules": generate_basic_quality_rules(entity)
                }
                
                contract = gdp_client.contracts.create(contract_data)
                sync_results["contracts_created"] += 1
                
        except Exception as e:
            sync_results["errors"].append({
                "entity": entity["name"],
                "error": str(e)
            })
    
    return sync_results
```

**Seção 9: Monitoramento e Logging**
```python
import logging
from datetime import datetime

def setup_logging():
    """Configura logging estruturado para o extractor"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('unity_catalog_extractor.log'),
            logging.StreamHandler()
        ]
    )
    
    return logging.getLogger(__name__)

def log_extraction_metrics(logger, sync_results):
    """Log métricas de extração"""
    logger.info(f"Extraction completed at {datetime.now()}")
    logger.info(f"Entities created: {sync_results['entities_created']}")
    logger.info(f"Entities updated: {sync_results['entities_updated']}")
    logger.info(f"Contracts created: {sync_results['contracts_created']}")
    logger.info(f"Errors: {len(sync_results['errors'])}")
```

**Seção 10: Configuração de Agendamento**
```python
def schedule_extraction():
    """Configura execução agendada do extractor"""
    
    # Configuração para execução a cada 4 horas
    SYNC_FREQUENCY = "0 */4 * * *"  # Cron expression
    BATCH_SIZE = 1000
    MAX_RETRIES = 3
    
    # Implementação usando Databricks Jobs API
    job_config = {
        "name": "Unity Catalog to TBR GDP Core Sync",
        "new_cluster": {
            "spark_version": "13.3.x-scala2.12",
            "node_type_id": "i3.xlarge",
            "num_workers": 2
        },
        "notebook_task": {
            "notebook_path": "/Shared/unity_catalog_extractor",
            "base_parameters": {
                "batch_size": str(BATCH_SIZE),
                "max_retries": str(MAX_RETRIES)
            }
        },
        "schedule": {
            "quartz_cron_expression": SYNC_FREQUENCY,
            "timezone_id": "UTC"
        }
    }
    
    return job_config
```

**Seção 11: Tratamento de Erros e Recuperação**
```python
def handle_extraction_errors(error, context):
    """Trata erros durante extração com estratégias de recuperação"""
    
    error_strategies = {
        "connection_timeout": retry_with_backoff,
        "rate_limit_exceeded": wait_and_retry,
        "authentication_failed": refresh_token_and_retry,
        "data_validation_error": skip_and_log,
        "api_error": escalate_to_admin
    }
    
    error_type = classify_error(error)
    strategy = error_strategies.get(error_type, escalate_to_admin)
    
    return strategy(error, context)

def retry_with_backoff(error, context, max_retries=3):
    """Retry com backoff exponencial"""
    import time
    import random
    
    for attempt in range(max_retries):
        try:
            time.sleep((2 ** attempt) + random.uniform(0, 1))
            return context["retry_function"]()
        except Exception as e:
            if attempt == max_retries - 1:
                raise e
            continue
```

**Seção 12: Validação e Qualidade dos Dados**
```python
def validate_extracted_data(extracted_data):
    """Valida qualidade dos dados extraídos"""
    
    validation_results = {
        "total_entities": len(extracted_data),
        "valid_entities": 0,
        "invalid_entities": 0,
        "validation_errors": []
    }
    
    for entity in extracted_data:
        try:
            # Validações básicas
            assert entity.get("name"), "Entity name is required"
            assert entity.get("attributes"), "Entity must have attributes"
            assert len(entity["attributes"]) > 0, "Entity must have at least one attribute"
            
            # Validações de schema
            for attr in entity["attributes"]:
                assert attr.get("name"), "Attribute name is required"
                assert attr.get("data_type"), "Attribute data type is required"
            
            validation_results["valid_entities"] += 1
            
        except AssertionError as e:
            validation_results["invalid_entities"] += 1
            validation_results["validation_errors"].append({
                "entity": entity.get("name", "unknown"),
                "error": str(e)
            })
    
    return validation_results
```

### 2. Notebook Azure SPN Extractor

**Objetivo:** Extração de metadados de 5 serviços Azure principais usando Service Principal

#### Serviços Suportados

**1. Azure Data Factory**
- Pipelines e atividades
- Datasets e linked services
- Triggers e schedules
- Monitoring e logs

**2. Azure SQL Database**
- Schemas e tabelas
- Views e procedures
- Índices e constraints
- Estatísticas de uso

**3. Azure Storage**
- Containers e blobs
- File shares e queues
- Access policies
- Métricas de uso

**4. Azure Synapse Analytics**
- Workspaces e pools
- Pipelines e notebooks
- SQL pools e Spark pools
- Monitoring e performance

**5. Azure Key Vault**
- Secrets e keys
- Certificates
- Access policies
- Audit logs

#### Implementação do Extractor

**Configuração e Autenticação:**
```python
from azure.identity import ClientSecretCredential
from azure.mgmt.datafactory import DataFactoryManagementClient
from azure.mgmt.sql import SqlManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.mgmt.synapse import SynapseManagementClient
from azure.mgmt.keyvault import KeyVaultManagementClient

class AzureSPNExtractor:
    def __init__(self, tenant_id, client_id, client_secret, subscription_id):
        self.credential = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret
        )
        self.subscription_id = subscription_id
        
        # Inicializar clientes
        self.adf_client = DataFactoryManagementClient(
            self.credential, subscription_id
        )
        self.sql_client = SqlManagementClient(
            self.credential, subscription_id
        )
        self.storage_client = StorageManagementClient(
            self.credential, subscription_id
        )
        self.synapse_client = SynapseManagementClient(
            self.credential, subscription_id
        )
        self.keyvault_client = KeyVaultManagementClient(
            self.credential, subscription_id
        )
```

**Extração Azure Data Factory:**
```python
def extract_data_factory_metadata(self, resource_group, factory_name):
    """Extrai metadados completos do Azure Data Factory"""
    
    metadata = {
        "factory_info": {},
        "pipelines": [],
        "datasets": [],
        "linked_services": [],
        "triggers": []
    }
    
    # Informações da factory
    factory = self.adf_client.factories.get(resource_group, factory_name)
    metadata["factory_info"] = {
        "name": factory.name,
        "location": factory.location,
        "created_time": factory.create_time,
        "provisioning_state": factory.provisioning_state
    }
    
    # Pipelines
    for pipeline in self.adf_client.pipelines.list_by_factory(
        resource_group, factory_name
    ):
        pipeline_detail = self.adf_client.pipelines.get(
            resource_group, factory_name, pipeline.name
        )
        
        pipeline_info = {
            "name": pipeline.name,
            "description": pipeline_detail.description,
            "activities": [],
            "parameters": pipeline_detail.parameters or {}
        }
        
        # Atividades do pipeline
        if pipeline_detail.activities:
            for activity in pipeline_detail.activities:
                activity_info = {
                    "name": activity.name,
                    "type": activity.type,
                    "description": getattr(activity, 'description', ''),
                    "depends_on": [dep.activity for dep in getattr(activity, 'depends_on', [])]
                }
                pipeline_info["activities"].append(activity_info)
        
        metadata["pipelines"].append(pipeline_info)
    
    # Datasets
    for dataset in self.adf_client.datasets.list_by_factory(
        resource_group, factory_name
    ):
        dataset_detail = self.adf_client.datasets.get(
            resource_group, factory_name, dataset.name
        )
        
        dataset_info = {
            "name": dataset.name,
            "type": dataset_detail.type,
            "linked_service": dataset_detail.linked_service_name,
            "schema": getattr(dataset_detail, 'schema', []),
            "structure": getattr(dataset_detail, 'structure', [])
        }
        metadata["datasets"].append(dataset_info)
    
    return metadata
```

### 3. SDK Python Completo

**Arquitetura do SDK:**
```python
# tbr_gdpcore_client/__init__.py
from .client import GDPCoreClient, AsyncGDPCoreClient
from .exceptions import (
    GDPCoreException,
    AuthenticationError,
    ValidationError,
    RateLimitError
)
from .models import (
    Contract,
    Entity,
    QualityRule,
    ValidationResult
)

__version__ = "2.1.0"
__all__ = [
    "GDPCoreClient",
    "AsyncGDPCoreClient",
    "GDPCoreException",
    "AuthenticationError",
    "ValidationError",
    "RateLimitError",
    "Contract",
    "Entity",
    "QualityRule",
    "ValidationResult"
]
```

**Cliente Principal:**
```python
# tbr_gdpcore_client/client.py
import httpx
import asyncio
from typing import Optional, Dict, Any, List
from .auth import AuthManager
from .rate_limiter import RateLimiter
from .resources import (
    ContractsResource,
    EntitiesResource,
    QualityResource,
    AuditResource,
    SystemResource
)

class GDPCoreClient:
    """Cliente principal para TBR GDP Core API v2.1"""
    
    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: int = 30,
        retry_attempts: int = 3,
        rate_limit_per_minute: int = 1000
    ):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.retry_attempts = retry_attempts
        
        # Componentes
        self.auth = AuthManager(api_key)
        self.rate_limiter = RateLimiter(rate_limit_per_minute)
        
        # HTTP client
        self.http_client = httpx.Client(
            base_url=self.base_url,
            timeout=self.timeout,
            headers=self.auth.get_headers()
        )
        
        # Resources
        self.contracts = ContractsResource(self)
        self.entities = EntitiesResource(self)
        self.quality = QualityResource(self)
        self.audit = AuditResource(self)
        self.system = SystemResource(self)
    
    def _make_request(
        self,
        method: str,
        endpoint: str,
        **kwargs
    ) -> Dict[Any, Any]:
        """Faz requisição HTTP com retry e rate limiting"""
        
        # Rate limiting
        self.rate_limiter.wait_if_needed()
        
        url = f"{self.base_url}{endpoint}"
        
        for attempt in range(self.retry_attempts):
            try:
                response = self.http_client.request(
                    method=method,
                    url=url,
                    **kwargs
                )
                response.raise_for_status()
                return response.json()
                
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 429:  # Rate limit
                    wait_time = int(e.response.headers.get('Retry-After', 60))
                    time.sleep(wait_time)
                    continue
                elif e.response.status_code in [500, 502, 503, 504] and attempt < self.retry_attempts - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                    continue
                else:
                    raise
            except httpx.RequestError as e:
                if attempt < self.retry_attempts - 1:
                    time.sleep(2 ** attempt)
                    continue
                else:
                    raise
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.http_client.close()
```

**Resource Classes:**
```python
# tbr_gdpcore_client/resources/contracts.py
from typing import List, Optional, Dict, Any
from ..models import Contract

class ContractsResource:
    """Resource para operações com contratos"""
    
    def __init__(self, client):
        self.client = client
    
    def list(
        self,
        status: Optional[str] = None,
        domain: Optional[str] = None,
        limit: int = 100,
        offset: int = 0
    ) -> List[Contract]:
        """Lista contratos com filtros opcionais"""
        
        params = {
            "limit": limit,
            "offset": offset
        }
        
        if status:
            params["status"] = status
        if domain:
            params["domain"] = domain
        
        response = self.client._make_request(
            "GET",
            "/api/v1/contracts/",
            params=params
        )
        
        return [Contract.from_dict(item) for item in response["items"]]
    
    def get(self, contract_id: str) -> Contract:
        """Obtém contrato por ID"""
        
        response = self.client._make_request(
            "GET",
            f"/api/v1/contracts/{contract_id}"
        )
        
        return Contract.from_dict(response)
    
    def create(self, contract_data: Dict[str, Any]) -> Contract:
        """Cria novo contrato"""
        
        response = self.client._make_request(
            "POST",
            "/api/v1/contracts/",
            json=contract_data
        )
        
        return Contract.from_dict(response)
    
    def update(self, contract_id: str, contract_data: Dict[str, Any]) -> Contract:
        """Atualiza contrato existente"""
        
        response = self.client._make_request(
            "PUT",
            f"/api/v1/contracts/{contract_id}",
            json=contract_data
        )
        
        return Contract.from_dict(response)
    
    def activate_version(self, contract_id: str, version: str) -> Contract:
        """Ativa versão específica do contrato"""
        
        response = self.client._make_request(
            "POST",
            f"/api/v1/contracts/{contract_id}/versions/{version}/activate"
        )
        
        return Contract.from_dict(response)
```

### 4. CLI Tool Avançado

**Estrutura do CLI:**
```bash
tbr-gdp/
├── __init__.py
├── cli.py              # Entry point principal
├── commands/
│   ├── __init__.py
│   ├── configure.py    # Configuração
│   ├── contracts.py    # Operações com contratos
│   ├── entities.py     # Operações com entidades
│   ├── quality.py      # Operações de qualidade
│   ├── extract.py      # Extractors
│   └── metrics.py      # Monitoramento
├── config/
│   ├── __init__.py
│   └── settings.py     # Configurações
└── utils/
    ├── __init__.py
    ├── formatters.py   # Formatação de output
    └── validators.py   # Validações
```

**Implementação Principal:**
```python
# tbr_gdp/cli.py
import click
import json
from .config.settings import Config
from .commands import (
    configure,
    contracts,
    entities,
    quality,
    extract,
    metrics
)

@click.group()
@click.version_option(version="2.1.0")
@click.pass_context
def cli(ctx):
    """TBR GDP Core CLI Tool v2.1"""
    ctx.ensure_object(dict)
    ctx.obj['config'] = Config()

# Registrar comandos
cli.add_command(configure.configure)
cli.add_command(contracts.contracts)
cli.add_command(entities.entities)
cli.add_command(quality.quality)
cli.add_command(extract.extract)
cli.add_command(metrics.metrics)

if __name__ == "__main__":
    cli()
```

**Comando de Contratos:**
```python
# tbr_gdp/commands/contracts.py
import click
import json
from tbr_gdpcore_client import GDPCoreClient
from ..utils.formatters import format_table, format_json

@click.group()
def contracts():
    """Operações com contratos de dados"""
    pass

@contracts.command()
@click.option('--status', help='Filtrar por status')
@click.option('--domain', help='Filtrar por domínio')
@click.option('--format', type=click.Choice(['table', 'json']), default='table')
@click.pass_context
def list(ctx, status, domain, format):
    """Lista contratos de dados"""
    
    config = ctx.obj['config']
    client = GDPCoreClient(
        base_url=config.base_url,
        api_key=config.api_key
    )
    
    try:
        contracts = client.contracts.list(status=status, domain=domain)
        
        if format == 'json':
            click.echo(format_json([c.to_dict() for c in contracts]))
        else:
            headers = ['ID', 'Nome', 'Versão', 'Status', 'Domínio']
            rows = [
                [c.id, c.name, c.version, c.status, c.domain]
                for c in contracts
            ]
            click.echo(format_table(headers, rows))
            
    except Exception as e:
        click.echo(f"Erro: {e}", err=True)
        ctx.exit(1)

@contracts.command()
@click.argument('file', type=click.File('r'))
@click.pass_context
def create(ctx, file):
    """Cria contrato a partir de arquivo JSON"""
    
    config = ctx.obj['config']
    client = GDPCoreClient(
        base_url=config.base_url,
        api_key=config.api_key
    )
    
    try:
        contract_data = json.load(file)
        contract = client.contracts.create(contract_data)
        
        click.echo(f"Contrato criado: {contract.id}")
        click.echo(format_json(contract.to_dict()))
        
    except Exception as e:
        click.echo(f"Erro: {e}", err=True)
        ctx.exit(1)
```

### 5. Componentes React/Vue

**Estrutura do Pacote NPM:**
```
@tbr-gdpcore/react-components/
├── package.json
├── src/
│   ├── index.ts
│   ├── components/
│   │   ├── ContractViewer/
│   │   ├── QualityDashboard/
│   │   ├── EntityExplorer/
│   │   └── LineageGraph/
│   ├── hooks/
│   │   ├── useContracts.ts
│   │   ├── useEntities.ts
│   │   └── useQuality.ts
│   ├── services/
│   │   └── api.ts
│   └── types/
│       └── index.ts
└── dist/
```

**Componente ContractViewer:**
```tsx
// src/components/ContractViewer/ContractViewer.tsx
import React, { useState, useEffect } from 'react';
import { Contract } from '../../types';
import { useContracts } from '../../hooks/useContracts';

interface ContractViewerProps {
  contractId: string;
  onContractChange?: (contract: Contract) => void;
}

export const ContractViewer: React.FC<ContractViewerProps> = ({
  contractId,
  onContractChange
}) => {
  const { contract, loading, error, updateContract } = useContracts(contractId);
  const [isEditing, setIsEditing] = useState(false);

  if (loading) return <div>Carregando contrato...</div>;
  if (error) return <div>Erro: {error.message}</div>;
  if (!contract) return <div>Contrato não encontrado</div>;

  return (
    <div className="contract-viewer">
      <div className="contract-header">
        <h2>{contract.name}</h2>
        <span className={`status ${contract.status}`}>
          {contract.status}
        </span>
      </div>
      
      <div className="contract-details">
        <div className="section">
          <h3>Informações Básicas</h3>
          <p><strong>Versão:</strong> {contract.version}</p>
          <p><strong>Domínio:</strong> {contract.domain}</p>
          <p><strong>Descrição:</strong> {contract.description}</p>
        </div>
        
        <div className="section">
          <h3>Schema</h3>
          <pre className="schema-display">
            {JSON.stringify(contract.schema, null, 2)}
          </pre>
        </div>
        
        <div className="section">
          <h3>Regras de Qualidade</h3>
          <ul className="quality-rules">
            {contract.qualityRules.map(rule => (
              <li key={rule.id} className="quality-rule">
                <strong>{rule.name}:</strong> {rule.description}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};
```

**Hook useContracts:**
```tsx
// src/hooks/useContracts.ts
import { useState, useEffect } from 'react';
import { Contract } from '../types';
import { apiService } from '../services/api';

export const useContracts = (contractId?: string) => {
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [contract, setContract] = useState<Contract | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  const fetchContracts = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await apiService.contracts.list();
      setContracts(data);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  };

  const fetchContract = async (id: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const data = await apiService.contracts.get(id);
      setContract(data);
    } catch (err) {
      setError(err as Error);
    } finally {
      setLoading(false);
    }
  };

  const updateContract = async (id: string, updates: Partial<Contract>) => {
    try {
      const updated = await apiService.contracts.update(id, updates);
      setContract(updated);
      return updated;
    } catch (err) {
      setError(err as Error);
      throw err;
    }
  };

  useEffect(() => {
    if (contractId) {
      fetchContract(contractId);
    } else {
      fetchContracts();
    }
  }, [contractId]);

  return {
    contracts,
    contract,
    loading,
    error,
    fetchContracts,
    fetchContract,
    updateContract
  };
};
```

## 📊 Métricas e Monitoramento

### Métricas Prometheus Nativas

**Métricas de API:**
```python
# Métricas implementadas no TBR GDP Core v2.1
from prometheus_client import Counter, Histogram, Gauge

# Contadores de requisições
tbr_gdpcore_requests_total = Counter(
    'tbr_gdpcore_requests_total',
    'Total requests to TBR GDP Core API',
    ['method', 'endpoint', 'status_code']
)

# Histograma de latência
tbr_gdpcore_request_duration_seconds = Histogram(
    'tbr_gdpcore_request_duration_seconds',
    'Request duration in seconds',
    ['method', 'endpoint']
)

# Gauge de recursos ativos
tbr_gdpcore_active_contracts = Gauge(
    'tbr_gdpcore_active_contracts',
    'Number of active contracts'
)

tbr_gdpcore_total_entities = Gauge(
    'tbr_gdpcore_total_entities',
    'Total number of entities'
)

# Métricas de qualidade
tbr_gdpcore_quality_score = Gauge(
    'tbr_gdpcore_quality_score',
    'Average quality score',
    ['domain']
)

# Métricas de integração
tbr_gdpcore_sync_duration_seconds = Histogram(
    'tbr_gdpcore_sync_duration_seconds',
    'Sync operation duration',
    ['source', 'operation']
)

tbr_gdpcore_sync_errors_total = Counter(
    'tbr_gdpcore_sync_errors_total',
    'Total sync errors',
    ['source', 'error_type']
)
```

### Dashboard Grafana

**Configuração do Dashboard:**
```json
{
  "dashboard": {
    "id": null,
    "title": "TBR GDP Core v2.1 - Overview",
    "tags": ["tbr-gdpcore", "governance", "data"],
    "timezone": "browser",
    "panels": [
      {
        "id": 1,
        "title": "Request Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(tbr_gdpcore_requests_total[5m])",
            "legendFormat": "{{method}} {{endpoint}}"
          }
        ],
        "yAxes": [
          {
            "label": "Requests/sec"
          }
        ]
      },
      {
        "id": 2,
        "title": "Response Time",
        "type": "graph",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(tbr_gdpcore_request_duration_seconds_bucket[5m]))",
            "legendFormat": "95th percentile"
          },
          {
            "expr": "histogram_quantile(0.50, rate(tbr_gdpcore_request_duration_seconds_bucket[5m]))",
            "legendFormat": "50th percentile"
          }
        ]
      },
      {
        "id": 3,
        "title": "Active Resources",
        "type": "singlestat",
        "targets": [
          {
            "expr": "tbr_gdpcore_active_contracts",
            "legendFormat": "Contracts"
          }
        ]
      },
      {
        "id": 4,
        "title": "Quality Score by Domain",
        "type": "graph",
        "targets": [
          {
            "expr": "tbr_gdpcore_quality_score",
            "legendFormat": "{{domain}}"
          }
        ]
      }
    ]
  }
}
```

## 🎉 Conclusão

O **TBR GDP Core v2.1** estabelece um novo padrão para componentes de integração em governança de dados. Com notebooks especializados, SDKs robustos, CLI avançado e componentes web prontos, a plataforma oferece uma experiência de integração excepcional que reduz significativamente o tempo e esforço necessários para implementar governança de dados efetiva.

### Principais Conquistas

✅ **Notebooks Databricks Especializados** - Unity Catalog e Azure SPN extractors  
✅ **SDK Python Completo** - Com async, type hints e retry automático  
✅ **CLI Tool Avançado** - Para automação e operações em lote  
✅ **Componentes React/Vue** - Para interfaces web modernas  
✅ **65+ Endpoints REST** - Organizados e documentados  
✅ **Métricas Prometheus Nativas** - Para observabilidade completa  
✅ **Arquitetura Hexagonal** - Extensível e testável  

O ecossistema de componentes do **TBR GDP Core v2.1** capacita desenvolvedores e equipes técnicas a implementar governança de dados de forma rápida, eficiente e escalável, estabelecendo uma base sólida para a transformação digital orientada por dados.

**Desenvolvido por Carlos Morais**  
**TBR GDP Core - Data Governance API v2.1**  
**Janeiro 2025**

