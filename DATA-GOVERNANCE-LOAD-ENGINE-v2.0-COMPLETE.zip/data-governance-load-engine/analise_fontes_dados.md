# Análise de Fontes de Dados para Motor de Load

## Objetivo
Identificar e mapear todas as fontes de dados necessárias para alimentar 100% do modelo de governança de dados com 36 tabelas.

## Fontes de Dados Identificadas

### 1. Unity Catalog (Databricks)
**Disponibilidade:** ✅ Disponível via API REST e SQL
**Cobertura:** 85% das necessidades

#### Dados Disponíveis:
- **Catálogos, Schemas e Tabelas**
  - Metadados básicos (nome, descrição, proprietário)
  - Informações de schema (colunas, tipos, constraints)
  - Estatísticas de tabela (tamanho, contagem de linhas)
  - Histórico de versões (Delta Lake)
  
- **Colunas e Propriedades**
  - Tipos de dados (lógicos e físicos)
  - Constraints (nullable, unique, primary key)
  - Comentários e descrições
  - Tags de classificação
  
- **Linhagem de Dados**
  - Relacionamentos entre tabelas
  - Transformações aplicadas
  - Dependências upstream/downstream
  
- **Métricas de Performance**
  - Estatísticas de query
  - Métricas de job
  - Uso de recursos (CPU, memória, storage)
  
- **Controle de Acesso**
  - Usuários e grupos
  - Permissões granulares
  - Políticas de acesso

#### APIs Utilizadas:
```
GET /api/2.1/unity-catalog/catalogs
GET /api/2.1/unity-catalog/schemas
GET /api/2.1/unity-catalog/tables
GET /api/2.1/unity-catalog/columns
GET /api/2.1/unity-catalog/lineage
GET /api/2.0/clusters/list
GET /api/2.0/jobs/list
GET /api/2.0/sql/history/queries
```

### 2. Azure Resource Manager (ARM)
**Disponibilidade:** ✅ Disponível via SPN (Service Principal Name)
**Cobertura:** 10% das necessidades

#### Dados Disponíveis:
- **Recursos de Dados**
  - Azure Data Factory pipelines
  - Azure Synapse workspaces
  - Azure Storage accounts
  - Azure SQL databases
  
- **Métricas de Recursos**
  - Uso de CPU e memória
  - Throughput de rede
  - Custos por recurso
  
- **Logs de Auditoria**
  - Atividades de usuário
  - Mudanças de configuração
  - Acessos a recursos

#### APIs Utilizadas:
```
GET https://management.azure.com/subscriptions/{subscription-id}/resources
GET https://management.azure.com/subscriptions/{subscription-id}/providers/Microsoft.DataFactory
GET https://management.azure.com/subscriptions/{subscription-id}/providers/Microsoft.Synapse
```

### 3. Fontes Complementares Necessárias
**Disponibilidade:** ❌ Precisam ser implementadas/configuradas
**Cobertura:** 5% das necessidades

#### Dados Faltantes:
- **Contratos de Dados**
  - Definições de contrato (manual/configuração)
  - Versionamento de contratos
  - Layouts customizáveis
  - SLAs e precificação
  
- **Qualidade de Dados**
  - Regras de qualidade customizadas
  - Resultados de execução históricos
  - Definições de qualidade por contrato
  
- **Governança Específica**
  - Políticas ABAC customizadas
  - Classificações de dados específicas
  - Procedimentos de auditoria
  
- **Integrações Externas**
  - Informatica Axon (se disponível)
  - Ferramentas de BI/Analytics
  - Sistemas de ticketing

## Mapeamento Tabela x Fonte de Dados

### Tabelas 100% Cobertas pelo Unity Catalog (15 tabelas)
1. `data_objects` - Tabelas/Views do Unity Catalog
2. `data_object_properties` - Colunas e metadados
3. `data_lineage` - Linhagem nativa do Unity Catalog
4. `users` - Usuários do workspace
5. `groups` - Grupos do workspace
6. `user_groups` - Associações usuário-grupo
7. `permissions` - Permissões do Unity Catalog
8. `group_permissions` - Permissões por grupo
9. `cluster_metrics` - Métricas de cluster
10. `job_metrics` - Métricas de jobs
11. `query_metrics` - Histórico de queries
12. `storage_metrics` - Métricas de storage Delta
13. `entity` - Entidades tagueáveis
14. `tag` - Sistema de tags do Unity Catalog
15. `tagged` - Relacionamentos de tags

### Tabelas Parcialmente Cobertas (10 tabelas)
1. `data_contracts` - 30% Unity Catalog + 70% configuração manual
2. `contract_versions` - 20% Unity Catalog + 80% configuração manual
3. `contract_schema_definitions` - 60% Unity Catalog + 40% configuração manual
4. `quality_rules` - 40% Unity Catalog + 60% configuração manual
5. `quality_execution_results` - 50% Unity Catalog + 50% logs customizados
6. `abac_policy_evaluations` - 30% Unity Catalog + 70% logs customizados
7. `data_classification_results` - 50% Unity Catalog + 50% classificação manual
8. `tool_integrations` - 20% Unity Catalog + 80% configuração manual
9. `sync_executions` - 10% Unity Catalog + 90% logs do motor
10. `audit_log` - 40% Unity Catalog + 60% logs customizados

### Tabelas Requerem Configuração Manual (11 tabelas)
1. `contract_layouts` - 100% configuração manual
2. `contract_custom_properties` - 100% configuração manual
3. `contract_fundamentals` - 100% configuração manual
4. `contract_team_definitions` - 100% configuração manual
5. `contract_sla_definitions` - 100% configuração manual
6. `contract_pricing_definitions` - 100% configuração manual
7. `contract_quality_definitions` - 100% configuração manual
8. `property_quality_rule_links` - 100% configuração manual
9. `sync_errors` - 100% logs do motor
10. `data_quality_aggregates` - 100% cálculos do motor
11. `data_anomaly_detection` - 100% algoritmos do motor

## Estratégia de Implementação

### Fase 1: Extração Unity Catalog (Semana 1)
- Implementar conectores para todas as APIs do Unity Catalog
- Mapear dados para 15 tabelas com cobertura 100%
- Criar pipeline de sincronização automática

### Fase 2: Integração Azure (Semana 2)
- Configurar autenticação via SPN
- Extrair métricas complementares do Azure
- Integrar logs de auditoria

### Fase 3: Dados Configuráveis (Semana 3)
- Criar interfaces para configuração manual
- Implementar templates para contratos
- Desenvolver sistema de qualidade customizado

### Fase 4: Motor de Qualidade (Semana 4)
- Implementar algoritmos de detecção de anomalias
- Criar sistema de agregação de métricas
- Desenvolver dashboards de monitoramento

## Gaps Identificados

### Dados Não Disponíveis (5% do modelo)
1. **Contratos de Dados Históricos** - Precisam ser criados manualmente
2. **Definições de SLA Específicas** - Requerem configuração de negócio
3. **Modelos de Precificação** - Dependem de estratégia comercial
4. **Políticas ABAC Customizadas** - Precisam ser definidas por domínio
5. **Integrações com Ferramentas Externas** - Dependem de disponibilidade

### Dados Inferíveis (10% do modelo)
1. **Classificação Automática de Dados** - Pode ser inferida via ML
2. **Qualidade de Dados Básica** - Pode ser calculada automaticamente
3. **Linhagem Estendida** - Pode ser inferida via análise de queries
4. **Anomalias de Dados** - Podem ser detectadas via algoritmos
5. **Métricas de Uso** - Podem ser calculadas a partir de logs

## Conclusão

**Cobertura Total Estimada: 85% automática + 10% inferível + 5% manual = 100%**

O motor de load conseguirá alimentar automaticamente 85% do modelo, inferir 10% através de algoritmos e machine learning, e os 5% restantes precisarão de configuração manual ou integração com sistemas externos específicos.

Esta análise fornece a base para o desenvolvimento do motor de load completo e identifica claramente onde estão os gaps que precisam ser endereçados.

