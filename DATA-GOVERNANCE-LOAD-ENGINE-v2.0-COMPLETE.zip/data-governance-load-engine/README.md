# 🚀 Data Governance Load Engine

## 📋 Visão Geral

O **Data Governance Load Engine** é um motor de carga de dados especializado para alimentar modelos de governança de dados, desenvolvido para integrar-se nativamente com **Unity Catalog (Databricks)** e **Azure** via Service Principal Name (SPN).

### 🎯 Objetivos

- **Automatizar** a coleta de metadados de governança
- **Integrar** múltiplas fontes de dados (Unity Catalog, Azure, etc.)
- **Transformar** dados brutos em modelo estruturado de governança
- **Detectar** anomalias e classificar dados automaticamente
- **Monitorar** qualidade e linhagem de dados continuamente

### 📊 Cobertura Atual

| Categoria | Cobertura | Status |
|-----------|-----------|--------|
| **Unity Catalog** | 41.7% (15/36 tabelas) | ✅ Implementado |
| **Azure Integration** | 16.7% (6/36 tabelas) | ✅ Implementado |
| **Inferência Automática** | 22.2% (8/36 tabelas) | ⚠️ Parcial |
| **Configuração Manual** | 19.4% (7/36 tabelas) | ❌ Pendente |
| **Total** | **80.6%** | 🎯 **Meta: 100%** |

## 🏗️ Arquitetura

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Data Sources  │    │   Load Engine    │    │   Target Model  │
├─────────────────┤    ├──────────────────┤    ├─────────────────┤
│ Unity Catalog   │───▶│ Connectors       │───▶│ 36 Tables       │
│ Azure Resources │    │ Transformers     │    │ Governance      │
│ Databricks APIs │    │ Loaders          │    │ Model           │
│ Custom Sources  │    │ ML/AI Features   │    │ PostgreSQL      │
└─────────────────┘    └──────────────────┘    └─────────────────┘
```

## 🚀 Quick Start

### 1. Instalação

```bash
git clone <repository-url>
cd data-governance-load-engine
pip install -r requirements.txt
```

### 2. Configuração

```bash
cp .env.example .env
# Edite .env com suas credenciais
```

### 3. Execução

```python
from src.load_engine import get_load_engine

# Inicializar motor
engine = await get_load_engine()
await engine.initialize()

# Sincronizar dados
result = await engine.sync_all()
print(f"Processados: {result['total_records']} registros")
```

## 📁 Estrutura do Projeto

```
data-governance-load-engine/
├── src/                          # Código fonte
│   ├── connectors/              # Conectores de dados
│   │   ├── unity_catalog.py     # Unity Catalog
│   │   ├── azure_connector.py   # Azure SPN
│   │   └── base_connector.py    # Classe base
│   ├── transformers/            # Transformação de dados
│   ├── loaders/                 # Carga no banco
│   ├── load_engine.py          # Motor principal
│   └── config.py               # Configurações
├── docs/                        # Documentação
│   ├── README.md               # Documentação principal
│   ├── DATABRICKS_DEPLOY_GUIDE.md  # Guia de deploy
│   └── ANALISE_GAPS_DADOS.md   # Análise de gaps
├── notebooks/                   # Notebooks Jupyter
│   └── manual_execution.ipynb  # Execução manual
├── config/                      # Arquivos de configuração
├── tests/                       # Testes
└── scripts/                     # Scripts utilitários
```

## 🔌 Conectores Disponíveis

### Unity Catalog Connector
- **Catálogos, Schemas, Tabelas**: Metadados completos
- **Colunas e Propriedades**: Tipos, constraints, comentários
- **Usuários e Grupos**: SCIM API
- **Permissões**: Grants API
- **Métricas**: Clusters, Jobs, Queries
- **Linhagem**: Relacionamentos entre objetos

### Azure Connector
- **Resource Groups**: Organização de recursos
- **Data Factory**: Pipelines e atividades
- **Synapse**: Workspaces e pools
- **Storage**: Accounts e métricas
- **SQL Servers**: Databases e performance
- **Monitoring**: Métricas de recursos

## 🤖 Funcionalidades Avançadas

### Inferência de Qualidade
- **Completude**: % de valores não nulos
- **Unicidade**: % de valores únicos
- **Validade**: Conformidade com padrões
- **Consistência**: Coerência entre campos
- **Pontualidade**: Atualização dentro dos SLAs

### Detecção de Anomalias
- **Volume**: Mudanças inesperadas no volume
- **Qualidade**: Degradação súbita
- **Estatísticas**: Valores fora dos padrões
- **Schema**: Mudanças não documentadas

### Classificação Automática
- **PII**: Detecção de dados pessoais
- **Sensibilidade**: Público, interno, confidencial, restrito
- **Conformidade**: LGPD, GDPR, HIPAA, PCI-DSS
- **Negócio**: Domínios e sub-domínios

## 📊 Modelo de Dados Suportado

### Contratos de Dados (8 tabelas)
- `data_contracts`, `contract_versions`, `contract_layouts`
- `contract_custom_properties`, `contract_fundamentals`
- `contract_team_definitions`, `contract_sla_definitions`
- `contract_pricing_definitions`

### Objetos e Qualidade (8 tabelas)
- `data_objects`, `data_object_properties`, `quality_rules`
- `property_quality_rule_links`, `quality_execution_results`
- `data_quality_aggregates`, `data_anomaly_detection`
- `data_classification_results`

### Métricas e Monitoramento (6 tabelas)
- `cluster_metrics`, `job_metrics`, `query_metrics`
- `storage_metrics`, `audit_log`, `sync_executions`

### Usuários e Permissões (6 tabelas)
- `users`, `groups`, `user_groups`
- `permissions`, `group_permissions`, `abac_policy_evaluations`

### Linhagem e Integração (8 tabelas)
- `data_lineage`, `entity`, `tag`, `tagged`
- `tool_integrations`, `sync_errors`
- `contract_schema_definitions`, `contract_quality_definitions`

## 🎯 Roadmap para 100% de Cobertura

### Fase 1: Integrações Adicionais (0-30 dias)
- [ ] Azure Purview Connector
- [ ] Informatica Axon Connector
- [ ] dbt Connector
- [ ] APIs de configuração bulk

### Fase 2: Configuração Assistida (30-60 dias)
- [ ] Dashboard de configuração
- [ ] Templates pré-configurados
- [ ] Integração com ferramentas de negócio
- [ ] Workflows de aprovação

### Fase 3: Automação Completa (60-90 dias)
- [ ] Machine Learning avançado
- [ ] NLP para extração de regras
- [ ] Workflows inteligentes
- [ ] Otimização contínua

## 🚀 Deploy no Databricks

### Databricks Free Edition
1. Acesse: https://login.databricks.com/?intent=SIGN_UP&provider=DB_FREE_TIER
2. Siga o [Guia de Deploy](docs/DATABRICKS_DEPLOY_GUIDE.md)
3. Execute o [Notebook Manual](notebooks/manual_execution.ipynb)

### Configuração Mínima
```env
DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
DATABRICKS_TOKEN=your_token
UNITY_CATALOG_NAME=main
DATABASE_URL=postgresql://user:pass@host:5432/db
```

## 📈 Métricas e Monitoramento

### APIs de Status
- `GET /health` - Status de saúde
- `GET /status` - Status detalhado
- `GET /metrics` - Métricas operacionais
- `POST /sync/all` - Sincronização completa

### Dashboard
```python
# Executar API
uvicorn src.api:app --host 0.0.0.0 --port 8000

# Acessar documentação
http://localhost:8000/docs
```

## 🧪 Testes

```bash
# Todos os testes
pytest

# Testes específicos
pytest tests/test_connectors.py

# Com cobertura
pytest --cov=src tests/
```

## 📚 Documentação

- [**Documentação Principal**](docs/README.md) - Guia completo
- [**Guia de Deploy Databricks**](docs/DATABRICKS_DEPLOY_GUIDE.md) - Deploy passo a passo
- [**Análise de Gaps**](docs/ANALISE_GAPS_DADOS.md) - O que falta para 100%
- [**Notebook Manual**](notebooks/manual_execution.ipynb) - Execução interativa

## 🤝 Contribuindo

1. Fork o repositório
2. Crie uma branch para sua feature
3. Implemente os testes
4. Execute a suíte de testes
5. Submeta um Pull Request

## 📄 Licença

Este projeto está licenciado sob a MIT License - veja o arquivo [LICENSE](LICENSE) para detalhes.

## 🆘 Suporte

- **Issues**: GitHub Issues
- **Email**: support@datagovernance.com
- **Documentação**: [docs/](docs/)

## 🏆 Status do Projeto

| Componente | Status | Cobertura |
|------------|--------|-----------|
| Unity Catalog Connector | ✅ Completo | 100% |
| Azure Connector | ✅ Completo | 100% |
| Data Transformer | ✅ Completo | 90% |
| Database Loader | ✅ Completo | 95% |
| Quality Inference | ⚠️ Básico | 70% |
| Anomaly Detection | ⚠️ Básico | 60% |
| Auto Classification | ⚠️ Básico | 75% |
| API REST | ✅ Completo | 100% |
| Documentação | ✅ Completo | 100% |
| Testes | ⚠️ Parcial | 80% |

---

**Desenvolvido com ❤️ para democratizar a governança de dados**

