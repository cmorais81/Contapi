"""
Transformador de dados para normalização e mapeamento
"""

import logging
from typing import Any, Dict, List, Optional
from datetime import datetime
import uuid
import re
import json

logger = logging.getLogger(__name__)


class DataTransformer:
    """Transformador de dados para o modelo de governança"""
    
    def __init__(self):
        self.initialized = False
        self.transformation_rules = {}
        self.quality_rules = {}
        self.classification_patterns = {}
        
    async def initialize(self):
        """Inicializa o transformador"""
        try:
            await self._load_transformation_rules()
            await self._load_quality_rules()
            await self._load_classification_patterns()
            
            self.initialized = True
            logger.info("DataTransformer inicializado com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao inicializar DataTransformer: {e}")
            raise
    
    async def _load_transformation_rules(self):
        """Carrega regras de transformação"""
        self.transformation_rules = {
            "unity_catalog": {
                "catalogs": self._transform_unity_catalogs,
                "schemas": self._transform_unity_schemas,
                "tables": self._transform_unity_tables,
                "columns": self._transform_unity_columns,
                "users": self._transform_unity_users,
                "groups": self._transform_unity_groups,
                "cluster_metrics": self._transform_cluster_metrics,
                "job_metrics": self._transform_job_metrics,
                "query_metrics": self._transform_query_metrics
            },
            "azure": {
                "resource_groups": self._transform_azure_resource_groups,
                "data_factories": self._transform_azure_data_factories,
                "synapse_workspaces": self._transform_azure_synapse,
                "storage_accounts": self._transform_azure_storage,
                "sql_servers": self._transform_azure_sql,
                "resource_metrics": self._transform_azure_metrics
            }
        }
    
    async def _load_quality_rules(self):
        """Carrega regras de qualidade"""
        self.quality_rules = {
            "completeness": self._calculate_completeness,
            "uniqueness": self._calculate_uniqueness,
            "validity": self._calculate_validity,
            "consistency": self._calculate_consistency,
            "timeliness": self._calculate_timeliness
        }
    
    async def _load_classification_patterns(self):
        """Carrega padrões de classificação"""
        self.classification_patterns = {
            "pii_patterns": {
                "cpf": r"\d{3}\.\d{3}\.\d{3}-\d{2}",
                "cnpj": r"\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}",
                "email": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
                "phone": r"\(\d{2}\)\s\d{4,5}-\d{4}",
                "credit_card": r"\d{4}\s\d{4}\s\d{4}\s\d{4}"
            },
            "sensitivity_keywords": {
                "confidential": ["password", "secret", "token", "key", "credential"],
                "personal": ["name", "email", "phone", "address", "cpf", "cnpj"],
                "financial": ["salary", "revenue", "cost", "price", "payment"],
                "health": ["medical", "health", "diagnosis", "treatment"]
            }
        }
    
    async def transform(self, connector_name: str, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Transforma dados brutos para o modelo de governança"""
        if not self.initialized:
            await self.initialize()
        
        try:
            logger.info(f"Transformando dados de {connector_name}...")
            
            transformed_data = {
                "connector": connector_name,
                "timestamp": datetime.now(),
                "records": [],
                "metadata": {
                    "total_input_records": raw_data.get("total_records", 0),
                    "transformation_rules_applied": [],
                    "errors": []
                }
            }
            
            # Obtém dados específicos do conector
            connector_data = raw_data.get("data", {})
            
            # Aplica transformações específicas do conector
            if connector_name in self.transformation_rules:
                rules = self.transformation_rules[connector_name]
                
                for data_type, data_items in connector_data.items():
                    if data_type in rules:
                        try:
                            transformation_func = rules[data_type]
                            transformed_items = await transformation_func(data_items)
                            
                            transformed_data["records"].extend(transformed_items)
                            transformed_data["metadata"]["transformation_rules_applied"].append(data_type)
                            
                            logger.info(f"Transformados {len(transformed_items)} registros de {data_type}")
                            
                        except Exception as e:
                            error_msg = f"Erro ao transformar {data_type}: {e}"
                            transformed_data["metadata"]["errors"].append(error_msg)
                            logger.error(error_msg)
            
            transformed_data["metadata"]["total_output_records"] = len(transformed_data["records"])
            
            logger.info(f"Transformação {connector_name} concluída: {len(transformed_data['records'])} registros")
            
            return transformed_data
            
        except Exception as e:
            logger.error(f"Erro na transformação {connector_name}: {e}")
            return {
                "connector": connector_name,
                "timestamp": datetime.now(),
                "records": [],
                "metadata": {"errors": [str(e)]}
            }
    
    # Transformações Unity Catalog
    
    async def _transform_unity_catalogs(self, catalogs: List[Dict]) -> List[Dict]:
        """Transforma catálogos Unity Catalog"""
        transformed = []
        
        for catalog in catalogs:
            record = {
                "table": "data_objects",
                "data": {
                    "data_object_id": str(uuid.uuid4()),
                    "object_name": catalog.get("name"),
                    "object_type": "catalog",
                    "object_description": catalog.get("comment"),
                    "unity_catalog_table_id": catalog.get("id"),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    async def _transform_unity_schemas(self, schemas: List[Dict]) -> List[Dict]:
        """Transforma schemas Unity Catalog"""
        transformed = []
        
        for schema in schemas:
            record = {
                "table": "data_objects",
                "data": {
                    "data_object_id": str(uuid.uuid4()),
                    "object_name": f"{schema.get('catalog_name')}.{schema.get('name')}",
                    "object_type": "schema",
                    "object_description": schema.get("comment"),
                    "unity_catalog_table_id": schema.get("id"),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    async def _transform_unity_tables(self, tables: List[Dict]) -> List[Dict]:
        """Transforma tabelas Unity Catalog"""
        transformed = []
        
        for table in tables:
            # Tabela principal
            table_record = {
                "table": "data_objects",
                "data": {
                    "data_object_id": str(uuid.uuid4()),
                    "object_name": table.get("name"),
                    "object_type": table.get("table_type", "table").lower(),
                    "object_description": table.get("comment"),
                    "unity_catalog_table_id": table.get("table_id"),
                    "delta_table_path": table.get("storage_location"),
                    "estimated_size_gb": table.get("size_in_bytes", 0) / (1024**3) if table.get("size_in_bytes") else None,
                    "row_count_estimate": table.get("row_count"),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(table_record)
            
            # Linhagem se disponível
            if table.get("lineage"):
                lineage_record = {
                    "table": "data_lineage",
                    "data": {
                        "lineage_id": str(uuid.uuid4()),
                        "source_object_name": table.get("name"),
                        "target_object_name": table.get("name"),
                        "transformation_logic": json.dumps(table["lineage"]),
                        "lineage_type": "table",
                        "data_criacao": datetime.now(),
                        "data_atualizacao": datetime.now()
                    }
                }
                transformed.append(lineage_record)
        
        return transformed
    
    async def _transform_unity_columns(self, columns: List[Dict]) -> List[Dict]:
        """Transforma colunas Unity Catalog"""
        transformed = []
        
        for column in columns:
            # Propriedade da coluna
            property_record = {
                "table": "data_object_properties",
                "data": {
                    "property_id": str(uuid.uuid4()),
                    "property_name": column.get("name"),
                    "ordinal_position": column.get("position"),
                    "property_description": column.get("comment"),
                    "logical_type": column.get("type_name"),
                    "physical_type": column.get("type_text"),
                    "is_nullable": not column.get("nullable", True),
                    "unity_catalog_column_id": column.get("column_id"),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            
            # Classificação automática
            classification = await self._classify_column(column)
            if classification:
                property_record["data"].update(classification)
            
            transformed.append(property_record)
        
        return transformed
    
    async def _transform_unity_users(self, users: List[Dict]) -> List[Dict]:
        """Transforma usuários Unity Catalog"""
        transformed = []
        
        for user in users:
            record = {
                "table": "users",
                "data": {
                    "user_id": str(uuid.uuid4()),
                    "username": user.get("userName"),
                    "email": user.get("emails", [{}])[0].get("value") if user.get("emails") else None,
                    "display_name": user.get("displayName"),
                    "is_active": user.get("active", True),
                    "unity_catalog_user_id": user.get("id"),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    async def _transform_unity_groups(self, groups: List[Dict]) -> List[Dict]:
        """Transforma grupos Unity Catalog"""
        transformed = []
        
        for group in groups:
            record = {
                "table": "groups",
                "data": {
                    "group_id": str(uuid.uuid4()),
                    "group_name": group.get("displayName"),
                    "group_description": group.get("description"),
                    "unity_catalog_group_id": group.get("id"),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    async def _transform_cluster_metrics(self, metrics: List[Dict]) -> List[Dict]:
        """Transforma métricas de cluster"""
        transformed = []
        
        for metric in metrics:
            record = {
                "table": "cluster_metrics",
                "data": {
                    "metric_id": str(uuid.uuid4()),
                    "cluster_id": metric.get("cluster_id"),
                    "cluster_name": metric.get("cluster_name"),
                    "cluster_state": metric.get("state"),
                    "node_type": metric.get("node_type_id"),
                    "num_workers": metric.get("num_workers", 0),
                    "spark_version": metric.get("spark_version"),
                    "autotermination_minutes": metric.get("autotermination_minutes"),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    async def _transform_job_metrics(self, metrics: List[Dict]) -> List[Dict]:
        """Transforma métricas de job"""
        transformed = []
        
        for metric in metrics:
            record = {
                "table": "job_metrics",
                "data": {
                    "metric_id": str(uuid.uuid4()),
                    "job_id": str(metric.get("job_id")),
                    "job_name": metric.get("job_name"),
                    "job_type": metric.get("job_type"),
                    "created_time": metric.get("created_time"),
                    "creator_user_name": metric.get("creator_user_name"),
                    "recent_runs_count": len(metric.get("recent_runs", [])),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    async def _transform_query_metrics(self, metrics: List[Dict]) -> List[Dict]:
        """Transforma métricas de query"""
        transformed = []
        
        for metric in metrics:
            record = {
                "table": "query_metrics",
                "data": {
                    "metric_id": str(uuid.uuid4()),
                    "query_id": metric.get("query_id"),
                    "query_text": metric.get("query_text", "")[:1000],  # Limita tamanho
                    "user_name": metric.get("user_name"),
                    "execution_time_ms": metric.get("execution_time_ms"),
                    "rows_produced": metric.get("rows_produced"),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    # Transformações Azure
    
    async def _transform_azure_resource_groups(self, resource_groups: List[Dict]) -> List[Dict]:
        """Transforma resource groups Azure"""
        transformed = []
        
        for rg in resource_groups:
            record = {
                "table": "tool_integrations",
                "data": {
                    "integration_id": str(uuid.uuid4()),
                    "tool_name": "Azure Resource Manager",
                    "tool_type": "cloud_platform",
                    "connection_string": f"ResourceGroup:{rg.get('name')}",
                    "integration_status": "active",
                    "configuration": json.dumps({
                        "resource_group": rg.get("name"),
                        "location": rg.get("location"),
                        "tags": rg.get("tags", {})
                    }),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    async def _transform_azure_data_factories(self, data_factories: List[Dict]) -> List[Dict]:
        """Transforma Data Factories Azure"""
        transformed = []
        
        for df in data_factories:
            record = {
                "table": "tool_integrations",
                "data": {
                    "integration_id": str(uuid.uuid4()),
                    "tool_name": "Azure Data Factory",
                    "tool_type": "etl_platform",
                    "connection_string": f"DataFactory:{df.get('name')}",
                    "integration_status": "active",
                    "configuration": json.dumps({
                        "data_factory_name": df.get("name"),
                        "location": df.get("location"),
                        "pipelines_count": df.get("pipelines_count", 0),
                        "properties": df.get("properties", {})
                    }),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    async def _transform_azure_synapse(self, workspaces: List[Dict]) -> List[Dict]:
        """Transforma Synapse Workspaces"""
        transformed = []
        
        for workspace in workspaces:
            record = {
                "table": "tool_integrations",
                "data": {
                    "integration_id": str(uuid.uuid4()),
                    "tool_name": "Azure Synapse Analytics",
                    "tool_type": "analytics_platform",
                    "connection_string": f"Synapse:{workspace.get('name')}",
                    "integration_status": "active",
                    "configuration": json.dumps({
                        "workspace_name": workspace.get("name"),
                        "location": workspace.get("location"),
                        "properties": workspace.get("properties", {})
                    }),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    async def _transform_azure_storage(self, storage_accounts: List[Dict]) -> List[Dict]:
        """Transforma Storage Accounts"""
        transformed = []
        
        for storage in storage_accounts:
            record = {
                "table": "storage_metrics",
                "data": {
                    "metric_id": str(uuid.uuid4()),
                    "storage_account_name": storage.get("name"),
                    "storage_type": storage.get("kind"),
                    "location": storage.get("location"),
                    "access_tier": storage.get("properties", {}).get("access_tier"),
                    "provisioning_state": storage.get("properties", {}).get("provisioning_state"),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    async def _transform_azure_sql(self, sql_servers: List[Dict]) -> List[Dict]:
        """Transforma SQL Servers"""
        transformed = []
        
        for server in sql_servers:
            record = {
                "table": "tool_integrations",
                "data": {
                    "integration_id": str(uuid.uuid4()),
                    "tool_name": "Azure SQL Server",
                    "tool_type": "database_platform",
                    "connection_string": f"SQLServer:{server.get('name')}",
                    "integration_status": "active",
                    "configuration": json.dumps({
                        "server_name": server.get("name"),
                        "location": server.get("location"),
                        "databases_count": server.get("databases_count", 0),
                        "properties": server.get("properties", {})
                    }),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    async def _transform_azure_metrics(self, metrics: List[Dict]) -> List[Dict]:
        """Transforma métricas de recursos Azure"""
        transformed = []
        
        for metric in metrics:
            record = {
                "table": "storage_metrics",
                "data": {
                    "metric_id": str(uuid.uuid4()),
                    "resource_name": metric.get("resource_name"),
                    "resource_type": metric.get("resource_type"),
                    "metrics_data": json.dumps(metric.get("metrics", [])),
                    "data_criacao": datetime.now(),
                    "data_atualizacao": datetime.now()
                }
            }
            transformed.append(record)
        
        return transformed
    
    # Funcionalidades avançadas
    
    async def _classify_column(self, column: Dict) -> Dict[str, Any]:
        """Classifica automaticamente uma coluna"""
        classification = {}
        
        column_name = column.get("name", "").lower()
        column_type = column.get("type_name", "").lower()
        column_comment = column.get("comment", "").lower()
        
        # Detecta PII
        pii_detected = False
        for pii_type, pattern in self.classification_patterns["pii_patterns"].items():
            if pii_type in column_name or pii_type in column_comment:
                pii_detected = True
                break
        
        classification["is_pii"] = pii_detected
        
        # Detecta sensibilidade
        sensitivity = "public"
        for level, keywords in self.classification_patterns["sensitivity_keywords"].items():
            if any(keyword in column_name or keyword in column_comment for keyword in keywords):
                if level == "personal":
                    sensitivity = "internal"
                elif level == "financial":
                    sensitivity = "confidential"
                elif level == "health":
                    sensitivity = "restricted"
        
        classification["classification_tag"] = sensitivity
        
        # Detecta relevância regulatória
        classification["is_lgpd_relevant"] = pii_detected or "pessoal" in column_comment
        classification["is_gdpr_relevant"] = pii_detected or "personal" in column_comment
        classification["is_hipaa_relevant"] = "health" in column_name or "medical" in column_comment
        classification["is_pci_relevant"] = "card" in column_name or "payment" in column_comment
        
        return classification
    
    async def infer_quality_metrics(self) -> Dict[str, Any]:
        """Infere métricas de qualidade dos dados"""
        # Implementação simulada - seria conectada ao banco
        return {
            "records": [
                {
                    "table": "data_quality_aggregates",
                    "data": {
                        "aggregate_id": str(uuid.uuid4()),
                        "object_name": "sample_table",
                        "quality_dimension": "completeness",
                        "quality_score": 95.5,
                        "measurement_date": datetime.now(),
                        "data_criacao": datetime.now(),
                        "data_atualizacao": datetime.now()
                    }
                }
            ]
        }
    
    async def detect_anomalies(self) -> Dict[str, Any]:
        """Detecta anomalias nos dados"""
        # Implementação simulada - seria conectada a algoritmos ML
        return {
            "records": [
                {
                    "table": "data_anomaly_detection",
                    "data": {
                        "detection_id": str(uuid.uuid4()),
                        "object_name": "sample_table",
                        "anomaly_type": "volume",
                        "anomaly_score": 0.85,
                        "detection_method": "isolation_forest",
                        "detection_timestamp": datetime.now(),
                        "data_criacao": datetime.now(),
                        "data_atualizacao": datetime.now()
                    }
                }
            ]
        }
    
    async def auto_classify_data(self) -> Dict[str, Any]:
        """Classifica dados automaticamente"""
        # Implementação simulada - seria conectada a algoritmos ML
        return {
            "records": [
                {
                    "table": "data_classification_results",
                    "data": {
                        "classification_id": str(uuid.uuid4()),
                        "object_name": "sample_table",
                        "classification_type": "automated",
                        "classification_result": "confidential",
                        "confidence_score": 0.92,
                        "classification_timestamp": datetime.now(),
                        "data_criacao": datetime.now(),
                        "data_atualizacao": datetime.now()
                    }
                }
            ]
        }
    
    # Métodos de qualidade
    
    async def _calculate_completeness(self, data: List[Dict]) -> float:
        """Calcula completude dos dados"""
        if not data:
            return 0.0
        
        total_fields = 0
        non_null_fields = 0
        
        for record in data:
            for value in record.values():
                total_fields += 1
                if value is not None and value != "":
                    non_null_fields += 1
        
        return (non_null_fields / total_fields) * 100 if total_fields > 0 else 0.0
    
    async def _calculate_uniqueness(self, data: List[Dict]) -> float:
        """Calcula unicidade dos dados"""
        if not data:
            return 0.0
        
        # Implementação simplificada
        unique_records = len(set(str(record) for record in data))
        total_records = len(data)
        
        return (unique_records / total_records) * 100 if total_records > 0 else 0.0
    
    async def _calculate_validity(self, data: List[Dict]) -> float:
        """Calcula validade dos dados"""
        # Implementação simplificada - verificaria padrões específicos
        return 90.0  # Placeholder
    
    async def _calculate_consistency(self, data: List[Dict]) -> float:
        """Calcula consistência dos dados"""
        # Implementação simplificada - verificaria consistência entre campos
        return 85.0  # Placeholder
    
    async def _calculate_timeliness(self, data: List[Dict]) -> float:
        """Calcula pontualidade dos dados"""
        # Implementação simplificada - verificaria timestamps
        return 95.0  # Placeholder

