"""
Configuração centralizada do Data Governance Load Engine
"""

import os
from typing import List, Optional
from pydantic import BaseSettings, Field


class DatabaseConfig(BaseSettings):
    """Configuração do banco de dados"""
    url: str = Field(..., env="DATABASE_URL")
    pool_size: int = Field(10, env="DATABASE_POOL_SIZE")
    max_overflow: int = Field(20, env="DATABASE_MAX_OVERFLOW")
    echo: bool = Field(False, env="DATABASE_ECHO")


class DatabricksConfig(BaseSettings):
    """Configuração do Databricks e Unity Catalog"""
    host: str = Field(..., env="DATABRICKS_HOST")
    token: str = Field(..., env="DATABRICKS_TOKEN")
    cluster_id: Optional[str] = Field(None, env="DATABRICKS_CLUSTER_ID")
    warehouse_id: Optional[str] = Field(None, env="DATABRICKS_WAREHOUSE_ID")
    
    # Unity Catalog
    catalog_name: str = Field(..., env="UNITY_CATALOG_NAME")
    schema_name: str = Field(..., env="UNITY_CATALOG_SCHEMA")
    metastore_id: Optional[str] = Field(None, env="UNITY_CATALOG_METASTORE_ID")


class AzureConfig(BaseSettings):
    """Configuração do Azure via Service Principal"""
    tenant_id: str = Field(..., env="AZURE_TENANT_ID")
    client_id: str = Field(..., env="AZURE_CLIENT_ID")
    client_secret: str = Field(..., env="AZURE_CLIENT_SECRET")
    subscription_id: str = Field(..., env="AZURE_SUBSCRIPTION_ID")
    
    # Recursos Azure
    resource_group: Optional[str] = Field(None, env="AZURE_RESOURCE_GROUP")
    data_factory_name: Optional[str] = Field(None, env="AZURE_DATA_FACTORY_NAME")
    synapse_workspace: Optional[str] = Field(None, env="AZURE_SYNAPSE_WORKSPACE")


class PurviewConfig(BaseSettings):
    """Configuração do Azure Purview"""
    account_name: str = Field(..., env="PURVIEW_ACCOUNT_NAME")
    # Usa as mesmas credenciais do Azure
    max_concurrent_requests: int = Field(10, env="PURVIEW_MAX_CONCURRENT_REQUESTS")
    requests_per_second: int = Field(20, env="PURVIEW_REQUESTS_PER_SECOND")


class AxonConfig(BaseSettings):
    """Configuração do Informatica Axon"""
    host: str = Field(..., env="AXON_HOST")
    port: int = Field(443, env="AXON_PORT")
    username: str = Field(..., env="AXON_USERNAME")
    password: str = Field(..., env="AXON_PASSWORD")
    domain: str = Field("Native", env="AXON_DOMAIN")
    use_ssl: bool = Field(True, env="AXON_USE_SSL")
    max_concurrent_requests: int = Field(8, env="AXON_MAX_CONCURRENT_REQUESTS")
    requests_per_second: int = Field(15, env="AXON_REQUESTS_PER_SECOND")
    page_size: int = Field(100, env="AXON_PAGE_SIZE")


class LoadEngineConfig(BaseSettings):
    """Configuração do motor de load"""
    # Schedules (formato cron)
    sync_schedule_unity_catalog: str = Field("0 */6 * * *", env="SYNC_SCHEDULE_UNITY_CATALOG")
    sync_schedule_azure_metrics: str = Field("0 */12 * * *", env="SYNC_SCHEDULE_AZURE_METRICS")
    sync_schedule_quality_checks: str = Field("0 2 * * *", env="SYNC_SCHEDULE_QUALITY_CHECKS")
    
    # Batch sizes
    batch_size_tables: int = Field(100, env="BATCH_SIZE_TABLES")
    batch_size_columns: int = Field(1000, env="BATCH_SIZE_COLUMNS")
    batch_size_metrics: int = Field(500, env="BATCH_SIZE_METRICS")
    
    # Retry configuration
    max_retries: int = Field(3, env="MAX_RETRIES")
    retry_delay_seconds: int = Field(30, env="RETRY_DELAY_SECONDS")
    timeout_seconds: int = Field(300, env="TIMEOUT_SECONDS")


class APIConfig(BaseSettings):
    """Configuração da API"""
    host: str = Field("0.0.0.0", env="API_HOST")
    port: int = Field(8000, env="API_PORT")
    workers: int = Field(4, env="API_WORKERS")
    reload: bool = Field(False, env="API_RELOAD")
    
    # CORS
    cors_origins: List[str] = Field(["*"], env="CORS_ORIGINS")
    cors_methods: List[str] = Field(["*"], env="CORS_METHODS")
    cors_headers: List[str] = Field(["*"], env="CORS_HEADERS")


class LoggingConfig(BaseSettings):
    """Configuração de logging"""
    level: str = Field("INFO", env="LOG_LEVEL")
    format: str = Field("json", env="LOG_FORMAT")
    file_path: str = Field("logs/load_engine.log", env="LOG_FILE_PATH")
    max_size_mb: int = Field(100, env="LOG_MAX_SIZE_MB")
    backup_count: int = Field(5, env="LOG_BACKUP_COUNT")


class MonitoringConfig(BaseSettings):
    """Configuração de monitoramento"""
    prometheus_port: int = Field(9090, env="PROMETHEUS_PORT")
    metrics_enabled: bool = Field(True, env="METRICS_ENABLED")
    health_check_interval: int = Field(60, env="HEALTH_CHECK_INTERVAL")


class SecurityConfig(BaseSettings):
    """Configuração de segurança"""
    secret_key: str = Field(..., env="SECRET_KEY")
    jwt_algorithm: str = Field("HS256", env="JWT_ALGORITHM")
    jwt_expire_minutes: int = Field(1440, env="JWT_EXPIRE_MINUTES")


class FeatureFlags(BaseSettings):
    """Feature flags para controle de funcionalidades"""
    enable_unity_catalog_sync: bool = Field(True, env="ENABLE_UNITY_CATALOG_SYNC")
    enable_azure_sync: bool = Field(True, env="ENABLE_AZURE_SYNC")
    enable_purview_sync: bool = Field(False, env="ENABLE_PURVIEW_SYNC")
    enable_axon_sync: bool = Field(False, env="ENABLE_AXON_SYNC")
    enable_quality_inference: bool = Field(True, env="ENABLE_QUALITY_INFERENCE")
    enable_anomaly_detection: bool = Field(True, env="ENABLE_ANOMALY_DETECTION")
    enable_auto_classification: bool = Field(True, env="ENABLE_AUTO_CLASSIFICATION")


class DevelopmentConfig(BaseSettings):
    """Configuração de desenvolvimento"""
    debug: bool = Field(False, env="DEBUG")
    testing: bool = Field(False, env="TESTING")
    development_mode: bool = Field(False, env="DEVELOPMENT_MODE")
    use_mock_data: bool = Field(False, env="USE_MOCK_DATA")
    mock_data_size: int = Field(1000, env="MOCK_DATA_SIZE")


class Settings(BaseSettings):
    """Configuração principal do sistema"""
    
    # Configurações por módulo
    database: DatabaseConfig = DatabaseConfig()
    databricks: DatabricksConfig = DatabricksConfig()
    azure: AzureConfig = AzureConfig()
    purview: PurviewConfig = PurviewConfig()
    axon: AxonConfig = AxonConfig()
    load_engine: LoadEngineConfig = LoadEngineConfig()
    api: APIConfig = APIConfig()
    logging: LoggingConfig = LoggingConfig()
    monitoring: MonitoringConfig = MonitoringConfig()
    security: SecurityConfig = SecurityConfig()
    features: FeatureFlags = FeatureFlags()
    development: DevelopmentConfig = DevelopmentConfig()
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


# Instância global das configurações
settings = Settings()


def get_settings() -> Settings:
    """Retorna as configurações do sistema"""
    return settings


def validate_configuration() -> bool:
    """Valida se todas as configurações obrigatórias estão presentes"""
    try:
        # Testa se consegue instanciar todas as configurações
        settings = Settings()
        
        # Validações específicas
        if not settings.databricks.host.startswith("https://"):
            raise ValueError("DATABRICKS_HOST deve começar com https://")
        
        if not settings.azure.tenant_id:
            raise ValueError("AZURE_TENANT_ID é obrigatório")
        
        if not settings.database.url:
            raise ValueError("DATABASE_URL é obrigatório")
        
        return True
        
    except Exception as e:
        print(f"Erro na validação da configuração: {e}")
        return False


if __name__ == "__main__":
    # Teste de configuração
    if validate_configuration():
        print("✅ Configuração válida")
        print(f"Databricks Host: {settings.databricks.host}")
        print(f"Unity Catalog: {settings.databricks.catalog_name}")
        print(f"Azure Tenant: {settings.azure.tenant_id}")
    else:
        print("❌ Configuração inválida")

