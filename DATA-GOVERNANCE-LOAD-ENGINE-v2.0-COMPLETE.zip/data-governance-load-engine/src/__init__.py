"""
Data Governance Load Engine

Motor de carga de dados para alimentar o modelo de governança de dados,
com integração Unity Catalog e Azure via SPN.
"""

__version__ = "1.0.0"
__author__ = "Data Governance Team"
__description__ = "Motor de load para governança de dados"

