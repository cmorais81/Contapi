"""
Motor principal de load de dados para governança
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional
from datetime import datetime
import json
import uuid

from .config import get_settings
from .connectors import UnityCatalogConnector, AzureConnector, AzurePurviewConnector, InformaticaAxonConnector
from .transformers import DataTransformer
from .loaders import DatabaseLoader

logger = logging.getLogger(__name__)


class DataGovernanceLoadEngine:
    """Motor principal de load de dados para governança"""
    
    def __init__(self):
        self.settings = get_settings()
        self.connectors = {}
        self.transformer = DataTransformer()
        self.loader = DatabaseLoader()
        self.running = False
        self.last_sync = {}
        
        # Métricas
        self.metrics = {
            "total_syncs": 0,
            "successful_syncs": 0,
            "failed_syncs": 0,
            "total_records_processed": 0,
            "last_sync_duration": 0.0,
            "errors": []
        }
    
    async def initialize(self) -> bool:
        """Inicializa o motor de load"""
        try:
            logger.info("Inicializando Data Governance Load Engine...")
            
            # Inicializa conectores
            await self._initialize_connectors()
            
            # Inicializa transformer
            await self.transformer.initialize()
            
            # Inicializa loader
            await self.loader.initialize()
            
            logger.info("Motor de load inicializado com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao inicializar motor de load: {e}")
            return False
    
    async def _initialize_connectors(self):
        """Inicializa conectores de dados"""
        try:
            # Unity Catalog Connector
            if self.settings.features.enable_unity_catalog_sync:
                uc_config = {
                    "host": self.settings.databricks.host,
                    "token": self.settings.databricks.token,
                    "catalog_name": self.settings.databricks.catalog_name,
                    "schema_name": self.settings.databricks.schema_name,
                    "warehouse_id": self.settings.databricks.warehouse_id
                }
                
                self.connectors["unity_catalog"] = UnityCatalogConnector(uc_config)
                await self.connectors["unity_catalog"].connect()
            
            # Azure Connector
            if self.settings.features.enable_azure_sync:
                azure_config = {
                    "tenant_id": self.settings.azure.tenant_id,
                    "client_id": self.settings.azure.client_id,
                    "client_secret": self.settings.azure.client_secret,
                    "subscription_id": self.settings.azure.subscription_id,
                    "resource_group": self.settings.azure.resource_group,
                    "data_factory_name": self.settings.azure.data_factory_name,
                    "synapse_workspace": self.settings.azure.synapse_workspace
                }
                
                self.connectors["azure"] = AzureConnector(azure_config)
                await self.connectors["azure"].connect()
            
            # Azure Purview Connector
            if self.settings.features.enable_purview_sync:
                purview_config = {
                    "purview_account_name": self.settings.purview.account_name,
                    "tenant_id": self.settings.azure.tenant_id,
                    "client_id": self.settings.azure.client_id,
                    "client_secret": self.settings.azure.client_secret,
                    "max_concurrent_requests": 10,
                    "requests_per_second": 20
                }
                
                self.connectors["azure_purview"] = AzurePurviewConnector(purview_config)
                await self.connectors["azure_purview"].connect()
            
            # Informatica Axon Connector
            if self.settings.features.enable_axon_sync:
                axon_config = {
                    "axon_host": self.settings.axon.host,
                    "axon_port": self.settings.axon.port,
                    "username": self.settings.axon.username,
                    "password": self.settings.axon.password,
                    "domain": self.settings.axon.domain,
                    "use_ssl": self.settings.axon.use_ssl,
                    "max_concurrent_requests": 8,
                    "requests_per_second": 15,
                    "page_size": 100
                }
                
                self.connectors["informatica_axon"] = InformaticaAxonConnector(axon_config)
                await self.connectors["informatica_axon"].connect()
            
            logger.info(f"Conectores inicializados: {list(self.connectors.keys())}")
            
        except Exception as e:
            logger.error(f"Erro ao inicializar conectores: {e}")
            raise
    
    async def sync_all(self, force: bool = False) -> Dict[str, Any]:
        """Sincroniza dados de todas as fontes"""
        if self.running and not force:
            return {"error": "Sincronização já em andamento"}
        
        self.running = True
        start_time = datetime.now()
        
        results = {
            "sync_id": str(uuid.uuid4()),
            "start_time": start_time,
            "connectors": {},
            "total_records": 0,
            "errors": [],
            "success": False
        }
        
        try:
            logger.info("Iniciando sincronização completa...")
            self.metrics["total_syncs"] += 1
            
            # Sincroniza cada conector
            for connector_name, connector in self.connectors.items():
                try:
                    logger.info(f"Sincronizando {connector_name}...")
                    
                    # Extrai dados
                    raw_data = await connector.sync_data()
                    
                    # Transforma dados
                    transformed_data = await self.transformer.transform(
                        connector_name, raw_data
                    )
                    
                    # Carrega dados
                    load_result = await self.loader.load(
                        connector_name, transformed_data
                    )
                    
                    results["connectors"][connector_name] = {
                        "raw_records": raw_data.get("total_records", 0),
                        "transformed_records": len(transformed_data.get("records", [])),
                        "loaded_records": load_result.get("loaded_records", 0),
                        "errors": raw_data.get("errors", []) + load_result.get("errors", []),
                        "duration_seconds": (datetime.now() - start_time).total_seconds()
                    }
                    
                    results["total_records"] += load_result.get("loaded_records", 0)
                    self.last_sync[connector_name] = datetime.now()
                    
                    logger.info(f"Sincronização {connector_name} concluída: {load_result.get('loaded_records', 0)} registros")
                    
                except Exception as e:
                    error_msg = f"Erro na sincronização {connector_name}: {e}"
                    results["errors"].append(error_msg)
                    results["connectors"][connector_name] = {"error": error_msg}
                    logger.error(error_msg)
            
            # Pós-processamento
            if self.settings.features.enable_quality_inference:
                await self._infer_quality_metrics()
            
            if self.settings.features.enable_anomaly_detection:
                await self._detect_anomalies()
            
            if self.settings.features.enable_auto_classification:
                await self._auto_classify_data()
            
            # Finaliza
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            results["end_time"] = end_time
            results["duration_seconds"] = duration
            results["success"] = len(results["errors"]) == 0
            
            # Atualiza métricas
            if results["success"]:
                self.metrics["successful_syncs"] += 1
            else:
                self.metrics["failed_syncs"] += 1
            
            self.metrics["total_records_processed"] += results["total_records"]
            self.metrics["last_sync_duration"] = duration
            
            if results["errors"]:
                self.metrics["errors"].extend(results["errors"])
                # Mantém apenas os últimos 100 erros
                self.metrics["errors"] = self.metrics["errors"][-100:]
            
            logger.info(f"Sincronização completa finalizada: {results['total_records']} registros em {duration:.2f}s")
            
        except Exception as e:
            error_msg = f"Erro na sincronização completa: {e}"
            results["errors"].append(error_msg)
            results["success"] = False
            self.metrics["failed_syncs"] += 1
            logger.error(error_msg)
        
        finally:
            self.running = False
        
        return results
    
    async def sync_connector(self, connector_name: str, tables: Optional[List[str]] = None) -> Dict[str, Any]:
        """Sincroniza dados de um conector específico"""
        if connector_name not in self.connectors:
            return {"error": f"Conector {connector_name} não encontrado"}
        
        start_time = datetime.now()
        
        try:
            connector = self.connectors[connector_name]
            
            # Extrai dados
            raw_data = await connector.sync_data(tables)
            
            # Transforma dados
            transformed_data = await self.transformer.transform(
                connector_name, raw_data
            )
            
            # Carrega dados
            load_result = await self.loader.load(
                connector_name, transformed_data
            )
            
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            result = {
                "connector": connector_name,
                "start_time": start_time,
                "end_time": end_time,
                "duration_seconds": duration,
                "raw_records": raw_data.get("total_records", 0),
                "transformed_records": len(transformed_data.get("records", [])),
                "loaded_records": load_result.get("loaded_records", 0),
                "errors": raw_data.get("errors", []) + load_result.get("errors", []),
                "success": len(raw_data.get("errors", []) + load_result.get("errors", [])) == 0
            }
            
            self.last_sync[connector_name] = end_time
            
            logger.info(f"Sincronização {connector_name} concluída: {result['loaded_records']} registros")
            
            return result
            
        except Exception as e:
            error_msg = f"Erro na sincronização {connector_name}: {e}"
            logger.error(error_msg)
            return {
                "connector": connector_name,
                "error": error_msg,
                "success": False
            }
    
    async def _infer_quality_metrics(self):
        """Infere métricas de qualidade dos dados"""
        try:
            logger.info("Inferindo métricas de qualidade...")
            
            # Implementação de inferência de qualidade
            # Analisa dados carregados e calcula métricas automáticas
            quality_results = await self.transformer.infer_quality_metrics()
            
            if quality_results:
                await self.loader.load("quality_inference", quality_results)
                logger.info(f"Métricas de qualidade inferidas: {len(quality_results.get('records', []))} registros")
            
        except Exception as e:
            logger.error(f"Erro ao inferir métricas de qualidade: {e}")
    
    async def _detect_anomalies(self):
        """Detecta anomalias nos dados"""
        try:
            logger.info("Detectando anomalias...")
            
            # Implementação de detecção de anomalias
            anomaly_results = await self.transformer.detect_anomalies()
            
            if anomaly_results:
                await self.loader.load("anomaly_detection", anomaly_results)
                logger.info(f"Anomalias detectadas: {len(anomaly_results.get('records', []))} registros")
            
        except Exception as e:
            logger.error(f"Erro ao detectar anomalias: {e}")
    
    async def _auto_classify_data(self):
        """Classifica dados automaticamente"""
        try:
            logger.info("Classificando dados automaticamente...")
            
            # Implementação de classificação automática
            classification_results = await self.transformer.auto_classify_data()
            
            if classification_results:
                await self.loader.load("auto_classification", classification_results)
                logger.info(f"Dados classificados: {len(classification_results.get('records', []))} registros")
            
        except Exception as e:
            logger.error(f"Erro ao classificar dados: {e}")
    
    async def get_status(self) -> Dict[str, Any]:
        """Retorna status do motor de load"""
        connector_status = {}
        for name, connector in self.connectors.items():
            connector_status[name] = connector.get_health_status()
        
        return {
            "engine_status": "running" if self.running else "idle",
            "connectors": connector_status,
            "last_sync": self.last_sync,
            "metrics": self.metrics,
            "settings": {
                "unity_catalog_enabled": self.settings.features.enable_unity_catalog_sync,
                "azure_enabled": self.settings.features.enable_azure_sync,
                "quality_inference_enabled": self.settings.features.enable_quality_inference,
                "anomaly_detection_enabled": self.settings.features.enable_anomaly_detection,
                "auto_classification_enabled": self.settings.features.enable_auto_classification
            }
        }
    
    async def shutdown(self):
        """Encerra o motor de load"""
        try:
            logger.info("Encerrando motor de load...")
            
            # Desconecta conectores
            for connector in self.connectors.values():
                await connector.disconnect()
            
            # Encerra loader
            await self.loader.shutdown()
            
            logger.info("Motor de load encerrado")
            
        except Exception as e:
            logger.error(f"Erro ao encerrar motor de load: {e}")


# Instância global do motor
load_engine = DataGovernanceLoadEngine()


async def get_load_engine() -> DataGovernanceLoadEngine:
    """Retorna instância do motor de load"""
    return load_engine

