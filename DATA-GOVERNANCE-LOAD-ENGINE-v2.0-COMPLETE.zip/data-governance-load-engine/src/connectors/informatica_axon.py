"""
Conector para Informatica Axon - Plataforma de Governança de Dados Empresarial
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional, Set
from datetime import datetime, timedelta
import json
import uuid
import aiohttp
from urllib.parse import urljoin, quote
import base64
import hashlib

from .base_connector import BaseConnector

logger = logging.getLogger(__name__)


class InformaticaAxonConnector(BaseConnector):
    """Conector para Informatica Axon - Governança de Dados Empresarial"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        
        # Configurações específicas do Axon
        self.axon_host = config.get("axon_host")
        self.axon_port = config.get("axon_port", 443)
        self.username = config.get("username")
        self.password = config.get("password")
        self.domain = config.get("domain", "Native")
        self.use_ssl = config.get("use_ssl", True)
        
        # URLs das APIs do Axon
        protocol = "https" if self.use_ssl else "http"
        self.base_url = f"{protocol}://{self.axon_host}:{self.axon_port}"
        self.api_base = f"{self.base_url}/axonapi/api"
        
        # Sessão HTTP e autenticação
        self.http_session = None
        self.session_token = None
        self.session_expires_at = None
        
        # Cache para otimização
        self.business_terms_cache = {}
        self.data_domains_cache = {}
        self.policies_cache = {}
        self.stewards_cache = {}
        
        # Configurações de performance
        self.max_concurrent_requests = config.get("max_concurrent_requests", 8)
        self.requests_per_second = config.get("requests_per_second", 15)
        self.page_size = config.get("page_size", 100)
        
        # Controle de concorrência
        self.semaphore = asyncio.Semaphore(self.max_concurrent_requests)
        self.rate_limiter = asyncio.Semaphore(self.requests_per_second)
    
    async def connect(self) -> bool:
        """Estabelece conexão com Informatica Axon"""
        try:
            logger.info(f"Conectando ao Informatica Axon: {self.axon_host}")
            
            # Inicializa sessão HTTP
            connector = aiohttp.TCPConnector(
                ssl=self.use_ssl,
                limit=30,
                verify_ssl=False  # Para ambientes de desenvolvimento
            )
            
            self.http_session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=300),
                connector=connector
            )
            
            # Autentica no Axon
            if await self._authenticate():
                # Testa conectividade
                if await self.test_connection():
                    self.connected = True
                    logger.info(f"Conectado ao Informatica Axon: {self.axon_host}")
                    return True
                else:
                    raise Exception("Falha no teste de conectividade")
            else:
                raise Exception("Falha na autenticação")
                
        except Exception as e:
            logger.error(f"Erro ao conectar Informatica Axon: {e}")
            self.connected = False
            return False
    
    async def disconnect(self) -> bool:
        """Encerra conexão com Informatica Axon"""
        try:
            # Logout da sessão
            if self.session_token:
                await self._logout()
            
            # Fecha sessão HTTP
            if self.http_session:
                await self.http_session.close()
            
            self.connected = False
            logger.info("Desconectado do Informatica Axon")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao desconectar Informatica Axon: {e}")
            return False
    
    async def test_connection(self) -> bool:
        """Testa conexão com Informatica Axon"""
        try:
            # Testa API de versão
            url = f"{self.api_base}/version"
            
            async with self.semaphore:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        version_info = await response.json()
                        logger.info(f"Teste de conectividade Axon bem-sucedido: {version_info.get('version', 'N/A')}")
                        return True
                    else:
                        logger.error(f"Teste de conectividade falhou: {response.status}")
                        return False
                        
        except Exception as e:
            logger.error(f"Teste de conectividade Axon falhou: {e}")
            return False
    
    async def _authenticate(self) -> bool:
        """Autentica no Informatica Axon"""
        try:
            url = f"{self.api_base}/login"
            
            # Prepara credenciais
            credentials = {
                "username": self.username,
                "password": self.password,
                "domain": self.domain
            }
            
            async with self.http_session.post(
                url,
                json=credentials,
                headers={"Content-Type": "application/json"}
            ) as response:
                if response.status == 200:
                    auth_data = await response.json()
                    
                    self.session_token = auth_data.get("sessionId")
                    
                    # Calcula expiração da sessão (padrão 8 horas)
                    session_timeout = auth_data.get("sessionTimeout", 28800)  # 8 horas em segundos
                    self.session_expires_at = datetime.now() + timedelta(seconds=session_timeout - 300)  # 5min buffer
                    
                    logger.info("Autenticação Axon bem-sucedida")
                    return True
                else:
                    error_text = await response.text()
                    logger.error(f"Falha na autenticação Axon: {response.status} - {error_text}")
                    return False
                    
        except Exception as e:
            logger.error(f"Erro na autenticação Axon: {e}")
            return False
    
    async def _logout(self):
        """Faz logout da sessão Axon"""
        try:
            if not self.session_token:
                return
            
            url = f"{self.api_base}/logout"
            
            async with self.http_session.post(
                url,
                headers=await self._get_auth_headers()
            ) as response:
                if response.status == 200:
                    logger.debug("Logout Axon bem-sucedido")
                else:
                    logger.warning(f"Erro no logout Axon: {response.status}")
                    
        except Exception as e:
            logger.error(f"Erro no logout Axon: {e}")
        finally:
            self.session_token = None
            self.session_expires_at = None
    
    async def _get_auth_headers(self) -> Dict[str, str]:
        """Obtém headers de autenticação"""
        # Verifica se sessão precisa ser renovada
        if not self.session_token or datetime.now() >= self.session_expires_at:
            await self._authenticate()
        
        return {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "INFA-SESSION-ID": self.session_token
        }
    
    async def get_metadata(self) -> Dict[str, Any]:
        """Obtém metadados completos do Informatica Axon"""
        try:
            logger.info("Coletando metadados do Informatica Axon...")
            
            metadata = {
                "system_info": await self._get_system_info(),
                "business_terms": await self._get_business_terms(),
                "data_domains": await self._get_data_domains(),
                "policies": await self._get_policies(),
                "stewards": await self._get_stewards(),
                "data_assets": await self._get_data_assets(),
                "relationships": await self._get_relationships(),
                "workflows": await self._get_workflows(),
                "quality_rules": await self._get_quality_rules(),
                "lineage": await self._get_lineage_info()
            }
            
            total_items = sum(len(v) if isinstance(v, list) else 1 for v in metadata.values())
            logger.info(f"Metadados Axon coletados: {total_items} itens")
            return metadata
            
        except Exception as e:
            logger.error(f"Erro ao coletar metadados Axon: {e}")
            return {}
    
    async def _get_system_info(self) -> Dict[str, Any]:
        """Obtém informações do sistema Axon"""
        try:
            # Informações de versão
            version_url = f"{self.api_base}/version"
            
            async with self.semaphore:
                async with self.http_session.get(
                    version_url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        version_info = await response.json()
                    else:
                        version_info = {}
            
            # Informações de configuração
            config_url = f"{self.api_base}/configuration"
            
            async with self.semaphore:
                async with self.http_session.get(
                    config_url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        config_info = await response.json()
                    else:
                        config_info = {}
            
            return {
                "host": self.axon_host,
                "port": self.axon_port,
                "version": version_info,
                "configuration": config_info,
                "connection_time": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter informações do sistema: {e}")
            return {}
    
    async def _get_business_terms(self) -> List[Dict[str, Any]]:
        """Obtém termos de negócio do glossário"""
        try:
            url = f"{self.api_base}/glossary/terms"
            
            all_terms = []
            offset = 0
            
            while True:
                params = {
                    "limit": self.page_size,
                    "offset": offset,
                    "includeDetails": "true"
                }
                
                async with self.rate_limiter:
                    async with self.http_session.get(
                        url,
                        headers=await self._get_auth_headers(),
                        params=params
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            terms = data.get("items", [])
                            
                            if not terms:
                                break
                            
                            # Enriquece termos com detalhes adicionais
                            enriched_terms = []
                            for term in terms:
                                enriched_term = await self._enrich_business_term(term)
                                enriched_terms.append(enriched_term)
                            
                            all_terms.extend(enriched_terms)
                            offset += len(terms)
                            
                            # Verifica se há mais páginas
                            if len(terms) < self.page_size:
                                break
                        else:
                            logger.warning(f"Erro ao obter termos de negócio: {response.status}")
                            break
            
            logger.info(f"Coletados {len(all_terms)} termos de negócio")
            return all_terms
            
        except Exception as e:
            logger.error(f"Erro ao obter termos de negócio: {e}")
            return []
    
    async def _enrich_business_term(self, term: Dict[str, Any]) -> Dict[str, Any]:
        """Enriquece termo de negócio com informações adicionais"""
        try:
            term_id = term.get("id")
            if not term_id:
                return term
            
            # Obtém relacionamentos do termo
            relationships = await self._get_term_relationships(term_id)
            term["relationships"] = relationships
            
            # Obtém histórico de aprovação
            approval_history = await self._get_term_approval_history(term_id)
            term["approval_history"] = approval_history
            
            # Obtém métricas de uso
            usage_metrics = await self._get_term_usage_metrics(term_id)
            term["usage_metrics"] = usage_metrics
            
            return term
            
        except Exception as e:
            logger.error(f"Erro ao enriquecer termo {term.get('name', 'N/A')}: {e}")
            return term
    
    async def _get_term_relationships(self, term_id: str) -> List[Dict[str, Any]]:
        """Obtém relacionamentos de um termo"""
        try:
            url = f"{self.api_base}/glossary/terms/{term_id}/relationships"
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("items", [])
                    else:
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter relacionamentos do termo {term_id}: {e}")
            return []
    
    async def _get_term_approval_history(self, term_id: str) -> List[Dict[str, Any]]:
        """Obtém histórico de aprovação de um termo"""
        try:
            url = f"{self.api_base}/glossary/terms/{term_id}/approvals"
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("items", [])
                    else:
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter histórico de aprovação do termo {term_id}: {e}")
            return []
    
    async def _get_term_usage_metrics(self, term_id: str) -> Dict[str, Any]:
        """Obtém métricas de uso de um termo"""
        try:
            url = f"{self.api_base}/analytics/terms/{term_id}/usage"
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        return {}
                        
        except Exception as e:
            logger.error(f"Erro ao obter métricas de uso do termo {term_id}: {e}")
            return {}
    
    async def _get_data_domains(self) -> List[Dict[str, Any]]:
        """Obtém domínios de dados"""
        try:
            url = f"{self.api_base}/domains"
            
            all_domains = []
            offset = 0
            
            while True:
                params = {
                    "limit": self.page_size,
                    "offset": offset,
                    "includeHierarchy": "true"
                }
                
                async with self.rate_limiter:
                    async with self.http_session.get(
                        url,
                        headers=await self._get_auth_headers(),
                        params=params
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            domains = data.get("items", [])
                            
                            if not domains:
                                break
                            
                            # Enriquece domínios com detalhes
                            for domain in domains:
                                domain_details = await self._get_domain_details(domain.get("id"))
                                if domain_details:
                                    domain.update(domain_details)
                            
                            all_domains.extend(domains)
                            offset += len(domains)
                            
                            if len(domains) < self.page_size:
                                break
                        else:
                            logger.warning(f"Erro ao obter domínios: {response.status}")
                            break
            
            logger.info(f"Coletados {len(all_domains)} domínios de dados")
            return all_domains
            
        except Exception as e:
            logger.error(f"Erro ao obter domínios de dados: {e}")
            return []
    
    async def _get_domain_details(self, domain_id: str) -> Optional[Dict[str, Any]]:
        """Obtém detalhes de um domínio específico"""
        try:
            if not domain_id:
                return None
            
            url = f"{self.api_base}/domains/{domain_id}"
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        domain_data = await response.json()
                        
                        # Adiciona informações de stewards
                        stewards = await self._get_domain_stewards(domain_id)
                        domain_data["stewards"] = stewards
                        
                        # Adiciona métricas do domínio
                        metrics = await self._get_domain_metrics(domain_id)
                        domain_data["metrics"] = metrics
                        
                        return domain_data
                    else:
                        return None
                        
        except Exception as e:
            logger.error(f"Erro ao obter detalhes do domínio {domain_id}: {e}")
            return None
    
    async def _get_domain_stewards(self, domain_id: str) -> List[Dict[str, Any]]:
        """Obtém stewards de um domínio"""
        try:
            url = f"{self.api_base}/domains/{domain_id}/stewards"
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("items", [])
                    else:
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter stewards do domínio {domain_id}: {e}")
            return []
    
    async def _get_domain_metrics(self, domain_id: str) -> Dict[str, Any]:
        """Obtém métricas de um domínio"""
        try:
            url = f"{self.api_base}/analytics/domains/{domain_id}/metrics"
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        return await response.json()
                    else:
                        return {}
                        
        except Exception as e:
            logger.error(f"Erro ao obter métricas do domínio {domain_id}: {e}")
            return {}
    
    async def _get_policies(self) -> List[Dict[str, Any]]:
        """Obtém políticas de dados"""
        try:
            url = f"{self.api_base}/policies"
            
            all_policies = []
            offset = 0
            
            while True:
                params = {
                    "limit": self.page_size,
                    "offset": offset,
                    "includeRules": "true"
                }
                
                async with self.rate_limiter:
                    async with self.http_session.get(
                        url,
                        headers=await self._get_auth_headers(),
                        params=params
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            policies = data.get("items", [])
                            
                            if not policies:
                                break
                            
                            # Enriquece políticas com execuções
                            for policy in policies:
                                executions = await self._get_policy_executions(policy.get("id"))
                                policy["recent_executions"] = executions
                            
                            all_policies.extend(policies)
                            offset += len(policies)
                            
                            if len(policies) < self.page_size:
                                break
                        else:
                            logger.warning(f"Erro ao obter políticas: {response.status}")
                            break
            
            logger.info(f"Coletadas {len(all_policies)} políticas")
            return all_policies
            
        except Exception as e:
            logger.error(f"Erro ao obter políticas: {e}")
            return []
    
    async def _get_policy_executions(self, policy_id: str) -> List[Dict[str, Any]]:
        """Obtém execuções recentes de uma política"""
        try:
            if not policy_id:
                return []
            
            url = f"{self.api_base}/policies/{policy_id}/executions"
            params = {
                "limit": 10,  # Últimas 10 execuções
                "orderBy": "executionTime",
                "orderDirection": "desc"
            }
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers(),
                    params=params
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("items", [])
                    else:
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter execuções da política {policy_id}: {e}")
            return []
    
    async def _get_stewards(self) -> List[Dict[str, Any]]:
        """Obtém stewards de dados"""
        try:
            url = f"{self.api_base}/stewards"
            
            all_stewards = []
            offset = 0
            
            while True:
                params = {
                    "limit": self.page_size,
                    "offset": offset,
                    "includeAssignments": "true"
                }
                
                async with self.rate_limiter:
                    async with self.http_session.get(
                        url,
                        headers=await self._get_auth_headers(),
                        params=params
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            stewards = data.get("items", [])
                            
                            if not stewards:
                                break
                            
                            all_stewards.extend(stewards)
                            offset += len(stewards)
                            
                            if len(stewards) < self.page_size:
                                break
                        else:
                            logger.warning(f"Erro ao obter stewards: {response.status}")
                            break
            
            logger.info(f"Coletados {len(all_stewards)} stewards")
            return all_stewards
            
        except Exception as e:
            logger.error(f"Erro ao obter stewards: {e}")
            return []
    
    async def _get_data_assets(self) -> List[Dict[str, Any]]:
        """Obtém assets de dados"""
        try:
            url = f"{self.api_base}/assets"
            
            all_assets = []
            offset = 0
            
            while True:
                params = {
                    "limit": self.page_size,
                    "offset": offset,
                    "includeMetadata": "true"
                }
                
                async with self.rate_limiter:
                    async with self.http_session.get(
                        url,
                        headers=await self._get_auth_headers(),
                        params=params
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            assets = data.get("items", [])
                            
                            if not assets:
                                break
                            
                            # Enriquece assets com classificações
                            for asset in assets:
                                classifications = await self._get_asset_classifications(asset.get("id"))
                                asset["classifications"] = classifications
                            
                            all_assets.extend(assets)
                            offset += len(assets)
                            
                            if len(assets) < self.page_size:
                                break
                        else:
                            logger.warning(f"Erro ao obter assets: {response.status}")
                            break
            
            logger.info(f"Coletados {len(all_assets)} assets de dados")
            return all_assets
            
        except Exception as e:
            logger.error(f"Erro ao obter assets de dados: {e}")
            return []
    
    async def _get_asset_classifications(self, asset_id: str) -> List[Dict[str, Any]]:
        """Obtém classificações de um asset"""
        try:
            if not asset_id:
                return []
            
            url = f"{self.api_base}/assets/{asset_id}/classifications"
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("items", [])
                    else:
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter classificações do asset {asset_id}: {e}")
            return []
    
    async def _get_relationships(self) -> List[Dict[str, Any]]:
        """Obtém relacionamentos entre entidades"""
        try:
            url = f"{self.api_base}/relationships"
            
            all_relationships = []
            offset = 0
            
            while True:
                params = {
                    "limit": self.page_size,
                    "offset": offset
                }
                
                async with self.rate_limiter:
                    async with self.http_session.get(
                        url,
                        headers=await self._get_auth_headers(),
                        params=params
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            relationships = data.get("items", [])
                            
                            if not relationships:
                                break
                            
                            all_relationships.extend(relationships)
                            offset += len(relationships)
                            
                            if len(relationships) < self.page_size:
                                break
                        else:
                            logger.warning(f"Erro ao obter relacionamentos: {response.status}")
                            break
            
            logger.info(f"Coletados {len(all_relationships)} relacionamentos")
            return all_relationships
            
        except Exception as e:
            logger.error(f"Erro ao obter relacionamentos: {e}")
            return []
    
    async def _get_workflows(self) -> List[Dict[str, Any]]:
        """Obtém workflows de aprovação"""
        try:
            url = f"{self.api_base}/workflows"
            
            all_workflows = []
            offset = 0
            
            while True:
                params = {
                    "limit": self.page_size,
                    "offset": offset,
                    "includeSteps": "true"
                }
                
                async with self.rate_limiter:
                    async with self.http_session.get(
                        url,
                        headers=await self._get_auth_headers(),
                        params=params
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            workflows = data.get("items", [])
                            
                            if not workflows:
                                break
                            
                            all_workflows.extend(workflows)
                            offset += len(workflows)
                            
                            if len(workflows) < self.page_size:
                                break
                        else:
                            logger.warning(f"Erro ao obter workflows: {response.status}")
                            break
            
            logger.info(f"Coletados {len(all_workflows)} workflows")
            return all_workflows
            
        except Exception as e:
            logger.error(f"Erro ao obter workflows: {e}")
            return []
    
    async def _get_quality_rules(self) -> List[Dict[str, Any]]:
        """Obtém regras de qualidade"""
        try:
            url = f"{self.api_base}/quality/rules"
            
            all_rules = []
            offset = 0
            
            while True:
                params = {
                    "limit": self.page_size,
                    "offset": offset,
                    "includeExecutions": "true"
                }
                
                async with self.rate_limiter:
                    async with self.http_session.get(
                        url,
                        headers=await self._get_auth_headers(),
                        params=params
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            rules = data.get("items", [])
                            
                            if not rules:
                                break
                            
                            all_rules.extend(rules)
                            offset += len(rules)
                            
                            if len(rules) < self.page_size:
                                break
                        else:
                            logger.warning(f"Erro ao obter regras de qualidade: {response.status}")
                            break
            
            logger.info(f"Coletadas {len(all_rules)} regras de qualidade")
            return all_rules
            
        except Exception as e:
            logger.error(f"Erro ao obter regras de qualidade: {e}")
            return []
    
    async def _get_lineage_info(self) -> List[Dict[str, Any]]:
        """Obtém informações de linhagem"""
        try:
            url = f"{self.api_base}/lineage"
            
            all_lineage = []
            offset = 0
            
            while True:
                params = {
                    "limit": self.page_size,
                    "offset": offset,
                    "depth": 3  # Profundidade da linhagem
                }
                
                async with self.rate_limiter:
                    async with self.http_session.get(
                        url,
                        headers=await self._get_auth_headers(),
                        params=params
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            lineage_items = data.get("items", [])
                            
                            if not lineage_items:
                                break
                            
                            all_lineage.extend(lineage_items)
                            offset += len(lineage_items)
                            
                            if len(lineage_items) < self.page_size:
                                break
                        else:
                            logger.warning(f"Erro ao obter linhagem: {response.status}")
                            break
            
            logger.info(f"Coletadas {len(all_lineage)} informações de linhagem")
            return all_lineage
            
        except Exception as e:
            logger.error(f"Erro ao obter linhagem: {e}")
            return []
    
    async def _perform_sync(self, tables: Optional[List[str]] = None) -> Dict[str, Any]:
        """Implementação específica da sincronização Axon"""
        results = {
            "tables_synced": [],
            "errors": [],
            "total_records": 0,
            "data": {}
        }
        
        try:
            logger.info("Iniciando sincronização Informatica Axon...")
            
            # Coleta metadados completos
            metadata = await self.get_metadata()
            results["data"] = metadata
            
            # Conta registros coletados
            for key, value in metadata.items():
                if isinstance(value, list):
                    results["total_records"] += len(value)
                    results["tables_synced"].append(f"axon_{key}")
                elif isinstance(value, dict) and value:
                    results["total_records"] += 1
                    results["tables_synced"].append(f"axon_{key}")
            
            logger.info(f"Sincronização Axon concluída: {results['total_records']} registros")
            
        except Exception as e:
            error_msg = f"Erro na sincronização Axon: {e}"
            results["errors"].append(error_msg)
            logger.error(error_msg)
        
        return results
    
    def get_health_status(self) -> Dict[str, Any]:
        """Retorna status de saúde do conector"""
        return {
            "connected": self.connected,
            "axon_host": self.axon_host,
            "axon_port": self.axon_port,
            "domain": self.domain,
            "session_valid": self.session_token is not None and datetime.now() < self.session_expires_at,
            "cache_size": {
                "business_terms": len(self.business_terms_cache),
                "data_domains": len(self.data_domains_cache),
                "policies": len(self.policies_cache),
                "stewards": len(self.stewards_cache)
            },
            "last_sync": getattr(self, 'last_sync_time', None)
        }

