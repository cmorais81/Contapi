"""
Conector para Unity Catalog (Databricks)
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional
from datetime import datetime
import json

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.catalog import CatalogInfo, SchemaInfo, TableInfo
from databricks.sql import connect as sql_connect
import httpx

from .base_connector import BaseConnector

logger = logging.getLogger(__name__)


class UnityCatalogConnector(BaseConnector):
    """Conector para Unity Catalog do Databricks"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.workspace_client = None
        self.sql_connection = None
        self.http_client = None
        
        # Configurações específicas
        self.host = config.get("host")
        self.token = config.get("token")
        self.catalog_name = config.get("catalog_name")
        self.schema_name = config.get("schema_name")
        self.warehouse_id = config.get("warehouse_id")
    
    async def connect(self) -> bool:
        """Estabelece conexão com Unity Catalog"""
        try:
            # Cliente do workspace
            self.workspace_client = WorkspaceClient(
                host=self.host,
                token=self.token
            )
            
            # Cliente HTTP para APIs REST
            self.http_client = httpx.AsyncClient(
                base_url=self.host,
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Content-Type": "application/json"
                },
                timeout=30.0
            )
            
            # Testa conexão
            if await self.test_connection():
                self.connected = True
                logger.info(f"Conectado ao Unity Catalog: {self.host}")
                return True
            else:
                raise Exception("Falha no teste de conexão")
                
        except Exception as e:
            logger.error(f"Erro ao conectar Unity Catalog: {e}")
            self.connected = False
            return False
    
    async def disconnect(self) -> bool:
        """Encerra conexão com Unity Catalog"""
        try:
            if self.http_client:
                await self.http_client.aclose()
            
            if self.sql_connection:
                self.sql_connection.close()
            
            self.connected = False
            logger.info("Desconectado do Unity Catalog")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao desconectar Unity Catalog: {e}")
            return False
    
    async def test_connection(self) -> bool:
        """Testa conexão com Unity Catalog"""
        try:
            # Testa API REST
            response = await self.http_client.get("/api/2.1/unity-catalog/catalogs")
            if response.status_code != 200:
                return False
            
            # Testa workspace client
            catalogs = list(self.workspace_client.catalogs.list())
            logger.info(f"Encontrados {len(catalogs)} catálogos")
            
            return True
            
        except Exception as e:
            logger.error(f"Teste de conexão falhou: {e}")
            return False
    
    async def get_metadata(self) -> Dict[str, Any]:
        """Obtém metadados do Unity Catalog"""
        try:
            metadata = {
                "catalogs": await self._get_catalogs(),
                "workspace_info": await self._get_workspace_info(),
                "metastore_info": await self._get_metastore_info()
            }
            return metadata
            
        except Exception as e:
            logger.error(f"Erro ao obter metadados: {e}")
            return {}
    
    async def _get_catalogs(self) -> List[Dict[str, Any]]:
        """Obtém lista de catálogos"""
        try:
            response = await self.http_client.get("/api/2.1/unity-catalog/catalogs")
            data = response.json()
            return data.get("catalogs", [])
            
        except Exception as e:
            logger.error(f"Erro ao obter catálogos: {e}")
            return []
    
    async def _get_schemas(self, catalog_name: str) -> List[Dict[str, Any]]:
        """Obtém schemas de um catálogo"""
        try:
            response = await self.http_client.get(
                f"/api/2.1/unity-catalog/schemas",
                params={"catalog_name": catalog_name}
            )
            data = response.json()
            return data.get("schemas", [])
            
        except Exception as e:
            logger.error(f"Erro ao obter schemas do catálogo {catalog_name}: {e}")
            return []
    
    async def _get_tables(self, catalog_name: str, schema_name: str) -> List[Dict[str, Any]]:
        """Obtém tabelas de um schema"""
        try:
            response = await self.http_client.get(
                f"/api/2.1/unity-catalog/tables",
                params={
                    "catalog_name": catalog_name,
                    "schema_name": schema_name
                }
            )
            data = response.json()
            return data.get("tables", [])
            
        except Exception as e:
            logger.error(f"Erro ao obter tabelas do schema {catalog_name}.{schema_name}: {e}")
            return []
    
    async def _get_table_details(self, full_table_name: str) -> Dict[str, Any]:
        """Obtém detalhes de uma tabela específica"""
        try:
            response = await self.http_client.get(
                f"/api/2.1/unity-catalog/tables/{full_table_name}"
            )
            return response.json()
            
        except Exception as e:
            logger.error(f"Erro ao obter detalhes da tabela {full_table_name}: {e}")
            return {}
    
    async def _get_columns(self, full_table_name: str) -> List[Dict[str, Any]]:
        """Obtém colunas de uma tabela"""
        try:
            table_details = await self._get_table_details(full_table_name)
            return table_details.get("columns", [])
            
        except Exception as e:
            logger.error(f"Erro ao obter colunas da tabela {full_table_name}: {e}")
            return []
    
    async def _get_lineage(self, full_table_name: str) -> Dict[str, Any]:
        """Obtém linhagem de uma tabela"""
        try:
            response = await self.http_client.get(
                f"/api/2.1/unity-catalog/lineage",
                params={"table_name": full_table_name}
            )
            return response.json()
            
        except Exception as e:
            logger.error(f"Erro ao obter linhagem da tabela {full_table_name}: {e}")
            return {}
    
    async def _get_workspace_info(self) -> Dict[str, Any]:
        """Obtém informações do workspace"""
        try:
            response = await self.http_client.get("/api/2.0/workspace/conf")
            return response.json()
            
        except Exception as e:
            logger.error(f"Erro ao obter info do workspace: {e}")
            return {}
    
    async def _get_metastore_info(self) -> Dict[str, Any]:
        """Obtém informações do metastore"""
        try:
            response = await self.http_client.get("/api/2.1/unity-catalog/metastores")
            data = response.json()
            metastores = data.get("metastores", [])
            return metastores[0] if metastores else {}
            
        except Exception as e:
            logger.error(f"Erro ao obter info do metastore: {e}")
            return {}
    
    async def _get_users_and_groups(self) -> Dict[str, Any]:
        """Obtém usuários e grupos do workspace"""
        try:
            # Usuários
            users_response = await self.http_client.get("/api/2.0/preview/scim/v2/Users")
            users_data = users_response.json()
            
            # Grupos
            groups_response = await self.http_client.get("/api/2.0/preview/scim/v2/Groups")
            groups_data = groups_response.json()
            
            return {
                "users": users_data.get("Resources", []),
                "groups": groups_data.get("Resources", [])
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter usuários e grupos: {e}")
            return {"users": [], "groups": []}
    
    async def _get_cluster_metrics(self) -> List[Dict[str, Any]]:
        """Obtém métricas de clusters"""
        try:
            response = await self.http_client.get("/api/2.0/clusters/list")
            clusters_data = response.json()
            
            metrics = []
            for cluster in clusters_data.get("clusters", []):
                cluster_id = cluster.get("cluster_id")
                
                # Obtém métricas específicas do cluster
                metrics_response = await self.http_client.get(
                    f"/api/2.0/clusters/get",
                    params={"cluster_id": cluster_id}
                )
                
                if metrics_response.status_code == 200:
                    cluster_details = metrics_response.json()
                    metrics.append({
                        "cluster_id": cluster_id,
                        "cluster_name": cluster.get("cluster_name"),
                        "state": cluster.get("state"),
                        "node_type_id": cluster.get("node_type_id"),
                        "num_workers": cluster.get("num_workers", 0),
                        "driver_node_type_id": cluster.get("driver_node_type_id"),
                        "spark_version": cluster.get("spark_version"),
                        "autotermination_minutes": cluster.get("autotermination_minutes"),
                        "details": cluster_details
                    })
            
            return metrics
            
        except Exception as e:
            logger.error(f"Erro ao obter métricas de clusters: {e}")
            return []
    
    async def _get_job_metrics(self) -> List[Dict[str, Any]]:
        """Obtém métricas de jobs"""
        try:
            response = await self.http_client.get("/api/2.1/jobs/list")
            jobs_data = response.json()
            
            metrics = []
            for job in jobs_data.get("jobs", []):
                job_id = job.get("job_id")
                
                # Obtém runs do job
                runs_response = await self.http_client.get(
                    f"/api/2.1/jobs/runs/list",
                    params={"job_id": job_id, "limit": 10}
                )
                
                if runs_response.status_code == 200:
                    runs_data = runs_response.json()
                    metrics.append({
                        "job_id": job_id,
                        "job_name": job.get("settings", {}).get("name"),
                        "job_type": job.get("settings", {}).get("job_type"),
                        "created_time": job.get("created_time"),
                        "creator_user_name": job.get("creator_user_name"),
                        "recent_runs": runs_data.get("runs", [])
                    })
            
            return metrics
            
        except Exception as e:
            logger.error(f"Erro ao obter métricas de jobs: {e}")
            return []
    
    async def _get_query_metrics(self) -> List[Dict[str, Any]]:
        """Obtém métricas de queries"""
        try:
            response = await self.http_client.get("/api/2.0/sql/history/queries")
            data = response.json()
            return data.get("res", [])
            
        except Exception as e:
            logger.error(f"Erro ao obter métricas de queries: {e}")
            return []
    
    async def _perform_sync(self, tables: Optional[List[str]] = None) -> Dict[str, Any]:
        """Implementação específica da sincronização Unity Catalog"""
        results = {
            "tables_synced": [],
            "errors": [],
            "total_records": 0,
            "data": {}
        }
        
        try:
            # 1. Sincronizar catálogos
            catalogs = await self._get_catalogs()
            results["data"]["catalogs"] = catalogs
            results["total_records"] += len(catalogs)
            
            # 2. Sincronizar schemas
            schemas = []
            for catalog in catalogs:
                catalog_name = catalog.get("name")
                catalog_schemas = await self._get_schemas(catalog_name)
                schemas.extend(catalog_schemas)
            
            results["data"]["schemas"] = schemas
            results["total_records"] += len(schemas)
            
            # 3. Sincronizar tabelas e colunas
            all_tables = []
            all_columns = []
            
            for schema in schemas:
                catalog_name = schema.get("catalog_name")
                schema_name = schema.get("name")
                
                if tables and f"{catalog_name}.{schema_name}" not in tables:
                    continue
                
                schema_tables = await self._get_tables(catalog_name, schema_name)
                
                for table in schema_tables:
                    table_name = table.get("name")
                    full_table_name = f"{catalog_name}.{schema_name}.{table_name}"
                    
                    # Detalhes da tabela
                    table_details = await self._get_table_details(full_table_name)
                    table.update(table_details)
                    all_tables.append(table)
                    
                    # Colunas da tabela
                    columns = await self._get_columns(full_table_name)
                    for column in columns:
                        column["full_table_name"] = full_table_name
                        all_columns.append(column)
                    
                    # Linhagem da tabela
                    lineage = await self._get_lineage(full_table_name)
                    table["lineage"] = lineage
                    
                    results["tables_synced"].append(full_table_name)
            
            results["data"]["tables"] = all_tables
            results["data"]["columns"] = all_columns
            results["total_records"] += len(all_tables) + len(all_columns)
            
            # 4. Sincronizar usuários e grupos
            users_groups = await self._get_users_and_groups()
            results["data"]["users"] = users_groups["users"]
            results["data"]["groups"] = users_groups["groups"]
            results["total_records"] += len(users_groups["users"]) + len(users_groups["groups"])
            
            # 5. Sincronizar métricas
            cluster_metrics = await self._get_cluster_metrics()
            job_metrics = await self._get_job_metrics()
            query_metrics = await self._get_query_metrics()
            
            results["data"]["cluster_metrics"] = cluster_metrics
            results["data"]["job_metrics"] = job_metrics
            results["data"]["query_metrics"] = query_metrics
            results["total_records"] += len(cluster_metrics) + len(job_metrics) + len(query_metrics)
            
            logger.info(f"Unity Catalog sync concluído: {results['total_records']} registros")
            
        except Exception as e:
            error_msg = f"Erro na sincronização Unity Catalog: {e}"
            results["errors"].append(error_msg)
            logger.error(error_msg)
        
        return results

