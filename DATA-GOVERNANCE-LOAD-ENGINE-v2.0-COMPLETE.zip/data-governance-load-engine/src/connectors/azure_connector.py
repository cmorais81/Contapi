"""
Conector para Azure via Service Principal Name (SPN)
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional
from datetime import datetime, timedelta
import json

from azure.identity import ClientSecretCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.datafactory import DataFactoryManagementClient
from azure.mgmt.synapse import SynapseManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.mgmt.sql import SqlManagementClient
from azure.mgmt.monitor import MonitorManagementClient

from .base_connector import BaseConnector

logger = logging.getLogger(__name__)


class AzureConnector(BaseConnector):
    """Conector para Azure via Service Principal"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.credential = None
        self.clients = {}
        
        # Configurações específicas
        self.tenant_id = config.get("tenant_id")
        self.client_id = config.get("client_id")
        self.client_secret = config.get("client_secret")
        self.subscription_id = config.get("subscription_id")
        self.resource_group = config.get("resource_group")
        self.data_factory_name = config.get("data_factory_name")
        self.synapse_workspace = config.get("synapse_workspace")
    
    async def connect(self) -> bool:
        """Estabelece conexão com Azure"""
        try:
            # Credencial do Service Principal
            self.credential = ClientSecretCredential(
                tenant_id=self.tenant_id,
                client_id=self.client_id,
                client_secret=self.client_secret
            )
            
            # Inicializa clientes Azure
            await self._initialize_clients()
            
            # Testa conexão
            if await self.test_connection():
                self.connected = True
                logger.info(f"Conectado ao Azure: {self.subscription_id}")
                return True
            else:
                raise Exception("Falha no teste de conexão")
                
        except Exception as e:
            logger.error(f"Erro ao conectar Azure: {e}")
            self.connected = False
            return False
    
    async def _initialize_clients(self):
        """Inicializa clientes Azure"""
        try:
            self.clients = {
                "resource": ResourceManagementClient(
                    self.credential, self.subscription_id
                ),
                "datafactory": DataFactoryManagementClient(
                    self.credential, self.subscription_id
                ) if self.data_factory_name else None,
                "synapse": SynapseManagementClient(
                    self.credential, self.subscription_id
                ) if self.synapse_workspace else None,
                "storage": StorageManagementClient(
                    self.credential, self.subscription_id
                ),
                "sql": SqlManagementClient(
                    self.credential, self.subscription_id
                ),
                "monitor": MonitorManagementClient(
                    self.credential, self.subscription_id
                )
            }
            
            # Remove clientes None
            self.clients = {k: v for k, v in self.clients.items() if v is not None}
            
        except Exception as e:
            logger.error(f"Erro ao inicializar clientes Azure: {e}")
            raise
    
    async def disconnect(self) -> bool:
        """Encerra conexão com Azure"""
        try:
            # Fecha clientes se necessário
            for client in self.clients.values():
                if hasattr(client, 'close'):
                    client.close()
            
            self.clients = {}
            self.connected = False
            logger.info("Desconectado do Azure")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao desconectar Azure: {e}")
            return False
    
    async def test_connection(self) -> bool:
        """Testa conexão com Azure"""
        try:
            # Testa listando resource groups
            resource_client = self.clients.get("resource")
            if not resource_client:
                return False
            
            rgs = list(resource_client.resource_groups.list())
            logger.info(f"Encontrados {len(rgs)} resource groups")
            
            return True
            
        except Exception as e:
            logger.error(f"Teste de conexão Azure falhou: {e}")
            return False
    
    async def get_metadata(self) -> Dict[str, Any]:
        """Obtém metadados do Azure"""
        try:
            metadata = {
                "subscription_info": await self._get_subscription_info(),
                "resource_groups": await self._get_resource_groups(),
                "data_resources": await self._get_data_resources()
            }
            return metadata
            
        except Exception as e:
            logger.error(f"Erro ao obter metadados Azure: {e}")
            return {}
    
    async def _get_subscription_info(self) -> Dict[str, Any]:
        """Obtém informações da subscription"""
        try:
            resource_client = self.clients.get("resource")
            if not resource_client:
                return {}
            
            # Informações da subscription
            subscription = resource_client.subscriptions.get(self.subscription_id)
            
            return {
                "subscription_id": subscription.subscription_id,
                "display_name": subscription.display_name,
                "state": subscription.state,
                "tenant_id": subscription.tenant_id
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter info da subscription: {e}")
            return {}
    
    async def _get_resource_groups(self) -> List[Dict[str, Any]]:
        """Obtém resource groups"""
        try:
            resource_client = self.clients.get("resource")
            if not resource_client:
                return []
            
            rgs = []
            for rg in resource_client.resource_groups.list():
                rgs.append({
                    "name": rg.name,
                    "location": rg.location,
                    "id": rg.id,
                    "tags": rg.tags or {},
                    "properties": rg.properties.__dict__ if rg.properties else {}
                })
            
            return rgs
            
        except Exception as e:
            logger.error(f"Erro ao obter resource groups: {e}")
            return []
    
    async def _get_data_resources(self) -> Dict[str, List[Dict[str, Any]]]:
        """Obtém recursos relacionados a dados"""
        try:
            resources = {
                "data_factories": await self._get_data_factories(),
                "synapse_workspaces": await self._get_synapse_workspaces(),
                "storage_accounts": await self._get_storage_accounts(),
                "sql_servers": await self._get_sql_servers()
            }
            return resources
            
        except Exception as e:
            logger.error(f"Erro ao obter recursos de dados: {e}")
            return {}
    
    async def _get_data_factories(self) -> List[Dict[str, Any]]:
        """Obtém Data Factories"""
        try:
            df_client = self.clients.get("datafactory")
            if not df_client:
                return []
            
            factories = []
            for factory in df_client.factories.list():
                factory_info = {
                    "name": factory.name,
                    "location": factory.location,
                    "id": factory.id,
                    "type": factory.type,
                    "tags": factory.tags or {},
                    "properties": {}
                }
                
                # Propriedades específicas
                if hasattr(factory, 'properties'):
                    props = factory.properties
                    factory_info["properties"] = {
                        "provisioning_state": getattr(props, 'provisioning_state', None),
                        "create_time": getattr(props, 'create_time', None),
                        "version": getattr(props, 'version', None)
                    }
                
                # Pipelines do Data Factory
                if self.resource_group and factory.name:
                    try:
                        pipelines = list(df_client.pipelines.list_by_factory(
                            self.resource_group, factory.name
                        ))
                        factory_info["pipelines_count"] = len(pipelines)
                        factory_info["pipelines"] = [
                            {
                                "name": p.name,
                                "id": p.id,
                                "type": p.type
                            } for p in pipelines[:10]  # Limita a 10 para performance
                        ]
                    except Exception as e:
                        logger.warning(f"Erro ao obter pipelines do ADF {factory.name}: {e}")
                
                factories.append(factory_info)
            
            return factories
            
        except Exception as e:
            logger.error(f"Erro ao obter Data Factories: {e}")
            return []
    
    async def _get_synapse_workspaces(self) -> List[Dict[str, Any]]:
        """Obtém Synapse Workspaces"""
        try:
            synapse_client = self.clients.get("synapse")
            if not synapse_client:
                return []
            
            workspaces = []
            for workspace in synapse_client.workspaces.list():
                workspace_info = {
                    "name": workspace.name,
                    "location": workspace.location,
                    "id": workspace.id,
                    "type": workspace.type,
                    "tags": workspace.tags or {},
                    "properties": {}
                }
                
                # Propriedades específicas
                if hasattr(workspace, 'properties'):
                    props = workspace.properties
                    workspace_info["properties"] = {
                        "provisioning_state": getattr(props, 'provisioning_state', None),
                        "sql_administrator_login": getattr(props, 'sql_administrator_login', None),
                        "default_data_lake_storage": getattr(props, 'default_data_lake_storage', None)
                    }
                
                workspaces.append(workspace_info)
            
            return workspaces
            
        except Exception as e:
            logger.error(f"Erro ao obter Synapse Workspaces: {e}")
            return []
    
    async def _get_storage_accounts(self) -> List[Dict[str, Any]]:
        """Obtém Storage Accounts"""
        try:
            storage_client = self.clients.get("storage")
            if not storage_client:
                return []
            
            accounts = []
            for account in storage_client.storage_accounts.list():
                account_info = {
                    "name": account.name,
                    "location": account.location,
                    "id": account.id,
                    "type": account.type,
                    "kind": account.kind,
                    "tags": account.tags or {},
                    "properties": {}
                }
                
                # Propriedades específicas
                if hasattr(account, 'properties'):
                    props = account.properties
                    account_info["properties"] = {
                        "provisioning_state": getattr(props, 'provisioning_state', None),
                        "primary_location": getattr(props, 'primary_location', None),
                        "status_of_primary": getattr(props, 'status_of_primary', None),
                        "creation_time": getattr(props, 'creation_time', None),
                        "access_tier": getattr(props, 'access_tier', None)
                    }
                
                accounts.append(account_info)
            
            return accounts
            
        except Exception as e:
            logger.error(f"Erro ao obter Storage Accounts: {e}")
            return []
    
    async def _get_sql_servers(self) -> List[Dict[str, Any]]:
        """Obtém SQL Servers"""
        try:
            sql_client = self.clients.get("sql")
            if not sql_client:
                return []
            
            servers = []
            for server in sql_client.servers.list():
                server_info = {
                    "name": server.name,
                    "location": server.location,
                    "id": server.id,
                    "type": server.type,
                    "tags": server.tags or {},
                    "properties": {}
                }
                
                # Propriedades específicas
                if hasattr(server, 'properties'):
                    props = server.properties
                    server_info["properties"] = {
                        "state": getattr(props, 'state', None),
                        "version": getattr(props, 'version', None),
                        "administrator_login": getattr(props, 'administrator_login', None),
                        "fully_qualified_domain_name": getattr(props, 'fully_qualified_domain_name', None)
                    }
                
                # Databases do servidor
                if self.resource_group and server.name:
                    try:
                        databases = list(sql_client.databases.list_by_server(
                            self.resource_group, server.name
                        ))
                        server_info["databases_count"] = len(databases)
                        server_info["databases"] = [
                            {
                                "name": db.name,
                                "id": db.id,
                                "status": getattr(db.properties, 'status', None) if hasattr(db, 'properties') else None
                            } for db in databases[:10]  # Limita a 10 para performance
                        ]
                    except Exception as e:
                        logger.warning(f"Erro ao obter databases do SQL Server {server.name}: {e}")
                
                servers.append(server_info)
            
            return servers
            
        except Exception as e:
            logger.error(f"Erro ao obter SQL Servers: {e}")
            return []
    
    async def _get_resource_metrics(self) -> List[Dict[str, Any]]:
        """Obtém métricas de recursos"""
        try:
            monitor_client = self.clients.get("monitor")
            if not monitor_client:
                return []
            
            # Define período para métricas (últimas 24 horas)
            end_time = datetime.utcnow()
            start_time = end_time - timedelta(hours=24)
            
            metrics = []
            
            # Obtém recursos para coletar métricas
            resource_client = self.clients.get("resource")
            if resource_client:
                for resource in resource_client.resources.list():
                    try:
                        # Obtém métricas do recurso
                        resource_metrics = monitor_client.metrics.list(
                            resource_uri=resource.id,
                            timespan=f"{start_time.isoformat()}/{end_time.isoformat()}",
                            interval="PT1H",  # Intervalo de 1 hora
                            metricnames="Percentage CPU,Network In,Network Out",
                            aggregation="Average"
                        )
                        
                        metrics.append({
                            "resource_id": resource.id,
                            "resource_name": resource.name,
                            "resource_type": resource.type,
                            "metrics": [
                                {
                                    "name": metric.name.value,
                                    "unit": metric.unit,
                                    "timeseries": [
                                        {
                                            "data": [
                                                {
                                                    "timestamp": data.time_stamp,
                                                    "average": data.average,
                                                    "maximum": data.maximum,
                                                    "minimum": data.minimum
                                                } for data in ts.data
                                            ]
                                        } for ts in metric.timeseries
                                    ]
                                } for metric in resource_metrics.value
                            ]
                        })
                        
                    except Exception as e:
                        logger.warning(f"Erro ao obter métricas do recurso {resource.name}: {e}")
                        continue
            
            return metrics
            
        except Exception as e:
            logger.error(f"Erro ao obter métricas de recursos: {e}")
            return []
    
    async def _perform_sync(self, tables: Optional[List[str]] = None) -> Dict[str, Any]:
        """Implementação específica da sincronização Azure"""
        results = {
            "tables_synced": [],
            "errors": [],
            "total_records": 0,
            "data": {}
        }
        
        try:
            # 1. Sincronizar informações da subscription
            subscription_info = await self._get_subscription_info()
            results["data"]["subscription_info"] = subscription_info
            results["total_records"] += 1
            
            # 2. Sincronizar resource groups
            resource_groups = await self._get_resource_groups()
            results["data"]["resource_groups"] = resource_groups
            results["total_records"] += len(resource_groups)
            
            # 3. Sincronizar recursos de dados
            data_resources = await self._get_data_resources()
            results["data"]["data_resources"] = data_resources
            
            # Conta recursos
            for resource_type, resources in data_resources.items():
                results["total_records"] += len(resources)
                results["tables_synced"].append(f"azure_{resource_type}")
            
            # 4. Sincronizar métricas de recursos
            resource_metrics = await self._get_resource_metrics()
            results["data"]["resource_metrics"] = resource_metrics
            results["total_records"] += len(resource_metrics)
            
            logger.info(f"Azure sync concluído: {results['total_records']} registros")
            
        except Exception as e:
            error_msg = f"Erro na sincronização Azure: {e}"
            results["errors"].append(error_msg)
            logger.error(error_msg)
        
        return results

