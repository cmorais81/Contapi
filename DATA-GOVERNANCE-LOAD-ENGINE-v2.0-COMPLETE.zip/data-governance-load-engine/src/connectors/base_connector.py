"""
Classe base para conectores de dados
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
import asyncio
import logging
from datetime import datetime
from tenacity import retry, stop_after_attempt, wait_exponential

logger = logging.getLogger(__name__)


class BaseConnector(ABC):
    """Classe base para todos os conectores de dados"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.name = self.__class__.__name__
        self.connected = False
        self.last_sync = None
        self.metrics = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "last_error": None,
            "avg_response_time": 0.0
        }
    
    @abstractmethod
    async def connect(self) -> bool:
        """Estabelece conexão com a fonte de dados"""
        pass
    
    @abstractmethod
    async def disconnect(self) -> bool:
        """Encerra conexão com a fonte de dados"""
        pass
    
    @abstractmethod
    async def test_connection(self) -> bool:
        """Testa se a conexão está funcionando"""
        pass
    
    @abstractmethod
    async def get_metadata(self) -> Dict[str, Any]:
        """Obtém metadados da fonte de dados"""
        pass
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    async def execute_with_retry(self, operation, *args, **kwargs):
        """Executa operação com retry automático"""
        start_time = datetime.now()
        
        try:
            self.metrics["total_requests"] += 1
            result = await operation(*args, **kwargs)
            self.metrics["successful_requests"] += 1
            
            # Calcula tempo de resposta
            response_time = (datetime.now() - start_time).total_seconds()
            self._update_avg_response_time(response_time)
            
            return result
            
        except Exception as e:
            self.metrics["failed_requests"] += 1
            self.metrics["last_error"] = str(e)
            logger.error(f"Erro em {self.name}: {e}")
            raise
    
    def _update_avg_response_time(self, response_time: float):
        """Atualiza tempo médio de resposta"""
        total_requests = self.metrics["total_requests"]
        current_avg = self.metrics["avg_response_time"]
        
        # Média móvel simples
        self.metrics["avg_response_time"] = (
            (current_avg * (total_requests - 1) + response_time) / total_requests
        )
    
    def get_health_status(self) -> Dict[str, Any]:
        """Retorna status de saúde do conector"""
        success_rate = 0.0
        if self.metrics["total_requests"] > 0:
            success_rate = (
                self.metrics["successful_requests"] / self.metrics["total_requests"]
            ) * 100
        
        return {
            "connector_name": self.name,
            "connected": self.connected,
            "last_sync": self.last_sync,
            "success_rate_percentage": round(success_rate, 2),
            "total_requests": self.metrics["total_requests"],
            "avg_response_time_seconds": round(self.metrics["avg_response_time"], 3),
            "last_error": self.metrics["last_error"]
        }
    
    async def sync_data(self, tables: Optional[List[str]] = None) -> Dict[str, Any]:
        """Sincroniza dados da fonte"""
        if not self.connected:
            await self.connect()
        
        start_time = datetime.now()
        results = {
            "start_time": start_time,
            "tables_synced": [],
            "errors": [],
            "total_records": 0
        }
        
        try:
            # Implementação específica em cada conector
            sync_result = await self._perform_sync(tables)
            results.update(sync_result)
            
            self.last_sync = datetime.now()
            results["end_time"] = self.last_sync
            results["duration_seconds"] = (
                self.last_sync - start_time
            ).total_seconds()
            
            logger.info(f"Sincronização {self.name} concluída: {results}")
            
        except Exception as e:
            results["errors"].append(str(e))
            logger.error(f"Erro na sincronização {self.name}: {e}")
            raise
        
        return results
    
    @abstractmethod
    async def _perform_sync(self, tables: Optional[List[str]] = None) -> Dict[str, Any]:
        """Implementação específica da sincronização"""
        pass
    
    def __str__(self) -> str:
        return f"{self.name}(connected={self.connected})"
    
    def __repr__(self) -> str:
        return (
            f"{self.name}("
            f"connected={self.connected}, "
            f"last_sync={self.last_sync}, "
            f"success_rate={self.get_health_status()['success_rate_percentage']}%"
            f")"
        )

