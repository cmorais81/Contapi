"""
Conector para Azure Purview - Governança de Dados Avançada
"""

import asyncio
import logging
from typing import Any, Dict, List, Optional, Set
from datetime import datetime, timedelta
import json
import uuid
import aiohttp
from urllib.parse import urljoin

from azure.identity.aio import ClientSecretCredential, DefaultAzureCredential
from azure.core.exceptions import AzureError

from .base_connector import BaseConnector

logger = logging.getLogger(__name__)


class AzurePurviewConnector(BaseConnector):
    """Conector para Azure Purview - Catálogo de Dados e Governança"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        
        # Configurações específicas do Purview
        self.purview_account_name = config.get("purview_account_name")
        self.tenant_id = config.get("tenant_id")
        self.client_id = config.get("client_id")
        self.client_secret = config.get("client_secret")
        
        # URLs das APIs do Purview
        self.catalog_endpoint = f"https://{self.purview_account_name}.purview.azure.com"
        self.scanning_endpoint = f"https://{self.purview_account_name}.scan.purview.azure.com"
        self.guardian_endpoint = f"https://{self.purview_account_name}.guardian.purview.azure.com"
        
        # Clientes e sessões
        self.credential = None
        self.http_session = None
        self.access_token = None
        self.token_expires_at = None
        
        # Cache para otimização
        self.entity_cache = {}
        self.classification_cache = {}
        self.glossary_cache = {}
        
        # Configurações de rate limiting
        self.max_concurrent_requests = config.get("max_concurrent_requests", 10)
        self.requests_per_second = config.get("requests_per_second", 20)
        
        # Semáforo para controle de concorrência
        self.semaphore = asyncio.Semaphore(self.max_concurrent_requests)
        self.rate_limiter = asyncio.Semaphore(self.requests_per_second)
    
    async def connect(self) -> bool:
        """Estabelece conexão com Azure Purview"""
        try:
            logger.info(f"Conectando ao Azure Purview: {self.purview_account_name}")
            
            # Inicializa credencial
            if self.client_id and self.client_secret and self.tenant_id:
                self.credential = ClientSecretCredential(
                    tenant_id=self.tenant_id,
                    client_id=self.client_id,
                    client_secret=self.client_secret
                )
            else:
                self.credential = DefaultAzureCredential()
            
            # Inicializa sessão HTTP
            self.http_session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=300),
                connector=aiohttp.TCPConnector(limit=50)
            )
            
            # Obtém token de acesso
            await self._refresh_access_token()
            
            # Testa conectividade
            if await self.test_connection():
                self.connected = True
                logger.info(f"Conectado ao Azure Purview: {self.purview_account_name}")
                return True
            else:
                raise Exception("Falha no teste de conectividade")
                
        except Exception as e:
            logger.error(f"Erro ao conectar Azure Purview: {e}")
            self.connected = False
            return False
    
    async def disconnect(self) -> bool:
        """Encerra conexão com Azure Purview"""
        try:
            if self.http_session:
                await self.http_session.close()
            
            self.connected = False
            logger.info("Desconectado do Azure Purview")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao desconectar Azure Purview: {e}")
            return False
    
    async def test_connection(self) -> bool:
        """Testa conexão com Azure Purview"""
        try:
            # Testa API do catálogo
            url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/types/typedefs"
            
            async with self.semaphore:
                async with self.http_session.get(
                    url, 
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        logger.info("Teste de conectividade Azure Purview bem-sucedido")
                        return True
                    else:
                        logger.error(f"Teste de conectividade falhou: {response.status}")
                        return False
                        
        except Exception as e:
            logger.error(f"Teste de conectividade Azure Purview falhou: {e}")
            return False
    
    async def _refresh_access_token(self):
        """Atualiza token de acesso"""
        try:
            # Scope para APIs do Purview
            scope = "https://purview.azure.net/.default"
            
            token = await self.credential.get_token(scope)
            self.access_token = token.token
            self.token_expires_at = datetime.now() + timedelta(seconds=token.expires_on - 300)  # 5min buffer
            
            logger.debug("Token de acesso Azure Purview atualizado")
            
        except Exception as e:
            logger.error(f"Erro ao atualizar token Azure Purview: {e}")
            raise
    
    async def _get_auth_headers(self) -> Dict[str, str]:
        """Obtém headers de autenticação"""
        # Verifica se token precisa ser renovado
        if not self.access_token or datetime.now() >= self.token_expires_at:
            await self._refresh_access_token()
        
        return {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
    
    async def get_metadata(self) -> Dict[str, Any]:
        """Obtém metadados completos do Azure Purview"""
        try:
            logger.info("Coletando metadados do Azure Purview...")
            
            metadata = {
                "account_info": await self._get_account_info(),
                "data_sources": await self._get_data_sources(),
                "entities": await self._get_entities(),
                "classifications": await self._get_classifications(),
                "glossary": await self._get_glossary(),
                "lineage": await self._get_lineage_info(),
                "scan_results": await self._get_scan_results(),
                "insights": await self._get_insights()
            }
            
            logger.info(f"Metadados coletados: {sum(len(v) if isinstance(v, list) else 1 for v in metadata.values())} itens")
            return metadata
            
        except Exception as e:
            logger.error(f"Erro ao coletar metadados Azure Purview: {e}")
            return {}
    
    async def _get_account_info(self) -> Dict[str, Any]:
        """Obtém informações da conta Purview"""
        try:
            url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/admin/version"
            
            async with self.semaphore:
                async with self.http_session.get(
                    url, 
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            "account_name": self.purview_account_name,
                            "version": data,
                            "endpoints": {
                                "catalog": self.catalog_endpoint,
                                "scanning": self.scanning_endpoint,
                                "guardian": self.guardian_endpoint
                            }
                        }
                    else:
                        logger.warning(f"Erro ao obter info da conta: {response.status}")
                        return {}
                        
        except Exception as e:
            logger.error(f"Erro ao obter informações da conta: {e}")
            return {}
    
    async def _get_data_sources(self) -> List[Dict[str, Any]]:
        """Obtém fontes de dados registradas"""
        try:
            url = f"{self.scanning_endpoint}/datasources"
            
            async with self.semaphore:
                async with self.http_session.get(
                    url, 
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        sources = data.get("value", [])
                        
                        logger.info(f"Encontradas {len(sources)} fontes de dados")
                        return sources
                    else:
                        logger.warning(f"Erro ao obter fontes de dados: {response.status}")
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter fontes de dados: {e}")
            return []
    
    async def _get_entities(self) -> List[Dict[str, Any]]:
        """Obtém entidades do catálogo"""
        try:
            entities = []
            
            # Busca diferentes tipos de entidades
            entity_types = [
                "DataSet", "Table", "Column", "Database", "Schema",
                "Process", "Pipeline", "Job", "Notebook"
            ]
            
            for entity_type in entity_types:
                type_entities = await self._get_entities_by_type(entity_type)
                entities.extend(type_entities)
            
            logger.info(f"Coletadas {len(entities)} entidades")
            return entities
            
        except Exception as e:
            logger.error(f"Erro ao obter entidades: {e}")
            return []
    
    async def _get_entities_by_type(self, entity_type: str) -> List[Dict[str, Any]]:
        """Obtém entidades de um tipo específico"""
        try:
            url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/search/basic"
            
            payload = {
                "typeName": entity_type,
                "limit": 1000,
                "offset": 0
            }
            
            entities = []
            
            async with self.semaphore:
                async with self.http_session.post(
                    url,
                    headers=await self._get_auth_headers(),
                    json=payload
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        entities = data.get("entities", [])
                        
                        # Enriquece entidades com detalhes
                        enriched_entities = []
                        for entity in entities:
                            if entity.get("guid"):
                                detailed_entity = await self._get_entity_details(entity["guid"])
                                if detailed_entity:
                                    enriched_entities.append(detailed_entity)
                        
                        logger.debug(f"Coletadas {len(enriched_entities)} entidades do tipo {entity_type}")
                        return enriched_entities
                    else:
                        logger.warning(f"Erro ao buscar entidades {entity_type}: {response.status}")
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter entidades do tipo {entity_type}: {e}")
            return []
    
    async def _get_entity_details(self, entity_guid: str) -> Optional[Dict[str, Any]]:
        """Obtém detalhes de uma entidade específica"""
        try:
            # Verifica cache primeiro
            if entity_guid in self.entity_cache:
                return self.entity_cache[entity_guid]
            
            url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/entity/guid/{entity_guid}"
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        entity_data = await response.json()
                        entity = entity_data.get("entity", {})
                        
                        # Adiciona ao cache
                        self.entity_cache[entity_guid] = entity
                        
                        return entity
                    else:
                        logger.warning(f"Erro ao obter detalhes da entidade {entity_guid}: {response.status}")
                        return None
                        
        except Exception as e:
            logger.error(f"Erro ao obter detalhes da entidade {entity_guid}: {e}")
            return None
    
    async def _get_classifications(self) -> List[Dict[str, Any]]:
        """Obtém classificações de dados"""
        try:
            url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/types/classificationdef"
            
            async with self.semaphore:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        classifications = data.get("classificationDefs", [])
                        
                        # Enriquece com estatísticas de uso
                        enriched_classifications = []
                        for classification in classifications:
                            enriched = await self._enrich_classification(classification)
                            enriched_classifications.append(enriched)
                        
                        logger.info(f"Coletadas {len(enriched_classifications)} classificações")
                        return enriched_classifications
                    else:
                        logger.warning(f"Erro ao obter classificações: {response.status}")
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter classificações: {e}")
            return []
    
    async def _enrich_classification(self, classification: Dict[str, Any]) -> Dict[str, Any]:
        """Enriquece classificação com estatísticas de uso"""
        try:
            classification_name = classification.get("name")
            if not classification_name:
                return classification
            
            # Busca entidades com esta classificação
            url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/search/basic"
            payload = {
                "classification": classification_name,
                "limit": 1000
            }
            
            async with self.rate_limiter:
                async with self.http_session.post(
                    url,
                    headers=await self._get_auth_headers(),
                    json=payload
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        entities_count = len(data.get("entities", []))
                        
                        classification["usage_statistics"] = {
                            "entities_count": entities_count,
                            "last_updated": datetime.now().isoformat()
                        }
                    
            return classification
            
        except Exception as e:
            logger.error(f"Erro ao enriquecer classificação {classification.get('name')}: {e}")
            return classification
    
    async def _get_glossary(self) -> List[Dict[str, Any]]:
        """Obtém glossário de negócio"""
        try:
            # Primeiro obtém todos os glossários
            glossaries = await self._get_glossaries()
            
            all_terms = []
            for glossary in glossaries:
                glossary_guid = glossary.get("guid")
                if glossary_guid:
                    terms = await self._get_glossary_terms(glossary_guid)
                    all_terms.extend(terms)
            
            logger.info(f"Coletados {len(all_terms)} termos do glossário")
            return all_terms
            
        except Exception as e:
            logger.error(f"Erro ao obter glossário: {e}")
            return []
    
    async def _get_glossaries(self) -> List[Dict[str, Any]]:
        """Obtém lista de glossários"""
        try:
            url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/glossary"
            
            async with self.semaphore:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        glossaries = await response.json()
                        return glossaries if isinstance(glossaries, list) else [glossaries]
                    else:
                        logger.warning(f"Erro ao obter glossários: {response.status}")
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter glossários: {e}")
            return []
    
    async def _get_glossary_terms(self, glossary_guid: str) -> List[Dict[str, Any]]:
        """Obtém termos de um glossário específico"""
        try:
            url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/glossary/{glossary_guid}/terms"
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        terms = await response.json()
                        
                        # Enriquece termos com detalhes
                        enriched_terms = []
                        for term in terms:
                            term_guid = term.get("termGuid")
                            if term_guid:
                                detailed_term = await self._get_term_details(term_guid)
                                if detailed_term:
                                    enriched_terms.append(detailed_term)
                        
                        return enriched_terms
                    else:
                        logger.warning(f"Erro ao obter termos do glossário {glossary_guid}: {response.status}")
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter termos do glossário {glossary_guid}: {e}")
            return []
    
    async def _get_term_details(self, term_guid: str) -> Optional[Dict[str, Any]]:
        """Obtém detalhes de um termo do glossário"""
        try:
            url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/glossary/term/{term_guid}"
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        term_details = await response.json()
                        return term_details
                    else:
                        logger.warning(f"Erro ao obter detalhes do termo {term_guid}: {response.status}")
                        return None
                        
        except Exception as e:
            logger.error(f"Erro ao obter detalhes do termo {term_guid}: {e}")
            return None
    
    async def _get_lineage_info(self) -> List[Dict[str, Any]]:
        """Obtém informações de linhagem"""
        try:
            lineage_data = []
            
            # Obtém linhagem para entidades principais
            entities = await self._get_key_entities_for_lineage()
            
            for entity in entities:
                entity_guid = entity.get("guid")
                if entity_guid:
                    lineage = await self._get_entity_lineage(entity_guid)
                    if lineage:
                        lineage_data.append(lineage)
            
            logger.info(f"Coletadas {len(lineage_data)} informações de linhagem")
            return lineage_data
            
        except Exception as e:
            logger.error(f"Erro ao obter linhagem: {e}")
            return []
    
    async def _get_key_entities_for_lineage(self) -> List[Dict[str, Any]]:
        """Obtém entidades principais para análise de linhagem"""
        try:
            # Busca tabelas e datasets principais
            url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/search/basic"
            payload = {
                "typeName": "Table",
                "limit": 100  # Limita para performance
            }
            
            async with self.semaphore:
                async with self.http_session.post(
                    url,
                    headers=await self._get_auth_headers(),
                    json=payload
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("entities", [])
                    else:
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter entidades para linhagem: {e}")
            return []
    
    async def _get_entity_lineage(self, entity_guid: str) -> Optional[Dict[str, Any]]:
        """Obtém linhagem de uma entidade específica"""
        try:
            url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/lineage/{entity_guid}"
            params = {
                "direction": "BOTH",
                "depth": 3
            }
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers(),
                    params=params
                ) as response:
                    if response.status == 200:
                        lineage_data = await response.json()
                        return {
                            "entity_guid": entity_guid,
                            "lineage": lineage_data
                        }
                    else:
                        return None
                        
        except Exception as e:
            logger.error(f"Erro ao obter linhagem da entidade {entity_guid}: {e}")
            return None
    
    async def _get_scan_results(self) -> List[Dict[str, Any]]:
        """Obtém resultados de scans"""
        try:
            # Primeiro obtém lista de scans
            scans = await self._get_scans()
            
            scan_results = []
            for scan in scans:
                scan_name = scan.get("name")
                if scan_name:
                    runs = await self._get_scan_runs(scan_name)
                    scan_results.extend(runs)
            
            logger.info(f"Coletados {len(scan_results)} resultados de scan")
            return scan_results
            
        except Exception as e:
            logger.error(f"Erro ao obter resultados de scan: {e}")
            return []
    
    async def _get_scans(self) -> List[Dict[str, Any]]:
        """Obtém lista de scans configurados"""
        try:
            url = f"{self.scanning_endpoint}/scans"
            
            async with self.semaphore:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("value", [])
                    else:
                        logger.warning(f"Erro ao obter scans: {response.status}")
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter scans: {e}")
            return []
    
    async def _get_scan_runs(self, scan_name: str) -> List[Dict[str, Any]]:
        """Obtém execuções de um scan específico"""
        try:
            url = f"{self.scanning_endpoint}/scans/{scan_name}/runs"
            
            async with self.rate_limiter:
                async with self.http_session.get(
                    url,
                    headers=await self._get_auth_headers()
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        runs = data.get("value", [])
                        
                        # Adiciona nome do scan aos resultados
                        for run in runs:
                            run["scan_name"] = scan_name
                        
                        return runs
                    else:
                        return []
                        
        except Exception as e:
            logger.error(f"Erro ao obter execuções do scan {scan_name}: {e}")
            return []
    
    async def _get_insights(self) -> Dict[str, Any]:
        """Obtém insights e métricas do Purview"""
        try:
            insights = {
                "asset_distribution": await self._get_asset_distribution(),
                "classification_distribution": await self._get_classification_distribution(),
                "scan_statistics": await self._get_scan_statistics(),
                "data_source_health": await self._get_data_source_health()
            }
            
            return insights
            
        except Exception as e:
            logger.error(f"Erro ao obter insights: {e}")
            return {}
    
    async def _get_asset_distribution(self) -> Dict[str, int]:
        """Obtém distribuição de assets por tipo"""
        try:
            distribution = {}
            
            asset_types = ["Table", "Column", "Database", "Schema", "DataSet"]
            
            for asset_type in asset_types:
                url = f"{self.catalog_endpoint}/catalog/api/atlas/v2/search/basic"
                payload = {
                    "typeName": asset_type,
                    "limit": 1
                }
                
                async with self.rate_limiter:
                    async with self.http_session.post(
                        url,
                        headers=await self._get_auth_headers(),
                        json=payload
                    ) as response:
                        if response.status == 200:
                            data = await response.json()
                            distribution[asset_type] = data.get("approximateCount", 0)
            
            return distribution
            
        except Exception as e:
            logger.error(f"Erro ao obter distribuição de assets: {e}")
            return {}
    
    async def _get_classification_distribution(self) -> Dict[str, int]:
        """Obtém distribuição de classificações"""
        try:
            # Implementação simplificada - em produção seria mais detalhada
            return {
                "PII": 0,
                "Confidential": 0,
                "Public": 0,
                "Internal": 0
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter distribuição de classificações: {e}")
            return {}
    
    async def _get_scan_statistics(self) -> Dict[str, Any]:
        """Obtém estatísticas de scans"""
        try:
            scans = await self._get_scans()
            
            total_scans = len(scans)
            active_scans = len([s for s in scans if s.get("properties", {}).get("state") == "Running"])
            
            return {
                "total_scans": total_scans,
                "active_scans": active_scans,
                "last_scan_time": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas de scan: {e}")
            return {}
    
    async def _get_data_source_health(self) -> Dict[str, Any]:
        """Obtém saúde das fontes de dados"""
        try:
            sources = await self._get_data_sources()
            
            total_sources = len(sources)
            healthy_sources = len([s for s in sources if s.get("properties", {}).get("state") == "Online"])
            
            return {
                "total_sources": total_sources,
                "healthy_sources": healthy_sources,
                "health_percentage": (healthy_sources / total_sources * 100) if total_sources > 0 else 0
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter saúde das fontes: {e}")
            return {}
    
    async def _perform_sync(self, tables: Optional[List[str]] = None) -> Dict[str, Any]:
        """Implementação específica da sincronização Purview"""
        results = {
            "tables_synced": [],
            "errors": [],
            "total_records": 0,
            "data": {}
        }
        
        try:
            logger.info("Iniciando sincronização Azure Purview...")
            
            # Coleta metadados completos
            metadata = await self.get_metadata()
            results["data"] = metadata
            
            # Conta registros coletados
            for key, value in metadata.items():
                if isinstance(value, list):
                    results["total_records"] += len(value)
                    results["tables_synced"].append(f"purview_{key}")
                elif isinstance(value, dict) and value:
                    results["total_records"] += 1
                    results["tables_synced"].append(f"purview_{key}")
            
            logger.info(f"Sincronização Purview concluída: {results['total_records']} registros")
            
        except Exception as e:
            error_msg = f"Erro na sincronização Purview: {e}"
            results["errors"].append(error_msg)
            logger.error(error_msg)
        
        return results
    
    def get_health_status(self) -> Dict[str, Any]:
        """Retorna status de saúde do conector"""
        return {
            "connected": self.connected,
            "purview_account": self.purview_account_name,
            "endpoints": {
                "catalog": self.catalog_endpoint,
                "scanning": self.scanning_endpoint,
                "guardian": self.guardian_endpoint
            },
            "token_valid": self.access_token is not None and datetime.now() < self.token_expires_at,
            "cache_size": {
                "entities": len(self.entity_cache),
                "classifications": len(self.classification_cache),
                "glossary": len(self.glossary_cache)
            },
            "last_sync": getattr(self, 'last_sync_time', None)
        }

