"""
Conectores para diferentes fontes de dados
"""

from .base_connector import BaseConnector
from .unity_catalog import UnityCatalogConnector
from .azure_connector import AzureConnector
from .azure_purview import AzurePurviewConnector
from .informatica_axon import InformaticaAxonConnector

__all__ = [
    "BaseConnector",
    "UnityCatalogConnector", 
    "AzureConnector",
    "AzurePurviewConnector",
    "InformaticaAxonConnector"
]

