"""
Loaders para persistência de dados
"""

from .database_loader import DatabaseLoader

__all__ = ["DatabaseLoader"]

