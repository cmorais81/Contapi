"""
Loader para persistência no banco de dados
"""

import logging
from typing import Any, Dict, List, Optional
from datetime import datetime
import asyncio
import json

import asyncpg
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker

from ..config import get_settings

logger = logging.getLogger(__name__)


class DatabaseLoader:
    """Loader para persistência no banco de dados"""
    
    def __init__(self):
        self.settings = get_settings()
        self.engine = None
        self.session_factory = None
        self.initialized = False
        
        # Mapeamento de tabelas para o modelo de governança
        self.table_mappings = {
            "data_contracts": "data_contracts",
            "contract_versions": "contract_versions",
            "contract_layouts": "contract_layouts",
            "data_objects": "data_objects",
            "data_object_properties": "data_object_properties",
            "data_lineage": "data_lineage",
            "users": "users",
            "groups": "groups",
            "user_groups": "user_groups",
            "permissions": "permissions",
            "group_permissions": "group_permissions",
            "cluster_metrics": "cluster_metrics",
            "job_metrics": "job_metrics",
            "query_metrics": "query_metrics",
            "storage_metrics": "storage_metrics",
            "tool_integrations": "tool_integrations",
            "sync_executions": "sync_executions",
            "sync_errors": "sync_errors",
            "audit_log": "audit_log",
            "data_quality_aggregates": "data_quality_aggregates",
            "data_anomaly_detection": "data_anomaly_detection",
            "data_classification_results": "data_classification_results"
        }
    
    async def initialize(self):
        """Inicializa o loader"""
        try:
            # Cria engine assíncrono
            self.engine = create_async_engine(
                self.settings.database.url,
                pool_size=self.settings.database.pool_size,
                max_overflow=self.settings.database.max_overflow,
                echo=self.settings.database.echo
            )
            
            # Cria factory de sessões
            self.session_factory = sessionmaker(
                self.engine,
                class_=AsyncSession,
                expire_on_commit=False
            )
            
            # Testa conexão
            await self._test_connection()
            
            self.initialized = True
            logger.info("DatabaseLoader inicializado com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao inicializar DatabaseLoader: {e}")
            raise
    
    async def _test_connection(self):
        """Testa conexão com o banco"""
        try:
            async with self.engine.begin() as conn:
                result = await conn.execute("SELECT 1")
                await result.fetchone()
            
            logger.info("Conexão com banco de dados testada com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao testar conexão com banco: {e}")
            raise
    
    async def load(self, connector_name: str, transformed_data: Dict[str, Any]) -> Dict[str, Any]:
        """Carrega dados transformados no banco"""
        if not self.initialized:
            await self.initialize()
        
        load_result = {
            "connector": connector_name,
            "timestamp": datetime.now(),
            "loaded_records": 0,
            "errors": [],
            "tables_affected": [],
            "execution_id": None
        }
        
        try:
            # Registra execução de sincronização
            execution_id = await self._register_sync_execution(connector_name, transformed_data)
            load_result["execution_id"] = execution_id
            
            records = transformed_data.get("records", [])
            
            if not records:
                logger.warning(f"Nenhum registro para carregar de {connector_name}")
                return load_result
            
            # Agrupa registros por tabela
            records_by_table = {}
            for record in records:
                table_name = record.get("table")
                if table_name:
                    if table_name not in records_by_table:
                        records_by_table[table_name] = []
                    records_by_table[table_name].append(record.get("data", {}))
            
            # Carrega dados por tabela
            async with self.session_factory() as session:
                try:
                    for table_name, table_records in records_by_table.items():
                        try:
                            loaded_count = await self._load_table_records(
                                session, table_name, table_records
                            )
                            
                            load_result["loaded_records"] += loaded_count
                            load_result["tables_affected"].append({
                                "table": table_name,
                                "records": loaded_count
                            })
                            
                            logger.info(f"Carregados {loaded_count} registros na tabela {table_name}")
                            
                        except Exception as e:
                            error_msg = f"Erro ao carregar tabela {table_name}: {e}"
                            load_result["errors"].append(error_msg)
                            logger.error(error_msg)
                    
                    # Commit da transação
                    await session.commit()
                    
                    # Atualiza execução como bem-sucedida
                    await self._update_sync_execution(execution_id, "success", load_result)
                    
                except Exception as e:
                    await session.rollback()
                    raise e
            
            logger.info(f"Load {connector_name} concluído: {load_result['loaded_records']} registros")
            
        except Exception as e:
            error_msg = f"Erro no load {connector_name}: {e}"
            load_result["errors"].append(error_msg)
            logger.error(error_msg)
            
            # Registra erro na execução
            if load_result["execution_id"]:
                await self._update_sync_execution(
                    load_result["execution_id"], "failed", load_result
                )
        
        return load_result
    
    async def _register_sync_execution(self, connector_name: str, transformed_data: Dict[str, Any]) -> str:
        """Registra execução de sincronização"""
        try:
            execution_id = f"sync_{connector_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            # Simula inserção na tabela sync_executions
            # Em implementação real, usaria SQLAlchemy models
            logger.info(f"Registrada execução de sincronização: {execution_id}")
            
            return execution_id
            
        except Exception as e:
            logger.error(f"Erro ao registrar execução: {e}")
            return f"sync_{connector_name}_error"
    
    async def _update_sync_execution(self, execution_id: str, status: str, result: Dict[str, Any]):
        """Atualiza status da execução"""
        try:
            # Simula atualização na tabela sync_executions
            logger.info(f"Execução {execution_id} atualizada para status: {status}")
            
        except Exception as e:
            logger.error(f"Erro ao atualizar execução {execution_id}: {e}")
    
    async def _load_table_records(self, session: AsyncSession, table_name: str, records: List[Dict]) -> int:
        """Carrega registros em uma tabela específica"""
        if not records:
            return 0
        
        try:
            # Mapeia nome da tabela
            mapped_table = self.table_mappings.get(table_name, table_name)
            
            # Em implementação real, usaria SQLAlchemy models
            # Por agora, simula a inserção
            
            if mapped_table == "data_objects":
                return await self._load_data_objects(session, records)
            elif mapped_table == "data_object_properties":
                return await self._load_data_object_properties(session, records)
            elif mapped_table == "users":
                return await self._load_users(session, records)
            elif mapped_table == "groups":
                return await self._load_groups(session, records)
            elif mapped_table == "cluster_metrics":
                return await self._load_cluster_metrics(session, records)
            elif mapped_table == "job_metrics":
                return await self._load_job_metrics(session, records)
            elif mapped_table == "query_metrics":
                return await self._load_query_metrics(session, records)
            elif mapped_table == "storage_metrics":
                return await self._load_storage_metrics(session, records)
            elif mapped_table == "tool_integrations":
                return await self._load_tool_integrations(session, records)
            elif mapped_table == "data_lineage":
                return await self._load_data_lineage(session, records)
            elif mapped_table == "data_quality_aggregates":
                return await self._load_data_quality_aggregates(session, records)
            elif mapped_table == "data_anomaly_detection":
                return await self._load_data_anomaly_detection(session, records)
            elif mapped_table == "data_classification_results":
                return await self._load_data_classification_results(session, records)
            else:
                logger.warning(f"Tabela {mapped_table} não mapeada - simulando inserção")
                return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao carregar registros na tabela {table_name}: {e}")
            raise
    
    # Métodos específicos para cada tabela (simulados)
    
    async def _load_data_objects(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega objetos de dados"""
        # Simula inserção usando SQL direto
        try:
            for record in records:
                # Em implementação real, usaria upsert baseado em chaves únicas
                logger.debug(f"Inserindo data_object: {record.get('object_name')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir data_objects: {e}")
            raise
    
    async def _load_data_object_properties(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega propriedades de objetos"""
        try:
            for record in records:
                logger.debug(f"Inserindo property: {record.get('property_name')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir data_object_properties: {e}")
            raise
    
    async def _load_users(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega usuários"""
        try:
            for record in records:
                logger.debug(f"Inserindo user: {record.get('username')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir users: {e}")
            raise
    
    async def _load_groups(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega grupos"""
        try:
            for record in records:
                logger.debug(f"Inserindo group: {record.get('group_name')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir groups: {e}")
            raise
    
    async def _load_cluster_metrics(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega métricas de cluster"""
        try:
            for record in records:
                logger.debug(f"Inserindo cluster_metric: {record.get('cluster_name')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir cluster_metrics: {e}")
            raise
    
    async def _load_job_metrics(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega métricas de job"""
        try:
            for record in records:
                logger.debug(f"Inserindo job_metric: {record.get('job_name')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir job_metrics: {e}")
            raise
    
    async def _load_query_metrics(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega métricas de query"""
        try:
            for record in records:
                logger.debug(f"Inserindo query_metric: {record.get('query_id')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir query_metrics: {e}")
            raise
    
    async def _load_storage_metrics(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega métricas de storage"""
        try:
            for record in records:
                logger.debug(f"Inserindo storage_metric: {record.get('storage_account_name', record.get('resource_name'))}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir storage_metrics: {e}")
            raise
    
    async def _load_tool_integrations(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega integrações de ferramentas"""
        try:
            for record in records:
                logger.debug(f"Inserindo tool_integration: {record.get('tool_name')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir tool_integrations: {e}")
            raise
    
    async def _load_data_lineage(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega linhagem de dados"""
        try:
            for record in records:
                logger.debug(f"Inserindo lineage: {record.get('source_object_name')} -> {record.get('target_object_name')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir data_lineage: {e}")
            raise
    
    async def _load_data_quality_aggregates(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega agregados de qualidade"""
        try:
            for record in records:
                logger.debug(f"Inserindo quality_aggregate: {record.get('object_name')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir data_quality_aggregates: {e}")
            raise
    
    async def _load_data_anomaly_detection(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega detecções de anomalia"""
        try:
            for record in records:
                logger.debug(f"Inserindo anomaly_detection: {record.get('object_name')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir data_anomaly_detection: {e}")
            raise
    
    async def _load_data_classification_results(self, session: AsyncSession, records: List[Dict]) -> int:
        """Carrega resultados de classificação"""
        try:
            for record in records:
                logger.debug(f"Inserindo classification_result: {record.get('object_name')}")
            
            return len(records)
            
        except Exception as e:
            logger.error(f"Erro ao inserir data_classification_results: {e}")
            raise
    
    async def get_load_statistics(self) -> Dict[str, Any]:
        """Obtém estatísticas de carga"""
        try:
            # Simula consulta de estatísticas
            stats = {
                "total_records_loaded": 0,
                "tables_with_data": [],
                "last_load_timestamp": None,
                "load_frequency": {},
                "error_count": 0
            }
            
            # Em implementação real, consultaria o banco
            return stats
            
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas: {e}")
            return {}
    
    async def cleanup_old_data(self, retention_days: int = 30):
        """Remove dados antigos baseado na política de retenção"""
        try:
            cutoff_date = datetime.now() - timedelta(days=retention_days)
            
            # Em implementação real, executaria DELETE baseado em data_criacao
            logger.info(f"Limpeza de dados anteriores a {cutoff_date} simulada")
            
        except Exception as e:
            logger.error(f"Erro na limpeza de dados: {e}")
    
    async def shutdown(self):
        """Encerra o loader"""
        try:
            if self.engine:
                await self.engine.dispose()
            
            self.initialized = False
            logger.info("DatabaseLoader encerrado")
            
        except Exception as e:
            logger.error(f"Erro ao encerrar DatabaseLoader: {e}")

