# Data Governance Load Engine

## Visão Geral

O **Data Governance Load Engine** é um motor de carga de dados especializado para alimentar modelos de governança de dados, desenvolvido para integrar-se nativamente com **Unity Catalog (Databricks)** e **Azure** via Service Principal Name (SPN). Este sistema foi projetado para automatizar a coleta, transformação e carga de metadados essenciais para uma governança de dados efetiva e abrangente.

### Principais Características

- **Integração Nativa Unity Catalog**: Extração completa de metadados, linhagem, métricas de performance e controle de acesso
- **Conectividade Azure**: Integração via SPN para coleta de métricas de recursos, Data Factory, Synapse e Storage
- **Transformação Inteligente**: Processamento e normalização automática de dados para o modelo de governança
- **Detecção de Anomalias**: Algoritmos de machine learning para identificação proativa de problemas
- **Classificação Automática**: Sistema de classificação de dados baseado em padrões e conteúdo
- **Inferência de Qualidade**: Cálculo automático de métricas de qualidade de dados
- **API RESTful**: Interface completa para monitoramento e controle do motor
- **Observabilidade**: Métricas, logs e tracing distribuído para monitoramento operacional

### Arquitetura do Sistema

O motor é composto por quatro camadas principais:

1. **Camada de Conectores**: Responsável pela extração de dados das fontes
2. **Camada de Transformação**: Processamento e normalização dos dados extraídos
3. **Camada de Carga**: Persistência dos dados transformados no modelo de governança
4. **Camada de API**: Interface para controle e monitoramento do sistema

## Instalação e Configuração

### Pré-requisitos

- Python 3.11+
- PostgreSQL 12+
- Acesso ao Databricks com Unity Catalog
- Service Principal configurado no Azure
- Docker (opcional, para containerização)

### Instalação

```bash
# Clone o repositório
git clone <repository-url>
cd data-governance-load-engine

# Crie ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate  # Windows

# Instale dependências
pip install -r requirements.txt
```

### Configuração

1. **Copie o arquivo de configuração**:
```bash
cp .env.example .env
```

2. **Configure as variáveis de ambiente** no arquivo `.env`:

#### Configuração do Banco de Dados
```env
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/data_governance
```

#### Configuração do Databricks
```env
DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
DATABRICKS_TOKEN=your_databricks_token_here
UNITY_CATALOG_NAME=your_catalog_name
UNITY_CATALOG_SCHEMA=your_schema_name
```

#### Configuração do Azure
```env
AZURE_TENANT_ID=your_tenant_id_here
AZURE_CLIENT_ID=your_client_id_here
AZURE_CLIENT_SECRET=your_client_secret_here
AZURE_SUBSCRIPTION_ID=your_subscription_id_here
```

### Validação da Configuração

```bash
python -m src.config
```

Este comando validará se todas as configurações obrigatórias estão presentes e corretas.

## Uso do Sistema

### Inicialização do Motor

```python
from src.load_engine import get_load_engine

# Obter instância do motor
engine = await get_load_engine()

# Inicializar
await engine.initialize()
```

### Sincronização Completa

```python
# Sincronizar todas as fontes
result = await engine.sync_all()

print(f"Registros processados: {result['total_records']}")
print(f"Duração: {result['duration_seconds']}s")
```

### Sincronização por Conector

```python
# Sincronizar apenas Unity Catalog
uc_result = await engine.sync_connector("unity_catalog")

# Sincronizar apenas Azure
azure_result = await engine.sync_connector("azure")
```

### Monitoramento

```python
# Obter status do motor
status = await engine.get_status()

print(f"Status: {status['engine_status']}")
print(f"Conectores: {list(status['connectors'].keys())}")
print(f"Última sincronização: {status['last_sync']}")
```

## API REST

O motor inclui uma API REST completa para controle e monitoramento:

### Endpoints Principais

- `GET /health` - Status de saúde do sistema
- `POST /sync/all` - Iniciar sincronização completa
- `POST /sync/{connector}` - Sincronizar conector específico
- `GET /status` - Status detalhado do motor
- `GET /metrics` - Métricas operacionais
- `GET /connectors` - Lista de conectores disponíveis

### Executando a API

```bash
# Desenvolvimento
uvicorn src.api:app --reload --host 0.0.0.0 --port 8000

# Produção
uvicorn src.api:app --host 0.0.0.0 --port 8000 --workers 4
```

Acesse a documentação interativa em: http://localhost:8000/docs

## Conectores Disponíveis

### Unity Catalog Connector

Extrai dados completos do Unity Catalog do Databricks:

#### Dados Coletados:
- **Catálogos, Schemas e Tabelas**: Metadados completos incluindo descrições, proprietários e tags
- **Colunas e Propriedades**: Tipos de dados, constraints, comentários e classificações
- **Linhagem de Dados**: Relacionamentos upstream/downstream entre tabelas
- **Métricas de Performance**: Estatísticas de queries, jobs e clusters
- **Controle de Acesso**: Usuários, grupos e permissões granulares
- **Métricas de Storage**: Informações sobre Delta Lake e Iceberg

#### Configuração:
```env
DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
DATABRICKS_TOKEN=your_token
UNITY_CATALOG_NAME=your_catalog
UNITY_CATALOG_SCHEMA=your_schema
```

### Azure Connector

Integra com Azure via Service Principal para coleta de métricas:

#### Dados Coletados:
- **Resource Groups**: Organização de recursos por grupo
- **Data Factory**: Pipelines, atividades e execuções
- **Synapse Workspaces**: Pools SQL, Spark e pipelines
- **Storage Accounts**: Containers, blobs e métricas de uso
- **SQL Servers**: Databases, tabelas e métricas de performance
- **Métricas de Recursos**: CPU, memória, rede e storage

#### Configuração:
```env
AZURE_TENANT_ID=your_tenant_id
AZURE_CLIENT_ID=your_client_id
AZURE_CLIENT_SECRET=your_client_secret
AZURE_SUBSCRIPTION_ID=your_subscription_id
```

## Funcionalidades Avançadas

### Inferência de Qualidade

O sistema calcula automaticamente métricas de qualidade para todos os dados coletados:

- **Completude**: Porcentagem de valores não nulos
- **Unicidade**: Porcentagem de valores únicos
- **Validade**: Conformidade com padrões esperados
- **Consistência**: Coerência entre campos relacionados
- **Pontualidade**: Atualização dentro dos SLAs definidos

### Detecção de Anomalias

Algoritmos de machine learning identificam automaticamente:

- **Anomalias de Volume**: Mudanças inesperadas no volume de dados
- **Anomalias de Qualidade**: Degradação súbita da qualidade
- **Anomalias Estatísticas**: Valores fora dos padrões históricos
- **Anomalias de Schema**: Mudanças não documentadas na estrutura

### Classificação Automática

Sistema inteligente de classificação de dados:

- **Detecção de PII**: Identificação automática de dados pessoais
- **Classificação de Sensibilidade**: Público, interno, confidencial, restrito
- **Conformidade Regulatória**: LGPD, GDPR, HIPAA, PCI-DSS
- **Categorização de Negócio**: Domínios e sub-domínios automáticos

## Monitoramento e Observabilidade

### Métricas Disponíveis

- **Métricas de Sistema**: CPU, memória, rede
- **Métricas de Aplicação**: Throughput, latência, erros
- **Métricas de Negócio**: Registros processados, qualidade, cobertura

### Logs Estruturados

Todos os logs são estruturados em JSON para facilitar análise:

```json
{
  "timestamp": "2024-01-15T10:30:00Z",
  "level": "INFO",
  "component": "unity_catalog_connector",
  "message": "Sincronização concluída",
  "records_processed": 1500,
  "duration_seconds": 45.2
}
```

### Health Checks

Verificações automáticas de saúde:

- **Conectividade**: Testa conexões com todas as fontes
- **Performance**: Monitora tempos de resposta
- **Recursos**: Verifica uso de CPU, memória e disco
- **Dependências**: Valida disponibilidade de serviços externos

## Troubleshooting

### Problemas Comuns

#### Erro de Conexão Unity Catalog
```
Erro: Falha na autenticação Unity Catalog
Solução: Verificar token e permissões do workspace
```

#### Erro de Conexão Azure
```
Erro: Service Principal sem permissões
Solução: Verificar roles do SPN na subscription
```

#### Erro de Performance
```
Erro: Timeout na sincronização
Solução: Aumentar TIMEOUT_SECONDS ou reduzir BATCH_SIZE
```

### Logs de Debug

Para habilitar logs detalhados:

```env
LOG_LEVEL=DEBUG
DEBUG=true
```

### Validação de Configuração

```bash
# Testa conectividade
python -c "
from src.connectors import UnityCatalogConnector, AzureConnector
import asyncio

async def test():
    # Testa Unity Catalog
    uc = UnityCatalogConnector(config)
    print('UC:', await uc.test_connection())
    
    # Testa Azure
    az = AzureConnector(config)
    print('Azure:', await az.test_connection())

asyncio.run(test())
"
```

## Desenvolvimento

### Estrutura do Projeto

```
data-governance-load-engine/
├── src/
│   ├── connectors/          # Conectores de dados
│   ├── transformers/        # Transformação de dados
│   ├── loaders/            # Carga no banco
│   ├── api/                # API REST
│   └── utils/              # Utilitários
├── config/                 # Configurações
├── docs/                   # Documentação
├── notebooks/              # Notebooks Jupyter
├── tests/                  # Testes
└── scripts/                # Scripts utilitários
```

### Executando Testes

```bash
# Todos os testes
pytest

# Testes específicos
pytest tests/test_connectors.py

# Com cobertura
pytest --cov=src tests/
```

### Contribuindo

1. Fork o repositório
2. Crie uma branch para sua feature
3. Implemente os testes
4. Execute a suíte de testes
5. Submeta um Pull Request

## Roadmap

### Versão 1.1 (Q2 2024)
- Conector para Informatica Axon
- Integração com Apache Atlas
- Dashboard web para monitoramento

### Versão 1.2 (Q3 2024)
- Conector para AWS Glue
- Integração com dbt
- Alertas inteligentes via Slack/Teams

### Versão 2.0 (Q4 2024)
- Interface gráfica completa
- Workflows de aprovação
- Integração com ferramentas de BI

## Suporte

Para suporte técnico:
- **Email**: support@datagovernance.com
- **Slack**: #data-governance-engine
- **Issues**: GitHub Issues

## Licença

Este projeto está licenciado sob a MIT License - veja o arquivo LICENSE para detalhes.

