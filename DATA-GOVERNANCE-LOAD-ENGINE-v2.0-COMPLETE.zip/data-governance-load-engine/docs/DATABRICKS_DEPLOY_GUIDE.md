# Guia de Deploy no Databricks Free Edition

## Visão Geral

Este guia detalha como fazer o deploy do Data Governance Load Engine no Databricks Free Edition, incluindo configuração do ambiente, upload dos arquivos, configuração de credenciais e execução dos testes.

## Pré-requisitos

### 1. Conta Databricks Free Edition
- Acesse: https://login.databricks.com/?intent=SIGN_UP&provider=DB_FREE_TIER
- Crie uma conta gratuita usando email ou Google/Microsoft
- Confirme o email e complete o setup inicial

### 2. Configurações Necessárias
- Service Principal do Azure (se usando integração Azure)
- Token de acesso pessoal do Databricks
- Banco PostgreSQL (pode usar serviços gratuitos como ElephantSQL)

## Passo 1: Configuração Inicial do Workspace

### 1.1 Acesso ao Workspace
1. Faça login no Databricks Free Edition
2. Acesse seu workspace padrão
3. Navegue para a seção "Workspace" no menu lateral

### 1.2 Criação da Estrutura de Pastas
```
/Workspace/Users/seu-email/
├── data-governance-load-engine/
│   ├── src/
│   ├── config/
│   ├── notebooks/
│   └── docs/
```

## Passo 2: Upload dos Arquivos

### 2.1 Upload via Interface Web
1. No Workspace, clique em "Create" → "Folder"
2. Crie a pasta "data-governance-load-engine"
3. Upload os arquivos do projeto:
   - Arquivos Python (.py) da pasta src/
   - Notebook de execução manual
   - Arquivo requirements.txt
   - Arquivo .env.example

### 2.2 Upload via Databricks CLI (Alternativo)
```bash
# Instalar Databricks CLI
pip install databricks-cli

# Configurar autenticação
databricks configure --token

# Upload dos arquivos
databricks workspace import-dir ./data-governance-load-engine /Users/seu-email/data-governance-load-engine
```

## Passo 3: Configuração do Ambiente

### 3.1 Instalação de Dependências
Crie um notebook com o seguinte código:

```python
# Instalar dependências
%pip install -r /Workspace/Users/seu-email/data-governance-load-engine/requirements.txt

# Reiniciar Python
dbutils.library.restartPython()
```

### 3.2 Configuração de Variáveis de Ambiente
```python
# Configurar variáveis de ambiente
import os

# Databricks (obtido automaticamente)
os.environ["DATABRICKS_HOST"] = spark.conf.get("spark.databricks.workspaceUrl")
os.environ["DATABRICKS_TOKEN"] = "seu_token_aqui"

# Unity Catalog (se disponível)
os.environ["UNITY_CATALOG_NAME"] = "main"  # ou seu catálogo
os.environ["UNITY_CATALOG_SCHEMA"] = "default"

# Azure (se usando)
os.environ["AZURE_TENANT_ID"] = "seu_tenant_id"
os.environ["AZURE_CLIENT_ID"] = "seu_client_id"
os.environ["AZURE_CLIENT_SECRET"] = "seu_client_secret"
os.environ["AZURE_SUBSCRIPTION_ID"] = "seu_subscription_id"

# Database (usar serviço gratuito)
os.environ["DATABASE_URL"] = "postgresql+asyncpg://user:pass@host:5432/db"

# Feature flags
os.environ["ENABLE_UNITY_CATALOG_SYNC"] = "true"
os.environ["ENABLE_AZURE_SYNC"] = "false"  # Desabilitar se não tiver Azure
os.environ["ENABLE_QUALITY_INFERENCE"] = "true"
os.environ["ENABLE_ANOMALY_DETECTION"] = "true"
os.environ["ENABLE_AUTO_CLASSIFICATION"] = "true"
```

## Passo 4: Configuração do Unity Catalog

### 4.1 Verificação de Disponibilidade
```python
# Verificar se Unity Catalog está disponível
try:
    catalogs = spark.sql("SHOW CATALOGS").collect()
    print("Unity Catalog disponível!")
    for catalog in catalogs:
        print(f"  - {catalog.catalog}")
except Exception as e:
    print(f"Unity Catalog não disponível: {e}")
    print("Usando Hive Metastore como fallback")
```

### 4.2 Criação de Catálogo de Teste (se necessário)
```python
# Criar catálogo de teste se Unity Catalog estiver disponível
try:
    spark.sql("CREATE CATALOG IF NOT EXISTS data_governance_test")
    spark.sql("CREATE SCHEMA IF NOT EXISTS data_governance_test.metadata")
    print("Catálogo de teste criado com sucesso")
except Exception as e:
    print(f"Erro ao criar catálogo: {e}")
```

## Passo 5: Configuração do Banco de Dados

### 5.1 Opções de Banco Gratuito

#### ElephantSQL (PostgreSQL gratuito)
1. Acesse: https://www.elephantsql.com/
2. Crie conta gratuita
3. Crie uma instância "Tiny Turtle" (gratuita)
4. Obtenha a URL de conexão

#### Supabase (PostgreSQL gratuito)
1. Acesse: https://supabase.com/
2. Crie projeto gratuito
3. Obtenha credenciais de conexão

### 5.2 Criação das Tabelas
```python
# Script para criar tabelas do modelo de governança
import asyncpg
import asyncio

async def create_tables():
    conn = await asyncpg.connect("sua_database_url_aqui")
    
    # Criar tabelas principais (exemplo)
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS data_objects (
            data_object_id UUID PRIMARY KEY,
            object_name VARCHAR(255) NOT NULL,
            object_type VARCHAR(100),
            object_description TEXT,
            unity_catalog_table_id VARCHAR(255),
            delta_table_path VARCHAR(500),
            estimated_size_gb DECIMAL(15,3),
            row_count_estimate BIGINT,
            data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Adicionar outras tabelas conforme necessário
    await conn.close()

# Executar criação
await create_tables()
```

## Passo 6: Execução do Motor de Load

### 6.1 Importação e Inicialização
```python
# Adicionar caminho do projeto
import sys
sys.path.append('/Workspace/Users/seu-email/data-governance-load-engine/src')

# Importar motor de load
from load_engine import DataGovernanceLoadEngine

# Inicializar
engine = DataGovernanceLoadEngine()
await engine.initialize()
```

### 6.2 Teste de Conectividade
```python
# Testar conectores
status = await engine.get_status()
print("Status dos conectores:")
for connector, info in status['connectors'].items():
    print(f"  - {connector}: {'✅' if info['connected'] else '❌'}")
```

### 6.3 Execução de Sincronização
```python
# Sincronização completa
result = await engine.sync_all()

print(f"Sincronização concluída:")
print(f"  - Total de registros: {result['total_records']}")
print(f"  - Duração: {result['duration_seconds']:.2f}s")
print(f"  - Sucesso: {'✅' if result['success'] else '❌'}")

if result['errors']:
    print("Erros encontrados:")
    for error in result['errors']:
        print(f"  - {error}")
```

## Passo 7: Monitoramento e Validação

### 7.1 Dashboard de Monitoramento
```python
# Criar dashboard simples
import matplotlib.pyplot as plt
import pandas as pd

# Obter métricas
status = await engine.get_status()
metrics = status['metrics']

# Gráfico de registros processados
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

# Gráfico de sucessos vs falhas
labels = ['Sucessos', 'Falhas']
values = [metrics['successful_syncs'], metrics['failed_syncs']]
ax1.pie(values, labels=labels, autopct='%1.1f%%')
ax1.set_title('Taxa de Sucesso das Sincronizações')

# Gráfico de registros por conector
connector_data = []
for connector, info in status['connectors'].items():
    connector_data.append({
        'Conector': connector,
        'Registros': info.get('total_requests', 0)
    })

df = pd.DataFrame(connector_data)
if not df.empty:
    ax2.bar(df['Conector'], df['Registros'])
    ax2.set_title('Registros por Conector')
    ax2.tick_params(axis='x', rotation=45)

plt.tight_layout()
plt.show()
```

### 7.2 Validação dos Dados
```python
# Validar dados carregados
import asyncpg

async def validate_data():
    conn = await asyncpg.connect(os.environ["DATABASE_URL"])
    
    # Contar registros por tabela
    tables = [
        'data_objects', 'data_object_properties', 'users', 'groups',
        'cluster_metrics', 'job_metrics', 'query_metrics', 'storage_metrics'
    ]
    
    print("Registros por tabela:")
    for table in tables:
        try:
            count = await conn.fetchval(f"SELECT COUNT(*) FROM {table}")
            print(f"  - {table}: {count:,}")
        except Exception as e:
            print(f"  - {table}: Erro - {e}")
    
    await conn.close()

await validate_data()
```

## Passo 8: Agendamento Automático

### 8.1 Criação de Job no Databricks
1. No workspace, vá para "Workflows" → "Jobs"
2. Clique em "Create Job"
3. Configure:
   - Nome: "Data Governance Load Engine"
   - Tipo: "Notebook"
   - Notebook: Selecione o notebook de execução
   - Cluster: Use cluster compartilhado ou crie um pequeno
   - Agendamento: Diário às 6:00 AM

### 8.2 Configuração de Alertas
```python
# Configurar alertas via email (exemplo)
def send_alert(message):
    # Usar serviço de email gratuito como SendGrid
    print(f"ALERTA: {message}")

# Verificar falhas
if result['errors']:
    send_alert(f"Falhas na sincronização: {len(result['errors'])} erros")
```

## Passo 9: Otimizações para Free Edition

### 9.1 Limitações da Free Edition
- Cluster limitado (1 driver, sem workers)
- 15GB de storage
- Sem Unity Catalog completo (dependendo da região)
- Sem integração com cloud providers

### 9.2 Adaptações Necessárias
```python
# Configurações otimizadas para Free Edition
os.environ["BATCH_SIZE"] = "100"  # Reduzir batch size
os.environ["TIMEOUT_SECONDS"] = "300"  # Aumentar timeout
os.environ["MAX_RETRIES"] = "3"
os.environ["ENABLE_PARALLEL_PROCESSING"] = "false"  # Desabilitar paralelismo
```

### 9.3 Fallbacks para Limitações
```python
# Fallback para Hive Metastore se Unity Catalog não disponível
def get_tables_fallback():
    try:
        # Tentar Unity Catalog primeiro
        return spark.sql("SHOW TABLES IN catalog.schema").collect()
    except:
        # Fallback para Hive Metastore
        return spark.sql("SHOW TABLES").collect()
```

## Passo 10: Troubleshooting

### 10.1 Problemas Comuns

#### Erro de Memória
```python
# Reduzir uso de memória
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
```

#### Timeout de Conexão
```python
# Aumentar timeouts
os.environ["CONNECTION_TIMEOUT"] = "60"
os.environ["READ_TIMEOUT"] = "120"
```

#### Erro de Permissões
```python
# Verificar permissões
try:
    spark.sql("SHOW CATALOGS")
    print("Permissões OK")
except Exception as e:
    print(f"Erro de permissões: {e}")
```

### 10.2 Logs e Debug
```python
# Habilitar logs detalhados
import logging
logging.basicConfig(level=logging.DEBUG)

# Verificar configurações
from config import validate_configuration
if not validate_configuration():
    print("❌ Configuração inválida")
else:
    print("✅ Configuração válida")
```

## Conclusão

Este guia fornece um roteiro completo para deploy do Data Governance Load Engine no Databricks Free Edition. As limitações da versão gratuita podem impactar a performance, mas o sistema funcionará adequadamente para testes e desenvolvimento.

### Próximos Passos
1. Configurar conta Databricks Free Edition
2. Seguir os passos de configuração
3. Executar testes de conectividade
4. Realizar sincronização inicial
5. Configurar monitoramento
6. Agendar execuções automáticas

### Suporte
Para problemas específicos:
- Verificar logs detalhados
- Consultar documentação do Databricks
- Usar fallbacks para limitações da Free Edition

