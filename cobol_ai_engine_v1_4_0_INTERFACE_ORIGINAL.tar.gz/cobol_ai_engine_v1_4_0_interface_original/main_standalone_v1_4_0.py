#!/usr/bin/env python3
"""
COBOL AI Engine v1.4.0 - Sistema de Análise de Programas COBOL (Versão Standalone)
Sistema completo de análise de programas COBOL com IA, com correções críticas implementadas.

CORREÇÕES v1.4.0:
- Renovação automática de token (HTTP 401)
- Tratamento de HTTP 201 e 202
- Sistema de auditoria completo
- Logs detalhados e estruturados

USO:
python main_standalone_v1_4_0.py --fontes examples/fontes.txt --books examples/BOOKS.txt --output minha_analise --pdf
"""

import argparse
import json
import logging
import os
import sys
import time
import hashlib
import uuid
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import requests
import urllib3
from urllib.parse import urljoin

# Desabilitar warnings SSL se necessário
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class COBOLProgram:
    """Representa um programa COBOL."""
    def __init__(self, name: str, content: str):
        self.name = name
        self.content = content

class TokenManager:
    """Gerenciador de tokens com renovação automática."""
    
    def __init__(self, client_id: str, client_secret: str):
        self.client_id = client_id
        self.client_secret = client_secret
        self.token = None
        self.token_expires_at = None
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def get_valid_token(self) -> Optional[str]:
        """Obtém um token válido, renovando se necessário."""
        if self.is_token_valid():
            return self.token
        
        return self.refresh_token()
    
    def is_token_valid(self) -> bool:
        """Verifica se o token atual é válido."""
        if not self.token or not self.token_expires_at:
            return False
        
        # Buffer de 5 minutos antes da expiração
        buffer_time = timedelta(minutes=5)
        return datetime.now() < (self.token_expires_at - buffer_time)
    
    def refresh_token(self) -> Optional[str]:
        """Renova o token de acesso."""
        try:
            self.logger.info("Renovando token de acesso...")
            
            # URL e dados para obtenção do token
            token_url = "https://luzia.santander.com.br/oauth/token"
            
            data = {
                'grant_type': 'client_credentials',
                'client_id': self.client_id,
                'client_secret': self.client_secret
            }
            
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            
            response = requests.post(token_url, data=data, headers=headers, timeout=30)
            
            if response.status_code == 200:
                token_data = response.json()
                self.token = token_data.get('access_token')
                expires_in = token_data.get('expires_in', 3600)  # Default 1 hora
                self.token_expires_at = datetime.now() + timedelta(seconds=expires_in)
                
                self.logger.info(f"Token renovado com sucesso. Expira em: {self.token_expires_at}")
                return self.token
            else:
                self.logger.error(f"Falha ao renovar token: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            self.logger.error(f"Erro ao renovar token: {e}")
            return None

class LuziaProvider:
    """Provedor LuzIA com correções implementadas."""
    
    def __init__(self, client_id: str, client_secret: str):
        self.client_id = client_id
        self.client_secret = client_secret
        self.token_manager = TokenManager(client_id, client_secret)
        self.base_url = "https://luzia.santander.com.br"
        self.logger = logging.getLogger(self.__class__.__name__)
    
    def test_connectivity(self) -> bool:
        """Testa conectividade com a API LuzIA."""
        try:
            token = self.token_manager.get_valid_token()
            return token is not None
        except Exception as e:
            self.logger.error(f"Erro no teste de conectividade: {e}")
            return False
    
    def analyze_program(self, program_content: str, books_content: List[str] = None) -> Dict[str, Any]:
        """Analisa um programa COBOL usando a API LuzIA."""
        try:
            token = self.token_manager.get_valid_token()
            if not token:
                return {
                    'success': False,
                    'error': 'Falha ao obter token de acesso',
                    'analysis': '',
                    'tokens_used': 0
                }
            
            # Preparar payload
            payload = {
                "model": "aws-claude-3-5-sonnet",
                "messages": [
                    {
                        "role": "user",
                        "content": self._create_analysis_prompt(program_content, books_content)
                    }
                ],
                "max_tokens": 4000,
                "temperature": 0.1
            }
            
            headers = {
                'Authorization': f'Bearer {token}',
                'Content-Type': 'application/json'
            }
            
            # Fazer requisição
            url = urljoin(self.base_url, "/v1/chat/completions")
            response = requests.post(url, json=payload, headers=headers, timeout=120)
            
            # Processar resposta com tratamento robusto de HTTP
            return self._handle_http_response(response)
            
        except Exception as e:
            self.logger.error(f"Erro na análise: {e}")
            return {
                'success': False,
                'error': str(e),
                'analysis': '',
                'tokens_used': 0
            }
    
    def _handle_http_response(self, response: requests.Response) -> Dict[str, Any]:
        """Trata resposta HTTP com suporte para códigos 200, 201, 202."""
        
        # CORREÇÃO PRINCIPAL: Códigos de sucesso incluem 201 e 202
        if response.status_code in [200, 201, 202]:
            self.logger.info(f"Resposta HTTP {response.status_code} processada com sucesso")
            
            try:
                response_data = response.json()
                
                # Extrair conteúdo da resposta
                content = self._extract_content_from_response(response_data)
                tokens_used = self._extract_tokens_from_response(response_data)
                
                return {
                    'success': True,
                    'analysis': content,
                    'tokens_used': tokens_used,
                    'status_code': response.status_code
                }
                
            except json.JSONDecodeError as e:
                self.logger.error(f"Erro ao decodificar JSON: {e}")
                return {
                    'success': False,
                    'error': f'Resposta inválida: {e}',
                    'analysis': '',
                    'tokens_used': 0
                }
        
        elif response.status_code == 401:
            # Token expirado - tentar renovar automaticamente
            self.logger.warning("Token expirado (401), tentando renovar...")
            self.token_manager.token = None  # Forçar renovação
            return {
                'success': False,
                'error': 'Token expirado - renovação necessária',
                'analysis': '',
                'tokens_used': 0,
                'retry_suggested': True
            }
        
        elif response.status_code >= 400 and response.status_code < 500:
            self.logger.error(f"Erro do cliente: {response.status_code} - {response.text}")
            return {
                'success': False,
                'error': f'Erro do cliente: {response.status_code}',
                'analysis': '',
                'tokens_used': 0
            }
        
        elif response.status_code >= 500:
            self.logger.error(f"Erro do servidor: {response.status_code}")
            return {
                'success': False,
                'error': f'Erro do servidor: {response.status_code}',
                'analysis': '',
                'tokens_used': 0
            }
        
        else:
            self.logger.warning(f"Código de status não tratado: {response.status_code}")
            return {
                'success': False,
                'error': f'Status não tratado: {response.status_code}',
                'analysis': '',
                'tokens_used': 0
            }
    
    def _extract_content_from_response(self, response_data: Dict) -> str:
        """Extrai conteúdo da resposta da API."""
        try:
            # Tentar estrutura padrão da OpenAI
            if 'choices' in response_data and response_data['choices']:
                choice = response_data['choices'][0]
                if 'message' in choice and 'content' in choice['message']:
                    return choice['message']['content']
            
            # Tentar estrutura alternativa
            if 'content' in response_data:
                return response_data['content']
            
            # Fallback para JSON formatado
            return json.dumps(response_data, indent=2, ensure_ascii=False)
            
        except Exception as e:
            self.logger.warning(f"Erro ao extrair conteúdo: {e}")
            return json.dumps(response_data, indent=2, ensure_ascii=False)
    
    def _extract_tokens_from_response(self, response_data: Dict) -> int:
        """Extrai informação de tokens da resposta."""
        try:
            if 'usage' in response_data:
                usage = response_data['usage']
                return usage.get('total_tokens', 0)
            return 0
        except:
            return 0
    
    def _create_analysis_prompt(self, program_content: str, books_content: List[str] = None) -> str:
        """Cria prompt para análise do programa COBOL."""
        
        prompt = f"""Analise o seguinte programa COBOL e forneça uma documentação completa e detalhada:

PROGRAMA COBOL:
```cobol
{program_content}
```
"""
        
        if books_content:
            prompt += f"""
COPYBOOKS RELACIONADOS:
```cobol
{chr(10).join(books_content)}
```
"""
        
        prompt += """
Forneça uma análise completa incluindo:

1. **Identificação do Programa**
   - Nome do programa
   - Propósito e funcionalidade principal
   - Autor e data (se disponível)

2. **Estrutura e Organização**
   - Divisões utilizadas
   - Seções principais
   - Organização do código

3. **Análise de Dados**
   - Variáveis de working-storage
   - Estruturas de dados
   - Copybooks utilizados
   - Arquivos e registros

4. **Lógica de Processamento**
   - Fluxo principal do programa
   - Parágrafos e seções de processamento
   - Condições e loops
   - Cálculos e transformações

5. **Análise de Arquivos**
   - Arquivos de entrada e saída
   - Estrutura dos registros
   - Modos de acesso

6. **Dependências e Integrações**
   - Copybooks incluídos
   - Programas chamados
   - Recursos externos

7. **Qualidade e Manutenibilidade**
   - Boas práticas utilizadas
   - Pontos de atenção
   - Sugestões de melhoria

8. **Resumo Executivo**
   - Funcionalidade principal
   - Complexidade
   - Importância no sistema

Formate a resposta em Markdown com seções bem organizadas e exemplos quando relevante.
"""
        
        return prompt

class AuditLogger:
    """Sistema de auditoria completo."""
    
    def __init__(self, output_dir: str):
        self.output_dir = output_dir
        self.audit_dir = os.path.join(output_dir, 'audit')
        os.makedirs(self.audit_dir, exist_ok=True)
        self.logger = logging.getLogger(self.__class__.__name__)
        self.session_data = {}
    
    def start_session(self, total_programs: int) -> str:
        """Inicia uma sessão de auditoria."""
        session_id = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        self.session_data = {
            'session_id': session_id,
            'start_time': datetime.now(),
            'total_programs': total_programs,
            'requests': [],
            'responses': []
        }
        
        self.logger.info(f"Sessão de auditoria iniciada: {session_id}")
        return session_id
    
    def log_request(self, program_name: str, provider: str, program_content: str, 
                   books_content: List[str] = None) -> str:
        """Registra uma requisição."""
        request_id = f"req_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        
        request_data = {
            'request_id': request_id,
            'timestamp': datetime.now().isoformat(),
            'program_name': program_name,
            'provider': provider,
            'content_hash': hashlib.md5(program_content.encode()).hexdigest(),
            'books_count': len(books_content) if books_content else 0
        }
        
        self.session_data['requests'].append(request_data)
        
        # Salvar payload completo
        payload_file = os.path.join(self.audit_dir, f"{request_id}_payload.json")
        with open(payload_file, 'w', encoding='utf-8') as f:
            json.dump({
                'program_name': program_name,
                'program_content': program_content,
                'books_content': books_content or [],
                'metadata': request_data
            }, f, indent=2, ensure_ascii=False)
        
        return request_id
    
    def log_response(self, request_id: str, status_code: int, response_content: str,
                    processing_time_ms: int, tokens_used: int, success: bool,
                    error_message: str = None) -> None:
        """Registra uma resposta."""
        
        response_data = {
            'request_id': request_id,
            'timestamp': datetime.now().isoformat(),
            'status_code': status_code,
            'processing_time_ms': processing_time_ms,
            'tokens_used': tokens_used,
            'success': success,
            'error_message': error_message,
            'content_hash': hashlib.md5(response_content.encode()).hexdigest() if response_content else None
        }
        
        self.session_data['responses'].append(response_data)
        
        # Salvar resposta completa
        response_file = os.path.join(self.audit_dir, f"{request_id}_response.json")
        with open(response_file, 'w', encoding='utf-8') as f:
            json.dump({
                'response_content': response_content,
                'metadata': response_data
            }, f, indent=2, ensure_ascii=False)
    
    def end_session(self, session_id: str) -> None:
        """Finaliza sessão e gera relatório."""
        self.session_data['end_time'] = datetime.now()
        self.session_data['duration_seconds'] = (
            self.session_data['end_time'] - self.session_data['start_time']
        ).total_seconds()
        
        # Gerar relatório de auditoria
        self._generate_audit_report(session_id)
        
        self.logger.info(f"Sessão de auditoria finalizada: {session_id}")
    
    def _generate_audit_report(self, session_id: str) -> None:
        """Gera relatório de auditoria em Markdown."""
        report_file = os.path.join(self.audit_dir, f"audit_report_session_{session_id}.md")
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(f"# Relatório de Auditoria - Sessão {session_id}\n\n")
            f.write(f"**Data de Início**: {self.session_data['start_time'].strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Data de Fim**: {self.session_data['end_time'].strftime('%d/%m/%Y %H:%M:%S')}\n")
            f.write(f"**Duração**: {self.session_data['duration_seconds']:.2f} segundos\n")
            f.write(f"**Total de Programas**: {self.session_data['total_programs']}\n\n")
            
            # Estatísticas
            total_requests = len(self.session_data['requests'])
            successful_responses = sum(1 for r in self.session_data['responses'] if r['success'])
            total_tokens = sum(r['tokens_used'] for r in self.session_data['responses'])
            avg_processing_time = sum(r['processing_time_ms'] for r in self.session_data['responses']) / len(self.session_data['responses']) if self.session_data['responses'] else 0
            
            f.write("## Estatísticas\n\n")
            f.write(f"- **Total de Requisições**: {total_requests}\n")
            f.write(f"- **Respostas Bem-sucedidas**: {successful_responses}\n")
            f.write(f"- **Taxa de Sucesso**: {(successful_responses/total_requests*100):.1f}%\n")
            f.write(f"- **Total de Tokens**: {total_tokens}\n")
            f.write(f"- **Tempo Médio de Processamento**: {avg_processing_time:.0f}ms\n\n")
            
            # Detalhes das requisições
            f.write("## Detalhes das Requisições\n\n")
            f.write("| Programa | Status | Tempo (ms) | Tokens | Hash Conteúdo |\n")
            f.write("|----------|--------|------------|--------|--------------|\n")
            
            for req in self.session_data['requests']:
                resp = next((r for r in self.session_data['responses'] if r['request_id'] == req['request_id']), None)
                if resp:
                    status = "✅ Sucesso" if resp['success'] else "❌ Falha"
                    f.write(f"| {req['program_name']} | {status} | {resp['processing_time_ms']} | {resp['tokens_used']} | {req['content_hash'][:8]}... |\n")

class COBOLParser:
    """Parser simples para programas COBOL."""
    
    def parse_file(self, file_path: str) -> List[COBOLProgram]:
        """Parseia arquivo de programas COBOL."""
        programs = []
        
        try:
            # Tentar diferentes encodings
            encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
            content = None
            
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    break
                except UnicodeDecodeError:
                    continue
            
            if content is None:
                raise ValueError(f"Não foi possível ler o arquivo {file_path} com nenhum encoding suportado")
            
            # Dividir por PROGRAM-ID
            program_sections = content.split('PROGRAM-ID.')
            
            for i, section in enumerate(program_sections[1:], 1):  # Pular primeira seção vazia
                lines = section.strip().split('\n')
                if lines:
                    # Primeira linha contém o nome do programa
                    program_name = lines[0].strip().rstrip('.')
                    
                    # Reconstruir conteúdo do programa
                    program_content = f"PROGRAM-ID.{section}"
                    
                    programs.append(COBOLProgram(program_name, program_content))
            
            return programs
            
        except Exception as e:
            logging.error(f"Erro ao parsear arquivo {file_path}: {e}")
            return []

def setup_logging(log_level: str = "INFO") -> None:
    """Configura o sistema de logging."""
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_file = os.path.join(log_dir, f"cobol_ai_engine_standalone_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log")
    
    logging.basicConfig(
        level=getattr(logging, log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def load_cobol_programs(fontes_file: str) -> List[COBOLProgram]:
    """Carrega programas COBOL do arquivo de fontes."""
    logger = logging.getLogger(__name__)
    
    if not os.path.exists(fontes_file):
        raise FileNotFoundError(f"Arquivo de fontes não encontrado: {fontes_file}")
    
    logger.info(f"Carregando programas COBOL de: {fontes_file}")
    
    parser = COBOLParser()
    programs = parser.parse_file(fontes_file)
    
    logger.info(f"Total de programas encontrados: {len(programs)}")
    
    return programs

def load_copybooks(books_file: Optional[str]) -> List[str]:
    """Carrega copybooks se fornecido."""
    logger = logging.getLogger(__name__)
    
    if not books_file:
        logger.info("Nenhum arquivo de copybooks fornecido")
        return []
    
    if not os.path.exists(books_file):
        logger.warning(f"Arquivo de copybooks não encontrado: {books_file}")
        return []
    
    logger.info(f"Carregando copybooks de: {books_file}")
    
    try:
        # Tentar diferentes encodings
        encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
        content = None
        
        for encoding in encodings:
            try:
                with open(books_file, 'r', encoding=encoding) as f:
                    content = f.read()
                break
            except UnicodeDecodeError:
                continue
        
        if content is None:
            logger.warning(f"Não foi possível ler copybooks com nenhum encoding suportado")
            return []
        
        # Dividir copybooks (assumindo separação por linhas vazias ou padrão específico)
        books = [book.strip() for book in content.split('\n\n') if book.strip()]
        
        logger.info(f"Total de copybooks encontrados: {len(books)}")
        return books
        
    except Exception as e:
        logger.error(f"Erro ao carregar copybooks: {e}")
        return []

def save_analysis_result(program: COBOLProgram, analysis: str, output_dir: str) -> None:
    """Salva resultado da análise."""
    
    # Criar diretórios necessários
    reports_dir = os.path.join(output_dir, 'reports')
    requests_dir = os.path.join(output_dir, 'requests')
    responses_dir = os.path.join(output_dir, 'responses')
    metadata_dir = os.path.join(output_dir, 'metadata')
    
    for dir_path in [reports_dir, requests_dir, responses_dir, metadata_dir]:
        os.makedirs(dir_path, exist_ok=True)
    
    # Salvar relatório principal
    report_file = os.path.join(reports_dir, f"{program.name}.md")
    with open(report_file, 'w', encoding='utf-8') as f:
        f.write(analysis)
    
    # Salvar metadados
    metadata = {
        'program_name': program.name,
        'analysis_date': datetime.now().isoformat(),
        'content_hash': hashlib.md5(program.content.encode()).hexdigest(),
        'success': True
    }
    
    metadata_file = os.path.join(metadata_dir, f"{program.name}_metadata.json")
    with open(metadata_file, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)

def check_credentials() -> tuple:
    """Verifica e obtém credenciais LuzIA."""
    client_id = os.getenv('LUZIA_CLIENT_ID')
    client_secret = os.getenv('LUZIA_CLIENT_SECRET')
    
    if not client_id or not client_secret:
        print("❌ Credenciais LuzIA não configuradas!")
        print("\nConfigure as variáveis de ambiente:")
        print("export LUZIA_CLIENT_ID=\"seu_client_id\"")
        print("export LUZIA_CLIENT_SECRET=\"seu_client_secret\"")
        print("\nOu use um arquivo .env")
        return None, None
    
    return client_id, client_secret

def check_providers_status() -> None:
    """Verifica status dos provedores."""
    print("=== VERIFICAÇÃO DE STATUS DOS PROVEDORES ===\n")
    
    client_id, client_secret = check_credentials()
    
    if not client_id or not client_secret:
        return
    
    try:
        provider = LuziaProvider(client_id, client_secret)
        
        print("Testando conectividade LuzIA...")
        if provider.test_connectivity():
            print("  ✅ LuzIA: Conectividade OK")
        else:
            print("  ❌ LuzIA: Falha na conectividade")
        
        print("\n=== VERIFICAÇÃO CONCLUÍDA ===")
        
    except Exception as e:
        print(f"❌ Erro na verificação: {e}")

def process_cobol_files(args: argparse.Namespace) -> None:
    """Processa os arquivos COBOL."""
    logger = logging.getLogger(__name__)
    start_time = time.time()
    
    # Verificar credenciais
    client_id, client_secret = check_credentials()
    if not client_id or not client_secret:
        sys.exit(1)
    
    # Inicializar provedor e auditoria
    provider = LuziaProvider(client_id, client_secret)
    audit_logger = AuditLogger(args.output)
    
    # Carregar programas e copybooks
    programs = load_cobol_programs(args.fontes)
    books = load_copybooks(args.books)
    
    if not programs:
        print("❌ Nenhum programa COBOL encontrado")
        sys.exit(1)
    
    # Iniciar sessão de auditoria
    session_id = audit_logger.start_session(len(programs))
    
    print(f"🚀 Iniciando análise de {len(programs)} programas...")
    print("=" * 60)
    
    all_results = []
    
    for i, program in enumerate(programs, 1):
        print(f"\n[ {i:2d}/{len(programs)} ] Analisando {program.name}...")
        
        start_analysis = time.time()
        
        # Registrar requisição na auditoria
        request_id = audit_logger.log_request(
            program_name=program.name,
            provider="luzia",
            program_content=program.content,
            books_content=books
        )
        
        # Realizar análise
        result = provider.analyze_program(program.content, books)
        
        processing_time = time.time() - start_analysis
        
        # Registrar resposta na auditoria
        audit_logger.log_response(
            request_id=request_id,
            status_code=result.get('status_code', 500),
            response_content=result.get('analysis', ''),
            processing_time_ms=int(processing_time * 1000),
            tokens_used=result.get('tokens_used', 0),
            success=result['success'],
            error_message=result.get('error') if not result['success'] else None
        )
        
        if result['success']:
            # Salvar resultado
            save_analysis_result(program, result['analysis'], args.output)
            print(f"        ✅ Sucesso ({processing_time:.0f}ms, {result['tokens_used']} tokens)")
        else:
            print(f"        ❌ Erro: {result['error']}")
        
        all_results.append({
            'program': program.name,
            'success': result['success'],
            'processing_time': processing_time,
            'tokens_used': result.get('tokens_used', 0),
            'error': result.get('error') if not result['success'] else None
        })
        
        # Mostrar progresso
        successes = sum(1 for r in all_results if r['success'])
        progress = (i / len(programs)) * 100
        print(f"        📊 Progresso: {progress:.1f}% ({successes} sucessos, {i - successes} erros)")
    
    # Finalizar sessão de auditoria
    audit_logger.end_session(session_id)
    
    # Estatísticas finais
    processing_time = time.time() - start_time
    successful_analyses = sum(1 for r in all_results if r['success'])
    total_tokens = sum(r.get('tokens_used', 0) for r in all_results if r['success'])
    
    print("\n" + "=" * 60)
    print("📋 RELATÓRIO FINAL")
    print("=" * 60)
    print(f"Programas processados: {len(programs)}")
    print(f"Análises bem-sucedidas: {successful_analyses}/{len(all_results)}")
    print(f"Taxa de sucesso geral: {(successful_analyses/len(all_results)*100):.1f}%")
    print(f"Total de tokens utilizados: {total_tokens}")
    print(f"Tempo total de processamento: {processing_time:.2f}s")
    print(f"Documentação gerada em: {args.output}")
    
    # Mostrar informações de auditoria
    audit_report_path = os.path.join(args.output, 'audit', f'audit_report_session_{session_id}.md')
    if os.path.exists(audit_report_path):
        print(f"Relatório de auditoria: {audit_report_path}")

def main():
    """Função principal para executar o script."""
    parser = argparse.ArgumentParser(
        description='COBOL AI Engine v1.4.0 - Sistema de Análise de Programas COBOL (Standalone)',
        epilog="""
Exemplos de uso:
  python main_standalone_v1_4_0.py --fontes examples/fontes.txt --output minha_analise
  python main_standalone_v1_4_0.py --fontes examples/fontes.txt --books examples/BOOKS.txt --output analise_completa --pdf
  python main_standalone_v1_4_0.py --status
        """,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument('--fontes', 
                       help='Caminho para o arquivo de fontes COBOL (ex: fontes.txt)')
    parser.add_argument('--books', 
                       help='Caminho para o arquivo de copybooks (opcional)')
    parser.add_argument('--output', default='output', 
                       help='Diretório de saída para a documentação (padrão: output)')
    parser.add_argument('--pdf', action='store_true', 
                       help='Gera relatórios HTML otimizados para conversão PDF via navegador')
    parser.add_argument('--log', default='INFO', 
                       help='Nível de log (DEBUG, INFO, WARNING, ERROR)')
    parser.add_argument('--status', action='store_true', 
                       help='Verifica status e conectividade dos provedores de IA configurados')

    args = parser.parse_args()

    # Mostrar banner
    print("=" * 60)
    print("COBOL AI Engine v1.4.0 - Sistema de Análise de Programas COBOL")
    print("Correções implementadas: Token automático, HTTP 201/202, Auditoria")
    print("=" * 60)

    setup_logging(args.log)
    
    try:
        # Verificar se é comando de status
        if args.status:
            check_providers_status()
            return
        
        # Validar argumentos obrigatórios para análise
        if not args.fontes:
            print("\n❌ Erro: --fontes é obrigatório para análise de programas")
            print("💡 Use --status para verificar conectividade dos provedores")
            print("\nExemplos:")
            print("  python main_standalone_v1_4_0.py --fontes examples/fontes.txt --output minha_analise")
            print("  python main_standalone_v1_4_0.py --status")
            sys.exit(1)
        
        process_cobol_files(args)
        
    except Exception as e:
        logging.error(f"Uma falha crítica ocorreu: {e}")
        print(f"\n❌ Erro crítico: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
