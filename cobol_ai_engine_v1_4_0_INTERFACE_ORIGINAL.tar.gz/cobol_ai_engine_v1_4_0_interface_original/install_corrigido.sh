#!/bin/bash

# COBOL AI Engine v1.4.0 - Script de Instalação Automática (Corrigido)
# Este script configura automaticamente o ambiente para teste com interface original

set -e  # Parar em caso de erro

echo "============================================================"
echo "COBOL AI Engine v1.4.0 - Instalação Automática (Corrigido)"
echo "Interface original restaurada: --fontes, --books, --output, --pdf"
echo "============================================================"

# Verificar Python
echo "1. Verificando Python..."
if ! command -v python3 &> /dev/null; then
    echo "ERRO: Python 3 não encontrado. Instale Python 3.8+ primeiro."
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
echo "   Python encontrado: $PYTHON_VERSION"

# Verificar pip
echo "2. Verificando pip..."
if ! command -v pip3 &> /dev/null; then
    echo "ERRO: pip3 não encontrado. Instale pip primeiro."
    exit 1
fi
echo "   pip3 encontrado"

# Criar diretórios necessários
echo "3. Criando estrutura de diretórios..."
mkdir -p logs
mkdir -p output
mkdir -p examples
mkdir -p src/providers
mkdir -p src/utils
echo "   Diretórios criados"

# Instalar dependências
echo "4. Instalando dependências Python..."
pip3 install --user requests urllib3 python-dateutil
echo "   Dependências instaladas"

# Verificar instalação
echo "5. Verificando instalação..."
python3 -c "import requests, urllib3; print('   Dependências OK')"

# Criar arquivo de exemplo se não existir
if [ ! -f "examples/fontes.txt" ]; then
    echo "6. Criando arquivo de exemplo..."
    cat > examples/fontes.txt << 'EOF'
PROGRAM-ID. EXEMPLO-TESTE.
IDENTIFICATION DIVISION.
PROGRAM-ID. EXEMPLO-TESTE.
AUTHOR. SISTEMA-TESTE.
DATE-WRITTEN. 22/09/2025.

ENVIRONMENT DIVISION.
CONFIGURATION SECTION.
SOURCE-COMPUTER. IBM-370.
OBJECT-COMPUTER. IBM-370.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-CONTADOR         PIC 9(3) VALUE 0.
01 WS-MENSAGEM         PIC X(50) VALUE 'SISTEMA FUNCIONANDO CORRETAMENTE'.
01 WS-STATUS           PIC X(10) VALUE 'ATIVO'.

PROCEDURE DIVISION.
MAIN-PARA.
    DISPLAY 'INICIANDO PROGRAMA DE TESTE'.
    PERFORM PROCESSAR-DADOS.
    DISPLAY 'PROGRAMA FINALIZADO COM SUCESSO'.
    STOP RUN.

PROCESSAR-DADOS.
    MOVE 1 TO WS-CONTADOR.
    DISPLAY WS-MENSAGEM.
    DISPLAY 'CONTADOR: ' WS-CONTADOR.
    DISPLAY 'STATUS: ' WS-STATUS.

PROGRAM-ID. SEGUNDO-PROGRAMA.
IDENTIFICATION DIVISION.
PROGRAM-ID. SEGUNDO-PROGRAMA.
AUTHOR. SISTEMA-TESTE.

DATA DIVISION.
WORKING-STORAGE SECTION.
01 WS-VALOR            PIC 9(5)V99 VALUE 100.50.
01 WS-RESULTADO        PIC 9(5)V99 VALUE ZERO.

PROCEDURE DIVISION.
INICIO.
    COMPUTE WS-RESULTADO = WS-VALOR * 1.10.
    DISPLAY 'VALOR ORIGINAL: ' WS-VALOR.
    DISPLAY 'RESULTADO: ' WS-RESULTADO.
    STOP RUN.
EOF
    echo "   Arquivo de exemplo criado"
else
    echo "6. Arquivo de exemplo já existe"
fi

# Criar arquivo de copybooks se não existir
if [ ! -f "examples/BOOKS.txt" ]; then
    echo "7. Criando arquivo de copybooks de exemplo..."
    cat > examples/BOOKS.txt << 'EOF'
      * COPYBOOK: CLIENTE-RECORD
       01  CLIENTE-RECORD.
           05  CLI-CODIGO          PIC 9(8).
           05  CLI-NOME            PIC X(50).
           05  CLI-ENDERECO        PIC X(100).
           05  CLI-TELEFONE        PIC X(15).
           05  CLI-EMAIL           PIC X(50).
           05  CLI-STATUS          PIC X(1).
               88  CLI-ATIVO       VALUE 'A'.
               88  CLI-INATIVO     VALUE 'I'.

      * COPYBOOK: CONTA-RECORD
       01  CONTA-RECORD.
           05  CTA-NUMERO          PIC 9(10).
           05  CTA-CLIENTE         PIC 9(8).
           05  CTA-TIPO            PIC X(2).
               88  CTA-CORRENTE    VALUE 'CC'.
               88  CTA-POUPANCA    VALUE 'CP'.
           05  CTA-SALDO           PIC S9(13)V99 COMP-3.
           05  CTA-DATA-ABERTURA   PIC 9(8).
           05  CTA-STATUS          PIC X(1).
               88  CTA-ATIVA       VALUE 'A'.
               88  CTA-BLOQUEADA   VALUE 'B'.
               88  CTA-ENCERRADA   VALUE 'E'.
EOF
    echo "   Arquivo de copybooks criado"
else
    echo "7. Arquivo de copybooks já existe"
fi

# Verificar permissões
echo "8. Configurando permissões..."
chmod +x *.py 2>/dev/null || true
chmod +x main_standalone_v1_4_0.py 2>/dev/null || true
echo "   Permissões configuradas"

echo ""
echo "============================================================"
echo "INSTALAÇÃO CONCLUÍDA COM SUCESSO!"
echo "============================================================"
echo ""
echo "INTERFACE ORIGINAL RESTAURADA:"
echo ""
echo "Próximos passos:"
echo ""
echo "1. Configure suas credenciais LuzIA:"
echo "   export LUZIA_CLIENT_ID=\"seu_client_id\""
echo "   export LUZIA_CLIENT_SECRET=\"seu_client_secret\""
echo ""
echo "2. Teste a conectividade:"
echo "   python3 main_standalone_v1_4_0.py --status"
echo ""
echo "3. Execute uma análise de teste (INTERFACE ORIGINAL):"
echo "   python3 main_standalone_v1_4_0.py --fontes examples/fontes.txt --output minha_analise"
echo ""
echo "4. Análise completa com copybooks e PDF:"
echo "   python3 main_standalone_v1_4_0.py --fontes examples/fontes.txt --books examples/BOOKS.txt --output analise_completa --pdf"
echo ""
echo "5. Para testes completos:"
echo "   python3 test_enhanced_system.py"
echo ""
echo "CORREÇÕES IMPLEMENTADAS v1.4.0:"
echo "✅ Renovação automática de token (HTTP 401)"
echo "✅ Tratamento de HTTP 201 e 202"
echo "✅ Sistema de auditoria completo"
echo "✅ Interface original mantida: --fontes, --books, --output, --pdf"
echo ""
echo "Documentação disponível:"
echo "- README_v1_4_0.md"
echo "- GUIA_INSTALACAO_v1_4_0.md"
echo "- CORRECOES_IMPLEMENTADAS_v1_4_0.md"
echo ""
echo "============================================================"
