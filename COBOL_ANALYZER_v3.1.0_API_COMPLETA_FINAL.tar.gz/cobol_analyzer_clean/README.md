# COBOL Analyzer - Ferramenta de Análise e Documentação

## Visão Geral

O COBOL Analyzer é uma ferramenta avançada para análise automatizada e geração de documentação de sistemas COBOL legados. Utiliza inteligência artificial para compreender e documentar código COBOL de forma abrangente e precisa.

## Características Principais

- **Análise Automatizada**: Processamento inteligente de código COBOL
- **Documentação Completa**: Geração de documentação técnica detalhada
- **API Programática**: Interface Python para integração com sistemas existentes
- **Múltiplos Formatos**: Saída em Markdown, HTML, JSON, PDF e DOCX
- **Análise em Lote**: Processamento de múltiplos programas simultaneamente
- **Base de Conhecimento**: Sistema RAG especializado em COBOL
- **Configuração Flexível**: Personalização completa de parâmetros

## Instalação

### Instalação via Pip

```bash
# Extrair o pacote
tar -xzf cobol-analyzer-v3.1.0.tar.gz
cd cobol_analyzer_clean/

# Instalar com API programática
python install_api.py
```

### Verificação da Instalação

```bash
# Testar comando
cobol-to-docs --help

# Testar API
python -c "import cobol_to_docs; print('API instalada com sucesso')"
```

## Uso Rápido

### 1. Inicialização do Ambiente

```bash
# Via linha de comando
cobol-to-docs --init

# Via API Python
python -c "import cobol_to_docs; cobol_to_docs.init()"
```

### 2. Análise de Programas

```bash
# Análise básica
cobol-to-docs --fontes programas.txt

# Análise com copybooks
cobol-to-docs --fontes programas.txt --books copybooks.txt

# Análise consolidada
cobol-to-docs --fontes programas.txt --consolidado
```

### 3. Uso Programático

```python
import cobol_to_docs

# Inicializar
cobol_to_docs.init()

# Analisar programa
codigo_cobol = """
IDENTIFICATION DIVISION.
PROGRAM-ID. EXEMPLO.
PROCEDURE DIVISION.
    DISPLAY 'HELLO WORLD'.
    STOP RUN.
"""

resultado = cobol_to_docs.analyze_program(codigo_cobol, "EXEMPLO.CBL")
print(f"Análise concluída: {resultado.success}")
```

## Estrutura do Projeto

Após a inicialização, a seguinte estrutura é criada:

```
projeto/
├── config/                 # Configurações do sistema
│   ├── config.yaml        # Configuração principal
│   ├── prompts_*.yaml     # Prompts especializados
│   └── ...
├── data/                  # Base de conhecimento
│   ├── cobol_knowledge_base*.json
│   ├── embeddings/
│   └── ...
├── logs/                  # Logs do sistema
├── examples/              # Exemplos de uso
└── output/               # Documentação gerada
```

## API Programática

### Funções Principais

#### Inicialização
```python
cobol_to_docs.init(config_dir='./config', data_dir='./data')
```

#### Análise Individual
```python
resultado = cobol_to_docs.analyze_program(codigo, nome_programa)
```

#### Análise em Lote
```python
resultados = cobol_to_docs.analyze_batch(lista_arquivos)
```

#### Configuração
```python
cobol_to_docs.configure({'model': 'enhanced_mock', 'analysis_type': 'detailed'})
```

### Classes Avançadas

#### COBOLAnalyzer
```python
analyzer = cobol_to_docs.COBOLAnalyzer({'model': 'gpt-4'})
resultado = analyzer.analyze_program(codigo)
```

#### COBOLProject
```python
projeto = cobol_to_docs.COBOLProject("MeuSistema")
projeto.add_program("PROGRAMA.CBL")
resultado = projeto.analyze_all()
```

#### COBOLBatch
```python
batch = cobol_to_docs.COBOLBatch()
batch.add_files(["PROG1.CBL", "PROG2.CBL"])
resultado = batch.execute()
```

## Configuração

### Modelos Disponíveis

- **enhanced_mock**: Modelo padrão para testes
- **gpt-4**: OpenAI GPT-4
- **claude**: Anthropic Claude
- **gemini**: Google Gemini

### Tipos de Análise

- **basic**: Análise básica
- **detailed**: Análise detalhada (padrão)
- **comprehensive**: Análise abrangente
- **business_rules**: Foco em regras de negócio
- **modernization**: Análise para modernização

### Formatos de Saída

- **markdown**: Markdown (padrão)
- **html**: HTML
- **json**: JSON estruturado
- **pdf**: PDF
- **docx**: Microsoft Word

## Comandos Disponíveis

### Inicialização
```bash
cobol-to-docs --init                    # Inicialização básica
cobol-to-docs --init --config-dir ./config  # Diretório personalizado
cobol-to-docs --init --force-init       # Forçar reinicialização
```

### Análise
```bash
cobol-to-docs --fontes programas.txt    # Análise básica
cobol-to-docs --books copybooks.txt     # Com copybooks
cobol-to-docs --consolidado             # Análise consolidada
cobol-to-docs --models enhanced_mock    # Modelo específico
```

### Utilitários
```bash
cobol-to-docs --status                  # Status do sistema
cobol-to-docs --show-paths             # Mostrar caminhos
cobol-to-docs --help                   # Ajuda
```

## Exemplos Práticos

### Análise de Sistema Completo

```python
import cobol_to_docs

# Configurar ambiente
cobol_to_docs.init()
cobol_to_docs.set_model('enhanced_mock')

# Analisar sistema
resultado = cobol_to_docs.analyze_system(
    fontes_file="sistema_fontes.txt",
    books_file="sistema_books.txt",
    consolidado=True
)

print(f"Sistema analisado: {resultado.successful} programas")
```

### Integração com Pipeline CI/CD

```python
def processar_cobol_pipeline(lista_programas):
    """Integração com pipeline de CI/CD"""
    
    cobol_to_docs.init()
    resultado = cobol_to_docs.analyze_batch(lista_programas)
    
    # Gerar relatório
    relatorio = {
        'total': resultado.total_programs,
        'sucessos': resultado.successful,
        'falhas': resultado.failed,
        'tempo': resultado.total_time
    }
    
    return relatorio
```

### Análise Personalizada

```python
# Configuração personalizada
analyzer = cobol_to_docs.COBOLAnalyzer({
    'model': 'gpt-4',
    'analysis_type': 'comprehensive',
    'output_format': 'html'
})

# Analisar com configuração específica
resultado = analyzer.analyze_program(codigo_cobol)
```

## Estruturas de Dados

### AnalysisResult
```python
@dataclass
class AnalysisResult:
    program_name: str           # Nome do programa
    success: bool              # Status da análise
    documentation: str         # Documentação gerada
    metadata: Dict[str, Any]   # Metadados
    execution_time: float      # Tempo de execução
    error_message: str         # Mensagem de erro (se houver)
```

### BatchResult
```python
@dataclass
class BatchResult:
    total_programs: int        # Total de programas
    successful: int           # Sucessos
    failed: int              # Falhas
    results: List[AnalysisResult]  # Resultados individuais
    total_time: float        # Tempo total
```

## Tratamento de Erros

### Exceções Personalizadas

```python
try:
    resultado = cobol_to_docs.analyze_program(codigo)
except cobol_to_docs.AnalysisError as e:
    print(f"Erro na análise: {e}")
except cobol_to_docs.ConfigurationError as e:
    print(f"Erro de configuração: {e}")
```

### Verificação de Resultados

```python
resultado = cobol_to_docs.analyze_program(codigo)

if resultado.success:
    print("Análise bem-sucedida")
    print(resultado.documentation)
else:
    print(f"Falha: {resultado.error_message}")
```

## Solução de Problemas

### Comando não encontrado
```bash
# Reinstalar
python install_api.py
```

### Erro de importação
```python
# Verificar instalação
import sys
print(sys.path)
```

### Problemas de configuração
```bash
# Reinicializar ambiente
cobol-to-docs --init --force-init
```

## Arquivos de Configuração

### config.yaml
Configuração principal do sistema com parâmetros de modelos, análise e saída.

### prompts_*.yaml
Prompts especializados para diferentes tipos de análise:
- prompts_enhanced.yaml: Prompts principais
- prompts_especialista.yaml: Análise especializada
- prompts_deep_business_rules.yaml: Regras de negócio
- prompts_cadoc_deep_analysis.yaml: Análise profunda

### cobol_knowledge_base*.json
Base de conhecimento especializada em COBOL com padrões, boas práticas e documentação técnica.

## Requisitos do Sistema

- Python 3.8 ou superior
- Bibliotecas: PyYAML, requests, numpy, scikit-learn
- Espaço em disco: 50MB mínimo
- Memória RAM: 512MB mínimo

## Licença

Este software é distribuído sob licença MIT. Consulte o arquivo LICENSE para mais detalhes.

## Suporte

Para suporte técnico e documentação adicional, consulte:
- Documentação completa: README_USO_PROGRAMATICO.md
- Exemplos: exemplo_api_completa.py
- Guias: GUIA_DIRETORIOS_PERSONALIZADOS.md

## Versão

**Versão**: 3.1.0  
**Data**: Outubro 2025  
**Compatibilidade**: Python 3.8+
