#!/usr/bin/env python3
"""
Script final para limpar ícones e referências do projeto
"""

import os
import re
import glob

def clean_file(file_path):
    """Remove ícones e referências do arquivo"""
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        
        # Remover emojis/ícones específicos que aparecem na saída
        replacements = {
            '🚀': '',
            '✅': '',
            '❌': 'ERRO: ',
            '📁': '',
            '📊': '',
            '📝': '',
            '📋': '',
            '📂': '',
            '⚠️': 'AVISO: ',
            '🚨': 'ALERTA: ',
            'print("🚀': 'print("',
            'print(f"🚀': 'print(f"',
            'print("✅': 'print("',
            'print(f"✅': 'print(f"',
            'print("❌': 'print("ERRO: ',
            'print(f"❌': 'print(f"ERRO: ',
            'print("📁': 'print("',
            'print(f"📁': 'print(f"',
            'print("📊': 'print("',
            'print(f"📊': 'print(f"',
            'print("📝': 'print("',
            'print(f"📝': 'print(f"',
            'print("📋': 'print("',
            'print(f"📋': 'print(f"',
            'print("📂': 'print("',
            'print(f"📂': 'print(f"',
            '"🚀 ': '"',
            '"✅ ': '"',
            '"❌ ': '"ERRO: ',
            '"📁 ': '"',
            '"📊 ': '"',
            '"📝 ': '"',
            '"📋 ': '"',
            '"📂 ': '"',
            'f"🚀': 'f"',
            'f"✅': 'f"',
            'f"❌': 'f"ERRO: ',
            'f"📁': 'f"',
            'f"📊': 'f"',
            'f"📝': 'f"',
            'f"📋': 'f"',
            'f"📂': 'f"'
        }
        
        # Aplicar substituições
        for old, new in replacements.items():
            content = content.replace(old, new)
        
        # Remover referências ao Manus
        manus_patterns = [
            (r'[Mm]anus', 'COBOL Analyzer'),
            (r'MANUS', 'COBOL ANALYZER'),
            (r'Manus team', 'COBOL Analyzer team'),
            (r'Manus\.im', 'cobol-analyzer.com'),
            (r'help\.manus\.im', 'support.cobol-analyzer.com')
        ]
        
        for pattern, replacement in manus_patterns:
            content = re.sub(pattern, replacement, content)
        
        # Se houve mudanças, salvar arquivo
        if content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        
        return False
        
    except Exception as e:
        print(f"Erro ao processar {file_path}: {e}")
        return False

def clean_project():
    """Limpa todo o projeto"""
    
    print("Limpando projeto COBOL Analyzer...")
    
    # Tipos de arquivo para limpar
    file_patterns = [
        "*.py",
        "*.md",
        "*.txt",
        "*.yaml",
        "*.yml"
    ]
    
    files_cleaned = 0
    total_files = 0
    
    for pattern in file_patterns:
        for file_path in glob.glob(f"**/{pattern}", recursive=True):
            if any(skip in file_path for skip in ['build/', '__pycache__', '.git/', 'clean_final.py']):
                continue
                
            total_files += 1
            if clean_file(file_path):
                files_cleaned += 1
                print(f"Limpo: {file_path}")
    
    print(f"\nLimpeza concluída:")
    print(f"Arquivos processados: {total_files}")
    print(f"Arquivos modificados: {files_cleaned}")

if __name__ == "__main__":
    clean_project()
