#!/usr/bin/env python3
"""
COBOL to Docs Enhanced v3.1.0 - Wrapper principal com inicialização automática
Ponto de entrada global que suporta diretórios personalizados e inicialização automática
"""

import sys
import os
from pathlib import Path

# Adicionar diretório atual ao path para importações
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

def main():
    """
    Ponto de entrada principal que processa comandos diretamente
    Suporte completo para --init e outros parâmetros
    """
    
    # Processar argumentos diretamente
    args = sys.argv[1:]
    
    # Comando --init (inicialização)
    if '--init' in args:
        import subprocess
        main_script = os.path.join(current_dir, 'main_enhanced.py')
        if os.path.exists(main_script):
            # Substituir --init por --init-local
            processed_args = []
            for arg in args:
                if arg == '--init':
                    processed_args.append('--init-local')
                else:
                    processed_args.append(arg)
            
            cmd = [sys.executable, main_script] + processed_args
            result = subprocess.run(cmd, check=False)
            sys.exit(result.returncode)
        else:
            print("Erro: main_enhanced.py não encontrado")
            sys.exit(1)
    
    # Comando --help
    if '--help' in args or '-h' in args:
        print_help()
        sys.exit(0)
    
    # Comando --status
    if '--status' in args:
        import subprocess
        main_script = os.path.join(current_dir, 'main_enhanced.py')
        if os.path.exists(main_script):
            cmd = [sys.executable, main_script, '--status']
            result = subprocess.run(cmd, check=False)
            sys.exit(result.returncode)
    
    # Outros comandos - delegar para CLI enhanced
    try:
        from cli_enhanced import main as cli_main
        cli_main()
    except ImportError:
        # Fallback para main_enhanced.py diretamente
        import subprocess
        main_script = os.path.join(current_dir, 'main_enhanced.py')
        if os.path.exists(main_script):
            cmd = [sys.executable, main_script] + args
            result = subprocess.run(cmd, check=False)
            sys.exit(result.returncode)
        else:
            print("Erro: Não foi possível encontrar os arquivos principais do COBOL Analyzer")
            sys.exit(1)

def print_help():
    """Exibe ajuda do comando"""
    help_text = """
COBOL to Docs v3.1.0 - Análise e Documentação de Programas COBOL

Uso: cobol-to-docs [OPÇÕES]

Comandos principais:
  --init                          Inicializar ambiente local
  --init --config-dir DIR         Inicializar com diretório personalizado
  --fontes ARQUIVO                Analisar programas listados no arquivo
  --books ARQUIVO                 Incluir copybooks na análise
  --status                        Verificar status dos provedores
  --help                          Mostrar esta ajuda

Exemplos:
  cobol-to-docs --init                                    # Inicializar ambiente
  cobol-to-docs --fontes programas.txt                   # Analisar programas
  cobol-to-docs --fontes prog.txt --books books.txt      # Com copybooks
  cobol-to-docs --init --config-dir ./config_custom      # Diretório personalizado

Para ajuda completa: cobol-to-docs --fontes --help
"""
    print(help_text)

if __name__ == "__main__":
    main()
