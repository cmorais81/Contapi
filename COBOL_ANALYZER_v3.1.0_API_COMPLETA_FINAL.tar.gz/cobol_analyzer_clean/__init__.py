"""
COBOL Analyzer - Interface Programática Principal
================================================

Uso após instalação via pip:
    pip install cobol-to-docs
    
Exemplo básico:
    import cobol_to_docs
    
    # Inicializar ambiente
    cobol_to_docs.init()
    
    # Analisar programa
    resultado = cobol_to_docs.analyze_program("PROGRAMA.CBL")
    
    # Analisar múltiplos programas
    resultados = cobol_to_docs.analyze_batch(["PROG1.CBL", "PROG2.CBL"])
"""

__version__ = "3.1.0"
__author__ = "COBOL Analyzer Team"

# Importar todas as funções do módulo API
from .cobol_analyzer_api import (
    # Funções principais
    init,
    analyze_program,
    analyze_file,
    analyze_batch,
    analyze_system,
    
    # Configuração
    configure,
    get_config,
    set_model,
    
    # Utilitários
    status,
    show_paths,
    list_models,
    
    # Classes principais
    COBOLAnalyzer,
    COBOLProject,
    COBOLBatch,
    
    # Exceções
    COBOLAnalyzerError,
    ConfigurationError,
    AnalysisError,
    
    # Constantes
    ANALYSIS_TYPES,
    OUTPUT_FORMATS,
    SUPPORTED_MODELS
)

# Aliases para compatibilidade
analyze = analyze_program
batch_analyze = analyze_batch

# Configuração padrão
DEFAULT_CONFIG = {
    'model': 'enhanced_mock',
    'analysis_type': 'detailed',
    'output_format': 'markdown',
    'include_business_rules': True,
    'include_comments': True
}

# Metadados do pacote
__all__ = [
    # Funções principais
    'init',
    'analyze_program',
    'analyze_file', 
    'analyze_batch',
    'analyze_system',
    'analyze',  # alias
    'batch_analyze',  # alias
    
    # Configuração
    'configure',
    'get_config',
    'set_model',
    
    # Utilitários
    'status',
    'show_paths',
    'list_models',
    
    # Classes
    'COBOLAnalyzer',
    'COBOLProject',
    'COBOLBatch',
    
    # Exceções
    'COBOLAnalyzerError',
    'ConfigurationError',
    'AnalysisError',
    
    # Constantes
    'ANALYSIS_TYPES',
    'OUTPUT_FORMATS',
    'SUPPORTED_MODELS',
    'DEFAULT_CONFIG'
]
