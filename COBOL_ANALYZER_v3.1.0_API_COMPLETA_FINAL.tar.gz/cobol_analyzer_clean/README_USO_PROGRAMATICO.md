# COBOL Analyzer - Uso Programático

## Instalação e Configuração

### 1. Instalação via pip
```bash
pip install cobol-to-docs
```

### 2. Inicialização do Ambiente
```bash
# Criar estrutura local com configs e dados padrão
cobol-to-docs --init
```

**O que o `--init` faz:**
-  Cria pasta `config/` com configurações padrão do pacote
-  Cria pasta `data/` com knowledge base e RAGs padrão
-  Cria pasta `logs/` para logs do sistema
-  Cria pasta `examples/` com exemplos prontos
- ⚙ Copia todos os prompts especializados do pacote

### 3. Estrutura Criada
```
meu_projeto/
├── config/                    # Configurações do pacote
│   ├── config.yaml           # Config principal
│   ├── prompts_enhanced.yaml # Prompts especializados
│   └── ...                   # Outros configs
├── data/                     # Knowledge base do pacote
│   ├── cobol_knowledge_base.json
│   ├── embeddings/
│   └── ...
├── logs/                     # Logs do sistema
└── examples/                 # Exemplos prontos
    ├── fontes.txt
    └── programa_exemplo.cbl
```

## Uso Programático

### Exemplo 1: Uso Básico via Linha de Comando
```python
import subprocess
import os

# Garantir que ambiente está inicializado
if not os.path.exists('.cobol_analyzer_init'):
    subprocess.run(['cobol-to-docs', '--init'])

# Analisar programa
resultado = subprocess.run([
    'cobol-to-docs',
    '--fontes', 'meus_programas.txt',
    '--models', 'enhanced_mock'
], capture_output=True, text=True)

if resultado.returncode == 0:
    print(" Análise concluída!")
    print(resultado.stdout)
else:
    print(" Erro:", resultado.stderr)
```

### Exemplo 2: Uso Direto das Classes Python
```python
# Após cobol-to-docs --init
from src.core.config_enhanced import EnhancedConfigManager
from src.providers.enhanced_provider_manager import EnhancedProviderManager
from src.analyzers.enhanced_cobol_analyzer import EnhancedCOBOLAnalyzer

# Configurar
config_manager = EnhancedConfigManager()
provider_manager = EnhancedProviderManager(config_manager.config)
analyzer = EnhancedCOBOLAnalyzer(provider_manager, config_manager)

# Analisar programa
programa_cobol = """
IDENTIFICATION DIVISION.
PROGRAM-ID. MEU-PROGRAMA.
PROCEDURE DIVISION.
    DISPLAY 'HELLO WORLD'.
    STOP RUN.
"""

resultado = analyzer.analyze_program(
    program_content=programa_cobol,
    program_name="MEU-PROGRAMA.CBL"
)

print(f"Documentação gerada: {len(resultado)} caracteres")
```

### Exemplo 3: Integração em Sistema Existente
```python
def analisar_cobol_sistema(arquivo_cobol, config_personalizada=None):
    """Função para integrar em sistema existente"""
    
    import subprocess
    import tempfile
    from pathlib import Path
    
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)
        
        # Copiar arquivo
        shutil.copy(arquivo_cobol, temp_path)
        
        # Criar lista de fontes
        fontes_file = temp_path / "fontes.txt"
        with open(fontes_file, "w") as f:
            f.write(f"{Path(arquivo_cobol).name}\n")
        
        # Executar análise
        cmd = ['cobol-to-docs', '--fontes', str(fontes_file)]
        
        if config_personalizada:
            cmd.extend(['--models', config_personalizada.get('modelo')])
        
        resultado = subprocess.run(cmd, cwd=temp_path, capture_output=True)
        
        return {
            'sucesso': resultado.returncode == 0,
            'stdout': resultado.stdout.decode(),
            'stderr': resultado.stderr.decode()
        }

# Usar no seu sistema
resultado = analisar_cobol_sistema('PROGRAMA-CLIENTE.CBL', {
    'modelo': 'enhanced_mock'
})
```

### Exemplo 4: Análise de Múltiplos Programas
```python
def analisar_lote_programas(lista_programas):
    """Analisa múltiplos programas COBOL"""
    
    resultados = []
    
    for programa in lista_programas:
        print(f"Analisando {programa}...")
        
        resultado = subprocess.run([
            'cobol-to-docs',
            '--fontes', programa,
            '--models', 'enhanced_mock'
        ], capture_output=True, text=True)
        
        resultados.append({
            'programa': programa,
            'sucesso': resultado.returncode == 0,
            'saida': resultado.stdout
        })
    
    return resultados

# Usar
programas = ['sistema1.txt', 'sistema2.txt', 'sistema3.txt']
resultados = analisar_lote_programas(programas)

for r in resultados:
    status = "" if r['sucesso'] else ""
    print(f"{status} {r['programa']}")
```

### Exemplo 5: Configuração Personalizada
```python
# Modificar configuração após --init
import yaml

# Ler config atual
with open('config/config.yaml', 'r') as f:
    config = yaml.safe_load(f)

# Personalizar
config['models']['default'] = 'meu_modelo_personalizado'
config['analysis']['depth'] = 'detailed'
config['analysis']['include_business_rules'] = True

# Salvar
with open('config/config_personalizada.yaml', 'w') as f:
    yaml.dump(config, f)

# Usar config personalizada
subprocess.run([
    'cobol-to-docs',
    '--fontes', 'programas.txt',
    '--config', 'config/config_personalizada.yaml'
])
```

## Comandos Disponíveis

### Inicialização
```bash
# Básica - cria config/, data/, logs/, examples/
cobol-to-docs --init

# Personalizada
cobol-to-docs --init --config-dir ./minha_config --data-dir ./meus_dados

# Forçar reinicialização
cobol-to-docs --init --force-init
```

### Análise
```bash
# Análise básica
cobol-to-docs --fontes programas.txt

# Com copybooks
cobol-to-docs --fontes programas.txt --books copybooks.txt

# Análise consolidada
cobol-to-docs --fontes programas.txt --consolidado

# Modelo específico
cobol-to-docs --fontes programas.txt --models enhanced_mock
```

### Utilitários
```bash
# Status do sistema
cobol-to-docs --status

# Mostrar caminhos configurados
cobol-to-docs --show-paths

# Ajuda
cobol-to-docs --help
```

## Estrutura de Arquivos Após Instalação

### No Sistema (após pip install)
```
/usr/local/lib/python3.x/dist-packages/
├── main_enhanced.py          # Motor principal
├── config/                   # Configs padrão do pacote
├── data/                     # Knowledge base padrão
├── src/                      # Código fonte
└── ...
```

### No Projeto (após --init)
```
meu_projeto/
├── config/                   # Configs copiados do pacote
├── data/                     # Knowledge base copiado
├── logs/                     # Logs locais
├── examples/                 # Exemplos prontos
└── .cobol_analyzer_init      # Marca de inicialização
```

## Fluxo de Trabalho Recomendado

### 1. Configuração Inicial
```bash
# Instalar
pip install cobol-to-docs

# Criar projeto
mkdir meu_projeto_cobol
cd meu_projeto_cobol

# Inicializar (copia configs e dados do pacote)
cobol-to-docs --init
```

### 2. Personalização (Opcional)
```bash
# Editar configurações
nano config/config.yaml

# Editar prompts
nano config/prompts_enhanced.yaml
```

### 3. Uso Programático
```python
# Em seu script Python
import subprocess

# Analisar
resultado = subprocess.run([
    'cobol-to-docs',
    '--fontes', 'meus_programas.txt'
], capture_output=True, text=True)

# Processar resultado
if resultado.returncode == 0:
    print("Análise concluída!")
    # Processar arquivos de saída
```

## Vantagens do Uso Programático

###  Isolamento por Projeto
- Cada projeto tem sua configuração
- Não interfere com outros projetos
- Configurações independentes

###  Configuração Zero
- `--init` copia tudo do pacote
- Pronto para usar imediatamente
- Sem configuração manual

###  Flexibilidade Total
- Use via linha de comando
- Use via classes Python
- Integre com sistemas existentes

###  Escalabilidade
- Processe lotes de programas
- Integre com pipelines CI/CD
- Automatize análises

## Exemplos Práticos Incluídos

1. **`exemplo_simples_pip.py`** - Uso básico após pip install
2. **`exemplo_uso_programatico.py`** - Exemplos avançados
3. **`examples/`** - Programas COBOL de exemplo

## Suporte e Documentação

- **Logs**: Verifique `logs/cobol_to_docs_*.log`
- **Configuração**: Edite `config/config.yaml`
- **Prompts**: Personalize `config/prompts_*.yaml`
- **Knowledge Base**: Expanda `data/cobol_knowledge_base*.json`

---

**Versão**: 3.1.0  
**Instalação**: `pip install cobol-to-docs`  
**Inicialização**: `cobol-to-docs --init`  
**Uso**: Programático via Python ou linha de comando
