"""
Local Setup - Configuração automática do ambiente local COBOL Analyzer
Versão limpa sem ícones/emojis
"""

import os
import shutil
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any

class LocalSetup:
    """Gerenciador de configuração local do COBOL Analyzer"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.init_marker = ".cobol_analyzer_init"
    
    def is_initialized(self, base_dir: str = ".") -> bool:
        """Verifica se o ambiente já foi inicializado"""
        marker_path = Path(base_dir) / self.init_marker
        return marker_path.exists()
    
    def setup_local_environment(self, 
                              config_dir: Optional[str] = None,
                              data_dir: Optional[str] = None, 
                              logs_dir: Optional[str] = None,
                              examples_dir: Optional[str] = None,
                              force_init: bool = False) -> Dict[str, Any]:
        """
        Configura ambiente local completo
        
        Args:
            config_dir: Diretório para configurações (padrão: ./config)
            data_dir: Diretório para dados RAG (padrão: ./data)
            logs_dir: Diretório para logs (padrão: ./logs)
            examples_dir: Diretório para exemplos (padrão: ./examples)
            force_init: Forçar reconfiguração
            
        Returns:
            Dict com informações da configuração
        """
        
        # Definir diretórios padrão
        base_dir = Path(".")
        config_dir = Path(config_dir or "config")
        data_dir = Path(data_dir or "data")
        logs_dir = Path(logs_dir or "logs")
        examples_dir = Path(examples_dir or "examples")
        
        # Verificar se já foi inicializado
        if self.is_initialized() and not force_init:
            return {
                'already_initialized': True,
                'config_dir': str(config_dir.absolute()),
                'data_dir': str(data_dir.absolute()),
                'logs_dir': str(logs_dir.absolute()),
                'examples_dir': str(examples_dir.absolute())
            }
        
        created_directories = []
        
        # Criar diretórios
        for directory in [config_dir, data_dir, logs_dir, examples_dir]:
            if not directory.exists():
                directory.mkdir(parents=True, exist_ok=True)
                created_directories.append(str(directory))
                self.logger.info(f"Diretório criado: {directory}")
        
        # Copiar configurações padrão
        self._copy_default_configs(config_dir)
        
        # Copiar dados RAG padrão
        self._copy_default_rag_data(data_dir)
        
        # Criar exemplos
        self._create_examples(examples_dir)
        
        # Marcar como inicializado
        marker_path = base_dir / self.init_marker
        with open(marker_path, 'w') as f:
            f.write(f"Inicializado em: {Path.cwd()}\n")
        
        return {
            'success': True,
            'config_dir': str(config_dir.absolute()),
            'data_dir': str(data_dir.absolute()),
            'logs_dir': str(logs_dir.absolute()),
            'examples_dir': str(examples_dir.absolute()),
            'created_directories': created_directories
        }
    
    def _find_package_resource(self, resource_name: str) -> Optional[Path]:
        """Encontra recursos do pacote instalado"""
        
        # Locais possíveis para recursos
        possible_locations = [
            # Pacote instalado
            Path("/usr/local/lib/python3.11/dist-packages") / resource_name,
            Path("/usr/local/lib/python3.8/dist-packages") / resource_name,
            Path("/usr/local/lib/python3.9/dist-packages") / resource_name,
            Path("/usr/local/lib/python3.10/dist-packages") / resource_name,
            
            # Desenvolvimento local
            Path(__file__).parent.parent.parent / resource_name,
            Path(".") / resource_name,
            Path("..") / resource_name,
            Path("../..") / resource_name
        ]
        
        for location in possible_locations:
            if location.exists():
                return location
        
        return None
    
    def _copy_default_configs(self, config_dir: Path):
        """Copia configurações padrão"""
        
        try:
            # Tentar encontrar configurações do pacote instalado
            package_config = self._find_package_resource("config")
            
            if package_config and package_config.exists():
                # Copiar do pacote instalado
                for config_file in package_config.glob("*.yaml"):
                    dest_file = config_dir / config_file.name
                    if not dest_file.exists():
                        shutil.copy2(config_file, dest_file)
                        self.logger.info(f"Configuração copiada: {dest_file}")
            else:
                # Criar configuração básica
                self._create_basic_config(config_dir)
                
        except Exception as e:
            self.logger.warning(f"Erro ao copiar configurações: {e}")
            self._create_basic_config(config_dir)
    
    def _copy_default_rag_data(self, data_dir: Path):
        """Copia dados RAG padrão"""
        try:
            # Tentar encontrar dados do pacote instalado
            package_data = self._find_package_resource("data")
            
            if package_data and package_data.exists():
                # Copiar dados RAG do pacote
                for data_file in package_data.glob("*.json"):
                    dest_file = data_dir / data_file.name
                    if not dest_file.exists():
                        shutil.copy2(data_file, dest_file)
                        self.logger.info(f"Dados RAG copiados: {dest_file}")
            
            # Criar estrutura básica de dados RAG
            rag_dirs = ['embeddings', 'knowledge_base', 'sessions']
            for rag_dir in rag_dirs:
                rag_path = data_dir / rag_dir
                rag_path.mkdir(exist_ok=True)
            
            # Criar base de conhecimento inicial se não existir
            kb_file = data_dir / "cobol_knowledge_base.json"
            if not kb_file.exists():
                self._create_basic_knowledge_base(kb_file)
                
        except Exception as e:
            self.logger.warning(f"Erro ao copiar dados RAG: {e}")
    
    def _create_basic_config(self, config_dir: Path):
        """Cria configuração básica"""
        
        basic_config = {
            'models': {
                'default': 'enhanced_mock',
                'fallback': ['gpt-4', 'claude'],
                'temperature': 0.1,
                'max_tokens': 8000
            },
            'analysis': {
                'type': 'detailed',
                'include_business_rules': True,
                'include_comments': True
            },
            'output': {
                'format': 'markdown',
                'directory': './output'
            },
            'rag': {
                'enabled': True,
                'knowledge_base_path': 'data/cobol_knowledge_base.json',
                'max_context_items': 10
            }
        }
        
        config_file = config_dir / "config.yaml"
        with open(config_file, 'w') as f:
            import yaml
            yaml.dump(basic_config, f, default_flow_style=False)
    
    def _create_basic_knowledge_base(self, kb_file: Path):
        """Cria base de conhecimento básica"""
        
        basic_kb = {
            "cobol_patterns": [
                {
                    "pattern": "IDENTIFICATION DIVISION",
                    "description": "Divisão de identificação do programa"
                },
                {
                    "pattern": "DATA DIVISION", 
                    "description": "Divisão de definição de dados"
                },
                {
                    "pattern": "PROCEDURE DIVISION",
                    "description": "Divisão de procedimentos"
                }
            ],
            "business_rules": [],
            "modernization_tips": []
        }
        
        with open(kb_file, 'w') as f:
            json.dump(basic_kb, f, indent=2)
    
    def _create_examples(self, examples_dir: Path):
        """Cria arquivos de exemplo"""
        
        # Exemplo de lista de fontes
        fontes_file = examples_dir / "fontes.txt"
        if not fontes_file.exists():
            with open(fontes_file, 'w') as f:
                f.write("# Lista de programas COBOL para análise\n")
                f.write("# Um programa por linha\n")
                f.write("PROGRAMA1.CBL\n")
                f.write("PROGRAMA2.CBL\n")
        
        # Exemplo de lista de copybooks
        books_file = examples_dir / "books.txt"
        if not books_file.exists():
            with open(books_file, 'w') as f:
                f.write("# Lista de copybooks COBOL\n")
                f.write("# Um copybook por linha\n")
                f.write("COPYBOOK1.CPY\n")
                f.write("COPYBOOK2.CPY\n")
    
    def get_local_paths(self, 
                       config_dir: Optional[str] = None,
                       data_dir: Optional[str] = None,
                       logs_dir: Optional[str] = None) -> Dict[str, str]:
        """Retorna caminhos configurados"""
        
        return {
            'config_dir': str(Path(config_dir or "config").absolute()),
            'data_dir': str(Path(data_dir or "data").absolute()),
            'logs_dir': str(Path(logs_dir or "logs").absolute()),
            'examples_dir': str(Path("examples").absolute()),
            'base_dir': str(Path(".").absolute())
        }


def auto_setup_environment(config_dir: Optional[str] = None,
                          data_dir: Optional[str] = None,
                          logs_dir: Optional[str] = None,
                          force_init: bool = False) -> Dict[str, Any]:
    """
    Configuração automática do ambiente local
    
    Args:
        config_dir: Diretório personalizado para configurações
        data_dir: Diretório personalizado para dados RAG
        logs_dir: Diretório personalizado para logs
        force: Forçar reconfiguração mesmo se já inicializado
        
    Returns:
        dict: Informações sobre a configuração realizada
    """
    setup = LocalSetup()
    
    if not setup.is_initialized() or force_init:
        print("Configurando ambiente local do COBOL Analyzer...")
        
        result = setup.setup_local_environment(config_dir, data_dir, logs_dir, examples_dir="examples", force_init=force_init)
        print("Ambiente configurado com sucesso!")
        print(f"Configurações: {result['config_dir']}")
        print(f"Dados RAG: {result['data_dir']}")
        print(f"Logs: {result['logs_dir']}")
        print(f"Exemplos: {result['examples_dir']}")
        
        if result['created_directories']:
            print(f"Diretórios criados: {len(result['created_directories'])}")
        
        return result
    else:
        print("Ambiente já configurado.")
        return setup.get_local_paths(config_dir, data_dir, logs_dir)


if __name__ == "__main__":
    # Teste da configuração automática
    auto_setup_environment()
