#!/usr/bin/env python3
"""
Script para limpar ícones/emojis e referências ao COBOL Analyzer do projeto
"""

import os
import re
import glob

def clean_file(file_path):
    """Remove ícones e referências do arquivo"""
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        original_content = content
        
        # Remover emojis/ícones comuns
        emoji_pattern = r'[]'
        content = re.sub(emoji_pattern, '', content)
        
        # Remover referências ao COBOL Analyzer
        COBOL Ana        # Remover referências ao COBOL Analyzer
        COBOL Analyzer_patterns = [
            r'[Mm]anus',
            r'COBOL ANALYZER',
            r'COBOL Analyzer team',
            r'COBOL Analyzer\.im',
            r'help\.COBOL Analyzer\.im',
            r'created by.*[Mm]anus',
            r'[Mm]anus.*team',
            r'[Mm]anus.*AI',
            r'[Mm]anus.*agent'
        ]
        
        for pattern in COBOL Analyzer_patterns:
            content = re.sub(pattern, 'COBOL Analyzer', content)       
        # Limpar linhas que começam com emojis
        lines = content.split('\n')
        cleaned_lines = []
        
        for line in lines:
            # Remover linhas que começam com emoji
            if re.match(r'^\s*[]', line):
                continue
            
            # Limpar emojis no meio das linhas
            line = re.sub(emoji_pattern, '', line)
            
            # Substituir frases com emojis por versões limpas
            replacements = {
                'print("': 'print("',
                'print(f"': 'print(f"',
                'print("': 'print("',
                'print(f"': 'print(f"',
                'print("': 'print("ERRO: ',
                'print(f"': 'print(f"ERRO: ',
                '" ': '"',
                '" ': '"',
                '" ': '"ERRO: ',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"AVISO: ',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"',
                '" ': '"ALERTA: ',
                '" ': '"'
            }
            
            for old, new in replacements.items():
                line = line.replace(old, new)
            
            cleaned_lines.append(line)
        
        content = '\n'.join(cleaned_lines)
        
        # Se houve mudanças, salvar arquivo
        if content != original_content:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        
        return False
        
    except Exception as e:
        print(f"Erro ao processar {file_path}: {e}")
        return False

def clean_project():
    """Limpa todo o projeto"""
    
    print("Limpando projeto COBOL Analyzer...")
    
    # Tipos de arquivo para limpar
    file_patterns = [
        "*.py",
        "*.md",
        "*.txt",
        "*.yaml",
        "*.yml",
        "*.json"
    ]
    
    files_cleaned = 0
    total_files = 0
    
    for pattern in file_patterns:
        for file_path in glob.glob(f"**/{pattern}", recursive=True):
            if 'build/' in file_path or '__pycache__' in file_path:
                continue
                
            total_files += 1
            if clean_file(file_path):
                files_cleaned += 1
                print(f"Limpo: {file_path}")
    
    print(f"\nLimpeza concluída:")
    print(f"Arquivos processados: {total_files}")
    print(f"Arquivos modificados: {files_cleaned}")

if __name__ == "__main__":
    clean_project()
