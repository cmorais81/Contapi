#!/usr/bin/env python3
"""
Analisador Profissional Aprimorado de COBOL
Integra prompts otimizados com análise técnica detalhada
"""

import logging
import re
from typing import Dict, List, Any, Optional
from datetime import datetime

from prompts.professional_cobol_prompts import ProfessionalCOBOLPrompts
from providers.enhanced_provider_manager import EnhancedProviderManager
from utils.enhanced_cost_calculator import EnhancedCostCalculator

class EnhancedProfessionalAnalyzer:
    """
    Analisador profissional que combina análise automatizada com IA
    para gerar relatórios de qualidade empresarial
    """
    
    def __init__(self, provider_config: Dict[str, Any]):
        self.logger = logging.getLogger(__name__)
        self.provider_manager = EnhancedProviderManager(provider_config)
        self.cost_calculator = EnhancedCostCalculator()
        self.prompts = ProfessionalCOBOLPrompts()
        
    def analyze_program_comprehensive(self, 
                                    program: Any, 
                                    model: str = "luzia",
                                    copybooks: Dict[str, str] = None) -> Dict[str, Any]:
        """
        Realiza análise abrangente usando IA com prompts otimizados
        """
        self.logger.info(f"Iniciando análise profissional aprimorada do programa {program.name}")
        
        try:
            # Preparar copybooks relacionados
            copybook_content = ""
            if copybooks:
                copybook_content = "\n".join([f"COPYBOOK {name}:\n{content}" 
                                            for name, content in copybooks.items()])
            
            # Análise principal com prompt abrangente
            main_analysis = self._execute_comprehensive_analysis(
                program, model, copybook_content
            )
            
            # Análises específicas complementares
            business_rules = self._extract_business_rules(program, model)
            integrations = self._analyze_integrations(program, model)
            performance = self._analyze_performance(program, model)
            modernization = self._assess_modernization(program, model)
            quality_metrics = self._calculate_quality_metrics(program, model)
            
            # Consolidar resultados
            consolidated_analysis = {
                'program_info': self._extract_basic_info(program),
                'main_analysis': main_analysis,
                'business_rules_detailed': business_rules,
                'integration_analysis': integrations,
                'performance_analysis': performance,
                'modernization_assessment': modernization,
                'quality_metrics': quality_metrics,
                'cost_analysis': self._get_analysis_costs(),
                'analysis_metadata': {
                    'timestamp': datetime.now().isoformat(),
                    'model_used': model,
                    'analysis_version': '2.0',
                    'analyzer': 'EnhancedProfessionalAnalyzer'
                }
            }
            
            self.logger.info(f"Análise profissional concluída para {program.name}")
            return consolidated_analysis
            
        except Exception as e:
            self.logger.error(f"Erro na análise profissional de {program.name}: {e}", exc_info=True)
            return self._generate_error_analysis(program, str(e))
    
    def _execute_comprehensive_analysis(self, program: Any, model: str, copybooks: str) -> Dict[str, Any]:
        """Executa análise abrangente principal"""
        prompt = self.prompts.get_comprehensive_analysis_prompt(
            program.name, program.content, copybooks
        )
        
        # Criar request para análise
        request = type('AIRequest', (), {
            'prompt': prompt,
            'model': model,
            'max_tokens': 8000,
            'temperature': 0.1
        })()
        
        response = self.provider_manager.analyze(request)
        
        if response.get('success'):
            # Calcular custos
            cost_info = self.cost_calculator.tokens_analytics(
                response.get('metadata', {}), model
            )
            
            return {
                'success': True,
                'analysis_content': response.get('content', ''),
                'tokens_used': cost_info.get('total_tokens', 0),
                'cost_usd': cost_info.get('cost', 0.0),
                'cost_brl': cost_info.get('cost_brl', 0.0),
                'processing_time': response.get('processing_time', 0)
            }
        else:
            return {
                'success': False,
                'error': response.get('error', 'Erro desconhecido'),
                'tokens_used': 0,
                'cost_usd': 0.0,
                'cost_brl': 0.0
            }
    
    def _extract_business_rules(self, program: Any, model: str) -> Dict[str, Any]:
        """Extrai regras de negócio específicas"""
        prompt = self.prompts.get_business_rules_extraction_prompt(
            program.name, program.content
        )
        
        # Criar request para análise
        request = type('AIRequest', (), {
            'prompt': prompt,
            'model': model,
            'max_tokens': 8000,
            'temperature': 0.1
        })()
        
        response = self.provider_manager.analyze(request)
        
        if response.get('success'):
            cost_info = self.cost_calculator.tokens_analytics(
                response.get('metadata', {}), model
            )
            
            # Processar resposta para extrair regras estruturadas
            rules = self._parse_business_rules_response(response.get('content', ''))
            
            return {
                'success': True,
                'rules_count': len(rules),
                'rules_detailed': rules,
                'analysis_content': response.get('content', ''),
                'tokens_used': cost_info.get('total_tokens', 0),
                'cost_brl': cost_info.get('cost_brl', 0.0)
            }
        else:
            return {
                'success': False,
                'error': response.get('error', 'Erro na extração de regras'),
                'rules_count': 0,
                'rules_detailed': []
            }
    
    def _analyze_integrations(self, program: Any, model: str) -> Dict[str, Any]:
        """Analisa integrações e interfaces"""
        prompt = self.prompts.get_integration_analysis_prompt(
            program.name, program.content
        )
        
        # Criar request para análise
        request = type('AIRequest', (), {
            'prompt': prompt,
            'model': model,
            'max_tokens': 8000,
            'temperature': 0.1
        })()
        
        response = self.provider_manager.analyze(request)
        
        if response.get('success'):
            cost_info = self.cost_calculator.tokens_analytics(
                response.get('metadata', {}), model
            )
            
            integrations = self._parse_integrations_response(response.get('content', ''))
            
            return {
                'success': True,
                'integrations_count': len(integrations),
                'integrations_detailed': integrations,
                'analysis_content': response.get('content', ''),
                'tokens_used': cost_info.get('total_tokens', 0),
                'cost_brl': cost_info.get('cost_brl', 0.0)
            }
        else:
            return {
                'success': False,
                'error': response.get('error', 'Erro na análise de integrações'),
                'integrations_count': 0,
                'integrations_detailed': []
            }
    
    def _analyze_performance(self, program: Any, model: str) -> Dict[str, Any]:
        """Analisa considerações de performance"""
        prompt = self.prompts.get_performance_analysis_prompt(
            program.name, program.content
        )
        
        # Criar request para análise
        request = type('AIRequest', (), {
            'prompt': prompt,
            'model': model,
            'max_tokens': 8000,
            'temperature': 0.1
        })()
        
        response = self.provider_manager.analyze(request)
        
        if response.get('success'):
            cost_info = self.cost_calculator.tokens_analytics(
                response.get('metadata', {}), model
            )
            
            performance_issues = self._parse_performance_response(response.get('content', ''))
            
            return {
                'success': True,
                'issues_count': len(performance_issues),
                'performance_issues': performance_issues,
                'analysis_content': response.get('content', ''),
                'tokens_used': cost_info.get('total_tokens', 0),
                'cost_brl': cost_info.get('cost_brl', 0.0)
            }
        else:
            return {
                'success': False,
                'error': response.get('error', 'Erro na análise de performance'),
                'issues_count': 0,
                'performance_issues': []
            }
    
    def _assess_modernization(self, program: Any, model: str) -> Dict[str, Any]:
        """Avalia necessidades de modernização"""
        prompt = self.prompts.get_modernization_assessment_prompt(
            program.name, program.content
        )
        
        # Criar request para análise
        request = type('AIRequest', (), {
            'prompt': prompt,
            'model': model,
            'max_tokens': 8000,
            'temperature': 0.1
        })()
        
        response = self.provider_manager.analyze(request)
        
        if response.get('success'):
            cost_info = self.cost_calculator.tokens_analytics(
                response.get('metadata', {}), model
            )
            
            modernization_data = self._parse_modernization_response(response.get('content', ''))
            
            return {
                'success': True,
                'priority': modernization_data.get('priority', 'MÉDIA'),
                'obsolete_features': modernization_data.get('obsolete_features', []),
                'recommendations': modernization_data.get('recommendations', []),
                'estimated_effort': modernization_data.get('estimated_effort', 'N/A'),
                'analysis_content': response.get('content', ''),
                'tokens_used': cost_info.get('total_tokens', 0),
                'cost_brl': cost_info.get('cost_brl', 0.0)
            }
        else:
            return {
                'success': False,
                'error': response.get('error', 'Erro na avaliação de modernização'),
                'priority': 'BAIXA',
                'obsolete_features': [],
                'recommendations': []
            }
    
    def _calculate_quality_metrics(self, program: Any, model: str) -> Dict[str, Any]:
        """Calcula métricas de qualidade"""
        prompt = self.prompts.get_quality_metrics_prompt(
            program.name, program.content
        )
        
        # Criar request para análise
        request = type('AIRequest', (), {
            'prompt': prompt,
            'model': model,
            'max_tokens': 8000,
            'temperature': 0.1
        })()
        
        response = self.provider_manager.analyze(request)
        
        if response.get('success'):
            cost_info = self.cost_calculator.tokens_analytics(
                response.get('metadata', {}), model
            )
            
            metrics = self._parse_quality_metrics_response(response.get('content', ''))
            
            return {
                'success': True,
                'cyclomatic_complexity': metrics.get('cyclomatic_complexity', 0),
                'maintainability_index': metrics.get('maintainability_index', 0),
                'code_quality_score': metrics.get('quality_score', 0),
                'quality_level': metrics.get('quality_level', 'REGULAR'),
                'detailed_metrics': metrics,
                'analysis_content': response.get('content', ''),
                'tokens_used': cost_info.get('total_tokens', 0),
                'cost_brl': cost_info.get('cost_brl', 0.0)
            }
        else:
            return {
                'success': False,
                'error': response.get('error', 'Erro no cálculo de métricas'),
                'cyclomatic_complexity': 0,
                'maintainability_index': 0,
                'code_quality_score': 0,
                'quality_level': 'DESCONHECIDO'
            }
    
    def _extract_basic_info(self, program: Any) -> Dict[str, Any]:
        """Extrai informações básicas do programa"""
        lines = program.content.split('\n')
        
        # Extrair informações básicas
        program_id = self._extract_program_id(lines)
        author = self._extract_author(lines)
        date_written = self._extract_date_written(lines)
        
        # Contar elementos básicos
        total_lines = len(lines)
        code_lines = len([line for line in lines if line.strip() and not line.strip().startswith('*')])
        comment_lines = len([line for line in lines if line.strip().startswith('*')])
        
        return {
            'program_id': program_id,
            'author': author,
            'date_written': date_written,
            'total_lines': total_lines,
            'code_lines': code_lines,
            'comment_lines': comment_lines,
            'comment_ratio': comment_lines / total_lines if total_lines > 0 else 0,
            'size_bytes': len(program.content)
        }
    
    def _get_analysis_costs(self) -> Dict[str, Any]:
        """Obtém custos da análise atual"""
        return self.cost_calculator.get_session_summary()
    
    def _generate_error_analysis(self, program: Any, error: str) -> Dict[str, Any]:
        """Gera análise de erro quando falha"""
        return {
            'program_info': self._extract_basic_info(program),
            'main_analysis': {'success': False, 'error': error},
            'business_rules_detailed': {'success': False, 'rules_count': 0},
            'integration_analysis': {'success': False, 'integrations_count': 0},
            'performance_analysis': {'success': False, 'issues_count': 0},
            'modernization_assessment': {'success': False, 'priority': 'DESCONHECIDO'},
            'quality_metrics': {'success': False, 'quality_level': 'DESCONHECIDO'},
            'cost_analysis': {'total_cost_brl': 0.0},
            'analysis_metadata': {
                'timestamp': datetime.now().isoformat(),
                'error': error,
                'status': 'FAILED'
            }
        }
    
    # Métodos de parsing das respostas da IA
    def _parse_business_rules_response(self, content: str) -> List[Dict[str, Any]]:
        """Parseia resposta de regras de negócio"""
        rules = []
        # Implementação simplificada - em produção seria mais robusta
        lines = content.split('\n')
        current_rule = {}
        
        for line in lines:
            if line.startswith('- **ID**:'):
                if current_rule:
                    rules.append(current_rule)
                current_rule = {'id': line.split(':')[1].strip()}
            elif line.startswith('- **Linha**:') and current_rule:
                current_rule['line'] = line.split(':')[1].strip()
            elif line.startswith('- **Tipo**:') and current_rule:
                current_rule['type'] = line.split(':')[1].strip()
            elif line.startswith('- **Descrição**:') and current_rule:
                current_rule['description'] = line.split(':')[1].strip()
            elif line.startswith('- **Criticidade**:') and current_rule:
                current_rule['criticality'] = line.split(':')[1].strip()
        
        if current_rule:
            rules.append(current_rule)
        
        return rules
    
    def _parse_integrations_response(self, content: str) -> List[Dict[str, Any]]:
        """Parseia resposta de integrações"""
        integrations = []
        # Implementação simplificada
        if 'EXEC SQL' in content:
            integrations.append({'type': 'Database', 'technology': 'SQL'})
        if 'EXEC CICS' in content:
            integrations.append({'type': 'Transaction', 'technology': 'CICS'})
        if 'CALL ' in content:
            integrations.append({'type': 'Program', 'technology': 'COBOL'})
        if 'OPEN ' in content or 'READ ' in content:
            integrations.append({'type': 'File', 'technology': 'Sequential/VSAM'})
        
        return integrations
    
    def _parse_performance_response(self, content: str) -> List[Dict[str, Any]]:
        """Parseia resposta de performance"""
        issues = []
        # Implementação simplificada
        if 'GO TO' in content:
            issues.append({'type': 'Code Structure', 'severity': 'MEDIUM', 'description': 'GO TO statements found'})
        if 'nested' in content.lower():
            issues.append({'type': 'Complexity', 'severity': 'HIGH', 'description': 'High nesting levels'})
        
        return issues
    
    def _parse_modernization_response(self, content: str) -> Dict[str, Any]:
        """Parseia resposta de modernização"""
        return {
            'priority': 'MÉDIA',  # Extrair da resposta
            'obsolete_features': ['GO TO statements'],  # Extrair da resposta
            'recommendations': ['Refactor conditional logic'],  # Extrair da resposta
            'estimated_effort': '2-4 weeks'  # Extrair da resposta
        }
    
    def _parse_quality_metrics_response(self, content: str) -> Dict[str, Any]:
        """Parseia resposta de métricas de qualidade"""
        return {
            'cyclomatic_complexity': 15,  # Extrair da resposta
            'maintainability_index': 65,  # Extrair da resposta
            'quality_score': 70,  # Extrair da resposta
            'quality_level': 'BOA'  # Extrair da resposta
        }
    
    # Métodos auxiliares
    def _extract_program_id(self, lines: List[str]) -> str:
        """Extrai ID do programa"""
        for line in lines:
            if 'PROGRAM-ID' in line.upper():
                parts = line.split('.')
                if len(parts) > 0:
                    return parts[0].split()[-1]
        return "Unknown"
    
    def _extract_author(self, lines: List[str]) -> str:
        """Extrai autor do programa"""
        for line in lines:
            if 'AUTHOR' in line.upper():
                return line.split('AUTHOR')[-1].strip().rstrip('.')
        return "Unknown"
    
    def _extract_date_written(self, lines: List[str]) -> str:
        """Extrai data de criação"""
        for line in lines:
            if 'DATE-WRITTEN' in line.upper():
                return line.split('DATE-WRITTEN')[-1].strip().rstrip('.')
        return "Unknown"
