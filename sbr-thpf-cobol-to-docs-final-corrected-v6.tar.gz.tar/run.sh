#!/bin/bash

# Get the directory where the run.sh script is located (sbr-thpf-cobol-to-docs)
SCRIPT_DIR=$(dirname "$(realpath "$0")")

# Add the cobol_to_docs directory to PYTHONPATH
# This allows Python to find 'src' as a top-level package when imported from main.py
export PYTHONPATH="$SCRIPT_DIR/cobol_to_docs:$PYTHONPATH"

# Execute the main.py script with all arguments passed to run.sh
python3 "$SCRIPT_DIR/cobol_to_docs/runner/main.py" "$@"
