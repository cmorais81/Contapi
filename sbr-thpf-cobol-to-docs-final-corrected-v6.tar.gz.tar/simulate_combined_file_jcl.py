
import sys
import os
import json
from unittest.mock import patch, MagicMock

# Adicionar o diretório raiz do projeto ao sys.path
project_root = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, project_root)
# Adicionar o subdiretório 'cobol_to_docs' que contém 'src' e 'runner'
cobol_to_docs_path = os.path.join(project_root, 'cobol_to_docs')
sys.path.insert(0, cobol_to_docs_path)

# Importar main como um módulo para poder chamar sua função principal
# e evitar problemas com sys.argv global
from cobol_to_docs.runner import main as main_module
from cobol_to_docs.src.providers.base_provider import AIRequest

# Caminhos para os arquivos de teste
TEST_COBOL_FILE = os.path.join(project_root, "upload", "BSPD.DB.MZ.T520BF9.MZ3C0030")
TEST_JCL_FILE = os.path.join(project_root, "examples", "test.jcl")
OUTPUT_DIR = os.path.join(project_root, "output_combined_test")
GENERATED_PAYLOAD_FILE = os.path.join(OUTPUT_DIR, "generated_luzia_payload_combined.json")

# Mock para capturar o payload enviado ao LuziaProvider
class MockLuziaProvider:
    def __init__(self, *args, **kwargs):
        self.captured_payload = None
        self.mock_response = MagicMock()
        self.mock_response.success = True
        self.mock_response.content = "Análise simulada do programa COBOL e JCL."
        self.mock_response.tokens_used = 1000
        self.mock_response.model_used = "aws-claude-3-5-sonnet"
        self.mock_response.provider_used = "luzia"
        self.mock_response.original_prompt = "Original prompt mock"
        self.mock_response.prompt_used = "Main prompt mock"

    def analyze(self, ai_request: AIRequest):
        self.captured_payload = ai_request.to_dict()
        return self.mock_response

    def get_token(self):
        return "mock_token"

    def check_status(self):
        return True

def run_test():
    print(f"\n--- Executando teste de arquivo combinado e JCL ---")
    print(f"COBOL File: {TEST_COBOL_FILE}")
    print(f"JCL File: {TEST_JCL_FILE}")
    print(f"Output Dir: {OUTPUT_DIR}")

    # Criar diretório de saída se não existir
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Mockar a chamada ao LuziaProvider para capturar o payload
    with patch("cobol_to_docs.src.providers.luzia_provider.LuziaProvider", MockLuziaProvider) as MockProviderClass:
        mock_provider_instance = MockProviderClass()
        
        # Simular argumentos da linha de comando para main.py
        # Usamos uma cópia de sys.argv para não afetar outros módulos
        original_argv = sys.argv.copy()
        sys.argv = [
            "main.py",
            "--program-path", TEST_COBOL_FILE,
            "--jcl-file", TEST_JCL_FILE,
            "--output", OUTPUT_DIR,
            "--models", "luzia", # Solicita o provedor Luzia, que será mapeado para seu modelo padrão
            "--log-level", "DEBUG"
        ]

        try:
            # Executar a função main do módulo main.py
            main_module.main()
        finally:
            # Restaurar sys.argv
            sys.argv = original_argv

        # Salvar o payload capturado
        if mock_provider_instance.captured_payload:
            with open(GENERATED_PAYLOAD_FILE, "w", encoding="utf-8") as f:
                json.dump(mock_provider_instance.captured_payload, f, indent=4, ensure_ascii=False)
            print(f"Payload da Luzia capturado e salvo em: {GENERATED_PAYLOAD_FILE}")
        else:
            print("Erro: Nenhum payload da Luzia foi capturado.")

if __name__ == "__main__":
    run_test()

