# COBOL to Docs

Este projeto visa analisar programas COBOL e gerar documentação funcional e payloads para provedores de IA, como o Luzia.

## Instalação

Para instalar o pacote, siga os passos abaixo:

1.  **Clone o repositório:**

    ```bash
    git clone <URL_DO_REPOSITORIO>
    cd sbr-thpf-cobol-to-docs
    ```

2.  **Crie e ative um ambiente virtual (recomendado):**

    ```bash
    python3 -m venv venv
    source venv/bin/activate
    ```

3.  **Instale as dependências:**

    ```bash
    pip install -r requirements.txt
    pip install .
    ```

## Uso

O principal ponto de entrada da aplicação é o script `main.py` dentro do módulo `cobol_to_docs.runner`. Ele pode ser executado diretamente ou como um módulo Python.

### Execução via `python -m`

```bash
python -m cobol_to_docs.runner.main --program-path <caminho/para/seu/programa.cbl> --output <diretorio/de/saida> --models <modelo_ia>
```

### Argumentos:

-   `--program-path`: Caminho para o arquivo COBOL a ser analisado.
-   `--output`: Diretório onde os resultados (JSON do payload, documentação Markdown) serão salvos.
-   `--models`: Nome do modelo de IA a ser utilizado (ex: `enhanced_mock`).
-   `--log-level`: Nível de log (DEBUG, INFO, WARNING, ERROR, CRITICAL). Padrão: INFO.

### Exemplo de Uso:

Assumindo que você está na raiz do projeto `sbr-thpf-cobol-to-docs` e tem um arquivo COBOL de exemplo em `examples/HELLOWLD.cbl`:

```bash
python -m cobol_to_docs.runner.main --program-path examples/HELLOWLD.cbl --output output_dir --models enhanced_mock --log-level DEBUG
```

Isso irá gerar os arquivos de saída no diretório `output_dir`.

## Configuração

As configurações da aplicação são gerenciadas através do arquivo `config/config.yaml`.

### Exemplo de `config.yaml`:

```yaml
ai:
  primary_provider: enhanced_mock
  fallback_providers:
    - basic
  enable_fallback: True
  global_timeout: 120
  global_max_tokens: 4000
  providers:
    enhanced_mock:
      enabled: True
      response_delay: 0.1
      enable_phasing: True
      max_tokens_per_phase: 2000
      simulate_realistic_tokens: True
      models:
        enhanced-mock-gpt-4:
          name: enhanced-mock-gpt-4
          max_tokens: 8192
          temperature: 0.1
          default: True
    basic:
      enabled: True
      max_tokens: 1000
      models:
        basic-fallback:
          name: basic-fallback
          max_tokens: 1000
          temperature: 0.7
          default: true
```

## Contribuição

Sinta-se à vontade para contribuir com o projeto. Por favor, siga as diretrizes de contribuição e o código de conduta.

## Licença

Este projeto está licenciado sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.
