#!/usr/bin/env python3
"""
COBOL to Docs - Ponto de entrada principal simplificado
"""

import sys
import os
import argparse
import shutil
from pathlib import Path

def init_project(target_dir=None):
    """Inicializa um projeto COBOL Analyzer copiando todos os arquivos necessários"""
    if target_dir is None:
        target_dir = Path.cwd()
    else:
        target_dir = Path(target_dir)
    
    print(f"Inicializando projeto COBOL Analyzer em: {target_dir}")
    
    # Caminho fixo do pacote instalado
    package_path = Path("/usr/local/lib/python3.11/dist-packages/cobol_to_docs")
    
    # Diretórios a serem copiados
    dirs_to_copy = ["config", "data", "examples"]
    
    success_count = 0
    
    for dir_name in dirs_to_copy:
        source_dir = package_path / dir_name
        target_subdir = target_dir / dir_name
        
        if source_dir.exists():
            try:
                if target_subdir.exists():
                    print(f"Diretório {dir_name} já existe, sobrescrevendo...")
                    shutil.rmtree(target_subdir)
                
                shutil.copytree(source_dir, target_subdir)
                print(f"Copiado: {dir_name}/")
                success_count += 1
            except Exception as e:
                print(f"Erro ao copiar {dir_name}: {e}")
        else:
            print(f"Diretório {dir_name} não encontrado em {source_dir}")
    
    # Criar diretórios de trabalho
    work_dirs = ["logs", "output", "temp"]
    for work_dir in work_dirs:
        work_path = target_dir / work_dir
        work_path.mkdir(exist_ok=True)
        print(f"Criado: {work_dir}/")
    
    # Criar arquivo de exemplo de fontes se não existir
    fontes_example = target_dir / "fontes_exemplo.txt"
    if not fontes_example.exists():
        with open(fontes_example, "w", encoding="utf-8") as f:
            f.write("# Lista de programas COBOL para análise\n")
            f.write("# Um programa por linha\n")
            f.write("# Exemplo:\n")
            f.write("# programa1.cbl\n")
            f.write("# programa2.cbl\n")
        print("Criado: fontes_exemplo.txt")
    
    print(f"\nInicialização concluída!")
    print(f"Arquivos copiados: {success_count}/{len(dirs_to_copy)}")
    print(f"\nPara usar:")
    print(f"1. Configure suas credenciais de IA no arquivo config/config.yaml")
    print(f"2. Liste seus programas COBOL em um arquivo (ex: fontes_exemplo.txt)")
    print(f"3. Execute: python config/../runner/main.py --fontes fontes_exemplo.txt --models enhanced_mock")

def main():
    """Função principal"""
    parser = argparse.ArgumentParser(description="COBOL to Docs v3.1.0")
    parser.add_argument("--init", action="store_true", help="Inicializar projeto")
    parser.add_argument("--init-dir", type=str, help="Diretório para inicialização")
    
    args = parser.parse_args()
    
    if args.init:
        init_project(args.init_dir)
        return 0
    
    print("Use --init para inicializar um projeto")
    return 0

if __name__ == "__main__":
    sys.exit(main())
