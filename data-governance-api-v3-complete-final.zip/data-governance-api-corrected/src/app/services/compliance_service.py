"""
Serviço de compliance para Data Governance API
Implementa validação de compliance e princípios SOLID
"""

from typing import List, Optional, Dict, Any
from uuid import UUID
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_
from datetime import datetime, timedelta
import logging

from .interfaces import IComplianceService, IAuditService
from ..models import DataContract, ComplianceFramework, User
from ..schemas import (
    ComplianceFrameworkCreate, ComplianceFrameworkResponse,
    DataClassification, ContractStatus
)
from ..utils.exceptions import (
    EntityNotFoundError, ComplianceViolationError,
    ValidationError, BusinessRuleViolationError
)

logger = logging.getLogger(__name__)


class ComplianceRuleEngine:
    """
    Engine de regras de compliance
    Implementa SRP: responsável apenas pela lógica de regras
    """
    
    # Mapeamento de frameworks por país
    COUNTRY_FRAMEWORKS = {
        'BRA': ['LGPD', 'BACEN'],
        'USA': ['CCPA', 'HIPAA', 'SOX'],
        'DEU': ['GDPR', 'BDSG'],
        'GBR': ['GDPR', 'DPA'],
        'FRA': ['GDPR', 'CNIL'],
        'CAN': ['PIPEDA'],
        'AUS': ['APP'],
        'JPN': ['APPI'],
        'CHN': ['PIPL'],
        'IND': ['PDPB']
    }
    
    # Requisitos de retenção por framework (em dias)
    RETENTION_REQUIREMENTS = {
        'GDPR': {'max_retention': 2555, 'default_retention': 1095},  # 7 anos max, 3 anos default
        'LGPD': {'max_retention': 1825, 'default_retention': 1095},  # 5 anos max, 3 anos default
        'CCPA': {'max_retention': 1095, 'default_retention': 365},   # 3 anos max, 1 ano default
        'HIPAA': {'max_retention': 2190, 'default_retention': 1825}, # 6 anos max, 5 anos default
        'SOX': {'max_retention': 2555, 'default_retention': 2190},   # 7 anos max, 6 anos default
        'PIPEDA': {'max_retention': 1095, 'default_retention': 730}  # 3 anos max, 2 anos default
    }
    
    # Classificações permitidas por framework
    CLASSIFICATION_REQUIREMENTS = {
        'GDPR': {
            'allowed_classifications': ['public', 'internal', 'confidential', 'restricted'],
            'requires_consent': ['confidential', 'restricted'],
            'requires_dpo_approval': ['restricted']
        },
        'LGPD': {
            'allowed_classifications': ['public', 'internal', 'confidential', 'restricted'],
            'requires_consent': ['confidential', 'restricted'],
            'requires_dpo_approval': ['restricted']
        },
        'HIPAA': {
            'allowed_classifications': ['internal', 'confidential', 'restricted'],
            'requires_consent': ['confidential', 'restricted'],
            'requires_encryption': ['confidential', 'restricted']
        }
    }
    
    @classmethod
    def get_applicable_frameworks(cls, country_code: str) -> List[str]:
        """Obtém frameworks aplicáveis para um país"""
        return cls.COUNTRY_FRAMEWORKS.get(country_code, [])
    
    @classmethod
    def validate_retention_period(cls, framework_code: str, retention_days: int) -> Dict[str, Any]:
        """Valida período de retenção para um framework"""
        requirements = cls.RETENTION_REQUIREMENTS.get(framework_code)
        if not requirements:
            return {'valid': True, 'warnings': []}
        
        warnings = []
        valid = True
        
        if retention_days > requirements['max_retention']:
            valid = False
            warnings.append(
                f"Período de retenção ({retention_days} dias) excede máximo permitido "
                f"pelo {framework_code} ({requirements['max_retention']} dias)"
            )
        
        if retention_days < requirements['default_retention']:
            warnings.append(
                f"Período de retenção ({retention_days} dias) é menor que recomendado "
                f"pelo {framework_code} ({requirements['default_retention']} dias)"
            )
        
        return {'valid': valid, 'warnings': warnings}
    
    @classmethod
    def validate_data_classification(
        cls, 
        framework_code: str, 
        classification: str
    ) -> Dict[str, Any]:
        """Valida classificação de dados para um framework"""
        requirements = cls.CLASSIFICATION_REQUIREMENTS.get(framework_code)
        if not requirements:
            return {'valid': True, 'requirements': []}
        
        valid = classification in requirements['allowed_classifications']
        compliance_requirements = []
        
        if classification in requirements.get('requires_consent', []):
            compliance_requirements.append('consent_required')
        
        if classification in requirements.get('requires_dpo_approval', []):
            compliance_requirements.append('dpo_approval_required')
        
        if classification in requirements.get('requires_encryption', []):
            compliance_requirements.append('encryption_required')
        
        return {
            'valid': valid,
            'requirements': compliance_requirements,
            'allowed_classifications': requirements['allowed_classifications']
        }


class ComplianceService(IComplianceService):
    """
    Implementação do serviço de compliance
    Implementa SRP: responsável apenas pela lógica de compliance
    Implementa DIP: depende de abstrações (interfaces)
    """
    
    def __init__(self, audit_service: IAuditService):
        self._audit_service = audit_service
        self._rule_engine = ComplianceRuleEngine()
    
    async def create_framework(
        self,
        framework_data: ComplianceFrameworkCreate,
        db: Session
    ) -> ComplianceFrameworkResponse:
        """
        Cria um novo framework de compliance
        """
        try:
            # Validar unicidade do código
            existing_framework = db.query(ComplianceFramework).filter(
                ComplianceFramework.framework_code == framework_data.framework_code
            ).first()
            
            if existing_framework:
                raise BusinessRuleViolationError(
                    f"Framework com código '{framework_data.framework_code}' já existe"
                )
            
            # Criar framework
            framework_dict = framework_data.dict()
            framework = ComplianceFramework(**framework_dict)
            
            db.add(framework)
            db.commit()
            
            logger.info(f"Framework de compliance {framework._id} criado")
            
            return await self._build_framework_response(framework)
            
        except Exception as e:
            db.rollback()
            logger.error(f"Erro ao criar framework de compliance: {e}")
            raise
    
    async def get_framework(
        self,
        framework_id: UUID,
        db: Session
    ) -> Optional[ComplianceFrameworkResponse]:
        """
        Obtém um framework por ID
        """
        try:
            framework = db.query(ComplianceFramework).filter(
                ComplianceFramework._id == framework_id
            ).first()
            
            if not framework:
                return None
            
            return await self._build_framework_response(framework)
            
        except Exception as e:
            logger.error(f"Erro ao obter framework {framework_id}: {e}")
            raise
    
    async def get_frameworks_by_country(
        self,
        country_code: str,
        db: Session
    ) -> List[ComplianceFrameworkResponse]:
        """
        Obtém frameworks aplicáveis a um país
        """
        try:
            # Obter frameworks aplicáveis pelo rule engine
            applicable_codes = self._rule_engine.get_applicable_frameworks(country_code)
            
            if not applicable_codes:
                return []
            
            # Buscar frameworks no banco
            frameworks = db.query(ComplianceFramework).filter(
                or_(
                    ComplianceFramework.framework_code.in_(applicable_codes),
                    ComplianceFramework.applicable_countries.contains([country_code])
                )
            ).all()
            
            framework_responses = []
            for framework in frameworks:
                response = await self._build_framework_response(framework)
                framework_responses.append(response)
            
            return framework_responses
            
        except Exception as e:
            logger.error(f"Erro ao obter frameworks para país {country_code}: {e}")
            raise
    
    async def validate_contract_compliance(
        self,
        contract_id: UUID,
        db: Session
    ) -> Dict[str, Any]:
        """
        Valida compliance de um contrato
        Implementa validação abrangente de compliance
        """
        try:
            # Obter contrato com frameworks
            contract = db.query(DataContract).options(
                joinedload(DataContract.compliance_frameworks)
            ).filter(DataContract._id == contract_id).first()
            
            if not contract:
                raise EntityNotFoundError(f"Contrato {contract_id} não encontrado")
            
            validation_result = {
                'contract_id': contract_id,
                'compliance_status': 'compliant',
                'violations': [],
                'warnings': [],
                'requirements': [],
                'frameworks_validated': [],
                'validation_timestamp': datetime.utcnow()
            }
            
            # Validar cada framework associado
            for framework in contract.compliance_frameworks:
                framework_validation = await self._validate_framework_compliance(
                    contract, framework
                )
                
                validation_result['frameworks_validated'].append({
                    'framework_code': framework.framework_code,
                    'framework_name': framework.framework_name,
                    'validation_result': framework_validation
                })
                
                # Agregar resultados
                if framework_validation['violations']:
                    validation_result['violations'].extend(framework_validation['violations'])
                    validation_result['compliance_status'] = 'non_compliant'
                
                if framework_validation['warnings']:
                    validation_result['warnings'].extend(framework_validation['warnings'])
                    if validation_result['compliance_status'] == 'compliant':
                        validation_result['compliance_status'] = 'warning'
                
                validation_result['requirements'].extend(framework_validation['requirements'])
            
            # Validar frameworks aplicáveis por país se não associados
            if contract.country_code:
                country_validation = await self._validate_country_compliance(
                    contract, db
                )
                validation_result.update(country_validation)
            
            return validation_result
            
        except Exception as e:
            logger.error(f"Erro ao validar compliance do contrato {contract_id}: {e}")
            raise
    
    async def generate_compliance_report(
        self,
        contract_id: UUID,
        framework_id: UUID,
        db: Session
    ) -> Dict[str, Any]:
        """
        Gera relatório de compliance detalhado
        """
        try:
            # Obter contrato e framework
            contract = db.query(DataContract).filter(
                DataContract._id == contract_id
            ).first()
            
            framework = db.query(ComplianceFramework).filter(
                ComplianceFramework._id == framework_id
            ).first()
            
            if not contract:
                raise EntityNotFoundError(f"Contrato {contract_id} não encontrado")
            
            if not framework:
                raise EntityNotFoundError(f"Framework {framework_id} não encontrado")
            
            # Validar compliance específico
            validation = await self._validate_framework_compliance(contract, framework)
            
            # Gerar relatório detalhado
            report = {
                'report_id': str(UUID()),
                'generated_at': datetime.utcnow(),
                'contract': {
                    'id': contract._id,
                    'name': contract.contract_name,
                    'version': contract.contract_version,
                    'status': contract.contract_status,
                    'classification': contract.data_classification
                },
                'framework': {
                    'id': framework._id,
                    'name': framework.framework_name,
                    'code': framework.framework_code
                },
                'compliance_assessment': validation,
                'recommendations': self._generate_compliance_recommendations(
                    contract, framework, validation
                ),
                'action_items': self._generate_action_items(validation),
                'risk_assessment': self._assess_compliance_risk(validation),
                'next_review_date': datetime.utcnow() + timedelta(days=90)
            }
            
            return report
            
        except Exception as e:
            logger.error(f"Erro ao gerar relatório de compliance: {e}")
            raise
    
    async def check_expiring_contracts(
        self,
        days_ahead: int = 30,
        db: Session = None
    ) -> List[Dict[str, Any]]:
        """
        Verifica contratos que expiram em breve
        Implementa monitoramento proativo de compliance
        """
        try:
            cutoff_date = datetime.utcnow() + timedelta(days=days_ahead)
            
            expiring_contracts = db.query(DataContract).filter(
                and_(
                    DataContract.expiration_date.isnot(None),
                    DataContract.expiration_date <= cutoff_date,
                    DataContract.contract_status == ContractStatus.ACTIVE
                )
            ).all()
            
            expiring_list = []
            for contract in expiring_contracts:
                days_until_expiration = (contract.expiration_date - datetime.utcnow()).days
                
                expiring_list.append({
                    'contract_id': contract._id,
                    'contract_name': contract.contract_name,
                    'expiration_date': contract.expiration_date,
                    'days_until_expiration': days_until_expiration,
                    'risk_level': 'high' if days_until_expiration <= 7 else 'medium',
                    'compliance_frameworks': [
                        fw.framework_code for fw in contract.compliance_frameworks
                    ]
                })
            
            return expiring_list
            
        except Exception as e:
            logger.error(f"Erro ao verificar contratos expirando: {e}")
            raise
    
    async def _validate_framework_compliance(
        self,
        contract: DataContract,
        framework: ComplianceFramework
    ) -> Dict[str, Any]:
        """
        Valida compliance para um framework específico
        Implementa SRP: responsável apenas pela validação de framework
        """
        violations = []
        warnings = []
        requirements = []
        
        # Validar período de retenção
        if contract.data_retention_days:
            retention_validation = self._rule_engine.validate_retention_period(
                framework.framework_code,
                contract.data_retention_days
            )
            
            if not retention_validation['valid']:
                violations.extend(retention_validation['warnings'])
            else:
                warnings.extend(retention_validation['warnings'])
        
        # Validar classificação de dados
        classification_validation = self._rule_engine.validate_data_classification(
            framework.framework_code,
            contract.data_classification
        )
        
        if not classification_validation['valid']:
            violations.append(
                f"Classificação '{contract.data_classification}' não permitida pelo {framework.framework_code}"
            )
        
        requirements.extend(classification_validation['requirements'])
        
        # Validar datas de vigência
        if contract.effective_date and contract.expiration_date:
            if contract.effective_date >= contract.expiration_date:
                violations.append("Data de vigência deve ser anterior à data de expiração")
        
        # Validar status do contrato
        if contract.contract_status == ContractStatus.ACTIVE and not contract.approved_at:
            violations.append("Contrato ativo deve ter aprovação registrada")
        
        return {
            'framework_code': framework.framework_code,
            'violations': violations,
            'warnings': warnings,
            'requirements': requirements,
            'compliant': len(violations) == 0
        }
    
    async def _validate_country_compliance(
        self,
        contract: DataContract,
        db: Session
    ) -> Dict[str, Any]:
        """
        Valida compliance baseado no país do contrato
        """
        applicable_frameworks = self._rule_engine.get_applicable_frameworks(
            contract.country_code
        )
        
        missing_frameworks = []
        associated_codes = [fw.framework_code for fw in contract.compliance_frameworks]
        
        for framework_code in applicable_frameworks:
            if framework_code not in associated_codes:
                missing_frameworks.append(framework_code)
        
        country_validation = {
            'country_code': contract.country_code,
            'applicable_frameworks': applicable_frameworks,
            'missing_frameworks': missing_frameworks
        }
        
        if missing_frameworks:
            country_validation['warnings'] = [
                f"Frameworks recomendados para {contract.country_code} não associados: {', '.join(missing_frameworks)}"
            ]
        
        return {'country_validation': country_validation}
    
    def _generate_compliance_recommendations(
        self,
        contract: DataContract,
        framework: ComplianceFramework,
        validation: Dict[str, Any]
    ) -> List[str]:
        """Gera recomendações de compliance"""
        recommendations = []
        
        if validation['violations']:
            recommendations.append("Corrigir violações identificadas antes da ativação")
        
        if validation['warnings']:
            recommendations.append("Revisar avisos e considerar ajustes")
        
        if 'consent_required' in validation['requirements']:
            recommendations.append("Implementar mecanismo de coleta de consentimento")
        
        if 'encryption_required' in validation['requirements']:
            recommendations.append("Implementar criptografia para dados sensíveis")
        
        return recommendations
    
    def _generate_action_items(self, validation: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Gera itens de ação baseados na validação"""
        action_items = []
        
        for violation in validation.get('violations', []):
            action_items.append({
                'type': 'violation',
                'description': violation,
                'priority': 'high',
                'due_date': datetime.utcnow() + timedelta(days=7)
            })
        
        for warning in validation.get('warnings', []):
            action_items.append({
                'type': 'warning',
                'description': warning,
                'priority': 'medium',
                'due_date': datetime.utcnow() + timedelta(days=30)
            })
        
        return action_items
    
    def _assess_compliance_risk(self, validation: Dict[str, Any]) -> Dict[str, Any]:
        """Avalia risco de compliance"""
        violation_count = len(validation.get('violations', []))
        warning_count = len(validation.get('warnings', []))
        
        if violation_count > 0:
            risk_level = 'high'
            risk_score = min(100, 50 + (violation_count * 25))
        elif warning_count > 2:
            risk_level = 'medium'
            risk_score = 25 + (warning_count * 5)
        else:
            risk_level = 'low'
            risk_score = warning_count * 5
        
        return {
            'risk_level': risk_level,
            'risk_score': risk_score,
            'factors': {
                'violations': violation_count,
                'warnings': warning_count
            }
        }
    
    async def _build_framework_response(
        self,
        framework: ComplianceFramework
    ) -> ComplianceFrameworkResponse:
        """
        Constrói response do framework
        Implementa SRP: responsável apenas pela construção da resposta
        """
        framework_dict = {
            '_id': framework._id,
            'framework_name': framework.framework_name,
            'framework_code': framework.framework_code,
            'description': framework.description,
            'applicable_countries': framework.applicable_countries,
            'data_retention_requirements': framework.data_retention_requirements,
            'consent_requirements': framework.consent_requirements,
            'created_at': framework.created_at,
            'updated_at': framework.updated_at
        }
        
        return ComplianceFrameworkResponse(**framework_dict)

