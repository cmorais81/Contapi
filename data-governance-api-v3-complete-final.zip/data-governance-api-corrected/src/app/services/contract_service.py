"""
Implementação do serviço de contratos de dados
Implementa princípios SOLID e Clean Architecture
"""

from typing import List, Optional, Dict, Any, Tuple
from uuid import UUID
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, desc, asc, func
from datetime import datetime
import logging

from .interfaces import IDataContractService, IAuditService, IValidationService
from ..models import DataContract, User, ComplianceFramework
from ..schemas import (
    DataContractCreate, DataContractUpdate, DataContractResponse,
    ContractFilters, PaginationParams, ContractStatus
)
from ..utils.exceptions import (
    EntityNotFoundError, EntityAlreadyExistsError, 
    BusinessRuleViolationError, ValidationError
)

logger = logging.getLogger(__name__)


class DataContractService(IDataContractService):
    """
    Implementação do serviço de contratos de dados
    Implementa SRP: responsável apenas pela lógica de contratos
    Implementa DIP: depende de abstrações (interfaces)
    """
    
    def __init__(
        self, 
        audit_service: IAuditService,
        validation_service: IValidationService
    ):
        self._audit_service = audit_service
        self._validation_service = validation_service
    
    async def create_contract(
        self, 
        contract_data: DataContractCreate, 
        user_id: UUID,
        db: Session
    ) -> DataContractResponse:
        """
        Cria um novo contrato de dados
        Implementa validações de negócio e auditoria
        """
        try:
            # Validar unicidade do nome e versão
            is_unique = await self._validation_service.validate_contract_name_uniqueness(
                contract_data.contract_name,
                contract_data.contract_version,
                None,
                db
            )
            
            if not is_unique:
                raise EntityAlreadyExistsError(
                    f"Contrato '{contract_data.contract_name}' versão '{contract_data.contract_version}' já existe"
                )
            
            # Validar usuário existe
            user = db.query(User).filter(User._id == user_id).first()
            if not user:
                raise EntityNotFoundError(f"Usuário {user_id} não encontrado")
            
            # Validar frameworks de compliance se especificados
            if contract_data.compliance_framework_ids:
                frameworks = db.query(ComplianceFramework).filter(
                    ComplianceFramework._id.in_(contract_data.compliance_framework_ids)
                ).all()
                
                if len(frameworks) != len(contract_data.compliance_framework_ids):
                    raise EntityNotFoundError("Um ou mais frameworks de compliance não encontrados")
            
            # Criar contrato
            contract_dict = contract_data.dict(exclude={'compliance_framework_ids'})
            contract_dict.update({
                'created_by_user_id': user_id,
                'updated_by_user_id': user_id,
                'contract_status': ContractStatus.DRAFT
            })
            
            contract = DataContract(**contract_dict)
            db.add(contract)
            db.flush()  # Para obter o ID
            
            # Associar frameworks de compliance
            if contract_data.compliance_framework_ids:
                for framework_id in contract_data.compliance_framework_ids:
                    framework = db.query(ComplianceFramework).filter(
                        ComplianceFramework._id == framework_id
                    ).first()
                    if framework:
                        contract.compliance_frameworks.append(framework)
            
            db.commit()
            
            # Log de auditoria
            await self._audit_service.log_action(
                user_id=user_id,
                contract_id=contract._id,
                action_type="CREATE",
                resource_type="contract",
                resource_id=contract._id,
                old_values=None,
                new_values=contract_dict,
                description=f"Contrato '{contract.contract_name}' criado",
                ip_address=None,
                user_agent=None,
                db=db
            )
            
            logger.info(f"Contrato {contract._id} criado por usuário {user_id}")
            
            return await self._build_contract_response(contract, db)
            
        except Exception as e:
            db.rollback()
            logger.error(f"Erro ao criar contrato: {e}")
            raise
    
    async def get_contract(
        self, 
        contract_id: UUID, 
        db: Session
    ) -> Optional[DataContractResponse]:
        """
        Obtém um contrato por ID com relacionamentos carregados
        """
        try:
            contract = db.query(DataContract).options(
                joinedload(DataContract.created_by),
                joinedload(DataContract.updated_by),
                joinedload(DataContract.approved_by),
                joinedload(DataContract.compliance_frameworks)
            ).filter(DataContract._id == contract_id).first()
            
            if not contract:
                return None
            
            return await self._build_contract_response(contract, db)
            
        except Exception as e:
            logger.error(f"Erro ao obter contrato {contract_id}: {e}")
            raise
    
    async def get_contracts(
        self,
        filters: ContractFilters,
        pagination: PaginationParams,
        db: Session
    ) -> Tuple[List[DataContractResponse], int]:
        """
        Lista contratos com filtros e paginação
        Implementa busca otimizada com índices
        """
        try:
            query = db.query(DataContract).options(
                joinedload(DataContract.created_by),
                joinedload(DataContract.updated_by),
                joinedload(DataContract.compliance_frameworks)
            )
            
            # Aplicar filtros
            query = self._apply_filters(query, filters)
            
            # Contar total
            total = query.count()
            
            # Aplicar ordenação
            if pagination.sort_by == "created_at":
                order_field = DataContract.created_at
            elif pagination.sort_by == "updated_at":
                order_field = DataContract.updated_at
            elif pagination.sort_by == "contract_name":
                order_field = DataContract.contract_name
            else:
                order_field = DataContract.created_at
            
            if pagination.sort_order == "desc":
                query = query.order_by(desc(order_field))
            else:
                query = query.order_by(asc(order_field))
            
            # Aplicar paginação
            offset = (pagination.page - 1) * pagination.size
            contracts = query.offset(offset).limit(pagination.size).all()
            
            # Converter para response
            contract_responses = []
            for contract in contracts:
                response = await self._build_contract_response(contract, db)
                contract_responses.append(response)
            
            return contract_responses, total
            
        except Exception as e:
            logger.error(f"Erro ao listar contratos: {e}")
            raise
    
    async def update_contract(
        self,
        contract_id: UUID,
        contract_data: DataContractUpdate,
        user_id: UUID,
        db: Session
    ) -> Optional[DataContractResponse]:
        """
        Atualiza um contrato existente
        Implementa validações de negócio e controle de breaking changes
        """
        try:
            # Buscar contrato
            contract = db.query(DataContract).filter(
                DataContract._id == contract_id
            ).first()
            
            if not contract:
                raise EntityNotFoundError(f"Contrato {contract_id} não encontrado")
            
            # Validar usuário
            user = db.query(User).filter(User._id == user_id).first()
            if not user:
                raise EntityNotFoundError(f"Usuário {user_id} não encontrado")
            
            # Validar se contrato pode ser atualizado
            if contract.contract_status == ContractStatus.ARCHIVED:
                raise BusinessRuleViolationError("Contrato arquivado não pode ser atualizado")
            
            # Capturar valores antigos para auditoria
            old_values = {
                'description': contract.description,
                'business_purpose': contract.business_purpose,
                'data_classification': contract.data_classification,
                'contract_status': contract.contract_status,
                'data_retention_days': contract.data_retention_days
            }
            
            # Aplicar atualizações
            update_data = contract_data.dict(exclude_unset=True)
            for field, value in update_data.items():
                if hasattr(contract, field):
                    setattr(contract, field, value)
            
            contract.updated_by_user_id = user_id
            contract.updated_at = datetime.utcnow()
            
            db.commit()
            
            # Log de auditoria
            await self._audit_service.log_action(
                user_id=user_id,
                contract_id=contract_id,
                action_type="UPDATE",
                resource_type="contract",
                resource_id=contract_id,
                old_values=old_values,
                new_values=update_data,
                description=f"Contrato '{contract.contract_name}' atualizado",
                ip_address=None,
                user_agent=None,
                db=db
            )
            
            logger.info(f"Contrato {contract_id} atualizado por usuário {user_id}")
            
            return await self._build_contract_response(contract, db)
            
        except Exception as e:
            db.rollback()
            logger.error(f"Erro ao atualizar contrato {contract_id}: {e}")
            raise
    
    async def delete_contract(
        self,
        contract_id: UUID,
        user_id: UUID,
        db: Session
    ) -> bool:
        """
        Remove um contrato (soft delete)
        Implementa validações de negócio
        """
        try:
            contract = db.query(DataContract).filter(
                DataContract._id == contract_id
            ).first()
            
            if not contract:
                raise EntityNotFoundError(f"Contrato {contract_id} não encontrado")
            
            # Validar se pode ser removido
            if contract.contract_status == ContractStatus.ACTIVE:
                raise BusinessRuleViolationError("Contrato ativo não pode ser removido")
            
            # Soft delete - marcar como arquivado
            contract.contract_status = ContractStatus.ARCHIVED
            contract.updated_by_user_id = user_id
            contract.updated_at = datetime.utcnow()
            
            db.commit()
            
            # Log de auditoria
            await self._audit_service.log_action(
                user_id=user_id,
                contract_id=contract_id,
                action_type="DELETE",
                resource_type="contract",
                resource_id=contract_id,
                old_values={'contract_status': 'active'},
                new_values={'contract_status': 'archived'},
                description=f"Contrato '{contract.contract_name}' arquivado",
                ip_address=None,
                user_agent=None,
                db=db
            )
            
            logger.info(f"Contrato {contract_id} arquivado por usuário {user_id}")
            
            return True
            
        except Exception as e:
            db.rollback()
            logger.error(f"Erro ao arquivar contrato {contract_id}: {e}")
            raise
    
    async def approve_contract(
        self,
        contract_id: UUID,
        user_id: UUID,
        db: Session
    ) -> Optional[DataContractResponse]:
        """
        Aprova um contrato
        Implementa workflow de aprovação
        """
        try:
            contract = db.query(DataContract).filter(
                DataContract._id == contract_id
            ).first()
            
            if not contract:
                raise EntityNotFoundError(f"Contrato {contract_id} não encontrado")
            
            # Validar se pode ser aprovado
            if contract.contract_status != ContractStatus.DRAFT:
                raise BusinessRuleViolationError("Apenas contratos em draft podem ser aprovados")
            
            # Validar usuário aprovador
            user = db.query(User).filter(User._id == user_id).first()
            if not user:
                raise EntityNotFoundError(f"Usuário {user_id} não encontrado")
            
            if not user.is_admin:
                raise BusinessRuleViolationError("Apenas administradores podem aprovar contratos")
            
            # Aprovar contrato
            contract.contract_status = ContractStatus.ACTIVE
            contract.approved_by_user_id = user_id
            contract.approved_at = datetime.utcnow()
            contract.updated_by_user_id = user_id
            contract.updated_at = datetime.utcnow()
            
            if not contract.effective_date:
                contract.effective_date = datetime.utcnow()
            
            db.commit()
            
            # Log de auditoria
            await self._audit_service.log_action(
                user_id=user_id,
                contract_id=contract_id,
                action_type="APPROVE",
                resource_type="contract",
                resource_id=contract_id,
                old_values={'contract_status': 'draft'},
                new_values={'contract_status': 'active'},
                description=f"Contrato '{contract.contract_name}' aprovado",
                ip_address=None,
                user_agent=None,
                db=db
            )
            
            logger.info(f"Contrato {contract_id} aprovado por usuário {user_id}")
            
            return await self._build_contract_response(contract, db)
            
        except Exception as e:
            db.rollback()
            logger.error(f"Erro ao aprovar contrato {contract_id}: {e}")
            raise
    
    async def get_contract_versions(
        self,
        contract_id: UUID,
        db: Session
    ) -> List:
        """
        Obtém todas as versões de um contrato
        """
        try:
            # Por enquanto retorna lista vazia - será implementado no ContractVersionService
            return []
            
        except Exception as e:
            logger.error(f"Erro ao obter versões do contrato {contract_id}: {e}")
            raise
    
    def _apply_filters(self, query, filters: ContractFilters):
        """
        Aplica filtros à query
        Implementa SRP: responsável apenas pela aplicação de filtros
        """
        if filters.contract_name:
            query = query.filter(
                DataContract.contract_name.ilike(f"%{filters.contract_name}%")
            )
        
        if filters.contract_status:
            query = query.filter(DataContract.contract_status == filters.contract_status)
        
        if filters.data_classification:
            query = query.filter(DataContract.data_classification == filters.data_classification)
        
        if filters.country_code:
            query = query.filter(DataContract.country_code == filters.country_code)
        
        if filters.created_after:
            query = query.filter(DataContract.created_at >= filters.created_after)
        
        if filters.created_before:
            query = query.filter(DataContract.created_at <= filters.created_before)
        
        if filters.search:
            search_term = f"%{filters.search}%"
            query = query.filter(
                or_(
                    DataContract.contract_name.ilike(search_term),
                    DataContract.description.ilike(search_term),
                    DataContract.business_purpose.ilike(search_term)
                )
            )
        
        return query
    
    async def _build_contract_response(
        self, 
        contract: DataContract, 
        db: Session
    ) -> DataContractResponse:
        """
        Constrói response do contrato com relacionamentos
        Implementa SRP: responsável apenas pela construção da resposta
        """
        # Converter para dict
        contract_dict = {
            '_id': contract._id,
            'contract_name': contract.contract_name,
            'contract_version': contract.contract_version,
            'contract_status': contract.contract_status,
            'description': contract.description,
            'business_purpose': contract.business_purpose,
            'data_classification': contract.data_classification,
            'breaking_changes': contract.breaking_changes,
            'migration_notes': contract.migration_notes,
            'previous_version_id': contract.previous_version_id,
            'country_code': contract.country_code,
            'region': contract.region,
            'jurisdiction': contract.jurisdiction,
            'data_retention_days': contract.data_retention_days,
            'created_at': contract.created_at,
            'updated_at': contract.updated_at,
            'approved_at': contract.approved_at,
            'effective_date': contract.effective_date,
            'expiration_date': contract.expiration_date,
            'created_by': self._build_user_reference(contract.created_by) if contract.created_by else None,
            'updated_by': self._build_user_reference(contract.updated_by) if contract.updated_by else None,
            'approved_by': self._build_user_reference(contract.approved_by) if contract.approved_by else None,
            'compliance_frameworks': [
                self._build_framework_response(fw) for fw in contract.compliance_frameworks
            ] if contract.compliance_frameworks else []
        }
        
        return DataContractResponse(**contract_dict)
    
    def _build_user_reference(self, user: User) -> Dict[str, Any]:
        """Constrói referência de usuário"""
        return {
            '_id': user._id,
            'username': user.username,
            'full_name': user.full_name,
            'email': user.email
        }
    
    def _build_framework_response(self, framework: ComplianceFramework) -> Dict[str, Any]:
        """Constrói resposta de framework de compliance"""
        return {
            '_id': framework._id,
            'framework_name': framework.framework_name,
            'framework_code': framework.framework_code,
            'description': framework.description,
            'applicable_countries': framework.applicable_countries,
            'data_retention_requirements': framework.data_retention_requirements,
            'consent_requirements': framework.consent_requirements,
            'created_at': framework.created_at,
            'updated_at': framework.updated_at
        }

