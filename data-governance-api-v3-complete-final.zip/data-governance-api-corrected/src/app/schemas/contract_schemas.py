"""
Schemas Pydantic para Data Governance API - Contratos de Dados
Implementa validação robusta e princípios SOLID
"""

from pydantic import BaseModel, Field, validator, root_validator
from typing import Optional, List, Dict, Any, Union
from datetime import datetime
from uuid import UUID
from enum import Enum
import re


class ContractStatus(str, Enum):
    """Enum para status de contratos"""
    DRAFT = "draft"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"


class DataClassification(str, Enum):
    """Enum para classificação de dados"""
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"


class AccessLevel(str, Enum):
    """Enum para níveis de acesso"""
    READ = "read"
    WRITE = "write"
    ADMIN = "admin"
    NONE = "none"


class ActionType(str, Enum):
    """Enum para tipos de ação em auditoria"""
    CREATE = "CREATE"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    ACCESS = "ACCESS"
    APPROVE = "APPROVE"


class VersionType(str, Enum):
    """Enum para tipos de versão"""
    MAJOR = "major"
    MINOR = "minor"
    PATCH = "patch"


# ===== BASE SCHEMAS =====

class BaseSchema(BaseModel):
    """
    Schema base com configurações comuns
    Implementa SRP: responsável apenas por configurações base
    """
    
    class Config:
        orm_mode = True
        use_enum_values = True
        validate_assignment = True
        allow_population_by_field_name = True


class TimestampMixin(BaseModel):
    """
    Mixin para campos de timestamp
    Implementa DRY: evita repetição de campos de auditoria
    """
    created_at: datetime = Field(..., description="Data de criação")
    updated_at: datetime = Field(..., description="Data de última atualização")


class UserReference(BaseSchema):
    """Schema para referência de usuário"""
    id: UUID = Field(..., alias="_id", description="ID único do usuário")
    username: str = Field(..., description="Nome de usuário")
    full_name: str = Field(..., description="Nome completo")
    email: str = Field(..., description="Email do usuário")


# ===== DATA CONTRACT SCHEMAS =====

class DataContractBase(BaseSchema):
    """
    Schema base para contratos de dados
    Implementa SRP: responsável apenas pelos campos básicos
    """
    contract_name: str = Field(
        ..., 
        min_length=3, 
        max_length=255,
        description="Nome único do contrato de dados"
    )
    contract_version: str = Field(
        ..., 
        regex=r"^\d+\.\d+\.\d+$",
        description="Versão semântica do contrato (ex: 1.2.3)"
    )
    description: Optional[str] = Field(
        None, 
        max_length=2000,
        description="Descrição detalhada do propósito do contrato"
    )
    business_purpose: Optional[str] = Field(
        None,
        max_length=2000, 
        description="Justificativa de negócio para o contrato"
    )
    data_classification: DataClassification = Field(
        ...,
        description="Classificação de segurança dos dados"
    )
    country_code: Optional[str] = Field(
        None,
        regex=r"^[A-Z]{3}$",
        description="Código do país (ISO 3166-1 alpha-3)"
    )
    region: Optional[str] = Field(
        None,
        max_length=100,
        description="Região geográfica específica"
    )
    jurisdiction: Optional[str] = Field(
        None,
        max_length=100,
        description="Jurisdição legal aplicável"
    )
    data_retention_days: Optional[int] = Field(
        None,
        ge=1,
        le=36500,  # 100 anos máximo
        description="Período de retenção em dias"
    )

    @validator('contract_name')
    def validate_contract_name(cls, v):
        """Valida nome do contrato"""
        if not re.match(r'^[a-zA-Z0-9_-]+$', v):
            raise ValueError('Nome do contrato deve conter apenas letras, números, _ e -')
        return v.lower()

    @validator('country_code')
    def validate_country_code(cls, v):
        """Valida código do país"""
        if v and len(v) != 3:
            raise ValueError('Código do país deve ter exatamente 3 caracteres')
        return v.upper() if v else v


class DataContractCreate(DataContractBase):
    """
    Schema para criação de contratos
    Implementa SRP: responsável apenas pela validação de criação
    """
    breaking_changes: bool = Field(
        default=False,
        description="Indica se há mudanças que quebram compatibilidade"
    )
    migration_notes: Optional[str] = Field(
        None,
        max_length=5000,
        description="Instruções para migração entre versões"
    )
    effective_date: Optional[datetime] = Field(
        None,
        description="Data de início da vigência"
    )
    expiration_date: Optional[datetime] = Field(
        None,
        description="Data de expiração do contrato"
    )
    compliance_framework_ids: List[UUID] = Field(
        default_factory=list,
        description="IDs dos frameworks de compliance aplicáveis"
    )

    @root_validator
    def validate_dates(cls, values):
        """Valida consistência das datas"""
        effective_date = values.get('effective_date')
        expiration_date = values.get('expiration_date')
        
        if effective_date and expiration_date:
            if effective_date >= expiration_date:
                raise ValueError('Data de expiração deve ser posterior à data de vigência')
        
        return values


class DataContractUpdate(BaseSchema):
    """
    Schema para atualização de contratos
    Implementa SRP: responsável apenas pela validação de atualização
    """
    description: Optional[str] = Field(None, max_length=2000)
    business_purpose: Optional[str] = Field(None, max_length=2000)
    data_classification: Optional[DataClassification] = None
    contract_status: Optional[ContractStatus] = None
    data_retention_days: Optional[int] = Field(None, ge=1, le=36500)
    migration_notes: Optional[str] = Field(None, max_length=5000)
    effective_date: Optional[datetime] = None
    expiration_date: Optional[datetime] = None


class DataContractResponse(DataContractBase, TimestampMixin):
    """
    Schema para resposta de contratos
    Implementa SRP: responsável apenas pela serialização de resposta
    """
    id: UUID = Field(..., alias="_id", description="ID único do contrato")
    contract_status: ContractStatus = Field(..., description="Status atual do contrato")
    breaking_changes: bool = Field(..., description="Indica mudanças que quebram compatibilidade")
    migration_notes: Optional[str] = Field(None, description="Instruções de migração")
    previous_version_id: Optional[UUID] = Field(None, description="ID da versão anterior")
    
    # Datas de aprovação e vigência
    approved_at: Optional[datetime] = Field(None, description="Data de aprovação")
    effective_date: Optional[datetime] = Field(None, description="Data de vigência")
    expiration_date: Optional[datetime] = Field(None, description="Data de expiração")
    
    # Referências de usuários
    created_by: Optional[UserReference] = Field(None, description="Usuário que criou")
    updated_by: Optional[UserReference] = Field(None, description="Usuário que atualizou")
    approved_by: Optional[UserReference] = Field(None, description="Usuário que aprovou")
    
    # Relacionamentos
    compliance_frameworks: List['ComplianceFrameworkResponse'] = Field(
        default_factory=list,
        description="Frameworks de compliance aplicáveis"
    )


# ===== CONTRACT VERSION SCHEMAS =====

class ContractVersionBase(BaseSchema):
    """Schema base para versões de contrato"""
    version_number: str = Field(
        ...,
        regex=r"^\d+\.\d+\.\d+$",
        description="Número da versão (semântico)"
    )
    version_type: VersionType = Field(..., description="Tipo da versão")
    changelog: Optional[str] = Field(
        None,
        max_length=5000,
        description="Descrição das mudanças"
    )
    is_breaking_change: bool = Field(
        default=False,
        description="Indica se é uma mudança que quebra compatibilidade"
    )
    migration_script: Optional[str] = Field(
        None,
        max_length=10000,
        description="Script de migração"
    )


class ContractVersionCreate(ContractVersionBase):
    """Schema para criação de versão"""
    contract_id: UUID = Field(..., description="ID do contrato")


class ContractVersionResponse(ContractVersionBase, TimestampMixin):
    """Schema para resposta de versão"""
    id: UUID = Field(..., alias="_id", description="ID único da versão")
    contract_id: UUID = Field(..., description="ID do contrato")
    created_by: Optional[UserReference] = Field(None, description="Usuário que criou")


# ===== USER SCHEMAS =====

class UserBase(BaseSchema):
    """Schema base para usuários"""
    username: str = Field(..., min_length=3, max_length=100, description="Nome de usuário")
    email: str = Field(..., description="Email do usuário")
    full_name: str = Field(..., min_length=2, max_length=255, description="Nome completo")
    country_code: Optional[str] = Field(None, regex=r"^[A-Z]{3}$", description="País do usuário")
    department: Optional[str] = Field(None, max_length=100, description="Departamento")
    role: Optional[str] = Field(None, max_length=100, description="Cargo")

    @validator('email')
    def validate_email(cls, v):
        """Valida formato do email"""
        email_regex = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(email_regex, v):
            raise ValueError('Formato de email inválido')
        return v.lower()


class UserCreate(UserBase):
    """Schema para criação de usuário"""
    is_admin: bool = Field(default=False, description="Usuário administrador")


class UserResponse(UserBase, TimestampMixin):
    """Schema para resposta de usuário"""
    id: UUID = Field(..., alias="_id", description="ID único do usuário")
    is_active: bool = Field(..., description="Usuário ativo")
    is_admin: bool = Field(..., description="Usuário administrador")
    last_login: Optional[datetime] = Field(None, description="Último login")


# ===== ACCESS POLICY SCHEMAS =====

class AccessPolicyBase(BaseSchema):
    """Schema base para políticas de acesso"""
    policy_name: str = Field(..., min_length=3, max_length=255, description="Nome da política")
    access_level: AccessLevel = Field(..., description="Nível de acesso")
    field_restrictions: List[str] = Field(
        default_factory=list,
        description="Campos com restrição de acesso"
    )
    row_level_filters: Optional[str] = Field(
        None,
        max_length=2000,
        description="Filtros de linha em SQL"
    )
    masking_rules: Optional[Dict[str, Any]] = Field(
        None,
        description="Regras de mascaramento em JSON"
    )
    effective_date: datetime = Field(..., description="Data de início da vigência")
    expiration_date: Optional[datetime] = Field(None, description="Data de expiração")


class AccessPolicyCreate(AccessPolicyBase):
    """Schema para criação de política de acesso"""
    contract_id: UUID = Field(..., description="ID do contrato")
    group_id: UUID = Field(..., description="ID do grupo de usuários")


class AccessPolicyResponse(AccessPolicyBase, TimestampMixin):
    """Schema para resposta de política de acesso"""
    id: UUID = Field(..., alias="_id", description="ID único da política")
    contract_id: UUID = Field(..., description="ID do contrato")
    group_id: UUID = Field(..., description="ID do grupo")
    is_active: bool = Field(..., description="Política ativa")
    created_by: Optional[UserReference] = Field(None, description="Usuário que criou")


# ===== COMPLIANCE FRAMEWORK SCHEMAS =====

class ComplianceFrameworkBase(BaseSchema):
    """Schema base para frameworks de compliance"""
    framework_name: str = Field(..., min_length=3, max_length=100, description="Nome do framework")
    framework_code: str = Field(
        ...,
        regex=r"^[A-Z]{2,10}$",
        description="Código do framework (ex: GDPR, LGPD)"
    )
    description: Optional[str] = Field(None, max_length=2000, description="Descrição")
    applicable_countries: List[str] = Field(
        default_factory=list,
        description="Países onde se aplica"
    )
    data_retention_requirements: Optional[str] = Field(
        None,
        max_length=2000,
        description="Requisitos de retenção"
    )
    consent_requirements: Optional[str] = Field(
        None,
        max_length=2000,
        description="Requisitos de consentimento"
    )


class ComplianceFrameworkCreate(ComplianceFrameworkBase):
    """Schema para criação de framework de compliance"""
    pass


class ComplianceFrameworkResponse(ComplianceFrameworkBase, TimestampMixin):
    """Schema para resposta de framework de compliance"""
    id: UUID = Field(..., alias="_id", description="ID único do framework")


# ===== AUDIT LOG SCHEMAS =====

class AuditLogResponse(BaseSchema, TimestampMixin):
    """Schema para resposta de log de auditoria"""
    id: UUID = Field(..., alias="_id", description="ID único do log")
    contract_id: UUID = Field(..., description="ID do contrato")
    user_id: UUID = Field(..., description="ID do usuário")
    action_type: ActionType = Field(..., description="Tipo da ação")
    resource_type: str = Field(..., description="Tipo do recurso")
    resource_id: Optional[UUID] = Field(None, description="ID do recurso")
    change_description: Optional[str] = Field(None, description="Descrição da mudança")
    ip_address: Optional[str] = Field(None, description="Endereço IP")
    user_agent: Optional[str] = Field(None, description="User agent")


# ===== PAGINATION SCHEMAS =====

class PaginationParams(BaseSchema):
    """Schema para parâmetros de paginação"""
    page: int = Field(default=1, ge=1, description="Número da página")
    size: int = Field(default=20, ge=1, le=100, description="Tamanho da página")
    sort_by: Optional[str] = Field(default="created_at", description="Campo para ordenação")
    sort_order: Optional[str] = Field(default="desc", regex="^(asc|desc)$", description="Ordem")


class PaginatedResponse(BaseSchema):
    """Schema genérico para respostas paginadas"""
    items: List[Any] = Field(..., description="Lista de itens")
    total: int = Field(..., description="Total de itens")
    page: int = Field(..., description="Página atual")
    size: int = Field(..., description="Tamanho da página")
    pages: int = Field(..., description="Total de páginas")


# ===== FILTER SCHEMAS =====

class ContractFilters(BaseSchema):
    """Schema para filtros de contratos"""
    contract_name: Optional[str] = Field(None, description="Filtro por nome")
    contract_status: Optional[ContractStatus] = Field(None, description="Filtro por status")
    data_classification: Optional[DataClassification] = Field(None, description="Filtro por classificação")
    country_code: Optional[str] = Field(None, description="Filtro por país")
    created_after: Optional[datetime] = Field(None, description="Criado após")
    created_before: Optional[datetime] = Field(None, description="Criado antes")
    search: Optional[str] = Field(None, min_length=3, description="Busca textual")


# ===== ERROR SCHEMAS =====

class ErrorDetail(BaseSchema):
    """Schema para detalhes de erro"""
    field: Optional[str] = Field(None, description="Campo com erro")
    message: str = Field(..., description="Mensagem de erro")
    code: Optional[str] = Field(None, description="Código do erro")


class ErrorResponse(BaseSchema):
    """Schema para resposta de erro"""
    error: str = Field(..., description="Tipo do erro")
    message: str = Field(..., description="Mensagem principal")
    details: List[ErrorDetail] = Field(default_factory=list, description="Detalhes dos erros")
    request_id: Optional[str] = Field(None, description="ID da requisição")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Timestamp do erro")


# Forward references para relacionamentos circulares
DataContractResponse.update_forward_refs()
ComplianceFrameworkResponse.update_forward_refs()

