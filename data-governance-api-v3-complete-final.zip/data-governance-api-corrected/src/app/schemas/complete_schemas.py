"""
Schemas Pydantic completos para Data Governance API
Versão: 3.0.0 - Schemas Completos com 30+ Entidades
Autor: Carlos Morais
Data: 26 de Dezembro de 2025

Schemas para todas as entidades do modelo completo, incluindo:
- Validação robusta de dados
- Flexibilidade de versão por contrato e país
- Visibilidade aprimorada de acessos
- Tabelas de tags mantidas
"""

from pydantic import BaseModel, Field, EmailStr, validator, root_validator
from typing import Optional, List, Dict, Any, Union
from datetime import datetime
from decimal import Decimal
from enum import Enum
import uuid

# ===== ENUMS E TIPOS =====

class ContractStatus(str, Enum):
    DRAFT = "draft"
    REVIEW = "review"
    APPROVED = "approved"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    ARCHIVED = "archived"

class DataClassification(str, Enum):
    PUBLIC = "public"
    INTERNAL = "internal"
    CONFIDENTIAL = "confidential"
    RESTRICTED = "restricted"

class VersionType(str, Enum):
    MAJOR = "major"
    MINOR = "minor"
    PATCH = "patch"

class ComplianceStatus(str, Enum):
    PENDING = "pending"
    COMPLIANT = "compliant"
    NON_COMPLIANT = "non_compliant"
    WARNING = "warning"

class ObjectType(str, Enum):
    TABLE = "table"
    VIEW = "view"
    FILE = "file"
    STREAM = "stream"
    API = "api"
    DATASET = "dataset"

class MaskingType(str, Enum):
    HASH = "hash"
    ENCRYPT = "encrypt"
    TOKENIZE = "tokenize"
    REDACT = "redact"
    PARTIAL = "partial"

class PolicyType(str, Enum):
    ACCESS_CONTROL = "access_control"
    DATA_MASKING = "data_masking"
    RETENTION = "retention"
    QUALITY = "quality"
    COMPLIANCE = "compliance"

class ActionType(str, Enum):
    CREATE = "CREATE"
    READ = "READ"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    APPROVE = "APPROVE"
    ACCESS = "ACCESS"
    EXPORT = "EXPORT"

class MetricType(str, Enum):
    COMPLETENESS = "completeness"
    ACCURACY = "accuracy"
    CONSISTENCY = "consistency"
    VALIDITY = "validity"
    UNIQUENESS = "uniqueness"
    TIMELINESS = "timeliness"

class LineageType(str, Enum):
    FIELD_TO_FIELD = "field_to_field"
    OBJECT_TO_OBJECT = "object_to_object"
    CONTRACT_TO_CONTRACT = "contract_to_contract"

class NotificationType(str, Enum):
    CONTRACT_EXPIRING = "contract_expiring"
    COMPLIANCE_VIOLATION = "compliance_violation"
    QUALITY_ISSUE = "quality_issue"
    APPROVAL_REQUIRED = "approval_required"
    SYSTEM_ALERT = "system_alert"

class Priority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

# ===== SCHEMAS BASE =====

class BaseSchema(BaseModel):
    class Config:
        from_attributes = True
        use_enum_values = True
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            uuid.UUID: lambda v: str(v),
            Decimal: lambda v: float(v)
        }

class TimestampMixin(BaseModel):
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

# ===== USUÁRIOS E CONTROLE DE ACESSO =====

class UserBase(BaseSchema):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    full_name: str = Field(..., min_length=1, max_length=255)
    is_active: bool = True
    is_superuser: bool = False
    country_access: List[str] = Field(default_factory=list)

class UserCreate(UserBase):
    password: str = Field(..., min_length=8)

class UserUpdate(BaseSchema):
    username: Optional[str] = Field(None, min_length=3, max_length=50)
    email: Optional[EmailStr] = None
    full_name: Optional[str] = Field(None, min_length=1, max_length=255)
    is_active: Optional[bool] = None
    is_superuser: Optional[bool] = None
    country_access: Optional[List[str]] = None

class UserResponse(UserBase, TimestampMixin):
    _id: uuid.UUID
    last_login: Optional[datetime] = None

class UserGroupBase(BaseSchema):
    group_name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    permissions: Dict[str, Any] = Field(default_factory=dict)
    country_restrictions: List[str] = Field(default_factory=list)
    contract_access_level: str = Field(default="read")

class UserGroupCreate(UserGroupBase):
    pass

class UserGroupUpdate(BaseSchema):
    group_name: Optional[str] = Field(None, min_length=1, max_length=100)
    description: Optional[str] = None
    permissions: Optional[Dict[str, Any]] = None
    country_restrictions: Optional[List[str]] = None
    contract_access_level: Optional[str] = None

class UserGroupResponse(UserGroupBase, TimestampMixin):
    _id: uuid.UUID

class UserGroupMembershipBase(BaseSchema):
    user_id: uuid.UUID
    group_id: uuid.UUID
    access_level: str = Field(default="member")

class UserGroupMembershipCreate(UserGroupMembershipBase):
    assigned_by_user_id: Optional[uuid.UUID] = None

class UserGroupMembershipResponse(UserGroupMembershipBase, TimestampMixin):
    _id: uuid.UUID
    assigned_at: datetime
    assigned_by_user_id: Optional[uuid.UUID] = None

class UserRoleBase(BaseSchema):
    role_name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    permissions: Dict[str, Any] = Field(...)
    is_system_role: bool = False

class UserRoleCreate(UserRoleBase):
    pass

class UserRoleResponse(UserRoleBase, TimestampMixin):
    _id: uuid.UUID

class UserRoleAssignmentBase(BaseSchema):
    user_id: uuid.UUID
    role_id: uuid.UUID
    expires_at: Optional[datetime] = None

class UserRoleAssignmentCreate(UserRoleAssignmentBase):
    assigned_by_user_id: Optional[uuid.UUID] = None

class UserRoleAssignmentResponse(UserRoleAssignmentBase, TimestampMixin):
    _id: uuid.UUID
    assigned_at: datetime
    assigned_by_user_id: Optional[uuid.UUID] = None

# ===== COMPLIANCE E FRAMEWORKS =====

class ComplianceFrameworkBase(BaseSchema):
    framework_name: str = Field(..., min_length=1, max_length=255)
    framework_code: str = Field(..., min_length=1, max_length=50)
    description: Optional[str] = None
    applicable_countries: List[str] = Field(default_factory=list)
    data_retention_requirements: Dict[str, Any] = Field(default_factory=dict)
    consent_requirements: Dict[str, Any] = Field(default_factory=dict)

class ComplianceFrameworkCreate(ComplianceFrameworkBase):
    pass

class ComplianceFrameworkUpdate(BaseSchema):
    framework_name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    applicable_countries: Optional[List[str]] = None
    data_retention_requirements: Optional[Dict[str, Any]] = None
    consent_requirements: Optional[Dict[str, Any]] = None

class ComplianceFrameworkResponse(ComplianceFrameworkBase, TimestampMixin):
    _id: uuid.UUID

class ComplianceRuleBase(BaseSchema):
    framework_id: uuid.UUID
    rule_name: str = Field(..., min_length=1, max_length=255)
    rule_type: str = Field(..., min_length=1, max_length=100)
    rule_definition: Dict[str, Any] = Field(...)
    applicable_countries: List[str] = Field(default_factory=list)
    severity: str = Field(default="medium")
    is_active: bool = True

class ComplianceRuleCreate(ComplianceRuleBase):
    pass

class ComplianceRuleResponse(ComplianceRuleBase, TimestampMixin):
    _id: uuid.UUID

# ===== CONTRATOS E VERSIONAMENTO =====

class DataContractBase(BaseSchema):
    contract_name: str = Field(..., min_length=1, max_length=255)
    contract_description: Optional[str] = None
    contract_version: str = Field(default="1.0.0")
    contract_status: ContractStatus = ContractStatus.DRAFT
    data_classification: DataClassification = DataClassification.INTERNAL
    business_owner_id: Optional[uuid.UUID] = None
    technical_owner_id: Optional[uuid.UUID] = None
    data_steward_id: Optional[uuid.UUID] = None
    country_code: str = Field(..., min_length=2, max_length=3)
    jurisdiction: Optional[str] = None
    region: Optional[str] = None
    regulatory_framework: Optional[str] = None
    effective_date: Optional[datetime] = None
    expiration_date: Optional[datetime] = None
    review_date: Optional[datetime] = None
    data_retention_days: int = Field(default=1095, ge=1)
    purge_after_expiration: bool = False

    @validator('expiration_date')
    def validate_expiration_date(cls, v, values):
        if v and 'effective_date' in values and values['effective_date']:
            if v <= values['effective_date']:
                raise ValueError('expiration_date must be after effective_date')
        return v

class DataContractCreate(DataContractBase):
    created_by_user_id: uuid.UUID

class DataContractUpdate(BaseSchema):
    contract_name: Optional[str] = Field(None, min_length=1, max_length=255)
    contract_description: Optional[str] = None
    contract_status: Optional[ContractStatus] = None
    data_classification: Optional[DataClassification] = None
    business_owner_id: Optional[uuid.UUID] = None
    technical_owner_id: Optional[uuid.UUID] = None
    data_steward_id: Optional[uuid.UUID] = None
    jurisdiction: Optional[str] = None
    region: Optional[str] = None
    regulatory_framework: Optional[str] = None
    effective_date: Optional[datetime] = None
    expiration_date: Optional[datetime] = None
    review_date: Optional[datetime] = None
    data_retention_days: Optional[int] = Field(None, ge=1)
    purge_after_expiration: Optional[bool] = None
    updated_by_user_id: Optional[uuid.UUID] = None

class DataContractResponse(DataContractBase, TimestampMixin):
    _id: uuid.UUID
    approved_at: Optional[datetime] = None
    approved_by_user_id: Optional[uuid.UUID] = None
    created_by_user_id: uuid.UUID
    updated_by_user_id: Optional[uuid.UUID] = None
    previous_version_id: Optional[uuid.UUID] = None

class ContractVersionBase(BaseSchema):
    contract_id: uuid.UUID
    version_number: str = Field(..., min_length=1, max_length=50)
    version_type: VersionType = VersionType.MINOR
    country_specific_version: bool = False
    country_code: Optional[str] = Field(None, min_length=2, max_length=3)
    changelog: Optional[str] = None
    is_breaking_change: bool = False
    migration_script: Optional[str] = None

class ContractVersionCreate(ContractVersionBase):
    created_by_user_id: uuid.UUID

class ContractVersionResponse(ContractVersionBase, TimestampMixin):
    _id: uuid.UUID
    created_by_user_id: uuid.UUID

class ContractLayoutBase(BaseSchema):
    contract_id: uuid.UUID
    layout_name: str = Field(..., min_length=1, max_length=255)
    layout_type: str = Field(..., min_length=1, max_length=100)
    layout_definition: Dict[str, Any] = Field(...)
    is_active: bool = True

class ContractLayoutCreate(ContractLayoutBase):
    pass

class ContractLayoutResponse(ContractLayoutBase, TimestampMixin):
    _id: uuid.UUID

class ContractComplianceFrameworkBase(BaseSchema):
    contract_id: uuid.UUID
    framework_id: uuid.UUID
    compliance_status: ComplianceStatus = ComplianceStatus.PENDING
    validation_results: Dict[str, Any] = Field(default_factory=dict)
    country_specific_rules: Dict[str, Any] = Field(default_factory=dict)

class ContractComplianceFrameworkCreate(ContractComplianceFrameworkBase):
    pass

class ContractComplianceFrameworkResponse(ContractComplianceFrameworkBase, TimestampMixin):
    _id: uuid.UUID
    last_validation_date: Optional[datetime] = None

# ===== OBJETOS E ESTRUTURA DE DADOS =====

class DataObjectBase(BaseSchema):
    contract_id: uuid.UUID
    object_name: str = Field(..., min_length=1, max_length=255)
    object_type: ObjectType
    object_description: Optional[str] = None
    schema_definition: Dict[str, Any] = Field(default_factory=dict)
    data_format: Optional[str] = None
    encoding: Optional[str] = None
    storage_location: Optional[str] = None
    access_pattern: Optional[str] = None
    quality_rules: Dict[str, Any] = Field(default_factory=dict)
    validation_rules: Dict[str, Any] = Field(default_factory=dict)
    business_glossary: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    encryption_required: bool = False
    masking_rules: Dict[str, Any] = Field(default_factory=dict)
    access_controls: Dict[str, Any] = Field(default_factory=dict)

class DataObjectCreate(DataObjectBase):
    pass

class DataObjectUpdate(BaseSchema):
    object_name: Optional[str] = Field(None, min_length=1, max_length=255)
    object_description: Optional[str] = None
    schema_definition: Optional[Dict[str, Any]] = None
    data_format: Optional[str] = None
    encoding: Optional[str] = None
    storage_location: Optional[str] = None
    access_pattern: Optional[str] = None
    quality_rules: Optional[Dict[str, Any]] = None
    validation_rules: Optional[Dict[str, Any]] = None
    business_glossary: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = None
    encryption_required: Optional[bool] = None
    masking_rules: Optional[Dict[str, Any]] = None
    access_controls: Optional[Dict[str, Any]] = None

class DataObjectResponse(DataObjectBase, TimestampMixin):
    _id: uuid.UUID

class DataObjectFieldBase(BaseSchema):
    data_object_id: uuid.UUID
    field_name: str = Field(..., min_length=1, max_length=255)
    field_type: str = Field(..., min_length=1, max_length=100)
    field_description: Optional[str] = None
    is_nullable: bool = True
    is_primary_key: bool = False
    is_foreign_key: bool = False
    default_value: Optional[str] = None
    validation_rules: Dict[str, Any] = Field(default_factory=dict)
    quality_checks: Dict[str, Any] = Field(default_factory=dict)
    data_classification: DataClassification = DataClassification.INTERNAL
    is_pii: bool = False
    is_sensitive: bool = False
    masking_type: Optional[MaskingType] = None
    business_name: Optional[str] = None
    business_description: Optional[str] = None
    business_rules: Optional[str] = None
    field_order: Optional[int] = None
    field_group: Optional[str] = None

class DataObjectFieldCreate(DataObjectFieldBase):
    pass

class DataObjectFieldResponse(DataObjectFieldBase, TimestampMixin):
    _id: uuid.UUID

class DataSchemaBase(BaseSchema):
    contract_id: uuid.UUID
    schema_name: str = Field(..., min_length=1, max_length=255)
    schema_version: str = Field(..., min_length=1, max_length=50)
    schema_definition: Dict[str, Any] = Field(...)
    schema_format: str = Field(..., min_length=1, max_length=50)
    is_active: bool = True

class DataSchemaCreate(DataSchemaBase):
    pass

class DataSchemaResponse(DataSchemaBase, TimestampMixin):
    _id: uuid.UUID

# ===== POLÍTICAS E CONTROLE DE ACESSO =====

class AccessPolicyBase(BaseSchema):
    contract_id: uuid.UUID
    policy_name: str = Field(..., min_length=1, max_length=255)
    policy_type: PolicyType
    policy_description: Optional[str] = None
    policy_rules: Dict[str, Any] = Field(...)
    conditions: Dict[str, Any] = Field(default_factory=dict)
    actions: Dict[str, Any] = Field(default_factory=dict)
    applies_to_objects: List[uuid.UUID] = Field(default_factory=list)
    applies_to_fields: List[uuid.UUID] = Field(default_factory=list)
    applies_to_users: List[uuid.UUID] = Field(default_factory=list)
    applies_to_groups: List[uuid.UUID] = Field(default_factory=list)
    country_restrictions: List[str] = Field(default_factory=list)
    is_active: bool = True
    effective_from: Optional[datetime] = None
    effective_until: Optional[datetime] = None

class AccessPolicyCreate(AccessPolicyBase):
    created_by_user_id: uuid.UUID

class AccessPolicyResponse(AccessPolicyBase, TimestampMixin):
    _id: uuid.UUID
    created_by_user_id: uuid.UUID
    approved_by_user_id: Optional[uuid.UUID] = None

class AccessControlListBase(BaseSchema):
    resource_type: str = Field(..., min_length=1, max_length=100)
    resource_id: uuid.UUID
    principal_type: str = Field(..., min_length=1, max_length=50)
    principal_id: uuid.UUID
    permission: str = Field(..., min_length=1, max_length=100)
    granted: bool = True
    expires_at: Optional[datetime] = None

class AccessControlListCreate(AccessControlListBase):
    granted_by_user_id: Optional[uuid.UUID] = None

class AccessControlListResponse(AccessControlListBase, TimestampMixin):
    _id: uuid.UUID
    granted_by_user_id: Optional[uuid.UUID] = None
    granted_at: datetime

class DataMaskingPolicyBase(BaseSchema):
    contract_id: uuid.UUID
    policy_name: str = Field(..., min_length=1, max_length=255)
    masking_type: str = Field(..., min_length=1, max_length=50)
    masking_rules: Dict[str, Any] = Field(...)
    applies_to_fields: List[uuid.UUID] = Field(...)
    conditions: Dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True

class DataMaskingPolicyCreate(DataMaskingPolicyBase):
    pass

class DataMaskingPolicyResponse(DataMaskingPolicyBase, TimestampMixin):
    _id: uuid.UUID

# ===== AUDITORIA E MONITORAMENTO =====

class AuditLogBase(BaseSchema):
    contract_id: Optional[uuid.UUID] = None
    user_id: Optional[uuid.UUID] = None
    action_type: ActionType
    resource_type: str = Field(..., min_length=1, max_length=100)
    resource_id: Optional[uuid.UUID] = None
    change_description: Optional[str] = None
    old_values: Optional[Dict[str, Any]] = None
    new_values: Optional[Dict[str, Any]] = None
    change_summary: Dict[str, Any] = Field(default_factory=dict)
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    session_id: Optional[str] = None
    country_code: Optional[str] = None

class AuditLogCreate(AuditLogBase):
    pass

class AuditLogResponse(AuditLogBase, TimestampMixin):
    _id: uuid.UUID

class AuditTrailBase(BaseSchema):
    entity_type: str = Field(..., min_length=1, max_length=100)
    entity_id: uuid.UUID
    operation: str = Field(..., min_length=1, max_length=50)
    details: Dict[str, Any] = Field(default_factory=dict)
    correlation_id: Optional[uuid.UUID] = None

class AuditTrailCreate(AuditTrailBase):
    performed_by_user_id: Optional[uuid.UUID] = None

class AuditTrailResponse(AuditTrailBase, TimestampMixin):
    _id: uuid.UUID
    performed_by_user_id: Optional[uuid.UUID] = None
    performed_at: datetime

class SystemEventBase(BaseSchema):
    event_type: str = Field(..., min_length=1, max_length=100)
    event_category: str = Field(..., min_length=1, max_length=50)
    event_description: Optional[str] = None
    event_data: Dict[str, Any] = Field(default_factory=dict)
    severity: str = Field(default="info")
    source_system: Optional[str] = None
    correlation_id: Optional[uuid.UUID] = None

class SystemEventCreate(SystemEventBase):
    pass

class SystemEventResponse(SystemEventBase, TimestampMixin):
    _id: uuid.UUID

# ===== QUALIDADE DE DADOS =====

class QualityMetricBase(BaseSchema):
    contract_id: uuid.UUID
    data_object_id: Optional[uuid.UUID] = None
    field_id: Optional[uuid.UUID] = None
    metric_name: str = Field(..., min_length=1, max_length=255)
    metric_type: MetricType
    metric_description: Optional[str] = None
    metric_definition: Dict[str, Any] = Field(...)
    thresholds: Dict[str, Any] = Field(default_factory=dict)
    is_active: bool = True

class QualityMetricCreate(QualityMetricBase):
    pass

class QualityMetricUpdate(BaseSchema):
    metric_name: Optional[str] = Field(None, min_length=1, max_length=255)
    metric_description: Optional[str] = None
    metric_definition: Optional[Dict[str, Any]] = None
    thresholds: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None

class QualityMetricResponse(QualityMetricBase, TimestampMixin):
    _id: uuid.UUID
    last_execution_date: Optional[datetime] = None
    last_result: Optional[Dict[str, Any]] = None
    execution_status: Optional[str] = None
    execution_history: List[Dict[str, Any]] = Field(default_factory=list)

class QualityRuleBase(BaseSchema):
    contract_id: uuid.UUID
    rule_name: str = Field(..., min_length=1, max_length=255)
    rule_type: str = Field(..., min_length=1, max_length=100)
    rule_definition: Dict[str, Any] = Field(...)
    applies_to_objects: List[uuid.UUID] = Field(default_factory=list)
    applies_to_fields: List[uuid.UUID] = Field(default_factory=list)
    severity: str = Field(default="medium")
    is_active: bool = True

class QualityRuleCreate(QualityRuleBase):
    pass

class QualityRuleResponse(QualityRuleBase, TimestampMixin):
    _id: uuid.UUID

class QualityAssessmentBase(BaseSchema):
    contract_id: uuid.UUID
    assessment_date: datetime
    overall_score: Optional[Decimal] = None
    completeness_score: Optional[Decimal] = None
    accuracy_score: Optional[Decimal] = None
    consistency_score: Optional[Decimal] = None
    validity_score: Optional[Decimal] = None
    uniqueness_score: Optional[Decimal] = None
    timeliness_score: Optional[Decimal] = None
    assessment_details: Dict[str, Any] = Field(default_factory=dict)
    recommendations: Optional[str] = None

class QualityAssessmentCreate(QualityAssessmentBase):
    pass

class QualityAssessmentResponse(QualityAssessmentBase, TimestampMixin):
    _id: uuid.UUID

# ===== LINEAGE E RASTREABILIDADE =====

class DataLineageBase(BaseSchema):
    source_contract_id: Optional[uuid.UUID] = None
    source_object_id: Optional[uuid.UUID] = None
    source_field_id: Optional[uuid.UUID] = None
    target_contract_id: Optional[uuid.UUID] = None
    target_object_id: Optional[uuid.UUID] = None
    target_field_id: Optional[uuid.UUID] = None
    transformation_type: Optional[str] = None
    transformation_logic: Optional[str] = None
    transformation_rules: Dict[str, Any] = Field(default_factory=dict)
    lineage_type: LineageType = LineageType.FIELD_TO_FIELD
    confidence_score: Decimal = Field(default=Decimal('1.0'), ge=0, le=1)
    is_verified: bool = False

    @root_validator
    def validate_lineage_entities(cls, values):
        source_fields = [values.get('source_contract_id'), values.get('source_object_id'), values.get('source_field_id')]
        target_fields = [values.get('target_contract_id'), values.get('target_object_id'), values.get('target_field_id')]
        
        if not any(source_fields):
            raise ValueError('At least one source entity must be specified')
        if not any(target_fields):
            raise ValueError('At least one target entity must be specified')
        
        return values

class DataLineageCreate(DataLineageBase):
    pass

class DataLineageResponse(DataLineageBase, TimestampMixin):
    _id: uuid.UUID
    verified_by_user_id: Optional[uuid.UUID] = None
    verified_at: Optional[datetime] = None

class LineageGraphBase(BaseSchema):
    graph_name: str = Field(..., min_length=1, max_length=255)
    graph_type: str = Field(..., min_length=1, max_length=100)
    root_entity_type: str = Field(..., min_length=1, max_length=100)
    root_entity_id: uuid.UUID
    graph_definition: Dict[str, Any] = Field(...)
    is_cached: bool = False
    cache_expires_at: Optional[datetime] = None

class LineageGraphCreate(LineageGraphBase):
    pass

class LineageGraphResponse(LineageGraphBase, TimestampMixin):
    _id: uuid.UUID

class ImpactAnalysisBase(BaseSchema):
    source_entity_type: str = Field(..., min_length=1, max_length=100)
    source_entity_id: uuid.UUID
    change_type: str = Field(..., min_length=1, max_length=100)
    impact_scope: Dict[str, Any] = Field(...)
    affected_entities: Dict[str, Any] = Field(...)
    risk_level: str = Field(default="medium")
    recommendations: Optional[str] = None

class ImpactAnalysisCreate(ImpactAnalysisBase):
    analyzed_by_user_id: Optional[uuid.UUID] = None

class ImpactAnalysisResponse(ImpactAnalysisBase, TimestampMixin):
    _id: uuid.UUID
    analysis_date: datetime
    analyzed_by_user_id: Optional[uuid.UUID] = None

# ===== MONITORAMENTO E MÉTRICAS =====

class MonitoringMetricBase(BaseSchema):
    contract_id: Optional[uuid.UUID] = None
    metric_name: str = Field(..., min_length=1, max_length=255)
    metric_type: str = Field(..., min_length=1, max_length=100)
    metric_value: Optional[Decimal] = None
    metric_unit: Optional[str] = None
    dimensions: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime
    collected_by: Optional[str] = None

class MonitoringMetricCreate(MonitoringMetricBase):
    pass

class MonitoringMetricResponse(MonitoringMetricBase, TimestampMixin):
    _id: uuid.UUID

class PerformanceMetricBase(BaseSchema):
    contract_id: Optional[uuid.UUID] = None
    operation_type: str = Field(..., min_length=1, max_length=100)
    execution_time_ms: Optional[int] = None
    throughput_per_second: Optional[Decimal] = None
    error_rate: Optional[Decimal] = None
    success_rate: Optional[Decimal] = None
    resource_usage: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime

class PerformanceMetricCreate(PerformanceMetricBase):
    pass

class PerformanceMetricResponse(PerformanceMetricBase, TimestampMixin):
    _id: uuid.UUID

class SLADefinitionBase(BaseSchema):
    contract_id: uuid.UUID
    sla_name: str = Field(..., min_length=1, max_length=255)
    sla_type: str = Field(..., min_length=1, max_length=100)
    target_value: Decimal = Field(...)
    threshold_warning: Optional[Decimal] = None
    threshold_critical: Optional[Decimal] = None
    measurement_window: str = Field(..., min_length=1, max_length=50)
    is_active: bool = True

class SLADefinitionCreate(SLADefinitionBase):
    pass

class SLADefinitionResponse(SLADefinitionBase, TimestampMixin):
    _id: uuid.UUID

class SLAViolationBase(BaseSchema):
    sla_id: uuid.UUID
    violation_type: str = Field(..., min_length=1, max_length=100)
    actual_value: Decimal = Field(...)
    threshold_value: Decimal = Field(...)
    severity: str = Field(..., min_length=1, max_length=50)
    violation_start: datetime
    violation_end: Optional[datetime] = None
    resolution_notes: Optional[str] = None

class SLAViolationCreate(SLAViolationBase):
    pass

class SLAViolationResponse(SLAViolationBase, TimestampMixin):
    _id: uuid.UUID
    resolved_by_user_id: Optional[uuid.UUID] = None

# ===== NOTIFICAÇÕES E ALERTAS =====

class NotificationBase(BaseSchema):
    user_id: uuid.UUID
    contract_id: Optional[uuid.UUID] = None
    notification_type: NotificationType
    title: str = Field(..., min_length=1, max_length=255)
    message: str = Field(..., min_length=1)
    priority: Priority = Priority.MEDIUM
    category: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class NotificationCreate(NotificationBase):
    pass

class NotificationUpdate(BaseSchema):
    is_read: Optional[bool] = None

class NotificationResponse(NotificationBase, TimestampMixin):
    _id: uuid.UUID
    is_read: bool = False
    read_at: Optional[datetime] = None

class AlertRuleBase(BaseSchema):
    rule_name: str = Field(..., min_length=1, max_length=255)
    rule_type: str = Field(..., min_length=1, max_length=100)
    condition_expression: str = Field(..., min_length=1)
    severity: str = Field(..., min_length=1, max_length=50)
    notification_channels: List[str] = Field(default_factory=list)
    is_active: bool = True

class AlertRuleCreate(AlertRuleBase):
    created_by_user_id: Optional[uuid.UUID] = None

class AlertRuleResponse(AlertRuleBase, TimestampMixin):
    _id: uuid.UUID
    created_by_user_id: Optional[uuid.UUID] = None

class AlertInstanceBase(BaseSchema):
    rule_id: uuid.UUID
    contract_id: Optional[uuid.UUID] = None
    alert_status: str = Field(default="active")
    triggered_at: datetime
    alert_data: Dict[str, Any] = Field(default_factory=dict)

class AlertInstanceCreate(AlertInstanceBase):
    pass

class AlertInstanceUpdate(BaseSchema):
    alert_status: Optional[str] = None
    resolved_at: Optional[datetime] = None
    resolution_notes: Optional[str] = None
    resolved_by_user_id: Optional[uuid.UUID] = None

class AlertInstanceResponse(AlertInstanceBase, TimestampMixin):
    _id: uuid.UUID
    resolved_at: Optional[datetime] = None
    resolution_notes: Optional[str] = None
    resolved_by_user_id: Optional[uuid.UUID] = None

# ===== CONFIGURAÇÕES E METADADOS (INCLUINDO TAGS) =====

class SystemConfigurationBase(BaseSchema):
    config_key: str = Field(..., min_length=1, max_length=255)
    config_value: str = Field(..., min_length=1)
    config_type: str = Field(..., min_length=1, max_length=50)
    description: Optional[str] = None
    is_encrypted: bool = False
    country_specific: Optional[str] = Field(None, min_length=2, max_length=3)

class SystemConfigurationCreate(SystemConfigurationBase):
    updated_by_user_id: Optional[uuid.UUID] = None

class SystemConfigurationUpdate(BaseSchema):
    config_value: Optional[str] = Field(None, min_length=1)
    description: Optional[str] = None
    is_encrypted: Optional[bool] = None
    country_specific: Optional[str] = Field(None, min_length=2, max_length=3)
    updated_by_user_id: Optional[uuid.UUID] = None

class SystemConfigurationResponse(SystemConfigurationBase, TimestampMixin):
    _id: uuid.UUID
    updated_by_user_id: Optional[uuid.UUID] = None

class MetadataTagBase(BaseSchema):
    tag_name: str = Field(..., min_length=1, max_length=100)
    tag_category: Optional[str] = None
    tag_description: Optional[str] = None
    tag_color: Optional[str] = Field(None, regex=r'^#[0-9A-Fa-f]{6}$')
    is_system_tag: bool = False

class MetadataTagCreate(MetadataTagBase):
    pass

class MetadataTagUpdate(BaseSchema):
    tag_name: Optional[str] = Field(None, min_length=1, max_length=100)
    tag_category: Optional[str] = None
    tag_description: Optional[str] = None
    tag_color: Optional[str] = Field(None, regex=r'^#[0-9A-Fa-f]{6}$')

class MetadataTagResponse(MetadataTagBase, TimestampMixin):
    _id: uuid.UUID

class EntityTagBase(BaseSchema):
    entity_type: str = Field(..., min_length=1, max_length=100)
    entity_id: uuid.UUID
    tag_id: uuid.UUID

class EntityTagCreate(EntityTagBase):
    tagged_by_user_id: Optional[uuid.UUID] = None

class EntityTagResponse(EntityTagBase, TimestampMixin):
    _id: uuid.UUID
    tagged_by_user_id: Optional[uuid.UUID] = None
    tagged_at: datetime

# ===== SCHEMAS DE RESPOSTA COMPLEXOS =====

class DataContractDetailResponse(DataContractResponse):
    business_owner: Optional[UserResponse] = None
    technical_owner: Optional[UserResponse] = None
    data_steward: Optional[UserResponse] = None
    created_by: Optional[UserResponse] = None
    versions: List[ContractVersionResponse] = Field(default_factory=list)
    compliance_frameworks: List[ContractComplianceFrameworkResponse] = Field(default_factory=list)
    data_objects: List[DataObjectResponse] = Field(default_factory=list)
    access_policies: List[AccessPolicyResponse] = Field(default_factory=list)
    quality_metrics: List[QualityMetricResponse] = Field(default_factory=list)

class DataObjectDetailResponse(DataObjectResponse):
    fields: List[DataObjectFieldResponse] = Field(default_factory=list)
    quality_metrics: List[QualityMetricResponse] = Field(default_factory=list)

class UserDetailResponse(UserResponse):
    group_memberships: List[UserGroupMembershipResponse] = Field(default_factory=list)
    role_assignments: List[UserRoleAssignmentResponse] = Field(default_factory=list)

# ===== SCHEMAS DE FILTROS E PAGINAÇÃO =====

class PaginationParams(BaseModel):
    page: int = Field(default=1, ge=1)
    size: int = Field(default=20, ge=1, le=100)

class ContractFilters(BaseModel):
    contract_status: Optional[ContractStatus] = None
    data_classification: Optional[DataClassification] = None
    country_code: Optional[str] = None
    business_owner_id: Optional[uuid.UUID] = None
    created_by_user_id: Optional[uuid.UUID] = None
    search: Optional[str] = None

class QualityMetricFilters(BaseModel):
    contract_id: Optional[uuid.UUID] = None
    metric_type: Optional[MetricType] = None
    is_active: Optional[bool] = None

class AuditLogFilters(BaseModel):
    contract_id: Optional[uuid.UUID] = None
    user_id: Optional[uuid.UUID] = None
    action_type: Optional[ActionType] = None
    resource_type: Optional[str] = None
    country_code: Optional[str] = None
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None

class NotificationFilters(BaseModel):
    user_id: Optional[uuid.UUID] = None
    notification_type: Optional[NotificationType] = None
    is_read: Optional[bool] = None
    priority: Optional[Priority] = None

# ===== SCHEMAS DE RESPOSTA PAGINADA =====

class PaginatedResponse(BaseModel):
    items: List[Any]
    total: int
    page: int
    size: int
    pages: int

    @validator('pages', pre=True, always=True)
    def calculate_pages(cls, v, values):
        total = values.get('total', 0)
        size = values.get('size', 20)
        return (total + size - 1) // size if total > 0 else 0

# ===== SCHEMAS DE ESTATÍSTICAS E RELATÓRIOS =====

class ContractStatistics(BaseModel):
    total_contracts: int
    contracts_by_status: Dict[str, int]
    contracts_by_classification: Dict[str, int]
    contracts_by_country: Dict[str, int]
    expiring_soon: int
    compliance_violations: int

class QualityStatistics(BaseModel):
    total_metrics: int
    active_metrics: int
    metrics_by_type: Dict[str, int]
    average_scores: Dict[str, float]
    failed_metrics: int

class AuditStatistics(BaseModel):
    total_events: int
    events_by_action: Dict[str, int]
    events_by_user: Dict[str, int]
    events_by_country: Dict[str, int]
    recent_activity: List[AuditLogResponse]

class SystemHealthResponse(BaseModel):
    status: str
    version: str
    uptime: str
    database_status: str
    cache_status: str
    active_users: int
    total_contracts: int
    system_load: Dict[str, Any]

