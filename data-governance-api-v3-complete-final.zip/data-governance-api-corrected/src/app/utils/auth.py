"""
Sistema de autenticação para Data Governance API
Implementa autenticação JWT e princípios SOLID
"""

from abc import ABC, abstractmethod
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
import os
import logging

from .exceptions import AuthenticationError, AuthorizationError

logger = logging.getLogger(__name__)

# Configurações JWT
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "your-secret-key-change-in-production")
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = int(os.getenv("JWT_EXPIRATION_HOURS", "24"))

# Security scheme
security = HTTPBearer()


class IAuthenticationService(ABC):
    """
    Interface para serviços de autenticação
    Implementa ISP: Interface específica para autenticação
    """
    
    @abstractmethod
    def create_access_token(self, user_data: Dict[str, Any]) -> str:
        """Cria token de acesso JWT"""
        pass
    
    @abstractmethod
    def verify_token(self, token: str) -> Dict[str, Any]:
        """Verifica e decodifica token JWT"""
        pass
    
    @abstractmethod
    def refresh_token(self, token: str) -> str:
        """Renova token de acesso"""
        pass


class IAuthorizationService(ABC):
    """
    Interface para serviços de autorização
    Implementa ISP: Interface específica para autorização
    """
    
    @abstractmethod
    def check_permission(self, user: Dict[str, Any], permission: str) -> bool:
        """Verifica se usuário tem permissão específica"""
        pass
    
    @abstractmethod
    def check_resource_access(
        self, 
        user: Dict[str, Any], 
        resource_type: str, 
        resource_id: str,
        action: str
    ) -> bool:
        """Verifica acesso a recurso específico"""
        pass


class JWTAuthenticationService(IAuthenticationService):
    """
    Implementação de autenticação JWT
    Implementa SRP: responsável apenas pela autenticação JWT
    """
    
    def __init__(self, secret_key: str = JWT_SECRET_KEY, algorithm: str = JWT_ALGORITHM):
        self.secret_key = secret_key
        self.algorithm = algorithm
    
    def create_access_token(self, user_data: Dict[str, Any]) -> str:
        """
        Cria token de acesso JWT
        Implementa Factory Pattern para criação de tokens
        """
        try:
            # Dados do payload
            payload = {
                "user_id": str(user_data.get("user_id")),
                "username": user_data.get("username"),
                "email": user_data.get("email"),
                "is_admin": user_data.get("is_admin", False),
                "permissions": user_data.get("permissions", []),
                "exp": datetime.utcnow() + timedelta(hours=JWT_EXPIRATION_HOURS),
                "iat": datetime.utcnow(),
                "type": "access_token"
            }
            
            # Criar token
            token = jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
            
            logger.info(f"Token criado para usuário {user_data.get('username')}")
            return token
            
        except Exception as e:
            logger.error(f"Erro ao criar token: {e}")
            raise AuthenticationError("Falha ao criar token de acesso")
    
    def verify_token(self, token: str) -> Dict[str, Any]:
        """
        Verifica e decodifica token JWT
        Implementa validações de segurança
        """
        try:
            # Decodificar token
            payload = jwt.decode(
                token, 
                self.secret_key, 
                algorithms=[self.algorithm]
            )
            
            # Validar tipo do token
            if payload.get("type") != "access_token":
                raise AuthenticationError("Tipo de token inválido")
            
            # Validar expiração
            exp = payload.get("exp")
            if exp and datetime.fromtimestamp(exp) < datetime.utcnow():
                raise AuthenticationError("Token expirado")
            
            return payload
            
        except jwt.ExpiredSignatureError:
            raise AuthenticationError("Token expirado")
        except jwt.InvalidTokenError:
            raise AuthenticationError("Token inválido")
        except Exception as e:
            logger.error(f"Erro ao verificar token: {e}")
            raise AuthenticationError("Falha na verificação do token")
    
    def refresh_token(self, token: str) -> str:
        """
        Renova token de acesso
        Implementa renovação segura de tokens
        """
        try:
            # Verificar token atual (mesmo que expirado)
            payload = jwt.decode(
                token, 
                self.secret_key, 
                algorithms=[self.algorithm],
                options={"verify_exp": False}  # Ignorar expiração para refresh
            )
            
            # Validar que não está muito expirado (máximo 7 dias)
            exp = payload.get("exp")
            if exp:
                exp_date = datetime.fromtimestamp(exp)
                if datetime.utcnow() - exp_date > timedelta(days=7):
                    raise AuthenticationError("Token muito antigo para renovação")
            
            # Criar novo token com mesmos dados
            user_data = {
                "user_id": payload.get("user_id"),
                "username": payload.get("username"),
                "email": payload.get("email"),
                "is_admin": payload.get("is_admin", False),
                "permissions": payload.get("permissions", [])
            }
            
            return self.create_access_token(user_data)
            
        except AuthenticationError:
            raise
        except Exception as e:
            logger.error(f"Erro ao renovar token: {e}")
            raise AuthenticationError("Falha ao renovar token")


class RBACAuthorizationService(IAuthorizationService):
    """
    Implementação de autorização baseada em roles (RBAC)
    Implementa SRP: responsável apenas pela autorização RBAC
    """
    
    def __init__(self):
        # Definir permissões por role
        self.role_permissions = {
            "admin": [
                "contracts:create", "contracts:read", "contracts:update", "contracts:delete",
                "contracts:approve", "users:manage", "policies:manage", "audit:read"
            ],
            "data_steward": [
                "contracts:create", "contracts:read", "contracts:update",
                "policies:read", "audit:read"
            ],
            "data_analyst": [
                "contracts:read", "policies:read"
            ],
            "viewer": [
                "contracts:read"
            ]
        }
    
    def check_permission(self, user: Dict[str, Any], permission: str) -> bool:
        """
        Verifica se usuário tem permissão específica
        Implementa Strategy Pattern para diferentes tipos de verificação
        """
        try:
            # Admin tem todas as permissões
            if user.get("is_admin", False):
                return True
            
            # Verificar permissões diretas do usuário
            user_permissions = user.get("permissions", [])
            if permission in user_permissions:
                return True
            
            # Verificar permissões por role (se implementado)
            user_roles = user.get("roles", [])
            for role in user_roles:
                role_perms = self.role_permissions.get(role, [])
                if permission in role_perms:
                    return True
            
            return False
            
        except Exception as e:
            logger.error(f"Erro ao verificar permissão {permission}: {e}")
            return False
    
    def check_resource_access(
        self, 
        user: Dict[str, Any], 
        resource_type: str, 
        resource_id: str,
        action: str
    ) -> bool:
        """
        Verifica acesso a recurso específico
        Implementa verificação granular de recursos
        """
        try:
            # Construir permissão específica
            permission = f"{resource_type}:{action}"
            
            # Verificar permissão básica
            if not self.check_permission(user, permission):
                return False
            
            # Verificações específicas por tipo de recurso
            if resource_type == "contracts":
                return self._check_contract_access(user, resource_id, action)
            elif resource_type == "users":
                return self._check_user_access(user, resource_id, action)
            
            return True
            
        except Exception as e:
            logger.error(f"Erro ao verificar acesso ao recurso {resource_type}:{resource_id}: {e}")
            return False
    
    def _check_contract_access(self, user: Dict[str, Any], contract_id: str, action: str) -> bool:
        """Verifica acesso específico a contratos"""
        # Implementar lógica específica de acesso a contratos
        # Por exemplo: usuário só pode editar contratos que criou
        return True  # Implementação simplificada
    
    def _check_user_access(self, user: Dict[str, Any], user_id: str, action: str) -> bool:
        """Verifica acesso específico a usuários"""
        # Usuário pode sempre acessar seus próprios dados
        if str(user.get("user_id")) == str(user_id):
            return True
        
        # Admin pode acessar qualquer usuário
        if user.get("is_admin", False):
            return True
        
        return False


# Instâncias globais dos serviços
_auth_service = JWTAuthenticationService()
_authz_service = RBACAuthorizationService()


def get_auth_service() -> IAuthenticationService:
    """Dependency injection para serviço de autenticação"""
    return _auth_service


def get_authz_service() -> IAuthorizationService:
    """Dependency injection para serviço de autorização"""
    return _authz_service


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    auth_service: IAuthenticationService = Depends(get_auth_service)
) -> Dict[str, Any]:
    """
    Dependency para obter usuário atual autenticado
    Implementa Dependency Injection Pattern
    """
    try:
        # Extrair token
        token = credentials.credentials
        
        # Verificar token
        payload = auth_service.verify_token(token)
        
        # Retornar dados do usuário
        return {
            "user_id": payload.get("user_id"),
            "username": payload.get("username"),
            "email": payload.get("email"),
            "is_admin": payload.get("is_admin", False),
            "permissions": payload.get("permissions", []),
            "roles": payload.get("roles", [])
        }
        
    except AuthenticationError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido ou expirado",
            headers={"WWW-Authenticate": "Bearer"}
        )
    except Exception as e:
        logger.error(f"Erro na autenticação: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Falha na autenticação",
            headers={"WWW-Authenticate": "Bearer"}
        )


def require_permission(permission: str):
    """
    Decorator para exigir permissão específica
    Implementa Decorator Pattern para autorização
    """
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # Obter usuário atual
            current_user = kwargs.get("current_user")
            if not current_user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Usuário não autenticado"
                )
            
            # Verificar permissão
            authz_service = get_authz_service()
            if not authz_service.check_permission(current_user, permission):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Permissão '{permission}' necessária"
                )
            
            return await func(*args, **kwargs)
        return wrapper
    return decorator


def require_admin():
    """
    Decorator para exigir privilégios de administrador
    Implementa Decorator Pattern para autorização de admin
    """
    def decorator(func):
        async def wrapper(*args, **kwargs):
            # Obter usuário atual
            current_user = kwargs.get("current_user")
            if not current_user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Usuário não autenticado"
                )
            
            # Verificar se é admin
            if not current_user.get("is_admin", False):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Privilégios de administrador necessários"
                )
            
            return await func(*args, **kwargs)
        return wrapper
    return decorator


# Função para criar token de usuário mock (desenvolvimento)
def create_mock_user_token(
    user_id: str = "mock-user-123",
    username: str = "mock.user",
    email: str = "mock@example.com",
    is_admin: bool = False,
    permissions: list = None
) -> str:
    """
    Cria token mock para desenvolvimento/testes
    Implementa Factory Pattern para tokens de teste
    """
    user_data = {
        "user_id": user_id,
        "username": username,
        "email": email,
        "is_admin": is_admin,
        "permissions": permissions or ["contracts:read", "contracts:create"]
    }
    
    return _auth_service.create_access_token(user_data)

