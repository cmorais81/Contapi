"""
Modelos SQLAlchemy completos para Data Governance API
Versão: 3.0.0 - Modelo Completo com 30+ Tabelas
Autor: Carlos Morais
Data: 26 de Dezembro de 2025

Baseado no modelo DBML completo com:
- 30+ tabelas para governança enterprise
- Flexibilidade de versão por contrato e país
- Visibilidade aprimorada de acessos
- Tabelas de tags mantidas
"""

from sqlalchemy import (
    Column, String, Text, Boolean, Integer, DateTime, Decimal, 
    ForeignKey, JSON, ARRAY, UUID, func, CheckConstraint, Index
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import INET, UUID as PG_UUID
from datetime import datetime
import uuid

Base = declarative_base()

# ===== USUÁRIOS E CONTROLE DE ACESSO =====

class User(Base):
    __tablename__ = 'users'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    full_name = Column(String(255), nullable=False)
    password_hash = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)
    country_access = Column(ARRAY(String(3)), default=[])
    last_login = Column(DateTime)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    owned_contracts = relationship("DataContract", foreign_keys="DataContract.business_owner_id", back_populates="business_owner")
    technical_contracts = relationship("DataContract", foreign_keys="DataContract.technical_owner_id", back_populates="technical_owner")
    stewarded_contracts = relationship("DataContract", foreign_keys="DataContract.data_steward_id", back_populates="data_steward")
    created_contracts = relationship("DataContract", foreign_keys="DataContract.created_by_user_id", back_populates="created_by")
    group_memberships = relationship("UserGroupMembership", back_populates="user")
    role_assignments = relationship("UserRoleAssignment", back_populates="user")
    notifications = relationship("Notification", back_populates="user")
    audit_logs = relationship("AuditLog", back_populates="user")

class UserGroup(Base):
    __tablename__ = 'user_groups'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    group_name = Column(String(100), unique=True, nullable=False)
    description = Column(Text)
    permissions = Column(JSON, default={})
    country_restrictions = Column(ARRAY(String(3)), default=[])
    contract_access_level = Column(String(50), default='read')
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    memberships = relationship("UserGroupMembership", back_populates="group")

class UserGroupMembership(Base):
    __tablename__ = 'user_group_memberships'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    group_id = Column(PG_UUID(as_uuid=True), ForeignKey('user_groups._id'), nullable=False)
    assigned_at = Column(DateTime, default=func.current_timestamp())
    assigned_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    access_level = Column(String(50), default='member')
    
    # Relacionamentos
    user = relationship("User", foreign_keys=[user_id], back_populates="group_memberships")
    group = relationship("UserGroup", back_populates="memberships")
    assigned_by = relationship("User", foreign_keys=[assigned_by_user_id])

class UserRole(Base):
    __tablename__ = 'user_roles'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    role_name = Column(String(100), unique=True, nullable=False)
    description = Column(Text)
    permissions = Column(JSON, nullable=False)
    is_system_role = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    assignments = relationship("UserRoleAssignment", back_populates="role")

class UserRoleAssignment(Base):
    __tablename__ = 'user_role_assignments'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    role_id = Column(PG_UUID(as_uuid=True), ForeignKey('user_roles._id'), nullable=False)
    assigned_at = Column(DateTime, default=func.current_timestamp())
    assigned_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    expires_at = Column(DateTime)
    
    # Relacionamentos
    user = relationship("User", foreign_keys=[user_id], back_populates="role_assignments")
    role = relationship("UserRole", back_populates="assignments")
    assigned_by = relationship("User", foreign_keys=[assigned_by_user_id])

# ===== COMPLIANCE E FRAMEWORKS =====

class ComplianceFramework(Base):
    __tablename__ = 'compliance_frameworks'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    framework_name = Column(String(255), nullable=False)
    framework_code = Column(String(50), unique=True, nullable=False)
    description = Column(Text)
    applicable_countries = Column(ARRAY(String(3)), default=[])
    data_retention_requirements = Column(JSON, default={})
    consent_requirements = Column(JSON, default={})
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    contract_associations = relationship("ContractComplianceFramework", back_populates="framework")
    rules = relationship("ComplianceRule", back_populates="framework")

class ComplianceRule(Base):
    __tablename__ = 'compliance_rules'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    framework_id = Column(PG_UUID(as_uuid=True), ForeignKey('compliance_frameworks._id'), nullable=False)
    rule_name = Column(String(255), nullable=False)
    rule_type = Column(String(100), nullable=False)
    rule_definition = Column(JSON, nullable=False)
    applicable_countries = Column(ARRAY(String(3)), default=[])
    severity = Column(String(50), default='medium')
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    framework = relationship("ComplianceFramework", back_populates="rules")

# ===== CONTRATOS E VERSIONAMENTO =====

class DataContract(Base):
    __tablename__ = 'data_contracts'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_name = Column(String(255), nullable=False)
    contract_description = Column(Text)
    contract_version = Column(String(50), nullable=False, default='1.0.0')
    contract_status = Column(String(50), nullable=False, default='draft')
    data_classification = Column(String(50), nullable=False, default='internal')
    
    # Informações de negócio
    business_owner_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    technical_owner_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    data_steward_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    
    # Informações geográficas e compliance - FLEXIBILIDADE POR PAÍS
    country_code = Column(String(3), nullable=False)
    jurisdiction = Column(String(100))
    region = Column(String(100))
    regulatory_framework = Column(String(100))
    
    # Datas importantes
    effective_date = Column(DateTime)
    expiration_date = Column(DateTime)
    review_date = Column(DateTime)
    
    # Configurações de retenção
    data_retention_days = Column(Integer, default=1095)
    purge_after_expiration = Column(Boolean, default=False)
    
    # Metadados de controle
    approved_at = Column(DateTime)
    approved_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    created_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    updated_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    previous_version_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'))
    
    # Timestamps
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Constraints
    __table_args__ = (
        CheckConstraint(contract_status.in_(['draft', 'review', 'approved', 'active', 'deprecated', 'archived'])),
        CheckConstraint(data_classification.in_(['public', 'internal', 'confidential', 'restricted'])),
        Index('idx_contracts_status', contract_status),
        Index('idx_contracts_country', country_code),
        Index('idx_contracts_classification', data_classification),
    )
    
    # Relacionamentos
    business_owner = relationship("User", foreign_keys=[business_owner_id], back_populates="owned_contracts")
    technical_owner = relationship("User", foreign_keys=[technical_owner_id], back_populates="technical_contracts")
    data_steward = relationship("User", foreign_keys=[data_steward_id], back_populates="stewarded_contracts")
    created_by = relationship("User", foreign_keys=[created_by_user_id], back_populates="created_contracts")
    approved_by = relationship("User", foreign_keys=[approved_by_user_id])
    updated_by = relationship("User", foreign_keys=[updated_by_user_id])
    previous_version = relationship("DataContract", remote_side=[_id])
    
    versions = relationship("ContractVersion", back_populates="contract")
    layouts = relationship("ContractLayout", back_populates="contract")
    compliance_frameworks = relationship("ContractComplianceFramework", back_populates="contract")
    data_objects = relationship("DataObject", back_populates="contract")
    schemas = relationship("DataSchema", back_populates="contract")
    access_policies = relationship("AccessPolicy", back_populates="contract")
    quality_metrics = relationship("QualityMetric", back_populates="contract")
    quality_assessments = relationship("QualityAssessment", back_populates="contract")
    sla_definitions = relationship("SLADefinition", back_populates="contract")
    notifications = relationship("Notification", back_populates="contract")

class ContractVersion(Base):
    __tablename__ = 'contract_versions'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    version_number = Column(String(50), nullable=False)
    version_type = Column(String(20), nullable=False, default='minor')
    country_specific_version = Column(Boolean, default=False)
    country_code = Column(String(3))
    changelog = Column(Text)
    is_breaking_change = Column(Boolean, default=False)
    migration_script = Column(Text)
    created_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Constraints
    __table_args__ = (
        CheckConstraint(version_type.in_(['major', 'minor', 'patch'])),
        Index('idx_versions_contract', contract_id),
        Index('idx_versions_number', version_number),
    )
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="versions")
    created_by = relationship("User")

class ContractLayout(Base):
    __tablename__ = 'contract_layouts'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    layout_name = Column(String(255), nullable=False)
    layout_type = Column(String(100), nullable=False)
    layout_definition = Column(JSON, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="layouts")

class ContractComplianceFramework(Base):
    __tablename__ = 'contract_compliance_frameworks'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    framework_id = Column(PG_UUID(as_uuid=True), ForeignKey('compliance_frameworks._id'), nullable=False)
    compliance_status = Column(String(50), default='pending')
    last_validation_date = Column(DateTime)
    validation_results = Column(JSON, default={})
    country_specific_rules = Column(JSON, default={})
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Constraints
    __table_args__ = (
        CheckConstraint(compliance_status.in_(['pending', 'compliant', 'non_compliant', 'warning'])),
    )
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="compliance_frameworks")
    framework = relationship("ComplianceFramework", back_populates="contract_associations")

# ===== OBJETOS E ESTRUTURA DE DADOS =====

class DataObject(Base):
    __tablename__ = 'data_objects'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    object_name = Column(String(255), nullable=False)
    object_type = Column(String(100), nullable=False)
    object_description = Column(Text)
    schema_definition = Column(JSON, default={})
    data_format = Column(String(100))
    encoding = Column(String(50))
    storage_location = Column(Text)
    access_pattern = Column(String(100))
    quality_rules = Column(JSON, default={})
    validation_rules = Column(JSON, default={})
    business_glossary = Column(JSON, default={})
    tags = Column(ARRAY(String(100)), default=[])
    encryption_required = Column(Boolean, default=False)
    masking_rules = Column(JSON, default={})
    access_controls = Column(JSON, default={})
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Constraints
    __table_args__ = (
        CheckConstraint(object_type.in_(['table', 'view', 'file', 'stream', 'api', 'dataset'])),
        Index('idx_objects_contract', contract_id),
        Index('idx_objects_type', object_type),
    )
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="data_objects")
    fields = relationship("DataObjectField", back_populates="data_object")
    quality_metrics = relationship("QualityMetric", back_populates="data_object")

class DataObjectField(Base):
    __tablename__ = 'data_object_fields'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    data_object_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_objects._id'), nullable=False)
    field_name = Column(String(255), nullable=False)
    field_type = Column(String(100), nullable=False)
    field_description = Column(Text)
    is_nullable = Column(Boolean, default=True)
    is_primary_key = Column(Boolean, default=False)
    is_foreign_key = Column(Boolean, default=False)
    default_value = Column(Text)
    validation_rules = Column(JSON, default={})
    quality_checks = Column(JSON, default={})
    data_classification = Column(String(50), default='internal')
    is_pii = Column(Boolean, default=False)
    is_sensitive = Column(Boolean, default=False)
    masking_type = Column(String(50))
    business_name = Column(String(255))
    business_description = Column(Text)
    business_rules = Column(Text)
    field_order = Column(Integer)
    field_group = Column(String(100))
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Constraints
    __table_args__ = (
        CheckConstraint(data_classification.in_(['public', 'internal', 'confidential', 'restricted'])),
        CheckConstraint(masking_type.in_(['hash', 'encrypt', 'tokenize', 'redact', 'partial']) | (masking_type == None)),
        Index('idx_fields_object', data_object_id),
        Index('idx_fields_pii', is_pii),
        Index('idx_fields_sensitive', is_sensitive),
    )
    
    # Relacionamentos
    data_object = relationship("DataObject", back_populates="fields")
    quality_metrics = relationship("QualityMetric", back_populates="field")

class DataSchema(Base):
    __tablename__ = 'data_schemas'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    schema_name = Column(String(255), nullable=False)
    schema_version = Column(String(50), nullable=False)
    schema_definition = Column(JSON, nullable=False)
    schema_format = Column(String(50), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="schemas")

# ===== POLÍTICAS E CONTROLE DE ACESSO =====

class AccessPolicy(Base):
    __tablename__ = 'access_policies'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    policy_name = Column(String(255), nullable=False)
    policy_type = Column(String(50), nullable=False)
    policy_description = Column(Text)
    policy_rules = Column(JSON, nullable=False, default={})
    conditions = Column(JSON, default={})
    actions = Column(JSON, default={})
    applies_to_objects = Column(ARRAY(PG_UUID(as_uuid=True)), default=[])
    applies_to_fields = Column(ARRAY(PG_UUID(as_uuid=True)), default=[])
    applies_to_users = Column(ARRAY(PG_UUID(as_uuid=True)), default=[])
    applies_to_groups = Column(ARRAY(PG_UUID(as_uuid=True)), default=[])
    country_restrictions = Column(ARRAY(String(3)), default=[])
    is_active = Column(Boolean, default=True)
    effective_from = Column(DateTime, default=func.current_timestamp())
    effective_until = Column(DateTime)
    created_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    approved_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Constraints
    __table_args__ = (
        CheckConstraint(policy_type.in_(['access_control', 'data_masking', 'retention', 'quality', 'compliance'])),
        Index('idx_policies_contract', contract_id),
        Index('idx_policies_type', policy_type),
    )
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="access_policies")
    created_by = relationship("User", foreign_keys=[created_by_user_id])
    approved_by = relationship("User", foreign_keys=[approved_by_user_id])

class AccessControlList(Base):
    __tablename__ = 'access_control_lists'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    resource_type = Column(String(100), nullable=False)
    resource_id = Column(PG_UUID(as_uuid=True), nullable=False)
    principal_type = Column(String(50), nullable=False)
    principal_id = Column(PG_UUID(as_uuid=True), nullable=False)
    permission = Column(String(100), nullable=False)
    granted = Column(Boolean, default=True)
    granted_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    granted_at = Column(DateTime, default=func.current_timestamp())
    expires_at = Column(DateTime)
    
    # Relacionamentos
    granted_by = relationship("User")

class DataMaskingPolicy(Base):
    __tablename__ = 'data_masking_policies'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    policy_name = Column(String(255), nullable=False)
    masking_type = Column(String(50), nullable=False)
    masking_rules = Column(JSON, nullable=False)
    applies_to_fields = Column(ARRAY(PG_UUID(as_uuid=True)), nullable=False)
    conditions = Column(JSON, default={})
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    contract = relationship("DataContract")

# ===== AUDITORIA E MONITORAMENTO =====

class AuditLog(Base):
    __tablename__ = 'audit_logs'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'))
    user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    action_type = Column(String(50), nullable=False)
    resource_type = Column(String(100), nullable=False)
    resource_id = Column(PG_UUID(as_uuid=True))
    change_description = Column(Text)
    old_values = Column(JSON)
    new_values = Column(JSON)
    change_summary = Column(JSON, default={})
    ip_address = Column(INET)
    user_agent = Column(Text)
    session_id = Column(String(255))
    country_code = Column(String(3))
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Constraints
    __table_args__ = (
        CheckConstraint(action_type.in_(['CREATE', 'READ', 'UPDATE', 'DELETE', 'APPROVE', 'ACCESS', 'EXPORT'])),
        Index('idx_audit_contract', contract_id),
        Index('idx_audit_user', user_id),
        Index('idx_audit_action', action_type),
        Index('idx_audit_created', created_at),
    )
    
    # Relacionamentos
    contract = relationship("DataContract")
    user = relationship("User", back_populates="audit_logs")

class AuditTrail(Base):
    __tablename__ = 'audit_trails'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    entity_type = Column(String(100), nullable=False)
    entity_id = Column(PG_UUID(as_uuid=True), nullable=False)
    operation = Column(String(50), nullable=False)
    performed_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    performed_at = Column(DateTime, default=func.current_timestamp())
    details = Column(JSON, default={})
    correlation_id = Column(PG_UUID(as_uuid=True))
    
    # Relacionamentos
    performed_by = relationship("User")

class SystemEvent(Base):
    __tablename__ = 'system_events'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    event_type = Column(String(100), nullable=False)
    event_category = Column(String(50), nullable=False)
    event_description = Column(Text)
    event_data = Column(JSON, default={})
    severity = Column(String(20), default='info')
    source_system = Column(String(100))
    correlation_id = Column(PG_UUID(as_uuid=True))
    created_at = Column(DateTime, default=func.current_timestamp())

# ===== QUALIDADE DE DADOS =====

class QualityMetric(Base):
    __tablename__ = 'quality_metrics'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    data_object_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_objects._id'))
    field_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_object_fields._id'))
    metric_name = Column(String(255), nullable=False)
    metric_type = Column(String(100), nullable=False)
    metric_description = Column(Text)
    metric_definition = Column(JSON, nullable=False, default={})
    thresholds = Column(JSON, default={})
    last_execution_date = Column(DateTime)
    last_result = Column(JSON)
    execution_status = Column(String(50))
    execution_history = Column(JSON, default=[])
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Constraints
    __table_args__ = (
        CheckConstraint(metric_type.in_(['completeness', 'accuracy', 'consistency', 'validity', 'uniqueness', 'timeliness'])),
        CheckConstraint(execution_status.in_(['pending', 'running', 'success', 'failed', 'warning']) | (execution_status == None)),
        Index('idx_quality_contract', contract_id),
        Index('idx_quality_type', metric_type),
    )
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="quality_metrics")
    data_object = relationship("DataObject", back_populates="quality_metrics")
    field = relationship("DataObjectField", back_populates="quality_metrics")

class QualityRule(Base):
    __tablename__ = 'quality_rules'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    rule_name = Column(String(255), nullable=False)
    rule_type = Column(String(100), nullable=False)
    rule_definition = Column(JSON, nullable=False)
    applies_to_objects = Column(ARRAY(PG_UUID(as_uuid=True)), default=[])
    applies_to_fields = Column(ARRAY(PG_UUID(as_uuid=True)), default=[])
    severity = Column(String(50), default='medium')
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    contract = relationship("DataContract")

class QualityAssessment(Base):
    __tablename__ = 'quality_assessments'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    assessment_date = Column(DateTime, nullable=False)
    overall_score = Column(Decimal(5, 2))
    completeness_score = Column(Decimal(5, 2))
    accuracy_score = Column(Decimal(5, 2))
    consistency_score = Column(Decimal(5, 2))
    validity_score = Column(Decimal(5, 2))
    uniqueness_score = Column(Decimal(5, 2))
    timeliness_score = Column(Decimal(5, 2))
    assessment_details = Column(JSON, default={})
    recommendations = Column(Text)
    created_at = Column(DateTime, default=func.current_timestamp())
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="quality_assessments")

# ===== LINEAGE E RASTREABILIDADE =====

class DataLineage(Base):
    __tablename__ = 'data_lineage'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    source_contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'))
    source_object_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_objects._id'))
    source_field_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_object_fields._id'))
    target_contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'))
    target_object_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_objects._id'))
    target_field_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_object_fields._id'))
    transformation_type = Column(String(100))
    transformation_logic = Column(Text)
    transformation_rules = Column(JSON, default={})
    lineage_type = Column(String(50), nullable=False, default='field_to_field')
    confidence_score = Column(Decimal(3, 2), default=1.0)
    is_verified = Column(Boolean, default=False)
    verified_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    verified_at = Column(DateTime)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Constraints
    __table_args__ = (
        CheckConstraint(lineage_type.in_(['field_to_field', 'object_to_object', 'contract_to_contract'])),
        CheckConstraint((confidence_score >= 0.0) & (confidence_score <= 1.0)),
        Index('idx_lineage_source_contract', source_contract_id),
        Index('idx_lineage_target_contract', target_contract_id),
    )
    
    # Relacionamentos
    source_contract = relationship("DataContract", foreign_keys=[source_contract_id])
    target_contract = relationship("DataContract", foreign_keys=[target_contract_id])
    verified_by = relationship("User")

class LineageGraph(Base):
    __tablename__ = 'lineage_graphs'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    graph_name = Column(String(255), nullable=False)
    graph_type = Column(String(100), nullable=False)
    root_entity_type = Column(String(100), nullable=False)
    root_entity_id = Column(PG_UUID(as_uuid=True), nullable=False)
    graph_definition = Column(JSON, nullable=False)
    is_cached = Column(Boolean, default=False)
    cache_expires_at = Column(DateTime)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())

class ImpactAnalysis(Base):
    __tablename__ = 'impact_analysis'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    source_entity_type = Column(String(100), nullable=False)
    source_entity_id = Column(PG_UUID(as_uuid=True), nullable=False)
    change_type = Column(String(100), nullable=False)
    impact_scope = Column(JSON, nullable=False)
    affected_entities = Column(JSON, nullable=False)
    risk_level = Column(String(50), default='medium')
    recommendations = Column(Text)
    analysis_date = Column(DateTime, default=func.current_timestamp())
    analyzed_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    
    # Relacionamentos
    analyzed_by = relationship("User")

# ===== MONITORAMENTO E MÉTRICAS =====

class MonitoringMetric(Base):
    __tablename__ = 'monitoring_metrics'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'))
    metric_name = Column(String(255), nullable=False)
    metric_type = Column(String(100), nullable=False)
    metric_value = Column(Decimal(15, 4))
    metric_unit = Column(String(50))
    dimensions = Column(JSON, default={})
    timestamp = Column(DateTime, nullable=False)
    collected_by = Column(String(100))
    
    # Relacionamentos
    contract = relationship("DataContract")

class PerformanceMetric(Base):
    __tablename__ = 'performance_metrics'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'))
    operation_type = Column(String(100), nullable=False)
    execution_time_ms = Column(Integer)
    throughput_per_second = Column(Decimal(10, 2))
    error_rate = Column(Decimal(5, 4))
    success_rate = Column(Decimal(5, 4))
    resource_usage = Column(JSON, default={})
    timestamp = Column(DateTime, nullable=False)
    
    # Relacionamentos
    contract = relationship("DataContract")

class SLADefinition(Base):
    __tablename__ = 'sla_definitions'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'), nullable=False)
    sla_name = Column(String(255), nullable=False)
    sla_type = Column(String(100), nullable=False)
    target_value = Column(Decimal(10, 4), nullable=False)
    threshold_warning = Column(Decimal(10, 4))
    threshold_critical = Column(Decimal(10, 4))
    measurement_window = Column(String(50), nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    contract = relationship("DataContract", back_populates="sla_definitions")
    violations = relationship("SLAViolation", back_populates="sla")

class SLAViolation(Base):
    __tablename__ = 'sla_violations'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    sla_id = Column(PG_UUID(as_uuid=True), ForeignKey('sla_definitions._id'), nullable=False)
    violation_type = Column(String(100), nullable=False)
    actual_value = Column(Decimal(10, 4), nullable=False)
    threshold_value = Column(Decimal(10, 4), nullable=False)
    severity = Column(String(50), nullable=False)
    violation_start = Column(DateTime, nullable=False)
    violation_end = Column(DateTime)
    resolution_notes = Column(Text)
    resolved_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    
    # Relacionamentos
    sla = relationship("SLADefinition", back_populates="violations")
    resolved_by = relationship("User")

# ===== NOTIFICAÇÕES E ALERTAS =====

class Notification(Base):
    __tablename__ = 'notifications'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'), nullable=False)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'))
    notification_type = Column(String(100), nullable=False)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    is_read = Column(Boolean, default=False)
    read_at = Column(DateTime)
    priority = Column(String(20), default='medium')
    category = Column(String(100))
    metadata = Column(JSON, default={})
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Constraints
    __table_args__ = (
        CheckConstraint(notification_type.in_(['contract_expiring', 'compliance_violation', 'quality_issue', 'approval_required', 'system_alert'])),
        CheckConstraint(priority.in_(['low', 'medium', 'high', 'critical'])),
        Index('idx_notifications_user', user_id),
        Index('idx_notifications_type', notification_type),
    )
    
    # Relacionamentos
    user = relationship("User", back_populates="notifications")
    contract = relationship("DataContract", back_populates="notifications")

class AlertRule(Base):
    __tablename__ = 'alert_rules'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_name = Column(String(255), nullable=False)
    rule_type = Column(String(100), nullable=False)
    condition_expression = Column(Text, nullable=False)
    severity = Column(String(50), nullable=False)
    notification_channels = Column(ARRAY(String(100)), default=[])
    is_active = Column(Boolean, default=True)
    created_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    created_by = relationship("User")
    instances = relationship("AlertInstance", back_populates="rule")

class AlertInstance(Base):
    __tablename__ = 'alert_instances'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_id = Column(PG_UUID(as_uuid=True), ForeignKey('alert_rules._id'), nullable=False)
    contract_id = Column(PG_UUID(as_uuid=True), ForeignKey('data_contracts._id'))
    alert_status = Column(String(50), nullable=False, default='active')
    triggered_at = Column(DateTime, nullable=False)
    resolved_at = Column(DateTime)
    alert_data = Column(JSON, default={})
    resolution_notes = Column(Text)
    resolved_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    
    # Relacionamentos
    rule = relationship("AlertRule", back_populates="instances")
    contract = relationship("DataContract")
    resolved_by = relationship("User")

# ===== CONFIGURAÇÕES E METADADOS (INCLUINDO TAGS) =====

class SystemConfiguration(Base):
    __tablename__ = 'system_configurations'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    config_key = Column(String(255), unique=True, nullable=False)
    config_value = Column(Text, nullable=False)
    config_type = Column(String(50), nullable=False)
    description = Column(Text)
    is_encrypted = Column(Boolean, default=False)
    country_specific = Column(String(3))
    updated_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    created_at = Column(DateTime, default=func.current_timestamp())
    updated_at = Column(DateTime, default=func.current_timestamp(), onupdate=func.current_timestamp())
    
    # Relacionamentos
    updated_by = relationship("User")

class MetadataTag(Base):
    __tablename__ = 'metadata_tags'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    tag_name = Column(String(100), unique=True, nullable=False)
    tag_category = Column(String(100))
    tag_description = Column(Text)
    tag_color = Column(String(7))
    is_system_tag = Column(Boolean, default=False)
    created_at = Column(DateTime, default=func.current_timestamp())
    
    # Relacionamentos
    entity_associations = relationship("EntityTag", back_populates="tag")

class EntityTag(Base):
    __tablename__ = 'entity_tags'
    
    _id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    entity_type = Column(String(100), nullable=False)
    entity_id = Column(PG_UUID(as_uuid=True), nullable=False)
    tag_id = Column(PG_UUID(as_uuid=True), ForeignKey('metadata_tags._id'), nullable=False)
    tagged_by_user_id = Column(PG_UUID(as_uuid=True), ForeignKey('users._id'))
    tagged_at = Column(DateTime, default=func.current_timestamp())
    
    # Relacionamentos
    tag = relationship("MetadataTag", back_populates="entity_associations")
    tagged_by = relationship("User")

# ===== ÍNDICES ADICIONAIS PARA PERFORMANCE =====

# Índices compostos para consultas frequentes
Index('idx_contracts_country_status', DataContract.country_code, DataContract.contract_status)
Index('idx_contracts_owner_country', DataContract.business_owner_id, DataContract.country_code)
Index('idx_versions_contract_country', ContractVersion.contract_id, ContractVersion.country_code)
Index('idx_policies_contract_active', AccessPolicy.contract_id, AccessPolicy.is_active)
Index('idx_quality_contract_active', QualityMetric.contract_id, QualityMetric.is_active)
Index('idx_notifications_user_read', Notification.user_id, Notification.is_read)
Index('idx_audit_user_action_date', AuditLog.user_id, AuditLog.action_type, AuditLog.created_at)
Index('idx_entity_tags_type_entity', EntityTag.entity_type, EntityTag.entity_id)

