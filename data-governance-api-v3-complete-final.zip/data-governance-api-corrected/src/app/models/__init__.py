"""
Modelos de dados para Data Governance API
Implementa Clean Architecture e princípios SOLID
"""

from .data_contracts import (
    Base,
    DataContract,
    ContractVersion,
    User,
    UserGroup,
    AccessPolicy,
    ComplianceFramework,
    AuditLog,
    ContractSchema,
    contract_compliance_frameworks,
    user_groups_association
)

__all__ = [
    'Base',
    'DataContract',
    'ContractVersion', 
    'User',
    'UserGroup',
    'AccessPolicy',
    'ComplianceFramework',
    'AuditLog',
    'ContractSchema',
    'contract_compliance_frameworks',
    'user_groups_association'
]

