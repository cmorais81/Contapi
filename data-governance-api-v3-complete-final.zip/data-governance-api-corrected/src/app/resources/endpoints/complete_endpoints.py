"""
Endpoints principais para Data Governance API
Versão: 3.0.0 - Endpoints Completos com 30+ Recursos
Autor: Carlos Morais
Data: 26 de Dezembro de 2025

Endpoints para todas as funcionalidades:
- Contratos de dados com versionamento flexível
- Usuários e controle de acesso granular
- Compliance e frameworks
- Qualidade de dados
- Lineage e rastreabilidade
- Monitoramento e métricas
- Notificações e alertas
- Tags e metadados
"""

from fastapi import APIRouter, Depends, HTTPException, Query, Path, status
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from uuid import UUID
import logging

from ..config.database import get_db
from ..models.complete_models import *
from ..schemas.complete_schemas import *
from ..services.interfaces import *
from ..utils.auth import get_current_user, require_permissions
from ..utils.exceptions import *

# Configuração de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Security
security = HTTPBearer()

# Router principal
router = APIRouter(prefix="/api/v1", tags=["Data Governance API"])

# ===== ENDPOINTS DE CONTRATOS DE DADOS =====

contracts_router = APIRouter(prefix="/contracts", tags=["Data Contracts"])

@contracts_router.post("/", response_model=DataContractResponse, status_code=status.HTTP_201_CREATED)
async def create_contract(
    contract: DataContractCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Criar um novo contrato de dados.
    
    - **Flexibilidade por país**: Suporte a contratos específicos por jurisdição
    - **Versionamento**: Controle de versões automático
    - **Auditoria**: Log completo de criação
    """
    try:
        # Validar permissões por país
        if contract.country_code not in current_user.country_access:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Acesso negado para o país: {contract.country_code}"
            )
        
        # Criar contrato
        db_contract = DataContract(**contract.dict())
        db.add(db_contract)
        db.commit()
        db.refresh(db_contract)
        
        # Log de auditoria
        audit_log = AuditLog(
            contract_id=db_contract._id,
            user_id=current_user._id,
            action_type=ActionType.CREATE,
            resource_type="data_contract",
            resource_id=db_contract._id,
            change_description=f"Contrato '{contract.contract_name}' criado",
            new_values=contract.dict(),
            country_code=contract.country_code
        )
        db.add(audit_log)
        db.commit()
        
        logger.info(f"Contrato criado: {db_contract._id} por usuário {current_user._id}")
        return db_contract
        
    except Exception as e:
        db.rollback()
        logger.error(f"Erro ao criar contrato: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@contracts_router.get("/", response_model=List[DataContractResponse])
async def list_contracts(
    filters: ContractFilters = Depends(),
    pagination: PaginationParams = Depends(),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Listar contratos de dados com filtros avançados.
    
    - **Filtros**: Status, classificação, país, proprietário
    - **Paginação**: Controle de páginas e tamanho
    - **Acesso**: Baseado nas permissões do usuário
    """
    try:
        query = db.query(DataContract)
        
        # Filtrar por países acessíveis ao usuário
        if not current_user.is_superuser:
            query = query.filter(DataContract.country_code.in_(current_user.country_access))
        
        # Aplicar filtros
        if filters.contract_status:
            query = query.filter(DataContract.contract_status == filters.contract_status)
        if filters.data_classification:
            query = query.filter(DataContract.data_classification == filters.data_classification)
        if filters.country_code:
            query = query.filter(DataContract.country_code == filters.country_code)
        if filters.business_owner_id:
            query = query.filter(DataContract.business_owner_id == filters.business_owner_id)
        if filters.created_by_user_id:
            query = query.filter(DataContract.created_by_user_id == filters.created_by_user_id)
        if filters.search:
            query = query.filter(DataContract.contract_name.ilike(f"%{filters.search}%"))
        
        # Paginação
        total = query.count()
        contracts = query.offset((pagination.page - 1) * pagination.size).limit(pagination.size).all()
        
        return contracts
        
    except Exception as e:
        logger.error(f"Erro ao listar contratos: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@contracts_router.get("/{contract_id}", response_model=DataContractDetailResponse)
async def get_contract(
    contract_id: UUID = Path(..., description="ID do contrato"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Obter detalhes completos de um contrato específico.
    
    - **Detalhes completos**: Inclui versões, compliance, objetos de dados
    - **Controle de acesso**: Validação por país e permissões
    """
    try:
        contract = db.query(DataContract).filter(DataContract._id == contract_id).first()
        if not contract:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Contrato não encontrado")
        
        # Validar acesso por país
        if not current_user.is_superuser and contract.country_code not in current_user.country_access:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Acesso negado")
        
        # Log de auditoria para acesso
        audit_log = AuditLog(
            contract_id=contract._id,
            user_id=current_user._id,
            action_type=ActionType.READ,
            resource_type="data_contract",
            resource_id=contract._id,
            change_description=f"Contrato '{contract.contract_name}' acessado",
            country_code=contract.country_code
        )
        db.add(audit_log)
        db.commit()
        
        return contract
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter contrato: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@contracts_router.put("/{contract_id}", response_model=DataContractResponse)
async def update_contract(
    contract_id: UUID = Path(..., description="ID do contrato"),
    contract_update: DataContractUpdate = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Atualizar um contrato de dados existente.
    
    - **Versionamento automático**: Criação de nova versão se necessário
    - **Auditoria completa**: Log de todas as alterações
    """
    try:
        contract = db.query(DataContract).filter(DataContract._id == contract_id).first()
        if not contract:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Contrato não encontrado")
        
        # Validar acesso
        if not current_user.is_superuser and contract.country_code not in current_user.country_access:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Acesso negado")
        
        # Armazenar valores antigos para auditoria
        old_values = {
            "contract_name": contract.contract_name,
            "contract_description": contract.contract_description,
            "contract_status": contract.contract_status,
            "data_classification": contract.data_classification
        }
        
        # Atualizar campos
        update_data = contract_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            if hasattr(contract, field):
                setattr(contract, field, value)
        
        contract.updated_by_user_id = current_user._id
        db.commit()
        db.refresh(contract)
        
        # Log de auditoria
        audit_log = AuditLog(
            contract_id=contract._id,
            user_id=current_user._id,
            action_type=ActionType.UPDATE,
            resource_type="data_contract",
            resource_id=contract._id,
            change_description=f"Contrato '{contract.contract_name}' atualizado",
            old_values=old_values,
            new_values=update_data,
            country_code=contract.country_code
        )
        db.add(audit_log)
        db.commit()
        
        return contract
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Erro ao atualizar contrato: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@contracts_router.delete("/{contract_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_contract(
    contract_id: UUID = Path(..., description="ID do contrato"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Excluir um contrato de dados (soft delete).
    
    - **Soft delete**: Marca como arquivado ao invés de excluir
    - **Auditoria**: Log completo da exclusão
    """
    try:
        contract = db.query(DataContract).filter(DataContract._id == contract_id).first()
        if not contract:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Contrato não encontrado")
        
        # Validar acesso
        if not current_user.is_superuser and contract.country_code not in current_user.country_access:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Acesso negado")
        
        # Soft delete - marcar como arquivado
        contract.contract_status = ContractStatus.ARCHIVED
        contract.updated_by_user_id = current_user._id
        db.commit()
        
        # Log de auditoria
        audit_log = AuditLog(
            contract_id=contract._id,
            user_id=current_user._id,
            action_type=ActionType.DELETE,
            resource_type="data_contract",
            resource_id=contract._id,
            change_description=f"Contrato '{contract.contract_name}' arquivado",
            country_code=contract.country_code
        )
        db.add(audit_log)
        db.commit()
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Erro ao excluir contrato: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ===== ENDPOINTS DE VERSIONAMENTO =====

versions_router = APIRouter(prefix="/contracts/{contract_id}/versions", tags=["Contract Versions"])

@versions_router.post("/", response_model=ContractVersionResponse, status_code=status.HTTP_201_CREATED)
async def create_version(
    contract_id: UUID = Path(..., description="ID do contrato"),
    version: ContractVersionCreate = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Criar nova versão de um contrato.
    
    - **Versionamento flexível**: Suporte a versões por país
    - **Breaking changes**: Detecção automática de mudanças críticas
    """
    try:
        # Validar se contrato existe
        contract = db.query(DataContract).filter(DataContract._id == contract_id).first()
        if not contract:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Contrato não encontrado")
        
        # Criar versão
        version.contract_id = contract_id
        db_version = ContractVersion(**version.dict())
        db.add(db_version)
        db.commit()
        db.refresh(db_version)
        
        return db_version
        
    except Exception as e:
        db.rollback()
        logger.error(f"Erro ao criar versão: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ===== ENDPOINTS DE USUÁRIOS =====

users_router = APIRouter(prefix="/users", tags=["Users"])

@users_router.post("/", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(
    user: UserCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Criar novo usuário.
    
    - **Controle de acesso por país**: Definição de países acessíveis
    - **Validação de email**: Email único no sistema
    """
    try:
        # Verificar se usuário já existe
        existing_user = db.query(User).filter(
            (User.username == user.username) | (User.email == user.email)
        ).first()
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Usuário ou email já existe"
            )
        
        # Hash da senha (implementar hash real em produção)
        user_data = user.dict()
        user_data['password_hash'] = user_data.pop('password')  # Simplificado
        
        db_user = User(**user_data)
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
        
        return db_user
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Erro ao criar usuário: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@users_router.get("/", response_model=List[UserResponse])
async def list_users(
    pagination: PaginationParams = Depends(),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Listar usuários com paginação."""
    try:
        query = db.query(User).filter(User.is_active == True)
        
        total = query.count()
        users = query.offset((pagination.page - 1) * pagination.size).limit(pagination.size).all()
        
        return users
        
    except Exception as e:
        logger.error(f"Erro ao listar usuários: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ===== ENDPOINTS DE QUALIDADE DE DADOS =====

quality_router = APIRouter(prefix="/quality", tags=["Data Quality"])

@quality_router.post("/metrics", response_model=QualityMetricResponse, status_code=status.HTTP_201_CREATED)
async def create_quality_metric(
    metric: QualityMetricCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Criar métrica de qualidade de dados.
    
    - **Métricas automatizadas**: Execução automática de validações
    - **Histórico**: Armazenamento de resultados históricos
    """
    try:
        db_metric = QualityMetric(**metric.dict())
        db.add(db_metric)
        db.commit()
        db.refresh(db_metric)
        
        return db_metric
        
    except Exception as e:
        db.rollback()
        logger.error(f"Erro ao criar métrica de qualidade: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@quality_router.get("/metrics", response_model=List[QualityMetricResponse])
async def list_quality_metrics(
    filters: QualityMetricFilters = Depends(),
    pagination: PaginationParams = Depends(),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Listar métricas de qualidade com filtros."""
    try:
        query = db.query(QualityMetric)
        
        if filters.contract_id:
            query = query.filter(QualityMetric.contract_id == filters.contract_id)
        if filters.metric_type:
            query = query.filter(QualityMetric.metric_type == filters.metric_type)
        if filters.is_active is not None:
            query = query.filter(QualityMetric.is_active == filters.is_active)
        
        total = query.count()
        metrics = query.offset((pagination.page - 1) * pagination.size).limit(pagination.size).all()
        
        return metrics
        
    except Exception as e:
        logger.error(f"Erro ao listar métricas de qualidade: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ===== ENDPOINTS DE TAGS E METADADOS =====

tags_router = APIRouter(prefix="/tags", tags=["Metadata Tags"])

@tags_router.post("/", response_model=MetadataTagResponse, status_code=status.HTTP_201_CREATED)
async def create_tag(
    tag: MetadataTagCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Criar nova tag de metadados.
    
    - **Categorização**: Organização por categorias
    - **Cores**: Suporte a cores para visualização
    """
    try:
        # Verificar se tag já existe
        existing_tag = db.query(MetadataTag).filter(MetadataTag.tag_name == tag.tag_name).first()
        if existing_tag:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Tag já existe"
            )
        
        db_tag = MetadataTag(**tag.dict())
        db.add(db_tag)
        db.commit()
        db.refresh(db_tag)
        
        return db_tag
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Erro ao criar tag: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@tags_router.get("/", response_model=List[MetadataTagResponse])
async def list_tags(
    category: Optional[str] = Query(None, description="Filtrar por categoria"),
    pagination: PaginationParams = Depends(),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Listar tags de metadados."""
    try:
        query = db.query(MetadataTag)
        
        if category:
            query = query.filter(MetadataTag.tag_category == category)
        
        total = query.count()
        tags = query.offset((pagination.page - 1) * pagination.size).limit(pagination.size).all()
        
        return tags
        
    except Exception as e:
        logger.error(f"Erro ao listar tags: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@tags_router.post("/entities", response_model=EntityTagResponse, status_code=status.HTTP_201_CREATED)
async def tag_entity(
    entity_tag: EntityTagCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Associar tag a uma entidade.
    
    - **Flexibilidade**: Suporte a qualquer tipo de entidade
    - **Rastreabilidade**: Log de quem aplicou a tag
    """
    try:
        # Verificar se tag existe
        tag = db.query(MetadataTag).filter(MetadataTag._id == entity_tag.tag_id).first()
        if not tag:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Tag não encontrada")
        
        # Verificar se associação já existe
        existing = db.query(EntityTag).filter(
            EntityTag.entity_type == entity_tag.entity_type,
            EntityTag.entity_id == entity_tag.entity_id,
            EntityTag.tag_id == entity_tag.tag_id
        ).first()
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Tag já associada a esta entidade"
            )
        
        entity_tag.tagged_by_user_id = current_user._id
        db_entity_tag = EntityTag(**entity_tag.dict())
        db.add(db_entity_tag)
        db.commit()
        db.refresh(db_entity_tag)
        
        return db_entity_tag
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Erro ao associar tag: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ===== ENDPOINTS DE AUDITORIA =====

audit_router = APIRouter(prefix="/audit", tags=["Audit & Monitoring"])

@audit_router.get("/logs", response_model=List[AuditLogResponse])
async def list_audit_logs(
    filters: AuditLogFilters = Depends(),
    pagination: PaginationParams = Depends(),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Listar logs de auditoria com filtros avançados.
    
    - **Filtros avançados**: Por usuário, ação, país, período
    - **Controle de acesso**: Baseado em permissões do usuário
    """
    try:
        query = db.query(AuditLog)
        
        # Filtrar por países acessíveis (se não for superuser)
        if not current_user.is_superuser:
            query = query.filter(AuditLog.country_code.in_(current_user.country_access))
        
        # Aplicar filtros
        if filters.contract_id:
            query = query.filter(AuditLog.contract_id == filters.contract_id)
        if filters.user_id:
            query = query.filter(AuditLog.user_id == filters.user_id)
        if filters.action_type:
            query = query.filter(AuditLog.action_type == filters.action_type)
        if filters.resource_type:
            query = query.filter(AuditLog.resource_type == filters.resource_type)
        if filters.country_code:
            query = query.filter(AuditLog.country_code == filters.country_code)
        if filters.date_from:
            query = query.filter(AuditLog.created_at >= filters.date_from)
        if filters.date_to:
            query = query.filter(AuditLog.created_at <= filters.date_to)
        
        # Ordenar por data (mais recente primeiro)
        query = query.order_by(AuditLog.created_at.desc())
        
        total = query.count()
        logs = query.offset((pagination.page - 1) * pagination.size).limit(pagination.size).all()
        
        return logs
        
    except Exception as e:
        logger.error(f"Erro ao listar logs de auditoria: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ===== ENDPOINTS DE NOTIFICAÇÕES =====

notifications_router = APIRouter(prefix="/notifications", tags=["Notifications"])

@notifications_router.get("/", response_model=List[NotificationResponse])
async def list_notifications(
    filters: NotificationFilters = Depends(),
    pagination: PaginationParams = Depends(),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Listar notificações do usuário.
    
    - **Filtros**: Por tipo, status de leitura, prioridade
    - **Personalização**: Apenas notificações do usuário atual
    """
    try:
        query = db.query(Notification).filter(Notification.user_id == current_user._id)
        
        if filters.notification_type:
            query = query.filter(Notification.notification_type == filters.notification_type)
        if filters.is_read is not None:
            query = query.filter(Notification.is_read == filters.is_read)
        if filters.priority:
            query = query.filter(Notification.priority == filters.priority)
        
        # Ordenar por data (mais recente primeiro)
        query = query.order_by(Notification.created_at.desc())
        
        total = query.count()
        notifications = query.offset((pagination.page - 1) * pagination.size).limit(pagination.size).all()
        
        return notifications
        
    except Exception as e:
        logger.error(f"Erro ao listar notificações: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

@notifications_router.patch("/{notification_id}/read", response_model=NotificationResponse)
async def mark_notification_read(
    notification_id: UUID = Path(..., description="ID da notificação"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Marcar notificação como lida."""
    try:
        notification = db.query(Notification).filter(
            Notification._id == notification_id,
            Notification.user_id == current_user._id
        ).first()
        
        if not notification:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Notificação não encontrada")
        
        notification.is_read = True
        notification.read_at = datetime.utcnow()
        db.commit()
        db.refresh(notification)
        
        return notification
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Erro ao marcar notificação como lida: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ===== ENDPOINTS DE ESTATÍSTICAS =====

stats_router = APIRouter(prefix="/statistics", tags=["Statistics & Reports"])

@stats_router.get("/contracts", response_model=ContractStatistics)
async def get_contract_statistics(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Obter estatísticas de contratos.
    
    - **Visão geral**: Total, status, classificação, países
    - **Alertas**: Contratos expirando, violações de compliance
    """
    try:
        query = db.query(DataContract)
        
        # Filtrar por países acessíveis
        if not current_user.is_superuser:
            query = query.filter(DataContract.country_code.in_(current_user.country_access))
        
        total_contracts = query.count()
        
        # Estatísticas por status
        contracts_by_status = {}
        for status in ContractStatus:
            count = query.filter(DataContract.contract_status == status).count()
            contracts_by_status[status.value] = count
        
        # Estatísticas por classificação
        contracts_by_classification = {}
        for classification in DataClassification:
            count = query.filter(DataContract.data_classification == classification).count()
            contracts_by_classification[classification.value] = count
        
        # Estatísticas por país
        contracts_by_country = {}
        country_results = db.query(
            DataContract.country_code,
            db.func.count(DataContract._id).label('count')
        ).group_by(DataContract.country_code).all()
        
        for country, count in country_results:
            contracts_by_country[country] = count
        
        # Contratos expirando em 30 dias
        from datetime import datetime, timedelta
        expiring_date = datetime.utcnow() + timedelta(days=30)
        expiring_soon = query.filter(
            DataContract.expiration_date <= expiring_date,
            DataContract.contract_status == ContractStatus.ACTIVE
        ).count()
        
        # Violações de compliance (simplificado)
        compliance_violations = db.query(ContractComplianceFramework).filter(
            ContractComplianceFramework.compliance_status == ComplianceStatus.NON_COMPLIANT
        ).count()
        
        return ContractStatistics(
            total_contracts=total_contracts,
            contracts_by_status=contracts_by_status,
            contracts_by_classification=contracts_by_classification,
            contracts_by_country=contracts_by_country,
            expiring_soon=expiring_soon,
            compliance_violations=compliance_violations
        )
        
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas de contratos: {str(e)}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

# ===== ENDPOINT DE SAÚDE DO SISTEMA =====

@router.get("/health", response_model=SystemHealthResponse)
async def health_check(db: Session = Depends(get_db)):
    """
    Verificação de saúde do sistema.
    
    - **Status geral**: API, banco de dados, cache
    - **Métricas**: Usuários ativos, contratos totais
    """
    try:
        # Testar conexão com banco
        db.execute("SELECT 1")
        database_status = "healthy"
        
        # Métricas básicas
        active_users = db.query(User).filter(User.is_active == True).count()
        total_contracts = db.query(DataContract).count()
        
        return SystemHealthResponse(
            status="healthy",
            version="3.0.0",
            uptime="Sistema operacional",
            database_status=database_status,
            cache_status="healthy",
            active_users=active_users,
            total_contracts=total_contracts,
            system_load={"cpu": "normal", "memory": "normal", "disk": "normal"}
        )
        
    except Exception as e:
        logger.error(f"Erro na verificação de saúde: {str(e)}")
        return SystemHealthResponse(
            status="unhealthy",
            version="3.0.0",
            uptime="Sistema com problemas",
            database_status="error",
            cache_status="error",
            active_users=0,
            total_contracts=0,
            system_load={"cpu": "error", "memory": "error", "disk": "error"}
        )

# ===== REGISTRO DE ROUTERS =====

# Incluir todos os routers no router principal
router.include_router(contracts_router)
router.include_router(versions_router)
router.include_router(users_router)
router.include_router(quality_router)
router.include_router(tags_router)
router.include_router(audit_router)
router.include_router(notifications_router)
router.include_router(stats_router)

