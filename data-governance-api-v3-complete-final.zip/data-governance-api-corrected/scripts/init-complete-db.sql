-- Data Governance API - Script de Inicialização Completo
-- Versão: 3.0.0 - Schema Completo com 30+ Tabelas
-- Autor: Carlos Morais
-- Data: 26 de Dezembro de 2025
--
-- Script para criação de todas as tabelas do modelo completo
-- Inclui extensões, índices, constraints e dados mock

-- ===== EXTENSÕES NECESSÁRIAS =====

-- Extensão para UUIDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Extensão para tipos de rede
CREATE EXTENSION IF NOT EXISTS "cidr";

-- ===== CRIAÇÃO DAS TABELAS =====

-- Tabela: users
CREATE TABLE IF NOT EXISTS users (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_superuser BOOLEAN DEFAULT FALSE,
    country_access VARCHAR(3)[] DEFAULT '{}',
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: user_groups
CREATE TABLE IF NOT EXISTS user_groups (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    group_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    permissions JSONB DEFAULT '{}',
    country_restrictions VARCHAR(3)[] DEFAULT '{}',
    contract_access_level VARCHAR(50) DEFAULT 'read',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: user_group_memberships
CREATE TABLE IF NOT EXISTS user_group_memberships (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(_id) ON DELETE CASCADE,
    group_id UUID NOT NULL REFERENCES user_groups(_id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    assigned_by_user_id UUID REFERENCES users(_id),
    access_level VARCHAR(50) DEFAULT 'member'
);

-- Tabela: user_roles
CREATE TABLE IF NOT EXISTS user_roles (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    role_name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    permissions JSONB NOT NULL,
    is_system_role BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: user_role_assignments
CREATE TABLE IF NOT EXISTS user_role_assignments (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(_id) ON DELETE CASCADE,
    role_id UUID NOT NULL REFERENCES user_roles(_id) ON DELETE CASCADE,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    assigned_by_user_id UUID REFERENCES users(_id),
    expires_at TIMESTAMP
);

-- Tabela: compliance_frameworks
CREATE TABLE IF NOT EXISTS compliance_frameworks (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    framework_name VARCHAR(255) NOT NULL,
    framework_code VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    applicable_countries VARCHAR(3)[] DEFAULT '{}',
    data_retention_requirements JSONB DEFAULT '{}',
    consent_requirements JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: compliance_rules
CREATE TABLE IF NOT EXISTS compliance_rules (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    framework_id UUID NOT NULL REFERENCES compliance_frameworks(_id) ON DELETE CASCADE,
    rule_name VARCHAR(255) NOT NULL,
    rule_type VARCHAR(100) NOT NULL,
    rule_definition JSONB NOT NULL,
    applicable_countries VARCHAR(3)[] DEFAULT '{}',
    severity VARCHAR(50) DEFAULT 'medium',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: data_contracts
CREATE TABLE IF NOT EXISTS data_contracts (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_name VARCHAR(255) NOT NULL,
    contract_description TEXT,
    contract_version VARCHAR(50) NOT NULL DEFAULT '1.0.0',
    contract_status VARCHAR(50) NOT NULL DEFAULT 'draft' CHECK (contract_status IN ('draft', 'review', 'approved', 'active', 'deprecated', 'archived')),
    data_classification VARCHAR(50) NOT NULL DEFAULT 'internal' CHECK (data_classification IN ('public', 'internal', 'confidential', 'restricted')),
    business_owner_id UUID REFERENCES users(_id),
    technical_owner_id UUID REFERENCES users(_id),
    data_steward_id UUID REFERENCES users(_id),
    country_code VARCHAR(3) NOT NULL,
    jurisdiction VARCHAR(100),
    region VARCHAR(100),
    regulatory_framework VARCHAR(100),
    effective_date TIMESTAMP,
    expiration_date TIMESTAMP,
    review_date TIMESTAMP,
    data_retention_days INTEGER DEFAULT 1095 CHECK (data_retention_days > 0),
    purge_after_expiration BOOLEAN DEFAULT FALSE,
    approved_at TIMESTAMP,
    approved_by_user_id UUID REFERENCES users(_id),
    created_by_user_id UUID NOT NULL REFERENCES users(_id),
    updated_by_user_id UUID REFERENCES users(_id),
    previous_version_id UUID REFERENCES data_contracts(_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: contract_versions
CREATE TABLE IF NOT EXISTS contract_versions (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    version_number VARCHAR(50) NOT NULL,
    version_type VARCHAR(20) NOT NULL DEFAULT 'minor' CHECK (version_type IN ('major', 'minor', 'patch')),
    country_specific_version BOOLEAN DEFAULT FALSE,
    country_code VARCHAR(3),
    changelog TEXT,
    is_breaking_change BOOLEAN DEFAULT FALSE,
    migration_script TEXT,
    created_by_user_id UUID NOT NULL REFERENCES users(_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: contract_layouts
CREATE TABLE IF NOT EXISTS contract_layouts (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    layout_name VARCHAR(255) NOT NULL,
    layout_type VARCHAR(100) NOT NULL,
    layout_definition JSONB NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: contract_compliance_frameworks
CREATE TABLE IF NOT EXISTS contract_compliance_frameworks (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    framework_id UUID NOT NULL REFERENCES compliance_frameworks(_id) ON DELETE CASCADE,
    compliance_status VARCHAR(50) DEFAULT 'pending' CHECK (compliance_status IN ('pending', 'compliant', 'non_compliant', 'warning')),
    last_validation_date TIMESTAMP,
    validation_results JSONB DEFAULT '{}',
    country_specific_rules JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: data_objects
CREATE TABLE IF NOT EXISTS data_objects (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    object_name VARCHAR(255) NOT NULL,
    object_type VARCHAR(100) NOT NULL CHECK (object_type IN ('table', 'view', 'file', 'stream', 'api', 'dataset')),
    object_description TEXT,
    schema_definition JSONB DEFAULT '{}',
    data_format VARCHAR(100),
    encoding VARCHAR(50),
    storage_location TEXT,
    access_pattern VARCHAR(100),
    quality_rules JSONB DEFAULT '{}',
    validation_rules JSONB DEFAULT '{}',
    business_glossary JSONB DEFAULT '{}',
    tags VARCHAR(100)[] DEFAULT '{}',
    encryption_required BOOLEAN DEFAULT FALSE,
    masking_rules JSONB DEFAULT '{}',
    access_controls JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: data_object_fields
CREATE TABLE IF NOT EXISTS data_object_fields (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    data_object_id UUID NOT NULL REFERENCES data_objects(_id) ON DELETE CASCADE,
    field_name VARCHAR(255) NOT NULL,
    field_type VARCHAR(100) NOT NULL,
    field_description TEXT,
    is_nullable BOOLEAN DEFAULT TRUE,
    is_primary_key BOOLEAN DEFAULT FALSE,
    is_foreign_key BOOLEAN DEFAULT FALSE,
    default_value TEXT,
    validation_rules JSONB DEFAULT '{}',
    quality_checks JSONB DEFAULT '{}',
    data_classification VARCHAR(50) DEFAULT 'internal' CHECK (data_classification IN ('public', 'internal', 'confidential', 'restricted')),
    is_pii BOOLEAN DEFAULT FALSE,
    is_sensitive BOOLEAN DEFAULT FALSE,
    masking_type VARCHAR(50) CHECK (masking_type IN ('hash', 'encrypt', 'tokenize', 'redact', 'partial') OR masking_type IS NULL),
    business_name VARCHAR(255),
    business_description TEXT,
    business_rules TEXT,
    field_order INTEGER,
    field_group VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: data_schemas
CREATE TABLE IF NOT EXISTS data_schemas (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    schema_name VARCHAR(255) NOT NULL,
    schema_version VARCHAR(50) NOT NULL,
    schema_definition JSONB NOT NULL,
    schema_format VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: access_policies
CREATE TABLE IF NOT EXISTS access_policies (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    policy_name VARCHAR(255) NOT NULL,
    policy_type VARCHAR(50) NOT NULL CHECK (policy_type IN ('access_control', 'data_masking', 'retention', 'quality', 'compliance')),
    policy_description TEXT,
    policy_rules JSONB NOT NULL DEFAULT '{}',
    conditions JSONB DEFAULT '{}',
    actions JSONB DEFAULT '{}',
    applies_to_objects UUID[] DEFAULT '{}',
    applies_to_fields UUID[] DEFAULT '{}',
    applies_to_users UUID[] DEFAULT '{}',
    applies_to_groups UUID[] DEFAULT '{}',
    country_restrictions VARCHAR(3)[] DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    effective_from TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    effective_until TIMESTAMP,
    created_by_user_id UUID NOT NULL REFERENCES users(_id),
    approved_by_user_id UUID REFERENCES users(_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: access_control_lists
CREATE TABLE IF NOT EXISTS access_control_lists (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    resource_type VARCHAR(100) NOT NULL,
    resource_id UUID NOT NULL,
    principal_type VARCHAR(50) NOT NULL,
    principal_id UUID NOT NULL,
    permission VARCHAR(100) NOT NULL,
    granted BOOLEAN DEFAULT TRUE,
    granted_by_user_id UUID REFERENCES users(_id),
    granted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP
);

-- Tabela: data_masking_policies
CREATE TABLE IF NOT EXISTS data_masking_policies (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    policy_name VARCHAR(255) NOT NULL,
    masking_type VARCHAR(50) NOT NULL,
    masking_rules JSONB NOT NULL,
    applies_to_fields UUID[] NOT NULL,
    conditions JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: audit_logs
CREATE TABLE IF NOT EXISTS audit_logs (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID REFERENCES data_contracts(_id),
    user_id UUID REFERENCES users(_id),
    action_type VARCHAR(50) NOT NULL CHECK (action_type IN ('CREATE', 'READ', 'UPDATE', 'DELETE', 'APPROVE', 'ACCESS', 'EXPORT')),
    resource_type VARCHAR(100) NOT NULL,
    resource_id UUID,
    change_description TEXT,
    old_values JSONB,
    new_values JSONB,
    change_summary JSONB DEFAULT '{}',
    ip_address INET,
    user_agent TEXT,
    session_id VARCHAR(255),
    country_code VARCHAR(3),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: audit_trails
CREATE TABLE IF NOT EXISTS audit_trails (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_type VARCHAR(100) NOT NULL,
    entity_id UUID NOT NULL,
    operation VARCHAR(50) NOT NULL,
    performed_by_user_id UUID REFERENCES users(_id),
    performed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    details JSONB DEFAULT '{}',
    correlation_id UUID
);

-- Tabela: system_events
CREATE TABLE IF NOT EXISTS system_events (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_type VARCHAR(100) NOT NULL,
    event_category VARCHAR(50) NOT NULL,
    event_description TEXT,
    event_data JSONB DEFAULT '{}',
    severity VARCHAR(20) DEFAULT 'info',
    source_system VARCHAR(100),
    correlation_id UUID,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: quality_metrics
CREATE TABLE IF NOT EXISTS quality_metrics (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    data_object_id UUID REFERENCES data_objects(_id) ON DELETE CASCADE,
    field_id UUID REFERENCES data_object_fields(_id) ON DELETE CASCADE,
    metric_name VARCHAR(255) NOT NULL,
    metric_type VARCHAR(100) NOT NULL CHECK (metric_type IN ('completeness', 'accuracy', 'consistency', 'validity', 'uniqueness', 'timeliness')),
    metric_description TEXT,
    metric_definition JSONB NOT NULL DEFAULT '{}',
    thresholds JSONB DEFAULT '{}',
    last_execution_date TIMESTAMP,
    last_result JSONB,
    execution_status VARCHAR(50) CHECK (execution_status IN ('pending', 'running', 'success', 'failed', 'warning') OR execution_status IS NULL),
    execution_history JSONB DEFAULT '[]',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: quality_rules
CREATE TABLE IF NOT EXISTS quality_rules (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    rule_name VARCHAR(255) NOT NULL,
    rule_type VARCHAR(100) NOT NULL,
    rule_definition JSONB NOT NULL,
    applies_to_objects UUID[] DEFAULT '{}',
    applies_to_fields UUID[] DEFAULT '{}',
    severity VARCHAR(50) DEFAULT 'medium',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: quality_assessments
CREATE TABLE IF NOT EXISTS quality_assessments (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    assessment_date TIMESTAMP NOT NULL,
    overall_score DECIMAL(5,2),
    completeness_score DECIMAL(5,2),
    accuracy_score DECIMAL(5,2),
    consistency_score DECIMAL(5,2),
    validity_score DECIMAL(5,2),
    uniqueness_score DECIMAL(5,2),
    timeliness_score DECIMAL(5,2),
    assessment_details JSONB DEFAULT '{}',
    recommendations TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: data_lineage
CREATE TABLE IF NOT EXISTS data_lineage (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_contract_id UUID REFERENCES data_contracts(_id),
    source_object_id UUID REFERENCES data_objects(_id),
    source_field_id UUID REFERENCES data_object_fields(_id),
    target_contract_id UUID REFERENCES data_contracts(_id),
    target_object_id UUID REFERENCES data_objects(_id),
    target_field_id UUID REFERENCES data_object_fields(_id),
    transformation_type VARCHAR(100),
    transformation_logic TEXT,
    transformation_rules JSONB DEFAULT '{}',
    lineage_type VARCHAR(50) NOT NULL DEFAULT 'field_to_field' CHECK (lineage_type IN ('field_to_field', 'object_to_object', 'contract_to_contract')),
    confidence_score DECIMAL(3,2) DEFAULT 1.0 CHECK (confidence_score >= 0.0 AND confidence_score <= 1.0),
    is_verified BOOLEAN DEFAULT FALSE,
    verified_by_user_id UUID REFERENCES users(_id),
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: lineage_graphs
CREATE TABLE IF NOT EXISTS lineage_graphs (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    graph_name VARCHAR(255) NOT NULL,
    graph_type VARCHAR(100) NOT NULL,
    root_entity_type VARCHAR(100) NOT NULL,
    root_entity_id UUID NOT NULL,
    graph_definition JSONB NOT NULL,
    is_cached BOOLEAN DEFAULT FALSE,
    cache_expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: impact_analysis
CREATE TABLE IF NOT EXISTS impact_analysis (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_entity_type VARCHAR(100) NOT NULL,
    source_entity_id UUID NOT NULL,
    change_type VARCHAR(100) NOT NULL,
    impact_scope JSONB NOT NULL,
    affected_entities JSONB NOT NULL,
    risk_level VARCHAR(50) DEFAULT 'medium',
    recommendations TEXT,
    analysis_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    analyzed_by_user_id UUID REFERENCES users(_id)
);

-- Tabela: monitoring_metrics
CREATE TABLE IF NOT EXISTS monitoring_metrics (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID REFERENCES data_contracts(_id),
    metric_name VARCHAR(255) NOT NULL,
    metric_type VARCHAR(100) NOT NULL,
    metric_value DECIMAL(15,4),
    metric_unit VARCHAR(50),
    dimensions JSONB DEFAULT '{}',
    timestamp TIMESTAMP NOT NULL,
    collected_by VARCHAR(100)
);

-- Tabela: performance_metrics
CREATE TABLE IF NOT EXISTS performance_metrics (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID REFERENCES data_contracts(_id),
    operation_type VARCHAR(100) NOT NULL,
    execution_time_ms INTEGER,
    throughput_per_second DECIMAL(10,2),
    error_rate DECIMAL(5,4),
    success_rate DECIMAL(5,4),
    resource_usage JSONB DEFAULT '{}',
    timestamp TIMESTAMP NOT NULL
);

-- Tabela: sla_definitions
CREATE TABLE IF NOT EXISTS sla_definitions (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    contract_id UUID NOT NULL REFERENCES data_contracts(_id) ON DELETE CASCADE,
    sla_name VARCHAR(255) NOT NULL,
    sla_type VARCHAR(100) NOT NULL,
    target_value DECIMAL(10,4) NOT NULL,
    threshold_warning DECIMAL(10,4),
    threshold_critical DECIMAL(10,4),
    measurement_window VARCHAR(50) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: sla_violations
CREATE TABLE IF NOT EXISTS sla_violations (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sla_id UUID NOT NULL REFERENCES sla_definitions(_id) ON DELETE CASCADE,
    violation_type VARCHAR(100) NOT NULL,
    actual_value DECIMAL(10,4) NOT NULL,
    threshold_value DECIMAL(10,4) NOT NULL,
    severity VARCHAR(50) NOT NULL,
    violation_start TIMESTAMP NOT NULL,
    violation_end TIMESTAMP,
    resolution_notes TEXT,
    resolved_by_user_id UUID REFERENCES users(_id)
);

-- Tabela: notifications
CREATE TABLE IF NOT EXISTS notifications (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(_id) ON DELETE CASCADE,
    contract_id UUID REFERENCES data_contracts(_id) ON DELETE CASCADE,
    notification_type VARCHAR(100) NOT NULL CHECK (notification_type IN ('contract_expiring', 'compliance_violation', 'quality_issue', 'approval_required', 'system_alert')),
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP,
    priority VARCHAR(20) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'critical')),
    category VARCHAR(100),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: alert_rules
CREATE TABLE IF NOT EXISTS alert_rules (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rule_name VARCHAR(255) NOT NULL,
    rule_type VARCHAR(100) NOT NULL,
    condition_expression TEXT NOT NULL,
    severity VARCHAR(50) NOT NULL,
    notification_channels VARCHAR(100)[] DEFAULT '{}',
    is_active BOOLEAN DEFAULT TRUE,
    created_by_user_id UUID REFERENCES users(_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: alert_instances
CREATE TABLE IF NOT EXISTS alert_instances (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rule_id UUID NOT NULL REFERENCES alert_rules(_id) ON DELETE CASCADE,
    contract_id UUID REFERENCES data_contracts(_id),
    alert_status VARCHAR(50) NOT NULL DEFAULT 'active',
    triggered_at TIMESTAMP NOT NULL,
    resolved_at TIMESTAMP,
    alert_data JSONB DEFAULT '{}',
    resolution_notes TEXT,
    resolved_by_user_id UUID REFERENCES users(_id)
);

-- Tabela: system_configurations
CREATE TABLE IF NOT EXISTS system_configurations (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    config_key VARCHAR(255) UNIQUE NOT NULL,
    config_value TEXT NOT NULL,
    config_type VARCHAR(50) NOT NULL,
    description TEXT,
    is_encrypted BOOLEAN DEFAULT FALSE,
    country_specific VARCHAR(3),
    updated_by_user_id UUID REFERENCES users(_id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: metadata_tags (MANTIDA CONFORME SOLICITADO)
CREATE TABLE IF NOT EXISTS metadata_tags (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tag_name VARCHAR(100) UNIQUE NOT NULL,
    tag_category VARCHAR(100),
    tag_description TEXT,
    tag_color VARCHAR(7) CHECK (tag_color ~ '^#[0-9A-Fa-f]{6}$' OR tag_color IS NULL),
    is_system_tag BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela: entity_tags (MANTIDA CONFORME SOLICITADO)
CREATE TABLE IF NOT EXISTS entity_tags (
    _id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    entity_type VARCHAR(100) NOT NULL,
    entity_id UUID NOT NULL,
    tag_id UUID NOT NULL REFERENCES metadata_tags(_id) ON DELETE CASCADE,
    tagged_by_user_id UUID REFERENCES users(_id),
    tagged_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===== ÍNDICES PARA PERFORMANCE =====

-- Índices principais
CREATE INDEX IF NOT EXISTS idx_contracts_status ON data_contracts(contract_status);
CREATE INDEX IF NOT EXISTS idx_contracts_country ON data_contracts(country_code);
CREATE INDEX IF NOT EXISTS idx_contracts_classification ON data_contracts(data_classification);
CREATE INDEX IF NOT EXISTS idx_contracts_country_status ON data_contracts(country_code, contract_status);
CREATE INDEX IF NOT EXISTS idx_contracts_owner_country ON data_contracts(business_owner_id, country_code);

CREATE INDEX IF NOT EXISTS idx_versions_contract ON contract_versions(contract_id);
CREATE INDEX IF NOT EXISTS idx_versions_number ON contract_versions(version_number);
CREATE INDEX IF NOT EXISTS idx_versions_contract_country ON contract_versions(contract_id, country_code);

CREATE INDEX IF NOT EXISTS idx_objects_contract ON data_objects(contract_id);
CREATE INDEX IF NOT EXISTS idx_objects_type ON data_objects(object_type);

CREATE INDEX IF NOT EXISTS idx_fields_object ON data_object_fields(data_object_id);
CREATE INDEX IF NOT EXISTS idx_fields_pii ON data_object_fields(is_pii);
CREATE INDEX IF NOT EXISTS idx_fields_sensitive ON data_object_fields(is_sensitive);

CREATE INDEX IF NOT EXISTS idx_policies_contract ON access_policies(contract_id);
CREATE INDEX IF NOT EXISTS idx_policies_type ON access_policies(policy_type);
CREATE INDEX IF NOT EXISTS idx_policies_contract_active ON access_policies(contract_id, is_active);

CREATE INDEX IF NOT EXISTS idx_audit_contract ON audit_logs(contract_id);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action_type);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_user_action_date ON audit_logs(user_id, action_type, created_at);

CREATE INDEX IF NOT EXISTS idx_quality_contract ON quality_metrics(contract_id);
CREATE INDEX IF NOT EXISTS idx_quality_type ON quality_metrics(metric_type);
CREATE INDEX IF NOT EXISTS idx_quality_contract_active ON quality_metrics(contract_id, is_active);

CREATE INDEX IF NOT EXISTS idx_lineage_source_contract ON data_lineage(source_contract_id);
CREATE INDEX IF NOT EXISTS idx_lineage_target_contract ON data_lineage(target_contract_id);

CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(notification_type);
CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id, is_read);

CREATE INDEX IF NOT EXISTS idx_entity_tags_type_entity ON entity_tags(entity_type, entity_id);

-- ===== TRIGGERS PARA UPDATED_AT =====

-- Função para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para tabelas com updated_at
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_user_groups_updated_at BEFORE UPDATE ON user_groups FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_user_roles_updated_at BEFORE UPDATE ON user_roles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_compliance_frameworks_updated_at BEFORE UPDATE ON compliance_frameworks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_compliance_rules_updated_at BEFORE UPDATE ON compliance_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_contracts_updated_at BEFORE UPDATE ON data_contracts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contract_versions_updated_at BEFORE UPDATE ON contract_versions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contract_layouts_updated_at BEFORE UPDATE ON contract_layouts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_contract_compliance_frameworks_updated_at BEFORE UPDATE ON contract_compliance_frameworks FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_objects_updated_at BEFORE UPDATE ON data_objects FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_object_fields_updated_at BEFORE UPDATE ON data_object_fields FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_schemas_updated_at BEFORE UPDATE ON data_schemas FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_access_policies_updated_at BEFORE UPDATE ON access_policies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_masking_policies_updated_at BEFORE UPDATE ON data_masking_policies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_audit_logs_updated_at BEFORE UPDATE ON audit_logs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_quality_metrics_updated_at BEFORE UPDATE ON quality_metrics FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_quality_rules_updated_at BEFORE UPDATE ON quality_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_data_lineage_updated_at BEFORE UPDATE ON data_lineage FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_lineage_graphs_updated_at BEFORE UPDATE ON lineage_graphs FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_sla_definitions_updated_at BEFORE UPDATE ON sla_definitions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_notifications_updated_at BEFORE UPDATE ON notifications FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_alert_rules_updated_at BEFORE UPDATE ON alert_rules FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_system_configurations_updated_at BEFORE UPDATE ON system_configurations FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ===== DADOS MOCK REALISTAS =====

-- Inserir usuários de exemplo
INSERT INTO users (username, email, full_name, password_hash, is_superuser, country_access) VALUES
('admin', 'admin@datagovernance.com', 'Administrador do Sistema', 'hashed_password_admin', TRUE, ARRAY['BRA', 'USA', 'EUR']),
('carlos.morais', 'carlos.morais@datagovernance.com', 'Carlos Morais', 'hashed_password_carlos', FALSE, ARRAY['BRA', 'USA']),
('ana.silva', 'ana.silva@datagovernance.com', 'Ana Silva', 'hashed_password_ana', FALSE, ARRAY['BRA']),
('john.doe', 'john.doe@datagovernance.com', 'John Doe', 'hashed_password_john', FALSE, ARRAY['USA']),
('marie.dupont', 'marie.dupont@datagovernance.com', 'Marie Dupont', 'hashed_password_marie', FALSE, ARRAY['EUR'])
ON CONFLICT (username) DO NOTHING;

-- Inserir frameworks de compliance
INSERT INTO compliance_frameworks (framework_name, framework_code, description, applicable_countries) VALUES
('Lei Geral de Proteção de Dados', 'LGPD', 'Framework brasileiro de proteção de dados pessoais', ARRAY['BRA']),
('General Data Protection Regulation', 'GDPR', 'Regulamento europeu de proteção de dados', ARRAY['EUR']),
('California Consumer Privacy Act', 'CCPA', 'Lei californiana de privacidade do consumidor', ARRAY['USA']),
('Health Insurance Portability and Accountability Act', 'HIPAA', 'Lei americana para proteção de dados de saúde', ARRAY['USA']),
('Sarbanes-Oxley Act', 'SOX', 'Lei americana para transparência corporativa', ARRAY['USA'])
ON CONFLICT (framework_code) DO NOTHING;

-- Inserir grupos de usuários
INSERT INTO user_groups (group_name, description, contract_access_level, country_restrictions) VALUES
('Data Stewards', 'Responsáveis pela governança de dados', 'write', ARRAY['BRA', 'USA']),
('Data Analysts', 'Analistas de dados com acesso de leitura', 'read', ARRAY['BRA']),
('Compliance Officers', 'Responsáveis por compliance regulatório', 'admin', ARRAY['BRA', 'USA', 'EUR']),
('Technical Owners', 'Proprietários técnicos de contratos', 'write', ARRAY['BRA', 'USA'])
ON CONFLICT (group_name) DO NOTHING;

-- Inserir roles do sistema
INSERT INTO user_roles (role_name, description, permissions, is_system_role) VALUES
('Contract Admin', 'Administrador de contratos', '{"contracts": ["create", "read", "update", "delete"], "quality": ["read", "write"]}', TRUE),
('Quality Manager', 'Gerente de qualidade de dados', '{"quality": ["read", "write", "execute"], "contracts": ["read"]}', TRUE),
('Auditor', 'Auditor do sistema', '{"audit": ["read"], "contracts": ["read"], "compliance": ["read"]}', TRUE),
('Data Owner', 'Proprietário de dados', '{"contracts": ["create", "read", "update"], "objects": ["create", "read", "update"]}', FALSE)
ON CONFLICT (role_name) DO NOTHING;

-- Inserir tags de metadados
INSERT INTO metadata_tags (tag_name, tag_category, tag_description, tag_color, is_system_tag) VALUES
('PII', 'Classificação', 'Dados Pessoais Identificáveis', '#FF6B6B', TRUE),
('Financeiro', 'Domínio', 'Dados relacionados a finanças', '#4ECDC4', FALSE),
('Crítico', 'Prioridade', 'Dados críticos para o negócio', '#FF8E53', TRUE),
('Público', 'Acesso', 'Dados de acesso público', '#95E1D3', FALSE),
('Confidencial', 'Acesso', 'Dados confidenciais', '#F38BA8', TRUE),
('Produção', 'Ambiente', 'Ambiente de produção', '#A8DADC', FALSE),
('Desenvolvimento', 'Ambiente', 'Ambiente de desenvolvimento', '#457B9D', FALSE),
('Analytics', 'Uso', 'Dados para análises', '#1D3557', FALSE)
ON CONFLICT (tag_name) DO NOTHING;

-- Inserir contratos de exemplo
DO $$
DECLARE
    admin_id UUID;
    carlos_id UUID;
    ana_id UUID;
    contract1_id UUID;
    contract2_id UUID;
    lgpd_id UUID;
    gdpr_id UUID;
BEGIN
    -- Obter IDs dos usuários
    SELECT _id INTO admin_id FROM users WHERE username = 'admin';
    SELECT _id INTO carlos_id FROM users WHERE username = 'carlos.morais';
    SELECT _id INTO ana_id FROM users WHERE username = 'ana.silva';
    
    -- Obter IDs dos frameworks
    SELECT _id INTO lgpd_id FROM compliance_frameworks WHERE framework_code = 'LGPD';
    SELECT _id INTO gdpr_id FROM compliance_frameworks WHERE framework_code = 'GDPR';
    
    -- Inserir contratos
    INSERT INTO data_contracts (
        contract_name, contract_description, contract_version, contract_status,
        data_classification, business_owner_id, technical_owner_id, data_steward_id,
        country_code, jurisdiction, region, regulatory_framework,
        effective_date, expiration_date, review_date, data_retention_days,
        created_by_user_id
    ) VALUES
    (
        'Contrato de Dados de Clientes Brasil',
        'Contrato para governança de dados de clientes no Brasil, incluindo informações pessoais e transacionais',
        '2.1.0', 'active', 'confidential',
        carlos_id, ana_id, carlos_id,
        'BRA', 'Brasil', 'América do Sul', 'LGPD',
        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP + INTERVAL '2 years', CURRENT_TIMESTAMP + INTERVAL '6 months', 2555,
        admin_id
    ),
    (
        'Customer Analytics Data Contract US',
        'Data contract for customer analytics data in the United States market',
        '1.5.2', 'active', 'internal',
        carlos_id, ana_id, carlos_id,
        'USA', 'United States', 'North America', 'CCPA',
        CURRENT_TIMESTAMP, CURRENT_TIMESTAMP + INTERVAL '18 months', CURRENT_TIMESTAMP + INTERVAL '3 months', 1825,
        admin_id
    )
    RETURNING _id INTO contract1_id;
    
    -- Obter ID do segundo contrato
    SELECT _id INTO contract2_id FROM data_contracts WHERE contract_name = 'Customer Analytics Data Contract US';
    
    -- Inserir associações de compliance
    INSERT INTO contract_compliance_frameworks (contract_id, framework_id, compliance_status) VALUES
    (contract1_id, lgpd_id, 'compliant'),
    (contract2_id, lgpd_id, 'pending');
    
    -- Inserir objetos de dados
    INSERT INTO data_objects (
        contract_id, object_name, object_type, object_description,
        data_format, storage_location, encryption_required, tags
    ) VALUES
    (
        contract1_id, 'customers_brazil', 'table',
        'Tabela principal de clientes do Brasil com dados pessoais',
        'parquet', 's3://datalake/customers/brazil/', TRUE,
        ARRAY['PII', 'Crítico', 'Confidencial']
    ),
    (
        contract1_id, 'transactions_brazil', 'table',
        'Transações financeiras de clientes brasileiros',
        'delta', 's3://datalake/transactions/brazil/', TRUE,
        ARRAY['Financeiro', 'Crítico']
    ),
    (
        contract2_id, 'customer_analytics_us', 'view',
        'View analítica de dados de clientes americanos',
        'sql', 'analytics_db.customer_analytics_us', FALSE,
        ARRAY['Analytics', 'Público']
    );
    
END $$;

-- Inserir configurações do sistema
INSERT INTO system_configurations (config_key, config_value, config_type, description) VALUES
('data_retention_default_days', '1095', 'integer', 'Período padrão de retenção de dados em dias'),
('encryption_algorithm', 'AES-256', 'string', 'Algoritmo de criptografia padrão'),
('audit_log_retention_days', '2555', 'integer', 'Período de retenção dos logs de auditoria'),
('notification_email_enabled', 'true', 'boolean', 'Habilitar notificações por email'),
('quality_check_frequency_hours', '24', 'integer', 'Frequência de execução das verificações de qualidade')
ON CONFLICT (config_key) DO NOTHING;

-- Inserir notificações de exemplo
DO $$
DECLARE
    carlos_id UUID;
    contract_id UUID;
BEGIN
    SELECT _id INTO carlos_id FROM users WHERE username = 'carlos.morais';
    SELECT _id INTO contract_id FROM data_contracts WHERE contract_name = 'Contrato de Dados de Clientes Brasil';
    
    INSERT INTO notifications (
        user_id, contract_id, notification_type, title, message, priority
    ) VALUES
    (
        carlos_id, contract_id, 'contract_expiring',
        'Contrato próximo ao vencimento',
        'O contrato "Contrato de Dados de Clientes Brasil" vence em 30 dias. Revisar e renovar se necessário.',
        'high'
    ),
    (
        carlos_id, NULL, 'system_alert',
        'Sistema de qualidade executado',
        'Verificação de qualidade de dados executada com sucesso. 15 métricas avaliadas.',
        'medium'
    );
END $$;

-- ===== COMENTÁRIOS FINAIS =====

COMMENT ON DATABASE postgres IS 'Data Governance API - Base de dados completa com 30+ tabelas para governança enterprise';

-- Estatísticas finais
SELECT 
    'Inicialização completa!' as status,
    (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public') as total_tables,
    (SELECT COUNT(*) FROM users) as total_users,
    (SELECT COUNT(*) FROM data_contracts) as total_contracts,
    (SELECT COUNT(*) FROM metadata_tags) as total_tags,
    (SELECT COUNT(*) FROM compliance_frameworks) as total_frameworks;

